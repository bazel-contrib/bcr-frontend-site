��
'
apple_supportlibapple_support.bzl�#apple_support.action_required_attrs�Returns a dictionary with required attributes for registering actions on Apple platforms.

This method adds private attributes which should not be used outside of the apple_support
codebase. It also adds the following attributes which are considered to be public for rule
maintainers to use:

 * `_xcode_config`: Attribute that references a target containing the single
   `apple_common.XcodeVersionConfig` provider. This provider can be used to inspect Xcode-related
   properties about the Xcode being used for the build, as specified with the `--xcode_version`
   Bazel flag. The most common way to retrieve this provider is:
   `ctx.attr._xcode_config[apple_common.XcodeVersionConfig]`.

The returned `dict` can be added to the rule's attributes using a [Starlark dictionary union expression: `|`](https://bazel.build/rules/lib/core/dict).
*�
�
#apple_support.action_required_attrs�Returns a dictionary with required attributes for registering actions on Apple platforms.

This method adds private attributes which should not be used outside of the apple_support
codebase. It also adds the following attributes which are considered to be public for rule
maintainers to use:

 * `_xcode_config`: Attribute that references a target containing the single
   `apple_common.XcodeVersionConfig` provider. This provider can be used to inspect Xcode-related
   properties about the Xcode being used for the build, as specified with the `--xcode_version`
   Bazel flag. The most common way to retrieve this provider is:
   `ctx.attr._xcode_config[apple_common.XcodeVersionConfig]`.

The returned `dict` can be added to the rule's attributes using a [Starlark dictionary union expression: `|`](https://bazel.build/rules/lib/core/dict).
"L
JA `dict` object containing attributes to be added to rule implementations.2?
_action_required_attrs%@apple_support//lib:apple_support.bzl�3apple_support.path_placeholders.platform_frameworksTReturns the platform's frameworks directory, anchored to the Xcode path placeholder.*�
�
3apple_support.path_placeholders.platform_frameworks~
apple_platform_info_An ApplePlatformInfo provider.
Typically from `apple_support.platform_info_from_rule_ctx(ctx)`.None(�
apple_fragmentuA reference to the apple fragment. Typically from `ctx.fragments.apple`.
Deprecated: Use apple_platform_info instead.None(TReturns the platform's frameworks directory, anchored to the Xcode path placeholder."d
bReturns a string with the platform's frameworks directory, anchored to the Xcode path
placeholder.2N
%_platform_frameworks_path_placeholder%@apple_support//lib:apple_support.bzl�
~
apple_platform_info_An ApplePlatformInfo provider.
Typically from `apple_support.platform_info_from_rule_ctx(ctx)`.None(�
�
apple_fragmentuA reference to the apple fragment. Typically from `ctx.fragments.apple`.
Deprecated: Use apple_platform_info instead.None(�'apple_support.path_placeholders.sdkroot�Returns a placeholder value to be replaced with SDKROOT during action execution.

In order to get this values replaced, you'll need to use the `apple_support.run()` API by
setting the `xcode_path_resolve_level` argument to either the
`apple_support.xcode_path_resolve_level.args` or
`apple_support.xcode_path_resolve_level.args_and_files` value.
*�
�
'apple_support.path_placeholders.sdkroot�Returns a placeholder value to be replaced with SDKROOT during action execution.

In order to get this values replaced, you'll need to use the `apple_support.run()` API by
setting the `xcode_path_resolve_level` argument to either the
`apple_support.xcode_path_resolve_level.args` or
`apple_support.xcode_path_resolve_level.args_and_files` value.
"R
PReturns a placeholder value to be replaced with SDKROOT during action execution.2B
_sdkroot_path_placeholder%@apple_support//lib:apple_support.bzl�%apple_support.path_placeholders.xcode�Returns a placeholder value to be replaced with DEVELOPER_DIR during action execution.

In order to get this values replaced, you'll need to use the `apple_support.run()` API by
setting the `xcode_path_resolve_level` argument to either the
`apple_support.xcode_path_resolve_level.args` or
`apple_support.xcode_path_resolve_level.args_and_files` value.
*�
�
%apple_support.path_placeholders.xcode�Returns a placeholder value to be replaced with DEVELOPER_DIR during action execution.

In order to get this values replaced, you'll need to use the `apple_support.run()` API by
setting the `xcode_path_resolve_level` argument to either the
`apple_support.xcode_path_resolve_level.args` or
`apple_support.xcode_path_resolve_level.args_and_files` value.
"X
VReturns a placeholder value to be replaced with DEVELOPER_DIR during action execution.2@
_xcode_path_placeholder%@apple_support//lib:apple_support.bzl�'apple_support.platform_constraint_attrs�Returns a dictionary of all known Apple platform constraints that can be resolved.

The returned `dict` can be added to the rule's attributes using a [Starlark dictionary union expression: `|`](https://bazel.build/rules/lib/core/dict).
*�
�
'apple_support.platform_constraint_attrs�Returns a dictionary of all known Apple platform constraints that can be resolved.

The returned `dict` can be added to the rule's attributes using a [Starlark dictionary union expression: `|`](https://bazel.build/rules/lib/core/dict).
"L
JA `dict` object containing attributes to be added to rule implementations.2C
_platform_constraint_attrs%@apple_support//lib:apple_support.bzl�(apple_support.run�Registers an action to run on an Apple machine.

In order to use `apple_support.run()`, you'll need to modify your rule definition to add the
following:

  * `fragments = ["apple"]`
  * Add the `apple_support.action_required_attrs()` attributes to the `attrs` dictionary. This
    can be done using a [Starlark dictionary union expression: `|`](https://bazel.build/rules/lib/core/dict)

This method registers an action to run on an Apple machine, configuring it to ensure that the
`DEVELOPER_DIR` and `SDKROOT` environment variables are set.

If the `xcode_path_resolve_level` is enabled, this method will replace the given `executable`
with a wrapper script that will replace all instances of the `__BAZEL_XCODE_DEVELOPER_DIR__` and
`__BAZEL_XCODE_SDKROOT__` placeholders in the given arguments with the values of `DEVELOPER_DIR`
and `SDKROOT`, respectively.

In your rule implementation, you can use references to Xcode through the
`apple_support.path_placeholders` API, which in turn uses the placeholder values as described
above. The available APIs are:

  * `apple_support.path_placeholders.xcode()`: Returns a reference to the Xcode.app
    installation path.
  * `apple_support.path_placeholders.sdkroot()`: Returns a reference to the SDK root path.
  * `apple_support.path_placeholders.platform_frameworks(ctx)`: Returns the Frameworks path
    within the Xcode installation, for the requested platform.

If the `xcode_path_resolve_level` value is:

  * `apple_support.xcode_path_resolve_level.none`: No processing will be done to the given
    `arguments`.
  * `apple_support.xcode_path_resolve_level.args`: Only instances of the placeholders in the
     argument strings will be replaced.
  * `apple_support.xcode_path_resolve_level.args_and_files`: Instances of the placeholders in
     the arguments strings and instances of the placeholders within response files (i.e. any
     path argument beginning with `@`) will be replaced.
*�
�
apple_support.run5
actions&The actions provider from ctx.actions. (�
xcode_config�The xcode_config as found in the current rule or aspect's
context. Typically from `ctx.attr._xcode_config[apple_common.XcodeVersionConfig]`. (=
apple_platform_infoAn ApplePlatformInfo provider.None(�
apple_fragmentuA reference to the apple fragment. Typically from `ctx.fragments.apple`.
Deprecated: Use apple_platform_info instead.None(`
xcode_path_resolve_level<The level of Xcode path replacement required for the action.None(J
kwargs>See `ctx.actions.run` for the rest of the available arguments.(�Registers an action to run on an Apple machine.

In order to use `apple_support.run()`, you'll need to modify your rule definition to add the
following:

  * `fragments = ["apple"]`
  * Add the `apple_support.action_required_attrs()` attributes to the `attrs` dictionary. This
    can be done using a [Starlark dictionary union expression: `|`](https://bazel.build/rules/lib/core/dict)

This method registers an action to run on an Apple machine, configuring it to ensure that the
`DEVELOPER_DIR` and `SDKROOT` environment variables are set.

If the `xcode_path_resolve_level` is enabled, this method will replace the given `executable`
with a wrapper script that will replace all instances of the `__BAZEL_XCODE_DEVELOPER_DIR__` and
`__BAZEL_XCODE_SDKROOT__` placeholders in the given arguments with the values of `DEVELOPER_DIR`
and `SDKROOT`, respectively.

In your rule implementation, you can use references to Xcode through the
`apple_support.path_placeholders` API, which in turn uses the placeholder values as described
above. The available APIs are:

  * `apple_support.path_placeholders.xcode()`: Returns a reference to the Xcode.app
    installation path.
  * `apple_support.path_placeholders.sdkroot()`: Returns a reference to the SDK root path.
  * `apple_support.path_placeholders.platform_frameworks(ctx)`: Returns the Frameworks path
    within the Xcode installation, for the requested platform.

If the `xcode_path_resolve_level` value is:

  * `apple_support.xcode_path_resolve_level.none`: No processing will be done to the given
    `arguments`.
  * `apple_support.xcode_path_resolve_level.args`: Only instances of the placeholders in the
     argument strings will be replaced.
  * `apple_support.xcode_path_resolve_level.args_and_files`: Instances of the placeholders in
     the arguments strings and instances of the placeholders within response files (i.e. any
     path argument beginning with `@`) will be replaced.
2-
_run%@apple_support//lib:apple_support.bzl7
5
actions&The actions provider from ctx.actions. (�
�
xcode_config�The xcode_config as found in the current rule or aspect's
context. Typically from `ctx.attr._xcode_config[apple_common.XcodeVersionConfig]`. (?
=
apple_platform_infoAn ApplePlatformInfo provider.None(�
�
apple_fragmentuA reference to the apple fragment. Typically from `ctx.fragments.apple`.
Deprecated: Use apple_platform_info instead.None(b
`
xcode_path_resolve_level<The level of Xcode path replacement required for the action.None(L
J
kwargs>See `ctx.actions.run` for the rest of the available arguments.(�apple_support.run_shell�Registers a shell action to run on an Apple machine.

In order to use `apple_support.run_shell()`, you'll need to modify your rule definition to add
the following:

  * `fragments = ["apple"]`
  * Add the `apple_support.action_required_attrs()` attributes to the `attrs` dictionary. This
    can be done using a [Starlark dictionary union expression: `|`](https://bazel.build/rules/lib/core/dict).

This method registers an action to run on an Apple machine, configuring it to ensure that the
`DEVELOPER_DIR` and `SDKROOT` environment variables are set.

`run_shell` does not support placeholder substitution. To achieve placeholder substitution,
please use `run` instead.
*�
�	
apple_support.run_shell5
actions&The actions provider from ctx.actions. (�
xcode_config�The xcode_config as found in the current rule or aspect's
context. Typically from `ctx.attr._xcode_config[apple_common.XcodeVersionConfig]`. (=
apple_platform_infoAn ApplePlatformInfo provider.None(�
apple_fragmentuA reference to the apple fragment. Typically from `ctx.fragments.apple`.
Deprecated: Use apple_platform_info instead.None(P
kwargsDSee `ctx.actions.run_shell` for the rest of the available arguments.(�Registers a shell action to run on an Apple machine.

In order to use `apple_support.run_shell()`, you'll need to modify your rule definition to add
the following:

  * `fragments = ["apple"]`
  * Add the `apple_support.action_required_attrs()` attributes to the `attrs` dictionary. This
    can be done using a [Starlark dictionary union expression: `|`](https://bazel.build/rules/lib/core/dict).

This method registers an action to run on an Apple machine, configuring it to ensure that the
`DEVELOPER_DIR` and `SDKROOT` environment variables are set.

`run_shell` does not support placeholder substitution. To achieve placeholder substitution,
please use `run` instead.
23

_run_shell%@apple_support//lib:apple_support.bzl7
5
actions&The actions provider from ctx.actions. (�
�
xcode_config�The xcode_config as found in the current rule or aspect's
context. Typically from `ctx.attr._xcode_config[apple_common.XcodeVersionConfig]`. (?
=
apple_platform_infoAn ApplePlatformInfo provider.None(�
�
apple_fragmentuA reference to the apple fragment. Typically from `ctx.fragments.apple`.
Deprecated: Use apple_platform_info instead.None(R
P
kwargsDSee `ctx.actions.run_shell` for the rest of the available arguments.(�'apple_support.target_arch_from_rule_ctx�Returns a `String` representing the target architecture based on constraints.

The returned `String` will represent a cpu architecture, such as `arm64` or `arm64e`.

In order to use `apple_support.target_arch_from_rule_ctx()`, you'll need to modify your rule
definition to add the following:

  * Add the `apple_support.platform_constraint_attrs()` attributes to the `attrs` dictionary.
    This can be done using a [Starlark dictionary union expression: `|`](https://bazel.build/rules/lib/core/dict).
*�
�
'apple_support.target_arch_from_rule_ctxQ
ctxFThe context of the rule that has Apple platform constraint attributes. (b
fail_on_missing_constraint<Whether to fail if no constraint is found. (default: `True`)True(�Returns a `String` representing the target architecture based on constraints.

The returned `String` will represent a cpu architecture, such as `arm64` or `arm64e`.

In order to use `apple_support.target_arch_from_rule_ctx()`, you'll need to modify your rule
definition to add the following:

  * Add the `apple_support.platform_constraint_attrs()` attributes to the `attrs` dictionary.
    This can be done using a [Starlark dictionary union expression: `|`](https://bazel.build/rules/lib/core/dict).
"�
�A `String` representing the selected target architecture or cpu type (e.g. `arm64`,
`arm64e`) or `None` if no constraint is found.2C
_target_arch_from_rule_ctx%@apple_support//lib:apple_support.bzlS
Q
ctxFThe context of the rule that has Apple platform constraint attributes. (d
b
fail_on_missing_constraint<Whether to fail if no constraint is found. (default: `True`)True(�.apple_support.target_environment_from_rule_ctx�Returns a `String` representing the target environment based on constraints.

The returned `String` will represent an environment, such as `device` or `simulator`.

For consistency with other Apple platforms, `macos` is considered to be a `device`.

In order to use `apple_support.target_environment_from_rule_ctx()`, you'll need to modify your
rule definition to add the following:

  * Add the `apple_support.platform_constraint_attrs()` attributes to the `attrs` dictionary.
    This can be done using a [Starlark dictionary union expression: `|`](https://bazel.build/rules/lib/core/dict).
*�	
�
.apple_support.target_environment_from_rule_ctxQ
ctxFThe context of the rule that has Apple platform constraint attributes. (b
fail_on_missing_constraint<Whether to fail if no constraint is found. (default: `True`)True(�Returns a `String` representing the target environment based on constraints.

The returned `String` will represent an environment, such as `device` or `simulator`.

For consistency with other Apple platforms, `macos` is considered to be a `device`.

In order to use `apple_support.target_environment_from_rule_ctx()`, you'll need to modify your
rule definition to add the following:

  * Add the `apple_support.platform_constraint_attrs()` attributes to the `attrs` dictionary.
    This can be done using a [Starlark dictionary union expression: `|`](https://bazel.build/rules/lib/core/dict).
"u
sA `String` representing the selected environment (e.g. `device`, `simulator`)  or `None` if
no constraint is found.2J
!_target_environment_from_rule_ctx%@apple_support//lib:apple_support.bzlS
Q
ctxFThe context of the rule that has Apple platform constraint attributes. (d
b
fail_on_missing_constraint<Whether to fail if no constraint is found. (default: `True`)True(�%apple_support.target_os_from_rule_ctx�Returns a `String` representing the target OS based on constraints.

The returned `String` will match an equivalent value from one of the platform definitions in
`apple_common.platform_type`, such as `ios` or `macos`.

In order to use `apple_support.target_os_from_rule_ctx()`, you'll need to modify your rule
definition to add the following:

  * Add the `apple_support.platform_constraint_attrs()` attributes to the `attrs` dictionary.
    This can be done using a [Starlark dictionary union expression: `|`](https://bazel.build/rules/lib/core/dict).
*�
�
%apple_support.target_os_from_rule_ctxQ
ctxFThe context of the rule that has Apple platform constraint attributes. (b
fail_on_missing_constraint<Whether to fail if no constraint is found. (default: `True`)True(�Returns a `String` representing the target OS based on constraints.

The returned `String` will match an equivalent value from one of the platform definitions in
`apple_common.platform_type`, such as `ios` or `macos`.

In order to use `apple_support.target_os_from_rule_ctx()`, you'll need to modify your rule
definition to add the following:

  * Add the `apple_support.platform_constraint_attrs()` attributes to the `attrs` dictionary.
    This can be done using a [Starlark dictionary union expression: `|`](https://bazel.build/rules/lib/core/dict).
"T
RA `String` representing the selected Apple OS or `None` if no constraint is found.2A
_target_os_from_rule_ctx%@apple_support//lib:apple_support.bzlS
Q
ctxFThe context of the rule that has Apple platform constraint attributes. (d
b
fail_on_missing_constraint<Whether to fail if no constraint is found. (default: `True`)True(�# `apple_support` starlark module

A module of helpers for rule authors to aid in writing actions that target
Apple platforms.

To use these in your Starlark code, simply load the module; for example:

```build
load("@apple_support//lib:apple_support.bzl", "apple_support")
```�A
%
apple_supportrulesrules.doc.bzl�-apple_genrule�Genrule which provides make variables and an Apple environment on macOS.

This mirrors the native genrule except that it provides a different set of
make variables. This rule can run on any execution platform and prefers macOS
when available. When running on macOS, it also provides the Xcode environment
and execution requirements.

Example of use:

```
load("@apple_support//rules:apple_genrule.bzl", "apple_genrule")

apple_genrule(
    name = "world",
    outs = ["hi"],
    cmd = "touch $@",
)
```

This rule also does location expansion, much like the native genrule.
For example, `$(location hi)` may be used to refer to the output in the
above example.

The set of make variables that are supported for this rule:

* `OUTS`: The outs list. If you have only one output file, you can also use
          `$@`.
* `SRCS`: The srcs list (or more precisely, the pathnames of the files
          corresponding to labels in the srcs list). If you have only one
          source file, you can also use `$<`.
* `<`: srcs, if it's a single file.
* `@`: outs, if it's a single file.
* `@D`: The output directory. If there is only one filename in outs, this
        expands to the directory containing that file. If there are
        multiple filenames, this variable instead expands to the package's
        root directory in the genfiles tree, even if all the generated
        files belong to the same subdirectory.

The following environment variables are defined when the rule runs on macOS:

* `DEVELOPER_DIR`: The base developer directory as defined on Apple
                   architectures, most commonly used in invoking Apple
                   tools such as xcrun.
* `SDKROOT`: The base SDK directory as defined on Apple architectures, most
             commonly used in invoking Apple tools such as xcrun.

NOTE: `DEVELOPER_DIR` and `SDKROOT` are environment variables and *not* make
      variables. To refer to them in `cmd` you must use environment variable
      syntax (i.e. using `$$`). Example: ```cmd = "xcrun --sdkroot $$SDKROOT clang...```"�
�
apple_genrule�Genrule which provides make variables and an Apple environment on macOS.

This mirrors the native genrule except that it provides a different set of
make variables. This rule can run on any execution platform and prefers macOS
when available. When running on macOS, it also provides the Xcode environment
and execution requirements.

Example of use:

```
load("@apple_support//rules:apple_genrule.bzl", "apple_genrule")

apple_genrule(
    name = "world",
    outs = ["hi"],
    cmd = "touch $@",
)
```

This rule also does location expansion, much like the native genrule.
For example, `$(location hi)` may be used to refer to the output in the
above example.

The set of make variables that are supported for this rule:

* `OUTS`: The outs list. If you have only one output file, you can also use
          `$@`.
* `SRCS`: The srcs list (or more precisely, the pathnames of the files
          corresponding to labels in the srcs list). If you have only one
          source file, you can also use `$<`.
* `<`: srcs, if it's a single file.
* `@`: outs, if it's a single file.
* `@D`: The output directory. If there is only one filename in outs, this
        expands to the directory containing that file. If there are
        multiple filenames, this variable instead expands to the package's
        root directory in the genfiles tree, even if all the generated
        files belong to the same subdirectory.

The following environment variables are defined when the rule runs on macOS:

* `DEVELOPER_DIR`: The base developer directory as defined on Apple
                   architectures, most commonly used in invoking Apple
                   tools such as xcrun.
* `SDKROOT`: The base SDK directory as defined on Apple architectures, most
             commonly used in invoking Apple tools such as xcrun.

NOTE: `DEVELOPER_DIR` and `SDKROOT` are environment variables and *not* make
      variables. To refer to them in `cmd` you must use environment variable
      syntax (i.e. using `$$`). Example: ```cmd = "xcrun --sdkroot $$SDKROOT clang...```*
nameA unique name for this target. A
cmd6The command to run. Subject the variable substitution. �

executable�Declare output to be executable. Setting this flag to 1 means the output is an
executable file and can be run using the run command. The genrule must produce
exactly one output in this case.2Falsey
outskA list of files generated by this rule. If the executable flag is set, outs must
contain exactly one label. 8N
srcs@A list of inputs for this rule, such as source files to process.2[]D
message3A progress message to be reported as the rule runs.2""h
toolsYA list of tool dependencies for this rule, they will be available when the
action is run.2[]P

no_sandbox9If the sandbox should be disabled when the action is run.2False"@
apple_genrule/@apple_support//rules/private:apple_genrule.bzl,
*
nameA unique name for this target. C
A
cmd6The command to run. Subject the variable substitution. �
�

executable�Declare output to be executable. Setting this flag to 1 means the output is an
executable file and can be run using the run command. The genrule must produce
exactly one output in this case.2False{
y
outskA list of files generated by this rule. If the executable flag is set, outs must
contain exactly one label. 8P
N
srcs@A list of inputs for this rule, such as source files to process.2[]F
D
message3A progress message to be reported as the rule runs.2""j
h
toolsYA list of tool dependencies for this rule, they will be available when the
action is run.2[]R
P

no_sandbox9If the sandbox should be disabled when the action is run.2False�toolchain_substitution�Register a subsitution, from a variable to a file, for use in arguments in a
target's attributes. Useful for passing custom tools to a compile or link.

### Example:

```bzl
load("@apple_support//rules:toolchain_substitution.bzl", "toolchain_substitution")

toolchain_substitution(
    name = "resource_rules",
    src = "resource_rules.plist",
    var_name = "RULES",
)

ios_application(
    ...
    codesignopts = ["--resource-rules=$(RULES)"],
    codesign_inputs = [":resource_rules"],
    toolchains = [":resource_rules"],
)
```"�
�
toolchain_substitution�Register a subsitution, from a variable to a file, for use in arguments in a
target's attributes. Useful for passing custom tools to a compile or link.

### Example:

```bzl
load("@apple_support//rules:toolchain_substitution.bzl", "toolchain_substitution")

toolchain_substitution(
    name = "resource_rules",
    src = "resource_rules.plist",
    var_name = "RULES",
)

ios_application(
    ...
    codesignopts = ["--resource-rules=$(RULES)"],
    codesign_inputs = [":resource_rules"],
    toolchains = [":resource_rules"],
)
```*
nameA unique name for this target. ;
var_name+Name of the variable to substitute, ex: FOO $
srcSource file to substitute "J
toolchain_substitution0@apple_support//rules:toolchain_substitution.bzl,
*
nameA unique name for this target. =
;
var_name+Name of the variable to substitute, ex: FOO &
$
srcSource file to substitute �universal_binary�This rule produces a multi-architecture ("fat") binary targeting Apple macOS
platforms *regardless* of the architecture of the macOS host platform. The
`lipo` tool is used to combine built binaries of multiple architectures. For
non-macOS platforms, this simply just creates a symbolic link of the input
binary."�
�
universal_binary�This rule produces a multi-architecture ("fat") binary targeting Apple macOS
platforms *regardless* of the architecture of the macOS host platform. The
`lipo` tool is used to combine built binaries of multiple architectures. For
non-macOS platforms, this simply just creates a symbolic link of the input
binary.*
nameA unique name for this target. 5
binary'Target to generate a 'fat' binary from. ">
universal_binary*@apple_support//rules:universal_binary.bzl8,
*
nameA unique name for this target. 7
5
binary'Target to generate a 'fat' binary from. "# Helper rules for Apple platforms�
'
apple_supportlibxcode_support.bzl�xcode_support.get_current_sdk�Returns the `XcodeSdkVariantInfo` provider for the current configuration.

Callers of this function must define the `_xcode_config` attribute in their
rule or aspect. This is best done using the
`apple_support.action_required_attrs()` helper.
*�
�
xcode_support.get_current_sdk&
ctxThe rule or aspect context. (�Returns the `XcodeSdkVariantInfo` provider for the current configuration.

Callers of this function must define the `_xcode_config` attribute in their
rule or aspect. This is best done using the
`apple_support.action_required_attrs()` helper.
"C
AThe `XcodeSdkVariantInfo` provider for the current configuration.29
_get_current_sdk%@apple_support//lib:xcode_support.bzl(
&
ctxThe rule or aspect context. (�xcode_support.get_current_xcode�Returns the `XcodeVersionConfig` provider for the current configuration.

Callers of this function must define the `_xcode_config` attribute in their
rule or aspect. This is best done using the
`apple_support.action_required_attrs()` helper.
*�
�
xcode_support.get_current_xcode&
ctxThe rule or aspect context. (�Returns the `XcodeVersionConfig` provider for the current configuration.

Callers of this function must define the `_xcode_config` attribute in their
rule or aspect. This is best done using the
`apple_support.action_required_attrs()` helper.
"B
@The `XcodeVersionConfig` provider for the current configuration.2;
_get_current_xcode%@apple_support//lib:xcode_support.bzl(
&
ctxThe rule or aspect context. (�'xcode_support.is_xcode_at_least_version�Returns True if Xcode version is at least a given version.

This method takes as input an `XcodeVersionConfig` provider, which can be obtained from the
`_xcode_config` attribute (e.g. `ctx.attr._xcode_config[apple_common.XcodeVersionConfig]`). This
provider should contain the Xcode version parameters with which this rule is being built with.
If you need to add this attribute to your rule implementation, please refer to
`apple_support.action_required_attrs()`.
*�
�
'xcode_support.is_xcode_at_least_version_
xcode_configKThe XcodeVersionConfig provider from the `_xcode_config` attribute's value. (M
version>The minimum desired Xcode version, as a dotted version string. (�Returns True if Xcode version is at least a given version.

This method takes as input an `XcodeVersionConfig` provider, which can be obtained from the
`_xcode_config` attribute (e.g. `ctx.attr._xcode_config[apple_common.XcodeVersionConfig]`). This
provider should contain the Xcode version parameters with which this rule is being built with.
If you need to add this attribute to your rule implementation, please refer to
`apple_support.action_required_attrs()`.
"U
STrue if the given `xcode_config` version at least as high as the requested version.2C
_is_xcode_at_least_version%@apple_support//lib:xcode_support.bzla
_
xcode_configKThe XcodeVersionConfig provider from the `_xcode_config` attribute's value. (O
M
version>The minimum desired Xcode version, as a dotted version string. (�# `xcode_support` Starlark Module

A modules of helpers for rule authors to aid in writing rules that
need to change what they do based on attributes of the active Xcode.

To use these in your Starlark code, simply load the module; for example:

```build
load("@apple_support//lib:xcode_support.bzl", "xcode_support")
```�-
2
apple_supportxcodexcode_version_at_least.bzl�+xcode_version_at_least�Creates a `config_setting` target that matches when Xcode is at least `minimum_xcode_version`.

The condition compares the resolved Xcode version, including when Xcode is
selected by default without an explicit `--xcode_version` flag. It does not
match if the resolved configuration has no Xcode version.

For example, enable a definition with Xcode 26.4 or newer:

```starlark
load("@apple_support//xcode:xcode_version_at_least.bzl", "xcode_version_at_least")
load("@rules_cc//cc:cc_library.bzl", "cc_library")

xcode_version_at_least(
    name = "xcode_26_4_or_newer",
    minimum_xcode_version = "26.4",
)

cc_library(
    name = "example",
    srcs = ["example.cc"],
    defines = select({
        ":xcode_26_4_or_newer": ["HAS_XCODE_26_4"],
        "//conditions:default": [],
    }),
)
```

When multiple thresholds appear in the same `select()`, use `after` to make
the higher threshold specialize the lower one. Continuing the example above:

```starlark
xcode_version_at_least(
    name = "xcode_27_or_newer",
    minimum_xcode_version = "27",
    after = [":xcode_26_4_or_newer"],
)

cc_library(
    name = "versioned_example",
    srcs = ["example.cc"],
    defines = select({
        ":xcode_27_or_newer": ["XCODE_LEVEL=27"],
        ":xcode_26_4_or_newer": ["XCODE_LEVEL=26"],
        "//conditions:default": ["XCODE_LEVEL=0"],
    }),
)
```

With Xcode 27 or newer, both conditions match, but the more specialized
`xcode_27_or_newer` branch wins. Without `after`, different values for these
overlapping conditions would make the `select()` ambiguous.

Declare lower thresholds before higher thresholds and use local target names
or `:name` labels to inherit a same-package `after` chain transitively. For
cross-package or fully qualified references, list every lower threshold in
the chain explicitly. Each threshold must be strictly higher than those in
its `after` list.
*�
�
xcode_version_at_least�
name|The name of the `config_setting` target to create. A companion
feature flag target named `<name>_flag` will also be created. (�
minimum_xcode_versioneThe minimum Xcode version to match (inclusive),
such as `"26.4"`, `"26.4.1"`, or `"27.0.0.27A5228h"`. (�
after�An optional list of lower-version `xcode_version_at_least` target
names or labels that this condition should refine when used together
in the same `select()` expression. If a referenced target is in the
same package, any lower thresholds it already refines are inherited
transitively.None(>

visibility(The visibility of the generated targets.None(�
kwargs�Additional keyword arguments (such as `tags` or
`constraint_values`) forwarded to `native.config_setting`. `tags` is
also forwarded to the companion `<name>_flag` target.(�Creates a `config_setting` target that matches when Xcode is at least `minimum_xcode_version`.

The condition compares the resolved Xcode version, including when Xcode is
selected by default without an explicit `--xcode_version` flag. It does not
match if the resolved configuration has no Xcode version.

For example, enable a definition with Xcode 26.4 or newer:

```starlark
load("@apple_support//xcode:xcode_version_at_least.bzl", "xcode_version_at_least")
load("@rules_cc//cc:cc_library.bzl", "cc_library")

xcode_version_at_least(
    name = "xcode_26_4_or_newer",
    minimum_xcode_version = "26.4",
)

cc_library(
    name = "example",
    srcs = ["example.cc"],
    defines = select({
        ":xcode_26_4_or_newer": ["HAS_XCODE_26_4"],
        "//conditions:default": [],
    }),
)
```

When multiple thresholds appear in the same `select()`, use `after` to make
the higher threshold specialize the lower one. Continuing the example above:

```starlark
xcode_version_at_least(
    name = "xcode_27_or_newer",
    minimum_xcode_version = "27",
    after = [":xcode_26_4_or_newer"],
)

cc_library(
    name = "versioned_example",
    srcs = ["example.cc"],
    defines = select({
        ":xcode_27_or_newer": ["XCODE_LEVEL=27"],
        ":xcode_26_4_or_newer": ["XCODE_LEVEL=26"],
        "//conditions:default": ["XCODE_LEVEL=0"],
    }),
)
```

With Xcode 27 or newer, both conditions match, but the more specialized
`xcode_27_or_newer` branch wins. Without `after`, different values for these
overlapping conditions would make the `select()` ambiguous.

Declare lower thresholds before higher thresholds and use local target names
or `:name` labels to inherit a same-package `after` chain transitively. For
cross-package or fully qualified references, list every lower threshold in
the chain explicitly. Each threshold must be strictly higher than those in
its `after` list.
2J
xcode_version_at_least0@apple_support//xcode:xcode_version_at_least.bzl�
�
name|The name of the `config_setting` target to create. A companion
feature flag target named `<name>_flag` will also be created. (�
�
minimum_xcode_versioneThe minimum Xcode version to match (inclusive),
such as `"26.4"`, `"26.4.1"`, or `"27.0.0.27A5228h"`. (�
�
after�An optional list of lower-version `xcode_version_at_least` target
names or labels that this condition should refine when used together
in the same `select()` expression. If a referenced target is in the
same package, any lower thresholds it already refines are inherited
transitively.None(@
>

visibility(The visibility of the generated targets.None(�
�
kwargs�Additional keyword arguments (such as `tags` or
`constraint_values`) forwarded to `native.config_setting`. `tags` is
also forwarded to the companion `<name>_flag` target.(�# Minimum Xcode version conditions

Use `xcode_version_at_least` in BUILD files to configure attributes based on the
selected Xcode version. 