�
.
aspect_bazel_liblib/privatecopy_file.bzl�	copy_bash*x
h
	copy_bash	
ctx (	
src (	
dst (2:
	copy_bash-@@aspect_bazel_lib//lib/private:copy_file.bzl
VV�copy_cmd*v
f
copy_cmd	
ctx (	
src (	
dst (29
copy_cmd-@@aspect_bazel_lib//lib/private:copy_file.bzl
))�	copy_file�Copies a file or directory to another location.

`native.genrule()` is sometimes used to copy files (often wishing to rename them). The 'copy_file' rule does this with a simpler interface than genrule.

This rule uses a Bash command on Linux/macOS/non-Windows, and a cmd.exe command on Windows (no Bash is required).

If using this rule with source directories, it is recommended that you use the
`--host_jvm_args=-DBAZEL_TRACK_SOURCE_DIRECTORIES=1` startup option so that changes
to files within source directories are detected. See
https://github.com/bazelbuild/bazel/commit/c64421bc35214f0414e4f4226cc953e8c55fa0d2
for more context.
*�
�
	copy_file
nameName of the rule. (�
srcwA Label. The file or directory to make a copy of.
(Can also be the label of a rule that generates a file or directory.) (=
out2Path of the output file, relative to this package. (}
is_directorydtreat the source file as a directory
Workaround for https://github.com/bazelbuild/bazel/issues/12954False(�
is_executable�A boolean. Whether to make the output file executable. When
True, the rule's output can be executed using `bazel run` and can be
in the srcs of binary and test rules that require executable sources.
WARNING: If `allow_symlink` is True, `src` must also be executable.False(�
allow_symlink�A boolean. Whether to allow symlinking instead of copying.
When False, the output is always a hard copy. When True, the output
*can* be a symlink, but there is no guarantee that a symlink is
created (i.e., at the time of writing, we don't create symlinks on
Windows). Set this to True if you need fast copying and your tools can
handle symlinks (which most UNIX tools can).False(8
kwargs,further keyword arguments, e.g. `visibility`(�Copies a file or directory to another location.

`native.genrule()` is sometimes used to copy files (often wishing to rename them). The 'copy_file' rule does this with a simpler interface than genrule.

This rule uses a Bash command on Linux/macOS/non-Windows, and a cmd.exe command on Windows (no Bash is required).

If using this rule with source directories, it is recommended that you use the
`--host_jvm_args=-DBAZEL_TRACK_SOURCE_DIRECTORIES=1` startup option so that changes
to files within source directories are detected. See
https://github.com/bazelbuild/bazel/commit/c64421bc35214f0414e4f4226cc953e8c55fa0d2
for more context.
2:
	copy_file-@@aspect_bazel_lib//lib/private:copy_file.bzl
��*copy_file_impl2copy_file_impl�Implementation of copy_file macro and underlying rules.

These rules copy a file or directory to another location using Bash (on Linux/macOS) or
cmd.exe (on Windows). `_copy_xfile` marks the resulting file executable,
`_copy_file` does not.
�0
6
aspect_bazel_liblib/privatecopy_to_directory.bzl�.copy_to_directory�Copies files and directories to an output directory.

Files and directories can be arranged as needed in the output directory using
the `root_paths`, `exclude_prefixes` and `replace_prefixes` attributes.
"�,
�
copy_to_directory�Copies files and directories to an output directory.

Files and directories can be arranged as needed in the output directory using
the `root_paths`, `exclude_prefixes` and `replace_prefixes` attributes.
*
nameA unique name for this target. �
exclude_prefixes�
List of path prefixes to exclude from output directory.

If the output directory path for a file or directory starts with or is equal to
a path in the list then that file is not copied to the output directory.

Exclude prefixes are matched *before* replace_prefixes are applied.
2[]�
include_external_repositories�
List of external repository names to include in the output directory.

Files from external repositories are not copied into the output directory unless
the external repository they come from is listed here.

When copied from an external repository, the file path in the output directory
defaults to the file's path within the external repository. The external repository
name is _not_ included in that path.

For example, the following copies `@external_repo//path/to:file` to
`path/to/file` within the output directory.

```
copy_to_directory(
    name = "dir",
    include_external_repositories = ["external_repo"],
    srcs = ["@external_repo//path/to:file"],
)
```

Files from external repositories are subject to `root_paths`, `exclude_prefixes`
and `replace_prefixes` in the same way as files form the main repository.
2[]

is_windows �
replace_prefixes�
Map of paths prefixes to replace in the output directory path when copying files.

If the output directory path for a file or directory starts with or is equal to
a key in the dict then the matching portion of the output directory path is
replaced with the dict value for that key.

Forward slashes (`/`) should be used as path separators. The final path segment
of the key can be a partial match in the corresponding segment of the output
directory path.

If there are multiple keys that match, the longest match wins.

2{}�

root_paths�
List of paths that are roots in the output directory. If a file or directory
being copied is in one of the listed paths or one of its subpaths, the output
directory path is the path relative to the root path instead of the path
relative to the file's workspace.

Forward slashes (`/`) should be used as path separators. Partial matches
on the final path segment of a root path against the corresponding segment
in the full workspace relative path of a file are not matched.

If there are multiple root paths that match, the longest match wins.

Defaults to [package_name()] so that the output directory path of files in the
target's package and and sub-packages are relative to the target's package and
files outside of that retain their full workspace relative paths.
2[]H
srcs:Files and/or directories to copy into the output directory2[]"J
copy_to_directory5@@aspect_bazel_lib//lib/private:copy_to_directory.bzl
��,
*
nameA unique name for this target. �
�
exclude_prefixes�
List of path prefixes to exclude from output directory.

If the output directory path for a file or directory starts with or is equal to
a path in the list then that file is not copied to the output directory.

Exclude prefixes are matched *before* replace_prefixes are applied.
2[]�
�
include_external_repositories�
List of external repository names to include in the output directory.

Files from external repositories are not copied into the output directory unless
the external repository they come from is listed here.

When copied from an external repository, the file path in the output directory
defaults to the file's path within the external repository. The external repository
name is _not_ included in that path.

For example, the following copies `@external_repo//path/to:file` to
`path/to/file` within the output directory.

```
copy_to_directory(
    name = "dir",
    include_external_repositories = ["external_repo"],
    srcs = ["@external_repo//path/to:file"],
)
```

Files from external repositories are subject to `root_paths`, `exclude_prefixes`
and `replace_prefixes` in the same way as files form the main repository.
2[]


is_windows �
�
replace_prefixes�
Map of paths prefixes to replace in the output directory path when copying files.

If the output directory path for a file or directory starts with or is equal to
a key in the dict then the matching portion of the output directory path is
replaced with the dict value for that key.

Forward slashes (`/`) should be used as path separators. The final path segment
of the key can be a partial match in the corresponding segment of the output
directory path.

If there are multiple keys that match, the longest match wins.

2{}�
�

root_paths�
List of paths that are roots in the output directory. If a file or directory
being copied is in one of the listed paths or one of its subpaths, the output
directory path is the path relative to the root path instead of the path
relative to the file's workspace.

Forward slashes (`/`) should be used as path separators. Partial matches
on the final path segment of a root path against the corresponding segment
in the full workspace relative path of a file are not matched.

If there are multiple root paths that match, the longest match wins.

Defaults to [package_name()] so that the output directory path of files in the
target's package and and sub-packages are relative to the target's package and
files outside of that retain their full workspace relative paths.
2[]J
H
srcs:Files and/or directories to copy into the output directory2[]u
//lib/private:paths.bzlrX
*
aspect_bazel_liblib/private	paths.bzl
pathspaths
38
:h
//lib:paths.bzlrS

bazel_skyliblib	paths.bzl#
pathsskylib_paths
&2
=1Copy files and directories to an output directory�
)
aspect_bazel_liblib/privatedocs.bzl�stardoc_with_diff_test�Creates a stardoc target coupled with a `diff_test` for a given `bzl_library`.

This is helpful for minimizing boilerplate in repos wih lots of stardoc targets.
*�	
�	
stardoc_with_diff_test]
bzl_library_targetCthe label of the `bzl_library` target to generate documentation for (0
	out_labelthe label of the output MD file (�
aspect_templateEthe label or path to the Velocity aspect template to use with stardoc@"@io_bazel_stardoc//stardoc:templates/markdown_tables/aspect.vm"(�
func_templateMthe label or path to the Velocity function/macro template to use with stardoc>"@io_bazel_stardoc//stardoc:templates/markdown_tables/func.vm"(�
header_templateEthe label or path to the Velocity header template to use with stardoc@"@io_bazel_stardoc//stardoc:templates/markdown_tables/header.vm"(�
provider_templateGthe label or path to the Velocity provider template to use with stardocB"@io_bazel_stardoc//stardoc:templates/markdown_tables/provider.vm"(�
rule_templateCthe label or path to the Velocity rule template to use with stardoc>"@io_bazel_stardoc//stardoc:templates/markdown_tables/rule.vm"(�Creates a stardoc target coupled with a `diff_test` for a given `bzl_library`.

This is helpful for minimizing boilerplate in repos wih lots of stardoc targets.
2B
stardoc_with_diff_test(@@aspect_bazel_lib//lib/private:docs.bzl
�	update_docs�Creates a `sh_binary` target which copies over generated doc files to the local source tree.

This is to be used in tandem with `stardoc_with_diff_test()` to produce a convenient workflow
for generating, testing, and updating all doc files as follows:

``` bash
bazel build //{docs_folder}/... && bazel test //{docs_folder}/... && bazel run //{docs_folder}:update
```

eg.

``` bash
bazel build //docs/... && bazel test //docs/... && bazel run //docs:update
```
*�
�
update_docs6
name"the name of the `sh_binary` target"update"(a
docs_folderHthe name of the folder containing the doc files in the local source tree"docs"(�Creates a `sh_binary` target which copies over generated doc files to the local source tree.

This is to be used in tandem with `stardoc_with_diff_test()` to produce a convenient workflow
for generating, testing, and updating all doc files as follows:

``` bash
bazel build //{docs_folder}/... && bazel test //{docs_folder}/... && bazel run //{docs_folder}:update
```

eg.

``` bash
bazel build //docs/... && bazel test //docs/... && bazel run //docs:update
```
27
update_docs(@@aspect_bazel_lib//lib/private:docs.bzl
66"native.sh_binary2
write_file2native.sh_binaryu
//rules:diff_test.bzlrZ
$
bazel_skylibrulesdiff_test.bzl$
	diff_test	diff_test
-6
8y
//rules:write_file.bzlr]
%
bazel_skylibruleswrite_file.bzl&

write_file
write_file
.8
:u
//stardoc:stardoc.bzlrZ
(
io_bazel_stardocstardocstardoc.bzl 
stardocstardoc
18
:,Helpers for generating stardoc documentation�6
5
aspect_bazel_liblib/privateexpand_make_vars.bzl�"expand_locations�Expand location templates.

Expands all `$(execpath ...)`, `$(rootpath ...)` and legacy `$(location ...)` templates in the
given string by replacing with the expanded path. Expansion only works for labels that point to direct dependencies
of this rule or that are explicitly listed in the optional argument targets.

See https://docs.bazel.build/versions/main/be/make-variables.html#predefined_label_variables.

Use `$(rootpath)` and `$(rootpaths)` to expand labels to the runfiles path that a built binary can use
to find its dependencies. This path is of the format:
- `./file`
- `path/to/file`
- `../external_repo/path/to/file`

Use `$(execpath)` and `$(execpaths)` to expand labels to the execroot (where Bazel runs build actions).
This is of the format:
- `./file`
- `path/to/file`
- `external/external_repo/path/to/file`
- `<bin_dir>/path/to/file`
- `<bin_dir>/external/external_repo/path/to/file`

The legacy `$(location)` and `$(locations)` expansions are deprecated as they return the runfiles manifest path of the
format `repo/path/to/file` which behave differently than the built-in `$(location)` expansion in args of *_binary
and *_test rules which returns the rootpath.
See https://docs.bazel.build/versions/main/be/common-definitions.html#common-attributes-binaries.

The legacy `$(location)` and `$(locations)` expansion also differs from how the builtin `ctx.expand_location()` expansions
of `$(location)` and `$(locations)` behave as that function returns either the execpath or rootpath depending on the context.
See https://docs.bazel.build/versions/main/be/make-variables.html#predefined_label_variables.

The behavior of `$(location)` and `$(locations)` expansion will be fixed in a future major release to match the
to default Bazel behavior and return the same path as `ctx.expand_location()` returns for these.

The recommended approach is to now use `$(rootpath)` where you previously used $(location). See the docstrings
of `nodejs_binary` or `params_file` for examples of how to use `$(rootpath)` in `templated_args` and `args` respectively.
*�
�
expand_locations
ctxcontext ("
inputString to be expanded (C
targets2List of targets for additional lookup information.[](�Expand location templates.

Expands all `$(execpath ...)`, `$(rootpath ...)` and legacy `$(location ...)` templates in the
given string by replacing with the expanded path. Expansion only works for labels that point to direct dependencies
of this rule or that are explicitly listed in the optional argument targets.

See https://docs.bazel.build/versions/main/be/make-variables.html#predefined_label_variables.

Use `$(rootpath)` and `$(rootpaths)` to expand labels to the runfiles path that a built binary can use
to find its dependencies. This path is of the format:
- `./file`
- `path/to/file`
- `../external_repo/path/to/file`

Use `$(execpath)` and `$(execpaths)` to expand labels to the execroot (where Bazel runs build actions).
This is of the format:
- `./file`
- `path/to/file`
- `external/external_repo/path/to/file`
- `<bin_dir>/path/to/file`
- `<bin_dir>/external/external_repo/path/to/file`

The legacy `$(location)` and `$(locations)` expansions are deprecated as they return the runfiles manifest path of the
format `repo/path/to/file` which behave differently than the built-in `$(location)` expansion in args of *_binary
and *_test rules which returns the rootpath.
See https://docs.bazel.build/versions/main/be/common-definitions.html#common-attributes-binaries.

The legacy `$(location)` and `$(locations)` expansion also differs from how the builtin `ctx.expand_location()` expansions
of `$(location)` and `$(locations)` behave as that function returns either the execpath or rootpath depending on the context.
See https://docs.bazel.build/versions/main/be/make-variables.html#predefined_label_variables.

The behavior of `$(location)` and `$(locations)` expansion will be fixed in a future major release to match the
to default Bazel behavior and return the same path as `ctx.expand_location()` returns for these.

The recommended approach is to now use `$(rootpath)` where you previously used $(location). See the docstrings
of `nodejs_binary` or `params_file` for examples of how to use `$(rootpath)` in `templated_args` and `args` respectively.
"(
&The expanded path or the original path2H
expand_locations4@@aspect_bazel_lib//lib/private:expand_make_vars.bzl
�expand_variables�Expand make variables and substitute like genrule does.

This function is the same as ctx.expand_make_variables with the additional
genrule-like substitutions of:

  - `$@`: The output file if it is a single file. Else triggers a build error.
  - `$(@D)`: The output directory. If there is only one file name in outs,
           this expands to the directory containing that file. If there are multiple files,
           this instead expands to the package's root directory in the bin tree,
           even if all generated files belong to the same subdirectory!
  - `$(RULEDIR)`: The output directory of the rule, that is, the directory
    corresponding to the name of the package containing the rule under the bin tree.

See https://docs.bazel.build/versions/main/be/general.html#genrule.cmd and
https://docs.bazel.build/versions/main/be/make-variables.html#predefined_genrule_variables
for more information of how these special variables are expanded.
*�
�

expand_variables 
ctxstarlark rule context (
sexpression to expand (O
outsAdeclared outputs of the rule, for expanding references to outputs[](X

output_dirAwhether the rule is expected to output a directory (TreeArtifact)False(K
attribute_name/name of the attribute containing the expression"args"(�Expand make variables and substitute like genrule does.

This function is the same as ctx.expand_make_variables with the additional
genrule-like substitutions of:

  - `$@`: The output file if it is a single file. Else triggers a build error.
  - `$(@D)`: The output directory. If there is only one file name in outs,
           this expands to the directory containing that file. If there are multiple files,
           this instead expands to the package's root directory in the bin tree,
           even if all generated files belong to the same subdirectory!
  - `$(RULEDIR)`: The output directory of the rule, that is, the directory
    corresponding to the name of the package containing the rule under the bin tree.

See https://docs.bazel.build/versions/main/be/general.html#genrule.cmd and
https://docs.bazel.build/versions/main/be/make-variables.html#predefined_genrule_variables
for more information of how these special variables are expanded.
"!
`s` with the variables expanded2H
expand_variables4@@aspect_bazel_lib//lib/private:expand_make_vars.bzl
hh Helpers to expand make variablesE
'
aspect_bazel_liblib/privatejq.bzlImplementation for jq rule�
1
aspect_bazel_liblib/privatejq_toolchain.bzl�jq_toolchain"�
�
jq_toolchain*
nameA unique name for this target. 	
bin "@
jq_toolchain0@@aspect_bazel_lib//lib/private:jq_toolchain.bzl
YY,
*
nameA unique name for this target. 
	
bin �JqInfoProvide info for executing jq2�
�
JqInfoProvide info for executing jq
binExecutable jq binary":
JqInfo0@@aspect_bazel_lib//lib/private:jq_toolchain.bzl
88

binExecutable jq binary�	jq_platform_repo,Fetch external tools needed for jq toolchainR�	
�
jq_platform_repo,Fetch external tools needed for jq toolchain.
name"A unique name for this repository. 

jq_version 
platform �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 *D
jq_platform_repo0@@aspect_bazel_lib//lib/private:jq_toolchain.bzl
�#�#0
.
name"A unique name for this repository. 


jq_version 

platform �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �jq_toolchains_repolCreates a repository with toolchain definitions for all known platforms
which can be registered or selected.R�

�
jq_toolchains_repolCreates a repository with toolchain definitions for all known platforms
which can be registered or selected..
name"A unique name for this repository. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 A
user_repository_name#Base name for toolchains repository2""*F
jq_toolchains_repo0@@aspect_bazel_lib//lib/private:jq_toolchain.bzl
�%�%0
.
name"A unique name for this repository. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 C
A
user_repository_name#Base name for toolchains repository2"")Setup jq toolchain repositories and rules�
0
aspect_bazel_liblib/privateparams_file.bzl�params_file"�
�
params_file*
nameA unique name for this target. 
args2[]
data2[]

is_windows 
newline2"auto"	
out ">
params_file/@@aspect_bazel_lib//lib/private:params_file.bzl
11,
*
nameA unique name for this target. 

args2[]

data2[]


is_windows 

newline2"auto"
	
out �
"//lib/private:expand_make_vars.bzlry
5
aspect_bazel_liblib/privateexpand_make_vars.bzl2
expand_locationsexpand_locations
>N
Pparams_file rule�
*
aspect_bazel_liblib/private	paths.bzlc
//lib:paths.bzlrN

bazel_skyliblib	paths.bzl
paths_spaths
&-
8.Path utils built on top of Skylib's path utilsG
*
aspect_bazel_liblib/private	utils.bzlGeneral utility functions�
&
aspect_bazel_liblibcopy_file.bzl�	copy_file�Copies a file or directory to another location.

`native.genrule()` is sometimes used to copy files (often wishing to rename them). The 'copy_file' rule does this with a simpler interface than genrule.

This rule uses a Bash command on Linux/macOS/non-Windows, and a cmd.exe command on Windows (no Bash is required).

If using this rule with source directories, it is recommended that you use the
`--host_jvm_args=-DBAZEL_TRACK_SOURCE_DIRECTORIES=1` startup option so that changes
to files within source directories are detected. See
https://github.com/bazelbuild/bazel/commit/c64421bc35214f0414e4f4226cc953e8c55fa0d2
for more context.
*�
�
	copy_file
nameName of the rule. (�
srcwA Label. The file or directory to make a copy of.
(Can also be the label of a rule that generates a file or directory.) (=
out2Path of the output file, relative to this package. (}
is_directorydtreat the source file as a directory
Workaround for https://github.com/bazelbuild/bazel/issues/12954False(�
is_executable�A boolean. Whether to make the output file executable. When
True, the rule's output can be executed using `bazel run` and can be
in the srcs of binary and test rules that require executable sources.
WARNING: If `allow_symlink` is True, `src` must also be executable.False(�
allow_symlink�A boolean. Whether to allow symlinking instead of copying.
When False, the output is always a hard copy. When True, the output
*can* be a symlink, but there is no guarantee that a symlink is
created (i.e., at the time of writing, we don't create symlinks on
Windows). Set this to True if you need fast copying and your tools can
handle symlinks (which most UNIX tools can).False(8
kwargs,further keyword arguments, e.g. `visibility`(�Copies a file or directory to another location.

`native.genrule()` is sometimes used to copy files (often wishing to rename them). The 'copy_file' rule does this with a simpler interface than genrule.

This rule uses a Bash command on Linux/macOS/non-Windows, and a cmd.exe command on Windows (no Bash is required).

If using this rule with source directories, it is recommended that you use the
`--host_jvm_args=-DBAZEL_TRACK_SOURCE_DIRECTORIES=1` startup option so that changes
to files within source directories are detected. See
https://github.com/bazelbuild/bazel/commit/c64421bc35214f0414e4f4226cc953e8c55fa0d2
for more context.
2:
	copy_file-@@aspect_bazel_lib//lib/private:copy_file.bzl
��*copy_file_impl2copy_file_impl�
//lib/private:copy_file.bzlre
.
aspect_bazel_liblib/privatecopy_file.bzl%
	copy_file
_copy_file
  
!�A rule that copies a file to another place.

native.genrule() is sometimes used to copy files (often wishing to rename them).
The 'copy_file' rule does this with a simpler interface than genrule.

The rule uses a Bash command on Linux/macOS/non-Windows, and a cmd.exe command
on Windows (no Bash is required).
�,
.
aspect_bazel_liblibcopy_to_directory.bzl�*copy_to_directory"�*
�
copy_to_directory*
nameA unique name for this target. �
exclude_prefixes�
List of path prefixes to exclude from output directory.

If the output directory path for a file or directory starts with or is equal to
a path in the list then that file is not copied to the output directory.

Exclude prefixes are matched *before* replace_prefixes are applied.
2[]�
include_external_repositories�
List of external repository names to include in the output directory.

Files from external repositories are not copied into the output directory unless
the external repository they come from is listed here.

When copied from an external repository, the file path in the output directory
defaults to the file's path within the external repository. The external repository
name is _not_ included in that path.

For example, the following copies `@external_repo//path/to:file` to
`path/to/file` within the output directory.

```
copy_to_directory(
    name = "dir",
    include_external_repositories = ["external_repo"],
    srcs = ["@external_repo//path/to:file"],
)
```

Files from external repositories are subject to `root_paths`, `exclude_prefixes`
and `replace_prefixes` in the same way as files form the main repository.
2[]

is_windows �
replace_prefixes�
Map of paths prefixes to replace in the output directory path when copying files.

If the output directory path for a file or directory starts with or is equal to
a key in the dict then the matching portion of the output directory path is
replaced with the dict value for that key.

Forward slashes (`/`) should be used as path separators. The final path segment
of the key can be a partial match in the corresponding segment of the output
directory path.

If there are multiple keys that match, the longest match wins.

2{}�

root_paths�
List of paths that are roots in the output directory. If a file or directory
being copied is in one of the listed paths or one of its subpaths, the output
directory path is the path relative to the root path instead of the path
relative to the file's workspace.

Forward slashes (`/`) should be used as path separators. Partial matches
on the final path segment of a root path against the corresponding segment
in the full workspace relative path of a file are not matched.

If there are multiple root paths that match, the longest match wins.

Defaults to [package_name()] so that the output directory path of files in the
target's package and and sub-packages are relative to the target's package and
files outside of that retain their full workspace relative paths.
2[]H
srcs:Files and/or directories to copy into the output directory2[]"C
_copy_to_directory-@@aspect_bazel_lib//lib:copy_to_directory.bzl
,
*
nameA unique name for this target. �
�
exclude_prefixes�
List of path prefixes to exclude from output directory.

If the output directory path for a file or directory starts with or is equal to
a path in the list then that file is not copied to the output directory.

Exclude prefixes are matched *before* replace_prefixes are applied.
2[]�
�
include_external_repositories�
List of external repository names to include in the output directory.

Files from external repositories are not copied into the output directory unless
the external repository they come from is listed here.

When copied from an external repository, the file path in the output directory
defaults to the file's path within the external repository. The external repository
name is _not_ included in that path.

For example, the following copies `@external_repo//path/to:file` to
`path/to/file` within the output directory.

```
copy_to_directory(
    name = "dir",
    include_external_repositories = ["external_repo"],
    srcs = ["@external_repo//path/to:file"],
)
```

Files from external repositories are subject to `root_paths`, `exclude_prefixes`
and `replace_prefixes` in the same way as files form the main repository.
2[]


is_windows �
�
replace_prefixes�
Map of paths prefixes to replace in the output directory path when copying files.

If the output directory path for a file or directory starts with or is equal to
a key in the dict then the matching portion of the output directory path is
replaced with the dict value for that key.

Forward slashes (`/`) should be used as path separators. The final path segment
of the key can be a partial match in the corresponding segment of the output
directory path.

If there are multiple keys that match, the longest match wins.

2{}�
�

root_paths�
List of paths that are roots in the output directory. If a file or directory
being copied is in one of the listed paths or one of its subpaths, the output
directory path is the path relative to the root path instead of the path
relative to the file's workspace.

Forward slashes (`/`) should be used as path separators. Partial matches
on the final path segment of a root path against the corresponding segment
in the full workspace relative path of a file are not matched.

If there are multiple root paths that match, the longest match wins.

Defaults to [package_name()] so that the output directory path of files in the
target's package and and sub-packages are relative to the target's package and
files outside of that retain their full workspace relative paths.
2[]J
H
srcs:Files and/or directories to copy into the output directory2[]�
#//lib/private:copy_to_directory.bzlrr
6
aspect_bazel_liblib/privatecopy_to_directory.bzl*
copy_to_directory_liblib

 Public API for copy_to_directory�
!
aspect_bazel_liblibdocs.bzl�stardoc_with_diff_test�Creates a stardoc target coupled with a `diff_test` for a given `bzl_library`.

This is helpful for minimizing boilerplate in repos wih lots of stardoc targets.
*�	
�	
stardoc_with_diff_test]
bzl_library_targetCthe label of the `bzl_library` target to generate documentation for (0
	out_labelthe label of the output MD file (�
aspect_templateEthe label or path to the Velocity aspect template to use with stardoc@"@io_bazel_stardoc//stardoc:templates/markdown_tables/aspect.vm"(�
func_templateMthe label or path to the Velocity function/macro template to use with stardoc>"@io_bazel_stardoc//stardoc:templates/markdown_tables/func.vm"(�
header_templateEthe label or path to the Velocity header template to use with stardoc@"@io_bazel_stardoc//stardoc:templates/markdown_tables/header.vm"(�
provider_templateGthe label or path to the Velocity provider template to use with stardocB"@io_bazel_stardoc//stardoc:templates/markdown_tables/provider.vm"(�
rule_templateCthe label or path to the Velocity rule template to use with stardoc>"@io_bazel_stardoc//stardoc:templates/markdown_tables/rule.vm"(�Creates a stardoc target coupled with a `diff_test` for a given `bzl_library`.

This is helpful for minimizing boilerplate in repos wih lots of stardoc targets.
2B
stardoc_with_diff_test(@@aspect_bazel_lib//lib/private:docs.bzl
�	update_docs�Creates a `sh_binary` target which copies over generated doc files to the local source tree.

This is to be used in tandem with `stardoc_with_diff_test()` to produce a convenient workflow
for generating, testing, and updating all doc files as follows:

``` bash
bazel build //{docs_folder}/... && bazel test //{docs_folder}/... && bazel run //{docs_folder}:update
```

eg.

``` bash
bazel build //docs/... && bazel test //docs/... && bazel run //docs:update
```
*�
�
update_docs6
name"the name of the `sh_binary` target"update"(a
docs_folderHthe name of the folder containing the doc files in the local source tree"docs"(�Creates a `sh_binary` target which copies over generated doc files to the local source tree.

This is to be used in tandem with `stardoc_with_diff_test()` to produce a convenient workflow
for generating, testing, and updating all doc files as follows:

``` bash
bazel build //{docs_folder}/... && bazel test //{docs_folder}/... && bazel run //{docs_folder}:update
```

eg.

``` bash
bazel build //docs/... && bazel test //docs/... && bazel run //docs:update
```
27
update_docs(@@aspect_bazel_lib//lib/private:docs.bzl
66"native.sh_binary2
write_file2native.sh_binary�
//lib/private:docs.bzlr�
)
aspect_bazel_liblib/privatedocs.bzl?
stardoc_with_diff_test_stardoc_with_diff_test
)
update_docs_update_docs

Public API for docs helpers�E
-
aspect_bazel_liblibexpand_make_vars.bzl�expand_template�Template expansion

This performs a simple search over the template file for the keys in substitutions,
and replaces them with the corresponding values.

Values may also use location templates as documented in [expand_locations](#expand_locations)
as well as [configuration variables] such as `$(BINDIR)`, `$(TARGET_CPU)`, and `$(COMPILATION_MODE)`.

[configuration variables]: https://docs.bazel.build/versions/main/skylark/lib/ctx.html#var
"�	
�
expand_template�Template expansion

This performs a simple search over the template file for the keys in substitutions,
and replaces them with the corresponding values.

Values may also use location templates as documented in [expand_locations](#expand_locations)
as well as [configuration variables] such as `$(BINDIR)`, `$(TARGET_CPU)`, and `$(COMPILATION_MODE)`.

[configuration variables]: https://docs.bazel.build/versions/main/skylark/lib/ctx.html#var
*
nameA unique name for this target. @
data2List of targets for additional lookup information.2[]H
is_executable.Whether to mark the output file as executable.2False,
out!Where to write the expanded file. 9
substitutions$Mapping of strings to substitutions.
 ,
templateThe template file to expand. "?
expand_template,@@aspect_bazel_lib//lib:expand_make_vars.bzl
,
*
nameA unique name for this target. B
@
data2List of targets for additional lookup information.2[]J
H
is_executable.Whether to mark the output file as executable.2False.
,
out!Where to write the expanded file. ;
9
substitutions$Mapping of strings to substitutions.
 .
,
templateThe template file to expand. �"expand_locations�Expand location templates.

Expands all `$(execpath ...)`, `$(rootpath ...)` and legacy `$(location ...)` templates in the
given string by replacing with the expanded path. Expansion only works for labels that point to direct dependencies
of this rule or that are explicitly listed in the optional argument targets.

See https://docs.bazel.build/versions/main/be/make-variables.html#predefined_label_variables.

Use `$(rootpath)` and `$(rootpaths)` to expand labels to the runfiles path that a built binary can use
to find its dependencies. This path is of the format:
- `./file`
- `path/to/file`
- `../external_repo/path/to/file`

Use `$(execpath)` and `$(execpaths)` to expand labels to the execroot (where Bazel runs build actions).
This is of the format:
- `./file`
- `path/to/file`
- `external/external_repo/path/to/file`
- `<bin_dir>/path/to/file`
- `<bin_dir>/external/external_repo/path/to/file`

The legacy `$(location)` and `$(locations)` expansions are deprecated as they return the runfiles manifest path of the
format `repo/path/to/file` which behave differently than the built-in `$(location)` expansion in args of *_binary
and *_test rules which returns the rootpath.
See https://docs.bazel.build/versions/main/be/common-definitions.html#common-attributes-binaries.

The legacy `$(location)` and `$(locations)` expansion also differs from how the builtin `ctx.expand_location()` expansions
of `$(location)` and `$(locations)` behave as that function returns either the execpath or rootpath depending on the context.
See https://docs.bazel.build/versions/main/be/make-variables.html#predefined_label_variables.

The behavior of `$(location)` and `$(locations)` expansion will be fixed in a future major release to match the
to default Bazel behavior and return the same path as `ctx.expand_location()` returns for these.

The recommended approach is to now use `$(rootpath)` where you previously used $(location). See the docstrings
of `nodejs_binary` or `params_file` for examples of how to use `$(rootpath)` in `templated_args` and `args` respectively.
*�
�
expand_locations
ctxcontext ("
inputString to be expanded (C
targets2List of targets for additional lookup information.[](�Expand location templates.

Expands all `$(execpath ...)`, `$(rootpath ...)` and legacy `$(location ...)` templates in the
given string by replacing with the expanded path. Expansion only works for labels that point to direct dependencies
of this rule or that are explicitly listed in the optional argument targets.

See https://docs.bazel.build/versions/main/be/make-variables.html#predefined_label_variables.

Use `$(rootpath)` and `$(rootpaths)` to expand labels to the runfiles path that a built binary can use
to find its dependencies. This path is of the format:
- `./file`
- `path/to/file`
- `../external_repo/path/to/file`

Use `$(execpath)` and `$(execpaths)` to expand labels to the execroot (where Bazel runs build actions).
This is of the format:
- `./file`
- `path/to/file`
- `external/external_repo/path/to/file`
- `<bin_dir>/path/to/file`
- `<bin_dir>/external/external_repo/path/to/file`

The legacy `$(location)` and `$(locations)` expansions are deprecated as they return the runfiles manifest path of the
format `repo/path/to/file` which behave differently than the built-in `$(location)` expansion in args of *_binary
and *_test rules which returns the rootpath.
See https://docs.bazel.build/versions/main/be/common-definitions.html#common-attributes-binaries.

The legacy `$(location)` and `$(locations)` expansion also differs from how the builtin `ctx.expand_location()` expansions
of `$(location)` and `$(locations)` behave as that function returns either the execpath or rootpath depending on the context.
See https://docs.bazel.build/versions/main/be/make-variables.html#predefined_label_variables.

The behavior of `$(location)` and `$(locations)` expansion will be fixed in a future major release to match the
to default Bazel behavior and return the same path as `ctx.expand_location()` returns for these.

The recommended approach is to now use `$(rootpath)` where you previously used $(location). See the docstrings
of `nodejs_binary` or `params_file` for examples of how to use `$(rootpath)` in `templated_args` and `args` respectively.
"(
&The expanded path or the original path2H
expand_locations4@@aspect_bazel_lib//lib/private:expand_make_vars.bzl
�expand_variables�Expand make variables and substitute like genrule does.

This function is the same as ctx.expand_make_variables with the additional
genrule-like substitutions of:

  - `$@`: The output file if it is a single file. Else triggers a build error.
  - `$(@D)`: The output directory. If there is only one file name in outs,
           this expands to the directory containing that file. If there are multiple files,
           this instead expands to the package's root directory in the bin tree,
           even if all generated files belong to the same subdirectory!
  - `$(RULEDIR)`: The output directory of the rule, that is, the directory
    corresponding to the name of the package containing the rule under the bin tree.

See https://docs.bazel.build/versions/main/be/general.html#genrule.cmd and
https://docs.bazel.build/versions/main/be/make-variables.html#predefined_genrule_variables
for more information of how these special variables are expanded.
*�
�

expand_variables 
ctxstarlark rule context (
sexpression to expand (O
outsAdeclared outputs of the rule, for expanding references to outputs[](X

output_dirAwhether the rule is expected to output a directory (TreeArtifact)False(K
attribute_name/name of the attribute containing the expression"args"(�Expand make variables and substitute like genrule does.

This function is the same as ctx.expand_make_variables with the additional
genrule-like substitutions of:

  - `$@`: The output file if it is a single file. Else triggers a build error.
  - `$(@D)`: The output directory. If there is only one file name in outs,
           this expands to the directory containing that file. If there are multiple files,
           this instead expands to the package's root directory in the bin tree,
           even if all generated files belong to the same subdirectory!
  - `$(RULEDIR)`: The output directory of the rule, that is, the directory
    corresponding to the name of the package containing the rule under the bin tree.

See https://docs.bazel.build/versions/main/be/general.html#genrule.cmd and
https://docs.bazel.build/versions/main/be/make-variables.html#predefined_genrule_variables
for more information of how these special variables are expanded.
"!
`s` with the variables expanded2H
expand_variables4@@aspect_bazel_lib//lib/private:expand_make_vars.bzl
hh�
"//lib/private:expand_make_vars.bzlr�
5
aspect_bazel_liblib/privateexpand_make_vars.bzl3
expand_locations_expand_locations
1
expand_template_expand_template
3
expand_variables_expand_variables

"Public API for expanding variables�

aspect_bazel_liblibjq.bzl�jq�Invoke jq with a filter on a set of json input files.

For jq documentation, see https://stedolan.github.io/jq/.

Usage examples:

```starlark
# Remove fields from package.json
jq(
    name = "no_dev_deps",
    srcs = ["package.json"],
    filter = "del(.devDependencies)",
)

# Merge bar.json on top of foo.json
jq(
    name = "merged",
    srcs = ["foo.json", "bar.json"],
    filter = ".[0] * .[1]",
    args = ["--slurp"],
    out = "foobar.json",
)

# Long filters can be split over several lines with comments
jq(
    name = "complex",
    srcs = ["a.json", "b.json"],
    filter = """
        .[0] as $a
        # Take select fields from b.json
        | (.[1] | {foo, bar, tags}) as $b
        # Merge b onto a
        | ($a * $b)
        # Combine 'tags' array from both
        | .tags = ($a.tags + $b.tags)
        # Add new field
        + {\"aspect_is_cool\": true}
    """,
    args = ["--slurp"],
)

# Load filter from a file
jq(
    name = "merged",
    srcs = ["foo.json", "bar.json"],
    filter_file = "filter.txt",
    args = ["--slurp"],
    out = "foobar.json",
)
```
"�
�	
jq�Invoke jq with a filter on a set of json input files.

For jq documentation, see https://stedolan.github.io/jq/.

Usage examples:

```starlark
# Remove fields from package.json
jq(
    name = "no_dev_deps",
    srcs = ["package.json"],
    filter = "del(.devDependencies)",
)

# Merge bar.json on top of foo.json
jq(
    name = "merged",
    srcs = ["foo.json", "bar.json"],
    filter = ".[0] * .[1]",
    args = ["--slurp"],
    out = "foobar.json",
)

# Long filters can be split over several lines with comments
jq(
    name = "complex",
    srcs = ["a.json", "b.json"],
    filter = """
        .[0] as $a
        # Take select fields from b.json
        | (.[1] | {foo, bar, tags}) as $b
        # Merge b onto a
        | ($a * $b)
        # Combine 'tags' array from both
        | .tags = ($a.tags + $b.tags)
        # Add new field
        + {\"aspect_is_cool\": true}
    """,
    args = ["--slurp"],
)

# Load filter from a file
jq(
    name = "merged",
    srcs = ["foo.json", "bar.json"],
    filter_file = "filter.txt",
    args = ["--slurp"],
    out = "foobar.json",
)
```
*
nameA unique name for this target. 
args2[]
filter2""
filter_file2None	
out 

srcs "*
_jq_rule@@aspect_bazel_lib//lib:jq.bzl
,
*
nameA unique name for this target. 

args2[]

filter2""

filter_file2None
	
out 


srcs r
//lib/private:jq.bzlrX
'
aspect_bazel_liblib/privatejq.bzl
jq_lib_jq_lib
/6
BPublic API for jq�
(
aspect_bazel_liblibparams_file.bzl�params_filejGenerates a UTF-8 encoded params file from a list of arguments.

Handles variable substitutions for args.
*�
�
params_file
nameName of the rule. (=
out2Path of the output file, relative to this package. (�
args�
Arguments to concatenate into a params file.

Subject to 'Make variable' substitution. See https://docs.bazel.build/versions/main/be/make-variables.html.

<ol>
<li> Subject to predefined source/output path variables substitutions.

The predefined variables `execpath`, `execpaths`, `rootpath`, `rootpaths`, `location`, and `locations` take
label parameters (e.g. `$(execpath //foo:bar)`) and substitute the file paths denoted by that label.

See https://docs.bazel.build/versions/main/be/make-variables.html#predefined_label_variables for more info.

NB: This $(location) substition returns the manifest file path which differs from the `*_binary` & `*_test`
args and genrule bazel substitions. This will be fixed in a future major release.
See docs string of `expand_location_into_runfiles` macro in `internal/common/expand_into_runfiles.bzl`
for more info.</li>

<li>Subject to predefined variables & custom variable substitutions.

Predefined "Make" variables such as `$(COMPILATION_MODE)` and `$(TARGET_CPU)` are expanded.
See https://docs.bazel.build/versions/main/be/make-variables.html#predefined_variables.

Custom variables are also expanded including variables set through the Bazel CLI with `--define=SOME_VAR=SOME_VALUE`.
See https://docs.bazel.build/versions/main/be/make-variables.html#custom_variables.

Predefined genrule variables are not supported in this context.</li>
</ol>[](8
data*Data for `$(location)` expansions in args.[](�
newline�Line endings to use. One of [`"auto"`, `"unix"`, `"windows"`].

<ul>
<li>`"auto"` for platform-determined</li>
<li>`"unix"` for LF</li>
<li>`"windows"` for CRLF</li>
</ul>"auto"((
kwargsundocumented named arguments(jGenerates a UTF-8 encoded params file from a list of arguments.

Handles variable substitutions for args.
26
params_file'@@aspect_bazel_lib//lib:params_file.bzl
*_params_file2_params_file�
//lib/private:params_file.bzlrk
0
aspect_bazel_liblib/privateparams_file.bzl)
params_file_params_file
8D
Uparams_file public API�
"
aspect_bazel_liblib	paths.bzl�relative_filecResolves a relative path between two files, "to_file" and "frm_file", they must share the same root*�
�
relative_file>
to_file/the path with file name to resolve to, from frm (7
frm_file'the path with file name to resolve from (cResolves a relative path between two files, "to_file" and "frm_file", they must share the same root"E
CThe relative path from frm_file to to_file, including the file name2;
_relative_file)@@aspect_bazel_lib//lib/private:paths.bzl
�to_manifest_path�The runfiles manifest entry path for a file

This is the full runfiles path of a file including its workspace name as
the first segment. We refert to it as the manifest path as it is the path
flavor that is used for in the runfiles MANIFEST file.

We must avoid using non-normalized paths (workspace/../other_workspace/path)
in order to locate entries by their key.
*�
�
to_manifest_path*
ctxstarlark rule execution context (
filea File object (�The runfiles manifest entry path for a file

This is the full runfiles path of a file including its workspace name as
the first segment. We refert to it as the manifest path as it is the path
flavor that is used for in the runfiles MANIFEST file.

We must avoid using non-normalized paths (workspace/../other_workspace/path)
in order to locate entries by their key.
"-
+The runfiles manifest entry path for a file2>
_to_manifest_path)@@aspect_bazel_lib//lib/private:paths.bzl
--�to_workspace_path�The workspace relative path for a file

This is the full runfiles path of a file excluding its workspace name.
This differs from root path and manifest path as it does not include the
repository name if the file is from an external repository.
*�
�
to_workspace_path*
ctxstarlark rule execution context (
filea File object (�The workspace relative path for a file

This is the full runfiles path of a file excluding its workspace name.
This differs from root path and manifest path as it does not include the
repository name if the file is from an external repository.
"(
&The workspace relative path for a file2?
_to_workspace_path)@@aspect_bazel_lib//lib/private:paths.bzl
DDu
//lib/private:paths.bzlrX
*
aspect_bazel_liblib/private	paths.bzl
pathspaths
38
:�		BASH_RLOCATION_FUNCTION�
# --- begin runfiles.bash initialization v2 ---
set -uo pipefail; f=bazel_tools/tools/bash/runfiles/runfiles.bash
source "${RUNFILES_DIR:-/dev/null}/$f" 2>/dev/null || \
source "$(grep -sm1 "^$f " "${RUNFILES_MANIFEST_FILE:-/dev/null}" | cut -f2- -d' ')" 2>/dev/null || \
source "$0.runfiles/$f" 2>/dev/null || \
source "$(grep -sm1 "^$f " "$0.runfiles_manifest" | cut -f2- -d' ')" 2>/dev/null || \
source "$(grep -sm1 "^$f " "$0.exe.runfiles_manifest" | cut -f2- -d' ')" 2>/dev/null || \
{ echo>&2 "ERROR: cannot find $f"; exit 1; }; f=; set -e
# --- end runfiles.bash initialization v2 ---
j��
# --- begin runfiles.bash initialization v2 ---
set -uo pipefail; f=bazel_tools/tools/bash/runfiles/runfiles.bash
source "${RUNFILES_DIR:-/dev/null}/$f" 2>/dev/null || \
source "$(grep -sm1 "^$f " "${RUNFILES_MANIFEST_FILE:-/dev/null}" | cut -f2- -d' ')" 2>/dev/null || \
source "$0.runfiles/$f" 2>/dev/null || \
source "$(grep -sm1 "^$f " "$0.runfiles_manifest" | cut -f2- -d' ')" 2>/dev/null || \
source "$(grep -sm1 "^$f " "$0.exe.runfiles_manifest" | cut -f2- -d' ')" 2>/dev/null || \
{ echo>&2 "ERROR: cannot find $f"; exit 1; }; f=; set -e
# --- end runfiles.bash initialization v2 ---

Public API�

)
aspect_bazel_liblibrepositories.bzl�aspect_bazel_lib_dependencies*Load dependencies required by aspect rules*�
�
aspect_bazel_lib_dependencies*Load dependencies required by aspect rules2I
aspect_bazel_lib_dependencies(@@aspect_bazel_lib//lib:repositories.bzl
�register_jq_toolchains'Registers jq toolchain and repositories*�
�
register_jq_toolchainsY
versionJthe version of jq to execute (see https://github.com/stedolan/jq/releases) (L
name<override the prefix for the generated toolchain repositories"jq"('Registers jq toolchain and repositories2B
register_jq_toolchains(@@aspect_bazel_lib//lib:repositories.bzl
2jq_toolchains_repo�
//lib/private:jq_toolchain.bzlr�
1
aspect_bazel_liblib/privatejq_toolchain.bzl*
JQ_PLATFORMSJQ_PLATFORMS
:F2
jq_platform_repojq_platform_repo
JZ6
jq_toolchains_repojq_toolchains_repo
^p
r�
 //tools/build_defs/repo:http.bzlrj
.
bazel_toolstools/build_defs/repohttp.bzl*
http_archivehttp_archive
7C
E�
!//tools/build_defs/repo:utils.bzlr]
/
bazel_toolstools/build_defs/repo	utils.bzl
maybemaybe
8=
?:Macros for loading dependencies and registering toolchains�
"
aspect_bazel_liblib	utils.bzl�glob_directories*�
m
glob_directories
include (

kwargs(2>
_glob_directories)@@aspect_bazel_lib//lib/private:utils.bzl
VV*native.glob*native.glob�is_external_labellReturns True if the given Label (or stringy version of a label) represents a target outside of the workspace*�
�
is_external_label
parama string or label (lReturns True if the given Label (or stringy version of a label) represents a target outside of the workspace"
a bool2?
_is_external_label)@@aspect_bazel_lib//lib/private:utils.bzl
AA�path_to_workspace_root1Retuns the path to the workspace root under bazel*�
�
path_to_workspace_root1Retuns the path to the workspace root under bazel"
Path to the workspace root2D
_path_to_workspace_root)@@aspect_bazel_lib//lib/private:utils.bzl
MM�propagate_well_known_tags�Returns a list of tags filtered from the input set that only contains the ones that are considered "well known"

These are listed in Bazel's documentation:
https://docs.bazel.build/versions/main/test-encyclopedia.html#tag-conventions
https://docs.bazel.build/versions/main/be/common-definitions.html#common-attributes
*�
�
propagate_well_known_tags$
tagsList of tags to filter[](�Returns a list of tags filtered from the input set that only contains the ones that are considered "well known"

These are listed in Bazel's documentation:
https://docs.bazel.build/versions/main/test-encyclopedia.html#tag-conventions
https://docs.bazel.build/versions/main/be/common-definitions.html#common-attributes
"4
2List of tags that only contains the well known set2G
_propagate_well_known_tags)@@aspect_bazel_lib//lib/private:utils.bzl
�to_labelOConverts a string to a Label. If Label is supplied, the same label is returned.*�
�
to_label5
param(a string representing a label or a Label (OConverts a string to a Label. If Label is supplied, the same label is returned."	
a Label26
	_to_label)@@aspect_bazel_lib//lib/private:utils.bzl
""u
//lib/private:utils.bzlrX
*
aspect_bazel_liblib/private	utils.bzl
utilsutils
38
:
Public API�
*
aspect_bazel_liblibwindows_utils.bzl�	BATCH_RLOCATION_FUNCTION�	
rem Usage of rlocation function:
rem        call :rlocation <runfile_path> <abs_path>
rem        The rlocation function maps the given <runfile_path> to its absolute
rem        path and stores the result in a variable named <abs_path>.
rem        This function fails if the <runfile_path> doesn't exist in mainifest
rem        file.
:: Start of rlocation
goto :rlocation_end
:rlocation
if "%~2" equ "" (
  echo>&2 ERROR: Expected two arguments for rlocation function.
  exit 1
)
if "%RUNFILES_MANIFEST_ONLY%" neq "1" (
  set %~2=%~1
  exit /b 0
)
if exist "%RUNFILES_DIR%" (
  set RUNFILES_MANIFEST_FILE=%RUNFILES_DIR%_manifest
)
if "%RUNFILES_MANIFEST_FILE%" equ "" (
  set RUNFILES_MANIFEST_FILE=%~f0.runfiles\MANIFEST
)
if not exist "%RUNFILES_MANIFEST_FILE%" (
  set RUNFILES_MANIFEST_FILE=%~f0.runfiles_manifest
)
set MF=%RUNFILES_MANIFEST_FILE:/=\%
if not exist "%MF%" (
  echo>&2 ERROR: Manifest file %MF% does not exist.
  exit 1
)
set runfile_path=%~1
for /F "tokens=2* usebackq" %%i in (`%SYSTEMROOT%\system32\findstr.exe /l /c:"!runfile_path! " "%MF%"`) do (
  set abs_path=%%i
)
if "!abs_path!" equ "" (
  echo>&2 ERROR: !runfile_path! not found in runfiles manifest
  exit 1
)
set %~2=!abs_path!
exit /b 0
:rlocation_end
:: End of rlocation
j�	�	
rem Usage of rlocation function:
rem        call :rlocation <runfile_path> <abs_path>
rem        The rlocation function maps the given <runfile_path> to its absolute
rem        path and stores the result in a variable named <abs_path>.
rem        This function fails if the <runfile_path> doesn't exist in mainifest
rem        file.
:: Start of rlocation
goto :rlocation_end
:rlocation
if "%~2" equ "" (
  echo>&2 ERROR: Expected two arguments for rlocation function.
  exit 1
)
if "%RUNFILES_MANIFEST_ONLY%" neq "1" (
  set %~2=%~1
  exit /b 0
)
if exist "%RUNFILES_DIR%" (
  set RUNFILES_MANIFEST_FILE=%RUNFILES_DIR%_manifest
)
if "%RUNFILES_MANIFEST_FILE%" equ "" (
  set RUNFILES_MANIFEST_FILE=%~f0.runfiles\MANIFEST
)
if not exist "%RUNFILES_MANIFEST_FILE%" (
  set RUNFILES_MANIFEST_FILE=%~f0.runfiles_manifest
)
set MF=%RUNFILES_MANIFEST_FILE:/=\%
if not exist "%MF%" (
  echo>&2 ERROR: Manifest file %MF% does not exist.
  exit 1
)
set runfile_path=%~1
for /F "tokens=2* usebackq" %%i in (`%SYSTEMROOT%\system32\findstr.exe /l /c:"!runfile_path! " "%MF%"`) do (
  set abs_path=%%i
)
if "!abs_path!" equ "" (
  echo>&2 ERROR: !runfile_path! not found in runfiles manifest
  exit 1
)
set %~2=!abs_path!
exit /b 0
:rlocation_end
:: End of rlocation
$Helpers for rules running on windows�
%
aspect_bazel_libinternal_deps.bzl�bazel_lib_internal_deps'Fetch deps needed for local development*�
�
bazel_lib_internal_deps'Fetch deps needed for local development2A
bazel_lib_internal_deps&@@aspect_bazel_lib//:internal_deps.bzl
�
//lib:repositories.bzlry
)
aspect_bazel_liblibrepositories.bzl>
register_jq_toolchainsregister_jq_toolchains
2H
J�
 //tools/build_defs/repo:http.bzlrj
.
bazel_toolstools/build_defs/repohttp.bzl*
http_archivehttp_archive
7C
E�
!//tools/build_defs/repo:utils.bzlr]
/
bazel_toolstools/build_defs/repo	utils.bzl
maybemaybe
	8	=
		?�Our "development" dependencies

Users should *not* need to install these. If users see a load()
statement from these, that's a bug in our distribution.
 