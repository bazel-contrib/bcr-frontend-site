J
0
aspect_bazel_liblib/privatecopy_common.bzlHelpers for copy rules�
3
aspect_bazel_liblib/privatecopy_directory.bzl�	copy_directory�Copies a directory to another location.

This rule uses a Bash command on Linux/macOS/non-Windows, and a cmd.exe command on Windows (no Bash is required).

If using this rule with source directories, it is recommended that you use the
`--host_jvm_args=-DBAZEL_TRACK_SOURCE_DIRECTORIES=1` startup option so that changes
to files within source directories are detected. See
https://github.com/bazelbuild/bazel/commit/c64421bc35214f0414e4f4226cc953e8c55fa0d2
for more context.
"�
�
copy_directory�Copies a directory to another location.

This rule uses a Bash command on Linux/macOS/non-Windows, and a cmd.exe command on Windows (no Bash is required).

If using this rule with source directories, it is recommended that you use the
`--host_jvm_args=-DBAZEL_TRACK_SOURCE_DIRECTORIES=1` startup option so that changes
to files within source directories are detected. See
https://github.com/bazelbuild/bazel/commit/c64421bc35214f0414e4f4226cc953e8c55fa0d2
for more context.
*
nameA unique name for this target. 	
out 	
src "E
_copy_directory2@@aspect_bazel_lib//lib/private:copy_directory.bzl
qq,
*
nameA unique name for this target. 
	
out 
	
src �copy_directory_action�Helper function that creates an action to copy a directory from src to dst.

This helper is used by copy_directory. It is exposed as a public API so it can be used within
other rule implementations.
*�
�
copy_directory_action
ctxThe rule context. (V
srcKThe directory to make a copy of. Can be a source directory or TreeArtifact. (<
dst1The directory to copy to. Must be a TreeArtifact. (+

is_windowsDeprecated and unusedNone(�Helper function that creates an action to copy a directory from src to dst.

This helper is used by copy_directory. It is exposed as a public API so it can be used within
other rule implementations.
2K
copy_directory_action2@@aspect_bazel_lib//lib/private:copy_directory.bzl
AA�
//lib/private:copy_common.bzlr�
0
aspect_bazel_liblib/privatecopy_common.bzlI
COPY_EXECUTION_REQUIREMENTS_COPY_EXECUTION_REQUIREMENTS
8T
u�
 //lib/private:platform_utils.bzlrt
3
aspect_bazel_liblib/privateplatform_utils.bzl/
platform_utils_platform_utils
;J
^�Implementation of copy_directory macro and underlying rules.

This rule copies a directory to another location using Bash (on Linux/macOS) or
cmd.exe (on Windows).
� 
.
aspect_bazel_liblib/privatecopy_file.bzl�	copy_file�Copies a file or directory to another location.

`native.genrule()` is sometimes used to copy files (often wishing to rename them). The 'copy_file' rule does this with a simpler interface than genrule.

This rule uses a Bash command on Linux/macOS/non-Windows, and a cmd.exe command on Windows (no Bash is required).

If using this rule with source directories, it is recommended that you use the
`--host_jvm_args=-DBAZEL_TRACK_SOURCE_DIRECTORIES=1` startup option so that changes
to files within source directories are detected. See
https://github.com/bazelbuild/bazel/commit/c64421bc35214f0414e4f4226cc953e8c55fa0d2
for more context.
*�
�
	copy_file
nameName of the rule. (h
src]A Label. The file to make a copy of.
(Can also be the label of a rule that generates a file.) (=
out2Path of the output file, relative to this package. (�
is_executable�A boolean. Whether to make the output file executable. When
True, the rule's output can be executed using `bazel run` and can be
in the srcs of binary and test rules that require executable sources.
WARNING: If `allow_symlink` is True, `src` must also be executable.False(�
allow_symlink�A boolean. Whether to allow symlinking instead of copying.
When False, the output is always a hard copy. When True, the output
*can* be a symlink, but there is no guarantee that a symlink is
created (i.e., at the time of writing, we don't create symlinks on
Windows). Set this to True if you need fast copying and your tools can
handle symlinks (which most UNIX tools can).False(8
kwargs,further keyword arguments, e.g. `visibility`(�Copies a file or directory to another location.

`native.genrule()` is sometimes used to copy files (often wishing to rename them). The 'copy_file' rule does this with a simpler interface than genrule.

This rule uses a Bash command on Linux/macOS/non-Windows, and a cmd.exe command on Windows (no Bash is required).

If using this rule with source directories, it is recommended that you use the
`--host_jvm_args=-DBAZEL_TRACK_SOURCE_DIRECTORIES=1` startup option so that changes
to files within source directories are detected. See
https://github.com/bazelbuild/bazel/commit/c64421bc35214f0414e4f4226cc953e8c55fa0d2
for more context.
2:
	copy_file-@@aspect_bazel_lib//lib/private:copy_file.bzl
��*copy_file_impl2copy_file_impl�copy_file_action�Helper function that creates an action to copy a file from src to dst.

If src is a TreeArtifact, dir_path must be specified as the path within
the TreeArtifact to the file to copy.

This helper is used by copy_file. It is exposed as a public API so it can be used within
other rule implementations.
*�
�
copy_file_action
ctxThe rule context. (P
srcEThe source file to copy or TreeArtifact to copy a single file out of. ( 
dstThe destination file. (c
dir_pathOIf src is a TreeArtifact, the path within the TreeArtifact to the file to copy.None(+

is_windowsDeprecated and unusedNone(�Helper function that creates an action to copy a file from src to dst.

If src is a TreeArtifact, dir_path must be specified as the path within
the TreeArtifact to the file to copy.

This helper is used by copy_file. It is exposed as a public API so it can be used within
other rule implementations.
2A
copy_file_action-@@aspect_bazel_lib//lib/private:copy_file.bzl
WW�
//lib/private:copy_common.bzlr�
0
aspect_bazel_liblib/privatecopy_common.bzlI
COPY_EXECUTION_REQUIREMENTS_COPY_EXECUTION_REQUIREMENTS
8T
u�
 //lib/private:directory_path.bzlry
3
aspect_bazel_liblib/privatedirectory_path.bzl4
DirectoryPathInfoDirectoryPathInfo
<M
O�
 //lib/private:platform_utils.bzlrt
3
aspect_bazel_liblib/privateplatform_utils.bzl/
platform_utils_platform_utils
;J
^�Implementation of copy_file macro and underlying rules.

These rules copy a file to another location using Bash (on Linux/macOS) or
cmd.exe (on Windows). `_copy_xfile` marks the resulting file executable,
`_copy_file` does not.
�
0
aspect_bazel_liblib/privatecopy_to_bin.bzl�copy_to_bin�Copies a source file to output tree at the same workspace-relative path.

e.g. `<execroot>/path/to/file -> <execroot>/bazel-out/<platform>/bin/path/to/file`

If a file passed in is already in the output tree is then it is added directly to the
DefaultInfo provided by the rule without a copy.

This is useful to populate the output folder with all files needed at runtime, even
those which aren't outputs of a Bazel rule.

This way you can run a binary in the output folder (execroot or runfiles_root)
without that program needing to rely on a runfiles helper library or be aware that
files are divided between the source tree and the output tree.
"�
�
copy_to_bin�Copies a source file to output tree at the same workspace-relative path.

e.g. `<execroot>/path/to/file -> <execroot>/bazel-out/<platform>/bin/path/to/file`

If a file passed in is already in the output tree is then it is added directly to the
DefaultInfo provided by the rule without a copy.

This is useful to populate the output folder with all files needed at runtime, even
those which aren't outputs of a Bazel rule.

This way you can run a binary in the output folder (execroot or runfiles_root)
without that program needing to rely on a runfiles helper library or be aware that
files are divided between the source tree and the output tree.
*
nameA unique name for this target. 

srcs "?
_copy_to_bin/@@aspect_bazel_lib//lib/private:copy_to_bin.bzl
��,
*
nameA unique name for this target. 


srcs �copy_file_to_bin_action�Helper function that creates an action to copy a file to the output tree.

File are copied to the same workspace-relative path. The resulting files is
returned.

If the file passed in is already in the output tree is then it is returned
without a copy action.
*�
�
copy_file_to_bin_action
ctxThe rule context. (
fileThe file to copy. (+

is_windowsDeprecated and unusedNone(�Helper function that creates an action to copy a file to the output tree.

File are copied to the same workspace-relative path. The resulting files is
returned.

If the file passed in is already in the output tree is then it is returned
without a copy action.
"
A File in the output tree.2J
copy_file_to_bin_action/@@aspect_bazel_lib//lib/private:copy_to_bin.bzl
�copy_files_to_bin_actions�Helper function that creates actions to copy files to the output tree.

Files are copied to the same workspace-relative path. The resulting list of
files is returned.

If a file passed in is already in the output tree is then it is added
directly to the result without a copy action.
*�
�
copy_files_to_bin_actions
ctxThe rule context. ("
filesList of File objects. (+

is_windowsDeprecated and unusedNone(�Helper function that creates actions to copy files to the output tree.

Files are copied to the same workspace-relative path. The resulting list of
files is returned.

If a file passed in is already in the output tree is then it is added
directly to the result without a copy action.
"*
(List of File objects in the output tree.2L
copy_files_to_bin_actions/@@aspect_bazel_lib//lib/private:copy_to_bin.bzl
^^�
//lib/private:copy_file.bzlrr
.
aspect_bazel_liblib/privatecopy_file.bzl2
copy_file_actioncopy_file_action
7G
Ia
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.9Implementation of copy_to_bin macro and underlying rules.�
6
aspect_bazel_liblib/privatecopy_to_directory.bzl�copy_to_directory_action�Helper function to copy files to a directory.

This helper is used by copy_to_directory. It is exposed as a public API so it can be used within
other rule implementations where additional_files can also be passed in.
*�
�
copy_to_directory_action
ctxThe rule context. (q
srcseFiles and/or directories or targets that provide DirectoryPathInfo to copy into the output directory. (<
dst1The directory to copy to. Must be a TreeArtifact. (�
additional_filesgList or depset of additional files to copy that are not in the DefaultInfo or DirectoryPathInfo of srcs[](�

root_pathsqList of paths that are roots in the output directory.

See copy_to_directory rule documentation for more details.["."](�
include_external_repositories�List of external repository names to include in the output directory.

See copy_to_directory rule documentation for more details.[](�
include_srcs_packagesrList of Bazel packages to include in output directory.

See copy_to_directory rule documentation for more details.["**"](�
exclude_srcs_packages�List of Bazel packages (with glob support) to exclude from output directory.

See copy_to_directory rule documentation for more details.[](�
include_srcs_patterns}List of paths (with glob support) to include in output directory.

See copy_to_directory rule documentation for more details.["**"](�
exclude_srcs_patternsList of paths (with glob support) to exclude from output directory.

See copy_to_directory rule documentation for more details.[](Q
exclude_prefixes7List of path prefixes to exclude from output directory.[](�
replace_prefixes�Map of paths prefixes to replace in the output directory path when copying files.

See copy_to_directory rule documentation for more details.{}(�
allow_overwrites�If True, allow files to be overwritten if the same output file is copied to twice.

See copy_to_directory rule documentation for more details.False(+

is_windowsDeprecated and unusedNone(�Helper function to copy files to a directory.

This helper is used by copy_to_directory. It is exposed as a public API so it can be used within
other rule implementations where additional_files can also be passed in.
2Q
copy_to_directory_action5@@aspect_bazel_lib//lib/private:copy_to_directory.bzl
���
//lib/private:copy_common.bzlr�
0
aspect_bazel_liblib/privatecopy_common.bzlI
COPY_EXECUTION_REQUIREMENTS_COPY_EXECUTION_REQUIREMENTS
8T
u�
 //lib/private:directory_path.bzlry
3
aspect_bazel_liblib/privatedirectory_path.bzl4
DirectoryPathInfoDirectoryPathInfo
<M
O�
//lib/private:glob_match.bzlrg
/
aspect_bazel_liblib/privateglob_match.bzl&

glob_match
glob_match
8B
Du
//lib/private:paths.bzlrX
*
aspect_bazel_liblib/private	paths.bzl
pathspaths
38
:�
 //lib/private:platform_utils.bzlrt
3
aspect_bazel_liblib/privateplatform_utils.bzl/
platform_utils_platform_utils
;J
^h
//lib:paths.bzlrS

bazel_skyliblib	paths.bzl#
pathsskylib_paths
&2
= copy_to_directory implementation�'
3
aspect_bazel_liblib/privatedirectory_path.bzl�directory_path}Provide DirectoryPathInfo to reference some path within a directory.

Otherwise there is no way to give a Bazel label for it."�
�
directory_path}Provide DirectoryPathInfo to reference some path within a directory.

Otherwise there is no way to give a Bazel label for it.*
nameA unique name for this target. ?
	directory.a TreeArtifact (ctx.actions.declare_directory) *
pathpath relative to the directory "D
directory_path2@@aspect_bazel_lib//lib/private:directory_path.bzl
,
*
nameA unique name for this target. A
?
	directory.a TreeArtifact (ctx.actions.declare_directory) ,
*
pathpath relative to the directory �make_directory_path�Helper function to generate a directory_path target and return its label.

Provide DirectoryPathInfo to reference some path within a directory.

Otherwise there is no way to give a Bazel label for it."�
�
make_directory_path�Helper function to generate a directory_path target and return its label.

Provide DirectoryPathInfo to reference some path within a directory.

Otherwise there is no way to give a Bazel label for it.*
nameA unique name for this target. ?
	directory.a TreeArtifact (ctx.actions.declare_directory) *
pathpath relative to the directory "D
directory_path2@@aspect_bazel_lib//lib/private:directory_path.bzl
((,
*
nameA unique name for this target. A
?
	directory.a TreeArtifact (ctx.actions.declare_directory) ,
*
pathpath relative to the directory �make_directory_paths�Helper function to convert a dict of directory to path mappings to directory_path targets and labels.

For example,

```
make_directory_paths("my_name", {
    "//directory/artifact:target_1": "file/path",
    "//directory/artifact:target_2": ["file/path1", "file/path2"],
})
```

generates the targets,

```
directory_path(
    name = "my_name_0",
    directory = "//directory/artifact:target_1",
    path = "file/path"
)

directory_path(
    name = "my_name_1",
    directory = "//directory/artifact:target_2",
    path = "file/path1"
)

directory_path(
    name = "my_name_2",
    directory = "//directory/artifact:target_2",
    path = "file/path2"
)
```

and the list of targets is returned,

```
[
    "my_name_0",
    "my_name_1",
    "my_name_2",
]
```
b�
�	
�	
make_directory_paths�
nametThe target name to use for the generated targets & labels.

The names are generated as zero-indexed `name + "_" + i` (I
dict=The dictionary of directory keys to path or path list values. (B
kwargs6additional parameters to pass to each generated target(�Helper function to convert a dict of directory to path mappings to directory_path targets and labels.

For example,

```
make_directory_paths("my_name", {
    "//directory/artifact:target_1": "file/path",
    "//directory/artifact:target_2": ["file/path1", "file/path2"],
})
```

generates the targets,

```
directory_path(
    name = "my_name_0",
    directory = "//directory/artifact:target_1",
    path = "file/path"
)

directory_path(
    name = "my_name_1",
    directory = "//directory/artifact:target_2",
    path = "file/path1"
)

directory_path(
    name = "my_name_2",
    directory = "//directory/artifact:target_2",
    path = "file/path2"
)
```

and the list of targets is returned,

```
[
    "my_name_0",
    "my_name_1",
    "my_name_2",
]
```
"L
JThe label of the generated `directory_path` targets named `name + "_" + i`2J
make_directory_paths2@@aspect_bazel_lib//lib/private:directory_path.bzl
<<"make_directory_path*make_directory_path�
�
make_directory_path�Helper function to generate a directory_path target and return its label.

Provide DirectoryPathInfo to reference some path within a directory.

Otherwise there is no way to give a Bazel label for it.*
nameA unique name for this target. ?
	directory.a TreeArtifact (ctx.actions.declare_directory) *
pathpath relative to the directory "D
directory_path2@@aspect_bazel_lib//lib/private:directory_path.bzl,
*
nameA unique name for this target. A
?
	directory.a TreeArtifact (ctx.actions.declare_directory) ,
*
pathpath relative to the directory �DirectoryPathInfoRJoins a label pointing to a TreeArtifact with a path nested within that directory.2�
�
DirectoryPathInfoRJoins a label pointing to a TreeArtifact with a path nested within that directory.;
	directory.a TreeArtifact (ctx.actions.declare_directory)&
pathpath relative to the directory"G
DirectoryPathInfo2@@aspect_bazel_lib//lib/private:directory_path.bzl
=
;
	directory.a TreeArtifact (ctx.actions.declare_directory)(
&
pathpath relative to the directoryl
//lib:utils.bzlrW
"
aspect_bazel_liblib	utils.bzl#
to_label	_to_label
*3
AwRule and corresponding provider that joins a label pointing to a TreeArtifact
with a path nested within that directory
�
)
aspect_bazel_liblib/privatedocs.bzl�stardoc_with_diff_test�Creates a stardoc target that can be auto-detected by update_docs to write the generated doc to the source tree and test that it's up to date.

This is helpful for minimizing boilerplate in repos wih lots of stardoc targets.
*�
�
stardoc_with_diff_test�
name�the name of the stardoc file to be written to the current source directory (.md will be appended to the name). Call bazel run on this target to update the file. (]
bzl_library_targetCthe label of the `bzl_library` target to generate documentation for (d
kwargsXadditional attributes passed to the stardoc() rule, such as for overriding the templates(�Creates a stardoc target that can be auto-detected by update_docs to write the generated doc to the source tree and test that it's up to date.

This is helpful for minimizing boilerplate in repos wih lots of stardoc targets.
2B
stardoc_with_diff_test(@@aspect_bazel_lib//lib/private:docs.bzl
*_stardoc2_stardoc�update_docs�Stamps an executable run for writing all stardocs declared with stardoc_with_diff_test to the source tree.

This is to be used in tandem with `stardoc_with_diff_test()` to produce a convenient workflow
for generating, testing, and updating all doc files as follows:

``` bash
bazel build //{docs_folder}/... && bazel test //{docs_folder}/... && bazel run //{docs_folder}:update
```

eg.

``` bash
bazel build //docs/... && bazel test //docs/... && bazel run //docs:update
```
*�
�
update_docs1
namethe name of executable target"update"(�Stamps an executable run for writing all stardocs declared with stardoc_with_diff_test to the source tree.

This is to be used in tandem with `stardoc_with_diff_test()` to produce a convenient workflow
for generating, testing, and updating all doc files as follows:

``` bash
bazel build //{docs_folder}/... && bazel test //{docs_folder}/... && bazel run //{docs_folder}:update
```

eg.

``` bash
bazel build //docs/... && bazel test //docs/... && bazel run //docs:update
```
27
update_docs(@@aspect_bazel_lib//lib/private:docs.bzl
2write_source_files�
//lib:write_source_files.bzlrw
/
aspect_bazel_liblibwrite_source_files.bzl6
write_source_fileswrite_source_files
8J
Lm
//stardoc:stardoc.bzlrR

stardocstardocstardoc.bzl!
stardoc_stardoc
'/
<,Helpers for generating stardoc documentation�
5
aspect_bazel_liblib/privateexpand_locations.bzl�expand_locations�Expand location templates.

Expands all `$(execpath ...)`, `$(rootpath ...)` and deprecated `$(location ...)` templates in the
given string by replacing with the expanded path. Expansion only works for labels that point to direct dependencies
of this rule or that are explicitly listed in the optional argument targets.

See https://docs.bazel.build/versions/main/be/make-variables.html#predefined_label_variables.

Use `$(rootpath)` and `$(rootpaths)` to expand labels to the runfiles path that a built binary can use
to find its dependencies. This path is of the format:
- `./file`
- `path/to/file`
- `../external_repo/path/to/file`

Use `$(execpath)` and `$(execpaths)` to expand labels to the execroot (where Bazel runs build actions).
This is of the format:
- `./file`
- `path/to/file`
- `external/external_repo/path/to/file`
- `<bin_dir>/path/to/file`
- `<bin_dir>/external/external_repo/path/to/file`

The deprecated `$(location)` and `$(locations)` expansions returns either the execpath or rootpath depending on the context.
*�

�

expand_locations
ctxcontext ("
inputString to be expanded (C
targets2List of targets for additional lookup information.[](�Expand location templates.

Expands all `$(execpath ...)`, `$(rootpath ...)` and deprecated `$(location ...)` templates in the
given string by replacing with the expanded path. Expansion only works for labels that point to direct dependencies
of this rule or that are explicitly listed in the optional argument targets.

See https://docs.bazel.build/versions/main/be/make-variables.html#predefined_label_variables.

Use `$(rootpath)` and `$(rootpaths)` to expand labels to the runfiles path that a built binary can use
to find its dependencies. This path is of the format:
- `./file`
- `path/to/file`
- `../external_repo/path/to/file`

Use `$(execpath)` and `$(execpaths)` to expand labels to the execroot (where Bazel runs build actions).
This is of the format:
- `./file`
- `path/to/file`
- `external/external_repo/path/to/file`
- `<bin_dir>/path/to/file`
- `<bin_dir>/external/external_repo/path/to/file`

The deprecated `$(location)` and `$(locations)` expansions returns either the execpath or rootpath depending on the context.
"(
&The expanded path or the original path2H
expand_locations4@@aspect_bazel_lib//lib/private:expand_locations.bzl
Helpers to expand location�
4
aspect_bazel_liblib/privateexpand_template.bzl�expand_template�Template expansion

This performs a simple search over the template file for the keys in substitutions,
and replaces them with the corresponding values.

Values may also use location templates as documented in
[expand_locations](https://github.com/aspect-build/bazel-lib/blob/main/docs/expand_make_vars.md#expand_locations)
as well as [configuration variables](https://docs.bazel.build/versions/main/skylark/lib/ctx.html#var)
such as `$(BINDIR)`, `$(TARGET_CPU)`, and `$(COMPILATION_MODE)` as documented in
[expand_variables](https://github.com/aspect-build/bazel-lib/blob/main/docs/expand_make_vars.md#expand_variables).
"�
�
expand_template�Template expansion

This performs a simple search over the template file for the keys in substitutions,
and replaces them with the corresponding values.

Values may also use location templates as documented in
[expand_locations](https://github.com/aspect-build/bazel-lib/blob/main/docs/expand_make_vars.md#expand_locations)
as well as [configuration variables](https://docs.bazel.build/versions/main/skylark/lib/ctx.html#var)
such as `$(BINDIR)`, `$(TARGET_CPU)`, and `$(COMPILATION_MODE)` as documented in
[expand_variables](https://github.com/aspect-build/bazel-lib/blob/main/docs/expand_make_vars.md#expand_variables).
*
nameA unique name for this target. @
data2List of targets for additional lookup information.2[]H
is_executable.Whether to mark the output file as executable.2False,
out!Where to write the expanded file. 9
substitutions$Mapping of strings to substitutions.
 ,
templateThe template file to expand. "F
expand_template3@@aspect_bazel_lib//lib/private:expand_template.bzl
;;,
*
nameA unique name for this target. B
@
data2List of targets for additional lookup information.2[]J
H
is_executable.Whether to mark the output file as executable.2False.
,
out!Where to write the expanded file. ;
9
substitutions$Mapping of strings to substitutions.
 .
,
templateThe template file to expand. �
"//lib/private:expand_locations.bzlrz
5
aspect_bazel_liblib/privateexpand_locations.bzl3
expand_locations_expand_locations
=N
d�
"//lib/private:expand_variables.bzlrz
5
aspect_bazel_liblib/privateexpand_variables.bzl3
expand_variables_expand_variables
=N
dexpand_template rule�
5
aspect_bazel_liblib/privateexpand_variables.bzl�expand_variables�	Expand make variables and substitute like genrule does.

This function is the same as ctx.expand_make_variables with the additional
genrule-like substitutions of:

  - `$@`: The output file if it is a single file. Else triggers a build error.

  - `$(@D)`: The output directory.

    If there is only one file name in outs, this expands to the directory containing that file.

    If there is only one directory in outs, this expands to the single output directory.

    If there are multiple files, this instead expands to the package's root directory in the bin tree,
    even if all generated files belong to the same subdirectory!

  - `$(RULEDIR)`: The output directory of the rule, that is, the directory
    corresponding to the name of the package containing the rule under the bin tree.

  - `$(BUILD_FILE_PATH)`: ctx.build_file_path

  - `$(VERSION_FILE)`: ctx.version_file.path

  - `$(INFO_FILE)`: ctx.info_file.path

  - `$(TARGET)`: ctx.label

  - `$(WORKSPACE)`: ctx.workspace_name

See https://docs.bazel.build/versions/main/be/general.html#genrule.cmd and
https://docs.bazel.build/versions/main/be/make-variables.html#predefined_genrule_variables
for more information of how these special variables are expanded.
*�
�
expand_variables 
ctxstarlark rule context (
sexpression to expand (O
outsAdeclared outputs of the rule, for expanding references to outputs[](�

output_dir�whether the rule is expected to output a directory (TreeArtifact)
Deprecated. For backward compatability with @aspect_bazel_lib 1.x. Pass
output tree artifacts to outs instead.False(f
attribute_nameJname of the attribute containing the expression. Used for error reporting."args"(�	Expand make variables and substitute like genrule does.

This function is the same as ctx.expand_make_variables with the additional
genrule-like substitutions of:

  - `$@`: The output file if it is a single file. Else triggers a build error.

  - `$(@D)`: The output directory.

    If there is only one file name in outs, this expands to the directory containing that file.

    If there is only one directory in outs, this expands to the single output directory.

    If there are multiple files, this instead expands to the package's root directory in the bin tree,
    even if all generated files belong to the same subdirectory!

  - `$(RULEDIR)`: The output directory of the rule, that is, the directory
    corresponding to the name of the package containing the rule under the bin tree.

  - `$(BUILD_FILE_PATH)`: ctx.build_file_path

  - `$(VERSION_FILE)`: ctx.version_file.path

  - `$(INFO_FILE)`: ctx.info_file.path

  - `$(TARGET)`: ctx.label

  - `$(WORKSPACE)`: ctx.workspace_name

See https://docs.bazel.build/versions/main/be/general.html#genrule.cmd and
https://docs.bazel.build/versions/main/be/make-variables.html#predefined_genrule_variables
for more information of how these special variables are expanded.
"!
`s` with the variables expanded2H
expand_variables4@@aspect_bazel_lib//lib/private:expand_variables.bzl
c
//lib:paths.bzlrN

bazel_skyliblib	paths.bzl
paths_spaths
&-
8 Helpers to expand make variables�
/
aspect_bazel_liblib/privateglob_match.bzl�
glob_match�Test if the passed path matches the glob expression.

`*` A single asterisk stands for zero or more arbitrary characters except for the the path separator `/` if `match_path_separator` is False

`?` The question mark stands for exactly one character except for the the path separator `/` if `match_path_separator` is False

`**` A double asterisk stands for an arbitrary sequence of 0 or more characters. It is only allowed when preceded by either the beginning of the string or a slash. Likewise it must be followed by a slash or the end of the pattern.
*�
�

glob_match
exprthe glob expression (?
path3the path against which to match the glob expression (u
match_path_separatorTwhether or not to match the path separator '/' when matching `*` and `?` expressionsFalse(�Test if the passed path matches the glob expression.

`*` A single asterisk stands for zero or more arbitrary characters except for the the path separator `/` if `match_path_separator` is False

`?` The question mark stands for exactly one character except for the the path separator `/` if `match_path_separator` is False

`**` A double asterisk stands for an arbitrary sequence of 0 or more characters. It is only allowed when preceded by either the beginning of the string or a slash. Likewise it must be followed by a slash or the end of the pattern.
".
,True if the path matches the glob expression2<

glob_match.@@aspect_bazel_lib//lib/private:glob_match.bzl
**$	GLOB_SYMBOLSj2
**
*
?�
Basic glob match implementation for starlark.

This was originally developed by @jbedard for use in rules_js
(https://github.com/aspect-build/rules_js/blob/6ca32d5199ddc0bf19bd704f591030dc1468ca5f/npm/private/pkg_glob.bzl)
to support the pnpm public-hoist-expr option (https://pnpm.io/npmrc#public-hoist-expr). The pnpm
implementation and tests were used as a reference implementation:
    https://github.com/pnpm/pnpm/blob/v7.4.0-2/packages/matcher/src/index.ts
    https://github.com/pnpm/pnpm/blob/v7.4.0-2/packages/matcher/test/index.ts
�
.
aspect_bazel_liblib/privatehost_repo.bzl�		host_repo+Exposes information about the host platformR�
�
	host_repo+Exposes information about the host platform.
name"A unique name for this repository. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 *:
	host_repo-@@aspect_bazel_lib//lib/private:host_repo.bzl
%%0
.
name"A unique name for this repository. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
//lib/private:repo_utils.bzlrg
/
aspect_bazel_liblib/privaterepo_utils.bzl&

repo_utils
repo_utils
8B
Dm
//lib:versions.bzlrU
!
bazel_skyliblibversions.bzl"
versionsversions
*2
4=A repository that exposes information about the host platform�
'
aspect_bazel_liblib/privatejq.bzl�
//lib:stamping.bzlr�
%
aspect_bazel_liblibstamping.bzl(
STAMP_ATTRSSTAMP_ATTRS
.9(
maybe_stampmaybe_stamp
=H
JImplementation for jq rule�&
1
aspect_bazel_liblib/privatejq_toolchain.bzl�jq_toolchain"�
�
jq_toolchain*
nameA unique name for this target. 	
bin "@
jq_toolchain0@@aspect_bazel_lib//lib/private:jq_toolchain.bzl
TT,
*
nameA unique name for this target. 
	
bin �JqInfoProvide info for executing jq2�
�
JqInfoProvide info for executing jq
binExecutable jq binary":
JqInfo0@@aspect_bazel_lib//lib/private:jq_toolchain.bzl
33

binExecutable jq binary�jq_host_alias_repo�Creates a repository with a shorter name meant for the host platform, which contains
a BUILD.bazel file that exports symlinks to the host platform's binaries
R�	
�
jq_host_alias_repo�Creates a repository with a shorter name meant for the host platform, which contains
a BUILD.bazel file that exports symlinks to the host platform's binaries
.
name"A unique name for this repository. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 *F
jq_host_alias_repo0@@aspect_bazel_lib//lib/private:jq_toolchain.bzl
�%�%0
.
name"A unique name for this repository. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �	jq_platform_repo,Fetch external tools needed for jq toolchainR�	
�
jq_platform_repo,Fetch external tools needed for jq toolchain.
name"A unique name for this repository. 
platform �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 
version *D
jq_platform_repo0@@aspect_bazel_lib//lib/private:jq_toolchain.bzl
�#�#0
.
name"A unique name for this repository. 

platform �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 

version �jq_toolchains_repolCreates a repository with toolchain definitions for all known platforms
which can be registered or selected.R�

�
jq_toolchains_repolCreates a repository with toolchain definitions for all known platforms
which can be registered or selected..
name"A unique name for this repository. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 A
user_repository_name#Base name for toolchains repository2""*F
jq_toolchains_repo0@@aspect_bazel_lib//lib/private:jq_toolchain.bzl
�%�%0
.
name"A unique name for this repository. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 C
A
user_repository_name#Base name for toolchains repository2""�
//lib/private:repo_utils.bzlrg
/
aspect_bazel_liblib/privaterepo_utils.bzl&

repo_utils
repo_utils
8B
D"	DEFAULT_JQ_VERSION1.6j1.6)Setup jq toolchain repositories and rules�
:
aspect_bazel_liblib/privatelocal_config_platform.bzl�local_config_platform�Generates a repository in the same shape as the auto-generated @local_config_platform repository with an added bzl_library.

This is useful for rules that want to load `HOST_CONSTRAINTS` from `@local_config_platform//:constraints.bzl` and
also want to use stardoc for generating documentation.
R�

�
local_config_platform�Generates a repository in the same shape as the auto-generated @local_config_platform repository with an added bzl_library.

This is useful for rules that want to load `HOST_CONSTRAINTS` from `@local_config_platform//:constraints.bzl` and
also want to use stardoc for generating documentation.
.
name"A unique name for this repository. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 *R
local_config_platform9@@aspect_bazel_lib//lib/private:local_config_platform.bzl
"("(0
.
name"A unique name for this repository. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
//lib/private:repo_utils.bzlrg
/
aspect_bazel_liblib/privaterepo_utils.bzl&

repo_utils
repo_utils
8B
D&local_config_platform repository rule
�
1
aspect_bazel_liblib/privateoutput_files.bzl�output_filesjA rule that provides file(s) specific via DefaultInfo from a given target's DefaultInfo or OutputGroupInfo"�
�
output_filesjA rule that provides file(s) specific via DefaultInfo from a given target's DefaultInfo or OutputGroupInfo*
nameA unique name for this target. d
output_groupNif set, we look in the specified output group for paths instead of DefaultInfo2""�
paths�the paths of the file(s), relative to their roots, to provide via DefaultInfo from the given target's DefaultInfo or OutputGroupInfo ^
targetPthe target to look in for requested paths in its' DefaultInfo or OutputGroupInfo "@
output_files0@@aspect_bazel_lib//lib/private:output_files.bzl
$$,
*
nameA unique name for this target. f
d
output_groupNif set, we look in the specified output group for paths instead of DefaultInfo2""�
�
paths�the paths of the file(s), relative to their roots, to provide via DefaultInfo from the given target's DefaultInfo or OutputGroupInfo `
^
targetPthe target to look in for requested paths in its' DefaultInfo or OutputGroupInfo �
make_output_files�Helper function to generate a output_files target and return its label.

A rule that provides file(s) specific via DefaultInfo from a given target's DefaultInfo or OutputGroupInfo"�
�
make_output_files�Helper function to generate a output_files target and return its label.

A rule that provides file(s) specific via DefaultInfo from a given target's DefaultInfo or OutputGroupInfo*
nameA unique name for this target. d
output_groupNif set, we look in the specified output group for paths instead of DefaultInfo2""�
paths�the paths of the file(s), relative to their roots, to provide via DefaultInfo from the given target's DefaultInfo or OutputGroupInfo ^
targetPthe target to look in for requested paths in its' DefaultInfo or OutputGroupInfo "@
output_files0@@aspect_bazel_lib//lib/private:output_files.bzl
88,
*
nameA unique name for this target. f
d
output_groupNif set, we look in the specified output group for paths instead of DefaultInfo2""�
�
paths�the paths of the file(s), relative to their roots, to provide via DefaultInfo from the given target's DefaultInfo or OutputGroupInfo `
^
targetPthe target to look in for requested paths in its' DefaultInfo or OutputGroupInfo l
//lib:utils.bzlrW
"
aspect_bazel_liblib	utils.bzl#
to_label	_to_label
*3
Aoutput_files implementation
�
0
aspect_bazel_liblib/privateparams_file.bzl�params_file"�
�
params_file*
nameA unique name for this target. 
args2[]
data2[]
newline2"auto"	
out ">
params_file/@@aspect_bazel_lib//lib/private:params_file.bzl
33,
*
nameA unique name for this target. 

args2[]

data2[]

newline2"auto"
	
out �
"//lib/private:expand_locations.bzlry
5
aspect_bazel_liblib/privateexpand_locations.bzl2
expand_locationsexpand_locations
>N
Pparams_file rule�
*
aspect_bazel_liblib/private	patch.bzl�patch�Implementation of patching an already extracted repository.

This rule is intended to be used in the implementation function of
a repository rule. If the parameters `patches`, `patch_tool`,
`patch_args`, `patch_cmds` and `patch_cmds_win` are not specified
then they are taken from `ctx.attr`.
*�	
�	
patchW
ctxLThe repository context of the repository rule calling this utility
function. (O
patches<The patch files to apply. List of strings, Labels, or paths.None(i

patch_cmdsSBash commands to run for patching, passed one at a
time to bash -c. List of stringsNone(�
patch_cmds_win�Powershell commands to run for patching, passed
one at a time to powershell /c. List of strings. If the
boolean value of this parameter is false, patch_cmds will be
used and this parameter will be ignored.None(U

patch_tool?Path of the patch tool to execute for applying
patches. String.None(K

patch_args5Arguments to pass to the patch tool. List of strings.None(\
authLAn optional dict specifying authentication information for some of the URLs.None(<
patch_directory!Directory to apply the patches inNone(�Implementation of patching an already extracted repository.

This rule is intended to be used in the implementation function of
a repository rule. If the parameters `patches`, `patch_tool`,
`patch_args`, `patch_cmds` and `patch_cmds_win` are not specified
then they are taken from `ctx.attr`.
22
patch)@@aspect_bazel_lib//lib/private:patch.bzl
..�
//lib/private:repo_utils.bzlrg
/
aspect_bazel_liblib/privaterepo_utils.bzl&

repo_utils
repo_utils
8B
D�Fork of @bazel_tools//tools/build_defs/repo:utils.bzl patch function with
working_directory argument added.

Upstream code is at
https://github.com/bazelbuild/bazel/blob/f4214746fcd15f0ef8c4e747ef8e3edca9f112a5/tools/build_defs/repo/utils.bzl#L87
�
*
aspect_bazel_liblib/private	paths.bzlc
//lib:paths.bzlrN

bazel_skyliblib	paths.bzl
paths_spaths
&-
8.Path utils built on top of Skylib's path utils�
3
aspect_bazel_liblib/privateplatform_utils.bzl�
:constraints.bzlrl
(
local_config_platformconstraints.bzl2
HOST_CONSTRAINTSHOST_CONSTRAINTS
3C
EUtility functions for platformsY
/
aspect_bazel_liblib/privaterepo_utils.bzl&Utility functions for repository rules�
/
aspect_bazel_liblib/privaterun_binary.bzl�
run_binary]Runs a binary as a build action.

This rule does not require Bash (unlike `native.genrule`).
"�
�	

run_binary]Runs a binary as a build action.

This rule does not require Bash (unlike `native.genrule`).
*
nameA unique name for this target. 
args2[]
env
2{}
execution_requirements
2{}
mnemonic2""
out_dirs2[]
outs
progress_message2""
srcs2[]�
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.
2-1

tool "=
_run_binary.@@aspect_bazel_lib//lib/private:run_binary.bzl
nn,
*
nameA unique name for this target. 

args2[]

env
2{} 

execution_requirements
2{}

mnemonic2""

out_dirs2[]


outs

progress_message2""

srcs2[]�
�
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.
2-1


tool �
//lib:stamping.bzlr�
%
aspect_bazel_liblibstamping.bzl(
STAMP_ATTRSSTAMP_ATTRS
.9(
maybe_stampmaybe_stamp
=H
J�
"//lib/private:expand_locations.bzlry
5
aspect_bazel_liblib/privateexpand_locations.bzl2
expand_locationsexpand_locations
>N
P�
"//lib/private:expand_variables.bzlry
5
aspect_bazel_liblib/privateexpand_variables.bzl2
expand_variablesexpand_variables
>N
Pa
//lib:dicts.bzlrL

bazel_skyliblib	dicts.bzl
dictsdicts
',
.run_binary implementation�	
-
aspect_bazel_liblib/privatestamping.bzl�is_stamping_enabled3Determine whether or not build stamping is enabled.*�
�
is_stamping_enabled6
attr*A rule's struct of attributes (`ctx.attr`) (3Determine whether or not build stamping is enabled."
bool: The stamp value2C
is_stamping_enabled,@@aspect_bazel_lib//lib/private:stamping.bzl
++�stamp_build_setting*�
�
stamp_build_setting

name ('

visibility["//visibility:public"](2C
stamp_build_setting,@@aspect_bazel_lib//lib/private:stamping.bzl
"_stamp_build_setting2_stamp_build_setting�StampSettingInfo1Information about the `--stamp` command line flag2�
�
StampSettingInfo1Information about the `--stamp` command line flag<
value3bool: Whether or not the `--stamp` flag was enabled"@
StampSettingInfo,@@aspect_bazel_lib//lib/private:stamping.bzl
>
<
value3bool: Whether or not the `--stamp` flag was enabled�A small utility module dedicated to detecting whether or not the `--stamp` flag is enabled
This module can be removed likely after the following PRs ar addressed:
- https://github.com/bazelbuild/bazel/issues/11164
G
*
aspect_bazel_liblib/private	utils.bzlGeneral utility functions�
6
aspect_bazel_liblib/privatewrite_source_file.bzl�write_source_filelWrite a file or folder to the output tree. Stamp out tests that ensure the sources exist and are up to date."�
�
write_source_filelWrite a file or folder to the output tree. Stamp out tests that ensure the sources exist and are up to date.*
nameA unique name for this target. 8
additional_update_targets*
WriteSourceFileInfo2[]
in_file2None
out_file2"""K
_write_source_file5@@aspect_bazel_lib//lib/private:write_source_file.bzl
,
*
nameA unique name for this target. :
8
additional_update_targets*
WriteSourceFileInfo2[]

in_file2None

out_file2""�WriteSourceFileInfo&Provider for write_source_file targets2�
�
WriteSourceFileInfo&Provider for write_source_file targets6

executable(Executable that updates the source files"L
WriteSourceFileInfo5@@aspect_bazel_lib//lib/private:write_source_file.bzl
8
6

executable(Executable that updates the source files�
//lib/private:diff_test.bzlre
.
aspect_bazel_liblib/privatediff_test.bzl%
	diff_test
_diff_test
6@
O�
 //lib/private:directory_path.bzlry
3
aspect_bazel_liblib/privatedirectory_path.bzl4
DirectoryPathInfoDirectoryPathInfo
<M
O�
(//lib/private:fail_with_message_test.bzlr�
;
aspect_bazel_liblib/privatefail_with_message_test.bzl>
fail_with_message_testfail_with_message_test
DZ
\u
//lib/private:utils.bzlrX
*
aspect_bazel_liblib/private	utils.bzl
utilsutils
38
: write_source_file implementation�
'
aspect_bazel_liblib/privateyq.bzl�is_split_operation*n
^
is_split_operation

args (2<
is_split_operation&@@aspect_bazel_lib//lib/private:yq.bzl
Implementation for yq rule�&
1
aspect_bazel_liblib/privateyq_toolchain.bzl�yq_toolchain"�
�
yq_toolchain*
nameA unique name for this target. 	
bin "@
yq_toolchain0@@aspect_bazel_lib//lib/private:yq_toolchain.bzl
||,
*
nameA unique name for this target. 
	
bin �YqInfoProvide info for executing yq2�
�
YqInfoProvide info for executing yq
binExecutable yq binary":
YqInfo0@@aspect_bazel_lib//lib/private:yq_toolchain.bzl
[[

binExecutable yq binary�yq_host_alias_repo�Creates a repository with a shorter name meant for the host platform, which contains
a BUILD.bazel file that exports symlinks to the host platform's binaries
R�	
�
yq_host_alias_repo�Creates a repository with a shorter name meant for the host platform, which contains
a BUILD.bazel file that exports symlinks to the host platform's binaries
.
name"A unique name for this repository. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 *F
yq_host_alias_repo0@@aspect_bazel_lib//lib/private:yq_toolchain.bzl
�%�%0
.
name"A unique name for this repository. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �	yq_platform_repo,Fetch external tools needed for yq toolchainR�	
�
yq_platform_repo,Fetch external tools needed for yq toolchain.
name"A unique name for this repository. 
platform �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 
version *D
yq_platform_repo0@@aspect_bazel_lib//lib/private:yq_toolchain.bzl
�#�#0
.
name"A unique name for this repository. 

platform �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 

version �yq_toolchains_repolCreates a repository with toolchain definitions for all known platforms
which can be registered or selected.R�

�
yq_toolchains_repolCreates a repository with toolchain definitions for all known platforms
which can be registered or selected..
name"A unique name for this repository. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 A
user_repository_name#Base name for toolchains repository2""*F
yq_toolchains_repo0@@aspect_bazel_lib//lib/private:yq_toolchain.bzl
�%�%0
.
name"A unique name for this repository. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 C
A
user_repository_name#Base name for toolchains repository2""�
//lib/private:repo_utils.bzlrg
/
aspect_bazel_liblib/privaterepo_utils.bzl&

repo_utils
repo_utils
8B
D(	DEFAULT_YQ_VERSION4.25.2j4.25.2)Setup yq toolchain repositories and rules�
?
aspect_bazel_lib"lib/tests/copy_to_directory_actionlib.bzl�lib"�
�
lib*
nameA unique name for this target. 
others2[]
srcs2[]"E
lib>@@aspect_bazel_lib//lib/tests/copy_to_directory_action:lib.bzl
,
*
nameA unique name for this target. 

others2[]

srcs2[]�
3//lib/tests/copy_to_directory_action:other_info.bzlr|
F
aspect_bazel_lib"lib/tests/copy_to_directory_actionother_info.bzl$
	OtherInfo	OtherInfo
OX
Z>
Test rule to create a lib with a DefaultInfo and a OtherInfo
�
F
aspect_bazel_lib"lib/tests/copy_to_directory_actionother_info.bzl�	OtherInfoFor testing2�
�
	OtherInfoFor testing
filesA depset of files"R
	OtherInfoE@@aspect_bazel_lib//lib/tests/copy_to_directory_action:other_info.bzl


filesA depset of filesFor testing�
?
aspect_bazel_lib"lib/tests/copy_to_directory_actionpkg.bzl�pkg"�
�
pkg*
nameA unique name for this target. 	
out 
srcs2[]"E
pkg>@@aspect_bazel_lib//lib/tests/copy_to_directory_action:pkg.bzl
"",
*
nameA unique name for this target. 
	
out 

srcs2[]�
//lib:copy_to_directory.bzlr�
.
aspect_bazel_liblibcopy_to_directory.bzlB
copy_to_directory_actioncopy_to_directory_action
7O
Q�
3//lib/tests/copy_to_directory_action:other_info.bzlr|
F
aspect_bazel_lib"lib/tests/copy_to_directory_actionother_info.bzl$
	OtherInfo	OtherInfo
OX
Z@
Test rule to create a pkg with DefaultInfo and OtherInfo files
�
<
aspect_bazel_liblib/tests/stampingstamp_aware_rule.bzl�my_stamp_aware_rule"�
�
my_stamp_aware_rule*
nameA unique name for this target. 	
out �
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.
2-1"R
my_stamp_aware_rule;@@aspect_bazel_lib//lib/tests/stamping:stamp_aware_rule.bzl
,
*
nameA unique name for this target. 
	
out �
�
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.
2-1�
//lib:stamping.bzlr�
%
aspect_bazel_liblibstamping.bzl(
STAMP_ATTRSSTAMP_ATTRS
.9(
maybe_stampmaybe_stamp
=H
J4Example of a rule that can version-stamp its outputs�
3
aspect_bazel_lib	lib/testsgenerate_outputs.bzl�generate_outputs"�
�
generate_outputs*
nameA unique name for this target. 
output_contents2[]
output_files2[]
output_group2"""F
generate_outputs2@@aspect_bazel_lib//lib/tests:generate_outputs.bzl
,
*
nameA unique name for this target. 

output_contents2[]

output_files2[]

output_group2""EA simple rule that generates provides a DefaultOutput with some files�
+
aspect_bazel_liblibcopy_directory.bzl�copy_directory�Copies a directory to another location.

This rule uses a Bash command on Linux/macOS/non-Windows, and a cmd.exe command on Windows (no Bash is required).

If using this rule with source directories, it is recommended that you use the
`--host_jvm_args=-DBAZEL_TRACK_SOURCE_DIRECTORIES=1` startup option so that changes
to files within source directories are detected. See
https://github.com/bazelbuild/bazel/commit/c64421bc35214f0414e4f4226cc953e8c55fa0d2
for more context.
"�
�
copy_directory�Copies a directory to another location.

This rule uses a Bash command on Linux/macOS/non-Windows, and a cmd.exe command on Windows (no Bash is required).

If using this rule with source directories, it is recommended that you use the
`--host_jvm_args=-DBAZEL_TRACK_SOURCE_DIRECTORIES=1` startup option so that changes
to files within source directories are detected. See
https://github.com/bazelbuild/bazel/commit/c64421bc35214f0414e4f4226cc953e8c55fa0d2
for more context.
*
nameA unique name for this target. 	
out 	
src 
qq,
*
nameA unique name for this target. 
	
out 
	
src �copy_directory_action�Helper function that creates an action to copy a directory from src to dst.

This helper is used by copy_directory. It is exposed as a public API so it can be used within
other rule implementations.
*�
�
copy_directory_action
ctxThe rule context. (V
srcKThe directory to make a copy of. Can be a source directory or TreeArtifact. (<
dst1The directory to copy to. Must be a TreeArtifact. (+

is_windowsDeprecated and unusedNone(�Helper function that creates an action to copy a directory from src to dst.

This helper is used by copy_directory. It is exposed as a public API so it can be used within
other rule implementations.
2K
copy_directory_action2@@aspect_bazel_lib//lib/private:copy_directory.bzl
AA�
 //lib/private:copy_directory.bzlr�
3
aspect_bazel_liblib/privatecopy_directory.bzl/
copy_directory_copy_directory
		=
copy_directory_action_copy_directory_action



�A rule that copies a directory to another place.

The rule uses a Bash command on Linux/macOS/non-Windows, and a cmd.exe command
on Windows (no Bash is required).
�
&
aspect_bazel_liblibcopy_file.bzl�	copy_file�Copies a file or directory to another location.

`native.genrule()` is sometimes used to copy files (often wishing to rename them). The 'copy_file' rule does this with a simpler interface than genrule.

This rule uses a Bash command on Linux/macOS/non-Windows, and a cmd.exe command on Windows (no Bash is required).

If using this rule with source directories, it is recommended that you use the
`--host_jvm_args=-DBAZEL_TRACK_SOURCE_DIRECTORIES=1` startup option so that changes
to files within source directories are detected. See
https://github.com/bazelbuild/bazel/commit/c64421bc35214f0414e4f4226cc953e8c55fa0d2
for more context.
*�
�
	copy_file
nameName of the rule. (h
src]A Label. The file to make a copy of.
(Can also be the label of a rule that generates a file.) (=
out2Path of the output file, relative to this package. (�
is_executable�A boolean. Whether to make the output file executable. When
True, the rule's output can be executed using `bazel run` and can be
in the srcs of binary and test rules that require executable sources.
WARNING: If `allow_symlink` is True, `src` must also be executable.False(�
allow_symlink�A boolean. Whether to allow symlinking instead of copying.
When False, the output is always a hard copy. When True, the output
*can* be a symlink, but there is no guarantee that a symlink is
created (i.e., at the time of writing, we don't create symlinks on
Windows). Set this to True if you need fast copying and your tools can
handle symlinks (which most UNIX tools can).False(8
kwargs,further keyword arguments, e.g. `visibility`(�Copies a file or directory to another location.

`native.genrule()` is sometimes used to copy files (often wishing to rename them). The 'copy_file' rule does this with a simpler interface than genrule.

This rule uses a Bash command on Linux/macOS/non-Windows, and a cmd.exe command on Windows (no Bash is required).

If using this rule with source directories, it is recommended that you use the
`--host_jvm_args=-DBAZEL_TRACK_SOURCE_DIRECTORIES=1` startup option so that changes
to files within source directories are detected. See
https://github.com/bazelbuild/bazel/commit/c64421bc35214f0414e4f4226cc953e8c55fa0d2
for more context.
2:
	copy_file-@@aspect_bazel_lib//lib/private:copy_file.bzl
��*copy_file_impl2copy_file_impl�copy_file_action�Helper function that creates an action to copy a file from src to dst.

If src is a TreeArtifact, dir_path must be specified as the path within
the TreeArtifact to the file to copy.

This helper is used by copy_file. It is exposed as a public API so it can be used within
other rule implementations.
*�
�
copy_file_action
ctxThe rule context. (P
srcEThe source file to copy or TreeArtifact to copy a single file out of. ( 
dstThe destination file. (c
dir_pathOIf src is a TreeArtifact, the path within the TreeArtifact to the file to copy.None(+

is_windowsDeprecated and unusedNone(�Helper function that creates an action to copy a file from src to dst.

If src is a TreeArtifact, dir_path must be specified as the path within
the TreeArtifact to the file to copy.

This helper is used by copy_file. It is exposed as a public API so it can be used within
other rule implementations.
2A
copy_file_action-@@aspect_bazel_lib//lib/private:copy_file.bzl
WW�
//lib/private:copy_file.bzlr�
.
aspect_bazel_liblib/privatecopy_file.bzl%
	copy_file
_copy_file
""3
copy_file_action_copy_file_action
##
 $�A rule that copies a file to another place.

native.genrule() is sometimes used to copy files (often wishing to rename them).
The 'copy_file' rule does this with a simpler interface than genrule.

The rule uses a Bash command on Linux/macOS/non-Windows, and a cmd.exe command
on Windows (no Bash is required).

This fork of bazel-skylib's copy_file adds DirectoryPathInfo support and allows multiple
copy_file in the same package.
�
(
aspect_bazel_liblibcopy_to_bin.bzl�copy_to_bin�Copies a source file to output tree at the same workspace-relative path.

e.g. `<execroot>/path/to/file -> <execroot>/bazel-out/<platform>/bin/path/to/file`

If a file passed in is already in the output tree is then it is added directly to the
DefaultInfo provided by the rule without a copy.

This is useful to populate the output folder with all files needed at runtime, even
those which aren't outputs of a Bazel rule.

This way you can run a binary in the output folder (execroot or runfiles_root)
without that program needing to rely on a runfiles helper library or be aware that
files are divided between the source tree and the output tree.
"�
�
copy_to_bin�Copies a source file to output tree at the same workspace-relative path.

e.g. `<execroot>/path/to/file -> <execroot>/bazel-out/<platform>/bin/path/to/file`

If a file passed in is already in the output tree is then it is added directly to the
DefaultInfo provided by the rule without a copy.

This is useful to populate the output folder with all files needed at runtime, even
those which aren't outputs of a Bazel rule.

This way you can run a binary in the output folder (execroot or runfiles_root)
without that program needing to rely on a runfiles helper library or be aware that
files are divided between the source tree and the output tree.
*
nameA unique name for this target. 

srcs 
��,
*
nameA unique name for this target. 


srcs �copy_file_to_bin_action�Helper function that creates an action to copy a file to the output tree.

File are copied to the same workspace-relative path. The resulting files is
returned.

If the file passed in is already in the output tree is then it is returned
without a copy action.
*�
�
copy_file_to_bin_action
ctxThe rule context. (
fileThe file to copy. (+

is_windowsDeprecated and unusedNone(�Helper function that creates an action to copy a file to the output tree.

File are copied to the same workspace-relative path. The resulting files is
returned.

If the file passed in is already in the output tree is then it is returned
without a copy action.
"
A File in the output tree.2J
copy_file_to_bin_action/@@aspect_bazel_lib//lib/private:copy_to_bin.bzl
�copy_files_to_bin_actions�Helper function that creates actions to copy files to the output tree.

Files are copied to the same workspace-relative path. The resulting list of
files is returned.

If a file passed in is already in the output tree is then it is added
directly to the result without a copy action.
*�
�
copy_files_to_bin_actions
ctxThe rule context. ("
filesList of File objects. (+

is_windowsDeprecated and unusedNone(�Helper function that creates actions to copy files to the output tree.

Files are copied to the same workspace-relative path. The resulting list of
files is returned.

If a file passed in is already in the output tree is then it is added
directly to the result without a copy action.
"*
(List of File objects in the output tree.2L
copy_files_to_bin_actions/@@aspect_bazel_lib//lib/private:copy_to_bin.bzl
^^�
//lib/private:copy_to_bin.bzlr�
0
aspect_bazel_liblib/privatecopy_to_bin.bzlA
copy_file_to_bin_action_copy_file_to_bin_action
E
copy_files_to_bin_actions_copy_files_to_bin_actions
)
copy_to_bin_copy_to_bin


�A rule that copies source files to the output tree.

This rule uses a Bash command (diff) on Linux/macOS/non-Windows, and a cmd.exe
command (fc.exe) on Windows (no Bash is required).

Originally authored in rules_nodejs
https://github.com/bazelbuild/rules_nodejs/blob/8b5d27400db51e7027fe95ae413eeabea4856f8e/internal/common/copy_to_bin.bzl
��
.
aspect_bazel_liblibcopy_to_directory.bzl��copy_to_directory"��
�u
copy_to_directory*
nameA unique name for this target. �
allow_overwrites�If True, allow files to be overwritten if the same output file is copied to twice.

If set, then the order of srcs matters as the last copy of a particular file will win.

This setting has no effect on Windows where overwrites are always allowed.2False�
exclude_prefixes�List of path prefixes (with glob support) to exclude from output directory.

        DEPRECATED: use `exclude_srcs_patterns` instead

        Glob patterns `**`, `*` and `?` are supported. See `glob_match` documentation for
        more details on how to use glob patterns:
        https://github.com/aspect-build/bazel-lib/blob/main/docs/glob_match.md.

        Files and directories in srcs are not copied to the output directory if their output
        directory path, after applying `root_paths`, starts with or fully matches one of the
        patterns specified.

        Patterns do not look into files within source directory or generated directory (TreeArtifact)
        targets since matches are performed in Starlark. To use `include_srcs_patterns` on files
        within directories you can use the `make_directory_paths` helper to specify individual files inside
        directories in `srcs`. This restriction may be fixed in a future release by performing matching
        inside the copy action instead of in Starlark.

        Forward slashes (`/`) should be used as path separators.

        Files and directories that do not have matching output directory paths are subject to subsequent
        filters and transformations to determine if they are copied and what their path in the output
        directory will be.

        Filters and transformations are applied in the following order:

1. `include_external_repositories`

2. `include_srcs_packages`

3. `exclude_srcs_packages`

4. `root_paths`

5. `include_srcs_patterns`

6. `exclude_srcs_patterns`

7. `replace_prefixes`

For more information each filters / transformations applied, see
the documentation for the specific filter / transformation attribute.

2[]�
exclude_srcs_packages�List of Bazel packages (with glob support) to exclude from output directory.

        Glob patterns `**`, `*` and `?` are supported. See `glob_match` documentation for
        more details on how to use glob patterns:
        https://github.com/aspect-build/bazel-lib/blob/main/docs/glob_match.md.

        Files and directories in srcs are not copied to the output directory if
        the Bazel package of the file or directory matches one of the patterns specified.

        Forward slashes (`/`) should be used as path separators.

        A `"."` value means exclude srcs that are in the target's package.
        It expands to the target's package path (`ctx.label.package`). This
        will be an empty string `""` if the target is in the root package.

        A `"./**"` value means exclude srcs that are in subpackages of the target's package.
        It expands to the target's package path followed by a slash and a
        globstar (`"{}/**".format(ctx.label.package)`). If the target's package is
        the root package, `"./**"` expands to `["?*", "?*/**"]` instead.

        Files and directories that have do not have matching Bazel packages are subject to subsequent
        filters and transformations to determine if they are copied and what their path in the output
        directory will be.

        Filters and transformations are applied in the following order:

1. `include_external_repositories`

2. `include_srcs_packages`

3. `exclude_srcs_packages`

4. `root_paths`

5. `include_srcs_patterns`

6. `exclude_srcs_patterns`

7. `replace_prefixes`

For more information each filters / transformations applied, see
the documentation for the specific filter / transformation attribute.

2[]�
exclude_srcs_patterns�List of paths (with glob support) to exclude from output directory.

        Glob patterns `**`, `*` and `?` are supported. See `glob_match` documentation for
        more details on how to use glob patterns:
        https://github.com/aspect-build/bazel-lib/blob/main/docs/glob_match.md.

        Files and directories in srcs are not copied to the output directory if their output
        directory path, after applying `root_paths`, matches one of the patterns specified.

        Patterns do not look into files within source directory or generated directory (TreeArtifact)
        targets since matches are performed in Starlark. To use `include_srcs_patterns` on files
        within directories you can use the `make_directory_paths` helper to specify individual files inside
        directories in `srcs`. This restriction may be fixed in a future release by performing matching
        inside the copy action instead of in Starlark.

        Forward slashes (`/`) should be used as path separators.

        Files and directories that do not have matching output directory paths are subject to subsequent
        filters and transformations to determine if they are copied and what their path in the output
        directory will be.

        Filters and transformations are applied in the following order:

1. `include_external_repositories`

2. `include_srcs_packages`

3. `exclude_srcs_packages`

4. `root_paths`

5. `include_srcs_patterns`

6. `exclude_srcs_patterns`

7. `replace_prefixes`

For more information each filters / transformations applied, see
the documentation for the specific filter / transformation attribute.

2[]�
include_external_repositories�List of external repository names (with glob support) to include in the output directory.

        Glob patterns `**`, `*` and `?` are supported. See `glob_match` documentation for
        more details on how to use glob patterns:
        https://github.com/aspect-build/bazel-lib/blob/main/docs/glob_match.md.

        Files from external repositories are only copied into the output directory if
        the external repository they come from matches one of the external repository patterns
        specified.

        When copied from an external repository, the file path in the output directory
        defaults to the file's path within the external repository. The external repository
        name is _not_ included in that path.

        For example, the following copies `@external_repo//path/to:file` to
        `path/to/file` within the output directory.

        ```
        copy_to_directory(
            name = "dir",
            include_external_repositories = ["external_*"],
            srcs = ["@external_repo//path/to:file"],
        )
        ```

        Files and directories that come from matching external are subject to subsequent filters and
        transformations to determine if they are copied and what their path in the output
        directory will be. The external repository name of the file or directory from an external
        repository is not included in the output directory path and is considered in subsequent
        filters and transformations.

        Filters and transformations are applied in the following order:

1. `include_external_repositories`

2. `include_srcs_packages`

3. `exclude_srcs_packages`

4. `root_paths`

5. `include_srcs_patterns`

6. `exclude_srcs_patterns`

7. `replace_prefixes`

For more information each filters / transformations applied, see
the documentation for the specific filter / transformation attribute.

2[]�
include_srcs_packages�List of Bazel packages (with glob support) to include in output directory.

        Glob patterns `**`, `*` and `?` are supported. See `glob_match` documentation for
        more details on how to use glob patterns:
        https://github.com/aspect-build/bazel-lib/blob/main/docs/glob_match.md.

        Files and directories in srcs are only copied to the output directory if
        the Bazel package of the file or directory matches one of the patterns specified.

        Forward slashes (`/`) should be used as path separators.

        A `"."` value means include srcs that are in the target's package.
        It expands to the target's package path (`ctx.label.package`). This
        will be an empty string `""` if the target is in the root package.

        A `"./**"` value means include srcs that are in subpackages of the target's package.
        It expands to the target's package path followed by a slash and a
        globstar (`"{}/**".format(ctx.label.package)`). If the target's package is
        the root package, `"./**"` expands to `["?*", "?*/**"]` instead.

        Defaults to `["**"]` which includes sources from all packages.

        Files and directories that have matching Bazel packages are subject to subsequent filters and
        transformations to determine if they are copied and what their path in the output
        directory will be.

        Filters and transformations are applied in the following order:

1. `include_external_repositories`

2. `include_srcs_packages`

3. `exclude_srcs_packages`

4. `root_paths`

5. `include_srcs_patterns`

6. `exclude_srcs_patterns`

7. `replace_prefixes`

For more information each filters / transformations applied, see
the documentation for the specific filter / transformation attribute.

2["**"]�
include_srcs_patterns�List of paths (with glob support) to include in output directory.

        Glob patterns `**`, `*` and `?` are supported. See `glob_match` documentation for
        more details on how to use glob patterns:
        https://github.com/aspect-build/bazel-lib/blob/main/docs/glob_match.md.

        Files and directories in srcs are only copied to the output directory if their output
        directory path, after applying `root_paths`, matches one of the patterns specified.

        Patterns do not look into files within source directory or generated directory (TreeArtifact)
        targets since matches are performed in Starlark. To use `include_srcs_patterns` on files
        within directories you can use the `make_directory_paths` helper to specify individual files inside
        directories in `srcs`. This restriction may be fixed in a future release by performing matching
        inside the copy action instead of in Starlark.

        Forward slashes (`/`) should be used as path separators.

        Defaults to ["**"] which includes all sources.

        Files and directories that have matching output directory paths are subject to subsequent
        filters and transformations to determine if they are copied and what their path in the output
        directory will be.

        Filters and transformations are applied in the following order:

1. `include_external_repositories`

2. `include_srcs_packages`

3. `exclude_srcs_packages`

4. `root_paths`

5. `include_srcs_patterns`

6. `exclude_srcs_patterns`

7. `replace_prefixes`

For more information each filters / transformations applied, see
the documentation for the specific filter / transformation attribute.

2["**"]r
outePath of the output directory, relative to this package.

If not set, the name of the target is used.
2""�
replace_prefixes�Map of paths prefixes (with glob support) to replace in the output directory path when copying files.

        Glob patterns `**`, `*` and `?` are supported but the pattern must not end with a `**` glob
        expression. See `glob_match` documentation for more details on how to use glob patterns:
        https://github.com/aspect-build/bazel-lib/blob/main/docs/glob_match.md.

        If the output directory path for a file or directory starts with or fully matches a
        a key in the dict then the matching portion of the output directory path is
        replaced with the dict value for that key. The final path segment
        matched can be a partial match of that segment and only the matching portion will
        be replaced. If there are multiple keys that match, the longest match wins.

        Patterns do not look into files within source directory or generated directory (TreeArtifact)
        targets since matches are performed in Starlark. To use `replace_prefixes` on files
        within directories you can use the `make_directory_paths` helper to specify individual files inside
        directories in `srcs`. This restriction may be fixed in a future release by performing matching
        inside the copy action instead of in Starlark.

        Forward slashes (`/`) should be used as path separators. 

        Replace prefix transformation are the final step in the list of filters and transformations.
        The final output path of a file or directory being copied into the output directory
        is determined at this step.

        Filters and transformations are applied in the following order:

1. `include_external_repositories`

2. `include_srcs_packages`

3. `exclude_srcs_packages`

4. `root_paths`

5. `include_srcs_patterns`

6. `exclude_srcs_patterns`

7. `replace_prefixes`

For more information each filters / transformations applied, see
the documentation for the specific filter / transformation attribute.


2{}�

root_paths�List of paths (with glob support) that are roots in the output directory.

        Glob patterns `**`, `*` and `?` are supported. See `glob_match` documentation for
        more details on how to use glob patterns:
        https://github.com/aspect-build/bazel-lib/blob/main/docs/glob_match.md.

        If any parent directory of a file or directory being copied matches one of the root paths
        patterns specified, the output directory path will be the path relative to the root path
        instead of the path relative to the file's or directory's workspace. If there are multiple
        root paths that match, the longest match wins.

        Matching is done on the parent directory of the output file path so a trailing '**' glob patterm
        will match only up to the last path segment of the dirname and will not include the basename.
        Only complete path segments are matched. Partial matches on the last segment of the root path
        are ignored.

        Forward slashes (`/`) should be used as path separators.

        A "." value expands to the target's package path (`ctx.label.package`).

        Defaults to ["."] which results in the output directory path of files in the
        target's package and and sub-packages are relative to the target's package and
        files outside of that retain their full workspace relative paths.

        Filters and transformations are applied in the following order:

1. `include_external_repositories`

2. `include_srcs_packages`

3. `exclude_srcs_packages`

4. `root_paths`

5. `include_srcs_patterns`

6. `exclude_srcs_patterns`

7. `replace_prefixes`

For more information each filters / transformations applied, see
the documentation for the specific filter / transformation attribute.

2["."]s
srcseFiles and/or directories or targets that provide DirectoryPathInfo to copy
into the output directory.2[]"B
copy_to_directory-@@aspect_bazel_lib//lib:copy_to_directory.bzl
,
*
nameA unique name for this target. �
�
allow_overwrites�If True, allow files to be overwritten if the same output file is copied to twice.

If set, then the order of srcs matters as the last copy of a particular file will win.

This setting has no effect on Windows where overwrites are always allowed.2False�
�
exclude_prefixes�List of path prefixes (with glob support) to exclude from output directory.

        DEPRECATED: use `exclude_srcs_patterns` instead

        Glob patterns `**`, `*` and `?` are supported. See `glob_match` documentation for
        more details on how to use glob patterns:
        https://github.com/aspect-build/bazel-lib/blob/main/docs/glob_match.md.

        Files and directories in srcs are not copied to the output directory if their output
        directory path, after applying `root_paths`, starts with or fully matches one of the
        patterns specified.

        Patterns do not look into files within source directory or generated directory (TreeArtifact)
        targets since matches are performed in Starlark. To use `include_srcs_patterns` on files
        within directories you can use the `make_directory_paths` helper to specify individual files inside
        directories in `srcs`. This restriction may be fixed in a future release by performing matching
        inside the copy action instead of in Starlark.

        Forward slashes (`/`) should be used as path separators.

        Files and directories that do not have matching output directory paths are subject to subsequent
        filters and transformations to determine if they are copied and what their path in the output
        directory will be.

        Filters and transformations are applied in the following order:

1. `include_external_repositories`

2. `include_srcs_packages`

3. `exclude_srcs_packages`

4. `root_paths`

5. `include_srcs_patterns`

6. `exclude_srcs_patterns`

7. `replace_prefixes`

For more information each filters / transformations applied, see
the documentation for the specific filter / transformation attribute.

2[]�
�
exclude_srcs_packages�List of Bazel packages (with glob support) to exclude from output directory.

        Glob patterns `**`, `*` and `?` are supported. See `glob_match` documentation for
        more details on how to use glob patterns:
        https://github.com/aspect-build/bazel-lib/blob/main/docs/glob_match.md.

        Files and directories in srcs are not copied to the output directory if
        the Bazel package of the file or directory matches one of the patterns specified.

        Forward slashes (`/`) should be used as path separators.

        A `"."` value means exclude srcs that are in the target's package.
        It expands to the target's package path (`ctx.label.package`). This
        will be an empty string `""` if the target is in the root package.

        A `"./**"` value means exclude srcs that are in subpackages of the target's package.
        It expands to the target's package path followed by a slash and a
        globstar (`"{}/**".format(ctx.label.package)`). If the target's package is
        the root package, `"./**"` expands to `["?*", "?*/**"]` instead.

        Files and directories that have do not have matching Bazel packages are subject to subsequent
        filters and transformations to determine if they are copied and what their path in the output
        directory will be.

        Filters and transformations are applied in the following order:

1. `include_external_repositories`

2. `include_srcs_packages`

3. `exclude_srcs_packages`

4. `root_paths`

5. `include_srcs_patterns`

6. `exclude_srcs_patterns`

7. `replace_prefixes`

For more information each filters / transformations applied, see
the documentation for the specific filter / transformation attribute.

2[]�
�
exclude_srcs_patterns�List of paths (with glob support) to exclude from output directory.

        Glob patterns `**`, `*` and `?` are supported. See `glob_match` documentation for
        more details on how to use glob patterns:
        https://github.com/aspect-build/bazel-lib/blob/main/docs/glob_match.md.

        Files and directories in srcs are not copied to the output directory if their output
        directory path, after applying `root_paths`, matches one of the patterns specified.

        Patterns do not look into files within source directory or generated directory (TreeArtifact)
        targets since matches are performed in Starlark. To use `include_srcs_patterns` on files
        within directories you can use the `make_directory_paths` helper to specify individual files inside
        directories in `srcs`. This restriction may be fixed in a future release by performing matching
        inside the copy action instead of in Starlark.

        Forward slashes (`/`) should be used as path separators.

        Files and directories that do not have matching output directory paths are subject to subsequent
        filters and transformations to determine if they are copied and what their path in the output
        directory will be.

        Filters and transformations are applied in the following order:

1. `include_external_repositories`

2. `include_srcs_packages`

3. `exclude_srcs_packages`

4. `root_paths`

5. `include_srcs_patterns`

6. `exclude_srcs_patterns`

7. `replace_prefixes`

For more information each filters / transformations applied, see
the documentation for the specific filter / transformation attribute.

2[]�
�
include_external_repositories�List of external repository names (with glob support) to include in the output directory.

        Glob patterns `**`, `*` and `?` are supported. See `glob_match` documentation for
        more details on how to use glob patterns:
        https://github.com/aspect-build/bazel-lib/blob/main/docs/glob_match.md.

        Files from external repositories are only copied into the output directory if
        the external repository they come from matches one of the external repository patterns
        specified.

        When copied from an external repository, the file path in the output directory
        defaults to the file's path within the external repository. The external repository
        name is _not_ included in that path.

        For example, the following copies `@external_repo//path/to:file` to
        `path/to/file` within the output directory.

        ```
        copy_to_directory(
            name = "dir",
            include_external_repositories = ["external_*"],
            srcs = ["@external_repo//path/to:file"],
        )
        ```

        Files and directories that come from matching external are subject to subsequent filters and
        transformations to determine if they are copied and what their path in the output
        directory will be. The external repository name of the file or directory from an external
        repository is not included in the output directory path and is considered in subsequent
        filters and transformations.

        Filters and transformations are applied in the following order:

1. `include_external_repositories`

2. `include_srcs_packages`

3. `exclude_srcs_packages`

4. `root_paths`

5. `include_srcs_patterns`

6. `exclude_srcs_patterns`

7. `replace_prefixes`

For more information each filters / transformations applied, see
the documentation for the specific filter / transformation attribute.

2[]�
�
include_srcs_packages�List of Bazel packages (with glob support) to include in output directory.

        Glob patterns `**`, `*` and `?` are supported. See `glob_match` documentation for
        more details on how to use glob patterns:
        https://github.com/aspect-build/bazel-lib/blob/main/docs/glob_match.md.

        Files and directories in srcs are only copied to the output directory if
        the Bazel package of the file or directory matches one of the patterns specified.

        Forward slashes (`/`) should be used as path separators.

        A `"."` value means include srcs that are in the target's package.
        It expands to the target's package path (`ctx.label.package`). This
        will be an empty string `""` if the target is in the root package.

        A `"./**"` value means include srcs that are in subpackages of the target's package.
        It expands to the target's package path followed by a slash and a
        globstar (`"{}/**".format(ctx.label.package)`). If the target's package is
        the root package, `"./**"` expands to `["?*", "?*/**"]` instead.

        Defaults to `["**"]` which includes sources from all packages.

        Files and directories that have matching Bazel packages are subject to subsequent filters and
        transformations to determine if they are copied and what their path in the output
        directory will be.

        Filters and transformations are applied in the following order:

1. `include_external_repositories`

2. `include_srcs_packages`

3. `exclude_srcs_packages`

4. `root_paths`

5. `include_srcs_patterns`

6. `exclude_srcs_patterns`

7. `replace_prefixes`

For more information each filters / transformations applied, see
the documentation for the specific filter / transformation attribute.

2["**"]�
�
include_srcs_patterns�List of paths (with glob support) to include in output directory.

        Glob patterns `**`, `*` and `?` are supported. See `glob_match` documentation for
        more details on how to use glob patterns:
        https://github.com/aspect-build/bazel-lib/blob/main/docs/glob_match.md.

        Files and directories in srcs are only copied to the output directory if their output
        directory path, after applying `root_paths`, matches one of the patterns specified.

        Patterns do not look into files within source directory or generated directory (TreeArtifact)
        targets since matches are performed in Starlark. To use `include_srcs_patterns` on files
        within directories you can use the `make_directory_paths` helper to specify individual files inside
        directories in `srcs`. This restriction may be fixed in a future release by performing matching
        inside the copy action instead of in Starlark.

        Forward slashes (`/`) should be used as path separators.

        Defaults to ["**"] which includes all sources.

        Files and directories that have matching output directory paths are subject to subsequent
        filters and transformations to determine if they are copied and what their path in the output
        directory will be.

        Filters and transformations are applied in the following order:

1. `include_external_repositories`

2. `include_srcs_packages`

3. `exclude_srcs_packages`

4. `root_paths`

5. `include_srcs_patterns`

6. `exclude_srcs_patterns`

7. `replace_prefixes`

For more information each filters / transformations applied, see
the documentation for the specific filter / transformation attribute.

2["**"]t
r
outePath of the output directory, relative to this package.

If not set, the name of the target is used.
2""�
�
replace_prefixes�Map of paths prefixes (with glob support) to replace in the output directory path when copying files.

        Glob patterns `**`, `*` and `?` are supported but the pattern must not end with a `**` glob
        expression. See `glob_match` documentation for more details on how to use glob patterns:
        https://github.com/aspect-build/bazel-lib/blob/main/docs/glob_match.md.

        If the output directory path for a file or directory starts with or fully matches a
        a key in the dict then the matching portion of the output directory path is
        replaced with the dict value for that key. The final path segment
        matched can be a partial match of that segment and only the matching portion will
        be replaced. If there are multiple keys that match, the longest match wins.

        Patterns do not look into files within source directory or generated directory (TreeArtifact)
        targets since matches are performed in Starlark. To use `replace_prefixes` on files
        within directories you can use the `make_directory_paths` helper to specify individual files inside
        directories in `srcs`. This restriction may be fixed in a future release by performing matching
        inside the copy action instead of in Starlark.

        Forward slashes (`/`) should be used as path separators. 

        Replace prefix transformation are the final step in the list of filters and transformations.
        The final output path of a file or directory being copied into the output directory
        is determined at this step.

        Filters and transformations are applied in the following order:

1. `include_external_repositories`

2. `include_srcs_packages`

3. `exclude_srcs_packages`

4. `root_paths`

5. `include_srcs_patterns`

6. `exclude_srcs_patterns`

7. `replace_prefixes`

For more information each filters / transformations applied, see
the documentation for the specific filter / transformation attribute.


2{}�
�

root_paths�List of paths (with glob support) that are roots in the output directory.

        Glob patterns `**`, `*` and `?` are supported. See `glob_match` documentation for
        more details on how to use glob patterns:
        https://github.com/aspect-build/bazel-lib/blob/main/docs/glob_match.md.

        If any parent directory of a file or directory being copied matches one of the root paths
        patterns specified, the output directory path will be the path relative to the root path
        instead of the path relative to the file's or directory's workspace. If there are multiple
        root paths that match, the longest match wins.

        Matching is done on the parent directory of the output file path so a trailing '**' glob patterm
        will match only up to the last path segment of the dirname and will not include the basename.
        Only complete path segments are matched. Partial matches on the last segment of the root path
        are ignored.

        Forward slashes (`/`) should be used as path separators.

        A "." value expands to the target's package path (`ctx.label.package`).

        Defaults to ["."] which results in the output directory path of files in the
        target's package and and sub-packages are relative to the target's package and
        files outside of that retain their full workspace relative paths.

        Filters and transformations are applied in the following order:

1. `include_external_repositories`

2. `include_srcs_packages`

3. `exclude_srcs_packages`

4. `root_paths`

5. `include_srcs_patterns`

6. `exclude_srcs_patterns`

7. `replace_prefixes`

For more information each filters / transformations applied, see
the documentation for the specific filter / transformation attribute.

2["."]u
s
srcseFiles and/or directories or targets that provide DirectoryPathInfo to copy
into the output directory.2[]�copy_to_directory_action�Helper function to copy files to a directory.

This helper is used by copy_to_directory. It is exposed as a public API so it can be used within
other rule implementations where additional_files can also be passed in.
*�
�
copy_to_directory_action
ctxThe rule context. (q
srcseFiles and/or directories or targets that provide DirectoryPathInfo to copy into the output directory. (<
dst1The directory to copy to. Must be a TreeArtifact. (�
additional_filesgList or depset of additional files to copy that are not in the DefaultInfo or DirectoryPathInfo of srcs[](�

root_pathsqList of paths that are roots in the output directory.

See copy_to_directory rule documentation for more details.["."](�
include_external_repositories�List of external repository names to include in the output directory.

See copy_to_directory rule documentation for more details.[](�
include_srcs_packagesrList of Bazel packages to include in output directory.

See copy_to_directory rule documentation for more details.["**"](�
exclude_srcs_packages�List of Bazel packages (with glob support) to exclude from output directory.

See copy_to_directory rule documentation for more details.[](�
include_srcs_patterns}List of paths (with glob support) to include in output directory.

See copy_to_directory rule documentation for more details.["**"](�
exclude_srcs_patternsList of paths (with glob support) to exclude from output directory.

See copy_to_directory rule documentation for more details.[](Q
exclude_prefixes7List of path prefixes to exclude from output directory.[](�
replace_prefixes�Map of paths prefixes to replace in the output directory path when copying files.

See copy_to_directory rule documentation for more details.{}(�
allow_overwrites�If True, allow files to be overwritten if the same output file is copied to twice.

See copy_to_directory rule documentation for more details.False(+

is_windowsDeprecated and unusedNone(�Helper function to copy files to a directory.

This helper is used by copy_to_directory. It is exposed as a public API so it can be used within
other rule implementations where additional_files can also be passed in.
2Q
copy_to_directory_action5@@aspect_bazel_lib//lib/private:copy_to_directory.bzl
���
#//lib/private:copy_to_directory.bzlr�
6
aspect_bazel_liblib/privatecopy_to_directory.bzlC
copy_to_directory_action_copy_to_directory_action
		=
copy_to_directory_lib_copy_to_directory_lib



�Copies files and directories to an output directory.

Files and directories can be arranged as needed in the output directory using
the `root_paths`, `include_srcs_patters`, `exclude_srcs_patters` and `replace_prefixes` attributes.
�(
+
aspect_bazel_liblibdirectory_path.bzl�directory_path}Provide DirectoryPathInfo to reference some path within a directory.

Otherwise there is no way to give a Bazel label for it."�
�
directory_path}Provide DirectoryPathInfo to reference some path within a directory.

Otherwise there is no way to give a Bazel label for it.*
nameA unique name for this target. ?
	directory.a TreeArtifact (ctx.actions.declare_directory) *
pathpath relative to the directory "<
directory_path*@@aspect_bazel_lib//lib:directory_path.bzl
,
*
nameA unique name for this target. A
?
	directory.a TreeArtifact (ctx.actions.declare_directory) ,
*
pathpath relative to the directory �make_directory_path�Helper function to generate a directory_path target and return its label.

Provide DirectoryPathInfo to reference some path within a directory.

Otherwise there is no way to give a Bazel label for it."�
�
make_directory_path�Helper function to generate a directory_path target and return its label.

Provide DirectoryPathInfo to reference some path within a directory.

Otherwise there is no way to give a Bazel label for it.*
nameA unique name for this target. ?
	directory.a TreeArtifact (ctx.actions.declare_directory) *
pathpath relative to the directory "<
directory_path*@@aspect_bazel_lib//lib:directory_path.bzl
((,
*
nameA unique name for this target. A
?
	directory.a TreeArtifact (ctx.actions.declare_directory) ,
*
pathpath relative to the directory �make_directory_paths�Helper function to convert a dict of directory to path mappings to directory_path targets and labels.

For example,

```
make_directory_paths("my_name", {
    "//directory/artifact:target_1": "file/path",
    "//directory/artifact:target_2": ["file/path1", "file/path2"],
})
```

generates the targets,

```
directory_path(
    name = "my_name_0",
    directory = "//directory/artifact:target_1",
    path = "file/path"
)

directory_path(
    name = "my_name_1",
    directory = "//directory/artifact:target_2",
    path = "file/path1"
)

directory_path(
    name = "my_name_2",
    directory = "//directory/artifact:target_2",
    path = "file/path2"
)
```

and the list of targets is returned,

```
[
    "my_name_0",
    "my_name_1",
    "my_name_2",
]
```
b�
�	
�	
make_directory_paths�
nametThe target name to use for the generated targets & labels.

The names are generated as zero-indexed `name + "_" + i` (I
dict=The dictionary of directory keys to path or path list values. (B
kwargs6additional parameters to pass to each generated target(�Helper function to convert a dict of directory to path mappings to directory_path targets and labels.

For example,

```
make_directory_paths("my_name", {
    "//directory/artifact:target_1": "file/path",
    "//directory/artifact:target_2": ["file/path1", "file/path2"],
})
```

generates the targets,

```
directory_path(
    name = "my_name_0",
    directory = "//directory/artifact:target_1",
    path = "file/path"
)

directory_path(
    name = "my_name_1",
    directory = "//directory/artifact:target_2",
    path = "file/path1"
)

directory_path(
    name = "my_name_2",
    directory = "//directory/artifact:target_2",
    path = "file/path2"
)
```

and the list of targets is returned,

```
[
    "my_name_0",
    "my_name_1",
    "my_name_2",
]
```
"L
JThe label of the generated `directory_path` targets named `name + "_" + i`2J
make_directory_paths2@@aspect_bazel_lib//lib/private:directory_path.bzl
<<"make_directory_path*make_directory_path�
�
make_directory_path�Helper function to generate a directory_path target and return its label.

Provide DirectoryPathInfo to reference some path within a directory.

Otherwise there is no way to give a Bazel label for it.*
nameA unique name for this target. ?
	directory.a TreeArtifact (ctx.actions.declare_directory) *
pathpath relative to the directory "<
directory_path*@@aspect_bazel_lib//lib:directory_path.bzl,
*
nameA unique name for this target. A
?
	directory.a TreeArtifact (ctx.actions.declare_directory) ,
*
pathpath relative to the directory �DirectoryPathInfoRJoins a label pointing to a TreeArtifact with a path nested within that directory.2�
�
DirectoryPathInfoRJoins a label pointing to a TreeArtifact with a path nested within that directory.;
	directory.a TreeArtifact (ctx.actions.declare_directory)&
pathpath relative to the directory"?
DirectoryPathInfo*@@aspect_bazel_lib//lib:directory_path.bzl
=
;
	directory.a TreeArtifact (ctx.actions.declare_directory)(
&
pathpath relative to the directory�
 //lib/private:directory_path.bzlr�
3
aspect_bazel_liblib/privatedirectory_path.bzl5
DirectoryPathInfo_DirectoryPathInfo
/
directory_path_directory_path
9
make_directory_path_make_directory_path
		;
make_directory_paths_make_directory_paths



wRule and corresponding provider that joins a label pointing to a TreeArtifact
with a path nested within that directory
�
!
aspect_bazel_liblibdocs.bzl�stardoc_with_diff_test�Creates a stardoc target that can be auto-detected by update_docs to write the generated doc to the source tree and test that it's up to date.

This is helpful for minimizing boilerplate in repos wih lots of stardoc targets.
*�
�
stardoc_with_diff_test�
name�the name of the stardoc file to be written to the current source directory (.md will be appended to the name). Call bazel run on this target to update the file. (]
bzl_library_targetCthe label of the `bzl_library` target to generate documentation for (d
kwargsXadditional attributes passed to the stardoc() rule, such as for overriding the templates(�Creates a stardoc target that can be auto-detected by update_docs to write the generated doc to the source tree and test that it's up to date.

This is helpful for minimizing boilerplate in repos wih lots of stardoc targets.
2B
stardoc_with_diff_test(@@aspect_bazel_lib//lib/private:docs.bzl
*_stardoc2_stardoc�update_docs�Stamps an executable run for writing all stardocs declared with stardoc_with_diff_test to the source tree.

This is to be used in tandem with `stardoc_with_diff_test()` to produce a convenient workflow
for generating, testing, and updating all doc files as follows:

``` bash
bazel build //{docs_folder}/... && bazel test //{docs_folder}/... && bazel run //{docs_folder}:update
```

eg.

``` bash
bazel build //docs/... && bazel test //docs/... && bazel run //docs:update
```
*�
�
update_docs1
namethe name of executable target"update"(�Stamps an executable run for writing all stardocs declared with stardoc_with_diff_test to the source tree.

This is to be used in tandem with `stardoc_with_diff_test()` to produce a convenient workflow
for generating, testing, and updating all doc files as follows:

``` bash
bazel build //{docs_folder}/... && bazel test //{docs_folder}/... && bazel run //{docs_folder}:update
```

eg.

``` bash
bazel build //docs/... && bazel test //docs/... && bazel run //docs:update
```
27
update_docs(@@aspect_bazel_lib//lib/private:docs.bzl
2write_source_files�
//lib/private:docs.bzlr�
)
aspect_bazel_liblib/privatedocs.bzl?
stardoc_with_diff_test_stardoc_with_diff_test
)
update_docs_update_docs

Public API for docs helpers�?
-
aspect_bazel_liblibexpand_make_vars.bzl�expand_template�Template expansion

This performs a simple search over the template file for the keys in substitutions,
and replaces them with the corresponding values.

Values may also use location templates as documented in
[expand_locations](https://github.com/aspect-build/bazel-lib/blob/main/docs/expand_make_vars.md#expand_locations)
as well as [configuration variables](https://docs.bazel.build/versions/main/skylark/lib/ctx.html#var)
such as `$(BINDIR)`, `$(TARGET_CPU)`, and `$(COMPILATION_MODE)` as documented in
[expand_variables](https://github.com/aspect-build/bazel-lib/blob/main/docs/expand_make_vars.md#expand_variables).
"�

�
expand_template�Template expansion

This performs a simple search over the template file for the keys in substitutions,
and replaces them with the corresponding values.

Values may also use location templates as documented in
[expand_locations](https://github.com/aspect-build/bazel-lib/blob/main/docs/expand_make_vars.md#expand_locations)
as well as [configuration variables](https://docs.bazel.build/versions/main/skylark/lib/ctx.html#var)
such as `$(BINDIR)`, `$(TARGET_CPU)`, and `$(COMPILATION_MODE)` as documented in
[expand_variables](https://github.com/aspect-build/bazel-lib/blob/main/docs/expand_make_vars.md#expand_variables).
*
nameA unique name for this target. @
data2List of targets for additional lookup information.2[]H
is_executable.Whether to mark the output file as executable.2False,
out!Where to write the expanded file. 9
substitutions$Mapping of strings to substitutions.
 ,
templateThe template file to expand. "?
expand_template,@@aspect_bazel_lib//lib:expand_make_vars.bzl
;;,
*
nameA unique name for this target. B
@
data2List of targets for additional lookup information.2[]J
H
is_executable.Whether to mark the output file as executable.2False.
,
out!Where to write the expanded file. ;
9
substitutions$Mapping of strings to substitutions.
 .
,
templateThe template file to expand. �expand_locations�Expand location templates.

Expands all `$(execpath ...)`, `$(rootpath ...)` and deprecated `$(location ...)` templates in the
given string by replacing with the expanded path. Expansion only works for labels that point to direct dependencies
of this rule or that are explicitly listed in the optional argument targets.

See https://docs.bazel.build/versions/main/be/make-variables.html#predefined_label_variables.

Use `$(rootpath)` and `$(rootpaths)` to expand labels to the runfiles path that a built binary can use
to find its dependencies. This path is of the format:
- `./file`
- `path/to/file`
- `../external_repo/path/to/file`

Use `$(execpath)` and `$(execpaths)` to expand labels to the execroot (where Bazel runs build actions).
This is of the format:
- `./file`
- `path/to/file`
- `external/external_repo/path/to/file`
- `<bin_dir>/path/to/file`
- `<bin_dir>/external/external_repo/path/to/file`

The deprecated `$(location)` and `$(locations)` expansions returns either the execpath or rootpath depending on the context.
*�

�

expand_locations
ctxcontext ("
inputString to be expanded (C
targets2List of targets for additional lookup information.[](�Expand location templates.

Expands all `$(execpath ...)`, `$(rootpath ...)` and deprecated `$(location ...)` templates in the
given string by replacing with the expanded path. Expansion only works for labels that point to direct dependencies
of this rule or that are explicitly listed in the optional argument targets.

See https://docs.bazel.build/versions/main/be/make-variables.html#predefined_label_variables.

Use `$(rootpath)` and `$(rootpaths)` to expand labels to the runfiles path that a built binary can use
to find its dependencies. This path is of the format:
- `./file`
- `path/to/file`
- `../external_repo/path/to/file`

Use `$(execpath)` and `$(execpaths)` to expand labels to the execroot (where Bazel runs build actions).
This is of the format:
- `./file`
- `path/to/file`
- `external/external_repo/path/to/file`
- `<bin_dir>/path/to/file`
- `<bin_dir>/external/external_repo/path/to/file`

The deprecated `$(location)` and `$(locations)` expansions returns either the execpath or rootpath depending on the context.
"(
&The expanded path or the original path2H
expand_locations4@@aspect_bazel_lib//lib/private:expand_locations.bzl
�expand_variables�	Expand make variables and substitute like genrule does.

This function is the same as ctx.expand_make_variables with the additional
genrule-like substitutions of:

  - `$@`: The output file if it is a single file. Else triggers a build error.

  - `$(@D)`: The output directory.

    If there is only one file name in outs, this expands to the directory containing that file.

    If there is only one directory in outs, this expands to the single output directory.

    If there are multiple files, this instead expands to the package's root directory in the bin tree,
    even if all generated files belong to the same subdirectory!

  - `$(RULEDIR)`: The output directory of the rule, that is, the directory
    corresponding to the name of the package containing the rule under the bin tree.

  - `$(BUILD_FILE_PATH)`: ctx.build_file_path

  - `$(VERSION_FILE)`: ctx.version_file.path

  - `$(INFO_FILE)`: ctx.info_file.path

  - `$(TARGET)`: ctx.label

  - `$(WORKSPACE)`: ctx.workspace_name

See https://docs.bazel.build/versions/main/be/general.html#genrule.cmd and
https://docs.bazel.build/versions/main/be/make-variables.html#predefined_genrule_variables
for more information of how these special variables are expanded.
*�
�
expand_variables 
ctxstarlark rule context (
sexpression to expand (O
outsAdeclared outputs of the rule, for expanding references to outputs[](�

output_dir�whether the rule is expected to output a directory (TreeArtifact)
Deprecated. For backward compatability with @aspect_bazel_lib 1.x. Pass
output tree artifacts to outs instead.False(f
attribute_nameJname of the attribute containing the expression. Used for error reporting."args"(�	Expand make variables and substitute like genrule does.

This function is the same as ctx.expand_make_variables with the additional
genrule-like substitutions of:

  - `$@`: The output file if it is a single file. Else triggers a build error.

  - `$(@D)`: The output directory.

    If there is only one file name in outs, this expands to the directory containing that file.

    If there is only one directory in outs, this expands to the single output directory.

    If there are multiple files, this instead expands to the package's root directory in the bin tree,
    even if all generated files belong to the same subdirectory!

  - `$(RULEDIR)`: The output directory of the rule, that is, the directory
    corresponding to the name of the package containing the rule under the bin tree.

  - `$(BUILD_FILE_PATH)`: ctx.build_file_path

  - `$(VERSION_FILE)`: ctx.version_file.path

  - `$(INFO_FILE)`: ctx.info_file.path

  - `$(TARGET)`: ctx.label

  - `$(WORKSPACE)`: ctx.workspace_name

See https://docs.bazel.build/versions/main/be/general.html#genrule.cmd and
https://docs.bazel.build/versions/main/be/make-variables.html#predefined_genrule_variables
for more information of how these special variables are expanded.
"!
`s` with the variables expanded2H
expand_variables4@@aspect_bazel_lib//lib/private:expand_variables.bzl
�
"//lib/private:expand_locations.bzlrz
5
aspect_bazel_liblib/privateexpand_locations.bzl3
expand_locations_expand_locations
=N
d�
!//lib/private:expand_template.bzlrw
4
aspect_bazel_liblib/privateexpand_template.bzl1
expand_template_expand_template
<L
a�
"//lib/private:expand_variables.bzlrz
5
aspect_bazel_liblib/privateexpand_variables.bzl3
expand_variables_expand_variables
=N
d"Public API for expanding variables�
'
aspect_bazel_liblibextensions.bzlMextJD
4
ext"-
ext&@@aspect_bazel_lib//lib:extensions.bzl
�
//lib:repositories.bzlr�
)
aspect_bazel_liblibrepositories.bzl>
register_jq_toolchainsregister_jq_toolchains
>
register_yq_toolchainsregister_yq_toolchains

%Module extensions for use with bzlmod�
'
aspect_bazel_liblibglob_match.bzl�
glob_match�Test if the passed path matches the glob expression.

`*` A single asterisk stands for zero or more arbitrary characters except for the the path separator `/` if `match_path_separator` is False

`?` The question mark stands for exactly one character except for the the path separator `/` if `match_path_separator` is False

`**` A double asterisk stands for an arbitrary sequence of 0 or more characters. It is only allowed when preceded by either the beginning of the string or a slash. Likewise it must be followed by a slash or the end of the pattern.
*�
�

glob_match
exprthe glob expression (?
path3the path against which to match the glob expression (u
match_path_separatorTwhether or not to match the path separator '/' when matching `*` and `?` expressionsFalse(�Test if the passed path matches the glob expression.

`*` A single asterisk stands for zero or more arbitrary characters except for the the path separator `/` if `match_path_separator` is False

`?` The question mark stands for exactly one character except for the the path separator `/` if `match_path_separator` is False

`**` A double asterisk stands for an arbitrary sequence of 0 or more characters. It is only allowed when preceded by either the beginning of the string or a slash. Likewise it must be followed by a slash or the end of the pattern.
".
,True if the path matches the glob expression2<

glob_match.@@aspect_bazel_lib//lib/private:glob_match.bzl
**�
//lib/private:glob_match.bzlrh
/
aspect_bazel_liblib/privateglob_match.bzl'

glob_match_glob_match
7B
R
Public API�

&
aspect_bazel_liblibhost_repo.bzl�	host_repo+Exposes information about the host platformR�
�
	host_repo+Exposes information about the host platform.
name"A unique name for this repository. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 *2
	host_repo%@@aspect_bazel_lib//lib:host_repo.bzl
%%0
.
name"A unique name for this repository. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
//lib/private:host_repo.bzlre
.
aspect_bazel_liblib/privatehost_repo.bzl%
	host_repo
_host_repo
6@
O
Public API�1

aspect_bazel_liblibjq.bzl�0jq�Invoke jq with a filter on a set of json input files.

For jq documentation, see https://stedolan.github.io/jq/.

To use this rule you must register the jq toolchain in your WORKSPACE:

```starlark
load("@aspect_bazel_lib//lib:repositories.bzl", "register_jq_toolchains")

register_jq_toolchains()
```

Usage examples:

```starlark
load("@aspect_bazel_lib//lib:jq.bzl", "jq")

# Remove fields from package.json
jq(
    name = "no_dev_deps",
    srcs = ["package.json"],
    filter = "del(.devDependencies)",
)

# Merge bar.json on top of foo.json
jq(
    name = "merged",
    srcs = ["foo.json", "bar.json"],
    filter = ".[0] * .[1]",
    args = ["--slurp"],
    out = "foobar.json",
)

# Long filters can be split over several lines with comments
jq(
    name = "complex",
    srcs = ["a.json", "b.json"],
    filter = """
        .[0] as $a
        # Take select fields from b.json
        | (.[1] | {foo, bar, tags}) as $b
        # Merge b onto a
        | ($a * $b)
        # Combine 'tags' array from both
        | .tags = ($a.tags + $b.tags)
        # Add new field
        + {\"aspect_is_cool\": true}
    """,
    args = ["--slurp"],
)

# Load filter from a file
jq(
    name = "merged",
    srcs = ["foo.json", "bar.json"],
    filter_file = "filter.txt",
    args = ["--slurp"],
    out = "foobar.json",
)

# Convert genquery output to json
genquery(
    name = "deps",
    expression = "deps(//some:target)",
    scope = ["//some:target"],
)

jq(
    name = "deps_json",
    srcs = [":deps"],
    args = [
        "--raw-input",
        "--slurp",
    ],
    filter = "{ deps: split("\n") | map(select(. | length > 0)) }",
)

# With --stamp, causes properties to be replaced by version control info.
jq(
    name = "stamped",
    srcs = ["package.json"],
    filter = "|".join([
        # Don't directly reference $STAMP as it's only set when stamping
        # This 'as' syntax results in $stamp being null in unstamped builds.
        "$ARGS.named.STAMP as $stamp",
        # Provide a default using the "alternative operator" in case $stamp is null.
        ".version = ($stamp.BUILD_EMBED_LABEL // "<unstamped>")",
    ]),
)
```
"�
�
jq�Invoke jq with a filter on a set of json input files.

For jq documentation, see https://stedolan.github.io/jq/.

To use this rule you must register the jq toolchain in your WORKSPACE:

```starlark
load("@aspect_bazel_lib//lib:repositories.bzl", "register_jq_toolchains")

register_jq_toolchains()
```

Usage examples:

```starlark
load("@aspect_bazel_lib//lib:jq.bzl", "jq")

# Remove fields from package.json
jq(
    name = "no_dev_deps",
    srcs = ["package.json"],
    filter = "del(.devDependencies)",
)

# Merge bar.json on top of foo.json
jq(
    name = "merged",
    srcs = ["foo.json", "bar.json"],
    filter = ".[0] * .[1]",
    args = ["--slurp"],
    out = "foobar.json",
)

# Long filters can be split over several lines with comments
jq(
    name = "complex",
    srcs = ["a.json", "b.json"],
    filter = """
        .[0] as $a
        # Take select fields from b.json
        | (.[1] | {foo, bar, tags}) as $b
        # Merge b onto a
        | ($a * $b)
        # Combine 'tags' array from both
        | .tags = ($a.tags + $b.tags)
        # Add new field
        + {\"aspect_is_cool\": true}
    """,
    args = ["--slurp"],
)

# Load filter from a file
jq(
    name = "merged",
    srcs = ["foo.json", "bar.json"],
    filter_file = "filter.txt",
    args = ["--slurp"],
    out = "foobar.json",
)

# Convert genquery output to json
genquery(
    name = "deps",
    expression = "deps(//some:target)",
    scope = ["//some:target"],
)

jq(
    name = "deps_json",
    srcs = [":deps"],
    args = [
        "--raw-input",
        "--slurp",
    ],
    filter = "{ deps: split("\n") | map(select(. | length > 0)) }",
)

# With --stamp, causes properties to be replaced by version control info.
jq(
    name = "stamped",
    srcs = ["package.json"],
    filter = "|".join([
        # Don't directly reference $STAMP as it's only set when stamping
        # This 'as' syntax results in $stamp being null in unstamped builds.
        "$ARGS.named.STAMP as $stamp",
        # Provide a default using the "alternative operator" in case $stamp is null.
        ".version = ($stamp.BUILD_EMBED_LABEL // "<unstamped>")",
    ]),
)
```
*
nameA unique name for this target. 
args2[]
filter2""
filter_file2None
out

srcs �
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.
2-1"*
_jq_rule@@aspect_bazel_lib//lib:jq.bzl
,
*
nameA unique name for this target. 

args2[]

filter2""

filter_file2None	

out


srcs �
�
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.
2-1r
//lib/private:jq.bzlrX
'
aspect_bazel_liblib/privatejq.bzl
jq_lib_jq_lib
/6
BPublic API for jq�
)
aspect_bazel_libliboutput_files.bzl�output_filesjA rule that provides file(s) specific via DefaultInfo from a given target's DefaultInfo or OutputGroupInfo"�
�
output_filesjA rule that provides file(s) specific via DefaultInfo from a given target's DefaultInfo or OutputGroupInfo*
nameA unique name for this target. d
output_groupNif set, we look in the specified output group for paths instead of DefaultInfo2""�
paths�the paths of the file(s), relative to their roots, to provide via DefaultInfo from the given target's DefaultInfo or OutputGroupInfo ^
targetPthe target to look in for requested paths in its' DefaultInfo or OutputGroupInfo "8
output_files(@@aspect_bazel_lib//lib:output_files.bzl
$$,
*
nameA unique name for this target. f
d
output_groupNif set, we look in the specified output group for paths instead of DefaultInfo2""�
�
paths�the paths of the file(s), relative to their roots, to provide via DefaultInfo from the given target's DefaultInfo or OutputGroupInfo `
^
targetPthe target to look in for requested paths in its' DefaultInfo or OutputGroupInfo �	make_output_files�Helper function to generate a output_files target and return its label.

A rule that provides file(s) specific via DefaultInfo from a given target's DefaultInfo or OutputGroupInfo"�
�
make_output_files�Helper function to generate a output_files target and return its label.

A rule that provides file(s) specific via DefaultInfo from a given target's DefaultInfo or OutputGroupInfo*
nameA unique name for this target. d
output_groupNif set, we look in the specified output group for paths instead of DefaultInfo2""�
paths�the paths of the file(s), relative to their roots, to provide via DefaultInfo from the given target's DefaultInfo or OutputGroupInfo ^
targetPthe target to look in for requested paths in its' DefaultInfo or OutputGroupInfo "8
output_files(@@aspect_bazel_lib//lib:output_files.bzl
88,
*
nameA unique name for this target. f
d
output_groupNif set, we look in the specified output group for paths instead of DefaultInfo2""�
�
paths�the paths of the file(s), relative to their roots, to provide via DefaultInfo from the given target's DefaultInfo or OutputGroupInfo `
^
targetPthe target to look in for requested paths in its' DefaultInfo or OutputGroupInfo �
//lib/private:output_files.bzlr�
1
aspect_bazel_liblib/privateoutput_files.bzl5
make_output_files_make_output_files
+
output_files_output_files

kA rule that provides file(s) specific via DefaultInfo from a given target's DefaultInfo or OutputGroupInfo
�
(
aspect_bazel_liblibparams_file.bzl�params_filejGenerates a UTF-8 encoded params file from a list of arguments.

Handles variable substitutions for args.
*�
�
params_file
nameName of the rule. (=
out2Path of the output file, relative to this package. (�
args�
Arguments to concatenate into a params file.

Subject to 'Make variable' substitution. See https://docs.bazel.build/versions/main/be/make-variables.html.

<ol>
<li> Subject to predefined source/output path variables substitutions.

The predefined variables `execpath`, `execpaths`, `rootpath`, `rootpaths`, `location`, and `locations` take
label parameters (e.g. `$(execpath //foo:bar)`) and substitute the file paths denoted by that label.

See https://docs.bazel.build/versions/main/be/make-variables.html#predefined_label_variables for more info.

NB: This $(location) substition returns the manifest file path which differs from the `*_binary` & `*_test`
args and genrule bazel substitions. This will be fixed in a future major release.
See docs string of `expand_location_into_runfiles` macro in `internal/common/expand_into_runfiles.bzl`
for more info.</li>

<li>Subject to predefined variables & custom variable substitutions.

Predefined "Make" variables such as `$(COMPILATION_MODE)` and `$(TARGET_CPU)` are expanded.
See https://docs.bazel.build/versions/main/be/make-variables.html#predefined_variables.

Custom variables are also expanded including variables set through the Bazel CLI with `--define=SOME_VAR=SOME_VALUE`.
See https://docs.bazel.build/versions/main/be/make-variables.html#custom_variables.

Predefined genrule variables are not supported in this context.</li>
</ol>[](8
data*Data for `$(location)` expansions in args.[](�
newline�Line endings to use. One of [`"auto"`, `"unix"`, `"windows"`].

<ul>
<li>`"auto"` for platform-determined</li>
<li>`"unix"` for LF</li>
<li>`"windows"` for CRLF</li>
</ul>"auto"((
kwargsundocumented named arguments(jGenerates a UTF-8 encoded params file from a list of arguments.

Handles variable substitutions for args.
26
params_file'@@aspect_bazel_lib//lib:params_file.bzl
*_params_file2_params_file�
//lib/private:params_file.bzlrk
0
aspect_bazel_liblib/privateparams_file.bzl)
params_file_params_file
8D
Uparams_file public API�$
"
aspect_bazel_liblib	paths.bzl�
relative_file�Resolves a relative path between two files, "to_file" and "frm_file".

If neither of the paths begin with ../ it is assumed that they share the same root. When finding the relative path,
the incoming files are treated as actual files (not folders) so the resulting relative path may differ when compared
to passing the same arguments to python's "os.path.relpath()" or NodeJs's "path.relative()".

For example, 'relative_file("../foo/foo.txt", "bar/bar.txt")' will return '../../foo/foo.txt'
*�
�
relative_file>
to_file/the path with file name to resolve to, from frm (7
frm_file'the path with file name to resolve from (�Resolves a relative path between two files, "to_file" and "frm_file".

If neither of the paths begin with ../ it is assumed that they share the same root. When finding the relative path,
the incoming files are treated as actual files (not folders) so the resulting relative path may differ when compared
to passing the same arguments to python's "os.path.relpath()" or NodeJs's "path.relative()".

For example, 'relative_file("../foo/foo.txt", "bar/bar.txt")' will return '../../foo/foo.txt'
"E
CThe relative path from frm_file to to_file, including the file name2;
_relative_file)@@aspect_bazel_lib//lib/private:paths.bzl
�to_manifest_path�The runfiles manifest entry path for a file

This is the full runfiles path of a file including its workspace name as
the first segment. We refert to it as the manifest path as it is the path
flavor that is used for in the runfiles MANIFEST file.

We must avoid using non-normalized paths (workspace/../other_workspace/path)
in order to locate entries by their key.
*�
�
to_manifest_path*
ctxstarlark rule execution context (
filea File object (�The runfiles manifest entry path for a file

This is the full runfiles path of a file including its workspace name as
the first segment. We refert to it as the manifest path as it is the path
flavor that is used for in the runfiles MANIFEST file.

We must avoid using non-normalized paths (workspace/../other_workspace/path)
in order to locate entries by their key.
"-
+The runfiles manifest entry path for a file2>
_to_manifest_path)@@aspect_bazel_lib//lib/private:paths.bzl
II�to_output_relative_pathDThe relative path from bazel-out/[arch]/bin to the given File object*�
�
to_output_relative_path
f (DThe relative path from bazel-out/[arch]/bin to the given File object2E
_to_output_relative_path)@@aspect_bazel_lib//lib/private:paths.bzl
==�to_workspace_path�The workspace relative path for a file

This is the full runfiles path of a file excluding its workspace name.
This differs from root path and manifest path as it does not include the
repository name if the file is from an external repository.
*�
�
to_workspace_path
filea File object (�The workspace relative path for a file

This is the full runfiles path of a file excluding its workspace name.
This differs from root path and manifest path as it does not include the
repository name if the file is from an external repository.
"(
&The workspace relative path for a file2?
_to_workspace_path)@@aspect_bazel_lib//lib/private:paths.bzl
``u
//lib/private:paths.bzlrX
*
aspect_bazel_liblib/private	paths.bzl
pathspaths
38
:�		BASH_RLOCATION_FUNCTION�
# --- begin runfiles.bash initialization v2 ---
set -uo pipefail; f=bazel_tools/tools/bash/runfiles/runfiles.bash
source "${RUNFILES_DIR:-/dev/null}/$f" 2>/dev/null || \
source "$(grep -sm1 "^$f " "${RUNFILES_MANIFEST_FILE:-/dev/null}" | cut -f2- -d' ')" 2>/dev/null || \
source "$0.runfiles/$f" 2>/dev/null || \
source "$(grep -sm1 "^$f " "$0.runfiles_manifest" | cut -f2- -d' ')" 2>/dev/null || \
source "$(grep -sm1 "^$f " "$0.exe.runfiles_manifest" | cut -f2- -d' ')" 2>/dev/null || \
{ echo>&2 "ERROR: cannot find $f"; exit 1; }; f=; set -e
# --- end runfiles.bash initialization v2 ---
j��
# --- begin runfiles.bash initialization v2 ---
set -uo pipefail; f=bazel_tools/tools/bash/runfiles/runfiles.bash
source "${RUNFILES_DIR:-/dev/null}/$f" 2>/dev/null || \
source "$(grep -sm1 "^$f " "${RUNFILES_MANIFEST_FILE:-/dev/null}" | cut -f2- -d' ')" 2>/dev/null || \
source "$0.runfiles/$f" 2>/dev/null || \
source "$(grep -sm1 "^$f " "$0.runfiles_manifest" | cut -f2- -d' ')" 2>/dev/null || \
source "$(grep -sm1 "^$f " "$0.exe.runfiles_manifest" | cut -f2- -d' ')" 2>/dev/null || \
{ echo>&2 "ERROR: cannot find $f"; exit 1; }; f=; set -e
# --- end runfiles.bash initialization v2 ---

Public API�
+
aspect_bazel_liblibplatform_utils.bzl�
 //lib/private:platform_utils.bzlrt
3
aspect_bazel_liblib/privateplatform_utils.bzl/
platform_utils_platform_utils
;J
^
Public API�
'
aspect_bazel_liblibrepo_utils.bzl�patch�Implementation of patching an already extracted repository.

This rule is intended to be used in the implementation function of
a repository rule. If the parameters `patches`, `patch_tool`,
`patch_args`, `patch_cmds` and `patch_cmds_win` are not specified
then they are taken from `ctx.attr`.
*�	
�	
patchW
ctxLThe repository context of the repository rule calling this utility
function. (O
patches<The patch files to apply. List of strings, Labels, or paths.None(i

patch_cmdsSBash commands to run for patching, passed one at a
time to bash -c. List of stringsNone(�
patch_cmds_win�Powershell commands to run for patching, passed
one at a time to powershell /c. List of strings. If the
boolean value of this parameter is false, patch_cmds will be
used and this parameter will be ignored.None(U

patch_tool?Path of the patch tool to execute for applying
patches. String.None(K

patch_args5Arguments to pass to the patch tool. List of strings.None(\
authLAn optional dict specifying authentication information for some of the URLs.None(<
patch_directory!Directory to apply the patches inNone(�Implementation of patching an already extracted repository.

This rule is intended to be used in the implementation function of
a repository rule. If the parameters `patches`, `patch_tool`,
`patch_args`, `patch_cmds` and `patch_cmds_win` are not specified
then they are taken from `ctx.attr`.
22
patch)@@aspect_bazel_lib//lib/private:patch.bzl
..v
//lib/private:patch.bzlrY
*
aspect_bazel_liblib/private	patch.bzl
patch_patch
28
C�
//lib/private:repo_utils.bzlrh
/
aspect_bazel_liblib/privaterepo_utils.bzl'

repo_utils_repo_utils
7B
R
Public API�
)
aspect_bazel_liblibrepositories.bzl�aspect_bazel_lib_dependencies*Load dependencies required by aspect rules*�
�
aspect_bazel_lib_dependencies�
override_local_config_platform�override the @local_config_platform repository with one that adds stardoc
support for loading constraints.bzl.

Should be set in repositories that load @aspect_bazel_lib copy actions and also generate stardoc.False(*Load dependencies required by aspect rules2I
aspect_bazel_lib_dependencies(@@aspect_bazel_lib//lib:repositories.bzl
�register_jq_toolchains'Registers jq toolchain and repositories*�
�
register_jq_toolchainsL
name<override the prefix for the generated toolchain repositories"jq"(^
versionJthe version of jq to execute (see https://github.com/stedolan/jq/releases)"1.6"(�
register�whether to call through to native.register_toolchains.
Should be True for WORKSPACE users, but false when used under bzlmod extensionTrue('Registers jq toolchain and repositories2B
register_jq_toolchains(@@aspect_bazel_lib//lib:repositories.bzl
##2jq_host_alias_repo2jq_toolchains_repo�register_yq_toolchains'Registers yq toolchain and repositories*�
�
register_yq_toolchainsL
name<override the prefix for the generated toolchain repositories"yq"(b
versionKthe version of yq to execute (see https://github.com/mikefarah/yq/releases)"4.25.2"(�
register�whether to call through to native.register_toolchains.
Should be True for WORKSPACE users, but false when used under bzlmod extensionTrue('Registers yq toolchain and repositories2B
register_yq_toolchains(@@aspect_bazel_lib//lib:repositories.bzl
<<2yq_host_alias_repo2yq_toolchains_repoy
//lib:utils.bzlrd
"
aspect_bazel_liblib	utils.bzl0
maybe_http_archivehttp_archive
*6
N�
//lib/private:jq_toolchain.bzlr�
1
aspect_bazel_liblib/privatejq_toolchain.bzl*
JQ_PLATFORMSJQ_PLATFORMS
:F6
jq_host_alias_repojq_host_alias_repo
J\2
jq_platform_repojq_platform_repo
`p7
jq_toolchains_repojq_toolchains_repo
t�9
DEFAULT_JQ_VERSION_DEFAULT_JQ_VERSION
��
��
'//lib/private:local_config_platform.bzlr�
:
aspect_bazel_liblib/privatelocal_config_platform.bzl<
local_config_platformlocal_config_platform
CX
Z�
//lib/private:yq_toolchain.bzlr�
1
aspect_bazel_liblib/privateyq_toolchain.bzl*
YQ_PLATFORMSYQ_PLATFORMS
:F6
yq_host_alias_repoyq_host_alias_repo
J\2
yq_platform_repoyq_platform_repo
`p7
yq_toolchains_repoyq_toolchains_repo
t�9
DEFAULT_YQ_VERSION_DEFAULT_YQ_VERSION
��
�"	DEFAULT_JQ_VERSION1.6j1.6(	DEFAULT_YQ_VERSION4.25.2j4.25.2:Macros for loading dependencies and registering toolchains�
'
aspect_bazel_liblibrun_binary.bzl�
run_binary]Runs a binary as a build action.

This rule does not require Bash (unlike `native.genrule`).
"�
�

run_binary]Runs a binary as a build action.

This rule does not require Bash (unlike `native.genrule`).
*
nameA unique name for this target. 
args2[]
env
2{}
execution_requirements
2{}
mnemonic2""
out_dirs2[]
outs
progress_message2""
srcs2[]�
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.
2-1

tool 
nn,
*
nameA unique name for this target. 

args2[]

env
2{} 

execution_requirements
2{}

mnemonic2""

out_dirs2[]


outs

progress_message2""

srcs2[]�
�
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.
2-1


tool �
//lib/private:run_binary.bzlrh
/
aspect_bazel_liblib/privaterun_binary.bzl'

run_binary_run_binary

	�Runs a binary as a build action. This rule does not require Bash (unlike native.genrule()).

This fork of bazel-skylib's run_binary adds directory output support and better makevar expansions.
�"
%
aspect_bazel_liblibstamping.bzl�maybe_stampPProvide the bazel-out/stable_status.txt and bazel-out/volatile_status.txt files.*�
�
maybe_stamp
ctxThe rule context (PProvide the bazel-out/stable_status.txt and bazel-out/volatile_status.txt files."�
�If stamping is not enabled for this rule under the current build, returns None.
Otherwise, returns a struct containing (volatile_status_file, stable_status_file) keys23
maybe_stamp$@@aspect_bazel_lib//lib:stamping.bzl
[[�
//lib/private:stamping.bzlrw
-
aspect_bazel_liblib/privatestamping.bzl8
is_stamping_enabledis_stamping_enabled
Y6YI
YYK�# Version Stamping

Bazel is generally only a build tool, and is unaware of your version control system.
However, when publishing releases, you may want to embed version information in the resulting distribution.
Bazel supports this with the concept of a "Workspace status" which is evaluated before each build.
See [the Bazel workspace status docs](https://docs.bazel.build/versions/master/user-manual.html#workspace_status)

To stamp a build, you pass the `--stamp` argument to Bazel.

> Note: https://github.com/bazelbuild/bazel/issues/14341 proposes that Bazel enforce this by
> only giving constant values to rule implementations when stamping isn't enabled.

Stamping is typically performed on a later action in the graph, like on a linking or packaging rule (`pkg_*`).
This means that a changed status variable only causes that action, not re-compilation and thus does not cause cascading re-builds.

Bazel provides a couple of statuses by default, such as `BUILD_EMBED_LABEL` which is the value of the `--embed_label`
argument, as well as `BUILD_HOST` and `BUILD_USER`. You can supply more with the workspace status script, see below.

Some rules accept an attribute that uses the status variables.
They will usually say something like "subject to stamp variable replacements".

## Stamping with a Workspace status script

To define additional statuses, pass the `--workspace_status_command` flag to `bazel`.
This slows down every build, so you should avoid passing this flag unless you need to stamp this build.
The value of this flag is a path to a script that prints space-separated key/value pairs, one per line, such as

```bash
#!/usr/bin/env bash
echo STABLE_GIT_COMMIT $(git rev-parse HEAD)
```
> For a more full-featured script, take a look at the [bazel_stamp_vars in Angular]

Make sure you set the executable bit, eg. `chmod +x tools/bazel_stamp_vars.sh`.

> **NOTE** keys that start with `STABLE_` will cause a re-build when they change.
> Other keys will NOT cause a re-build, so stale values can appear in your app.
> Non-stable (volatile) keys should typically be things like timestamps that always vary between builds.

You might like to encode your setup using an entry in `.bazelrc` such as:

```sh
# This tells Bazel how to interact with the version control system
# Enable this with --config=release
build:release --stamp --workspace_status_command=./tools/bazel_stamp_vars.sh
```

[bazel_stamp_vars in Angular]: https://github.com/angular/angular/blob/master/tools/bazel_stamp_vars.sh

## Writing a custom rule which reads stamp variables

First, load the helpers:

```starlark
load("@aspect_bazel_lib//lib:stamping.bzl", "STAMP_ATTRS", "maybe_stamp")
```

In your rule implementation, call the `maybe_stamp` function.
If it returns `None` then this build doesn't have stamping enabled.
Otherwise you can use the returned struct to access two files.
The stable_status file contains the keys which were prefixed with `STABLE_`, see above.
The volatile_status file contains the rest of the keys.

```starlark
def _rule_impl(ctx):
    args = ctx.actions.args()
    inputs = []
    stamp = maybe_stamp(ctx)
    if stamp:
        args.add("--volatile_status_file", stamp.volatile_status_file.path)
        args.add("--stable_status_file", stamp.stable_status_file.path)
        inputs.extend([stamp.volatile_status_file, stamp.stable_status_file])

    # ... call actions which parse the stamp files and do something with the values ...
```

Finally, in the declaration of the rule, include the `STAMP_ATTRS` to declare attributes
which are read by that `maybe_stamp` function above.

```starlark
my_stamp_aware_rule = rule(
    attrs = dict({
        # ... my attributes ...
    }, **STAMP_ATTRS),
)
```
�
$
aspect_bazel_liblibtesting.bzl�assert_containsGenerates a test target which fails if the file doesn't contain the string.

Depends on bash, as it creates an sh_test target.
*�
�
assert_contains
nametarget to create (
actualLabel of a file (8
expected(a string which should appear in the file (5
size%the size attribute of the test targetNone(;
timeout(the timeout attribute of the test targetNone(Generates a test target which fails if the file doesn't contain the string.

Depends on bash, as it creates an sh_test target.
26
assert_contains#@@aspect_bazel_lib//lib:testing.bzl
"native.sh_test2
write_file2native.sh_testy
//lib:utils.bzlrd
"
aspect_bazel_liblib	utils.bzl0
default_timeoutdefault_timeout
+:
<y
//rules:write_file.bzlr]
%
bazel_skylibruleswrite_file.bzl&

write_file
write_file
.8
:"Helpers for making test assertions�
(
aspect_bazel_liblibtransitions.bzl�platform_transition_filegrouppTransitions the srcs to use the provided platform. The filegroup will contain artifacts for the target platform."�
�
platform_transition_filegrouppTransitions the srcs to use the provided platform. The filegroup will contain artifacts for the target platform.*
nameA unique name for this target. B
srcs4The input to be transitioned to the target platform.2[]B
target_platform+The target platform to transition the srcs. "H
platform_transition_filegroup'@@aspect_bazel_lib//lib:transitions.bzl
%%,
*
nameA unique name for this target. D
B
srcs4The input to be transitioned to the target platform.2[]D
B
target_platform+The target platform to transition the srcs. #Rules for working with transitions.�F
"
aspect_bazel_liblib	utils.bzl�default_timeout�Provide a sane default for *_test timeout attribute.

The [test-encyclopedia](https://bazel.build/reference/test-encyclopedia) says
> Tests may return arbitrarily fast regardless of timeout.
> A test is not penalized for an overgenerous timeout, although a warning may be issued:
> you should generally set your timeout as tight as you can without incurring any flakiness.

However Bazel's default for timeout is medium, which is dumb given this guidance.

It also says:
> Tests which do not explicitly specify a timeout have one implied based on the test's size as follows
Therefore if size is specified, we should allow timeout to take its implied default.
If neither is set, then we can fix Bazel's wrong default here to avoid warnings under
`--test_verbose_timeout_warnings`.

This function can be used in a macro which wraps a testing rule.
*�
�
default_timeout/
size#the size attribute of a test target (5
timeout&the timeout attribute of a test target (�Provide a sane default for *_test timeout attribute.

The [test-encyclopedia](https://bazel.build/reference/test-encyclopedia) says
> Tests may return arbitrarily fast regardless of timeout.
> A test is not penalized for an overgenerous timeout, although a warning may be issued:
> you should generally set your timeout as tight as you can without incurring any flakiness.

However Bazel's default for timeout is medium, which is dumb given this guidance.

It also says:
> Tests which do not explicitly specify a timeout have one implied based on the test's size as follows
Therefore if size is specified, we should allow timeout to take its implied default.
If neither is set, then we can fix Bazel's wrong default here to avoid warnings under
`--test_verbose_timeout_warnings`.

This function can be used in a macro which wraps a testing rule.
".
,"short" if neither is set, otherwise timeout2=
_default_timeout)@@aspect_bazel_lib//lib/private:utils.bzl
vv�file_exists�Check whether a file exists.

Useful in macros to set defaults for a configuration file if it is present.
This can only be called during the loading phase, not from a rule implementation.
*�
�
file_existsI
path=a label, or a string which is a path relative to this package (�Check whether a file exists.

Useful in macros to set defaults for a configuration file if it is present.
This can only be called during the loading phase, not from a rule implementation.
29
_file_exists)@@aspect_bazel_lib//lib/private:utils.bzl
gg�glob_directories*�
m
glob_directories
include (

kwargs(2>
_glob_directories)@@aspect_bazel_lib//lib/private:utils.bzl
aa*native.glob*native.glob�is_bazel_6_or_greater�Detects if the Bazel version being used is greater than or equal to 6 (including Bazel 6 pre-releases and RCs).

Detecting Bazel 6 or greater is particularly useful in rules as slightly different code paths may be needed to
support bzlmod which was added in Bazel 6.

Unlike the undocumented `native.bazel_version`, which only works in WORKSPACE and repository rules, this function can
be used in rules and BUILD files.

An alternate approach to make the Bazel version available in BUILD files and rules would be to
use the [host_repo](https://github.com/aspect-build/bazel-lib/blob/main/docs/host_repo.md) repository rule
which contains the bazel_version in the exported `host` struct:

WORKSPACE:
```
load("@aspect_bazel_lib//lib:host_repo.bzl", "host_repo")
host_repo(name = "aspect_bazel_lib_host")
```

BUILD.bazel:
```
load("@aspect_bazel_lib_host//:defs.bzl", "host")
print(host.bazel_version)
```

That approach, however, incurs a cost in the user's WORKSPACE.
*�	
�	
is_bazel_6_or_greater�Detects if the Bazel version being used is greater than or equal to 6 (including Bazel 6 pre-releases and RCs).

Detecting Bazel 6 or greater is particularly useful in rules as slightly different code paths may be needed to
support bzlmod which was added in Bazel 6.

Unlike the undocumented `native.bazel_version`, which only works in WORKSPACE and repository rules, this function can
be used in rules and BUILD files.

An alternate approach to make the Bazel version available in BUILD files and rules would be to
use the [host_repo](https://github.com/aspect-build/bazel-lib/blob/main/docs/host_repo.md) repository rule
which contains the bazel_version in the exported `host` struct:

WORKSPACE:
```
load("@aspect_bazel_lib//lib:host_repo.bzl", "host_repo")
host_repo(name = "aspect_bazel_lib_host")
```

BUILD.bazel:
```
load("@aspect_bazel_lib_host//:defs.bzl", "host")
print(host.bazel_version)
```

That approach, however, incurs a cost in the user's WORKSPACE.
"e
cTrue if the Bazel version being used is greater than or equal to 6 (including pre-releases and RCs)2C
_is_bazel_6_or_greater)@@aspect_bazel_lib//lib/private:utils.bzl
���is_external_labellReturns True if the given Label (or stringy version of a label) represents a target outside of the workspace*�
�
is_external_label
parama string or label (lReturns True if the given Label (or stringy version of a label) represents a target outside of the workspace"
a bool2?
_is_external_label)@@aspect_bazel_lib//lib/private:utils.bzl
FF�maybe_http_archive�Adapts a maybe(http_archive, ...) to look like an http_archive.

This makes WORKSPACE dependencies easier to read and update.

Typical usage looks like,

```
load("//lib:utils.bzl", http_archive = "maybe_http_archive")

http_archive(
    name = "aspect_rules_js",
    sha256 = "5bb643d9e119832a383e67f946dc752b6d719d66d1df9b46d840509ceb53e1f1",
    strip_prefix = "rules_js-1.6.2",
    url = "https://github.com/aspect-build/rules_js/archive/refs/tags/v1.6.2.tar.gz",
)
```

instead of the classic maybe pattern of,

```
load("@bazel_tools//tools/build_defs/repo:http.bzl", "http_archive")
load("@bazel_tools//tools/build_defs/repo:utils.bzl", "maybe")

maybe(
    http_archive,
    name = "aspect_rules_js",
    sha256 = "5bb643d9e119832a383e67f946dc752b6d719d66d1df9b46d840509ceb53e1f1",
    strip_prefix = "rules_js-1.6.2",
    url = "https://github.com/aspect-build/rules_js/archive/refs/tags/v1.6.2.tar.gz",
)
```
*�
�
maybe_http_archive9
kwargs-all arguments to pass-forward to http_archive(�Adapts a maybe(http_archive, ...) to look like an http_archive.

This makes WORKSPACE dependencies easier to read and update.

Typical usage looks like,

```
load("//lib:utils.bzl", http_archive = "maybe_http_archive")

http_archive(
    name = "aspect_rules_js",
    sha256 = "5bb643d9e119832a383e67f946dc752b6d719d66d1df9b46d840509ceb53e1f1",
    strip_prefix = "rules_js-1.6.2",
    url = "https://github.com/aspect-build/rules_js/archive/refs/tags/v1.6.2.tar.gz",
)
```

instead of the classic maybe pattern of,

```
load("@bazel_tools//tools/build_defs/repo:http.bzl", "http_archive")
load("@bazel_tools//tools/build_defs/repo:utils.bzl", "maybe")

maybe(
    http_archive,
    name = "aspect_rules_js",
    sha256 = "5bb643d9e119832a383e67f946dc752b6d719d66d1df9b46d840509ceb53e1f1",
    strip_prefix = "rules_js-1.6.2",
    url = "https://github.com/aspect-build/rules_js/archive/refs/tags/v1.6.2.tar.gz",
)
```
2@
_maybe_http_archive)@@aspect_bazel_lib//lib/private:utils.bzl
��*maybe�path_to_workspace_root2Returns the path to the workspace root under bazel*�
�
path_to_workspace_root2Returns the path to the workspace root under bazel"
Path to the workspace root2D
_path_to_workspace_root)@@aspect_bazel_lib//lib/private:utils.bzl
XX�propagate_well_known_tags�Returns a list of tags filtered from the input set that only contains the ones that are considered "well known"

These are listed in Bazel's documentation:
https://docs.bazel.build/versions/main/test-encyclopedia.html#tag-conventions
https://docs.bazel.build/versions/main/be/common-definitions.html#common-attributes
*�
�
propagate_well_known_tags$
tagsList of tags to filter[](�Returns a list of tags filtered from the input set that only contains the ones that are considered "well known"

These are listed in Bazel's documentation:
https://docs.bazel.build/versions/main/test-encyclopedia.html#tag-conventions
https://docs.bazel.build/versions/main/be/common-definitions.html#common-attributes
"4
2List of tags that only contains the well known set2G
_propagate_well_known_tags)@@aspect_bazel_lib//lib/private:utils.bzl
�to_labelOConverts a string to a Label. If Label is supplied, the same label is returned.*�
�
to_label5
param(a string representing a label or a Label (OConverts a string to a Label. If Label is supplied, the same label is returned."	
a Label26
	_to_label)@@aspect_bazel_lib//lib/private:utils.bzl
--u
//lib/private:utils.bzlrX
*
aspect_bazel_liblib/private	utils.bzl
utilsutils
38
:
Public API�
*
aspect_bazel_liblibwindows_utils.bzl�%create_windows_native_launcher_script�Create a Windows Batch file to launch the given shell script.

The rule should specify @bazel_tools//tools/sh:toolchain_type as a required toolchain.
*�
�
%create_windows_native_launcher_script
ctxRule context (,
shell_scriptThe bash launcher script (�Create a Windows Batch file to launch the given shell script.

The rule should specify @bazel_tools//tools/sh:toolchain_type as a required toolchain.
"
A windows launcher script2R
%create_windows_native_launcher_script)@@aspect_bazel_lib//lib:windows_utils.bzl
JJ�	BATCH_RLOCATION_FUNCTION�	
rem Usage of rlocation function:
rem        call :rlocation <runfile_path> <abs_path>
rem        The rlocation function maps the given <runfile_path> to its absolute
rem        path and stores the result in a variable named <abs_path>.
rem        This function fails if the <runfile_path> doesn't exist in mainifest
rem        file.
:: Start of rlocation
goto :rlocation_end
:rlocation
if "%~2" equ "" (
  echo>&2 ERROR: Expected two arguments for rlocation function.
  exit 1
)
if "%RUNFILES_MANIFEST_ONLY%" neq "1" (
  set %~2=%~1
  exit /b 0
)
if exist "%RUNFILES_DIR%" (
  set RUNFILES_MANIFEST_FILE=%RUNFILES_DIR%_manifest
)
if "%RUNFILES_MANIFEST_FILE%" equ "" (
  set RUNFILES_MANIFEST_FILE=%~f0.runfiles\MANIFEST
)
if not exist "%RUNFILES_MANIFEST_FILE%" (
  set RUNFILES_MANIFEST_FILE=%~f0.runfiles_manifest
)
set MF=%RUNFILES_MANIFEST_FILE:/=\%
if not exist "%MF%" (
  echo>&2 ERROR: Manifest file %MF% does not exist.
  exit 1
)
set runfile_path=%~1
for /F "tokens=2* usebackq" %%i in (`%SYSTEMROOT%\system32\findstr.exe /l /c:"!runfile_path! " "%MF%"`) do (
  set abs_path=%%i
)
if "!abs_path!" equ "" (
  echo>&2 ERROR: !runfile_path! not found in runfiles manifest
  exit 1
)
set %~2=!abs_path!
exit /b 0
:rlocation_end
:: End of rlocation
j�	�	
rem Usage of rlocation function:
rem        call :rlocation <runfile_path> <abs_path>
rem        The rlocation function maps the given <runfile_path> to its absolute
rem        path and stores the result in a variable named <abs_path>.
rem        This function fails if the <runfile_path> doesn't exist in mainifest
rem        file.
:: Start of rlocation
goto :rlocation_end
:rlocation
if "%~2" equ "" (
  echo>&2 ERROR: Expected two arguments for rlocation function.
  exit 1
)
if "%RUNFILES_MANIFEST_ONLY%" neq "1" (
  set %~2=%~1
  exit /b 0
)
if exist "%RUNFILES_DIR%" (
  set RUNFILES_MANIFEST_FILE=%RUNFILES_DIR%_manifest
)
if "%RUNFILES_MANIFEST_FILE%" equ "" (
  set RUNFILES_MANIFEST_FILE=%~f0.runfiles\MANIFEST
)
if not exist "%RUNFILES_MANIFEST_FILE%" (
  set RUNFILES_MANIFEST_FILE=%~f0.runfiles_manifest
)
set MF=%RUNFILES_MANIFEST_FILE:/=\%
if not exist "%MF%" (
  echo>&2 ERROR: Manifest file %MF% does not exist.
  exit 1
)
set runfile_path=%~1
for /F "tokens=2* usebackq" %%i in (`%SYSTEMROOT%\system32\findstr.exe /l /c:"!runfile_path! " "%MF%"`) do (
  set abs_path=%%i
)
if "!abs_path!" equ "" (
  echo>&2 ERROR: !runfile_path! not found in runfiles manifest
  exit 1
)
set %~2=!abs_path!
exit /b 0
:rlocation_end
:: End of rlocation
$Helpers for rules running on windows�#
/
aspect_bazel_liblibwrite_source_files.bzl�!write_source_files�Write to one or more files or folders in the source tree. Stamp out tests that ensure the sources exist and are up to date.

Usage:

```starlark
load("@aspect_bazel_lib//lib:write_source_files.bzl", "write_source_files")

write_source_files(
    name = "write_foobar",
    files = {
        "foobar.json": "//some/generated:file",
    },
)
```

To update the source file, run:
```bash
bazel run //:write_foobar
```

A test will fail if the source file doesn't exist or if it's out of date with instructions on how to create/update it.

You can declare a tree of generated source file targets:

```starlark
load("@aspect_bazel_lib//lib:write_source_files.bzl", "write_source_files")

write_source_files(
    name = "write_all",
    additional_update_targets = [
        # Other write_source_files targets to run when this target is run
        "//a/b/c:write_foo",
        "//a/b:write_bar",
    ]
)
```

And update them with a single run:

```bash
bazel run //:write_all
```

When a file is out of date, you can leave a suggestion to run a target further up in the tree by specifying `suggested_update_target`. E.g.,

```starlark
write_source_files(
    name = "write_foo",
    files = {
        "foo.json": ":generated-foo",
    },
    suggested_update_target = "//:write_all"
)
```

A test failure from foo.json being out of date will yield the following message:

```
//a/b:c:foo.json is out of date. To update this and other generated files, run:

    bazel run //:write_all

To update *only* this file, run:

    bazel run //a/b/c:write_foo
```

If you have many sources that you want to update as a group, we recommend wrapping write_source_files in a macro that defaults `suggested_update_target` to the umbrella update target.

NOTE: If you run formatters or linters on your codebase, it is advised that you exclude/ignore the outputs of this rule from those formatters/linters so as to avoid causing collisions and failing tests.
"�
�
write_source_files�Write to one or more files or folders in the source tree. Stamp out tests that ensure the sources exist and are up to date.

Usage:

```starlark
load("@aspect_bazel_lib//lib:write_source_files.bzl", "write_source_files")

write_source_files(
    name = "write_foobar",
    files = {
        "foobar.json": "//some/generated:file",
    },
)
```

To update the source file, run:
```bash
bazel run //:write_foobar
```

A test will fail if the source file doesn't exist or if it's out of date with instructions on how to create/update it.

You can declare a tree of generated source file targets:

```starlark
load("@aspect_bazel_lib//lib:write_source_files.bzl", "write_source_files")

write_source_files(
    name = "write_all",
    additional_update_targets = [
        # Other write_source_files targets to run when this target is run
        "//a/b/c:write_foo",
        "//a/b:write_bar",
    ]
)
```

And update them with a single run:

```bash
bazel run //:write_all
```

When a file is out of date, you can leave a suggestion to run a target further up in the tree by specifying `suggested_update_target`. E.g.,

```starlark
write_source_files(
    name = "write_foo",
    files = {
        "foo.json": ":generated-foo",
    },
    suggested_update_target = "//:write_all"
)
```

A test failure from foo.json being out of date will yield the following message:

```
//a/b:c:foo.json is out of date. To update this and other generated files, run:

    bazel run //:write_all

To update *only* this file, run:

    bazel run //a/b/c:write_foo
```

If you have many sources that you want to update as a group, we recommend wrapping write_source_files in a macro that defaults `suggested_update_target` to the umbrella update target.

NOTE: If you run formatters or linters on your codebase, it is advised that you exclude/ignore the outputs of this rule from those formatters/linters so as to avoid causing collisions and failing tests.
*
nameA unique name for this target. 8
additional_update_targets*
WriteSourceFileInfo2[]
in_file2None
out_file2""
,
*
nameA unique name for this target. :
8
additional_update_targets*
WriteSourceFileInfo2[]

in_file2None

out_file2""�
#//lib/private:write_source_file.bzlr}
6
aspect_bazel_liblib/privatewrite_source_file.bzl5
write_source_file_write_source_file

!Public API for write_source_files�

aspect_bazel_liblibyq.bzl�yq�Invoke yq with an expression on a set of input files.

For yq documentation, see https://mikefarah.gitbook.io/yq.

To use this rule you must register the yq toolchain in your WORKSPACE:

```starlark
load("@aspect_bazel_lib//lib:repositories.bzl", "register_yq_toolchains")

register_yq_toolchains()
```

Usage examples:

```starlark
load("@aspect_bazel_lib//lib:yq.bzl", "yq")
```

```starlark
# Remove fields
yq(
    name = "safe-config",
    srcs = ["config.yaml"],
    expression = "del(.credentials)",
)
```

```starlark
# Merge two yaml documents
yq(
    name = "ab",
    srcs = [
        "a.yaml",
        "b.yaml",
    ],
    expression = ". as $item ireduce ({}; . * $item )",
)
```

```starlark
# Split a yaml file into several files
yq(
    name = "split",
    srcs = ["multidoc.yaml"],
    outs = [
        "first.yml",
        "second.yml",
    ],
    args = [
        "-s '.a'",  # Split expression
        "--no-doc", # Exclude document separator --
    ],
)
```

```starlark
# Convert a yaml file to json
yq(
    name = "convert-to-json",
    srcs = ["foo.yaml"],
    args = ["-o=json"],
    outs = ["foo.json"],
)
```

```starlark
# Convert a json file to yaml
yq(
    name = "convert-to-yaml",
    srcs = ["bar.json"],
    args = ["-P"],
    outs = ["bar.yaml"],
)
```

```starlark
# Call yq in a genrule
genrule(
    name = "generate",
    srcs = ["farm.yaml"],
    outs = ["genrule_output.yaml"],
    cmd = "$(YQ_BIN) '.moo = "cow"' $(location farm.yaml) > $@",
    toolchains = ["@yq_toolchains//:resolved_toolchain"],
)
```

yq is capable of parsing and outputting to other formats. See their [docs](https://mikefarah.gitbook.io/yq) for more examples.
"�
�
yq�Invoke yq with an expression on a set of input files.

For yq documentation, see https://mikefarah.gitbook.io/yq.

To use this rule you must register the yq toolchain in your WORKSPACE:

```starlark
load("@aspect_bazel_lib//lib:repositories.bzl", "register_yq_toolchains")

register_yq_toolchains()
```

Usage examples:

```starlark
load("@aspect_bazel_lib//lib:yq.bzl", "yq")
```

```starlark
# Remove fields
yq(
    name = "safe-config",
    srcs = ["config.yaml"],
    expression = "del(.credentials)",
)
```

```starlark
# Merge two yaml documents
yq(
    name = "ab",
    srcs = [
        "a.yaml",
        "b.yaml",
    ],
    expression = ". as $item ireduce ({}; . * $item )",
)
```

```starlark
# Split a yaml file into several files
yq(
    name = "split",
    srcs = ["multidoc.yaml"],
    outs = [
        "first.yml",
        "second.yml",
    ],
    args = [
        "-s '.a'",  # Split expression
        "--no-doc", # Exclude document separator --
    ],
)
```

```starlark
# Convert a yaml file to json
yq(
    name = "convert-to-json",
    srcs = ["foo.yaml"],
    args = ["-o=json"],
    outs = ["foo.json"],
)
```

```starlark
# Convert a json file to yaml
yq(
    name = "convert-to-yaml",
    srcs = ["bar.json"],
    args = ["-P"],
    outs = ["bar.yaml"],
)
```

```starlark
# Call yq in a genrule
genrule(
    name = "generate",
    srcs = ["farm.yaml"],
    outs = ["genrule_output.yaml"],
    cmd = "$(YQ_BIN) '.moo = "cow"' $(location farm.yaml) > $@",
    toolchains = ["@yq_toolchains//:resolved_toolchain"],
)
```

yq is capable of parsing and outputting to other formats. See their [docs](https://mikefarah.gitbook.io/yq) for more examples.
*
nameA unique name for this target. 
args2[]

expression2""

outs 

srcs "*
_yq_rule@@aspect_bazel_lib//lib:yq.bzl
,
*
nameA unique name for this target. 

args2[]


expression2""


outs 


srcs �
//lib/private:yq.bzlr�
'
aspect_bazel_liblib/privateyq.bzl7
is_split_operation_is_split_operation
/B
yq_lib_yq_lib
[b
nPublic API for yq�
%
aspect_bazel_libinternal_deps.bzl�bazel_lib_internal_deps'Fetch deps needed for local development*�
�
bazel_lib_internal_deps'Fetch deps needed for local development2A
bazel_lib_internal_deps&@@aspect_bazel_lib//:internal_deps.bzl
�
//lib:repositories.bzlr�
)
aspect_bazel_liblibrepositories.bzl>
register_jq_toolchainsregister_jq_toolchains
2H>
register_yq_toolchainsregister_yq_toolchains
Lb
dy
//lib:utils.bzlrd
"
aspect_bazel_liblib	utils.bzl0
maybe_http_archivehttp_archive
*6
N�Our "development" dependencies

Users should *not* need to install these. If users see a load()
statement from these, that's a bug in our distribution.
 