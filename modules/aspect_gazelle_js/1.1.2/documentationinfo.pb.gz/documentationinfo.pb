�
.
aspect_gazelle_jscrates/js-parseropt.bzl*�ModuleInfo request error: invalid argument: Traceback (most recent call last):
	File "external/aspect_gazelle_js/crates/js-parser/opt.bzl", line 19, column 56, in <toplevel>
		opt_rust_static_library, _opt_rust_static_library_rule = (
Error: too few values to unpack (got 0, want 2) 