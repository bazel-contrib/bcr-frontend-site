�k
esbuilddefs.bzl�aesbuild_bundle�Runs the esbuild bundler under Bazel

For further information about esbuild, see https://esbuild.github.io/

Note: to prevent esbuild from following symlinks and leaving the bazel sandbox, a custom `bazel-sandbox` resolver plugin is used in this rule. See https://github.com/aspect-build/rules_esbuild/issues/58 for more info."�^
�0
esbuild_bundle�Runs the esbuild bundler under Bazel

For further information about esbuild, see https://esbuild.github.io/

Note: to prevent esbuild from following symlinks and leaving the bazel sandbox, a custom `bazel-sandbox` resolver plugin is used in this rule. See https://github.com/aspect-build/rules_esbuild/issues/58 for more info.*
nameA unique name for this target. &
	args_fileInternal use only2None�
define�A dict of global identifier replacements. Values are subject to $(location ...) expansion.
Example:
```python
esbuild(
name = "bundle",
define = {
"process.env.NODE_ENV": "production"
},
)
```

See https://esbuild.github.io/api/#define for more details
2{}�
depsCA list of direct dependencies that are required to build the bundle*<
JsInfo2
JsInfo(@aspect_rules_js//js/private:js_info.bzl2[]�
data�Runtime dependencies to include in binaries/tests that depend on this target.

Follows the same semantics as `js_library` `data` attribute. See
https://docs.aspect.build/rulesets/aspect_rules_js/docs/js_library#data for more info.2[]�
entry_point�The bundle's entry point (e.g. your main.js or app.js or index.js)

This is a shortcut for the `entry_points` attribute with a single entry.
Specify either this attribute or `entry_point`, but not both.2None�
entry_points�The bundle's entry points (e.g. your main.js or app.js or index.js)

Specify either this attribute or `entry_point`, but not both.2[]�
external�A list of module names that are treated as external and not included in the resulting bundle

See https://esbuild.github.io/api/#external for more details2[]�
format�The output format of the bundle, defaults to iife when platform is browser
and cjs when platform is node. If performing code splitting or multiple entry_points are specified, defaults to esm.

See https://esbuild.github.io/api/#format for more details2""d
launcherPOverride the default esbuild wrapper, which is supplied by the esbuild toolchain2None�
max_threads�Sets the `GOMAXPROCS` variable to limit the number of threads that esbuild can run with.
This can be useful if running many esbuild rule invocations in parallel, which has the potential to cause slowdown.
For general use, leave this attribute unset.20N
metafile9If true, esbuild creates a metafile along with the output2False�
minify�Minifies the bundle with the built in minification.
Removes whitespace, shortens identifieres and uses equivalent but shorter syntax.

Sets all --minify-* flags

See https://esbuild.github.io/api/#minify for more details2False9
output%Name of the output file when bundling2None8�

output_css�Declare a .css file will be output next to output bundle.

If your JS code contains import statements that import .css files, esbuild will place the
content in a file next to the main output file, which you'll need to declare. If your output
file is named 'foo.js', you should set this to 'foo.css'.2None8`

output_dirIIf true, esbuild produces an output directory containing all output files2FalseC

output_map+Name of the output source map when bundling2None8r
platformYThe platform to bundle for.

See https://esbuild.github.io/api/#platform for more details2	"browser"�
	sourcemap�Defines where sourcemaps are output and how they are included in the bundle. If `linked`, a separate `.js.map` file is generated and referenced by the bundle. If `external`, a separate `.js.map` file is generated but not referenced by the bundle. If `inline`, a sourcemap is generated and its contents are inlined into the bundle (and no external sourcemap file is created). If `both`, a sourcemap is inlined and a `.js.map` file is created.

See https://esbuild.github.io/api/#sourcemap for more details2""�
sources_content�If False, omits the `sourcesContent` field from generated source maps

See https://esbuild.github.io/api/#sources-content for more details2False�
	splitting�If true, esbuild produces an output directory containing all the output files from code splitting for multiple entry points

See https://esbuild.github.io/api/#splitting and https://esbuild.github.io/api/#entry-points for more details2False:
srcs,Source files to be made available to esbuild2[]�
target�Environment target (e.g. es2017, chrome58, firefox57, safari11,
edge16, node10, esnext). Default es2015.

See https://esbuild.github.io/api/#target for more details2
["es2015"]g
bundleUIf true, esbuild will bundle the input files, inlining their dependencies recursively2True�
config�Configuration file used for esbuild. Note that options set in this file may get overwritten. If you formerly used `args` from rules_nodejs' npm package `@bazel/esbuild`, replace it with this attribute.
TODO: show how to write a config file that depends on plugins, similar to the esbuild_config macro in rules_nodejs.2None�
tsconfig�TypeScript configuration file used by esbuild. Default to an empty file with no configuration.

See https://esbuild.github.io/api/#tsconfig for more details �
bazel_sandbox_plugin�If true, a custom bazel-sandbox plugin will be enabled that prevents esbuild from leaving the Bazel sandbox.
See https://github.com/aspect-build/rules_esbuild/pull/160 for more info.2True�
esbuild_log_level�Set the logging level of esbuild.

We set a default of "warmning" since the esbuild default of "info" includes
an output file summary which is slightly redundant under Bazel and may lead
to spammy `bazel build` output.

See https://esbuild.github.io/api/#log-level for more details.2	"warning"�
js_log_level�Set the logging level for js_binary launcher and the JavaScript bazel-sandbox plugin.

Log levels: fatal, error, warn, info, debug2"error"�
node_toolchain�The Node.js toolchain to use for this target.

See https://bazelbuild.github.io/rules_nodejs/Toolchains.html

Typically this is left unset so that Bazel automatically selects the right Node.js toolchain
for the target platform. See https://bazel.build/extending/toolchains#toolchain-resolution
for more information.2None"/
esbuild_bundle//esbuild/private:esbuild.bzl,
*
nameA unique name for this target. (
&
	args_fileInternal use only2None�
�
define�A dict of global identifier replacements. Values are subject to $(location ...) expansion.
Example:
```python
esbuild(
name = "bundle",
define = {
"process.env.NODE_ENV": "production"
},
)
```

See https://esbuild.github.io/api/#define for more details
2{}�
�
depsCA list of direct dependencies that are required to build the bundle*<
JsInfo2
JsInfo(@aspect_rules_js//js/private:js_info.bzl2[]�
�
data�Runtime dependencies to include in binaries/tests that depend on this target.

Follows the same semantics as `js_library` `data` attribute. See
https://docs.aspect.build/rulesets/aspect_rules_js/docs/js_library#data for more info.2[]�
�
entry_point�The bundle's entry point (e.g. your main.js or app.js or index.js)

This is a shortcut for the `entry_points` attribute with a single entry.
Specify either this attribute or `entry_point`, but not both.2None�
�
entry_points�The bundle's entry points (e.g. your main.js or app.js or index.js)

Specify either this attribute or `entry_point`, but not both.2[]�
�
external�A list of module names that are treated as external and not included in the resulting bundle

See https://esbuild.github.io/api/#external for more details2[]�
�
format�The output format of the bundle, defaults to iife when platform is browser
and cjs when platform is node. If performing code splitting or multiple entry_points are specified, defaults to esm.

See https://esbuild.github.io/api/#format for more details2""f
d
launcherPOverride the default esbuild wrapper, which is supplied by the esbuild toolchain2None�
�
max_threads�Sets the `GOMAXPROCS` variable to limit the number of threads that esbuild can run with.
This can be useful if running many esbuild rule invocations in parallel, which has the potential to cause slowdown.
For general use, leave this attribute unset.20P
N
metafile9If true, esbuild creates a metafile along with the output2False�
�
minify�Minifies the bundle with the built in minification.
Removes whitespace, shortens identifieres and uses equivalent but shorter syntax.

Sets all --minify-* flags

See https://esbuild.github.io/api/#minify for more details2False;
9
output%Name of the output file when bundling2None8�
�

output_css�Declare a .css file will be output next to output bundle.

If your JS code contains import statements that import .css files, esbuild will place the
content in a file next to the main output file, which you'll need to declare. If your output
file is named 'foo.js', you should set this to 'foo.css'.2None8b
`

output_dirIIf true, esbuild produces an output directory containing all output files2FalseE
C

output_map+Name of the output source map when bundling2None8t
r
platformYThe platform to bundle for.

See https://esbuild.github.io/api/#platform for more details2	"browser"�
�
	sourcemap�Defines where sourcemaps are output and how they are included in the bundle. If `linked`, a separate `.js.map` file is generated and referenced by the bundle. If `external`, a separate `.js.map` file is generated but not referenced by the bundle. If `inline`, a sourcemap is generated and its contents are inlined into the bundle (and no external sourcemap file is created). If `both`, a sourcemap is inlined and a `.js.map` file is created.

See https://esbuild.github.io/api/#sourcemap for more details2""�
�
sources_content�If False, omits the `sourcesContent` field from generated source maps

See https://esbuild.github.io/api/#sources-content for more details2False�
�
	splitting�If true, esbuild produces an output directory containing all the output files from code splitting for multiple entry points

See https://esbuild.github.io/api/#splitting and https://esbuild.github.io/api/#entry-points for more details2False<
:
srcs,Source files to be made available to esbuild2[]�
�
target�Environment target (e.g. es2017, chrome58, firefox57, safari11,
edge16, node10, esnext). Default es2015.

See https://esbuild.github.io/api/#target for more details2
["es2015"]i
g
bundleUIf true, esbuild will bundle the input files, inlining their dependencies recursively2True�
�
config�Configuration file used for esbuild. Note that options set in this file may get overwritten. If you formerly used `args` from rules_nodejs' npm package `@bazel/esbuild`, replace it with this attribute.
TODO: show how to write a config file that depends on plugins, similar to the esbuild_config macro in rules_nodejs.2None�
�
tsconfig�TypeScript configuration file used by esbuild. Default to an empty file with no configuration.

See https://esbuild.github.io/api/#tsconfig for more details �
�
bazel_sandbox_plugin�If true, a custom bazel-sandbox plugin will be enabled that prevents esbuild from leaving the Bazel sandbox.
See https://github.com/aspect-build/rules_esbuild/pull/160 for more info.2True�
�
esbuild_log_level�Set the logging level of esbuild.

We set a default of "warmning" since the esbuild default of "info" includes
an output file summary which is slightly redundant under Bazel and may lead
to spammy `bazel build` output.

See https://esbuild.github.io/api/#log-level for more details.2	"warning"�
�
js_log_level�Set the logging level for js_binary launcher and the JavaScript bazel-sandbox plugin.

Log levels: fatal, error, warn, info, debug2"error"�
�
node_toolchain�The Node.js toolchain to use for this target.

See https://bazelbuild.github.io/rules_nodejs/Toolchains.html

Typically this is left unset so that Bazel automatically selects the right Node.js toolchain
for the target platform. See https://bazel.build/extending/toolchains#toolchain-resolution
for more information.2None�	esbuild�esbuild helper macro around the `esbuild_bundle` rule

For a full list of attributes, see the [`esbuild_bundle`](./esbuild.md) rule
*�
�
esbuild6
name,The name used for this rule and output files ;

output_dir&If `True`, produce an output directoryFalseR
	splitting>If `True`, produce a code split bundle in the output directoryFalse�
config�an esbuild configuration file
Can be a dictionary.
In this case it is converted to json, and a config file is generated
which exports the resulting object, e.g.
`export default {...}`None.
kwargs$All other args from `esbuild_bundle`�esbuild helper macro around the `esbuild_bundle` rule

For a full list of attributes, see the [`esbuild_bundle`](./esbuild.md) rule
2
esbuild//esbuild:defs.bzl8
6
name,The name used for this rule and output files =
;

output_dir&If `True`, produce an output directoryFalseT
R
	splitting>If `True`, produce a code split bundle in the output directoryFalse�
�
config�an esbuild configuration file
Can be a dictionary.
In this case it is converted to json, and a config file is generated
which exports the resulting object, e.g.
`export default {...}`None0
.
kwargs$All other args from `esbuild_bundle`# Public API 