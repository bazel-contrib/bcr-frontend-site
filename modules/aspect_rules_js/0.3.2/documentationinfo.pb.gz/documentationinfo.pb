�1
0
aspect_rules_js
js/privatenodejs_binary.bzl�-nodejs_binary�Execute a program in the node.js runtime.

The version of node is determined by Bazel's toolchain selection.
In the WORKSPACE you used `nodejs_register_toolchains` to provide options to Bazel.
Then Bazel selects from these options based on the requested target platform.
Use the 
[`--toolchain_resolution_debug`](https://docs.bazel.build/versions/main/command-line-reference.html#flag--toolchain_resolution_debug)
Bazel option to see more detail about the selection.

### Static linking

This rule executes node with the Global Folders set to Bazel's runfiles folder.
<https://nodejs.org/docs/latest-v16.x/api/modules.html#loading-from-the-global-folders>
describes Node's module resolution algorithm.
By setting the `NODE_PATH` variable, we supply a location for `node_modules` resolution
outside of the project's source folder.
This means that all transitive dependencies of the `data` attribute will be available at
runtime for every execution of this program.

This requires that Bazel was run with
[`--enable_runfiles`](https://docs.bazel.build/versions/main/command-line-reference.html#flag--enable_runfiles). 

In some language runtimes, this concept is called "static linking", so we use the same term
in aspect_rules_js. This is in contrast to "dynamic linking", where the program needs to
resolve a module which is declared only in the place where the program is used, generally
with a `deps` attribute at the callsite.

> Note that some libraries do not follow the semantics of Node.js module resolution,
> and instead make fixed assumptions about the `node_modules` folder existing in some
> parent directory of a source file. These libraries will need some patching to work
> under this "static linker" approach. We expect to provide more detail about how to do
> this in a future release.
"�
�
nodejs_binary�Execute a program in the node.js runtime.

The version of node is determined by Bazel's toolchain selection.
In the WORKSPACE you used `nodejs_register_toolchains` to provide options to Bazel.
Then Bazel selects from these options based on the requested target platform.
Use the 
[`--toolchain_resolution_debug`](https://docs.bazel.build/versions/main/command-line-reference.html#flag--toolchain_resolution_debug)
Bazel option to see more detail about the selection.

### Static linking

This rule executes node with the Global Folders set to Bazel's runfiles folder.
<https://nodejs.org/docs/latest-v16.x/api/modules.html#loading-from-the-global-folders>
describes Node's module resolution algorithm.
By setting the `NODE_PATH` variable, we supply a location for `node_modules` resolution
outside of the project's source folder.
This means that all transitive dependencies of the `data` attribute will be available at
runtime for every execution of this program.

This requires that Bazel was run with
[`--enable_runfiles`](https://docs.bazel.build/versions/main/command-line-reference.html#flag--enable_runfiles). 

In some language runtimes, this concept is called "static linking", so we use the same term
in aspect_rules_js. This is in contrast to "dynamic linking", where the program needs to
resolve a module which is declared only in the place where the program is used, generally
with a `deps` attribute at the callsite.

> Note that some libraries do not follow the semantics of Node.js module resolution,
> and instead make fixed assumptions about the `node_modules` folder existing in some
> parent directory of a source file. These libraries will need some patching to work
> under this "static linker" approach. We expect to provide more detail about how to do
> this in a future release.
*
nameA unique name for this target. �
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

You can use the `@bazel/runfiles` npm library to access these files
at runtime.

npm packages are also linked into the `.runfiles/node_modules` folder
so they may be resolved directly from runfiles.
2[]�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
entry_point|The main script which is evaluated by node.js

This is the module referenced by the `require.main` property in the runtime.
2None�

is_windows�Whether the build is being performed on a Windows host platform.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `select()` on `@bazel_tools//src/conditions:host_windows`.
 "@
nodejs_binary/@@aspect_rules_js//js/private:nodejs_binary.bzl
��,
*
nameA unique name for this target. �
�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

You can use the `@bazel/runfiles` npm library to access these files
at runtime.

npm packages are also linked into the `.runfiles/node_modules` folder
so they may be resolved directly from runfiles.
2[]�
�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
�
entry_point|The main script which is evaluated by node.js

This is the module referenced by the `require.main` property in the runtime.
2None�
�

is_windows�Whether the build is being performed on a Windows host platform.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `select()` on `@bazel_tools//src/conditions:host_windows`.
 �
//lib:paths.bzlr�
"
aspect_bazel_liblib	paths.bzl@
BASH_RLOCATION_FUNCTIONBASH_RLOCATION_FUNCTION
+B2
to_manifest_pathto_manifest_path
FV
X�
//lib:windows_utils.bzlr~
*
aspect_bazel_liblibwindows_utils.bzlB
BATCH_RLOCATION_FUNCTIONBATCH_RLOCATION_FUNCTION
3K
M�
//nodejs:providers.bzlro
%
rules_nodejsnodejsproviders.bzl8
LinkablePackageInfoLinkablePackageInfo
.A
C#nodejs_binary and nodejs_test rules�
1
aspect_rules_js
js/privatenodejs_package.bzl�nodejs_package�Defines a library that executes in a node.js runtime.

The term "package" is defined at
<https://nodejs.org/docs/latest-v16.x/api/packages.html>

To be compatible with Bazel's remote execution protocol,
all source files are copied to an an output directory,
which is 

NB: This rule is not yet tested on Windows
"�
�
nodejs_package�Defines a library that executes in a node.js runtime.

The term "package" is defined at
<https://nodejs.org/docs/latest-v16.x/api/packages.html>

To be compatible with Bazel's remote execution protocol,
all source files are copied to an an output directory,
which is 

NB: This rule is not yet tested on Windows
*
nameA unique name for this target. �
deps�Other packages this one depends on.

This should include *all* modules the program may need at runtime.

> In typical usage, a node.js program sometimes requires modules which were
> never declared as dependencies.
> This pattern is typically used when the program has conditional behavior
> that is enabled when the module is found (like a plugin) but the program
> also runs without the dependency.
> 
> This is possible because node.js doesn't enforce the dependencies are sound.
> All files under `node_modules` are available to any program.
> In contrast, Bazel makes it possible to make builds hermetic, which means that
> all dependencies of a program must be declared when running in Bazel's sandbox.
2[]

is_windows \
package_nameHMust match the `name` field in the `package.json` file for this package. 
remap_paths
2{}o
src`A TreeArtifact containing the npm package files.

Exactly one of `src` or `srcs` should be set.
2Noneg
srcsYFiles to copy into the package directory.

Exactly one of `src` or `srcs` should be set.
2[]"B
nodejs_package0@@aspect_rules_js//js/private:nodejs_package.bzl
��,
*
nameA unique name for this target. �
�
deps�Other packages this one depends on.

This should include *all* modules the program may need at runtime.

> In typical usage, a node.js program sometimes requires modules which were
> never declared as dependencies.
> This pattern is typically used when the program has conditional behavior
> that is enabled when the module is found (like a plugin) but the program
> also runs without the dependency.
> 
> This is possible because node.js doesn't enforce the dependencies are sound.
> All files under `node_modules` are available to any program.
> In contrast, Bazel makes it possible to make builds hermetic, which means that
> all dependencies of a program must be declared when running in Bazel's sandbox.
2[]


is_windows ^
\
package_nameHMust match the `name` field in the `package.json` file for this package. 

remap_paths
2{}q
o
src`A TreeArtifact containing the npm package files.

Exactly one of `src` or `srcs` should be set.
2Nonei
g
srcsYFiles to copy into the package directory.

Exactly one of `src` or `srcs` should be set.
2[]a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.�
//nodejs:providers.bzlro
%
rules_nodejsnodejsproviders.bzl8
LinkablePackageInfoLinkablePackageInfo
.A
Cnodejs_package ruler
9
aspect_rules_js
js/privatetranslate_package_lock.bzl5Convert package-lock.json into starlark Bazel fetches�
(
aspect_rules_jsjsnodejs_binary.bzl�nodejs_binary"�
�
nodejs_binary*
nameA unique name for this target. �
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

You can use the `@bazel/runfiles` npm library to access these files
at runtime.

npm packages are also linked into the `.runfiles/node_modules` folder
so they may be resolved directly from runfiles.
2[]�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
entry_point|The main script which is evaluated by node.js

This is the module referenced by the `require.main` property in the runtime.
2None�

is_windows�Whether the build is being performed on a Windows host platform.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `select()` on `@bazel_tools//src/conditions:host_windows`.
 "9
_nodejs_binary'@@aspect_rules_js//js:nodejs_binary.bzl
,
*
nameA unique name for this target. �
�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

You can use the `@bazel/runfiles` npm library to access these files
at runtime.

npm packages are also linked into the `.runfiles/node_modules` folder
so they may be resolved directly from runfiles.
2[]�
�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
�
entry_point|The main script which is evaluated by node.js

This is the module referenced by the `require.main` property in the runtime.
2None�
�

is_windows�Whether the build is being performed on a Windows host platform.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `select()` on `@bazel_tools//src/conditions:host_windows`.
 �
//js/private:nodejs_binary.bzlrh
0
aspect_rules_js
js/privatenodejs_binary.bzl&
nodejs_binary_liblib
8;
R$wrapper macro for nodejs_binary rule�
)
aspect_rules_jsjsnodejs_package.bzl�nodejs_package"�
�	
nodejs_package*
nameA unique name for this target. �
deps�Other packages this one depends on.

This should include *all* modules the program may need at runtime.

> In typical usage, a node.js program sometimes requires modules which were
> never declared as dependencies.
> This pattern is typically used when the program has conditional behavior
> that is enabled when the module is found (like a plugin) but the program
> also runs without the dependency.
> 
> This is possible because node.js doesn't enforce the dependencies are sound.
> All files under `node_modules` are available to any program.
> In contrast, Bazel makes it possible to make builds hermetic, which means that
> all dependencies of a program must be declared when running in Bazel's sandbox.
2[]

is_windows \
package_nameHMust match the `name` field in the `package.json` file for this package. 
remap_paths
2{}o
src`A TreeArtifact containing the npm package files.

Exactly one of `src` or `srcs` should be set.
2Noneg
srcsYFiles to copy into the package directory.

Exactly one of `src` or `srcs` should be set.
2[]";
_nodejs_package(@@aspect_rules_js//js:nodejs_package.bzl
,
*
nameA unique name for this target. �
�
deps�Other packages this one depends on.

This should include *all* modules the program may need at runtime.

> In typical usage, a node.js program sometimes requires modules which were
> never declared as dependencies.
> This pattern is typically used when the program has conditional behavior
> that is enabled when the module is found (like a plugin) but the program
> also runs without the dependency.
> 
> This is possible because node.js doesn't enforce the dependencies are sound.
> All files under `node_modules` are available to any program.
> In contrast, Bazel makes it possible to make builds hermetic, which means that
> all dependencies of a program must be declared when running in Bazel's sandbox.
2[]


is_windows ^
\
package_nameHMust match the `name` field in the `package.json` file for this package. 

remap_paths
2{}q
o
src`A TreeArtifact containing the npm package files.

Exactly one of `src` or `srcs` should be set.
2Nonei
g
srcsYFiles to copy into the package directory.

Exactly one of `src` or `srcs` should be set.
2[]�
//js/private:nodejs_package.bzlrj
1
aspect_rules_js
js/privatenodejs_package.bzl'
nodejs_package_liblib
9<
T%wrapper macro for nodejs_package rule�P
%
aspect_rules_jsjsnpm_import.bzl�*
npm_import�Import a single npm package into Bazel.

Normally you'd want to use `translate_package_lock` to import all your packages at once.
It generates `npm_import` rules.
You can create these manually if you want to have exact control.

Bazel will only fetch the given package from an external registry if the package is
required for the user-requested targets to be build/tested.
The package will be exposed as a [`nodejs_package`](./nodejs_package) rule in a repository
with a default name `@npm_[package name]-[version]`, as the default target in that repository.
(Characters in the package name which are not legal in Bazel repository names are converted to underscore.)

This is a repository rule, which should be called from your `WORKSPACE` file
or some `.bzl` file loaded from it. For example, with this code in `WORKSPACE`:

```starlark
npm_import(
    integrity = "sha512-zjQ69G564OCIWIOHSXyQEEDpdpGl+G348RAKY0XXy9Z5kU9Vzv1GMNnkar/ZJ8dzXB3COzD9Mo9NtRZ4xfgUww==",
    package = "@types/node",
    version = "15.12.2",
)
```

you can use the label `@npm__types_node-15.12.2` in your BUILD files to reference the package.

> This is similar to Bazel rules in other ecosystems named "_import" like
> `apple_bundle_import`, `scala_import`, `java_import`, and `py_import`
> `go_repository` is also a model for this rule.

The name of this repository should contain the version number, so that multiple versions of the same
package don't collide.
(Note that the npm ecosystem always supports multiple versions of a library depending on where
it is required, unlike other languages like Go or Python.)

To change the proxy URL we use to fetch, configure the Bazel downloader:
1. Make a file containing a rewrite rule like

   rewrite (registry.nodejs.org)/(.*) artifactory.build.internal.net/artifactory/$1/$2

1. To understand the rewrites, see [UrlRewriterConfig] in Bazel sources.

1. Point bazel to the config with a line in .bazelrc like
    common --experimental_downloader_config=.bazel_downloader_config

[UrlRewriterConfig]: https://github.com/bazelbuild/bazel/blob/4.2.1/src/main/java/com/google/devtools/build/lib/bazel/repository/downloader/UrlRewriterConfig.java#L66
*�
�

npm_import�
	integrity�Expected checksum of the file downloaded, in Subresource Integrity format.
This must match the checksum of the file downloaded.

This is the same as appears in the yarn.lock or package-lock.json file.

It is a security risk to omit the checksum as remote files can change.
At best omitting this field will make your build non-hermetic.
It is optional to make development easier but should be set before shipping. (A
package2npm package name, such as `acorn` or `@types/node` (:
version+version of the npm package, such as `8.4.0` (5
deps'other npm packages this one depends on.[](�
name�the external repository generated to contain the package content.
This argument may be omitted to get the default name documented above.None(�
patches�patch files to apply onto the downloaded npm package.
Paths in the patch file must start with `extract_tmp/package`
where `package` is the top-level folder in the archive on npm.[](�Import a single npm package into Bazel.

Normally you'd want to use `translate_package_lock` to import all your packages at once.
It generates `npm_import` rules.
You can create these manually if you want to have exact control.

Bazel will only fetch the given package from an external registry if the package is
required for the user-requested targets to be build/tested.
The package will be exposed as a [`nodejs_package`](./nodejs_package) rule in a repository
with a default name `@npm_[package name]-[version]`, as the default target in that repository.
(Characters in the package name which are not legal in Bazel repository names are converted to underscore.)

This is a repository rule, which should be called from your `WORKSPACE` file
or some `.bzl` file loaded from it. For example, with this code in `WORKSPACE`:

```starlark
npm_import(
    integrity = "sha512-zjQ69G564OCIWIOHSXyQEEDpdpGl+G348RAKY0XXy9Z5kU9Vzv1GMNnkar/ZJ8dzXB3COzD9Mo9NtRZ4xfgUww==",
    package = "@types/node",
    version = "15.12.2",
)
```

you can use the label `@npm__types_node-15.12.2` in your BUILD files to reference the package.

> This is similar to Bazel rules in other ecosystems named "_import" like
> `apple_bundle_import`, `scala_import`, `java_import`, and `py_import`
> `go_repository` is also a model for this rule.

The name of this repository should contain the version number, so that multiple versions of the same
package don't collide.
(Note that the npm ecosystem always supports multiple versions of a library depending on where
it is required, unlike other languages like Go or Python.)

To change the proxy URL we use to fetch, configure the Bazel downloader:
1. Make a file containing a rewrite rule like

   rewrite (registry.nodejs.org)/(.*) artifactory.build.internal.net/artifactory/$1/$2

1. To understand the rewrites, see [UrlRewriterConfig] in Bazel sources.

1. Point bazel to the config with a line in .bazelrc like
    common --experimental_downloader_config=.bazel_downloader_config

[UrlRewriterConfig]: https://github.com/bazelbuild/bazel/blob/4.2.1/src/main/java/com/google/devtools/build/lib/bazel/repository/downloader/UrlRewriterConfig.java#L66
22

npm_import$@@aspect_rules_js//js:npm_import.bzl
OO2_npm_import�#translate_package_lock�Repository rule to generate npm_import rules from package-lock.json file.

The npm lockfile format includes all the information needed to define npm_import rules,
including the integrity hash, as calculated by the package manager.

Instead of manually declaring the `npm_imports`, this helper generates an external repository
containing a helper starlark module `repositories.bzl`, which supplies a loadable macro
`npm_repositories`. This macro creates an `npm_import` for each package.

The generated repository also contains BUILD files declaring targets for the packages
listed as `dependencies` or `devDependencies` in `package.json`, so you can declare
dependencies on those packages without having to repeat version information.

Bazel will only fetch the packages which are required for the requested targets to be analyzed.
Thus it is performant to convert a very large package-lock.json file without concern for
users needing to fetch many unnecessary packages.

Typical usage:
```starlark
load("@aspect_rules_js//js:npm_import.bzl", "translate_package_lock")

# Read the package-lock.json file to automate creation of remaining npm_import rules
translate_package_lock(
    name = "npm_deps",
    package_lock = "//:package-lock.json",
)

load("@npm_deps//:repositories.bzl", "npm_repositories")

npm_repositories()
```

Next, in your BUILD files you can declare dependencies on the packages using the same external repository.

Following the same example, this might look like:

```starlark
nodejs_test(
    name = "test_test",
    data = ["@npm_deps//@types/node"],
    entry_point = "test.js",
)
```
R�
�
translate_package_lock�Repository rule to generate npm_import rules from package-lock.json file.

The npm lockfile format includes all the information needed to define npm_import rules,
including the integrity hash, as calculated by the package manager.

Instead of manually declaring the `npm_imports`, this helper generates an external repository
containing a helper starlark module `repositories.bzl`, which supplies a loadable macro
`npm_repositories`. This macro creates an `npm_import` for each package.

The generated repository also contains BUILD files declaring targets for the packages
listed as `dependencies` or `devDependencies` in `package.json`, so you can declare
dependencies on those packages without having to repeat version information.

Bazel will only fetch the packages which are required for the requested targets to be analyzed.
Thus it is performant to convert a very large package-lock.json file without concern for
users needing to fetch many unnecessary packages.

Typical usage:
```starlark
load("@aspect_rules_js//js:npm_import.bzl", "translate_package_lock")

# Read the package-lock.json file to automate creation of remaining npm_import rules
translate_package_lock(
    name = "npm_deps",
    package_lock = "//:package-lock.json",
)

load("@npm_deps//:repositories.bzl", "npm_repositories")

npm_repositories()
```

Next, in your BUILD files you can declare dependencies on the packages using the same external repository.

Following the same example, this might look like:

```starlark
nodejs_test(
    name = "test_test",
    data = ["@npm_deps//@types/node"],
    entry_point = "test.js",
)
```
.
name"A unique name for this repository. }
package_lockiThe package-lock.json file.

It should use the lockfileVersion 2, which is produced from npm 7 or higher. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 *>
translate_package_lock$@@aspect_rules_js//js:npm_import.bzl
�)�)0
.
name"A unique name for this repository. 
}
package_lockiThe package-lock.json file.

It should use the lockfileVersion 2, which is produced from npm 7 or higher. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
'//js/private:translate_package_lock.bzlrv
9
aspect_rules_js
js/privatetranslate_package_lock.bzl+
translate_package_locklib
AD
`0repository rules for importing packages from npm�
'
aspect_rules_jsjsrepositories.bzl�rules_js_dependencies)Dependencies for users of aspect_rules_js*�
�
rules_js_dependencies)Dependencies for users of aspect_rules_js2?
rules_js_dependencies&@@aspect_rules_js//js:repositories.bzl
�
 //tools/build_defs/repo:http.bzlrj
.
bazel_toolstools/build_defs/repohttp.bzl*
http_archivehttp_archive
7C
E�
!//tools/build_defs/repo:utils.bzlr]
/
bazel_toolstools/build_defs/repo	utils.bzl
maybemaybe
8=
?�Declare runtime dependencies

These are needed for local dev, and users must install them as well.
See https://docs.bazel.build/versions/main/skylark/deploying.html#dependencies
�
$
aspect_rules_jsinternal_deps.bzl�rules_js_internal_deps0Fetch repositories used for developing the rules*�
�
rules_js_internal_deps0Fetch repositories used for developing the rules2?
rules_js_internal_deps%@@aspect_rules_js//:internal_deps.bzl


�
 //tools/build_defs/repo:http.bzlrj
.
bazel_toolstools/build_defs/repohttp.bzl*
http_archivehttp_archive
7C
E�
!//tools/build_defs/repo:utils.bzlr]
/
bazel_toolstools/build_defs/repo	utils.bzl
maybemaybe
8=
?�Our "development" dependencies

Users should *not* need to install these. If users see a load()
statement from these, that's a bug in our distribution.
 