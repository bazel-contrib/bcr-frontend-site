�
6
aspect_rules_jsexamples/js_binarycustom_rule.bzl�custom_rule"�
�
custom_rule*
nameA unique name for this target. 
execution_requirements
2{}
tool2None"D
custom_rule5@@aspect_rules_js//examples/js_binary:custom_rule.bzl
,
*
nameA unique name for this target.  

execution_requirements
2{}

tool2None@A simple custom rule for testing js_binary used in a custom rule�
3
aspect_rules_jsexamples/js_library/twotsc.bzl�tsc*�
{
tsc

name (!
args["-p", "tsconfig.json"](

kwargs(29
tsc2@@aspect_rules_js//examples/js_library/two:tsc.bzl
y
:typescript/package_json.bzlrW
"
npmtypescript/package_json.bzl#
bintypescript_bin
,:
CwSimple macro exposing the typescript tsc binary.

Most users should use ts_project from aspect-build/rules_ts instead.
�
,
aspect_rules_jsexamples/macro	mocha.bzl�
mocha_test*�
�

mocha_test

name (

srcs (
args[](
data[](
env{}(

kwargs(29

mocha_test+@@aspect_rules_js//examples/macro:mocha.bzl
*dict�
'//examples/macro:mocha/package_json.bzlrW
-
npmexamples/macromocha/package_json.bzl
binbin
69
;$Example macro wrapping the mocha CLI�
2
aspect_rules_jsjs/private/coverage
merger.bzl�coverage_merger"�
�
coverage_merger*
nameA unique name for this target. 2
entry_point2!//js/private/coverage:coverage.js"D
coverage_merger1@@aspect_rules_js//js/private/coverage:merger.bzl
55,
*
nameA unique name for this target. 4
2
entry_point2!//js/private/coverage:coverage.js�
//lib:windows_utils.bzlr�
*
aspect_bazel_liblibwindows_utils.bzl\
%create_windows_native_launcher_script%create_windows_native_launcher_script
3X
Z�
//js/private:bash.bzlr{
'
aspect_rules_js
js/privatebash.bzlB
BASH_INITIALIZE_RUNFILESBASH_INITIALIZE_RUNFILES
0H
JInternal use only͒
5
aspect_rules_jsjs/private/test/coveragetest.bzl��coverage_fail_test"��
�D
coverage_fail_test*
nameA unique name for this target. �
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/"))) + "$(rootpath //path/to/some:file)"],
)
```2""�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

NB: `data` files are copied to the Bazel output tree before being passed
as inputs to runfiles. See `copy_data_to_bin` docstring for more info.
2[]�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/aspect-build/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 �
env�Environment variables of the action.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution.

2{}i
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�

fixed_args�Fixed command line arguments to pass to the Node.js when this
binary target is executed.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution.

Unlike the built-in `args`, which are only passed to the target when it is
executed either by the `bazel run` command or as a test, `fixed_args` are baked
into the generated launcher script so are always passed even when the binary
target is run outside of Bazel directly from the launcher script.

`fixed_args` are passed before the ones specified in `args` and before ones
that are specified on the `bazel run` or `bazel test` command line.

See https://bazel.build/reference/be/common-definitions#common-attributes-binaries
for more info on the built-in `args` attribute.
2[]�
include_declarations�When True, `declarations` and `transitive_declarations` from `JsInfo` providers in data targets are included in the runfiles of the target.

Defaults to false since declarations are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
include_npm_linked_packages�When True, files in `npm_linked_packages` and `transitive_npm_linked_packages` from `JsInfo` providers in data targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in data targets are also included in the runfiles of the target.
2True�
include_transitive_sourcessWhen True, `transitive_sources` from `JsInfo` providers in data targets are included in the runfiles of the target.2True�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.

Log levels: fatal, error, warn, info, debug2"error"�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
node_toolchain�The Node.js toolchain to use for this target.

See https://bazelbuild.github.io/rules_nodejs/Toolchains.html

Typically this is left unset so that Bazel automatically selects the right Node.js toolchain
for the target platform. See https://bazel.build/extending/toolchains#toolchain-resolution
for more information.
2None�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2True�
unresolved_symlinks_enabled�Whether unresolved symlinks are enabled in the current build configuration.

These are enabled with the --experimental_allow_unresolved_symlinks flag.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
2False"J
coverage_fail_test4@@aspect_rules_js//js/private/test/coverage:test.bzl
,
*
nameA unique name for this target. �
�
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/"))) + "$(rootpath //path/to/some:file)"],
)
```2""�
�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

NB: `data` files are copied to the Bazel output tree before being passed
as inputs to runfiles. See `copy_data_to_bin` docstring for more info.
2[]�
�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
�
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/aspect-build/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 �
�
env�Environment variables of the action.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution.

2{}k
i
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�
�

fixed_args�Fixed command line arguments to pass to the Node.js when this
binary target is executed.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution.

Unlike the built-in `args`, which are only passed to the target when it is
executed either by the `bazel run` command or as a test, `fixed_args` are baked
into the generated launcher script so are always passed even when the binary
target is run outside of Bazel directly from the launcher script.

`fixed_args` are passed before the ones specified in `args` and before ones
that are specified on the `bazel run` or `bazel test` command line.

See https://bazel.build/reference/be/common-definitions#common-attributes-binaries
for more info on the built-in `args` attribute.
2[]�
�
include_declarations�When True, `declarations` and `transitive_declarations` from `JsInfo` providers in data targets are included in the runfiles of the target.

Defaults to false since declarations are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
�
include_npm_linked_packages�When True, files in `npm_linked_packages` and `transitive_npm_linked_packages` from `JsInfo` providers in data targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in data targets are also included in the runfiles of the target.
2True�
�
include_transitive_sourcessWhen True, `transitive_sources` from `JsInfo` providers in data targets are included in the runfiles of the target.2True�
�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.

Log levels: fatal, error, warn, info, debug2"error"�
�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
�
node_toolchain�The Node.js toolchain to use for this target.

See https://bazelbuild.github.io/rules_nodejs/Toolchains.html

Typically this is left unset so that Bazel automatically selects the right Node.js toolchain
for the target platform. See https://bazel.build/extending/toolchains#toolchain-resolution
for more information.
2None�
�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2True�
�
unresolved_symlinks_enabled�Whether unresolved symlinks are enabled in the current build configuration.

These are enabled with the --experimental_allow_unresolved_symlinks flag.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
2False��coverage_pass_test"��
�D
coverage_pass_test*
nameA unique name for this target. �
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/"))) + "$(rootpath //path/to/some:file)"],
)
```2""�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

NB: `data` files are copied to the Bazel output tree before being passed
as inputs to runfiles. See `copy_data_to_bin` docstring for more info.
2[]�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/aspect-build/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 �
env�Environment variables of the action.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution.

2{}i
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�

fixed_args�Fixed command line arguments to pass to the Node.js when this
binary target is executed.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution.

Unlike the built-in `args`, which are only passed to the target when it is
executed either by the `bazel run` command or as a test, `fixed_args` are baked
into the generated launcher script so are always passed even when the binary
target is run outside of Bazel directly from the launcher script.

`fixed_args` are passed before the ones specified in `args` and before ones
that are specified on the `bazel run` or `bazel test` command line.

See https://bazel.build/reference/be/common-definitions#common-attributes-binaries
for more info on the built-in `args` attribute.
2[]�
include_declarations�When True, `declarations` and `transitive_declarations` from `JsInfo` providers in data targets are included in the runfiles of the target.

Defaults to false since declarations are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
include_npm_linked_packages�When True, files in `npm_linked_packages` and `transitive_npm_linked_packages` from `JsInfo` providers in data targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in data targets are also included in the runfiles of the target.
2True�
include_transitive_sourcessWhen True, `transitive_sources` from `JsInfo` providers in data targets are included in the runfiles of the target.2True�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.

Log levels: fatal, error, warn, info, debug2"error"�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
node_toolchain�The Node.js toolchain to use for this target.

See https://bazelbuild.github.io/rules_nodejs/Toolchains.html

Typically this is left unset so that Bazel automatically selects the right Node.js toolchain
for the target platform. See https://bazel.build/extending/toolchains#toolchain-resolution
for more information.
2None�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2True�
unresolved_symlinks_enabled�Whether unresolved symlinks are enabled in the current build configuration.

These are enabled with the --experimental_allow_unresolved_symlinks flag.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
2False"J
coverage_pass_test4@@aspect_rules_js//js/private/test/coverage:test.bzl
,
*
nameA unique name for this target. �
�
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/"))) + "$(rootpath //path/to/some:file)"],
)
```2""�
�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

NB: `data` files are copied to the Bazel output tree before being passed
as inputs to runfiles. See `copy_data_to_bin` docstring for more info.
2[]�
�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
�
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/aspect-build/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 �
�
env�Environment variables of the action.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution.

2{}k
i
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�
�

fixed_args�Fixed command line arguments to pass to the Node.js when this
binary target is executed.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution.

Unlike the built-in `args`, which are only passed to the target when it is
executed either by the `bazel run` command or as a test, `fixed_args` are baked
into the generated launcher script so are always passed even when the binary
target is run outside of Bazel directly from the launcher script.

`fixed_args` are passed before the ones specified in `args` and before ones
that are specified on the `bazel run` or `bazel test` command line.

See https://bazel.build/reference/be/common-definitions#common-attributes-binaries
for more info on the built-in `args` attribute.
2[]�
�
include_declarations�When True, `declarations` and `transitive_declarations` from `JsInfo` providers in data targets are included in the runfiles of the target.

Defaults to false since declarations are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
�
include_npm_linked_packages�When True, files in `npm_linked_packages` and `transitive_npm_linked_packages` from `JsInfo` providers in data targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in data targets are also included in the runfiles of the target.
2True�
�
include_transitive_sourcessWhen True, `transitive_sources` from `JsInfo` providers in data targets are included in the runfiles of the target.2True�
�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.

Log levels: fatal, error, warn, info, debug2"error"�
�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
�
node_toolchain�The Node.js toolchain to use for this target.

See https://bazelbuild.github.io/rules_nodejs/Toolchains.html

Typically this is left unset so that Bazel automatically selects the right Node.js toolchain
for the target platform. See https://bazel.build/extending/toolchains#toolchain-resolution
for more information.
2None�
�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2True�
�
unresolved_symlinks_enabled�Whether unresolved symlinks are enabled in the current build configuration.

These are enabled with the --experimental_allow_unresolved_symlinks flag.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
2False�
//js/private:js_binary.bzlrj
,
aspect_rules_js
js/privatejs_binary.bzl,
js_binary_libjs_binary_lib
5B
D!Helper rule for checking coverage�
1
aspect_rules_jsjs/private/test/datadata.bzl�extract"�
�
extract*
nameA unique name for this target. 
single2None";
extract0@@aspect_rules_js//js/private/test/data:data.bzl
,
*
nameA unique name for this target. 

single2None�extract_test"�
�
extract_test*
nameA unique name for this target. 
single2None";
extract0@@aspect_rules_js//js/private/test/data:data.bzl
,
*
nameA unique name for this target. 

single2Noney
//rules:build_test.bzlr]
%
bazel_skylibrulesbuild_test.bzl&

build_test
build_test
.8
:'
Utils for testing js_*() rule outputs
�:
'
aspect_rules_js
js/privatebash.bzl�:	BASH_INITIALIZE_RUNFILES�
# It helps to determine if we are running on a Windows environment (excludes WSL as it acts like Unix)
case "$(uname -s)" in
    CYGWIN*)    _IS_WINDOWS=1 ;;
    MINGW*)     _IS_WINDOWS=1 ;;
    MSYS_NT*)   _IS_WINDOWS=1 ;;
    *)          _IS_WINDOWS=0 ;;
esac

# It helps to normalizes paths when running on Windows.
#
# Example:
# C:/Users/XUser/_bazel_XUser/7q7kkv32/execroot/A/b/C -> /c/Users/XUser/_bazel_XUser/7q7kkv32/execroot/A/b/C
function _normalize_path {
    if [ "$_IS_WINDOWS" -eq "1" ]; then
        # Apply the followings paths transformations to normalize paths on Windows
        # -process driver letter
        # -convert path separator
        sed -e 's#^\(.\):#/\L\1#' -e 's#\\#/#g' <<< "$1"
    else
        echo "$1"
    fi
    return
}

# Set a RUNFILES environment variable to the root of the runfiles tree
# since RUNFILES_DIR is not set by Bazel in all contexts.
# For example, `RUNFILES=/path/to/my_js_binary.sh.runfiles`.
#
# Call this program X. X was generated by a genrule and may be invoked
# in many ways:
#   1a) directly by a user, with $0 in the output tree
#   1b) via 'bazel run' (similar to case 1a)
#   2) directly by a user, with $0 in X's runfiles
#   3) by another program Y which has a data dependency on X, with $0 in Y's
#      runfiles
#   4a) via 'bazel test'
#   4b) case 3 in the context of a test
#   5a) by a genrule cmd, with $0 in the output tree
#   6a) case 3 in the context of a genrule
#
# For case 1, $0 will be a regular file, and the runfiles will be
# at $0.runfiles.
# For case 2 or 3, $0 will be a symlink to the file seen in case 1.
# For case 4, $TEST_SRCDIR should already be set to the runfiles by
# blaze.
# Case 5a is handled like case 1.
# Case 6a is handled like case 3.
if [ "${TEST_SRCDIR:-}" ]; then
    # Case 4, bazel has identified runfiles for us.
    RUNFILES=$(_normalize_path "$TEST_SRCDIR")
elif [ "${RUNFILES_MANIFEST_FILE:-}" ]; then
    RUNFILES=$(_normalize_path "$RUNFILES_MANIFEST_FILE")
    if [[ "${RUNFILES}" == *.runfiles_manifest ]]; then
        # Newer versions of Bazel put the manifest besides the runfiles with the suffix .runfiles_manifest.
        # For example, the runfiles directory is named my_binary.runfiles then the manifest is beside the
        # runfiles directory and named my_binary.runfiles_manifest
        RUNFILES=${RUNFILES%_manifest}
    elif [[ "${RUNFILES}" == */MANIFEST ]]; then
        # Older versions of Bazel put the manifest file named MANIFEST in the runfiles directory
        RUNFILES=${RUNFILES%/MANIFEST}
    else
        logf_fatal "Unexpected RUNFILES_MANIFEST_FILE value $RUNFILES_MANIFEST_FILE"
        exit 1
    fi
else
    case "$0" in
    /*) self="$0" ;;
    *) self="$PWD/$0" ;;
    esac
    while true; do
        if [ -e "$self.runfiles" ]; then
            RUNFILES="$self.runfiles"
            break
        fi

        if [[ "$self" == *.runfiles/* ]]; then
            RUNFILES="${self%%.runfiles/*}.runfiles"
            # don't break; this is a last resort for case 6b
        fi

        if [ ! -L "$self" ]; then
            break;
        fi

        readlink="$(readlink "$self")"
        if [[ "$readlink" == /* ]]; then
            self="$readlink"
        else
            # resolve relative symlink
            self="${self%%/*}/$readlink"
        fi
    done

    if [ -z "${RUNFILES:-}" ]; then
        logf_fatal "RUNFILES environment variable is not set"
        exit 1
    fi

    RUNFILES=$(_normalize_path "$RUNFILES")
fi
if [ "${RUNFILES:0:1}" != "/" ]; then
    # Ensure RUNFILES set above is an absolute path. It may be a path relative
    # to the PWD in case where RUNFILES_MANIFEST_FILE is used above.
    RUNFILES="$PWD/$RUNFILES"
fi
j��
# It helps to determine if we are running on a Windows environment (excludes WSL as it acts like Unix)
case "$(uname -s)" in
    CYGWIN*)    _IS_WINDOWS=1 ;;
    MINGW*)     _IS_WINDOWS=1 ;;
    MSYS_NT*)   _IS_WINDOWS=1 ;;
    *)          _IS_WINDOWS=0 ;;
esac

# It helps to normalizes paths when running on Windows.
#
# Example:
# C:/Users/XUser/_bazel_XUser/7q7kkv32/execroot/A/b/C -> /c/Users/XUser/_bazel_XUser/7q7kkv32/execroot/A/b/C
function _normalize_path {
    if [ "$_IS_WINDOWS" -eq "1" ]; then
        # Apply the followings paths transformations to normalize paths on Windows
        # -process driver letter
        # -convert path separator
        sed -e 's#^\(.\):#/\L\1#' -e 's#\\#/#g' <<< "$1"
    else
        echo "$1"
    fi
    return
}

# Set a RUNFILES environment variable to the root of the runfiles tree
# since RUNFILES_DIR is not set by Bazel in all contexts.
# For example, `RUNFILES=/path/to/my_js_binary.sh.runfiles`.
#
# Call this program X. X was generated by a genrule and may be invoked
# in many ways:
#   1a) directly by a user, with $0 in the output tree
#   1b) via 'bazel run' (similar to case 1a)
#   2) directly by a user, with $0 in X's runfiles
#   3) by another program Y which has a data dependency on X, with $0 in Y's
#      runfiles
#   4a) via 'bazel test'
#   4b) case 3 in the context of a test
#   5a) by a genrule cmd, with $0 in the output tree
#   6a) case 3 in the context of a genrule
#
# For case 1, $0 will be a regular file, and the runfiles will be
# at $0.runfiles.
# For case 2 or 3, $0 will be a symlink to the file seen in case 1.
# For case 4, $TEST_SRCDIR should already be set to the runfiles by
# blaze.
# Case 5a is handled like case 1.
# Case 6a is handled like case 3.
if [ "${TEST_SRCDIR:-}" ]; then
    # Case 4, bazel has identified runfiles for us.
    RUNFILES=$(_normalize_path "$TEST_SRCDIR")
elif [ "${RUNFILES_MANIFEST_FILE:-}" ]; then
    RUNFILES=$(_normalize_path "$RUNFILES_MANIFEST_FILE")
    if [[ "${RUNFILES}" == *.runfiles_manifest ]]; then
        # Newer versions of Bazel put the manifest besides the runfiles with the suffix .runfiles_manifest.
        # For example, the runfiles directory is named my_binary.runfiles then the manifest is beside the
        # runfiles directory and named my_binary.runfiles_manifest
        RUNFILES=${RUNFILES%_manifest}
    elif [[ "${RUNFILES}" == */MANIFEST ]]; then
        # Older versions of Bazel put the manifest file named MANIFEST in the runfiles directory
        RUNFILES=${RUNFILES%/MANIFEST}
    else
        logf_fatal "Unexpected RUNFILES_MANIFEST_FILE value $RUNFILES_MANIFEST_FILE"
        exit 1
    fi
else
    case "$0" in
    /*) self="$0" ;;
    *) self="$PWD/$0" ;;
    esac
    while true; do
        if [ -e "$self.runfiles" ]; then
            RUNFILES="$self.runfiles"
            break
        fi

        if [[ "$self" == *.runfiles/* ]]; then
            RUNFILES="${self%%.runfiles/*}.runfiles"
            # don't break; this is a last resort for case 6b
        fi

        if [ ! -L "$self" ]; then
            break;
        fi

        readlink="$(readlink "$self")"
        if [[ "$readlink" == /* ]]; then
            self="$readlink"
        else
            # resolve relative symlink
            self="${self%%/*}/$readlink"
        fi
    done

    if [ -z "${RUNFILES:-}" ]; then
        logf_fatal "RUNFILES environment variable is not set"
        exit 1
    fi

    RUNFILES=$(_normalize_path "$RUNFILES")
fi
if [ "${RUNFILES:0:1}" != "/" ]; then
    # Ensure RUNFILES set above is an absolute path. It may be a path relative
    # to the PWD in case where RUNFILES_MANIFEST_FILE is used above.
    RUNFILES="$PWD/$RUNFILES"
fi
Bash snippets for js rules�*
2
aspect_rules_js
js/privateexpand_template.bzl�&expand_template�Template expansion with stamp var support.

This performs a simple search over the template file for the keys in substitutions,
and replaces them with the corresponding values.

Values may also use location templates as documented in
[expand_locations](https://github.com/aspect-build/bazel-lib/blob/main/docs/expand_make_vars.md#expand_locations)
as well as [configuration variables](https://docs.bazel.build/versions/main/skylark/lib/ctx.html#var)
such as `$(BINDIR)`, `$(TARGET_CPU)`, and `$(COMPILATION_MODE)` as documented in
[expand_variables](https://github.com/aspect-build/bazel-lib/blob/main/docs/expand_make_vars.md#expand_variables).

If stamp attribute is True, stamp variable substitutions are supported with {{STAMP_VAR}} tokens.
"� 
�
expand_template�Template expansion with stamp var support.

This performs a simple search over the template file for the keys in substitutions,
and replaces them with the corresponding values.

Values may also use location templates as documented in
[expand_locations](https://github.com/aspect-build/bazel-lib/blob/main/docs/expand_make_vars.md#expand_locations)
as well as [configuration variables](https://docs.bazel.build/versions/main/skylark/lib/ctx.html#var)
such as `$(BINDIR)`, `$(TARGET_CPU)`, and `$(COMPILATION_MODE)` as documented in
[expand_variables](https://github.com/aspect-build/bazel-lib/blob/main/docs/expand_make_vars.md#expand_variables).

If stamp attribute is True, stamp variable substitutions are supported with {{STAMP_VAR}} tokens.
*
nameA unique name for this target. @
data2List of targets for additional lookup information.2[]H
is_executable.Whether to mark the output file as executable.2False,
out!Where to write the expanded file. �
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.
2-1�
stamp_substitutions�Mapping of strings to substitutions.

There are overlayed on top of substitutions when stamping is enabled
for the target.

Substitutions can contain $(execpath :target) and $(rootpath :target)
expansions, $(MAKEVAR) expansions and {{STAMP_VAR}} expansions when
stamping is enabled for the target.

2{}�
substitutions�Mapping of strings to substitutions.

Substitutions can contain $(execpath :target) and $(rootpath :target)
expansions, $(MAKEVAR) expansions and {{STAMP_VAR}} expansions when
stamping is enabled for the target.

2{},
templateThe template file to expand. "D
expand_template1@@aspect_rules_js//js/private:expand_template.bzl
ss,
*
nameA unique name for this target. B
@
data2List of targets for additional lookup information.2[]J
H
is_executable.Whether to mark the output file as executable.2False.
,
out!Where to write the expanded file. �
�
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.
2-1�
�
stamp_substitutions�Mapping of strings to substitutions.

There are overlayed on top of substitutions when stamping is enabled
for the target.

Substitutions can contain $(execpath :target) and $(rootpath :target)
expansions, $(MAKEVAR) expansions and {{STAMP_VAR}} expansions when
stamping is enabled for the target.

2{}�
�
substitutions�Mapping of strings to substitutions.

Substitutions can contain $(execpath :target) and $(rootpath :target)
expansions, $(MAKEVAR) expansions and {{STAMP_VAR}} expansions when
stamping is enabled for the target.

2{}.
,
templateThe template file to expand. �
//lib:expand_make_vars.bzlr�
-
aspect_bazel_liblibexpand_make_vars.bzl3
expand_locations_expand_locations
5F3
expand_variables_expand_variables
]n
��
//lib:stamping.bzlr�
%
aspect_bazel_liblibstamping.bzl(
STAMP_ATTRSSTAMP_ATTRS
.9(
maybe_stampmaybe_stamp
=H
Ja
//lib:dicts.bzlrL

bazel_skyliblib	dicts.bzl
dictsdicts
',
.expand_template rule��
,
aspect_rules_js
js/privatejs_binary.bzl�	js_binary�Execute a program in the Node.js runtime.

The version of Node.js is determined by Bazel's toolchain selection. In the WORKSPACE you used
`nodejs_register_toolchains` to provide options to Bazel. Then Bazel selects from these options
based on the requested target platform. Use the
[`--toolchain_resolution_debug`](https://docs.bazel.build/versions/main/command-line-reference.html#flag--toolchain_resolution_debug)
Bazel option to see more detail about the selection.

All [common binary attributes](https://bazel.build/reference/be/common-definitions#common-attributes-binaries) are supported
including `args` as the list of arguments passed Node.js.

The following environment variables are made available to the Node.js runtime based on available Bazel [Make variables](https://bazel.build/reference/be/make-variables#predefined_variables):

* JS_BINARY__BINDIR: the WORKSPACE-relative Bazel bin directory; equivalent to the `$(BINDIR)` Make variable of the `js_binary` target
* JS_BINARY__COMPILATION_MODE: One of `fastbuild`, `dbg`, or `opt` as set by [`--compilation_mode`](https://bazel.build/docs/user-manual#compilation-mode); equivalent to `$(COMPILATION_MODE)` Make variable of the `js_binary` target
* JS_BINARY__TARGET_CPU: the target cpu architecture; equivalent to `$(TARGET_CPU)` Make variable of the `js_binary` target

The following environment variables are made available to the Node.js runtime based on the rule context:

* JS_BINARY__BUILD_FILE_PATH: the WORKSPACE-relative path to the BUILD file of the Bazel target being run; equivalent to `ctx.build_file_path` of the `js_binary` target's rule context
* JS_BINARY__PACKAGE: the package of the Bazel target being run; equivalent to `ctx.label.package` of the `js_binary` target's rule context
* JS_BINARY__TARGET: the full label of the Bazel target being run; a stringified version of `ctx.label` of the `js_binary` target's rule context
* JS_BINARY__TARGET_NAME: the name of the Bazel target being run; equivalent to `ctx.label.name` of the `js_binary` target's rule context
* JS_BINARY__WORKSPACE: the Bazel workspace name; equivalent to `ctx.workspace_name` of the `js_binary` target's rule context

The following environment variables are made available to the Node.js runtime based the runtime environment:

* JS_BINARY__NODE_BINARY: the Node.js binary path run by the `js_binary` target
* JS_BINARY__NPM_BINARY: the npm binary path; this is available when [`include_npm`](https://docs.aspect.build/rules/aspect_rules_js/docs/js_binary#include_npm) is `True` on the `js_binary` target
* JS_BINARY__NODE_WRAPPER: the Node.js wrapper script used to run Node.js which is available as `node` on the `PATH` at runtime
* JS_BINARY__RUNFILES: the absolute path to the Bazel runfiles directory
* JS_BINARY__EXECROOT: the absolute path to the root of the execution root for the action; if in the sandbox, this path absolute path to the root of the execution root within the sandbox

This rules requires that Bazel was run with
[`--enable_runfiles`](https://docs.bazel.build/versions/main/command-line-reference.html#flag--enable_runfiles). 
"��
�\
	js_binary�Execute a program in the Node.js runtime.

The version of Node.js is determined by Bazel's toolchain selection. In the WORKSPACE you used
`nodejs_register_toolchains` to provide options to Bazel. Then Bazel selects from these options
based on the requested target platform. Use the
[`--toolchain_resolution_debug`](https://docs.bazel.build/versions/main/command-line-reference.html#flag--toolchain_resolution_debug)
Bazel option to see more detail about the selection.

All [common binary attributes](https://bazel.build/reference/be/common-definitions#common-attributes-binaries) are supported
including `args` as the list of arguments passed Node.js.

The following environment variables are made available to the Node.js runtime based on available Bazel [Make variables](https://bazel.build/reference/be/make-variables#predefined_variables):

* JS_BINARY__BINDIR: the WORKSPACE-relative Bazel bin directory; equivalent to the `$(BINDIR)` Make variable of the `js_binary` target
* JS_BINARY__COMPILATION_MODE: One of `fastbuild`, `dbg`, or `opt` as set by [`--compilation_mode`](https://bazel.build/docs/user-manual#compilation-mode); equivalent to `$(COMPILATION_MODE)` Make variable of the `js_binary` target
* JS_BINARY__TARGET_CPU: the target cpu architecture; equivalent to `$(TARGET_CPU)` Make variable of the `js_binary` target

The following environment variables are made available to the Node.js runtime based on the rule context:

* JS_BINARY__BUILD_FILE_PATH: the WORKSPACE-relative path to the BUILD file of the Bazel target being run; equivalent to `ctx.build_file_path` of the `js_binary` target's rule context
* JS_BINARY__PACKAGE: the package of the Bazel target being run; equivalent to `ctx.label.package` of the `js_binary` target's rule context
* JS_BINARY__TARGET: the full label of the Bazel target being run; a stringified version of `ctx.label` of the `js_binary` target's rule context
* JS_BINARY__TARGET_NAME: the name of the Bazel target being run; equivalent to `ctx.label.name` of the `js_binary` target's rule context
* JS_BINARY__WORKSPACE: the Bazel workspace name; equivalent to `ctx.workspace_name` of the `js_binary` target's rule context

The following environment variables are made available to the Node.js runtime based the runtime environment:

* JS_BINARY__NODE_BINARY: the Node.js binary path run by the `js_binary` target
* JS_BINARY__NPM_BINARY: the npm binary path; this is available when [`include_npm`](https://docs.aspect.build/rules/aspect_rules_js/docs/js_binary#include_npm) is `True` on the `js_binary` target
* JS_BINARY__NODE_WRAPPER: the Node.js wrapper script used to run Node.js which is available as `node` on the `PATH` at runtime
* JS_BINARY__RUNFILES: the absolute path to the Bazel runfiles directory
* JS_BINARY__EXECROOT: the absolute path to the root of the execution root for the action; if in the sandbox, this path absolute path to the root of the execution root within the sandbox

This rules requires that Bazel was run with
[`--enable_runfiles`](https://docs.bazel.build/versions/main/command-line-reference.html#flag--enable_runfiles). 
*
nameA unique name for this target. �
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/"))) + "$(rootpath //path/to/some:file)"],
)
```2""�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

NB: `data` files are copied to the Bazel output tree before being passed
as inputs to runfiles. See `copy_data_to_bin` docstring for more info.
2[]�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/aspect-build/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 �
env�Environment variables of the action.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution.

2{}i
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�

fixed_args�Fixed command line arguments to pass to the Node.js when this
binary target is executed.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution.

Unlike the built-in `args`, which are only passed to the target when it is
executed either by the `bazel run` command or as a test, `fixed_args` are baked
into the generated launcher script so are always passed even when the binary
target is run outside of Bazel directly from the launcher script.

`fixed_args` are passed before the ones specified in `args` and before ones
that are specified on the `bazel run` or `bazel test` command line.

See https://bazel.build/reference/be/common-definitions#common-attributes-binaries
for more info on the built-in `args` attribute.
2[]�
include_declarations�When True, `declarations` and `transitive_declarations` from `JsInfo` providers in data targets are included in the runfiles of the target.

Defaults to false since declarations are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
include_npm_linked_packages�When True, files in `npm_linked_packages` and `transitive_npm_linked_packages` from `JsInfo` providers in data targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in data targets are also included in the runfiles of the target.
2True�
include_transitive_sourcessWhen True, `transitive_sources` from `JsInfo` providers in data targets are included in the runfiles of the target.2True�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.

Log levels: fatal, error, warn, info, debug2"error"�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
node_toolchain�The Node.js toolchain to use for this target.

See https://bazelbuild.github.io/rules_nodejs/Toolchains.html

Typically this is left unset so that Bazel automatically selects the right Node.js toolchain
for the target platform. See https://bazel.build/extending/toolchains#toolchain-resolution
for more information.
2None�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2True�
unresolved_symlinks_enabled�Whether unresolved symlinks are enabled in the current build configuration.

These are enabled with the --experimental_allow_unresolved_symlinks flag.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
2False"8
	js_binary+@@aspect_rules_js//js/private:js_binary.bzl
��,
*
nameA unique name for this target. �
�
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/"))) + "$(rootpath //path/to/some:file)"],
)
```2""�
�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

NB: `data` files are copied to the Bazel output tree before being passed
as inputs to runfiles. See `copy_data_to_bin` docstring for more info.
2[]�
�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
�
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/aspect-build/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 �
�
env�Environment variables of the action.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution.

2{}k
i
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�
�

fixed_args�Fixed command line arguments to pass to the Node.js when this
binary target is executed.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution.

Unlike the built-in `args`, which are only passed to the target when it is
executed either by the `bazel run` command or as a test, `fixed_args` are baked
into the generated launcher script so are always passed even when the binary
target is run outside of Bazel directly from the launcher script.

`fixed_args` are passed before the ones specified in `args` and before ones
that are specified on the `bazel run` or `bazel test` command line.

See https://bazel.build/reference/be/common-definitions#common-attributes-binaries
for more info on the built-in `args` attribute.
2[]�
�
include_declarations�When True, `declarations` and `transitive_declarations` from `JsInfo` providers in data targets are included in the runfiles of the target.

Defaults to false since declarations are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
�
include_npm_linked_packages�When True, files in `npm_linked_packages` and `transitive_npm_linked_packages` from `JsInfo` providers in data targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in data targets are also included in the runfiles of the target.
2True�
�
include_transitive_sourcessWhen True, `transitive_sources` from `JsInfo` providers in data targets are included in the runfiles of the target.2True�
�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.

Log levels: fatal, error, warn, info, debug2"error"�
�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
�
node_toolchain�The Node.js toolchain to use for this target.

See https://bazelbuild.github.io/rules_nodejs/Toolchains.html

Typically this is left unset so that Bazel automatically selects the right Node.js toolchain
for the target platform. See https://bazel.build/extending/toolchains#toolchain-resolution
for more information.
2None�
�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2True�
�
unresolved_symlinks_enabled�Whether unresolved symlinks are enabled in the current build configuration.

These are enabled with the --experimental_allow_unresolved_symlinks flag.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
2False��js_test�Identical to js_binary, but usable under `bazel test`.

All [common test attributes](https://bazel.build/reference/be/common-definitions#common-attributes-tests) are
supported including `args` as the list of arguments passed Node.js.

Bazel will set environment variables when a test target is run under `bazel test` and `bazel run`
that a test runner can use.

A runner can write arbitrary outputs files it wants Bazel to pickup and save with the test logs to
`TEST_UNDECLARED_OUTPUTS_DIR`. These get zipped up and saved along with the test logs.

JUnit XML reports can be written to `XML_OUTPUT_FILE` for Bazel to consume.

`TEST_TMPDIR` is an absolute path to a private writeable directory that the test runner can use for
creating temporary files.

LCOV coverage reports can be written to `COVERAGE_OUTPUT_FILE` when running under `bazel coverage`
or if the `--coverage` flag is set.

See the Bazel [Test encyclopedia](https://bazel.build/reference/test-encyclopedia) for details on
the contract between Bazel and a test runner."��
�L
js_test�Identical to js_binary, but usable under `bazel test`.

All [common test attributes](https://bazel.build/reference/be/common-definitions#common-attributes-tests) are
supported including `args` as the list of arguments passed Node.js.

Bazel will set environment variables when a test target is run under `bazel test` and `bazel run`
that a test runner can use.

A runner can write arbitrary outputs files it wants Bazel to pickup and save with the test logs to
`TEST_UNDECLARED_OUTPUTS_DIR`. These get zipped up and saved along with the test logs.

JUnit XML reports can be written to `XML_OUTPUT_FILE` for Bazel to consume.

`TEST_TMPDIR` is an absolute path to a private writeable directory that the test runner can use for
creating temporary files.

LCOV coverage reports can be written to `COVERAGE_OUTPUT_FILE` when running under `bazel coverage`
or if the `--coverage` flag is set.

See the Bazel [Test encyclopedia](https://bazel.build/reference/test-encyclopedia) for details on
the contract between Bazel and a test runner.*
nameA unique name for this target. �
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/"))) + "$(rootpath //path/to/some:file)"],
)
```2""�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

NB: `data` files are copied to the Bazel output tree before being passed
as inputs to runfiles. See `copy_data_to_bin` docstring for more info.
2[]�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/aspect-build/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 �
env�Environment variables of the action.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution.

2{}i
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�

fixed_args�Fixed command line arguments to pass to the Node.js when this
binary target is executed.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution.

Unlike the built-in `args`, which are only passed to the target when it is
executed either by the `bazel run` command or as a test, `fixed_args` are baked
into the generated launcher script so are always passed even when the binary
target is run outside of Bazel directly from the launcher script.

`fixed_args` are passed before the ones specified in `args` and before ones
that are specified on the `bazel run` or `bazel test` command line.

See https://bazel.build/reference/be/common-definitions#common-attributes-binaries
for more info on the built-in `args` attribute.
2[]�
include_declarations�When True, `declarations` and `transitive_declarations` from `JsInfo` providers in data targets are included in the runfiles of the target.

Defaults to false since declarations are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
include_npm_linked_packages�When True, files in `npm_linked_packages` and `transitive_npm_linked_packages` from `JsInfo` providers in data targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in data targets are also included in the runfiles of the target.
2True�
include_transitive_sourcessWhen True, `transitive_sources` from `JsInfo` providers in data targets are included in the runfiles of the target.2True�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.

Log levels: fatal, error, warn, info, debug2"error"�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
node_toolchain�The Node.js toolchain to use for this target.

See https://bazelbuild.github.io/rules_nodejs/Toolchains.html

Typically this is left unset so that Bazel automatically selects the right Node.js toolchain
for the target platform. See https://bazel.build/extending/toolchains#toolchain-resolution
for more information.
2None�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2True�
unresolved_symlinks_enabled�Whether unresolved symlinks are enabled in the current build configuration.

These are enabled with the --experimental_allow_unresolved_symlinks flag.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
2False"6
js_test+@@aspect_rules_js//js/private:js_binary.bzl
��,
*
nameA unique name for this target. �
�
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/"))) + "$(rootpath //path/to/some:file)"],
)
```2""�
�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

NB: `data` files are copied to the Bazel output tree before being passed
as inputs to runfiles. See `copy_data_to_bin` docstring for more info.
2[]�
�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
�
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/aspect-build/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 �
�
env�Environment variables of the action.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution.

2{}k
i
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�
�

fixed_args�Fixed command line arguments to pass to the Node.js when this
binary target is executed.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution.

Unlike the built-in `args`, which are only passed to the target when it is
executed either by the `bazel run` command or as a test, `fixed_args` are baked
into the generated launcher script so are always passed even when the binary
target is run outside of Bazel directly from the launcher script.

`fixed_args` are passed before the ones specified in `args` and before ones
that are specified on the `bazel run` or `bazel test` command line.

See https://bazel.build/reference/be/common-definitions#common-attributes-binaries
for more info on the built-in `args` attribute.
2[]�
�
include_declarations�When True, `declarations` and `transitive_declarations` from `JsInfo` providers in data targets are included in the runfiles of the target.

Defaults to false since declarations are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
�
include_npm_linked_packages�When True, files in `npm_linked_packages` and `transitive_npm_linked_packages` from `JsInfo` providers in data targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in data targets are also included in the runfiles of the target.
2True�
�
include_transitive_sourcessWhen True, `transitive_sources` from `JsInfo` providers in data targets are included in the runfiles of the target.2True�
�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.

Log levels: fatal, error, warn, info, debug2"error"�
�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
�
node_toolchain�The Node.js toolchain to use for this target.

See https://bazelbuild.github.io/rules_nodejs/Toolchains.html

Typically this is left unset so that Bazel automatically selects the right Node.js toolchain
for the target platform. See https://bazel.build/extending/toolchains#toolchain-resolution
for more information.
2None�
�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2True�
�
unresolved_symlinks_enabled�Whether unresolved symlinks are enabled in the current build configuration.

These are enabled with the --experimental_allow_unresolved_symlinks flag.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
2False�
//lib:directory_path.bzlrq
+
aspect_bazel_liblibdirectory_path.bzl4
DirectoryPathInfoDirectoryPathInfo
4E
G�
//lib:expand_make_vars.bzlr�
-
aspect_bazel_liblibexpand_make_vars.bzl2
expand_locationsexpand_locations
6F2
expand_variablesexpand_variables
JZ
\�
//lib:utils.bzlrp
"
aspect_bazel_liblib	utils.bzl<
is_bazel_6_or_greateris_bazel_6_or_greater
+@
B�
//lib:windows_utils.bzlr�
*
aspect_bazel_liblibwindows_utils.bzl\
%create_windows_native_launcher_script%create_windows_native_launcher_script
3X
Z�
//js/private:bash.bzlr{
'
aspect_rules_js
js/privatebash.bzlB
BASH_INITIALIZE_RUNFILESBASH_INITIALIZE_RUNFILES
0H
J�
//js/private:js_helpers.bzlr�
-
aspect_rules_js
js/privatejs_helpers.bzl&

LOG_LEVELS
LOG_LEVELS
6@6
envs_for_log_levelenvs_for_log_level
DV0
gather_runfilesgather_runfiles
Zi
ka
//lib:dicts.bzlrL

bazel_skyliblib	dicts.bzl
dictsdicts
',
.�Rules for running JavaScript programs under Bazel, as tools or with `bazel run` or `bazel test`.

For example, this binary references the `acorn` npm package which was already linked
using an API like `npm_link_all_packages`.

```starlark
load("@aspect_rules_js//js:defs.bzl", "js_binary", "js_test")

js_binary(
    name = "bin",
    # Reference the location where the acorn npm module was linked in the root Bazel package
    data = ["//:node_modules/acorn"],
    entry_point = "require_acorn.js",
)
```
�
/
aspect_rules_js
js/privatejs_filegroup.bzl�js_filegroup�Gathers files from the JsInfo providers from targets in srcs and provides them as default outputs.

This helper rule is used by the `js_run_binary` macro.
"�
�	
js_filegroup�Gathers files from the JsInfo providers from targets in srcs and provides them as default outputs.

This helper rule is used by the `js_run_binary` macro.
*
nameA unique name for this target. �
include_declarations�When True, `declarations` and `transitive_declarations` from `JsInfo` providers in srcs targets are included in the default outputs of the target.

Defaults to false since declarations are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
include_npm_linked_packages�When True, files in `npm_linked_packages` and `transitive_npm_linked_packages` from `JsInfo` providers in srcs targets are included in the default outputs of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in data targets are also included in the default outputs of the target.
2True�
include_transitive_sources|When True, `transitive_sources` from `JsInfo` providers in `srcs` targets are included in the default outputs of the target.2True3
srcs%List of targets to gather files from.2[]">
js_filegroup.@@aspect_rules_js//js/private:js_filegroup.bzl
,
*
nameA unique name for this target. �
�
include_declarations�When True, `declarations` and `transitive_declarations` from `JsInfo` providers in srcs targets are included in the default outputs of the target.

Defaults to false since declarations are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
�
include_npm_linked_packages�When True, files in `npm_linked_packages` and `transitive_npm_linked_packages` from `JsInfo` providers in srcs targets are included in the default outputs of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in data targets are also included in the default outputs of the target.
2True�
�
include_transitive_sources|When True, `transitive_sources` from `JsInfo` providers in `srcs` targets are included in the default outputs of the target.2True5
3
srcs%List of targets to gather files from.2[]�
//js/private:js_helpers.bzlr�
-
aspect_rules_js
js/privatejs_helpers.bzlO
gather_files_from_js_providers_gather_files_from_js_providers
5T
x`Helper rule to gather files from JsInfo providers of targets and provide them as default outputs�C
-
aspect_rules_js
js/privatejs_helpers.bzl�copy_js_file_to_bin_action*�

copy_js_file_to_bin_action	
ctx (

file (2J
copy_js_file_to_bin_action,@@aspect_rules_js//js/private:js_helpers.bzl
���envs_for_log_levelAReturns a list environment variables to set for a given log level*�
�
envs_for_log_level+
	log_levelThe log level string value (AReturns a list environment variables to set for a given log level"�
�A list of environment variables to set to turn on the js_binary runtime
logs for the given log level. Typically, they are each set to "1".2B
envs_for_log_level,@@aspect_rules_js//js/private:js_helpers.bzl
���gather_files_from_js_providers<Gathers files from JsInfo and NpmPackageStoreInfo providers.*�
�
gather_files_from_js_providers,
targetslist of target to gather from (@
include_transitive_sourcessee js_filegroup documentation (:
include_declarationssee js_filegroup documentation (A
include_npm_linked_packagessee js_filegroup documentation (<Gathers files from JsInfo and NpmPackageStoreInfo providers."
A depset of files2N
gather_files_from_js_providers,@@aspect_rules_js//js/private:js_helpers.bzl
���gather_npm_linked_packages@Gathers npm linked packages from a list of srcs and deps targets*�
�
gather_npm_linked_packagesc
srcsWsource targets; these typically come from the `srcs` and/or `data` attributes of a rule (Q
depsEdep targets; these typically come from the `deps` attribute of a rule (@Gathers npm linked packages from a list of srcs and deps targets"�
�A `struct(direct, direct_files, transitive, transitive_files)` of direct and transitive npm linked packages & underlying files gathered2J
gather_npm_linked_packages,@@aspect_rules_js//js/private:js_helpers.bzl
LL�gather_npm_package_store_deps>Gathers NpmPackageStoreInfo providers from the list of targets*�
�
gather_npm_package_store_deps1
targets"the list of targets to gather from (>Gathers NpmPackageStoreInfo providers from the list of targets")
'A depset of npm package stores gathered2M
gather_npm_package_store_deps,@@aspect_rules_js//js/private:js_helpers.bzl
zz�gather_runfiles�Creates a runfiles object containing files in `sources`, default outputs from `data` and transitive runfiles from `data` & `deps`.

As a defense in depth against `data` & `deps` targets not supplying all required runfiles, also
gathers the transitive sources & transitive npm linked packages from the `JsInfo` &
`NpmPackageStoreInfo` providers of `data` & `deps` targets.

See https://bazel.build/extending/rules#runfiles for more info on providing runfiles in build rules.
*�
�
gather_runfiles
ctxthe rule context (K
sources<list or depset of files which should be included in runfiles (�
data�list of data targets; default outputs and transitive runfiles are gather from these targets

See https://bazel.build/reference/be/common-definitions#typical.data and
https://bazel.build/concepts/dependencies#data-dependencies for more info and guidance
on common usage of the `data` attribute in build rules. (^
depsRlist of dependency targets; only transitive runfiles are gather from these targets (�

data_files�a list of data files which should be included in runfiles

Data files that are source files are copied to the Bazel output tree when
`copy_data_files_to_bin` is set to `True`.[](�
copy_data_files_to_binWhen True, `data` files that are source files and are copied to the
Bazel output tree before being passed to returned runfiles.False(�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_data_files_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_files_to_bin` docstring for more info.[](D
include_transitive_sourcessee js_filegroup documentationTrue(?
include_declarationssee js_filegroup documentationFalse(E
include_npm_linked_packagessee js_filegroup documentationTrue(�Creates a runfiles object containing files in `sources`, default outputs from `data` and transitive runfiles from `data` & `deps`.

As a defense in depth against `data` & `deps` targets not supplying all required runfiles, also
gathers the transitive sources & transitive npm linked packages from the `JsInfo` &
`NpmPackageStoreInfo` providers of `data` & `deps` targets.

See https://bazel.build/extending/rules#runfiles for more info on providing runfiles in build rules.
"�
�A [runfiles](https://bazel.build/rules/lib/runfiles) object created with [ctx.runfiles](https://bazel.build/rules/lib/ctx#runfiles).2?
gather_runfiles,@@aspect_rules_js//js/private:js_helpers.bzl
���gather_transitive_declarationsDGathers transitive sources from a list of direct sources and targets*�
�
gather_transitive_declarationsj
declarationsVlist or depset of direct sources which should be included in `transitive_declarations` (P
targetsAList of targets to gather `transitive_declarations` from `JsInfo` (DGathers transitive sources from a list of direct sources and targets" 
A depset of transitive sources2N
gather_transitive_declarations,@@aspect_rules_js//js/private:js_helpers.bzl
99�gather_transitive_sourcesDGathers transitive sources from a list of direct sources and targets*�
�
gather_transitive_sources`
sourcesQlist or depset of direct sources which should be included in `transitive_sources` (K
targets<list of targets to gather `transitive_sources` from `JsInfo` (DGathers transitive sources from a list of direct sources and targets" 
A depset of transitive sources2I
gather_transitive_sources,@@aspect_rules_js//js/private:js_helpers.bzl
&&�
//lib:copy_to_bin.bzlrz
(
aspect_bazel_liblibcopy_to_bin.bzl@
copy_file_to_bin_actioncopy_file_to_bin_action
1H
Jx
//js/private:js_info.bzlrZ
*
aspect_rules_js
js/privatejs_info.bzl
JsInfoJsInfo
39
;�
//npm:providers.bzlro
%
aspect_rules_jsnpmproviders.bzl8
NpmPackageStoreInfoNpmPackageStoreInfo
.A
C�	$DOWNSTREAM_LINKED_NPM_DEPS_DOCSTRING�If this list contains linked npm packages, npm package store targets or other targets that provide
`JsInfo`, `NpmPackageStoreInfo` providers are gathered from `JsInfo`. This is done directly from
the `npm_package_store_deps` field of these. For linked npm package targets, the underlying
`npm_package_store` target(s) that back the links is used. Gathered `NpmPackageStoreInfo`
providers are propagated to the direct dependencies of downstream linked `npm_package` targets.

NB: Linked npm package targets that are "dev" dependencies do not forward their underlying
`npm_package_store` target(s) through `npm_package_store_deps` and will therefore not be
propagated to the direct dependencies of downstream linked `npm_package` targets. npm packages
that come in from `npm_translate_lock` are considered "dev" dependencies if they are have
`dev: true` set in the pnpm lock file. This should be all packages that are only listed as
"devDependencies" in all `package.json` files within the pnpm workspace. This behavior is
intentional to mimic how `devDependencies` work in published npm packages.
j��If this list contains linked npm packages, npm package store targets or other targets that provide
`JsInfo`, `NpmPackageStoreInfo` providers are gathered from `JsInfo`. This is done directly from
the `npm_package_store_deps` field of these. For linked npm package targets, the underlying
`npm_package_store` target(s) that back the links is used. Gathered `NpmPackageStoreInfo`
providers are propagated to the direct dependencies of downstream linked `npm_package` targets.

NB: Linked npm package targets that are "dev" dependencies do not forward their underlying
`npm_package_store` target(s) through `npm_package_store_deps` and will therefore not be
propagated to the direct dependencies of downstream linked `npm_package` targets. npm packages
that come in from `npm_translate_lock` are considered "dev" dependencies if they are have
`dev: true` set in the pnpm lock file. This should be all packages that are only listed as
"devDependencies" in all `package.json` files within the pnpm workspace. This behavior is
intentional to mimic how `devDependencies` work in published npm packages.
`js_library` helper functions.
�B
1
aspect_rules_js
js/privatejs_image_layer.bzl�>js_image_layer�Create container image layers from js_binary targets.

By design, js_image_layer doesn't have any preference over which rule assembles the container image. 
This means the downstream rule (`oci_image`, or `container_image` in this case) must set a proper `workdir` and `cmd` to for the container work.
A proper `cmd` usually looks like /`[ root of js_image_layer ]`/`[ relative path to BUILD file from WORKSPACE or package_name() ]/[ name of js_binary ]`, 
unless you have a launcher script that invokes the entry_point of the `js_binary` in a different path.
On the other hand, `workdir` has to be set to `runfiles tree root` which would be exactly `cmd` **but with `.runfiles/[ name of the workspace or __main__ if empty ]` suffix**. If `workdir` is not set correctly, some
attributes such as `chdir` might not work properly.

js_image_layer supports transitioning to specific `platform` to allow building multi-platform container images.

**A partial example using rules_oci with transition to linux/amd64 platform.**

```starlark
load("@aspect_rules_js//js:defs.bzl", "js_binary", "js_image_layer")
load("@rules_oci//oci:defs.bzl", "oci_image")

js_binary(
    name = "binary",
    entry_point = "main.js",
)

platform(
    name = "amd64_linux",
    constraint_values = [
        "@platforms//os:linux",
        "@platforms//cpu:x86_64",
    ],
)

js_image_layer(
    name = "layers",
    binary = ":binary",
    platform = ":amd64_linux",
    root = "/app"
)

oci_image(
    name = "image",
    cmd = ["/app/main"],
    entrypoint = ["bash"],
    tars = [
        ":layers"
    ]
)
```

**A partial example using rules_oci to create multi-platform images.**


```starlark
load("@aspect_rules_js//js:defs.bzl", "js_binary", "js_image_layer")
load("@rules_oci//oci:defs.bzl", "oci_image", "oci_image_index")

js_binary(
    name = "binary",
    entry_point = "main.js",
)

[
    platform(
        name = "linux_{}".format(arch),
        constraint_values = [
            "@platforms//os:linux",
            "@platforms//cpu:{}".format(arch if arch != "amd64" else "x86_64"),
        ],
    )
    js_image_layer(
        name = "{}_layers".format(arch),
        binary = ":binary",
        platform = ":linux_{arch}",
        root = "/app"
    )
    oci_image(
        name = "{}_image".format(arch),
        cmd = ["/app/main"],
        entrypoint = ["bash"],
        tars = [
            ":{}_layers".format(arch)
        ]
    )
    for arch in ["amd64", "arm64"]
]

oci_image_index(
    name = "image",
    images = [
        ":arm64_image",
        ":amd64_image"
    ]
)

```

**An example using legacy rules_docker**

See `e2e/js_image_rules_docker` for full example.

```starlark
load("@aspect_rules_js//js:defs.bzl", "js_binary", "js_image_layer")
load("@io_bazel_rules_docker//container:container.bzl", "container_image")

js_binary(
    name = "main",
    data = [
        "//:node_modules/args-parser",
    ],
    entry_point = "main.js",
)


js_image_layer(
    name = "layers",
    binary = ":main",
    root = "/app",
    visibility = ["//visibility:__pkg__"],
)

filegroup(
    name = "app_tar", 
    srcs = [":layers"], 
    output_group = "app"
)
container_layer(
    name = "app_layer",
    tars = [":app_tar"],
)

filegroup(
    name = "node_modules_tar", 
    srcs = [":layers"], 
    output_group = "node_modules"
)
container_layer(
    name = "node_modules_layer",
    tars = [":node_modules_tar"],
)

container_image(
    name = "image",
    cmd = ["/app/main"],
    entrypoint = ["bash"],
    layers = [
        ":app_layer",
        ":node_modules_layer",
    ],
)
```
"�!
�
js_image_layer�Create container image layers from js_binary targets.

By design, js_image_layer doesn't have any preference over which rule assembles the container image. 
This means the downstream rule (`oci_image`, or `container_image` in this case) must set a proper `workdir` and `cmd` to for the container work.
A proper `cmd` usually looks like /`[ root of js_image_layer ]`/`[ relative path to BUILD file from WORKSPACE or package_name() ]/[ name of js_binary ]`, 
unless you have a launcher script that invokes the entry_point of the `js_binary` in a different path.
On the other hand, `workdir` has to be set to `runfiles tree root` which would be exactly `cmd` **but with `.runfiles/[ name of the workspace or __main__ if empty ]` suffix**. If `workdir` is not set correctly, some
attributes such as `chdir` might not work properly.

js_image_layer supports transitioning to specific `platform` to allow building multi-platform container images.

**A partial example using rules_oci with transition to linux/amd64 platform.**

```starlark
load("@aspect_rules_js//js:defs.bzl", "js_binary", "js_image_layer")
load("@rules_oci//oci:defs.bzl", "oci_image")

js_binary(
    name = "binary",
    entry_point = "main.js",
)

platform(
    name = "amd64_linux",
    constraint_values = [
        "@platforms//os:linux",
        "@platforms//cpu:x86_64",
    ],
)

js_image_layer(
    name = "layers",
    binary = ":binary",
    platform = ":amd64_linux",
    root = "/app"
)

oci_image(
    name = "image",
    cmd = ["/app/main"],
    entrypoint = ["bash"],
    tars = [
        ":layers"
    ]
)
```

**A partial example using rules_oci to create multi-platform images.**


```starlark
load("@aspect_rules_js//js:defs.bzl", "js_binary", "js_image_layer")
load("@rules_oci//oci:defs.bzl", "oci_image", "oci_image_index")

js_binary(
    name = "binary",
    entry_point = "main.js",
)

[
    platform(
        name = "linux_{}".format(arch),
        constraint_values = [
            "@platforms//os:linux",
            "@platforms//cpu:{}".format(arch if arch != "amd64" else "x86_64"),
        ],
    )
    js_image_layer(
        name = "{}_layers".format(arch),
        binary = ":binary",
        platform = ":linux_{arch}",
        root = "/app"
    )
    oci_image(
        name = "{}_image".format(arch),
        cmd = ["/app/main"],
        entrypoint = ["bash"],
        tars = [
            ":{}_layers".format(arch)
        ]
    )
    for arch in ["amd64", "arm64"]
]

oci_image_index(
    name = "image",
    images = [
        ":arm64_image",
        ":amd64_image"
    ]
)

```

**An example using legacy rules_docker**

See `e2e/js_image_rules_docker` for full example.

```starlark
load("@aspect_rules_js//js:defs.bzl", "js_binary", "js_image_layer")
load("@io_bazel_rules_docker//container:container.bzl", "container_image")

js_binary(
    name = "main",
    data = [
        "//:node_modules/args-parser",
    ],
    entry_point = "main.js",
)


js_image_layer(
    name = "layers",
    binary = ":main",
    root = "/app",
    visibility = ["//visibility:__pkg__"],
)

filegroup(
    name = "app_tar", 
    srcs = [":layers"], 
    output_group = "app"
)
container_layer(
    name = "app_layer",
    tars = [":app_tar"],
)

filegroup(
    name = "node_modules_tar", 
    srcs = [":layers"], 
    output_group = "node_modules"
)
container_layer(
    name = "node_modules_layer",
    tars = [":node_modules_tar"],
)

container_image(
    name = "image",
    cmd = ["/app/main"],
    entrypoint = ["bash"],
    layers = [
        ":app_layer",
        ":node_modules_layer",
    ],
)
```
*
nameA unique name for this target. *
binaryLabel to an js_binary target M
compression4Compression algorithm. Can be one of `gzip`, `none`.2"gzip"+
platformPlatform to transition.2NoneX
rootJPath where the files from js_binary will reside in. eg: /apps/app1 or /app2"""B
js_image_layer0@@aspect_rules_js//js/private:js_image_layer.bzl
��,
*
nameA unique name for this target. ,
*
binaryLabel to an js_binary target O
M
compression4Compression algorithm. Can be one of `gzip`, `none`.2"gzip"-
+
platformPlatform to transition.2NoneZ
X
rootJPath where the files from js_binary will reside in. eg: /apps/app1 or /app2""{
//lib:paths.bzlrf
"
aspect_bazel_liblib	paths.bzl2
to_manifest_pathto_manifest_path
+;
=a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.�Rules for creating container image layers from js_binary targets

For example, this js_image_layer target outputs `node_modules.tar` and `app.tar` with `/app` prefix.

```starlark
load("@aspect_rules_js//js:defs.bzl", "js_image_layer")

js_image_layer(
    name = "layers",
    binary = "//label/to:js_binary",
    root = "/app",
)
```
�
*
aspect_rules_js
js/privatejs_info.bzl�js_infoConstruct a JsInfo.*�
�
js_info6
declarationsSee JsInfo documentation
depset([])(B
npm_linked_package_filesSee JsInfo documentation
depset([])(=
npm_linked_packagesSee JsInfo documentation
depset([])(@
npm_package_store_depsSee JsInfo documentation
depset([])(1
sourcesSee JsInfo documentation
depset([])(A
transitive_declarationsSee JsInfo documentation
depset([])(M
#transitive_npm_linked_package_filesSee JsInfo documentation
depset([])(H
transitive_npm_linked_packagesSee JsInfo documentation
depset([])(<
transitive_sourcesSee JsInfo documentation
depset([])(Construct a JsInfo."
A JsInfo provider24
js_info)@@aspect_rules_js//js/private:js_info.bzl
�JsInfoOEncapsulates information provided by rules in rules_js and derivative rule sets2�
�	
JsInfoOEncapsulates information provided by rules in rules_js and derivative rule setsD
declarations4A depset of declaration files produced by the target_
npm_linked_package_filesCA depset of files in npm linked package dependencies of this targetf
npm_linked_packagesOA depset of NpmLinkedPackageInfo providers that are dependencies of this target�
npm_package_store_deps�A depset of NpmPackageStoreInfo providers from non-dev npm dependencies of this target and the target's transitive dependencies to use as direct dependencies when linking downstream npm_package targets with npm_link_package:
sources/A depset of source files produced by the targetp
transitive_declarationsUA depset of declaration files produced by the target and the target's transitive deps�
#transitive_npm_linked_package_filesdA depset of files in npm linked package dependencies of this target and the target's transitive deps�
transitive_npm_linked_packagespA depset of NpmLinkedPackageInfo providers that are dependencies of this target and the target's transitive depsf
transitive_sourcesPA depset of source files produced by the target and the target's transitive deps"3
JsInfo)@@aspect_rules_js//js/private:js_info.bzl
F
D
declarations4A depset of declaration files produced by the targeta
_
npm_linked_package_filesCA depset of files in npm linked package dependencies of this targeth
f
npm_linked_packagesOA depset of NpmLinkedPackageInfo providers that are dependencies of this target�
�
npm_package_store_deps�A depset of NpmPackageStoreInfo providers from non-dev npm dependencies of this target and the target's transitive dependencies to use as direct dependencies when linking downstream npm_package targets with npm_link_package<
:
sources/A depset of source files produced by the targetr
p
transitive_declarationsUA depset of declaration files produced by the target and the target's transitive deps�
�
#transitive_npm_linked_package_filesdA depset of files in npm linked package dependencies of this target and the target's transitive deps�
�
transitive_npm_linked_packagespA depset of NpmLinkedPackageInfo providers that are dependencies of this target and the target's transitive depsh
f
transitive_sourcesPA depset of source files produced by the target and the target's transitive depsJsInfo provider�d
-
aspect_rules_js
js/privatejs_library.bzl�W
js_library�A library of JavaScript sources. Provides JsInfo, the primary provider used in rules_js
and derivative rule sets.

Declaration files are handled separately from sources since they are generally not needed at
runtime and build rules, such as ts_project, are optimal in their build graph if they only depend
on declarations from `deps` since these they don't need the JavaScript source files from deps to
typecheck.

Linked npm dependences are also handled separately from sources since not all rules require them and it
is optimal for these rules to not depend on them in the build graph.

NB: `js_library` copies all source files to the output tree before providing them in JsInfo. See
https://github.com/aspect-build/rules_js/tree/dbb5af0d2a9a2bb50e4cf4a96dbc582b27567155/docs#javascript
for more context on why we do this."�P
�+

js_library�A library of JavaScript sources. Provides JsInfo, the primary provider used in rules_js
and derivative rule sets.

Declaration files are handled separately from sources since they are generally not needed at
runtime and build rules, such as ts_project, are optimal in their build graph if they only depend
on declarations from `deps` since these they don't need the JavaScript source files from deps to
typecheck.

Linked npm dependences are also handled separately from sources since not all rules require them and it
is optimal for these rules to not depend on them in the build graph.

NB: `js_library` copies all source files to the output tree before providing them in JsInfo. See
https://github.com/aspect-build/rules_js/tree/dbb5af0d2a9a2bb50e4cf4a96dbc582b27567155/docs#javascript
for more context on why we do this.*
nameA unique name for this target. �
copy_data_to_binfWhen True, `data` files are copied to the Bazel output tree before being passed as inputs to runfiles.2True�
data�Runtime dependencies to include in binaries/tests that depend on this target.

The transitive npm dependencies, transitive sources, default outputs and runfiles of targets in the `data` attribute
are added to the runfiles of this target. They should appear in the '*.runfiles' area of any executable which has
a runtime dependency on this target.

If this list contains linked npm packages, npm package store targets or other targets that provide
`JsInfo`, `NpmPackageStoreInfo` providers are gathered from `JsInfo`. This is done directly from
the `npm_package_store_deps` field of these. For linked npm package targets, the underlying
`npm_package_store` target(s) that back the links is used. Gathered `NpmPackageStoreInfo`
providers are propagated to the direct dependencies of downstream linked `npm_package` targets.

NB: Linked npm package targets that are "dev" dependencies do not forward their underlying
`npm_package_store` target(s) through `npm_package_store_deps` and will therefore not be
propagated to the direct dependencies of downstream linked `npm_package` targets. npm packages
that come in from `npm_translate_lock` are considered "dev" dependencies if they are have
`dev: true` set in the pnpm lock file. This should be all packages that are only listed as
"devDependencies" in all `package.json` files within the pnpm workspace. This behavior is
intentional to mimic how `devDependencies` work in published npm packages.

2[]�
declarations�Same as `srcs` except all files are also provided as "declarations" available to downstream rules for type checking.

For example, a js_library with only `.js` files that are intended to be imported as `.js` files by downstream type checking
rules such as `ts_project` would list those files in `declarations`:

```
js_library(
    name = "js_lib",
    declarations = ["index.js"],
)
```
2[]�
deps�Dependencies of this target.

This may include other js_library targets or other targets that provide JsInfo

The transitive npm dependencies, transitive sources & runfiles of targets in the `deps` attribute are added to the
runfiles of this target. They should appear in the '*.runfiles' area of any executable which is output by or has a
runtime dependency on this target.

If this list contains linked npm packages, npm package store targets or other targets that provide
`JsInfo`, `NpmPackageStoreInfo` providers are gathered from `JsInfo`. This is done directly from
the `npm_package_store_deps` field of these. For linked npm package targets, the underlying
`npm_package_store` target(s) that back the links is used. Gathered `NpmPackageStoreInfo`
providers are propagated to the direct dependencies of downstream linked `npm_package` targets.

NB: Linked npm package targets that are "dev" dependencies do not forward their underlying
`npm_package_store` target(s) through `npm_package_store_deps` and will therefore not be
propagated to the direct dependencies of downstream linked `npm_package` targets. npm packages
that come in from `npm_translate_lock` are considered "dev" dependencies if they are have
`dev: true` set in the pnpm lock file. This should be all packages that are only listed as
"devDependencies" in all `package.json` files within the pnpm workspace. This behavior is
intentional to mimic how `devDependencies` work in published npm packages.

*
JsInfo2[]�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
srcs�Source files that are included in this library.

This includes all your checked-in code and any generated source files.

The transitive npm dependencies, transitive sources & runfiles of targets in the `srcs` attribute are added to the
runfiles of this target. They should appear in the '*.runfiles' area of any executable which is output by or has a
runtime dependency on this target.

Source files that are JSON files, declaration files or directory artifacts will be automatically provided as
"declarations" available to downstream rules for type checking. To explicitly provide source files as "declarations"
available to downstream rules for type checking that do not match these criteria, move those files to the `declarations`
attribute instead.
2[]":

js_library,@@aspect_rules_js//js/private:js_library.bzl
��,
*
nameA unique name for this target. �
�
copy_data_to_binfWhen True, `data` files are copied to the Bazel output tree before being passed as inputs to runfiles.2True�
�
data�Runtime dependencies to include in binaries/tests that depend on this target.

The transitive npm dependencies, transitive sources, default outputs and runfiles of targets in the `data` attribute
are added to the runfiles of this target. They should appear in the '*.runfiles' area of any executable which has
a runtime dependency on this target.

If this list contains linked npm packages, npm package store targets or other targets that provide
`JsInfo`, `NpmPackageStoreInfo` providers are gathered from `JsInfo`. This is done directly from
the `npm_package_store_deps` field of these. For linked npm package targets, the underlying
`npm_package_store` target(s) that back the links is used. Gathered `NpmPackageStoreInfo`
providers are propagated to the direct dependencies of downstream linked `npm_package` targets.

NB: Linked npm package targets that are "dev" dependencies do not forward their underlying
`npm_package_store` target(s) through `npm_package_store_deps` and will therefore not be
propagated to the direct dependencies of downstream linked `npm_package` targets. npm packages
that come in from `npm_translate_lock` are considered "dev" dependencies if they are have
`dev: true` set in the pnpm lock file. This should be all packages that are only listed as
"devDependencies" in all `package.json` files within the pnpm workspace. This behavior is
intentional to mimic how `devDependencies` work in published npm packages.

2[]�
�
declarations�Same as `srcs` except all files are also provided as "declarations" available to downstream rules for type checking.

For example, a js_library with only `.js` files that are intended to be imported as `.js` files by downstream type checking
rules such as `ts_project` would list those files in `declarations`:

```
js_library(
    name = "js_lib",
    declarations = ["index.js"],
)
```
2[]�
�
deps�Dependencies of this target.

This may include other js_library targets or other targets that provide JsInfo

The transitive npm dependencies, transitive sources & runfiles of targets in the `deps` attribute are added to the
runfiles of this target. They should appear in the '*.runfiles' area of any executable which is output by or has a
runtime dependency on this target.

If this list contains linked npm packages, npm package store targets or other targets that provide
`JsInfo`, `NpmPackageStoreInfo` providers are gathered from `JsInfo`. This is done directly from
the `npm_package_store_deps` field of these. For linked npm package targets, the underlying
`npm_package_store` target(s) that back the links is used. Gathered `NpmPackageStoreInfo`
providers are propagated to the direct dependencies of downstream linked `npm_package` targets.

NB: Linked npm package targets that are "dev" dependencies do not forward their underlying
`npm_package_store` target(s) through `npm_package_store_deps` and will therefore not be
propagated to the direct dependencies of downstream linked `npm_package` targets. npm packages
that come in from `npm_translate_lock` are considered "dev" dependencies if they are have
`dev: true` set in the pnpm lock file. This should be all packages that are only listed as
"devDependencies" in all `package.json` files within the pnpm workspace. This behavior is
intentional to mimic how `devDependencies` work in published npm packages.

*
JsInfo2[]�
�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
�
srcs�Source files that are included in this library.

This includes all your checked-in code and any generated source files.

The transitive npm dependencies, transitive sources & runfiles of targets in the `srcs` attribute are added to the
runfiles of this target. They should appear in the '*.runfiles' area of any executable which is output by or has a
runtime dependency on this target.

Source files that are JSON files, declaration files or directory artifacts will be automatically provided as
"declarations" available to downstream rules for type checking. To explicitly provide source files as "declarations"
available to downstream rules for type checking that do not match these criteria, move those files to the `declarations`
attribute instead.
2[]�
//js/private:js_helpers.bzlr�
-
aspect_rules_js
js/privatejs_helpers.bzlZ
$DOWNSTREAM_LINKED_NPM_DEPS_DOCSTRING$DOWNSTREAM_LINKED_NPM_DEPS_DOCSTRING
6Z:
JS_LIBRARY_DATA_ATTRJS_LIBRARY_DATA_ATTR
^rG
copy_js_file_to_bin_actioncopy_js_file_to_bin_action
v�H
gather_npm_linked_packagesgather_npm_linked_packages
��N
gather_npm_package_store_depsgather_npm_package_store_deps
��2
gather_runfilesgather_runfiles
��P
gather_transitive_declarationsgather_transitive_declarations
��F
gather_transitive_sourcesgather_transitive_sources
��
��
//js/private:js_info.bzlr|
*
aspect_rules_js
js/privatejs_info.bzl
JsInfoJsInfo
39 
js_infojs_info
=D
F�js_library groups together JS sources and arranges them and their transitive and npm dependencies into a provided
`JsInfo`. There are no Bazel actions to run.

For example, this `BUILD` file groups a pair of `.js/.d.ts` files along with the `package.json`.
The latter is needed because it contains a `typings` key that allows downstream
users of this library to resolve the `one.d.ts` file.
The `main` key is another commonly used field in `package.json` which would require including it in the library.

```starlark
load("@aspect_rules_js//js:defs.bzl", "js_library")

js_library(
    name = "one",
    srcs = [
        "one.d.ts",
        "one.js",
        "package.json",
    ],
)
```

| This is similar to [`py_library`](https://docs.bazel.build/versions/main/be/python.html#py_library) which depends on
| Python sources and provides a `PyInfo`.
�4
0
aspect_rules_js
js/privatejs_run_binary.bzl�*js_run_binary�Wrapper around @aspect_bazel_lib `run_binary` that adds convenience attributes for using a `js_binary` tool.

This rule does not require Bash `native.genrule`.

The following environment variables are made available to the Node.js runtime based on available Bazel [Make variables](https://bazel.build/reference/be/make-variables#predefined_variables):

* BAZEL_BINDIR: the WORKSPACE-relative bazel bin directory; equivalent to the `$(BINDIR)` Make variable of the `js_run_binary` target
* BAZEL_COMPILATION_MODE: One of `fastbuild`, `dbg`, or `opt` as set by [`--compilation_mode`](https://bazel.build/docs/user-manual#compilation-mode); equivalent to `$(COMPILATION_MODE)` Make variable of the `js_run_binary` target
* BAZEL_TARGET_CPU: the target cpu architecture; equivalent to `$(TARGET_CPU)` Make variable of the `js_run_binary` target

The following environment variables are made available to the Node.js runtime based on the rule context:

* BAZEL_BUILD_FILE_PATH: the WORKSPACE-relative path to the BUILD file of the bazel target being run; equivalent to `ctx.build_file_path` of the `js_run_binary` target's rule context
* BAZEL_PACKAGE: the package of the bazel target being run; equivalent to `ctx.label.package` of the `js_run_binary` target's rule context
* BAZEL_TARGET_NAME: the full label of the bazel target being run; a stringified version of `ctx.label` of the `js_run_binary` target's rule context
* BAZEL_TARGET: the name of the bazel target being run; equivalent to `ctx.label.name` of the  `js_run_binary` target's rule context
* BAZEL_WORKSPACE: the bazel workspace name; equivalent to `ctx.workspace_name` of the `js_run_binary` target's rule context
"�
�
js_run_binary�Wrapper around @aspect_bazel_lib `run_binary` that adds convenience attributes for using a `js_binary` tool.

This rule does not require Bash `native.genrule`.

The following environment variables are made available to the Node.js runtime based on available Bazel [Make variables](https://bazel.build/reference/be/make-variables#predefined_variables):

* BAZEL_BINDIR: the WORKSPACE-relative bazel bin directory; equivalent to the `$(BINDIR)` Make variable of the `js_run_binary` target
* BAZEL_COMPILATION_MODE: One of `fastbuild`, `dbg`, or `opt` as set by [`--compilation_mode`](https://bazel.build/docs/user-manual#compilation-mode); equivalent to `$(COMPILATION_MODE)` Make variable of the `js_run_binary` target
* BAZEL_TARGET_CPU: the target cpu architecture; equivalent to `$(TARGET_CPU)` Make variable of the `js_run_binary` target

The following environment variables are made available to the Node.js runtime based on the rule context:

* BAZEL_BUILD_FILE_PATH: the WORKSPACE-relative path to the BUILD file of the bazel target being run; equivalent to `ctx.build_file_path` of the `js_run_binary` target's rule context
* BAZEL_PACKAGE: the package of the bazel target being run; equivalent to `ctx.label.package` of the `js_run_binary` target's rule context
* BAZEL_TARGET_NAME: the full label of the bazel target being run; a stringified version of `ctx.label` of the `js_run_binary` target's rule context
* BAZEL_TARGET: the name of the bazel target being run; equivalent to `ctx.label.name` of the  `js_run_binary` target's rule context
* BAZEL_WORKSPACE: the bazel workspace name; equivalent to `ctx.workspace_name` of the `js_run_binary` target's rule context
*
nameA unique name for this target. 
args2[]
env
2{}
execution_requirements
2{}
mnemonic2""
out_dirs2[]
outs
progress_message2""
srcs2[]�
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.
2-1

tool 
,
*
nameA unique name for this target. 

args2[]

env
2{} 

execution_requirements
2{}

mnemonic2""

out_dirs2[]


outs

progress_message2""

srcs2[]�
�
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.
2-1


tool ~
//lib:copy_to_bin.bzlrc
(
aspect_bazel_liblibcopy_to_bin.bzl)
copy_to_bin_copy_to_bin
0<
Mz
//lib:run_binary.bzlr`
'
aspect_bazel_liblibrun_binary.bzl'

run_binary_run_binary
/:
Jk
//lib:utils.bzlrV
"
aspect_bazel_liblib	utils.bzl"
to_labelto_label
+3
5�
//js/private:js_filegroup.bzlrl
/
aspect_rules_js
js/privatejs_filegroup.bzl+
js_filegroup_js_filegroup
7D
V�
//js/private:js_helpers.bzlrv
-
aspect_rules_js
js/privatejs_helpers.bzl7
envs_for_log_level_envs_for_log_level
5H
`�
//js/private:js_library.bzlrf
-
aspect_rules_js
js/privatejs_library.bzl'

js_library_js_library
5@
Pa
//lib:dicts.bzlrL

bazel_skyliblib	dicts.bzl
dictsdicts
',
.�Runs a js_binary as a build action.

This macro wraps Aspect bazel-lib's run_binary (https://github.com/aspect-build/bazel-lib/blob/main/lib/run_binary.bzl)
and adds attributes and features specific to rules_js's js_binary.

Load this with,

```starlark
load("@aspect_rules_js//js:defs.bzl", "js_run_binary")
```
��
3
aspect_rules_js
js/privatejs_run_devserver.bzl��js_run_devserver�Runs a devserver via binary target or command.

A simple http-server, for example, can be setup as follows,

```
load("@aspect_rules_js//js:defs.bzl", "js_run_devserver")
load("@npm//:http-server/package_json.bzl", http_server_bin = "bin")

http_server_bin.http_server_binary(
    name = "http_server",
)

js_run_devserver(
    name = "serve",
    args = ["."],
    data = ["index.html"],
    tool = ":http_server",
)
```

A Next.js devserver can be setup as follows,

```
js_run_devserver(
    name = "dev",
    args = ["dev"],
    command = "./node_modules/.bin/next",
    data = [
        "next.config.js",
        "package.json",
        ":node_modules/next",
        ":node_modules/react",
        ":node_modules/react-dom",
        ":node_modules/typescript",
        "//pages",
        "//public",
        "//styles",
    ],
)
```

where the `./node_modules/.bin/next` bin entry of Next.js is configured in
`npm_translate_lock` as such,

```
npm_translate_lock(
    name = "npm",
    bins = {
        # derived from "bin" attribute in node_modules/next/package.json
        "next": {
            "next": "./dist/bin/next",
        },
    },
    pnpm_lock = "//:pnpm-lock.yaml",
)
```

and run in watch mode using [ibazel](https://github.com/bazelbuild/bazel-watcher) with
`ibazel run //:dev`.

The devserver specified by either `tool` or `command` is run in a custom sandbox that is more
compatible with devserver watch modes in Node.js tools such as Webpack and Next.js.

The custom sandbox is populated with the default outputs of all targets in `data`
as well as transitive sources & npm links.

An an optimization, virtual store files are explicitly excluded from the sandbox since the npm
links will point to the virtual store in the execroot and Node.js will follow those links as it
does within the execroot. As a result, rules_js npm package link targets such as
`//:node_modules/next` are handled efficiently. Since these targets are symlinks in the output
tree, they are recreated as symlinks in the custom sandbox and do not incur a fully copy of the
underlying npm packages.

Supports running with [ibazel](https://github.com/bazelbuild/bazel-watcher).
Only `data` files that change on incremental builds are synchronized when running with ibazel.
"��
�W
js_run_devserver�Runs a devserver via binary target or command.

A simple http-server, for example, can be setup as follows,

```
load("@aspect_rules_js//js:defs.bzl", "js_run_devserver")
load("@npm//:http-server/package_json.bzl", http_server_bin = "bin")

http_server_bin.http_server_binary(
    name = "http_server",
)

js_run_devserver(
    name = "serve",
    args = ["."],
    data = ["index.html"],
    tool = ":http_server",
)
```

A Next.js devserver can be setup as follows,

```
js_run_devserver(
    name = "dev",
    args = ["dev"],
    command = "./node_modules/.bin/next",
    data = [
        "next.config.js",
        "package.json",
        ":node_modules/next",
        ":node_modules/react",
        ":node_modules/react-dom",
        ":node_modules/typescript",
        "//pages",
        "//public",
        "//styles",
    ],
)
```

where the `./node_modules/.bin/next` bin entry of Next.js is configured in
`npm_translate_lock` as such,

```
npm_translate_lock(
    name = "npm",
    bins = {
        # derived from "bin" attribute in node_modules/next/package.json
        "next": {
            "next": "./dist/bin/next",
        },
    },
    pnpm_lock = "//:pnpm-lock.yaml",
)
```

and run in watch mode using [ibazel](https://github.com/bazelbuild/bazel-watcher) with
`ibazel run //:dev`.

The devserver specified by either `tool` or `command` is run in a custom sandbox that is more
compatible with devserver watch modes in Node.js tools such as Webpack and Next.js.

The custom sandbox is populated with the default outputs of all targets in `data`
as well as transitive sources & npm links.

An an optimization, virtual store files are explicitly excluded from the sandbox since the npm
links will point to the virtual store in the execroot and Node.js will follow those links as it
does within the execroot. As a result, rules_js npm package link targets such as
`//:node_modules/next` are handled efficiently. Since these targets are symlinks in the output
tree, they are recreated as symlinks in the custom sandbox and do not incur a fully copy of the
underlying npm packages.

Supports running with [ibazel](https://github.com/bazelbuild/bazel-watcher).
Only `data` files that change on incremental builds are synchronized when running with ibazel.
*
nameA unique name for this target. >
3allow_execroot_entry_point_with_no_copy_data_to_bin2False�
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/"))) + "$(rootpath //path/to/some:file)"],
)
```2""
command2""�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

NB: `data` files are copied to the Bazel output tree before being passed
as inputs to runfiles. See `copy_data_to_bin` docstring for more info.
2[]�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/aspect-build/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 �
env�Environment variables of the action.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution.

2{}i
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�

fixed_args�Fixed command line arguments to pass to the Node.js when this
binary target is executed.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution.

Unlike the built-in `args`, which are only passed to the target when it is
executed either by the `bazel run` command or as a test, `fixed_args` are baked
into the generated launcher script so are always passed even when the binary
target is run outside of Bazel directly from the launcher script.

`fixed_args` are passed before the ones specified in `args` and before ones
that are specified on the `bazel run` or `bazel test` command line.

See https://bazel.build/reference/be/common-definitions#common-attributes-binaries
for more info on the built-in `args` attribute.
2[]*
grant_sandbox_write_permissions2False�
include_declarations�When True, `declarations` and `transitive_declarations` from `JsInfo` providers in data targets are included in the runfiles of the target.

Defaults to false since declarations are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
include_npm_linked_packages�When True, files in `npm_linked_packages` and `transitive_npm_linked_packages` from `JsInfo` providers in data targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in data targets are also included in the runfiles of the target.
2True�
include_transitive_sourcessWhen True, `transitive_sources` from `JsInfo` providers in data targets are included in the runfiles of the target.2True�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.

Log levels: fatal, error, warn, info, debug2"error"�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
node_toolchain�The Node.js toolchain to use for this target.

See https://bazelbuild.github.io/rules_nodejs/Toolchains.html

Typically this is left unset so that Bazel automatically selects the right Node.js toolchain
for the target platform. See https://bazel.build/extending/toolchains#toolchain-resolution
for more information.
2None�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2True
tool_exec_cfg2None
tool_target_cfg2None�
unresolved_symlinks_enabled�Whether unresolved symlinks are enabled in the current build configuration.

These are enabled with the --experimental_allow_unresolved_symlinks flag.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
2False"
use_execroot_entry_point2True"G
_js_run_devserver2@@aspect_rules_js//js/private:js_run_devserver.bzl
ii,
*
nameA unique name for this target. @
>
3allow_execroot_entry_point_with_no_copy_data_to_bin2False�
�
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/"))) + "$(rootpath //path/to/some:file)"],
)
```2""

command2""�
�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

NB: `data` files are copied to the Bazel output tree before being passed
as inputs to runfiles. See `copy_data_to_bin` docstring for more info.
2[]�
�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
�
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/aspect-build/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 �
�
env�Environment variables of the action.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution.

2{}k
i
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�
�

fixed_args�Fixed command line arguments to pass to the Node.js when this
binary target is executed.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution.

Unlike the built-in `args`, which are only passed to the target when it is
executed either by the `bazel run` command or as a test, `fixed_args` are baked
into the generated launcher script so are always passed even when the binary
target is run outside of Bazel directly from the launcher script.

`fixed_args` are passed before the ones specified in `args` and before ones
that are specified on the `bazel run` or `bazel test` command line.

See https://bazel.build/reference/be/common-definitions#common-attributes-binaries
for more info on the built-in `args` attribute.
2[],
*
grant_sandbox_write_permissions2False�
�
include_declarations�When True, `declarations` and `transitive_declarations` from `JsInfo` providers in data targets are included in the runfiles of the target.

Defaults to false since declarations are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
�
include_npm_linked_packages�When True, files in `npm_linked_packages` and `transitive_npm_linked_packages` from `JsInfo` providers in data targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in data targets are also included in the runfiles of the target.
2True�
�
include_transitive_sourcessWhen True, `transitive_sources` from `JsInfo` providers in data targets are included in the runfiles of the target.2True�
�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.

Log levels: fatal, error, warn, info, debug2"error"�
�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
�
node_toolchain�The Node.js toolchain to use for this target.

See https://bazelbuild.github.io/rules_nodejs/Toolchains.html

Typically this is left unset so that Bazel automatically selects the right Node.js toolchain
for the target platform. See https://bazel.build/extending/toolchains#toolchain-resolution
for more information.
2None�
�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2True

tool_exec_cfg2None

tool_target_cfg2None�
�
unresolved_symlinks_enabled�Whether unresolved symlinks are enabled in the current build configuration.

These are enabled with the --experimental_allow_unresolved_symlinks flag.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
2False$
"
use_execroot_entry_point2True�
//js/private:js_binary.bzlrj
,
aspect_rules_js
js/privatejs_binary.bzl,
js_binary_libjs_binary_lib
5B
D�
//js/private:js_helpers.bzlr�
-
aspect_rules_js
js/privatejs_helpers.bzlO
gather_files_from_js_providers_gather_files_from_js_providers
5T
xa
//lib:dicts.bzlrL

bazel_skyliblib	dicts.bzl
dictsdicts
',
.0Implementation details for js_run_devserver rule�
(
aspect_rules_js
js/private	maybe.bzl�maybe_http_archive*v
_
maybe_http_archive

kwargs(2=
maybe_http_archive'@@aspect_rules_js//js/private:maybe.bzl
*maybe�
 //tools/build_defs/repo:http.bzlrk
.
bazel_toolstools/build_defs/repohttp.bzl+
http_archive_http_archive
6C
U�
!//tools/build_defs/repo:utils.bzlr]
/
bazel_toolstools/build_defs/repo	utils.bzl
maybemaybe
8=
?maybe utilities��

aspect_rules_jsjsdefs.bzl�js_filegroup�Gathers files from the JsInfo providers from targets in srcs and provides them as default outputs.

This helper rule is used by the `js_run_binary` macro.
"�
�	
js_filegroup�Gathers files from the JsInfo providers from targets in srcs and provides them as default outputs.

This helper rule is used by the `js_run_binary` macro.
*
nameA unique name for this target. �
include_declarations�When True, `declarations` and `transitive_declarations` from `JsInfo` providers in srcs targets are included in the default outputs of the target.

Defaults to false since declarations are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
include_npm_linked_packages�When True, files in `npm_linked_packages` and `transitive_npm_linked_packages` from `JsInfo` providers in srcs targets are included in the default outputs of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in data targets are also included in the default outputs of the target.
2True�
include_transitive_sources|When True, `transitive_sources` from `JsInfo` providers in `srcs` targets are included in the default outputs of the target.2True3
srcs%List of targets to gather files from.2[]".
js_filegroup@@aspect_rules_js//js:defs.bzl
,
*
nameA unique name for this target. �
�
include_declarations�When True, `declarations` and `transitive_declarations` from `JsInfo` providers in srcs targets are included in the default outputs of the target.

Defaults to false since declarations are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
�
include_npm_linked_packages�When True, files in `npm_linked_packages` and `transitive_npm_linked_packages` from `JsInfo` providers in srcs targets are included in the default outputs of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in data targets are also included in the default outputs of the target.
2True�
�
include_transitive_sources|When True, `transitive_sources` from `JsInfo` providers in `srcs` targets are included in the default outputs of the target.2True5
3
srcs%List of targets to gather files from.2[]�=js_image_layer�Create container image layers from js_binary targets.

By design, js_image_layer doesn't have any preference over which rule assembles the container image. 
This means the downstream rule (`oci_image`, or `container_image` in this case) must set a proper `workdir` and `cmd` to for the container work.
A proper `cmd` usually looks like /`[ root of js_image_layer ]`/`[ relative path to BUILD file from WORKSPACE or package_name() ]/[ name of js_binary ]`, 
unless you have a launcher script that invokes the entry_point of the `js_binary` in a different path.
On the other hand, `workdir` has to be set to `runfiles tree root` which would be exactly `cmd` **but with `.runfiles/[ name of the workspace or __main__ if empty ]` suffix**. If `workdir` is not set correctly, some
attributes such as `chdir` might not work properly.

js_image_layer supports transitioning to specific `platform` to allow building multi-platform container images.

**A partial example using rules_oci with transition to linux/amd64 platform.**

```starlark
load("@aspect_rules_js//js:defs.bzl", "js_binary", "js_image_layer")
load("@rules_oci//oci:defs.bzl", "oci_image")

js_binary(
    name = "binary",
    entry_point = "main.js",
)

platform(
    name = "amd64_linux",
    constraint_values = [
        "@platforms//os:linux",
        "@platforms//cpu:x86_64",
    ],
)

js_image_layer(
    name = "layers",
    binary = ":binary",
    platform = ":amd64_linux",
    root = "/app"
)

oci_image(
    name = "image",
    cmd = ["/app/main"],
    entrypoint = ["bash"],
    tars = [
        ":layers"
    ]
)
```

**A partial example using rules_oci to create multi-platform images.**


```starlark
load("@aspect_rules_js//js:defs.bzl", "js_binary", "js_image_layer")
load("@rules_oci//oci:defs.bzl", "oci_image", "oci_image_index")

js_binary(
    name = "binary",
    entry_point = "main.js",
)

[
    platform(
        name = "linux_{}".format(arch),
        constraint_values = [
            "@platforms//os:linux",
            "@platforms//cpu:{}".format(arch if arch != "amd64" else "x86_64"),
        ],
    )
    js_image_layer(
        name = "{}_layers".format(arch),
        binary = ":binary",
        platform = ":linux_{arch}",
        root = "/app"
    )
    oci_image(
        name = "{}_image".format(arch),
        cmd = ["/app/main"],
        entrypoint = ["bash"],
        tars = [
            ":{}_layers".format(arch)
        ]
    )
    for arch in ["amd64", "arm64"]
]

oci_image_index(
    name = "image",
    images = [
        ":arm64_image",
        ":amd64_image"
    ]
)

```

**An example using legacy rules_docker**

See `e2e/js_image_rules_docker` for full example.

```starlark
load("@aspect_rules_js//js:defs.bzl", "js_binary", "js_image_layer")
load("@io_bazel_rules_docker//container:container.bzl", "container_image")

js_binary(
    name = "main",
    data = [
        "//:node_modules/args-parser",
    ],
    entry_point = "main.js",
)


js_image_layer(
    name = "layers",
    binary = ":main",
    root = "/app",
    visibility = ["//visibility:__pkg__"],
)

filegroup(
    name = "app_tar", 
    srcs = [":layers"], 
    output_group = "app"
)
container_layer(
    name = "app_layer",
    tars = [":app_tar"],
)

filegroup(
    name = "node_modules_tar", 
    srcs = [":layers"], 
    output_group = "node_modules"
)
container_layer(
    name = "node_modules_layer",
    tars = [":node_modules_tar"],
)

container_image(
    name = "image",
    cmd = ["/app/main"],
    entrypoint = ["bash"],
    layers = [
        ":app_layer",
        ":node_modules_layer",
    ],
)
```
"�!
�
js_image_layer�Create container image layers from js_binary targets.

By design, js_image_layer doesn't have any preference over which rule assembles the container image. 
This means the downstream rule (`oci_image`, or `container_image` in this case) must set a proper `workdir` and `cmd` to for the container work.
A proper `cmd` usually looks like /`[ root of js_image_layer ]`/`[ relative path to BUILD file from WORKSPACE or package_name() ]/[ name of js_binary ]`, 
unless you have a launcher script that invokes the entry_point of the `js_binary` in a different path.
On the other hand, `workdir` has to be set to `runfiles tree root` which would be exactly `cmd` **but with `.runfiles/[ name of the workspace or __main__ if empty ]` suffix**. If `workdir` is not set correctly, some
attributes such as `chdir` might not work properly.

js_image_layer supports transitioning to specific `platform` to allow building multi-platform container images.

**A partial example using rules_oci with transition to linux/amd64 platform.**

```starlark
load("@aspect_rules_js//js:defs.bzl", "js_binary", "js_image_layer")
load("@rules_oci//oci:defs.bzl", "oci_image")

js_binary(
    name = "binary",
    entry_point = "main.js",
)

platform(
    name = "amd64_linux",
    constraint_values = [
        "@platforms//os:linux",
        "@platforms//cpu:x86_64",
    ],
)

js_image_layer(
    name = "layers",
    binary = ":binary",
    platform = ":amd64_linux",
    root = "/app"
)

oci_image(
    name = "image",
    cmd = ["/app/main"],
    entrypoint = ["bash"],
    tars = [
        ":layers"
    ]
)
```

**A partial example using rules_oci to create multi-platform images.**


```starlark
load("@aspect_rules_js//js:defs.bzl", "js_binary", "js_image_layer")
load("@rules_oci//oci:defs.bzl", "oci_image", "oci_image_index")

js_binary(
    name = "binary",
    entry_point = "main.js",
)

[
    platform(
        name = "linux_{}".format(arch),
        constraint_values = [
            "@platforms//os:linux",
            "@platforms//cpu:{}".format(arch if arch != "amd64" else "x86_64"),
        ],
    )
    js_image_layer(
        name = "{}_layers".format(arch),
        binary = ":binary",
        platform = ":linux_{arch}",
        root = "/app"
    )
    oci_image(
        name = "{}_image".format(arch),
        cmd = ["/app/main"],
        entrypoint = ["bash"],
        tars = [
            ":{}_layers".format(arch)
        ]
    )
    for arch in ["amd64", "arm64"]
]

oci_image_index(
    name = "image",
    images = [
        ":arm64_image",
        ":amd64_image"
    ]
)

```

**An example using legacy rules_docker**

See `e2e/js_image_rules_docker` for full example.

```starlark
load("@aspect_rules_js//js:defs.bzl", "js_binary", "js_image_layer")
load("@io_bazel_rules_docker//container:container.bzl", "container_image")

js_binary(
    name = "main",
    data = [
        "//:node_modules/args-parser",
    ],
    entry_point = "main.js",
)


js_image_layer(
    name = "layers",
    binary = ":main",
    root = "/app",
    visibility = ["//visibility:__pkg__"],
)

filegroup(
    name = "app_tar", 
    srcs = [":layers"], 
    output_group = "app"
)
container_layer(
    name = "app_layer",
    tars = [":app_tar"],
)

filegroup(
    name = "node_modules_tar", 
    srcs = [":layers"], 
    output_group = "node_modules"
)
container_layer(
    name = "node_modules_layer",
    tars = [":node_modules_tar"],
)

container_image(
    name = "image",
    cmd = ["/app/main"],
    entrypoint = ["bash"],
    layers = [
        ":app_layer",
        ":node_modules_layer",
    ],
)
```
*
nameA unique name for this target. *
binaryLabel to an js_binary target M
compression4Compression algorithm. Can be one of `gzip`, `none`.2"gzip"+
platformPlatform to transition.2NoneX
rootJPath where the files from js_binary will reside in. eg: /apps/app1 or /app2"""0
js_image_layer@@aspect_rules_js//js:defs.bzl
��,
*
nameA unique name for this target. ,
*
binaryLabel to an js_binary target O
M
compression4Compression algorithm. Can be one of `gzip`, `none`.2"gzip"-
+
platformPlatform to transition.2NoneZ
X
rootJPath where the files from js_binary will reside in. eg: /apps/app1 or /app2""�V
js_library�A library of JavaScript sources. Provides JsInfo, the primary provider used in rules_js
and derivative rule sets.

Declaration files are handled separately from sources since they are generally not needed at
runtime and build rules, such as ts_project, are optimal in their build graph if they only depend
on declarations from `deps` since these they don't need the JavaScript source files from deps to
typecheck.

Linked npm dependences are also handled separately from sources since not all rules require them and it
is optimal for these rules to not depend on them in the build graph.

NB: `js_library` copies all source files to the output tree before providing them in JsInfo. See
https://github.com/aspect-build/rules_js/tree/dbb5af0d2a9a2bb50e4cf4a96dbc582b27567155/docs#javascript
for more context on why we do this."�P
�+

js_library�A library of JavaScript sources. Provides JsInfo, the primary provider used in rules_js
and derivative rule sets.

Declaration files are handled separately from sources since they are generally not needed at
runtime and build rules, such as ts_project, are optimal in their build graph if they only depend
on declarations from `deps` since these they don't need the JavaScript source files from deps to
typecheck.

Linked npm dependences are also handled separately from sources since not all rules require them and it
is optimal for these rules to not depend on them in the build graph.

NB: `js_library` copies all source files to the output tree before providing them in JsInfo. See
https://github.com/aspect-build/rules_js/tree/dbb5af0d2a9a2bb50e4cf4a96dbc582b27567155/docs#javascript
for more context on why we do this.*
nameA unique name for this target. �
copy_data_to_binfWhen True, `data` files are copied to the Bazel output tree before being passed as inputs to runfiles.2True�
data�Runtime dependencies to include in binaries/tests that depend on this target.

The transitive npm dependencies, transitive sources, default outputs and runfiles of targets in the `data` attribute
are added to the runfiles of this target. They should appear in the '*.runfiles' area of any executable which has
a runtime dependency on this target.

If this list contains linked npm packages, npm package store targets or other targets that provide
`JsInfo`, `NpmPackageStoreInfo` providers are gathered from `JsInfo`. This is done directly from
the `npm_package_store_deps` field of these. For linked npm package targets, the underlying
`npm_package_store` target(s) that back the links is used. Gathered `NpmPackageStoreInfo`
providers are propagated to the direct dependencies of downstream linked `npm_package` targets.

NB: Linked npm package targets that are "dev" dependencies do not forward their underlying
`npm_package_store` target(s) through `npm_package_store_deps` and will therefore not be
propagated to the direct dependencies of downstream linked `npm_package` targets. npm packages
that come in from `npm_translate_lock` are considered "dev" dependencies if they are have
`dev: true` set in the pnpm lock file. This should be all packages that are only listed as
"devDependencies" in all `package.json` files within the pnpm workspace. This behavior is
intentional to mimic how `devDependencies` work in published npm packages.

2[]�
declarations�Same as `srcs` except all files are also provided as "declarations" available to downstream rules for type checking.

For example, a js_library with only `.js` files that are intended to be imported as `.js` files by downstream type checking
rules such as `ts_project` would list those files in `declarations`:

```
js_library(
    name = "js_lib",
    declarations = ["index.js"],
)
```
2[]�
deps�Dependencies of this target.

This may include other js_library targets or other targets that provide JsInfo

The transitive npm dependencies, transitive sources & runfiles of targets in the `deps` attribute are added to the
runfiles of this target. They should appear in the '*.runfiles' area of any executable which is output by or has a
runtime dependency on this target.

If this list contains linked npm packages, npm package store targets or other targets that provide
`JsInfo`, `NpmPackageStoreInfo` providers are gathered from `JsInfo`. This is done directly from
the `npm_package_store_deps` field of these. For linked npm package targets, the underlying
`npm_package_store` target(s) that back the links is used. Gathered `NpmPackageStoreInfo`
providers are propagated to the direct dependencies of downstream linked `npm_package` targets.

NB: Linked npm package targets that are "dev" dependencies do not forward their underlying
`npm_package_store` target(s) through `npm_package_store_deps` and will therefore not be
propagated to the direct dependencies of downstream linked `npm_package` targets. npm packages
that come in from `npm_translate_lock` are considered "dev" dependencies if they are have
`dev: true` set in the pnpm lock file. This should be all packages that are only listed as
"devDependencies" in all `package.json` files within the pnpm workspace. This behavior is
intentional to mimic how `devDependencies` work in published npm packages.

*
JsInfo2[]�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
srcs�Source files that are included in this library.

This includes all your checked-in code and any generated source files.

The transitive npm dependencies, transitive sources & runfiles of targets in the `srcs` attribute are added to the
runfiles of this target. They should appear in the '*.runfiles' area of any executable which is output by or has a
runtime dependency on this target.

Source files that are JSON files, declaration files or directory artifacts will be automatically provided as
"declarations" available to downstream rules for type checking. To explicitly provide source files as "declarations"
available to downstream rules for type checking that do not match these criteria, move those files to the `declarations`
attribute instead.
2[]",

js_library@@aspect_rules_js//js:defs.bzl
��,
*
nameA unique name for this target. �
�
copy_data_to_binfWhen True, `data` files are copied to the Bazel output tree before being passed as inputs to runfiles.2True�
�
data�Runtime dependencies to include in binaries/tests that depend on this target.

The transitive npm dependencies, transitive sources, default outputs and runfiles of targets in the `data` attribute
are added to the runfiles of this target. They should appear in the '*.runfiles' area of any executable which has
a runtime dependency on this target.

If this list contains linked npm packages, npm package store targets or other targets that provide
`JsInfo`, `NpmPackageStoreInfo` providers are gathered from `JsInfo`. This is done directly from
the `npm_package_store_deps` field of these. For linked npm package targets, the underlying
`npm_package_store` target(s) that back the links is used. Gathered `NpmPackageStoreInfo`
providers are propagated to the direct dependencies of downstream linked `npm_package` targets.

NB: Linked npm package targets that are "dev" dependencies do not forward their underlying
`npm_package_store` target(s) through `npm_package_store_deps` and will therefore not be
propagated to the direct dependencies of downstream linked `npm_package` targets. npm packages
that come in from `npm_translate_lock` are considered "dev" dependencies if they are have
`dev: true` set in the pnpm lock file. This should be all packages that are only listed as
"devDependencies" in all `package.json` files within the pnpm workspace. This behavior is
intentional to mimic how `devDependencies` work in published npm packages.

2[]�
�
declarations�Same as `srcs` except all files are also provided as "declarations" available to downstream rules for type checking.

For example, a js_library with only `.js` files that are intended to be imported as `.js` files by downstream type checking
rules such as `ts_project` would list those files in `declarations`:

```
js_library(
    name = "js_lib",
    declarations = ["index.js"],
)
```
2[]�
�
deps�Dependencies of this target.

This may include other js_library targets or other targets that provide JsInfo

The transitive npm dependencies, transitive sources & runfiles of targets in the `deps` attribute are added to the
runfiles of this target. They should appear in the '*.runfiles' area of any executable which is output by or has a
runtime dependency on this target.

If this list contains linked npm packages, npm package store targets or other targets that provide
`JsInfo`, `NpmPackageStoreInfo` providers are gathered from `JsInfo`. This is done directly from
the `npm_package_store_deps` field of these. For linked npm package targets, the underlying
`npm_package_store` target(s) that back the links is used. Gathered `NpmPackageStoreInfo`
providers are propagated to the direct dependencies of downstream linked `npm_package` targets.

NB: Linked npm package targets that are "dev" dependencies do not forward their underlying
`npm_package_store` target(s) through `npm_package_store_deps` and will therefore not be
propagated to the direct dependencies of downstream linked `npm_package` targets. npm packages
that come in from `npm_translate_lock` are considered "dev" dependencies if they are have
`dev: true` set in the pnpm lock file. This should be all packages that are only listed as
"devDependencies" in all `package.json` files within the pnpm workspace. This behavior is
intentional to mimic how `devDependencies` work in published npm packages.

*
JsInfo2[]�
�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
�
srcs�Source files that are included in this library.

This includes all your checked-in code and any generated source files.

The transitive npm dependencies, transitive sources & runfiles of targets in the `srcs` attribute are added to the
runfiles of this target. They should appear in the '*.runfiles' area of any executable which is output by or has a
runtime dependency on this target.

Source files that are JSON files, declaration files or directory artifacts will be automatically provided as
"declarations" available to downstream rules for type checking. To explicitly provide source files as "declarations"
available to downstream rules for type checking that do not match these criteria, move those files to the `declarations`
attribute instead.
2[]�*js_run_binary�Wrapper around @aspect_bazel_lib `run_binary` that adds convenience attributes for using a `js_binary` tool.

This rule does not require Bash `native.genrule`.

The following environment variables are made available to the Node.js runtime based on available Bazel [Make variables](https://bazel.build/reference/be/make-variables#predefined_variables):

* BAZEL_BINDIR: the WORKSPACE-relative bazel bin directory; equivalent to the `$(BINDIR)` Make variable of the `js_run_binary` target
* BAZEL_COMPILATION_MODE: One of `fastbuild`, `dbg`, or `opt` as set by [`--compilation_mode`](https://bazel.build/docs/user-manual#compilation-mode); equivalent to `$(COMPILATION_MODE)` Make variable of the `js_run_binary` target
* BAZEL_TARGET_CPU: the target cpu architecture; equivalent to `$(TARGET_CPU)` Make variable of the `js_run_binary` target

The following environment variables are made available to the Node.js runtime based on the rule context:

* BAZEL_BUILD_FILE_PATH: the WORKSPACE-relative path to the BUILD file of the bazel target being run; equivalent to `ctx.build_file_path` of the `js_run_binary` target's rule context
* BAZEL_PACKAGE: the package of the bazel target being run; equivalent to `ctx.label.package` of the `js_run_binary` target's rule context
* BAZEL_TARGET_NAME: the full label of the bazel target being run; a stringified version of `ctx.label` of the `js_run_binary` target's rule context
* BAZEL_TARGET: the name of the bazel target being run; equivalent to `ctx.label.name` of the  `js_run_binary` target's rule context
* BAZEL_WORKSPACE: the bazel workspace name; equivalent to `ctx.workspace_name` of the `js_run_binary` target's rule context
"�
�
js_run_binary�Wrapper around @aspect_bazel_lib `run_binary` that adds convenience attributes for using a `js_binary` tool.

This rule does not require Bash `native.genrule`.

The following environment variables are made available to the Node.js runtime based on available Bazel [Make variables](https://bazel.build/reference/be/make-variables#predefined_variables):

* BAZEL_BINDIR: the WORKSPACE-relative bazel bin directory; equivalent to the `$(BINDIR)` Make variable of the `js_run_binary` target
* BAZEL_COMPILATION_MODE: One of `fastbuild`, `dbg`, or `opt` as set by [`--compilation_mode`](https://bazel.build/docs/user-manual#compilation-mode); equivalent to `$(COMPILATION_MODE)` Make variable of the `js_run_binary` target
* BAZEL_TARGET_CPU: the target cpu architecture; equivalent to `$(TARGET_CPU)` Make variable of the `js_run_binary` target

The following environment variables are made available to the Node.js runtime based on the rule context:

* BAZEL_BUILD_FILE_PATH: the WORKSPACE-relative path to the BUILD file of the bazel target being run; equivalent to `ctx.build_file_path` of the `js_run_binary` target's rule context
* BAZEL_PACKAGE: the package of the bazel target being run; equivalent to `ctx.label.package` of the `js_run_binary` target's rule context
* BAZEL_TARGET_NAME: the full label of the bazel target being run; a stringified version of `ctx.label` of the `js_run_binary` target's rule context
* BAZEL_TARGET: the name of the bazel target being run; equivalent to `ctx.label.name` of the  `js_run_binary` target's rule context
* BAZEL_WORKSPACE: the bazel workspace name; equivalent to `ctx.workspace_name` of the `js_run_binary` target's rule context
*
nameA unique name for this target. 
args2[]
env
2{}
execution_requirements
2{}
mnemonic2""
out_dirs2[]
outs
progress_message2""
srcs2[]�
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.
2-1

tool 
,
*
nameA unique name for this target. 

args2[]

env
2{} 

execution_requirements
2{}

mnemonic2""

out_dirs2[]


outs

progress_message2""

srcs2[]�
�
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.
2-1


tool Ѯjs_run_devserver�Runs a devserver via binary target or command.

A simple http-server, for example, can be setup as follows,

```
load("@aspect_rules_js//js:defs.bzl", "js_run_devserver")
load("@npm//:http-server/package_json.bzl", http_server_bin = "bin")

http_server_bin.http_server_binary(
    name = "http_server",
)

js_run_devserver(
    name = "serve",
    args = ["."],
    data = ["index.html"],
    tool = ":http_server",
)
```

A Next.js devserver can be setup as follows,

```
js_run_devserver(
    name = "dev",
    args = ["dev"],
    command = "./node_modules/.bin/next",
    data = [
        "next.config.js",
        "package.json",
        ":node_modules/next",
        ":node_modules/react",
        ":node_modules/react-dom",
        ":node_modules/typescript",
        "//pages",
        "//public",
        "//styles",
    ],
)
```

where the `./node_modules/.bin/next` bin entry of Next.js is configured in
`npm_translate_lock` as such,

```
npm_translate_lock(
    name = "npm",
    bins = {
        # derived from "bin" attribute in node_modules/next/package.json
        "next": {
            "next": "./dist/bin/next",
        },
    },
    pnpm_lock = "//:pnpm-lock.yaml",
)
```

and run in watch mode using [ibazel](https://github.com/bazelbuild/bazel-watcher) with
`ibazel run //:dev`.

The devserver specified by either `tool` or `command` is run in a custom sandbox that is more
compatible with devserver watch modes in Node.js tools such as Webpack and Next.js.

The custom sandbox is populated with the default outputs of all targets in `data`
as well as transitive sources & npm links.

An an optimization, virtual store files are explicitly excluded from the sandbox since the npm
links will point to the virtual store in the execroot and Node.js will follow those links as it
does within the execroot. As a result, rules_js npm package link targets such as
`//:node_modules/next` are handled efficiently. Since these targets are symlinks in the output
tree, they are recreated as symlinks in the custom sandbox and do not incur a fully copy of the
underlying npm packages.

Supports running with [ibazel](https://github.com/bazelbuild/bazel-watcher).
Only `data` files that change on incremental builds are synchronized when running with ibazel.
"ۜ
�V
js_run_devserver�Runs a devserver via binary target or command.

A simple http-server, for example, can be setup as follows,

```
load("@aspect_rules_js//js:defs.bzl", "js_run_devserver")
load("@npm//:http-server/package_json.bzl", http_server_bin = "bin")

http_server_bin.http_server_binary(
    name = "http_server",
)

js_run_devserver(
    name = "serve",
    args = ["."],
    data = ["index.html"],
    tool = ":http_server",
)
```

A Next.js devserver can be setup as follows,

```
js_run_devserver(
    name = "dev",
    args = ["dev"],
    command = "./node_modules/.bin/next",
    data = [
        "next.config.js",
        "package.json",
        ":node_modules/next",
        ":node_modules/react",
        ":node_modules/react-dom",
        ":node_modules/typescript",
        "//pages",
        "//public",
        "//styles",
    ],
)
```

where the `./node_modules/.bin/next` bin entry of Next.js is configured in
`npm_translate_lock` as such,

```
npm_translate_lock(
    name = "npm",
    bins = {
        # derived from "bin" attribute in node_modules/next/package.json
        "next": {
            "next": "./dist/bin/next",
        },
    },
    pnpm_lock = "//:pnpm-lock.yaml",
)
```

and run in watch mode using [ibazel](https://github.com/bazelbuild/bazel-watcher) with
`ibazel run //:dev`.

The devserver specified by either `tool` or `command` is run in a custom sandbox that is more
compatible with devserver watch modes in Node.js tools such as Webpack and Next.js.

The custom sandbox is populated with the default outputs of all targets in `data`
as well as transitive sources & npm links.

An an optimization, virtual store files are explicitly excluded from the sandbox since the npm
links will point to the virtual store in the execroot and Node.js will follow those links as it
does within the execroot. As a result, rules_js npm package link targets such as
`//:node_modules/next` are handled efficiently. Since these targets are symlinks in the output
tree, they are recreated as symlinks in the custom sandbox and do not incur a fully copy of the
underlying npm packages.

Supports running with [ibazel](https://github.com/bazelbuild/bazel-watcher).
Only `data` files that change on incremental builds are synchronized when running with ibazel.
*
nameA unique name for this target. >
3allow_execroot_entry_point_with_no_copy_data_to_bin2False�
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/"))) + "$(rootpath //path/to/some:file)"],
)
```2""
command2""�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

NB: `data` files are copied to the Bazel output tree before being passed
as inputs to runfiles. See `copy_data_to_bin` docstring for more info.
2[]�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/aspect-build/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 �
env�Environment variables of the action.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution.

2{}i
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�

fixed_args�Fixed command line arguments to pass to the Node.js when this
binary target is executed.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution.

Unlike the built-in `args`, which are only passed to the target when it is
executed either by the `bazel run` command or as a test, `fixed_args` are baked
into the generated launcher script so are always passed even when the binary
target is run outside of Bazel directly from the launcher script.

`fixed_args` are passed before the ones specified in `args` and before ones
that are specified on the `bazel run` or `bazel test` command line.

See https://bazel.build/reference/be/common-definitions#common-attributes-binaries
for more info on the built-in `args` attribute.
2[]*
grant_sandbox_write_permissions2False�
include_declarations�When True, `declarations` and `transitive_declarations` from `JsInfo` providers in data targets are included in the runfiles of the target.

Defaults to false since declarations are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
include_npm_linked_packages�When True, files in `npm_linked_packages` and `transitive_npm_linked_packages` from `JsInfo` providers in data targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in data targets are also included in the runfiles of the target.
2True�
include_transitive_sourcessWhen True, `transitive_sources` from `JsInfo` providers in data targets are included in the runfiles of the target.2True�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.

Log levels: fatal, error, warn, info, debug2"error"�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
node_toolchain�The Node.js toolchain to use for this target.

See https://bazelbuild.github.io/rules_nodejs/Toolchains.html

Typically this is left unset so that Bazel automatically selects the right Node.js toolchain
for the target platform. See https://bazel.build/extending/toolchains#toolchain-resolution
for more information.
2None�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2True
tool_exec_cfg2None
tool_target_cfg2None�
unresolved_symlinks_enabled�Whether unresolved symlinks are enabled in the current build configuration.

These are enabled with the --experimental_allow_unresolved_symlinks flag.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
2False"
use_execroot_entry_point2True
ii,
*
nameA unique name for this target. @
>
3allow_execroot_entry_point_with_no_copy_data_to_bin2False�
�
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/"))) + "$(rootpath //path/to/some:file)"],
)
```2""

command2""�
�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

NB: `data` files are copied to the Bazel output tree before being passed
as inputs to runfiles. See `copy_data_to_bin` docstring for more info.
2[]�
�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
�
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/aspect-build/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 �
�
env�Environment variables of the action.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution.

2{}k
i
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�
�

fixed_args�Fixed command line arguments to pass to the Node.js when this
binary target is executed.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution.

Unlike the built-in `args`, which are only passed to the target when it is
executed either by the `bazel run` command or as a test, `fixed_args` are baked
into the generated launcher script so are always passed even when the binary
target is run outside of Bazel directly from the launcher script.

`fixed_args` are passed before the ones specified in `args` and before ones
that are specified on the `bazel run` or `bazel test` command line.

See https://bazel.build/reference/be/common-definitions#common-attributes-binaries
for more info on the built-in `args` attribute.
2[],
*
grant_sandbox_write_permissions2False�
�
include_declarations�When True, `declarations` and `transitive_declarations` from `JsInfo` providers in data targets are included in the runfiles of the target.

Defaults to false since declarations are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
�
include_npm_linked_packages�When True, files in `npm_linked_packages` and `transitive_npm_linked_packages` from `JsInfo` providers in data targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in data targets are also included in the runfiles of the target.
2True�
�
include_transitive_sourcessWhen True, `transitive_sources` from `JsInfo` providers in data targets are included in the runfiles of the target.2True�
�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.

Log levels: fatal, error, warn, info, debug2"error"�
�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
�
node_toolchain�The Node.js toolchain to use for this target.

See https://bazelbuild.github.io/rules_nodejs/Toolchains.html

Typically this is left unset so that Bazel automatically selects the right Node.js toolchain
for the target platform. See https://bazel.build/extending/toolchains#toolchain-resolution
for more information.
2None�
�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2True

tool_exec_cfg2None

tool_target_cfg2None�
�
unresolved_symlinks_enabled�Whether unresolved symlinks are enabled in the current build configuration.

These are enabled with the --experimental_allow_unresolved_symlinks flag.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
2False$
"
use_execroot_entry_point2Trueo	js_binary*`
D
	js_binary

kwargs(2+
	js_binary@@aspect_rules_js//js:defs.bzl
*
_js_binarygjs_test*Z
@
js_test

kwargs(2)
js_test@@aspect_rules_js//js:defs.bzl
***_js_test�
//js/private:js_binary.bzlr�
,
aspect_rules_js
js/privatejs_binary.bzl%
	js_binary
_js_binary
!
js_test_js_test

�
//js/private:js_filegroup.bzlrl
/
aspect_rules_js
js/privatejs_filegroup.bzl+
js_filegroup_js_filegroup



�
//js/private:js_image_layer.bzlrr
1
aspect_rules_js
js/privatejs_image_layer.bzl/
js_image_layer_js_image_layer

�
//js/private:js_library.bzlrf
-
aspect_rules_js
js/privatejs_library.bzl'

js_library_js_library

�
//js/private:js_run_binary.bzlro
0
aspect_rules_js
js/privatejs_run_binary.bzl-
js_run_binary_js_run_binary

�
!//js/private:js_run_devserver.bzlrx
3
aspect_rules_js
js/privatejs_run_devserver.bzl3
js_run_devserver_js_run_devserver

%Rules for running JavaScript programs�
+
aspect_rules_jsjsdev_repositories.bzl�rules_js_dev_dependencies0Fetch repositories used for developing the rules*�
�
rules_js_dev_dependencies0Fetch repositories used for developing the rules2G
rules_js_dev_dependencies*@@aspect_rules_js//js:dev_repositories.bzl


�
//js/private:maybe.bzlrj
(
aspect_rules_js
js/private	maybe.bzl0
maybe_http_archivehttp_archive
0<
T�Our "development" dependencies

Users should *not* need to install these. If users see a load()
statement from these, that's a bug in our distribution.
�	

aspect_rules_jsjslibs.bzl�
//js/private:js_binary.bzlrk
,
aspect_rules_js
js/privatejs_binary.bzl-
js_binary_lib_js_binary_lib

�
//js/private:js_helpers.bzlr�
-
aspect_rules_js
js/privatejs_helpers.bzl[
$DOWNSTREAM_LINKED_NPM_DEPS_DOCSTRING%_DOWNSTREAM_LINKED_NPM_DEPS_DOCSTRING
		*;
JS_LIBRARY_DATA_ATTR_JS_LIBRARY_DATA_ATTR


'

LOG_LEVELS_LOG_LEVELS
7
envs_for_log_level_envs_for_log_level
O
gather_files_from_js_providers_gather_files_from_js_providers
$G
gather_npm_linked_packages_gather_npm_linked_packages
 M
gather_npm_package_store_deps_gather_npm_package_store_deps
#1
gather_runfiles_gather_runfiles
O
gather_transitive_declarations_gather_transitive_declarations
$E
gather_transitive_sources_gather_transitive_sources

�
//js/private:js_library.bzlrn
-
aspect_rules_js
js/privatejs_library.bzl/
js_library_lib_js_library_lib

0Starlark libraries for building derivative rules�
$
aspect_rules_jsjsproviders.bzl�js_infoConstruct a JsInfo.*�
�
js_info6
declarationsSee JsInfo documentation
depset([])(B
npm_linked_package_filesSee JsInfo documentation
depset([])(=
npm_linked_packagesSee JsInfo documentation
depset([])(@
npm_package_store_depsSee JsInfo documentation
depset([])(1
sourcesSee JsInfo documentation
depset([])(A
transitive_declarationsSee JsInfo documentation
depset([])(M
#transitive_npm_linked_package_filesSee JsInfo documentation
depset([])(H
transitive_npm_linked_packagesSee JsInfo documentation
depset([])(<
transitive_sourcesSee JsInfo documentation
depset([])(Construct a JsInfo."
A JsInfo provider24
js_info)@@aspect_rules_js//js/private:js_info.bzl
�JsInfoOEncapsulates information provided by rules in rules_js and derivative rule sets2�
�	
JsInfoOEncapsulates information provided by rules in rules_js and derivative rule setsD
declarations4A depset of declaration files produced by the target_
npm_linked_package_filesCA depset of files in npm linked package dependencies of this targetf
npm_linked_packagesOA depset of NpmLinkedPackageInfo providers that are dependencies of this target�
npm_package_store_deps�A depset of NpmPackageStoreInfo providers from non-dev npm dependencies of this target and the target's transitive dependencies to use as direct dependencies when linking downstream npm_package targets with npm_link_package:
sources/A depset of source files produced by the targetp
transitive_declarationsUA depset of declaration files produced by the target and the target's transitive deps�
#transitive_npm_linked_package_filesdA depset of files in npm linked package dependencies of this target and the target's transitive deps�
transitive_npm_linked_packagespA depset of NpmLinkedPackageInfo providers that are dependencies of this target and the target's transitive depsf
transitive_sourcesPA depset of source files produced by the target and the target's transitive deps"-
JsInfo#@@aspect_rules_js//js:providers.bzl
F
D
declarations4A depset of declaration files produced by the targeta
_
npm_linked_package_filesCA depset of files in npm linked package dependencies of this targeth
f
npm_linked_packagesOA depset of NpmLinkedPackageInfo providers that are dependencies of this target�
�
npm_package_store_deps�A depset of NpmPackageStoreInfo providers from non-dev npm dependencies of this target and the target's transitive dependencies to use as direct dependencies when linking downstream npm_package targets with npm_link_package<
:
sources/A depset of source files produced by the targetr
p
transitive_declarationsUA depset of declaration files produced by the target and the target's transitive deps�
�
#transitive_npm_linked_package_filesdA depset of files in npm linked package dependencies of this target and the target's transitive deps�
�
transitive_npm_linked_packagespA depset of NpmLinkedPackageInfo providers that are dependencies of this target and the target's transitive depsh
f
transitive_sourcesPA depset of source files produced by the target and the target's transitive deps�
//js/private:js_info.bzlr~
*
aspect_rules_js
js/privatejs_info.bzl
JsInfo_JsInfo
!
js_info_js_info

'Providers for building derivative rules�
'
aspect_rules_jsjsrepositories.bzl�rules_js_dependencies*h
X
rules_js_dependencies2?
rules_js_dependencies&@@aspect_rules_js//js:repositories.bzl
		�
//js/private:maybe.bzlrj
(
aspect_rules_js
js/private	maybe.bzl0
maybe_http_archivehttp_archive
0<
T�Declare runtime dependencies

These are needed for local dev, and users must install them as well.
See https://docs.bazel.build/versions/main/skylark/deploying.html#dependencies
�
=
aspect_rules_jsnpm/private/testpackage_json_checked.bzl�bin_factory*�
p
bin_factory
link_root_name (2K
bin_factory<@@aspect_rules_js//npm/private/test:package_json_checked.bzl
CC�rollup*�
h
rollup

name (

kwargs(2F
rollup<@@aspect_rules_js//npm/private/test:package_json_checked.bzl
::*_rollup_internal�rollup_binary*�
v
rollup_binary

name (

kwargs(2M
rollup_binary<@@aspect_rules_js//npm/private/test:package_json_checked.bzl
@@*_rollup_binary_internal�rollup_test*�
r
rollup_test

name (

kwargs(2K
rollup_test<@@aspect_rules_js//npm/private/test:package_json_checked.bzl
==*_rollup_test_internal�
//lib:directory_path.bzlrl
+
aspect_bazel_liblibdirectory_path.bzl/
directory_path_directory_path
3B
V�
//js:defs.bzlr�

aspect_rules_jsjsdefs.bzl%
	js_binary
_js_binary
'1-
js_run_binary_js_run_binary
AO!
js_test_js_test
ck
xX@generated by @aspect_rules_js//npm/private:npm_import.bzl for npm package rollup@2.70.2�
I
aspect_rules_jsnpm/private/test$package_json_with_dashes_checked.bzl�bin_factory*�
|
bin_factory
link_root_name (2W
bin_factoryH@@aspect_rules_js//npm/private/test:package_json_with_dashes_checked.bzl
CC�webpack_bundle_analyzer*�
�
webpack_bundle_analyzer

name (

kwargs(2c
webpack_bundle_analyzerH@@aspect_rules_js//npm/private/test:package_json_with_dashes_checked.bzl
::*!_webpack_bundle_analyzer_internal�webpack_bundle_analyzer_binary*�
�
webpack_bundle_analyzer_binary

name (

kwargs(2j
webpack_bundle_analyzer_binaryH@@aspect_rules_js//npm/private/test:package_json_with_dashes_checked.bzl
@@*(_webpack_bundle_analyzer_binary_internal�webpack_bundle_analyzer_test*�
�
webpack_bundle_analyzer_test

name (

kwargs(2h
webpack_bundle_analyzer_testH@@aspect_rules_js//npm/private/test:package_json_with_dashes_checked.bzl
==*&_webpack_bundle_analyzer_test_internal�
//lib:directory_path.bzlrl
+
aspect_bazel_liblibdirectory_path.bzl/
directory_path_directory_path
3B
V�
//js:defs.bzlr�

aspect_rules_jsjsdefs.bzl%
	js_binary
_js_binary
'1-
js_run_binary_js_run_binary
AO!
js_test_js_test
ck
xy@generated by @aspect_rules_js//npm/private:npm_import.bzl for npm package webpack-bundle-analyzer@4.5.0_bufferutil_4.0.7�
=
aspect_rules_jsnpm/private/testrepositories_checked.bzl�npm_repositoriesXGenerated npm_import repository rules corresponding to npm packages in //:pnpm-lock.yaml*�
�
npm_repositoriesXGenerated npm_import repository rules corresponding to npm packages in //:pnpm-lock.yaml2P
npm_repositories<@@aspect_rules_js//npm/private/test:repositories_checked.bzl
|
//npm:repositories.bzlr`
(
aspect_rules_jsnpmrepositories.bzl&

npm_import
npm_import
1;
=O@generated by npm_translate_lock(name = "npm", pnpm_lock = "//:pnpm-lock.yaml")�
0
aspect_rules_jsnpm/privatelist_sources.bzl�list_sources"�
�
list_sources*
nameA unique name for this target. 
srcs2[]"?
list_sources/@@aspect_rules_js//npm/private:list_sources.bzl
,
*
nameA unique name for this target. 

srcs2[]'Output a list of source files to a file��
.
aspect_rules_jsnpm/privatenpm_import.bzl�m
npm_import� Import a single npm package into Bazel.

Normally you'd want to use `npm_translate_lock` to import all your packages at once.
It generates `npm_import` rules.
You can create these manually if you want to have exact control.

Bazel will only fetch the given package from an external registry if the package is
required for the user-requested targets to be build/tested.

This is a repository rule, which should be called from your `WORKSPACE` file
or some `.bzl` file loaded from it. For example, with this code in `WORKSPACE`:

```starlark
npm_import(
    name = "npm__at_types_node_15.12.2",
    package = "@types/node",
    version = "15.12.2",
    integrity = "sha512-zjQ69G564OCIWIOHSXyQEEDpdpGl+G348RAKY0XXy9Z5kU9Vzv1GMNnkar/ZJ8dzXB3COzD9Mo9NtRZ4xfgUww==",
)
```

> This is similar to Bazel rules in other ecosystems named "_import" like
> `apple_bundle_import`, `scala_import`, `java_import`, and `py_import`.
> `go_repository` is also a model for this rule.

The name of this repository should contain the version number, so that multiple versions of the same
package don't collide.
(Note that the npm ecosystem always supports multiple versions of a library depending on where
it is required, unlike other languages like Go or Python.)

To consume the downloaded package in rules, it must be "linked" into the link package in the
package's `BUILD.bazel` file:

```
load("@npm__at_types_node__15.12.2__links//:defs.bzl", npm_link_types_node = "npm_link_imported_package")

npm_link_types_node(name = "node_modules")
```

This links `@types/node` into the `node_modules` of this package with the target name `:node_modules/@types/node`.

A `:node_modules/@types/node/dir` filegroup target is also created that provides the the directory artifact of the npm package.
This target can be used to create entry points for binary target or to access files within the npm package.

NB: You can choose any target name for the link target but we recommend using the `node_modules/@scope/name` and
`node_modules/name` convention for readability.

When using `npm_translate_lock`, you can link all the npm dependencies in the lock file for a package:

```
load("@npm//:defs.bzl", "npm_link_all_packages")

npm_link_all_packages(name = "node_modules")
```

This creates `:node_modules/name` and `:node_modules/@scope/name` targets for all direct npm dependencies in the package.
It also creates `:node_modules/name/dir` and `:node_modules/@scope/name/dir` filegroup targets that provide the the directory artifacts of their npm packages.
These target can be used to create entry points for binary target or to access files within the npm package.

If you have a mix of `npm_link_all_packages` and `npm_link_imported_package` functions to call you can pass the
`npm_link_imported_package` link functions to the `imported_links` attribute of `npm_link_all_packages` to link
them all in one call. For example,

```
load("@npm//:defs.bzl", "npm_link_all_packages")
load("@npm__at_types_node__15.12.2__links//:defs.bzl", npm_link_types_node = "npm_link_imported_package")

npm_link_all_packages(
    name = "node_modules",
    imported_links = [
        npm_link_types_node,
    ]
)
```

This has the added benefit of adding the `imported_links` to the convienence `:node_modules` target which
includes all direct dependencies in that package.

NB: You can pass an name to npm_link_all_packages and this will change the targets generated to "{name}/@scope/name" and
"{name}/name". We recommend using "node_modules" as the convention for readability.

To change the proxy URL we use to fetch, configure the Bazel downloader:

1. Make a file containing a rewrite rule like

    `rewrite (registry.nodejs.org)/(.*) artifactory.build.internal.net/artifactory/$1/$2`

1. To understand the rewrites, see [UrlRewriterConfig] in Bazel sources.

1. Point bazel to the config with a line in .bazelrc like
common --experimental_downloader_config=.bazel_downloader_config

Read more about the downloader config: <https://blog.aspect.dev/configuring-bazels-downloader>

[UrlRewriterConfig]: https://github.com/bazelbuild/bazel/blob/4.2.1/src/main/java/com/google/devtools/build/lib/bazel/repository/downloader/UrlRewriterConfig.java#L66
*�L
�L

npm_import)
nameName for this repository rule (H
package9Name of the npm package, such as `acorn` or `@types/node` (:
version+Version of the npm package, such as `8.4.0` (v
depshA dict other npm packages this one depends on where the key is the package name and value is the version{}(�
extra_build_content�Additional content to append on the generated BUILD file at the root of
the created repository, either as a string or a list of lines similar to
<https://github.com/bazelbuild/bazel-skylib/blob/main/docs/write_file_doc.md>.""(�
transitive_closure�A dict all npm packages this one depends on directly or transitively where the key is the
package name and value is a list of version(s) depended on in the closure.{}(�
root_package�The root package where the node_modules virtual store is linked to.
Typically this is the package that the pnpm-lock.yaml file is located when using `npm_translate_lock`.""(�
link_workspace�The workspace name where links will be created for this package.

This is typically set in rule sets and libraries that are to be consumed as external repositories so
links are created in the external repository and not the user workspace.

Can be left unspecified if the link workspace is the user workspace.""(�
link_packages�Dict of paths where links may be created at for this package to
a list of link aliases to link as in each package. If aliases are an
empty list this indicates to link as the package name.

Defaults to {} which indicates that links may be created in any package as specified by
the `direct` attribute of the generated npm_link_package.{}(m
lifecycle_hooksTList of lifecycle hook `package.json` scripts to run for this package if they exist.[](�
&lifecycle_hooks_execution_requirements�Execution requirements when running the lifecycle hooks.

For example:

```
lifecycle_hooks_execution_requirements: ["no-sandbox', "requires-network"]
```

This defaults to ["no-sandbox"] to limit the overhead of sandbox creation and copying the output
TreeArtifact out of the sandbox.["no-sandbox"](�
lifecycle_hooks_env�Environment variables set for the lifecycle hooks action for this npm
package if there is one.

Environment variables are defined by providing an array of "key=value" entries.

For example:

```
lifecycle_hooks_env: ["PREBULT_BINARY=https://downloadurl"],
```[](�
	integrity�Expected checksum of the file downloaded, in Subresource Integrity format.
This must match the checksum of the file downloaded.

This is the same as appears in the pnpm-lock.yaml, yarn.lock or package-lock.json file.

It is a security risk to omit the checksum as remote files can change.

At best omitting this field will make your build non-hermetic.

It is optional to make development easier but should be set before shipping.""(�
url�Optional url for this package. If unset, a default npm registry url is generated from
the package name and version.

May start with `git+ssh://` or `git+https://` to indicate a git repository. For example,

```
git+ssh://git@github.com/org/repo.git
```

If url is configured as a git repository, the commit attribute must be set to the
desired commit.""(M
commit=Specific commit to be checked out if url is a git repository.""(y

patch_args`Arguments to pass to the patch tool.

`-p1` will usually be needed for patches generated by git.["-p0"](F
patches5Patch files to apply onto the downloaded npm package.[](�
custom_postinstall�Custom string postinstall script to run on the installed npm package. Runs after any
existing lifecycle hooks if `run_lifecycle_hooks` is True.""(X
npm_authFAuth token to authenticate with npm. When using Bearer authentication.""(�
npm_auth_basic�Auth token to authenticate with npm. When using Basic authentication.

This is typically the base64 encoded string "username:password".""(c
npm_auth_usernameHAuth username to authenticate with npm. When using Basic authentication.""(c
npm_auth_passwordHAuth password to authenticate with npm. When using Basic authentication.""(�
bins�Dictionary of `node_modules/.bin` binary files to create mapped to their node entry points.

This is typically derived from the "bin" attribute in the package.json
file of the npm package being linked.

For example:

```
bins = {
    "foo": "./foo.js",
    "bar": "./bar.js",
}
```

In the future, this field may be automatically populated by npm_translate_lock
from information in the pnpm lock file. That feature is currently blocked on
https://github.com/pnpm/pnpm/issues/5131.{}(<
dev,Whether this npm package is a dev dependencyFalse(�
"register_copy_directory_toolchains�if True, `@aspect_bazel_lib//lib:repositories.bzl` `register_copy_directory_toolchains()` is called if the toolchain is not already registeredTrue(�
%register_copy_to_directory_toolchains�if True, `@aspect_bazel_lib//lib:repositories.bzl` `register_copy_to_directory_toolchains()` is called if the toolchain is not already registeredTrue(�
run_lifecycle_hooks�If True, runs `preinstall`, `install`, `postinstall` and 'prepare' lifecycle hooks declared
in this package.

Deprecated. Use `lifecycle_hooks` instead.None(�
lifecycle_hooks_no_sandbox�If True, adds "no-sandbox" to `lifecycle_hooks_execution_requirements`.

Deprecated. Add "no-sandbox" to `lifecycle_hooks_execution_requirements` instead.None(
kwargsInternal use only(� Import a single npm package into Bazel.

Normally you'd want to use `npm_translate_lock` to import all your packages at once.
It generates `npm_import` rules.
You can create these manually if you want to have exact control.

Bazel will only fetch the given package from an external registry if the package is
required for the user-requested targets to be build/tested.

This is a repository rule, which should be called from your `WORKSPACE` file
or some `.bzl` file loaded from it. For example, with this code in `WORKSPACE`:

```starlark
npm_import(
    name = "npm__at_types_node_15.12.2",
    package = "@types/node",
    version = "15.12.2",
    integrity = "sha512-zjQ69G564OCIWIOHSXyQEEDpdpGl+G348RAKY0XXy9Z5kU9Vzv1GMNnkar/ZJ8dzXB3COzD9Mo9NtRZ4xfgUww==",
)
```

> This is similar to Bazel rules in other ecosystems named "_import" like
> `apple_bundle_import`, `scala_import`, `java_import`, and `py_import`.
> `go_repository` is also a model for this rule.

The name of this repository should contain the version number, so that multiple versions of the same
package don't collide.
(Note that the npm ecosystem always supports multiple versions of a library depending on where
it is required, unlike other languages like Go or Python.)

To consume the downloaded package in rules, it must be "linked" into the link package in the
package's `BUILD.bazel` file:

```
load("@npm__at_types_node__15.12.2__links//:defs.bzl", npm_link_types_node = "npm_link_imported_package")

npm_link_types_node(name = "node_modules")
```

This links `@types/node` into the `node_modules` of this package with the target name `:node_modules/@types/node`.

A `:node_modules/@types/node/dir` filegroup target is also created that provides the the directory artifact of the npm package.
This target can be used to create entry points for binary target or to access files within the npm package.

NB: You can choose any target name for the link target but we recommend using the `node_modules/@scope/name` and
`node_modules/name` convention for readability.

When using `npm_translate_lock`, you can link all the npm dependencies in the lock file for a package:

```
load("@npm//:defs.bzl", "npm_link_all_packages")

npm_link_all_packages(name = "node_modules")
```

This creates `:node_modules/name` and `:node_modules/@scope/name` targets for all direct npm dependencies in the package.
It also creates `:node_modules/name/dir` and `:node_modules/@scope/name/dir` filegroup targets that provide the the directory artifacts of their npm packages.
These target can be used to create entry points for binary target or to access files within the npm package.

If you have a mix of `npm_link_all_packages` and `npm_link_imported_package` functions to call you can pass the
`npm_link_imported_package` link functions to the `imported_links` attribute of `npm_link_all_packages` to link
them all in one call. For example,

```
load("@npm//:defs.bzl", "npm_link_all_packages")
load("@npm__at_types_node__15.12.2__links//:defs.bzl", npm_link_types_node = "npm_link_imported_package")

npm_link_all_packages(
    name = "node_modules",
    imported_links = [
        npm_link_types_node,
    ]
)
```

This has the added benefit of adding the `imported_links` to the convienence `:node_modules` target which
includes all direct dependencies in that package.

NB: You can pass an name to npm_link_all_packages and this will change the targets generated to "{name}/@scope/name" and
"{name}/name". We recommend using "node_modules" as the convention for readability.

To change the proxy URL we use to fetch, configure the Bazel downloader:

1. Make a file containing a rewrite rule like

    `rewrite (registry.nodejs.org)/(.*) artifactory.build.internal.net/artifactory/$1/$2`

1. To understand the rewrites, see [UrlRewriterConfig] in Bazel sources.

1. Point bazel to the config with a line in .bazelrc like
common --experimental_downloader_config=.bazel_downloader_config

Read more about the downloader config: <https://blog.aspect.dev/configuring-bazels-downloader>

[UrlRewriterConfig]: https://github.com/bazelbuild/bazel/blob/4.2.1/src/main/java/com/google/devtools/build/lib/bazel/repository/downloader/UrlRewriterConfig.java#L66
2;

npm_import-@@aspect_rules_js//npm/private:npm_import.bzl
��2npm_import_rule�npm_import_linksR�
�
npm_import_links.
name"A unique name for this repository. 
bins
2{}
deps
2{}
dev2False!
lifecycle_build_target2False
lifecycle_hooks_env2[].
&lifecycle_hooks_execution_requirements2[]
link_packages 
npm_translate_lock_repo2""
package �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 
root_package2""
transitive_closure 
version *A
npm_import_links-@@aspect_rules_js//npm/private:npm_import.bzl
�#�#0
.
name"A unique name for this repository. 

bins
2{}

deps
2{}

dev2False#
!
lifecycle_build_target2False

lifecycle_hooks_env2[]0
.
&lifecycle_hooks_execution_requirements2[]

link_packages !

npm_translate_lock_repo2""

package �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 

root_package2""

transitive_closure 

version �npm_import_ruleR�
�
npm_import_rule.
name"A unique name for this repository. 
commit2""
custom_postinstall2""
extra_build_content2""'
generate_bzl_library_targets2False
	integrity2""
lifecycle_hooks2[]
link_packages 
link_workspace2""
npm_auth2""
npm_auth_basic2""
npm_auth_password2""
npm_auth_username2""
package 

patch_args2[]
patches2[]�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 
root_package2""
url2""
version *@
npm_import_rule-@@aspect_rules_js//npm/private:npm_import.bzl
�"�"0
.
name"A unique name for this repository. 

commit2""

custom_postinstall2""

extra_build_content2"")
'
generate_bzl_library_targets2False

	integrity2""

lifecycle_hooks2[]

link_packages 

link_workspace2""

npm_auth2""

npm_auth_basic2""

npm_auth_password2""

npm_auth_username2""

package 


patch_args2[]

patches2[]�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 

root_package2""

url2""

version �
//lib:repo_utils.bzlr}
'
aspect_bazel_liblibrepo_utils.bzl
patchpatch
05&

repo_utils
repo_utils
9C
E�
//lib:repositories.bzlr�
)
aspect_bazel_liblibrepositories.bzlW
"register_copy_directory_toolchains#_register_copy_directory_toolchains
1T^
%register_copy_to_directory_toolchains&_register_copy_to_directory_toolchains
}�
��
//lib:utils.bzlrp
"
aspect_bazel_liblib	utils.bzl<
is_bazel_6_or_greateris_bazel_6_or_greater
+@
B�
(//npm/private:starlark_codegen_utils.bzlr�
:
aspect_rules_jsnpm/privatestarlark_codegen_utils.bzl>
starlark_codegen_utilsstarlark_codegen_utils
CY
[t
//npm/private:utils.bzlrW
)
aspect_rules_jsnpm/private	utils.bzl
utilsutils
27
9a
//lib:dicts.bzlrL

bazel_skyliblib	dicts.bzl
dictsdicts
',
.a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.�
&//tools/build_defs/repo:git_worker.bzlr�
4
bazel_toolstools/build_defs/repogit_worker.bzl+

add_origin_git_add_origin
!
clean
_git_clean
!
fetch
_git_fetch

init	_git_init
  !
reset
_git_reset
!!
"�
Repository rule to fetch npm packages.

Load this with,

```starlark
load("@aspect_rules_js//npm:repositories.bzl", "npm_import")
```

This uses Bazel's downloader to fetch the packages.
You can use this to redirect all fetches through a store like Artifactory.

See &lt;https://blog.aspect.dev/configuring-bazels-downloader&gt; for more info about how it works
and how to configure it.

See [`npm_translate_lock`](#npm_translate_lock) for the primary user-facing API to fetch npm packages
for a given lockfile.
�\
4
aspect_rules_jsnpm/privatenpm_link_package.bzl�Xnpm_link_package�"Links an npm package to node_modules if link is True.

When called at the root_package, a virtual store target is generated named `link__{bazelified_name}__store`.

When linking, a `{name}` target is generated which consists of the `node_modules/<package>` symlink and transitively
its virtual store link and the virtual store links of the transitive closure of deps.

When linking, `{name}/dir` filegroup is also generated that refers to a directory artifact can be used to access
the package directory for creating entry points or accessing files in the package.


Defines a npm package that is linked into a node_modules tree.

The npm package is linked with a pnpm style symlinked node_modules output tree.

The term "package" is defined at
<https://nodejs.org/docs/latest-v16.x/api/packages.html>

See https://pnpm.io/symlinked-node-modules-structure for more information on
the symlinked node_modules structure.
Npm may also support a symlinked node_modules structure called
"Isolated mode" in the future:
https://github.com/npm/rfcs/blob/main/accepted/0042-isolated-mode.md.
"�O
�,
npm_link_package�"Links an npm package to node_modules if link is True.

When called at the root_package, a virtual store target is generated named `link__{bazelified_name}__store`.

When linking, a `{name}` target is generated which consists of the `node_modules/<package>` symlink and transitively
its virtual store link and the virtual store links of the transitive closure of deps.

When linking, `{name}/dir` filegroup is also generated that refers to a directory artifact can be used to access
the package directory for creating entry points or accessing files in the package.


Defines a npm package that is linked into a node_modules tree.

The npm package is linked with a pnpm style symlinked node_modules output tree.

The term "package" is defined at
<https://nodejs.org/docs/latest-v16.x/api/packages.html>

See https://pnpm.io/symlinked-node-modules-structure for more information on
the symlinked node_modules structure.
Npm may also support a symlinked node_modules structure called
"Isolated mode" in the future:
https://github.com/npm/rfcs/blob/main/accepted/0042-isolated-mode.md.
*
nameA unique name for this target. �
deps�Other node packages store link targets one depends on mapped to the name to link them under in this packages deps.

This should include *all* modules the program may need at runtime.

You can find all the package store link targets in your repository with

```
bazel query ... | grep :.aspect_rules_js | grep -v /dir | grep -v /pkg | grep -v /ref
```

Package store link targets names for 3rd party packages that come from `npm_translate_lock`
start with `.aspect_rules_js/` then the name passed to the `npm_link_all_packages` macro
(typically `node_modules`) followed by `/<package>/<version>` where `package` is the
package name (including @scope segment if any) and `version` is the specific version of
the package that comes from the pnpm-lock.yaml file.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

The version may include peer dep(s),

```
//:.aspect_rules_js/node_modules/debug/4.3.4_supports-color@8.1.1
```

It could be also be a url based version,

```
//:.aspect_rules_js/node_modules/debug/github.com/ngokevin/debug/9742c5f383a6f8046241920156236ade8ec30d53
```

Package store link targets names for 3rd party package that come directly from an
`npm_import` start with `.aspect_rules_js/` then the name passed to the `npm_import`'s `npm_link_imported_package`
macro (typically `node_modules`) followed by `/<package>/<version>` where `package`
matches the `package` attribute in the npm_import of the package and `version` matches the
`version` attribute.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

Package store link targets names for 1st party packages automatically linked by `npm_link_all_packages`
using workspaces will follow the same pattern as 3rd party packages with the version typically defaulting
to "0.0.0".

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg/0.0.0
```

Package store link targets names for 1st party packages manually linked with `npm_link_package`
start with `.aspect_rules_js/` followed by the name passed to the `npm_link_package`.

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg
```

> In typical usage, a node.js program sometimes requires modules which were
> never declared as dependencies.
> This pattern is typically used when the program has conditional behavior
> that is enabled when the module is found (like a plugin) but the program
> also runs without the dependency.
> 
> This is possible because node.js doesn't enforce the dependencies are sound.
> All files under `node_modules` are available to any program.
> In contrast, Bazel makes it possible to make builds hermetic, which means that
> all dependencies of a program must be declared when running in Bazel's sandbox.
	*
NpmPackageStoreInfo2{}<
dev,Whether this npm package is a dev dependency2False�
hardlink�Controls when to use hardlinks to files instead of making copies.

Creating hardlinks is much faster than making copies of files with the caveat that
hardlinks share file permissions with their source.

Since Bazel removes write permissions on files in the output tree after an action completes,
hardlinks to source files is not recommended since write permissions will be inadvertently
removed from sources files.

- "auto": hardlinks are used for generated files already in the output tree
- "off": all files are copied
- "on": hardlinks are used for all files (not recommended)
2"auto"�
package�The package name to link to.

If unset, the package name in the NpmPackageInfo src must be set.
If set, takes precendance over the package name in the NpmPackageInfo src.
2""i
srcLA npm_package target or or any other target that provides a NpmPackageInfo.
 *
NpmPackageInfo�
use_declare_symlink�Whether to use ctx.actions.declare_symlink to create symlinks.

In Bazel 5.x these are enabled with the --experimental_allow_unresolved_symlinks flag.

Typical usage of this rule is via a macro which automatically sets this
attribute with `select` based on a `config_setting` rule such as,

```
config_setting(
    name = "experimental_allow_unresolved_symlinks",
    values = {"experimental_allow_unresolved_symlinks": "true"},
    visibility = ["//visibility:public"],
)
```
 >
verbose*If true, prints out verbose logs to stdout2False�
version�The package version being linked.

If unset, the package version in the NpmPackageInfo src must be set.
If set, takes precendance over the package version in the NpmPackageInfo src.
2""
,
*
nameA unique name for this target. �
�
deps�Other node packages store link targets one depends on mapped to the name to link them under in this packages deps.

This should include *all* modules the program may need at runtime.

You can find all the package store link targets in your repository with

```
bazel query ... | grep :.aspect_rules_js | grep -v /dir | grep -v /pkg | grep -v /ref
```

Package store link targets names for 3rd party packages that come from `npm_translate_lock`
start with `.aspect_rules_js/` then the name passed to the `npm_link_all_packages` macro
(typically `node_modules`) followed by `/<package>/<version>` where `package` is the
package name (including @scope segment if any) and `version` is the specific version of
the package that comes from the pnpm-lock.yaml file.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

The version may include peer dep(s),

```
//:.aspect_rules_js/node_modules/debug/4.3.4_supports-color@8.1.1
```

It could be also be a url based version,

```
//:.aspect_rules_js/node_modules/debug/github.com/ngokevin/debug/9742c5f383a6f8046241920156236ade8ec30d53
```

Package store link targets names for 3rd party package that come directly from an
`npm_import` start with `.aspect_rules_js/` then the name passed to the `npm_import`'s `npm_link_imported_package`
macro (typically `node_modules`) followed by `/<package>/<version>` where `package`
matches the `package` attribute in the npm_import of the package and `version` matches the
`version` attribute.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

Package store link targets names for 1st party packages automatically linked by `npm_link_all_packages`
using workspaces will follow the same pattern as 3rd party packages with the version typically defaulting
to "0.0.0".

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg/0.0.0
```

Package store link targets names for 1st party packages manually linked with `npm_link_package`
start with `.aspect_rules_js/` followed by the name passed to the `npm_link_package`.

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg
```

> In typical usage, a node.js program sometimes requires modules which were
> never declared as dependencies.
> This pattern is typically used when the program has conditional behavior
> that is enabled when the module is found (like a plugin) but the program
> also runs without the dependency.
> 
> This is possible because node.js doesn't enforce the dependencies are sound.
> All files under `node_modules` are available to any program.
> In contrast, Bazel makes it possible to make builds hermetic, which means that
> all dependencies of a program must be declared when running in Bazel's sandbox.
	*
NpmPackageStoreInfo2{}>
<
dev,Whether this npm package is a dev dependency2False�
�
hardlink�Controls when to use hardlinks to files instead of making copies.

Creating hardlinks is much faster than making copies of files with the caveat that
hardlinks share file permissions with their source.

Since Bazel removes write permissions on files in the output tree after an action completes,
hardlinks to source files is not recommended since write permissions will be inadvertently
removed from sources files.

- "auto": hardlinks are used for generated files already in the output tree
- "off": all files are copied
- "on": hardlinks are used for all files (not recommended)
2"auto"�
�
package�The package name to link to.

If unset, the package name in the NpmPackageInfo src must be set.
If set, takes precendance over the package name in the NpmPackageInfo src.
2""k
i
srcLA npm_package target or or any other target that provides a NpmPackageInfo.
 *
NpmPackageInfo�
�
use_declare_symlink�Whether to use ctx.actions.declare_symlink to create symlinks.

In Bazel 5.x these are enabled with the --experimental_allow_unresolved_symlinks flag.

Typical usage of this rule is via a macro which automatically sets this
attribute with `select` based on a `config_setting` rule such as,

```
config_setting(
    name = "experimental_allow_unresolved_symlinks",
    values = {"experimental_allow_unresolved_symlinks": "true"},
    visibility = ["//visibility:public"],
)
```
 @
>
verbose*If true, prints out verbose logs to stdout2False�
�
version�The package version being linked.

If unset, the package version in the NpmPackageInfo src must be set.
If set, takes precendance over the package version in the NpmPackageInfo src.
2""�
(//npm/private:npm_link_package_store.bzlr�
:
aspect_rules_jsnpm/privatenpm_link_package_store.bzl>
npm_link_package_storenpm_link_package_store
CY
[�
#//npm/private:npm_package_store.bzlr{
5
aspect_rules_jsnpm/privatenpm_package_store.bzl4
npm_package_storenpm_package_store
>O
Qt
//npm/private:utils.bzlrW
)
aspect_rules_jsnpm/private	utils.bzl
utilsutils
27
9npm_link_package rule�#
:
aspect_rules_jsnpm/privatenpm_link_package_store.bzl�npm_link_package_store�Links an npm package that is backed by an npm_package_store into a node_modules tree as a direct dependency.

This is used in conjunction with the npm_package_store rule that outputs an npm package into the
node_modules/.aspect_rules_js virtual store in a pnpm style symlinked node_modules structure.

The term "package" is defined at
<https://nodejs.org/docs/latest-v16.x/api/packages.html>

See https://pnpm.io/symlinked-node-modules-structure for more information on
the symlinked node_modules structure.
Npm may also support a symlinked node_modules structure called
"Isolated mode" in the future:
https://github.com/npm/rfcs/blob/main/accepted/0042-isolated-mode.md.
"�
�
npm_link_package_store�Links an npm package that is backed by an npm_package_store into a node_modules tree as a direct dependency.

This is used in conjunction with the npm_package_store rule that outputs an npm package into the
node_modules/.aspect_rules_js virtual store in a pnpm style symlinked node_modules structure.

The term "package" is defined at
<https://nodejs.org/docs/latest-v16.x/api/packages.html>

See https://pnpm.io/symlinked-node-modules-structure for more information on
the symlinked node_modules structure.
Npm may also support a symlinked node_modules structure called
"Isolated mode" in the future:
https://github.com/npm/rfcs/blob/main/accepted/0042-isolated-mode.md.
*
nameA unique name for this target. �
bins�Dictionary of `node_modules/.bin` binary files to create mapped to their node entry points.

This is typically derived from the "bin" attribute in the package.json
file of the npm package being linked.

For example:

```
bins = {
    "foo": "./foo.js",
    "bar": "./bar.js",
}
```

In the future, this field may be automatically populated by npm_translate_lock
from information in the pnpm lock file. That feature is currently blocked on
https://github.com/pnpm/pnpm/issues/5131.

2{}�
package�The package name to link to.

If unset, the package name of the src npm_package_store is used.
If set, takes precendance over the package name in the src npm_package_store.
2""^
src<The npm_package_store target to link as a direct dependency. *
NpmPackageStoreInfo�
use_declare_symlink�Whether unresolved symlinks are enabled in the current build configuration.

These are enabled with the --experimental_allow_unresolved_symlinks flag.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 "S
npm_link_package_store9@@aspect_rules_js//npm/private:npm_link_package_store.bzl
��,
*
nameA unique name for this target. �
�
bins�Dictionary of `node_modules/.bin` binary files to create mapped to their node entry points.

This is typically derived from the "bin" attribute in the package.json
file of the npm package being linked.

For example:

```
bins = {
    "foo": "./foo.js",
    "bar": "./bar.js",
}
```

In the future, this field may be automatically populated by npm_translate_lock
from information in the pnpm lock file. That feature is currently blocked on
https://github.com/pnpm/pnpm/issues/5131.

2{}�
�
package�The package name to link to.

If unset, the package name of the src npm_package_store is used.
If set, takes precendance over the package name in the src npm_package_store.
2""`
^
src<The npm_package_store target to link as a direct dependency. *
NpmPackageStoreInfo�
�
use_declare_symlink�Whether unresolved symlinks are enabled in the current build configuration.

These are enabled with the --experimental_allow_unresolved_symlinks flag.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
//js:providers.bzlrv
$
aspect_rules_jsjsproviders.bzl
JsInfoJsInfo
-3 
js_infojs_info
7>
@�
)//npm/private:npm_linked_package_info.bzlr�
;
aspect_rules_jsnpm/privatenpm_linked_package_info.bzl:
NpmLinkedPackageInfoNpmLinkedPackageInfo
DX
Z�
(//npm/private:npm_package_store_info.bzlr�
:
aspect_rules_jsnpm/privatenpm_package_store_info.bzl8
NpmPackageStoreInfoNpmPackageStoreInfo
CV
Xt
//npm/private:utils.bzlrW
)
aspect_rules_jsnpm/private	utils.bzl
utilsutils
27
9a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.npm_link_package_store rule�

;
aspect_rules_jsnpm/privatenpm_linked_package_info.bzl�	NpmLinkedPackageInfoProvides a linked npm package2�	
�
NpmLinkedPackageInfoProvides a linked npm packageQ
labelHthe label of the npm_link_package_store target the created this providerC
link_package3package that this npm package is directly linked at#
packagename of this npm package&
versionversion of this npm package_

store_infoQthe NpmPackageStoreInfo of the linked npm package store that is backing this link@
files7depset of files that are part of the linked npm packager
transitive_files^depset of the transitive files that are part of the linked npm package and its transitive deps"R
NpmLinkedPackageInfo:@@aspect_rules_js//npm/private:npm_linked_package_info.bzl
  S
Q
labelHthe label of the npm_link_package_store target the created this providerE
C
link_package3package that this npm package is directly linked at%
#
packagename of this npm package(
&
versionversion of this npm packagea
_

store_infoQthe NpmPackageStoreInfo of the linked npm package store that is backing this linkB
@
files7depset of files that are part of the linked npm packaget
r
transitive_files^depset of the transitive files that are part of the linked npm package and its transitive depsNpmLinkedPackageInfo provider��
/
aspect_rules_jsnpm/privatenpm_package.bzl�npm_package�A rule that packages sources into a directory (a tree artifact) and provides an `NpmPackageInfo`.

This target can be used as the `src` attribute to `npm_link_package`.

Every npm_package target has a sub target named after its name, which is `<name>.publish`, that can be run
to publish to an npm registry.

Under the hood, this target runs `npm publish`. You can pass arguments to npm by escaping them from Bazel using a double-hyphen,
for example: `bazel run my_package.publish -- --tag=next`


Files and directories can be arranged as needed in the output directory using
the `root_paths`, `include_srcs_patters`, `exclude_srcs_patters` and `replace_prefixes` attributes.

Filters and transformations are applied in the following order:

1. `include_external_repositories`

2. `include_srcs_packages`

3. `exclude_srcs_packages`

4. `root_paths`

5. `include_srcs_patterns`

6. `exclude_srcs_patterns`

7. `replace_prefixes`

For more information each filters / transformations applied, see
the documentation for the specific filter / transformation attribute.

Glob patterns are supported. Standard wildcards (globbing patterns) plus the `**` doublestar (aka. super-asterisk)
are supported with the underlying globbing library, https://github.com/bmatcuk/doublestar. This is the same
globbing library used by [gazelle](https://github.com/bazelbuild/bazel-gazelle). See https://github.com/bmatcuk/doublestar#patterns
for more information on supported globbing patterns.

`npm_package` makes use of `copy_to_directory`
(https://docs.aspect.build/rules/aspect_bazel_lib/docs/copy_to_directory) under the hood,
adopting its API and its copy action using composition. However, unlike `copy_to_directory`,
`npm_package` includes `transitive_sources` and `transitive_declarations` files from `JsInfo` providers in srcs
by default. The behavior of including sources and declarations from `JsInfo` can be configured
using the `include_sources`, `include_transitive_sources`, `include_declarations`, `include_transitive_declarations`
attributes.

`npm_package` also includes default runfiles from `srcs` by default which `copy_to_directory` does not. This behavior
can be configured with the `include_runfiles` attribute.

The default `include_srcs_packages`, `[".", "./**"]`, prevents files from outside of the target's
package and subpackages from being included.

The default `exclude_srcs_patterns`, of `["node_modules/**", "**/node_modules/**"]`, prevents
`node_modules` files from being included.

To stamp the current git tag as the "version" in the package.json file, see
[stamped_package_json](#stamped_package_json)
"��
�K
npm_package�A rule that packages sources into a directory (a tree artifact) and provides an `NpmPackageInfo`.

This target can be used as the `src` attribute to `npm_link_package`.

Every npm_package target has a sub target named after its name, which is `<name>.publish`, that can be run
to publish to an npm registry.

Under the hood, this target runs `npm publish`. You can pass arguments to npm by escaping them from Bazel using a double-hyphen,
for example: `bazel run my_package.publish -- --tag=next`


Files and directories can be arranged as needed in the output directory using
the `root_paths`, `include_srcs_patters`, `exclude_srcs_patters` and `replace_prefixes` attributes.

Filters and transformations are applied in the following order:

1. `include_external_repositories`

2. `include_srcs_packages`

3. `exclude_srcs_packages`

4. `root_paths`

5. `include_srcs_patterns`

6. `exclude_srcs_patterns`

7. `replace_prefixes`

For more information each filters / transformations applied, see
the documentation for the specific filter / transformation attribute.

Glob patterns are supported. Standard wildcards (globbing patterns) plus the `**` doublestar (aka. super-asterisk)
are supported with the underlying globbing library, https://github.com/bmatcuk/doublestar. This is the same
globbing library used by [gazelle](https://github.com/bazelbuild/bazel-gazelle). See https://github.com/bmatcuk/doublestar#patterns
for more information on supported globbing patterns.

`npm_package` makes use of `copy_to_directory`
(https://docs.aspect.build/rules/aspect_bazel_lib/docs/copy_to_directory) under the hood,
adopting its API and its copy action using composition. However, unlike `copy_to_directory`,
`npm_package` includes `transitive_sources` and `transitive_declarations` files from `JsInfo` providers in srcs
by default. The behavior of including sources and declarations from `JsInfo` can be configured
using the `include_sources`, `include_transitive_sources`, `include_declarations`, `include_transitive_declarations`
attributes.

`npm_package` also includes default runfiles from `srcs` by default which `copy_to_directory` does not. This behavior
can be configured with the `include_runfiles` attribute.

The default `include_srcs_packages`, `[".", "./**"]`, prevents files from outside of the target's
package and subpackages from being included.

The default `exclude_srcs_patterns`, of `["node_modules/**", "**/node_modules/**"]`, prevents
`node_modules` files from being included.

To stamp the current git tag as the "version" in the package.json file, see
[stamped_package_json](#stamped_package_json)
*
nameA unique name for this target. �
allow_overwrites�If True, allow files to be overwritten if the same output file is copied to twice.

The order of srcs matters as the last copy of a particular file will win when overwriting.
Performance of copy_to_directory will be slightly degraded when allow_overwrites is True
since copies cannot be parallelized out as they are calculated. Instead all copy paths
must be calculated before any copies can be started.
2False
data2[]�
exclude_srcs_packages�List of Bazel packages (with glob support) to exclude from output directory.

Files in srcs are not copied to the output directory if
the Bazel package of the file matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators. A first character of `"."`
will be replaced by the target's package path.

Files that have do not have matching Bazel packages are subject to subsequent
filters and transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).
2[]�
exclude_srcs_patterns�List of paths (with glob support) to exclude from output directory.

Files in srcs are not copied to the output directory if their output
directory path, after applying `root_paths`, matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators.

Files that do not have matching output directory paths are subject to subsequent
filters and transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).
2[]�
hardlink�Controls when to use hardlinks to files instead of making copies.

Creating hardlinks is much faster than making copies of files with the caveat that
hardlinks share file permissions with their source.

Since Bazel removes write permissions on files in the output tree after an action completes,
hardlinks to source files are not recommended since write permissions will be inadvertently
removed from sources files.

- `auto`: hardlinks are used for generated files already in the output tree
- `off`: all files are copied
- `on`: hardlinks are used for all files (not recommended)
2"auto"�	
include_external_repositories�List of external repository names (with glob support) to include in the output directory.

Files from external repositories are only copied into the output directory if
the external repository they come from matches one of the external repository patterns
specified.

When copied from an external repository, the file path in the output directory
defaults to the file's path within the external repository. The external repository
name is _not_ included in that path.

For example, the following copies `@external_repo//path/to:file` to
`path/to/file` within the output directory.

```
copy_to_directory(
    name = "dir",
    include_external_repositories = ["external_*"],
    srcs = ["@external_repo//path/to:file"],
)
```

Files that come from matching external are subject to subsequent filters and
transformations to determine if they are copied and what their path in the output
directory will be. The external repository name of the file from an external
repository is not included in the output directory path and is considered in subsequent
filters and transformations.

Globs are supported (see rule docstring above).
2[]�
include_srcs_packages�List of Bazel packages (with glob support) to include in output directory.

Files in srcs are only copied to the output directory if
the Bazel package of the file matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators. A first character of `"."`
will be replaced by the target's package path.

Defaults to `["**"]` which includes sources from all packages.

Files that have matching Bazel packages are subject to subsequent filters and
transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).
2["**"]�
include_srcs_patterns�List of paths (with glob support) to include in output directory.

Files in srcs are only copied to the output directory if their output
directory path, after applying `root_paths`, matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators.

Defaults to `["**"]` which includes all sources.

Files that have matching output directory paths are subject to subsequent
filters and transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).
2["**"]r
outePath of the output directory, relative to this package.

If not set, the name of the target is used.
2""
package2""�
replace_prefixes�Map of paths prefixes (with glob support) to replace in the output directory path when copying files.

If the output directory path for a file starts with or fully matches a
a key in the dict then the matching portion of the output directory path is
replaced with the dict value for that key. The final path segment
matched can be a partial match of that segment and only the matching portion will
be replaced. If there are multiple keys that match, the longest match wins.

Forward slashes (`/`) should be used as path separators.

Replace prefix transformation are the final step in the list of filters and transformations.
The final output path of a file being copied into the output directory
is determined at this step.

Globs are supported (see rule docstring above).

2{}�

root_paths�List of paths (with glob support) that are roots in the output directory.

If any parent directory of a file being copied matches one of the root paths
patterns specified, the output directory path will be the path relative to the root path
instead of the path relative to the file's workspace. If there are multiple
root paths that match, the longest match wins.

Matching is done on the parent directory of the output file path so a trailing '**' glob patterm
will match only up to the last path segment of the dirname and will not include the basename.
Only complete path segments are matched. Partial matches on the last segment of the root path
are ignored.

Forward slashes (`/`) should be used as path separators.

A `"."` value expands to the target's package path (`ctx.label.package`).

Defaults to `["."]` which results in the output directory path of files in the
target's package and and sub-packages are relative to the target's package and
files outside of that retain their full workspace relative paths.

Globs are supported (see rule docstring above).
2["."]u
srcsgFiles and/or directories or targets that provide `DirectoryPathInfo` to copy into the output directory.2[]>
verbose*If true, prints out verbose logs to stdout2False
version2""">
_npm_package.@@aspect_rules_js//npm/private:npm_package.bzl
��,
*
nameA unique name for this target. �
�
allow_overwrites�If True, allow files to be overwritten if the same output file is copied to twice.

The order of srcs matters as the last copy of a particular file will win when overwriting.
Performance of copy_to_directory will be slightly degraded when allow_overwrites is True
since copies cannot be parallelized out as they are calculated. Instead all copy paths
must be calculated before any copies can be started.
2False

data2[]�
�
exclude_srcs_packages�List of Bazel packages (with glob support) to exclude from output directory.

Files in srcs are not copied to the output directory if
the Bazel package of the file matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators. A first character of `"."`
will be replaced by the target's package path.

Files that have do not have matching Bazel packages are subject to subsequent
filters and transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).
2[]�
�
exclude_srcs_patterns�List of paths (with glob support) to exclude from output directory.

Files in srcs are not copied to the output directory if their output
directory path, after applying `root_paths`, matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators.

Files that do not have matching output directory paths are subject to subsequent
filters and transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).
2[]�
�
hardlink�Controls when to use hardlinks to files instead of making copies.

Creating hardlinks is much faster than making copies of files with the caveat that
hardlinks share file permissions with their source.

Since Bazel removes write permissions on files in the output tree after an action completes,
hardlinks to source files are not recommended since write permissions will be inadvertently
removed from sources files.

- `auto`: hardlinks are used for generated files already in the output tree
- `off`: all files are copied
- `on`: hardlinks are used for all files (not recommended)
2"auto"�	
�	
include_external_repositories�List of external repository names (with glob support) to include in the output directory.

Files from external repositories are only copied into the output directory if
the external repository they come from matches one of the external repository patterns
specified.

When copied from an external repository, the file path in the output directory
defaults to the file's path within the external repository. The external repository
name is _not_ included in that path.

For example, the following copies `@external_repo//path/to:file` to
`path/to/file` within the output directory.

```
copy_to_directory(
    name = "dir",
    include_external_repositories = ["external_*"],
    srcs = ["@external_repo//path/to:file"],
)
```

Files that come from matching external are subject to subsequent filters and
transformations to determine if they are copied and what their path in the output
directory will be. The external repository name of the file from an external
repository is not included in the output directory path and is considered in subsequent
filters and transformations.

Globs are supported (see rule docstring above).
2[]�
�
include_srcs_packages�List of Bazel packages (with glob support) to include in output directory.

Files in srcs are only copied to the output directory if
the Bazel package of the file matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators. A first character of `"."`
will be replaced by the target's package path.

Defaults to `["**"]` which includes sources from all packages.

Files that have matching Bazel packages are subject to subsequent filters and
transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).
2["**"]�
�
include_srcs_patterns�List of paths (with glob support) to include in output directory.

Files in srcs are only copied to the output directory if their output
directory path, after applying `root_paths`, matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators.

Defaults to `["**"]` which includes all sources.

Files that have matching output directory paths are subject to subsequent
filters and transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).
2["**"]t
r
outePath of the output directory, relative to this package.

If not set, the name of the target is used.
2""

package2""�
�
replace_prefixes�Map of paths prefixes (with glob support) to replace in the output directory path when copying files.

If the output directory path for a file starts with or fully matches a
a key in the dict then the matching portion of the output directory path is
replaced with the dict value for that key. The final path segment
matched can be a partial match of that segment and only the matching portion will
be replaced. If there are multiple keys that match, the longest match wins.

Forward slashes (`/`) should be used as path separators.

Replace prefix transformation are the final step in the list of filters and transformations.
The final output path of a file being copied into the output directory
is determined at this step.

Globs are supported (see rule docstring above).

2{}�
�

root_paths�List of paths (with glob support) that are roots in the output directory.

If any parent directory of a file being copied matches one of the root paths
patterns specified, the output directory path will be the path relative to the root path
instead of the path relative to the file's workspace. If there are multiple
root paths that match, the longest match wins.

Matching is done on the parent directory of the output file path so a trailing '**' glob patterm
will match only up to the last path segment of the dirname and will not include the basename.
Only complete path segments are matched. Partial matches on the last segment of the root path
are ignored.

Forward slashes (`/`) should be used as path separators.

A `"."` value expands to the target's package path (`ctx.label.package`).

Defaults to `["."]` which results in the output directory path of files in the
target's package and and sub-packages are relative to the target's package and
files outside of that retain their full workspace relative paths.

Globs are supported (see rule docstring above).
2["."]w
u
srcsgFiles and/or directories or targets that provide `DirectoryPathInfo` to copy into the output directory.2[]@
>
verbose*If true, prints out verbose logs to stdout2False

version2""�stamped_package_json�Convenience wrapper to set the "version" property in package.json with the git tag.

In unstamped builds (typically those without `--stamp`) the version will be set to `0.0.0`.
This ensures that actions which use the package.json file can get cache hits.

For more information on stamping, read https://docs.aspect.build/rules/aspect_bazel_lib/docs/stamping.

Using this rule requires that you register the jq toolchain in your WORKSPACE:

```starlark
load("@aspect_bazel_lib//lib:repositories.bzl", "register_jq_toolchains")

register_jq_toolchains()
```
*�
�
stamped_package_json@
name4name of the resulting `jq` target, must be "package" (b
	stamp_varQa key from the bazel-out/stable-status.txt or bazel-out/volatile-status.txt files (u
kwargsiadditional attributes passed to the jq rule, see https://docs.aspect.build/rules/aspect_bazel_lib/docs/jq(�Convenience wrapper to set the "version" property in package.json with the git tag.

In unstamped builds (typically those without `--stamp`) the version will be set to `0.0.0`.
This ensures that actions which use the package.json file can get cache hits.

For more information on stamping, read https://docs.aspect.build/rules/aspect_bazel_lib/docs/stamping.

Using this rule requires that you register the jq toolchain in your WORKSPACE:

```starlark
load("@aspect_bazel_lib//lib:repositories.bzl", "register_jq_toolchains")

register_jq_toolchains()
```
2F
stamped_package_json.@@aspect_rules_js//npm/private:npm_package.bzl
��*jq2jq�
//lib:copy_to_directory.bzlr�
.
aspect_bazel_liblibcopy_to_directory.bzlJ
copy_to_directory_bin_actioncopy_to_directory_bin_action
7S<
copy_to_directory_libcopy_to_directory_lib
Wl
n�
//lib:directory_path.bzlrq
+
aspect_bazel_liblibdirectory_path.bzl4
DirectoryPathInfoDirectoryPathInfo
4E
GY
//lib:jq.bzlrG

aspect_bazel_liblibjq.bzl
jqjq
(*
,h
//js:defs.bzlrU

aspect_rules_jsjsdefs.bzl$
	js_binary	js_binary
(1
3r
//js:libs.bzlr_

aspect_rules_jsjslibs.bzl.
js_lib_helpersjs_lib_helpers
(6
8l
//js:providers.bzlrT
$
aspect_rules_jsjsproviders.bzl
JsInfoJsInfo
-3
5�
"//npm/private:npm_package_info.bzlrt
4
aspect_rules_jsnpm/privatenpm_package_info.bzl.
NpmPackageInfoNpmPackageInfo
=K
Ma
//lib:dicts.bzlrL

bazel_skyliblib	dicts.bzl
dictsdicts
',
.�
Rules for linking npm dependencies and packaging and linking first-party deps.

Load these with,

```starlark
load("@aspect_rules_js//npm:defs.bzl", "npm_package")
```
�

4
aspect_rules_jsnpm/privatenpm_package_info.bzl�	NpmPackageInfo�Provides the output directory (TreeArtifact) of an npm package containing the packages sources along with the package name and version2�
�
NpmPackageInfo�Provides the output directory (TreeArtifact) of an npm package containing the packages sources along with the package name and version#
packagename of this npm package&
versionversion of this npm packageW
	directoryJthe directory (typically a TreeArtifact) that contains the package sources�
npm_package_store_deps�A depset of NpmPackageStoreInfo providers from npm dependencies of the package and the packages's transitive deps to use as direct dependencies when linking with npm_link_package
hardlinkinternal use only"E
NpmPackageInfo3@@aspect_rules_js//npm/private:npm_package_info.bzl
%
#
packagename of this npm package(
&
versionversion of this npm packageY
W
	directoryJthe directory (typically a TreeArtifact) that contains the package sources�
�
npm_package_store_deps�A depset of NpmPackageStoreInfo providers from npm dependencies of the package and the packages's transitive deps to use as direct dependencies when linking with npm_link_package

hardlinkinternal use onlyNpmPackageInfo provider�
8
aspect_rules_jsnpm/privatenpm_package_internal.bzl�npm_package_internal"�
�
npm_package_internal*
nameA unique name for this target.  
packageThe package name. J
src?A source directory or output directory to use for this package. #
versionThe package version. "O
npm_package_internal7@@aspect_rules_js//npm/private:npm_package_internal.bzl
)),
*
nameA unique name for this target. "
 
packageThe package name. L
J
src?A source directory or output directory to use for this package. %
#
versionThe package version. �
"//npm/private:npm_package_info.bzlrt
4
aspect_rules_jsnpm/privatenpm_package_info.bzl.
NpmPackageInfoNpmPackageInfo
=K
Mnpm_package_internal rule�V
5
aspect_rules_jsnpm/privatenpm_package_store.bzl�Pnpm_package_store�Defines a npm package that is linked into a node_modules tree.

The npm package is linked with a pnpm style symlinked node_modules output tree.

The term "package" is defined at
<https://nodejs.org/docs/latest-v16.x/api/packages.html>

See https://pnpm.io/symlinked-node-modules-structure for more information on
the symlinked node_modules structure.
Npm may also support a symlinked node_modules structure called
"Isolated mode" in the future:
https://github.com/npm/rfcs/blob/main/accepted/0042-isolated-mode.md.
"�L
�(
npm_package_store�Defines a npm package that is linked into a node_modules tree.

The npm package is linked with a pnpm style symlinked node_modules output tree.

The term "package" is defined at
<https://nodejs.org/docs/latest-v16.x/api/packages.html>

See https://pnpm.io/symlinked-node-modules-structure for more information on
the symlinked node_modules structure.
Npm may also support a symlinked node_modules structure called
"Isolated mode" in the future:
https://github.com/npm/rfcs/blob/main/accepted/0042-isolated-mode.md.
*
nameA unique name for this target. �
deps�Other node packages store link targets one depends on mapped to the name to link them under in this packages deps.

This should include *all* modules the program may need at runtime.

You can find all the package store link targets in your repository with

```
bazel query ... | grep :.aspect_rules_js | grep -v /dir | grep -v /pkg | grep -v /ref
```

Package store link targets names for 3rd party packages that come from `npm_translate_lock`
start with `.aspect_rules_js/` then the name passed to the `npm_link_all_packages` macro
(typically `node_modules`) followed by `/<package>/<version>` where `package` is the
package name (including @scope segment if any) and `version` is the specific version of
the package that comes from the pnpm-lock.yaml file.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

The version may include peer dep(s),

```
//:.aspect_rules_js/node_modules/debug/4.3.4_supports-color@8.1.1
```

It could be also be a url based version,

```
//:.aspect_rules_js/node_modules/debug/github.com/ngokevin/debug/9742c5f383a6f8046241920156236ade8ec30d53
```

Package store link targets names for 3rd party package that come directly from an
`npm_import` start with `.aspect_rules_js/` then the name passed to the `npm_import`'s `npm_link_imported_package`
macro (typically `node_modules`) followed by `/<package>/<version>` where `package`
matches the `package` attribute in the npm_import of the package and `version` matches the
`version` attribute.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

Package store link targets names for 1st party packages automatically linked by `npm_link_all_packages`
using workspaces will follow the same pattern as 3rd party packages with the version typically defaulting
to "0.0.0".

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg/0.0.0
```

Package store link targets names for 1st party packages manually linked with `npm_link_package`
start with `.aspect_rules_js/` followed by the name passed to the `npm_link_package`.

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg
```

> In typical usage, a node.js program sometimes requires modules which were
> never declared as dependencies.
> This pattern is typically used when the program has conditional behavior
> that is enabled when the module is found (like a plugin) but the program
> also runs without the dependency.
> 
> This is possible because node.js doesn't enforce the dependencies are sound.
> All files under `node_modules` are available to any program.
> In contrast, Bazel makes it possible to make builds hermetic, which means that
> all dependencies of a program must be declared when running in Bazel's sandbox.
	*
NpmPackageStoreInfo2{}<
dev,Whether this npm package is a dev dependency2False�
hardlink�Controls when to use hardlinks to files instead of making copies.

Creating hardlinks is much faster than making copies of files with the caveat that
hardlinks share file permissions with their source.

Since Bazel removes write permissions on files in the output tree after an action completes,
hardlinks to source files is not recommended since write permissions will be inadvertently
removed from sources files.

- "auto": hardlinks are used for generated files already in the output tree
- "off": all files are copied
- "on": hardlinks are used for all files (not recommended)
2"auto"�
package�The package name to link to.

If unset, the package name in the NpmPackageInfo src must be set.
If set, takes precendance over the package name in the NpmPackageInfo src.
2""i
srcLA npm_package target or or any other target that provides a NpmPackageInfo.
 *
NpmPackageInfo�
use_declare_symlink�Whether to use ctx.actions.declare_symlink to create symlinks.

In Bazel 5.x these are enabled with the --experimental_allow_unresolved_symlinks flag.

Typical usage of this rule is via a macro which automatically sets this
attribute with `select` based on a `config_setting` rule such as,

```
config_setting(
    name = "experimental_allow_unresolved_symlinks",
    values = {"experimental_allow_unresolved_symlinks": "true"},
    visibility = ["//visibility:public"],
)
```
 >
verbose*If true, prints out verbose logs to stdout2False�
version�The package version being linked.

If unset, the package version in the NpmPackageInfo src must be set.
If set, takes precendance over the package version in the NpmPackageInfo src.
2"""I
npm_package_store4@@aspect_rules_js//npm/private:npm_package_store.bzl
��,
*
nameA unique name for this target. �
�
deps�Other node packages store link targets one depends on mapped to the name to link them under in this packages deps.

This should include *all* modules the program may need at runtime.

You can find all the package store link targets in your repository with

```
bazel query ... | grep :.aspect_rules_js | grep -v /dir | grep -v /pkg | grep -v /ref
```

Package store link targets names for 3rd party packages that come from `npm_translate_lock`
start with `.aspect_rules_js/` then the name passed to the `npm_link_all_packages` macro
(typically `node_modules`) followed by `/<package>/<version>` where `package` is the
package name (including @scope segment if any) and `version` is the specific version of
the package that comes from the pnpm-lock.yaml file.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

The version may include peer dep(s),

```
//:.aspect_rules_js/node_modules/debug/4.3.4_supports-color@8.1.1
```

It could be also be a url based version,

```
//:.aspect_rules_js/node_modules/debug/github.com/ngokevin/debug/9742c5f383a6f8046241920156236ade8ec30d53
```

Package store link targets names for 3rd party package that come directly from an
`npm_import` start with `.aspect_rules_js/` then the name passed to the `npm_import`'s `npm_link_imported_package`
macro (typically `node_modules`) followed by `/<package>/<version>` where `package`
matches the `package` attribute in the npm_import of the package and `version` matches the
`version` attribute.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

Package store link targets names for 1st party packages automatically linked by `npm_link_all_packages`
using workspaces will follow the same pattern as 3rd party packages with the version typically defaulting
to "0.0.0".

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg/0.0.0
```

Package store link targets names for 1st party packages manually linked with `npm_link_package`
start with `.aspect_rules_js/` followed by the name passed to the `npm_link_package`.

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg
```

> In typical usage, a node.js program sometimes requires modules which were
> never declared as dependencies.
> This pattern is typically used when the program has conditional behavior
> that is enabled when the module is found (like a plugin) but the program
> also runs without the dependency.
> 
> This is possible because node.js doesn't enforce the dependencies are sound.
> All files under `node_modules` are available to any program.
> In contrast, Bazel makes it possible to make builds hermetic, which means that
> all dependencies of a program must be declared when running in Bazel's sandbox.
	*
NpmPackageStoreInfo2{}>
<
dev,Whether this npm package is a dev dependency2False�
�
hardlink�Controls when to use hardlinks to files instead of making copies.

Creating hardlinks is much faster than making copies of files with the caveat that
hardlinks share file permissions with their source.

Since Bazel removes write permissions on files in the output tree after an action completes,
hardlinks to source files is not recommended since write permissions will be inadvertently
removed from sources files.

- "auto": hardlinks are used for generated files already in the output tree
- "off": all files are copied
- "on": hardlinks are used for all files (not recommended)
2"auto"�
�
package�The package name to link to.

If unset, the package name in the NpmPackageInfo src must be set.
If set, takes precendance over the package name in the NpmPackageInfo src.
2""k
i
srcLA npm_package target or or any other target that provides a NpmPackageInfo.
 *
NpmPackageInfo�
�
use_declare_symlink�Whether to use ctx.actions.declare_symlink to create symlinks.

In Bazel 5.x these are enabled with the --experimental_allow_unresolved_symlinks flag.

Typical usage of this rule is via a macro which automatically sets this
attribute with `select` based on a `config_setting` rule such as,

```
config_setting(
    name = "experimental_allow_unresolved_symlinks",
    values = {"experimental_allow_unresolved_symlinks": "true"},
    visibility = ["//visibility:public"],
)
```
 @
>
verbose*If true, prints out verbose logs to stdout2False�
�
version�The package version being linked.

If unset, the package version in the NpmPackageInfo src must be set.
If set, takes precendance over the package version in the NpmPackageInfo src.
2""�
//lib:copy_directory.bzlr�
+
aspect_bazel_liblibcopy_directory.bzlD
copy_directory_bin_actioncopy_directory_bin_action
4M
O�
"//npm/private:npm_package_info.bzlrt
4
aspect_rules_jsnpm/privatenpm_package_info.bzl.
NpmPackageInfoNpmPackageInfo
=K
M�
(//npm/private:npm_package_store_info.bzlr�
:
aspect_rules_jsnpm/privatenpm_package_store_info.bzl8
NpmPackageStoreInfoNpmPackageStoreInfo
CV
Xt
//npm/private:utils.bzlrW
)
aspect_rules_jsnpm/private	utils.bzl
utilsutils
27
9a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.npm_package_store rule�
:
aspect_rules_jsnpm/privatenpm_package_store_info.bzl�NpmPackageStoreInfo�Provides information about an npm package within the virtual store of a pnpm-style
symlinked node_modules tree.

See https://pnpm.io/symlinked-node-modules-structure for more information about
symlinked node_modules trees.2�
�
NpmPackageStoreInfo�Provides information about an npm package within the virtual store of a pnpm-style
symlinked node_modules tree.

See https://pnpm.io/symlinked-node-modules-structure for more information about
symlinked node_modules trees.@
root_package0package that this npm package store is linked at#
packagename of this npm package&
versionversion of this npm packageB
ref_deps6dictionary of dependency npm_package_store ref targets[
src_directoryJthe directory (typically a TreeArtifact) that contains the package sourcesX
virtual_store_directory=the TreeArtifact of this npm package's virtual store location9
files0depset of files that are part of the npm package`
transitive_filesLdepset of the files that are part of the npm package and its transitive deps:
dev3whether or not this npm package is a dev dependency"P
NpmPackageStoreInfo9@@aspect_rules_js//npm/private:npm_package_store_info.bzl
B
@
root_package0package that this npm package store is linked at%
#
packagename of this npm package(
&
versionversion of this npm packageD
B
ref_deps6dictionary of dependency npm_package_store ref targets]
[
src_directoryJthe directory (typically a TreeArtifact) that contains the package sourcesZ
X
virtual_store_directory=the TreeArtifact of this npm package's virtual store location;
9
files0depset of files that are part of the npm packageb
`
transitive_filesLdepset of the files that are part of the npm package and its transitive deps<
:
dev3whether or not this npm package is a dev dependencyNpmPackageStoreInfo provider�Q
>
aspect_rules_jsnpm/privatenpm_package_store_internal.bzl�Mnpm_package_store_internal"�M
�&
npm_package_store_internal*
nameA unique name for this target. �
deps�Other node packages store link targets one depends on mapped to the name to link them under in this packages deps.

This should include *all* modules the program may need at runtime.

You can find all the package store link targets in your repository with

```
bazel query ... | grep :.aspect_rules_js | grep -v /dir | grep -v /pkg | grep -v /ref
```

Package store link targets names for 3rd party packages that come from `npm_translate_lock`
start with `.aspect_rules_js/` then the name passed to the `npm_link_all_packages` macro
(typically `node_modules`) followed by `/<package>/<version>` where `package` is the
package name (including @scope segment if any) and `version` is the specific version of
the package that comes from the pnpm-lock.yaml file.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

The version may include peer dep(s),

```
//:.aspect_rules_js/node_modules/debug/4.3.4_supports-color@8.1.1
```

It could be also be a url based version,

```
//:.aspect_rules_js/node_modules/debug/github.com/ngokevin/debug/9742c5f383a6f8046241920156236ade8ec30d53
```

Package store link targets names for 3rd party package that come directly from an
`npm_import` start with `.aspect_rules_js/` then the name passed to the `npm_import`'s `npm_link_imported_package`
macro (typically `node_modules`) followed by `/<package>/<version>` where `package`
matches the `package` attribute in the npm_import of the package and `version` matches the
`version` attribute.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

Package store link targets names for 1st party packages automatically linked by `npm_link_all_packages`
using workspaces will follow the same pattern as 3rd party packages with the version typically defaulting
to "0.0.0".

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg/0.0.0
```

Package store link targets names for 1st party packages manually linked with `npm_link_package`
start with `.aspect_rules_js/` followed by the name passed to the `npm_link_package`.

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg
```

> In typical usage, a node.js program sometimes requires modules which were
> never declared as dependencies.
> This pattern is typically used when the program has conditional behavior
> that is enabled when the module is found (like a plugin) but the program
> also runs without the dependency.
> 
> This is possible because node.js doesn't enforce the dependencies are sound.
> All files under `node_modules` are available to any program.
> In contrast, Bazel makes it possible to make builds hermetic, which means that
> all dependencies of a program must be declared when running in Bazel's sandbox.
	*
NpmPackageStoreInfo2{}<
dev,Whether this npm package is a dev dependency2False�
hardlink�Controls when to use hardlinks to files instead of making copies.

Creating hardlinks is much faster than making copies of files with the caveat that
hardlinks share file permissions with their source.

Since Bazel removes write permissions on files in the output tree after an action completes,
hardlinks to source files is not recommended since write permissions will be inadvertently
removed from sources files.

- "auto": hardlinks are used for generated files already in the output tree
- "off": all files are copied
- "on": hardlinks are used for all files (not recommended)
2"auto"n
package_The package name to link to.

Takes precedence over the package name in the NpmPackageInfo src. �
src�A npm_package target or or any other target that provides a NpmPackageInfo.

Can be left unspecified to allow for npm_link_package "reference" targets. `npm_link_package`
targets without a `src` are used internally by `npm_import` to create "reference"
`npm_link_package` targets in order to break circular dependencies between 3rd party npm
dependencies. This pattern is not recommended outside of `npm_import` as it adds
complication. Outside our `npm_import` you should structure you `npm_link_package` targets in
a DAG (without cycles).
*
NpmPackageInfo2None�
use_declare_symlink�Whether to use ctx.actions.declare_symlink to create symlinks.

In Bazel 5.x these are enabled with the --experimental_allow_unresolved_symlinks flag.

Typical usage of this rule is via a macro which automatically sets this
attribute with `select` based on a `config_setting` rule such as,

```
config_setting(
    name = "experimental_allow_unresolved_symlinks",
    values = {"experimental_allow_unresolved_symlinks": "true"},
    visibility = ["//visibility:public"],
)
```
 >
verbose*If true, prints out verbose logs to stdout2Falset
versioneThe package version to link to.

Takes precedence over the package version in the NpmPackageInfo src. "[
npm_package_store_internal=@@aspect_rules_js//npm/private:npm_package_store_internal.bzl
"""",
*
nameA unique name for this target. �
�
deps�Other node packages store link targets one depends on mapped to the name to link them under in this packages deps.

This should include *all* modules the program may need at runtime.

You can find all the package store link targets in your repository with

```
bazel query ... | grep :.aspect_rules_js | grep -v /dir | grep -v /pkg | grep -v /ref
```

Package store link targets names for 3rd party packages that come from `npm_translate_lock`
start with `.aspect_rules_js/` then the name passed to the `npm_link_all_packages` macro
(typically `node_modules`) followed by `/<package>/<version>` where `package` is the
package name (including @scope segment if any) and `version` is the specific version of
the package that comes from the pnpm-lock.yaml file.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

The version may include peer dep(s),

```
//:.aspect_rules_js/node_modules/debug/4.3.4_supports-color@8.1.1
```

It could be also be a url based version,

```
//:.aspect_rules_js/node_modules/debug/github.com/ngokevin/debug/9742c5f383a6f8046241920156236ade8ec30d53
```

Package store link targets names for 3rd party package that come directly from an
`npm_import` start with `.aspect_rules_js/` then the name passed to the `npm_import`'s `npm_link_imported_package`
macro (typically `node_modules`) followed by `/<package>/<version>` where `package`
matches the `package` attribute in the npm_import of the package and `version` matches the
`version` attribute.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

Package store link targets names for 1st party packages automatically linked by `npm_link_all_packages`
using workspaces will follow the same pattern as 3rd party packages with the version typically defaulting
to "0.0.0".

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg/0.0.0
```

Package store link targets names for 1st party packages manually linked with `npm_link_package`
start with `.aspect_rules_js/` followed by the name passed to the `npm_link_package`.

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg
```

> In typical usage, a node.js program sometimes requires modules which were
> never declared as dependencies.
> This pattern is typically used when the program has conditional behavior
> that is enabled when the module is found (like a plugin) but the program
> also runs without the dependency.
> 
> This is possible because node.js doesn't enforce the dependencies are sound.
> All files under `node_modules` are available to any program.
> In contrast, Bazel makes it possible to make builds hermetic, which means that
> all dependencies of a program must be declared when running in Bazel's sandbox.
	*
NpmPackageStoreInfo2{}>
<
dev,Whether this npm package is a dev dependency2False�
�
hardlink�Controls when to use hardlinks to files instead of making copies.

Creating hardlinks is much faster than making copies of files with the caveat that
hardlinks share file permissions with their source.

Since Bazel removes write permissions on files in the output tree after an action completes,
hardlinks to source files is not recommended since write permissions will be inadvertently
removed from sources files.

- "auto": hardlinks are used for generated files already in the output tree
- "off": all files are copied
- "on": hardlinks are used for all files (not recommended)
2"auto"p
n
package_The package name to link to.

Takes precedence over the package name in the NpmPackageInfo src. �
�
src�A npm_package target or or any other target that provides a NpmPackageInfo.

Can be left unspecified to allow for npm_link_package "reference" targets. `npm_link_package`
targets without a `src` are used internally by `npm_import` to create "reference"
`npm_link_package` targets in order to break circular dependencies between 3rd party npm
dependencies. This pattern is not recommended outside of `npm_import` as it adds
complication. Outside our `npm_import` you should structure you `npm_link_package` targets in
a DAG (without cycles).
*
NpmPackageInfo2None�
�
use_declare_symlink�Whether to use ctx.actions.declare_symlink to create symlinks.

In Bazel 5.x these are enabled with the --experimental_allow_unresolved_symlinks flag.

Typical usage of this rule is via a macro which automatically sets this
attribute with `select` based on a `config_setting` rule such as,

```
config_setting(
    name = "experimental_allow_unresolved_symlinks",
    values = {"experimental_allow_unresolved_symlinks": "true"},
    visibility = ["//visibility:public"],
)
```
 @
>
verbose*If true, prints out verbose logs to stdout2Falsev
t
versioneThe package version to link to.

Takes precedence over the package version in the NpmPackageInfo src. �
"//npm/private:npm_package_info.bzlrt
4
aspect_rules_jsnpm/privatenpm_package_info.bzl.
NpmPackageInfoNpmPackageInfo
=K
M�
#//npm/private:npm_package_store.bzlr�
5
aspect_rules_jsnpm/privatenpm_package_store.bzl=
npm_package_store_lib_npm_package_store_lib
=S
na
//lib:dicts.bzlrL

bazel_skyliblib	dicts.bzl
dictsdicts
',
.npm_package_store_internal rule��
6
aspect_rules_jsnpm/privatenpm_translate_lock.bzl�list_patches�Write a file containing a list of all patches in the current folder to the source tree.

Use this together with the `verify_patches` attribute of `npm_translate_lock` to verify
that all patches in a patch folder are included. This macro stamps a test to ensure the
file stays up to date.
*�
�
list_patches
nameName of the target (W
outHName of file to write to the source tree. If unspecified, `name` is usedNone(V
include_patterns)Patterns to pass to a glob of patch files["*.diff", "*.patch"](E
exclude_patterns+Patterns to ignore in a glob of patch files[](�Write a file containing a list of all patches in the current folder to the source tree.

Use this together with the `verify_patches` attribute of `npm_translate_lock` to verify
that all patches in a patch folder are included. This macro stamps a test to ensure the
file stays up to date.
2E
list_patches5@@aspect_rules_js//npm/private:npm_translate_lock.bzl
��"list_sources2list_sources2write_source_file�mnpm_translate_lock�Repository macro to generate starlark code from a lock file.

In most repositories, it would be an impossible maintenance burden to manually declare all
of the [`npm_import`](./npm_import) rules. This helper generates an external repository
containing a helper starlark module `repositories.bzl`, which supplies a loadable macro
`npm_repositories`. That macro creates an `npm_import` for each package.

The generated repository also contains `BUILD` files declaring targets for the packages
listed as `dependencies` or `devDependencies` in `package.json`, so you can declare
dependencies on those packages without having to repeat version information.

This macro creates a `pnpm` external repository, if the user didn't create a repository named
"pnpm" prior to calling `npm_translate_lock`.
`rules_js` currently only uses this repository when `npm_package_lock` or `yarn_lock` are used.
Set `pnpm_version` to `None` to inhibit this repository creation.

For more about how to use npm_translate_lock, read [pnpm and rules_js](/docs/pnpm.md).
*�e
�d
npm_translate_lock$
nameThe repository rule name (/
	pnpm_lockThe `pnpm-lock.yaml` file.None(�
npm_package_lockqThe `package-lock.json` file written by `npm install`.

Only one of `npm_package_lock` or `yarn_lock` may be set.None(
	yarn_lockjThe `yarn.lock` file written by `yarn install`.

Only one of `npm_package_lock` or `yarn_lock` may be set.None(�
update_pnpm_lock�When True, the pnpm lock file will be updated automatically when any of its inputs
have changed since the last update.

Defaults to True when one of `npm_package_lock` or `yarn_lock` are set.
Otherwise it defaults to False.

Read more: [using update_pnpm_lock](/docs/pnpm.md#update_pnpm_lock)None(�
	preupdate�Node.js scripts to run in this repository rule before auto-updating the pnpm lock file.

Scripts are run sequentially in the order they are listed. The working directory is set to the root of the
external repository. Make sure all files required by preupdate scripts are added to the `data` attribute.

A preupdate script could, for example, transform `resolutions` in the root `package.json` file from a format
that yarn understands such as `@foo/**/bar` to the equivalent `@foo/*>bar` that pnpm understands so that
`resolutions` are compatible with pnpm when running `pnpm import` to update the pnpm lock file.

Only needed when `update_pnpm_lock` is True.
Read more: [using update_pnpm_lock](/docs/pnpm.md#update_pnpm_lock)[](�
npmrc�The `.npmrc` file, if any, to use.

When set, the `.npmrc` file specified is parsed and npm auth tokens and basic authentication configuration
specified in the file are passed to the Bazel downloader for authentication with private npm registries.

In a future release, pnpm settings such as public-hoist-patterns will be used.None(�
use_home_npmrc�Use the `$HOME/.npmrc` file (or `$USERPROFILE/.npmrc` when on Windows) if it exists.

Settings from home `.npmrc` are merged with settings loaded from the `.npmrc` file specified
in the `npmrc` attribute, if any. Where there are conflicting settings, the home `.npmrc` values
will take precedence.

WARNING: The repository rule will not be invalidated by changes to the home `.npmrc` file since there
is no way to specify this file as an input to the repository rule. If changes are made to the home
`.npmrc` you can force the repository rule to re-run and pick up the changes by running:
`bazel run @{name}//:sync` where `name` is the name of the `npm_translate_lock` you want to re-run.

Because of the repository rule invalidation issue, using the home `.npmrc` is not recommended.
`.npmrc` settings should generally go in the `npmrc` in your repository so they are shared by all
developers. The home `.npmrc` should be reserved for authentication settings for private npm repositories.None(�
data�Data files required by this repository rule when auto-updating the pnpm lock file.

Only needed when `update_pnpm_lock` is True.
Read more: [using update_pnpm_lock](/docs/pnpm.md#update_pnpm_lock)[](�
patches�A map of package names or package names with their version (e.g., "my-package" or "my-package@v1.2.3")
to a label list of patches to apply to the downloaded npm package. Multiple matches are additive.

These patches are applied after any patches in [pnpm.patchedDependencies](https://pnpm.io/next/package_json#pnpmpatcheddependencies).

Read more: [patching](/docs/pnpm.md#patching){}(�

patch_args�A map of package names or package names with their version (e.g., "my-package" or "my-package@v1.2.3")
to a label list arguments to pass to the patch tool. The most specific match wins.

Read more: [patching](/docs/pnpm.md#patching){"*": ["-p0"]}(�
custom_postinstalls�A map of package names or package names with their version (e.g., "my-package" or "my-package@v1.2.3")
to a custom postinstall script to apply to the downloaded npm package after its lifecycle scripts runs.
If the version is left out of the package name, the script will run on every version of the npm package. If
a custom postinstall scripts exists for a package as well as for a specific version, the script for the versioned package
will be appended with `&&` to the non-versioned package script.

For example,

```
custom_postinstalls = {
    "@foo/bar": "echo something > somewhere.txt",
    "fum@0.0.1": "echo something_else > somewhere_else.txt",
},
```

Custom postinstalls are additive and joined with ` && ` when there are multiple matches for a package.
More specific matches are appended to previous matches.{}(P
prod?If True, only install `dependencies` but not `devDependencies`.False(�
public_hoist_packages�A map of package names or package names with their version (e.g., "my-package" or "my-package@v1.2.3")
to a list of Bazel packages in which to hoist the package to the top-level of the node_modules tree when linking.

This is similar to setting https://pnpm.io/npmrc#public-hoist-pattern in an .npmrc file outside of Bazel, however,
wild-cards are not yet supported and npm_translate_lock will fail if there are multiple versions of a package that
are to be hoisted.

```
public_hoist_packages = {
    "@foo/bar": [""] # link to the root package in the WORKSPACE
    "fum@0.0.1": ["some/sub/package"]
},
```

List of public hoist packages are additive when there are multiple matches for a package. More specific matches
are appended to previous matches.{}(7
dev'If True, only install `devDependencies`False(�
no_optional�If True, `optionalDependencies` are not installed.

Currently `npm_translate_lock` behaves differently from pnpm in that is downloads all `optionaDependencies`
while pnpm doesn't download `optionalDependencies` that are not needed for the platform pnpm is run on.
See https://github.com/pnpm/pnpm/pull/3672 for more context.False(�
run_lifecycle_hooksrSets a default value for `lifecycle_hooks` if `*` not already set.
Set this to `False` to disable lifecycle hooks.True(�
lifecycle_hooks�A dict of package names to list of lifecycle hooks to run for that package.

By default the `preinstall`, `install` and `postinstall` hooks are run if they exist. This attribute allows
the default to be overridden for packages to run `prepare`.

List of hooks are not additive. The most specific match wins.

Read more: [lifecycles](/docs/pnpm.md#lifecycles){}(�
lifecycle_hooks_envs�Environment variables set for the lifecycle hooks actions on npm packages.
The environment variables can be defined per package by package name or globally using "*".
Variables are declared as key/value pairs of the form "key=value".
Multiple matches are additive.

Read more: [lifecycles](/docs/pnpm.md#lifecycles){}(�
lifecycle_hooks_exclude�A list of package names or package names with their version (e.g., "my-package" or "my-package@v1.2.3")
to not run any lifecycle hooks on.

Equivalent to adding `<value>: []` to `lifecycle_hooks`.

Read more: [lifecycles](/docs/pnpm.md#lifecycles)[](�
&lifecycle_hooks_execution_requirements�Execution requirements applied to the preinstall, install and postinstall
lifecycle hooks on npm packages.

The execution requirements can be defined per package by package name or globally using "*".

Execution requirements are not additive. The most specific match wins.

Read more: [lifecycles](/docs/pnpm.md#lifecycles){}(�
lifecycle_hooks_no_sandbox�If True, a "no-sandbox" execution requirement is added to all lifecycle hooks
unless overridden by `lifecycle_hooks_execution_requirements`.

Equivalent to adding `"*": ["no-sandbox"]` to `lifecycle_hooks_execution_requirements`.

This defaults to True to limit the overhead of sandbox creation and copying the output
TreeArtifacts out of the sandbox.

Read more: [lifecycles](/docs/pnpm.md#lifecycles)True(�
bins�Binary files to create in `node_modules/.bin` for packages in this lock file.

For a given package, this is typically derived from the "bin" attribute in
the package.json file of that package.

For example:

```
bins = {
    "@foo/bar": {
        "foo": "./foo.js",
        "bar": "./bar.js"
    },
}
```

Dicts of bins not additive. The most specific match wins.

In the future, this field may be automatically populated from information in the pnpm lock
file. That feature is currently blocked on https://github.com/pnpm/pnpm/issues/5131.{}(�
verify_node_modules_ignored�node_modules folders in the source tree should be ignored by Bazel.

This points to a `.bazelignore` file to verify that all nested node_modules directories
pnpm will create are listed.

See https://github.com/bazelbuild/bazel/issues/8106None(�	
verify_patches�	Label to a patch list file.

Use this in together with the `list_patches` macro to guarantee that all patches in a patch folder
are included in the `patches` attribute.

For example:

```
verify_patches = "//patches:patches.list",
```

In your patches folder add a BUILD.bazel file containing.
```
load("@aspect_rules_js//npm:repositories.bzl", "list_patches")

list_patches(
    name = "patches",
    out = "patches.list",
)
```

Once you have created this file, you need to create an empty `patches.list` file before generating the first list. You can do this by running
```
touch patches/patches.list
```

Finally, write the patches file at least once to make sure all patches are listed. This can be done by running `bazel run //patches:patches_update`.

See the `list_patches` documentation for further info.
NOTE: if you would like to customize the patches directory location, you can set a flag in the `.npmrc`. Here is an example of what this might look like
```
# Set the directory for pnpm when patching
# https://github.com/pnpm/pnpm/issues/6508#issuecomment-1537242124
patches-dir=bazel/js/patches
```
If you do this, you will have to update the `verify_patches` path to be this path instead of `//patches` like above.None(w
quietfSet to False to print info logs and output stdout & stderr of pnpm lock update actions to the console.True(�
 external_repository_action_cache`The location of the external repository action cache to write to when `update_pnpm_lock` = True.0".aspect/rules/external_repository_action_cache"(�
link_workspace�The workspace name where links will be created for the packages in this lock file.

This is typically set in rule sets and libraries that vendor the starlark generated by npm_translate_lock
so the link_workspace passed to npm_import is set correctly so that links are created in the external
repository and not the user workspace.

Can be left unspecified if the link workspace is the user workspace.None(
pnpm_versiondpnpm version to use when generating the @pnpm repository. Set to None to not create this repository."8.6.0"(�
"register_copy_directory_toolchains�if True, `@aspect_bazel_lib//lib:repositories.bzl` `register_copy_directory_toolchains()` is called if the toolchain is not already registeredTrue(�
%register_copy_to_directory_toolchains�if True, `@aspect_bazel_lib//lib:repositories.bzl` `register_copy_to_directory_toolchains()` is called if the toolchain is not already registeredTrue(�
npm_package_target_name�The name of linked `npm_package` targets. When `npm_package` targets are linked as pnpm workspace
packages, the name of the target must align with this value.

The `{dirname}` placeholder is replaced with the directory name of the target.

By default the directory name of the target is used.

Default: `{dirname}`"{dirname}"(s
package_json[Deprecated.

Add all `package.json` files that are part of the workspace to `data` instead.None(]
warn_on_unqualified_tarball_url2Deprecated. Will be removed in next major release.None(
kwargsInternal use only(�Repository macro to generate starlark code from a lock file.

In most repositories, it would be an impossible maintenance burden to manually declare all
of the [`npm_import`](./npm_import) rules. This helper generates an external repository
containing a helper starlark module `repositories.bzl`, which supplies a loadable macro
`npm_repositories`. That macro creates an `npm_import` for each package.

The generated repository also contains `BUILD` files declaring targets for the packages
listed as `dependencies` or `devDependencies` in `package.json`, so you can declare
dependencies on those packages without having to repeat version information.

This macro creates a `pnpm` external repository, if the user didn't create a repository named
"pnpm" prior to calling `npm_translate_lock`.
`rules_js` currently only uses this repository when `npm_package_lock` or `yarn_lock` are used.
Set `pnpm_version` to `None` to inhibit this repository creation.

For more about how to use npm_translate_lock, read [pnpm and rules_js](/docs/pnpm.md).
2K
npm_translate_lock5@@aspect_rules_js//npm/private:npm_translate_lock.bzl
��2npm_translate_lock_rule�npm_translate_lock_ruleR�
�
npm_translate_lock_rule.
name"A unique name for this repository. 
additional_file_contents 

bins 
custom_postinstalls
2{}
data2[]!
defs_bzl_filename2
"defs.bzl"
dev2FalseV
 external_repository_action_cache20".aspect/rules/external_repository_action_cache"'
generate_bzl_library_targets2False
lifecycle_hooks 
lifecycle_hooks_envs ,
&lifecycle_hooks_execution_requirements 
link_workspace2""
no_optional2False
npm_package_lock2None
npm_package_target_name2""
npmrc2None

patch_args 
patches 
	pnpm_lock2None
	preupdate2[]
prod2False
public_hoist_packages 
quiet2True�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 1
repositories_bzl_filename2"repositories.bzl"
root_package2"."
update_pnpm_lock2False
use_home_npmrc2False%
verify_node_modules_ignored2None
verify_patches2None
	yarn_lock2None*P
npm_translate_lock_rule5@@aspect_rules_js//npm/private:npm_translate_lock.bzl
�*�*0
.
name"A unique name for this repository.  

additional_file_contents 


bins 

custom_postinstalls
2{}

data2[]#
!
defs_bzl_filename2
"defs.bzl"

dev2FalseX
V
 external_repository_action_cache20".aspect/rules/external_repository_action_cache")
'
generate_bzl_library_targets2False

lifecycle_hooks 

lifecycle_hooks_envs .
,
&lifecycle_hooks_execution_requirements 

link_workspace2""

no_optional2False

npm_package_lock2None!

npm_package_target_name2""

npmrc2None


patch_args 

patches 

	pnpm_lock2None

	preupdate2[]

prod2False

public_hoist_packages 

quiet2True�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 3
1
repositories_bzl_filename2"repositories.bzl"

root_package2"."

update_pnpm_lock2False

use_home_npmrc2False'
%
verify_node_modules_ignored2None

verify_patches2None

	yarn_lock2None�
//lib:repositories.bzlr�
)
aspect_bazel_liblibrepositories.bzlW
"register_copy_directory_toolchains#_register_copy_directory_toolchains
1T^
%register_copy_to_directory_toolchains&_register_copy_to_directory_toolchains
}�
��
//lib:write_source_files.bzlru
/
aspect_bazel_liblibwrite_source_files.bzl4
write_source_filewrite_source_file
8I
K�
//npm/private:list_sources.bzlrl
0
aspect_rules_jsnpm/privatelist_sources.bzl*
list_sourceslist_sources
9E
G�
-//npm/private:npm_translate_lock_generate.bzlru
?
aspect_rules_jsnpm/privatenpm_translate_lock_generate.bzl$
helpersgen_helpers
GR
_�
,//npm/private:npm_translate_lock_helpers.bzlrp
>
aspect_rules_jsnpm/privatenpm_translate_lock_helpers.bzl 
helpershelpers
 G N
  P�
2//npm/private:npm_translate_lock_macro_helpers.bzlr|
D
aspect_rules_jsnpm/private$npm_translate_lock_macro_helpers.bzl&
helpersmacro_helpers
!L!Y
!!f�
*//npm/private:npm_translate_lock_state.bzlr�
<
aspect_rules_jsnpm/privatenpm_translate_lock_state.bzl:
DEFAULT_ROOT_PACKAGEDEFAULT_ROOT_PACKAGE
"E"YB
npm_translate_lock_statenpm_translate_lock_state
"]"u
""w�
!//npm/private:pnpm_repository.bzlr�
3
aspect_rules_jsnpm/privatepnpm_repository.bzl8
LATEST_PNPM_VERSIONLATEST_PNPM_VERSION
#<#O1
pnpm_repository_pnpm_repository
#R#b
##w�
$//npm/private:transitive_closure.bzlr�
6
aspect_rules_jsnpm/privatetransitive_closure.bzlP
translate_to_transitive_closuretranslate_to_transitive_closure
$?$^
$$`t
//npm/private:utils.bzlrW
)
aspect_rules_jsnpm/private	utils.bzl
utilsutils
%2%7
%%9a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
&'&,
&&.3	DEFAULT_DEFS_BZL_FILENAMEdefs.bzlj
defs.bzlK	!DEFAULT_REPOSITORIES_BZL_FILENAMErepositories.bzljrepositories.bzlg	RULES_JS_FROZEN_PNPM_LOCK_ENV ASPECT_RULES_JS_FROZEN_PNPM_LOCKj" ASPECT_RULES_JS_FROZEN_PNPM_LOCK�Repository rule to fetch npm packages for a lockfile.

Load this with,

```starlark
load("@aspect_rules_js//npm:repositories.bzl", "npm_translate_lock")
```

These use Bazel's downloader to fetch the packages.
You can use this to redirect all fetches through a store like Artifactory.

See <https://blog.aspect.dev/configuring-bazels-downloader> for more info about how it works
and how to configure it.

[`npm_translate_lock`](#npm_translate_lock) is the primary user-facing API.
It uses the lockfile format from [pnpm](https://pnpm.io/motivation) because it gives us reliable
semantics for how to dynamically lay out `node_modules` trees on disk in bazel-out.

To create `pnpm-lock.yaml`, consider using [`pnpm import`](https://pnpm.io/cli/import)
to preserve the versions pinned by your existing `package-lock.json` or `yarn.lock` file.

If you don't have an existing lock file, you can run `npx pnpm install --lockfile-only`.

Advanced users may want to directly fetch a package from npm rather than start from a lockfile,
[`npm_import`](./npm_import) does this.
�
?
aspect_rules_jsnpm/privatenpm_translate_lock_generate.bzli
//lib:base64.bzlrS
#
aspect_bazel_liblib
base64.bzl
base64base64
,2
4�
(//npm/private:starlark_codegen_utils.bzlr�
:
aspect_rules_jsnpm/privatestarlark_codegen_utils.bzl>
starlark_codegen_utilsstarlark_codegen_utils
CY
[t
//npm/private:utils.bzlrW
)
aspect_rules_jsnpm/private	utils.bzl
utilsutils
27
9a
//lib:dicts.bzlrL

bazel_skyliblib	dicts.bzl
dictsdicts
',
.a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.4Starlark generation helpers for npm_translate_lock.
�
>
aspect_rules_jsnpm/privatenpm_translate_lock_helpers.bzle
//lib:new_sets.bzlrM
!
bazel_skyliblibnew_sets.bzl
setssets
*.
0(Starlark helpers for npm_translate_lock.�
D
aspect_rules_jsnpm/private$npm_translate_lock_macro_helpers.bzla
//lib:dicts.bzlrL

bazel_skyliblib	dicts.bzl
dictsdicts
',
./Helper methods for the npm_translate_lock macro�
<
aspect_rules_jsnpm/privatenpm_translate_lock_state.bzli
//lib:base64.bzlrS
#
aspect_bazel_liblib
base64.bzl
base64base64
,2
4y
//lib:repo_utils.bzlr_
'
aspect_bazel_liblibrepo_utils.bzl&

repo_utils
repo_utils
0:
<�
-//npm/private:npm_translate_lock_generate.bzlrq
?
aspect_rules_jsnpm/privatenpm_translate_lock_generate.bzl 
helpershelpers
HO
Q�
//npm/private:npmrc.bzlrc
)
aspect_rules_jsnpm/private	npmrc.bzl(
parse_npmrcparse_npmrc
2=
?�
(//npm/private:repository_label_store.bzlr�
:
aspect_rules_jsnpm/privaterepository_label_store.bzl>
repository_label_storerepository_label_store
CY
[�
//npm/private:utils.bzlr�
)
aspect_rules_jsnpm/private	utils.bzl6
INTERNAL_ERROR_MSGINTERNAL_ERROR_MSG
	2	D
utilsutils
	H	M
		Oa
//lib:dicts.bzlrL

bazel_skyliblib	dicts.bzl
dictsdicts

'
,


.a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.M	PNPM_LOCK_ACTION_CACHE_PREFIXnpm_translate_lock_jnpm_translate_lock_8	PNPM_LOCK_FILENAMEpnpm-lock.yamljpnpm-lock.yamlG	PNPM_WORKSPACE_FILENAMEpnpm-workspace.yamljpnpm-workspace.yaml	%RULES_JS_DISABLE_UPDATE_PNPM_LOCK_ENV(ASPECT_RULES_JS_DISABLE_UPDATE_PNPM_LOCKj*(ASPECT_RULES_JS_DISABLE_UPDATE_PNPM_LOCK 	DEFAULT_ROOT_PACKAGE.j.%	NPM_RC_FILENAME.npmrcj.npmrc7	PACKAGE_JSON_FILENAMEpackage.jsonjpackage.json[npm_translate_lock state management abstraction so main impl is easier to read
and maintain�

)
aspect_rules_jsnpm/private	npmrc.bzl�
parse_npmrc�Parse an `.npmrc` file in into key/value map.

`.npmrc` files are in [INI](https://en.wikipedia.org/wiki/INI_file#Format) format but we don't
treat keys as [case insensitive](https://en.wikipedia.org/wiki/INI_file#Case_sensitivity) due
to https://github.com/aspect-build/rules_js/issues/622.

Duplicate case-sensitive keys override previous values.

Supports:
* basic key/value
* # or ; comments

Does NOT support or ignores:
* sections
* escape characters
* number or boolean types (all values are strings)
* comment characters (#, ;) within a value
*�
�
parse_npmrc0
npmrc_contentthe `.npmrc` content string (�Parse an `.npmrc` file in into key/value map.

`.npmrc` files are in [INI](https://en.wikipedia.org/wiki/INI_file#Format) format but we don't
treat keys as [case insensitive](https://en.wikipedia.org/wiki/INI_file#Case_sensitivity) due
to https://github.com/aspect-build/rules_js/issues/622.

Duplicate case-sensitive keys override previous values.

Supports:
* basic key/value
* # or ; comments

Does NOT support or ignores:
* sections
* escape characters
* number or boolean types (all values are strings)
* comment characters (#, ;) within a value
"8
6A dict() of key/value pairs of the `.npmrc` properties27
parse_npmrc(@@aspect_rules_js//npm/private:npmrc.bzl
npmrc utils�
,
aspect_rules_jsnpm/privatepkg_glob.bzl�pkg_glob*Testing if the passed pkg matches the exp.*�
�
pkg_glob
expthe glob expression (#
pkgthe package name to test (*Testing if the passed pkg matches the exp."1
/True if the package matches the glob expression27
pkg_glob+@@aspect_rules_js//npm/private:pkg_glob.bzl


�
Basic glob implementation required for the pnpm public-hoist-exp option
(https://pnpm.io/npmrc#public-hoist-exp).

pnpm implementation and tests:
    https://github.com/pnpm/pnpm/blob/v7.4.0-2/packages/matcher/src/index.ts
    https://github.com/pnpm/pnpm/blob/v7.4.0-2/packages/matcher/test/index.ts
�
3
aspect_rules_jsnpm/privatepnpm_repository.bzl�pnpm_repository�Import https://npmjs.com/package/pnpm and provide a js_binary to run the tool.

Useful as a way to run exactly the same pnpm as Bazel does, for example with:
bazel run -- @pnpm//:pnpm --dir $PWD
*�
�
pnpm_repository5
name)name of the resulting external repository (e
pnpm_versionJversion of pnpm, see https://www.npmjs.com/package/pnpm?activeTab=versions"8.6.0"(�Import https://npmjs.com/package/pnpm and provide a js_binary to run the tool.

Useful as a way to run exactly the same pnpm as Bazel does, for example with:
bazel run -- @pnpm//:pnpm --dir $PWD
2E
pnpm_repository2@@aspect_rules_js//npm/private:pnpm_repository.bzl
		2native.existing_rule2_npm_import�
//npm/private:npm_import.bzlrg
.
aspect_rules_jsnpm/privatenpm_import.bzl'

npm_import_npm_import
6A
Q�
//npm/private:versions.bzlrj
,
aspect_rules_jsnpm/privateversions.bzl,
PNPM_VERSIONSPNPM_VERSIONS
5B
D'	LATEST_PNPM_VERSION8.6.0j8.6.0!Repository rules to import pnpm.
�
:
aspect_rules_jsnpm/privaterepository_label_store.bzl�
//lib:utils.bzlrp
"
aspect_bazel_liblib	utils.bzl<
is_bazel_6_or_greateris_bazel_6_or_greater
	+	@
		Ba
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths

'
,


.�In order to avoid late restarts, repository rules should pre-compute dynamic labels and
paths to static & dynamic labels. This helper "class" abstracts that into a tidy interface.

See https://github.com/bazelbuild/bazel-gazelle/issues/1175 &&
https://github.com/bazelbuild/rules_nodejs/issues/2620 for more context. A fix in Bazel may
resolve the underlying issue in the future https://github.com/bazelbuild/bazel/issues/16162.
k
:
aspect_rules_jsnpm/privatestarlark_codegen_utils.bzl-Utilities for generating starlark source code�
6
aspect_rules_jsnpm/privatetransitive_closure.bzl�gather_transitive_closure�Walk the dependency tree, collecting the transitive closure of dependencies and their versions.

This is needed to resolve npm dependency cycles.
Note: Starlark expressly forbids recursion and infinite loops, so we need to iterate over a large range of numbers,
where each iteration takes one item from the stack, and possibly adds many new items to the stack.
*�
�
gather_transitive_closure)
packagesdictionary from pnpm lock (:
no_optional'whether to exclude optionalDependencies (@
direct_deps-the immediate dependencies of a given package (K
transitive_closure1a dictionary which is mutated as the return value (�Walk the dependency tree, collecting the transitive closure of dependencies and their versions.

This is needed to resolve npm dependency cycles.
Note: Starlark expressly forbids recursion and infinite loops, so we need to iterate over a large range of numbers,
where each iteration takes one item from the stack, and possibly adds many new items to the stack.
2R
gather_transitive_closure5@@aspect_rules_js//npm/private:transitive_closure.bzl
�translate_to_transitive_closuremImplementation detail of translate_package_lock, converts pnpm-lock to a different dictionary with more data.*�
�
translate_to_transitive_closure-
lock_importerslockfile importers dict (+
lock_packageslockfile packages dict (3
prod"If true, only install dependenciesFalse(5
dev%If true, only install devDependenciesFalse(G
no_optional/If true, optionalDependencies are not installedFalse(mImplementation detail of translate_package_lock, converts pnpm-lock to a different dictionary with more data."J
HNested dictionary suitable for further processing in our repository rule2X
translate_to_transitive_closure5@@aspect_rules_js//npm/private:transitive_closure.bzl
oot
//npm/private:utils.bzlrW
)
aspect_rules_jsnpm/private	utils.bzl
utilsutils
27
9a
//lib:dicts.bzlrL

bazel_skyliblib	dicts.bzl
dictsdicts
',
.-Helper utility for working with pnpm lockfile�	
)
aspect_rules_jsnpm/private	utils.bzlu
//lib:paths.bzlr`
"
aspect_bazel_liblib	paths.bzl,
relative_filerelative_file
+8
:y
//lib:repo_utils.bzlr_
'
aspect_bazel_liblibrepo_utils.bzl&

repo_utils
repo_utils
0:
<�
//lib:utils.bzlrp
"
aspect_bazel_liblib	utils.bzl<
is_bazel_6_or_greateris_bazel_6_or_greater
+@
Bx
//npm/private:yaml.bzlr\
(
aspect_rules_jsnpm/privateyaml.bzl"
parse_parse_yaml
0;
Fa
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.a
//lib:types.bzlrL

bazel_skyliblib	types.bzl
typestypes
',
.�	(DEFAULT_EXTERNAL_REPOSITORY_ACTION_CACHE..aspect/rules/external_repository_action_cachej0..aspect/rules/external_repository_action_cache-	DEFAULT_REGISTRY_PROTOCOLhttpsjhttps�	INTERNAL_ERROR_MSGeERROR: rules_js internal error, please file an issue: https://github.com/aspect-build/rules_js/issuesjgeERROR: rules_js internal error, please file an issue: https://github.com/aspect-build/rules_js/issuesUtility functions for npm rules�
,
aspect_rules_jsnpm/privateversions.bzl�Mirror npm registry metadata for the pnpm package.

Update with: 
curl --silent https://registry.npmjs.org/pnpm | jq '[.versions[] | select(.version | test("^[0-9.]+$")) | {key: .version, value: .dist.integrity}] | sort_by(.key | split(".") | map(tonumber)) | from_entries'
�
(
aspect_rules_jsnpm/privateyaml.bzl�parseParse yaml into starlark*�
�
parse-
yaml!string, the yaml content to parse (Parse yaml into starlark"0
.An equivalent mapping to native starlark types20
parse'@@aspect_rules_js//npm/private:yaml.bzl
9An experimental (and incomplete) yaml parser for starlark��
 
aspect_rules_jsnpmdefs.bzl�Xnpm_link_package�"Links an npm package to node_modules if link is True.

When called at the root_package, a virtual store target is generated named `link__{bazelified_name}__store`.

When linking, a `{name}` target is generated which consists of the `node_modules/<package>` symlink and transitively
its virtual store link and the virtual store links of the transitive closure of deps.

When linking, `{name}/dir` filegroup is also generated that refers to a directory artifact can be used to access
the package directory for creating entry points or accessing files in the package.


Defines a npm package that is linked into a node_modules tree.

The npm package is linked with a pnpm style symlinked node_modules output tree.

The term "package" is defined at
<https://nodejs.org/docs/latest-v16.x/api/packages.html>

See https://pnpm.io/symlinked-node-modules-structure for more information on
the symlinked node_modules structure.
Npm may also support a symlinked node_modules structure called
"Isolated mode" in the future:
https://github.com/npm/rfcs/blob/main/accepted/0042-isolated-mode.md.
"�O
�,
npm_link_package�"Links an npm package to node_modules if link is True.

When called at the root_package, a virtual store target is generated named `link__{bazelified_name}__store`.

When linking, a `{name}` target is generated which consists of the `node_modules/<package>` symlink and transitively
its virtual store link and the virtual store links of the transitive closure of deps.

When linking, `{name}/dir` filegroup is also generated that refers to a directory artifact can be used to access
the package directory for creating entry points or accessing files in the package.


Defines a npm package that is linked into a node_modules tree.

The npm package is linked with a pnpm style symlinked node_modules output tree.

The term "package" is defined at
<https://nodejs.org/docs/latest-v16.x/api/packages.html>

See https://pnpm.io/symlinked-node-modules-structure for more information on
the symlinked node_modules structure.
Npm may also support a symlinked node_modules structure called
"Isolated mode" in the future:
https://github.com/npm/rfcs/blob/main/accepted/0042-isolated-mode.md.
*
nameA unique name for this target. �
deps�Other node packages store link targets one depends on mapped to the name to link them under in this packages deps.

This should include *all* modules the program may need at runtime.

You can find all the package store link targets in your repository with

```
bazel query ... | grep :.aspect_rules_js | grep -v /dir | grep -v /pkg | grep -v /ref
```

Package store link targets names for 3rd party packages that come from `npm_translate_lock`
start with `.aspect_rules_js/` then the name passed to the `npm_link_all_packages` macro
(typically `node_modules`) followed by `/<package>/<version>` where `package` is the
package name (including @scope segment if any) and `version` is the specific version of
the package that comes from the pnpm-lock.yaml file.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

The version may include peer dep(s),

```
//:.aspect_rules_js/node_modules/debug/4.3.4_supports-color@8.1.1
```

It could be also be a url based version,

```
//:.aspect_rules_js/node_modules/debug/github.com/ngokevin/debug/9742c5f383a6f8046241920156236ade8ec30d53
```

Package store link targets names for 3rd party package that come directly from an
`npm_import` start with `.aspect_rules_js/` then the name passed to the `npm_import`'s `npm_link_imported_package`
macro (typically `node_modules`) followed by `/<package>/<version>` where `package`
matches the `package` attribute in the npm_import of the package and `version` matches the
`version` attribute.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

Package store link targets names for 1st party packages automatically linked by `npm_link_all_packages`
using workspaces will follow the same pattern as 3rd party packages with the version typically defaulting
to "0.0.0".

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg/0.0.0
```

Package store link targets names for 1st party packages manually linked with `npm_link_package`
start with `.aspect_rules_js/` followed by the name passed to the `npm_link_package`.

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg
```

> In typical usage, a node.js program sometimes requires modules which were
> never declared as dependencies.
> This pattern is typically used when the program has conditional behavior
> that is enabled when the module is found (like a plugin) but the program
> also runs without the dependency.
> 
> This is possible because node.js doesn't enforce the dependencies are sound.
> All files under `node_modules` are available to any program.
> In contrast, Bazel makes it possible to make builds hermetic, which means that
> all dependencies of a program must be declared when running in Bazel's sandbox.
	*
NpmPackageStoreInfo2{}<
dev,Whether this npm package is a dev dependency2False�
hardlink�Controls when to use hardlinks to files instead of making copies.

Creating hardlinks is much faster than making copies of files with the caveat that
hardlinks share file permissions with their source.

Since Bazel removes write permissions on files in the output tree after an action completes,
hardlinks to source files is not recommended since write permissions will be inadvertently
removed from sources files.

- "auto": hardlinks are used for generated files already in the output tree
- "off": all files are copied
- "on": hardlinks are used for all files (not recommended)
2"auto"�
package�The package name to link to.

If unset, the package name in the NpmPackageInfo src must be set.
If set, takes precendance over the package name in the NpmPackageInfo src.
2""i
srcLA npm_package target or or any other target that provides a NpmPackageInfo.
 *
NpmPackageInfo�
use_declare_symlink�Whether to use ctx.actions.declare_symlink to create symlinks.

In Bazel 5.x these are enabled with the --experimental_allow_unresolved_symlinks flag.

Typical usage of this rule is via a macro which automatically sets this
attribute with `select` based on a `config_setting` rule such as,

```
config_setting(
    name = "experimental_allow_unresolved_symlinks",
    values = {"experimental_allow_unresolved_symlinks": "true"},
    visibility = ["//visibility:public"],
)
```
 >
verbose*If true, prints out verbose logs to stdout2False�
version�The package version being linked.

If unset, the package version in the NpmPackageInfo src must be set.
If set, takes precendance over the package version in the NpmPackageInfo src.
2""
,
*
nameA unique name for this target. �
�
deps�Other node packages store link targets one depends on mapped to the name to link them under in this packages deps.

This should include *all* modules the program may need at runtime.

You can find all the package store link targets in your repository with

```
bazel query ... | grep :.aspect_rules_js | grep -v /dir | grep -v /pkg | grep -v /ref
```

Package store link targets names for 3rd party packages that come from `npm_translate_lock`
start with `.aspect_rules_js/` then the name passed to the `npm_link_all_packages` macro
(typically `node_modules`) followed by `/<package>/<version>` where `package` is the
package name (including @scope segment if any) and `version` is the specific version of
the package that comes from the pnpm-lock.yaml file.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

The version may include peer dep(s),

```
//:.aspect_rules_js/node_modules/debug/4.3.4_supports-color@8.1.1
```

It could be also be a url based version,

```
//:.aspect_rules_js/node_modules/debug/github.com/ngokevin/debug/9742c5f383a6f8046241920156236ade8ec30d53
```

Package store link targets names for 3rd party package that come directly from an
`npm_import` start with `.aspect_rules_js/` then the name passed to the `npm_import`'s `npm_link_imported_package`
macro (typically `node_modules`) followed by `/<package>/<version>` where `package`
matches the `package` attribute in the npm_import of the package and `version` matches the
`version` attribute.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

Package store link targets names for 1st party packages automatically linked by `npm_link_all_packages`
using workspaces will follow the same pattern as 3rd party packages with the version typically defaulting
to "0.0.0".

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg/0.0.0
```

Package store link targets names for 1st party packages manually linked with `npm_link_package`
start with `.aspect_rules_js/` followed by the name passed to the `npm_link_package`.

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg
```

> In typical usage, a node.js program sometimes requires modules which were
> never declared as dependencies.
> This pattern is typically used when the program has conditional behavior
> that is enabled when the module is found (like a plugin) but the program
> also runs without the dependency.
> 
> This is possible because node.js doesn't enforce the dependencies are sound.
> All files under `node_modules` are available to any program.
> In contrast, Bazel makes it possible to make builds hermetic, which means that
> all dependencies of a program must be declared when running in Bazel's sandbox.
	*
NpmPackageStoreInfo2{}>
<
dev,Whether this npm package is a dev dependency2False�
�
hardlink�Controls when to use hardlinks to files instead of making copies.

Creating hardlinks is much faster than making copies of files with the caveat that
hardlinks share file permissions with their source.

Since Bazel removes write permissions on files in the output tree after an action completes,
hardlinks to source files is not recommended since write permissions will be inadvertently
removed from sources files.

- "auto": hardlinks are used for generated files already in the output tree
- "off": all files are copied
- "on": hardlinks are used for all files (not recommended)
2"auto"�
�
package�The package name to link to.

If unset, the package name in the NpmPackageInfo src must be set.
If set, takes precendance over the package name in the NpmPackageInfo src.
2""k
i
srcLA npm_package target or or any other target that provides a NpmPackageInfo.
 *
NpmPackageInfo�
�
use_declare_symlink�Whether to use ctx.actions.declare_symlink to create symlinks.

In Bazel 5.x these are enabled with the --experimental_allow_unresolved_symlinks flag.

Typical usage of this rule is via a macro which automatically sets this
attribute with `select` based on a `config_setting` rule such as,

```
config_setting(
    name = "experimental_allow_unresolved_symlinks",
    values = {"experimental_allow_unresolved_symlinks": "true"},
    visibility = ["//visibility:public"],
)
```
 @
>
verbose*If true, prints out verbose logs to stdout2False�
�
version�The package version being linked.

If unset, the package version in the NpmPackageInfo src must be set.
If set, takes precendance over the package version in the NpmPackageInfo src.
2""��npm_package�A rule that packages sources into a directory (a tree artifact) and provides an `NpmPackageInfo`.

This target can be used as the `src` attribute to `npm_link_package`.

Every npm_package target has a sub target named after its name, which is `<name>.publish`, that can be run
to publish to an npm registry.

Under the hood, this target runs `npm publish`. You can pass arguments to npm by escaping them from Bazel using a double-hyphen,
for example: `bazel run my_package.publish -- --tag=next`


Files and directories can be arranged as needed in the output directory using
the `root_paths`, `include_srcs_patters`, `exclude_srcs_patters` and `replace_prefixes` attributes.

Filters and transformations are applied in the following order:

1. `include_external_repositories`

2. `include_srcs_packages`

3. `exclude_srcs_packages`

4. `root_paths`

5. `include_srcs_patterns`

6. `exclude_srcs_patterns`

7. `replace_prefixes`

For more information each filters / transformations applied, see
the documentation for the specific filter / transformation attribute.

Glob patterns are supported. Standard wildcards (globbing patterns) plus the `**` doublestar (aka. super-asterisk)
are supported with the underlying globbing library, https://github.com/bmatcuk/doublestar. This is the same
globbing library used by [gazelle](https://github.com/bazelbuild/bazel-gazelle). See https://github.com/bmatcuk/doublestar#patterns
for more information on supported globbing patterns.

`npm_package` makes use of `copy_to_directory`
(https://docs.aspect.build/rules/aspect_bazel_lib/docs/copy_to_directory) under the hood,
adopting its API and its copy action using composition. However, unlike `copy_to_directory`,
`npm_package` includes `transitive_sources` and `transitive_declarations` files from `JsInfo` providers in srcs
by default. The behavior of including sources and declarations from `JsInfo` can be configured
using the `include_sources`, `include_transitive_sources`, `include_declarations`, `include_transitive_declarations`
attributes.

`npm_package` also includes default runfiles from `srcs` by default which `copy_to_directory` does not. This behavior
can be configured with the `include_runfiles` attribute.

The default `include_srcs_packages`, `[".", "./**"]`, prevents files from outside of the target's
package and subpackages from being included.

The default `exclude_srcs_patterns`, of `["node_modules/**", "**/node_modules/**"]`, prevents
`node_modules` files from being included.

To stamp the current git tag as the "version" in the package.json file, see
[stamped_package_json](#stamped_package_json)
"Ձ
�J
npm_package�A rule that packages sources into a directory (a tree artifact) and provides an `NpmPackageInfo`.

This target can be used as the `src` attribute to `npm_link_package`.

Every npm_package target has a sub target named after its name, which is `<name>.publish`, that can be run
to publish to an npm registry.

Under the hood, this target runs `npm publish`. You can pass arguments to npm by escaping them from Bazel using a double-hyphen,
for example: `bazel run my_package.publish -- --tag=next`


Files and directories can be arranged as needed in the output directory using
the `root_paths`, `include_srcs_patters`, `exclude_srcs_patters` and `replace_prefixes` attributes.

Filters and transformations are applied in the following order:

1. `include_external_repositories`

2. `include_srcs_packages`

3. `exclude_srcs_packages`

4. `root_paths`

5. `include_srcs_patterns`

6. `exclude_srcs_patterns`

7. `replace_prefixes`

For more information each filters / transformations applied, see
the documentation for the specific filter / transformation attribute.

Glob patterns are supported. Standard wildcards (globbing patterns) plus the `**` doublestar (aka. super-asterisk)
are supported with the underlying globbing library, https://github.com/bmatcuk/doublestar. This is the same
globbing library used by [gazelle](https://github.com/bazelbuild/bazel-gazelle). See https://github.com/bmatcuk/doublestar#patterns
for more information on supported globbing patterns.

`npm_package` makes use of `copy_to_directory`
(https://docs.aspect.build/rules/aspect_bazel_lib/docs/copy_to_directory) under the hood,
adopting its API and its copy action using composition. However, unlike `copy_to_directory`,
`npm_package` includes `transitive_sources` and `transitive_declarations` files from `JsInfo` providers in srcs
by default. The behavior of including sources and declarations from `JsInfo` can be configured
using the `include_sources`, `include_transitive_sources`, `include_declarations`, `include_transitive_declarations`
attributes.

`npm_package` also includes default runfiles from `srcs` by default which `copy_to_directory` does not. This behavior
can be configured with the `include_runfiles` attribute.

The default `include_srcs_packages`, `[".", "./**"]`, prevents files from outside of the target's
package and subpackages from being included.

The default `exclude_srcs_patterns`, of `["node_modules/**", "**/node_modules/**"]`, prevents
`node_modules` files from being included.

To stamp the current git tag as the "version" in the package.json file, see
[stamped_package_json](#stamped_package_json)
*
nameA unique name for this target. �
allow_overwrites�If True, allow files to be overwritten if the same output file is copied to twice.

The order of srcs matters as the last copy of a particular file will win when overwriting.
Performance of copy_to_directory will be slightly degraded when allow_overwrites is True
since copies cannot be parallelized out as they are calculated. Instead all copy paths
must be calculated before any copies can be started.
2False
data2[]�
exclude_srcs_packages�List of Bazel packages (with glob support) to exclude from output directory.

Files in srcs are not copied to the output directory if
the Bazel package of the file matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators. A first character of `"."`
will be replaced by the target's package path.

Files that have do not have matching Bazel packages are subject to subsequent
filters and transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).
2[]�
exclude_srcs_patterns�List of paths (with glob support) to exclude from output directory.

Files in srcs are not copied to the output directory if their output
directory path, after applying `root_paths`, matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators.

Files that do not have matching output directory paths are subject to subsequent
filters and transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).
2[]�
hardlink�Controls when to use hardlinks to files instead of making copies.

Creating hardlinks is much faster than making copies of files with the caveat that
hardlinks share file permissions with their source.

Since Bazel removes write permissions on files in the output tree after an action completes,
hardlinks to source files are not recommended since write permissions will be inadvertently
removed from sources files.

- `auto`: hardlinks are used for generated files already in the output tree
- `off`: all files are copied
- `on`: hardlinks are used for all files (not recommended)
2"auto"�	
include_external_repositories�List of external repository names (with glob support) to include in the output directory.

Files from external repositories are only copied into the output directory if
the external repository they come from matches one of the external repository patterns
specified.

When copied from an external repository, the file path in the output directory
defaults to the file's path within the external repository. The external repository
name is _not_ included in that path.

For example, the following copies `@external_repo//path/to:file` to
`path/to/file` within the output directory.

```
copy_to_directory(
    name = "dir",
    include_external_repositories = ["external_*"],
    srcs = ["@external_repo//path/to:file"],
)
```

Files that come from matching external are subject to subsequent filters and
transformations to determine if they are copied and what their path in the output
directory will be. The external repository name of the file from an external
repository is not included in the output directory path and is considered in subsequent
filters and transformations.

Globs are supported (see rule docstring above).
2[]�
include_srcs_packages�List of Bazel packages (with glob support) to include in output directory.

Files in srcs are only copied to the output directory if
the Bazel package of the file matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators. A first character of `"."`
will be replaced by the target's package path.

Defaults to `["**"]` which includes sources from all packages.

Files that have matching Bazel packages are subject to subsequent filters and
transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).
2["**"]�
include_srcs_patterns�List of paths (with glob support) to include in output directory.

Files in srcs are only copied to the output directory if their output
directory path, after applying `root_paths`, matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators.

Defaults to `["**"]` which includes all sources.

Files that have matching output directory paths are subject to subsequent
filters and transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).
2["**"]r
outePath of the output directory, relative to this package.

If not set, the name of the target is used.
2""
package2""�
replace_prefixes�Map of paths prefixes (with glob support) to replace in the output directory path when copying files.

If the output directory path for a file starts with or fully matches a
a key in the dict then the matching portion of the output directory path is
replaced with the dict value for that key. The final path segment
matched can be a partial match of that segment and only the matching portion will
be replaced. If there are multiple keys that match, the longest match wins.

Forward slashes (`/`) should be used as path separators.

Replace prefix transformation are the final step in the list of filters and transformations.
The final output path of a file being copied into the output directory
is determined at this step.

Globs are supported (see rule docstring above).

2{}�

root_paths�List of paths (with glob support) that are roots in the output directory.

If any parent directory of a file being copied matches one of the root paths
patterns specified, the output directory path will be the path relative to the root path
instead of the path relative to the file's workspace. If there are multiple
root paths that match, the longest match wins.

Matching is done on the parent directory of the output file path so a trailing '**' glob patterm
will match only up to the last path segment of the dirname and will not include the basename.
Only complete path segments are matched. Partial matches on the last segment of the root path
are ignored.

Forward slashes (`/`) should be used as path separators.

A `"."` value expands to the target's package path (`ctx.label.package`).

Defaults to `["."]` which results in the output directory path of files in the
target's package and and sub-packages are relative to the target's package and
files outside of that retain their full workspace relative paths.

Globs are supported (see rule docstring above).
2["."]u
srcsgFiles and/or directories or targets that provide `DirectoryPathInfo` to copy into the output directory.2[]>
verbose*If true, prints out verbose logs to stdout2False
version2""
��,
*
nameA unique name for this target. �
�
allow_overwrites�If True, allow files to be overwritten if the same output file is copied to twice.

The order of srcs matters as the last copy of a particular file will win when overwriting.
Performance of copy_to_directory will be slightly degraded when allow_overwrites is True
since copies cannot be parallelized out as they are calculated. Instead all copy paths
must be calculated before any copies can be started.
2False

data2[]�
�
exclude_srcs_packages�List of Bazel packages (with glob support) to exclude from output directory.

Files in srcs are not copied to the output directory if
the Bazel package of the file matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators. A first character of `"."`
will be replaced by the target's package path.

Files that have do not have matching Bazel packages are subject to subsequent
filters and transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).
2[]�
�
exclude_srcs_patterns�List of paths (with glob support) to exclude from output directory.

Files in srcs are not copied to the output directory if their output
directory path, after applying `root_paths`, matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators.

Files that do not have matching output directory paths are subject to subsequent
filters and transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).
2[]�
�
hardlink�Controls when to use hardlinks to files instead of making copies.

Creating hardlinks is much faster than making copies of files with the caveat that
hardlinks share file permissions with their source.

Since Bazel removes write permissions on files in the output tree after an action completes,
hardlinks to source files are not recommended since write permissions will be inadvertently
removed from sources files.

- `auto`: hardlinks are used for generated files already in the output tree
- `off`: all files are copied
- `on`: hardlinks are used for all files (not recommended)
2"auto"�	
�	
include_external_repositories�List of external repository names (with glob support) to include in the output directory.

Files from external repositories are only copied into the output directory if
the external repository they come from matches one of the external repository patterns
specified.

When copied from an external repository, the file path in the output directory
defaults to the file's path within the external repository. The external repository
name is _not_ included in that path.

For example, the following copies `@external_repo//path/to:file` to
`path/to/file` within the output directory.

```
copy_to_directory(
    name = "dir",
    include_external_repositories = ["external_*"],
    srcs = ["@external_repo//path/to:file"],
)
```

Files that come from matching external are subject to subsequent filters and
transformations to determine if they are copied and what their path in the output
directory will be. The external repository name of the file from an external
repository is not included in the output directory path and is considered in subsequent
filters and transformations.

Globs are supported (see rule docstring above).
2[]�
�
include_srcs_packages�List of Bazel packages (with glob support) to include in output directory.

Files in srcs are only copied to the output directory if
the Bazel package of the file matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators. A first character of `"."`
will be replaced by the target's package path.

Defaults to `["**"]` which includes sources from all packages.

Files that have matching Bazel packages are subject to subsequent filters and
transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).
2["**"]�
�
include_srcs_patterns�List of paths (with glob support) to include in output directory.

Files in srcs are only copied to the output directory if their output
directory path, after applying `root_paths`, matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators.

Defaults to `["**"]` which includes all sources.

Files that have matching output directory paths are subject to subsequent
filters and transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).
2["**"]t
r
outePath of the output directory, relative to this package.

If not set, the name of the target is used.
2""

package2""�
�
replace_prefixes�Map of paths prefixes (with glob support) to replace in the output directory path when copying files.

If the output directory path for a file starts with or fully matches a
a key in the dict then the matching portion of the output directory path is
replaced with the dict value for that key. The final path segment
matched can be a partial match of that segment and only the matching portion will
be replaced. If there are multiple keys that match, the longest match wins.

Forward slashes (`/`) should be used as path separators.

Replace prefix transformation are the final step in the list of filters and transformations.
The final output path of a file being copied into the output directory
is determined at this step.

Globs are supported (see rule docstring above).

2{}�
�

root_paths�List of paths (with glob support) that are roots in the output directory.

If any parent directory of a file being copied matches one of the root paths
patterns specified, the output directory path will be the path relative to the root path
instead of the path relative to the file's workspace. If there are multiple
root paths that match, the longest match wins.

Matching is done on the parent directory of the output file path so a trailing '**' glob patterm
will match only up to the last path segment of the dirname and will not include the basename.
Only complete path segments are matched. Partial matches on the last segment of the root path
are ignored.

Forward slashes (`/`) should be used as path separators.

A `"."` value expands to the target's package path (`ctx.label.package`).

Defaults to `["."]` which results in the output directory path of files in the
target's package and and sub-packages are relative to the target's package and
files outside of that retain their full workspace relative paths.

Globs are supported (see rule docstring above).
2["."]w
u
srcsgFiles and/or directories or targets that provide `DirectoryPathInfo` to copy into the output directory.2[]@
>
verbose*If true, prints out verbose logs to stdout2False

version2""�stamped_package_json�Convenience wrapper to set the "version" property in package.json with the git tag.

In unstamped builds (typically those without `--stamp`) the version will be set to `0.0.0`.
This ensures that actions which use the package.json file can get cache hits.

For more information on stamping, read https://docs.aspect.build/rules/aspect_bazel_lib/docs/stamping.

Using this rule requires that you register the jq toolchain in your WORKSPACE:

```starlark
load("@aspect_bazel_lib//lib:repositories.bzl", "register_jq_toolchains")

register_jq_toolchains()
```
*�
�
stamped_package_json@
name4name of the resulting `jq` target, must be "package" (b
	stamp_varQa key from the bazel-out/stable-status.txt or bazel-out/volatile-status.txt files (u
kwargsiadditional attributes passed to the jq rule, see https://docs.aspect.build/rules/aspect_bazel_lib/docs/jq(�Convenience wrapper to set the "version" property in package.json with the git tag.

In unstamped builds (typically those without `--stamp`) the version will be set to `0.0.0`.
This ensures that actions which use the package.json file can get cache hits.

For more information on stamping, read https://docs.aspect.build/rules/aspect_bazel_lib/docs/stamping.

Using this rule requires that you register the jq toolchain in your WORKSPACE:

```starlark
load("@aspect_bazel_lib//lib:repositories.bzl", "register_jq_toolchains")

register_jq_toolchains()
```
2F
stamped_package_json.@@aspect_rules_js//npm/private:npm_package.bzl
��*jq2jq�
"//npm/private:npm_link_package.bzlry
4
aspect_rules_jsnpm/privatenpm_link_package.bzl3
npm_link_package_npm_link_package

�
//npm/private:npm_package.bzlr�
/
aspect_rules_jsnpm/privatenpm_package.bzl)
npm_package_npm_package


;
stamped_package_json_stamped_package_json

[Rules for fetching and linking npm dependencies and packaging and linking first-party deps
�9
&
aspect_rules_jsnpmextensions.bzl�*npmJ�*
�
npm�
npm_translate_lock
name2""
additional_file_contents 

bins 
custom_postinstalls
2{}
data2[]!
defs_bzl_filename2
"defs.bzl"
dev2FalseV
 external_repository_action_cache20".aspect/rules/external_repository_action_cache"'
generate_bzl_library_targets2False
lifecycle_hooks 
lifecycle_hooks_envs 
lifecycle_hooks_exclude2[],
&lifecycle_hooks_execution_requirements $
lifecycle_hooks_no_sandbox2True
link_workspace2""
no_optional2False
npm_package_lock2None(
npm_package_target_name2"{dirname}"
npmrc2None

patch_args 
patches 
	pnpm_lock2None
pnpm_version2"8.6.0"
	preupdate2[]
prod2False
public_hoist_packages 
quiet2True1
repositories_bzl_filename2"repositories.bzl"
root_package2"."
run_lifecycle_hooks2True
update_pnpm_lock2False
use_home_npmrc2False%
verify_node_modules_ignored2None
verify_patches2None
	yarn_lock2None�

npm_import
name2""
bins
2{}
commit2""
custom_postinstall2""
deps
2{}
dev2False
extra_build_content2""'
generate_bzl_library_targets2False
	integrity2""!
lifecycle_build_target2False
lifecycle_hooks2[]
lifecycle_hooks_env2[]:
&lifecycle_hooks_execution_requirements2["no-sandbox"]%
lifecycle_hooks_no_sandbox2False
link_packages 
link_workspace2""
npm_auth2""
npm_auth_basic2""
npm_auth_password2""
npm_auth_username2""
npm_translate_lock_repo2""
package 

patch_args2["-p0"]
patches2[]
root_package2""
run_lifecycle_hooks2False
transitive_closure 
url2""
version ",
npm%@@aspect_rules_js//npm:extensions.bzl
���
�
npm_translate_lock
name2""
additional_file_contents 

bins 
custom_postinstalls
2{}
data2[]!
defs_bzl_filename2
"defs.bzl"
dev2FalseV
 external_repository_action_cache20".aspect/rules/external_repository_action_cache"'
generate_bzl_library_targets2False
lifecycle_hooks 
lifecycle_hooks_envs 
lifecycle_hooks_exclude2[],
&lifecycle_hooks_execution_requirements $
lifecycle_hooks_no_sandbox2True
link_workspace2""
no_optional2False
npm_package_lock2None(
npm_package_target_name2"{dirname}"
npmrc2None

patch_args 
patches 
	pnpm_lock2None
pnpm_version2"8.6.0"
	preupdate2[]
prod2False
public_hoist_packages 
quiet2True1
repositories_bzl_filename2"repositories.bzl"
root_package2"."
run_lifecycle_hooks2True
update_pnpm_lock2False
use_home_npmrc2False%
verify_node_modules_ignored2None
verify_patches2None
	yarn_lock2None

name2"" 

additional_file_contents 


bins 

custom_postinstalls
2{}

data2[]#
!
defs_bzl_filename2
"defs.bzl"

dev2FalseX
V
 external_repository_action_cache20".aspect/rules/external_repository_action_cache")
'
generate_bzl_library_targets2False

lifecycle_hooks 

lifecycle_hooks_envs !

lifecycle_hooks_exclude2[].
,
&lifecycle_hooks_execution_requirements &
$
lifecycle_hooks_no_sandbox2True

link_workspace2""

no_optional2False

npm_package_lock2None*
(
npm_package_target_name2"{dirname}"

npmrc2None


patch_args 

patches 

	pnpm_lock2None

pnpm_version2"8.6.0"

	preupdate2[]

prod2False

public_hoist_packages 

quiet2True3
1
repositories_bzl_filename2"repositories.bzl"

root_package2"."

run_lifecycle_hooks2True

update_pnpm_lock2False

use_home_npmrc2False'
%
verify_node_modules_ignored2None

verify_patches2None

	yarn_lock2None�
�

npm_import
name2""
bins
2{}
commit2""
custom_postinstall2""
deps
2{}
dev2False
extra_build_content2""'
generate_bzl_library_targets2False
	integrity2""!
lifecycle_build_target2False
lifecycle_hooks2[]
lifecycle_hooks_env2[]:
&lifecycle_hooks_execution_requirements2["no-sandbox"]%
lifecycle_hooks_no_sandbox2False
link_packages 
link_workspace2""
npm_auth2""
npm_auth_basic2""
npm_auth_password2""
npm_auth_username2""
npm_translate_lock_repo2""
package 

patch_args2["-p0"]
patches2[]
root_package2""
run_lifecycle_hooks2False
transitive_closure 
url2""
version 

name2""

bins
2{}

commit2""

custom_postinstall2""

deps
2{}

dev2False

extra_build_content2"")
'
generate_bzl_library_targets2False

	integrity2""#
!
lifecycle_build_target2False

lifecycle_hooks2[]

lifecycle_hooks_env2[]<
:
&lifecycle_hooks_execution_requirements2["no-sandbox"]'
%
lifecycle_hooks_no_sandbox2False

link_packages 

link_workspace2""

npm_auth2""

npm_auth_basic2""

npm_auth_password2""

npm_auth_username2""!

npm_translate_lock_repo2""

package 


patch_args2["-p0"]

patches2[]

root_package2"" 

run_lifecycle_hooks2False

transitive_closure 

url2""

version �pnpmJ�
f
pnpm/
pnpm
name2""
pnpm_version2"8.6.0""-
pnpm%@@aspect_rules_js//npm:extensions.bzl
��^
/
pnpm
name2""
pnpm_version2"8.6.0"

name2""

pnpm_version2"8.6.0"�
//npm:repositories.bzlr�
(
aspect_rules_jsnpmrepositories.bzl&

npm_import
npm_import
1;6
npm_translate_locknpm_translate_lock
?Q0
pnpm_repositorypnpm_repository
Ud9
LATEST_PNPM_VERSION_LATEST_PNPM_VERSION
g{
��
//npm/private:npm_import.bzlr�
.
aspect_rules_jsnpm/privatenpm_import.bzl.
npm_import_libnpm_import_lib
7E:
npm_import_links_libnpm_import_links_lib
I]
_�
$//npm/private:npm_translate_lock.bzlr�
6
aspect_rules_jsnpm/privatenpm_translate_lock.bzl>
npm_translate_lock_libnpm_translate_lock_lib
?U
W�
-//npm/private:npm_translate_lock_generate.bzlr�
?
aspect_rules_jsnpm/privatenpm_translate_lock_generate.bzl3
helpersnpm_translate_lock_helpers
Ga
n�
2//npm/private:npm_translate_lock_macro_helpers.bzlr|
D
aspect_rules_jsnpm/private$npm_translate_lock_macro_helpers.bzl&
helpersmacro_helpers
	L	Y
		f�
//npm/private:npmrc.bzlrc
)
aspect_rules_jsnpm/private	npmrc.bzl(
parse_npmrcparse_npmrc

2
=


?�
$//npm/private:transitive_closure.bzlr�
6
aspect_rules_jsnpm/privatetransitive_closure.bzlP
translate_to_transitive_closuretranslate_to_transitive_closure
?^
`t
//npm/private:utils.bzlrW
)
aspect_rules_jsnpm/private	utils.bzl
utilsutils
27
9'	LATEST_PNPM_VERSION8.6.0j8.6.0sAdapt npm repository rules to be called from MODULE.bazel
See https://bazel.build/docs/bzlmod#extension-definition
�
 
aspect_rules_jsnpmlibs.bzl�
//npm/private:npm_package.bzlrr
/
aspect_rules_jsnpm/privatenpm_package.bzl1
npm_package_lib_npm_package_lib

0Starlark libraries for building derivative rules��
&
aspect_rules_jsnpmnpm_import.bzl�list_patches�Write a file containing a list of all patches in the current folder to the source tree.

Use this together with the `verify_patches` attribute of `npm_translate_lock` to verify
that all patches in a patch folder are included. This macro stamps a test to ensure the
file stays up to date.
*�
�
list_patches
nameName of the target (W
outHName of file to write to the source tree. If unspecified, `name` is usedNone(V
include_patterns)Patterns to pass to a glob of patch files["*.diff", "*.patch"](E
exclude_patterns+Patterns to ignore in a glob of patch files[](�Write a file containing a list of all patches in the current folder to the source tree.

Use this together with the `verify_patches` attribute of `npm_translate_lock` to verify
that all patches in a patch folder are included. This macro stamps a test to ensure the
file stays up to date.
2E
list_patches5@@aspect_rules_js//npm/private:npm_translate_lock.bzl
��"list_sources2list_sources2write_source_file�m
npm_import� Import a single npm package into Bazel.

Normally you'd want to use `npm_translate_lock` to import all your packages at once.
It generates `npm_import` rules.
You can create these manually if you want to have exact control.

Bazel will only fetch the given package from an external registry if the package is
required for the user-requested targets to be build/tested.

This is a repository rule, which should be called from your `WORKSPACE` file
or some `.bzl` file loaded from it. For example, with this code in `WORKSPACE`:

```starlark
npm_import(
    name = "npm__at_types_node_15.12.2",
    package = "@types/node",
    version = "15.12.2",
    integrity = "sha512-zjQ69G564OCIWIOHSXyQEEDpdpGl+G348RAKY0XXy9Z5kU9Vzv1GMNnkar/ZJ8dzXB3COzD9Mo9NtRZ4xfgUww==",
)
```

> This is similar to Bazel rules in other ecosystems named "_import" like
> `apple_bundle_import`, `scala_import`, `java_import`, and `py_import`.
> `go_repository` is also a model for this rule.

The name of this repository should contain the version number, so that multiple versions of the same
package don't collide.
(Note that the npm ecosystem always supports multiple versions of a library depending on where
it is required, unlike other languages like Go or Python.)

To consume the downloaded package in rules, it must be "linked" into the link package in the
package's `BUILD.bazel` file:

```
load("@npm__at_types_node__15.12.2__links//:defs.bzl", npm_link_types_node = "npm_link_imported_package")

npm_link_types_node(name = "node_modules")
```

This links `@types/node` into the `node_modules` of this package with the target name `:node_modules/@types/node`.

A `:node_modules/@types/node/dir` filegroup target is also created that provides the the directory artifact of the npm package.
This target can be used to create entry points for binary target or to access files within the npm package.

NB: You can choose any target name for the link target but we recommend using the `node_modules/@scope/name` and
`node_modules/name` convention for readability.

When using `npm_translate_lock`, you can link all the npm dependencies in the lock file for a package:

```
load("@npm//:defs.bzl", "npm_link_all_packages")

npm_link_all_packages(name = "node_modules")
```

This creates `:node_modules/name` and `:node_modules/@scope/name` targets for all direct npm dependencies in the package.
It also creates `:node_modules/name/dir` and `:node_modules/@scope/name/dir` filegroup targets that provide the the directory artifacts of their npm packages.
These target can be used to create entry points for binary target or to access files within the npm package.

If you have a mix of `npm_link_all_packages` and `npm_link_imported_package` functions to call you can pass the
`npm_link_imported_package` link functions to the `imported_links` attribute of `npm_link_all_packages` to link
them all in one call. For example,

```
load("@npm//:defs.bzl", "npm_link_all_packages")
load("@npm__at_types_node__15.12.2__links//:defs.bzl", npm_link_types_node = "npm_link_imported_package")

npm_link_all_packages(
    name = "node_modules",
    imported_links = [
        npm_link_types_node,
    ]
)
```

This has the added benefit of adding the `imported_links` to the convienence `:node_modules` target which
includes all direct dependencies in that package.

NB: You can pass an name to npm_link_all_packages and this will change the targets generated to "{name}/@scope/name" and
"{name}/name". We recommend using "node_modules" as the convention for readability.

To change the proxy URL we use to fetch, configure the Bazel downloader:

1. Make a file containing a rewrite rule like

    `rewrite (registry.nodejs.org)/(.*) artifactory.build.internal.net/artifactory/$1/$2`

1. To understand the rewrites, see [UrlRewriterConfig] in Bazel sources.

1. Point bazel to the config with a line in .bazelrc like
common --experimental_downloader_config=.bazel_downloader_config

Read more about the downloader config: <https://blog.aspect.dev/configuring-bazels-downloader>

[UrlRewriterConfig]: https://github.com/bazelbuild/bazel/blob/4.2.1/src/main/java/com/google/devtools/build/lib/bazel/repository/downloader/UrlRewriterConfig.java#L66
*�L
�L

npm_import)
nameName for this repository rule (H
package9Name of the npm package, such as `acorn` or `@types/node` (:
version+Version of the npm package, such as `8.4.0` (v
depshA dict other npm packages this one depends on where the key is the package name and value is the version{}(�
extra_build_content�Additional content to append on the generated BUILD file at the root of
the created repository, either as a string or a list of lines similar to
<https://github.com/bazelbuild/bazel-skylib/blob/main/docs/write_file_doc.md>.""(�
transitive_closure�A dict all npm packages this one depends on directly or transitively where the key is the
package name and value is a list of version(s) depended on in the closure.{}(�
root_package�The root package where the node_modules virtual store is linked to.
Typically this is the package that the pnpm-lock.yaml file is located when using `npm_translate_lock`.""(�
link_workspace�The workspace name where links will be created for this package.

This is typically set in rule sets and libraries that are to be consumed as external repositories so
links are created in the external repository and not the user workspace.

Can be left unspecified if the link workspace is the user workspace.""(�
link_packages�Dict of paths where links may be created at for this package to
a list of link aliases to link as in each package. If aliases are an
empty list this indicates to link as the package name.

Defaults to {} which indicates that links may be created in any package as specified by
the `direct` attribute of the generated npm_link_package.{}(m
lifecycle_hooksTList of lifecycle hook `package.json` scripts to run for this package if they exist.[](�
&lifecycle_hooks_execution_requirements�Execution requirements when running the lifecycle hooks.

For example:

```
lifecycle_hooks_execution_requirements: ["no-sandbox', "requires-network"]
```

This defaults to ["no-sandbox"] to limit the overhead of sandbox creation and copying the output
TreeArtifact out of the sandbox.["no-sandbox"](�
lifecycle_hooks_env�Environment variables set for the lifecycle hooks action for this npm
package if there is one.

Environment variables are defined by providing an array of "key=value" entries.

For example:

```
lifecycle_hooks_env: ["PREBULT_BINARY=https://downloadurl"],
```[](�
	integrity�Expected checksum of the file downloaded, in Subresource Integrity format.
This must match the checksum of the file downloaded.

This is the same as appears in the pnpm-lock.yaml, yarn.lock or package-lock.json file.

It is a security risk to omit the checksum as remote files can change.

At best omitting this field will make your build non-hermetic.

It is optional to make development easier but should be set before shipping.""(�
url�Optional url for this package. If unset, a default npm registry url is generated from
the package name and version.

May start with `git+ssh://` or `git+https://` to indicate a git repository. For example,

```
git+ssh://git@github.com/org/repo.git
```

If url is configured as a git repository, the commit attribute must be set to the
desired commit.""(M
commit=Specific commit to be checked out if url is a git repository.""(y

patch_args`Arguments to pass to the patch tool.

`-p1` will usually be needed for patches generated by git.["-p0"](F
patches5Patch files to apply onto the downloaded npm package.[](�
custom_postinstall�Custom string postinstall script to run on the installed npm package. Runs after any
existing lifecycle hooks if `run_lifecycle_hooks` is True.""(X
npm_authFAuth token to authenticate with npm. When using Bearer authentication.""(�
npm_auth_basic�Auth token to authenticate with npm. When using Basic authentication.

This is typically the base64 encoded string "username:password".""(c
npm_auth_usernameHAuth username to authenticate with npm. When using Basic authentication.""(c
npm_auth_passwordHAuth password to authenticate with npm. When using Basic authentication.""(�
bins�Dictionary of `node_modules/.bin` binary files to create mapped to their node entry points.

This is typically derived from the "bin" attribute in the package.json
file of the npm package being linked.

For example:

```
bins = {
    "foo": "./foo.js",
    "bar": "./bar.js",
}
```

In the future, this field may be automatically populated by npm_translate_lock
from information in the pnpm lock file. That feature is currently blocked on
https://github.com/pnpm/pnpm/issues/5131.{}(<
dev,Whether this npm package is a dev dependencyFalse(�
"register_copy_directory_toolchains�if True, `@aspect_bazel_lib//lib:repositories.bzl` `register_copy_directory_toolchains()` is called if the toolchain is not already registeredTrue(�
%register_copy_to_directory_toolchains�if True, `@aspect_bazel_lib//lib:repositories.bzl` `register_copy_to_directory_toolchains()` is called if the toolchain is not already registeredTrue(�
run_lifecycle_hooks�If True, runs `preinstall`, `install`, `postinstall` and 'prepare' lifecycle hooks declared
in this package.

Deprecated. Use `lifecycle_hooks` instead.None(�
lifecycle_hooks_no_sandbox�If True, adds "no-sandbox" to `lifecycle_hooks_execution_requirements`.

Deprecated. Add "no-sandbox" to `lifecycle_hooks_execution_requirements` instead.None(
kwargsInternal use only(� Import a single npm package into Bazel.

Normally you'd want to use `npm_translate_lock` to import all your packages at once.
It generates `npm_import` rules.
You can create these manually if you want to have exact control.

Bazel will only fetch the given package from an external registry if the package is
required for the user-requested targets to be build/tested.

This is a repository rule, which should be called from your `WORKSPACE` file
or some `.bzl` file loaded from it. For example, with this code in `WORKSPACE`:

```starlark
npm_import(
    name = "npm__at_types_node_15.12.2",
    package = "@types/node",
    version = "15.12.2",
    integrity = "sha512-zjQ69G564OCIWIOHSXyQEEDpdpGl+G348RAKY0XXy9Z5kU9Vzv1GMNnkar/ZJ8dzXB3COzD9Mo9NtRZ4xfgUww==",
)
```

> This is similar to Bazel rules in other ecosystems named "_import" like
> `apple_bundle_import`, `scala_import`, `java_import`, and `py_import`.
> `go_repository` is also a model for this rule.

The name of this repository should contain the version number, so that multiple versions of the same
package don't collide.
(Note that the npm ecosystem always supports multiple versions of a library depending on where
it is required, unlike other languages like Go or Python.)

To consume the downloaded package in rules, it must be "linked" into the link package in the
package's `BUILD.bazel` file:

```
load("@npm__at_types_node__15.12.2__links//:defs.bzl", npm_link_types_node = "npm_link_imported_package")

npm_link_types_node(name = "node_modules")
```

This links `@types/node` into the `node_modules` of this package with the target name `:node_modules/@types/node`.

A `:node_modules/@types/node/dir` filegroup target is also created that provides the the directory artifact of the npm package.
This target can be used to create entry points for binary target or to access files within the npm package.

NB: You can choose any target name for the link target but we recommend using the `node_modules/@scope/name` and
`node_modules/name` convention for readability.

When using `npm_translate_lock`, you can link all the npm dependencies in the lock file for a package:

```
load("@npm//:defs.bzl", "npm_link_all_packages")

npm_link_all_packages(name = "node_modules")
```

This creates `:node_modules/name` and `:node_modules/@scope/name` targets for all direct npm dependencies in the package.
It also creates `:node_modules/name/dir` and `:node_modules/@scope/name/dir` filegroup targets that provide the the directory artifacts of their npm packages.
These target can be used to create entry points for binary target or to access files within the npm package.

If you have a mix of `npm_link_all_packages` and `npm_link_imported_package` functions to call you can pass the
`npm_link_imported_package` link functions to the `imported_links` attribute of `npm_link_all_packages` to link
them all in one call. For example,

```
load("@npm//:defs.bzl", "npm_link_all_packages")
load("@npm__at_types_node__15.12.2__links//:defs.bzl", npm_link_types_node = "npm_link_imported_package")

npm_link_all_packages(
    name = "node_modules",
    imported_links = [
        npm_link_types_node,
    ]
)
```

This has the added benefit of adding the `imported_links` to the convienence `:node_modules` target which
includes all direct dependencies in that package.

NB: You can pass an name to npm_link_all_packages and this will change the targets generated to "{name}/@scope/name" and
"{name}/name". We recommend using "node_modules" as the convention for readability.

To change the proxy URL we use to fetch, configure the Bazel downloader:

1. Make a file containing a rewrite rule like

    `rewrite (registry.nodejs.org)/(.*) artifactory.build.internal.net/artifactory/$1/$2`

1. To understand the rewrites, see [UrlRewriterConfig] in Bazel sources.

1. Point bazel to the config with a line in .bazelrc like
common --experimental_downloader_config=.bazel_downloader_config

Read more about the downloader config: <https://blog.aspect.dev/configuring-bazels-downloader>

[UrlRewriterConfig]: https://github.com/bazelbuild/bazel/blob/4.2.1/src/main/java/com/google/devtools/build/lib/bazel/repository/downloader/UrlRewriterConfig.java#L66
2;

npm_import-@@aspect_rules_js//npm/private:npm_import.bzl
��2npm_import_rule�mnpm_translate_lock�Repository macro to generate starlark code from a lock file.

In most repositories, it would be an impossible maintenance burden to manually declare all
of the [`npm_import`](./npm_import) rules. This helper generates an external repository
containing a helper starlark module `repositories.bzl`, which supplies a loadable macro
`npm_repositories`. That macro creates an `npm_import` for each package.

The generated repository also contains `BUILD` files declaring targets for the packages
listed as `dependencies` or `devDependencies` in `package.json`, so you can declare
dependencies on those packages without having to repeat version information.

This macro creates a `pnpm` external repository, if the user didn't create a repository named
"pnpm" prior to calling `npm_translate_lock`.
`rules_js` currently only uses this repository when `npm_package_lock` or `yarn_lock` are used.
Set `pnpm_version` to `None` to inhibit this repository creation.

For more about how to use npm_translate_lock, read [pnpm and rules_js](/docs/pnpm.md).
*�e
�d
npm_translate_lock$
nameThe repository rule name (/
	pnpm_lockThe `pnpm-lock.yaml` file.None(�
npm_package_lockqThe `package-lock.json` file written by `npm install`.

Only one of `npm_package_lock` or `yarn_lock` may be set.None(
	yarn_lockjThe `yarn.lock` file written by `yarn install`.

Only one of `npm_package_lock` or `yarn_lock` may be set.None(�
update_pnpm_lock�When True, the pnpm lock file will be updated automatically when any of its inputs
have changed since the last update.

Defaults to True when one of `npm_package_lock` or `yarn_lock` are set.
Otherwise it defaults to False.

Read more: [using update_pnpm_lock](/docs/pnpm.md#update_pnpm_lock)None(�
	preupdate�Node.js scripts to run in this repository rule before auto-updating the pnpm lock file.

Scripts are run sequentially in the order they are listed. The working directory is set to the root of the
external repository. Make sure all files required by preupdate scripts are added to the `data` attribute.

A preupdate script could, for example, transform `resolutions` in the root `package.json` file from a format
that yarn understands such as `@foo/**/bar` to the equivalent `@foo/*>bar` that pnpm understands so that
`resolutions` are compatible with pnpm when running `pnpm import` to update the pnpm lock file.

Only needed when `update_pnpm_lock` is True.
Read more: [using update_pnpm_lock](/docs/pnpm.md#update_pnpm_lock)[](�
npmrc�The `.npmrc` file, if any, to use.

When set, the `.npmrc` file specified is parsed and npm auth tokens and basic authentication configuration
specified in the file are passed to the Bazel downloader for authentication with private npm registries.

In a future release, pnpm settings such as public-hoist-patterns will be used.None(�
use_home_npmrc�Use the `$HOME/.npmrc` file (or `$USERPROFILE/.npmrc` when on Windows) if it exists.

Settings from home `.npmrc` are merged with settings loaded from the `.npmrc` file specified
in the `npmrc` attribute, if any. Where there are conflicting settings, the home `.npmrc` values
will take precedence.

WARNING: The repository rule will not be invalidated by changes to the home `.npmrc` file since there
is no way to specify this file as an input to the repository rule. If changes are made to the home
`.npmrc` you can force the repository rule to re-run and pick up the changes by running:
`bazel run @{name}//:sync` where `name` is the name of the `npm_translate_lock` you want to re-run.

Because of the repository rule invalidation issue, using the home `.npmrc` is not recommended.
`.npmrc` settings should generally go in the `npmrc` in your repository so they are shared by all
developers. The home `.npmrc` should be reserved for authentication settings for private npm repositories.None(�
data�Data files required by this repository rule when auto-updating the pnpm lock file.

Only needed when `update_pnpm_lock` is True.
Read more: [using update_pnpm_lock](/docs/pnpm.md#update_pnpm_lock)[](�
patches�A map of package names or package names with their version (e.g., "my-package" or "my-package@v1.2.3")
to a label list of patches to apply to the downloaded npm package. Multiple matches are additive.

These patches are applied after any patches in [pnpm.patchedDependencies](https://pnpm.io/next/package_json#pnpmpatcheddependencies).

Read more: [patching](/docs/pnpm.md#patching){}(�

patch_args�A map of package names or package names with their version (e.g., "my-package" or "my-package@v1.2.3")
to a label list arguments to pass to the patch tool. The most specific match wins.

Read more: [patching](/docs/pnpm.md#patching){"*": ["-p0"]}(�
custom_postinstalls�A map of package names or package names with their version (e.g., "my-package" or "my-package@v1.2.3")
to a custom postinstall script to apply to the downloaded npm package after its lifecycle scripts runs.
If the version is left out of the package name, the script will run on every version of the npm package. If
a custom postinstall scripts exists for a package as well as for a specific version, the script for the versioned package
will be appended with `&&` to the non-versioned package script.

For example,

```
custom_postinstalls = {
    "@foo/bar": "echo something > somewhere.txt",
    "fum@0.0.1": "echo something_else > somewhere_else.txt",
},
```

Custom postinstalls are additive and joined with ` && ` when there are multiple matches for a package.
More specific matches are appended to previous matches.{}(P
prod?If True, only install `dependencies` but not `devDependencies`.False(�
public_hoist_packages�A map of package names or package names with their version (e.g., "my-package" or "my-package@v1.2.3")
to a list of Bazel packages in which to hoist the package to the top-level of the node_modules tree when linking.

This is similar to setting https://pnpm.io/npmrc#public-hoist-pattern in an .npmrc file outside of Bazel, however,
wild-cards are not yet supported and npm_translate_lock will fail if there are multiple versions of a package that
are to be hoisted.

```
public_hoist_packages = {
    "@foo/bar": [""] # link to the root package in the WORKSPACE
    "fum@0.0.1": ["some/sub/package"]
},
```

List of public hoist packages are additive when there are multiple matches for a package. More specific matches
are appended to previous matches.{}(7
dev'If True, only install `devDependencies`False(�
no_optional�If True, `optionalDependencies` are not installed.

Currently `npm_translate_lock` behaves differently from pnpm in that is downloads all `optionaDependencies`
while pnpm doesn't download `optionalDependencies` that are not needed for the platform pnpm is run on.
See https://github.com/pnpm/pnpm/pull/3672 for more context.False(�
run_lifecycle_hooksrSets a default value for `lifecycle_hooks` if `*` not already set.
Set this to `False` to disable lifecycle hooks.True(�
lifecycle_hooks�A dict of package names to list of lifecycle hooks to run for that package.

By default the `preinstall`, `install` and `postinstall` hooks are run if they exist. This attribute allows
the default to be overridden for packages to run `prepare`.

List of hooks are not additive. The most specific match wins.

Read more: [lifecycles](/docs/pnpm.md#lifecycles){}(�
lifecycle_hooks_envs�Environment variables set for the lifecycle hooks actions on npm packages.
The environment variables can be defined per package by package name or globally using "*".
Variables are declared as key/value pairs of the form "key=value".
Multiple matches are additive.

Read more: [lifecycles](/docs/pnpm.md#lifecycles){}(�
lifecycle_hooks_exclude�A list of package names or package names with their version (e.g., "my-package" or "my-package@v1.2.3")
to not run any lifecycle hooks on.

Equivalent to adding `<value>: []` to `lifecycle_hooks`.

Read more: [lifecycles](/docs/pnpm.md#lifecycles)[](�
&lifecycle_hooks_execution_requirements�Execution requirements applied to the preinstall, install and postinstall
lifecycle hooks on npm packages.

The execution requirements can be defined per package by package name or globally using "*".

Execution requirements are not additive. The most specific match wins.

Read more: [lifecycles](/docs/pnpm.md#lifecycles){}(�
lifecycle_hooks_no_sandbox�If True, a "no-sandbox" execution requirement is added to all lifecycle hooks
unless overridden by `lifecycle_hooks_execution_requirements`.

Equivalent to adding `"*": ["no-sandbox"]` to `lifecycle_hooks_execution_requirements`.

This defaults to True to limit the overhead of sandbox creation and copying the output
TreeArtifacts out of the sandbox.

Read more: [lifecycles](/docs/pnpm.md#lifecycles)True(�
bins�Binary files to create in `node_modules/.bin` for packages in this lock file.

For a given package, this is typically derived from the "bin" attribute in
the package.json file of that package.

For example:

```
bins = {
    "@foo/bar": {
        "foo": "./foo.js",
        "bar": "./bar.js"
    },
}
```

Dicts of bins not additive. The most specific match wins.

In the future, this field may be automatically populated from information in the pnpm lock
file. That feature is currently blocked on https://github.com/pnpm/pnpm/issues/5131.{}(�
verify_node_modules_ignored�node_modules folders in the source tree should be ignored by Bazel.

This points to a `.bazelignore` file to verify that all nested node_modules directories
pnpm will create are listed.

See https://github.com/bazelbuild/bazel/issues/8106None(�	
verify_patches�	Label to a patch list file.

Use this in together with the `list_patches` macro to guarantee that all patches in a patch folder
are included in the `patches` attribute.

For example:

```
verify_patches = "//patches:patches.list",
```

In your patches folder add a BUILD.bazel file containing.
```
load("@aspect_rules_js//npm:repositories.bzl", "list_patches")

list_patches(
    name = "patches",
    out = "patches.list",
)
```

Once you have created this file, you need to create an empty `patches.list` file before generating the first list. You can do this by running
```
touch patches/patches.list
```

Finally, write the patches file at least once to make sure all patches are listed. This can be done by running `bazel run //patches:patches_update`.

See the `list_patches` documentation for further info.
NOTE: if you would like to customize the patches directory location, you can set a flag in the `.npmrc`. Here is an example of what this might look like
```
# Set the directory for pnpm when patching
# https://github.com/pnpm/pnpm/issues/6508#issuecomment-1537242124
patches-dir=bazel/js/patches
```
If you do this, you will have to update the `verify_patches` path to be this path instead of `//patches` like above.None(w
quietfSet to False to print info logs and output stdout & stderr of pnpm lock update actions to the console.True(�
 external_repository_action_cache`The location of the external repository action cache to write to when `update_pnpm_lock` = True.0".aspect/rules/external_repository_action_cache"(�
link_workspace�The workspace name where links will be created for the packages in this lock file.

This is typically set in rule sets and libraries that vendor the starlark generated by npm_translate_lock
so the link_workspace passed to npm_import is set correctly so that links are created in the external
repository and not the user workspace.

Can be left unspecified if the link workspace is the user workspace.None(
pnpm_versiondpnpm version to use when generating the @pnpm repository. Set to None to not create this repository."8.6.0"(�
"register_copy_directory_toolchains�if True, `@aspect_bazel_lib//lib:repositories.bzl` `register_copy_directory_toolchains()` is called if the toolchain is not already registeredTrue(�
%register_copy_to_directory_toolchains�if True, `@aspect_bazel_lib//lib:repositories.bzl` `register_copy_to_directory_toolchains()` is called if the toolchain is not already registeredTrue(�
npm_package_target_name�The name of linked `npm_package` targets. When `npm_package` targets are linked as pnpm workspace
packages, the name of the target must align with this value.

The `{dirname}` placeholder is replaced with the directory name of the target.

By default the directory name of the target is used.

Default: `{dirname}`"{dirname}"(s
package_json[Deprecated.

Add all `package.json` files that are part of the workspace to `data` instead.None(]
warn_on_unqualified_tarball_url2Deprecated. Will be removed in next major release.None(
kwargsInternal use only(�Repository macro to generate starlark code from a lock file.

In most repositories, it would be an impossible maintenance burden to manually declare all
of the [`npm_import`](./npm_import) rules. This helper generates an external repository
containing a helper starlark module `repositories.bzl`, which supplies a loadable macro
`npm_repositories`. That macro creates an `npm_import` for each package.

The generated repository also contains `BUILD` files declaring targets for the packages
listed as `dependencies` or `devDependencies` in `package.json`, so you can declare
dependencies on those packages without having to repeat version information.

This macro creates a `pnpm` external repository, if the user didn't create a repository named
"pnpm" prior to calling `npm_translate_lock`.
`rules_js` currently only uses this repository when `npm_package_lock` or `yarn_lock` are used.
Set `pnpm_version` to `None` to inhibit this repository creation.

For more about how to use npm_translate_lock, read [pnpm and rules_js](/docs/pnpm.md).
2K
npm_translate_lock5@@aspect_rules_js//npm/private:npm_translate_lock.bzl
��2npm_translate_lock_rule�pnpm_repository�Import https://npmjs.com/package/pnpm and provide a js_binary to run the tool.

Useful as a way to run exactly the same pnpm as Bazel does, for example with:
bazel run -- @pnpm//:pnpm --dir $PWD
*�
�
pnpm_repository5
name)name of the resulting external repository (e
pnpm_versionJversion of pnpm, see https://www.npmjs.com/package/pnpm?activeTab=versions"8.6.0"(�Import https://npmjs.com/package/pnpm and provide a js_binary to run the tool.

Useful as a way to run exactly the same pnpm as Bazel does, for example with:
bazel run -- @pnpm//:pnpm --dir $PWD
2E
pnpm_repository2@@aspect_rules_js//npm/private:pnpm_repository.bzl
		2native.existing_rule2_npm_import�
//npm:repositories.bzlr�
(
aspect_rules_jsnpmrepositories.bzl9
LATEST_PNPM_VERSION_LATEST_PNPM_VERSION
0D+
list_patches_list_patches
^k(

npm_import_npm_import
~�9
npm_translate_lock_npm_translate_lock
��3
pnpm_repository_pnpm_repository
��
�'	LATEST_PNPM_VERSION8.6.0j8.6.0(DEPRECATED: see //npm:repositories.bzl.
�%
%
aspect_rules_jsnpmproviders.bzl�	NpmLinkedPackageInfoProvides a linked npm package2�	
�
NpmLinkedPackageInfoProvides a linked npm packageQ
labelHthe label of the npm_link_package_store target the created this providerC
link_package3package that this npm package is directly linked at#
packagename of this npm package&
versionversion of this npm package_

store_infoQthe NpmPackageStoreInfo of the linked npm package store that is backing this link@
files7depset of files that are part of the linked npm packager
transitive_files^depset of the transitive files that are part of the linked npm package and its transitive deps"<
NpmLinkedPackageInfo$@@aspect_rules_js//npm:providers.bzl
  S
Q
labelHthe label of the npm_link_package_store target the created this providerE
C
link_package3package that this npm package is directly linked at%
#
packagename of this npm package(
&
versionversion of this npm packagea
_

store_infoQthe NpmPackageStoreInfo of the linked npm package store that is backing this linkB
@
files7depset of files that are part of the linked npm packaget
r
transitive_files^depset of the transitive files that are part of the linked npm package and its transitive deps�	NpmPackageInfo�Provides the output directory (TreeArtifact) of an npm package containing the packages sources along with the package name and version2�
�
NpmPackageInfo�Provides the output directory (TreeArtifact) of an npm package containing the packages sources along with the package name and version#
packagename of this npm package&
versionversion of this npm packageW
	directoryJthe directory (typically a TreeArtifact) that contains the package sources�
npm_package_store_deps�A depset of NpmPackageStoreInfo providers from npm dependencies of the package and the packages's transitive deps to use as direct dependencies when linking with npm_link_package
hardlinkinternal use only"6
NpmPackageInfo$@@aspect_rules_js//npm:providers.bzl
%
#
packagename of this npm package(
&
versionversion of this npm packageY
W
	directoryJthe directory (typically a TreeArtifact) that contains the package sources�
�
npm_package_store_deps�A depset of NpmPackageStoreInfo providers from npm dependencies of the package and the packages's transitive deps to use as direct dependencies when linking with npm_link_package

hardlinkinternal use only�NpmPackageStoreInfo�Provides information about an npm package within the virtual store of a pnpm-style
symlinked node_modules tree.

See https://pnpm.io/symlinked-node-modules-structure for more information about
symlinked node_modules trees.2�
�
NpmPackageStoreInfo�Provides information about an npm package within the virtual store of a pnpm-style
symlinked node_modules tree.

See https://pnpm.io/symlinked-node-modules-structure for more information about
symlinked node_modules trees.@
root_package0package that this npm package store is linked at#
packagename of this npm package&
versionversion of this npm packageB
ref_deps6dictionary of dependency npm_package_store ref targets[
src_directoryJthe directory (typically a TreeArtifact) that contains the package sourcesX
virtual_store_directory=the TreeArtifact of this npm package's virtual store location9
files0depset of files that are part of the npm package`
transitive_filesLdepset of the files that are part of the npm package and its transitive deps:
dev3whether or not this npm package is a dev dependency";
NpmPackageStoreInfo$@@aspect_rules_js//npm:providers.bzl
B
@
root_package0package that this npm package store is linked at%
#
packagename of this npm package(
&
versionversion of this npm packageD
B
ref_deps6dictionary of dependency npm_package_store ref targets]
[
src_directoryJthe directory (typically a TreeArtifact) that contains the package sourcesZ
X
virtual_store_directory=the TreeArtifact of this npm package's virtual store location;
9
files0depset of files that are part of the npm packageb
`
transitive_filesLdepset of the files that are part of the npm package and its transitive deps<
:
dev3whether or not this npm package is a dev dependency�
)//npm/private:npm_linked_package_info.bzlr�
;
aspect_rules_jsnpm/privatenpm_linked_package_info.bzl;
NpmLinkedPackageInfo_NpmLinkedPackageInfo

�
"//npm/private:npm_package_info.bzlru
4
aspect_rules_jsnpm/privatenpm_package_info.bzl/
NpmPackageInfo_NpmPackageInfo
		

�
(//npm/private:npm_package_store_info.bzlr�
:
aspect_rules_jsnpm/privatenpm_package_store_info.bzl9
NpmPackageStoreInfo_NpmPackageStoreInfo

'Providers for building derivative rules��
(
aspect_rules_jsnpmrepositories.bzl�list_patches�Write a file containing a list of all patches in the current folder to the source tree.

Use this together with the `verify_patches` attribute of `npm_translate_lock` to verify
that all patches in a patch folder are included. This macro stamps a test to ensure the
file stays up to date.
*�
�
list_patches
nameName of the target (W
outHName of file to write to the source tree. If unspecified, `name` is usedNone(V
include_patterns)Patterns to pass to a glob of patch files["*.diff", "*.patch"](E
exclude_patterns+Patterns to ignore in a glob of patch files[](�Write a file containing a list of all patches in the current folder to the source tree.

Use this together with the `verify_patches` attribute of `npm_translate_lock` to verify
that all patches in a patch folder are included. This macro stamps a test to ensure the
file stays up to date.
2E
list_patches5@@aspect_rules_js//npm/private:npm_translate_lock.bzl
��"list_sources2list_sources2write_source_file�m
npm_import� Import a single npm package into Bazel.

Normally you'd want to use `npm_translate_lock` to import all your packages at once.
It generates `npm_import` rules.
You can create these manually if you want to have exact control.

Bazel will only fetch the given package from an external registry if the package is
required for the user-requested targets to be build/tested.

This is a repository rule, which should be called from your `WORKSPACE` file
or some `.bzl` file loaded from it. For example, with this code in `WORKSPACE`:

```starlark
npm_import(
    name = "npm__at_types_node_15.12.2",
    package = "@types/node",
    version = "15.12.2",
    integrity = "sha512-zjQ69G564OCIWIOHSXyQEEDpdpGl+G348RAKY0XXy9Z5kU9Vzv1GMNnkar/ZJ8dzXB3COzD9Mo9NtRZ4xfgUww==",
)
```

> This is similar to Bazel rules in other ecosystems named "_import" like
> `apple_bundle_import`, `scala_import`, `java_import`, and `py_import`.
> `go_repository` is also a model for this rule.

The name of this repository should contain the version number, so that multiple versions of the same
package don't collide.
(Note that the npm ecosystem always supports multiple versions of a library depending on where
it is required, unlike other languages like Go or Python.)

To consume the downloaded package in rules, it must be "linked" into the link package in the
package's `BUILD.bazel` file:

```
load("@npm__at_types_node__15.12.2__links//:defs.bzl", npm_link_types_node = "npm_link_imported_package")

npm_link_types_node(name = "node_modules")
```

This links `@types/node` into the `node_modules` of this package with the target name `:node_modules/@types/node`.

A `:node_modules/@types/node/dir` filegroup target is also created that provides the the directory artifact of the npm package.
This target can be used to create entry points for binary target or to access files within the npm package.

NB: You can choose any target name for the link target but we recommend using the `node_modules/@scope/name` and
`node_modules/name` convention for readability.

When using `npm_translate_lock`, you can link all the npm dependencies in the lock file for a package:

```
load("@npm//:defs.bzl", "npm_link_all_packages")

npm_link_all_packages(name = "node_modules")
```

This creates `:node_modules/name` and `:node_modules/@scope/name` targets for all direct npm dependencies in the package.
It also creates `:node_modules/name/dir` and `:node_modules/@scope/name/dir` filegroup targets that provide the the directory artifacts of their npm packages.
These target can be used to create entry points for binary target or to access files within the npm package.

If you have a mix of `npm_link_all_packages` and `npm_link_imported_package` functions to call you can pass the
`npm_link_imported_package` link functions to the `imported_links` attribute of `npm_link_all_packages` to link
them all in one call. For example,

```
load("@npm//:defs.bzl", "npm_link_all_packages")
load("@npm__at_types_node__15.12.2__links//:defs.bzl", npm_link_types_node = "npm_link_imported_package")

npm_link_all_packages(
    name = "node_modules",
    imported_links = [
        npm_link_types_node,
    ]
)
```

This has the added benefit of adding the `imported_links` to the convienence `:node_modules` target which
includes all direct dependencies in that package.

NB: You can pass an name to npm_link_all_packages and this will change the targets generated to "{name}/@scope/name" and
"{name}/name". We recommend using "node_modules" as the convention for readability.

To change the proxy URL we use to fetch, configure the Bazel downloader:

1. Make a file containing a rewrite rule like

    `rewrite (registry.nodejs.org)/(.*) artifactory.build.internal.net/artifactory/$1/$2`

1. To understand the rewrites, see [UrlRewriterConfig] in Bazel sources.

1. Point bazel to the config with a line in .bazelrc like
common --experimental_downloader_config=.bazel_downloader_config

Read more about the downloader config: <https://blog.aspect.dev/configuring-bazels-downloader>

[UrlRewriterConfig]: https://github.com/bazelbuild/bazel/blob/4.2.1/src/main/java/com/google/devtools/build/lib/bazel/repository/downloader/UrlRewriterConfig.java#L66
*�L
�L

npm_import)
nameName for this repository rule (H
package9Name of the npm package, such as `acorn` or `@types/node` (:
version+Version of the npm package, such as `8.4.0` (v
depshA dict other npm packages this one depends on where the key is the package name and value is the version{}(�
extra_build_content�Additional content to append on the generated BUILD file at the root of
the created repository, either as a string or a list of lines similar to
<https://github.com/bazelbuild/bazel-skylib/blob/main/docs/write_file_doc.md>.""(�
transitive_closure�A dict all npm packages this one depends on directly or transitively where the key is the
package name and value is a list of version(s) depended on in the closure.{}(�
root_package�The root package where the node_modules virtual store is linked to.
Typically this is the package that the pnpm-lock.yaml file is located when using `npm_translate_lock`.""(�
link_workspace�The workspace name where links will be created for this package.

This is typically set in rule sets and libraries that are to be consumed as external repositories so
links are created in the external repository and not the user workspace.

Can be left unspecified if the link workspace is the user workspace.""(�
link_packages�Dict of paths where links may be created at for this package to
a list of link aliases to link as in each package. If aliases are an
empty list this indicates to link as the package name.

Defaults to {} which indicates that links may be created in any package as specified by
the `direct` attribute of the generated npm_link_package.{}(m
lifecycle_hooksTList of lifecycle hook `package.json` scripts to run for this package if they exist.[](�
&lifecycle_hooks_execution_requirements�Execution requirements when running the lifecycle hooks.

For example:

```
lifecycle_hooks_execution_requirements: ["no-sandbox', "requires-network"]
```

This defaults to ["no-sandbox"] to limit the overhead of sandbox creation and copying the output
TreeArtifact out of the sandbox.["no-sandbox"](�
lifecycle_hooks_env�Environment variables set for the lifecycle hooks action for this npm
package if there is one.

Environment variables are defined by providing an array of "key=value" entries.

For example:

```
lifecycle_hooks_env: ["PREBULT_BINARY=https://downloadurl"],
```[](�
	integrity�Expected checksum of the file downloaded, in Subresource Integrity format.
This must match the checksum of the file downloaded.

This is the same as appears in the pnpm-lock.yaml, yarn.lock or package-lock.json file.

It is a security risk to omit the checksum as remote files can change.

At best omitting this field will make your build non-hermetic.

It is optional to make development easier but should be set before shipping.""(�
url�Optional url for this package. If unset, a default npm registry url is generated from
the package name and version.

May start with `git+ssh://` or `git+https://` to indicate a git repository. For example,

```
git+ssh://git@github.com/org/repo.git
```

If url is configured as a git repository, the commit attribute must be set to the
desired commit.""(M
commit=Specific commit to be checked out if url is a git repository.""(y

patch_args`Arguments to pass to the patch tool.

`-p1` will usually be needed for patches generated by git.["-p0"](F
patches5Patch files to apply onto the downloaded npm package.[](�
custom_postinstall�Custom string postinstall script to run on the installed npm package. Runs after any
existing lifecycle hooks if `run_lifecycle_hooks` is True.""(X
npm_authFAuth token to authenticate with npm. When using Bearer authentication.""(�
npm_auth_basic�Auth token to authenticate with npm. When using Basic authentication.

This is typically the base64 encoded string "username:password".""(c
npm_auth_usernameHAuth username to authenticate with npm. When using Basic authentication.""(c
npm_auth_passwordHAuth password to authenticate with npm. When using Basic authentication.""(�
bins�Dictionary of `node_modules/.bin` binary files to create mapped to their node entry points.

This is typically derived from the "bin" attribute in the package.json
file of the npm package being linked.

For example:

```
bins = {
    "foo": "./foo.js",
    "bar": "./bar.js",
}
```

In the future, this field may be automatically populated by npm_translate_lock
from information in the pnpm lock file. That feature is currently blocked on
https://github.com/pnpm/pnpm/issues/5131.{}(<
dev,Whether this npm package is a dev dependencyFalse(�
"register_copy_directory_toolchains�if True, `@aspect_bazel_lib//lib:repositories.bzl` `register_copy_directory_toolchains()` is called if the toolchain is not already registeredTrue(�
%register_copy_to_directory_toolchains�if True, `@aspect_bazel_lib//lib:repositories.bzl` `register_copy_to_directory_toolchains()` is called if the toolchain is not already registeredTrue(�
run_lifecycle_hooks�If True, runs `preinstall`, `install`, `postinstall` and 'prepare' lifecycle hooks declared
in this package.

Deprecated. Use `lifecycle_hooks` instead.None(�
lifecycle_hooks_no_sandbox�If True, adds "no-sandbox" to `lifecycle_hooks_execution_requirements`.

Deprecated. Add "no-sandbox" to `lifecycle_hooks_execution_requirements` instead.None(
kwargsInternal use only(� Import a single npm package into Bazel.

Normally you'd want to use `npm_translate_lock` to import all your packages at once.
It generates `npm_import` rules.
You can create these manually if you want to have exact control.

Bazel will only fetch the given package from an external registry if the package is
required for the user-requested targets to be build/tested.

This is a repository rule, which should be called from your `WORKSPACE` file
or some `.bzl` file loaded from it. For example, with this code in `WORKSPACE`:

```starlark
npm_import(
    name = "npm__at_types_node_15.12.2",
    package = "@types/node",
    version = "15.12.2",
    integrity = "sha512-zjQ69G564OCIWIOHSXyQEEDpdpGl+G348RAKY0XXy9Z5kU9Vzv1GMNnkar/ZJ8dzXB3COzD9Mo9NtRZ4xfgUww==",
)
```

> This is similar to Bazel rules in other ecosystems named "_import" like
> `apple_bundle_import`, `scala_import`, `java_import`, and `py_import`.
> `go_repository` is also a model for this rule.

The name of this repository should contain the version number, so that multiple versions of the same
package don't collide.
(Note that the npm ecosystem always supports multiple versions of a library depending on where
it is required, unlike other languages like Go or Python.)

To consume the downloaded package in rules, it must be "linked" into the link package in the
package's `BUILD.bazel` file:

```
load("@npm__at_types_node__15.12.2__links//:defs.bzl", npm_link_types_node = "npm_link_imported_package")

npm_link_types_node(name = "node_modules")
```

This links `@types/node` into the `node_modules` of this package with the target name `:node_modules/@types/node`.

A `:node_modules/@types/node/dir` filegroup target is also created that provides the the directory artifact of the npm package.
This target can be used to create entry points for binary target or to access files within the npm package.

NB: You can choose any target name for the link target but we recommend using the `node_modules/@scope/name` and
`node_modules/name` convention for readability.

When using `npm_translate_lock`, you can link all the npm dependencies in the lock file for a package:

```
load("@npm//:defs.bzl", "npm_link_all_packages")

npm_link_all_packages(name = "node_modules")
```

This creates `:node_modules/name` and `:node_modules/@scope/name` targets for all direct npm dependencies in the package.
It also creates `:node_modules/name/dir` and `:node_modules/@scope/name/dir` filegroup targets that provide the the directory artifacts of their npm packages.
These target can be used to create entry points for binary target or to access files within the npm package.

If you have a mix of `npm_link_all_packages` and `npm_link_imported_package` functions to call you can pass the
`npm_link_imported_package` link functions to the `imported_links` attribute of `npm_link_all_packages` to link
them all in one call. For example,

```
load("@npm//:defs.bzl", "npm_link_all_packages")
load("@npm__at_types_node__15.12.2__links//:defs.bzl", npm_link_types_node = "npm_link_imported_package")

npm_link_all_packages(
    name = "node_modules",
    imported_links = [
        npm_link_types_node,
    ]
)
```

This has the added benefit of adding the `imported_links` to the convienence `:node_modules` target which
includes all direct dependencies in that package.

NB: You can pass an name to npm_link_all_packages and this will change the targets generated to "{name}/@scope/name" and
"{name}/name". We recommend using "node_modules" as the convention for readability.

To change the proxy URL we use to fetch, configure the Bazel downloader:

1. Make a file containing a rewrite rule like

    `rewrite (registry.nodejs.org)/(.*) artifactory.build.internal.net/artifactory/$1/$2`

1. To understand the rewrites, see [UrlRewriterConfig] in Bazel sources.

1. Point bazel to the config with a line in .bazelrc like
common --experimental_downloader_config=.bazel_downloader_config

Read more about the downloader config: <https://blog.aspect.dev/configuring-bazels-downloader>

[UrlRewriterConfig]: https://github.com/bazelbuild/bazel/blob/4.2.1/src/main/java/com/google/devtools/build/lib/bazel/repository/downloader/UrlRewriterConfig.java#L66
2;

npm_import-@@aspect_rules_js//npm/private:npm_import.bzl
��2npm_import_rule�mnpm_translate_lock�Repository macro to generate starlark code from a lock file.

In most repositories, it would be an impossible maintenance burden to manually declare all
of the [`npm_import`](./npm_import) rules. This helper generates an external repository
containing a helper starlark module `repositories.bzl`, which supplies a loadable macro
`npm_repositories`. That macro creates an `npm_import` for each package.

The generated repository also contains `BUILD` files declaring targets for the packages
listed as `dependencies` or `devDependencies` in `package.json`, so you can declare
dependencies on those packages without having to repeat version information.

This macro creates a `pnpm` external repository, if the user didn't create a repository named
"pnpm" prior to calling `npm_translate_lock`.
`rules_js` currently only uses this repository when `npm_package_lock` or `yarn_lock` are used.
Set `pnpm_version` to `None` to inhibit this repository creation.

For more about how to use npm_translate_lock, read [pnpm and rules_js](/docs/pnpm.md).
*�e
�d
npm_translate_lock$
nameThe repository rule name (/
	pnpm_lockThe `pnpm-lock.yaml` file.None(�
npm_package_lockqThe `package-lock.json` file written by `npm install`.

Only one of `npm_package_lock` or `yarn_lock` may be set.None(
	yarn_lockjThe `yarn.lock` file written by `yarn install`.

Only one of `npm_package_lock` or `yarn_lock` may be set.None(�
update_pnpm_lock�When True, the pnpm lock file will be updated automatically when any of its inputs
have changed since the last update.

Defaults to True when one of `npm_package_lock` or `yarn_lock` are set.
Otherwise it defaults to False.

Read more: [using update_pnpm_lock](/docs/pnpm.md#update_pnpm_lock)None(�
	preupdate�Node.js scripts to run in this repository rule before auto-updating the pnpm lock file.

Scripts are run sequentially in the order they are listed. The working directory is set to the root of the
external repository. Make sure all files required by preupdate scripts are added to the `data` attribute.

A preupdate script could, for example, transform `resolutions` in the root `package.json` file from a format
that yarn understands such as `@foo/**/bar` to the equivalent `@foo/*>bar` that pnpm understands so that
`resolutions` are compatible with pnpm when running `pnpm import` to update the pnpm lock file.

Only needed when `update_pnpm_lock` is True.
Read more: [using update_pnpm_lock](/docs/pnpm.md#update_pnpm_lock)[](�
npmrc�The `.npmrc` file, if any, to use.

When set, the `.npmrc` file specified is parsed and npm auth tokens and basic authentication configuration
specified in the file are passed to the Bazel downloader for authentication with private npm registries.

In a future release, pnpm settings such as public-hoist-patterns will be used.None(�
use_home_npmrc�Use the `$HOME/.npmrc` file (or `$USERPROFILE/.npmrc` when on Windows) if it exists.

Settings from home `.npmrc` are merged with settings loaded from the `.npmrc` file specified
in the `npmrc` attribute, if any. Where there are conflicting settings, the home `.npmrc` values
will take precedence.

WARNING: The repository rule will not be invalidated by changes to the home `.npmrc` file since there
is no way to specify this file as an input to the repository rule. If changes are made to the home
`.npmrc` you can force the repository rule to re-run and pick up the changes by running:
`bazel run @{name}//:sync` where `name` is the name of the `npm_translate_lock` you want to re-run.

Because of the repository rule invalidation issue, using the home `.npmrc` is not recommended.
`.npmrc` settings should generally go in the `npmrc` in your repository so they are shared by all
developers. The home `.npmrc` should be reserved for authentication settings for private npm repositories.None(�
data�Data files required by this repository rule when auto-updating the pnpm lock file.

Only needed when `update_pnpm_lock` is True.
Read more: [using update_pnpm_lock](/docs/pnpm.md#update_pnpm_lock)[](�
patches�A map of package names or package names with their version (e.g., "my-package" or "my-package@v1.2.3")
to a label list of patches to apply to the downloaded npm package. Multiple matches are additive.

These patches are applied after any patches in [pnpm.patchedDependencies](https://pnpm.io/next/package_json#pnpmpatcheddependencies).

Read more: [patching](/docs/pnpm.md#patching){}(�

patch_args�A map of package names or package names with their version (e.g., "my-package" or "my-package@v1.2.3")
to a label list arguments to pass to the patch tool. The most specific match wins.

Read more: [patching](/docs/pnpm.md#patching){"*": ["-p0"]}(�
custom_postinstalls�A map of package names or package names with their version (e.g., "my-package" or "my-package@v1.2.3")
to a custom postinstall script to apply to the downloaded npm package after its lifecycle scripts runs.
If the version is left out of the package name, the script will run on every version of the npm package. If
a custom postinstall scripts exists for a package as well as for a specific version, the script for the versioned package
will be appended with `&&` to the non-versioned package script.

For example,

```
custom_postinstalls = {
    "@foo/bar": "echo something > somewhere.txt",
    "fum@0.0.1": "echo something_else > somewhere_else.txt",
},
```

Custom postinstalls are additive and joined with ` && ` when there are multiple matches for a package.
More specific matches are appended to previous matches.{}(P
prod?If True, only install `dependencies` but not `devDependencies`.False(�
public_hoist_packages�A map of package names or package names with their version (e.g., "my-package" or "my-package@v1.2.3")
to a list of Bazel packages in which to hoist the package to the top-level of the node_modules tree when linking.

This is similar to setting https://pnpm.io/npmrc#public-hoist-pattern in an .npmrc file outside of Bazel, however,
wild-cards are not yet supported and npm_translate_lock will fail if there are multiple versions of a package that
are to be hoisted.

```
public_hoist_packages = {
    "@foo/bar": [""] # link to the root package in the WORKSPACE
    "fum@0.0.1": ["some/sub/package"]
},
```

List of public hoist packages are additive when there are multiple matches for a package. More specific matches
are appended to previous matches.{}(7
dev'If True, only install `devDependencies`False(�
no_optional�If True, `optionalDependencies` are not installed.

Currently `npm_translate_lock` behaves differently from pnpm in that is downloads all `optionaDependencies`
while pnpm doesn't download `optionalDependencies` that are not needed for the platform pnpm is run on.
See https://github.com/pnpm/pnpm/pull/3672 for more context.False(�
run_lifecycle_hooksrSets a default value for `lifecycle_hooks` if `*` not already set.
Set this to `False` to disable lifecycle hooks.True(�
lifecycle_hooks�A dict of package names to list of lifecycle hooks to run for that package.

By default the `preinstall`, `install` and `postinstall` hooks are run if they exist. This attribute allows
the default to be overridden for packages to run `prepare`.

List of hooks are not additive. The most specific match wins.

Read more: [lifecycles](/docs/pnpm.md#lifecycles){}(�
lifecycle_hooks_envs�Environment variables set for the lifecycle hooks actions on npm packages.
The environment variables can be defined per package by package name or globally using "*".
Variables are declared as key/value pairs of the form "key=value".
Multiple matches are additive.

Read more: [lifecycles](/docs/pnpm.md#lifecycles){}(�
lifecycle_hooks_exclude�A list of package names or package names with their version (e.g., "my-package" or "my-package@v1.2.3")
to not run any lifecycle hooks on.

Equivalent to adding `<value>: []` to `lifecycle_hooks`.

Read more: [lifecycles](/docs/pnpm.md#lifecycles)[](�
&lifecycle_hooks_execution_requirements�Execution requirements applied to the preinstall, install and postinstall
lifecycle hooks on npm packages.

The execution requirements can be defined per package by package name or globally using "*".

Execution requirements are not additive. The most specific match wins.

Read more: [lifecycles](/docs/pnpm.md#lifecycles){}(�
lifecycle_hooks_no_sandbox�If True, a "no-sandbox" execution requirement is added to all lifecycle hooks
unless overridden by `lifecycle_hooks_execution_requirements`.

Equivalent to adding `"*": ["no-sandbox"]` to `lifecycle_hooks_execution_requirements`.

This defaults to True to limit the overhead of sandbox creation and copying the output
TreeArtifacts out of the sandbox.

Read more: [lifecycles](/docs/pnpm.md#lifecycles)True(�
bins�Binary files to create in `node_modules/.bin` for packages in this lock file.

For a given package, this is typically derived from the "bin" attribute in
the package.json file of that package.

For example:

```
bins = {
    "@foo/bar": {
        "foo": "./foo.js",
        "bar": "./bar.js"
    },
}
```

Dicts of bins not additive. The most specific match wins.

In the future, this field may be automatically populated from information in the pnpm lock
file. That feature is currently blocked on https://github.com/pnpm/pnpm/issues/5131.{}(�
verify_node_modules_ignored�node_modules folders in the source tree should be ignored by Bazel.

This points to a `.bazelignore` file to verify that all nested node_modules directories
pnpm will create are listed.

See https://github.com/bazelbuild/bazel/issues/8106None(�	
verify_patches�	Label to a patch list file.

Use this in together with the `list_patches` macro to guarantee that all patches in a patch folder
are included in the `patches` attribute.

For example:

```
verify_patches = "//patches:patches.list",
```

In your patches folder add a BUILD.bazel file containing.
```
load("@aspect_rules_js//npm:repositories.bzl", "list_patches")

list_patches(
    name = "patches",
    out = "patches.list",
)
```

Once you have created this file, you need to create an empty `patches.list` file before generating the first list. You can do this by running
```
touch patches/patches.list
```

Finally, write the patches file at least once to make sure all patches are listed. This can be done by running `bazel run //patches:patches_update`.

See the `list_patches` documentation for further info.
NOTE: if you would like to customize the patches directory location, you can set a flag in the `.npmrc`. Here is an example of what this might look like
```
# Set the directory for pnpm when patching
# https://github.com/pnpm/pnpm/issues/6508#issuecomment-1537242124
patches-dir=bazel/js/patches
```
If you do this, you will have to update the `verify_patches` path to be this path instead of `//patches` like above.None(w
quietfSet to False to print info logs and output stdout & stderr of pnpm lock update actions to the console.True(�
 external_repository_action_cache`The location of the external repository action cache to write to when `update_pnpm_lock` = True.0".aspect/rules/external_repository_action_cache"(�
link_workspace�The workspace name where links will be created for the packages in this lock file.

This is typically set in rule sets and libraries that vendor the starlark generated by npm_translate_lock
so the link_workspace passed to npm_import is set correctly so that links are created in the external
repository and not the user workspace.

Can be left unspecified if the link workspace is the user workspace.None(
pnpm_versiondpnpm version to use when generating the @pnpm repository. Set to None to not create this repository."8.6.0"(�
"register_copy_directory_toolchains�if True, `@aspect_bazel_lib//lib:repositories.bzl` `register_copy_directory_toolchains()` is called if the toolchain is not already registeredTrue(�
%register_copy_to_directory_toolchains�if True, `@aspect_bazel_lib//lib:repositories.bzl` `register_copy_to_directory_toolchains()` is called if the toolchain is not already registeredTrue(�
npm_package_target_name�The name of linked `npm_package` targets. When `npm_package` targets are linked as pnpm workspace
packages, the name of the target must align with this value.

The `{dirname}` placeholder is replaced with the directory name of the target.

By default the directory name of the target is used.

Default: `{dirname}`"{dirname}"(s
package_json[Deprecated.

Add all `package.json` files that are part of the workspace to `data` instead.None(]
warn_on_unqualified_tarball_url2Deprecated. Will be removed in next major release.None(
kwargsInternal use only(�Repository macro to generate starlark code from a lock file.

In most repositories, it would be an impossible maintenance burden to manually declare all
of the [`npm_import`](./npm_import) rules. This helper generates an external repository
containing a helper starlark module `repositories.bzl`, which supplies a loadable macro
`npm_repositories`. That macro creates an `npm_import` for each package.

The generated repository also contains `BUILD` files declaring targets for the packages
listed as `dependencies` or `devDependencies` in `package.json`, so you can declare
dependencies on those packages without having to repeat version information.

This macro creates a `pnpm` external repository, if the user didn't create a repository named
"pnpm" prior to calling `npm_translate_lock`.
`rules_js` currently only uses this repository when `npm_package_lock` or `yarn_lock` are used.
Set `pnpm_version` to `None` to inhibit this repository creation.

For more about how to use npm_translate_lock, read [pnpm and rules_js](/docs/pnpm.md).
2K
npm_translate_lock5@@aspect_rules_js//npm/private:npm_translate_lock.bzl
��2npm_translate_lock_rule�pnpm_repository�Import https://npmjs.com/package/pnpm and provide a js_binary to run the tool.

Useful as a way to run exactly the same pnpm as Bazel does, for example with:
bazel run -- @pnpm//:pnpm --dir $PWD
*�
�
pnpm_repository5
name)name of the resulting external repository (e
pnpm_versionJversion of pnpm, see https://www.npmjs.com/package/pnpm?activeTab=versions"8.6.0"(�Import https://npmjs.com/package/pnpm and provide a js_binary to run the tool.

Useful as a way to run exactly the same pnpm as Bazel does, for example with:
bazel run -- @pnpm//:pnpm --dir $PWD
2E
pnpm_repository2@@aspect_rules_js//npm/private:pnpm_repository.bzl
		2native.existing_rule2_npm_import�
//npm/private:npm_import.bzlrg
.
aspect_rules_jsnpm/privatenpm_import.bzl'

npm_import_npm_import
6A
Q�
$//npm/private:npm_translate_lock.bzlr�
6
aspect_rules_jsnpm/privatenpm_translate_lock.bzl+
list_patches_list_patches
>K7
npm_translate_lock_npm_translate_lock
^q
��
!//npm/private:pnpm_repository.bzlr�
3
aspect_rules_jsnpm/privatepnpm_repository.bzl9
LATEST_PNPM_VERSION_LATEST_PNPM_VERSION
;O1
pnpm_repository_pnpm_repository
iy
�'	LATEST_PNPM_VERSION8.6.0j8.6.02Repository rules to fetch third-party npm packages 