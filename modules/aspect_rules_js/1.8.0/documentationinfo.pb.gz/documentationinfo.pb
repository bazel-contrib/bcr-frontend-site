�
6
aspect_rules_jsexamples/js_binarycustom_rule.bzl�custom_rule"�
�
custom_rule*
nameA unique name for this target. 
execution_requirements
2{}
tool2None"D
custom_rule5@@aspect_rules_js//examples/js_binary:custom_rule.bzl
,
*
nameA unique name for this target.  

execution_requirements
2{}

tool2None@A simple custom rule for testing js_binary used in a custom rule�
3
aspect_rules_jsexamples/js_library/twotsc.bzl�tsc*�
{
tsc

name (!
args["-p", "tsconfig.json"](

kwargs(29
tsc2@@aspect_rules_js//examples/js_library/two:tsc.bzl
y
:typescript/package_json.bzlrW
"
npmtypescript/package_json.bzl#
bintypescript_bin
,:
CwSimple macro exposing the typescript tsc binary.

Most users should use ts_project from aspect-build/rules_ts instead.
�
,
aspect_rules_jsexamples/macro	mocha.bzl�
mocha_test*�
�

mocha_test

name (

srcs (
args[](
data[](
env{}(

kwargs(29

mocha_test+@@aspect_rules_js//examples/macro:mocha.bzl
*dict�
'//examples/macro:mocha/package_json.bzlrW
-
npmexamples/macromocha/package_json.bzl
binbin
69
;$Example macro wrapping the mocha CLI�
2
aspect_rules_jsjs/private/coverage
merger.bzl�coverage_merger"�
�
coverage_merger*
nameA unique name for this target. 2
entry_point2!//js/private/coverage:coverage.js"D
coverage_merger1@@aspect_rules_js//js/private/coverage:merger.bzl
44,
*
nameA unique name for this target. 4
2
entry_point2!//js/private/coverage:coverage.js�
//lib:windows_utils.bzlr�
*
aspect_bazel_liblibwindows_utils.bzl\
%create_windows_native_launcher_script%create_windows_native_launcher_script
3X
Z�
//js/private:bash.bzlr{
'
aspect_rules_js
js/privatebash.bzlB
BASH_INITIALIZE_RUNFILESBASH_INITIALIZE_RUNFILES
0H
JInternal use only��
5
aspect_rules_jsjs/private/test/coveragetest.bzl�hcoverage_fail_test"�h
�4
coverage_fail_test*
nameA unique name for this target. �
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/")) + "$(rootpath //path/to/some:file)"],
)
```2""�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

You can use the `@bazel/runfiles` npm library to access these files
at runtime.

npm packages are also linked into the `.runfiles/node_modules` folder
so they may be resolved directly from runfiles.
2[]�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/aspect-build/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 h
env[Environment variables of the action.

Subject to `$(location)` and make variable expansion.
2{}i
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�
include_declarations�When True, `declarations` and `transitive_declarations` from `JsInfo` providers in data targets are included in the runfiles of the target.

Defaults to false since declarations are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
include_npm_linked_packages�When True, files in `npm_linked_packages` and `transitive_npm_linked_packages` from `JsInfo` providers in data targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in data targets are also included in the runfiles of the target.
2True�
include_transitive_sourcessWhen True, `transitive_sources` from `JsInfo` providers in data targets are included in the runfiles of the target.2True�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.2"error"�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2True"J
coverage_fail_test4@@aspect_rules_js//js/private/test/coverage:test.bzl
,
*
nameA unique name for this target. �
�
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/")) + "$(rootpath //path/to/some:file)"],
)
```2""�
�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

You can use the `@bazel/runfiles` npm library to access these files
at runtime.

npm packages are also linked into the `.runfiles/node_modules` folder
so they may be resolved directly from runfiles.
2[]�
�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
�
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/aspect-build/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 j
h
env[Environment variables of the action.

Subject to `$(location)` and make variable expansion.
2{}k
i
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�
�
include_declarations�When True, `declarations` and `transitive_declarations` from `JsInfo` providers in data targets are included in the runfiles of the target.

Defaults to false since declarations are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
�
include_npm_linked_packages�When True, files in `npm_linked_packages` and `transitive_npm_linked_packages` from `JsInfo` providers in data targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in data targets are also included in the runfiles of the target.
2True�
�
include_transitive_sourcessWhen True, `transitive_sources` from `JsInfo` providers in data targets are included in the runfiles of the target.2True�
�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.2"error"�
�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2True�hcoverage_pass_test"�h
�4
coverage_pass_test*
nameA unique name for this target. �
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/")) + "$(rootpath //path/to/some:file)"],
)
```2""�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

You can use the `@bazel/runfiles` npm library to access these files
at runtime.

npm packages are also linked into the `.runfiles/node_modules` folder
so they may be resolved directly from runfiles.
2[]�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/aspect-build/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 h
env[Environment variables of the action.

Subject to `$(location)` and make variable expansion.
2{}i
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�
include_declarations�When True, `declarations` and `transitive_declarations` from `JsInfo` providers in data targets are included in the runfiles of the target.

Defaults to false since declarations are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
include_npm_linked_packages�When True, files in `npm_linked_packages` and `transitive_npm_linked_packages` from `JsInfo` providers in data targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in data targets are also included in the runfiles of the target.
2True�
include_transitive_sourcessWhen True, `transitive_sources` from `JsInfo` providers in data targets are included in the runfiles of the target.2True�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.2"error"�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2True"J
coverage_pass_test4@@aspect_rules_js//js/private/test/coverage:test.bzl
,
*
nameA unique name for this target. �
�
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/")) + "$(rootpath //path/to/some:file)"],
)
```2""�
�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

You can use the `@bazel/runfiles` npm library to access these files
at runtime.

npm packages are also linked into the `.runfiles/node_modules` folder
so they may be resolved directly from runfiles.
2[]�
�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
�
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/aspect-build/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 j
h
env[Environment variables of the action.

Subject to `$(location)` and make variable expansion.
2{}k
i
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�
�
include_declarations�When True, `declarations` and `transitive_declarations` from `JsInfo` providers in data targets are included in the runfiles of the target.

Defaults to false since declarations are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
�
include_npm_linked_packages�When True, files in `npm_linked_packages` and `transitive_npm_linked_packages` from `JsInfo` providers in data targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in data targets are also included in the runfiles of the target.
2True�
�
include_transitive_sourcessWhen True, `transitive_sources` from `JsInfo` providers in data targets are included in the runfiles of the target.2True�
�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.2"error"�
�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2True�
//js/private:js_binary.bzlrj
,
aspect_rules_js
js/privatejs_binary.bzl,
js_binary_libjs_binary_lib
5B
D�:
'
aspect_rules_js
js/privatebash.bzl�:	BASH_INITIALIZE_RUNFILES�
# It helps to determine if we are running on a Windows environment (excludes WSL as it acts like Unix)
case "$(uname -s)" in
    CYGWIN*)    _IS_WINDOWS=1 ;;
    MINGW*)     _IS_WINDOWS=1 ;;
    MSYS_NT*)   _IS_WINDOWS=1 ;;
    *)          _IS_WINDOWS=0 ;;
esac

# It helps to normalizes paths when running on Windows.
#
# Example:
# C:/Users/XUser/_bazel_XUser/7q7kkv32/execroot/A/b/C -> /c/Users/XUser/_bazel_XUser/7q7kkv32/execroot/A/b/C
function _normalize_path {
    if [ "$_IS_WINDOWS" -eq "1" ]; then
        # Apply the followings paths transformations to normalize paths on Windows
        # -process driver letter
        # -convert path separator
        sed -e 's#^\(.\):#/\L\1#' -e 's#\\#/#g' <<< "$1"
    else
        echo "$1"
    fi
    return
}

# Set a RUNFILES environment variable to the root of the runfiles tree
# since RUNFILES_DIR is not set by Bazel in all contexts.
# For example, `RUNFILES=/path/to/my_js_binary.sh.runfiles`.
#
# Call this program X. X was generated by a genrule and may be invoked
# in many ways:
#   1a) directly by a user, with $0 in the output tree
#   1b) via 'bazel run' (similar to case 1a)
#   2) directly by a user, with $0 in X's runfiles
#   3) by another program Y which has a data dependency on X, with $0 in Y's
#      runfiles
#   4a) via 'bazel test'
#   4b) case 3 in the context of a test
#   5a) by a genrule cmd, with $0 in the output tree
#   6a) case 3 in the context of a genrule
#
# For case 1, $0 will be a regular file, and the runfiles will be
# at $0.runfiles.
# For case 2 or 3, $0 will be a symlink to the file seen in case 1.
# For case 4, $TEST_SRCDIR should already be set to the runfiles by
# blaze.
# Case 5a is handled like case 1.
# Case 6a is handled like case 3.
if [ "${TEST_SRCDIR:-}" ]; then
    # Case 4, bazel has identified runfiles for us.
    RUNFILES=$(_normalize_path "$TEST_SRCDIR")
elif [ "${RUNFILES_MANIFEST_FILE:-}" ]; then
    RUNFILES=$(_normalize_path "$RUNFILES_MANIFEST_FILE")
    if [[ "${RUNFILES}" == *.runfiles_manifest ]]; then
        # Newer versions of Bazel put the manifest besides the runfiles with the suffix .runfiles_manifest.
        # For example, the runfiles directory is named my_binary.runfiles then the manifest is beside the
        # runfiles directory and named my_binary.runfiles_manifest
        RUNFILES=${RUNFILES%_manifest}
    elif [[ "${RUNFILES}" == */MANIFEST ]]; then
        # Older versions of Bazel put the manifest file named MANIFEST in the runfiles directory
        RUNFILES=${RUNFILES%/MANIFEST}
    else
        logf_fatal "Unexpected RUNFILES_MANIFEST_FILE value $RUNFILES_MANIFEST_FILE"
        exit 1
    fi
else
    case "$0" in
    /*) self="$0" ;;
    *) self="$PWD/$0" ;;
    esac
    while true; do
        if [ -e "$self.runfiles" ]; then
            RUNFILES="$self.runfiles"
            break
        fi

        if [[ "$self" == *.runfiles/* ]]; then
            RUNFILES="${self%%.runfiles/*}.runfiles"
            # don't break; this is a last resort for case 6b
        fi

        if [ ! -L "$self" ]; then
            break;
        fi

        readlink="$(readlink "$self")"
        if [[ "$readlink" == /* ]]; then
            self="$readlink"
        else
            # resolve relative symlink
            self="${self%%/*}/$readlink"
        fi
    done

    if [ -z "${RUNFILES:-}" ]; then
        logf_fatal "RUNFILES environment variable is not set"
        exit 1
    fi

    RUNFILES=$(_normalize_path "$RUNFILES")
fi
if [ "${RUNFILES:0:1}" != "/" ]; then
    # Ensure RUNFILES set above is an absolute path. It may be a path relative
    # to the PWD in case where RUNFILES_MANIFEST_FILE is used above.
    RUNFILES="$PWD/$RUNFILES"
fi
j��
# It helps to determine if we are running on a Windows environment (excludes WSL as it acts like Unix)
case "$(uname -s)" in
    CYGWIN*)    _IS_WINDOWS=1 ;;
    MINGW*)     _IS_WINDOWS=1 ;;
    MSYS_NT*)   _IS_WINDOWS=1 ;;
    *)          _IS_WINDOWS=0 ;;
esac

# It helps to normalizes paths when running on Windows.
#
# Example:
# C:/Users/XUser/_bazel_XUser/7q7kkv32/execroot/A/b/C -> /c/Users/XUser/_bazel_XUser/7q7kkv32/execroot/A/b/C
function _normalize_path {
    if [ "$_IS_WINDOWS" -eq "1" ]; then
        # Apply the followings paths transformations to normalize paths on Windows
        # -process driver letter
        # -convert path separator
        sed -e 's#^\(.\):#/\L\1#' -e 's#\\#/#g' <<< "$1"
    else
        echo "$1"
    fi
    return
}

# Set a RUNFILES environment variable to the root of the runfiles tree
# since RUNFILES_DIR is not set by Bazel in all contexts.
# For example, `RUNFILES=/path/to/my_js_binary.sh.runfiles`.
#
# Call this program X. X was generated by a genrule and may be invoked
# in many ways:
#   1a) directly by a user, with $0 in the output tree
#   1b) via 'bazel run' (similar to case 1a)
#   2) directly by a user, with $0 in X's runfiles
#   3) by another program Y which has a data dependency on X, with $0 in Y's
#      runfiles
#   4a) via 'bazel test'
#   4b) case 3 in the context of a test
#   5a) by a genrule cmd, with $0 in the output tree
#   6a) case 3 in the context of a genrule
#
# For case 1, $0 will be a regular file, and the runfiles will be
# at $0.runfiles.
# For case 2 or 3, $0 will be a symlink to the file seen in case 1.
# For case 4, $TEST_SRCDIR should already be set to the runfiles by
# blaze.
# Case 5a is handled like case 1.
# Case 6a is handled like case 3.
if [ "${TEST_SRCDIR:-}" ]; then
    # Case 4, bazel has identified runfiles for us.
    RUNFILES=$(_normalize_path "$TEST_SRCDIR")
elif [ "${RUNFILES_MANIFEST_FILE:-}" ]; then
    RUNFILES=$(_normalize_path "$RUNFILES_MANIFEST_FILE")
    if [[ "${RUNFILES}" == *.runfiles_manifest ]]; then
        # Newer versions of Bazel put the manifest besides the runfiles with the suffix .runfiles_manifest.
        # For example, the runfiles directory is named my_binary.runfiles then the manifest is beside the
        # runfiles directory and named my_binary.runfiles_manifest
        RUNFILES=${RUNFILES%_manifest}
    elif [[ "${RUNFILES}" == */MANIFEST ]]; then
        # Older versions of Bazel put the manifest file named MANIFEST in the runfiles directory
        RUNFILES=${RUNFILES%/MANIFEST}
    else
        logf_fatal "Unexpected RUNFILES_MANIFEST_FILE value $RUNFILES_MANIFEST_FILE"
        exit 1
    fi
else
    case "$0" in
    /*) self="$0" ;;
    *) self="$PWD/$0" ;;
    esac
    while true; do
        if [ -e "$self.runfiles" ]; then
            RUNFILES="$self.runfiles"
            break
        fi

        if [[ "$self" == *.runfiles/* ]]; then
            RUNFILES="${self%%.runfiles/*}.runfiles"
            # don't break; this is a last resort for case 6b
        fi

        if [ ! -L "$self" ]; then
            break;
        fi

        readlink="$(readlink "$self")"
        if [[ "$readlink" == /* ]]; then
            self="$readlink"
        else
            # resolve relative symlink
            self="${self%%/*}/$readlink"
        fi
    done

    if [ -z "${RUNFILES:-}" ]; then
        logf_fatal "RUNFILES environment variable is not set"
        exit 1
    fi

    RUNFILES=$(_normalize_path "$RUNFILES")
fi
if [ "${RUNFILES:0:1}" != "/" ]; then
    # Ensure RUNFILES set above is an absolute path. It may be a path relative
    # to the PWD in case where RUNFILES_MANIFEST_FILE is used above.
    RUNFILES="$PWD/$RUNFILES"
fi
Bash snippets for js rules�*
2
aspect_rules_js
js/privateexpand_template.bzl�&expand_template�Template expansion with stamp var support.

This performs a simple search over the template file for the keys in substitutions,
and replaces them with the corresponding values.

Values may also use location templates as documented in
[expand_locations](https://github.com/aspect-build/bazel-lib/blob/main/docs/expand_make_vars.md#expand_locations)
as well as [configuration variables](https://docs.bazel.build/versions/main/skylark/lib/ctx.html#var)
such as `$(BINDIR)`, `$(TARGET_CPU)`, and `$(COMPILATION_MODE)` as documented in
[expand_variables](https://github.com/aspect-build/bazel-lib/blob/main/docs/expand_make_vars.md#expand_variables).

If stamp attribute is True, stamp variable substitutions are supported with {{STAMP_VAR}} tokens.
"� 
�
expand_template�Template expansion with stamp var support.

This performs a simple search over the template file for the keys in substitutions,
and replaces them with the corresponding values.

Values may also use location templates as documented in
[expand_locations](https://github.com/aspect-build/bazel-lib/blob/main/docs/expand_make_vars.md#expand_locations)
as well as [configuration variables](https://docs.bazel.build/versions/main/skylark/lib/ctx.html#var)
such as `$(BINDIR)`, `$(TARGET_CPU)`, and `$(COMPILATION_MODE)` as documented in
[expand_variables](https://github.com/aspect-build/bazel-lib/blob/main/docs/expand_make_vars.md#expand_variables).

If stamp attribute is True, stamp variable substitutions are supported with {{STAMP_VAR}} tokens.
*
nameA unique name for this target. @
data2List of targets for additional lookup information.2[]H
is_executable.Whether to mark the output file as executable.2False,
out!Where to write the expanded file. �
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.
2-1�
stamp_substitutions�Mapping of strings to substitutions.

There are overlayed on top of substitutions when stamping is enabled
for the target.

Subtitutions can contain $(execpath :target) and $(rootpath :target)
expansions, $(MAKEVAR) expansions and {{STAMP_VAR}} expansions when
stamping is enabled for the target.

2{}�
substitutions�Mapping of strings to substitutions.

Subtitutions can contain $(execpath :target) and $(rootpath :target)
expansions, $(MAKEVAR) expansions and {{STAMP_VAR}} expansions when
stamping is enabled for the target.

2{},
templateThe template file to expand. "D
expand_template1@@aspect_rules_js//js/private:expand_template.bzl
ss,
*
nameA unique name for this target. B
@
data2List of targets for additional lookup information.2[]J
H
is_executable.Whether to mark the output file as executable.2False.
,
out!Where to write the expanded file. �
�
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.
2-1�
�
stamp_substitutions�Mapping of strings to substitutions.

There are overlayed on top of substitutions when stamping is enabled
for the target.

Subtitutions can contain $(execpath :target) and $(rootpath :target)
expansions, $(MAKEVAR) expansions and {{STAMP_VAR}} expansions when
stamping is enabled for the target.

2{}�
�
substitutions�Mapping of strings to substitutions.

Subtitutions can contain $(execpath :target) and $(rootpath :target)
expansions, $(MAKEVAR) expansions and {{STAMP_VAR}} expansions when
stamping is enabled for the target.

2{}.
,
templateThe template file to expand. �
//lib:expand_make_vars.bzlr�
-
aspect_bazel_liblibexpand_make_vars.bzl3
expand_locations_expand_locations
5F3
expand_variables_expand_variables
]n
��
//lib:stamping.bzlr�
%
aspect_bazel_liblibstamping.bzl(
STAMP_ATTRSSTAMP_ATTRS
.9(
maybe_stampmaybe_stamp
=H
Ja
//lib:dicts.bzlrL

bazel_skyliblib	dicts.bzl
dictsdicts
',
.expand_template rule��
,
aspect_rules_js
js/privatejs_binary.bzl�r	js_binary�Execute a program in the node.js runtime.

The version of node is determined by Bazel's toolchain selection. In the WORKSPACE you used
`nodejs_register_toolchains` to provide options to Bazel. Then Bazel selects from these options
based on the requested target platform. Use the
[`--toolchain_resolution_debug`](https://docs.bazel.build/versions/main/command-line-reference.html#flag--toolchain_resolution_debug)
Bazel option to see more detail about the selection.

This rules requires that Bazel was run with
[`--enable_runfiles`](https://docs.bazel.build/versions/main/command-line-reference.html#flag--enable_runfiles). 
"�m
�9
	js_binary�Execute a program in the node.js runtime.

The version of node is determined by Bazel's toolchain selection. In the WORKSPACE you used
`nodejs_register_toolchains` to provide options to Bazel. Then Bazel selects from these options
based on the requested target platform. Use the
[`--toolchain_resolution_debug`](https://docs.bazel.build/versions/main/command-line-reference.html#flag--toolchain_resolution_debug)
Bazel option to see more detail about the selection.

This rules requires that Bazel was run with
[`--enable_runfiles`](https://docs.bazel.build/versions/main/command-line-reference.html#flag--enable_runfiles). 
*
nameA unique name for this target. �
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/")) + "$(rootpath //path/to/some:file)"],
)
```2""�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

You can use the `@bazel/runfiles` npm library to access these files
at runtime.

npm packages are also linked into the `.runfiles/node_modules` folder
so they may be resolved directly from runfiles.
2[]�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/aspect-build/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 h
env[Environment variables of the action.

Subject to `$(location)` and make variable expansion.
2{}i
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�
include_declarations�When True, `declarations` and `transitive_declarations` from `JsInfo` providers in data targets are included in the runfiles of the target.

Defaults to false since declarations are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
include_npm_linked_packages�When True, files in `npm_linked_packages` and `transitive_npm_linked_packages` from `JsInfo` providers in data targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in data targets are also included in the runfiles of the target.
2True�
include_transitive_sourcessWhen True, `transitive_sources` from `JsInfo` providers in data targets are included in the runfiles of the target.2True�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.2"error"�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2True"8
	js_binary+@@aspect_rules_js//js/private:js_binary.bzl
��,
*
nameA unique name for this target. �
�
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/")) + "$(rootpath //path/to/some:file)"],
)
```2""�
�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

You can use the `@bazel/runfiles` npm library to access these files
at runtime.

npm packages are also linked into the `.runfiles/node_modules` folder
so they may be resolved directly from runfiles.
2[]�
�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
�
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/aspect-build/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 j
h
env[Environment variables of the action.

Subject to `$(location)` and make variable expansion.
2{}k
i
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�
�
include_declarations�When True, `declarations` and `transitive_declarations` from `JsInfo` providers in data targets are included in the runfiles of the target.

Defaults to false since declarations are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
�
include_npm_linked_packages�When True, files in `npm_linked_packages` and `transitive_npm_linked_packages` from `JsInfo` providers in data targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in data targets are also included in the runfiles of the target.
2True�
�
include_transitive_sourcessWhen True, `transitive_sources` from `JsInfo` providers in data targets are included in the runfiles of the target.2True�
�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.2"error"�
�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2True�ujs_test�Identical to js_binary, but usable under `bazel test`.

Bazel will set environment variables when a test target is run under `bazel test` and `bazel run`
that a test runner can use.

A runner can write arbitrary outputs files it wants Bazel to pickup and save with the test logs to
`TEST_UNDECLARED_OUTPUTS_DIR`. These get zipped up and saved along with the test logs.

JUnit XML reports can be written to `XML_OUTPUT_FILE` for Bazel to consume.

`TEST_TMPDIR` is an absolute path to a private writeable directory that the test runner can use for
creating temporary files.

LCOV coverage reports can be written to `COVERAGE_OUTPUT_FILE` when running under `bazel coverage`
or if the `--coverage` flag is set.

See the Bazel [Test encyclopedia](https://bazel.build/reference/test-encyclopedia) for details on
the contract between Bazel and a test runner."�o
�:
js_test�Identical to js_binary, but usable under `bazel test`.

Bazel will set environment variables when a test target is run under `bazel test` and `bazel run`
that a test runner can use.

A runner can write arbitrary outputs files it wants Bazel to pickup and save with the test logs to
`TEST_UNDECLARED_OUTPUTS_DIR`. These get zipped up and saved along with the test logs.

JUnit XML reports can be written to `XML_OUTPUT_FILE` for Bazel to consume.

`TEST_TMPDIR` is an absolute path to a private writeable directory that the test runner can use for
creating temporary files.

LCOV coverage reports can be written to `COVERAGE_OUTPUT_FILE` when running under `bazel coverage`
or if the `--coverage` flag is set.

See the Bazel [Test encyclopedia](https://bazel.build/reference/test-encyclopedia) for details on
the contract between Bazel and a test runner.*
nameA unique name for this target. �
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/")) + "$(rootpath //path/to/some:file)"],
)
```2""�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

You can use the `@bazel/runfiles` npm library to access these files
at runtime.

npm packages are also linked into the `.runfiles/node_modules` folder
so they may be resolved directly from runfiles.
2[]�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/aspect-build/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 h
env[Environment variables of the action.

Subject to `$(location)` and make variable expansion.
2{}i
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�
include_declarations�When True, `declarations` and `transitive_declarations` from `JsInfo` providers in data targets are included in the runfiles of the target.

Defaults to false since declarations are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
include_npm_linked_packages�When True, files in `npm_linked_packages` and `transitive_npm_linked_packages` from `JsInfo` providers in data targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in data targets are also included in the runfiles of the target.
2True�
include_transitive_sourcessWhen True, `transitive_sources` from `JsInfo` providers in data targets are included in the runfiles of the target.2True�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.2"error"�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2True"6
js_test+@@aspect_rules_js//js/private:js_binary.bzl
��,
*
nameA unique name for this target. �
�
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/")) + "$(rootpath //path/to/some:file)"],
)
```2""�
�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

You can use the `@bazel/runfiles` npm library to access these files
at runtime.

npm packages are also linked into the `.runfiles/node_modules` folder
so they may be resolved directly from runfiles.
2[]�
�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
�
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/aspect-build/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 j
h
env[Environment variables of the action.

Subject to `$(location)` and make variable expansion.
2{}k
i
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�
�
include_declarations�When True, `declarations` and `transitive_declarations` from `JsInfo` providers in data targets are included in the runfiles of the target.

Defaults to false since declarations are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
�
include_npm_linked_packages�When True, files in `npm_linked_packages` and `transitive_npm_linked_packages` from `JsInfo` providers in data targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in data targets are also included in the runfiles of the target.
2True�
�
include_transitive_sourcessWhen True, `transitive_sources` from `JsInfo` providers in data targets are included in the runfiles of the target.2True�
�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.2"error"�
�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2True�
//lib:copy_to_bin.bzlr�
(
aspect_bazel_liblibcopy_to_bin.bzl@
copy_file_to_bin_actioncopy_file_to_bin_action
1HD
copy_files_to_bin_actionscopy_files_to_bin_actions
Le
g�
//lib:directory_path.bzlrq
+
aspect_bazel_liblibdirectory_path.bzl4
DirectoryPathInfoDirectoryPathInfo
4E
G�
//lib:expand_make_vars.bzlr�
-
aspect_bazel_liblibexpand_make_vars.bzl2
expand_locationsexpand_locations
6F2
expand_variablesexpand_variables
JZ
\�
//lib:windows_utils.bzlr�
*
aspect_bazel_liblibwindows_utils.bzl\
%create_windows_native_launcher_script%create_windows_native_launcher_script
3X
Z�
//js/private:bash.bzlr{
'
aspect_rules_js
js/privatebash.bzlB
BASH_INITIALIZE_RUNFILESBASH_INITIALIZE_RUNFILES
0H
J�
"//js/private:js_binary_helpers.bzlr�
4
aspect_rules_js
js/privatejs_binary_helpers.bzl&

LOG_LEVELS
LOG_LEVELS
=G6
envs_for_log_levelenvs_for_log_level
K]N
gather_files_from_js_providersgather_files_from_js_providers
a
�a
//lib:dicts.bzlrL

bazel_skyliblib	dicts.bzl
dictsdicts
',
.�Rules for running JavaScript programs under Bazel, as tools or with `bazel run` or `bazel test`.

For example, this binary references the `acorn` npm package which was already linked
using an API like `npm_link_all_packages`.

```starlark
load("@aspect_rules_js//js:defs.bzl", "js_binary", "js_test")

js_binary(
    name = "bin",
    # Reference the location where the acorn npm module was linked in the root Bazel package
    data = ["//:node_modules/acorn"],
    entry_point = "require_acorn.js",
)
```
�

4
aspect_rules_js
js/privatejs_binary_helpers.bzl�envs_for_log_levelAReturns a list environment variables to set for a given log level*�
�
envs_for_log_level+
	log_levelThe log level string value (AReturns a list environment variables to set for a given log level"�
�A list of environment variables to set to turn on the js_binary runtime
logs for the given log level. Typically, they are each set to "1".2I
envs_for_log_level3@@aspect_rules_js//js/private:js_binary_helpers.bzl
�gather_files_from_js_providers<Gathers files from JsInfo and NpmPackageStoreInfo providers.*�
�
gather_files_from_js_providers,
targetslist of target to gather from (@
include_transitive_sourcessee js_filegroup documentation (:
include_declarationssee js_filegroup documentation (A
include_npm_linked_packagessee js_filegroup documentation (<Gathers files from JsInfo and NpmPackageStoreInfo providers."
A depset of files2U
gather_files_from_js_providers3@@aspect_rules_js//js/private:js_binary_helpers.bzl
**x
//js/private:js_info.bzlrZ
*
aspect_rules_js
js/privatejs_info.bzl
JsInfoJsInfo
39
;�
//npm:providers.bzlro
%
aspect_rules_jsnpmproviders.bzl8
NpmPackageStoreInfoNpmPackageStoreInfo
.A
C`js_binary` helper functions.
�
/
aspect_rules_js
js/privatejs_filegroup.bzl�js_filegroup�Gathers files from the JsInfo providers from targets in srcs and provides them as default outputs.

This helper rule is used by the `js_run_binary` macro.
"�
�	
js_filegroup�Gathers files from the JsInfo providers from targets in srcs and provides them as default outputs.

This helper rule is used by the `js_run_binary` macro.
*
nameA unique name for this target. �
include_declarations�When True, `declarations` and `transitive_declarations` from `JsInfo` providers in srcs targets are included in the default outputs of the target.

Defaults to false since declarations are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
include_npm_linked_packages�When True, files in `npm_linked_packages` and `transitive_npm_linked_packages` from `JsInfo` providers in srcs targets are included in the default outputs of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in data targets are also included in the default outputs of the target.
2True�
include_transitive_sources|When True, `transitive_sources` from `JsInfo` providers in `srcs` targets are included in the default outputs of the target.2True3
srcs%List of targets to gather files from.2[]">
js_filegroup.@@aspect_rules_js//js/private:js_filegroup.bzl
,
*
nameA unique name for this target. �
�
include_declarations�When True, `declarations` and `transitive_declarations` from `JsInfo` providers in srcs targets are included in the default outputs of the target.

Defaults to false since declarations are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
�
include_npm_linked_packages�When True, files in `npm_linked_packages` and `transitive_npm_linked_packages` from `JsInfo` providers in srcs targets are included in the default outputs of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in data targets are also included in the default outputs of the target.
2True�
�
include_transitive_sources|When True, `transitive_sources` from `JsInfo` providers in `srcs` targets are included in the default outputs of the target.2True5
3
srcs%List of targets to gather files from.2[]�
"//js/private:js_binary_helpers.bzlr�
4
aspect_rules_js
js/privatejs_binary_helpers.bzlO
gather_files_from_js_providers_gather_files_from_js_providers
<[
`Helper rule to gather files from JsInfo providers of targets and provide them as default outputs�
*
aspect_rules_js
js/privatejs_info.bzl�js_infoConstruct a JsInfo.*�
�
js_info6
declarationsSee JsInfo documentation
depset([])(B
npm_linked_package_filesSee JsInfo documentation
depset([])(=
npm_linked_packagesSee JsInfo documentation
depset([])(@
npm_package_store_depsSee JsInfo documentation
depset([])(1
sourcesSee JsInfo documentation
depset([])(A
transitive_declarationsSee JsInfo documentation
depset([])(M
#transitive_npm_linked_package_filesSee JsInfo documentation
depset([])(H
transitive_npm_linked_packagesSee JsInfo documentation
depset([])(<
transitive_sourcesSee JsInfo documentation
depset([])(Construct a JsInfo."
A JsInfo provider24
js_info)@@aspect_rules_js//js/private:js_info.bzl
�JsInfoOEncapsulates information provided by rules in rules_js and derivative rule sets2�
�	
JsInfoOEncapsulates information provided by rules in rules_js and derivative rule setsD
declarations4A depset of declaration files produced by the target_
npm_linked_package_filesCA depset of files in npm linked package dependencies of this targetf
npm_linked_packagesOA depset of NpmLinkedPackageInfo providers that are dependencies of this target�
npm_package_store_deps�A depset of NpmPackageStoreInfo providers from npm dependencies of this target and the target's transitive dependencies to use as direct dependencies when linking downstream npm_package targets with npm_link_package:
sources/A depset of source files produced by the targetp
transitive_declarationsUA depset of declaration files produced by the target and the target's transitive deps�
#transitive_npm_linked_package_filesdA depset of files in npm linked package dependencies of this target and the target's transitive deps�
transitive_npm_linked_packagespA depset of NpmLinkedPackageInfo providers that are dependencies of this target and the target's transitive depsf
transitive_sourcesPA depset of source files produced by the target and the target's transitive deps"3
JsInfo)@@aspect_rules_js//js/private:js_info.bzl
F
D
declarations4A depset of declaration files produced by the targeta
_
npm_linked_package_filesCA depset of files in npm linked package dependencies of this targeth
f
npm_linked_packagesOA depset of NpmLinkedPackageInfo providers that are dependencies of this target�
�
npm_package_store_deps�A depset of NpmPackageStoreInfo providers from npm dependencies of this target and the target's transitive dependencies to use as direct dependencies when linking downstream npm_package targets with npm_link_package<
:
sources/A depset of source files produced by the targetr
p
transitive_declarationsUA depset of declaration files produced by the target and the target's transitive deps�
�
#transitive_npm_linked_package_filesdA depset of files in npm linked package dependencies of this target and the target's transitive deps�
�
transitive_npm_linked_packagespA depset of NpmLinkedPackageInfo providers that are dependencies of this target and the target's transitive depsh
f
transitive_sourcesPA depset of source files produced by the target and the target's transitive depsJsInfo providery
-
aspect_rules_js
js/privatejs_library.bzl*HModuleInfo request error: invalid argument: indentation error (+ 9 more)�
5
aspect_rules_js
js/privatejs_library_helpers.bzl�gather_npm_linked_packages@Gathers npm linked packages from a list of srcs and deps targets*�
�
gather_npm_linked_packagesc
srcsWsource targets; these typically come from the `srcs` and/or `data` attributes of a rule (Q
depsEdep targets; these typically come from the `deps` attribute of a rule (@Gathers npm linked packages from a list of srcs and deps targets"�
�A `struct(direct, direct_files, transitive, transitive_files)` of direct and transitive npm linked packages & underlying files gathered2R
gather_npm_linked_packages4@@aspect_rules_js//js/private:js_library_helpers.bzl
@@�gather_npm_package_store_deps>Gathers NpmPackageStoreInfo providers from the list of targets*�
�
gather_npm_package_store_deps1
targets"the list of targets to gather from (>Gathers NpmPackageStoreInfo providers from the list of targets")
'A depset of npm package stores gathered2U
gather_npm_package_store_deps4@@aspect_rules_js//js/private:js_library_helpers.bzl
nn�gather_runfiles*Gathers runfiles from the list of targets.*�
�
gather_runfiles
ctxthe rule context (M
sources>list or depset of sources which should be included in runfiles (g
data[list of data targets; default outputs and transitive runfiles are gather from these targets (^
depsRlist of dependency targets; only transitive runfiles are gather from these targets (*Gathers runfiles from the list of targets."

Runfiles2G
gather_runfiles4@@aspect_rules_js//js/private:js_library_helpers.bzl
���gather_transitive_declarationsDGathers transitive sources from a list of direct sources and targets*�
�
gather_transitive_declarationsj
declarationsVlist or depset of direct sources which should be included in `transitive_declarations` (P
targetsAList of targets to gather `transitive_declarations` from `JsInfo` (DGathers transitive sources from a list of direct sources and targets" 
A depset of transitive sources2V
gather_transitive_declarations4@@aspect_rules_js//js/private:js_library_helpers.bzl
--�gather_transitive_sourcesDGathers transitive sources from a list of direct sources and targets*�
�
gather_transitive_sources`
sourcesQlist or depset of direct sources which should be included in `transitive_sources` (K
targets<list of targets to gather `transitive_sources` from `JsInfo` (DGathers transitive sources from a list of direct sources and targets" 
A depset of transitive sources2Q
gather_transitive_sources4@@aspect_rules_js//js/private:js_library_helpers.bzl
�
"//js/private:js_binary_helpers.bzlr�
4
aspect_rules_js
js/privatejs_binary_helpers.bzlN
gather_files_from_js_providersgather_files_from_js_providers
=[
]x
//js/private:js_info.bzlrZ
*
aspect_rules_js
js/privatejs_info.bzl
JsInfoJsInfo
39
;`js_library` helper functions.
|
0
aspect_rules_js
js/privatejs_run_binary.bzl*HModuleInfo request error: invalid argument: indentation error (+ 9 more)�
3
aspect_rules_js
js/privatejs_run_devserver.bzl*IModuleInfo request error: invalid argument: indentation error (+ 81 more)�
(
aspect_rules_js
js/private	maybe.bzl�maybe_http_archive*v
_
maybe_http_archive

kwargs(2=
maybe_http_archive'@@aspect_rules_js//js/private:maybe.bzl
*maybe�
 //tools/build_defs/repo:http.bzlrk
.
bazel_toolstools/build_defs/repohttp.bzl+
http_archive_http_archive
6C
U�
!//tools/build_defs/repo:utils.bzlr]
/
bazel_toolstools/build_defs/repo	utils.bzl
maybemaybe
8=
?maybe utilitiesk

aspect_rules_jsjsdefs.bzl*HModuleInfo request error: invalid argument: indentation error (+ 9 more)�
+
aspect_rules_jsjsdev_repositories.bzl�rules_js_dev_dependencies0Fetch repositories used for developing the rules*�
�
rules_js_dev_dependencies0Fetch repositories used for developing the rules2G
rules_js_dev_dependencies*@@aspect_rules_js//js:dev_repositories.bzl


�
//js/private:maybe.bzlrj
(
aspect_rules_js
js/private	maybe.bzl0
maybe_http_archivehttp_archive
0<
T�Our "development" dependencies

Users should *not* need to install these. If users see a load()
statement from these, that's a bug in our distribution.
�

aspect_rules_jsjslibs.bzl*nModuleInfo request error: invalid argument: Trailing comma is allowed only in parenthesized tuples. (+ 7 more)�
$
aspect_rules_jsjsproviders.bzl�js_infoConstruct a JsInfo.*�
�
js_info6
declarationsSee JsInfo documentation
depset([])(B
npm_linked_package_filesSee JsInfo documentation
depset([])(=
npm_linked_packagesSee JsInfo documentation
depset([])(@
npm_package_store_depsSee JsInfo documentation
depset([])(1
sourcesSee JsInfo documentation
depset([])(A
transitive_declarationsSee JsInfo documentation
depset([])(M
#transitive_npm_linked_package_filesSee JsInfo documentation
depset([])(H
transitive_npm_linked_packagesSee JsInfo documentation
depset([])(<
transitive_sourcesSee JsInfo documentation
depset([])(Construct a JsInfo."
A JsInfo provider24
js_info)@@aspect_rules_js//js/private:js_info.bzl
�JsInfoOEncapsulates information provided by rules in rules_js and derivative rule sets2�
�	
JsInfoOEncapsulates information provided by rules in rules_js and derivative rule setsD
declarations4A depset of declaration files produced by the target_
npm_linked_package_filesCA depset of files in npm linked package dependencies of this targetf
npm_linked_packagesOA depset of NpmLinkedPackageInfo providers that are dependencies of this target�
npm_package_store_deps�A depset of NpmPackageStoreInfo providers from npm dependencies of this target and the target's transitive dependencies to use as direct dependencies when linking downstream npm_package targets with npm_link_package:
sources/A depset of source files produced by the targetp
transitive_declarationsUA depset of declaration files produced by the target and the target's transitive deps�
#transitive_npm_linked_package_filesdA depset of files in npm linked package dependencies of this target and the target's transitive deps�
transitive_npm_linked_packagespA depset of NpmLinkedPackageInfo providers that are dependencies of this target and the target's transitive depsf
transitive_sourcesPA depset of source files produced by the target and the target's transitive deps"-
JsInfo#@@aspect_rules_js//js:providers.bzl
F
D
declarations4A depset of declaration files produced by the targeta
_
npm_linked_package_filesCA depset of files in npm linked package dependencies of this targeth
f
npm_linked_packagesOA depset of NpmLinkedPackageInfo providers that are dependencies of this target�
�
npm_package_store_deps�A depset of NpmPackageStoreInfo providers from npm dependencies of this target and the target's transitive dependencies to use as direct dependencies when linking downstream npm_package targets with npm_link_package<
:
sources/A depset of source files produced by the targetr
p
transitive_declarationsUA depset of declaration files produced by the target and the target's transitive deps�
�
#transitive_npm_linked_package_filesdA depset of files in npm linked package dependencies of this target and the target's transitive deps�
�
transitive_npm_linked_packagespA depset of NpmLinkedPackageInfo providers that are dependencies of this target and the target's transitive depsh
f
transitive_sourcesPA depset of source files produced by the target and the target's transitive deps�
//js/private:js_info.bzlr~
*
aspect_rules_js
js/privatejs_info.bzl
JsInfo_JsInfo
!
js_info_js_info

'Providers for building derivative rules�
'
aspect_rules_jsjsrepositories.bzl*_ModuleInfo request error: invalid argument: syntax error at 'a7bd': expected newline (+ 4 more)�
=
aspect_rules_jsnpm/private/testpackage_json_checked.bzl�bin_factory*�
p
bin_factory
link_root_name (2K
bin_factory<@@aspect_rules_js//npm/private/test:package_json_checked.bzl
CC�rollup*�
h
rollup

name (

kwargs(2F
rollup<@@aspect_rules_js//npm/private/test:package_json_checked.bzl
::*_rollup_internal�rollup_binary*�
v
rollup_binary

name (

kwargs(2M
rollup_binary<@@aspect_rules_js//npm/private/test:package_json_checked.bzl
@@*_rollup_binary_internal�rollup_test*�
r
rollup_test

name (

kwargs(2K
rollup_test<@@aspect_rules_js//npm/private/test:package_json_checked.bzl
==*_rollup_test_internal�
//lib:directory_path.bzlrl
+
aspect_bazel_liblibdirectory_path.bzl/
directory_path_directory_path
3B
V�
//js:defs.bzlr�

aspect_rules_jsjsdefs.bzl%
	js_binary
_js_binary
'1-
js_run_binary_js_run_binary
AO!
js_test_js_test
ck
xX@generated by @aspect_rules_js//npm/private:npm_import.bzl for npm package rollup@2.70.2�
I
aspect_rules_jsnpm/private/test$package_json_with_dashes_checked.bzl�bin_factory*�
|
bin_factory
link_root_name (2W
bin_factoryH@@aspect_rules_js//npm/private/test:package_json_with_dashes_checked.bzl
CC�webpack_bundle_analyzer*�
�
webpack_bundle_analyzer

name (

kwargs(2c
webpack_bundle_analyzerH@@aspect_rules_js//npm/private/test:package_json_with_dashes_checked.bzl
::*!_webpack_bundle_analyzer_internal�webpack_bundle_analyzer_binary*�
�
webpack_bundle_analyzer_binary

name (

kwargs(2j
webpack_bundle_analyzer_binaryH@@aspect_rules_js//npm/private/test:package_json_with_dashes_checked.bzl
@@*(_webpack_bundle_analyzer_binary_internal�webpack_bundle_analyzer_test*�
�
webpack_bundle_analyzer_test

name (

kwargs(2h
webpack_bundle_analyzer_testH@@aspect_rules_js//npm/private/test:package_json_with_dashes_checked.bzl
==*&_webpack_bundle_analyzer_test_internal�
//lib:directory_path.bzlrl
+
aspect_bazel_liblibdirectory_path.bzl/
directory_path_directory_path
3B
V�
//js:defs.bzlr�

aspect_rules_jsjsdefs.bzl%
	js_binary
_js_binary
'1-
js_run_binary_js_run_binary
AO!
js_test_js_test
ck
xy@generated by @aspect_rules_js//npm/private:npm_import.bzl for npm package webpack-bundle-analyzer@4.5.0_bufferutil@4.0.1�
=
aspect_rules_jsnpm/private/testrepositories_checked.bzl�npm_repositoriesXGenerated npm_import repository rules corresponding to npm packages in //:pnpm-lock.yaml*�
�
npm_repositoriesXGenerated npm_import repository rules corresponding to npm packages in //:pnpm-lock.yaml2P
npm_repositories<@@aspect_rules_js//npm/private/test:repositories_checked.bzl
x
//npm:npm_import.bzlr^
&
aspect_rules_jsnpmnpm_import.bzl&

npm_import
npm_import
/9
;Y@generated by @aspect_rules_js//npm/private:npm_translate_lock.bzl from //:pnpm-lock.yaml�

.
aspect_rules_jsnpm/privatenpm_import.bzl�
//lib:repo_utils.bzlr}
'
aspect_bazel_liblibrepo_utils.bzl
patchpatch
05&

repo_utils
repo_utils
9C
E�
//lib:utils.bzlrp
"
aspect_bazel_liblib	utils.bzl<
is_bazel_6_or_greateris_bazel_6_or_greater
+@
B�
$//npm/private:npm_translate_lock.bzlrz
6
aspect_rules_jsnpm/privatenpm_translate_lock.bzl2
DEFAULT_REGISTRYDEFAULT_REGISTRY
?O
Q�
(//npm/private:starlark_codegen_utils.bzlr�
:
aspect_rules_jsnpm/privatestarlark_codegen_utils.bzl>
starlark_codegen_utilsstarlark_codegen_utils
CY
[t
//npm/private:utils.bzlrW
)
aspect_rules_jsnpm/private	utils.bzl
utilsutils
27
9a
//lib:dicts.bzlrL

bazel_skyliblib	dicts.bzl
dictsdicts
',
.a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
	'	,
		.�
&//tools/build_defs/repo:git_worker.bzlr�
4
bazel_toolstools/build_defs/repogit_worker.bzl+

add_origin_git_add_origin
!
clean
_git_clean
!
fetch
_git_fetch

init	_git_init
!
reset
_git_reset


0Repository rules for importing packages from npm�Q
4
aspect_rules_jsnpm/privatenpm_link_package.bzl�Mnpm_link_package�"Links an npm package to node_modules if link is True.

When called at the root_package, a virtual store target is generated named "link__{bazelified_name}__store".

When linking, a "{name}" target is generated which consists of the node_modules/<package> symlink and transitively
its virtual store link and the virtual store links of the transitive closure of deps.

When linking, "{name}/dir" filegroup is also generated that refers to a directory artifact can be used to access
the package directory for creating entry points or accessing files in the package.


Defines a npm package that is linked into a node_modules tree.

The npm package is linked with a pnpm style symlinked node_modules output tree.

The term "package" is defined at
<https://nodejs.org/docs/latest-v16.x/api/packages.html>

See https://pnpm.io/symlinked-node-modules-structure for more information on
the symlinked node_modules structure.
Npm may also support a symlinked node_modules structure called
"Isolated mode" in the future:
https://github.com/npm/rfcs/blob/main/accepted/0042-isolated-mode.md.
"�D
�&
npm_link_package�"Links an npm package to node_modules if link is True.

When called at the root_package, a virtual store target is generated named "link__{bazelified_name}__store".

When linking, a "{name}" target is generated which consists of the node_modules/<package> symlink and transitively
its virtual store link and the virtual store links of the transitive closure of deps.

When linking, "{name}/dir" filegroup is also generated that refers to a directory artifact can be used to access
the package directory for creating entry points or accessing files in the package.


Defines a npm package that is linked into a node_modules tree.

The npm package is linked with a pnpm style symlinked node_modules output tree.

The term "package" is defined at
<https://nodejs.org/docs/latest-v16.x/api/packages.html>

See https://pnpm.io/symlinked-node-modules-structure for more information on
the symlinked node_modules structure.
Npm may also support a symlinked node_modules structure called
"Isolated mode" in the future:
https://github.com/npm/rfcs/blob/main/accepted/0042-isolated-mode.md.
*
nameA unique name for this target. �
deps�Other node packages store link targets one depends on mapped to the name to link them under in this packages deps.

This should include *all* modules the program may need at runtime.

You can find all the package store link targets in your repository with

```
bazel query ... | grep :.aspect_rules_js | grep -v /dir | grep -v /pkg | grep -v /ref
```

Package store link targets names for 3rd party packages that come from `npm_translate_lock`
start with `.aspect_rules_js/` then the name passed to the `npm_link_all_packages` macro
(typically `node_modules`) followed by `/<package>/<version>` where `package` is the
package name (including @scope segment if any) and `version` is the specific version of
the package that comes from the pnpm-lock.yaml file.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

The version may include peer dep(s),

```
//:.aspect_rules_js/node_modules/debug/4.3.4_supports-color@8.1.1
```

It could be also be a url based version,

```
//:.aspect_rules_js/node_modules/debug/github.com/ngokevin/debug/9742c5f383a6f8046241920156236ade8ec30d53
```

Package store link targets names for 3rd party package that come directly from an
`npm_import` start with `.aspect_rules_js/` then the name passed to the `npm_import`'s `npm_link_imported_package`
macro (typically `node_modules`) followed by `/<package>/<version>` where `package`
matches the `package` attribute in the npm_import of the package and `version` matches the
`version` attribute.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

Package store link targets names for 1st party packages automatically linked by `npm_link_all_packages`
using workspaces will follow the same pattern as 3rd party packages with the version typically defaulting
to "0.0.0".

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg/0.0.0
```

Package store link targets names for 1st party packages manually linked with `npm_link_package`
start with `.aspect_rules_js/` followed by the name passed to the `npm_link_package`.

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg
```

> In typical usage, a node.js program sometimes requires modules which were
> never declared as dependencies.
> This pattern is typically used when the program has conditional behavior
> that is enabled when the module is found (like a plugin) but the program
> also runs without the dependency.
> 
> This is possible because node.js doesn't enforce the dependencies are sound.
> All files under `node_modules` are available to any program.
> In contrast, Bazel makes it possible to make builds hermetic, which means that
> all dependencies of a program must be declared when running in Bazel's sandbox.
	*
NpmPackageStoreInfo2{}�
package�The package name to link to.

If unset, the package name in the NpmPackageInfo src must be set.
If set, takes precendance over the package name in the NpmPackageInfo src.
2""i
srcLA npm_package target or or any other target that provides a NpmPackageInfo.
 *
NpmPackageInfo�
use_declare_symlink�Whether to use ctx.actions.declare_symlink to create symlinks.

In Bazel 5.x these are enabled with the --experimental_allow_unresolved_symlinks flag.

Typical usage of this rule is via a macro which automatically sets this
attribute with `select` based on a `config_setting` rule such as,

```
config_setting(
    name = "experimental_allow_unresolved_symlinks",
    values = {"experimental_allow_unresolved_symlinks": "true"},
    visibility = ["//visibility:public"],
)
```
 �
version�The package version being linked.

If unset, the package version in the NpmPackageInfo src must be set.
If set, takes precendance over the package version in the NpmPackageInfo src.
2""
,
*
nameA unique name for this target. �
�
deps�Other node packages store link targets one depends on mapped to the name to link them under in this packages deps.

This should include *all* modules the program may need at runtime.

You can find all the package store link targets in your repository with

```
bazel query ... | grep :.aspect_rules_js | grep -v /dir | grep -v /pkg | grep -v /ref
```

Package store link targets names for 3rd party packages that come from `npm_translate_lock`
start with `.aspect_rules_js/` then the name passed to the `npm_link_all_packages` macro
(typically `node_modules`) followed by `/<package>/<version>` where `package` is the
package name (including @scope segment if any) and `version` is the specific version of
the package that comes from the pnpm-lock.yaml file.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

The version may include peer dep(s),

```
//:.aspect_rules_js/node_modules/debug/4.3.4_supports-color@8.1.1
```

It could be also be a url based version,

```
//:.aspect_rules_js/node_modules/debug/github.com/ngokevin/debug/9742c5f383a6f8046241920156236ade8ec30d53
```

Package store link targets names for 3rd party package that come directly from an
`npm_import` start with `.aspect_rules_js/` then the name passed to the `npm_import`'s `npm_link_imported_package`
macro (typically `node_modules`) followed by `/<package>/<version>` where `package`
matches the `package` attribute in the npm_import of the package and `version` matches the
`version` attribute.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

Package store link targets names for 1st party packages automatically linked by `npm_link_all_packages`
using workspaces will follow the same pattern as 3rd party packages with the version typically defaulting
to "0.0.0".

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg/0.0.0
```

Package store link targets names for 1st party packages manually linked with `npm_link_package`
start with `.aspect_rules_js/` followed by the name passed to the `npm_link_package`.

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg
```

> In typical usage, a node.js program sometimes requires modules which were
> never declared as dependencies.
> This pattern is typically used when the program has conditional behavior
> that is enabled when the module is found (like a plugin) but the program
> also runs without the dependency.
> 
> This is possible because node.js doesn't enforce the dependencies are sound.
> All files under `node_modules` are available to any program.
> In contrast, Bazel makes it possible to make builds hermetic, which means that
> all dependencies of a program must be declared when running in Bazel's sandbox.
	*
NpmPackageStoreInfo2{}�
�
package�The package name to link to.

If unset, the package name in the NpmPackageInfo src must be set.
If set, takes precendance over the package name in the NpmPackageInfo src.
2""k
i
srcLA npm_package target or or any other target that provides a NpmPackageInfo.
 *
NpmPackageInfo�
�
use_declare_symlink�Whether to use ctx.actions.declare_symlink to create symlinks.

In Bazel 5.x these are enabled with the --experimental_allow_unresolved_symlinks flag.

Typical usage of this rule is via a macro which automatically sets this
attribute with `select` based on a `config_setting` rule such as,

```
config_setting(
    name = "experimental_allow_unresolved_symlinks",
    values = {"experimental_allow_unresolved_symlinks": "true"},
    visibility = ["//visibility:public"],
)
```
 �
�
version�The package version being linked.

If unset, the package version in the NpmPackageInfo src must be set.
If set, takes precendance over the package version in the NpmPackageInfo src.
2""�
(//npm/private:npm_link_package_store.bzlr�
:
aspect_rules_jsnpm/privatenpm_link_package_store.bzl>
npm_link_package_storenpm_link_package_store
CY
[�
#//npm/private:npm_package_store.bzlr{
5
aspect_rules_jsnpm/privatenpm_package_store.bzl4
npm_package_storenpm_package_store
>O
Qt
//npm/private:utils.bzlrW
)
aspect_rules_jsnpm/private	utils.bzl
utilsutils
27
9npm_link_package rule�#
:
aspect_rules_jsnpm/privatenpm_link_package_store.bzl�npm_link_package_store�Links an npm package that is backed by an npm_package_store into a node_modules tree as a direct dependency.

This is used in conjunction with the npm_package_store rule that outputs an npm package into the
node_modules/.aspect_rules_js virtual store in a pnpm style symlinked node_modules structure.

The term "package" is defined at
<https://nodejs.org/docs/latest-v16.x/api/packages.html>

See https://pnpm.io/symlinked-node-modules-structure for more information on
the symlinked node_modules structure.
Npm may also support a symlinked node_modules structure called
"Isolated mode" in the future:
https://github.com/npm/rfcs/blob/main/accepted/0042-isolated-mode.md.
"�
�
npm_link_package_store�Links an npm package that is backed by an npm_package_store into a node_modules tree as a direct dependency.

This is used in conjunction with the npm_package_store rule that outputs an npm package into the
node_modules/.aspect_rules_js virtual store in a pnpm style symlinked node_modules structure.

The term "package" is defined at
<https://nodejs.org/docs/latest-v16.x/api/packages.html>

See https://pnpm.io/symlinked-node-modules-structure for more information on
the symlinked node_modules structure.
Npm may also support a symlinked node_modules structure called
"Isolated mode" in the future:
https://github.com/npm/rfcs/blob/main/accepted/0042-isolated-mode.md.
*
nameA unique name for this target. �
bins�Dictionary of `node_modules/.bin` binary files to create mapped to their node entry points.

This is typically derived from the "bin" attribute in the package.json
file of the npm package being linked.

For example:

```
bins = {
    "foo": "./foo.js",
    "bar": "./bar.js",
}
```

In the future, this field may be automatically populated by npm_translate_lock
from information in the pnpm lock file. That feature is currently blocked on
https://github.com/pnpm/pnpm/issues/5131.

2{}�
package�The package name to link to.

If unset, the package name of the src npm_package_store is used.
If set, takes precendance over the package name in the src npm_package_store.
2""^
src<The npm_package_store target to link as a direct dependency. *
NpmPackageStoreInfo�
use_declare_symlink�Whether unresolved symlinks are enabled in the current build configuration.

These are enabled with the --experimental_allow_unresolved_symlinks flag.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 "S
npm_link_package_store9@@aspect_rules_js//npm/private:npm_link_package_store.bzl
��,
*
nameA unique name for this target. �
�
bins�Dictionary of `node_modules/.bin` binary files to create mapped to their node entry points.

This is typically derived from the "bin" attribute in the package.json
file of the npm package being linked.

For example:

```
bins = {
    "foo": "./foo.js",
    "bar": "./bar.js",
}
```

In the future, this field may be automatically populated by npm_translate_lock
from information in the pnpm lock file. That feature is currently blocked on
https://github.com/pnpm/pnpm/issues/5131.

2{}�
�
package�The package name to link to.

If unset, the package name of the src npm_package_store is used.
If set, takes precendance over the package name in the src npm_package_store.
2""`
^
src<The npm_package_store target to link as a direct dependency. *
NpmPackageStoreInfo�
�
use_declare_symlink�Whether unresolved symlinks are enabled in the current build configuration.

These are enabled with the --experimental_allow_unresolved_symlinks flag.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
//js:providers.bzlrv
$
aspect_rules_jsjsproviders.bzl
JsInfoJsInfo
-3 
js_infojs_info
7>
@�
)//npm/private:npm_linked_package_info.bzlr�
;
aspect_rules_jsnpm/privatenpm_linked_package_info.bzl:
NpmLinkedPackageInfoNpmLinkedPackageInfo
DX
Z�
(//npm/private:npm_package_store_info.bzlr�
:
aspect_rules_jsnpm/privatenpm_package_store_info.bzl8
NpmPackageStoreInfoNpmPackageStoreInfo
CV
Xt
//npm/private:utils.bzlrW
)
aspect_rules_jsnpm/private	utils.bzl
utilsutils
27
9a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.npm_link_package_store rule�

;
aspect_rules_jsnpm/privatenpm_linked_package_info.bzl�	NpmLinkedPackageInfoProvides a linked npm package2�	
�
NpmLinkedPackageInfoProvides a linked npm packageQ
labelHthe label of the npm_link_package_store target the created this providerC
link_package3package that this npm package is directly linked at#
packagename of this npm package&
versionversion of this npm package_

store_infoQthe NpmPackageStoreInfo of the linked npm package store that is backing this link@
files7depset of files that are part of the linked npm packager
transitive_files^depset of the transitive files that are part of the linked npm package and its transitive deps"R
NpmLinkedPackageInfo:@@aspect_rules_js//npm/private:npm_linked_package_info.bzl
  S
Q
labelHthe label of the npm_link_package_store target the created this providerE
C
link_package3package that this npm package is directly linked at%
#
packagename of this npm package(
&
versionversion of this npm packagea
_

store_infoQthe NpmPackageStoreInfo of the linked npm package store that is backing this linkB
@
files7depset of files that are part of the linked npm packaget
r
transitive_files^depset of the transitive files that are part of the linked npm package and its transitive depsNpmLinkedPackageInfo provider�
/
aspect_rules_jsnpm/privatenpm_package.bzl*nModuleInfo request error: invalid argument: Trailing comma is allowed only in parenthesized tuples. (+ 7 more)�
4
aspect_rules_jsnpm/privatenpm_package_info.bzl�NpmPackageInfoNProvides the sources of an npm package along with the package name and version2�
�
NpmPackageInfoNProvides the sources of an npm package along with the package name and version#
packagename of this npm package&
versionversion of this npm packagec
src\the sources of this npm package; either a tarball file, a TreeArtifact or a source directory�
npm_package_store_infos�A depset of NpmPackageStoreInfo providers from npm dependencies of the package and the packages's transitive deps to use as direct dependencies when linking with npm_link_package"E
NpmPackageInfo3@@aspect_rules_js//npm/private:npm_package_info.bzl
%
#
packagename of this npm package(
&
versionversion of this npm packagee
c
src\the sources of this npm package; either a tarball file, a TreeArtifact or a source directory�
�
npm_package_store_infos�A depset of NpmPackageStoreInfo providers from npm dependencies of the package and the packages's transitive deps to use as direct dependencies when linking with npm_link_packageNpmPackageInfo provider�
8
aspect_rules_jsnpm/privatenpm_package_internal.bzl�npm_package_internal"�
�
npm_package_internal*
nameA unique name for this target.  
packageThe package name. J
src?A source directory or output directory to use for this package. #
versionThe package version. "O
npm_package_internal7@@aspect_rules_js//npm/private:npm_package_internal.bzl
((,
*
nameA unique name for this target. "
 
packageThe package name. L
J
src?A source directory or output directory to use for this package. %
#
versionThe package version. �
"//npm/private:npm_package_info.bzlrt
4
aspect_rules_jsnpm/privatenpm_package_info.bzl.
NpmPackageInfoNpmPackageInfo
=K
Mnpm_package_internal rule�
5
aspect_rules_jsnpm/privatenpm_package_store.bzl*�ModuleInfo request error: invalid argument: Traceback (most recent call last):
	File "external/aspect_rules_js/npm/private/npm_package_store.bzl", line 3, column 52, in <toplevel>
		load("@aspect_bazel_lib//lib:copy_directory.bzl", "copy_directory_bin_action")
Error: file '@aspect_bazel_lib//lib:copy_directory.bzl' does not contain symbol 'copy_directory_bin_action' (did you mean 'copy_directory_action'?)�
:
aspect_rules_jsnpm/privatenpm_package_store_info.bzl�NpmPackageStoreInfo�Provides information about an npm package within the package store of a pnpm-style
symlinked node_modules tree.

See https://pnpm.io/symlinked-node-modules-structure for more information about
symlinked node_modules trees.2�

�
NpmPackageStoreInfo�Provides information about an npm package within the package store of a pnpm-style
symlinked node_modules tree.

See https://pnpm.io/symlinked-node-modules-structure for more information about
symlinked node_modules trees.@
root_package0package that this npm package store is linked at#
packagename of this npm package&
versionversion of this npm packageB
ref_deps6dictionary of dependency npm_package_store ref targetsX
package_store_directory=the TreeArtifact of this npm package's package store location9
files0depset of files that are part of the npm package`
transitive_filesLdepset of the files that are part of the npm package and its transitive deps:
dev3whether or not this npm package is a dev dependency"P
NpmPackageStoreInfo9@@aspect_rules_js//npm/private:npm_package_store_info.bzl
B
@
root_package0package that this npm package store is linked at%
#
packagename of this npm package(
&
versionversion of this npm packageD
B
ref_deps6dictionary of dependency npm_package_store ref targetsZ
X
package_store_directory=the TreeArtifact of this npm package's package store location;
9
files0depset of files that are part of the npm packageb
`
transitive_filesLdepset of the files that are part of the npm package and its transitive deps<
:
dev3whether or not this npm package is a dev dependencyNpmPackageStoreInfo provider�K
>
aspect_rules_jsnpm/privatenpm_package_store_internal.bzl�Hnpm_package_store_internal"�H
�$
npm_package_store_internal*
nameA unique name for this target. �
deps�Other node packages store link targets one depends on mapped to the name to link them under in this packages deps.

This should include *all* modules the program may need at runtime.

You can find all the package store link targets in your repository with

```
bazel query ... | grep :.aspect_rules_js | grep -v /dir | grep -v /pkg | grep -v /ref
```

Package store link targets names for 3rd party packages that come from `npm_translate_lock`
start with `.aspect_rules_js/` then the name passed to the `npm_link_all_packages` macro
(typically `node_modules`) followed by `/<package>/<version>` where `package` is the
package name (including @scope segment if any) and `version` is the specific version of
the package that comes from the pnpm-lock.yaml file.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

The version may include peer dep(s),

```
//:.aspect_rules_js/node_modules/debug/4.3.4_supports-color@8.1.1
```

It could be also be a url based version,

```
//:.aspect_rules_js/node_modules/debug/github.com/ngokevin/debug/9742c5f383a6f8046241920156236ade8ec30d53
```

Package store link targets names for 3rd party package that come directly from an
`npm_import` start with `.aspect_rules_js/` then the name passed to the `npm_import`'s `npm_link_imported_package`
macro (typically `node_modules`) followed by `/<package>/<version>` where `package`
matches the `package` attribute in the npm_import of the package and `version` matches the
`version` attribute.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

Package store link targets names for 1st party packages automatically linked by `npm_link_all_packages`
using workspaces will follow the same pattern as 3rd party packages with the version typically defaulting
to "0.0.0".

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg/0.0.0
```

Package store link targets names for 1st party packages manually linked with `npm_link_package`
start with `.aspect_rules_js/` followed by the name passed to the `npm_link_package`.

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg
```

> In typical usage, a node.js program sometimes requires modules which were
> never declared as dependencies.
> This pattern is typically used when the program has conditional behavior
> that is enabled when the module is found (like a plugin) but the program
> also runs without the dependency.
> 
> This is possible because node.js doesn't enforce the dependencies are sound.
> All files under `node_modules` are available to any program.
> In contrast, Bazel makes it possible to make builds hermetic, which means that
> all dependencies of a program must be declared when running in Bazel's sandbox.
	*
NpmPackageStoreInfo
JsInfo2{}<
dev,Whether this npm package is a dev dependency2False�
hardlink�Controls when to use hardlinks to files instead of making copies.

Creating hardlinks is much faster than making copies of files with the caveat that
hardlinks share file permissions with their source.

Since Bazel removes write permissions on files in the output tree after an action completes,
hardlinks to source files is not recommended since write permissions will be inadvertently
removed from sources files.

- "auto": hardlinks are used for generated files already in the output tree
- "off": all files are copied
- "on": hardlinks are used for all files (not recommended)

NB: Hardlinking source files in external repositories as was done under the hood
prior to https://github.com/aspect-build/rules_js/pull/1533 may lead to flaky build
failures as reported in https://github.com/aspect-build/rules_js/issues/1412.
2"auto"n
package_The package name to link to.

Takes precedence over the package name in the NpmPackageInfo src. �
src�A npm_package target or or any other target that provides a NpmPackageInfo.

Can be left unspecified to allow for npm_link_package "reference" targets. `npm_link_package`
targets without a `src` are used internally by `npm_import` to create "reference"
`npm_link_package` targets in order to break circular dependencies between 3rd party npm
dependencies. This pattern is not recommended outside of `npm_import` as it adds
complication. Outside our `npm_import` you should structure you `npm_link_package` targets in
a DAG (without cycles).
2None>
verbose*If true, prints out verbose logs to stdout2Falset
versioneThe package version to link to.

Takes precedence over the package version in the NpmPackageInfo src. "[
npm_package_store_internal=@@aspect_rules_js//npm/private:npm_package_store_internal.bzl
 " ",
*
nameA unique name for this target. �
�
deps�Other node packages store link targets one depends on mapped to the name to link them under in this packages deps.

This should include *all* modules the program may need at runtime.

You can find all the package store link targets in your repository with

```
bazel query ... | grep :.aspect_rules_js | grep -v /dir | grep -v /pkg | grep -v /ref
```

Package store link targets names for 3rd party packages that come from `npm_translate_lock`
start with `.aspect_rules_js/` then the name passed to the `npm_link_all_packages` macro
(typically `node_modules`) followed by `/<package>/<version>` where `package` is the
package name (including @scope segment if any) and `version` is the specific version of
the package that comes from the pnpm-lock.yaml file.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

The version may include peer dep(s),

```
//:.aspect_rules_js/node_modules/debug/4.3.4_supports-color@8.1.1
```

It could be also be a url based version,

```
//:.aspect_rules_js/node_modules/debug/github.com/ngokevin/debug/9742c5f383a6f8046241920156236ade8ec30d53
```

Package store link targets names for 3rd party package that come directly from an
`npm_import` start with `.aspect_rules_js/` then the name passed to the `npm_import`'s `npm_link_imported_package`
macro (typically `node_modules`) followed by `/<package>/<version>` where `package`
matches the `package` attribute in the npm_import of the package and `version` matches the
`version` attribute.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

Package store link targets names for 1st party packages automatically linked by `npm_link_all_packages`
using workspaces will follow the same pattern as 3rd party packages with the version typically defaulting
to "0.0.0".

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg/0.0.0
```

Package store link targets names for 1st party packages manually linked with `npm_link_package`
start with `.aspect_rules_js/` followed by the name passed to the `npm_link_package`.

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg
```

> In typical usage, a node.js program sometimes requires modules which were
> never declared as dependencies.
> This pattern is typically used when the program has conditional behavior
> that is enabled when the module is found (like a plugin) but the program
> also runs without the dependency.
> 
> This is possible because node.js doesn't enforce the dependencies are sound.
> All files under `node_modules` are available to any program.
> In contrast, Bazel makes it possible to make builds hermetic, which means that
> all dependencies of a program must be declared when running in Bazel's sandbox.
	*
NpmPackageStoreInfo
JsInfo2{}>
<
dev,Whether this npm package is a dev dependency2False�
�
hardlink�Controls when to use hardlinks to files instead of making copies.

Creating hardlinks is much faster than making copies of files with the caveat that
hardlinks share file permissions with their source.

Since Bazel removes write permissions on files in the output tree after an action completes,
hardlinks to source files is not recommended since write permissions will be inadvertently
removed from sources files.

- "auto": hardlinks are used for generated files already in the output tree
- "off": all files are copied
- "on": hardlinks are used for all files (not recommended)

NB: Hardlinking source files in external repositories as was done under the hood
prior to https://github.com/aspect-build/rules_js/pull/1533 may lead to flaky build
failures as reported in https://github.com/aspect-build/rules_js/issues/1412.
2"auto"p
n
package_The package name to link to.

Takes precedence over the package name in the NpmPackageInfo src. �
�
src�A npm_package target or or any other target that provides a NpmPackageInfo.

Can be left unspecified to allow for npm_link_package "reference" targets. `npm_link_package`
targets without a `src` are used internally by `npm_import` to create "reference"
`npm_link_package` targets in order to break circular dependencies between 3rd party npm
dependencies. This pattern is not recommended outside of `npm_import` as it adds
complication. Outside our `npm_import` you should structure you `npm_link_package` targets in
a DAG (without cycles).
2None@
>
verbose*If true, prints out verbose logs to stdout2Falsev
t
versioneThe package version to link to.

Takes precedence over the package version in the NpmPackageInfo src. �
#//npm/private:npm_package_store.bzlr�
5
aspect_rules_jsnpm/privatenpm_package_store.bzl=
npm_package_store_lib_npm_package_store_lib
=S
na
//lib:dicts.bzlrL

bazel_skyliblib	dicts.bzl
dictsdicts
',
.npm_package_store_internal rule�
6
aspect_rules_jsnpm/privatenpm_translate_lock.bzl*�ModuleInfo request error: invalid argument: Traceback (most recent call last):
	File "external/aspect_rules_js/npm/private/npm_translate_lock.bzl", line 54, column 68, in <toplevel>
		"external_repository_action_cache": attr.string(default = utils.default_external_repository_action_cache()),
Error: 'struct' value has no field or method 'default_external_repository_action_cache'
Available attributes: assert_lockfile_version, bazel_name, friendly_name, is_git_repository_url, links_repo_suffix, make_symlink, npm_registry_download_url, npm_registry_url, package_directory_output_group, parse_package_name, parse_pnpm_lock, parse_pnpm_name, pnpm_name, strip_peer_dep_version, virtual_store_name, virtual_store_root�

)
aspect_rules_jsnpm/private	npmrc.bzl�
parse_npmrc�Parse an `.npmrc` file in into key/value map.

`.npmrc` files are in [INI](https://en.wikipedia.org/wiki/INI_file#Format) format but we don't
treat keys as [case insensitive](https://en.wikipedia.org/wiki/INI_file#Case_sensitivity) due
to https://github.com/aspect-build/rules_js/issues/622.

Duplicate case-sensitive keys override previous values.

Supports:
* basic key/value
* # or ; comments

Does NOT support or ignores:
* sections
* escape characters
* number or boolean types (all values are strings)
* comment characters (#, ;) within a value
*�
�
parse_npmrc0
npmrc_contentthe `.npmrc` content string (�Parse an `.npmrc` file in into key/value map.

`.npmrc` files are in [INI](https://en.wikipedia.org/wiki/INI_file#Format) format but we don't
treat keys as [case insensitive](https://en.wikipedia.org/wiki/INI_file#Case_sensitivity) due
to https://github.com/aspect-build/rules_js/issues/622.

Duplicate case-sensitive keys override previous values.

Supports:
* basic key/value
* # or ; comments

Does NOT support or ignores:
* sections
* escape characters
* number or boolean types (all values are strings)
* comment characters (#, ;) within a value
"8
6A dict() of key/value pairs of the `.npmrc` properties27
parse_npmrc(@@aspect_rules_js//npm/private:npmrc.bzl
npmrc utils�
,
aspect_rules_jsnpm/privatepkg_glob.bzl�pkg_glob*Testing if the passed pkg matches the exp.*�
�
pkg_glob
expthe glob expression (#
pkgthe package name to test (*Testing if the passed pkg matches the exp."1
/True if the package matches the glob expression27
pkg_glob+@@aspect_rules_js//npm/private:pkg_glob.bzl


�
Basic glob implementation required for the pnpm public-hoist-exp option
(https://pnpm.io/npmrc#public-hoist-exp).

pnpm implementation and tests:
    https://github.com/pnpm/pnpm/blob/v7.4.0-2/packages/matcher/src/index.ts
    https://github.com/pnpm/pnpm/blob/v7.4.0-2/packages/matcher/test/index.ts
k
:
aspect_rules_jsnpm/privatestarlark_codegen_utils.bzl-Utilities for generating starlark source code�
6
aspect_rules_jsnpm/privatetransitive_closure.bzl�	gather_transitive_closure�Walk the dependency tree, collecting the transitive closure of dependencies and their versions.

This is needed to resolve npm dependency cycles.
Note: Starlark expressly forbids recursion and infinite loops, so we need to iterate over a large range of numbers,
where each iteration takes one item from the stack, and possibly adds many new items to the stack.
*�
�
gather_transitive_closure)
packagesdictionary from pnpm lock (.
packagethe package to collect deps for (:
no_optional'whether to exclude optionalDependencies (@
cache1a dictionary of results from previous invocations{}(�Walk the dependency tree, collecting the transitive closure of dependencies and their versions.

This is needed to resolve npm dependency cycles.
Note: Starlark expressly forbids recursion and infinite loops, so we need to iterate over a large range of numbers,
where each iteration takes one item from the stack, and possibly adds many new items to the stack.
"W
UA dictionary of transitive dependencies, mapping package names to dependent versions.2R
gather_transitive_closure5@@aspect_rules_js//npm/private:transitive_closure.bzl
�translate_to_transitive_closuremImplementation detail of translate_package_lock, converts pnpm-lock to a different dictionary with more data.*�
�
translate_to_transitive_closure6
	importers%workspace projects (pnpm "importers") ((
packagesall package info by name (3
prod"If true, only install dependenciesFalse(5
dev%If true, only install devDependenciesFalse(G
no_optional/If true, optionalDependencies are not installedFalse(mImplementation detail of translate_package_lock, converts pnpm-lock to a different dictionary with more data."J
HNested dictionary suitable for further processing in our repository rule2X
translate_to_transitive_closure5@@aspect_rules_js//npm/private:transitive_closure.bzl
JJt
//npm/private:utils.bzlrW
)
aspect_rules_jsnpm/private	utils.bzl
utilsutils
27
9a
//lib:dicts.bzlrL

bazel_skyliblib	dicts.bzl
dictsdicts
',
.-Helper utility for working with pnpm lockfile�
)
aspect_rules_jsnpm/private	utils.bzlu
//lib:paths.bzlr`
"
aspect_bazel_liblib	paths.bzl,
relative_filerelative_file
+8
:y
//lib:repo_utils.bzlr_
'
aspect_bazel_liblibrepo_utils.bzl&

repo_utils
repo_utils
0:
<a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.�	INTERNAL_ERROR_MSGeERROR: rules_js internal error, please file an issue: https://github.com/aspect-build/rules_js/issuesjgeERROR: rules_js internal error, please file an issue: https://github.com/aspect-build/rules_js/issues�	(DEFAULT_EXTERNAL_REPOSITORY_ACTION_CACHE..aspect/rules/external_repository_action_cachej0..aspect/rules/external_repository_action_cacheE	DEFAULT_REGISTRY_DOMAINregistry.npmjs.orgjregistry.npmjs.orgM	DEFAULT_REGISTRY_DOMAIN_SLASHregistry.npmjs.org/jregistry.npmjs.org/-	DEFAULT_REGISTRY_PROTOCOLhttpsjhttpsUtility functions for npm rules�
,
aspect_rules_jsnpm/privateversions.bzlSMirror of npm registry metadata for the pnpm package.

AUTO-GENERATED; do not edit
�
(
aspect_rules_jsnpm/privateyaml.bzl�parseParse yaml into starlark*�
�
parse-
yaml!string, the yaml content to parse (Parse yaml into starlark"0
.An equivalent mapping to native starlark types20
parse'@@aspect_rules_js//npm/private:yaml.bzl
9An experimental (and incomplete) yaml parser for starlark��
 
aspect_rules_jsnpmdefs.bzl�Tnpm_link_package�"Links an npm package to node_modules if link is True.

When called at the root_package, a package store target is generated named `link__{bazelified_name}__store`.

When linking, a `{name}` target is generated which consists of the `node_modules/<package>` symlink and transitively
its package store link and the package store links of the transitive closure of deps.

When linking, `{name}/dir` filegroup is also generated that refers to a directory artifact can be used to access
the package directory for creating entry points or accessing files in the package.


Defines a npm package that is linked into a node_modules tree.

The npm package is linked with a pnpm style symlinked node_modules output tree.

The term "package" is defined at
<https://nodejs.org/docs/latest-v16.x/api/packages.html>

See https://pnpm.io/symlinked-node-modules-structure for more information on
the symlinked node_modules structure.
Npm may also support a symlinked node_modules structure called
"Isolated mode" in the future:
https://github.com/npm/rfcs/blob/main/accepted/0042-isolated-mode.md.
"�K
�)
npm_link_package�"Links an npm package to node_modules if link is True.

When called at the root_package, a package store target is generated named `link__{bazelified_name}__store`.

When linking, a `{name}` target is generated which consists of the `node_modules/<package>` symlink and transitively
its package store link and the package store links of the transitive closure of deps.

When linking, `{name}/dir` filegroup is also generated that refers to a directory artifact can be used to access
the package directory for creating entry points or accessing files in the package.


Defines a npm package that is linked into a node_modules tree.

The npm package is linked with a pnpm style symlinked node_modules output tree.

The term "package" is defined at
<https://nodejs.org/docs/latest-v16.x/api/packages.html>

See https://pnpm.io/symlinked-node-modules-structure for more information on
the symlinked node_modules structure.
Npm may also support a symlinked node_modules structure called
"Isolated mode" in the future:
https://github.com/npm/rfcs/blob/main/accepted/0042-isolated-mode.md.
*
nameA unique name for this target. �
deps�Other node packages store link targets one depends on mapped to the name to link them under in this packages deps.

This should include *all* modules the program may need at runtime.

You can find all the package store link targets in your repository with

```
bazel query ... | grep :.aspect_rules_js | grep -v /dir | grep -v /pkg | grep -v /ref
```

Package store link targets names for 3rd party packages that come from `npm_translate_lock`
start with `.aspect_rules_js/` then the name passed to the `npm_link_all_packages` macro
(typically `node_modules`) followed by `/<package>/<version>` where `package` is the
package name (including @scope segment if any) and `version` is the specific version of
the package that comes from the pnpm-lock.yaml file.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

The version may include peer dep(s),

```
//:.aspect_rules_js/node_modules/debug/4.3.4_supports-color@8.1.1
```

It could be also be a url based version,

```
//:.aspect_rules_js/node_modules/debug/github.com/ngokevin/debug/9742c5f383a6f8046241920156236ade8ec30d53
```

Package store link targets names for 3rd party package that come directly from an
`npm_import` start with `.aspect_rules_js/` then the name passed to the `npm_import`'s `npm_link_imported_package`
macro (typically `node_modules`) followed by `/<package>/<version>` where `package`
matches the `package` attribute in the npm_import of the package and `version` matches the
`version` attribute.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

Package store link targets names for 1st party packages automatically linked by `npm_link_all_packages`
using workspaces will follow the same pattern as 3rd party packages with the version typically defaulting
to "0.0.0".

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg/0.0.0
```

Package store link targets names for 1st party packages manually linked with `npm_link_package`
start with `.aspect_rules_js/` followed by the name passed to the `npm_link_package`.

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg
```

> In typical usage, a node.js program sometimes requires modules which were
> never declared as dependencies.
> This pattern is typically used when the program has conditional behavior
> that is enabled when the module is found (like a plugin) but the program
> also runs without the dependency.
> 
> This is possible because node.js doesn't enforce the dependencies are sound.
> All files under `node_modules` are available to any program.
> In contrast, Bazel makes it possible to make builds hermetic, which means that
> all dependencies of a program must be declared when running in Bazel's sandbox.
	*
NpmPackageStoreInfo
JsInfo2{}<
dev,Whether this npm package is a dev dependency2False�
hardlink�Controls when to use hardlinks to files instead of making copies.

Creating hardlinks is much faster than making copies of files with the caveat that
hardlinks share file permissions with their source.

Since Bazel removes write permissions on files in the output tree after an action completes,
hardlinks to source files is not recommended since write permissions will be inadvertently
removed from sources files.

- "auto": hardlinks are used for generated files already in the output tree
- "off": all files are copied
- "on": hardlinks are used for all files (not recommended)

NB: Hardlinking source files in external repositories as was done under the hood
prior to https://github.com/aspect-build/rules_js/pull/1533 may lead to flaky build
failures as reported in https://github.com/aspect-build/rules_js/issues/1412.
2"auto"�
package�The package name to link to.

If unset, the package name in the NpmPackageInfo src must be set.
If set, takes precendance over the package name in the NpmPackageInfo src.
2""W
srcLA npm_package target or or any other target that provides a NpmPackageInfo.
 >
verbose*If true, prints out verbose logs to stdout2False�
version�The package version being linked.

If unset, the package version in the NpmPackageInfo src must be set.
If set, takes precendance over the package version in the NpmPackageInfo src.
2""
,
*
nameA unique name for this target. �
�
deps�Other node packages store link targets one depends on mapped to the name to link them under in this packages deps.

This should include *all* modules the program may need at runtime.

You can find all the package store link targets in your repository with

```
bazel query ... | grep :.aspect_rules_js | grep -v /dir | grep -v /pkg | grep -v /ref
```

Package store link targets names for 3rd party packages that come from `npm_translate_lock`
start with `.aspect_rules_js/` then the name passed to the `npm_link_all_packages` macro
(typically `node_modules`) followed by `/<package>/<version>` where `package` is the
package name (including @scope segment if any) and `version` is the specific version of
the package that comes from the pnpm-lock.yaml file.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

The version may include peer dep(s),

```
//:.aspect_rules_js/node_modules/debug/4.3.4_supports-color@8.1.1
```

It could be also be a url based version,

```
//:.aspect_rules_js/node_modules/debug/github.com/ngokevin/debug/9742c5f383a6f8046241920156236ade8ec30d53
```

Package store link targets names for 3rd party package that come directly from an
`npm_import` start with `.aspect_rules_js/` then the name passed to the `npm_import`'s `npm_link_imported_package`
macro (typically `node_modules`) followed by `/<package>/<version>` where `package`
matches the `package` attribute in the npm_import of the package and `version` matches the
`version` attribute.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

Package store link targets names for 1st party packages automatically linked by `npm_link_all_packages`
using workspaces will follow the same pattern as 3rd party packages with the version typically defaulting
to "0.0.0".

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg/0.0.0
```

Package store link targets names for 1st party packages manually linked with `npm_link_package`
start with `.aspect_rules_js/` followed by the name passed to the `npm_link_package`.

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg
```

> In typical usage, a node.js program sometimes requires modules which were
> never declared as dependencies.
> This pattern is typically used when the program has conditional behavior
> that is enabled when the module is found (like a plugin) but the program
> also runs without the dependency.
> 
> This is possible because node.js doesn't enforce the dependencies are sound.
> All files under `node_modules` are available to any program.
> In contrast, Bazel makes it possible to make builds hermetic, which means that
> all dependencies of a program must be declared when running in Bazel's sandbox.
	*
NpmPackageStoreInfo
JsInfo2{}>
<
dev,Whether this npm package is a dev dependency2False�
�
hardlink�Controls when to use hardlinks to files instead of making copies.

Creating hardlinks is much faster than making copies of files with the caveat that
hardlinks share file permissions with their source.

Since Bazel removes write permissions on files in the output tree after an action completes,
hardlinks to source files is not recommended since write permissions will be inadvertently
removed from sources files.

- "auto": hardlinks are used for generated files already in the output tree
- "off": all files are copied
- "on": hardlinks are used for all files (not recommended)

NB: Hardlinking source files in external repositories as was done under the hood
prior to https://github.com/aspect-build/rules_js/pull/1533 may lead to flaky build
failures as reported in https://github.com/aspect-build/rules_js/issues/1412.
2"auto"�
�
package�The package name to link to.

If unset, the package name in the NpmPackageInfo src must be set.
If set, takes precendance over the package name in the NpmPackageInfo src.
2""Y
W
srcLA npm_package target or or any other target that provides a NpmPackageInfo.
 @
>
verbose*If true, prints out verbose logs to stdout2False�
�
version�The package version being linked.

If unset, the package version in the NpmPackageInfo src must be set.
If set, takes precendance over the package version in the NpmPackageInfo src.
2""ʠnpm_package�A macro that packages sources into a directory (a tree artifact) and provides an `NpmPackageInfo`.

This target can be used as the `src` attribute to `npm_link_package`.

The macro also produces a target `[name].publish`, that can be run to publish to an npm registry.
Under the hood, this target runs `npm publish`. You can pass arguments to npm by escaping them from Bazel using a double-hyphen,
for example: `bazel run //path/to:my_package.publish -- --tag=next`

Files and directories can be arranged as needed in the output directory using
the `root_paths`, `include_srcs_patterns`, `exclude_srcs_patterns` and `replace_prefixes` attributes.

Filters and transformations are applied in the following order:

1. `include_external_repositories`

2. `include_srcs_packages`

3. `exclude_srcs_packages`

4. `root_paths`

5. `include_srcs_patterns`

6. `exclude_srcs_patterns`

7. `replace_prefixes`

For more information each filters / transformations applied, see
the documentation for the specific filter / transformation attribute.

Glob patterns are supported. Standard wildcards (globbing patterns) plus the `**` doublestar (aka. super-asterisk)
are supported with the underlying globbing library, https://github.com/bmatcuk/doublestar. This is the same
globbing library used by [gazelle](https://github.com/bazelbuild/bazel-gazelle). See https://github.com/bmatcuk/doublestar#patterns
for more information on supported globbing patterns.

`npm_package` makes use of `copy_to_directory`
(https://docs.aspect.build/rules/aspect_bazel_lib/docs/copy_to_directory) under the hood,
adopting its API and its copy action using composition. However, unlike `copy_to_directory`,
`npm_package` includes direct and transitive sources and types files from `JsInfo` providers in srcs
by default. The behavior of including sources and types from `JsInfo` can be configured
using the `include_sources`, `include_transitive_sources`, `include_types`, `include_transitive_types`.

The two `include*_types` options may cause type-check actions to run, which slows down your
development round-trip.
You can pass the Bazel option `--@aspect_rules_js//npm:exclude_types_from_npm_packages`
to override these two attributes for an individual `bazel` invocation, avoiding the type-check.

As of rules_js 2.0, the recommended solution for avoiding eager type-checking when linking
1p deps is to link `js_library` or any `JsInfo` producing targets directly without the
indirection of going through an `npm_package` target (see https://github.com/aspect-build/rules_js/pull/1646
for more details).

`npm_package` can also include npm packages sources and default runfiles from `srcs` which `copy_to_directory` does not.
These behaviors can be configured with the `include_npm_sourfes` and `include_runfiles` attributes
respectively.

The default `include_srcs_packages`, `[".", "./**"]`, prevents files from outside of the target's
package and subpackages from being included.

The default `exclude_srcs_patterns`, of `["node_modules/**", "**/node_modules/**"]`, prevents
`node_modules` files from being included.

To stamp the current git tag as the "version" in the package.json file, see
[stamped_package_json](#stamped_package_json)
"��
�P
npm_package�A macro that packages sources into a directory (a tree artifact) and provides an `NpmPackageInfo`.

This target can be used as the `src` attribute to `npm_link_package`.

The macro also produces a target `[name].publish`, that can be run to publish to an npm registry.
Under the hood, this target runs `npm publish`. You can pass arguments to npm by escaping them from Bazel using a double-hyphen,
for example: `bazel run //path/to:my_package.publish -- --tag=next`

Files and directories can be arranged as needed in the output directory using
the `root_paths`, `include_srcs_patterns`, `exclude_srcs_patterns` and `replace_prefixes` attributes.

Filters and transformations are applied in the following order:

1. `include_external_repositories`

2. `include_srcs_packages`

3. `exclude_srcs_packages`

4. `root_paths`

5. `include_srcs_patterns`

6. `exclude_srcs_patterns`

7. `replace_prefixes`

For more information each filters / transformations applied, see
the documentation for the specific filter / transformation attribute.

Glob patterns are supported. Standard wildcards (globbing patterns) plus the `**` doublestar (aka. super-asterisk)
are supported with the underlying globbing library, https://github.com/bmatcuk/doublestar. This is the same
globbing library used by [gazelle](https://github.com/bazelbuild/bazel-gazelle). See https://github.com/bmatcuk/doublestar#patterns
for more information on supported globbing patterns.

`npm_package` makes use of `copy_to_directory`
(https://docs.aspect.build/rules/aspect_bazel_lib/docs/copy_to_directory) under the hood,
adopting its API and its copy action using composition. However, unlike `copy_to_directory`,
`npm_package` includes direct and transitive sources and types files from `JsInfo` providers in srcs
by default. The behavior of including sources and types from `JsInfo` can be configured
using the `include_sources`, `include_transitive_sources`, `include_types`, `include_transitive_types`.

The two `include*_types` options may cause type-check actions to run, which slows down your
development round-trip.
You can pass the Bazel option `--@aspect_rules_js//npm:exclude_types_from_npm_packages`
to override these two attributes for an individual `bazel` invocation, avoiding the type-check.

As of rules_js 2.0, the recommended solution for avoiding eager type-checking when linking
1p deps is to link `js_library` or any `JsInfo` producing targets directly without the
indirection of going through an `npm_package` target (see https://github.com/aspect-build/rules_js/pull/1646
for more details).

`npm_package` can also include npm packages sources and default runfiles from `srcs` which `copy_to_directory` does not.
These behaviors can be configured with the `include_npm_sourfes` and `include_runfiles` attributes
respectively.

The default `include_srcs_packages`, `[".", "./**"]`, prevents files from outside of the target's
package and subpackages from being included.

The default `exclude_srcs_patterns`, of `["node_modules/**", "**/node_modules/**"]`, prevents
`node_modules` files from being included.

To stamp the current git tag as the "version" in the package.json file, see
[stamped_package_json](#stamped_package_json)
*
nameA unique name for this target. �
allow_overwrites�If True, allow files to be overwritten if the same output file is copied to twice.

The order of srcs matters as the last copy of a particular file will win when overwriting.
Performance of copy_to_directory will be slightly degraded when allow_overwrites is True
since copies cannot be parallelized out as they are calculated. Instead all copy paths
must be calculated before any copies can be started.
2False
data2[]�
exclude_srcs_packages�List of Bazel packages (with glob support) to exclude from output directory.

Files in srcs are not copied to the output directory if
the Bazel package of the file matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators. A first character of `"."`
will be replaced by the target's package path.

Files that have do not have matching Bazel packages are subject to subsequent
filters and transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).
2[]�
exclude_srcs_patterns�List of paths (with glob support) to exclude from output directory.

Files in srcs are not copied to the output directory if their output
directory path, after applying `root_paths`, matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators.

Files that do not have matching output directory paths are subject to subsequent
filters and transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).
2[]�
hardlink�Controls when to use hardlinks to files instead of making copies.

Creating hardlinks is much faster than making copies of files with the caveat that
hardlinks share file permissions with their source.

Since Bazel removes write permissions on files in the output tree after an action completes,
hardlinks to source files are not recommended since write permissions will be inadvertently
removed from sources files.

- `auto`: hardlinks are used for generated files already in the output tree
- `off`: all files are copied
- `on`: hardlinks are used for all files (not recommended)
2"auto"�	
include_external_repositories�	List of external repository names (with glob support) to include in the output directory.

Files from external repositories are only copied into the output directory if
the external repository they come from matches one of the external repository patterns
specified or if they are in the same external repository as this target.

When copied from an external repository, the file path in the output directory
defaults to the file's path within the external repository. The external repository
name is _not_ included in that path.

For example, the following copies `@external_repo//path/to:file` to
`path/to/file` within the output directory.

```
copy_to_directory(
    name = "dir",
    include_external_repositories = ["external_*"],
    srcs = ["@external_repo//path/to:file"],
)
```

Files that come from matching external are subject to subsequent filters and
transformations to determine if they are copied and what their path in the output
directory will be. The external repository name of the file from an external
repository is not included in the output directory path and is considered in subsequent
filters and transformations.

Globs are supported (see rule docstring above).
2[]�
include_srcs_packages�List of Bazel packages (with glob support) to include in output directory.

Files in srcs are only copied to the output directory if
the Bazel package of the file matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators. A first character of `"."`
will be replaced by the target's package path.

Defaults to `["**"]` which includes sources from all packages.

Files that have matching Bazel packages are subject to subsequent filters and
transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).
2["**"]�
include_srcs_patterns�List of paths (with glob support) to include in output directory.

Files in srcs are only copied to the output directory if their output
directory path, after applying `root_paths`, matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators.

Defaults to `["**"]` which includes all sources.

Files that have matching output directory paths are subject to subsequent
filters and transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).
2["**"]r
outePath of the output directory, relative to this package.

If not set, the name of the target is used.
2""
package2""�
replace_prefixes�Map of paths prefixes (with glob support) to replace in the output directory path when copying files.

If the output directory path for a file starts with or fully matches a
a key in the dict then the matching portion of the output directory path is
replaced with the dict value for that key. The final path segment
matched can be a partial match of that segment and only the matching portion will
be replaced. If there are multiple keys that match, the longest match wins.

Forward slashes (`/`) should be used as path separators.

Replace prefix transformation are the final step in the list of filters and transformations.
The final output path of a file being copied into the output directory
is determined at this step.

Globs are supported (see rule docstring above).

2{}�

root_paths�List of paths (with glob support) that are roots in the output directory.

If any parent directory of a file being copied matches one of the root paths
patterns specified, the output directory path will be the path relative to the root path
instead of the path relative to the file's workspace. If there are multiple
root paths that match, the longest match wins.

Matching is done on the parent directory of the output file path so a trailing '**' glob patterm
will match only up to the last path segment of the dirname and will not include the basename.
Only complete path segments are matched. Partial matches on the last segment of the root path
are ignored.

Forward slashes (`/`) should be used as path separators.

A `"."` value expands to the target's package path (`ctx.label.package`).

Defaults to `["."]` which results in the output directory path of files in the
target's package and and sub-packages are relative to the target's package and
files outside of that retain their full workspace relative paths.

Globs are supported (see rule docstring above).
2["."]u
srcsgFiles and/or directories or targets that provide `DirectoryPathInfo` to copy into the output directory.2[]>
verbose*If true, prints out verbose logs to stdout2False
version2""
��,
*
nameA unique name for this target. �
�
allow_overwrites�If True, allow files to be overwritten if the same output file is copied to twice.

The order of srcs matters as the last copy of a particular file will win when overwriting.
Performance of copy_to_directory will be slightly degraded when allow_overwrites is True
since copies cannot be parallelized out as they are calculated. Instead all copy paths
must be calculated before any copies can be started.
2False

data2[]�
�
exclude_srcs_packages�List of Bazel packages (with glob support) to exclude from output directory.

Files in srcs are not copied to the output directory if
the Bazel package of the file matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators. A first character of `"."`
will be replaced by the target's package path.

Files that have do not have matching Bazel packages are subject to subsequent
filters and transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).
2[]�
�
exclude_srcs_patterns�List of paths (with glob support) to exclude from output directory.

Files in srcs are not copied to the output directory if their output
directory path, after applying `root_paths`, matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators.

Files that do not have matching output directory paths are subject to subsequent
filters and transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).
2[]�
�
hardlink�Controls when to use hardlinks to files instead of making copies.

Creating hardlinks is much faster than making copies of files with the caveat that
hardlinks share file permissions with their source.

Since Bazel removes write permissions on files in the output tree after an action completes,
hardlinks to source files are not recommended since write permissions will be inadvertently
removed from sources files.

- `auto`: hardlinks are used for generated files already in the output tree
- `off`: all files are copied
- `on`: hardlinks are used for all files (not recommended)
2"auto"�	
�	
include_external_repositories�	List of external repository names (with glob support) to include in the output directory.

Files from external repositories are only copied into the output directory if
the external repository they come from matches one of the external repository patterns
specified or if they are in the same external repository as this target.

When copied from an external repository, the file path in the output directory
defaults to the file's path within the external repository. The external repository
name is _not_ included in that path.

For example, the following copies `@external_repo//path/to:file` to
`path/to/file` within the output directory.

```
copy_to_directory(
    name = "dir",
    include_external_repositories = ["external_*"],
    srcs = ["@external_repo//path/to:file"],
)
```

Files that come from matching external are subject to subsequent filters and
transformations to determine if they are copied and what their path in the output
directory will be. The external repository name of the file from an external
repository is not included in the output directory path and is considered in subsequent
filters and transformations.

Globs are supported (see rule docstring above).
2[]�
�
include_srcs_packages�List of Bazel packages (with glob support) to include in output directory.

Files in srcs are only copied to the output directory if
the Bazel package of the file matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators. A first character of `"."`
will be replaced by the target's package path.

Defaults to `["**"]` which includes sources from all packages.

Files that have matching Bazel packages are subject to subsequent filters and
transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).
2["**"]�
�
include_srcs_patterns�List of paths (with glob support) to include in output directory.

Files in srcs are only copied to the output directory if their output
directory path, after applying `root_paths`, matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators.

Defaults to `["**"]` which includes all sources.

Files that have matching output directory paths are subject to subsequent
filters and transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).
2["**"]t
r
outePath of the output directory, relative to this package.

If not set, the name of the target is used.
2""

package2""�
�
replace_prefixes�Map of paths prefixes (with glob support) to replace in the output directory path when copying files.

If the output directory path for a file starts with or fully matches a
a key in the dict then the matching portion of the output directory path is
replaced with the dict value for that key. The final path segment
matched can be a partial match of that segment and only the matching portion will
be replaced. If there are multiple keys that match, the longest match wins.

Forward slashes (`/`) should be used as path separators.

Replace prefix transformation are the final step in the list of filters and transformations.
The final output path of a file being copied into the output directory
is determined at this step.

Globs are supported (see rule docstring above).

2{}�
�

root_paths�List of paths (with glob support) that are roots in the output directory.

If any parent directory of a file being copied matches one of the root paths
patterns specified, the output directory path will be the path relative to the root path
instead of the path relative to the file's workspace. If there are multiple
root paths that match, the longest match wins.

Matching is done on the parent directory of the output file path so a trailing '**' glob patterm
will match only up to the last path segment of the dirname and will not include the basename.
Only complete path segments are matched. Partial matches on the last segment of the root path
are ignored.

Forward slashes (`/`) should be used as path separators.

A `"."` value expands to the target's package path (`ctx.label.package`).

Defaults to `["."]` which results in the output directory path of files in the
target's package and and sub-packages are relative to the target's package and
files outside of that retain their full workspace relative paths.

Globs are supported (see rule docstring above).
2["."]w
u
srcsgFiles and/or directories or targets that provide `DirectoryPathInfo` to copy into the output directory.2[]@
>
verbose*If true, prints out verbose logs to stdout2False

version2""�	stamped_package_json�Convenience wrapper to set the "version" property in package.json with the git tag.

In unstamped builds (typically those without `--stamp`) the version will be set to `0.0.0`.
This ensures that actions which use the package.json file can get cache hits.

For more information on stamping, read https://docs.aspect.build/rules/aspect_bazel_lib/docs/stamping.
*�
�
stamped_package_json@
name4name of the resulting `jq` target, must be "package" (b
	stamp_varQa key from the bazel-out/stable-status.txt or bazel-out/volatile-status.txt files (u
kwargsiadditional attributes passed to the jq rule, see https://docs.aspect.build/rules/aspect_bazel_lib/docs/jq(�Convenience wrapper to set the "version" property in package.json with the git tag.

In unstamped builds (typically those without `--stamp`) the version will be set to `0.0.0`.
This ensures that actions which use the package.json file can get cache hits.

For more information on stamping, read https://docs.aspect.build/rules/aspect_bazel_lib/docs/stamping.
2F
stamped_package_json.@@aspect_rules_js//npm/private:npm_package.bzl
��*jq2jq�
"//npm/private:npm_link_package.bzlry
4
aspect_rules_jsnpm/privatenpm_link_package.bzl3
npm_link_package_npm_link_package

�
//npm/private:npm_package.bzlr�
/
aspect_rules_jsnpm/privatenpm_package.bzl)
npm_package_npm_package


;
stamped_package_json_stamped_package_json

[Rules for fetching and linking npm dependencies and packaging and linking first-party deps
�J
&
aspect_rules_jsnpmextensions.bzl�1npmJ�1
�
npm�	
npm_translate_lock
name2""
additional_file_contents 

bins 
bzlmod2False
custom_postinstalls
2{}
data2[]!
defs_bzl_filename2
"defs.bzl"
dev2FalseV
 external_repository_action_cache20".aspect/rules/external_repository_action_cache"'
generate_bzl_library_targets2False
lifecycle_hooks 
lifecycle_hooks_envs 
lifecycle_hooks_exclude2[],
&lifecycle_hooks_execution_requirements $
lifecycle_hooks_no_sandbox2True-
%lifecycle_hooks_use_default_shell_env
2{}
link_workspace2""
no_optional2False#
node_toolchain_prefix2"nodejs"
npm_package_lock2None"
npm_package_target_name2"pkg"
npmrc2None
package_visibility 

patch_args 
patches 
	pnpm_lock2None
	preupdate2[]
prod2False
public_hoist_packages 
quiet2True
replace_packages
2{}
root_package2"."
run_lifecycle_hooks2True
update_pnpm_lock2False
use_home_npmrc2False*
use_pnpm2@pnpm//:package/bin/pnpm.cjs%
verify_node_modules_ignored2None
verify_patches2None
	yarn_lock2None
yq_toolchain_prefix2"yq"�

npm_import
name2""
bins
2{}
commit2""
custom_postinstall2""
deps
2{}
dev2False
extra_build_content2""
extract_full_archive2False'
generate_bzl_library_targets2False
	integrity2""!
lifecycle_build_target2False
lifecycle_hooks2[]
lifecycle_hooks_env2[]:
&lifecycle_hooks_execution_requirements2["no-sandbox"]%
lifecycle_hooks_no_sandbox2False0
%lifecycle_hooks_use_default_shell_env2False
link_packages 
link_workspace2""
npm_auth2""
npm_auth_basic2""
npm_auth_password2""
npm_auth_username2""
package /
package_visibility2["//visibility:public"]

patch_args2["-p0"]
patches2[]
replace_package2""
root_package2""
run_lifecycle_hooks2False

system_tar2"auto"
transitive_closure 
url2""
version ",
npm%@@aspect_rules_js//npm:extensions.bzl
���
�	
npm_translate_lock
name2""
additional_file_contents 

bins 
bzlmod2False
custom_postinstalls
2{}
data2[]!
defs_bzl_filename2
"defs.bzl"
dev2FalseV
 external_repository_action_cache20".aspect/rules/external_repository_action_cache"'
generate_bzl_library_targets2False
lifecycle_hooks 
lifecycle_hooks_envs 
lifecycle_hooks_exclude2[],
&lifecycle_hooks_execution_requirements $
lifecycle_hooks_no_sandbox2True-
%lifecycle_hooks_use_default_shell_env
2{}
link_workspace2""
no_optional2False#
node_toolchain_prefix2"nodejs"
npm_package_lock2None"
npm_package_target_name2"pkg"
npmrc2None
package_visibility 

patch_args 
patches 
	pnpm_lock2None
	preupdate2[]
prod2False
public_hoist_packages 
quiet2True
replace_packages
2{}
root_package2"."
run_lifecycle_hooks2True
update_pnpm_lock2False
use_home_npmrc2False*
use_pnpm2@pnpm//:package/bin/pnpm.cjs%
verify_node_modules_ignored2None
verify_patches2None
	yarn_lock2None
yq_toolchain_prefix2"yq"

name2"" 

additional_file_contents 


bins 

bzlmod2False

custom_postinstalls
2{}

data2[]#
!
defs_bzl_filename2
"defs.bzl"

dev2FalseX
V
 external_repository_action_cache20".aspect/rules/external_repository_action_cache")
'
generate_bzl_library_targets2False

lifecycle_hooks 

lifecycle_hooks_envs !

lifecycle_hooks_exclude2[].
,
&lifecycle_hooks_execution_requirements &
$
lifecycle_hooks_no_sandbox2True/
-
%lifecycle_hooks_use_default_shell_env
2{}

link_workspace2""

no_optional2False%
#
node_toolchain_prefix2"nodejs"

npm_package_lock2None$
"
npm_package_target_name2"pkg"

npmrc2None

package_visibility 


patch_args 

patches 

	pnpm_lock2None

	preupdate2[]

prod2False

public_hoist_packages 

quiet2True

replace_packages
2{}

root_package2"."

run_lifecycle_hooks2True

update_pnpm_lock2False

use_home_npmrc2False,
*
use_pnpm2@pnpm//:package/bin/pnpm.cjs'
%
verify_node_modules_ignored2None

verify_patches2None

	yarn_lock2None

yq_toolchain_prefix2"yq"�
�

npm_import
name2""
bins
2{}
commit2""
custom_postinstall2""
deps
2{}
dev2False
extra_build_content2""
extract_full_archive2False'
generate_bzl_library_targets2False
	integrity2""!
lifecycle_build_target2False
lifecycle_hooks2[]
lifecycle_hooks_env2[]:
&lifecycle_hooks_execution_requirements2["no-sandbox"]%
lifecycle_hooks_no_sandbox2False0
%lifecycle_hooks_use_default_shell_env2False
link_packages 
link_workspace2""
npm_auth2""
npm_auth_basic2""
npm_auth_password2""
npm_auth_username2""
package /
package_visibility2["//visibility:public"]

patch_args2["-p0"]
patches2[]
replace_package2""
root_package2""
run_lifecycle_hooks2False

system_tar2"auto"
transitive_closure 
url2""
version 

name2""

bins
2{}

commit2""

custom_postinstall2""

deps
2{}

dev2False

extra_build_content2""!

extract_full_archive2False)
'
generate_bzl_library_targets2False

	integrity2""#
!
lifecycle_build_target2False

lifecycle_hooks2[]

lifecycle_hooks_env2[]<
:
&lifecycle_hooks_execution_requirements2["no-sandbox"]'
%
lifecycle_hooks_no_sandbox2False2
0
%lifecycle_hooks_use_default_shell_env2False

link_packages 

link_workspace2""

npm_auth2""

npm_auth_basic2""

npm_auth_password2""

npm_auth_username2""

package 1
/
package_visibility2["//visibility:public"]


patch_args2["-p0"]

patches2[]

replace_package2""

root_package2"" 

run_lifecycle_hooks2False


system_tar2"auto"

transitive_closure 

url2""

version �pnpmJ�
�
pnpm�
pnpm�
name�Name of the generated repository, allowing more than one pnpm version to be registered.
                        Overriding the default is only permitted in the root module.2"pnpm"
pnpm_version2"8.15.9"
pnpm_version_integrity2"""-
pnpm%@@aspect_rules_js//npm:extensions.bzl
���
�
pnpm�
name�Name of the generated repository, allowing more than one pnpm version to be registered.
Overriding the default is only permitted in the root module.2"pnpm"
pnpm_version2"8.15.9"
pnpm_version_integrity2""�
�
name�Name of the generated repository, allowing more than one pnpm version to be registered.
Overriding the default is only permitted in the root module.2"pnpm"

pnpm_version2"8.15.9" 

pnpm_version_integrity2""y
//lib:repo_utils.bzlr_
'
aspect_bazel_liblibrepo_utils.bzl&

repo_utils
repo_utils
0:
<o
//lib:utils.bzlrZ
"
aspect_bazel_liblib	utils.bzl&
utilsbazel_lib_utils
*9
D�
//npm:repositories.bzlr�
(
aspect_rules_jsnpmrepositories.bzl&

npm_import
npm_import
1;0
pnpm_repositorypnpm_repository
?N;
DEFAULT_PNPM_VERSION_DEFAULT_PNPM_VERSION
Qf;
LATEST_PNPM_VERSION_LATEST_PNPM_VERSION
��
��
//npm/private:npm_import.bzlr�
.
aspect_rules_jsnpm/privatenpm_import.bzl.
npm_import_libnpm_import_lib
7E:
npm_import_links_libnpm_import_links_lib
I]
_�
$//npm/private:npm_translate_lock.bzlr�
6
aspect_rules_jsnpm/privatenpm_translate_lock.bzl>
npm_translate_lock_libnpm_translate_lock_lib
	?	U@
npm_translate_lock_rulenpm_translate_lock_rule
	Y	p
		r�
,//npm/private:npm_translate_lock_helpers.bzlr�
>
aspect_rules_jsnpm/privatenpm_translate_lock_helpers.bzl3
helpersnpm_translate_lock_helpers

F
`


m�
2//npm/private:npm_translate_lock_macro_helpers.bzlr|
D
aspect_rules_jsnpm/private$npm_translate_lock_macro_helpers.bzl&
helpersmacro_helpers
LY
f�
*//npm/private:npm_translate_lock_state.bzlr�
<
aspect_rules_jsnpm/privatenpm_translate_lock_state.bzlB
npm_translate_lock_statenpm_translate_lock_state
E]
_�
//npm/private:npmrc.bzlrc
)
aspect_rules_jsnpm/private	npmrc.bzl(
parse_npmrcparse_npmrc
2=
?�
//npm/private:tar.bzlrm
'
aspect_rules_jsnpm/privatetar.bzl4
detect_system_tardetect_system_tar
0A
C�
$//npm/private:transitive_closure.bzlr�
6
aspect_rules_jsnpm/privatetransitive_closure.bzlP
translate_to_transitive_closuretranslate_to_transitive_closure
?^
`q
:features.bzlr^

bazel_featuresfeatures.bzl.
bazel_featuresbazel_features
)7
9*	DEFAULT_PNPM_VERSION8.15.9j8.15.9'	LATEST_PNPM_VERSION9.7.0j9.7.0sAdapt npm repository rules to be called from MODULE.bazel
See https://bazel.build/docs/bzlmod#extension-definition
�
 
aspect_rules_jsnpmlibs.bzl�
//npm/private:npm_package.bzlrr
/
aspect_rules_jsnpm/privatenpm_package.bzl1
npm_package_lib_npm_package_lib

0Starlark libraries for building derivative rules�
&
aspect_rules_jsnpmnpm_import.bzl*�ModuleInfo request error: invalid argument: Traceback (most recent call last):
	File "external/aspect_rules_js/npm/npm_import.bzl", line 34, column 45, in <toplevel>
		implementation = _npm_translate_lock_lib.implementation,
Error: 'function' value has no field or method 'implementation'�
%
aspect_rules_jsnpmproviders.bzl�NpmPackageInfoNProvides the sources of an npm package along with the package name and version2�
�
NpmPackageInfoNProvides the sources of an npm package along with the package name and version#
packagename of this npm package&
versionversion of this npm packagec
src\the sources of this npm package; either a tarball file, a TreeArtifact or a source directory�
npm_package_store_infos�A depset of NpmPackageStoreInfo providers from npm dependencies of the package and the packages's transitive deps to use as direct dependencies when linking with npm_link_package"6
NpmPackageInfo$@@aspect_rules_js//npm:providers.bzl
%
#
packagename of this npm package(
&
versionversion of this npm packagee
c
src\the sources of this npm package; either a tarball file, a TreeArtifact or a source directory�
�
npm_package_store_infos�A depset of NpmPackageStoreInfo providers from npm dependencies of the package and the packages's transitive deps to use as direct dependencies when linking with npm_link_package�NpmPackageStoreInfo�Provides information about an npm package within the package store of a pnpm-style
symlinked node_modules tree.

See https://pnpm.io/symlinked-node-modules-structure for more information about
symlinked node_modules trees.2�

�
NpmPackageStoreInfo�Provides information about an npm package within the package store of a pnpm-style
symlinked node_modules tree.

See https://pnpm.io/symlinked-node-modules-structure for more information about
symlinked node_modules trees.@
root_package0package that this npm package store is linked at#
packagename of this npm package&
versionversion of this npm packageB
ref_deps6dictionary of dependency npm_package_store ref targetsX
package_store_directory=the TreeArtifact of this npm package's package store location9
files0depset of files that are part of the npm package`
transitive_filesLdepset of the files that are part of the npm package and its transitive deps:
dev3whether or not this npm package is a dev dependency";
NpmPackageStoreInfo$@@aspect_rules_js//npm:providers.bzl
B
@
root_package0package that this npm package store is linked at%
#
packagename of this npm package(
&
versionversion of this npm packageD
B
ref_deps6dictionary of dependency npm_package_store ref targetsZ
X
package_store_directory=the TreeArtifact of this npm package's package store location;
9
files0depset of files that are part of the npm packageb
`
transitive_filesLdepset of the files that are part of the npm package and its transitive deps<
:
dev3whether or not this npm package is a dev dependency�
"//npm/private:npm_package_info.bzlru
4
aspect_rules_jsnpm/privatenpm_package_info.bzl/
NpmPackageInfo_NpmPackageInfo

�
(//npm/private:npm_package_store_info.bzlr�
:
aspect_rules_jsnpm/privatenpm_package_store_info.bzl9
NpmPackageStoreInfo_NpmPackageStoreInfo
		

'Providers for building derivative rules 