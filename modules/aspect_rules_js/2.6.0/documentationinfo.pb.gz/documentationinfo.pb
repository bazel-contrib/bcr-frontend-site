��
+
aspect_rules_jscontrib/nextjsdefs.bzl��nextjs_standalone_server�Configures the output of a standalone Next.js application to be a standalone server binary.

See the Next.js [standalone server documentation](https://nextjs.org/docs/app/api-reference/config/next-config-js/output#automatically-copying-traced-files)
for details on the standalone server directory structure.

This function is normally used in conjunction with `nextjs_standalone_build` to create a standalone
Next.js application. The standalone server is a `js_binary` target that can be run with `bazel run`
or deployed in a container image etc.


Execute a program in the Node.js runtime.

The version of Node.js is determined by Bazel's toolchain selection. In the WORKSPACE you used
`nodejs_register_toolchains` to provide options to Bazel. Then Bazel selects from these options
based on the requested target platform. Use the
[`--toolchain_resolution_debug`](https://docs.bazel.build/versions/main/command-line-reference.html#flag--toolchain_resolution_debug)
Bazel option to see more detail about the selection.

All [common binary attributes](https://bazel.build/reference/be/common-definitions#common-attributes-binaries) are supported
including `args` as the list of arguments passed Node.js.

Node.js execution is performed by a shell script that sets environment variables and runs the Node.js binary with the `entry_point` script.
The shell script is located relative to the directory containing the `js_binary` at `\{name\}_/\{name\}` similar to other rulesets
such as rules_go. See [PR #1690](https://github.com/aspect-build/rules_js/pull/1690) for more information on this naming scheme.

The following environment variables are made available to the Node.js runtime based on available Bazel [Make variables](https://bazel.build/reference/be/make-variables#predefined_variables):

* JS_BINARY__BINDIR: the WORKSPACE-relative Bazel bin directory; equivalent to the `$(BINDIR)` Make variable of the `js_binary` target
* JS_BINARY__COMPILATION_MODE: One of `fastbuild`, `dbg`, or `opt` as set by [`--compilation_mode`](https://bazel.build/docs/user-manual#compilation-mode); equivalent to `$(COMPILATION_MODE)` Make variable of the `js_binary` target
* JS_BINARY__TARGET_CPU: the target cpu architecture; equivalent to `$(TARGET_CPU)` Make variable of the `js_binary` target

The following environment variables are made available to the Node.js runtime based on the rule context:

* JS_BINARY__BUILD_FILE_PATH: the WORKSPACE-relative path to the BUILD file of the Bazel target being run; equivalent to `ctx.build_file_path` of the `js_binary` target's rule context
* JS_BINARY__PACKAGE: the package of the Bazel target being run; equivalent to `ctx.label.package` of the `js_binary` target's rule context
* JS_BINARY__TARGET: the full label of the Bazel target being run; a stringified version of `ctx.label` of the `js_binary` target's rule context
* JS_BINARY__TARGET_NAME: the name of the Bazel target being run; equivalent to `ctx.label.name` of the `js_binary` target's rule context
* JS_BINARY__WORKSPACE: the Bazel workspace name; equivalent to `ctx.workspace_name` of the `js_binary` target's rule context

The following environment variables are made available to the Node.js runtime based the runtime environment:

* JS_BINARY__NODE_BINARY: the Node.js binary path run by the `js_binary` target
* JS_BINARY__NPM_BINARY: the npm binary path; this is available when [`include_npm`](https://docs.aspect.build/rules/aspect_rules_js/docs/js_binary#include_npm) is `True` on the `js_binary` target
* JS_BINARY__NODE_WRAPPER: the Node.js wrapper script used to run Node.js which is available as `node` on the `PATH` at runtime
* JS_BINARY__RUNFILES: the absolute path to the Bazel runfiles directory
* JS_BINARY__EXECROOT: the absolute path to the root of the execution root for the action; if in the sandbox, this path absolute path to the root of the execution root within the sandbox
"��
�i
nextjs_standalone_server�Configures the output of a standalone Next.js application to be a standalone server binary.

See the Next.js [standalone server documentation](https://nextjs.org/docs/app/api-reference/config/next-config-js/output#automatically-copying-traced-files)
for details on the standalone server directory structure.

This function is normally used in conjunction with `nextjs_standalone_build` to create a standalone
Next.js application. The standalone server is a `js_binary` target that can be run with `bazel run`
or deployed in a container image etc.


Execute a program in the Node.js runtime.

The version of Node.js is determined by Bazel's toolchain selection. In the WORKSPACE you used
`nodejs_register_toolchains` to provide options to Bazel. Then Bazel selects from these options
based on the requested target platform. Use the
[`--toolchain_resolution_debug`](https://docs.bazel.build/versions/main/command-line-reference.html#flag--toolchain_resolution_debug)
Bazel option to see more detail about the selection.

All [common binary attributes](https://bazel.build/reference/be/common-definitions#common-attributes-binaries) are supported
including `args` as the list of arguments passed Node.js.

Node.js execution is performed by a shell script that sets environment variables and runs the Node.js binary with the `entry_point` script.
The shell script is located relative to the directory containing the `js_binary` at `\{name\}_/\{name\}` similar to other rulesets
such as rules_go. See [PR #1690](https://github.com/aspect-build/rules_js/pull/1690) for more information on this naming scheme.

The following environment variables are made available to the Node.js runtime based on available Bazel [Make variables](https://bazel.build/reference/be/make-variables#predefined_variables):

* JS_BINARY__BINDIR: the WORKSPACE-relative Bazel bin directory; equivalent to the `$(BINDIR)` Make variable of the `js_binary` target
* JS_BINARY__COMPILATION_MODE: One of `fastbuild`, `dbg`, or `opt` as set by [`--compilation_mode`](https://bazel.build/docs/user-manual#compilation-mode); equivalent to `$(COMPILATION_MODE)` Make variable of the `js_binary` target
* JS_BINARY__TARGET_CPU: the target cpu architecture; equivalent to `$(TARGET_CPU)` Make variable of the `js_binary` target

The following environment variables are made available to the Node.js runtime based on the rule context:

* JS_BINARY__BUILD_FILE_PATH: the WORKSPACE-relative path to the BUILD file of the Bazel target being run; equivalent to `ctx.build_file_path` of the `js_binary` target's rule context
* JS_BINARY__PACKAGE: the package of the Bazel target being run; equivalent to `ctx.label.package` of the `js_binary` target's rule context
* JS_BINARY__TARGET: the full label of the Bazel target being run; a stringified version of `ctx.label` of the `js_binary` target's rule context
* JS_BINARY__TARGET_NAME: the name of the Bazel target being run; equivalent to `ctx.label.name` of the `js_binary` target's rule context
* JS_BINARY__WORKSPACE: the Bazel workspace name; equivalent to `ctx.workspace_name` of the `js_binary` target's rule context

The following environment variables are made available to the Node.js runtime based the runtime environment:

* JS_BINARY__NODE_BINARY: the Node.js binary path run by the `js_binary` target
* JS_BINARY__NPM_BINARY: the npm binary path; this is available when [`include_npm`](https://docs.aspect.build/rules/aspect_rules_js/docs/js_binary#include_npm) is `True` on the `js_binary` target
* JS_BINARY__NODE_WRAPPER: the Node.js wrapper script used to run Node.js which is available as `node` on the `PATH` at runtime
* JS_BINARY__RUNFILES: the absolute path to the Bazel runfiles directory
* JS_BINARY__EXECROOT: the absolute path to the root of the execution root for the action; if in the sandbox, this path absolute path to the root of the execution root within the sandbox
*
nameA unique name for this target. �
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/"))) + "$(rootpath //path/to/some:file)"],
)
```2""�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

NB: `data` files are copied to the Bazel output tree before being passed
as inputs to runfiles. See `copy_data_to_bin` docstring for more info.
2[]�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/bazel-contrib/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 �
env�Environment variables of the action.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_env` is set to True.

2{}�
expand_args�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `fixed_args`.

This comes at some analysis-time cost even for a set of args that does not have any expansions.2True�

expand_env�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `env`.

This comes at some analysis-time cost even for a set of envs that does not have any expansions.2Truei
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�

fixed_args�Fixed command line arguments to pass to the Node.js when this
binary target is executed.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_args` is set to True.

Unlike the built-in `args`, which are only passed to the target when it is
executed either by the `bazel run` command or as a test, `fixed_args` are baked
into the generated launcher script so are always passed even when the binary
target is run outside of Bazel directly from the launcher script.

`fixed_args` are passed before the ones specified in `args` and before ones
that are specified on the `bazel run` or `bazel test` command line.

See https://bazel.build/reference/be/common-definitions#common-attributes-binaries
for more info on the built-in `args` attribute.
2[]�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
include_npm_sources�When True, files in `npm_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in `data` targets are also included in the runfiles of the target.
2True�
include_sourcesjWhen True, `sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
include_transitive_sourcesuWhen True, `transitive_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
include_transitive_types�When True, `transitive_types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
include_types�When True, `types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.

NB: These are types from direct `data` dependencies only. You may also need to set `include_transitive_types` to True.2False�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.

Log levels: fatal, error, warn, info, debug2"error"�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
node_toolchain�The Node.js toolchain to use for this target.

See https://bazel-contrib.github.io/rules_nodejs/Toolchains.html

Typically this is left unset so that Bazel automatically selects the right Node.js toolchain
for the target platform. See https://bazel.build/extending/toolchains#toolchain-resolution
for more information.
2None�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2True
��,
*
nameA unique name for this target. �
�
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/"))) + "$(rootpath //path/to/some:file)"],
)
```2""�
�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

NB: `data` files are copied to the Bazel output tree before being passed
as inputs to runfiles. See `copy_data_to_bin` docstring for more info.
2[]�
�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
�
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/bazel-contrib/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 �
�
env�Environment variables of the action.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_env` is set to True.

2{}�
�
expand_args�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `fixed_args`.

This comes at some analysis-time cost even for a set of args that does not have any expansions.2True�
�

expand_env�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `env`.

This comes at some analysis-time cost even for a set of envs that does not have any expansions.2Truek
i
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�
�

fixed_args�Fixed command line arguments to pass to the Node.js when this
binary target is executed.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_args` is set to True.

Unlike the built-in `args`, which are only passed to the target when it is
executed either by the `bazel run` command or as a test, `fixed_args` are baked
into the generated launcher script so are always passed even when the binary
target is run outside of Bazel directly from the launcher script.

`fixed_args` are passed before the ones specified in `args` and before ones
that are specified on the `bazel run` or `bazel test` command line.

See https://bazel.build/reference/be/common-definitions#common-attributes-binaries
for more info on the built-in `args` attribute.
2[]�
�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
�
include_npm_sources�When True, files in `npm_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in `data` targets are also included in the runfiles of the target.
2True�
�
include_sourcesjWhen True, `sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
�
include_transitive_sourcesuWhen True, `transitive_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
�
include_transitive_types�When True, `transitive_types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
�
include_types�When True, `types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.

NB: These are types from direct `data` dependencies only. You may also need to set `include_transitive_types` to True.2False�
�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.

Log levels: fatal, error, warn, info, debug2"error"�
�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
�
node_toolchain�The Node.js toolchain to use for this target.

See https://bazel-contrib.github.io/rules_nodejs/Toolchains.html

Typically this is left unset so that Bazel automatically selects the right Node.js toolchain
for the target platform. See https://bazel.build/extending/toolchains#toolchain-resolution
for more information.
2None�
�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2True�nextjs�	Generates Next.js build, dev & start targets.

`{name}`       - a Next.js production bundle
`{name}.dev`   - a Next.js devserver
`{name}.start` - a Next.js prodserver

Use this macro in the BUILD file at the root of a next app where the `next.config.mjs`
file is located.

For example, a target such as `//app:next` in `app/BUILD.bazel`

```
next(
    name = "next",
    config = "next.config.mjs",
    srcs = glob(["src/**"]),
    data = [
        "//:node_modules/next",
        "//:node_modules/react-dom",
        "//:node_modules/react",
        "package.json",
    ],
    next_js_binary = "//:next_js_binary",
)
```

will create the targets:

```
//app:next
//app:next.dev
//app:next.start
```

To build the above next app, equivalent to running `next build` outside Bazel:

```
bazel build //app:next
```

To run the development server in watch mode with
[ibazel](https://github.com/bazelbuild/bazel-watcher), equivalent to running
`next dev` outside Bazel:

```
ibazel run //app:next.dev
```

To run the production server in watch mode with
[ibazel](https://github.com/bazelbuild/bazel-watcher), equivalent to running
`next start` outside Bazel:

```
ibazel run //app:next.start
```
*�
�
nextjs(
namethe name of the build target (�
srcs�Source files to include in build & dev targets.
Typically these are source files or transpiled source files in Next.js source folders
such as `pages`, `public` & `styles`. (�
next_js_binary�The next `js_binary` target to use for running Next.js

Typically this is a js_binary target created using `bin` loaded from the `package_json.bzl`
file of the npm package.

See main docstring above for example usage. (T
config5the Next.js config file. Typically `next.config.mjs`."next.config.mjs"(�
data�Data files to include in all targets.
These are typically npm packages required for the build & configuration files such as
package.json and next.config.js.[](>

serve_data*Data files to include in devserver targets[](B
kwargs6Other attributes passed to all targets such as `tags`.(�	Generates Next.js build, dev & start targets.

`{name}`       - a Next.js production bundle
`{name}.dev`   - a Next.js devserver
`{name}.start` - a Next.js prodserver

Use this macro in the BUILD file at the root of a next app where the `next.config.mjs`
file is located.

For example, a target such as `//app:next` in `app/BUILD.bazel`

```
next(
    name = "next",
    config = "next.config.mjs",
    srcs = glob(["src/**"]),
    data = [
        "//:node_modules/next",
        "//:node_modules/react-dom",
        "//:node_modules/react",
        "package.json",
    ],
    next_js_binary = "//:next_js_binary",
)
```

will create the targets:

```
//app:next
//app:next.dev
//app:next.start
```

To build the above next app, equivalent to running `next build` outside Bazel:

```
bazel build //app:next
```

To run the development server in watch mode with
[ibazel](https://github.com/bazelbuild/bazel-watcher), equivalent to running
`next dev` outside Bazel:

```
ibazel run //app:next.dev
```

To run the production server in watch mode with
[ibazel](https://github.com/bazelbuild/bazel-watcher), equivalent to running
`next start` outside Bazel:

```
ibazel run //app:next.start
```
24
nextjs*@@aspect_rules_js//contrib/nextjs:defs.bzl
==*nextjs_build*
nextjs_dev*nextjs_start2nextjs_build2
nextjs_dev2nextjs_start�nextjs_buildgBuild the Next.js production artifact.

See https://nextjs.org/docs/pages/api-reference/cli/next#build
*�
�
nextjs_build(
namethe name of the build target (%
configthe Next.js config file (N
srcsBthe sources to include in the build, including any transitive deps (�
next_js_binary�The next `js_binary` target to use for running Next.js

Typically this is a js_binary target created using `bin` loaded from the `package_json.bzl`
file of the npm package.

See main docstring above for example usage. (4
data&the data files to include in the build[](F
kwargs:Other attributes passed to all targets such as `tags`, env(gBuild the Next.js production artifact.

See https://nextjs.org/docs/pages/api-reference/cli/next#build
2:
nextjs_build*@@aspect_rules_js//contrib/nextjs:defs.bzl
��*js_run_binary2js_run_binary�
nextjs_devoRun the Next.js development server.

See https://nextjs.org/docs/pages/api-reference/cli/next#next-dev-options
*�
�

nextjs_dev(
namethe name of the build target (%
configthe Next.js config file (N
srcsBthe sources to include in the build, including any transitive deps (-
data!additional devserver runtime data (�
next_js_binary�The next `js_binary` target to use for running Next.js

Typically this is a js_binary target created using `bin` loaded from the `package_json.bzl`
file of the npm package.

See main docstring above for example usage. (F
kwargs:Other attributes passed to all targets such as `tags`, env(oRun the Next.js development server.

See https://nextjs.org/docs/pages/api-reference/cli/next#next-dev-options
28

nextjs_dev*@@aspect_rules_js//contrib/nextjs:defs.bzl
��*js_run_devserver2js_run_devserver�nextjs_standalone_build�Compile a standalone Next.js application.

See https://nextjs.org/docs/app/api-reference/config/next-config-js/output#automatically-copying-traced-files

NOTE: a `next.config.mjs` is generated, wrapping the passed `config`, to overcome Next.js limitation with bazel,
rules_js and pnpm (with hoist=false, as required by rules_js).

Due to the generated `next.config.mjs` file the `nextjs_standalone_build(config)` must have a unique name
or file path that does not conflict with standard Next.js config files.

Issues worked around by the generated config include:
* https://github.com/vercel/next.js/issues/48017
* https://github.com/aspect-build/rules_js/issues/714
*�	
�
nextjs_standalone_build(
namethe name of the build target (%
configthe Next.js config file (N
srcsBthe sources to include in the build, including any transitive deps (<
next_js_binary&the Next.js binary to use for building (4
data&the data files to include in the build[](F
kwargs:Other attributes passed to all targets such as `tags`, env(�Compile a standalone Next.js application.

See https://nextjs.org/docs/app/api-reference/config/next-config-js/output#automatically-copying-traced-files

NOTE: a `next.config.mjs` is generated, wrapping the passed `config`, to overcome Next.js limitation with bazel,
rules_js and pnpm (with hoist=false, as required by rules_js).

Due to the generated `next.config.mjs` file the `nextjs_standalone_build(config)` must have a unique name
or file path that does not conflict with standard Next.js config files.

Issues worked around by the generated config include:
* https://github.com/vercel/next.js/issues/48017
* https://github.com/aspect-build/rules_js/issues/714
2E
nextjs_standalone_build*@@aspect_rules_js//contrib/nextjs:defs.bzl
��*js_run_binary2js_run_binary2	copy_file�nextjs_start{Run the Next.js production server for an app.

See https://nextjs.org/docs/pages/api-reference/cli/next#next-start-options
*�
�
nextjs_start(
namethe name of the build target (%
configthe Next.js config file (W
appLthe pre-compiled Next.js application, typically the output of `nextjs_build` (�
next_js_binary�The next `js_binary` target to use for running Next.js

Typically this is a js_binary target created using `bin` loaded from the `package_json.bzl`
file of the npm package.

See main docstring above for example usage. ($
dataadditional server data[](F
kwargs:Other attributes passed to all targets such as `tags`, env({Run the Next.js production server for an app.

See https://nextjs.org/docs/pages/api-reference/cli/next#next-start-options
2:
nextjs_start*@@aspect_rules_js//contrib/nextjs:defs.bzl
��*js_run_devserver2js_run_devserveru
//lib:copy_file.bzlr\
&
aspect_bazel_liblibcopy_file.bzl$
	copy_file	copy_file
///8
//:�
//lib:copy_to_directory.bzlrt
.
aspect_bazel_liblibcopy_to_directory.bzl4
copy_to_directorycopy_to_directory
070H
00J�
//lib:directory_path.bzlrk
+
aspect_bazel_liblibdirectory_path.bzl.
directory_pathdirectory_path
141B
11D�
//js:defs.bzlr�

aspect_rules_jsjsdefs.bzl$
	js_binary	js_binary
2(21,
js_run_binaryjs_run_binary
252B2
js_run_devserverjs_run_devserver
2F2V
22X�Utilities for building Next.js applications with Bazel and rules_js.

All invocations of Next.js are done through a `next_js_binary` target passed into the macros.
This is normally generated once alongside the `package.json` containing the `next` dependency:

```
load("@npm//:next/package_json.bzl", next_bin = "bin")

next_bin.next_binary(
    name = "next_js_binary",
    visibility = ["//visibility:public"],
)
```

The next binary is then passed into the macros, for example:

```
nextjs_build(
    name = "next",
    config = "next.config.mjs",
    srcs = glob(["src/**"]),
    next_js_binary = "//:next_js_binary",
)
```

# Macros

There are two sets of macros for building Next.js applications: standard and standalone.

## Standard

- `nextjs()`: wrap the build+dev+start targets
- `nextjs_build()`: the Next.js [build](https://nextjs.org/docs/app/building-your-application/deploying#production-builds) command
- `nextjs_dev()`: the Next.js [dev](https://nextjs.org/docs/app/getting-started/installation#run-the-development-server) command
- `nextjs_start()`: the Next.js [start](https://nextjs.org/docs/app/building-your-application/deploying#nodejs-server) command,
   accepting a Next.js build artifact to start

## Standalone

For [standalone applications](https://nextjs.org/docs/app/api-reference/config/next-config-js/output#automatically-copying-traced-files):
- `nextjs_standalone_build()`: the Next.js [build](https://nextjs.org/docs/app/building-your-application/deploying#production-builds) command,
   configured for a standalone application within bazel
- `nextjs_standalone_server()`: constructs a standalone Next.js server `js_binary` following the
  [standalone directory structure guidelines](https://nextjs.org/docs/app/api-reference/config/next-config-js/output#automatically-copying-traced-files)
�
2
aspect_rules_jsjs/private/coverage
merger.bzl�coverage_merger"�
�
coverage_merger*
nameA unique name for this target. 2
entry_point2!//js/private/coverage:coverage.js"D
coverage_merger1@@aspect_rules_js//js/private/coverage:merger.bzl
BB,
*
nameA unique name for this target. 4
2
entry_point2!//js/private/coverage:coverage.js�
//lib:windows_utils.bzlr�
*
aspect_bazel_liblibwindows_utils.bzl\
%create_windows_native_launcher_script%create_windows_native_launcher_script
3X
Z�
//js/private:bash.bzlr{
'
aspect_rules_js
js/privatebash.bzlB
BASH_INITIALIZE_RUNFILESBASH_INITIALIZE_RUNFILES
0H
JInternal use only�
5
aspect_rules_jsjs/private/test/coveragetest.bzl��coverage_fail_test"��
�K
coverage_fail_test*
nameA unique name for this target. �
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/"))) + "$(rootpath //path/to/some:file)"],
)
```2""�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

NB: `data` files are copied to the Bazel output tree before being passed
as inputs to runfiles. See `copy_data_to_bin` docstring for more info.
2[]�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/bazel-contrib/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 �
env�Environment variables of the action.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_env` is set to True.

2{}�
expand_args�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `fixed_args`.

This comes at some analysis-time cost even for a set of args that does not have any expansions.2True�

expand_env�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `env`.

This comes at some analysis-time cost even for a set of envs that does not have any expansions.2Truei
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�

fixed_args�Fixed command line arguments to pass to the Node.js when this
binary target is executed.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_args` is set to True.

Unlike the built-in `args`, which are only passed to the target when it is
executed either by the `bazel run` command or as a test, `fixed_args` are baked
into the generated launcher script so are always passed even when the binary
target is run outside of Bazel directly from the launcher script.

`fixed_args` are passed before the ones specified in `args` and before ones
that are specified on the `bazel run` or `bazel test` command line.

See https://bazel.build/reference/be/common-definitions#common-attributes-binaries
for more info on the built-in `args` attribute.
2[]�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
include_npm_sources�When True, files in `npm_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in `data` targets are also included in the runfiles of the target.
2True�
include_sourcesjWhen True, `sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
include_transitive_sourcesuWhen True, `transitive_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
include_transitive_types�When True, `transitive_types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
include_types�When True, `types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.

NB: These are types from direct `data` dependencies only. You may also need to set `include_transitive_types` to True.2False�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.

Log levels: fatal, error, warn, info, debug2"error"�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
node_toolchain�The Node.js toolchain to use for this target.

See https://bazel-contrib.github.io/rules_nodejs/Toolchains.html

Typically this is left unset so that Bazel automatically selects the right Node.js toolchain
for the target platform. See https://bazel.build/extending/toolchains#toolchain-resolution
for more information.
2None�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2True"J
coverage_fail_test4@@aspect_rules_js//js/private/test/coverage:test.bzl
,
*
nameA unique name for this target. �
�
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/"))) + "$(rootpath //path/to/some:file)"],
)
```2""�
�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

NB: `data` files are copied to the Bazel output tree before being passed
as inputs to runfiles. See `copy_data_to_bin` docstring for more info.
2[]�
�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
�
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/bazel-contrib/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 �
�
env�Environment variables of the action.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_env` is set to True.

2{}�
�
expand_args�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `fixed_args`.

This comes at some analysis-time cost even for a set of args that does not have any expansions.2True�
�

expand_env�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `env`.

This comes at some analysis-time cost even for a set of envs that does not have any expansions.2Truek
i
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�
�

fixed_args�Fixed command line arguments to pass to the Node.js when this
binary target is executed.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_args` is set to True.

Unlike the built-in `args`, which are only passed to the target when it is
executed either by the `bazel run` command or as a test, `fixed_args` are baked
into the generated launcher script so are always passed even when the binary
target is run outside of Bazel directly from the launcher script.

`fixed_args` are passed before the ones specified in `args` and before ones
that are specified on the `bazel run` or `bazel test` command line.

See https://bazel.build/reference/be/common-definitions#common-attributes-binaries
for more info on the built-in `args` attribute.
2[]�
�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
�
include_npm_sources�When True, files in `npm_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in `data` targets are also included in the runfiles of the target.
2True�
�
include_sourcesjWhen True, `sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
�
include_transitive_sourcesuWhen True, `transitive_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
�
include_transitive_types�When True, `transitive_types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
�
include_types�When True, `types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.

NB: These are types from direct `data` dependencies only. You may also need to set `include_transitive_types` to True.2False�
�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.

Log levels: fatal, error, warn, info, debug2"error"�
�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
�
node_toolchain�The Node.js toolchain to use for this target.

See https://bazel-contrib.github.io/rules_nodejs/Toolchains.html

Typically this is left unset so that Bazel automatically selects the right Node.js toolchain
for the target platform. See https://bazel.build/extending/toolchains#toolchain-resolution
for more information.
2None�
�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2True��coverage_pass_test"��
�K
coverage_pass_test*
nameA unique name for this target. �
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/"))) + "$(rootpath //path/to/some:file)"],
)
```2""�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

NB: `data` files are copied to the Bazel output tree before being passed
as inputs to runfiles. See `copy_data_to_bin` docstring for more info.
2[]�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/bazel-contrib/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 �
env�Environment variables of the action.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_env` is set to True.

2{}�
expand_args�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `fixed_args`.

This comes at some analysis-time cost even for a set of args that does not have any expansions.2True�

expand_env�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `env`.

This comes at some analysis-time cost even for a set of envs that does not have any expansions.2Truei
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�

fixed_args�Fixed command line arguments to pass to the Node.js when this
binary target is executed.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_args` is set to True.

Unlike the built-in `args`, which are only passed to the target when it is
executed either by the `bazel run` command or as a test, `fixed_args` are baked
into the generated launcher script so are always passed even when the binary
target is run outside of Bazel directly from the launcher script.

`fixed_args` are passed before the ones specified in `args` and before ones
that are specified on the `bazel run` or `bazel test` command line.

See https://bazel.build/reference/be/common-definitions#common-attributes-binaries
for more info on the built-in `args` attribute.
2[]�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
include_npm_sources�When True, files in `npm_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in `data` targets are also included in the runfiles of the target.
2True�
include_sourcesjWhen True, `sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
include_transitive_sourcesuWhen True, `transitive_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
include_transitive_types�When True, `transitive_types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
include_types�When True, `types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.

NB: These are types from direct `data` dependencies only. You may also need to set `include_transitive_types` to True.2False�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.

Log levels: fatal, error, warn, info, debug2"error"�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
node_toolchain�The Node.js toolchain to use for this target.

See https://bazel-contrib.github.io/rules_nodejs/Toolchains.html

Typically this is left unset so that Bazel automatically selects the right Node.js toolchain
for the target platform. See https://bazel.build/extending/toolchains#toolchain-resolution
for more information.
2None�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2True"J
coverage_pass_test4@@aspect_rules_js//js/private/test/coverage:test.bzl
,
*
nameA unique name for this target. �
�
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/"))) + "$(rootpath //path/to/some:file)"],
)
```2""�
�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

NB: `data` files are copied to the Bazel output tree before being passed
as inputs to runfiles. See `copy_data_to_bin` docstring for more info.
2[]�
�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
�
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/bazel-contrib/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 �
�
env�Environment variables of the action.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_env` is set to True.

2{}�
�
expand_args�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `fixed_args`.

This comes at some analysis-time cost even for a set of args that does not have any expansions.2True�
�

expand_env�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `env`.

This comes at some analysis-time cost even for a set of envs that does not have any expansions.2Truek
i
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�
�

fixed_args�Fixed command line arguments to pass to the Node.js when this
binary target is executed.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_args` is set to True.

Unlike the built-in `args`, which are only passed to the target when it is
executed either by the `bazel run` command or as a test, `fixed_args` are baked
into the generated launcher script so are always passed even when the binary
target is run outside of Bazel directly from the launcher script.

`fixed_args` are passed before the ones specified in `args` and before ones
that are specified on the `bazel run` or `bazel test` command line.

See https://bazel.build/reference/be/common-definitions#common-attributes-binaries
for more info on the built-in `args` attribute.
2[]�
�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
�
include_npm_sources�When True, files in `npm_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in `data` targets are also included in the runfiles of the target.
2True�
�
include_sourcesjWhen True, `sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
�
include_transitive_sourcesuWhen True, `transitive_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
�
include_transitive_types�When True, `transitive_types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
�
include_types�When True, `types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.

NB: These are types from direct `data` dependencies only. You may also need to set `include_transitive_types` to True.2False�
�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.

Log levels: fatal, error, warn, info, debug2"error"�
�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
�
node_toolchain�The Node.js toolchain to use for this target.

See https://bazel-contrib.github.io/rules_nodejs/Toolchains.html

Typically this is left unset so that Bazel automatically selects the right Node.js toolchain
for the target platform. See https://bazel.build/extending/toolchains#toolchain-resolution
for more information.
2None�
�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2True�
//js/private:js_binary.bzlrj
,
aspect_rules_js
js/privatejs_binary.bzl,
js_binary_libjs_binary_lib
5B
D!Helper rule for checking coverage�
1
aspect_rules_jsjs/private/test/datadata.bzl�extract"�
�
extract*
nameA unique name for this target. 
single2None";
extract0@@aspect_rules_js//js/private/test/data:data.bzl
,
*
nameA unique name for this target. 

single2None�extract_test"�
�
extract_test*
nameA unique name for this target. 
single2None";
extract0@@aspect_rules_js//js/private/test/data:data.bzl
,
*
nameA unique name for this target. 

single2Noney
//rules:build_test.bzlr]
%
bazel_skylibrulesbuild_test.bzl&

build_test
build_test
.8
:'
Utils for testing js_*() rule outputs
��
5
aspect_rules_jsjs/private/test/imageasserts.bzl݈make_js_image_layer�9Create container image layers from js_binary targets.

By design, js_image_layer doesn't have any preference over which rule assembles the container image.
This means the downstream rule (`oci_image` from [rules_oci](https://github.com/bazel-contrib/rules_oci)
or `container_image` from [rules_docker](https://github.com/bazelbuild/rules_docker)) must
set a proper `workdir` and `cmd` to for the container work.

A proper `cmd` usually looks like /`[ js_image_layer 'root' ]`/`[ package name of js_image_layer 'binary' target ]/[ name of js_image_layer 'binary' target ]`,
unless you have a custom launcher script that invokes the entry_point of the `js_binary` in a different path.

On the other hand, `workdir` has to be set to the "runfiles tree root" which would be exactly `cmd` **but with `.runfiles/[ name of the workspace ]` suffix**.
If using bzlmod then name of the local workspace is always `_main`. If bzlmod is not enabled then the name of the local workspace, if not otherwise specified
in the `WORKSPACE` file, is `__main__`. If `workdir` is not set correctly, some attributes such as `chdir` might not work properly.

js_image_layer creates up to 5 layers depending on what files are included in the runfiles of the provided
`binary` target.

1. `node` layer contains the Node.js toolchain
2. `package_store_3p` layer contains all 3p npm deps in the `node_modules/.aspect_rules_js` package store
3. `package_store_1p` layer contains all 1p npm deps in the `node_modules/.aspect_rules_js` package store
4. `node_modules` layer contains all `node_modules/*` symlinks which point into the package store
5. `app` layer contains all files that don't fall into any of the above layers

If no files are found in the runfiles of the `binary` target for one of the layers above, that
layer is not generated. All generated layer tarballs are provided as `DefaultInfo` files.

> The rules_js `node_modules/.aspect_rules_js` package store follows the same pattern as the pnpm
> `node_modules/.pnpm` virtual store. For more information see https://pnpm.io/symlinked-node-modules-structure.

js_image_layer also provides an `OutputGroupInfo` with outputs for each of the layers above which
can be used to reference an individual layer with using `filegroup` with `output_group`. For example,

```starlark
js_image_layer(
    name = "layers",
    binary = ":bin",
    root = "/app",
)

filegroup(
    name = "app_tar",
    srcs = [":layers"],
    output_group = "app",
)
```

> WARNING: The structure of the generated layers are not subject to semver guarantees and may change without a notice.
> However, it is guaranteed to work when all generated layers are provided together in the order specified above.

js_image_layer supports transitioning to specific `platform` to allow building multi-platform container images.

**A partial example using rules_oci with transition to linux/amd64 platform.**

```starlark
load("@aspect_rules_js//js:defs.bzl", "js_binary", "js_image_layer")
load("@rules_oci//oci:defs.bzl", "oci_image")

js_binary(
    name = "bin",
    entry_point = "main.js",
)

platform(
    name = "amd64_linux",
    constraint_values = [
        "@platforms//os:linux",
        "@platforms//cpu:x86_64",
    ],
)

js_image_layer(
    name = "layers",
    binary = ":bin",
    platform = ":amd64_linux",
    root = "/app",
)

oci_image(
    name = "image",
    cmd = ["/app/bin"],
    entrypoint = ["bash"],
    tars = [
        ":layers"
    ],
    workdir = select({
        "@aspect_bazel_lib//lib:bzlmod": "/app/bin.runfiles/_main",
        "//conditions:default": "/app/bin.runfiles/__main__",
    }),
)
```

**A partial example using rules_oci to create multi-platform images.**

```starlark
load("@aspect_rules_js//js:defs.bzl", "js_binary", "js_image_layer")
load("@rules_oci//oci:defs.bzl", "oci_image", "oci_image_index")

js_binary(
    name = "bin",
    entry_point = "main.js",
)

[
    platform(
        name = "linux_{}".format(arch),
        constraint_values = [
            "@platforms//os:linux",
            "@platforms//cpu:{}".format(arch if arch != "amd64" else "x86_64"),
        ],
    )

    js_image_layer(
        name = "{}_layers".format(arch),
        binary = ":bin",
        platform = ":linux_{arch}",
        root = "/app",
    )

    oci_image(
        name = "{}_image".format(arch),
        cmd = ["/app/bin"],
        entrypoint = ["bash"],
        tars = [
            ":{}_layers".format(arch)
        ],
        workdir = select({
            "@aspect_bazel_lib//lib:bzlmod": "/app/bin.runfiles/_main",
            "//conditions:default": "/app/bin.runfiles/__main__",
        }),
    )

    for arch in ["amd64", "arm64"]
]

oci_image_index(
    name = "image",
    images = [
        ":arm64_image",
        ":amd64_image"
    ]
)
```

**An example using legacy rules_docker**

See `e2e/js_image_docker` for full example.

```starlark
load("@aspect_rules_js//js:defs.bzl", "js_binary", "js_image_layer")
load("@io_bazel_rules_docker//container:container.bzl", "container_image")

js_binary(
    name = "bin",
    data = [
        "//:node_modules/args-parser",
    ],
    entry_point = "main.js",
)

js_image_layer(
    name = "layers",
    binary = ":bin",
    root = "/app",
    visibility = ["//visibility:__pkg__"],
)

filegroup(
    name = "node_tar",
    srcs = [":layers"],
    output_group = "node",
)

container_layer(
    name = "node_layer",
    tars = [":node_tar"],
)

filegroup(
    name = "package_store_3p_tar",
    srcs = [":layers"],
    output_group = "package_store_3p",
)

container_layer(
    name = "package_store_3p_layer",
    tars = [":package_store_3p_tar"],
)

filegroup(
    name = "package_store_1p_tar",
    srcs = [":layers"],
    output_group = "package_store_1p",
)

container_layer(
    name = "package_store_1p_layer",
    tars = [":package_store_1p_tar"],
)

filegroup(
    name = "node_modules_tar",
    srcs = [":layers"],
    output_group = "node_modules",
)

container_layer(
    name = "node_modules_layer",
    tars = [":node_modules_tar"],
)

filegroup(
    name = "app_tar",
    srcs = [":layers"],
    output_group = "app",
)

container_layer(
    name = "app_layer",
    tars = [":app_tar"],
)

container_image(
    name = "image",
    cmd = ["/app/bin"],
    entrypoint = ["bash"],
    layers = [
        ":node_layer",
        ":package_store_3p_layer",
        ":package_store_1p_layer",
        ":node_modules_layer",
        ":app_layer",
    ],
    workdir = select({
        "@aspect_bazel_lib//lib:bzlmod": "/app/bin.runfiles/_main",
        "//conditions:default": "/app/bin.runfiles/__main__",
    }),
)
```


## Performance

For better performance, it is recommended to split the large parts of a `js_binary` to have a separate layer.

The matching order for layer groups is as follows:

1. `layer_groups` are checked in order first
2. If no match is found for `layer_groups`, the `default layer groups` are checked.
3. Any remaining files are placed into the app layer.

The default layer groups are as follows and always created.

```
{
    "node": "/js/private/node-patches/|/bin/nodejs/",
    "package_store_1p": "\.aspect_rules_js/.*@0\.0\.0/node_modules",
    "package_store_3p": "\.aspect_rules_js/.*/node_modules",
    "node_modules": "/node_modules/",
    "app": "", # empty means just match anything.
}
```

"�O
�D
make_js_image_layer�9Create container image layers from js_binary targets.

By design, js_image_layer doesn't have any preference over which rule assembles the container image.
This means the downstream rule (`oci_image` from [rules_oci](https://github.com/bazel-contrib/rules_oci)
or `container_image` from [rules_docker](https://github.com/bazelbuild/rules_docker)) must
set a proper `workdir` and `cmd` to for the container work.

A proper `cmd` usually looks like /`[ js_image_layer 'root' ]`/`[ package name of js_image_layer 'binary' target ]/[ name of js_image_layer 'binary' target ]`,
unless you have a custom launcher script that invokes the entry_point of the `js_binary` in a different path.

On the other hand, `workdir` has to be set to the "runfiles tree root" which would be exactly `cmd` **but with `.runfiles/[ name of the workspace ]` suffix**.
If using bzlmod then name of the local workspace is always `_main`. If bzlmod is not enabled then the name of the local workspace, if not otherwise specified
in the `WORKSPACE` file, is `__main__`. If `workdir` is not set correctly, some attributes such as `chdir` might not work properly.

js_image_layer creates up to 5 layers depending on what files are included in the runfiles of the provided
`binary` target.

1. `node` layer contains the Node.js toolchain
2. `package_store_3p` layer contains all 3p npm deps in the `node_modules/.aspect_rules_js` package store
3. `package_store_1p` layer contains all 1p npm deps in the `node_modules/.aspect_rules_js` package store
4. `node_modules` layer contains all `node_modules/*` symlinks which point into the package store
5. `app` layer contains all files that don't fall into any of the above layers

If no files are found in the runfiles of the `binary` target for one of the layers above, that
layer is not generated. All generated layer tarballs are provided as `DefaultInfo` files.

> The rules_js `node_modules/.aspect_rules_js` package store follows the same pattern as the pnpm
> `node_modules/.pnpm` virtual store. For more information see https://pnpm.io/symlinked-node-modules-structure.

js_image_layer also provides an `OutputGroupInfo` with outputs for each of the layers above which
can be used to reference an individual layer with using `filegroup` with `output_group`. For example,

```starlark
js_image_layer(
    name = "layers",
    binary = ":bin",
    root = "/app",
)

filegroup(
    name = "app_tar",
    srcs = [":layers"],
    output_group = "app",
)
```

> WARNING: The structure of the generated layers are not subject to semver guarantees and may change without a notice.
> However, it is guaranteed to work when all generated layers are provided together in the order specified above.

js_image_layer supports transitioning to specific `platform` to allow building multi-platform container images.

**A partial example using rules_oci with transition to linux/amd64 platform.**

```starlark
load("@aspect_rules_js//js:defs.bzl", "js_binary", "js_image_layer")
load("@rules_oci//oci:defs.bzl", "oci_image")

js_binary(
    name = "bin",
    entry_point = "main.js",
)

platform(
    name = "amd64_linux",
    constraint_values = [
        "@platforms//os:linux",
        "@platforms//cpu:x86_64",
    ],
)

js_image_layer(
    name = "layers",
    binary = ":bin",
    platform = ":amd64_linux",
    root = "/app",
)

oci_image(
    name = "image",
    cmd = ["/app/bin"],
    entrypoint = ["bash"],
    tars = [
        ":layers"
    ],
    workdir = select({
        "@aspect_bazel_lib//lib:bzlmod": "/app/bin.runfiles/_main",
        "//conditions:default": "/app/bin.runfiles/__main__",
    }),
)
```

**A partial example using rules_oci to create multi-platform images.**

```starlark
load("@aspect_rules_js//js:defs.bzl", "js_binary", "js_image_layer")
load("@rules_oci//oci:defs.bzl", "oci_image", "oci_image_index")

js_binary(
    name = "bin",
    entry_point = "main.js",
)

[
    platform(
        name = "linux_{}".format(arch),
        constraint_values = [
            "@platforms//os:linux",
            "@platforms//cpu:{}".format(arch if arch != "amd64" else "x86_64"),
        ],
    )

    js_image_layer(
        name = "{}_layers".format(arch),
        binary = ":bin",
        platform = ":linux_{arch}",
        root = "/app",
    )

    oci_image(
        name = "{}_image".format(arch),
        cmd = ["/app/bin"],
        entrypoint = ["bash"],
        tars = [
            ":{}_layers".format(arch)
        ],
        workdir = select({
            "@aspect_bazel_lib//lib:bzlmod": "/app/bin.runfiles/_main",
            "//conditions:default": "/app/bin.runfiles/__main__",
        }),
    )

    for arch in ["amd64", "arm64"]
]

oci_image_index(
    name = "image",
    images = [
        ":arm64_image",
        ":amd64_image"
    ]
)
```

**An example using legacy rules_docker**

See `e2e/js_image_docker` for full example.

```starlark
load("@aspect_rules_js//js:defs.bzl", "js_binary", "js_image_layer")
load("@io_bazel_rules_docker//container:container.bzl", "container_image")

js_binary(
    name = "bin",
    data = [
        "//:node_modules/args-parser",
    ],
    entry_point = "main.js",
)

js_image_layer(
    name = "layers",
    binary = ":bin",
    root = "/app",
    visibility = ["//visibility:__pkg__"],
)

filegroup(
    name = "node_tar",
    srcs = [":layers"],
    output_group = "node",
)

container_layer(
    name = "node_layer",
    tars = [":node_tar"],
)

filegroup(
    name = "package_store_3p_tar",
    srcs = [":layers"],
    output_group = "package_store_3p",
)

container_layer(
    name = "package_store_3p_layer",
    tars = [":package_store_3p_tar"],
)

filegroup(
    name = "package_store_1p_tar",
    srcs = [":layers"],
    output_group = "package_store_1p",
)

container_layer(
    name = "package_store_1p_layer",
    tars = [":package_store_1p_tar"],
)

filegroup(
    name = "node_modules_tar",
    srcs = [":layers"],
    output_group = "node_modules",
)

container_layer(
    name = "node_modules_layer",
    tars = [":node_modules_tar"],
)

filegroup(
    name = "app_tar",
    srcs = [":layers"],
    output_group = "app",
)

container_layer(
    name = "app_layer",
    tars = [":app_tar"],
)

container_image(
    name = "image",
    cmd = ["/app/bin"],
    entrypoint = ["bash"],
    layers = [
        ":node_layer",
        ":package_store_3p_layer",
        ":package_store_1p_layer",
        ":node_modules_layer",
        ":app_layer",
    ],
    workdir = select({
        "@aspect_bazel_lib//lib:bzlmod": "/app/bin.runfiles/_main",
        "//conditions:default": "/app/bin.runfiles/__main__",
    }),
)
```


## Performance

For better performance, it is recommended to split the large parts of a `js_binary` to have a separate layer.

The matching order for layer groups is as follows:

1. `layer_groups` are checked in order first
2. If no match is found for `layer_groups`, the `default layer groups` are checked.
3. Any remaining files are placed into the app layer.

The default layer groups are as follows and always created.

```
{
    "node": "/js/private/node-patches/|/bin/nodejs/",
    "package_store_1p": "\.aspect_rules_js/.*@0\.0\.0/node_modules",
    "package_store_3p": "\.aspect_rules_js/.*/node_modules",
    "node_modules": "/node_modules/",
    "app": "", # empty means just match anything.
}
```

*
nameA unique name for this target. *
binaryLabel to an js_binary target �
compression�Compression algorithm. See https://github.com/bazel-contrib/bazel-lib/blob/bdc6ade0ba1ebe88d822bcdf4d4aaa2ce7e2cd37/lib/private/tar.bzl#L29-L392"gzip"b
directory_modeFMode of the directories, in `octal` format. By default `0755` is used.2"0755"W
	file_mode@Mode of the files, in `octal` format. By default `0555` is used.2"0555"{
generate_empty_layersYDEPRECATED. An empty layer is always generated if the layer group have no matching files.2False�
layer_groups�Layer groups to create.
These are utilized to categorize files into distinct layers, determined by their respective paths.
The expected format for each entry is "<key>": "<value>", where <key> MUST be a valid Bazel and
JavaScript identifier (alphanumeric characters), and <value> MAY be either an empty string (signifying a universal match)
or a valid regular expression.
2{}c
ownerQOwner of the entries, in `GID:UID` format. By default `0:0` (root, root) is used.2"0:0"+
platformPlatform to transition.2None�
preserve_symlinkspPreserve symlinks for entries matching the pattern.
By default symlinks within the `node_modules` is preserved.
2".*/node_modules/.*"X
rootJPath where the files from js_binary will reside in. eg: /apps/app1 or /app2""
::,
*
nameA unique name for this target. ,
*
binaryLabel to an js_binary target �
�
compression�Compression algorithm. See https://github.com/bazel-contrib/bazel-lib/blob/bdc6ade0ba1ebe88d822bcdf4d4aaa2ce7e2cd37/lib/private/tar.bzl#L29-L392"gzip"d
b
directory_modeFMode of the directories, in `octal` format. By default `0755` is used.2"0755"Y
W
	file_mode@Mode of the files, in `octal` format. By default `0555` is used.2"0555"}
{
generate_empty_layersYDEPRECATED. An empty layer is always generated if the layer group have no matching files.2False�
�
layer_groups�Layer groups to create.
These are utilized to categorize files into distinct layers, determined by their respective paths.
The expected format for each entry is "<key>": "<value>", where <key> MUST be a valid Bazel and
JavaScript identifier (alphanumeric characters), and <value> MAY be either an empty string (signifying a universal match)
or a valid regular expression.
2{}e
c
ownerQOwner of the entries, in `GID:UID` format. By default `0:0` (root, root) is used.2"0:0"-
+
platformPlatform to transition.2None�
�
preserve_symlinkspPreserve symlinks for entries matching the pattern.
By default symlinks within the `node_modules` is preserved.
2".*/node_modules/.*"Z
X
rootJPath where the files from js_binary will reside in. eg: /apps/app1 or /app2""�assert_checksum*�
y
assert_checksum

name (
image_layer (2G
assert_checksum4@@aspect_rules_js//js/private/test/image:asserts.bzl
OO2native.genrule2write_source_file�assert_js_image_layer_listings*�
�
assert_js_image_layer_listings

name (
js_image_layer (
additional_layers[](2V
assert_js_image_layer_listings4@@aspect_rules_js//js/private/test/image:asserts.bzl
&&2write_source_files�assert_tar_listing*�
�
assert_tar_listing

name (
actual (
expected (2J
assert_tar_listing4@@aspect_rules_js//js/private/test/image:asserts.bzl
2write_source_file�
//lib:write_source_files.bzlr�
/
aspect_bazel_liblibwrite_source_files.bzl4
write_source_filewrite_source_file
8I6
write_source_fileswrite_source_files
M_
ar
//js:defs.bzlr_

aspect_rules_jsjsdefs.bzl.
js_image_layerjs_image_layer
(6
8U	layersjI2G
node
package_store_3p
package_store_1p
node_modules
appMake shorter assertions�:
'
aspect_rules_js
js/privatebash.bzl�9	BASH_INITIALIZE_RUNFILES�
# It helps to determine if we are running on a Windows environment (excludes WSL as it acts like Unix)
case "$(uname -s)" in
CYGWIN*) _IS_WINDOWS=1 ;;
MINGW*) _IS_WINDOWS=1 ;;
MSYS_NT*) _IS_WINDOWS=1 ;;
*) _IS_WINDOWS=0 ;;
esac

# It helps to normalizes paths when running on Windows.
#
# Example:
# C:/Users/XUser/_bazel_XUser/7q7kkv32/execroot/A/b/C -> /c/Users/XUser/_bazel_XUser/7q7kkv32/execroot/A/b/C
function _normalize_path {
    if [ "$_IS_WINDOWS" -eq "1" ]; then
        # Apply the followings paths transformations to normalize paths on Windows
        # -process driver letter
        # -convert path separator
        sed -e 's#^\(.\):#/\L\1#' -e 's#\\#/#g' <<<"$1"
    else
        echo "$1"
    fi
    return
}

# Set a RUNFILES environment variable to the root of the runfiles tree
# since RUNFILES_DIR is not set by Bazel in all contexts.
# For example, `RUNFILES=/path/to/my_js_binary.sh.runfiles`.
#
# Call this program X. X was generated by a genrule and may be invoked
# in many ways:
#   1a) directly by a user, with $0 in the output tree
#   1b) via 'bazel run' (similar to case 1a)
#   2) directly by a user, with $0 in X's runfiles
#   3) by another program Y which has a data dependency on X, with $0 in Y's
#      runfiles
#   4a) via 'bazel test'
#   4b) case 3 in the context of a test
#   5a) by a genrule cmd, with $0 in the output tree
#   6a) case 3 in the context of a genrule
#
# For case 1, $0 will be a regular file, and the runfiles will be
# at $0.runfiles.
# For case 2 or 3, $0 will be a symlink to the file seen in case 1.
# For case 4, $TEST_SRCDIR should already be set to the runfiles by
# blaze.
# Case 5a is handled like case 1.
# Case 6a is handled like case 3.
if [ "${TEST_SRCDIR:-}" ]; then
    # Case 4, bazel has identified runfiles for us.
    RUNFILES=$(_normalize_path "$TEST_SRCDIR")
elif [ "${RUNFILES_MANIFEST_FILE:-}" ]; then
    RUNFILES=$(_normalize_path "$RUNFILES_MANIFEST_FILE")
    if [[ "${RUNFILES}" == *.runfiles_manifest ]]; then
        # Newer versions of Bazel put the manifest besides the runfiles with the suffix .runfiles_manifest.
        # For example, the runfiles directory is named my_binary.runfiles then the manifest is beside the
        # runfiles directory and named my_binary.runfiles_manifest
        RUNFILES=${RUNFILES%_manifest}
    elif [[ "${RUNFILES}" == */MANIFEST ]]; then
        # Older versions of Bazel put the manifest file named MANIFEST in the runfiles directory
        RUNFILES=${RUNFILES%/MANIFEST}
    else
        logf_fatal "Unexpected RUNFILES_MANIFEST_FILE value $RUNFILES_MANIFEST_FILE"
        exit 1
    fi
else
    case "$0" in
    /*) self="$0" ;;
    *) self="$PWD/$0" ;;
    esac
    while true; do
        if [ -e "$self.runfiles" ]; then
            RUNFILES="$self.runfiles"
            break
        fi

        if [[ "$self" == *.runfiles/* ]]; then
            RUNFILES="${self%%.runfiles/*}.runfiles"
            # don't break; this is a last resort for case 6b
        fi

        if [ ! -L "$self" ]; then
            break
        fi

        readlink="$(readlink "$self")"
        if [[ "$readlink" == /* ]]; then
            self="$readlink"
        else
            # resolve relative symlink
            self="${self%%/*}/$readlink"
        fi
    done

    if [ -z "${RUNFILES:-}" ]; then
        logf_fatal "RUNFILES environment variable is not set"
        exit 1
    fi

    RUNFILES=$(_normalize_path "$RUNFILES")
fi
if [ "${RUNFILES:0:1}" != "/" ]; then
    # Ensure RUNFILES set above is an absolute path. It may be a path relative
    # to the PWD in case where RUNFILES_MANIFEST_FILE is used above.
    RUNFILES="$PWD/$RUNFILES"
fi
j��
# It helps to determine if we are running on a Windows environment (excludes WSL as it acts like Unix)
case "$(uname -s)" in
CYGWIN*) _IS_WINDOWS=1 ;;
MINGW*) _IS_WINDOWS=1 ;;
MSYS_NT*) _IS_WINDOWS=1 ;;
*) _IS_WINDOWS=0 ;;
esac

# It helps to normalizes paths when running on Windows.
#
# Example:
# C:/Users/XUser/_bazel_XUser/7q7kkv32/execroot/A/b/C -> /c/Users/XUser/_bazel_XUser/7q7kkv32/execroot/A/b/C
function _normalize_path {
    if [ "$_IS_WINDOWS" -eq "1" ]; then
        # Apply the followings paths transformations to normalize paths on Windows
        # -process driver letter
        # -convert path separator
        sed -e 's#^\(.\):#/\L\1#' -e 's#\\#/#g' <<<"$1"
    else
        echo "$1"
    fi
    return
}

# Set a RUNFILES environment variable to the root of the runfiles tree
# since RUNFILES_DIR is not set by Bazel in all contexts.
# For example, `RUNFILES=/path/to/my_js_binary.sh.runfiles`.
#
# Call this program X. X was generated by a genrule and may be invoked
# in many ways:
#   1a) directly by a user, with $0 in the output tree
#   1b) via 'bazel run' (similar to case 1a)
#   2) directly by a user, with $0 in X's runfiles
#   3) by another program Y which has a data dependency on X, with $0 in Y's
#      runfiles
#   4a) via 'bazel test'
#   4b) case 3 in the context of a test
#   5a) by a genrule cmd, with $0 in the output tree
#   6a) case 3 in the context of a genrule
#
# For case 1, $0 will be a regular file, and the runfiles will be
# at $0.runfiles.
# For case 2 or 3, $0 will be a symlink to the file seen in case 1.
# For case 4, $TEST_SRCDIR should already be set to the runfiles by
# blaze.
# Case 5a is handled like case 1.
# Case 6a is handled like case 3.
if [ "${TEST_SRCDIR:-}" ]; then
    # Case 4, bazel has identified runfiles for us.
    RUNFILES=$(_normalize_path "$TEST_SRCDIR")
elif [ "${RUNFILES_MANIFEST_FILE:-}" ]; then
    RUNFILES=$(_normalize_path "$RUNFILES_MANIFEST_FILE")
    if [[ "${RUNFILES}" == *.runfiles_manifest ]]; then
        # Newer versions of Bazel put the manifest besides the runfiles with the suffix .runfiles_manifest.
        # For example, the runfiles directory is named my_binary.runfiles then the manifest is beside the
        # runfiles directory and named my_binary.runfiles_manifest
        RUNFILES=${RUNFILES%_manifest}
    elif [[ "${RUNFILES}" == */MANIFEST ]]; then
        # Older versions of Bazel put the manifest file named MANIFEST in the runfiles directory
        RUNFILES=${RUNFILES%/MANIFEST}
    else
        logf_fatal "Unexpected RUNFILES_MANIFEST_FILE value $RUNFILES_MANIFEST_FILE"
        exit 1
    fi
else
    case "$0" in
    /*) self="$0" ;;
    *) self="$PWD/$0" ;;
    esac
    while true; do
        if [ -e "$self.runfiles" ]; then
            RUNFILES="$self.runfiles"
            break
        fi

        if [[ "$self" == *.runfiles/* ]]; then
            RUNFILES="${self%%.runfiles/*}.runfiles"
            # don't break; this is a last resort for case 6b
        fi

        if [ ! -L "$self" ]; then
            break
        fi

        readlink="$(readlink "$self")"
        if [[ "$readlink" == /* ]]; then
            self="$readlink"
        else
            # resolve relative symlink
            self="${self%%/*}/$readlink"
        fi
    done

    if [ -z "${RUNFILES:-}" ]; then
        logf_fatal "RUNFILES environment variable is not set"
        exit 1
    fi

    RUNFILES=$(_normalize_path "$RUNFILES")
fi
if [ "${RUNFILES:0:1}" != "/" ]; then
    # Ensure RUNFILES set above is an absolute path. It may be a path relative
    # to the PWD in case where RUNFILES_MANIFEST_FILE is used above.
    RUNFILES="$PWD/$RUNFILES"
fi
Bash snippets for js rules��
,
aspect_rules_js
js/privatejs_binary.bzl��	js_binary�Execute a program in the Node.js runtime.

The version of Node.js is determined by Bazel's toolchain selection. In the WORKSPACE you used
`nodejs_register_toolchains` to provide options to Bazel. Then Bazel selects from these options
based on the requested target platform. Use the
[`--toolchain_resolution_debug`](https://docs.bazel.build/versions/main/command-line-reference.html#flag--toolchain_resolution_debug)
Bazel option to see more detail about the selection.

All [common binary attributes](https://bazel.build/reference/be/common-definitions#common-attributes-binaries) are supported
including `args` as the list of arguments passed Node.js.

Node.js execution is performed by a shell script that sets environment variables and runs the Node.js binary with the `entry_point` script.
The shell script is located relative to the directory containing the `js_binary` at `\{name\}_/\{name\}` similar to other rulesets
such as rules_go. See [PR #1690](https://github.com/aspect-build/rules_js/pull/1690) for more information on this naming scheme.

The following environment variables are made available to the Node.js runtime based on available Bazel [Make variables](https://bazel.build/reference/be/make-variables#predefined_variables):

* JS_BINARY__BINDIR: the WORKSPACE-relative Bazel bin directory; equivalent to the `$(BINDIR)` Make variable of the `js_binary` target
* JS_BINARY__COMPILATION_MODE: One of `fastbuild`, `dbg`, or `opt` as set by [`--compilation_mode`](https://bazel.build/docs/user-manual#compilation-mode); equivalent to `$(COMPILATION_MODE)` Make variable of the `js_binary` target
* JS_BINARY__TARGET_CPU: the target cpu architecture; equivalent to `$(TARGET_CPU)` Make variable of the `js_binary` target

The following environment variables are made available to the Node.js runtime based on the rule context:

* JS_BINARY__BUILD_FILE_PATH: the WORKSPACE-relative path to the BUILD file of the Bazel target being run; equivalent to `ctx.build_file_path` of the `js_binary` target's rule context
* JS_BINARY__PACKAGE: the package of the Bazel target being run; equivalent to `ctx.label.package` of the `js_binary` target's rule context
* JS_BINARY__TARGET: the full label of the Bazel target being run; a stringified version of `ctx.label` of the `js_binary` target's rule context
* JS_BINARY__TARGET_NAME: the name of the Bazel target being run; equivalent to `ctx.label.name` of the `js_binary` target's rule context
* JS_BINARY__WORKSPACE: the Bazel workspace name; equivalent to `ctx.workspace_name` of the `js_binary` target's rule context

The following environment variables are made available to the Node.js runtime based the runtime environment:

* JS_BINARY__NODE_BINARY: the Node.js binary path run by the `js_binary` target
* JS_BINARY__NPM_BINARY: the npm binary path; this is available when [`include_npm`](https://docs.aspect.build/rules/aspect_rules_js/docs/js_binary#include_npm) is `True` on the `js_binary` target
* JS_BINARY__NODE_WRAPPER: the Node.js wrapper script used to run Node.js which is available as `node` on the `PATH` at runtime
* JS_BINARY__RUNFILES: the absolute path to the Bazel runfiles directory
* JS_BINARY__EXECROOT: the absolute path to the root of the execution root for the action; if in the sandbox, this path absolute path to the root of the execution root within the sandbox
"��
�e
	js_binary�Execute a program in the Node.js runtime.

The version of Node.js is determined by Bazel's toolchain selection. In the WORKSPACE you used
`nodejs_register_toolchains` to provide options to Bazel. Then Bazel selects from these options
based on the requested target platform. Use the
[`--toolchain_resolution_debug`](https://docs.bazel.build/versions/main/command-line-reference.html#flag--toolchain_resolution_debug)
Bazel option to see more detail about the selection.

All [common binary attributes](https://bazel.build/reference/be/common-definitions#common-attributes-binaries) are supported
including `args` as the list of arguments passed Node.js.

Node.js execution is performed by a shell script that sets environment variables and runs the Node.js binary with the `entry_point` script.
The shell script is located relative to the directory containing the `js_binary` at `\{name\}_/\{name\}` similar to other rulesets
such as rules_go. See [PR #1690](https://github.com/aspect-build/rules_js/pull/1690) for more information on this naming scheme.

The following environment variables are made available to the Node.js runtime based on available Bazel [Make variables](https://bazel.build/reference/be/make-variables#predefined_variables):

* JS_BINARY__BINDIR: the WORKSPACE-relative Bazel bin directory; equivalent to the `$(BINDIR)` Make variable of the `js_binary` target
* JS_BINARY__COMPILATION_MODE: One of `fastbuild`, `dbg`, or `opt` as set by [`--compilation_mode`](https://bazel.build/docs/user-manual#compilation-mode); equivalent to `$(COMPILATION_MODE)` Make variable of the `js_binary` target
* JS_BINARY__TARGET_CPU: the target cpu architecture; equivalent to `$(TARGET_CPU)` Make variable of the `js_binary` target

The following environment variables are made available to the Node.js runtime based on the rule context:

* JS_BINARY__BUILD_FILE_PATH: the WORKSPACE-relative path to the BUILD file of the Bazel target being run; equivalent to `ctx.build_file_path` of the `js_binary` target's rule context
* JS_BINARY__PACKAGE: the package of the Bazel target being run; equivalent to `ctx.label.package` of the `js_binary` target's rule context
* JS_BINARY__TARGET: the full label of the Bazel target being run; a stringified version of `ctx.label` of the `js_binary` target's rule context
* JS_BINARY__TARGET_NAME: the name of the Bazel target being run; equivalent to `ctx.label.name` of the `js_binary` target's rule context
* JS_BINARY__WORKSPACE: the Bazel workspace name; equivalent to `ctx.workspace_name` of the `js_binary` target's rule context

The following environment variables are made available to the Node.js runtime based the runtime environment:

* JS_BINARY__NODE_BINARY: the Node.js binary path run by the `js_binary` target
* JS_BINARY__NPM_BINARY: the npm binary path; this is available when [`include_npm`](https://docs.aspect.build/rules/aspect_rules_js/docs/js_binary#include_npm) is `True` on the `js_binary` target
* JS_BINARY__NODE_WRAPPER: the Node.js wrapper script used to run Node.js which is available as `node` on the `PATH` at runtime
* JS_BINARY__RUNFILES: the absolute path to the Bazel runfiles directory
* JS_BINARY__EXECROOT: the absolute path to the root of the execution root for the action; if in the sandbox, this path absolute path to the root of the execution root within the sandbox
*
nameA unique name for this target. �
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/"))) + "$(rootpath //path/to/some:file)"],
)
```2""�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

NB: `data` files are copied to the Bazel output tree before being passed
as inputs to runfiles. See `copy_data_to_bin` docstring for more info.
2[]�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/bazel-contrib/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 �
env�Environment variables of the action.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_env` is set to True.

2{}�
expand_args�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `fixed_args`.

This comes at some analysis-time cost even for a set of args that does not have any expansions.2True�

expand_env�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `env`.

This comes at some analysis-time cost even for a set of envs that does not have any expansions.2Truei
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�

fixed_args�Fixed command line arguments to pass to the Node.js when this
binary target is executed.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_args` is set to True.

Unlike the built-in `args`, which are only passed to the target when it is
executed either by the `bazel run` command or as a test, `fixed_args` are baked
into the generated launcher script so are always passed even when the binary
target is run outside of Bazel directly from the launcher script.

`fixed_args` are passed before the ones specified in `args` and before ones
that are specified on the `bazel run` or `bazel test` command line.

See https://bazel.build/reference/be/common-definitions#common-attributes-binaries
for more info on the built-in `args` attribute.
2[]�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
include_npm_sources�When True, files in `npm_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in `data` targets are also included in the runfiles of the target.
2True�
include_sourcesjWhen True, `sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
include_transitive_sourcesuWhen True, `transitive_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
include_transitive_types�When True, `transitive_types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
include_types�When True, `types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.

NB: These are types from direct `data` dependencies only. You may also need to set `include_transitive_types` to True.2False�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.

Log levels: fatal, error, warn, info, debug2"error"�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
node_toolchain�The Node.js toolchain to use for this target.

See https://bazel-contrib.github.io/rules_nodejs/Toolchains.html

Typically this is left unset so that Bazel automatically selects the right Node.js toolchain
for the target platform. See https://bazel.build/extending/toolchains#toolchain-resolution
for more information.
2None�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2True"8
	js_binary+@@aspect_rules_js//js/private:js_binary.bzl
��,
*
nameA unique name for this target. �
�
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/"))) + "$(rootpath //path/to/some:file)"],
)
```2""�
�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

NB: `data` files are copied to the Bazel output tree before being passed
as inputs to runfiles. See `copy_data_to_bin` docstring for more info.
2[]�
�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
�
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/bazel-contrib/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 �
�
env�Environment variables of the action.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_env` is set to True.

2{}�
�
expand_args�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `fixed_args`.

This comes at some analysis-time cost even for a set of args that does not have any expansions.2True�
�

expand_env�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `env`.

This comes at some analysis-time cost even for a set of envs that does not have any expansions.2Truek
i
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�
�

fixed_args�Fixed command line arguments to pass to the Node.js when this
binary target is executed.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_args` is set to True.

Unlike the built-in `args`, which are only passed to the target when it is
executed either by the `bazel run` command or as a test, `fixed_args` are baked
into the generated launcher script so are always passed even when the binary
target is run outside of Bazel directly from the launcher script.

`fixed_args` are passed before the ones specified in `args` and before ones
that are specified on the `bazel run` or `bazel test` command line.

See https://bazel.build/reference/be/common-definitions#common-attributes-binaries
for more info on the built-in `args` attribute.
2[]�
�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
�
include_npm_sources�When True, files in `npm_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in `data` targets are also included in the runfiles of the target.
2True�
�
include_sourcesjWhen True, `sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
�
include_transitive_sourcesuWhen True, `transitive_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
�
include_transitive_types�When True, `transitive_types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
�
include_types�When True, `types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.

NB: These are types from direct `data` dependencies only. You may also need to set `include_transitive_types` to True.2False�
�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.

Log levels: fatal, error, warn, info, debug2"error"�
�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
�
node_toolchain�The Node.js toolchain to use for this target.

See https://bazel-contrib.github.io/rules_nodejs/Toolchains.html

Typically this is left unset so that Bazel automatically selects the right Node.js toolchain
for the target platform. See https://bazel.build/extending/toolchains#toolchain-resolution
for more information.
2None�
�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2TrueӨjs_test�Identical to js_binary, but usable under `bazel test`.

All [common test attributes](https://bazel.build/reference/be/common-definitions#common-attributes-tests) are
supported including `args` as the list of arguments passed Node.js.

Bazel will set environment variables when a test target is run under `bazel test` and `bazel run`
that a test runner can use.

A runner can write arbitrary outputs files it wants Bazel to pickup and save with the test logs to
`TEST_UNDECLARED_OUTPUTS_DIR`. These get zipped up and saved along with the test logs.

JUnit XML reports can be written to `XML_OUTPUT_FILE` for Bazel to consume.

`TEST_TMPDIR` is an absolute path to a private writeable directory that the test runner can use for
creating temporary files.

LCOV coverage reports can be written to `COVERAGE_OUTPUT_FILE` when running under `bazel coverage`
or if the `--coverage` flag is set.

See the Bazel [Test encyclopedia](https://bazel.build/reference/test-encyclopedia) for details on
the contract between Bazel and a test runner."��
�T
js_test�Identical to js_binary, but usable under `bazel test`.

All [common test attributes](https://bazel.build/reference/be/common-definitions#common-attributes-tests) are
supported including `args` as the list of arguments passed Node.js.

Bazel will set environment variables when a test target is run under `bazel test` and `bazel run`
that a test runner can use.

A runner can write arbitrary outputs files it wants Bazel to pickup and save with the test logs to
`TEST_UNDECLARED_OUTPUTS_DIR`. These get zipped up and saved along with the test logs.

JUnit XML reports can be written to `XML_OUTPUT_FILE` for Bazel to consume.

`TEST_TMPDIR` is an absolute path to a private writeable directory that the test runner can use for
creating temporary files.

LCOV coverage reports can be written to `COVERAGE_OUTPUT_FILE` when running under `bazel coverage`
or if the `--coverage` flag is set.

See the Bazel [Test encyclopedia](https://bazel.build/reference/test-encyclopedia) for details on
the contract between Bazel and a test runner.*
nameA unique name for this target. �
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/"))) + "$(rootpath //path/to/some:file)"],
)
```2""�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

NB: `data` files are copied to the Bazel output tree before being passed
as inputs to runfiles. See `copy_data_to_bin` docstring for more info.
2[]�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/bazel-contrib/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 �
env�Environment variables of the action.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_env` is set to True.

2{}�
env_inherit|Specifies additional environment variables to inherit from the external environment when the test is executed by bazel test.2[]�
expand_args�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `fixed_args`.

This comes at some analysis-time cost even for a set of args that does not have any expansions.2True�

expand_env�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `env`.

This comes at some analysis-time cost even for a set of envs that does not have any expansions.2Truei
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�

fixed_args�Fixed command line arguments to pass to the Node.js when this
binary target is executed.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_args` is set to True.

Unlike the built-in `args`, which are only passed to the target when it is
executed either by the `bazel run` command or as a test, `fixed_args` are baked
into the generated launcher script so are always passed even when the binary
target is run outside of Bazel directly from the launcher script.

`fixed_args` are passed before the ones specified in `args` and before ones
that are specified on the `bazel run` or `bazel test` command line.

See https://bazel.build/reference/be/common-definitions#common-attributes-binaries
for more info on the built-in `args` attribute.
2[]�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
include_npm_sources�When True, files in `npm_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in `data` targets are also included in the runfiles of the target.
2True�
include_sourcesjWhen True, `sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
include_transitive_sourcesuWhen True, `transitive_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
include_transitive_types�When True, `transitive_types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
include_types�When True, `types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.

NB: These are types from direct `data` dependencies only. You may also need to set `include_transitive_types` to True.2False�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.

Log levels: fatal, error, warn, info, debug2"error"�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
node_toolchain�The Node.js toolchain to use for this target.

See https://bazel-contrib.github.io/rules_nodejs/Toolchains.html

Typically this is left unset so that Bazel automatically selects the right Node.js toolchain
for the target platform. See https://bazel.build/extending/toolchains#toolchain-resolution
for more information.
2None�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2True"6
js_test+@@aspect_rules_js//js/private:js_binary.bzl
��,
*
nameA unique name for this target. �
�
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/"))) + "$(rootpath //path/to/some:file)"],
)
```2""�
�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

NB: `data` files are copied to the Bazel output tree before being passed
as inputs to runfiles. See `copy_data_to_bin` docstring for more info.
2[]�
�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
�
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/bazel-contrib/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 �
�
env�Environment variables of the action.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_env` is set to True.

2{}�
�
env_inherit|Specifies additional environment variables to inherit from the external environment when the test is executed by bazel test.2[]�
�
expand_args�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `fixed_args`.

This comes at some analysis-time cost even for a set of args that does not have any expansions.2True�
�

expand_env�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `env`.

This comes at some analysis-time cost even for a set of envs that does not have any expansions.2Truek
i
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�
�

fixed_args�Fixed command line arguments to pass to the Node.js when this
binary target is executed.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_args` is set to True.

Unlike the built-in `args`, which are only passed to the target when it is
executed either by the `bazel run` command or as a test, `fixed_args` are baked
into the generated launcher script so are always passed even when the binary
target is run outside of Bazel directly from the launcher script.

`fixed_args` are passed before the ones specified in `args` and before ones
that are specified on the `bazel run` or `bazel test` command line.

See https://bazel.build/reference/be/common-definitions#common-attributes-binaries
for more info on the built-in `args` attribute.
2[]�
�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
�
include_npm_sources�When True, files in `npm_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in `data` targets are also included in the runfiles of the target.
2True�
�
include_sourcesjWhen True, `sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
�
include_transitive_sourcesuWhen True, `transitive_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
�
include_transitive_types�When True, `transitive_types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
�
include_types�When True, `types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.

NB: These are types from direct `data` dependencies only. You may also need to set `include_transitive_types` to True.2False�
�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.

Log levels: fatal, error, warn, info, debug2"error"�
�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
�
node_toolchain�The Node.js toolchain to use for this target.

See https://bazel-contrib.github.io/rules_nodejs/Toolchains.html

Typically this is left unset so that Bazel automatically selects the right Node.js toolchain
for the target platform. See https://bazel.build/extending/toolchains#toolchain-resolution
for more information.
2None�
�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2True�
//lib:copy_to_bin.bzlr�
(
aspect_bazel_liblibcopy_to_bin.bzlH
COPY_FILE_TO_BIN_TOOLCHAINSCOPY_FILE_TO_BIN_TOOLCHAINS
1L
N�
//lib:directory_path.bzlrq
+
aspect_bazel_liblibdirectory_path.bzl4
DirectoryPathInfoDirectoryPathInfo
4E
G�
//lib:expand_make_vars.bzlr�
-
aspect_bazel_liblibexpand_make_vars.bzl2
expand_locationsexpand_locations
6F2
expand_variablesexpand_variables
JZ
\�
//lib:windows_utils.bzlr�
*
aspect_bazel_liblibwindows_utils.bzl\
%create_windows_native_launcher_script%create_windows_native_launcher_script
3X
Z�
//js/private:bash.bzlr{
'
aspect_rules_js
js/privatebash.bzlB
BASH_INITIALIZE_RUNFILESBASH_INITIALIZE_RUNFILES
0H
J�
//js/private:js_helpers.bzlr�
-
aspect_rules_js
js/privatejs_helpers.bzl&

LOG_LEVELS
LOG_LEVELS
6@6
envs_for_log_levelenvs_for_log_level
DV0
gather_runfilesgather_runfiles
Zi
k�Rules for running JavaScript programs under Bazel, as tools or with `bazel run` or `bazel test`.

For example, this binary references the `acorn` npm package which was already linked
using an API like `npm_link_all_packages`.

```starlark
load("@aspect_rules_js//js:defs.bzl", "js_binary", "js_test")

js_binary(
    name = "bin",
    # Reference the location where the acorn npm module was linked in the root Bazel package
    data = ["//:node_modules/acorn"],
    entry_point = "require_acorn.js",
)
```
�/
-
aspect_rules_js
js/privatejs_helpers.bzl�copy_js_file_to_bin_action*�

copy_js_file_to_bin_action	
ctx (

file (2J
copy_js_file_to_bin_action,@@aspect_rules_js//js/private:js_helpers.bzl
MM�envs_for_log_levelAReturns a list environment variables to set for a given log level*�
�
envs_for_log_level+
	log_levelThe log level string value (AReturns a list environment variables to set for a given log level"�
�A list of environment variables to set to turn on the js_binary runtime
logs for the given log level. Typically, they are each set to "1".2B
envs_for_log_level,@@aspect_rules_js//js/private:js_helpers.bzl
���gather_files_from_js_infos$Gathers files from JsInfo providers.*�
�
gather_files_from_js_infos,
targetslist of target to gather from (6
include_sourcessee js_info_files documentation (4
include_typessee js_info_files documentation (A
include_transitive_sourcessee js_info_files documentation (?
include_transitive_typessee js_info_files documentation (:
include_npm_sourcessee js_info_files documentation ($Gathers files from JsInfo providers."
A depset of files2J
gather_files_from_js_infos,@@aspect_rules_js//js/private:js_helpers.bzl
���gather_npm_package_store_infos>Gathers NpmPackageStoreInfo providers from the list of targets*�
�
gather_npm_package_store_infos1
targets"the list of targets to gather from (>Gathers NpmPackageStoreInfo providers from the list of targets")
'A depset of npm package stores gathered2N
gather_npm_package_store_infos,@@aspect_rules_js//js/private:js_helpers.bzl
::�gather_npm_sources8Gathers npm sources from a list of srcs and deps targets*�
�
gather_npm_sourcesc
srcsWsource targets; these typically come from the `srcs` and/or `data` attributes of a rule (Q
depsEdep targets; these typically come from the `deps` attribute of a rule (8Gathers npm sources from a list of srcs and deps targets"
Depset of npm sources2B
gather_npm_sources,@@aspect_rules_js//js/private:js_helpers.bzl
))�gather_runfiles�Creates a runfiles object containing files in `sources`, default outputs from `data` and transitive runfiles from `data` & `deps`.

As a defense in depth against `data` & `deps` targets not supplying all required runfiles, also
gathers the transitive sources & transitive npm sources from the `JsInfo` providers of
`data` & `deps` targets.

See https://bazel.build/extending/rules#runfiles for more info on providing runfiles in build rules.
*�
�
gather_runfiles
ctxthe rule context (>
sources+depset which should be included in runfilesNone(�
data�list of data targets; default outputs and transitive runfiles are gather from these targets

See https://bazel.build/reference/be/common-definitions#typical.data and
https://bazel.build/concepts/dependencies#data-dependencies for more info and guidance
on common usage of the `data` attribute in build rules.[](`
depsRlist of dependency targets; only transitive runfiles are gather from these targets[](�

data_files�a list of data files which should be included in runfiles

Data files that are source files are copied to the Bazel output tree when
`copy_data_files_to_bin` is set to `True`.[](�
copy_data_files_to_binWhen True, `data` files that are source files and are copied to the
Bazel output tree before being passed to returned runfiles.False(�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_data_files_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_files_to_bin` docstring for more info.[](:
include_sourcessee js_info_files documentationTrue(9
include_typessee js_info_files documentationFalse(E
include_transitive_sourcessee js_info_files documentationTrue(D
include_transitive_typessee js_info_files documentationFalse(>
include_npm_sourcessee js_info_files documentationTrue(�Creates a runfiles object containing files in `sources`, default outputs from `data` and transitive runfiles from `data` & `deps`.

As a defense in depth against `data` & `deps` targets not supplying all required runfiles, also
gathers the transitive sources & transitive npm sources from the `JsInfo` providers of
`data` & `deps` targets.

See https://bazel.build/extending/rules#runfiles for more info on providing runfiles in build rules.
"�
�A [runfiles](https://bazel.build/rules/lib/runfiles) object created with [ctx.runfiles](https://bazel.build/rules/lib/ctx#runfiles).2?
gather_runfiles,@@aspect_rules_js//js/private:js_helpers.bzl
qq�gather_transitive_sourcesDGathers transitive sources from a list of direct sources and targets*�
�
gather_transitive_sourcesV
sourcesGlist of direct sources which should be included in `transitive_sources` (K
targets<list of targets to gather `transitive_sources` from `JsInfo` (DGathers transitive sources from a list of direct sources and targets" 
A depset of transitive sources2I
gather_transitive_sources,@@aspect_rules_js//js/private:js_helpers.bzl
�gather_transitive_types@Gathers transitive types from a list of direct types and targets*�
�
gather_transitive_typesR
typesElist of direct sources which should be included in `transitive_types` (I
targets:list of targets to gather `transitive_types` from `JsInfo` (@Gathers transitive types from a list of direct types and targets" 
A depset of transitive sources2G
gather_transitive_types,@@aspect_rules_js//js/private:js_helpers.bzl
�
//lib:copy_to_bin.bzlrz
(
aspect_bazel_liblibcopy_to_bin.bzl@
copy_file_to_bin_actioncopy_file_to_bin_action
1H
Jx
//js/private:js_info.bzlrZ
*
aspect_rules_js
js/privatejs_info.bzl
JsInfoJsInfo
39
;`js_library` helper functions.
�
1
aspect_rules_js
js/privatejs_image_layer.bzl��js_image_layer�9Create container image layers from js_binary targets.

By design, js_image_layer doesn't have any preference over which rule assembles the container image.
This means the downstream rule (`oci_image` from [rules_oci](https://github.com/bazel-contrib/rules_oci)
or `container_image` from [rules_docker](https://github.com/bazelbuild/rules_docker)) must
set a proper `workdir` and `cmd` to for the container work.

A proper `cmd` usually looks like /`[ js_image_layer 'root' ]`/`[ package name of js_image_layer 'binary' target ]/[ name of js_image_layer 'binary' target ]`,
unless you have a custom launcher script that invokes the entry_point of the `js_binary` in a different path.

On the other hand, `workdir` has to be set to the "runfiles tree root" which would be exactly `cmd` **but with `.runfiles/[ name of the workspace ]` suffix**.
If using bzlmod then name of the local workspace is always `_main`. If bzlmod is not enabled then the name of the local workspace, if not otherwise specified
in the `WORKSPACE` file, is `__main__`. If `workdir` is not set correctly, some attributes such as `chdir` might not work properly.

js_image_layer creates up to 5 layers depending on what files are included in the runfiles of the provided
`binary` target.

1. `node` layer contains the Node.js toolchain
2. `package_store_3p` layer contains all 3p npm deps in the `node_modules/.aspect_rules_js` package store
3. `package_store_1p` layer contains all 1p npm deps in the `node_modules/.aspect_rules_js` package store
4. `node_modules` layer contains all `node_modules/*` symlinks which point into the package store
5. `app` layer contains all files that don't fall into any of the above layers

If no files are found in the runfiles of the `binary` target for one of the layers above, that
layer is not generated. All generated layer tarballs are provided as `DefaultInfo` files.

> The rules_js `node_modules/.aspect_rules_js` package store follows the same pattern as the pnpm
> `node_modules/.pnpm` virtual store. For more information see https://pnpm.io/symlinked-node-modules-structure.

js_image_layer also provides an `OutputGroupInfo` with outputs for each of the layers above which
can be used to reference an individual layer with using `filegroup` with `output_group`. For example,

```starlark
js_image_layer(
    name = "layers",
    binary = ":bin",
    root = "/app",
)

filegroup(
    name = "app_tar",
    srcs = [":layers"],
    output_group = "app",
)
```

> WARNING: The structure of the generated layers are not subject to semver guarantees and may change without a notice.
> However, it is guaranteed to work when all generated layers are provided together in the order specified above.

js_image_layer supports transitioning to specific `platform` to allow building multi-platform container images.

**A partial example using rules_oci with transition to linux/amd64 platform.**

```starlark
load("@aspect_rules_js//js:defs.bzl", "js_binary", "js_image_layer")
load("@rules_oci//oci:defs.bzl", "oci_image")

js_binary(
    name = "bin",
    entry_point = "main.js",
)

platform(
    name = "amd64_linux",
    constraint_values = [
        "@platforms//os:linux",
        "@platforms//cpu:x86_64",
    ],
)

js_image_layer(
    name = "layers",
    binary = ":bin",
    platform = ":amd64_linux",
    root = "/app",
)

oci_image(
    name = "image",
    cmd = ["/app/bin"],
    entrypoint = ["bash"],
    tars = [
        ":layers"
    ],
    workdir = select({
        "@aspect_bazel_lib//lib:bzlmod": "/app/bin.runfiles/_main",
        "//conditions:default": "/app/bin.runfiles/__main__",
    }),
)
```

**A partial example using rules_oci to create multi-platform images.**

```starlark
load("@aspect_rules_js//js:defs.bzl", "js_binary", "js_image_layer")
load("@rules_oci//oci:defs.bzl", "oci_image", "oci_image_index")

js_binary(
    name = "bin",
    entry_point = "main.js",
)

[
    platform(
        name = "linux_{}".format(arch),
        constraint_values = [
            "@platforms//os:linux",
            "@platforms//cpu:{}".format(arch if arch != "amd64" else "x86_64"),
        ],
    )

    js_image_layer(
        name = "{}_layers".format(arch),
        binary = ":bin",
        platform = ":linux_{arch}",
        root = "/app",
    )

    oci_image(
        name = "{}_image".format(arch),
        cmd = ["/app/bin"],
        entrypoint = ["bash"],
        tars = [
            ":{}_layers".format(arch)
        ],
        workdir = select({
            "@aspect_bazel_lib//lib:bzlmod": "/app/bin.runfiles/_main",
            "//conditions:default": "/app/bin.runfiles/__main__",
        }),
    )

    for arch in ["amd64", "arm64"]
]

oci_image_index(
    name = "image",
    images = [
        ":arm64_image",
        ":amd64_image"
    ]
)
```

**An example using legacy rules_docker**

See `e2e/js_image_docker` for full example.

```starlark
load("@aspect_rules_js//js:defs.bzl", "js_binary", "js_image_layer")
load("@io_bazel_rules_docker//container:container.bzl", "container_image")

js_binary(
    name = "bin",
    data = [
        "//:node_modules/args-parser",
    ],
    entry_point = "main.js",
)

js_image_layer(
    name = "layers",
    binary = ":bin",
    root = "/app",
    visibility = ["//visibility:__pkg__"],
)

filegroup(
    name = "node_tar",
    srcs = [":layers"],
    output_group = "node",
)

container_layer(
    name = "node_layer",
    tars = [":node_tar"],
)

filegroup(
    name = "package_store_3p_tar",
    srcs = [":layers"],
    output_group = "package_store_3p",
)

container_layer(
    name = "package_store_3p_layer",
    tars = [":package_store_3p_tar"],
)

filegroup(
    name = "package_store_1p_tar",
    srcs = [":layers"],
    output_group = "package_store_1p",
)

container_layer(
    name = "package_store_1p_layer",
    tars = [":package_store_1p_tar"],
)

filegroup(
    name = "node_modules_tar",
    srcs = [":layers"],
    output_group = "node_modules",
)

container_layer(
    name = "node_modules_layer",
    tars = [":node_modules_tar"],
)

filegroup(
    name = "app_tar",
    srcs = [":layers"],
    output_group = "app",
)

container_layer(
    name = "app_layer",
    tars = [":app_tar"],
)

container_image(
    name = "image",
    cmd = ["/app/bin"],
    entrypoint = ["bash"],
    layers = [
        ":node_layer",
        ":package_store_3p_layer",
        ":package_store_1p_layer",
        ":node_modules_layer",
        ":app_layer",
    ],
    workdir = select({
        "@aspect_bazel_lib//lib:bzlmod": "/app/bin.runfiles/_main",
        "//conditions:default": "/app/bin.runfiles/__main__",
    }),
)
```


## Performance

For better performance, it is recommended to split the large parts of a `js_binary` to have a separate layer.

The matching order for layer groups is as follows:

1. `layer_groups` are checked in order first
2. If no match is found for `layer_groups`, the `default layer groups` are checked.
3. Any remaining files are placed into the app layer.

The default layer groups are as follows and always created.

```
{
    "node": "/js/private/node-patches/|/bin/nodejs/",
    "package_store_1p": "\.aspect_rules_js/.*@0\.0\.0/node_modules",
    "package_store_3p": "\.aspect_rules_js/.*/node_modules",
    "node_modules": "/node_modules/",
    "app": "", # empty means just match anything.
}
```

"�O
�D
js_image_layer�9Create container image layers from js_binary targets.

By design, js_image_layer doesn't have any preference over which rule assembles the container image.
This means the downstream rule (`oci_image` from [rules_oci](https://github.com/bazel-contrib/rules_oci)
or `container_image` from [rules_docker](https://github.com/bazelbuild/rules_docker)) must
set a proper `workdir` and `cmd` to for the container work.

A proper `cmd` usually looks like /`[ js_image_layer 'root' ]`/`[ package name of js_image_layer 'binary' target ]/[ name of js_image_layer 'binary' target ]`,
unless you have a custom launcher script that invokes the entry_point of the `js_binary` in a different path.

On the other hand, `workdir` has to be set to the "runfiles tree root" which would be exactly `cmd` **but with `.runfiles/[ name of the workspace ]` suffix**.
If using bzlmod then name of the local workspace is always `_main`. If bzlmod is not enabled then the name of the local workspace, if not otherwise specified
in the `WORKSPACE` file, is `__main__`. If `workdir` is not set correctly, some attributes such as `chdir` might not work properly.

js_image_layer creates up to 5 layers depending on what files are included in the runfiles of the provided
`binary` target.

1. `node` layer contains the Node.js toolchain
2. `package_store_3p` layer contains all 3p npm deps in the `node_modules/.aspect_rules_js` package store
3. `package_store_1p` layer contains all 1p npm deps in the `node_modules/.aspect_rules_js` package store
4. `node_modules` layer contains all `node_modules/*` symlinks which point into the package store
5. `app` layer contains all files that don't fall into any of the above layers

If no files are found in the runfiles of the `binary` target for one of the layers above, that
layer is not generated. All generated layer tarballs are provided as `DefaultInfo` files.

> The rules_js `node_modules/.aspect_rules_js` package store follows the same pattern as the pnpm
> `node_modules/.pnpm` virtual store. For more information see https://pnpm.io/symlinked-node-modules-structure.

js_image_layer also provides an `OutputGroupInfo` with outputs for each of the layers above which
can be used to reference an individual layer with using `filegroup` with `output_group`. For example,

```starlark
js_image_layer(
    name = "layers",
    binary = ":bin",
    root = "/app",
)

filegroup(
    name = "app_tar",
    srcs = [":layers"],
    output_group = "app",
)
```

> WARNING: The structure of the generated layers are not subject to semver guarantees and may change without a notice.
> However, it is guaranteed to work when all generated layers are provided together in the order specified above.

js_image_layer supports transitioning to specific `platform` to allow building multi-platform container images.

**A partial example using rules_oci with transition to linux/amd64 platform.**

```starlark
load("@aspect_rules_js//js:defs.bzl", "js_binary", "js_image_layer")
load("@rules_oci//oci:defs.bzl", "oci_image")

js_binary(
    name = "bin",
    entry_point = "main.js",
)

platform(
    name = "amd64_linux",
    constraint_values = [
        "@platforms//os:linux",
        "@platforms//cpu:x86_64",
    ],
)

js_image_layer(
    name = "layers",
    binary = ":bin",
    platform = ":amd64_linux",
    root = "/app",
)

oci_image(
    name = "image",
    cmd = ["/app/bin"],
    entrypoint = ["bash"],
    tars = [
        ":layers"
    ],
    workdir = select({
        "@aspect_bazel_lib//lib:bzlmod": "/app/bin.runfiles/_main",
        "//conditions:default": "/app/bin.runfiles/__main__",
    }),
)
```

**A partial example using rules_oci to create multi-platform images.**

```starlark
load("@aspect_rules_js//js:defs.bzl", "js_binary", "js_image_layer")
load("@rules_oci//oci:defs.bzl", "oci_image", "oci_image_index")

js_binary(
    name = "bin",
    entry_point = "main.js",
)

[
    platform(
        name = "linux_{}".format(arch),
        constraint_values = [
            "@platforms//os:linux",
            "@platforms//cpu:{}".format(arch if arch != "amd64" else "x86_64"),
        ],
    )

    js_image_layer(
        name = "{}_layers".format(arch),
        binary = ":bin",
        platform = ":linux_{arch}",
        root = "/app",
    )

    oci_image(
        name = "{}_image".format(arch),
        cmd = ["/app/bin"],
        entrypoint = ["bash"],
        tars = [
            ":{}_layers".format(arch)
        ],
        workdir = select({
            "@aspect_bazel_lib//lib:bzlmod": "/app/bin.runfiles/_main",
            "//conditions:default": "/app/bin.runfiles/__main__",
        }),
    )

    for arch in ["amd64", "arm64"]
]

oci_image_index(
    name = "image",
    images = [
        ":arm64_image",
        ":amd64_image"
    ]
)
```

**An example using legacy rules_docker**

See `e2e/js_image_docker` for full example.

```starlark
load("@aspect_rules_js//js:defs.bzl", "js_binary", "js_image_layer")
load("@io_bazel_rules_docker//container:container.bzl", "container_image")

js_binary(
    name = "bin",
    data = [
        "//:node_modules/args-parser",
    ],
    entry_point = "main.js",
)

js_image_layer(
    name = "layers",
    binary = ":bin",
    root = "/app",
    visibility = ["//visibility:__pkg__"],
)

filegroup(
    name = "node_tar",
    srcs = [":layers"],
    output_group = "node",
)

container_layer(
    name = "node_layer",
    tars = [":node_tar"],
)

filegroup(
    name = "package_store_3p_tar",
    srcs = [":layers"],
    output_group = "package_store_3p",
)

container_layer(
    name = "package_store_3p_layer",
    tars = [":package_store_3p_tar"],
)

filegroup(
    name = "package_store_1p_tar",
    srcs = [":layers"],
    output_group = "package_store_1p",
)

container_layer(
    name = "package_store_1p_layer",
    tars = [":package_store_1p_tar"],
)

filegroup(
    name = "node_modules_tar",
    srcs = [":layers"],
    output_group = "node_modules",
)

container_layer(
    name = "node_modules_layer",
    tars = [":node_modules_tar"],
)

filegroup(
    name = "app_tar",
    srcs = [":layers"],
    output_group = "app",
)

container_layer(
    name = "app_layer",
    tars = [":app_tar"],
)

container_image(
    name = "image",
    cmd = ["/app/bin"],
    entrypoint = ["bash"],
    layers = [
        ":node_layer",
        ":package_store_3p_layer",
        ":package_store_1p_layer",
        ":node_modules_layer",
        ":app_layer",
    ],
    workdir = select({
        "@aspect_bazel_lib//lib:bzlmod": "/app/bin.runfiles/_main",
        "//conditions:default": "/app/bin.runfiles/__main__",
    }),
)
```


## Performance

For better performance, it is recommended to split the large parts of a `js_binary` to have a separate layer.

The matching order for layer groups is as follows:

1. `layer_groups` are checked in order first
2. If no match is found for `layer_groups`, the `default layer groups` are checked.
3. Any remaining files are placed into the app layer.

The default layer groups are as follows and always created.

```
{
    "node": "/js/private/node-patches/|/bin/nodejs/",
    "package_store_1p": "\.aspect_rules_js/.*@0\.0\.0/node_modules",
    "package_store_3p": "\.aspect_rules_js/.*/node_modules",
    "node_modules": "/node_modules/",
    "app": "", # empty means just match anything.
}
```

*
nameA unique name for this target. *
binaryLabel to an js_binary target �
compression�Compression algorithm. See https://github.com/bazel-contrib/bazel-lib/blob/bdc6ade0ba1ebe88d822bcdf4d4aaa2ce7e2cd37/lib/private/tar.bzl#L29-L392"gzip"b
directory_modeFMode of the directories, in `octal` format. By default `0755` is used.2"0755"W
	file_mode@Mode of the files, in `octal` format. By default `0555` is used.2"0555"{
generate_empty_layersYDEPRECATED. An empty layer is always generated if the layer group have no matching files.2False�
layer_groups�Layer groups to create.
These are utilized to categorize files into distinct layers, determined by their respective paths.
The expected format for each entry is "<key>": "<value>", where <key> MUST be a valid Bazel and
JavaScript identifier (alphanumeric characters), and <value> MAY be either an empty string (signifying a universal match)
or a valid regular expression.
2{}c
ownerQOwner of the entries, in `GID:UID` format. By default `0:0` (root, root) is used.2"0:0"+
platformPlatform to transition.2None�
preserve_symlinkspPreserve symlinks for entries matching the pattern.
By default symlinks within the `node_modules` is preserved.
2".*/node_modules/.*"X
rootJPath where the files from js_binary will reside in. eg: /apps/app1 or /app2"""B
js_image_layer0@@aspect_rules_js//js/private:js_image_layer.bzl
��,
*
nameA unique name for this target. ,
*
binaryLabel to an js_binary target �
�
compression�Compression algorithm. See https://github.com/bazel-contrib/bazel-lib/blob/bdc6ade0ba1ebe88d822bcdf4d4aaa2ce7e2cd37/lib/private/tar.bzl#L29-L392"gzip"d
b
directory_modeFMode of the directories, in `octal` format. By default `0755` is used.2"0755"Y
W
	file_mode@Mode of the files, in `octal` format. By default `0555` is used.2"0555"}
{
generate_empty_layersYDEPRECATED. An empty layer is always generated if the layer group have no matching files.2False�
�
layer_groups�Layer groups to create.
These are utilized to categorize files into distinct layers, determined by their respective paths.
The expected format for each entry is "<key>": "<value>", where <key> MUST be a valid Bazel and
JavaScript identifier (alphanumeric characters), and <value> MAY be either an empty string (signifying a universal match)
or a valid regular expression.
2{}e
c
ownerQOwner of the entries, in `GID:UID` format. By default `0:0` (root, root) is used.2"0:0"-
+
platformPlatform to transition.2None�
�
preserve_symlinkspPreserve symlinks for entries matching the pattern.
By default symlinks within the `node_modules` is preserved.
2".*/node_modules/.*"Z
X
rootJPath where the files from js_binary will reside in. eg: /apps/app1 or /app2""e
//lib:tar.bzlrR
 
aspect_bazel_liblibtar.bzl 
tar_libtar_lib
)0
2a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.�Rules for creating container image layers from js_binary targets

For example, this js_image_layer target outputs `node_modules.tar` and `app.tar` with `/app` prefix.

```starlark
load("@aspect_rules_js//js:defs.bzl", "js_image_layer")

js_image_layer(
    name = "layers",
    binary = "//label/to:js_binary",
    root = "/app",
)
```
�
*
aspect_rules_js
js/privatejs_info.bzl�js_infoConstruct a JsInfo.*�
�
js_info&
targetSee JsInfo documentation (+
sourcesSee JsInfo documentationNone()
typesSee JsInfo documentationNone(6
transitive_sourcesSee JsInfo documentationNone(4
transitive_typesSee JsInfo documentationNone(/
npm_sourcesSee JsInfo documentationNone(;
npm_package_store_infosSee JsInfo documentationNone('
kwargsFor backward compat support(Construct a JsInfo."
A JsInfo provider24
js_info)@@aspect_rules_js//js/private:js_info.bzl
�JsInfoOEncapsulates information provided by rules in rules_js and derivative rule sets2�
�
JsInfoOEncapsulates information provided by rules in rules_js and derivative rule sets6
target,The label of target that created this JsInfo:
sources/A depset of source files produced by the target9
types0A depset of typings files produced by the targetf
transitive_sourcesPA depset of source files produced by the target and the target's transitive depsi
transitive_typesUA depset of declaration files produced by the target and the target's transitive depsk
npm_sources\A depset of files in npm package dependencies of the target and the target's transitive deps�
npm_package_store_infos�A depset of NpmPackageStoreInfo providers from non-dev npm dependencies of the target and the target's transitive dependencies to use as direct dependencies when linking downstream npm_package targets with npm_link_package"3
JsInfo)@@aspect_rules_js//js/private:js_info.bzl
8
6
target,The label of target that created this JsInfo<
:
sources/A depset of source files produced by the target;
9
types0A depset of typings files produced by the targeth
f
transitive_sourcesPA depset of source files produced by the target and the target's transitive depsk
i
transitive_typesUA depset of declaration files produced by the target and the target's transitive depsm
k
npm_sources\A depset of files in npm package dependencies of the target and the target's transitive deps�
�
npm_package_store_infos�A depset of NpmPackageStoreInfo providers from non-dev npm dependencies of the target and the target's transitive dependencies to use as direct dependencies when linking downstream npm_package targets with npm_link_packageJsInfo provider�
0
aspect_rules_js
js/privatejs_info_files.bzl�js_info_files�Gathers files from the JsInfo providers from targets in srcs and provides them as default outputs.

This helper rule is used by the `js_run_binary` macro.
"�
�
js_info_files�Gathers files from the JsInfo providers from targets in srcs and provides them as default outputs.

This helper rule is used by the `js_run_binary` macro.
*
nameA unique name for this target. �
include_npm_sources�When True, files in `npm_sources` from `JsInfo` providers in `srcs` targets are included in the default outputs of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in `srcs` targets are also included in the default outputs of the target.
2True�
include_sourcesqWhen True, `sources` from `JsInfo` providers in `srcs` targets are included in the default outputs of the target.2True�
include_transitive_sources|When True, `transitive_sources` from `JsInfo` providers in `srcs` targets are included in the default outputs of the target.2True�
include_transitive_types�When True, `transitive_types` from `JsInfo` providers in `srcs` targets are included in the default outputs of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
include_types�When True, `types` from `JsInfo` providers in `srcs` targets are included in the default outputs of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.

NB: These are types from direct `srcs` dependencies only. You may also need to set `include_transitive_types` to True.2False3
srcs%List of targets to gather files from.2[]"@
js_info_files/@@aspect_rules_js//js/private:js_info_files.bzl
,
*
nameA unique name for this target. �
�
include_npm_sources�When True, files in `npm_sources` from `JsInfo` providers in `srcs` targets are included in the default outputs of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in `srcs` targets are also included in the default outputs of the target.
2True�
�
include_sourcesqWhen True, `sources` from `JsInfo` providers in `srcs` targets are included in the default outputs of the target.2True�
�
include_transitive_sources|When True, `transitive_sources` from `JsInfo` providers in `srcs` targets are included in the default outputs of the target.2True�
�
include_transitive_types�When True, `transitive_types` from `JsInfo` providers in `srcs` targets are included in the default outputs of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
�
include_types�When True, `types` from `JsInfo` providers in `srcs` targets are included in the default outputs of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.

NB: These are types from direct `srcs` dependencies only. You may also need to set `include_transitive_types` to True.2False5
3
srcs%List of targets to gather files from.2[]�
//js/private:js_helpers.bzlr�
-
aspect_rules_js
js/privatejs_helpers.bzlG
gather_files_from_js_infos_gather_files_from_js_infos
5P
p`Helper rule to gather files from JsInfo providers of targets and provide them as default outputs�`
-
aspect_rules_js
js/privatejs_library.bzl�U
js_library�A library of JavaScript sources. Provides JsInfo, the primary provider used in rules_js
and derivative rule sets.

Declaration files are handled separately from sources since they are generally not needed at
runtime and build rules, such as ts_project, are optimal in their build graph if they only depend
on types from `deps` since these they don't need the JavaScript source files from deps to
typecheck.

Linked npm dependences are also handled separately from sources since not all rules require them and it
is optimal for these rules to not depend on them in the build graph.

NB: `js_library` copies all source files to the output tree before providing them in JsInfo. See
https://github.com/aspect-build/rules_js/tree/dbb5af0d2a9a2bb50e4cf4a96dbc582b27567155/docs#javascript
for more context on why we do this."�N
�*

js_library�A library of JavaScript sources. Provides JsInfo, the primary provider used in rules_js
and derivative rule sets.

Declaration files are handled separately from sources since they are generally not needed at
runtime and build rules, such as ts_project, are optimal in their build graph if they only depend
on types from `deps` since these they don't need the JavaScript source files from deps to
typecheck.

Linked npm dependences are also handled separately from sources since not all rules require them and it
is optimal for these rules to not depend on them in the build graph.

NB: `js_library` copies all source files to the output tree before providing them in JsInfo. See
https://github.com/aspect-build/rules_js/tree/dbb5af0d2a9a2bb50e4cf4a96dbc582b27567155/docs#javascript
for more context on why we do this.*
nameA unique name for this target. �
copy_data_to_binfWhen True, `data` files are copied to the Bazel output tree before being passed as inputs to runfiles.2True�
data�Runtime dependencies to include in binaries/tests that depend on this target.

The transitive npm dependencies, transitive sources, default outputs and runfiles of targets in the `data` attribute
are added to the runfiles of this target. They should appear in the '*.runfiles' area of any executable which has
a runtime dependency on this target.

If this list contains linked npm packages, npm package store targets or other targets that provide
`JsInfo`, `NpmPackageStoreInfo` providers are gathered from `JsInfo`. This is done directly from
the `npm_package_store_infos` field of these. For linked npm package targets, the underlying
`npm_package_store` target(s) that back the links are used. Gathered `NpmPackageStoreInfo`
providers are propagated to the direct dependencies of downstream linked targets.

NB: Linked npm package targets that are "dev" dependencies do not forward their underlying
`npm_package_store` target(s) through `npm_package_store_infos` and will therefore not be
propagated to the direct dependencies of downstream linked targets. npm packages
that come in from `npm_translate_lock` are considered "dev" dependencies if they are have
`dev: true` set in the pnpm lock file. This should be all packages that are only listed as
"devDependencies" in all `package.json` files within the pnpm workspace. This behavior is
intentional to mimic how `devDependencies` work in published npm packages.

2[]�
deps�Dependencies of this target.

This may include other js_library targets or other targets that provide JsInfo

The transitive npm dependencies, transitive sources & runfiles of targets in the `deps` attribute are added to the
runfiles of this target. They should appear in the '*.runfiles' area of any executable which is output by or has a
runtime dependency on this target.

If this list contains linked npm packages, npm package store targets or other targets that provide
`JsInfo`, `NpmPackageStoreInfo` providers are gathered from `JsInfo`. This is done directly from
the `npm_package_store_infos` field of these. For linked npm package targets, the underlying
`npm_package_store` target(s) that back the links are used. Gathered `NpmPackageStoreInfo`
providers are propagated to the direct dependencies of downstream linked targets.

NB: Linked npm package targets that are "dev" dependencies do not forward their underlying
`npm_package_store` target(s) through `npm_package_store_infos` and will therefore not be
propagated to the direct dependencies of downstream linked targets. npm packages
that come in from `npm_translate_lock` are considered "dev" dependencies if they are have
`dev: true` set in the pnpm lock file. This should be all packages that are only listed as
"devDependencies" in all `package.json` files within the pnpm workspace. This behavior is
intentional to mimic how `devDependencies` work in published npm packages.

*
JsInfo2[]�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
srcs�Source files that are included in this library.

This includes all your checked-in code and any generated source files.

The transitive npm dependencies, transitive sources & runfiles of targets in the `srcs` attribute are added to the
runfiles of this target. They should appear in the '*.runfiles' area of any executable which is output by or has a
runtime dependency on this target.

Source files that are JSON files, declaration files or directory artifacts will be automatically provided as
"types" available to downstream rules for type checking. To explicitly provide source files as "types"
available to downstream rules for type checking that do not match these criteria, move those files to the `types`
attribute instead.
2[]�
types�Same as `srcs` except all files are also provided as "types" available to downstream rules for type checking.

For example, a js_library with only `.js` files that are intended to be imported as `.js` files by downstream type checking
rules such as `ts_project` would list those files in `types`:

```
js_library(
    name = "js_lib",
    types = ["index.js"],
)
```
2[]":

js_library,@@aspect_rules_js//js/private:js_library.bzl
��,
*
nameA unique name for this target. �
�
copy_data_to_binfWhen True, `data` files are copied to the Bazel output tree before being passed as inputs to runfiles.2True�
�
data�Runtime dependencies to include in binaries/tests that depend on this target.

The transitive npm dependencies, transitive sources, default outputs and runfiles of targets in the `data` attribute
are added to the runfiles of this target. They should appear in the '*.runfiles' area of any executable which has
a runtime dependency on this target.

If this list contains linked npm packages, npm package store targets or other targets that provide
`JsInfo`, `NpmPackageStoreInfo` providers are gathered from `JsInfo`. This is done directly from
the `npm_package_store_infos` field of these. For linked npm package targets, the underlying
`npm_package_store` target(s) that back the links are used. Gathered `NpmPackageStoreInfo`
providers are propagated to the direct dependencies of downstream linked targets.

NB: Linked npm package targets that are "dev" dependencies do not forward their underlying
`npm_package_store` target(s) through `npm_package_store_infos` and will therefore not be
propagated to the direct dependencies of downstream linked targets. npm packages
that come in from `npm_translate_lock` are considered "dev" dependencies if they are have
`dev: true` set in the pnpm lock file. This should be all packages that are only listed as
"devDependencies" in all `package.json` files within the pnpm workspace. This behavior is
intentional to mimic how `devDependencies` work in published npm packages.

2[]�
�
deps�Dependencies of this target.

This may include other js_library targets or other targets that provide JsInfo

The transitive npm dependencies, transitive sources & runfiles of targets in the `deps` attribute are added to the
runfiles of this target. They should appear in the '*.runfiles' area of any executable which is output by or has a
runtime dependency on this target.

If this list contains linked npm packages, npm package store targets or other targets that provide
`JsInfo`, `NpmPackageStoreInfo` providers are gathered from `JsInfo`. This is done directly from
the `npm_package_store_infos` field of these. For linked npm package targets, the underlying
`npm_package_store` target(s) that back the links are used. Gathered `NpmPackageStoreInfo`
providers are propagated to the direct dependencies of downstream linked targets.

NB: Linked npm package targets that are "dev" dependencies do not forward their underlying
`npm_package_store` target(s) through `npm_package_store_infos` and will therefore not be
propagated to the direct dependencies of downstream linked targets. npm packages
that come in from `npm_translate_lock` are considered "dev" dependencies if they are have
`dev: true` set in the pnpm lock file. This should be all packages that are only listed as
"devDependencies" in all `package.json` files within the pnpm workspace. This behavior is
intentional to mimic how `devDependencies` work in published npm packages.

*
JsInfo2[]�
�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
�
srcs�Source files that are included in this library.

This includes all your checked-in code and any generated source files.

The transitive npm dependencies, transitive sources & runfiles of targets in the `srcs` attribute are added to the
runfiles of this target. They should appear in the '*.runfiles' area of any executable which is output by or has a
runtime dependency on this target.

Source files that are JSON files, declaration files or directory artifacts will be automatically provided as
"types" available to downstream rules for type checking. To explicitly provide source files as "types"
available to downstream rules for type checking that do not match these criteria, move those files to the `types`
attribute instead.
2[]�
�
types�Same as `srcs` except all files are also provided as "types" available to downstream rules for type checking.

For example, a js_library with only `.js` files that are intended to be imported as `.js` files by downstream type checking
rules such as `ts_project` would list those files in `types`:

```
js_library(
    name = "js_lib",
    types = ["index.js"],
)
```
2[]�
//lib:copy_to_bin.bzlr�
(
aspect_bazel_liblibcopy_to_bin.bzlH
COPY_FILE_TO_BIN_TOOLCHAINSCOPY_FILE_TO_BIN_TOOLCHAINS
1L
N�
//js/private:js_helpers.bzlr�
-
aspect_rules_js
js/privatejs_helpers.bzlF
copy_js_file_to_bin_actioncopy_js_file_to_bin_action
6P0
gather_runfilesgather_runfiles
Tc
e�
//js/private:js_info.bzlr|
*
aspect_rules_js
js/privatejs_info.bzl
JsInfoJsInfo
39 
js_infojs_info
=D
F�js_library groups together JS sources and arranges them and their transitive and npm dependencies into a provided
`JsInfo`. There are no Bazel actions to run.

For example, this `BUILD` file groups a pair of `.js/.d.ts` files along with the `package.json`.
The latter is needed because it contains a `typings` key that allows downstream
users of this library to resolve the `one.d.ts` file.
The `main` key is another commonly used field in `package.json` which would require including it in the library.

```starlark
load("@aspect_rules_js//js:defs.bzl", "js_library")

js_library(
    name = "one",
    srcs = [
        "one.d.ts",
        "one.js",
        "package.json",
    ],
)
```

| This is similar to [`py_library`](https://docs.bazel.build/versions/main/be/python.html#py_library) which depends on
| Python sources and provides a `PyInfo`.
�;
0
aspect_rules_js
js/privatejs_run_binary.bzl�1js_run_binary�Wrapper around @aspect_bazel_lib `run_binary` that adds convenience attributes for using a `js_binary` tool.

This rule does not require Bash `native.genrule`.

The following environment variables are made available to the Node.js runtime based on available Bazel [Make variables](https://bazel.build/reference/be/make-variables#predefined_variables):

* BAZEL_BINDIR: the WORKSPACE-relative bazel bin directory; equivalent to the `$(BINDIR)` Make variable of the `js_run_binary` target
* BAZEL_COMPILATION_MODE: One of `fastbuild`, `dbg`, or `opt` as set by [`--compilation_mode`](https://bazel.build/docs/user-manual#compilation-mode); equivalent to `$(COMPILATION_MODE)` Make variable of the `js_run_binary` target
* BAZEL_TARGET_CPU: the target cpu architecture; equivalent to `$(TARGET_CPU)` Make variable of the `js_run_binary` target

The following environment variables are made available to the Node.js runtime based on the rule context:

* BAZEL_BUILD_FILE_PATH: the WORKSPACE-relative path to the BUILD file of the bazel target being run; equivalent to `ctx.build_file_path` of the `js_run_binary` target's rule context
* BAZEL_PACKAGE: the package of the bazel target being run; equivalent to `ctx.label.package` of the `js_run_binary` target's rule context
* BAZEL_TARGET_NAME: the full label of the bazel target being run; a stringified version of `ctx.label` of the `js_run_binary` target's rule context
* BAZEL_TARGET: the name of the bazel target being run; equivalent to `ctx.label.name` of the  `js_run_binary` target's rule context
* BAZEL_WORKSPACE: the bazel workspace name; equivalent to `ctx.workspace_name` of the `js_run_binary` target's rule context
"�$
�
js_run_binary�Wrapper around @aspect_bazel_lib `run_binary` that adds convenience attributes for using a `js_binary` tool.

This rule does not require Bash `native.genrule`.

The following environment variables are made available to the Node.js runtime based on available Bazel [Make variables](https://bazel.build/reference/be/make-variables#predefined_variables):

* BAZEL_BINDIR: the WORKSPACE-relative bazel bin directory; equivalent to the `$(BINDIR)` Make variable of the `js_run_binary` target
* BAZEL_COMPILATION_MODE: One of `fastbuild`, `dbg`, or `opt` as set by [`--compilation_mode`](https://bazel.build/docs/user-manual#compilation-mode); equivalent to `$(COMPILATION_MODE)` Make variable of the `js_run_binary` target
* BAZEL_TARGET_CPU: the target cpu architecture; equivalent to `$(TARGET_CPU)` Make variable of the `js_run_binary` target

The following environment variables are made available to the Node.js runtime based on the rule context:

* BAZEL_BUILD_FILE_PATH: the WORKSPACE-relative path to the BUILD file of the bazel target being run; equivalent to `ctx.build_file_path` of the `js_run_binary` target's rule context
* BAZEL_PACKAGE: the package of the bazel target being run; equivalent to `ctx.label.package` of the `js_run_binary` target's rule context
* BAZEL_TARGET_NAME: the full label of the bazel target being run; a stringified version of `ctx.label` of the `js_run_binary` target's rule context
* BAZEL_TARGET: the name of the bazel target being run; equivalent to `ctx.label.name` of the  `js_run_binary` target's rule context
* BAZEL_WORKSPACE: the bazel workspace name; equivalent to `ctx.workspace_name` of the `js_run_binary` target's rule context
*
nameA unique name for this target. 
args2[]
env
2{}
execution_requirements
2{}
mnemonic2""
out_dirs2[]
outs
progress_message2""�
resource_set�A predefined function used as the resource_set for actions.

Used with --experimental_action_resource_set to reserve more RAM/CPU, preventing Bazel overscheduling resource-intensive actions.

By default, Bazel allocates 1 CPU and 250M of RAM.
https://github.com/bazelbuild/bazel/blob/058f943037e21710837eda9ca2f85b5f8538c8c5/src/main/java/com/google/devtools/build/lib/actions/AbstractAction.java#L77
2	"default"
srcs2[]�
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.
2-1

tool  
use_default_shell_env2False
,
*
nameA unique name for this target. 

args2[]

env
2{} 

execution_requirements
2{}

mnemonic2""

out_dirs2[]


outs

progress_message2""�
�
resource_set�A predefined function used as the resource_set for actions.

Used with --experimental_action_resource_set to reserve more RAM/CPU, preventing Bazel overscheduling resource-intensive actions.

By default, Bazel allocates 1 CPU and 250M of RAM.
https://github.com/bazelbuild/bazel/blob/058f943037e21710837eda9ca2f85b5f8538c8c5/src/main/java/com/google/devtools/build/lib/actions/AbstractAction.java#L77
2	"default"

srcs2[]�
�
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.
2-1


tool "
 
use_default_shell_env2False~
//lib:copy_to_bin.bzlrc
(
aspect_bazel_liblibcopy_to_bin.bzl)
copy_to_bin_copy_to_bin
0<
Mz
//lib:run_binary.bzlr`
'
aspect_bazel_liblibrun_binary.bzl'

run_binary_run_binary
/:
Jo
//lib:utils.bzlrZ
"
aspect_bazel_liblib	utils.bzl&
utilsbazel_lib_utils
*9
D�
//js/private:js_helpers.bzlrv
-
aspect_rules_js
js/privatejs_helpers.bzl7
envs_for_log_level_envs_for_log_level
5H
`�
//js/private:js_info_files.bzlro
0
aspect_rules_js
js/privatejs_info_files.bzl-
js_info_files_js_info_files
8F
Y�
//js/private:js_library.bzlrf
-
aspect_rules_js
js/privatejs_library.bzl'

js_library_js_library
5@
P�Runs a js_binary as a build action.

This macro wraps Aspect bazel-lib's run_binary (https://github.com/bazel-contrib/bazel-lib/blob/main/lib/run_binary.bzl)
and adds attributes and features specific to rules_js's js_binary.

Load this with,

```starlark
load("@aspect_rules_js//js:defs.bzl", "js_run_binary")
```
�<
3
aspect_rules_js
js/privatejs_run_devserver.bzl�8js_run_devserver�Runs a devserver via binary target or command.

A simple http-server, for example, can be setup as follows,

```
load("@aspect_rules_js//js:defs.bzl", "js_run_devserver")
load("@npm//:http-server/package_json.bzl", http_server_bin = "bin")

http_server_bin.http_server_binary(
    name = "http_server",
)

js_run_devserver(
    name = "serve",
    args = ["."],
    data = ["index.html"],
    tool = ":http_server",
)
```

A Next.js devserver can be setup as follows,

```
js_run_devserver(
    name = "dev",
    args = ["dev"],
    command = "./node_modules/.bin/next",
    data = [
        "next.config.js",
        "package.json",
        ":node_modules/next",
        ":node_modules/react",
        ":node_modules/react-dom",
        ":node_modules/typescript",
        "//pages",
        "//public",
        "//styles",
    ],
)
```

where the `./node_modules/.bin/next` bin entry of Next.js is configured in
`npm_translate_lock` as such,

```
npm_translate_lock(
    name = "npm",
    bins = {
        # derived from "bin" attribute in node_modules/next/package.json
        "next": {
            "next": "./dist/bin/next",
        },
    },
    pnpm_lock = "//:pnpm-lock.yaml",
)
```

and run in watch mode using [ibazel](https://github.com/bazelbuild/bazel-watcher) with
`ibazel run //:dev`.

The devserver specified by either `tool` or `command` is run in a custom sandbox that is more
compatible with devserver watch modes in Node.js tools such as Webpack and Next.js.

The custom sandbox is populated with the default outputs of all targets in `data`
as well as transitive sources & npm links.

As an optimization, package store files are explicitly excluded from the sandbox since the npm
links will point to the package store in the execroot and Node.js will follow those links as it
does within the execroot. As a result, rules_js npm package link targets such as
`//:node_modules/next` are handled efficiently. Since these targets are symlinks in the output
tree, they are recreated as symlinks in the custom sandbox and do not incur a full copy of the
underlying npm packages.

Supports running with [ibazel](https://github.com/bazelbuild/bazel-watcher).
Only `data` files that change on incremental builds are synchronized when running with ibazel.

Note that the use of `alias` targets is not supported by ibazel: https://github.com/bazelbuild/bazel-watcher/issues/100
*�%
�$
js_run_devserver*
nameA unique name for this target. (f
toolVThe devserver binary target to run.

Only one of `command` or `tool` may be specified.None(�
command�The devserver command to run.

For example, this could be the bin entry of an npm package that is included
in data such as `./node_modules/.bin/next`.

Using the bin entry of next, for example, resolves issues with Next.js and React
being found in multiple node_modules trees when next is run as an encapsulated
`js_binary` tool.

Only one of `command` or `tool` may be specified.None(�
grant_sandbox_write_permissions�If set, write permissions is set on all files copied to the custom sandbox.

This can be useful to support some devservers such as Next.js which may, under some
circumstances, try to modify files when running.

See https://github.com/aspect-build/rules_js/issues/935 for more context.False(�
use_execroot_entry_point�Use the `entry_point` script of the `js_binary` `tool` that is in the execroot output tree
instead of the copy that is in runfiles.

Using the entry point script that is in the execroot output tree means that there will be no conflicting
runfiles `node_modules` in the node_modules resolution path which can confuse npm packages such as next and
react that don't like being resolved in multiple node_modules trees. This more closely emulates the
environment that tools such as Next.js see when they are run outside of Bazel.

When True, the `js_binary` tool must have `copy_data_to_bin` set to True (the default) so that all data files
needed by the binary are available in the execroot output tree. This requirement can be turned off with by
setting `allow_execroot_entry_point_with_no_copy_data_to_bin` to True.True(�
3allow_execroot_entry_point_with_no_copy_data_to_bin�Turn off validation that the `js_binary` tool
has `copy_data_to_bin` set to True when `use_execroot_entry_point` is set to True.

See `use_execroot_entry_point` doc for more info.False(�
kwargs�All other args from `js_binary` except for `entry_point` which is set implicitly.

`entry_point` is set implicitly by `js_run_devserver` and cannot be overridden.

See https://docs.aspect.build/rules/aspect_rules_js/docs/js_binary(�Runs a devserver via binary target or command.

A simple http-server, for example, can be setup as follows,

```
load("@aspect_rules_js//js:defs.bzl", "js_run_devserver")
load("@npm//:http-server/package_json.bzl", http_server_bin = "bin")

http_server_bin.http_server_binary(
    name = "http_server",
)

js_run_devserver(
    name = "serve",
    args = ["."],
    data = ["index.html"],
    tool = ":http_server",
)
```

A Next.js devserver can be setup as follows,

```
js_run_devserver(
    name = "dev",
    args = ["dev"],
    command = "./node_modules/.bin/next",
    data = [
        "next.config.js",
        "package.json",
        ":node_modules/next",
        ":node_modules/react",
        ":node_modules/react-dom",
        ":node_modules/typescript",
        "//pages",
        "//public",
        "//styles",
    ],
)
```

where the `./node_modules/.bin/next` bin entry of Next.js is configured in
`npm_translate_lock` as such,

```
npm_translate_lock(
    name = "npm",
    bins = {
        # derived from "bin" attribute in node_modules/next/package.json
        "next": {
            "next": "./dist/bin/next",
        },
    },
    pnpm_lock = "//:pnpm-lock.yaml",
)
```

and run in watch mode using [ibazel](https://github.com/bazelbuild/bazel-watcher) with
`ibazel run //:dev`.

The devserver specified by either `tool` or `command` is run in a custom sandbox that is more
compatible with devserver watch modes in Node.js tools such as Webpack and Next.js.

The custom sandbox is populated with the default outputs of all targets in `data`
as well as transitive sources & npm links.

As an optimization, package store files are explicitly excluded from the sandbox since the npm
links will point to the package store in the execroot and Node.js will follow those links as it
does within the execroot. As a result, rules_js npm package link targets such as
`//:node_modules/next` are handled efficiently. Since these targets are symlinks in the output
tree, they are recreated as symlinks in the custom sandbox and do not incur a full copy of the
underlying npm packages.

Supports running with [ibazel](https://github.com/bazelbuild/bazel-watcher).
Only `data` files that change on incremental builds are synchronized when running with ibazel.

Note that the use of `alias` targets is not supported by ibazel: https://github.com/bazelbuild/bazel-watcher/issues/100
2F
js_run_devserver2@@aspect_rules_js//js/private:js_run_devserver.bzl
��*rule_to_execute2rule_to_execute�
//js/private:js_binary.bzlrj
,
aspect_rules_js
js/privatejs_binary.bzl,
js_binary_libjs_binary_lib
5B
D�
//js/private:js_helpers.bzlr�
-
aspect_rules_js
js/privatejs_helpers.bzlG
gather_files_from_js_infos_gather_files_from_js_infos
5P
pa
//lib:dicts.bzlrL

bazel_skyliblib	dicts.bzl
dictsdicts
',
.0Implementation details for js_run_devserver rule��

aspect_rules_jsjsdefs.bzl��js_image_layer�9Create container image layers from js_binary targets.

By design, js_image_layer doesn't have any preference over which rule assembles the container image.
This means the downstream rule (`oci_image` from [rules_oci](https://github.com/bazel-contrib/rules_oci)
or `container_image` from [rules_docker](https://github.com/bazelbuild/rules_docker)) must
set a proper `workdir` and `cmd` to for the container work.

A proper `cmd` usually looks like /`[ js_image_layer 'root' ]`/`[ package name of js_image_layer 'binary' target ]/[ name of js_image_layer 'binary' target ]`,
unless you have a custom launcher script that invokes the entry_point of the `js_binary` in a different path.

On the other hand, `workdir` has to be set to the "runfiles tree root" which would be exactly `cmd` **but with `.runfiles/[ name of the workspace ]` suffix**.
If using bzlmod then name of the local workspace is always `_main`. If bzlmod is not enabled then the name of the local workspace, if not otherwise specified
in the `WORKSPACE` file, is `__main__`. If `workdir` is not set correctly, some attributes such as `chdir` might not work properly.

js_image_layer creates up to 5 layers depending on what files are included in the runfiles of the provided
`binary` target.

1. `node` layer contains the Node.js toolchain
2. `package_store_3p` layer contains all 3p npm deps in the `node_modules/.aspect_rules_js` package store
3. `package_store_1p` layer contains all 1p npm deps in the `node_modules/.aspect_rules_js` package store
4. `node_modules` layer contains all `node_modules/*` symlinks which point into the package store
5. `app` layer contains all files that don't fall into any of the above layers

If no files are found in the runfiles of the `binary` target for one of the layers above, that
layer is not generated. All generated layer tarballs are provided as `DefaultInfo` files.

> The rules_js `node_modules/.aspect_rules_js` package store follows the same pattern as the pnpm
> `node_modules/.pnpm` virtual store. For more information see https://pnpm.io/symlinked-node-modules-structure.

js_image_layer also provides an `OutputGroupInfo` with outputs for each of the layers above which
can be used to reference an individual layer with using `filegroup` with `output_group`. For example,

```starlark
js_image_layer(
    name = "layers",
    binary = ":bin",
    root = "/app",
)

filegroup(
    name = "app_tar",
    srcs = [":layers"],
    output_group = "app",
)
```

> WARNING: The structure of the generated layers are not subject to semver guarantees and may change without a notice.
> However, it is guaranteed to work when all generated layers are provided together in the order specified above.

js_image_layer supports transitioning to specific `platform` to allow building multi-platform container images.

**A partial example using rules_oci with transition to linux/amd64 platform.**

```starlark
load("@aspect_rules_js//js:defs.bzl", "js_binary", "js_image_layer")
load("@rules_oci//oci:defs.bzl", "oci_image")

js_binary(
    name = "bin",
    entry_point = "main.js",
)

platform(
    name = "amd64_linux",
    constraint_values = [
        "@platforms//os:linux",
        "@platforms//cpu:x86_64",
    ],
)

js_image_layer(
    name = "layers",
    binary = ":bin",
    platform = ":amd64_linux",
    root = "/app",
)

oci_image(
    name = "image",
    cmd = ["/app/bin"],
    entrypoint = ["bash"],
    tars = [
        ":layers"
    ],
    workdir = select({
        "@aspect_bazel_lib//lib:bzlmod": "/app/bin.runfiles/_main",
        "//conditions:default": "/app/bin.runfiles/__main__",
    }),
)
```

**A partial example using rules_oci to create multi-platform images.**

```starlark
load("@aspect_rules_js//js:defs.bzl", "js_binary", "js_image_layer")
load("@rules_oci//oci:defs.bzl", "oci_image", "oci_image_index")

js_binary(
    name = "bin",
    entry_point = "main.js",
)

[
    platform(
        name = "linux_{}".format(arch),
        constraint_values = [
            "@platforms//os:linux",
            "@platforms//cpu:{}".format(arch if arch != "amd64" else "x86_64"),
        ],
    )

    js_image_layer(
        name = "{}_layers".format(arch),
        binary = ":bin",
        platform = ":linux_{arch}",
        root = "/app",
    )

    oci_image(
        name = "{}_image".format(arch),
        cmd = ["/app/bin"],
        entrypoint = ["bash"],
        tars = [
            ":{}_layers".format(arch)
        ],
        workdir = select({
            "@aspect_bazel_lib//lib:bzlmod": "/app/bin.runfiles/_main",
            "//conditions:default": "/app/bin.runfiles/__main__",
        }),
    )

    for arch in ["amd64", "arm64"]
]

oci_image_index(
    name = "image",
    images = [
        ":arm64_image",
        ":amd64_image"
    ]
)
```

**An example using legacy rules_docker**

See `e2e/js_image_docker` for full example.

```starlark
load("@aspect_rules_js//js:defs.bzl", "js_binary", "js_image_layer")
load("@io_bazel_rules_docker//container:container.bzl", "container_image")

js_binary(
    name = "bin",
    data = [
        "//:node_modules/args-parser",
    ],
    entry_point = "main.js",
)

js_image_layer(
    name = "layers",
    binary = ":bin",
    root = "/app",
    visibility = ["//visibility:__pkg__"],
)

filegroup(
    name = "node_tar",
    srcs = [":layers"],
    output_group = "node",
)

container_layer(
    name = "node_layer",
    tars = [":node_tar"],
)

filegroup(
    name = "package_store_3p_tar",
    srcs = [":layers"],
    output_group = "package_store_3p",
)

container_layer(
    name = "package_store_3p_layer",
    tars = [":package_store_3p_tar"],
)

filegroup(
    name = "package_store_1p_tar",
    srcs = [":layers"],
    output_group = "package_store_1p",
)

container_layer(
    name = "package_store_1p_layer",
    tars = [":package_store_1p_tar"],
)

filegroup(
    name = "node_modules_tar",
    srcs = [":layers"],
    output_group = "node_modules",
)

container_layer(
    name = "node_modules_layer",
    tars = [":node_modules_tar"],
)

filegroup(
    name = "app_tar",
    srcs = [":layers"],
    output_group = "app",
)

container_layer(
    name = "app_layer",
    tars = [":app_tar"],
)

container_image(
    name = "image",
    cmd = ["/app/bin"],
    entrypoint = ["bash"],
    layers = [
        ":node_layer",
        ":package_store_3p_layer",
        ":package_store_1p_layer",
        ":node_modules_layer",
        ":app_layer",
    ],
    workdir = select({
        "@aspect_bazel_lib//lib:bzlmod": "/app/bin.runfiles/_main",
        "//conditions:default": "/app/bin.runfiles/__main__",
    }),
)
```


## Performance

For better performance, it is recommended to split the large parts of a `js_binary` to have a separate layer.

The matching order for layer groups is as follows:

1. `layer_groups` are checked in order first
2. If no match is found for `layer_groups`, the `default layer groups` are checked.
3. Any remaining files are placed into the app layer.

The default layer groups are as follows and always created.

```
{
    "node": "/js/private/node-patches/|/bin/nodejs/",
    "package_store_1p": "\.aspect_rules_js/.*@0\.0\.0/node_modules",
    "package_store_3p": "\.aspect_rules_js/.*/node_modules",
    "node_modules": "/node_modules/",
    "app": "", # empty means just match anything.
}
```

"�O
�D
js_image_layer�9Create container image layers from js_binary targets.

By design, js_image_layer doesn't have any preference over which rule assembles the container image.
This means the downstream rule (`oci_image` from [rules_oci](https://github.com/bazel-contrib/rules_oci)
or `container_image` from [rules_docker](https://github.com/bazelbuild/rules_docker)) must
set a proper `workdir` and `cmd` to for the container work.

A proper `cmd` usually looks like /`[ js_image_layer 'root' ]`/`[ package name of js_image_layer 'binary' target ]/[ name of js_image_layer 'binary' target ]`,
unless you have a custom launcher script that invokes the entry_point of the `js_binary` in a different path.

On the other hand, `workdir` has to be set to the "runfiles tree root" which would be exactly `cmd` **but with `.runfiles/[ name of the workspace ]` suffix**.
If using bzlmod then name of the local workspace is always `_main`. If bzlmod is not enabled then the name of the local workspace, if not otherwise specified
in the `WORKSPACE` file, is `__main__`. If `workdir` is not set correctly, some attributes such as `chdir` might not work properly.

js_image_layer creates up to 5 layers depending on what files are included in the runfiles of the provided
`binary` target.

1. `node` layer contains the Node.js toolchain
2. `package_store_3p` layer contains all 3p npm deps in the `node_modules/.aspect_rules_js` package store
3. `package_store_1p` layer contains all 1p npm deps in the `node_modules/.aspect_rules_js` package store
4. `node_modules` layer contains all `node_modules/*` symlinks which point into the package store
5. `app` layer contains all files that don't fall into any of the above layers

If no files are found in the runfiles of the `binary` target for one of the layers above, that
layer is not generated. All generated layer tarballs are provided as `DefaultInfo` files.

> The rules_js `node_modules/.aspect_rules_js` package store follows the same pattern as the pnpm
> `node_modules/.pnpm` virtual store. For more information see https://pnpm.io/symlinked-node-modules-structure.

js_image_layer also provides an `OutputGroupInfo` with outputs for each of the layers above which
can be used to reference an individual layer with using `filegroup` with `output_group`. For example,

```starlark
js_image_layer(
    name = "layers",
    binary = ":bin",
    root = "/app",
)

filegroup(
    name = "app_tar",
    srcs = [":layers"],
    output_group = "app",
)
```

> WARNING: The structure of the generated layers are not subject to semver guarantees and may change without a notice.
> However, it is guaranteed to work when all generated layers are provided together in the order specified above.

js_image_layer supports transitioning to specific `platform` to allow building multi-platform container images.

**A partial example using rules_oci with transition to linux/amd64 platform.**

```starlark
load("@aspect_rules_js//js:defs.bzl", "js_binary", "js_image_layer")
load("@rules_oci//oci:defs.bzl", "oci_image")

js_binary(
    name = "bin",
    entry_point = "main.js",
)

platform(
    name = "amd64_linux",
    constraint_values = [
        "@platforms//os:linux",
        "@platforms//cpu:x86_64",
    ],
)

js_image_layer(
    name = "layers",
    binary = ":bin",
    platform = ":amd64_linux",
    root = "/app",
)

oci_image(
    name = "image",
    cmd = ["/app/bin"],
    entrypoint = ["bash"],
    tars = [
        ":layers"
    ],
    workdir = select({
        "@aspect_bazel_lib//lib:bzlmod": "/app/bin.runfiles/_main",
        "//conditions:default": "/app/bin.runfiles/__main__",
    }),
)
```

**A partial example using rules_oci to create multi-platform images.**

```starlark
load("@aspect_rules_js//js:defs.bzl", "js_binary", "js_image_layer")
load("@rules_oci//oci:defs.bzl", "oci_image", "oci_image_index")

js_binary(
    name = "bin",
    entry_point = "main.js",
)

[
    platform(
        name = "linux_{}".format(arch),
        constraint_values = [
            "@platforms//os:linux",
            "@platforms//cpu:{}".format(arch if arch != "amd64" else "x86_64"),
        ],
    )

    js_image_layer(
        name = "{}_layers".format(arch),
        binary = ":bin",
        platform = ":linux_{arch}",
        root = "/app",
    )

    oci_image(
        name = "{}_image".format(arch),
        cmd = ["/app/bin"],
        entrypoint = ["bash"],
        tars = [
            ":{}_layers".format(arch)
        ],
        workdir = select({
            "@aspect_bazel_lib//lib:bzlmod": "/app/bin.runfiles/_main",
            "//conditions:default": "/app/bin.runfiles/__main__",
        }),
    )

    for arch in ["amd64", "arm64"]
]

oci_image_index(
    name = "image",
    images = [
        ":arm64_image",
        ":amd64_image"
    ]
)
```

**An example using legacy rules_docker**

See `e2e/js_image_docker` for full example.

```starlark
load("@aspect_rules_js//js:defs.bzl", "js_binary", "js_image_layer")
load("@io_bazel_rules_docker//container:container.bzl", "container_image")

js_binary(
    name = "bin",
    data = [
        "//:node_modules/args-parser",
    ],
    entry_point = "main.js",
)

js_image_layer(
    name = "layers",
    binary = ":bin",
    root = "/app",
    visibility = ["//visibility:__pkg__"],
)

filegroup(
    name = "node_tar",
    srcs = [":layers"],
    output_group = "node",
)

container_layer(
    name = "node_layer",
    tars = [":node_tar"],
)

filegroup(
    name = "package_store_3p_tar",
    srcs = [":layers"],
    output_group = "package_store_3p",
)

container_layer(
    name = "package_store_3p_layer",
    tars = [":package_store_3p_tar"],
)

filegroup(
    name = "package_store_1p_tar",
    srcs = [":layers"],
    output_group = "package_store_1p",
)

container_layer(
    name = "package_store_1p_layer",
    tars = [":package_store_1p_tar"],
)

filegroup(
    name = "node_modules_tar",
    srcs = [":layers"],
    output_group = "node_modules",
)

container_layer(
    name = "node_modules_layer",
    tars = [":node_modules_tar"],
)

filegroup(
    name = "app_tar",
    srcs = [":layers"],
    output_group = "app",
)

container_layer(
    name = "app_layer",
    tars = [":app_tar"],
)

container_image(
    name = "image",
    cmd = ["/app/bin"],
    entrypoint = ["bash"],
    layers = [
        ":node_layer",
        ":package_store_3p_layer",
        ":package_store_1p_layer",
        ":node_modules_layer",
        ":app_layer",
    ],
    workdir = select({
        "@aspect_bazel_lib//lib:bzlmod": "/app/bin.runfiles/_main",
        "//conditions:default": "/app/bin.runfiles/__main__",
    }),
)
```


## Performance

For better performance, it is recommended to split the large parts of a `js_binary` to have a separate layer.

The matching order for layer groups is as follows:

1. `layer_groups` are checked in order first
2. If no match is found for `layer_groups`, the `default layer groups` are checked.
3. Any remaining files are placed into the app layer.

The default layer groups are as follows and always created.

```
{
    "node": "/js/private/node-patches/|/bin/nodejs/",
    "package_store_1p": "\.aspect_rules_js/.*@0\.0\.0/node_modules",
    "package_store_3p": "\.aspect_rules_js/.*/node_modules",
    "node_modules": "/node_modules/",
    "app": "", # empty means just match anything.
}
```

*
nameA unique name for this target. *
binaryLabel to an js_binary target �
compression�Compression algorithm. See https://github.com/bazel-contrib/bazel-lib/blob/bdc6ade0ba1ebe88d822bcdf4d4aaa2ce7e2cd37/lib/private/tar.bzl#L29-L392"gzip"b
directory_modeFMode of the directories, in `octal` format. By default `0755` is used.2"0755"W
	file_mode@Mode of the files, in `octal` format. By default `0555` is used.2"0555"{
generate_empty_layersYDEPRECATED. An empty layer is always generated if the layer group have no matching files.2False�
layer_groups�Layer groups to create.
These are utilized to categorize files into distinct layers, determined by their respective paths.
The expected format for each entry is "<key>": "<value>", where <key> MUST be a valid Bazel and
JavaScript identifier (alphanumeric characters), and <value> MAY be either an empty string (signifying a universal match)
or a valid regular expression.
2{}c
ownerQOwner of the entries, in `GID:UID` format. By default `0:0` (root, root) is used.2"0:0"+
platformPlatform to transition.2None�
preserve_symlinkspPreserve symlinks for entries matching the pattern.
By default symlinks within the `node_modules` is preserved.
2".*/node_modules/.*"X
rootJPath where the files from js_binary will reside in. eg: /apps/app1 or /app2"""0
js_image_layer@@aspect_rules_js//js:defs.bzl
��,
*
nameA unique name for this target. ,
*
binaryLabel to an js_binary target �
�
compression�Compression algorithm. See https://github.com/bazel-contrib/bazel-lib/blob/bdc6ade0ba1ebe88d822bcdf4d4aaa2ce7e2cd37/lib/private/tar.bzl#L29-L392"gzip"d
b
directory_modeFMode of the directories, in `octal` format. By default `0755` is used.2"0755"Y
W
	file_mode@Mode of the files, in `octal` format. By default `0555` is used.2"0555"}
{
generate_empty_layersYDEPRECATED. An empty layer is always generated if the layer group have no matching files.2False�
�
layer_groups�Layer groups to create.
These are utilized to categorize files into distinct layers, determined by their respective paths.
The expected format for each entry is "<key>": "<value>", where <key> MUST be a valid Bazel and
JavaScript identifier (alphanumeric characters), and <value> MAY be either an empty string (signifying a universal match)
or a valid regular expression.
2{}e
c
ownerQOwner of the entries, in `GID:UID` format. By default `0:0` (root, root) is used.2"0:0"-
+
platformPlatform to transition.2None�
�
preserve_symlinkspPreserve symlinks for entries matching the pattern.
By default symlinks within the `node_modules` is preserved.
2".*/node_modules/.*"Z
X
rootJPath where the files from js_binary will reside in. eg: /apps/app1 or /app2""�js_info_files�Gathers files from the JsInfo providers from targets in srcs and provides them as default outputs.

This helper rule is used by the `js_run_binary` macro.
"�
�
js_info_files�Gathers files from the JsInfo providers from targets in srcs and provides them as default outputs.

This helper rule is used by the `js_run_binary` macro.
*
nameA unique name for this target. �
include_npm_sources�When True, files in `npm_sources` from `JsInfo` providers in `srcs` targets are included in the default outputs of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in `srcs` targets are also included in the default outputs of the target.
2True�
include_sourcesqWhen True, `sources` from `JsInfo` providers in `srcs` targets are included in the default outputs of the target.2True�
include_transitive_sources|When True, `transitive_sources` from `JsInfo` providers in `srcs` targets are included in the default outputs of the target.2True�
include_transitive_types�When True, `transitive_types` from `JsInfo` providers in `srcs` targets are included in the default outputs of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
include_types�When True, `types` from `JsInfo` providers in `srcs` targets are included in the default outputs of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.

NB: These are types from direct `srcs` dependencies only. You may also need to set `include_transitive_types` to True.2False3
srcs%List of targets to gather files from.2[]"/
js_info_files@@aspect_rules_js//js:defs.bzl
,
*
nameA unique name for this target. �
�
include_npm_sources�When True, files in `npm_sources` from `JsInfo` providers in `srcs` targets are included in the default outputs of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in `srcs` targets are also included in the default outputs of the target.
2True�
�
include_sourcesqWhen True, `sources` from `JsInfo` providers in `srcs` targets are included in the default outputs of the target.2True�
�
include_transitive_sources|When True, `transitive_sources` from `JsInfo` providers in `srcs` targets are included in the default outputs of the target.2True�
�
include_transitive_types�When True, `transitive_types` from `JsInfo` providers in `srcs` targets are included in the default outputs of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
�
include_types�When True, `types` from `JsInfo` providers in `srcs` targets are included in the default outputs of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.

NB: These are types from direct `srcs` dependencies only. You may also need to set `include_transitive_types` to True.2False5
3
srcs%List of targets to gather files from.2[]��js_run_devserver"��
�L
js_run_devserver*
nameA unique name for this target. >
3allow_execroot_entry_point_with_no_copy_data_to_bin2False�
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/"))) + "$(rootpath //path/to/some:file)"],
)
```2""
command2""�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

NB: `data` files are copied to the Bazel output tree before being passed
as inputs to runfiles. See `copy_data_to_bin` docstring for more info.
2[]�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/bazel-contrib/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 �
env�Environment variables of the action.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_env` is set to True.

2{}�
expand_args�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `fixed_args`.

This comes at some analysis-time cost even for a set of args that does not have any expansions.2True�

expand_env�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `env`.

This comes at some analysis-time cost even for a set of envs that does not have any expansions.2Truei
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�

fixed_args�Fixed command line arguments to pass to the Node.js when this
binary target is executed.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_args` is set to True.

Unlike the built-in `args`, which are only passed to the target when it is
executed either by the `bazel run` command or as a test, `fixed_args` are baked
into the generated launcher script so are always passed even when the binary
target is run outside of Bazel directly from the launcher script.

`fixed_args` are passed before the ones specified in `args` and before ones
that are specified on the `bazel run` or `bazel test` command line.

See https://bazel.build/reference/be/common-definitions#common-attributes-binaries
for more info on the built-in `args` attribute.
2[]*
grant_sandbox_write_permissions2False�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
include_npm_sources�When True, files in `npm_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in `data` targets are also included in the runfiles of the target.
2True�
include_sourcesjWhen True, `sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
include_transitive_sourcesuWhen True, `transitive_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
include_transitive_types�When True, `transitive_types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
include_types�When True, `types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.

NB: These are types from direct `data` dependencies only. You may also need to set `include_transitive_types` to True.2False�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.

Log levels: fatal, error, warn, info, debug2"error"�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
node_toolchain�The Node.js toolchain to use for this target.

See https://bazel-contrib.github.io/rules_nodejs/Toolchains.html

Typically this is left unset so that Bazel automatically selects the right Node.js toolchain
for the target platform. See https://bazel.build/extending/toolchains#toolchain-resolution
for more information.
2None�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2True
tool_exec_cfg2None
tool_target_cfg2None"
use_execroot_entry_point2True
ss,
*
nameA unique name for this target. @
>
3allow_execroot_entry_point_with_no_copy_data_to_bin2False�
�
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/"))) + "$(rootpath //path/to/some:file)"],
)
```2""

command2""�
�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

NB: `data` files are copied to the Bazel output tree before being passed
as inputs to runfiles. See `copy_data_to_bin` docstring for more info.
2[]�
�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
�
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/bazel-contrib/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 �
�
env�Environment variables of the action.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_env` is set to True.

2{}�
�
expand_args�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `fixed_args`.

This comes at some analysis-time cost even for a set of args that does not have any expansions.2True�
�

expand_env�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `env`.

This comes at some analysis-time cost even for a set of envs that does not have any expansions.2Truek
i
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�
�

fixed_args�Fixed command line arguments to pass to the Node.js when this
binary target is executed.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_args` is set to True.

Unlike the built-in `args`, which are only passed to the target when it is
executed either by the `bazel run` command or as a test, `fixed_args` are baked
into the generated launcher script so are always passed even when the binary
target is run outside of Bazel directly from the launcher script.

`fixed_args` are passed before the ones specified in `args` and before ones
that are specified on the `bazel run` or `bazel test` command line.

See https://bazel.build/reference/be/common-definitions#common-attributes-binaries
for more info on the built-in `args` attribute.
2[],
*
grant_sandbox_write_permissions2False�
�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
�
include_npm_sources�When True, files in `npm_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in `data` targets are also included in the runfiles of the target.
2True�
�
include_sourcesjWhen True, `sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
�
include_transitive_sourcesuWhen True, `transitive_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
�
include_transitive_types�When True, `transitive_types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
�
include_types�When True, `types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.

NB: These are types from direct `data` dependencies only. You may also need to set `include_transitive_types` to True.2False�
�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.

Log levels: fatal, error, warn, info, debug2"error"�
�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
�
node_toolchain�The Node.js toolchain to use for this target.

See https://bazel-contrib.github.io/rules_nodejs/Toolchains.html

Typically this is left unset so that Bazel automatically selects the right Node.js toolchain
for the target platform. See https://bazel.build/extending/toolchains#toolchain-resolution
for more information.
2None�
�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2True

tool_exec_cfg2None

tool_target_cfg2None$
"
use_execroot_entry_point2Trueo	js_binary*`
D
	js_binary

kwargs(2+
	js_binary@@aspect_rules_js//js:defs.bzl
*
_js_binarys
js_library*c
F

js_library

kwargs(2,

js_library@@aspect_rules_js//js:defs.bzl
aa*_js_library�js_run_binary*n
L
js_run_binary

kwargs(2/
js_run_binary@@aspect_rules_js//js:defs.bzl
��*_js_run_binarygjs_test*Z
@
js_test

kwargs(2)
js_test@@aspect_rules_js//js:defs.bzl
@@*_js_test�
//js/private:js_binary.bzlr�
,
aspect_rules_js
js/privatejs_binary.bzl%
	js_binary
_js_binary
!
js_test_js_test

�
//js/private:js_image_layer.bzlrr
1
aspect_rules_js
js/privatejs_image_layer.bzl/
js_image_layer_js_image_layer



�
//js/private:js_info_files.bzlro
0
aspect_rules_js
js/privatejs_info_files.bzl-
js_info_files_js_info_files

�
//js/private:js_library.bzlrf
-
aspect_rules_js
js/privatejs_library.bzl'

js_library_js_library

�
//js/private:js_run_binary.bzlro
0
aspect_rules_js
js/privatejs_run_binary.bzl-
js_run_binary_js_run_binary

�
!//js/private:js_run_devserver.bzlrx
3
aspect_rules_js
js/privatejs_run_devserver.bzl3
js_run_devserver_js_run_devserver

n
	:defs.bzlr_
)
aspect_tools_telemetry_reportdefs.bzl$
	TELEMETRY	TELEMETRY
4=
?%Rules for running JavaScript programs�

aspect_rules_jsjslibs.bzl�
//js/private:js_binary.bzlrk
,
aspect_rules_js
js/privatejs_binary.bzl-
js_binary_lib_js_binary_lib

�
//js/private:js_helpers.bzlr�
-
aspect_rules_js
js/privatejs_helpers.bzl'

LOG_LEVELS_LOG_LEVELS
		7
envs_for_log_level_envs_for_log_level


G
gather_files_from_js_infos_gather_files_from_js_infos
 O
gather_npm_package_store_infos_gather_npm_package_store_infos
$7
gather_npm_sources_gather_npm_sources
1
gather_runfiles_gather_runfiles
E
gather_transitive_sources_gather_transitive_sources
A
gather_transitive_types_gather_transitive_types

�
//js/private:js_library.bzlrn
-
aspect_rules_js
js/privatejs_library.bzl/
js_library_lib_js_library_lib

0Starlark libraries for building derivative rules�
$
aspect_rules_jsjsproviders.bzl�js_infoConstruct a JsInfo.*�
�
js_info&
targetSee JsInfo documentation (+
sourcesSee JsInfo documentationNone()
typesSee JsInfo documentationNone(6
transitive_sourcesSee JsInfo documentationNone(4
transitive_typesSee JsInfo documentationNone(/
npm_sourcesSee JsInfo documentationNone(;
npm_package_store_infosSee JsInfo documentationNone('
kwargsFor backward compat support(Construct a JsInfo."
A JsInfo provider24
js_info)@@aspect_rules_js//js/private:js_info.bzl
�JsInfoOEncapsulates information provided by rules in rules_js and derivative rule sets2�
�
JsInfoOEncapsulates information provided by rules in rules_js and derivative rule sets6
target,The label of target that created this JsInfo:
sources/A depset of source files produced by the target9
types0A depset of typings files produced by the targetf
transitive_sourcesPA depset of source files produced by the target and the target's transitive depsi
transitive_typesUA depset of declaration files produced by the target and the target's transitive depsk
npm_sources\A depset of files in npm package dependencies of the target and the target's transitive deps�
npm_package_store_infos�A depset of NpmPackageStoreInfo providers from non-dev npm dependencies of the target and the target's transitive dependencies to use as direct dependencies when linking downstream npm_package targets with npm_link_package"-
JsInfo#@@aspect_rules_js//js:providers.bzl
8
6
target,The label of target that created this JsInfo<
:
sources/A depset of source files produced by the target;
9
types0A depset of typings files produced by the targeth
f
transitive_sourcesPA depset of source files produced by the target and the target's transitive depsk
i
transitive_typesUA depset of declaration files produced by the target and the target's transitive depsm
k
npm_sources\A depset of files in npm package dependencies of the target and the target's transitive deps�
�
npm_package_store_infos�A depset of NpmPackageStoreInfo providers from non-dev npm dependencies of the target and the target's transitive dependencies to use as direct dependencies when linking downstream npm_package targets with npm_link_package�
//js/private:js_info.bzlr~
*
aspect_rules_js
js/privatejs_info.bzl
JsInfo_JsInfo
!
js_info_js_info

'Providers for building derivative rules�
'
aspect_rules_jsjsrepositories.bzl{http_archive*i
R
http_archive

kwargs(26
http_archive&@@aspect_rules_js//js:repositories.bzl


*maybe�rules_js_dependencies*h
X
rules_js_dependencies2?
rules_js_dependencies&@@aspect_rules_js//js:repositories.bzl
�
 //tools/build_defs/repo:http.bzlrk
.
bazel_toolstools/build_defs/repohttp.bzl+
http_archive_http_archive
6C
U�
!//tools/build_defs/repo:utils.bzlr]
/
bazel_toolstools/build_defs/repo	utils.bzl
maybemaybe
8=
?�Declare runtime dependencies

These are needed for local dev, and users must install them as well.
See https://docs.bazel.build/versions/main/skylark/deploying.html#dependencies
�
%
aspect_rules_jsjstoolchains.bzl�rules_js_register_toolchains�Configures transitive deps and toolchains required by rules_js.

Node.js toolchain comes from [rules_nodejs](https://docs.aspect.build/rulesets/rules_nodejs).
For more details on Node.js toolchain registration see
https://docs.aspect.build/rulesets/rules_nodejs/docs/core#node_repositories.

Additional required toolchains (jq, yq, copy_directory and copy_to_directory) come
from [Aspect bazel-lib](https://github.com/bazel-contrib/bazel-lib).
*�
�
rules_js_register_toolchains�
node_download_auth�Auth to use for all url requests when downloading Node

Example: {"type": "basic", "login": "<UserName>", "password": "<Password>" }{}(�
node_repositories�Custom list of node repositories to use

A dictionary mapping NodeJS versions to sets of hosts and their corresponding (filename, strip_prefix, sha256) tuples.
You should list a node binary for every platform users have, likely Mac, Windows, and Linux.

By default, if this attribute has no items, we'll use a list of all public NodeJS releases.{}(�
	node_urls�Custom list of URLs to use to download NodeJS

Each entry is a template for downloading a node distribution.

The `{version}` parameter is substituted with the `node_version` attribute,
and `{filename}` with the matching entry from the `node_repositories` attribute.None(F
node_version)The specific version of NodeJS to install	"18.20.4"(�
node_version_from_nvmrc�The label of the .nvmrc file containing the version of node

If set then the version is set to the version found in the .nvmrc file.

Requires a minimum rules_nodejs version of 6.1.0.None(
kwargs
Other args(�Configures transitive deps and toolchains required by rules_js.

Node.js toolchain comes from [rules_nodejs](https://docs.aspect.build/rulesets/rules_nodejs).
For more details on Node.js toolchain registration see
https://docs.aspect.build/rulesets/rules_nodejs/docs/core#node_repositories.

Additional required toolchains (jq, yq, copy_directory and copy_to_directory) come
from [Aspect bazel-lib](https://github.com/bazel-contrib/bazel-lib).
2D
rules_js_register_toolchains$@@aspect_rules_js//js:toolchains.bzl
*nodejs_register_toolchains�
//lib:repositories.bzlr�
)
aspect_bazel_liblibrepositories.bzlW
"register_copy_directory_toolchains#_register_copy_directory_toolchains
(]
%register_copy_to_directory_toolchains&_register_copy_to_directory_toolchains
+M
register_coreutils_toolchains_register_coreutils_toolchains
#?
register_jq_toolchains_register_jq_toolchains
		A
register_tar_toolchains_register_tar_toolchains


?
register_yq_toolchains_register_yq_toolchains

�
//nodejs:repositories.bzlr�
(
rules_nodejsnodejsrepositories.bzlF
nodejs_register_toolchainsnodejs_register_toolchains
1KA
DEFAULT_NODE_REPOSITORY_DEFAULT_NODE_REPOSITORY
Nf=
DEFAULT_NODE_VERSION_DEFAULT_NODE_VERSION
��
�-	DEFAULT_NODE_REPOSITORYnodejsjnodejs,	DEFAULT_NODE_VERSION18.20.4j	18.20.4JConfigures transitive deps and registers toolchains required by rules_js.
�
F
aspect_rules_jsnpm/private/test/snapshotsfsevents_links_defs.bzl�npm_imported_package_store*�
�
npm_imported_package_store
link_root_name (2c
npm_imported_package_storeE@@aspect_rules_js//npm/private/test/snapshots:fsevents_links_defs.bzl
�npm_link_imported_package*�
�
npm_link_imported_package
name"node_modules"(
linkTrue(
fail_if_no_linkTrue(2b
npm_link_imported_packageE@@aspect_rules_js//npm/private/test/snapshots:fsevents_links_defs.bzl
??2_npm_link_imported_package�npm_link_imported_package_store*�
�
npm_link_imported_package_store

name (
link_root_name (

link_alias (2h
npm_link_imported_package_storeE@@aspect_rules_js//npm/private/test/snapshots:fsevents_links_defs.bzl
112 _npm_link_imported_package_store�
//npm/private:npm_import.bzlr�
.
aspect_rules_jsnpm/privatenpm_import.bzlP
#npm_imported_package_store_internal_npm_imported_package_store
 N
"npm_link_imported_package_internal_npm_link_imported_package
Z
(npm_link_imported_package_store_internal _npm_link_imported_package_store
%
	�
,//npm/private:npm_package_store_internal.bzlr�
>
aspect_rules_jsnpm/privatenpm_package_store_internal.bzl>
npm_package_store_internal_npm_package_store
FX
x!	PACKAGEfseventsj
fsevents	VERSION2.3.2j2.3.2Y@generated by @aspect_rules_js//npm/private:npm_import.bzl for npm package fsevents@2.3.2�
;
aspect_rules_jsnpm/private/test/snapshotsnpm_defs.bzl*�ModuleInfo request error: invalid argument: Invalid load statement '@@_main~npm~npm__abbrev__1.1.1__links//:defs.bzl' in file @@aspect_rules_js//npm/private/test/snapshots:npm_defs.bzl (external/aspect_rules_js/npm/private/test/snapshots/npm_defs.bzl): invalid repository name '_main~npm~npm__abbrev__1.1.1__links': repo names may contain only A-Z, a-z, 0-9, '-', '_', '.' and '+'�
?
aspect_rules_jsnpm/private/test/snapshotspackage_json.bzl�bin_factory*�
r
bin_factory
link_root_name (2M
bin_factory>@@aspect_rules_js//npm/private/test/snapshots:package_json.bzl
00�rollup*�
j
rollup

name (

kwargs(2H
rollup>@@aspect_rules_js//npm/private/test/snapshots:package_json.bzl
''*_rollup_internal�rollup_binary*�
x
rollup_binary

name (

kwargs(2O
rollup_binary>@@aspect_rules_js//npm/private/test/snapshots:package_json.bzl
--*_rollup_binary_internal�rollup_test*�
t
rollup_test

name (

kwargs(2M
rollup_test>@@aspect_rules_js//npm/private/test/snapshots:package_json.bzl
***_rollup_test_internal�
//npm/private:npm_import.bzlr�
.
aspect_rules_jsnpm/privatenpm_import.bzl8
bin_binary_internalbin_binary_internal
7J*
bin_internalbin_internal
NZ4
bin_test_internalbin_test_internal
^o
qX@generated by @aspect_rules_js//npm/private:npm_import.bzl for npm package rollup@2.70.2�

K
aspect_rules_jsnpm/private/test/snapshotspackage_json_with_dashes.bzl�bin_factory*�
~
bin_factory
link_root_name (2Y
bin_factoryJ@@aspect_rules_js//npm/private/test/snapshots:package_json_with_dashes.bzl
00�webpack_bundle_analyzer*�
�
webpack_bundle_analyzer

name (

kwargs(2e
webpack_bundle_analyzerJ@@aspect_rules_js//npm/private/test/snapshots:package_json_with_dashes.bzl
''*!_webpack_bundle_analyzer_internal�webpack_bundle_analyzer_binary*�
�
webpack_bundle_analyzer_binary

name (

kwargs(2l
webpack_bundle_analyzer_binaryJ@@aspect_rules_js//npm/private/test/snapshots:package_json_with_dashes.bzl
--*(_webpack_bundle_analyzer_binary_internal�webpack_bundle_analyzer_test*�
�
webpack_bundle_analyzer_test

name (

kwargs(2j
webpack_bundle_analyzer_testJ@@aspect_rules_js//npm/private/test/snapshots:package_json_with_dashes.bzl
***&_webpack_bundle_analyzer_test_internal�
//npm/private:npm_import.bzlr�
.
aspect_rules_jsnpm/privatenpm_import.bzl8
bin_binary_internalbin_binary_internal
7J*
bin_internalbin_internal
NZ4
bin_test_internalbin_test_internal
^o
qy@generated by @aspect_rules_js//npm/private:npm_import.bzl for npm package webpack-bundle-analyzer@4.5.0_bufferutil_4.0.8�
D
aspect_rules_jsnpm/private/test/snapshotsrollup_links_defs.bzl�npm_imported_package_store*�
�
npm_imported_package_store
link_root_name (2a
npm_imported_package_storeC@@aspect_rules_js//npm/private/test/snapshots:rollup_links_defs.bzl
�npm_link_imported_package*�
�
npm_link_imported_package
name"node_modules"(
linkNone(
fail_if_no_linkTrue(2`
npm_link_imported_packageC@@aspect_rules_js//npm/private/test/snapshots:rollup_links_defs.bzl
AA2_npm_link_imported_package�npm_link_imported_package_store*�
�
npm_link_imported_package_store

name (
link_root_name (

link_alias (2f
npm_link_imported_package_storeC@@aspect_rules_js//npm/private/test/snapshots:rollup_links_defs.bzl
332 _npm_link_imported_package_store�
//npm/private:npm_import.bzlr�
.
aspect_rules_jsnpm/privatenpm_import.bzlP
#npm_imported_package_store_internal_npm_imported_package_store
 N
"npm_link_imported_package_internal_npm_link_imported_package
Z
(npm_link_imported_package_store_internal _npm_link_imported_package_store
%
	�
,//npm/private:npm_package_store_internal.bzlr�
>
aspect_rules_jsnpm/privatenpm_package_store_internal.bzl>
npm_package_store_internal_npm_package_store
FX
x	VERSION2.70.2j2.70.2	PACKAGErollupjrollupX@generated by @aspect_rules_js//npm/private:npm_import.bzl for npm package rollup@2.70.2�
D
aspect_rules_jsnpm/private/test/snapshotsunused_links_defs.bzl�npm_imported_package_store*�
�
npm_imported_package_store
link_root_name (2a
npm_imported_package_storeC@@aspect_rules_js//npm/private/test/snapshots:unused_links_defs.bzl
�npm_link_imported_package*�
�
npm_link_imported_package
name"node_modules"(
linkNone(
fail_if_no_linkTrue(2`
npm_link_imported_packageC@@aspect_rules_js//npm/private/test/snapshots:unused_links_defs.bzl
HH2_npm_link_imported_package�npm_link_imported_package_store*�
�
npm_link_imported_package_store

name (
link_root_name (

link_alias (2f
npm_link_imported_package_storeC@@aspect_rules_js//npm/private/test/snapshots:unused_links_defs.bzl
::2 _npm_link_imported_package_store�
//npm/private:npm_import.bzlr�
.
aspect_rules_jsnpm/privatenpm_import.bzlP
#npm_imported_package_store_internal_npm_imported_package_store
 N
"npm_link_imported_package_internal_npm_link_imported_package
Z
(npm_link_imported_package_store_internal _npm_link_imported_package_store
%
	�
,//npm/private:npm_package_store_internal.bzlr�
>
aspect_rules_jsnpm/privatenpm_package_store_internal.bzl>
npm_package_store_internal_npm_package_store
FX
x	PACKAGEunusedjunused	VERSION0.2.2j0.2.2W@generated by @aspect_rules_js//npm/private:npm_import.bzl for npm package unused@0.2.2�
D
aspect_rules_jsnpm/private$exclude_package_contents_default.bzl�	 exclude_package_contents_defaultj�2�
**/__tests__/**

**/test/**
**/tests/**
**/powered-test/**

**/docs/**
	**/doc/**
**/website/**
**/images/**
**/assets/**
**/example/**
**/examples/**
**/coverage/**
**/.nyc_output/**

Makefile
Gulpfile.js
Gruntfile.js
appveyor.yml

circle.yml
codeship-services.yml
codeship-steps.yml
wercker.yml
.tern-project
.gitattributes
.editorconfig

.*ignore
	.eslintrc
	.jshintrc
.flowconfig
.documentup.json
.yarn-metadata.json
.travis.yml
*.md�A default files exclude list for common packages.

Based on Yarn autoclean; see
https://github.com/yarnpkg/yarn/blob/7cafa512a777048ce0b666080a24e80aae3d66a9/src/cli/commands/autoclean.js#L16
�
0
aspect_rules_jsnpm/privatelist_sources.bzl�list_sources"�
�
list_sources*
nameA unique name for this target. 
srcs2[]"?
list_sources/@@aspect_rules_js//npm/private:list_sources.bzl
,
*
nameA unique name for this target. 

srcs2[]'Output a list of source files to a file��
.
aspect_rules_jsnpm/privatenpm_import.bzl�bin_binary_internal*�
�
bin_binary_internal

name ( 
link_workspace_and_package (
link_root_name (
package_store_name (
bin_path (

kwargs(2D
bin_binary_internal-@@aspect_rules_js//npm/private:npm_import.bzl
��*
_js_binary2_directory_path2
_js_binary�bin_internal*�
�
bin_internal

name ( 
link_workspace_and_package (
link_root_name (
package_store_name (
bin_path (
bin_mnemonic (

kwargs(2=
bin_internal-@@aspect_rules_js//npm/private:npm_import.bzl
��*_js_run_binary2_directory_path2
_js_binary2_js_run_binary�bin_test_internal*�
�
bin_test_internal

name ( 
link_workspace_and_package (
link_root_name (
package_store_name (
bin_path (

kwargs(2B
bin_test_internal-@@aspect_rules_js//npm/private:npm_import.bzl
��*_js_test2_directory_path2_js_test�|
npm_import�#Import a single npm package into Bazel.

Normally you'd want to use `npm_translate_lock` to import all your packages at once.
It generates `npm_import` rules.
You can create these manually if you want to have exact control.

Bazel will only fetch the given package from an external registry if the package is
required for the user-requested targets to be build/tested.

This is a repository rule, which should be called from your `WORKSPACE` file
or some `.bzl` file loaded from it. For example, with this code in `WORKSPACE`:

```starlark
npm_import(
    name = "npm__at_types_node__15.12.2",
    package = "@types/node",
    version = "15.12.2",
    integrity = "sha512-zjQ69G564OCIWIOHSXyQEEDpdpGl+G348RAKY0XXy9Z5kU9Vzv1GMNnkar/ZJ8dzXB3COzD9Mo9NtRZ4xfgUww==",
)
```

In `MODULE.bazel` the same would look like so:

```starlark
npm.npm_import(
    name = "npm__at_types_node__15.12.2",
    package = "@types/node",
    version = "15.12.2",
    integrity = "sha512-zjQ69G564OCIWIOHSXyQEEDpdpGl+G348RAKY0XXy9Z5kU9Vzv1GMNnkar/ZJ8dzXB3COzD9Mo9NtRZ4xfgUww==",v
)
use_repo(npm, "npm__at_types_node__15.12.2")
use_repo(npm, "npm__at_types_node__15.12.2__links")
```

> This is similar to Bazel rules in other ecosystems named "_import" like
> `apple_bundle_import`, `scala_import`, `java_import`, and `py_import`.
> `go_repository` is also a model for this rule.

The name of this repository should contain the version number, so that multiple versions of the same
package don't collide.
(Note that the npm ecosystem always supports multiple versions of a library depending on where
it is required, unlike other languages like Go or Python.)

To consume the downloaded package in rules, it must be "linked" into the link package in the
package's `BUILD.bazel` file:

```
load("@npm__at_types_node__15.12.2__links//:defs.bzl", npm_link_types_node = "npm_link_imported_package")

npm_link_types_node(name = "node_modules")
```

This links `@types/node` into the `node_modules` of this package with the target name `:node_modules/@types/node`.

A `:node_modules/@types/node/dir` filegroup target is also created that provides the the directory artifact of the npm package.
This target can be used to create entry points for binary target or to access files within the npm package.

NB: You can choose any target name for the link target but we recommend using the `node_modules/@scope/name` and
`node_modules/name` convention for readability.

When using `npm_translate_lock`, you can link all the npm dependencies in the lock file for a package:

```
load("@npm//:defs.bzl", "npm_link_all_packages")

npm_link_all_packages(name = "node_modules")
```

This creates `:node_modules/name` and `:node_modules/@scope/name` targets for all direct npm dependencies in the package.
It also creates `:node_modules/name/dir` and `:node_modules/@scope/name/dir` filegroup targets that provide the the directory artifacts of their npm packages.
These target can be used to create entry points for binary target or to access files within the npm package.

If you have a mix of `npm_link_all_packages` and `npm_link_imported_package` functions to call you can pass the
`npm_link_imported_package` link functions to the `imported_links` attribute of `npm_link_all_packages` to link
them all in one call. For example,

```
load("@npm//:defs.bzl", "npm_link_all_packages")
load("@npm__at_types_node__15.12.2__links//:defs.bzl", npm_link_types_node = "npm_link_imported_package")

npm_link_all_packages(
    name = "node_modules",
    imported_links = [
        npm_link_types_node,
    ]
)
```

This has the added benefit of adding the `imported_links` to the convienence `:node_modules` target which
includes all direct dependencies in that package.

NB: You can pass an name to npm_link_all_packages and this will change the targets generated to "{name}/@scope/name" and
"{name}/name". We recommend using "node_modules" as the convention for readability.

To change the proxy URL we use to fetch, configure the Bazel downloader:

1. Make a file containing a rewrite rule like

    `rewrite (registry.npmjs.org)/(.*) artifactory.build.internal.net/artifactory/$1/$2`

1. To understand the rewrites, see [UrlRewriterConfig] in Bazel sources.

1. Point bazel to the config with a line in .bazelrc like
common --experimental_downloader_config=.bazel_downloader_config

Read more about the downloader config: <https://blog.aspect.build/configuring-bazels-downloader>

[UrlRewriterConfig]: https://github.com/bazelbuild/bazel/blob/4.2.1/src/main/java/com/google/devtools/build/lib/bazel/repository/downloader/UrlRewriterConfig.java#L66
*�X
�X

npm_import)
nameName for this repository rule (H
package9Name of the npm package, such as `acorn` or `@types/node` (:
version+Version of the npm package, such as `8.4.0` (v
depshA dict other npm packages this one depends on where the key is the package name and value is the version{}(�
extra_build_content�Additional content to append on the generated BUILD file at the root of
the created repository, either as a string or a list of lines similar to
<https://github.com/bazelbuild/bazel-skylib/blob/main/docs/write_file_doc.md>.""(�
transitive_closure�A dict all npm packages this one depends on directly or transitively where the key is the
package name and value is a list of version(s) depended on in the closure.{}(�
root_package�The root package where the node_modules package store is linked to.
Typically this is the package that the pnpm-lock.yaml file is located when using `npm_translate_lock`.""(�
link_workspace�The workspace name where links will be created for this package.

This is typically set in rule sets and libraries that are to be consumed as external repositories so
links are created in the external repository and not the user workspace.

Can be left unspecified if the link workspace is the user workspace.""(�
link_packages�Dict of paths where links may be created at for this package to
a list of link aliases to link as in each package. If aliases are an
empty list this indicates to link as the package name.

Defaults to {} which indicates that links may be created in any package as specified by
the `direct` attribute of the generated npm_link_package.{}(m
lifecycle_hooksTList of lifecycle hook `package.json` scripts to run for this package if they exist.[](�
&lifecycle_hooks_execution_requirements�Execution requirements when running the lifecycle hooks.

For example:

```
lifecycle_hooks_execution_requirements: ["no-sandbox', "requires-network"]
```

This defaults to ["no-sandbox"] to limit the overhead of sandbox creation and copying the output
TreeArtifact out of the sandbox.["no-sandbox"](�
lifecycle_hooks_env�Environment variables set for the lifecycle hooks action for this npm
package if there is one.

Environment variables are defined by providing an array of "key=value" entries.

For example:

```
lifecycle_hooks_env: ["PREBULT_BINARY=https://downloadurl"],
```[](�
%lifecycle_hooks_use_default_shell_env�If True, the `use_default_shell_env` attribute of lifecycle hook
actions is set to True.

See [use_default_shell_env](https://bazel.build/rules/lib/builtins/actions#run.use_default_shell_env)

Note: [--incompatible_merge_fixed_and_default_shell_env](https://bazel.build/reference/command-line-reference#flag--incompatible_merge_fixed_and_default_shell_env)
is often required and not enabled by default in Bazel < 7.0.0.

This defaults to False reduce the negative effects of `use_default_shell_env`. Requires bazel-lib >= 2.4.2.False(�
	integrity�Expected checksum of the file downloaded, in Subresource Integrity format.
This must match the checksum of the file downloaded.

This is the same as appears in the pnpm-lock.yaml, yarn.lock or package-lock.json file.

It is a security risk to omit the checksum as remote files can change.

At best omitting this field will make your build non-hermetic.

It is optional to make development easier but should be set before shipping.""(�
url�Optional url for this package. If unset, a default npm registry url is generated from
the package name and version.

May start with `git+ssh://` or `git+https://` to indicate a git repository. For example,

```
git+ssh://git@github.com/org/repo.git
```

If url is configured as a git repository, the commit attribute must be set to the
desired commit.""(M
commit=Specific commit to be checked out if url is a git repository.""(�
replace_package�Use the specified npm_package target when linking instead of the fetched sources for this npm package.

The injected npm_package target may optionally contribute transitive npm package dependencies on top
of the transitive dependencies specified in the pnpm lock file for the same package, however, these
transitive dependencies must not collide with pnpm lock specified transitive dependencies.

Any patches specified for this package will be not applied to the injected npm_package target. They
will be applied, however, to the fetches sources so they can still be useful for patching the fetched
`package.json` file, which is used to determine the generated bin entries for the package.

NB: lifecycle hooks and custom_postinstall scripts, if implicitly or explicitly enabled, will be run on
the injected npm_package. These may be disabled explicitly using the `lifecycle_hooks` attribute.None(b
package_visibility1Visibility of generated node_module link targets.["//visibility:public"](_

patch_toolIThe patch tool to use. If not specified, the `patch` from `PATH` is used.None(y

patch_args`Arguments to pass to the patch tool.

`-p1` will usually be needed for patches generated by git.["-p0"](F
patches5Patch files to apply onto the downloaded npm package.[](�
custom_postinstall�Custom string postinstall script to run on the installed npm package.

Runs after any existing lifecycle hooks if any are enabled.""(X
npm_authFAuth token to authenticate with npm. When using Bearer authentication.""(�
npm_auth_basic�Auth token to authenticate with npm. When using Basic authentication.

This is typically the base64 encoded string "username:password".""(c
npm_auth_usernameHAuth username to authenticate with npm. When using Basic authentication.""(c
npm_auth_passwordHAuth password to authenticate with npm. When using Basic authentication.""(�
bins�Dictionary of `node_modules/.bin` binary files to create mapped to their node entry points.

This is typically derived from the "bin" attribute in the package.json
file of the npm package being linked.

For example:

```
bins = {
    "foo": "./foo.js",
    "bar": "./bar.js",
}
```

In the future, this field may be automatically populated by npm_translate_lock
from information in the pnpm lock file. That feature is currently blocked on
https://github.com/pnpm/pnpm/issues/5131.{}(<
dev,Whether this npm package is a dev dependencyFalse(�
exclude_package_contents�List of glob patterns to exclude from the linked package.

This is useful for excluding files that are not needed in the linked package.

For example:

```
exclude_package_contents = ["**/tests/**"]
```[](
kwargsInternal use only(�#Import a single npm package into Bazel.

Normally you'd want to use `npm_translate_lock` to import all your packages at once.
It generates `npm_import` rules.
You can create these manually if you want to have exact control.

Bazel will only fetch the given package from an external registry if the package is
required for the user-requested targets to be build/tested.

This is a repository rule, which should be called from your `WORKSPACE` file
or some `.bzl` file loaded from it. For example, with this code in `WORKSPACE`:

```starlark
npm_import(
    name = "npm__at_types_node__15.12.2",
    package = "@types/node",
    version = "15.12.2",
    integrity = "sha512-zjQ69G564OCIWIOHSXyQEEDpdpGl+G348RAKY0XXy9Z5kU9Vzv1GMNnkar/ZJ8dzXB3COzD9Mo9NtRZ4xfgUww==",
)
```

In `MODULE.bazel` the same would look like so:

```starlark
npm.npm_import(
    name = "npm__at_types_node__15.12.2",
    package = "@types/node",
    version = "15.12.2",
    integrity = "sha512-zjQ69G564OCIWIOHSXyQEEDpdpGl+G348RAKY0XXy9Z5kU9Vzv1GMNnkar/ZJ8dzXB3COzD9Mo9NtRZ4xfgUww==",v
)
use_repo(npm, "npm__at_types_node__15.12.2")
use_repo(npm, "npm__at_types_node__15.12.2__links")
```

> This is similar to Bazel rules in other ecosystems named "_import" like
> `apple_bundle_import`, `scala_import`, `java_import`, and `py_import`.
> `go_repository` is also a model for this rule.

The name of this repository should contain the version number, so that multiple versions of the same
package don't collide.
(Note that the npm ecosystem always supports multiple versions of a library depending on where
it is required, unlike other languages like Go or Python.)

To consume the downloaded package in rules, it must be "linked" into the link package in the
package's `BUILD.bazel` file:

```
load("@npm__at_types_node__15.12.2__links//:defs.bzl", npm_link_types_node = "npm_link_imported_package")

npm_link_types_node(name = "node_modules")
```

This links `@types/node` into the `node_modules` of this package with the target name `:node_modules/@types/node`.

A `:node_modules/@types/node/dir` filegroup target is also created that provides the the directory artifact of the npm package.
This target can be used to create entry points for binary target or to access files within the npm package.

NB: You can choose any target name for the link target but we recommend using the `node_modules/@scope/name` and
`node_modules/name` convention for readability.

When using `npm_translate_lock`, you can link all the npm dependencies in the lock file for a package:

```
load("@npm//:defs.bzl", "npm_link_all_packages")

npm_link_all_packages(name = "node_modules")
```

This creates `:node_modules/name` and `:node_modules/@scope/name` targets for all direct npm dependencies in the package.
It also creates `:node_modules/name/dir` and `:node_modules/@scope/name/dir` filegroup targets that provide the the directory artifacts of their npm packages.
These target can be used to create entry points for binary target or to access files within the npm package.

If you have a mix of `npm_link_all_packages` and `npm_link_imported_package` functions to call you can pass the
`npm_link_imported_package` link functions to the `imported_links` attribute of `npm_link_all_packages` to link
them all in one call. For example,

```
load("@npm//:defs.bzl", "npm_link_all_packages")
load("@npm__at_types_node__15.12.2__links//:defs.bzl", npm_link_types_node = "npm_link_imported_package")

npm_link_all_packages(
    name = "node_modules",
    imported_links = [
        npm_link_types_node,
    ]
)
```

This has the added benefit of adding the `imported_links` to the convienence `:node_modules` target which
includes all direct dependencies in that package.

NB: You can pass an name to npm_link_all_packages and this will change the targets generated to "{name}/@scope/name" and
"{name}/name". We recommend using "node_modules" as the convention for readability.

To change the proxy URL we use to fetch, configure the Bazel downloader:

1. Make a file containing a rewrite rule like

    `rewrite (registry.npmjs.org)/(.*) artifactory.build.internal.net/artifactory/$1/$2`

1. To understand the rewrites, see [UrlRewriterConfig] in Bazel sources.

1. Point bazel to the config with a line in .bazelrc like
common --experimental_downloader_config=.bazel_downloader_config

Read more about the downloader config: <https://blog.aspect.build/configuring-bazels-downloader>

[UrlRewriterConfig]: https://github.com/bazelbuild/bazel/blob/4.2.1/src/main/java/com/google/devtools/build/lib/bazel/repository/downloader/UrlRewriterConfig.java#L66
2;

npm_import-@@aspect_rules_js//npm/private:npm_import.bzl
��2npm_import_rule�#npm_imported_package_store_internal*�
�
#npm_imported_package_store_internal
link_root_name (
package (
version (
root_package (

deps (
ref_deps (
lc_deps (	
dev ( 
has_lifecycle_build_target ( 
transitive_closure_pattern (
npm_package_target (
package_store_name (
lifecycle_hooks_env (,
&lifecycle_hooks_execution_requirements (
use_default_shell_env (
exclude_package_contents (2T
#npm_imported_package_store_internal-@@aspect_rules_js//npm/private:npm_import.bzl
SS"npm_package_internal�"npm_link_imported_package_internal*�
�
"npm_link_imported_package_internal

name (
package (
version (
root_package (

link (
link_packages (
public_visibility (+
%npm_link_imported_package_store_macro (&
 npm_imported_package_store_macro (
fail_if_no_linkTrue(2S
"npm_link_imported_package_internal-@@aspect_rules_js//npm/private:npm_import.bzl
��2 npm_imported_package_store_macro�(npm_link_imported_package_store_internal*�
�
(npm_link_imported_package_store_internal

name (
link_root_name (

link_alias (
root_package (
link_visibility (

bins (
package_store_name (
public_visibility (2Y
(npm_link_imported_package_store_internal-@@aspect_rules_js//npm/private:npm_import.bzl
��"npm_link_package_store2npm_link_package_store�npm_import_linksR�
�
npm_import_links.
name"A unique name for this repository. 
bins
2{}
deps
2{}
dev2False 
exclude_package_contents2[]!
lifecycle_build_target2False
lifecycle_hooks_env2[].
&lifecycle_hooks_execution_requirements2[]0
%lifecycle_hooks_use_default_shell_env2False
link_packages 
package 
package_visibility2[]
replace_package2""�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 
root_package2""
transitive_closure 
version *A
npm_import_links-@@aspect_rules_js//npm/private:npm_import.bzl
�#�#0
.
name"A unique name for this repository. 

bins
2{}

deps
2{}

dev2False"
 
exclude_package_contents2[]#
!
lifecycle_build_target2False

lifecycle_hooks_env2[]0
.
&lifecycle_hooks_execution_requirements2[]2
0
%lifecycle_hooks_use_default_shell_env2False

link_packages 

package 

package_visibility2[]

replace_package2""�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 

root_package2""

transitive_closure 

version �npm_import_ruleR�
�
npm_import_rule.
name"A unique name for this repository. 
commit2""
custom_postinstall2"" 
exclude_package_contents2[]
extra_build_content2""
extract_full_archive2False'
generate_bzl_library_targets2False
	integrity2""
lifecycle_hooks2[]
link_packages 
link_workspace2""
npm_auth2""
npm_auth_basic2""
npm_auth_password2""
npm_auth_username2""
package 

patch_args2[]

patch_tool2None
patches2[]�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 
root_package2""

system_tar2"auto"
url2""
version *@
npm_import_rule-@@aspect_rules_js//npm/private:npm_import.bzl
�"�"0
.
name"A unique name for this repository. 

commit2""

custom_postinstall2"""
 
exclude_package_contents2[]

extra_build_content2""!

extract_full_archive2False)
'
generate_bzl_library_targets2False

	integrity2""

lifecycle_hooks2[]

link_packages 

link_workspace2""

npm_auth2""

npm_auth_basic2""

npm_auth_password2""

npm_auth_username2""

package 


patch_args2[]


patch_tool2None

patches2[]�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 

root_package2""


system_tar2"auto"

url2""

version �
//lib:directory_path.bzlrl
+
aspect_bazel_liblibdirectory_path.bzl/
directory_path_directory_path
3B
V�
//lib:repo_utils.bzlr}
'
aspect_bazel_liblibrepo_utils.bzl
patchpatch
05&

repo_utils
repo_utils
9C
E�
//js:defs.bzlr�

aspect_rules_jsjsdefs.bzl%
	js_binary
_js_binary
'1-
js_run_binary_js_run_binary
AO!
js_test_js_test
ck
x�
(//npm/private:npm_link_package_store.bzlr�
:
aspect_rules_jsnpm/privatenpm_link_package_store.bzl>
npm_link_package_storenpm_link_package_store
CY
[�
&//npm/private:npm_package_internal.bzlr�
8
aspect_rules_jsnpm/privatenpm_package_internal.bzl:
npm_package_internalnpm_package_internal
AU
W�
,//npm/private:npm_package_store_internal.bzlr�
>
aspect_rules_jsnpm/privatenpm_package_store_internal.bzl>
npm_package_store_internal_npm_package_store
FX
x�
(//npm/private:starlark_codegen_utils.bzlr�
:
aspect_rules_jsnpm/privatestarlark_codegen_utils.bzl>
starlark_codegen_utilsstarlark_codegen_utils
CY
[�
//npm/private:tar.bzlrm
'
aspect_rules_jsnpm/privatetar.bzl4
detect_system_tardetect_system_tar
0A
Ct
//npm/private:utils.bzlrW
)
aspect_rules_jsnpm/private	utils.bzl
utilsutils
27
9a
//lib:dicts.bzlrL

bazel_skyliblib	dicts.bzl
dictsdicts
',
.a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.�
&//tools/build_defs/repo:git_worker.bzlr�
4
bazel_toolstools/build_defs/repogit_worker.bzl+

add_origin_git_add_origin
!!!
clean
_git_clean
""!
fetch
_git_fetch
##
init	_git_init
$$!
reset
_git_reset
%%
&�
Repository rule to fetch npm packages.

Load this with,

```starlark
load("@aspect_rules_js//npm:repositories.bzl", "npm_import")
```

This uses Bazel's downloader to fetch the packages.
You can use this to redirect all fetches through a store like Artifactory.

See &lt;https://blog.aspect.build/configuring-bazels-downloader&gt; for more info about how it works
and how to configure it.

See [`npm_translate_lock`](#npm_translate_lock) for the primary user-facing API to fetch npm packages
for a given lockfile.
�[
4
aspect_rules_jsnpm/privatenpm_link_package.bzl�Wnpm_link_package�"Links an npm package to node_modules if link is True.

When called at the root_package, a package store target is generated named `link__{bazelified_name}__store`.

When linking, a `{name}` target is generated which consists of the `node_modules/<package>` symlink and transitively
its package store link and the package store links of the transitive closure of deps.

When linking, `{name}/dir` filegroup is also generated that refers to a directory artifact can be used to access
the package directory for creating entry points or accessing files in the package.


Defines a npm package that is linked into a node_modules tree.

The npm package is linked with a pnpm style symlinked node_modules output tree.

The term "package" is defined at
<https://nodejs.org/docs/latest-v16.x/api/packages.html>

See https://pnpm.io/symlinked-node-modules-structure for more information on
the symlinked node_modules structure.
Npm may also support a symlinked node_modules structure called
"Isolated mode" in the future:
https://github.com/npm/rfcs/blob/main/accepted/0042-isolated-mode.md.
"�N
�+
npm_link_package�"Links an npm package to node_modules if link is True.

When called at the root_package, a package store target is generated named `link__{bazelified_name}__store`.

When linking, a `{name}` target is generated which consists of the `node_modules/<package>` symlink and transitively
its package store link and the package store links of the transitive closure of deps.

When linking, `{name}/dir` filegroup is also generated that refers to a directory artifact can be used to access
the package directory for creating entry points or accessing files in the package.


Defines a npm package that is linked into a node_modules tree.

The npm package is linked with a pnpm style symlinked node_modules output tree.

The term "package" is defined at
<https://nodejs.org/docs/latest-v16.x/api/packages.html>

See https://pnpm.io/symlinked-node-modules-structure for more information on
the symlinked node_modules structure.
Npm may also support a symlinked node_modules structure called
"Isolated mode" in the future:
https://github.com/npm/rfcs/blob/main/accepted/0042-isolated-mode.md.
*
nameA unique name for this target. �
deps�Other node packages store link targets one depends on mapped to the name to link them under in this packages deps.

This should include *all* modules the program may need at runtime.

You can find all the package store link targets in your repository with

```
bazel query ... | grep :.aspect_rules_js | grep -v /dir | grep -v /pkg | grep -v /ref
```

Package store link targets names for 3rd party packages that come from `npm_translate_lock`
start with `.aspect_rules_js/` then the name passed to the `npm_link_all_packages` macro
(typically `node_modules`) followed by `/<package>/<version>` where `package` is the
package name (including @scope segment if any) and `version` is the specific version of
the package that comes from the pnpm-lock.yaml file.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

The version may include peer dep(s),

```
//:.aspect_rules_js/node_modules/debug/4.3.4_supports-color@8.1.1
```

It could be also be a url based version,

```
//:.aspect_rules_js/node_modules/debug/github.com/ngokevin/debug/9742c5f383a6f8046241920156236ade8ec30d53
```

Package store link targets names for 3rd party package that come directly from an
`npm_import` start with `.aspect_rules_js/` then the name passed to the `npm_import`'s `npm_link_imported_package`
macro (typically `node_modules`) followed by `/<package>/<version>` where `package`
matches the `package` attribute in the npm_import of the package and `version` matches the
`version` attribute.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

Package store link targets names for 1st party packages automatically linked by `npm_link_all_packages`
using workspaces will follow the same pattern as 3rd party packages with the version typically defaulting
to "0.0.0".

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg/0.0.0
```

Package store link targets names for 1st party packages manually linked with `npm_link_package`
start with `.aspect_rules_js/` followed by the name passed to the `npm_link_package`.

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg
```

> In typical usage, a node.js program sometimes requires modules which were
> never declared as dependencies.
> This pattern is typically used when the program has conditional behavior
> that is enabled when the module is found (like a plugin) but the program
> also runs without the dependency.
> 
> This is possible because node.js doesn't enforce the dependencies are sound.
> All files under `node_modules` are available to any program.
> In contrast, Bazel makes it possible to make builds hermetic, which means that
> all dependencies of a program must be declared when running in Bazel's sandbox.
	*
NpmPackageStoreInfo
JsInfo2{}<
dev,Whether this npm package is a dev dependency2False�
exclude_package_contents�List of exclude patterns to exclude files from the package store.

The exclude patterns are relative to the package store directory.
2[]�
hardlink�Controls when to use hardlinks to files instead of making copies.

Creating hardlinks is much faster than making copies of files with the caveat that
hardlinks share file permissions with their source.

Since Bazel removes write permissions on files in the output tree after an action completes,
hardlinks to source files is not recommended since write permissions will be inadvertently
removed from sources files.

- "auto": hardlinks are used for generated files already in the output tree
- "off": all files are copied
- "on": hardlinks are used for all files (not recommended)

NB: Hardlinking source files in external repositories as was done under the hood
prior to https://github.com/aspect-build/rules_js/pull/1533 may lead to flaky build
failures as reported in https://github.com/aspect-build/rules_js/issues/1412.
2"auto"�
package�The package name to link to.

If unset, the package name in the `NpmPackageInfo` src must be set.
If set, takes precendance over the package name in the `NpmPackageInfo` src.
2""]
srcRA target providing a `NpmPackageInfo` or `JsInfo` containing the package sources.
 >
verbose*If true, prints out verbose logs to stdout2False�
version�The package version being linked.

If unset, the package version in the `NpmPackageInfo` src must be set.
If set, takes precendance over the package version in the `NpmPackageInfo` src.
2""
,
*
nameA unique name for this target. �
�
deps�Other node packages store link targets one depends on mapped to the name to link them under in this packages deps.

This should include *all* modules the program may need at runtime.

You can find all the package store link targets in your repository with

```
bazel query ... | grep :.aspect_rules_js | grep -v /dir | grep -v /pkg | grep -v /ref
```

Package store link targets names for 3rd party packages that come from `npm_translate_lock`
start with `.aspect_rules_js/` then the name passed to the `npm_link_all_packages` macro
(typically `node_modules`) followed by `/<package>/<version>` where `package` is the
package name (including @scope segment if any) and `version` is the specific version of
the package that comes from the pnpm-lock.yaml file.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

The version may include peer dep(s),

```
//:.aspect_rules_js/node_modules/debug/4.3.4_supports-color@8.1.1
```

It could be also be a url based version,

```
//:.aspect_rules_js/node_modules/debug/github.com/ngokevin/debug/9742c5f383a6f8046241920156236ade8ec30d53
```

Package store link targets names for 3rd party package that come directly from an
`npm_import` start with `.aspect_rules_js/` then the name passed to the `npm_import`'s `npm_link_imported_package`
macro (typically `node_modules`) followed by `/<package>/<version>` where `package`
matches the `package` attribute in the npm_import of the package and `version` matches the
`version` attribute.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

Package store link targets names for 1st party packages automatically linked by `npm_link_all_packages`
using workspaces will follow the same pattern as 3rd party packages with the version typically defaulting
to "0.0.0".

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg/0.0.0
```

Package store link targets names for 1st party packages manually linked with `npm_link_package`
start with `.aspect_rules_js/` followed by the name passed to the `npm_link_package`.

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg
```

> In typical usage, a node.js program sometimes requires modules which were
> never declared as dependencies.
> This pattern is typically used when the program has conditional behavior
> that is enabled when the module is found (like a plugin) but the program
> also runs without the dependency.
> 
> This is possible because node.js doesn't enforce the dependencies are sound.
> All files under `node_modules` are available to any program.
> In contrast, Bazel makes it possible to make builds hermetic, which means that
> all dependencies of a program must be declared when running in Bazel's sandbox.
	*
NpmPackageStoreInfo
JsInfo2{}>
<
dev,Whether this npm package is a dev dependency2False�
�
exclude_package_contents�List of exclude patterns to exclude files from the package store.

The exclude patterns are relative to the package store directory.
2[]�
�
hardlink�Controls when to use hardlinks to files instead of making copies.

Creating hardlinks is much faster than making copies of files with the caveat that
hardlinks share file permissions with their source.

Since Bazel removes write permissions on files in the output tree after an action completes,
hardlinks to source files is not recommended since write permissions will be inadvertently
removed from sources files.

- "auto": hardlinks are used for generated files already in the output tree
- "off": all files are copied
- "on": hardlinks are used for all files (not recommended)

NB: Hardlinking source files in external repositories as was done under the hood
prior to https://github.com/aspect-build/rules_js/pull/1533 may lead to flaky build
failures as reported in https://github.com/aspect-build/rules_js/issues/1412.
2"auto"�
�
package�The package name to link to.

If unset, the package name in the `NpmPackageInfo` src must be set.
If set, takes precendance over the package name in the `NpmPackageInfo` src.
2""_
]
srcRA target providing a `NpmPackageInfo` or `JsInfo` containing the package sources.
 @
>
verbose*If true, prints out verbose logs to stdout2False�
�
version�The package version being linked.

If unset, the package version in the `NpmPackageInfo` src must be set.
If set, takes precendance over the package version in the `NpmPackageInfo` src.
2""�
(//npm/private:npm_link_package_store.bzlr�
:
aspect_rules_jsnpm/privatenpm_link_package_store.bzl>
npm_link_package_storenpm_link_package_store
CY
[�
#//npm/private:npm_package_store.bzlr{
5
aspect_rules_jsnpm/privatenpm_package_store.bzl4
npm_package_storenpm_package_store
>O
Qt
//npm/private:utils.bzlrW
)
aspect_rules_jsnpm/private	utils.bzl
utilsutils
27
9npm_link_package rule�
:
aspect_rules_jsnpm/privatenpm_link_package_store.bzl�npm_link_package_store�Links an npm package that is backed by an npm_package_store into a node_modules tree as a direct dependency.

This is used in conjunction with the npm_package_store rule that outputs an npm package into the
node_modules/.aspect_rules_js package store in a pnpm style symlinked node_modules structure.

The term "package" is defined at
<https://nodejs.org/docs/latest-v16.x/api/packages.html>

See https://pnpm.io/symlinked-node-modules-structure for more information on
the symlinked node_modules structure.
Npm may also support a symlinked node_modules structure called
"Isolated mode" in the future:
https://github.com/npm/rfcs/blob/main/accepted/0042-isolated-mode.md.
"�
�
npm_link_package_store�Links an npm package that is backed by an npm_package_store into a node_modules tree as a direct dependency.

This is used in conjunction with the npm_package_store rule that outputs an npm package into the
node_modules/.aspect_rules_js package store in a pnpm style symlinked node_modules structure.

The term "package" is defined at
<https://nodejs.org/docs/latest-v16.x/api/packages.html>

See https://pnpm.io/symlinked-node-modules-structure for more information on
the symlinked node_modules structure.
Npm may also support a symlinked node_modules structure called
"Isolated mode" in the future:
https://github.com/npm/rfcs/blob/main/accepted/0042-isolated-mode.md.
*
nameA unique name for this target. �
bins�Dictionary of `node_modules/.bin` binary files to create mapped to their node entry points.

This is typically derived from the "bin" attribute in the package.json
file of the npm package being linked.

For example:

```
bins = {
    "foo": "./foo.js",
    "bar": "./bar.js",
}
```

In the future, this field may be automatically populated by npm_translate_lock
from information in the pnpm lock file. That feature is currently blocked on
https://github.com/pnpm/pnpm/issues/5131.

2{}�
package�The package name to link to.

If unset, the package name of the src npm_package_store is used.
If set, takes precendance over the package name in the src npm_package_store.
2""f
src<The npm_package_store target to link as a direct dependency. *
NpmPackageStoreInfo
JsInfo"S
npm_link_package_store9@@aspect_rules_js//npm/private:npm_link_package_store.bzl
��,
*
nameA unique name for this target. �
�
bins�Dictionary of `node_modules/.bin` binary files to create mapped to their node entry points.

This is typically derived from the "bin" attribute in the package.json
file of the npm package being linked.

For example:

```
bins = {
    "foo": "./foo.js",
    "bar": "./bar.js",
}
```

In the future, this field may be automatically populated by npm_translate_lock
from information in the pnpm lock file. That feature is currently blocked on
https://github.com/pnpm/pnpm/issues/5131.

2{}�
�
package�The package name to link to.

If unset, the package name of the src npm_package_store is used.
If set, takes precendance over the package name in the src npm_package_store.
2""h
f
src<The npm_package_store target to link as a direct dependency. *
NpmPackageStoreInfo
JsInfo�
//js:providers.bzlrv
$
aspect_rules_jsjsproviders.bzl
JsInfoJsInfo
-3 
js_infojs_info
7>
@�
(//npm/private:npm_package_store_info.bzlr�
:
aspect_rules_jsnpm/privatenpm_package_store_info.bzl8
NpmPackageStoreInfoNpmPackageStoreInfo
CV
Xt
//npm/private:utils.bzlrW
)
aspect_rules_jsnpm/private	utils.bzl
utilsutils
27
9npm_link_package_store rule��
/
aspect_rules_jsnpm/privatenpm_package.bzl��npm_package�A macro that packages sources into a directory (a tree artifact) and provides an `NpmPackageInfo`.

This target can be used as the `src` attribute to `npm_link_package`.

With `publishable = True` the macro also produces a target `[name].publish`, that can be run to publish to an npm registry.
Under the hood, this target runs `npm publish`. You can pass arguments to npm by escaping them from Bazel using a double-hyphen,
for example: `bazel run //path/to:my_package.publish -- --tag=next`

Files and directories can be arranged as needed in the output directory using
the `root_paths`, `include_srcs_patterns`, `exclude_srcs_patterns` and `replace_prefixes` attributes.

Filters and transformations are applied in the following order:

1. `include_external_repositories`

2. `include_srcs_packages`

3. `exclude_srcs_packages`

4. `root_paths`

5. `include_srcs_patterns`

6. `exclude_srcs_patterns`

7. `replace_prefixes`

For more information each filters / transformations applied, see
the documentation for the specific filter / transformation attribute.

Glob patterns are supported. Standard wildcards (globbing patterns) plus the `**` doublestar (aka. super-asterisk)
are supported with the underlying globbing library, https://github.com/bmatcuk/doublestar. This is the same
globbing library used by [gazelle](https://github.com/bazelbuild/bazel-gazelle). See https://github.com/bmatcuk/doublestar#patterns
for more information on supported globbing patterns.

`npm_package` makes use of `copy_to_directory`
(https://docs.aspect.build/rules/aspect_bazel_lib/docs/copy_to_directory) under the hood,
adopting its API and its copy action using composition. However, unlike `copy_to_directory`,
`npm_package` includes direct and transitive sources and types files from `JsInfo` providers in srcs
by default. The behavior of including sources and types from `JsInfo` can be configured
using the `include_sources`, `include_transitive_sources`, `include_types`, `include_transitive_types`.

The two `include*_types` options may cause type-check actions to run, which slows down your
development round-trip.

As of rules_js 2.0, the recommended solution for avoiding eager type-checking when linking
1p deps is to link `js_library` or any `JsInfo` producing targets directly without the
indirection of going through an `npm_package` target (see https://github.com/aspect-build/rules_js/pull/1646
for more details).

`npm_package` can also include npm packages sources and default runfiles from `srcs` which `copy_to_directory` does not.
These behaviors can be configured with the `include_npm_sourfes` and `include_runfiles` attributes
respectively.

The default `include_srcs_packages`, `[".", "./**"]`, prevents files from outside of the target's
package and subpackages from being included.

The default `exclude_srcs_patterns`, of `["node_modules/**", "**/node_modules/**"]`, prevents
`node_modules` files from being included.

To stamp the current git tag as the "version" in the package.json file, see
[stamped_package_json](#stamped_package_json)
"�
�Q
npm_package�A macro that packages sources into a directory (a tree artifact) and provides an `NpmPackageInfo`.

This target can be used as the `src` attribute to `npm_link_package`.

With `publishable = True` the macro also produces a target `[name].publish`, that can be run to publish to an npm registry.
Under the hood, this target runs `npm publish`. You can pass arguments to npm by escaping them from Bazel using a double-hyphen,
for example: `bazel run //path/to:my_package.publish -- --tag=next`

Files and directories can be arranged as needed in the output directory using
the `root_paths`, `include_srcs_patterns`, `exclude_srcs_patterns` and `replace_prefixes` attributes.

Filters and transformations are applied in the following order:

1. `include_external_repositories`

2. `include_srcs_packages`

3. `exclude_srcs_packages`

4. `root_paths`

5. `include_srcs_patterns`

6. `exclude_srcs_patterns`

7. `replace_prefixes`

For more information each filters / transformations applied, see
the documentation for the specific filter / transformation attribute.

Glob patterns are supported. Standard wildcards (globbing patterns) plus the `**` doublestar (aka. super-asterisk)
are supported with the underlying globbing library, https://github.com/bmatcuk/doublestar. This is the same
globbing library used by [gazelle](https://github.com/bazelbuild/bazel-gazelle). See https://github.com/bmatcuk/doublestar#patterns
for more information on supported globbing patterns.

`npm_package` makes use of `copy_to_directory`
(https://docs.aspect.build/rules/aspect_bazel_lib/docs/copy_to_directory) under the hood,
adopting its API and its copy action using composition. However, unlike `copy_to_directory`,
`npm_package` includes direct and transitive sources and types files from `JsInfo` providers in srcs
by default. The behavior of including sources and types from `JsInfo` can be configured
using the `include_sources`, `include_transitive_sources`, `include_types`, `include_transitive_types`.

The two `include*_types` options may cause type-check actions to run, which slows down your
development round-trip.

As of rules_js 2.0, the recommended solution for avoiding eager type-checking when linking
1p deps is to link `js_library` or any `JsInfo` producing targets directly without the
indirection of going through an `npm_package` target (see https://github.com/aspect-build/rules_js/pull/1646
for more details).

`npm_package` can also include npm packages sources and default runfiles from `srcs` which `copy_to_directory` does not.
These behaviors can be configured with the `include_npm_sourfes` and `include_runfiles` attributes
respectively.

The default `include_srcs_packages`, `[".", "./**"]`, prevents files from outside of the target's
package and subpackages from being included.

The default `exclude_srcs_patterns`, of `["node_modules/**", "**/node_modules/**"]`, prevents
`node_modules` files from being included.

To stamp the current git tag as the "version" in the package.json file, see
[stamped_package_json](#stamped_package_json)
*
nameA unique name for this target. e
add_directory_to_runfiles@Whether to add the outputted directory to the target's runfiles.2True�
allow_overwrites�If True, allow files to be overwritten if the same output file is copied to twice.

The order of srcs matters as the last copy of a particular file will win when overwriting.
Performance of copy_to_directory will be slightly degraded when allow_overwrites is True
since copies cannot be parallelized out as they are calculated. Instead all copy paths
must be calculated before any copies can be started.
2False
data2[]�
exclude_srcs_packages�List of Bazel packages (with glob support) to exclude from output directory.

Files in srcs are not copied to the output directory if
the Bazel package of the file matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators. A first character of `"."`
will be replaced by the target's package path.

Files that have do not have matching Bazel packages are subject to subsequent
filters and transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).
2[]�
exclude_srcs_patterns�List of paths (with glob support) to exclude from output directory.

Files in srcs are not copied to the output directory if their output
directory path, after applying `root_paths`, matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators.

Files that do not have matching output directory paths are subject to subsequent
filters and transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).
2[]�
hardlink�Controls when to use hardlinks to files instead of making copies.

Creating hardlinks is much faster than making copies of files with the caveat that
hardlinks share file permissions with their source.

Since Bazel removes write permissions on files in the output tree after an action completes,
hardlinks to source files are not recommended since write permissions will be inadvertently
removed from sources files.

- `auto`: hardlinks are used for generated files already in the output tree
- `off`: all files are copied
- `on`: hardlinks are used for all files (not recommended)
2"auto"�	
include_external_repositories�	List of external repository names (with glob support) to include in the output directory.

Files from external repositories are only copied into the output directory if
the external repository they come from matches one of the external repository patterns
specified or if they are in the same external repository as this target.

When copied from an external repository, the file path in the output directory
defaults to the file's path within the external repository. The external repository
name is _not_ included in that path.

For example, the following copies `@external_repo//path/to:file` to
`path/to/file` within the output directory.

```
copy_to_directory(
    name = "dir",
    include_external_repositories = ["external_*"],
    srcs = ["@external_repo//path/to:file"],
)
```

Files that come from matching external are subject to subsequent filters and
transformations to determine if they are copied and what their path in the output
directory will be. The external repository name of the file from an external
repository is not included in the output directory path and is considered in subsequent
filters and transformations.

Globs are supported (see rule docstring above).
2[]�
include_srcs_packages�List of Bazel packages (with glob support) to include in output directory.

Files in srcs are only copied to the output directory if
the Bazel package of the file matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators. A first character of `"."`
will be replaced by the target's package path.

Defaults to `["**"]` which includes sources from all packages.

Files that have matching Bazel packages are subject to subsequent filters and
transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).
2["**"]�
include_srcs_patterns�List of paths (with glob support) to include in output directory.

Files in srcs are only copied to the output directory if their output
directory path, after applying `root_paths`, matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators.

Defaults to `["**"]` which includes all sources.

Files that have matching output directory paths are subject to subsequent
filters and transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).
2["**"]r
outePath of the output directory, relative to this package.

If not set, the name of the target is used.
2""
package2""�
preserve_mtime�If True, the last modified time of copied files is preserved.
See the [caveats on copy_directory](/docs/copy_directory.md#preserving-modification-times)
about interactions with remote execution and caching.2False�
replace_prefixes�Map of paths prefixes (with glob support) to replace in the output directory path when copying files.

If the output directory path for a file starts with or fully matches a
a key in the dict then the matching portion of the output directory path is
replaced with the dict value for that key. The final path segment
matched can be a partial match of that segment and only the matching portion will
be replaced. If there are multiple keys that match, the longest match wins.

Forward slashes (`/`) should be used as path separators.

Replace prefix transformation are the final step in the list of filters and transformations.
The final output path of a file being copied into the output directory
is determined at this step.

Globs are supported (see rule docstring above).

2{}�

root_paths�List of paths (with glob support) that are roots in the output directory.

If any parent directory of a file being copied matches one of the root paths
patterns specified, the output directory path will be the path relative to the root path
instead of the path relative to the file's workspace. If there are multiple
root paths that match, the longest match wins.

Matching is done on the parent directory of the output file path so a trailing '**' glob patterm
will match only up to the last path segment of the dirname and will not include the basename.
Only complete path segments are matched. Partial matches on the last segment of the root path
are ignored.

Forward slashes (`/`) should be used as path separators.

A `"."` value expands to the target's package path (`ctx.label.package`).

Defaults to `["."]` which results in the output directory path of files in the
target's package and and sub-packages are relative to the target's package and
files outside of that retain their full workspace relative paths.

Globs are supported (see rule docstring above).
2["."]u
srcsgFiles and/or directories or targets that provide `DirectoryPathInfo` to copy into the output directory.2[]>
verbose*If true, prints out verbose logs to stdout2False
version2""">
_npm_package.@@aspect_rules_js//npm/private:npm_package.bzl
��,
*
nameA unique name for this target. g
e
add_directory_to_runfiles@Whether to add the outputted directory to the target's runfiles.2True�
�
allow_overwrites�If True, allow files to be overwritten if the same output file is copied to twice.

The order of srcs matters as the last copy of a particular file will win when overwriting.
Performance of copy_to_directory will be slightly degraded when allow_overwrites is True
since copies cannot be parallelized out as they are calculated. Instead all copy paths
must be calculated before any copies can be started.
2False

data2[]�
�
exclude_srcs_packages�List of Bazel packages (with glob support) to exclude from output directory.

Files in srcs are not copied to the output directory if
the Bazel package of the file matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators. A first character of `"."`
will be replaced by the target's package path.

Files that have do not have matching Bazel packages are subject to subsequent
filters and transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).
2[]�
�
exclude_srcs_patterns�List of paths (with glob support) to exclude from output directory.

Files in srcs are not copied to the output directory if their output
directory path, after applying `root_paths`, matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators.

Files that do not have matching output directory paths are subject to subsequent
filters and transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).
2[]�
�
hardlink�Controls when to use hardlinks to files instead of making copies.

Creating hardlinks is much faster than making copies of files with the caveat that
hardlinks share file permissions with their source.

Since Bazel removes write permissions on files in the output tree after an action completes,
hardlinks to source files are not recommended since write permissions will be inadvertently
removed from sources files.

- `auto`: hardlinks are used for generated files already in the output tree
- `off`: all files are copied
- `on`: hardlinks are used for all files (not recommended)
2"auto"�	
�	
include_external_repositories�	List of external repository names (with glob support) to include in the output directory.

Files from external repositories are only copied into the output directory if
the external repository they come from matches one of the external repository patterns
specified or if they are in the same external repository as this target.

When copied from an external repository, the file path in the output directory
defaults to the file's path within the external repository. The external repository
name is _not_ included in that path.

For example, the following copies `@external_repo//path/to:file` to
`path/to/file` within the output directory.

```
copy_to_directory(
    name = "dir",
    include_external_repositories = ["external_*"],
    srcs = ["@external_repo//path/to:file"],
)
```

Files that come from matching external are subject to subsequent filters and
transformations to determine if they are copied and what their path in the output
directory will be. The external repository name of the file from an external
repository is not included in the output directory path and is considered in subsequent
filters and transformations.

Globs are supported (see rule docstring above).
2[]�
�
include_srcs_packages�List of Bazel packages (with glob support) to include in output directory.

Files in srcs are only copied to the output directory if
the Bazel package of the file matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators. A first character of `"."`
will be replaced by the target's package path.

Defaults to `["**"]` which includes sources from all packages.

Files that have matching Bazel packages are subject to subsequent filters and
transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).
2["**"]�
�
include_srcs_patterns�List of paths (with glob support) to include in output directory.

Files in srcs are only copied to the output directory if their output
directory path, after applying `root_paths`, matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators.

Defaults to `["**"]` which includes all sources.

Files that have matching output directory paths are subject to subsequent
filters and transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).
2["**"]t
r
outePath of the output directory, relative to this package.

If not set, the name of the target is used.
2""

package2""�
�
preserve_mtime�If True, the last modified time of copied files is preserved.
See the [caveats on copy_directory](/docs/copy_directory.md#preserving-modification-times)
about interactions with remote execution and caching.2False�
�
replace_prefixes�Map of paths prefixes (with glob support) to replace in the output directory path when copying files.

If the output directory path for a file starts with or fully matches a
a key in the dict then the matching portion of the output directory path is
replaced with the dict value for that key. The final path segment
matched can be a partial match of that segment and only the matching portion will
be replaced. If there are multiple keys that match, the longest match wins.

Forward slashes (`/`) should be used as path separators.

Replace prefix transformation are the final step in the list of filters and transformations.
The final output path of a file being copied into the output directory
is determined at this step.

Globs are supported (see rule docstring above).

2{}�
�

root_paths�List of paths (with glob support) that are roots in the output directory.

If any parent directory of a file being copied matches one of the root paths
patterns specified, the output directory path will be the path relative to the root path
instead of the path relative to the file's workspace. If there are multiple
root paths that match, the longest match wins.

Matching is done on the parent directory of the output file path so a trailing '**' glob patterm
will match only up to the last path segment of the dirname and will not include the basename.
Only complete path segments are matched. Partial matches on the last segment of the root path
are ignored.

Forward slashes (`/`) should be used as path separators.

A `"."` value expands to the target's package path (`ctx.label.package`).

Defaults to `["."]` which results in the output directory path of files in the
target's package and and sub-packages are relative to the target's package and
files outside of that retain their full workspace relative paths.

Globs are supported (see rule docstring above).
2["."]w
u
srcsgFiles and/or directories or targets that provide `DirectoryPathInfo` to copy into the output directory.2[]@
>
verbose*If true, prints out verbose logs to stdout2False

version2""�	stamped_package_json�Convenience wrapper to set the "version" property in package.json with the git tag.

In unstamped builds (typically those without `--stamp`) the version will be set to `0.0.0`.
This ensures that actions which use the package.json file can get cache hits.

For more information on stamping, read https://docs.aspect.build/rules/aspect_bazel_lib/docs/stamping.
*�
�
stamped_package_json@
name4name of the resulting `jq` target, must be "package" (b
	stamp_varQa key from the bazel-out/stable-status.txt or bazel-out/volatile-status.txt files (u
kwargsiadditional attributes passed to the jq rule, see https://docs.aspect.build/rules/aspect_bazel_lib/docs/jq(�Convenience wrapper to set the "version" property in package.json with the git tag.

In unstamped builds (typically those without `--stamp`) the version will be set to `0.0.0`.
This ensures that actions which use the package.json file can get cache hits.

For more information on stamping, read https://docs.aspect.build/rules/aspect_bazel_lib/docs/stamping.
2F
stamped_package_json.@@aspect_rules_js//npm/private:npm_package.bzl
��*jq2jq�
//lib:copy_to_directory.bzlr�
.
aspect_bazel_liblibcopy_to_directory.bzlJ
copy_to_directory_bin_actioncopy_to_directory_bin_action
7S<
copy_to_directory_libcopy_to_directory_lib
Wl
n�
//lib:directory_path.bzlrq
+
aspect_bazel_liblibdirectory_path.bzl4
DirectoryPathInfoDirectoryPathInfo
4E
GY
//lib:jq.bzlrG

aspect_bazel_liblibjq.bzl
jqjq
(*
,{
//tools:version.bzlrb
&
aspect_bazel_libtoolsversion.bzl*
VERSIONBAZEL_LIB_VERSION
.?
Lh
//js:defs.bzlrU

aspect_rules_jsjsdefs.bzl$
	js_binary	js_binary
(1
3r
//js:libs.bzlr_

aspect_rules_jsjslibs.bzl.
js_lib_helpersjs_lib_helpers
(6
8�
"//npm/private:npm_package_info.bzlrt
4
aspect_rules_jsnpm/privatenpm_package_info.bzl.
NpmPackageInfoNpmPackageInfo
=K
Ma
//lib:dicts.bzlrL

bazel_skyliblib	dicts.bzl
dictsdicts
',
.m
//lib:versions.bzlrU
!
bazel_skyliblibversions.bzl"
versionsversions
*2
4�
Rules for linking npm dependencies and packaging and linking first-party deps.

Load these with,

```starlark
load("@aspect_rules_js//npm:defs.bzl", "npm_package")
```
�
4
aspect_rules_jsnpm/privatenpm_package_info.bzl�NpmPackageInfoNProvides the sources of an npm package along with the package name and version2�
�
NpmPackageInfoNProvides the sources of an npm package along with the package name and version#
packagename of this npm package&
versionversion of this npm packagec
src\the sources of this npm package; either a tarball file, a TreeArtifact or a source directory�
npm_package_store_infos�A depset of NpmPackageStoreInfo providers from npm dependencies of the package and the packages's transitive deps to use as direct dependencies when linking with npm_link_package"E
NpmPackageInfo3@@aspect_rules_js//npm/private:npm_package_info.bzl
%
#
packagename of this npm package(
&
versionversion of this npm packagee
c
src\the sources of this npm package; either a tarball file, a TreeArtifact or a source directory�
�
npm_package_store_infos�A depset of NpmPackageStoreInfo providers from npm dependencies of the package and the packages's transitive deps to use as direct dependencies when linking with npm_link_packageNpmPackageInfo provider�
8
aspect_rules_jsnpm/privatenpm_package_internal.bzl�npm_package_internal"�
�
npm_package_internal*
nameA unique name for this target.  
packageThe package name. J
src?A source directory or output directory to use for this package. #
versionThe package version. "O
npm_package_internal7@@aspect_rules_js//npm/private:npm_package_internal.bzl
((,
*
nameA unique name for this target. "
 
packageThe package name. L
J
src?A source directory or output directory to use for this package. %
#
versionThe package version. �
"//npm/private:npm_package_info.bzlrt
4
aspect_rules_jsnpm/privatenpm_package_info.bzl.
NpmPackageInfoNpmPackageInfo
=K
Mnpm_package_internal rule�X
5
aspect_rules_jsnpm/privatenpm_package_store.bzl�Nnpm_package_store�Defines a npm package that is linked into a node_modules tree.

The npm package is linked with a pnpm style symlinked node_modules output tree.

The term "package" is defined at
<https://nodejs.org/docs/latest-v16.x/api/packages.html>

See https://pnpm.io/symlinked-node-modules-structure for more information on
the symlinked node_modules structure.
Npm may also support a symlinked node_modules structure called
"Isolated mode" in the future:
https://github.com/npm/rfcs/blob/main/accepted/0042-isolated-mode.md.
"�J
�'
npm_package_store�Defines a npm package that is linked into a node_modules tree.

The npm package is linked with a pnpm style symlinked node_modules output tree.

The term "package" is defined at
<https://nodejs.org/docs/latest-v16.x/api/packages.html>

See https://pnpm.io/symlinked-node-modules-structure for more information on
the symlinked node_modules structure.
Npm may also support a symlinked node_modules structure called
"Isolated mode" in the future:
https://github.com/npm/rfcs/blob/main/accepted/0042-isolated-mode.md.
*
nameA unique name for this target. �
deps�Other node packages store link targets one depends on mapped to the name to link them under in this packages deps.

This should include *all* modules the program may need at runtime.

You can find all the package store link targets in your repository with

```
bazel query ... | grep :.aspect_rules_js | grep -v /dir | grep -v /pkg | grep -v /ref
```

Package store link targets names for 3rd party packages that come from `npm_translate_lock`
start with `.aspect_rules_js/` then the name passed to the `npm_link_all_packages` macro
(typically `node_modules`) followed by `/<package>/<version>` where `package` is the
package name (including @scope segment if any) and `version` is the specific version of
the package that comes from the pnpm-lock.yaml file.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

The version may include peer dep(s),

```
//:.aspect_rules_js/node_modules/debug/4.3.4_supports-color@8.1.1
```

It could be also be a url based version,

```
//:.aspect_rules_js/node_modules/debug/github.com/ngokevin/debug/9742c5f383a6f8046241920156236ade8ec30d53
```

Package store link targets names for 3rd party package that come directly from an
`npm_import` start with `.aspect_rules_js/` then the name passed to the `npm_import`'s `npm_link_imported_package`
macro (typically `node_modules`) followed by `/<package>/<version>` where `package`
matches the `package` attribute in the npm_import of the package and `version` matches the
`version` attribute.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

Package store link targets names for 1st party packages automatically linked by `npm_link_all_packages`
using workspaces will follow the same pattern as 3rd party packages with the version typically defaulting
to "0.0.0".

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg/0.0.0
```

Package store link targets names for 1st party packages manually linked with `npm_link_package`
start with `.aspect_rules_js/` followed by the name passed to the `npm_link_package`.

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg
```

> In typical usage, a node.js program sometimes requires modules which were
> never declared as dependencies.
> This pattern is typically used when the program has conditional behavior
> that is enabled when the module is found (like a plugin) but the program
> also runs without the dependency.
> 
> This is possible because node.js doesn't enforce the dependencies are sound.
> All files under `node_modules` are available to any program.
> In contrast, Bazel makes it possible to make builds hermetic, which means that
> all dependencies of a program must be declared when running in Bazel's sandbox.
	*
NpmPackageStoreInfo
JsInfo2{}<
dev,Whether this npm package is a dev dependency2False�
exclude_package_contents�List of exclude patterns to exclude files from the package store.

The exclude patterns are relative to the package store directory.
2[]�
hardlink�Controls when to use hardlinks to files instead of making copies.

Creating hardlinks is much faster than making copies of files with the caveat that
hardlinks share file permissions with their source.

Since Bazel removes write permissions on files in the output tree after an action completes,
hardlinks to source files is not recommended since write permissions will be inadvertently
removed from sources files.

- "auto": hardlinks are used for generated files already in the output tree
- "off": all files are copied
- "on": hardlinks are used for all files (not recommended)

NB: Hardlinking source files in external repositories as was done under the hood
prior to https://github.com/aspect-build/rules_js/pull/1533 may lead to flaky build
failures as reported in https://github.com/aspect-build/rules_js/issues/1412.
2"auto"�
package�The package name to link to.

If unset, the package name in the `NpmPackageInfo` src must be set.
If set, takes precendance over the package name in the `NpmPackageInfo` src.
2""]
srcRA target providing a `NpmPackageInfo` or `JsInfo` containing the package sources.
 >
verbose*If true, prints out verbose logs to stdout2False�
version�The package version being linked.

If unset, the package version in the `NpmPackageInfo` src must be set.
If set, takes precendance over the package version in the `NpmPackageInfo` src.
2"""I
npm_package_store4@@aspect_rules_js//npm/private:npm_package_store.bzl
��,
*
nameA unique name for this target. �
�
deps�Other node packages store link targets one depends on mapped to the name to link them under in this packages deps.

This should include *all* modules the program may need at runtime.

You can find all the package store link targets in your repository with

```
bazel query ... | grep :.aspect_rules_js | grep -v /dir | grep -v /pkg | grep -v /ref
```

Package store link targets names for 3rd party packages that come from `npm_translate_lock`
start with `.aspect_rules_js/` then the name passed to the `npm_link_all_packages` macro
(typically `node_modules`) followed by `/<package>/<version>` where `package` is the
package name (including @scope segment if any) and `version` is the specific version of
the package that comes from the pnpm-lock.yaml file.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

The version may include peer dep(s),

```
//:.aspect_rules_js/node_modules/debug/4.3.4_supports-color@8.1.1
```

It could be also be a url based version,

```
//:.aspect_rules_js/node_modules/debug/github.com/ngokevin/debug/9742c5f383a6f8046241920156236ade8ec30d53
```

Package store link targets names for 3rd party package that come directly from an
`npm_import` start with `.aspect_rules_js/` then the name passed to the `npm_import`'s `npm_link_imported_package`
macro (typically `node_modules`) followed by `/<package>/<version>` where `package`
matches the `package` attribute in the npm_import of the package and `version` matches the
`version` attribute.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

Package store link targets names for 1st party packages automatically linked by `npm_link_all_packages`
using workspaces will follow the same pattern as 3rd party packages with the version typically defaulting
to "0.0.0".

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg/0.0.0
```

Package store link targets names for 1st party packages manually linked with `npm_link_package`
start with `.aspect_rules_js/` followed by the name passed to the `npm_link_package`.

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg
```

> In typical usage, a node.js program sometimes requires modules which were
> never declared as dependencies.
> This pattern is typically used when the program has conditional behavior
> that is enabled when the module is found (like a plugin) but the program
> also runs without the dependency.
> 
> This is possible because node.js doesn't enforce the dependencies are sound.
> All files under `node_modules` are available to any program.
> In contrast, Bazel makes it possible to make builds hermetic, which means that
> all dependencies of a program must be declared when running in Bazel's sandbox.
	*
NpmPackageStoreInfo
JsInfo2{}>
<
dev,Whether this npm package is a dev dependency2False�
�
exclude_package_contents�List of exclude patterns to exclude files from the package store.

The exclude patterns are relative to the package store directory.
2[]�
�
hardlink�Controls when to use hardlinks to files instead of making copies.

Creating hardlinks is much faster than making copies of files with the caveat that
hardlinks share file permissions with their source.

Since Bazel removes write permissions on files in the output tree after an action completes,
hardlinks to source files is not recommended since write permissions will be inadvertently
removed from sources files.

- "auto": hardlinks are used for generated files already in the output tree
- "off": all files are copied
- "on": hardlinks are used for all files (not recommended)

NB: Hardlinking source files in external repositories as was done under the hood
prior to https://github.com/aspect-build/rules_js/pull/1533 may lead to flaky build
failures as reported in https://github.com/aspect-build/rules_js/issues/1412.
2"auto"�
�
package�The package name to link to.

If unset, the package name in the `NpmPackageInfo` src must be set.
If set, takes precendance over the package name in the `NpmPackageInfo` src.
2""_
]
srcRA target providing a `NpmPackageInfo` or `JsInfo` containing the package sources.
 @
>
verbose*If true, prints out verbose logs to stdout2False�
�
version�The package version being linked.

If unset, the package version in the `NpmPackageInfo` src must be set.
If set, takes precendance over the package version in the `NpmPackageInfo` src.
2""� npm_local_package_store_internal*�
�
 npm_local_package_store_internal
link_root_name (
package_store_name (
package (
version (	
src (

deps (

visibility (

tags (2X
 npm_local_package_store_internal4@@aspect_rules_js//npm/private:npm_package_store.bzl
��"npm_package_store�
//lib:copy_directory.bzlr�
+
aspect_bazel_liblibcopy_directory.bzlD
copy_directory_bin_actioncopy_directory_bin_action
4M
O�
//js/private:js_info.bzlr|
*
aspect_rules_js
js/privatejs_info.bzl
JsInfoJsInfo
39 
js_infojs_info
=D
F�
"//npm/private:npm_package_info.bzlrt
4
aspect_rules_jsnpm/privatenpm_package_info.bzl.
NpmPackageInfoNpmPackageInfo
=K
M�
(//npm/private:npm_package_store_info.bzlr�
:
aspect_rules_jsnpm/privatenpm_package_store_info.bzl8
NpmPackageStoreInfoNpmPackageStoreInfo
CV
Xt
//npm/private:utils.bzlrW
)
aspect_rules_jsnpm/private	utils.bzl
utilsutils
	2	7
		9npm_package_store rule�
:
aspect_rules_jsnpm/privatenpm_package_store_info.bzl�NpmPackageStoreInfo�Provides information about an npm package within the package store of a pnpm-style
symlinked node_modules tree.

See https://pnpm.io/symlinked-node-modules-structure for more information about
symlinked node_modules trees.2�

�
NpmPackageStoreInfo�Provides information about an npm package within the package store of a pnpm-style
symlinked node_modules tree.

See https://pnpm.io/symlinked-node-modules-structure for more information about
symlinked node_modules trees.@
root_package0package that this npm package store is linked at#
packagename of this npm package&
versionversion of this npm packageB
ref_deps6dictionary of dependency npm_package_store ref targetsX
package_store_directory=the TreeArtifact of this npm package's package store location9
files0depset of files that are part of the npm package`
transitive_filesLdepset of the files that are part of the npm package and its transitive deps:
dev3whether or not this npm package is a dev dependency"P
NpmPackageStoreInfo9@@aspect_rules_js//npm/private:npm_package_store_info.bzl
B
@
root_package0package that this npm package store is linked at%
#
packagename of this npm package(
&
versionversion of this npm packageD
B
ref_deps6dictionary of dependency npm_package_store ref targetsZ
X
package_store_directory=the TreeArtifact of this npm package's package store location;
9
files0depset of files that are part of the npm packageb
`
transitive_filesLdepset of the files that are part of the npm package and its transitive deps<
:
dev3whether or not this npm package is a dev dependencyNpmPackageStoreInfo provider�N
>
aspect_rules_jsnpm/privatenpm_package_store_internal.bzl�Knpm_package_store_internal"�K
�&
npm_package_store_internal*
nameA unique name for this target. �
deps�Other node packages store link targets one depends on mapped to the name to link them under in this packages deps.

This should include *all* modules the program may need at runtime.

You can find all the package store link targets in your repository with

```
bazel query ... | grep :.aspect_rules_js | grep -v /dir | grep -v /pkg | grep -v /ref
```

Package store link targets names for 3rd party packages that come from `npm_translate_lock`
start with `.aspect_rules_js/` then the name passed to the `npm_link_all_packages` macro
(typically `node_modules`) followed by `/<package>/<version>` where `package` is the
package name (including @scope segment if any) and `version` is the specific version of
the package that comes from the pnpm-lock.yaml file.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

The version may include peer dep(s),

```
//:.aspect_rules_js/node_modules/debug/4.3.4_supports-color@8.1.1
```

It could be also be a url based version,

```
//:.aspect_rules_js/node_modules/debug/github.com/ngokevin/debug/9742c5f383a6f8046241920156236ade8ec30d53
```

Package store link targets names for 3rd party package that come directly from an
`npm_import` start with `.aspect_rules_js/` then the name passed to the `npm_import`'s `npm_link_imported_package`
macro (typically `node_modules`) followed by `/<package>/<version>` where `package`
matches the `package` attribute in the npm_import of the package and `version` matches the
`version` attribute.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

Package store link targets names for 1st party packages automatically linked by `npm_link_all_packages`
using workspaces will follow the same pattern as 3rd party packages with the version typically defaulting
to "0.0.0".

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg/0.0.0
```

Package store link targets names for 1st party packages manually linked with `npm_link_package`
start with `.aspect_rules_js/` followed by the name passed to the `npm_link_package`.

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg
```

> In typical usage, a node.js program sometimes requires modules which were
> never declared as dependencies.
> This pattern is typically used when the program has conditional behavior
> that is enabled when the module is found (like a plugin) but the program
> also runs without the dependency.
> 
> This is possible because node.js doesn't enforce the dependencies are sound.
> All files under `node_modules` are available to any program.
> In contrast, Bazel makes it possible to make builds hermetic, which means that
> all dependencies of a program must be declared when running in Bazel's sandbox.
	*
NpmPackageStoreInfo
JsInfo2{}<
dev,Whether this npm package is a dev dependency2False�
exclude_package_contents�List of exclude patterns to exclude files from the package store.

The exclude patterns are relative to the package store directory.
2[]�
hardlink�Controls when to use hardlinks to files instead of making copies.

Creating hardlinks is much faster than making copies of files with the caveat that
hardlinks share file permissions with their source.

Since Bazel removes write permissions on files in the output tree after an action completes,
hardlinks to source files is not recommended since write permissions will be inadvertently
removed from sources files.

- "auto": hardlinks are used for generated files already in the output tree
- "off": all files are copied
- "on": hardlinks are used for all files (not recommended)

NB: Hardlinking source files in external repositories as was done under the hood
prior to https://github.com/aspect-build/rules_js/pull/1533 may lead to flaky build
failures as reported in https://github.com/aspect-build/rules_js/issues/1412.
2"auto"p
packageaThe package name to link to.

Takes precedence over the package name in the `NpmPackageInfo` src. �
src�A target providing a `NpmPackageInfo` or `JsInfo` containing the package sources.

Can be left unspecified to allow for npm_link_package "reference" targets. `npm_link_package`
targets without a `src` are used internally by `npm_import` to create "reference"
`npm_link_package` targets in order to break circular dependencies between 3rd party npm
dependencies. This pattern is not recommended outside of `npm_import` as it adds
complication. Outside our `npm_import` you should structure you `npm_link_package` targets in
a DAG (without cycles).
2None>
verbose*If true, prints out verbose logs to stdout2Falsev
versiongThe package version to link to.

Takes precedence over the package version in the `NpmPackageInfo` src. "[
npm_package_store_internal=@@aspect_rules_js//npm/private:npm_package_store_internal.bzl
 " ",
*
nameA unique name for this target. �
�
deps�Other node packages store link targets one depends on mapped to the name to link them under in this packages deps.

This should include *all* modules the program may need at runtime.

You can find all the package store link targets in your repository with

```
bazel query ... | grep :.aspect_rules_js | grep -v /dir | grep -v /pkg | grep -v /ref
```

Package store link targets names for 3rd party packages that come from `npm_translate_lock`
start with `.aspect_rules_js/` then the name passed to the `npm_link_all_packages` macro
(typically `node_modules`) followed by `/<package>/<version>` where `package` is the
package name (including @scope segment if any) and `version` is the specific version of
the package that comes from the pnpm-lock.yaml file.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

The version may include peer dep(s),

```
//:.aspect_rules_js/node_modules/debug/4.3.4_supports-color@8.1.1
```

It could be also be a url based version,

```
//:.aspect_rules_js/node_modules/debug/github.com/ngokevin/debug/9742c5f383a6f8046241920156236ade8ec30d53
```

Package store link targets names for 3rd party package that come directly from an
`npm_import` start with `.aspect_rules_js/` then the name passed to the `npm_import`'s `npm_link_imported_package`
macro (typically `node_modules`) followed by `/<package>/<version>` where `package`
matches the `package` attribute in the npm_import of the package and `version` matches the
`version` attribute.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

Package store link targets names for 1st party packages automatically linked by `npm_link_all_packages`
using workspaces will follow the same pattern as 3rd party packages with the version typically defaulting
to "0.0.0".

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg/0.0.0
```

Package store link targets names for 1st party packages manually linked with `npm_link_package`
start with `.aspect_rules_js/` followed by the name passed to the `npm_link_package`.

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg
```

> In typical usage, a node.js program sometimes requires modules which were
> never declared as dependencies.
> This pattern is typically used when the program has conditional behavior
> that is enabled when the module is found (like a plugin) but the program
> also runs without the dependency.
> 
> This is possible because node.js doesn't enforce the dependencies are sound.
> All files under `node_modules` are available to any program.
> In contrast, Bazel makes it possible to make builds hermetic, which means that
> all dependencies of a program must be declared when running in Bazel's sandbox.
	*
NpmPackageStoreInfo
JsInfo2{}>
<
dev,Whether this npm package is a dev dependency2False�
�
exclude_package_contents�List of exclude patterns to exclude files from the package store.

The exclude patterns are relative to the package store directory.
2[]�
�
hardlink�Controls when to use hardlinks to files instead of making copies.

Creating hardlinks is much faster than making copies of files with the caveat that
hardlinks share file permissions with their source.

Since Bazel removes write permissions on files in the output tree after an action completes,
hardlinks to source files is not recommended since write permissions will be inadvertently
removed from sources files.

- "auto": hardlinks are used for generated files already in the output tree
- "off": all files are copied
- "on": hardlinks are used for all files (not recommended)

NB: Hardlinking source files in external repositories as was done under the hood
prior to https://github.com/aspect-build/rules_js/pull/1533 may lead to flaky build
failures as reported in https://github.com/aspect-build/rules_js/issues/1412.
2"auto"r
p
packageaThe package name to link to.

Takes precedence over the package name in the `NpmPackageInfo` src. �
�
src�A target providing a `NpmPackageInfo` or `JsInfo` containing the package sources.

Can be left unspecified to allow for npm_link_package "reference" targets. `npm_link_package`
targets without a `src` are used internally by `npm_import` to create "reference"
`npm_link_package` targets in order to break circular dependencies between 3rd party npm
dependencies. This pattern is not recommended outside of `npm_import` as it adds
complication. Outside our `npm_import` you should structure you `npm_link_package` targets in
a DAG (without cycles).
2None@
>
verbose*If true, prints out verbose logs to stdout2Falsex
v
versiongThe package version to link to.

Takes precedence over the package version in the `NpmPackageInfo` src. �
#//npm/private:npm_package_store.bzlr�
5
aspect_rules_jsnpm/privatenpm_package_store.bzl=
npm_package_store_lib_npm_package_store_lib
=S
na
//lib:dicts.bzlrL

bazel_skyliblib	dicts.bzl
dictsdicts
',
.npm_package_store_internal rule��
6
aspect_rules_jsnpm/privatenpm_translate_lock.bzl�list_patches�Write a file containing a list of all patches in the current folder to the source tree.

Use this together with the `verify_patches` attribute of `npm_translate_lock` to verify
that all patches in a patch folder are included. This macro stamps a test to ensure the
file stays up to date.
*�
�
list_patches
nameName of the target (W
outHName of file to write to the source tree. If unspecified, `name` is usedNone(V
include_patterns)Patterns to pass to a glob of patch files["*.diff", "*.patch"](M
exclude_package_contents+Patterns to ignore in a glob of patch files[](�Write a file containing a list of all patches in the current folder to the source tree.

Use this together with the `verify_patches` attribute of `npm_translate_lock` to verify
that all patches in a patch folder are included. This macro stamps a test to ensure the
file stays up to date.
2E
list_patches5@@aspect_rules_js//npm/private:npm_translate_lock.bzl
��"list_sources2list_sources2write_source_file��npm_translate_lock�	Repository macro to generate starlark code from a lock file.

In most repositories, it would be an impossible maintenance burden to manually declare all
of the [`npm_import`](./npm_import) rules. This helper generates an external repository
containing a helper starlark module `repositories.bzl`, which supplies a loadable macro
`npm_repositories`. That macro creates an `npm_import` for each package.

The generated repository also contains:

- A `defs.bzl` file containing some rules such as `npm_link_all_packages`, which are [documented here](./npm_link_all_packages.md).
- `BUILD` files declaring targets for the packages listed as `dependencies` or `devDependencies` in `package.json`,
  so you can declare dependencies on those packages without having to repeat version information.

This macro creates a `pnpm` external repository, if the user didn't create a repository named
"pnpm" prior to calling `npm_translate_lock`.
`rules_js` currently only uses this repository when `npm_package_lock` or `yarn_lock` are used.
Set `pnpm_version` to `None` to inhibit this repository creation.

For more about how to use npm_translate_lock, read [pnpm and rules_js](/docs/pnpm.md).
*�{
�z
npm_translate_lock$
nameThe repository rule name (/
	pnpm_lockThe `pnpm-lock.yaml` file.None(�
npm_package_lockqThe `package-lock.json` file written by `npm install`.

Only one of `npm_package_lock` or `yarn_lock` may be set.None(
	yarn_lockjThe `yarn.lock` file written by `yarn install`.

Only one of `npm_package_lock` or `yarn_lock` may be set.None(�
update_pnpm_lock�When True, the pnpm lock file will be updated automatically when any of its inputs
have changed since the last update.

Defaults to True when one of `npm_package_lock` or `yarn_lock` are set.
Otherwise it defaults to False.

Read more: [using update_pnpm_lock](/docs/pnpm.md#update_pnpm_lock)False(o
node_toolchain_prefixJthe prefix of the node toolchain to use when generating the pnpm lockfile."nodejs"(c
yq_toolchain_prefixDthe prefix of the yq toolchain to use for parsing the pnpm lockfile."yq"(�
	preupdate�Node.js scripts to run in this repository rule before auto-updating the pnpm lock file.

Scripts are run sequentially in the order they are listed. The working directory is set to the root of the
external repository. Make sure all files required by preupdate scripts are added to the `data` attribute.

A preupdate script could, for example, transform `resolutions` in the root `package.json` file from a format
that yarn understands such as `@foo/**/bar` to the equivalent `@foo/*>bar` that pnpm understands so that
`resolutions` are compatible with pnpm when running `pnpm import` to update the pnpm lock file.

Only needed when `update_pnpm_lock` is True.
Read more: [using update_pnpm_lock](/docs/pnpm.md#update_pnpm_lock)[](�
npmrc�The `.npmrc` file, if any, to use.

When set, the `.npmrc` file specified is parsed and npm auth tokens and basic authentication configuration
specified in the file are passed to the Bazel downloader for authentication with private npm registries.

In a future release, pnpm settings such as public-hoist-patterns will be used.None(�
use_home_npmrc�Use the `$HOME/.npmrc` file (or `$USERPROFILE/.npmrc` when on Windows) if it exists.

Settings from home `.npmrc` are merged with settings loaded from the `.npmrc` file specified
in the `npmrc` attribute, if any. Where there are conflicting settings, the home `.npmrc` values
will take precedence.

WARNING: The repository rule will not be invalidated by changes to the home `.npmrc` file since there
is no way to specify this file as an input to the repository rule. If changes are made to the home
`.npmrc` you can force the repository rule to re-run and pick up the changes by running:
`bazel run @{name}//:sync` where `name` is the name of the `npm_translate_lock` you want to re-run.

Because of the repository rule invalidation issue, using the home `.npmrc` is not recommended.
`.npmrc` settings should generally go in the `npmrc` in your repository so they are shared by all
developers. The home `.npmrc` should be reserved for authentication settings for private npm repositories.None(�
data�Data files required by this repository rule when auto-updating the pnpm lock file.

Only needed when `update_pnpm_lock` is True.
Read more: [using update_pnpm_lock](/docs/pnpm.md#update_pnpm_lock)[](�
patches�A map of package names or package names with their version (e.g., "my-package" or "my-package@v1.2.3")
to a label list of patches to apply to the downloaded npm package. Multiple matches are additive.

These patches are applied after any patches in [pnpm.patchedDependencies](https://pnpm.io/next/package_json#pnpmpatcheddependencies).

Read more: [patching](/docs/pnpm.md#patching){}(�
exclude_package_contents�Configuration for excluding package contents (WORKSPACE only).

For MODULE.bazel, use the `exclude_package_contents` tag class instead.

The configuration is a dictionary that maps package names (or package names with their version, e.g., "my-package" or "my-package@v1.2.3") to exclusion rules.

Values can be:
- `True`: Use default exclusions
- List of strings: Multiple exclusion patterns

Versions must match if used.

Example:

```
exclude_package_contents = {
    "*": True,  # Use defaults for all packages
    "@foo/bar": ["**/test/**"],
    "@foo/car@2.0.0": ["**/README*"],
}
```{}(_

patch_toolIThe patch tool to use. If not specified, the `patch` from `PATH` is used.None(�

patch_args�A map of package names or package names with their version (e.g., "my-package" or "my-package@v1.2.3")
to a label list arguments to pass to the patch tool. The most specific match wins.

Read more: [patching](/docs/pnpm.md#patching){"*": ["-p0"]}(�
custom_postinstalls�A map of package names or package names with their version (e.g., "my-package" or "my-package@v1.2.3")
to a custom postinstall script to apply to the downloaded npm package after its lifecycle scripts runs.
If the version is left out of the package name, the script will run on every version of the npm package. If
a custom postinstall scripts exists for a package as well as for a specific version, the script for the versioned package
will be appended with `&&` to the non-versioned package script.

For example,

```
custom_postinstalls = {
    "@foo/bar": "echo something > somewhere.txt",
    "fum@0.0.1": "echo something_else > somewhere_else.txt",
},
```

Custom postinstalls are additive and joined with ` && ` when there are multiple matches for a package.
More specific matches are appended to previous matches.{}(�
package_visibility�A map of package names or package names with their version (e.g., "my-package" or "my-package@v1.2.3")
to a visibility list to use for the package's generated node_modules link targets. Multiple matches are additive.
If there are no matches then the package's generated node_modules link targets default to public visibility
(`["//visibility:public"]`).{}(P
prod?If True, only install `dependencies` but not `devDependencies`.False(�
public_hoist_packages�A map of package names or package names with their version (e.g., "my-package" or "my-package@v1.2.3")
to a list of Bazel packages in which to hoist the package to the top-level of the node_modules tree when linking.

This is similar to setting https://pnpm.io/npmrc#public-hoist-pattern in an .npmrc file outside of Bazel, however,
wild-cards are not yet supported and npm_translate_lock will fail if there are multiple versions of a package that
are to be hoisted.

```
public_hoist_packages = {
    "@foo/bar": [""] # link to the root package in the WORKSPACE
    "fum@0.0.1": ["some/sub/package"]
},
```

List of public hoist packages are additive when there are multiple matches for a package. More specific matches
are appended to previous matches.{}(7
dev'If True, only install `devDependencies`False(�
no_optional�If True, `optionalDependencies` are not installed.

Currently `npm_translate_lock` behaves differently from pnpm in that is downloads all `optionaDependencies`
while pnpm doesn't download `optionalDependencies` that are not needed for the platform pnpm is run on.
See https://github.com/pnpm/pnpm/pull/3672 for more context.False(�
run_lifecycle_hooksrSets a default value for `lifecycle_hooks` if `*` not already set.
Set this to `False` to disable lifecycle hooks.True(�
lifecycle_hooks�A dict of package names to list of lifecycle hooks to run for that package.

By default the `preinstall`, `install` and `postinstall` hooks are run if they exist. This attribute allows
the default to be overridden for packages to run `prepare`.

List of hooks are not additive. The most specific match wins.

Read more: [lifecycles](/docs/pnpm.md#lifecycles){}(�
lifecycle_hooks_envs�Environment variables set for the lifecycle hooks actions on npm packages.
The environment variables can be defined per package by package name or globally using "*".
Variables are declared as key/value pairs of the form "key=value".
Multiple matches are additive.

Read more: [lifecycles](/docs/pnpm.md#lifecycles){}(�
lifecycle_hooks_exclude�A list of package names or package names with their version (e.g., "my-package" or "my-package@v1.2.3")
to not run any lifecycle hooks on.

Equivalent to adding `<value>: []` to `lifecycle_hooks`.

Read more: [lifecycles](/docs/pnpm.md#lifecycles)[](�
&lifecycle_hooks_execution_requirements�Execution requirements applied to the preinstall, install and postinstall
lifecycle hooks on npm packages.

The execution requirements can be defined per package by package name or globally using "*".

Execution requirements are not additive. The most specific match wins.

Read more: [lifecycles](/docs/pnpm.md#lifecycles){}(�
lifecycle_hooks_no_sandbox�If True, a "no-sandbox" execution requirement is added to all lifecycle hooks
unless overridden by `lifecycle_hooks_execution_requirements`.

Equivalent to adding `"*": ["no-sandbox"]` to `lifecycle_hooks_execution_requirements`.

This defaults to True to limit the overhead of sandbox creation and copying the output
TreeArtifacts out of the sandbox.

Read more: [lifecycles](/docs/pnpm.md#lifecycles)True(�
%lifecycle_hooks_use_default_shell_env�The `use_default_shell_env` attribute of the lifecycle hooks
actions on npm packages.

See [use_default_shell_env](https://bazel.build/rules/lib/builtins/actions#run.use_default_shell_env)

Note: [--incompatible_merge_fixed_and_default_shell_env](https://bazel.build/reference/command-line-reference#flag--incompatible_merge_fixed_and_default_shell_env)
is often required and not enabled by default in Bazel < 7.0.0.

This defaults to False reduce the negative effects of `use_default_shell_env`. Requires bazel-lib >= 2.4.2.

Read more: [lifecycles](/docs/pnpm.md#lifecycles){}(�
replace_packages�A dict of package names to npm_package targets to link instead of the sources specified in the pnpm lock file for the corresponding packages.

The injected npm_package targets may optionally contribute transitive npm package dependencies on top
of the transitive dependencies specified in the pnpm lock file for their respective packages, however, these
transitive dependencies must not collide with pnpm lock specified transitive dependencies.

Any patches specified for the packages will be not applied to the injected npm_package targets. They
will be applied, however, to the fetches sources for their respecitve packages so they can still be useful
for patching the fetched `package.json` files, which are used to determine the generated bin entries for packages.

NB: lifecycle hooks and custom_postinstall scripts, if implicitly or explicitly enabled, will be run on
the injected npm_package targets. These may be disabled explicitly using the `lifecycle_hooks` attribute.{}(�
bins�Binary files to create in `node_modules/.bin` for packages in this lock file.

For a given package, this is typically derived from the "bin" attribute in
the package.json file of that package.

For example:

```
bins = {
    "@foo/bar": {
        "foo": "./foo.js",
        "bar": "./bar.js"
    },
}
```

Dicts of bins not additive. The most specific match wins.

In the future, this field may be automatically populated from information in the pnpm lock
file. That feature is currently blocked on https://github.com/pnpm/pnpm/issues/5131.

Note: Bzlmod users must use an alternative syntax due to module extensions not supporting
dict-of-dict attributes:

```
bins = {
    "@foo/bar": [
        "foo=./foo.js",
        "bar=./bar.js"
    ],
}
```{}(�
verify_node_modules_ignored�node_modules folders in the source tree should be ignored by Bazel.

This points to a `.bazelignore` file to verify that all nested node_modules directories
pnpm will create are listed.

See https://github.com/bazelbuild/bazel/issues/8106None(�	
verify_patches�	Label to a patch list file.

Use this in together with the `list_patches` macro to guarantee that all patches in a patch folder
are included in the `patches` attribute.

For example:

```
verify_patches = "//patches:patches.list",
```

In your patches folder add a BUILD.bazel file containing.
```
load("@aspect_rules_js//npm:repositories.bzl", "list_patches")

list_patches(
    name = "patches",
    out = "patches.list",
)
```

Once you have created this file, you need to create an empty `patches.list` file before generating the first list. You can do this by running
```
touch patches/patches.list
```

Finally, write the patches file at least once to make sure all patches are listed. This can be done by running `bazel run //patches:patches_update`.

See the `list_patches` documentation for further info.
NOTE: if you would like to customize the patches directory location, you can set a flag in the `.npmrc`. Here is an example of what this might look like
```
# Set the directory for pnpm when patching
# https://github.com/pnpm/pnpm/issues/6508#issuecomment-1537242124
patches-dir=bazel/js/patches
```
If you do this, you will have to update the `verify_patches` path to be this path instead of `//patches` like above.None(w
quietfSet to False to print info logs and output stdout & stderr of pnpm lock update actions to the console.True(�
 external_repository_action_cache`The location of the external repository action cache to write to when `update_pnpm_lock` = True.0".aspect/rules/external_repository_action_cache"(�
link_workspace�The workspace name where links will be created for the packages in this lock file.

This is typically set in rule sets and libraries that vendor the starlark generated by npm_translate_lock
so the link_workspace passed to npm_import is set correctly so that links are created in the external
repository and not the user workspace.

Can be left unspecified if the link workspace is the user workspace.None(�
pnpm_version�pnpm version to use when generating the @pnpm repository. Set to None to not create this repository.

Can be left unspecified and the rules_js default `DEFAULT_PNPM_VERSION` will be used."8.15.9"(9
use_pnpm%label of the pnpm entry point to use.None(�
npm_package_target_name�The name of linked `npm_package`, `js_library` or `JsInfo` producing targets.

When targets are linked as pnpm workspace packages, the name of the target must align with this value.

The `{dirname}` placeholder is replaced with the directory name of the target."pkg"(
kwargsInternal use only(�	Repository macro to generate starlark code from a lock file.

In most repositories, it would be an impossible maintenance burden to manually declare all
of the [`npm_import`](./npm_import) rules. This helper generates an external repository
containing a helper starlark module `repositories.bzl`, which supplies a loadable macro
`npm_repositories`. That macro creates an `npm_import` for each package.

The generated repository also contains:

- A `defs.bzl` file containing some rules such as `npm_link_all_packages`, which are [documented here](./npm_link_all_packages.md).
- `BUILD` files declaring targets for the packages listed as `dependencies` or `devDependencies` in `package.json`,
  so you can declare dependencies on those packages without having to repeat version information.

This macro creates a `pnpm` external repository, if the user didn't create a repository named
"pnpm" prior to calling `npm_translate_lock`.
`rules_js` currently only uses this repository when `npm_package_lock` or `yarn_lock` are used.
Set `pnpm_version` to `None` to inhibit this repository creation.

For more about how to use npm_translate_lock, read [pnpm and rules_js](/docs/pnpm.md).
2K
npm_translate_lock5@@aspect_rules_js//npm/private:npm_translate_lock.bzl
��2npm_translate_lock_rule�npm_translate_lock_ruleR�
�
npm_translate_lock_rule.
name"A unique name for this repository. 
additional_file_contents 

bins 
bzlmod2False
custom_postinstalls
2{}
data2[]!
defs_bzl_filename2
"defs.bzl"
dev2False
exclude_package_contents V
 external_repository_action_cache20".aspect/rules/external_repository_action_cache"'
generate_bzl_library_targets2False
lifecycle_hooks 
lifecycle_hooks_envs ,
&lifecycle_hooks_execution_requirements -
%lifecycle_hooks_use_default_shell_env
2{}
link_workspace2""
no_optional2False#
node_toolchain_prefix2"nodejs"
npm_package_lock2None
npm_package_target_name2""
npmrc2None
package_visibility 

patch_args 

patch_tool2None
patches 
	pnpm_lock2None
	preupdate2[]
prod2False
public_hoist_packages 
quiet2True
replace_packages
2{}�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 1
repositories_bzl_filename2"repositories.bzl"
root_package2"."
update_pnpm_lock2False
use_home_npmrc2False*
use_pnpm2@pnpm//:package/bin/pnpm.cjs%
verify_node_modules_ignored2None
verify_patches2None
	yarn_lock2None
yq_toolchain_prefix2"yq"*P
npm_translate_lock_rule5@@aspect_rules_js//npm/private:npm_translate_lock.bzl
�*�*0
.
name"A unique name for this repository.  

additional_file_contents 


bins 

bzlmod2False

custom_postinstalls
2{}

data2[]#
!
defs_bzl_filename2
"defs.bzl"

dev2False 

exclude_package_contents X
V
 external_repository_action_cache20".aspect/rules/external_repository_action_cache")
'
generate_bzl_library_targets2False

lifecycle_hooks 

lifecycle_hooks_envs .
,
&lifecycle_hooks_execution_requirements /
-
%lifecycle_hooks_use_default_shell_env
2{}

link_workspace2""

no_optional2False%
#
node_toolchain_prefix2"nodejs"

npm_package_lock2None!

npm_package_target_name2""

npmrc2None

package_visibility 


patch_args 


patch_tool2None

patches 

	pnpm_lock2None

	preupdate2[]

prod2False

public_hoist_packages 

quiet2True

replace_packages
2{}�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 3
1
repositories_bzl_filename2"repositories.bzl"

root_package2"."

update_pnpm_lock2False

use_home_npmrc2False,
*
use_pnpm2@pnpm//:package/bin/pnpm.cjs'
%
verify_node_modules_ignored2None

verify_patches2None

	yarn_lock2None

yq_toolchain_prefix2"yq"o
//lib:utils.bzlrZ
"
aspect_bazel_liblib	utils.bzl&
utilsbazel_lib_utils
*9
D�
//lib:write_source_files.bzlru
/
aspect_bazel_liblibwrite_source_files.bzl4
write_source_filewrite_source_file
8I
K�
2//npm/private:exclude_package_contents_default.bzlr�
D
aspect_rules_jsnpm/private$exclude_package_contents_default.bzlR
 exclude_package_contents_default exclude_package_contents_default
Mm
o�
//npm/private:list_sources.bzlrl
0
aspect_rules_jsnpm/privatelist_sources.bzl*
list_sourceslist_sources
9E
G�
-//npm/private:npm_translate_lock_generate.bzlr�
?
aspect_rules_jsnpm/privatenpm_translate_lock_generate.bzlD
generate_repository_filesgenerate_repository_files
 H a
  c�
,//npm/private:npm_translate_lock_helpers.bzlrp
>
aspect_rules_jsnpm/privatenpm_translate_lock_helpers.bzl 
helpershelpers
!G!N
!!P�
2//npm/private:npm_translate_lock_macro_helpers.bzlr|
D
aspect_rules_jsnpm/private$npm_translate_lock_macro_helpers.bzl&
helpersmacro_helpers
"L"Y
""f�
*//npm/private:npm_translate_lock_state.bzlr�
<
aspect_rules_jsnpm/privatenpm_translate_lock_state.bzl:
DEFAULT_ROOT_PACKAGEDEFAULT_ROOT_PACKAGE
#E#YB
npm_translate_lock_statenpm_translate_lock_state
#]#u
##w�
!//npm/private:pnpm_repository.bzlr�
3
aspect_rules_jsnpm/privatepnpm_repository.bzl:
DEFAULT_PNPM_VERSIONDEFAULT_PNPM_VERSION
$<$P1
pnpm_repository_pnpm_repository
$S$c
$$x�
$//npm/private:transitive_closure.bzlr�
6
aspect_rules_jsnpm/privatetransitive_closure.bzlP
translate_to_transitive_closuretranslate_to_transitive_closure
%?%^
%%`t
//npm/private:utils.bzlrW
)
aspect_rules_jsnpm/private	utils.bzl
utilsutils
&2&7
&&9a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
''',
''.3	DEFAULT_DEFS_BZL_FILENAMEdefs.bzlj
defs.bzlK	!DEFAULT_REPOSITORIES_BZL_FILENAMErepositories.bzljrepositories.bzlg	RULES_JS_FROZEN_PNPM_LOCK_ENV ASPECT_RULES_JS_FROZEN_PNPM_LOCKj" ASPECT_RULES_JS_FROZEN_PNPM_LOCK�Repository rule to fetch npm packages for a lockfile.

Load this with,

```starlark
load("@aspect_rules_js//npm:repositories.bzl", "npm_translate_lock")
```

These use Bazel's downloader to fetch the packages.
You can use this to redirect all fetches through a store like Artifactory.

See <https://blog.aspect.build/configuring-bazels-downloader> for more info about how it works
and how to configure it.

[`npm_translate_lock`](#npm_translate_lock) is the primary user-facing API.
It uses the lockfile format from [pnpm](https://pnpm.io/motivation) because it gives us reliable
semantics for how to dynamically lay out `node_modules` trees on disk in bazel-out.

To create `pnpm-lock.yaml`, consider using [`pnpm import`](https://pnpm.io/cli/import)
to preserve the versions pinned by your existing `package-lock.json` or `yarn.lock` file.

If you don't have an existing lock file, you can run `npx pnpm install --lockfile-only`.

Advanced users may want to directly fetch a package from npm rather than start from a lockfile,
[`npm_import`](./npm_import) does this.
�	
?
aspect_rules_jsnpm/privatenpm_translate_lock_generate.bzl�generate_repository_files*�
�
generate_repository_files

rctx (
pnpm_lock_label (
	importers (
packages (
patched_dependencies (
only_built_dependencies (
root_package (
default_registry (
npm_registries (
npm_auth (
link_workspace (2[
generate_repository_files>@@aspect_rules_js//npm/private:npm_translate_lock_generate.bzl
``�
,//npm/private:npm_translate_lock_helpers.bzlrp
>
aspect_rules_jsnpm/privatenpm_translate_lock_helpers.bzl 
helpershelpers
GN
P�
(//npm/private:starlark_codegen_utils.bzlr�
:
aspect_rules_jsnpm/privatestarlark_codegen_utils.bzl>
starlark_codegen_utilsstarlark_codegen_utils
CY
[�
//npm/private:tar.bzlrm
'
aspect_rules_jsnpm/privatetar.bzl4
detect_system_tardetect_system_tar
0A
Ct
//npm/private:utils.bzlrW
)
aspect_rules_jsnpm/private	utils.bzl
utilsutils
27
9a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.4Starlark generation helpers for npm_translate_lock.
�
D
aspect_rules_jsnpm/private$npm_translate_lock_generate.docs.bzl�npm_link_all_packages�Generated list of npm_link_package() target generators and first-party linked packages corresponding to the packages in {pnpm_lock_label}

If you use manually-written [`npm_import`](/docs/npm_import.md#npm_import) you can link these as well, for example,

    load("@npm//:defs.bzl", "npm_link_all_packages")
    load("@npm_meaning-of-life__links//:defs.bzl", npm_link_meaning_of_life = "npm_link_imported_package")

    npm_link_all_packages(
        name = "node_modules",
        imported_links = [
            npm_link_meaning_of_life,
        ],
    )
*�
�
npm_link_all_packagesV
name<name of catch all target to generate for all packages linked"node_modules"(}
imported_linkseoptional list link functions from manually imported packages that were fetched with npm_import rules.[](�Generated list of npm_link_package() target generators and first-party linked packages corresponding to the packages in {pnpm_lock_label}

If you use manually-written [`npm_import`](/docs/npm_import.md#npm_import) you can link these as well, for example,

    load("@npm//:defs.bzl", "npm_link_all_packages")
    load("@npm_meaning-of-life__links//:defs.bzl", npm_link_meaning_of_life = "npm_link_imported_package")

    npm_link_all_packages(
        name = "node_modules",
        imported_links = [
            npm_link_meaning_of_life,
        ],
    )
2\
npm_link_all_packagesC@@aspect_rules_js//npm/private:npm_translate_lock_generate.docs.bzl
%%�npm_link_targetsIGenerated list of target names that are linked by npm_link_all_packages()*�
�
npm_link_targetsV
name<name of catch all target to generate for all packages linked"node_modules"(�
package�Bazel package to generate targets names for.

Set to an empty string "" to specify the root package.

If unspecified, the current package (`native.package_name()`) is used.None(IGenerated list of target names that are linked by npm_link_all_packages()"C
AA list of target names that are linked by npm_link_all_packages()2W
npm_link_targetsC@@aspect_rules_js//npm/private:npm_translate_lock_generate.docs.bzl
�Build rules generated by `npm_translate_lock`
=============================================

These are loaded from the external repository created by `npm_translate_lock` based on the name provided.

For example, if you run `npm_translate_lock(name = "npm")` then these rules can be loaded with

```
load("@npm//:defs.bzl", "npm_link_targets", "npm_link_all_packages")
```
�
>
aspect_rules_jsnpm/privatenpm_translate_lock_helpers.bzli
//lib:base64.bzlrS
#
aspect_bazel_liblib
base64.bzl
base64base64
,2
4t
//npm/private:utils.bzlrW
)
aspect_rules_jsnpm/private	utils.bzl
utilsutils
27
9a
//lib:dicts.bzlrL

bazel_skyliblib	dicts.bzl
dictsdicts
',
.e
//lib:new_sets.bzlrM
!
bazel_skyliblibnew_sets.bzl
setssets
*.
0a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.(Starlark helpers for npm_translate_lock.�
D
aspect_rules_jsnpm/private$npm_translate_lock_macro_helpers.bzla
//lib:dicts.bzlrL

bazel_skyliblib	dicts.bzl
dictsdicts
',
./Helper methods for the npm_translate_lock macro�
<
aspect_rules_jsnpm/privatenpm_translate_lock_state.bzli
//lib:base64.bzlrS
#
aspect_bazel_liblib
base64.bzl
base64base64
,2
4y
//lib:repo_utils.bzlr_
'
aspect_bazel_liblibrepo_utils.bzl&

repo_utils
repo_utils
0:
<�
,//npm/private:npm_translate_lock_helpers.bzlrp
>
aspect_rules_jsnpm/privatenpm_translate_lock_helpers.bzl 
helpershelpers
GN
P�
//npm/private:npmrc.bzlrc
)
aspect_rules_jsnpm/private	npmrc.bzl(
parse_npmrcparse_npmrc
2=
?p
//npm/private:pnpm.bzlrT
(
aspect_rules_jsnpm/privatepnpm.bzl
pnpmpnpm
15
7�
(//npm/private:repository_label_store.bzlr�
:
aspect_rules_jsnpm/privaterepository_label_store.bzl>
repository_label_storerepository_label_store
	C	Y
		[�
//npm/private:utils.bzlr�
)
aspect_rules_jsnpm/private	utils.bzl6
INTERNAL_ERROR_MSGINTERNAL_ERROR_MSG

2
D
utilsutils

H
M


Oa
//lib:dicts.bzlrL

bazel_skyliblib	dicts.bzl
dictsdicts
',
.a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.G	PNPM_WORKSPACE_FILENAMEpnpm-workspace.yamljpnpm-workspace.yaml	%RULES_JS_DISABLE_UPDATE_PNPM_LOCK_ENV(ASPECT_RULES_JS_DISABLE_UPDATE_PNPM_LOCKj*(ASPECT_RULES_JS_DISABLE_UPDATE_PNPM_LOCK 	DEFAULT_ROOT_PACKAGE.j.%	NPM_RC_FILENAME.npmrcj.npmrc7	PACKAGE_JSON_FILENAMEpackage.jsonjpackage.jsonM	PNPM_LOCK_ACTION_CACHE_PREFIXnpm_translate_lock_jnpm_translate_lock_8	PNPM_LOCK_FILENAMEpnpm-lock.yamljpnpm-lock.yaml[npm_translate_lock state management abstraction so main impl is easier to read
and maintain�

)
aspect_rules_jsnpm/private	npmrc.bzl�
parse_npmrc�Parse an `.npmrc` file in into key/value map.

`.npmrc` files are in [INI](https://en.wikipedia.org/wiki/INI_file#Format) format but we don't
treat keys as [case insensitive](https://en.wikipedia.org/wiki/INI_file#Case_sensitivity) due
to https://github.com/aspect-build/rules_js/issues/622.

Duplicate case-sensitive keys override previous values.

Supports:
* basic key/value
* # or ; comments

Does NOT support or ignores:
* sections
* escape characters
* number or boolean types (all values are strings)
* comment characters (#, ;) within a value
*�
�
parse_npmrc0
npmrc_contentthe `.npmrc` content string (�Parse an `.npmrc` file in into key/value map.

`.npmrc` files are in [INI](https://en.wikipedia.org/wiki/INI_file#Format) format but we don't
treat keys as [case insensitive](https://en.wikipedia.org/wiki/INI_file#Case_sensitivity) due
to https://github.com/aspect-build/rules_js/issues/622.

Duplicate case-sensitive keys override previous values.

Supports:
* basic key/value
* # or ; comments

Does NOT support or ignores:
* sections
* escape characters
* number or boolean types (all values are strings)
* comment characters (#, ;) within a value
"8
6A dict() of key/value pairs of the `.npmrc` properties27
parse_npmrc(@@aspect_rules_js//npm/private:npmrc.bzl
npmrc utils�
(
aspect_rules_jsnpm/privatepnpm.bzl�
//npm/private:utils.bzlr�
)
aspect_rules_jsnpm/private	utils.bzlL
DEFAULT_REGISTRY_DOMAIN_SLASHDEFAULT_REGISTRY_DOMAIN_SLASH
2O
utilsutils
SX
Za
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.a
//lib:types.bzlrL

bazel_skyliblib	types.bzl
typestypes
',
.8Pnpm lockfile parsing and conversion to rules_js format.�
2
aspect_rules_jsnpm/privatepnpm_extension.bzl�resolve_pnpm_repositories#Resolves pnpm tags in all `modules`*�
�
resolve_pnpm_repositories
mctxmodule context (#Resolves pnpm tags in all `modules`"�
�A struct with the following fields:
- `repositories`: dict (name -> pnpm_version) to invoke `pnpm_repository` with.
- `notes`: list of notes to print to the user.2N
resolve_pnpm_repositories1@@aspect_rules_js//npm/private:pnpm_extension.bzl
g
//lib:lists.bzlrR
"
aspect_bazel_liblib	lists.bzl
uniqueunique
+1
3�
!//npm/private:pnpm_repository.bzlr�
3
aspect_rules_jsnpm/privatepnpm_repository.bzl:
DEFAULT_PNPM_VERSIONDEFAULT_PNPM_VERSION
<P8
LATEST_PNPM_VERSIONLATEST_PNPM_VERSION
Tg
i(	DEFAULT_PNPM_REPO_NAMEpnpmjpnpmEpnpm extension logic (the extension itself is in npm/extensions.bzl).�

3
aspect_rules_jsnpm/privatepnpm_repository.bzl�pnpm_repository�Import https://npmjs.com/package/pnpm and provide a js_binary to run the tool.

Useful as a way to run exactly the same pnpm as Bazel does, for example with:
bazel run -- @pnpm//:pnpm --dir $PWD
*�
�
pnpm_repository5
name)name of the resulting external repository (�
pnpm_version�version of pnpm, see https://www.npmjs.com/package/pnpm?activeTab=versions

May also be a tuple of (version, integrity) where the integrity value may be fetched like:
`curl --silent https://registry.npmjs.org/pnpm | jq '.versions["8.6.11"].dist.integrity'`"8.15.9"(�Import https://npmjs.com/package/pnpm and provide a js_binary to run the tool.

Useful as a way to run exactly the same pnpm as Bazel does, for example with:
bazel run -- @pnpm//:pnpm --dir $PWD
2E
pnpm_repository2@@aspect_rules_js//npm/private:pnpm_repository.bzl
2native.existing_rule2_npm_import�
//npm/private:npm_import.bzlrg
.
aspect_rules_jsnpm/privatenpm_import.bzl'

npm_import_npm_import
6A
Q�
//npm/private:versions.bzlrj
,
aspect_rules_jsnpm/privateversions.bzl,
PNPM_VERSIONSPNPM_VERSIONS
5B
D*	DEFAULT_PNPM_VERSION8.15.9j8.15.9+	LATEST_PNPM_VERSION10.16.1j	10.16.1!Repository rules to import pnpm.
�
:
aspect_rules_jsnpm/privaterepository_label_store.bzla
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
	'	,
		.�In order to avoid late restarts, repository rules should pre-compute dynamic labels and
paths to static & dynamic labels. This helper "class" abstracts that into a tidy interface.

See https://github.com/bazelbuild/bazel-gazelle/issues/1175 &&
https://github.com/bazelbuild/rules_nodejs/issues/2620 for more context. A fix in Bazel may
resolve the underlying issue in the future https://github.com/bazelbuild/bazel/issues/16162.
k
:
aspect_rules_jsnpm/privatestarlark_codegen_utils.bzl-Utilities for generating starlark source code�
'
aspect_rules_jsnpm/privatetar.bzl�detect_system_tar)Check if the host tar command is GNU tar.*�
�
detect_system_tar"
rctxthe repository context ()Check if the host tar command is GNU tar."5
3True if the tar command is GNU tar, False otherwise2;
detect_system_tar&@@aspect_rules_js//npm/private:tar.bzl
y
//lib:repo_utils.bzlr_
'
aspect_bazel_liblibrepo_utils.bzl&

repo_utils
repo_utils
0:
<Tar helpers.�
6
aspect_rules_jsnpm/privatetransitive_closure.bzl�	gather_transitive_closure�Walk the dependency tree, collecting the transitive closure of dependencies and their versions.

This is needed to resolve npm dependency cycles.
Note: Starlark expressly forbids recursion and infinite loops, so we need to iterate over a large range of numbers,
where each iteration takes one item from the stack, and possibly adds many new items to the stack.
*�
�
gather_transitive_closure)
packagesdictionary from pnpm lock (.
packagethe package to collect deps for (:
no_optional'whether to exclude optionalDependencies (@
cache1a dictionary of results from previous invocations{}(�Walk the dependency tree, collecting the transitive closure of dependencies and their versions.

This is needed to resolve npm dependency cycles.
Note: Starlark expressly forbids recursion and infinite loops, so we need to iterate over a large range of numbers,
where each iteration takes one item from the stack, and possibly adds many new items to the stack.
"W
UA dictionary of transitive dependencies, mapping package names to dependent versions.2R
gather_transitive_closure5@@aspect_rules_js//npm/private:transitive_closure.bzl
�translate_to_transitive_closuremImplementation detail of translate_package_lock, converts pnpm-lock to a different dictionary with more data.*�
�
translate_to_transitive_closure6
	importers%workspace projects (pnpm "importers") ((
packagesall package info by name (3
prod"If true, only install dependenciesFalse(5
dev%If true, only install devDependenciesFalse(G
no_optional/If true, optionalDependencies are not installedFalse(mImplementation detail of translate_package_lock, converts pnpm-lock to a different dictionary with more data."J
HNested dictionary suitable for further processing in our repository rule2X
translate_to_transitive_closure5@@aspect_rules_js//npm/private:transitive_closure.bzl
JJt
//npm/private:utils.bzlrW
)
aspect_rules_jsnpm/private	utils.bzl
utilsutils
27
9a
//lib:dicts.bzlrL

bazel_skyliblib	dicts.bzl
dictsdicts
',
.-Helper utility for working with pnpm lockfile�
)
aspect_rules_jsnpm/private	utils.bzlu
//lib:paths.bzlr`
"
aspect_bazel_liblib	paths.bzl,
relative_filerelative_file
+8
:y
//lib:repo_utils.bzlr_
'
aspect_bazel_liblibrepo_utils.bzl&

repo_utils
repo_utils
0:
<a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.M	DEFAULT_REGISTRY_DOMAIN_SLASHregistry.npmjs.org/jregistry.npmjs.org/-	DEFAULT_REGISTRY_PROTOCOLhttpsjhttps�	INTERNAL_ERROR_MSGeERROR: rules_js internal error, please file an issue: https://github.com/aspect-build/rules_js/issuesjgeERROR: rules_js internal error, please file an issue: https://github.com/aspect-build/rules_js/issues�	(DEFAULT_EXTERNAL_REPOSITORY_ACTION_CACHE..aspect/rules/external_repository_action_cachej0..aspect/rules/external_repository_action_cacheE	DEFAULT_REGISTRY_DOMAINregistry.npmjs.orgjregistry.npmjs.orgUtility functions for npm rules�
,
aspect_rules_jsnpm/privateversions.bzlSMirror of npm registry metadata for the pnpm package.

AUTO-GENERATED; do not edit
ƈ
 
aspect_rules_jsnpmdefs.bzl�Wnpm_link_package�"Links an npm package to node_modules if link is True.

When called at the root_package, a package store target is generated named `link__{bazelified_name}__store`.

When linking, a `{name}` target is generated which consists of the `node_modules/<package>` symlink and transitively
its package store link and the package store links of the transitive closure of deps.

When linking, `{name}/dir` filegroup is also generated that refers to a directory artifact can be used to access
the package directory for creating entry points or accessing files in the package.


Defines a npm package that is linked into a node_modules tree.

The npm package is linked with a pnpm style symlinked node_modules output tree.

The term "package" is defined at
<https://nodejs.org/docs/latest-v16.x/api/packages.html>

See https://pnpm.io/symlinked-node-modules-structure for more information on
the symlinked node_modules structure.
Npm may also support a symlinked node_modules structure called
"Isolated mode" in the future:
https://github.com/npm/rfcs/blob/main/accepted/0042-isolated-mode.md.
"�N
�+
npm_link_package�"Links an npm package to node_modules if link is True.

When called at the root_package, a package store target is generated named `link__{bazelified_name}__store`.

When linking, a `{name}` target is generated which consists of the `node_modules/<package>` symlink and transitively
its package store link and the package store links of the transitive closure of deps.

When linking, `{name}/dir` filegroup is also generated that refers to a directory artifact can be used to access
the package directory for creating entry points or accessing files in the package.


Defines a npm package that is linked into a node_modules tree.

The npm package is linked with a pnpm style symlinked node_modules output tree.

The term "package" is defined at
<https://nodejs.org/docs/latest-v16.x/api/packages.html>

See https://pnpm.io/symlinked-node-modules-structure for more information on
the symlinked node_modules structure.
Npm may also support a symlinked node_modules structure called
"Isolated mode" in the future:
https://github.com/npm/rfcs/blob/main/accepted/0042-isolated-mode.md.
*
nameA unique name for this target. �
deps�Other node packages store link targets one depends on mapped to the name to link them under in this packages deps.

This should include *all* modules the program may need at runtime.

You can find all the package store link targets in your repository with

```
bazel query ... | grep :.aspect_rules_js | grep -v /dir | grep -v /pkg | grep -v /ref
```

Package store link targets names for 3rd party packages that come from `npm_translate_lock`
start with `.aspect_rules_js/` then the name passed to the `npm_link_all_packages` macro
(typically `node_modules`) followed by `/<package>/<version>` where `package` is the
package name (including @scope segment if any) and `version` is the specific version of
the package that comes from the pnpm-lock.yaml file.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

The version may include peer dep(s),

```
//:.aspect_rules_js/node_modules/debug/4.3.4_supports-color@8.1.1
```

It could be also be a url based version,

```
//:.aspect_rules_js/node_modules/debug/github.com/ngokevin/debug/9742c5f383a6f8046241920156236ade8ec30d53
```

Package store link targets names for 3rd party package that come directly from an
`npm_import` start with `.aspect_rules_js/` then the name passed to the `npm_import`'s `npm_link_imported_package`
macro (typically `node_modules`) followed by `/<package>/<version>` where `package`
matches the `package` attribute in the npm_import of the package and `version` matches the
`version` attribute.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

Package store link targets names for 1st party packages automatically linked by `npm_link_all_packages`
using workspaces will follow the same pattern as 3rd party packages with the version typically defaulting
to "0.0.0".

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg/0.0.0
```

Package store link targets names for 1st party packages manually linked with `npm_link_package`
start with `.aspect_rules_js/` followed by the name passed to the `npm_link_package`.

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg
```

> In typical usage, a node.js program sometimes requires modules which were
> never declared as dependencies.
> This pattern is typically used when the program has conditional behavior
> that is enabled when the module is found (like a plugin) but the program
> also runs without the dependency.
> 
> This is possible because node.js doesn't enforce the dependencies are sound.
> All files under `node_modules` are available to any program.
> In contrast, Bazel makes it possible to make builds hermetic, which means that
> all dependencies of a program must be declared when running in Bazel's sandbox.
	*
NpmPackageStoreInfo
JsInfo2{}<
dev,Whether this npm package is a dev dependency2False�
exclude_package_contents�List of exclude patterns to exclude files from the package store.

The exclude patterns are relative to the package store directory.
2[]�
hardlink�Controls when to use hardlinks to files instead of making copies.

Creating hardlinks is much faster than making copies of files with the caveat that
hardlinks share file permissions with their source.

Since Bazel removes write permissions on files in the output tree after an action completes,
hardlinks to source files is not recommended since write permissions will be inadvertently
removed from sources files.

- "auto": hardlinks are used for generated files already in the output tree
- "off": all files are copied
- "on": hardlinks are used for all files (not recommended)

NB: Hardlinking source files in external repositories as was done under the hood
prior to https://github.com/aspect-build/rules_js/pull/1533 may lead to flaky build
failures as reported in https://github.com/aspect-build/rules_js/issues/1412.
2"auto"�
package�The package name to link to.

If unset, the package name in the `NpmPackageInfo` src must be set.
If set, takes precendance over the package name in the `NpmPackageInfo` src.
2""]
srcRA target providing a `NpmPackageInfo` or `JsInfo` containing the package sources.
 >
verbose*If true, prints out verbose logs to stdout2False�
version�The package version being linked.

If unset, the package version in the `NpmPackageInfo` src must be set.
If set, takes precendance over the package version in the `NpmPackageInfo` src.
2""
,
*
nameA unique name for this target. �
�
deps�Other node packages store link targets one depends on mapped to the name to link them under in this packages deps.

This should include *all* modules the program may need at runtime.

You can find all the package store link targets in your repository with

```
bazel query ... | grep :.aspect_rules_js | grep -v /dir | grep -v /pkg | grep -v /ref
```

Package store link targets names for 3rd party packages that come from `npm_translate_lock`
start with `.aspect_rules_js/` then the name passed to the `npm_link_all_packages` macro
(typically `node_modules`) followed by `/<package>/<version>` where `package` is the
package name (including @scope segment if any) and `version` is the specific version of
the package that comes from the pnpm-lock.yaml file.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

The version may include peer dep(s),

```
//:.aspect_rules_js/node_modules/debug/4.3.4_supports-color@8.1.1
```

It could be also be a url based version,

```
//:.aspect_rules_js/node_modules/debug/github.com/ngokevin/debug/9742c5f383a6f8046241920156236ade8ec30d53
```

Package store link targets names for 3rd party package that come directly from an
`npm_import` start with `.aspect_rules_js/` then the name passed to the `npm_import`'s `npm_link_imported_package`
macro (typically `node_modules`) followed by `/<package>/<version>` where `package`
matches the `package` attribute in the npm_import of the package and `version` matches the
`version` attribute.

For example,

```
//:.aspect_rules_js/node_modules/cliui/7.0.4
```

Package store link targets names for 1st party packages automatically linked by `npm_link_all_packages`
using workspaces will follow the same pattern as 3rd party packages with the version typically defaulting
to "0.0.0".

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg/0.0.0
```

Package store link targets names for 1st party packages manually linked with `npm_link_package`
start with `.aspect_rules_js/` followed by the name passed to the `npm_link_package`.

For example,

```
//:.aspect_rules_js/node_modules/@mycorp/mypkg
```

> In typical usage, a node.js program sometimes requires modules which were
> never declared as dependencies.
> This pattern is typically used when the program has conditional behavior
> that is enabled when the module is found (like a plugin) but the program
> also runs without the dependency.
> 
> This is possible because node.js doesn't enforce the dependencies are sound.
> All files under `node_modules` are available to any program.
> In contrast, Bazel makes it possible to make builds hermetic, which means that
> all dependencies of a program must be declared when running in Bazel's sandbox.
	*
NpmPackageStoreInfo
JsInfo2{}>
<
dev,Whether this npm package is a dev dependency2False�
�
exclude_package_contents�List of exclude patterns to exclude files from the package store.

The exclude patterns are relative to the package store directory.
2[]�
�
hardlink�Controls when to use hardlinks to files instead of making copies.

Creating hardlinks is much faster than making copies of files with the caveat that
hardlinks share file permissions with their source.

Since Bazel removes write permissions on files in the output tree after an action completes,
hardlinks to source files is not recommended since write permissions will be inadvertently
removed from sources files.

- "auto": hardlinks are used for generated files already in the output tree
- "off": all files are copied
- "on": hardlinks are used for all files (not recommended)

NB: Hardlinking source files in external repositories as was done under the hood
prior to https://github.com/aspect-build/rules_js/pull/1533 may lead to flaky build
failures as reported in https://github.com/aspect-build/rules_js/issues/1412.
2"auto"�
�
package�The package name to link to.

If unset, the package name in the `NpmPackageInfo` src must be set.
If set, takes precendance over the package name in the `NpmPackageInfo` src.
2""_
]
srcRA target providing a `NpmPackageInfo` or `JsInfo` containing the package sources.
 @
>
verbose*If true, prints out verbose logs to stdout2False�
�
version�The package version being linked.

If unset, the package version in the `NpmPackageInfo` src must be set.
If set, takes precendance over the package version in the `NpmPackageInfo` src.
2""��npm_package�A macro that packages sources into a directory (a tree artifact) and provides an `NpmPackageInfo`.

This target can be used as the `src` attribute to `npm_link_package`.

With `publishable = True` the macro also produces a target `[name].publish`, that can be run to publish to an npm registry.
Under the hood, this target runs `npm publish`. You can pass arguments to npm by escaping them from Bazel using a double-hyphen,
for example: `bazel run //path/to:my_package.publish -- --tag=next`

Files and directories can be arranged as needed in the output directory using
the `root_paths`, `include_srcs_patterns`, `exclude_srcs_patterns` and `replace_prefixes` attributes.

Filters and transformations are applied in the following order:

1. `include_external_repositories`

2. `include_srcs_packages`

3. `exclude_srcs_packages`

4. `root_paths`

5. `include_srcs_patterns`

6. `exclude_srcs_patterns`

7. `replace_prefixes`

For more information each filters / transformations applied, see
the documentation for the specific filter / transformation attribute.

Glob patterns are supported. Standard wildcards (globbing patterns) plus the `**` doublestar (aka. super-asterisk)
are supported with the underlying globbing library, https://github.com/bmatcuk/doublestar. This is the same
globbing library used by [gazelle](https://github.com/bazelbuild/bazel-gazelle). See https://github.com/bmatcuk/doublestar#patterns
for more information on supported globbing patterns.

`npm_package` makes use of `copy_to_directory`
(https://docs.aspect.build/rules/aspect_bazel_lib/docs/copy_to_directory) under the hood,
adopting its API and its copy action using composition. However, unlike `copy_to_directory`,
`npm_package` includes direct and transitive sources and types files from `JsInfo` providers in srcs
by default. The behavior of including sources and types from `JsInfo` can be configured
using the `include_sources`, `include_transitive_sources`, `include_types`, `include_transitive_types`.

The two `include*_types` options may cause type-check actions to run, which slows down your
development round-trip.

As of rules_js 2.0, the recommended solution for avoiding eager type-checking when linking
1p deps is to link `js_library` or any `JsInfo` producing targets directly without the
indirection of going through an `npm_package` target (see https://github.com/aspect-build/rules_js/pull/1646
for more details).

`npm_package` can also include npm packages sources and default runfiles from `srcs` which `copy_to_directory` does not.
These behaviors can be configured with the `include_npm_sourfes` and `include_runfiles` attributes
respectively.

The default `include_srcs_packages`, `[".", "./**"]`, prevents files from outside of the target's
package and subpackages from being included.

The default `exclude_srcs_patterns`, of `["node_modules/**", "**/node_modules/**"]`, prevents
`node_modules` files from being included.

To stamp the current git tag as the "version" in the package.json file, see
[stamped_package_json](#stamped_package_json)
"��
�Q
npm_package�A macro that packages sources into a directory (a tree artifact) and provides an `NpmPackageInfo`.

This target can be used as the `src` attribute to `npm_link_package`.

With `publishable = True` the macro also produces a target `[name].publish`, that can be run to publish to an npm registry.
Under the hood, this target runs `npm publish`. You can pass arguments to npm by escaping them from Bazel using a double-hyphen,
for example: `bazel run //path/to:my_package.publish -- --tag=next`

Files and directories can be arranged as needed in the output directory using
the `root_paths`, `include_srcs_patterns`, `exclude_srcs_patterns` and `replace_prefixes` attributes.

Filters and transformations are applied in the following order:

1. `include_external_repositories`

2. `include_srcs_packages`

3. `exclude_srcs_packages`

4. `root_paths`

5. `include_srcs_patterns`

6. `exclude_srcs_patterns`

7. `replace_prefixes`

For more information each filters / transformations applied, see
the documentation for the specific filter / transformation attribute.

Glob patterns are supported. Standard wildcards (globbing patterns) plus the `**` doublestar (aka. super-asterisk)
are supported with the underlying globbing library, https://github.com/bmatcuk/doublestar. This is the same
globbing library used by [gazelle](https://github.com/bazelbuild/bazel-gazelle). See https://github.com/bmatcuk/doublestar#patterns
for more information on supported globbing patterns.

`npm_package` makes use of `copy_to_directory`
(https://docs.aspect.build/rules/aspect_bazel_lib/docs/copy_to_directory) under the hood,
adopting its API and its copy action using composition. However, unlike `copy_to_directory`,
`npm_package` includes direct and transitive sources and types files from `JsInfo` providers in srcs
by default. The behavior of including sources and types from `JsInfo` can be configured
using the `include_sources`, `include_transitive_sources`, `include_types`, `include_transitive_types`.

The two `include*_types` options may cause type-check actions to run, which slows down your
development round-trip.

As of rules_js 2.0, the recommended solution for avoiding eager type-checking when linking
1p deps is to link `js_library` or any `JsInfo` producing targets directly without the
indirection of going through an `npm_package` target (see https://github.com/aspect-build/rules_js/pull/1646
for more details).

`npm_package` can also include npm packages sources and default runfiles from `srcs` which `copy_to_directory` does not.
These behaviors can be configured with the `include_npm_sourfes` and `include_runfiles` attributes
respectively.

The default `include_srcs_packages`, `[".", "./**"]`, prevents files from outside of the target's
package and subpackages from being included.

The default `exclude_srcs_patterns`, of `["node_modules/**", "**/node_modules/**"]`, prevents
`node_modules` files from being included.

To stamp the current git tag as the "version" in the package.json file, see
[stamped_package_json](#stamped_package_json)
*
nameA unique name for this target. e
add_directory_to_runfiles@Whether to add the outputted directory to the target's runfiles.2True�
allow_overwrites�If True, allow files to be overwritten if the same output file is copied to twice.

The order of srcs matters as the last copy of a particular file will win when overwriting.
Performance of copy_to_directory will be slightly degraded when allow_overwrites is True
since copies cannot be parallelized out as they are calculated. Instead all copy paths
must be calculated before any copies can be started.
2False
data2[]�
exclude_srcs_packages�List of Bazel packages (with glob support) to exclude from output directory.

Files in srcs are not copied to the output directory if
the Bazel package of the file matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators. A first character of `"."`
will be replaced by the target's package path.

Files that have do not have matching Bazel packages are subject to subsequent
filters and transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).
2[]�
exclude_srcs_patterns�List of paths (with glob support) to exclude from output directory.

Files in srcs are not copied to the output directory if their output
directory path, after applying `root_paths`, matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators.

Files that do not have matching output directory paths are subject to subsequent
filters and transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).
2[]�
hardlink�Controls when to use hardlinks to files instead of making copies.

Creating hardlinks is much faster than making copies of files with the caveat that
hardlinks share file permissions with their source.

Since Bazel removes write permissions on files in the output tree after an action completes,
hardlinks to source files are not recommended since write permissions will be inadvertently
removed from sources files.

- `auto`: hardlinks are used for generated files already in the output tree
- `off`: all files are copied
- `on`: hardlinks are used for all files (not recommended)
2"auto"�	
include_external_repositories�	List of external repository names (with glob support) to include in the output directory.

Files from external repositories are only copied into the output directory if
the external repository they come from matches one of the external repository patterns
specified or if they are in the same external repository as this target.

When copied from an external repository, the file path in the output directory
defaults to the file's path within the external repository. The external repository
name is _not_ included in that path.

For example, the following copies `@external_repo//path/to:file` to
`path/to/file` within the output directory.

```
copy_to_directory(
    name = "dir",
    include_external_repositories = ["external_*"],
    srcs = ["@external_repo//path/to:file"],
)
```

Files that come from matching external are subject to subsequent filters and
transformations to determine if they are copied and what their path in the output
directory will be. The external repository name of the file from an external
repository is not included in the output directory path and is considered in subsequent
filters and transformations.

Globs are supported (see rule docstring above).
2[]�
include_srcs_packages�List of Bazel packages (with glob support) to include in output directory.

Files in srcs are only copied to the output directory if
the Bazel package of the file matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators. A first character of `"."`
will be replaced by the target's package path.

Defaults to `["**"]` which includes sources from all packages.

Files that have matching Bazel packages are subject to subsequent filters and
transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).
2["**"]�
include_srcs_patterns�List of paths (with glob support) to include in output directory.

Files in srcs are only copied to the output directory if their output
directory path, after applying `root_paths`, matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators.

Defaults to `["**"]` which includes all sources.

Files that have matching output directory paths are subject to subsequent
filters and transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).
2["**"]r
outePath of the output directory, relative to this package.

If not set, the name of the target is used.
2""
package2""�
preserve_mtime�If True, the last modified time of copied files is preserved.
See the [caveats on copy_directory](/docs/copy_directory.md#preserving-modification-times)
about interactions with remote execution and caching.2False�
replace_prefixes�Map of paths prefixes (with glob support) to replace in the output directory path when copying files.

If the output directory path for a file starts with or fully matches a
a key in the dict then the matching portion of the output directory path is
replaced with the dict value for that key. The final path segment
matched can be a partial match of that segment and only the matching portion will
be replaced. If there are multiple keys that match, the longest match wins.

Forward slashes (`/`) should be used as path separators.

Replace prefix transformation are the final step in the list of filters and transformations.
The final output path of a file being copied into the output directory
is determined at this step.

Globs are supported (see rule docstring above).

2{}�

root_paths�List of paths (with glob support) that are roots in the output directory.

If any parent directory of a file being copied matches one of the root paths
patterns specified, the output directory path will be the path relative to the root path
instead of the path relative to the file's workspace. If there are multiple
root paths that match, the longest match wins.

Matching is done on the parent directory of the output file path so a trailing '**' glob patterm
will match only up to the last path segment of the dirname and will not include the basename.
Only complete path segments are matched. Partial matches on the last segment of the root path
are ignored.

Forward slashes (`/`) should be used as path separators.

A `"."` value expands to the target's package path (`ctx.label.package`).

Defaults to `["."]` which results in the output directory path of files in the
target's package and and sub-packages are relative to the target's package and
files outside of that retain their full workspace relative paths.

Globs are supported (see rule docstring above).
2["."]u
srcsgFiles and/or directories or targets that provide `DirectoryPathInfo` to copy into the output directory.2[]>
verbose*If true, prints out verbose logs to stdout2False
version2""
��,
*
nameA unique name for this target. g
e
add_directory_to_runfiles@Whether to add the outputted directory to the target's runfiles.2True�
�
allow_overwrites�If True, allow files to be overwritten if the same output file is copied to twice.

The order of srcs matters as the last copy of a particular file will win when overwriting.
Performance of copy_to_directory will be slightly degraded when allow_overwrites is True
since copies cannot be parallelized out as they are calculated. Instead all copy paths
must be calculated before any copies can be started.
2False

data2[]�
�
exclude_srcs_packages�List of Bazel packages (with glob support) to exclude from output directory.

Files in srcs are not copied to the output directory if
the Bazel package of the file matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators. A first character of `"."`
will be replaced by the target's package path.

Files that have do not have matching Bazel packages are subject to subsequent
filters and transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).
2[]�
�
exclude_srcs_patterns�List of paths (with glob support) to exclude from output directory.

Files in srcs are not copied to the output directory if their output
directory path, after applying `root_paths`, matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators.

Files that do not have matching output directory paths are subject to subsequent
filters and transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).
2[]�
�
hardlink�Controls when to use hardlinks to files instead of making copies.

Creating hardlinks is much faster than making copies of files with the caveat that
hardlinks share file permissions with their source.

Since Bazel removes write permissions on files in the output tree after an action completes,
hardlinks to source files are not recommended since write permissions will be inadvertently
removed from sources files.

- `auto`: hardlinks are used for generated files already in the output tree
- `off`: all files are copied
- `on`: hardlinks are used for all files (not recommended)
2"auto"�	
�	
include_external_repositories�	List of external repository names (with glob support) to include in the output directory.

Files from external repositories are only copied into the output directory if
the external repository they come from matches one of the external repository patterns
specified or if they are in the same external repository as this target.

When copied from an external repository, the file path in the output directory
defaults to the file's path within the external repository. The external repository
name is _not_ included in that path.

For example, the following copies `@external_repo//path/to:file` to
`path/to/file` within the output directory.

```
copy_to_directory(
    name = "dir",
    include_external_repositories = ["external_*"],
    srcs = ["@external_repo//path/to:file"],
)
```

Files that come from matching external are subject to subsequent filters and
transformations to determine if they are copied and what their path in the output
directory will be. The external repository name of the file from an external
repository is not included in the output directory path and is considered in subsequent
filters and transformations.

Globs are supported (see rule docstring above).
2[]�
�
include_srcs_packages�List of Bazel packages (with glob support) to include in output directory.

Files in srcs are only copied to the output directory if
the Bazel package of the file matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators. A first character of `"."`
will be replaced by the target's package path.

Defaults to `["**"]` which includes sources from all packages.

Files that have matching Bazel packages are subject to subsequent filters and
transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).
2["**"]�
�
include_srcs_patterns�List of paths (with glob support) to include in output directory.

Files in srcs are only copied to the output directory if their output
directory path, after applying `root_paths`, matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators.

Defaults to `["**"]` which includes all sources.

Files that have matching output directory paths are subject to subsequent
filters and transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).
2["**"]t
r
outePath of the output directory, relative to this package.

If not set, the name of the target is used.
2""

package2""�
�
preserve_mtime�If True, the last modified time of copied files is preserved.
See the [caveats on copy_directory](/docs/copy_directory.md#preserving-modification-times)
about interactions with remote execution and caching.2False�
�
replace_prefixes�Map of paths prefixes (with glob support) to replace in the output directory path when copying files.

If the output directory path for a file starts with or fully matches a
a key in the dict then the matching portion of the output directory path is
replaced with the dict value for that key. The final path segment
matched can be a partial match of that segment and only the matching portion will
be replaced. If there are multiple keys that match, the longest match wins.

Forward slashes (`/`) should be used as path separators.

Replace prefix transformation are the final step in the list of filters and transformations.
The final output path of a file being copied into the output directory
is determined at this step.

Globs are supported (see rule docstring above).

2{}�
�

root_paths�List of paths (with glob support) that are roots in the output directory.

If any parent directory of a file being copied matches one of the root paths
patterns specified, the output directory path will be the path relative to the root path
instead of the path relative to the file's workspace. If there are multiple
root paths that match, the longest match wins.

Matching is done on the parent directory of the output file path so a trailing '**' glob patterm
will match only up to the last path segment of the dirname and will not include the basename.
Only complete path segments are matched. Partial matches on the last segment of the root path
are ignored.

Forward slashes (`/`) should be used as path separators.

A `"."` value expands to the target's package path (`ctx.label.package`).

Defaults to `["."]` which results in the output directory path of files in the
target's package and and sub-packages are relative to the target's package and
files outside of that retain their full workspace relative paths.

Globs are supported (see rule docstring above).
2["."]w
u
srcsgFiles and/or directories or targets that provide `DirectoryPathInfo` to copy into the output directory.2[]@
>
verbose*If true, prints out verbose logs to stdout2False

version2""�	stamped_package_json�Convenience wrapper to set the "version" property in package.json with the git tag.

In unstamped builds (typically those without `--stamp`) the version will be set to `0.0.0`.
This ensures that actions which use the package.json file can get cache hits.

For more information on stamping, read https://docs.aspect.build/rules/aspect_bazel_lib/docs/stamping.
*�
�
stamped_package_json@
name4name of the resulting `jq` target, must be "package" (b
	stamp_varQa key from the bazel-out/stable-status.txt or bazel-out/volatile-status.txt files (u
kwargsiadditional attributes passed to the jq rule, see https://docs.aspect.build/rules/aspect_bazel_lib/docs/jq(�Convenience wrapper to set the "version" property in package.json with the git tag.

In unstamped builds (typically those without `--stamp`) the version will be set to `0.0.0`.
This ensures that actions which use the package.json file can get cache hits.

For more information on stamping, read https://docs.aspect.build/rules/aspect_bazel_lib/docs/stamping.
2F
stamped_package_json.@@aspect_rules_js//npm/private:npm_package.bzl
��*jq2jq�
"//npm/private:npm_link_package.bzlry
4
aspect_rules_jsnpm/privatenpm_link_package.bzl3
npm_link_package_npm_link_package

�
//npm/private:npm_package.bzlr�
/
aspect_rules_jsnpm/privatenpm_package.bzl)
npm_package_npm_package


;
stamped_package_json_stamped_package_json

n
	:defs.bzlr_
)
aspect_tools_telemetry_reportdefs.bzl$
	TELEMETRY	TELEMETRY
4=
?[Rules for fetching and linking npm dependencies and packaging and linking first-party deps
�_
&
aspect_rules_jsnpmextensions.bzl�=npmJ�=
�
npm�	
npm_translate_lock
name2""
additional_file_contents 

bins 
bzlmod2False
custom_postinstalls
2{}
data2[]!
defs_bzl_filename2
"defs.bzl"
dev2FalseV
 external_repository_action_cache20".aspect/rules/external_repository_action_cache"'
generate_bzl_library_targets2False
lifecycle_hooks 
lifecycle_hooks_envs 
lifecycle_hooks_exclude2[],
&lifecycle_hooks_execution_requirements $
lifecycle_hooks_no_sandbox2True-
%lifecycle_hooks_use_default_shell_env
2{}
link_workspace2""
no_optional2False#
node_toolchain_prefix2"nodejs"
npm_package_lock2None"
npm_package_target_name2"pkg"
npmrc2None
package_visibility 

patch_args 

patch_tool2None
patches 
	pnpm_lock2None
	preupdate2[]
prod2False
public_hoist_packages 
quiet2True
replace_packages
2{}
root_package2"."
run_lifecycle_hooks2True
update_pnpm_lock2False
use_home_npmrc2False*
use_pnpm2@pnpm//:package/bin/pnpm.cjs%
verify_node_modules_ignored2None
verify_patches2None
	yarn_lock2None
yq_toolchain_prefix2"yq"�

npm_import
name2""
bins
2{}
commit2""
custom_postinstall2""
deps
2{}
dev2False 
exclude_package_contents2[]
extra_build_content2""
extract_full_archive2False'
generate_bzl_library_targets2False
	integrity2""!
lifecycle_build_target2False
lifecycle_hooks2[]
lifecycle_hooks_env2[]:
&lifecycle_hooks_execution_requirements2["no-sandbox"]%
lifecycle_hooks_no_sandbox2False0
%lifecycle_hooks_use_default_shell_env2False
link_packages 
link_workspace2""
npm_auth2""
npm_auth_basic2""
npm_auth_password2""
npm_auth_username2""
package /
package_visibility2["//visibility:public"]

patch_args2["-p0"]

patch_tool2None
patches2[]
replace_package2""
root_package2""
run_lifecycle_hooks2False

system_tar2"auto"
transitive_closure 
url2""
version �
npm_exclude_package_contentsa
packageRPackage name to apply exclusions to. Supports wildcards like '*' for all packages. N
patterns<List of glob patterns to exclude from the specified package.2[]�
use_defaults�Whether to use default exclusion patterns for the specified package. Defaults are as to Yarn autoclean: https://github.com/yarnpkg/yarn/blob/7cafa512a777048ce0b666080a24e80aae3d66a9/src/cli/commands/autoclean.js#L162False",
npm%@@aspect_rules_js//npm:extensions.bzl
���
�	
npm_translate_lock
name2""
additional_file_contents 

bins 
bzlmod2False
custom_postinstalls
2{}
data2[]!
defs_bzl_filename2
"defs.bzl"
dev2FalseV
 external_repository_action_cache20".aspect/rules/external_repository_action_cache"'
generate_bzl_library_targets2False
lifecycle_hooks 
lifecycle_hooks_envs 
lifecycle_hooks_exclude2[],
&lifecycle_hooks_execution_requirements $
lifecycle_hooks_no_sandbox2True-
%lifecycle_hooks_use_default_shell_env
2{}
link_workspace2""
no_optional2False#
node_toolchain_prefix2"nodejs"
npm_package_lock2None"
npm_package_target_name2"pkg"
npmrc2None
package_visibility 

patch_args 

patch_tool2None
patches 
	pnpm_lock2None
	preupdate2[]
prod2False
public_hoist_packages 
quiet2True
replace_packages
2{}
root_package2"."
run_lifecycle_hooks2True
update_pnpm_lock2False
use_home_npmrc2False*
use_pnpm2@pnpm//:package/bin/pnpm.cjs%
verify_node_modules_ignored2None
verify_patches2None
	yarn_lock2None
yq_toolchain_prefix2"yq"

name2"" 

additional_file_contents 


bins 

bzlmod2False

custom_postinstalls
2{}

data2[]#
!
defs_bzl_filename2
"defs.bzl"

dev2FalseX
V
 external_repository_action_cache20".aspect/rules/external_repository_action_cache")
'
generate_bzl_library_targets2False

lifecycle_hooks 

lifecycle_hooks_envs !

lifecycle_hooks_exclude2[].
,
&lifecycle_hooks_execution_requirements &
$
lifecycle_hooks_no_sandbox2True/
-
%lifecycle_hooks_use_default_shell_env
2{}

link_workspace2""

no_optional2False%
#
node_toolchain_prefix2"nodejs"

npm_package_lock2None$
"
npm_package_target_name2"pkg"

npmrc2None

package_visibility 


patch_args 


patch_tool2None

patches 

	pnpm_lock2None

	preupdate2[]

prod2False

public_hoist_packages 

quiet2True

replace_packages
2{}

root_package2"."

run_lifecycle_hooks2True

update_pnpm_lock2False

use_home_npmrc2False,
*
use_pnpm2@pnpm//:package/bin/pnpm.cjs'
%
verify_node_modules_ignored2None

verify_patches2None

	yarn_lock2None

yq_toolchain_prefix2"yq"�
�

npm_import
name2""
bins
2{}
commit2""
custom_postinstall2""
deps
2{}
dev2False 
exclude_package_contents2[]
extra_build_content2""
extract_full_archive2False'
generate_bzl_library_targets2False
	integrity2""!
lifecycle_build_target2False
lifecycle_hooks2[]
lifecycle_hooks_env2[]:
&lifecycle_hooks_execution_requirements2["no-sandbox"]%
lifecycle_hooks_no_sandbox2False0
%lifecycle_hooks_use_default_shell_env2False
link_packages 
link_workspace2""
npm_auth2""
npm_auth_basic2""
npm_auth_password2""
npm_auth_username2""
package /
package_visibility2["//visibility:public"]

patch_args2["-p0"]

patch_tool2None
patches2[]
replace_package2""
root_package2""
run_lifecycle_hooks2False

system_tar2"auto"
transitive_closure 
url2""
version 

name2""

bins
2{}

commit2""

custom_postinstall2""

deps
2{}

dev2False"
 
exclude_package_contents2[]

extra_build_content2""!

extract_full_archive2False)
'
generate_bzl_library_targets2False

	integrity2""#
!
lifecycle_build_target2False

lifecycle_hooks2[]

lifecycle_hooks_env2[]<
:
&lifecycle_hooks_execution_requirements2["no-sandbox"]'
%
lifecycle_hooks_no_sandbox2False2
0
%lifecycle_hooks_use_default_shell_env2False

link_packages 

link_workspace2""

npm_auth2""

npm_auth_basic2""

npm_auth_password2""

npm_auth_username2""

package 1
/
package_visibility2["//visibility:public"]


patch_args2["-p0"]


patch_tool2None

patches2[]

replace_package2""

root_package2"" 

run_lifecycle_hooks2False


system_tar2"auto"

transitive_closure 

url2""

version �
�
npm_exclude_package_contentsa
packageRPackage name to apply exclusions to. Supports wildcards like '*' for all packages. N
patterns<List of glob patterns to exclude from the specified package.2[]�
use_defaults�Whether to use default exclusion patterns for the specified package. Defaults are as to Yarn autoclean: https://github.com/yarnpkg/yarn/blob/7cafa512a777048ce0b666080a24e80aae3d66a9/src/cli/commands/autoclean.js#L162Falsec
a
packageRPackage name to apply exclusions to. Supports wildcards like '*' for all packages. P
N
patterns<List of glob patterns to exclude from the specified package.2[]�
�
use_defaults�Whether to use default exclusion patterns for the specified package. Defaults are as to Yarn autoclean: https://github.com/yarnpkg/yarn/blob/7cafa512a777048ce0b666080a24e80aae3d66a9/src/cli/commands/autoclean.js#L162False�pnpmJ�
�
pnpm�
pnpm�
name�Name of the generated repository, allowing more than one pnpm version to be registered.
                        Overriding the default is only permitted in the root module.2"pnpm"m
pnpm_versionQpnpm version to use. The string `latest` will be resolved to LATEST_PNPM_VERSION.2"8.15.9"�
pnpm_version_fromiLabel to a package.json file to read the pnpm version from. It should be in the packageManager attribute.2None
pnpm_version_integrity2"""-
pnpm%@@aspect_rules_js//npm:extensions.bzl
���
�
pnpm�
name�Name of the generated repository, allowing more than one pnpm version to be registered.
Overriding the default is only permitted in the root module.2"pnpm"m
pnpm_versionQpnpm version to use. The string `latest` will be resolved to LATEST_PNPM_VERSION.2"8.15.9"�
pnpm_version_fromiLabel to a package.json file to read the pnpm version from. It should be in the packageManager attribute.2None
pnpm_version_integrity2""�
�
name�Name of the generated repository, allowing more than one pnpm version to be registered.
Overriding the default is only permitted in the root module.2"pnpm"o
m
pnpm_versionQpnpm version to use. The string `latest` will be resolved to LATEST_PNPM_VERSION.2"8.15.9"�
�
pnpm_version_fromiLabel to a package.json file to read the pnpm version from. It should be in the packageManager attribute.2None 

pnpm_version_integrity2""y
//lib:repo_utils.bzlr_
'
aspect_bazel_liblibrepo_utils.bzl&

repo_utils
repo_utils
0:
<o
//lib:utils.bzlrZ
"
aspect_bazel_liblib	utils.bzl&
utilsbazel_lib_utils
*9
D�
//npm:repositories.bzlr�
(
aspect_rules_jsnpmrepositories.bzl&

npm_import
npm_import
1;0
pnpm_repositorypnpm_repository
?N;
DEFAULT_PNPM_VERSION_DEFAULT_PNPM_VERSION
Qf;
LATEST_PNPM_VERSION_LATEST_PNPM_VERSION
��
��
2//npm/private:exclude_package_contents_default.bzlr�
D
aspect_rules_jsnpm/private$exclude_package_contents_default.bzlR
 exclude_package_contents_default exclude_package_contents_default
Mm
o�
//npm/private:npm_import.bzlr�
.
aspect_rules_jsnpm/privatenpm_import.bzl.
npm_import_libnpm_import_lib
	7	E:
npm_import_links_libnpm_import_links_lib
	I	]
		_�
$//npm/private:npm_translate_lock.bzlr�
6
aspect_rules_jsnpm/privatenpm_translate_lock.bzl>
npm_translate_lock_libnpm_translate_lock_lib

?
U@
npm_translate_lock_rulenpm_translate_lock_rule

Y
p


r�
,//npm/private:npm_translate_lock_helpers.bzlr�
>
aspect_rules_jsnpm/privatenpm_translate_lock_helpers.bzl3
helpersnpm_translate_lock_helpers
F`
m�
2//npm/private:npm_translate_lock_macro_helpers.bzlr|
D
aspect_rules_jsnpm/private$npm_translate_lock_macro_helpers.bzl&
helpersmacro_helpers
LY
f�
*//npm/private:npm_translate_lock_state.bzlr�
<
aspect_rules_jsnpm/privatenpm_translate_lock_state.bzlB
npm_translate_lock_statenpm_translate_lock_state
E]
_�
//npm/private:npmrc.bzlrc
)
aspect_rules_jsnpm/private	npmrc.bzl(
parse_npmrcparse_npmrc
2=
?�
 //npm/private:pnpm_extension.bzlr�
2
aspect_rules_jsnpm/privatepnpm_extension.bzl>
DEFAULT_PNPM_REPO_NAMEDEFAULT_PNPM_REPO_NAME
;QD
resolve_pnpm_repositoriesresolve_pnpm_repositories
Un
p�
//npm/private:tar.bzlrm
'
aspect_rules_jsnpm/privatetar.bzl4
detect_system_tardetect_system_tar
0A
C�
$//npm/private:transitive_closure.bzlr�
6
aspect_rules_jsnpm/privatetransitive_closure.bzlP
translate_to_transitive_closuretranslate_to_transitive_closure
?^
`q
:features.bzlr^

bazel_featuresfeatures.bzl.
bazel_featuresbazel_features
)7
9*	DEFAULT_PNPM_VERSION8.15.9j8.15.9+	LATEST_PNPM_VERSION10.17.1j	10.17.1sAdapt npm repository rules to be called from MODULE.bazel
See https://bazel.build/docs/bzlmod#extension-definition
�
 
aspect_rules_jsnpmlibs.bzl�
//npm/private:npm_package.bzlrr
/
aspect_rules_jsnpm/privatenpm_package.bzl1
npm_package_lib_npm_package_lib

0Starlark libraries for building derivative rules�
%
aspect_rules_jsnpmproviders.bzl�NpmPackageInfoNProvides the sources of an npm package along with the package name and version2�
�
NpmPackageInfoNProvides the sources of an npm package along with the package name and version#
packagename of this npm package&
versionversion of this npm packagec
src\the sources of this npm package; either a tarball file, a TreeArtifact or a source directory�
npm_package_store_infos�A depset of NpmPackageStoreInfo providers from npm dependencies of the package and the packages's transitive deps to use as direct dependencies when linking with npm_link_package"6
NpmPackageInfo$@@aspect_rules_js//npm:providers.bzl
%
#
packagename of this npm package(
&
versionversion of this npm packagee
c
src\the sources of this npm package; either a tarball file, a TreeArtifact or a source directory�
�
npm_package_store_infos�A depset of NpmPackageStoreInfo providers from npm dependencies of the package and the packages's transitive deps to use as direct dependencies when linking with npm_link_package�NpmPackageStoreInfo�Provides information about an npm package within the package store of a pnpm-style
symlinked node_modules tree.

See https://pnpm.io/symlinked-node-modules-structure for more information about
symlinked node_modules trees.2�

�
NpmPackageStoreInfo�Provides information about an npm package within the package store of a pnpm-style
symlinked node_modules tree.

See https://pnpm.io/symlinked-node-modules-structure for more information about
symlinked node_modules trees.@
root_package0package that this npm package store is linked at#
packagename of this npm package&
versionversion of this npm packageB
ref_deps6dictionary of dependency npm_package_store ref targetsX
package_store_directory=the TreeArtifact of this npm package's package store location9
files0depset of files that are part of the npm package`
transitive_filesLdepset of the files that are part of the npm package and its transitive deps:
dev3whether or not this npm package is a dev dependency";
NpmPackageStoreInfo$@@aspect_rules_js//npm:providers.bzl
B
@
root_package0package that this npm package store is linked at%
#
packagename of this npm package(
&
versionversion of this npm packageD
B
ref_deps6dictionary of dependency npm_package_store ref targetsZ
X
package_store_directory=the TreeArtifact of this npm package's package store location;
9
files0depset of files that are part of the npm packageb
`
transitive_filesLdepset of the files that are part of the npm package and its transitive deps<
:
dev3whether or not this npm package is a dev dependency�
"//npm/private:npm_package_info.bzlru
4
aspect_rules_jsnpm/privatenpm_package_info.bzl/
NpmPackageInfo_NpmPackageInfo

�
(//npm/private:npm_package_store_info.bzlr�
:
aspect_rules_jsnpm/privatenpm_package_store_info.bzl9
NpmPackageStoreInfo_NpmPackageStoreInfo
		

'Providers for building derivative rules��
(
aspect_rules_jsnpmrepositories.bzl�list_patches�Write a file containing a list of all patches in the current folder to the source tree.

Use this together with the `verify_patches` attribute of `npm_translate_lock` to verify
that all patches in a patch folder are included. This macro stamps a test to ensure the
file stays up to date.
*�
�
list_patches
nameName of the target (W
outHName of file to write to the source tree. If unspecified, `name` is usedNone(V
include_patterns)Patterns to pass to a glob of patch files["*.diff", "*.patch"](M
exclude_package_contents+Patterns to ignore in a glob of patch files[](�Write a file containing a list of all patches in the current folder to the source tree.

Use this together with the `verify_patches` attribute of `npm_translate_lock` to verify
that all patches in a patch folder are included. This macro stamps a test to ensure the
file stays up to date.
2E
list_patches5@@aspect_rules_js//npm/private:npm_translate_lock.bzl
��"list_sources2list_sources2write_source_file�|
npm_import�#Import a single npm package into Bazel.

Normally you'd want to use `npm_translate_lock` to import all your packages at once.
It generates `npm_import` rules.
You can create these manually if you want to have exact control.

Bazel will only fetch the given package from an external registry if the package is
required for the user-requested targets to be build/tested.

This is a repository rule, which should be called from your `WORKSPACE` file
or some `.bzl` file loaded from it. For example, with this code in `WORKSPACE`:

```starlark
npm_import(
    name = "npm__at_types_node__15.12.2",
    package = "@types/node",
    version = "15.12.2",
    integrity = "sha512-zjQ69G564OCIWIOHSXyQEEDpdpGl+G348RAKY0XXy9Z5kU9Vzv1GMNnkar/ZJ8dzXB3COzD9Mo9NtRZ4xfgUww==",
)
```

In `MODULE.bazel` the same would look like so:

```starlark
npm.npm_import(
    name = "npm__at_types_node__15.12.2",
    package = "@types/node",
    version = "15.12.2",
    integrity = "sha512-zjQ69G564OCIWIOHSXyQEEDpdpGl+G348RAKY0XXy9Z5kU9Vzv1GMNnkar/ZJ8dzXB3COzD9Mo9NtRZ4xfgUww==",v
)
use_repo(npm, "npm__at_types_node__15.12.2")
use_repo(npm, "npm__at_types_node__15.12.2__links")
```

> This is similar to Bazel rules in other ecosystems named "_import" like
> `apple_bundle_import`, `scala_import`, `java_import`, and `py_import`.
> `go_repository` is also a model for this rule.

The name of this repository should contain the version number, so that multiple versions of the same
package don't collide.
(Note that the npm ecosystem always supports multiple versions of a library depending on where
it is required, unlike other languages like Go or Python.)

To consume the downloaded package in rules, it must be "linked" into the link package in the
package's `BUILD.bazel` file:

```
load("@npm__at_types_node__15.12.2__links//:defs.bzl", npm_link_types_node = "npm_link_imported_package")

npm_link_types_node(name = "node_modules")
```

This links `@types/node` into the `node_modules` of this package with the target name `:node_modules/@types/node`.

A `:node_modules/@types/node/dir` filegroup target is also created that provides the the directory artifact of the npm package.
This target can be used to create entry points for binary target or to access files within the npm package.

NB: You can choose any target name for the link target but we recommend using the `node_modules/@scope/name` and
`node_modules/name` convention for readability.

When using `npm_translate_lock`, you can link all the npm dependencies in the lock file for a package:

```
load("@npm//:defs.bzl", "npm_link_all_packages")

npm_link_all_packages(name = "node_modules")
```

This creates `:node_modules/name` and `:node_modules/@scope/name` targets for all direct npm dependencies in the package.
It also creates `:node_modules/name/dir` and `:node_modules/@scope/name/dir` filegroup targets that provide the the directory artifacts of their npm packages.
These target can be used to create entry points for binary target or to access files within the npm package.

If you have a mix of `npm_link_all_packages` and `npm_link_imported_package` functions to call you can pass the
`npm_link_imported_package` link functions to the `imported_links` attribute of `npm_link_all_packages` to link
them all in one call. For example,

```
load("@npm//:defs.bzl", "npm_link_all_packages")
load("@npm__at_types_node__15.12.2__links//:defs.bzl", npm_link_types_node = "npm_link_imported_package")

npm_link_all_packages(
    name = "node_modules",
    imported_links = [
        npm_link_types_node,
    ]
)
```

This has the added benefit of adding the `imported_links` to the convienence `:node_modules` target which
includes all direct dependencies in that package.

NB: You can pass an name to npm_link_all_packages and this will change the targets generated to "{name}/@scope/name" and
"{name}/name". We recommend using "node_modules" as the convention for readability.

To change the proxy URL we use to fetch, configure the Bazel downloader:

1. Make a file containing a rewrite rule like

    `rewrite (registry.npmjs.org)/(.*) artifactory.build.internal.net/artifactory/$1/$2`

1. To understand the rewrites, see [UrlRewriterConfig] in Bazel sources.

1. Point bazel to the config with a line in .bazelrc like
common --experimental_downloader_config=.bazel_downloader_config

Read more about the downloader config: <https://blog.aspect.build/configuring-bazels-downloader>

[UrlRewriterConfig]: https://github.com/bazelbuild/bazel/blob/4.2.1/src/main/java/com/google/devtools/build/lib/bazel/repository/downloader/UrlRewriterConfig.java#L66
*�X
�X

npm_import)
nameName for this repository rule (H
package9Name of the npm package, such as `acorn` or `@types/node` (:
version+Version of the npm package, such as `8.4.0` (v
depshA dict other npm packages this one depends on where the key is the package name and value is the version{}(�
extra_build_content�Additional content to append on the generated BUILD file at the root of
the created repository, either as a string or a list of lines similar to
<https://github.com/bazelbuild/bazel-skylib/blob/main/docs/write_file_doc.md>.""(�
transitive_closure�A dict all npm packages this one depends on directly or transitively where the key is the
package name and value is a list of version(s) depended on in the closure.{}(�
root_package�The root package where the node_modules package store is linked to.
Typically this is the package that the pnpm-lock.yaml file is located when using `npm_translate_lock`.""(�
link_workspace�The workspace name where links will be created for this package.

This is typically set in rule sets and libraries that are to be consumed as external repositories so
links are created in the external repository and not the user workspace.

Can be left unspecified if the link workspace is the user workspace.""(�
link_packages�Dict of paths where links may be created at for this package to
a list of link aliases to link as in each package. If aliases are an
empty list this indicates to link as the package name.

Defaults to {} which indicates that links may be created in any package as specified by
the `direct` attribute of the generated npm_link_package.{}(m
lifecycle_hooksTList of lifecycle hook `package.json` scripts to run for this package if they exist.[](�
&lifecycle_hooks_execution_requirements�Execution requirements when running the lifecycle hooks.

For example:

```
lifecycle_hooks_execution_requirements: ["no-sandbox', "requires-network"]
```

This defaults to ["no-sandbox"] to limit the overhead of sandbox creation and copying the output
TreeArtifact out of the sandbox.["no-sandbox"](�
lifecycle_hooks_env�Environment variables set for the lifecycle hooks action for this npm
package if there is one.

Environment variables are defined by providing an array of "key=value" entries.

For example:

```
lifecycle_hooks_env: ["PREBULT_BINARY=https://downloadurl"],
```[](�
%lifecycle_hooks_use_default_shell_env�If True, the `use_default_shell_env` attribute of lifecycle hook
actions is set to True.

See [use_default_shell_env](https://bazel.build/rules/lib/builtins/actions#run.use_default_shell_env)

Note: [--incompatible_merge_fixed_and_default_shell_env](https://bazel.build/reference/command-line-reference#flag--incompatible_merge_fixed_and_default_shell_env)
is often required and not enabled by default in Bazel < 7.0.0.

This defaults to False reduce the negative effects of `use_default_shell_env`. Requires bazel-lib >= 2.4.2.False(�
	integrity�Expected checksum of the file downloaded, in Subresource Integrity format.
This must match the checksum of the file downloaded.

This is the same as appears in the pnpm-lock.yaml, yarn.lock or package-lock.json file.

It is a security risk to omit the checksum as remote files can change.

At best omitting this field will make your build non-hermetic.

It is optional to make development easier but should be set before shipping.""(�
url�Optional url for this package. If unset, a default npm registry url is generated from
the package name and version.

May start with `git+ssh://` or `git+https://` to indicate a git repository. For example,

```
git+ssh://git@github.com/org/repo.git
```

If url is configured as a git repository, the commit attribute must be set to the
desired commit.""(M
commit=Specific commit to be checked out if url is a git repository.""(�
replace_package�Use the specified npm_package target when linking instead of the fetched sources for this npm package.

The injected npm_package target may optionally contribute transitive npm package dependencies on top
of the transitive dependencies specified in the pnpm lock file for the same package, however, these
transitive dependencies must not collide with pnpm lock specified transitive dependencies.

Any patches specified for this package will be not applied to the injected npm_package target. They
will be applied, however, to the fetches sources so they can still be useful for patching the fetched
`package.json` file, which is used to determine the generated bin entries for the package.

NB: lifecycle hooks and custom_postinstall scripts, if implicitly or explicitly enabled, will be run on
the injected npm_package. These may be disabled explicitly using the `lifecycle_hooks` attribute.None(b
package_visibility1Visibility of generated node_module link targets.["//visibility:public"](_

patch_toolIThe patch tool to use. If not specified, the `patch` from `PATH` is used.None(y

patch_args`Arguments to pass to the patch tool.

`-p1` will usually be needed for patches generated by git.["-p0"](F
patches5Patch files to apply onto the downloaded npm package.[](�
custom_postinstall�Custom string postinstall script to run on the installed npm package.

Runs after any existing lifecycle hooks if any are enabled.""(X
npm_authFAuth token to authenticate with npm. When using Bearer authentication.""(�
npm_auth_basic�Auth token to authenticate with npm. When using Basic authentication.

This is typically the base64 encoded string "username:password".""(c
npm_auth_usernameHAuth username to authenticate with npm. When using Basic authentication.""(c
npm_auth_passwordHAuth password to authenticate with npm. When using Basic authentication.""(�
bins�Dictionary of `node_modules/.bin` binary files to create mapped to their node entry points.

This is typically derived from the "bin" attribute in the package.json
file of the npm package being linked.

For example:

```
bins = {
    "foo": "./foo.js",
    "bar": "./bar.js",
}
```

In the future, this field may be automatically populated by npm_translate_lock
from information in the pnpm lock file. That feature is currently blocked on
https://github.com/pnpm/pnpm/issues/5131.{}(<
dev,Whether this npm package is a dev dependencyFalse(�
exclude_package_contents�List of glob patterns to exclude from the linked package.

This is useful for excluding files that are not needed in the linked package.

For example:

```
exclude_package_contents = ["**/tests/**"]
```[](
kwargsInternal use only(�#Import a single npm package into Bazel.

Normally you'd want to use `npm_translate_lock` to import all your packages at once.
It generates `npm_import` rules.
You can create these manually if you want to have exact control.

Bazel will only fetch the given package from an external registry if the package is
required for the user-requested targets to be build/tested.

This is a repository rule, which should be called from your `WORKSPACE` file
or some `.bzl` file loaded from it. For example, with this code in `WORKSPACE`:

```starlark
npm_import(
    name = "npm__at_types_node__15.12.2",
    package = "@types/node",
    version = "15.12.2",
    integrity = "sha512-zjQ69G564OCIWIOHSXyQEEDpdpGl+G348RAKY0XXy9Z5kU9Vzv1GMNnkar/ZJ8dzXB3COzD9Mo9NtRZ4xfgUww==",
)
```

In `MODULE.bazel` the same would look like so:

```starlark
npm.npm_import(
    name = "npm__at_types_node__15.12.2",
    package = "@types/node",
    version = "15.12.2",
    integrity = "sha512-zjQ69G564OCIWIOHSXyQEEDpdpGl+G348RAKY0XXy9Z5kU9Vzv1GMNnkar/ZJ8dzXB3COzD9Mo9NtRZ4xfgUww==",v
)
use_repo(npm, "npm__at_types_node__15.12.2")
use_repo(npm, "npm__at_types_node__15.12.2__links")
```

> This is similar to Bazel rules in other ecosystems named "_import" like
> `apple_bundle_import`, `scala_import`, `java_import`, and `py_import`.
> `go_repository` is also a model for this rule.

The name of this repository should contain the version number, so that multiple versions of the same
package don't collide.
(Note that the npm ecosystem always supports multiple versions of a library depending on where
it is required, unlike other languages like Go or Python.)

To consume the downloaded package in rules, it must be "linked" into the link package in the
package's `BUILD.bazel` file:

```
load("@npm__at_types_node__15.12.2__links//:defs.bzl", npm_link_types_node = "npm_link_imported_package")

npm_link_types_node(name = "node_modules")
```

This links `@types/node` into the `node_modules` of this package with the target name `:node_modules/@types/node`.

A `:node_modules/@types/node/dir` filegroup target is also created that provides the the directory artifact of the npm package.
This target can be used to create entry points for binary target or to access files within the npm package.

NB: You can choose any target name for the link target but we recommend using the `node_modules/@scope/name` and
`node_modules/name` convention for readability.

When using `npm_translate_lock`, you can link all the npm dependencies in the lock file for a package:

```
load("@npm//:defs.bzl", "npm_link_all_packages")

npm_link_all_packages(name = "node_modules")
```

This creates `:node_modules/name` and `:node_modules/@scope/name` targets for all direct npm dependencies in the package.
It also creates `:node_modules/name/dir` and `:node_modules/@scope/name/dir` filegroup targets that provide the the directory artifacts of their npm packages.
These target can be used to create entry points for binary target or to access files within the npm package.

If you have a mix of `npm_link_all_packages` and `npm_link_imported_package` functions to call you can pass the
`npm_link_imported_package` link functions to the `imported_links` attribute of `npm_link_all_packages` to link
them all in one call. For example,

```
load("@npm//:defs.bzl", "npm_link_all_packages")
load("@npm__at_types_node__15.12.2__links//:defs.bzl", npm_link_types_node = "npm_link_imported_package")

npm_link_all_packages(
    name = "node_modules",
    imported_links = [
        npm_link_types_node,
    ]
)
```

This has the added benefit of adding the `imported_links` to the convienence `:node_modules` target which
includes all direct dependencies in that package.

NB: You can pass an name to npm_link_all_packages and this will change the targets generated to "{name}/@scope/name" and
"{name}/name". We recommend using "node_modules" as the convention for readability.

To change the proxy URL we use to fetch, configure the Bazel downloader:

1. Make a file containing a rewrite rule like

    `rewrite (registry.npmjs.org)/(.*) artifactory.build.internal.net/artifactory/$1/$2`

1. To understand the rewrites, see [UrlRewriterConfig] in Bazel sources.

1. Point bazel to the config with a line in .bazelrc like
common --experimental_downloader_config=.bazel_downloader_config

Read more about the downloader config: <https://blog.aspect.build/configuring-bazels-downloader>

[UrlRewriterConfig]: https://github.com/bazelbuild/bazel/blob/4.2.1/src/main/java/com/google/devtools/build/lib/bazel/repository/downloader/UrlRewriterConfig.java#L66
2;

npm_import-@@aspect_rules_js//npm/private:npm_import.bzl
��2npm_import_rule��npm_translate_lock�	Repository macro to generate starlark code from a lock file.

In most repositories, it would be an impossible maintenance burden to manually declare all
of the [`npm_import`](./npm_import) rules. This helper generates an external repository
containing a helper starlark module `repositories.bzl`, which supplies a loadable macro
`npm_repositories`. That macro creates an `npm_import` for each package.

The generated repository also contains:

- A `defs.bzl` file containing some rules such as `npm_link_all_packages`, which are [documented here](./npm_link_all_packages.md).
- `BUILD` files declaring targets for the packages listed as `dependencies` or `devDependencies` in `package.json`,
  so you can declare dependencies on those packages without having to repeat version information.

This macro creates a `pnpm` external repository, if the user didn't create a repository named
"pnpm" prior to calling `npm_translate_lock`.
`rules_js` currently only uses this repository when `npm_package_lock` or `yarn_lock` are used.
Set `pnpm_version` to `None` to inhibit this repository creation.

For more about how to use npm_translate_lock, read [pnpm and rules_js](/docs/pnpm.md).
*�{
�z
npm_translate_lock$
nameThe repository rule name (/
	pnpm_lockThe `pnpm-lock.yaml` file.None(�
npm_package_lockqThe `package-lock.json` file written by `npm install`.

Only one of `npm_package_lock` or `yarn_lock` may be set.None(
	yarn_lockjThe `yarn.lock` file written by `yarn install`.

Only one of `npm_package_lock` or `yarn_lock` may be set.None(�
update_pnpm_lock�When True, the pnpm lock file will be updated automatically when any of its inputs
have changed since the last update.

Defaults to True when one of `npm_package_lock` or `yarn_lock` are set.
Otherwise it defaults to False.

Read more: [using update_pnpm_lock](/docs/pnpm.md#update_pnpm_lock)False(o
node_toolchain_prefixJthe prefix of the node toolchain to use when generating the pnpm lockfile."nodejs"(c
yq_toolchain_prefixDthe prefix of the yq toolchain to use for parsing the pnpm lockfile."yq"(�
	preupdate�Node.js scripts to run in this repository rule before auto-updating the pnpm lock file.

Scripts are run sequentially in the order they are listed. The working directory is set to the root of the
external repository. Make sure all files required by preupdate scripts are added to the `data` attribute.

A preupdate script could, for example, transform `resolutions` in the root `package.json` file from a format
that yarn understands such as `@foo/**/bar` to the equivalent `@foo/*>bar` that pnpm understands so that
`resolutions` are compatible with pnpm when running `pnpm import` to update the pnpm lock file.

Only needed when `update_pnpm_lock` is True.
Read more: [using update_pnpm_lock](/docs/pnpm.md#update_pnpm_lock)[](�
npmrc�The `.npmrc` file, if any, to use.

When set, the `.npmrc` file specified is parsed and npm auth tokens and basic authentication configuration
specified in the file are passed to the Bazel downloader for authentication with private npm registries.

In a future release, pnpm settings such as public-hoist-patterns will be used.None(�
use_home_npmrc�Use the `$HOME/.npmrc` file (or `$USERPROFILE/.npmrc` when on Windows) if it exists.

Settings from home `.npmrc` are merged with settings loaded from the `.npmrc` file specified
in the `npmrc` attribute, if any. Where there are conflicting settings, the home `.npmrc` values
will take precedence.

WARNING: The repository rule will not be invalidated by changes to the home `.npmrc` file since there
is no way to specify this file as an input to the repository rule. If changes are made to the home
`.npmrc` you can force the repository rule to re-run and pick up the changes by running:
`bazel run @{name}//:sync` where `name` is the name of the `npm_translate_lock` you want to re-run.

Because of the repository rule invalidation issue, using the home `.npmrc` is not recommended.
`.npmrc` settings should generally go in the `npmrc` in your repository so they are shared by all
developers. The home `.npmrc` should be reserved for authentication settings for private npm repositories.None(�
data�Data files required by this repository rule when auto-updating the pnpm lock file.

Only needed when `update_pnpm_lock` is True.
Read more: [using update_pnpm_lock](/docs/pnpm.md#update_pnpm_lock)[](�
patches�A map of package names or package names with their version (e.g., "my-package" or "my-package@v1.2.3")
to a label list of patches to apply to the downloaded npm package. Multiple matches are additive.

These patches are applied after any patches in [pnpm.patchedDependencies](https://pnpm.io/next/package_json#pnpmpatcheddependencies).

Read more: [patching](/docs/pnpm.md#patching){}(�
exclude_package_contents�Configuration for excluding package contents (WORKSPACE only).

For MODULE.bazel, use the `exclude_package_contents` tag class instead.

The configuration is a dictionary that maps package names (or package names with their version, e.g., "my-package" or "my-package@v1.2.3") to exclusion rules.

Values can be:
- `True`: Use default exclusions
- List of strings: Multiple exclusion patterns

Versions must match if used.

Example:

```
exclude_package_contents = {
    "*": True,  # Use defaults for all packages
    "@foo/bar": ["**/test/**"],
    "@foo/car@2.0.0": ["**/README*"],
}
```{}(_

patch_toolIThe patch tool to use. If not specified, the `patch` from `PATH` is used.None(�

patch_args�A map of package names or package names with their version (e.g., "my-package" or "my-package@v1.2.3")
to a label list arguments to pass to the patch tool. The most specific match wins.

Read more: [patching](/docs/pnpm.md#patching){"*": ["-p0"]}(�
custom_postinstalls�A map of package names or package names with their version (e.g., "my-package" or "my-package@v1.2.3")
to a custom postinstall script to apply to the downloaded npm package after its lifecycle scripts runs.
If the version is left out of the package name, the script will run on every version of the npm package. If
a custom postinstall scripts exists for a package as well as for a specific version, the script for the versioned package
will be appended with `&&` to the non-versioned package script.

For example,

```
custom_postinstalls = {
    "@foo/bar": "echo something > somewhere.txt",
    "fum@0.0.1": "echo something_else > somewhere_else.txt",
},
```

Custom postinstalls are additive and joined with ` && ` when there are multiple matches for a package.
More specific matches are appended to previous matches.{}(�
package_visibility�A map of package names or package names with their version (e.g., "my-package" or "my-package@v1.2.3")
to a visibility list to use for the package's generated node_modules link targets. Multiple matches are additive.
If there are no matches then the package's generated node_modules link targets default to public visibility
(`["//visibility:public"]`).{}(P
prod?If True, only install `dependencies` but not `devDependencies`.False(�
public_hoist_packages�A map of package names or package names with their version (e.g., "my-package" or "my-package@v1.2.3")
to a list of Bazel packages in which to hoist the package to the top-level of the node_modules tree when linking.

This is similar to setting https://pnpm.io/npmrc#public-hoist-pattern in an .npmrc file outside of Bazel, however,
wild-cards are not yet supported and npm_translate_lock will fail if there are multiple versions of a package that
are to be hoisted.

```
public_hoist_packages = {
    "@foo/bar": [""] # link to the root package in the WORKSPACE
    "fum@0.0.1": ["some/sub/package"]
},
```

List of public hoist packages are additive when there are multiple matches for a package. More specific matches
are appended to previous matches.{}(7
dev'If True, only install `devDependencies`False(�
no_optional�If True, `optionalDependencies` are not installed.

Currently `npm_translate_lock` behaves differently from pnpm in that is downloads all `optionaDependencies`
while pnpm doesn't download `optionalDependencies` that are not needed for the platform pnpm is run on.
See https://github.com/pnpm/pnpm/pull/3672 for more context.False(�
run_lifecycle_hooksrSets a default value for `lifecycle_hooks` if `*` not already set.
Set this to `False` to disable lifecycle hooks.True(�
lifecycle_hooks�A dict of package names to list of lifecycle hooks to run for that package.

By default the `preinstall`, `install` and `postinstall` hooks are run if they exist. This attribute allows
the default to be overridden for packages to run `prepare`.

List of hooks are not additive. The most specific match wins.

Read more: [lifecycles](/docs/pnpm.md#lifecycles){}(�
lifecycle_hooks_envs�Environment variables set for the lifecycle hooks actions on npm packages.
The environment variables can be defined per package by package name or globally using "*".
Variables are declared as key/value pairs of the form "key=value".
Multiple matches are additive.

Read more: [lifecycles](/docs/pnpm.md#lifecycles){}(�
lifecycle_hooks_exclude�A list of package names or package names with their version (e.g., "my-package" or "my-package@v1.2.3")
to not run any lifecycle hooks on.

Equivalent to adding `<value>: []` to `lifecycle_hooks`.

Read more: [lifecycles](/docs/pnpm.md#lifecycles)[](�
&lifecycle_hooks_execution_requirements�Execution requirements applied to the preinstall, install and postinstall
lifecycle hooks on npm packages.

The execution requirements can be defined per package by package name or globally using "*".

Execution requirements are not additive. The most specific match wins.

Read more: [lifecycles](/docs/pnpm.md#lifecycles){}(�
lifecycle_hooks_no_sandbox�If True, a "no-sandbox" execution requirement is added to all lifecycle hooks
unless overridden by `lifecycle_hooks_execution_requirements`.

Equivalent to adding `"*": ["no-sandbox"]` to `lifecycle_hooks_execution_requirements`.

This defaults to True to limit the overhead of sandbox creation and copying the output
TreeArtifacts out of the sandbox.

Read more: [lifecycles](/docs/pnpm.md#lifecycles)True(�
%lifecycle_hooks_use_default_shell_env�The `use_default_shell_env` attribute of the lifecycle hooks
actions on npm packages.

See [use_default_shell_env](https://bazel.build/rules/lib/builtins/actions#run.use_default_shell_env)

Note: [--incompatible_merge_fixed_and_default_shell_env](https://bazel.build/reference/command-line-reference#flag--incompatible_merge_fixed_and_default_shell_env)
is often required and not enabled by default in Bazel < 7.0.0.

This defaults to False reduce the negative effects of `use_default_shell_env`. Requires bazel-lib >= 2.4.2.

Read more: [lifecycles](/docs/pnpm.md#lifecycles){}(�
replace_packages�A dict of package names to npm_package targets to link instead of the sources specified in the pnpm lock file for the corresponding packages.

The injected npm_package targets may optionally contribute transitive npm package dependencies on top
of the transitive dependencies specified in the pnpm lock file for their respective packages, however, these
transitive dependencies must not collide with pnpm lock specified transitive dependencies.

Any patches specified for the packages will be not applied to the injected npm_package targets. They
will be applied, however, to the fetches sources for their respecitve packages so they can still be useful
for patching the fetched `package.json` files, which are used to determine the generated bin entries for packages.

NB: lifecycle hooks and custom_postinstall scripts, if implicitly or explicitly enabled, will be run on
the injected npm_package targets. These may be disabled explicitly using the `lifecycle_hooks` attribute.{}(�
bins�Binary files to create in `node_modules/.bin` for packages in this lock file.

For a given package, this is typically derived from the "bin" attribute in
the package.json file of that package.

For example:

```
bins = {
    "@foo/bar": {
        "foo": "./foo.js",
        "bar": "./bar.js"
    },
}
```

Dicts of bins not additive. The most specific match wins.

In the future, this field may be automatically populated from information in the pnpm lock
file. That feature is currently blocked on https://github.com/pnpm/pnpm/issues/5131.

Note: Bzlmod users must use an alternative syntax due to module extensions not supporting
dict-of-dict attributes:

```
bins = {
    "@foo/bar": [
        "foo=./foo.js",
        "bar=./bar.js"
    ],
}
```{}(�
verify_node_modules_ignored�node_modules folders in the source tree should be ignored by Bazel.

This points to a `.bazelignore` file to verify that all nested node_modules directories
pnpm will create are listed.

See https://github.com/bazelbuild/bazel/issues/8106None(�	
verify_patches�	Label to a patch list file.

Use this in together with the `list_patches` macro to guarantee that all patches in a patch folder
are included in the `patches` attribute.

For example:

```
verify_patches = "//patches:patches.list",
```

In your patches folder add a BUILD.bazel file containing.
```
load("@aspect_rules_js//npm:repositories.bzl", "list_patches")

list_patches(
    name = "patches",
    out = "patches.list",
)
```

Once you have created this file, you need to create an empty `patches.list` file before generating the first list. You can do this by running
```
touch patches/patches.list
```

Finally, write the patches file at least once to make sure all patches are listed. This can be done by running `bazel run //patches:patches_update`.

See the `list_patches` documentation for further info.
NOTE: if you would like to customize the patches directory location, you can set a flag in the `.npmrc`. Here is an example of what this might look like
```
# Set the directory for pnpm when patching
# https://github.com/pnpm/pnpm/issues/6508#issuecomment-1537242124
patches-dir=bazel/js/patches
```
If you do this, you will have to update the `verify_patches` path to be this path instead of `//patches` like above.None(w
quietfSet to False to print info logs and output stdout & stderr of pnpm lock update actions to the console.True(�
 external_repository_action_cache`The location of the external repository action cache to write to when `update_pnpm_lock` = True.0".aspect/rules/external_repository_action_cache"(�
link_workspace�The workspace name where links will be created for the packages in this lock file.

This is typically set in rule sets and libraries that vendor the starlark generated by npm_translate_lock
so the link_workspace passed to npm_import is set correctly so that links are created in the external
repository and not the user workspace.

Can be left unspecified if the link workspace is the user workspace.None(�
pnpm_version�pnpm version to use when generating the @pnpm repository. Set to None to not create this repository.

Can be left unspecified and the rules_js default `DEFAULT_PNPM_VERSION` will be used."8.15.9"(9
use_pnpm%label of the pnpm entry point to use.None(�
npm_package_target_name�The name of linked `npm_package`, `js_library` or `JsInfo` producing targets.

When targets are linked as pnpm workspace packages, the name of the target must align with this value.

The `{dirname}` placeholder is replaced with the directory name of the target."pkg"(
kwargsInternal use only(�	Repository macro to generate starlark code from a lock file.

In most repositories, it would be an impossible maintenance burden to manually declare all
of the [`npm_import`](./npm_import) rules. This helper generates an external repository
containing a helper starlark module `repositories.bzl`, which supplies a loadable macro
`npm_repositories`. That macro creates an `npm_import` for each package.

The generated repository also contains:

- A `defs.bzl` file containing some rules such as `npm_link_all_packages`, which are [documented here](./npm_link_all_packages.md).
- `BUILD` files declaring targets for the packages listed as `dependencies` or `devDependencies` in `package.json`,
  so you can declare dependencies on those packages without having to repeat version information.

This macro creates a `pnpm` external repository, if the user didn't create a repository named
"pnpm" prior to calling `npm_translate_lock`.
`rules_js` currently only uses this repository when `npm_package_lock` or `yarn_lock` are used.
Set `pnpm_version` to `None` to inhibit this repository creation.

For more about how to use npm_translate_lock, read [pnpm and rules_js](/docs/pnpm.md).
2K
npm_translate_lock5@@aspect_rules_js//npm/private:npm_translate_lock.bzl
��2npm_translate_lock_rule�pnpm_repository�Import https://npmjs.com/package/pnpm and provide a js_binary to run the tool.

Useful as a way to run exactly the same pnpm as Bazel does, for example with:
bazel run -- @pnpm//:pnpm --dir $PWD
*�
�
pnpm_repository5
name)name of the resulting external repository (�
pnpm_version�version of pnpm, see https://www.npmjs.com/package/pnpm?activeTab=versions

May also be a tuple of (version, integrity) where the integrity value may be fetched like:
`curl --silent https://registry.npmjs.org/pnpm | jq '.versions["8.6.11"].dist.integrity'`"8.15.9"(�Import https://npmjs.com/package/pnpm and provide a js_binary to run the tool.

Useful as a way to run exactly the same pnpm as Bazel does, for example with:
bazel run -- @pnpm//:pnpm --dir $PWD
2E
pnpm_repository2@@aspect_rules_js//npm/private:pnpm_repository.bzl
2native.existing_rule2_npm_import�
//npm/private:npm_import.bzlrg
.
aspect_rules_jsnpm/privatenpm_import.bzl'

npm_import_npm_import
6A
Q�
$//npm/private:npm_translate_lock.bzlr�
6
aspect_rules_jsnpm/privatenpm_translate_lock.bzl+
list_patches_list_patches
>K7
npm_translate_lock_npm_translate_lock
^q
��
!//npm/private:pnpm_repository.bzlr�
3
aspect_rules_jsnpm/privatepnpm_repository.bzl;
DEFAULT_PNPM_VERSION_DEFAULT_PNPM_VERSION
;P9
LATEST_PNPM_VERSION_LATEST_PNPM_VERSION
k3
pnpm_repository_pnpm_repository
��
�*	DEFAULT_PNPM_VERSION8.15.9j8.15.9+	LATEST_PNPM_VERSION10.17.1j	10.17.12Repository rules to fetch third-party npm packages 