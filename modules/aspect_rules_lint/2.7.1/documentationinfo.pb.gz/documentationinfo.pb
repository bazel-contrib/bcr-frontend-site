�x
formatdefs.bzl�D	languages�Language attributes that may be passed to [format_multirun](#format_multirun) or [format_test](#format_test).

Files with matching extensions from [GitHub Linguist] will be formatted for the given language.

Some languages have dialects:
    - `javascript` includes TypeScript, TSX, and JSON.
    - `css` includes Less and Sass.

**Do not call the `languages` rule directly, it exists only to document the attributes.**

[GitHub Linguist]: https://github.com/github-linguist/linguist/blob/559a6426942abcae16b6d6b328147476432bf6cb/lib/linguist/languages.yml"�@
�"
	languages�Language attributes that may be passed to [format_multirun](#format_multirun) or [format_test](#format_test).

Files with matching extensions from [GitHub Linguist] will be formatted for the given language.

Some languages have dialects:
    - `javascript` includes TypeScript, TSX, and JSON.
    - `css` includes Less and Sass.

**Do not call the `languages` rule directly, it exists only to document the attributes.**

[GitHub Linguist]: https://github.com/github-linguist/linguist/blob/559a6426942abcae16b6d6b328147476432bf6cb/lib/linguist/languages.yml*
nameA unique name for this target. h

javascriptRa `prettier` binary, or any other tool that has a matching command-line interface.2Nonef
markdownRa `prettier` binary, or any other tool that has a matching command-line interface.2Nonea
cssRa `prettier` binary, or any other tool that has a matching command-line interface.2None�
cue�a `cue-fmt` binary, or any other tool that has a matching command-line interface. Use `@aspect_rules_lint//format:cue` to choose the built-in tool.2Nonee
graphqlRa `prettier` binary, or any other tool that has a matching command-line interface.2Noneb
htmlRa `prettier` binary, or any other tool that has a matching command-line interface.2None�
python�a `ruff` binary, or any other tool that has a matching command-line interface. Use `@aspect_rules_lint//format:ruff` to choose the built-in tool.2Noneb
qmlSa `qmlformat` binary, or any other tool that has a matching command-line interface.2Noneh
starlarkTa `buildifier` binary, or any other tool that has a matching command-line interface.2None�
jsonnet�a `jsonnetfmt` binary, or any other tool that has a matching command-line interface. Use `@aspect_rules_lint//format:jsonnetfmt` to choose the built-in tool.2None�
	terraform�a `terraform-fmt` binary, or any other tool that has a matching command-line interface. Use `@aspect_rules_lint//format:terraform` to choose the built-in tool.2None_
tomlOa `taplo` binary, or any other tool that has a matching command-line interface.2Nonea
kotlinOa `ktfmt` binary, or any other tool that has a matching command-line interface.2Nonee
javaUa `java-format` binary, or any other tool that has a matching command-line interface.2Nonef

html_jinjaPa `djlint` binary, or any other tool that has a matching command-line interface.2Nonec
scalaRa `scalafmt` binary, or any other tool that has a matching command-line interface.2Nonef
swiftUa `swiftformat` binary, or any other tool that has a matching command-line interface.2None�
go�a `gofmt` binary, or any other tool that has a matching command-line interface. Use `@aspect_rules_lint//format:gofumpt` to choose the built-in tool.2Nonea
sqlRa `prettier` binary, or any other tool that has a matching command-line interface.2None�
shell�a `shfmt` binary, or any other tool that has a matching command-line interface. Use `@aspect_rules_lint//format:shfmt` to choose the built-in tool.2Noneh
protocol_bufferMa `buf` binary, or any other tool that has a matching command-line interface.2Nonec
cVa `clang-format` binary, or any other tool that has a matching command-line interface.2Noned
ccVa `clang-format` binary, or any other tool that has a matching command-line interface.2Nonef
cudaVa `clang-format` binary, or any other tool that has a matching command-line interface.2None�
yaml�a `yamlfmt` binary, or any other tool that has a matching command-line interface. Use `@aspect_rules_lint//format:yamlfmt` to choose the built-in tool.2Nonea
rustQa `rustfmt` binary, or any other tool that has a matching command-line interface.2Nonea
xmlRa `prettier` binary, or any other tool that has a matching command-line interface.2Nonee
gherkinRa `prettier` binary, or any other tool that has a matching command-line interface.2Noned
fsharpRa `fantomas` binary, or any other tool that has a matching command-line interface.2Nonee
csharpSa `csharpier` binary, or any other tool that has a matching command-line interface.2None\
pklMa `pkl` binary, or any other tool that has a matching command-line interface.2Nonee
	go_modulePa `modfmt` binary, or any other tool that has a matching command-line interface.2None"
	languages//format:defs.bzl,
*
nameA unique name for this target. j
h

javascriptRa `prettier` binary, or any other tool that has a matching command-line interface.2Noneh
f
markdownRa `prettier` binary, or any other tool that has a matching command-line interface.2Nonec
a
cssRa `prettier` binary, or any other tool that has a matching command-line interface.2None�
�
cue�a `cue-fmt` binary, or any other tool that has a matching command-line interface. Use `@aspect_rules_lint//format:cue` to choose the built-in tool.2Noneg
e
graphqlRa `prettier` binary, or any other tool that has a matching command-line interface.2Noned
b
htmlRa `prettier` binary, or any other tool that has a matching command-line interface.2None�
�
python�a `ruff` binary, or any other tool that has a matching command-line interface. Use `@aspect_rules_lint//format:ruff` to choose the built-in tool.2Noned
b
qmlSa `qmlformat` binary, or any other tool that has a matching command-line interface.2Nonej
h
starlarkTa `buildifier` binary, or any other tool that has a matching command-line interface.2None�
�
jsonnet�a `jsonnetfmt` binary, or any other tool that has a matching command-line interface. Use `@aspect_rules_lint//format:jsonnetfmt` to choose the built-in tool.2None�
�
	terraform�a `terraform-fmt` binary, or any other tool that has a matching command-line interface. Use `@aspect_rules_lint//format:terraform` to choose the built-in tool.2Nonea
_
tomlOa `taplo` binary, or any other tool that has a matching command-line interface.2Nonec
a
kotlinOa `ktfmt` binary, or any other tool that has a matching command-line interface.2Noneg
e
javaUa `java-format` binary, or any other tool that has a matching command-line interface.2Noneh
f

html_jinjaPa `djlint` binary, or any other tool that has a matching command-line interface.2Nonee
c
scalaRa `scalafmt` binary, or any other tool that has a matching command-line interface.2Noneh
f
swiftUa `swiftformat` binary, or any other tool that has a matching command-line interface.2None�
�
go�a `gofmt` binary, or any other tool that has a matching command-line interface. Use `@aspect_rules_lint//format:gofumpt` to choose the built-in tool.2Nonec
a
sqlRa `prettier` binary, or any other tool that has a matching command-line interface.2None�
�
shell�a `shfmt` binary, or any other tool that has a matching command-line interface. Use `@aspect_rules_lint//format:shfmt` to choose the built-in tool.2Nonej
h
protocol_bufferMa `buf` binary, or any other tool that has a matching command-line interface.2Nonee
c
cVa `clang-format` binary, or any other tool that has a matching command-line interface.2Nonef
d
ccVa `clang-format` binary, or any other tool that has a matching command-line interface.2Noneh
f
cudaVa `clang-format` binary, or any other tool that has a matching command-line interface.2None�
�
yaml�a `yamlfmt` binary, or any other tool that has a matching command-line interface. Use `@aspect_rules_lint//format:yamlfmt` to choose the built-in tool.2Nonec
a
rustQa `rustfmt` binary, or any other tool that has a matching command-line interface.2Nonec
a
xmlRa `prettier` binary, or any other tool that has a matching command-line interface.2Noneg
e
gherkinRa `prettier` binary, or any other tool that has a matching command-line interface.2Nonef
d
fsharpRa `fantomas` binary, or any other tool that has a matching command-line interface.2Noneg
e
csharpSa `csharpier` binary, or any other tool that has a matching command-line interface.2None^
\
pklMa `pkl` binary, or any other tool that has a matching command-line interface.2Noneg
e
	go_modulePa `modfmt` binary, or any other tool that has a matching command-line interface.2None�format_multirun�Create a [multirun] binary for the given languages.

Intended to be used with `bazel run` to update source files in-place.

This macro produces a target named `[name].check` which does not edit files,
rather it exits non-zero if any sources require formatting.

To check formatting with `bazel test`, use [format_test](#format_test) instead.

[multirun]: https://registry.bazel.build/modules/rules_multirun
*�
�	
format_multirun:
name0name of the resulting target, typically "format" j
jobs_how many language formatters to spawn in parallel, ideally matching how many CPUs are available4�
print_command�whether to print a progress message before calling the formatter of each language.
Note that a line is printed for a formatter even if no files of that language are to be formatted.False]
disable_git_attribute_checks6Set to True to disable honoring .gitattributes filtersFalse�
kwargs�attributes named for each language; see [languages](#languages).
Additionally supports custom arguments via {language}_fix_args and {language}_check_args
to override default formatter flags for fix and check modes respectively.�Create a [multirun] binary for the given languages.

Intended to be used with `bazel run` to update source files in-place.

This macro produces a target named `[name].check` which does not edit files,
rather it exits non-zero if any sources require formatting.

To check formatting with `bazel test`, use [format_test](#format_test) instead.

[multirun]: https://registry.bazel.build/modules/rules_multirun
2$
format_multirun//format:defs.bzl<
:
name0name of the resulting target, typically "format" l
j
jobs_how many language formatters to spawn in parallel, ideally matching how many CPUs are available4�
�
print_command�whether to print a progress message before calling the formatter of each language.
Note that a line is printed for a formatter even if no files of that language are to be formatted.False_
]
disable_git_attribute_checks6Set to True to disable honoring .gitattributes filtersFalse�
�
kwargs�attributes named for each language; see [languages](#languages).
Additionally supports custom arguments via {language}_fix_args and {language}_check_args
to override default formatter flags for fix and check modes respectively.�format_test�Create test for the given formatters.

Intended to be used with `bazel test` to verify files are formatted.
**This is not recommended**, because it is either non-hermetic or requires listing all source files.

To format with `bazel run`, see [format_multirun](#format_multirun).
*�
�
format_test:
name0name of the resulting target, typically "format" T
srcsFlist of files to verify formatting. Required when no_sandbox is False.None�
	workspace�a file in the root directory to verify formatting. Required when no_sandbox is True.
Typically `//:WORKSPACE` or `//:MODULE.bazel` may be used.None�

no_sandbox�Set to True to enable formatting all files in the workspace.
This mode causes the test to be non-hermetic and it cannot be cached. Read the documentation in /docs/formatting.md.False]
disable_git_attribute_checks6Set to True to disable honoring .gitattributes filtersFalse�
tagsytags to apply to generated targets. In 'no_sandbox' mode, `["no-sandbox", "no-cache", "external"]` are added to the tags.[]�

fix_target�label of the companion [format_multirun](#format_multirun) target. May be a target
name in the same package (e.g. `"format"`) or a full label (e.g. `"//tools/format:format"`).
When set, the test's failure message points users at the per-language fix command of that
target (e.g. `format_Go_with_gofmt`) instead of the test target itself.None�
kwargs�attributes named for each language; see [languages](#languages).
Additionally supports custom arguments via {language}_fix_args and {language}_check_args
to override default formatter flags. Test mode uses check_args when specified.�Create test for the given formatters.

Intended to be used with `bazel test` to verify files are formatted.
**This is not recommended**, because it is either non-hermetic or requires listing all source files.

To format with `bazel run`, see [format_multirun](#format_multirun).
2 
format_test//format:defs.bzl<
:
name0name of the resulting target, typically "format" V
T
srcsFlist of files to verify formatting. Required when no_sandbox is False.None�
�
	workspace�a file in the root directory to verify formatting. Required when no_sandbox is True.
Typically `//:WORKSPACE` or `//:MODULE.bazel` may be used.None�
�

no_sandbox�Set to True to enable formatting all files in the workspace.
This mode causes the test to be non-hermetic and it cannot be cached. Read the documentation in /docs/formatting.md.False_
]
disable_git_attribute_checks6Set to True to disable honoring .gitattributes filtersFalse�
�
tagsytags to apply to generated targets. In 'no_sandbox' mode, `["no-sandbox", "no-cache", "external"]` are added to the tags.[]�
�

fix_target�label of the companion [format_multirun](#format_multirun) target. May be a target
name in the same package (e.g. `"format"`) or a full label (e.g. `"//tools/format:format"`).
When set, the test's failure message points users at the per-language fix command of that
target (e.g. `format_Go_with_gofmt`) instead of the test target itself.None�
�
kwargs�attributes named for each language; see [languages](#languages).
Additionally supports custom arguments via {language}_fix_args and {language}_check_args
to override default formatter flags. Test mode uses check_args when specified.�Produce a multi-formatter that aggregates formatter tools.

Some formatter tools are built-in to rules_lint and may be installed by [multitool].
These are noted in the attributes for each language in 'languages' below.

Note: Under `--enable_bzlmod`, rules_lint installs multitool automatically.
`WORKSPACE` users must install it manually; see the snippet on the releases page.

Other formatter binaries may be declared in your repository, typically in `tools/format/BUILD.bazel`.
You can test that they work by running them directly, with `bazel run -- //tools/format:some-tool`.
Then use the label `//tools/format:some-tool` as the value of whatever language attribute in `format_multirun`.
See the example/tools/format/BUILD file in this repo for full examples of declaring formatters.

[multitool]: https://registry.bazel.build/modules/rules_multitool�
lint
bandit.bzl�bandit_action$Run bandit as an action under Bazel.*�
�
bandit_action0
ctx'Bazel Rule or Aspect evaluation context +

executablelabel of the bandit program 
srcsfiles to be linted J
config>label of the directory with bandit rules (defaults to `auto`). 3
stdout'output file containing stdout of bandit v
	exit_codecoutput file containing exit code of bandit
If None, then fail the build when bandit exits non-zero.None4
env)environment variables passed to the tool.{}.
optionsadditional command-line options[]$Run bandit as an action under Bazel.2"
bandit_action//lint:bandit.bzl2
0
ctx'Bazel Rule or Aspect evaluation context -
+

executablelabel of the bandit program 

srcsfiles to be linted L
J
config>label of the directory with bandit rules (defaults to `auto`). 5
3
stdout'output file containing stdout of bandit x
v
	exit_codecoutput file containing exit code of bandit
If None, then fail the build when bandit exits non-zero.None6
4
env)environment variables passed to the tool.{}0
.
optionsadditional command-line options[]�lint_bandit_aspect-A factory function to create a linter aspect.*�

�
lint_bandit_aspect�
binary�a bandit executable. Obtain from pypi like so:

load("@rules_python//python/entry_points:py_console_script_binary.bzl", "py_console_script_binary")

py_console_script_binary(
    name = "bandit",
    script = "bandit",
    pkg = "@pip//bandit:pkg",
) J
config>label of the directory with bandit rules (defaults to `auto`). U
argsIextra options passed to bandit (["--severity-level=medium"] for example).[]4
env)environment variables passed to the tool.{}�

rule_kinds_which [kinds](https://bazel.build/query/language#kind) of rules should be visited by the aspect&["py_binary", "py_library", "py_test"]-A factory function to create a linter aspect.2'
lint_bandit_aspect//lint:bandit.bzl�
�
binary�a bandit executable. Obtain from pypi like so:

load("@rules_python//python/entry_points:py_console_script_binary.bzl", "py_console_script_binary")

py_console_script_binary(
    name = "bandit",
    script = "bandit",
    pkg = "@pip//bandit:pkg",
) L
J
config>label of the directory with bandit rules (defaults to `auto`). W
U
argsIextra options passed to bandit (["--severity-level=medium"] for example).[]6
4
env)environment variables passed to the tool.{}�
�

rule_kinds_which [kinds](https://bazel.build/query/language#kind) of rules should be visited by the aspect&["py_binary", "py_library", "py_test"]�API for declaring a bandit lint aspect that visits supported rules.

Typical usage:

First, fetch `bandit[sarif]` package via your standard requirements file and python rules (pip, uv, etc).

Note that the `sarif` extra is **required** for machine output and the `toml` extra
is recommended to enable `pyproject.toml` support, see examples.

Then, declare a binary target for it, typically in `tools/lint/BUILD.bazel`:

```starlark
load("@rules_python//python/entry_points:py_console_script_binary.bzl", "py_console_script_binary")

py_console_script_binary(
    name = "bandit",
    script = "bandit",
    pkg = "@pip//bandit:pkg",
)
```

Finally, create the linter aspect, typically in `tools/lint/linters.bzl`:

```starlark
load("@aspect_rules_lint//lint:bandit.bzl", "lint_bandit_aspect")

bandit = lint_bandit_aspect(
    binary = Label("//tools/lint:bandit"),  # requires [sarif] extra
    config = Label("//:pyproject.toml"),  # requires [toml] extra
)
```�
lintbuf.bzl�buf_lint_action)Runs the buf lint tool as a Bazel action.*�
�
buf_lint_action
ctxRule OR Aspect context  
bufthe buf-lint executable !
protocthe protoc executable .
target"the proto_library target to run on 7
stderr+output file containing the stderr of protoc o
	exit_code\output file to write the exit code.
If None, then fail the build when protoc exits non-zero.None)Runs the buf lint tool as a Bazel action.2!
buf_lint_action//lint:buf.bzl!

ctxRule OR Aspect context "
 
bufthe buf-lint executable #
!
protocthe protoc executable 0
.
target"the proto_library target to run on 9
7
stderr+output file containing the stderr of protoc q
o
	exit_code\output file to write the exit code.
If None, then fail the build when protoc exits non-zero.None�lint_buf_aspect-A factory function to create a linter aspect.*�
�
lint_buf_aspect&
configlabel of the buf.yaml file �
	toolchain>override the default toolchain of the protoc-gen-buf-lint tool6"@rules_buf//tools/protoc-gen-buf-lint:toolchain_type"�

rule_kinds_which [kinds](https://bazel.build/query/language#kind) of rules should be visited by the aspect["proto_library"]-A factory function to create a linter aspect.2!
lint_buf_aspect//lint:buf.bzl(
&
configlabel of the buf.yaml file �
�
	toolchain>override the default toolchain of the protoc-gen-buf-lint tool6"@rules_buf//tools/protoc-gen-buf-lint:toolchain_type"�
�

rule_kinds_which [kinds](https://bazel.build/query/language#kind) of rules should be visited by the aspect["proto_library"]�API for calling declaring a buf lint aspect.

Typical usage:

```
load("@aspect_rules_lint//lint:buf.bzl", "lint_buf_aspect")

buf = lint_buf_aspect(
    config = Label("//path/to:buf.yaml"),
)
```

**Important:** while using buf's [`allow_comment_ignores` functionality](https://buf.build/docs/configuration/v1/buf-yaml#allow_comment_ignores), the bazel flag `--experimental_proto_descriptor_sets_include_source_info` is required.�
lintbuildifier.bzl�buildifier_action(Run Buildifier as an action under Bazel.*�
�
buildifier_action0
ctx'Bazel Rule or Aspect evaluation context /

executablelabel of the Buildifier program  
srcsStarlark files to lint D
stdout4output file containing stdout/stderr from BuildifierNone@
	exit_code-optional output file containing the exit codeNone9
patch*optional output file for a generated patchNone(Run Buildifier as an action under Bazel.2*
buildifier_action//lint:buildifier.bzl2
0
ctx'Bazel Rule or Aspect evaluation context 1
/

executablelabel of the Buildifier program "
 
srcsStarlark files to lint F
D
stdout4output file containing stdout/stderr from BuildifierNoneB
@
	exit_code-optional output file containing the exit codeNone;
9
patch*optional output file for a generated patchNone�lint_buildifier_aspect8A factory function to create a Buildifier linter aspect.*�
�
lint_buildifier_aspectT
binaryHa Buildifier executable, for example `@buildifier_prebuilt//:buildifier` ;
warnings(value for Buildifier's `--warnings` flag"all"e

rule_kinds2which target kinds should be visited automatically#["bzl_library", "bzl_library_rule"]n
filegroup_tags6which target tags opt a target into Buildifier linting$["starlark", "lint-with-buildifier"]8A factory function to create a Buildifier linter aspect.2/
lint_buildifier_aspect//lint:buildifier.bzlV
T
binaryHa Buildifier executable, for example `@buildifier_prebuilt//:buildifier` =
;
warnings(value for Buildifier's `--warnings` flag"all"g
e

rule_kinds2which target kinds should be visited automatically#["bzl_library", "bzl_library_rule"]p
n
filegroup_tags6which target tags opt a target into Buildifier linting$["starlark", "lint-with-buildifier"]�API for declaring a Buildifier lint aspect for Starlark sources.

Typical usage:

First, add `buildifier_prebuilt` in `MODULE.bazel`:

```starlark
bazel_dep(name = "buildifier_prebuilt", version = "8.5.1")
```

Then create the linter aspect, typically in `tools/lint/linters.bzl`:

```starlark
load("@aspect_rules_lint//lint:buildifier.bzl", "lint_buildifier_aspect")

buildifier = lint_buildifier_aspect(
    binary = Label("@buildifier_prebuilt//:buildifier"),
)
```

The aspect visits `bzl_library` targets by default. To lint files such as
`BUILD.bazel`, `MODULE.bazel`, or custom Starlark files, add `tags = ["starlark"]`
or `tags = ["lint-with-buildifier"]` to a target that lists those files in `srcs`.

```starlark
filegroup(
    name = "starlark_files",
    srcs = ["BUILD.bazel", "MODULE.bazel", "defs.star"],
    tags = ["starlark"],
)
```�
lintcheckstyle.bzl�
checkstyle_actionbRun Checkstyle as an action under Bazel.

Based on https://checkstyle.sourceforge.io/cmdline.html
*�	
�
checkstyle_action0
ctx'Bazel Rule or Aspect evaluation context /

executablelabel of the Checkstyle program !
srcsjava files to be linted ,
config label of the checkstyle.xml file A
data7labels of additional xml files such as suppressions.xml #
stdoutoutput file to generate s
	exit_code`output file to write the exit code.
If None, then fail the build when Checkstyle exits non-zero.Noneb
optionsSadditional command-line options, see https://checkstyle.sourceforge.io/cmdline.html[]bRun Checkstyle as an action under Bazel.

Based on https://checkstyle.sourceforge.io/cmdline.html
2*
checkstyle_action//lint:checkstyle.bzl2
0
ctx'Bazel Rule or Aspect evaluation context 1
/

executablelabel of the Checkstyle program #
!
srcsjava files to be linted .
,
config label of the checkstyle.xml file C
A
data7labels of additional xml files such as suppressions.xml %
#
stdoutoutput file to generate u
s
	exit_code`output file to write the exit code.
If None, then fail the build when Checkstyle exits non-zero.Noned
b
optionsSadditional command-line options, see https://checkstyle.sourceforge.io/cmdline.html[]�	lint_checkstyle_aspect�A factory function to create a linter aspect.

Attrs:
    binary: a Checkstyle executable. Obtain from rules_java like so:

        java_binary(
            name = "checkstyle",
            main_class = "com.puppycrawl.tools.checkstyle.Main",
            # Point to wherever you have the java_import rule defined, see our example
            runtime_deps = ["@com_puppycrawl_tools_checkstyle"],
        )

    config: the Checkstyle XML file*�
�
lint_checkstyle_aspect

binary 

config 

data[]-

rule_kinds["java_binary", "java_library"]�A factory function to create a linter aspect.

Attrs:
    binary: a Checkstyle executable. Obtain from rules_java like so:

        java_binary(
            name = "checkstyle",
            main_class = "com.puppycrawl.tools.checkstyle.Main",
            # Point to wherever you have the java_import rule defined, see our example
            runtime_deps = ["@com_puppycrawl_tools_checkstyle"],
        )

    config: the Checkstyle XML file2/
lint_checkstyle_aspect//lint:checkstyle.bzl


binary 


config 


data[]/
-

rule_kinds["java_binary", "java_library"]�API for declaring a checkstyle lint aspect that visits java_library rules.

Typical usage:

First, call the tools.checkstyle module extension to download the jar file.
Alternatively you could use whatever you prefer for managing Java dependencies, such as a Maven integration rule.

Next, declare a binary target for it, typically in `tools/lint/BUILD.bazel`:

```starlark
java_binary(
    name = "checkstyle",
    main_class = "com.puppycrawl.tools.checkstyle.Main",
    runtime_deps = ["@com_puppycrawl_tools_checkstyle//jar"],
)
```

Finally, declare an aspect for it, typically in `tools/lint/linters.bzl`:

```starlark
load("@aspect_rules_lint//lint:checkstyle.bzl", "lint_checkstyle_aspect")

checkstyle = lint_checkstyle_aspect(
    binary = Label("//tools/lint:checkstyle"),
    config = Label("//:checkstyle.xml"),
)
```�!
lint
eslint.bzl�eslint_action�Create a Bazel Action that spawns an eslint process.

Adapter for wrapping Bazel around
https://eslint.org/docs/latest/use/command-line-interface
*�
�
eslint_action,
ctx#an action context OR aspect context +

executablestruct with an eslint field &
srcslist of file objects to lint H
stdout<output file containing the stdout or --output-file of eslint {
	exit_codehoutput file containing the exit code of eslint.
If None, then fail the build when eslint exits non-zero.None9
format$value for eslint `--format` CLI flag	"stylish"+
env environment variables for eslint{}h
patchYoutput file for patch (optional). If provided, uses run_patcher instead of run/run_shell.None_
targetOthe aspect target, used to reuse bin-tree inputs already produced by the targetNone�Create a Bazel Action that spawns an eslint process.

Adapter for wrapping Bazel around
https://eslint.org/docs/latest/use/command-line-interface
2"
eslint_action//lint:eslint.bzl.
,
ctx#an action context OR aspect context -
+

executablestruct with an eslint field (
&
srcslist of file objects to lint J
H
stdout<output file containing the stdout or --output-file of eslint }
{
	exit_codehoutput file containing the exit code of eslint.
If None, then fail the build when eslint exits non-zero.None;
9
format$value for eslint `--format` CLI flag	"stylish"-
+
env environment variables for eslint{}j
h
patchYoutput file for patch (optional). If provided, uses run_patcher instead of run/run_shell.Nonea
_
targetOthe aspect target, used to reuse bin-tree inputs already produced by the targetNone�lint_eslint_aspect-A factory function to create a linter aspect.*�
�
lint_eslint_aspect�
binary�the eslint binary, typically a rule like

```
load("@npm//:eslint/package_json.bzl", eslint_bin = "bin")
eslint_bin.eslint_binary(name = "eslint")
``` 2
configs%label(s) of the eslint config file(s) �

rule_kinds_which [kinds](https://bazel.build/query/language#kind) of rules should be visited by the aspect/["js_library", "ts_project", "ts_project_rule"]-A factory function to create a linter aspect.2'
lint_eslint_aspect//lint:eslint.bzl�
�
binary�the eslint binary, typically a rule like

```
load("@npm//:eslint/package_json.bzl", eslint_bin = "bin")
eslint_bin.eslint_binary(name = "eslint")
``` 4
2
configs%label(s) of the eslint config file(s) �
�

rule_kinds_which [kinds](https://bazel.build/query/language#kind) of rules should be visited by the aspect/["js_library", "ts_project", "ts_project_rule"]�API for calling declaring an ESLint lint aspect.

Typical usage:

First, install eslint using your typical npm package.json and rules_js rules.

Next, declare a binary target for it, typically in `tools/lint/BUILD.bazel`:

```starlark
load("@npm//:eslint/package_json.bzl", eslint_bin = "bin")
eslint_bin.eslint_binary(name = "eslint")
```

Finally, create the linter aspect, typically in `tools/lint/linters.bzl`:

```starlark
load("@aspect_rules_lint//lint:eslint.bzl", "lint_eslint_aspect")

eslint = lint_eslint_aspect(
    binary = Label("//tools/lint:eslint"),
    # We trust that eslint will locate the correct configuration file for a given source file.
    # See https://eslint.org/docs/latest/use/configure/configuration-files#cascading-and-hierarchy
    configs = [
        Label("//:eslintrc"),
        ...
    ],
)
```

### With ts_project prior to version 3.2.0

Prior to [commit 5e25e91](https://github.com/aspect-build/rules_ts/commit/5e25e91420947e3a81938d8eb076803e5cf51fe2)
the rule produced by the `ts_project` macro and a custom `transpiler` expanded the macro to
multiple targets, including changing the default target to `js_library`.

Since you want to lint the original TypeScript source files, the `ts_project` rule produced
by the macro is the one you want to lint, so when used with an `eslint_test` you should use
the `[name]_typings` label:

```
ts_project(
    name = "my_ts",
    transpiler = swc,
    ...
)

eslint_test(
    name = "lint_my_ts",
    srcs = [":my_ts_typings"],
)
```

See the [react example](https://github.com/bazelbuild/examples/blob/b498bb106b2028b531ceffbd10cc89530814a177/frontend/react/src/BUILD.bazel#L86-L92)�
lint
flake8.bzl�	flake8_actiongRun flake8 as an action under Bazel.

Based on https://flake8.pycqa.org/en/latest/user/invocation.html
*�
�
flake8_action0
ctx'Bazel Rule or Aspect evaluation context +

executablelabel of the flake8 program #
srcspython files to be linted L
config@label of the flake8 config file (setup.cfg, tox.ini, or .flake8) 3
stdout'output file containing stdout of flake8 v
	exit_codecoutput file containing exit code of flake8
If None, then fail the build when flake8 exits non-zero.Noneh
optionsYadditional command-line options, see https://flake8.pycqa.org/en/latest/user/options.html[]gRun flake8 as an action under Bazel.

Based on https://flake8.pycqa.org/en/latest/user/invocation.html
2"
flake8_action//lint:flake8.bzl2
0
ctx'Bazel Rule or Aspect evaluation context -
+

executablelabel of the flake8 program %
#
srcspython files to be linted N
L
config@label of the flake8 config file (setup.cfg, tox.ini, or .flake8) 5
3
stdout'output file containing stdout of flake8 x
v
	exit_codecoutput file containing exit code of flake8
If None, then fail the build when flake8 exits non-zero.Nonej
h
optionsYadditional command-line options, see https://flake8.pycqa.org/en/latest/user/options.html[]�lint_flake8_aspect�A factory function to create a linter aspect.

Attrs:
    binary: a flake8 executable. Obtain from rules_python like so:

        load("@rules_python//python/entry_points:py_console_script_binary.bzl", "py_console_script_binary")

        py_console_script_binary(
            name = "flake8",
            pkg = "@pip//flake8:pkg",
        )

    config: the flake8 config file (`setup.cfg`, `tox.ini`, or `.flake8`)*�
�
lint_flake8_aspect

binary 

config )

rule_kinds["py_binary", "py_library"]�A factory function to create a linter aspect.

Attrs:
    binary: a flake8 executable. Obtain from rules_python like so:

        load("@rules_python//python/entry_points:py_console_script_binary.bzl", "py_console_script_binary")

        py_console_script_binary(
            name = "flake8",
            pkg = "@pip//flake8:pkg",
        )

    config: the flake8 config file (`setup.cfg`, `tox.ini`, or `.flake8`)2'
lint_flake8_aspect//lint:flake8.bzl


binary 


config +
)

rule_kinds["py_binary", "py_library"]�API for declaring a flake8 lint aspect that visits py_library rules.

Typical usage:

First, fetch the flake8 package via your standard requirements file and python rules (pip, uv, etc).

Then, declare a binary target for it, typically in `tools/lint/BUILD.bazel`:

```starlark
load("@rules_python//python/entry_points:py_console_script_binary.bzl", "py_console_script_binary")
py_console_script_binary(
    name = "flake8",
    pkg = "@pip//flake8:pkg",
)
```

Finally, create the linter aspect, typically in `tools/lint/linters.bzl`:

```starlark
load("@aspect_rules_lint//lint:flake8.bzl", "lint_flake8_aspect")

flake8 = lint_flake8_aspect(
    binary = Label("//tools/lint:flake8"),
    config = Label("//:.flake8"),
)
```�
lintkeep_sorted.bzl�keep_sorted_action)Run keep-sorted as an action under Bazel.*�
�
keep_sorted_action0
ctx'Bazel Rule or Aspect evaluation context 0

executable label of the keep-sorted program 
srcsfiles to be linted )
stdoutoutput file containing stdout m
	exit_codeZoutput file containing exit code
If None, then fail the build when program exits non-zero.None.
optionsadditional command-line options[]d
patchUoutput file for patch (optional). If provided, uses run_patcher instead of run_shell.None)Run keep-sorted as an action under Bazel.2,
keep_sorted_action//lint:keep_sorted.bzl2
0
ctx'Bazel Rule or Aspect evaluation context 2
0

executable label of the keep-sorted program 

srcsfiles to be linted +
)
stdoutoutput file containing stdout o
m
	exit_codeZoutput file containing exit code
If None, then fail the build when program exits non-zero.None0
.
optionsadditional command-line options[]f
d
patchUoutput file for patch (optional). If provided, uses run_patcher instead of run_shell.None�lint_keep_sorted_aspect-A factory function to create a linter aspect.*�
�
lint_keep_sorted_aspect$
binarya keep-sorted executable -A factory function to create a linter aspect."&
$An aspect definition for keep-sorted21
lint_keep_sorted_aspect//lint:keep_sorted.bzl&
$
binarya keep-sorted executable �API for declaring a keep-sorted lint aspect that visits all source files.

Typical usage:

First, fetch the keep-sorted dependency via gazelle. We provide a convenient go.mod file.
To keep it isolated from your other go dependencies, we recommend adding to .bazelrc:

    common --experimental_isolated_extension_usages

Next add to MODULE.bazel:

    keep_sorted_deps = use_extension("@gazelle//:extensions.bzl", "go_deps", isolate = True)
    keep_sorted_deps.from_file(go_mod = "@aspect_rules_lint//lint/keep-sorted:go.mod")
    use_repo(keep_sorted_deps, "com_github_google_keep_sorted")

Finally, create the linter aspect, typically in `tools/lint/linters.bzl`:

```starlark
load("@aspect_rules_lint//lint:keep_sorted.bzl", "lint_keep_sorted_aspect")

keep_sorted = lint_keep_sorted_aspect(
    binary = Label("@com_github_google_keep_sorted//:keep-sorted"),
)
```

Now you can add `// keep-sorted start` / `// keep-sorted end` lines to your library sources,
following the documentation at https://github.com/google/keep-sorted#usage.�
lintlint_test.bzlY	lint_test*J
:
	lint_test

aspect 2!
	lint_test//lint:lint_test.bzl


aspect �Factory function to make lint test rules.

When the linter exits non-zero, the test will print the output of the linter and then fail.

To use this, in your `linters.bzl` where you define the aspect, just create a test that references it.

For example, with `flake8`:

```starlark
load("@aspect_rules_lint//lint:lint_test.bzl", "lint_test")
load("@aspect_rules_lint//lint:flake8.bzl", "lint_flake8_aspect")

flake8 = lint_flake8_aspect(
    binary = Label("//:flake8"),
    config = Label("//:.flake8"),
)

flake8_test = lint_test(aspect = flake8)
```

Now in your BUILD files you can add a test:

```starlark
load("//tools/lint:linters.bzl", "flake8_test")

py_library(
    name = "unused_import",
    srcs = ["unused_import.py"],
)

flake8_test(
    name = "flake8",
    srcs = [":unused_import"],
)
```�
lintpmd.bzl�	
pmd_action�Run PMD as an action under Bazel.

Based on https://docs.pmd-code.org/latest/pmd_userdocs_installation.html#running-pmd-via-command-line
*�
�

pmd_action0
ctx'Bazel Rule or Aspect evaluation context (

executablelabel of the PMD program !
srcsjava files to be linted 5
rulesets'list of labels of the PMD ruleset files #
stdoutoutput file to generate l
	exit_codeYoutput file to write the exit code.
If None, then fail the build when PMD exits non-zero.Nonem
options^additional command-line options, see https://pmd.github.io/pmd/pmd_userdocs_cli_reference.html[]�Run PMD as an action under Bazel.

Based on https://docs.pmd-code.org/latest/pmd_userdocs_installation.html#running-pmd-via-command-line
2

pmd_action//lint:pmd.bzl2
0
ctx'Bazel Rule or Aspect evaluation context *
(

executablelabel of the PMD program #
!
srcsjava files to be linted 7
5
rulesets'list of labels of the PMD ruleset files %
#
stdoutoutput file to generate n
l
	exit_codeYoutput file to write the exit code.
If None, then fail the build when PMD exits non-zero.Noneo
m
options^additional command-line options, see https://pmd.github.io/pmd/pmd_userdocs_cli_reference.html[]�lint_pmd_aspect�A factory function to create a linter aspect.

Attrs:
    binary: a PMD executable. Obtain from rules_java like so:

        java_binary(
            name = "pmd",
            main_class = "net.sourceforge.pmd.PMD",
            # Point to wherever you have the java_import rule defined, see our example
            runtime_deps = ["@net_sourceforge_pmd"],
        )

    rulesets: the PMD ruleset XML files*�
�
lint_pmd_aspect

binary 
rulesets -

rule_kinds["java_binary", "java_library"]�A factory function to create a linter aspect.

Attrs:
    binary: a PMD executable. Obtain from rules_java like so:

        java_binary(
            name = "pmd",
            main_class = "net.sourceforge.pmd.PMD",
            # Point to wherever you have the java_import rule defined, see our example
            runtime_deps = ["@net_sourceforge_pmd"],
        )

    rulesets: the PMD ruleset XML files2!
lint_pmd_aspect//lint:pmd.bzl


binary 

rulesets /
-

rule_kinds["java_binary", "java_library"]�API for declaring a PMD lint aspect that visits java_library rules.

Typical usage:

First, call the tools.pmd module extension to download the zip file.
Alternatively you could use whatever you prefer for managing Java dependencies, such as a Maven integration rule.

Next, declare a binary target for it, typically in `tools/lint/BUILD.bazel`:

```starlark
java_binary(
    name = "pmd",
    main_class = "net.sourceforge.pmd.PMD",
    runtime_deps = ["@net_sourceforge_pmd"],
)
```

Finally, declare an aspect for it, typically in `tools/lint/linters.bzl`:

```starlark
load("@aspect_rules_lint//lint:pmd.bzl", "lint_pmd_aspect")

pmd = lint_pmd_aspect(
    binary = Label("//tools/lint:pmd"),
    rulesets = [Label("//:pmd.xml")],
)
```�
lintpydoclint.bzl�	pydoclint_actionTRun pydoclint as an action under Bazel.

Based on https://jsh9.github.io/pydoclint/
*�
�
pydoclint_action0
ctx'Bazel Rule or Aspect evaluation context .

executablelabel of the pydoclint program #
srcspython files to be linted V
configJlabel of the pydoclint config file (`pyproject.toml` or another TOML file) 6
stdout*output file containing stdout of pydoclint |
	exit_codeioutput file containing exit code of pydoclint
If None, then fail the build when pydoclint exits non-zero.None:
env/environment variables for the pydoclint process{}TRun pydoclint as an action under Bazel.

Based on https://jsh9.github.io/pydoclint/
2(
pydoclint_action//lint:pydoclint.bzl2
0
ctx'Bazel Rule or Aspect evaluation context 0
.

executablelabel of the pydoclint program %
#
srcspython files to be linted X
V
configJlabel of the pydoclint config file (`pyproject.toml` or another TOML file) 8
6
stdout*output file containing stdout of pydoclint ~
|
	exit_codeioutput file containing exit code of pydoclint
If None, then fail the build when pydoclint exits non-zero.None<
:
env/environment variables for the pydoclint process{}�lint_pydoclint_aspect-A factory function to create a linter aspect.*�
�
lint_pydoclint_aspect�
binary�a pydoclint executable. A small wrapper `py_binary` is recommended so
human-readable output can call Click with `color=True`, for example:

load("@aspect_rules_py//py:defs.bzl", "py_binary")

py_binary(
    name = "pydoclint",
    srcs = ["pydoclint_wrapper.py"],
    main = "pydoclint_wrapper.py",
    deps = [
        "@pip//pydoclint",
    ],
) M
configAthe pydoclint config file (`pyproject.toml` or another TOML file) �

rule_kinds_which [kinds](https://bazel.build/query/language#kind) of rules should be visited by the aspect&["py_binary", "py_library", "py_test"]y
filegroup_tagsDfilegroups tagged with these tags will also be visited by the aspect!["python", "lint-with-pydoclint"]-A factory function to create a linter aspect.2-
lint_pydoclint_aspect//lint:pydoclint.bzl�
�
binary�a pydoclint executable. A small wrapper `py_binary` is recommended so
human-readable output can call Click with `color=True`, for example:

load("@aspect_rules_py//py:defs.bzl", "py_binary")

py_binary(
    name = "pydoclint",
    srcs = ["pydoclint_wrapper.py"],
    main = "pydoclint_wrapper.py",
    deps = [
        "@pip//pydoclint",
    ],
) O
M
configAthe pydoclint config file (`pyproject.toml` or another TOML file) �
�

rule_kinds_which [kinds](https://bazel.build/query/language#kind) of rules should be visited by the aspect&["py_binary", "py_library", "py_test"]{
y
filegroup_tagsDfilegroups tagged with these tags will also be visited by the aspect!["python", "lint-with-pydoclint"]�API for declaring a pydoclint lint aspect that visits Python rules.

Typical usage:

First, fetch the pydoclint package via your standard requirements file and
python rules (pip, uv, etc).

Then, declare a binary target for it, typically in `tools/lint/BUILD.bazel`:

```starlark
load("@aspect_rules_py//py:defs.bzl", "py_binary")

py_binary(
    name = "pydoclint",
    srcs = ["pydoclint_wrapper.py"],
    main = "pydoclint_wrapper.py",
    deps = [
        "@pip//pydoclint",
    ],
)
```

Finally, create the linter aspect, typically in `tools/lint/linters.bzl`:

```starlark
load("@aspect_rules_lint//lint:pydoclint.bzl", "lint_pydoclint_aspect")

pydoclint = lint_pydoclint_aspect(
    binary = Label("//tools/lint:pydoclint"),
    config = Label("//:pyproject.toml"),
)
```�
lint
pylint.bzl�	pylint_actionkRun pylint as an action under Bazel.

Based on https://pylint.readthedocs.io/en/stable/user_guide/run.html
*�
�
pylint_action0
ctx'Bazel Rule or Aspect evaluation context +

executablelabel of the pylint program #
srcspython files to be linted U
configIlabel of the pylint config file (pyproject.toml, .pylintrc, or setup.cfg) 3
stdout'output file containing stdout of pylint v
	exit_codecoutput file containing exit code of pylint
If None, then fail the build when pylint exits non-zero.None.
optionsadditional command-line options[]kRun pylint as an action under Bazel.

Based on https://pylint.readthedocs.io/en/stable/user_guide/run.html
2"
pylint_action//lint:pylint.bzl2
0
ctx'Bazel Rule or Aspect evaluation context -
+

executablelabel of the pylint program %
#
srcspython files to be linted W
U
configIlabel of the pylint config file (pyproject.toml, .pylintrc, or setup.cfg) 5
3
stdout'output file containing stdout of pylint x
v
	exit_codecoutput file containing exit code of pylint
If None, then fail the build when pylint exits non-zero.None0
.
optionsadditional command-line options[]�
lint_pylint_aspect-A factory function to create a linter aspect.*�

�
lint_pylint_aspect�
binary�a pylint executable. Obtain from rules_python like so:

load("@rules_python//python/entry_points:py_console_script_binary.bzl", "py_console_script_binary")

py_console_script_binary(
    name = "pylint",
    pkg = "@pip//pylint:pkg",
) Q
configEthe pylint config file (`pyproject.toml`, `pylintrc`, or `.pylintrc`) �

rule_kinds_which [kinds](https://bazel.build/query/language#kind) of rules should be visited by the aspect&["py_binary", "py_library", "py_test"]v
filegroup_tagsDfilegroups tagged with these tags will also be visited by the aspect["python", "lint-with-pylint"]-A factory function to create a linter aspect.2'
lint_pylint_aspect//lint:pylint.bzl�
�
binary�a pylint executable. Obtain from rules_python like so:

load("@rules_python//python/entry_points:py_console_script_binary.bzl", "py_console_script_binary")

py_console_script_binary(
    name = "pylint",
    pkg = "@pip//pylint:pkg",
) S
Q
configEthe pylint config file (`pyproject.toml`, `pylintrc`, or `.pylintrc`) �
�

rule_kinds_which [kinds](https://bazel.build/query/language#kind) of rules should be visited by the aspect&["py_binary", "py_library", "py_test"]x
v
filegroup_tagsDfilegroups tagged with these tags will also be visited by the aspect["python", "lint-with-pylint"]�API for declaring a pylint lint aspect that visits Python rules.

Typical usage:

First, fetch the pylint package via your standard requirements file and python rules (pip, uv, etc).

Then, declare a binary target for it, typically in `tools/lint/BUILD.bazel`:

```starlark
load("@rules_python//python/entry_points:py_console_script_binary.bzl", "py_console_script_binary")

py_console_script_binary(
    name = "pylint",
    pkg = "@pip//pylint:pkg",
)
```

Finally, create the linter aspect, typically in `tools/lint/linters.bzl`:

```starlark
load("@aspect_rules_lint//lint:pylint.bzl", "lint_pylint_aspect")

pylint = lint_pylint_aspect(
    binary = Label("//tools/lint:pylint"),
    config = Label("//:.pylintrc"),
)
```�
lintqmllint.bzl�qmllint_action%Run qmllint as an action under Bazel.*�
�
qmllint_action"
ctxThe Bazel action context. .

executableThe qmllint executable to run. #
srcsThe source files to lint. 4
config(A configuration file to pass to qmllint. ;
stdout/The file to write the human-readable report to. z
	exit_codegAn optional file to write the exit code to. If not provided, the action will not capture the exit code.Noned
patchUoutput file for patch (optional). If provided, uses run_patcher instead of run_shell.None%Run qmllint as an action under Bazel.2$
qmllint_action//lint:qmllint.bzl$
"
ctxThe Bazel action context. 0
.

executableThe qmllint executable to run. %
#
srcsThe source files to lint. 6
4
config(A configuration file to pass to qmllint. =
;
stdout/The file to write the human-readable report to. |
z
	exit_codegAn optional file to write the exit code to. If not provided, the action will not capture the exit code.Nonef
d
patchUoutput file for patch (optional). If provided, uses run_patcher instead of run_shell.None�lint_qmllint_aspectCreate a qmllint aspect.*�
�
lint_qmllint_aspect

binary 

config 

rule_kinds[].
filegroup_tags["qml", "lint-with-qmllint"]Create a qmllint aspect.2)
lint_qmllint_aspect//lint:qmllint.bzl


binary 


config 


rule_kinds[]0
.
filegroup_tags["qml", "lint-with-qmllint"]�Configures [qmllint](https://doc.qt.io/qt-6/qtqml-tooling-qmllint.html) to run as a Bazel aspect.

Typical usage:

Create an executable target for the PySide wrapper, for example in `tools/lint/BUILD.bazel`:

```starlark
load("@rules_python//python/entry_points:py_console_script_binary.bzl", "py_console_script_binary")

py_console_script_binary(
    name = "qmllint",
    pkg = "@pip//pyside6_essentials:pkg",
    script = "qmllint",
)
```

Then declare the linter aspect, typically in `tools/lint/linters.bzl`:

```starlark
load("@aspect_rules_lint//lint:qmllint.bzl", "lint_qmllint_aspect")

qmllint = lint_qmllint_aspect(
    binary = Label("//tools/lint:qmllint"),
    config = Label("//:.qmllint.ini"),
)
```

Finally, opt QML sources into linting by tagging a `filegroup` with `qml`, or by
providing a custom `rule_kinds` list that matches your QML rules.�)
lintrubocop.bzl�rubocop_action�Run RuboCop as an action under Bazel.

RuboCop will select the configuration file to use for each source file,
as documented here:
https://docs.rubocop.org/rubocop/configuration.html

Note: all config files are passed to the action.
This means that a change to any config file invalidates the action cache
entries for ALL RuboCop actions.

However, this is important because RuboCop's logic for selecting the
appropriate config needs to traverse the directory hierarchy.
*�
�	
rubocop_action0
ctx'Bazel Rule or Aspect evaluation context 6

executable&File object for the RuboCop executable A
srcs7list of File objects for Ruby source files to be linted H
config<list of File objects for RuboCop config files (.rubocop.yml) ;
stdout/File object where linter output will be written �
	exit_code�File object where exit code will be written, or None.
If None, the build will fail when RuboCop exits non-zero.
See https://docs.rubocop.org/rubocop/usage/basic_usage.htmlNone7
color'boolean, whether to enable color outputFalsed
patchUoutput file for patch (optional). If provided, uses run_patcher instead of run_shell.None�Run RuboCop as an action under Bazel.

RuboCop will select the configuration file to use for each source file,
as documented here:
https://docs.rubocop.org/rubocop/configuration.html

Note: all config files are passed to the action.
This means that a change to any config file invalidates the action cache
entries for ALL RuboCop actions.

However, this is important because RuboCop's logic for selecting the
appropriate config needs to traverse the directory hierarchy.
2$
rubocop_action//lint:rubocop.bzl2
0
ctx'Bazel Rule or Aspect evaluation context 8
6

executable&File object for the RuboCop executable C
A
srcs7list of File objects for Ruby source files to be linted J
H
config<list of File objects for RuboCop config files (.rubocop.yml) =
;
stdout/File object where linter output will be written �
�
	exit_code�File object where exit code will be written, or None.
If None, the build will fail when RuboCop exits non-zero.
See https://docs.rubocop.org/rubocop/usage/basic_usage.htmlNone9
7
color'boolean, whether to enable color outputFalsef
d
patchUoutput file for patch (optional). If provided, uses run_patcher instead of run_shell.None�	lint_rubocop_aspect-A factory function to create a linter aspect.*�
�
lint_rubocop_aspectf
binaryZLabel of the RuboCop executable.
Example: "//tools/lint:rubocop" or "@bundle//bin:rubocop" o
configsbLabel or list of Labels of RuboCop config file(s).
Example: ["//:rubocop.yml"] or "//:rubocop.yml" ~

rule_kindsHlist of rule kinds to visit.
See https://bazel.build/query/language#kind&["rb_binary", "rb_library", "rb_test"]�
filegroup_tagsplist of filegroup tags. Filegroups with these tags
will be visited by the aspect in addition to Ruby rule kinds.["ruby", "lint-with-rubocop"]-A factory function to create a linter aspect.2)
lint_rubocop_aspect//lint:rubocop.bzlh
f
binaryZLabel of the RuboCop executable.
Example: "//tools/lint:rubocop" or "@bundle//bin:rubocop" q
o
configsbLabel or list of Labels of RuboCop config file(s).
Example: ["//:rubocop.yml"] or "//:rubocop.yml" �
~

rule_kindsHlist of rule kinds to visit.
See https://bazel.build/query/language#kind&["rb_binary", "rb_library", "rb_test"]�
�
filegroup_tagsplist of filegroup tags. Filegroups with these tags
will be visited by the aspect in addition to Ruby rule kinds.["ruby", "lint-with-rubocop"]�API for declaring a RuboCop lint aspect that visits rb_{binary|library|test}
rules.

Typical usage:

## Installing RuboCop

The recommended approach is to use Bundler with rules_ruby to manage RuboCop
as a gem dependency:

1. Add RuboCop to your `Gemfile`:
```ruby
gem "rubocop", "~> 1.50"
```

2. Run `bundle lock` to generate `Gemfile.lock`

3. Configure the bundle in your `MODULE.bazel`:
```starlark
ruby = use_extension("@rules_ruby//ruby:extensions.bzl", "ruby")
ruby.toolchain(
    name = "ruby",
    version = "3.3.0",
)
ruby.bundle_fetch(
    name = "bundle",
    gemfile = "//:Gemfile",
    gemfile_lock = "//:Gemfile.lock",
)
use_repo(ruby, "bundle", "ruby", "ruby_toolchains")
```

4. Create an alias to the gem-provided binary in
   `tools/lint/BUILD.bazel`:
```starlark
alias(
    name = "rubocop",
    actual = "@bundle//bin:rubocop",
)
```

5. Create the linter aspect, typically in `tools/lint/linters.bzl`:
```starlark
load("@aspect_rules_lint//lint:rubocop.bzl", "lint_rubocop_aspect")

rubocop = lint_rubocop_aspect(
    binary = "//tools/lint:rubocop",
    configs = ["//:rubocop.yml"],
)
```

This approach ensures:
- Hermetic builds with pinned gem versions
- Consistent RuboCop versions across all developers
- Integration with Bazel's dependency management

## Configuration

RuboCop will automatically discover `.rubocop.yml` files according to its
standard configuration hierarchy.
See https://docs.rubocop.org/rubocop/configuration.html for details.

Note: all config files are passed to the action as inputs.
This means that a change to any config file invalidates the action cache
entries for ALL RuboCop actions.�6
lintruff.bzl�ruff_action�Run ruff as an action under Bazel.

Ruff will select the configuration file to use for each source file, as documented here:
https://docs.astral.sh/ruff/configuration/#config-file-discovery

Note: all config files are passed to the action.
This means that a change to any config file invalidates the action cache entries for ALL
ruff actions.

However, this is important because:

1. ruff has an `extend` field, so it may need to read more than one config file
2. ruff's logic for selecting the appropriate config needs to read the file content to detect a `[tool.ruff]` section.
*�
�	
ruff_action0
ctx'Bazel Rule or Aspect evaluation context )

executablelabel of the ruff program #
srcspython files to be linted R
configFlabels of ruff config files (pyproject.toml, ruff.toml, or .ruff.toml) 5
stdout)output file of linter results to generate �
	exit_code�output file to write the exit code.
If None, then fail the build when ruff exits non-zero.
See https://github.com/astral-sh/ruff/blob/dfe4291c0b7249ae892f5f1d513e6f1404436c13/docs/linter.md#exit-codesNone*
envenvironment variaables for ruff{}d
patchUoutput file for patch (optional). If provided, uses run_patcher instead of run_shell.None�Run ruff as an action under Bazel.

Ruff will select the configuration file to use for each source file, as documented here:
https://docs.astral.sh/ruff/configuration/#config-file-discovery

Note: all config files are passed to the action.
This means that a change to any config file invalidates the action cache entries for ALL
ruff actions.

However, this is important because:

1. ruff has an `extend` field, so it may need to read more than one config file
2. ruff's logic for selecting the appropriate config needs to read the file content to detect a `[tool.ruff]` section.
2
ruff_action//lint:ruff.bzl2
0
ctx'Bazel Rule or Aspect evaluation context +
)

executablelabel of the ruff program %
#
srcspython files to be linted T
R
configFlabels of ruff config files (pyproject.toml, ruff.toml, or .ruff.toml) 7
5
stdout)output file of linter results to generate �
�
	exit_code�output file to write the exit code.
If None, then fail the build when ruff exits non-zero.
See https://github.com/astral-sh/ruff/blob/dfe4291c0b7249ae892f5f1d513e6f1404436c13/docs/linter.md#exit-codesNone,
*
envenvironment variaables for ruff{}f
d
patchUoutput file for patch (optional). If provided, uses run_patcher instead of run_shell.None�lint_ruff_aspect�A factory function to create a linter aspect.

Attrs:
    binary: a ruff executable
    configs: ruff config file(s) (`pyproject.toml`, `ruff.toml`, or `.ruff.toml`)
    rule_kinds: which [kinds](https://bazel.build/query/language#kind) of rules should be visited by the aspect
    filegroup_tags: filegroups tagged with these tags will be visited by the aspect in addition to Python rule kinds*�
�
lint_ruff_aspect

binary 
configs 4

rule_kinds&["py_binary", "py_library", "py_test"].
filegroup_tags["python", "lint-with-ruff"]�A factory function to create a linter aspect.

Attrs:
    binary: a ruff executable
    configs: ruff config file(s) (`pyproject.toml`, `ruff.toml`, or `.ruff.toml`)
    rule_kinds: which [kinds](https://bazel.build/query/language#kind) of rules should be visited by the aspect
    filegroup_tags: filegroups tagged with these tags will be visited by the aspect in addition to Python rule kinds2#
lint_ruff_aspect//lint:ruff.bzl


binary 

configs 6
4

rule_kinds&["py_binary", "py_library", "py_test"]0
.
filegroup_tags["python", "lint-with-ruff"]�ruff_workaround_20269?Workaround for https://github.com/bazelbuild/bazel/issues/20269R�
�
ruff_workaround_20269?Workaround for https://github.com/bazelbuild/bazel/issues/20269.
name"A unique name for this repository. �
repo_mapping�In `WORKSPACE` context only: a dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.

For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).

This attribute is _not_ supported in `MODULE.bazel` context (when invoking a repository rule inside a module extension's implementation function).

build_file_content2""
sha2562""b
strip_prefixLunlike http_archive, any value causes us to pass --strip-components=1 to tar2""
url2""*(
ruff_workaround_20269//lint:ruff.bzl0
.
name"A unique name for this repository. �
�
repo_mapping�In `WORKSPACE` context only: a dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.

For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).

This attribute is _not_ supported in `MODULE.bazel` context (when invoking a repository rule inside a module extension's implementation function).


build_file_content2""

sha2562""d
b
strip_prefixLunlike http_archive, any value causes us to pass --strip-components=1 to tar2""

url2""�API for declaring a Ruff lint aspect that visits py_{binary|library|test} rules.

Typical usage:

Ruff is provided as a built-in tool by rules_lint. To use the built-in version,
create the linter aspect, typically in `tools/lint/linters.bzl`:

```starlark
load("@aspect_rules_lint//lint:ruff.bzl", "lint_ruff_aspect")

ruff = lint_ruff_aspect(
    binary = Label("@aspect_rules_lint//lint:ruff_bin",
    configs = [Label("//:.ruff.toml")],
)
```

## Using a specific ruff version

In `MODULE.bazel`, fetch the desired version from https://github.com/astral-sh/ruff/releases.

In `tools/lint/BUILD.bazel`, select the tool for the host platform:

```starlark
# Note: this won't interact properly with the --platform flag, see
# https://github.com/aspect-build/rules_lint/issues/389
alias(
    name = "ruff",
    actual = select({
        "@bazel_tools//src/conditions:linux_x86_64": "@ruff_x86_64-unknown-linux-gnu//:ruff",
        "@bazel_tools//src/conditions:linux_aarch64": "@ruff_aarch64-unknown-linux-gnu//:ruff",
        "@bazel_tools//src/conditions:darwin_arm64": "@ruff_aarch64-apple-darwin//:ruff",
        "@bazel_tools//src/conditions:darwin_x86_64": "@ruff_x86_64-apple-darwin//:ruff",
        "@bazel_tools//src/conditions:windows_x64": "@ruff_x86_64-pc-windows-msvc//:ruff.exe",
    }),
)
```

Finally, reference this tool alias rather than the one from `@multitool`:

```starlark
ruff = lint_ruff_aspect(
    binary = "@@//tools/lint:ruff",
    ...
)
```Q
lintruff_versions.bzl4This file is automatically updated by mirror_ruff.sh�
lintshellcheck.bzl�shellcheck_actionvRun shellcheck as an action under Bazel.

Based on https://github.com/koalaman/shellcheck/blob/master/shellcheck.1.md
*�
�
shellcheck_action0
ctx'Bazel Rule or Aspect evaluation context /

executablelabel of the shellcheck program !
srcsbash files to be linted Q
transitive_srcs<depset of sourced shell files required for source resolution +
configlabel of the .shellcheckrc file 7
stdout+output file containing stdout of shellcheck �
	exit_code�output file containing shellcheck exit code.
If None, then fail the build when vale exits non-zero.
See https://github.com/koalaman/shellcheck/blob/master/shellcheck.1.md#return-valuesNonex
optionsiadditional command-line options, see https://github.com/koalaman/shellcheck/blob/master/shellcheck.hs#L95[]vRun shellcheck as an action under Bazel.

Based on https://github.com/koalaman/shellcheck/blob/master/shellcheck.1.md
2*
shellcheck_action//lint:shellcheck.bzl2
0
ctx'Bazel Rule or Aspect evaluation context 1
/

executablelabel of the shellcheck program #
!
srcsbash files to be linted S
Q
transitive_srcs<depset of sourced shell files required for source resolution -
+
configlabel of the .shellcheckrc file 9
7
stdout+output file containing stdout of shellcheck �
�
	exit_code�output file containing shellcheck exit code.
If None, then fail the build when vale exits non-zero.
See https://github.com/koalaman/shellcheck/blob/master/shellcheck.1.md#return-valuesNonez
x
optionsiadditional command-line options, see https://github.com/koalaman/shellcheck/blob/master/shellcheck.hs#L95[]�lint_shellcheck_aspect}A factory function to create a linter aspect.

Attrs:
    binary: a shellcheck executable.
    config: the .shellcheckrc file*�
�
lint_shellcheck_aspect

binary 

config 4

rule_kinds&["sh_binary", "sh_library", "sh_test"]}A factory function to create a linter aspect.

Attrs:
    binary: a shellcheck executable.
    config: the .shellcheckrc file2/
lint_shellcheck_aspect//lint:shellcheck.bzl


binary 


config 6
4

rule_kinds&["sh_binary", "sh_library", "sh_test"]�API for declaring a shellcheck lint aspect that visits sh_{binary|library|test} rules.

Typical usage:

Shellcheck is provided as a built-in tool by rules_lint. To use the built-in version,
create the linter aspect, typically in `tools/lint/linters.bzl`:

```starlark
load("@aspect_rules_lint//lint:shellcheck.bzl", "lint_shellcheck_aspect")

shellcheck = lint_shellcheck_aspect(
    binary = Label("@aspect_rules_lint//lint:shellcheck_bin",
    config = Label("//:.shellcheckrc"),
)
```�*
lintstandardrb.bzl�standardrb_action�Run Standard Ruby as an action under Bazel.

Standard Ruby will select the configuration file to use for each
source file, as documented here:
https://github.com/standardrb/standard

Note: all config files are passed to the action.
This means that a change to any config file invalidates the action cache
entries for ALL Standard Ruby actions.

However, this is important because Standard Ruby's logic for selecting the
appropriate config needs to traverse the directory hierarchy.
*�
�	
standardrb_action0
ctx'Bazel Rule or Aspect evaluation context <

executable,File object for the Standard Ruby executable A
srcs7list of File objects for Ruby source files to be linted O
configClist of File objects for Standard Ruby config files
(.standard.yml) ;
stdout/File object where linter output will be written �
	exit_code�File object where exit code will be written, or None.
If None, the build will fail when Standard Ruby exits non-zero.
See https://github.com/standardrb/standardNone7
color'boolean, whether to enable color outputFalsed
patchUoutput file for patch (optional). If provided, uses run_patcher instead of run_shell.None�Run Standard Ruby as an action under Bazel.

Standard Ruby will select the configuration file to use for each
source file, as documented here:
https://github.com/standardrb/standard

Note: all config files are passed to the action.
This means that a change to any config file invalidates the action cache
entries for ALL Standard Ruby actions.

However, this is important because Standard Ruby's logic for selecting the
appropriate config needs to traverse the directory hierarchy.
2*
standardrb_action//lint:standardrb.bzl2
0
ctx'Bazel Rule or Aspect evaluation context >
<

executable,File object for the Standard Ruby executable C
A
srcs7list of File objects for Ruby source files to be linted Q
O
configClist of File objects for Standard Ruby config files
(.standard.yml) =
;
stdout/File object where linter output will be written �
�
	exit_code�File object where exit code will be written, or None.
If None, the build will fail when Standard Ruby exits non-zero.
See https://github.com/standardrb/standardNone9
7
color'boolean, whether to enable color outputFalsef
d
patchUoutput file for patch (optional). If provided, uses run_patcher instead of run_shell.None�	lint_standardrb_aspect-A factory function to create a linter aspect.*�	
�
lint_standardrb_aspectr
binaryfLabel of the Standard Ruby executable.
Example: "//tools/lint:standardrb" or "@bundle//bin:standardrb" w
configsjLabel or list of Labels of Standard Ruby config file(s).
Example: ["//:standard.yml"] or "//:standard.yml" ~

rule_kindsHlist of rule kinds to visit.
See https://bazel.build/query/language#kind&["rb_binary", "rb_library", "rb_test"]�
filegroup_tagsplist of filegroup tags. Filegroups with these tags
will be visited by the aspect in addition to Ruby rule kinds. ["ruby", "lint-with-standardrb"]-A factory function to create a linter aspect.2/
lint_standardrb_aspect//lint:standardrb.bzlt
r
binaryfLabel of the Standard Ruby executable.
Example: "//tools/lint:standardrb" or "@bundle//bin:standardrb" y
w
configsjLabel or list of Labels of Standard Ruby config file(s).
Example: ["//:standard.yml"] or "//:standard.yml" �
~

rule_kindsHlist of rule kinds to visit.
See https://bazel.build/query/language#kind&["rb_binary", "rb_library", "rb_test"]�
�
filegroup_tagsplist of filegroup tags. Filegroups with these tags
will be visited by the aspect in addition to Ruby rule kinds. ["ruby", "lint-with-standardrb"]�API for declaring a Standard Ruby lint aspect.

Visits rb_{binary|library|test} rules.

Typical usage:

## Installing Standard Ruby

The recommended approach is to use Bundler with rules_ruby to manage
Standard Ruby as a gem dependency:

1. Add Standard Ruby to your `Gemfile`:
```ruby
gem "standard", "~> 1.0"
```

2. Run `bundle lock` to generate `Gemfile.lock`

3. Configure the bundle in your `MODULE.bazel`:
```starlark
ruby = use_extension("@rules_ruby//ruby:extensions.bzl", "ruby")
ruby.toolchain(
    name = "ruby",
    version = "3.3.0",
)
ruby.bundle_fetch(
    name = "bundle",
    gemfile = "//:Gemfile",
    gemfile_lock = "//:Gemfile.lock",
)
use_repo(ruby, "bundle", "ruby", "ruby_toolchains")
```

4. Create an alias to the gem-provided binary in
   `tools/lint/BUILD.bazel`:
```starlark
alias(
    name = "standardrb",
    actual = "@bundle//bin:standardrb",
)
```

5. Create the linter aspect, typically in `tools/lint/linters.bzl`:
```starlark
load("@aspect_rules_lint//lint:standardrb.bzl", "lint_standardrb_aspect")

standardrb = lint_standardrb_aspect(
    binary = "//tools/lint:standardrb",
    configs = ["//:standard.yml"],
)
```

This approach ensures:
- Hermetic builds with pinned gem versions
- Consistent Standard Ruby versions across all developers
- Integration with Bazel's dependency management

## Configuration

Standard Ruby will automatically discover `.standard.yml` files according to its
standard configuration hierarchy.
See https://github.com/standardrb/standard for details.

Note: all config files are passed to the action as inputs.
This means that a change to any config file invalidates the action cache
entries for ALL Standard Ruby actions.� 
lintstylelint.bzl�stylelint_action!Spawn stylelint as a Bazel action*�
�
stylelint_action,
ctx#an action context OR aspect context /

executablestruct with an _stylelint field &
srcslist of file objects to lint K
stderr?output file containing the stderr or --output-file of stylelint �
	exit_code�output file containing the exit code of stylelint.
If None, then fail the build when stylelint exits non-zero.
Exit codes may be:
    1 - fatal error
    2 - lint problem
    64 - invalid CLI usage
    78 - invalid configuration fileNone.
env#environment variables for stylelint{}0
options!additional command-line arguments[]=
format-a formatter to add as a command line argumentNoned
patchUoutput file for patch (optional). If provided, uses run_patcher instead of run_shell.None_
targetOthe aspect target, used to reuse bin-tree inputs already produced by the targetNone!Spawn stylelint as a Bazel action2(
stylelint_action//lint:stylelint.bzl.
,
ctx#an action context OR aspect context 1
/

executablestruct with an _stylelint field (
&
srcslist of file objects to lint M
K
stderr?output file containing the stderr or --output-file of stylelint �
�
	exit_code�output file containing the exit code of stylelint.
If None, then fail the build when stylelint exits non-zero.
Exit codes may be:
    1 - fatal error
    2 - lint problem
    64 - invalid CLI usage
    78 - invalid configuration fileNone0
.
env#environment variables for stylelint{}2
0
options!additional command-line arguments[]?
=
format-a formatter to add as a command line argumentNonef
d
patchUoutput file for patch (optional). If provided, uses run_patcher instead of run_shell.Nonea
_
targetOthe aspect target, used to reuse bin-tree inputs already produced by the targetNone�	lint_stylelint_aspect-A factory function to create a linter aspect.*�
�
lint_stylelint_aspect�
binary�the stylelint binary, typically a rule like

```
load("@npm//:stylelint/package_json.bzl", stylelint_bin = "bin")
stylelint_bin.stylelint_binary(name = "stylelint")
``` 1
config%label(s) of the stylelint config file ~

rule_kinds_which [kinds](https://bazel.build/query/language#kind) of rules should be visited by the aspect["css_library"]w
filegroup_tagsLwhich tags on a `filegroup` indicate that it should be visited by the aspect["lint-with-stylelint"]-A factory function to create a linter aspect.2-
lint_stylelint_aspect//lint:stylelint.bzl�
�
binary�the stylelint binary, typically a rule like

```
load("@npm//:stylelint/package_json.bzl", stylelint_bin = "bin")
stylelint_bin.stylelint_binary(name = "stylelint")
``` 3
1
config%label(s) of the stylelint config file �
~

rule_kinds_which [kinds](https://bazel.build/query/language#kind) of rules should be visited by the aspect["css_library"]y
w
filegroup_tagsLwhich tags on a `filegroup` indicate that it should be visited by the aspect["lint-with-stylelint"]�Configures [Stylelint](https://stylelint.io/) to run as a Bazel aspect

First, all CSS sources must be the srcs of some Bazel rule.
You can use a `filegroup` with `lint-with-stylelint` in the `tags`:

```python
filegroup(
    name = "css",
    srcs = glob(["*.css"]),
    tags = ["lint-with-stylelint"],
)
```

See the `filegroup_tags` and `rule_kinds` attributes below to customize this behavior.

## Usage

Add `stylelint` as a `devDependency` in your `package.json`, and declare a binary target for Bazel to execute it.

For example in `tools/lint/BUILD.bazel`:

```starlark
load("@npm//:stylelint/package_json.bzl", stylelint_bin = "bin")
stylelint_bin.stylelint_binary(name = "stylelint")
```

Then declare the linter aspect, typically in `tools/lint/linters.bzl`:

```starlark
load("@aspect_rules_lint//lint:stylelint.bzl", "lint_stylelint_aspect")
stylelint = lint_stylelint_aspect(
    binary = Label("//tools/lint:stylelint"),
    config = Label("//:stylelintrc"),
)
```

Finally, register the aspect with your linting workflow, such as in `.aspect/cli/config.yaml` for `aspect lint`.�
lintty.bzl�	ty_action�Run ty as an action under Bazel.

ty supports persistent configuration files at both the project- and user-level
as documented here: https://docs.astral.sh/ty/configuration/

Note: all config files are passed to the action.
This means that a change to any config file invalidates the action cache entries for ALL
ty actions.
*�
�
	ty_action0
ctx'Bazel Rule or Aspect evaluation context '

executablelabel of the ty program #
srcspython files to be linted J
transitive_srcs5depset of transitive Python sources from dependencies ?
config3labels of ty config files (pyproject.toml, ty.toml) 5
stdout)output file of linter results to generate �
	exit_code�output file to write the exit code.
If None, then fail the build when ty exits non-zero.
https://docs.astral.sh/ty/reference/exit-codes/None'
envenvironment variables for ty{}g
extra_search_pathsMlist of paths to add as --extra-search-path for third-party module resolution[]\
colorMwhether to enable color output (--color always) or disable it (--color never)True�Run ty as an action under Bazel.

ty supports persistent configuration files at both the project- and user-level
as documented here: https://docs.astral.sh/ty/configuration/

Note: all config files are passed to the action.
This means that a change to any config file invalidates the action cache entries for ALL
ty actions.
2
	ty_action//lint:ty.bzl2
0
ctx'Bazel Rule or Aspect evaluation context )
'

executablelabel of the ty program %
#
srcspython files to be linted L
J
transitive_srcs5depset of transitive Python sources from dependencies A
?
config3labels of ty config files (pyproject.toml, ty.toml) 7
5
stdout)output file of linter results to generate �
�
	exit_code�output file to write the exit code.
If None, then fail the build when ty exits non-zero.
https://docs.astral.sh/ty/reference/exit-codes/None)
'
envenvironment variables for ty{}i
g
extra_search_pathsMlist of paths to add as --extra-search-path for third-party module resolution[]^
\
colorMwhether to enable color output (--color always) or disable it (--color never)True�lint_ty_aspect�A factory function to create a linter aspect.

Attrs:
    binary: a ty executable
    configs: ty config file(s) (`pyproject.toml`, `ty.toml`)
    rule_kinds: which [kinds](https://bazel.build/query/language#kind) of rules should be visited by the aspect
    filegroup_tags: filegroups tagged with these tags will be visited by the aspect in addition to Python rule kinds*�
�
lint_ty_aspect

binary 

config 4

rule_kinds&["py_binary", "py_library", "py_test"],
filegroup_tags["python", "lint-with-ty"]�A factory function to create a linter aspect.

Attrs:
    binary: a ty executable
    configs: ty config file(s) (`pyproject.toml`, `ty.toml`)
    rule_kinds: which [kinds](https://bazel.build/query/language#kind) of rules should be visited by the aspect
    filegroup_tags: filegroups tagged with these tags will be visited by the aspect in addition to Python rule kinds2
lint_ty_aspect//lint:ty.bzl


binary 


config 6
4

rule_kinds&["py_binary", "py_library", "py_test"].
,
filegroup_tags["python", "lint-with-ty"]�API for declaring a Ty lint aspect that visits py_{binary|library|test} rules.

Typical usage:

Ty is provided as a built-in tool by rules_lint. To use the built-in version,
create the linter aspect, typically in `tools/lint/linters.bzl`:

```starlark
load("@aspect_rules_lint//lint:ty.bzl", "lint_ty_aspect")

ty = lint_ty_aspect(
    binary = Label("@aspect_rules_lint//lint:ty_bin"),
    config = Label("//:ty.toml"),
)
```�)
lintvale.bzl�vale_action"Run Vale as an action under Bazel.*�
�
vale_action0
ctx'Bazel Rule or Aspect evaluation context )

executablelabel of the Vale program %
srcsmarkdown files to be linted a
stylesUa directory containing vale extensions, following https://vale.sh/docs/topics/styles/ ]
configQlabel of the .vale.ini file, see https://vale.sh/docs/vale-cli/structure/#valeini 1
stdout%output file containing stdout of Vale p
	exit_code]output file containing Vale exit code.
If None, then fail the build when Vale exits non-zero.None�
output�the value for the --output flag. May be a string like 'line', 'JSON', 'CLI', or a File of a template to use: https://vale.sh/docs/templates"CLI")
envenvironment variables for vale{}"Run Vale as an action under Bazel.2
vale_action//lint:vale.bzl2
0
ctx'Bazel Rule or Aspect evaluation context +
)

executablelabel of the Vale program '
%
srcsmarkdown files to be linted c
a
stylesUa directory containing vale extensions, following https://vale.sh/docs/topics/styles/ _
]
configQlabel of the .vale.ini file, see https://vale.sh/docs/vale-cli/structure/#valeini 3
1
stdout%output file containing stdout of Vale r
p
	exit_code]output file containing Vale exit code.
If None, then fail the build when Vale exits non-zero.None�
�
output�the value for the --output flag. May be a string like 'line', 'JSON', 'CLI', or a File of a template to use: https://vale.sh/docs/templates"CLI"+
)
envenvironment variables for vale{}�
lint_vale_aspect-A factory function to create a linter aspect.*�

�
lint_vale_aspectX
binaryLa Vale executable, typically fetched by the `tools.vale()` module extension. ;
config/the label of the `.vale.ini` file used by Vale. P
template>an optional label of a `.tmpl` file passed to `vale --output`.None`
styles8a label of a directory containing installed Vale styles.Label("//lint:empty_styles")�

rule_kinds`which [kinds](https://bazel.build/query/language#kind) of rules should be visited by the aspect.["markdown_library"]w
filegroup_tagsEfilegroups tagged with these tags will also be visited by the aspect.["markdown", "lint-with-vale"]-A factory function to create a linter aspect." 
An aspect definition for Vale.2#
lint_vale_aspect//lint:vale.bzlZ
X
binaryLa Vale executable, typically fetched by the `tools.vale()` module extension. =
;
config/the label of the `.vale.ini` file used by Vale. R
P
template>an optional label of a `.tmpl` file passed to `vale --output`.Noneb
`
styles8a label of a directory containing installed Vale styles.Label("//lint:empty_styles")�
�

rule_kinds`which [kinds](https://bazel.build/query/language#kind) of rules should be visited by the aspect.["markdown_library"]y
w
filegroup_tagsEfilegroups tagged with these tags will also be visited by the aspect.["markdown", "lint-with-vale"]�API for declaring a Vale lint aspect that visits markdown files.

First, all markdown sources must be the srcs of some Bazel rule.
Either use a `filegroup` with `markdown` in the `tags`:

```python
filegroup(
    name = "md",
    srcs = glob(["*.md"]),
    tags = ["markdown"],
)
```

or use a `markdown_library` rule such as the one in [dwtj_rules_markdown](https://github.com/dwtj/dwtj_rules_markdown).
Aspect plans to provide support for Markdown in [configure]() so these rules can be automatically
maintained rather than requiring developers to write them by hand.

Note that any Markdown files in the repo which aren't in the `srcs` of one of these rules will *not*
be linted by Vale.

## Styles

Vale is powered by [Styles](https://vale.sh/docs/vale-cli/structure/#styles).
There is a [built-in style](https://vale.sh/docs/topics/styles/#built-in-style) and if this is
sufficient then it's not necessary to follow the rest of this section.

The styles from https://vale.sh/hub/ are already fetched by tools.vale_styles module extension which has a Bazel-based
mirror of https://github.com/errata-ai/packages/blob/master/library.json.
It's possible to fetch more styles using a typical `http_archive()` call.

At runtime, Vale requires the styles are "installed" into a folder together.
Use the [`copy_to_directory`](https://docs.aspect.build/rulesets/bazel_lib/docs/copy_to_directory/)
rule to accomplish this, for example,

```python
copy_to_directory(
    name = "vale_styles",
    srcs = ["@vale_write-good//:write-good"],
    include_external_repositories = ["vale_*"],
)
```

Note that the `.vale.ini` file may have a `StylesPath` entry.
Under Bazel, we set `VALE_STYLES_PATH` in the environment, so the `StylesPath` is used
only when running Vale outside Bazel, such as in an editor extension.

See the example in rules_lint for a fully-working vale setup.

## Usage

```starlark
load("@aspect_rules_lint//lint:vale.bzl", "lint_vale_aspect")

vale = lint_vale_aspect(
    binary = Label("//tools/lint:vale"),
    # A copy_to_bin rule that places the .vale.ini file into bazel-bin
    config = Label("//:.vale_ini"),
    # Optional.
    # A copy_to_directory rule that "installs" custom styles together into a single folder
    styles = Label("//tools/lint:vale_styles"),
)
```�
lintvale_library.bzl�Vale styles library

Vendored from https://raw.githubusercontent.com/errata-ai/styles/master/library.json
Then the url fields are converted from latest to a format string, and sha256sums added.Q
lintvale_versions.bzl4This file is automatically updated by mirror_vale.sh�
lintyamllint.bzl�yamllint_action&Run yamllint as an action under Bazel.*�
�
yamllint_action0
ctx'Bazel Rule or Aspect evaluation context 6

executable&File representing the yamllint program 
srcsYAML files to lint '
configyamllint configuration file +
stdoutoutput file for yamllint stdout `
	exit_codeMoptional output file for exit code. If absent, non-zero exits fail the build.None2
format"optional formatter passed via `-f`None.
optionsadditional command-line options[]&Run yamllint as an action under Bazel.2&
yamllint_action//lint:yamllint.bzl2
0
ctx'Bazel Rule or Aspect evaluation context 8
6

executable&File representing the yamllint program 

srcsYAML files to lint )
'
configyamllint configuration file -
+
stdoutoutput file for yamllint stdout b
`
	exit_codeMoptional output file for exit code. If absent, non-zero exits fail the build.None4
2
format"optional formatter passed via `-f`None0
.
optionsadditional command-line options[]�lint_yamllint_aspectCreate a yamllint aspect.*�
�
lint_yamllint_aspect

binary 

config 

rule_kinds["yaml_library"](
filegroup_tags["lint-with-yamllint"]

extra_args[]Create a yamllint aspect.2+
lint_yamllint_aspect//lint:yamllint.bzl


binary 


config  


rule_kinds["yaml_library"]*
(
filegroup_tags["lint-with-yamllint"]


extra_args[]�Configures [yamllint](https://yamllint.readthedocs.io/) to run as a Bazel aspect.

Typical usage:

Create an executable target for yamllint, for example in `tools/lint/BUILD.bazel`:

```starlark
load("@rules_python//python/entry_points:py_console_script_binary.bzl", "py_console_script_binary")

py_console_script_binary(
    name = "yamllint",
    pkg = "@pip//yamllint:pkg",
)
```

Then declare the linter aspect, typically in `tools/lint/linters.bzl`:

```starlark
load("@aspect_rules_lint//lint:yamllint.bzl", "lint_yamllint_aspect")

yamllint = lint_yamllint_aspect(
    binary = Label("//tools/lint:yamllint"),
    config = Label("//:.yamllint"),
)
```

Finally, opt YAML sources into linting by tagging a `filegroup` with `lint-with-yamllint`, or by
providing a custom `rule_kinds` list that matches your YAML rules. 