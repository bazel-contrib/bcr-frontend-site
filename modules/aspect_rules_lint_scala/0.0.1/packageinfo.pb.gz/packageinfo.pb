�
@@aspect_rules_lint_scala//�/home/sol/.cache/bazel/_bazel_sol/dee7d2116cbeda440a9fb8e57dc802ae/execroot/_main/work/external/aspect_rules_lint_scala/BUILD.bazel�
@@aspect_rules_lint_scala//lint�/home/sol/.cache/bazel/_bazel_sol/dee7d2116cbeda440a9fb8e57dc802ae/execroot/_main/work/external/aspect_rules_lint_scala/lint/BUILD.bazel 