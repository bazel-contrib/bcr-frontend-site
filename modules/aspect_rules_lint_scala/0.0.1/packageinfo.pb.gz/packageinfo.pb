p
@@aspect_rules_lint_scala//Q/home/sol/.bazel/execroot/_main/work/external/aspect_rules_lint_scala/BUILD.bazely
@@aspect_rules_lint_scala//lintV/home/sol/.bazel/execroot/_main/work/external/aspect_rules_lint_scala/lint/BUILD.bazel 