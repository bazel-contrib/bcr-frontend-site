�o
3
aspect_rules_oxcoxc/privateoxc_transpiler.bzl�koxc_transpiler�Transpile TypeScript and JavaScript sources with OXC.

Emits JavaScript and/or isolated .d.ts declarations without typechecking.
Each source file is transformed independently into its own outputs; nothing
is bundled. Provides JsInfo like ts_project, so targets can
consume the outputs interchangeably. Output files are pre-declared at load
time, letting downstream targets reference paths such as "dist/foo.js"
directly.
"�h
�5
oxc_transpiler�Transpile TypeScript and JavaScript sources with OXC.

Emits JavaScript and/or isolated .d.ts declarations without typechecking.
Each source file is transformed independently into its own outputs; nothing
is bundled. Provides JsInfo like ts_project, so targets can
consume the outputs interchangeably. Output files are pre-declared at load
time, letting downstream targets reference paths such as "dist/foo.js"
directly.
*
nameA unique name for this target. �
cpus�Threads the transpile action may use, reserved from the local scheduler via a cpu:<n> execution requirement. 0 (default) scales logarithmically with the number of srcs to transpile: one per decimal digit of the file count, plus one (2 at 3 files, 3 at 10), at most {}. Explicit values are still capped at one per file.20�
declaration_dirrDirectory for the .d.ts outputs, relative to the package. Defaults to out_dir. Equivalent to tsc's declarationDir.2""�
declaration_maps�Emit a .d.ts.map beside each declaration output, exposed with the declarations as types. Requires emit_dts. Equivalent to tsc's declarationMap.2False
dts_outs�
emit_decorator_metadata�Record design:type, design:paramtypes and design:returntype metadata for decorated members through Reflect.metadata, so a reflect-metadata polyfill must be loaded at runtime. Requires experimental_decorators. Equivalent to tsc's emitDecoratorMetadata.2False4
emit_dtsEmit .d.ts declaration outputs.2False+
emit_jsEmit JavaScript outputs.2True�
	emit_json�Copy .json srcs into the output layout unchanged; without it json srcs produce no outputs. Matches tsc's emit, which copies json only under resolveJsonModule â set this when the tsconfig sets that option.2False�
experimental_decorators�Compile decorators with the legacy (pre-TC39) transform, calling the decorate helpers imported from helpers_module. Without it decorators are emitted as written, since oxc has no transform for the standard proposal. Equivalent to tsc's experimentalDecorators.2False�
helpers_module�Module to import runtime helpers from, defaulting to @oxc-project/runtime. Transforms that need a helper always import it: oxc has no inline helper mode, so behavior is always like tsc's importHelpers=true. The helpers module must be a runtime dependency whenever a transform emits helper imports (none do in the default configuration).2""�
inline_source_maps�Embed each JS output's source map as a data URL in its sourceMappingURL comment instead of writing a .js.map. Exclusive with source_maps. Equivalent to tsc's inlineSourceMap.2False
js_outs
	json_outs�
jsx�JSX runtime, using oxc's values. "automatic" (default) is the automatic jsx-runtime transform. "classic" compiles JSX to React.createElement calls; providing React is the caller's concern. Coming from tsc, map the jsx spellings manually: react-jsx is "automatic", react is "classic".2""�
jsx_factory�Function the classic JSX runtime compiles elements to; React.createElement by default. Only applies to jsx = "classic". Equivalent to tsc's jsxFactory.2""�
jsx_fragment_factory�Expression the classic JSX runtime compiles fragments to; React.Fragment by default. Only applies to jsx = "classic". Equivalent to tsc's jsxFragmentFactory.2""�
jsx_import_source�Module the automatic JSX runtime is imported from; "react" by default. Only applies to jsx = "automatic". Equivalent to tsc's jsxImportSource.2""�
module�Module format of the JS outputs, using oxc's module values. "preserve" (default) keeps the input module syntax. "esm" keeps ESM syntax and makes TypeScript's CommonJS-specific syntax (`export =`, `import x = require(...)`) an error. "commonjs" transforms that CommonJS-specific syntax: `export =` becomes `module.exports =`, `import x = require(...)` becomes a require call, and a "use strict" directive is added; oxc has no ESM-to-CommonJS transform, so ESM import/export syntax in the sources is an error with "commonjs". Coming from tsc, map the tsconfig module manually: es2015/esnext is "esm", commonjs is "commonjs".2""
out_dir2""�
remove_comments�Drop comments from the JS and declaration outputs, keeping legal comments (`/*!`, @license, @preserve) and tooling annotations such as `/* @__PURE__ */`. Equivalent to tsc's removeComments.2False�
rewrite_extensions�Rewrite import/export specifiers that end in '.ts', '.tsx', '.mts', or '.cts' to their emitted JS extension, using oxc's rewrite_import_extensions transform. Unlike tsc's rewriteRelativeImportExtensions, any slash-containing specifier is rewritten (including bare package paths; see README limitations). Specifiers with other extensions (e.g. '.js') are left untouched.2False
root_dir2""P
source_maps8Emit a .js.map source map file alongside each JS output.2False�
source_root�The sourceRoot recorded in every JS and declaration source map. The map sources are then recorded relative to root_dir, since consumers resolve them against the sourceRoot instead of the map's location. Requires source_maps, inline_source_maps or declaration_maps. Equivalent to tsc's sourceRoot.2""x
srcsjSource files to transpile: .ts/.tsx and their module variants, plain JS, .json, or targets providing them.2[]�
strict_null_checks�Affects only decorator metadata: when False, `T | null` records T's constructor instead of Object. Set to match the tsconfig's strictNullChecks.2True�
strip_internal�Omit declarations documented with `/** @internal */` from the .d.ts outputs. JS outputs are unaffected. Equivalent to tsc's stripInternal.2False�
target�Downlevel the JS outputs to an ECMAScript target (e.g. "es2017"). Defaults to the latest ES version: syntax is left as written. es5 is not allowed: oxc cannot fully downlevel ES2015 syntax. Transforms that need a runtime helper (e.g. async functions below es2017) import it from @oxc-project/runtime, which must then be added as a runtime dependency. Declaration outputs are unaffected. Equivalent to tsc's target.2""�
use_define_for_class_fields�Class-field emit mode. "true" keeps class fields as field definitions, so a field without an initializer is defined as undefined. "false" removes fields without an initializer and assigns the others in the constructor. Unset defaults like tsc's useDefineForClassFields: "true" for target es2022 and above (including the default, esnext), "false" below. Declaration outputs are unaffected.2""�
verbatim_module_syntax�Remove only imports and exports marked `type`, so an import whose bindings are unused after type stripping is kept for its side effects. By default any such import is elided. Equivalent to tsc's verbatimModuleSyntax.2False"J
_oxc_transpiler_rule2@@aspect_rules_oxc//oxc/private:oxc_transpiler.bzl
��,
*
nameA unique name for this target. �
�
cpus�Threads the transpile action may use, reserved from the local scheduler via a cpu:<n> execution requirement. 0 (default) scales logarithmically with the number of srcs to transpile: one per decimal digit of the file count, plus one (2 at 3 files, 3 at 10), at most {}. Explicit values are still capped at one per file.20�
�
declaration_dirrDirectory for the .d.ts outputs, relative to the package. Defaults to out_dir. Equivalent to tsc's declarationDir.2""�
�
declaration_maps�Emit a .d.ts.map beside each declaration output, exposed with the declarations as types. Requires emit_dts. Equivalent to tsc's declarationMap.2False

dts_outs�
�
emit_decorator_metadata�Record design:type, design:paramtypes and design:returntype metadata for decorated members through Reflect.metadata, so a reflect-metadata polyfill must be loaded at runtime. Requires experimental_decorators. Equivalent to tsc's emitDecoratorMetadata.2False6
4
emit_dtsEmit .d.ts declaration outputs.2False-
+
emit_jsEmit JavaScript outputs.2True�
�
	emit_json�Copy .json srcs into the output layout unchanged; without it json srcs produce no outputs. Matches tsc's emit, which copies json only under resolveJsonModule â set this when the tsconfig sets that option.2False�
�
experimental_decorators�Compile decorators with the legacy (pre-TC39) transform, calling the decorate helpers imported from helpers_module. Without it decorators are emitted as written, since oxc has no transform for the standard proposal. Equivalent to tsc's experimentalDecorators.2False�
�
helpers_module�Module to import runtime helpers from, defaulting to @oxc-project/runtime. Transforms that need a helper always import it: oxc has no inline helper mode, so behavior is always like tsc's importHelpers=true. The helpers module must be a runtime dependency whenever a transform emits helper imports (none do in the default configuration).2""�
�
inline_source_maps�Embed each JS output's source map as a data URL in its sourceMappingURL comment instead of writing a .js.map. Exclusive with source_maps. Equivalent to tsc's inlineSourceMap.2False

js_outs

	json_outs�
�
jsx�JSX runtime, using oxc's values. "automatic" (default) is the automatic jsx-runtime transform. "classic" compiles JSX to React.createElement calls; providing React is the caller's concern. Coming from tsc, map the jsx spellings manually: react-jsx is "automatic", react is "classic".2""�
�
jsx_factory�Function the classic JSX runtime compiles elements to; React.createElement by default. Only applies to jsx = "classic". Equivalent to tsc's jsxFactory.2""�
�
jsx_fragment_factory�Expression the classic JSX runtime compiles fragments to; React.Fragment by default. Only applies to jsx = "classic". Equivalent to tsc's jsxFragmentFactory.2""�
�
jsx_import_source�Module the automatic JSX runtime is imported from; "react" by default. Only applies to jsx = "automatic". Equivalent to tsc's jsxImportSource.2""�
�
module�Module format of the JS outputs, using oxc's module values. "preserve" (default) keeps the input module syntax. "esm" keeps ESM syntax and makes TypeScript's CommonJS-specific syntax (`export =`, `import x = require(...)`) an error. "commonjs" transforms that CommonJS-specific syntax: `export =` becomes `module.exports =`, `import x = require(...)` becomes a require call, and a "use strict" directive is added; oxc has no ESM-to-CommonJS transform, so ESM import/export syntax in the sources is an error with "commonjs". Coming from tsc, map the tsconfig module manually: es2015/esnext is "esm", commonjs is "commonjs".2""

out_dir2""�
�
remove_comments�Drop comments from the JS and declaration outputs, keeping legal comments (`/*!`, @license, @preserve) and tooling annotations such as `/* @__PURE__ */`. Equivalent to tsc's removeComments.2False�
�
rewrite_extensions�Rewrite import/export specifiers that end in '.ts', '.tsx', '.mts', or '.cts' to their emitted JS extension, using oxc's rewrite_import_extensions transform. Unlike tsc's rewriteRelativeImportExtensions, any slash-containing specifier is rewritten (including bare package paths; see README limitations). Specifiers with other extensions (e.g. '.js') are left untouched.2False

root_dir2""R
P
source_maps8Emit a .js.map source map file alongside each JS output.2False�
�
source_root�The sourceRoot recorded in every JS and declaration source map. The map sources are then recorded relative to root_dir, since consumers resolve them against the sourceRoot instead of the map's location. Requires source_maps, inline_source_maps or declaration_maps. Equivalent to tsc's sourceRoot.2""z
x
srcsjSource files to transpile: .ts/.tsx and their module variants, plain JS, .json, or targets providing them.2[]�
�
strict_null_checks�Affects only decorator metadata: when False, `T | null` records T's constructor instead of Object. Set to match the tsconfig's strictNullChecks.2True�
�
strip_internal�Omit declarations documented with `/** @internal */` from the .d.ts outputs. JS outputs are unaffected. Equivalent to tsc's stripInternal.2False�
�
target�Downlevel the JS outputs to an ECMAScript target (e.g. "es2017"). Defaults to the latest ES version: syntax is left as written. es5 is not allowed: oxc cannot fully downlevel ES2015 syntax. Transforms that need a runtime helper (e.g. async functions below es2017) import it from @oxc-project/runtime, which must then be added as a runtime dependency. Declaration outputs are unaffected. Equivalent to tsc's target.2""�
�
use_define_for_class_fields�Class-field emit mode. "true" keeps class fields as field definitions, so a field without an initializer is defined as undefined. "false" removes fields without an initializer and assigns the others in the constructor. Unset defaults like tsc's useDefineForClassFields: "true" for target es2022 and above (including the default, esnext), "false" below. Declaration outputs are unaffected.2""�
�
verbatim_module_syntax�Remove only imports and exports marked `type`, so an import whose bindings are unused after type stripping is kept for its side effects. By default any such import is elided. Equivalent to tsc's verbatimModuleSyntax.2Falsel
//js:providers.bzlrT
$
aspect_rules_jsjsproviders.bzl
JsInfoJsInfo
-3
5�
//lib:copy_file.bzlr�

	bazel_liblibcopy_file.bzl:
COPY_FILE_TOOLCHAINSCOPY_FILE_TOOLCHAINS
(<2
copy_file_actioncopy_file_action
@P
ROOXC transpiler rule producing JavaScript and/or TypeScript declaration outputs.�m
!
aspect_rules_oxcoxcdefs.bzl�koxc_transpiler�Transpile TypeScript and JavaScript sources with OXC.

Emits JavaScript and/or isolated .d.ts declarations without typechecking.
Each source file is transformed independently into its own outputs; nothing
is bundled. Provides JsInfo like ts_project, so targets can
consume the outputs interchangeably. Output files are pre-declared at load
time, letting downstream targets reference paths such as "dist/foo.js"
directly.
"�g
�5
oxc_transpiler�Transpile TypeScript and JavaScript sources with OXC.

Emits JavaScript and/or isolated .d.ts declarations without typechecking.
Each source file is transformed independently into its own outputs; nothing
is bundled. Provides JsInfo like ts_project, so targets can
consume the outputs interchangeably. Output files are pre-declared at load
time, letting downstream targets reference paths such as "dist/foo.js"
directly.
*
nameA unique name for this target. �
cpus�Threads the transpile action may use, reserved from the local scheduler via a cpu:<n> execution requirement. 0 (default) scales logarithmically with the number of srcs to transpile: one per decimal digit of the file count, plus one (2 at 3 files, 3 at 10), at most {}. Explicit values are still capped at one per file.20�
declaration_dirrDirectory for the .d.ts outputs, relative to the package. Defaults to out_dir. Equivalent to tsc's declarationDir.2""�
declaration_maps�Emit a .d.ts.map beside each declaration output, exposed with the declarations as types. Requires emit_dts. Equivalent to tsc's declarationMap.2False
dts_outs�
emit_decorator_metadata�Record design:type, design:paramtypes and design:returntype metadata for decorated members through Reflect.metadata, so a reflect-metadata polyfill must be loaded at runtime. Requires experimental_decorators. Equivalent to tsc's emitDecoratorMetadata.2False4
emit_dtsEmit .d.ts declaration outputs.2False+
emit_jsEmit JavaScript outputs.2True�
	emit_json�Copy .json srcs into the output layout unchanged; without it json srcs produce no outputs. Matches tsc's emit, which copies json only under resolveJsonModule â set this when the tsconfig sets that option.2False�
experimental_decorators�Compile decorators with the legacy (pre-TC39) transform, calling the decorate helpers imported from helpers_module. Without it decorators are emitted as written, since oxc has no transform for the standard proposal. Equivalent to tsc's experimentalDecorators.2False�
helpers_module�Module to import runtime helpers from, defaulting to @oxc-project/runtime. Transforms that need a helper always import it: oxc has no inline helper mode, so behavior is always like tsc's importHelpers=true. The helpers module must be a runtime dependency whenever a transform emits helper imports (none do in the default configuration).2""�
inline_source_maps�Embed each JS output's source map as a data URL in its sourceMappingURL comment instead of writing a .js.map. Exclusive with source_maps. Equivalent to tsc's inlineSourceMap.2False
js_outs
	json_outs�
jsx�JSX runtime, using oxc's values. "automatic" (default) is the automatic jsx-runtime transform. "classic" compiles JSX to React.createElement calls; providing React is the caller's concern. Coming from tsc, map the jsx spellings manually: react-jsx is "automatic", react is "classic".2""�
jsx_factory�Function the classic JSX runtime compiles elements to; React.createElement by default. Only applies to jsx = "classic". Equivalent to tsc's jsxFactory.2""�
jsx_fragment_factory�Expression the classic JSX runtime compiles fragments to; React.Fragment by default. Only applies to jsx = "classic". Equivalent to tsc's jsxFragmentFactory.2""�
jsx_import_source�Module the automatic JSX runtime is imported from; "react" by default. Only applies to jsx = "automatic". Equivalent to tsc's jsxImportSource.2""�
module�Module format of the JS outputs, using oxc's module values. "preserve" (default) keeps the input module syntax. "esm" keeps ESM syntax and makes TypeScript's CommonJS-specific syntax (`export =`, `import x = require(...)`) an error. "commonjs" transforms that CommonJS-specific syntax: `export =` becomes `module.exports =`, `import x = require(...)` becomes a require call, and a "use strict" directive is added; oxc has no ESM-to-CommonJS transform, so ESM import/export syntax in the sources is an error with "commonjs". Coming from tsc, map the tsconfig module manually: es2015/esnext is "esm", commonjs is "commonjs".2""
out_dir2""�
remove_comments�Drop comments from the JS and declaration outputs, keeping legal comments (`/*!`, @license, @preserve) and tooling annotations such as `/* @__PURE__ */`. Equivalent to tsc's removeComments.2False�
rewrite_extensions�Rewrite import/export specifiers that end in '.ts', '.tsx', '.mts', or '.cts' to their emitted JS extension, using oxc's rewrite_import_extensions transform. Unlike tsc's rewriteRelativeImportExtensions, any slash-containing specifier is rewritten (including bare package paths; see README limitations). Specifiers with other extensions (e.g. '.js') are left untouched.2False
root_dir2""P
source_maps8Emit a .js.map source map file alongside each JS output.2False�
source_root�The sourceRoot recorded in every JS and declaration source map. The map sources are then recorded relative to root_dir, since consumers resolve them against the sourceRoot instead of the map's location. Requires source_maps, inline_source_maps or declaration_maps. Equivalent to tsc's sourceRoot.2""x
srcsjSource files to transpile: .ts/.tsx and their module variants, plain JS, .json, or targets providing them.2[]�
strict_null_checks�Affects only decorator metadata: when False, `T | null` records T's constructor instead of Object. Set to match the tsconfig's strictNullChecks.2True�
strip_internal�Omit declarations documented with `/** @internal */` from the .d.ts outputs. JS outputs are unaffected. Equivalent to tsc's stripInternal.2False�
target�Downlevel the JS outputs to an ECMAScript target (e.g. "es2017"). Defaults to the latest ES version: syntax is left as written. es5 is not allowed: oxc cannot fully downlevel ES2015 syntax. Transforms that need a runtime helper (e.g. async functions below es2017) import it from @oxc-project/runtime, which must then be added as a runtime dependency. Declaration outputs are unaffected. Equivalent to tsc's target.2""�
use_define_for_class_fields�Class-field emit mode. "true" keeps class fields as field definitions, so a field without an initializer is defined as undefined. "false" removes fields without an initializer and assigns the others in the constructor. Unset defaults like tsc's useDefineForClassFields: "true" for target es2022 and above (including the default, esnext), "false" below. Declaration outputs are unaffected.2""�
verbatim_module_syntax�Remove only imports and exports marked `type`, so an import whose bindings are unused after type stripping is kept for its side effects. By default any such import is elided. Equivalent to tsc's verbatimModuleSyntax.2False
��,
*
nameA unique name for this target. �
�
cpus�Threads the transpile action may use, reserved from the local scheduler via a cpu:<n> execution requirement. 0 (default) scales logarithmically with the number of srcs to transpile: one per decimal digit of the file count, plus one (2 at 3 files, 3 at 10), at most {}. Explicit values are still capped at one per file.20�
�
declaration_dirrDirectory for the .d.ts outputs, relative to the package. Defaults to out_dir. Equivalent to tsc's declarationDir.2""�
�
declaration_maps�Emit a .d.ts.map beside each declaration output, exposed with the declarations as types. Requires emit_dts. Equivalent to tsc's declarationMap.2False

dts_outs�
�
emit_decorator_metadata�Record design:type, design:paramtypes and design:returntype metadata for decorated members through Reflect.metadata, so a reflect-metadata polyfill must be loaded at runtime. Requires experimental_decorators. Equivalent to tsc's emitDecoratorMetadata.2False6
4
emit_dtsEmit .d.ts declaration outputs.2False-
+
emit_jsEmit JavaScript outputs.2True�
�
	emit_json�Copy .json srcs into the output layout unchanged; without it json srcs produce no outputs. Matches tsc's emit, which copies json only under resolveJsonModule â set this when the tsconfig sets that option.2False�
�
experimental_decorators�Compile decorators with the legacy (pre-TC39) transform, calling the decorate helpers imported from helpers_module. Without it decorators are emitted as written, since oxc has no transform for the standard proposal. Equivalent to tsc's experimentalDecorators.2False�
�
helpers_module�Module to import runtime helpers from, defaulting to @oxc-project/runtime. Transforms that need a helper always import it: oxc has no inline helper mode, so behavior is always like tsc's importHelpers=true. The helpers module must be a runtime dependency whenever a transform emits helper imports (none do in the default configuration).2""�
�
inline_source_maps�Embed each JS output's source map as a data URL in its sourceMappingURL comment instead of writing a .js.map. Exclusive with source_maps. Equivalent to tsc's inlineSourceMap.2False

js_outs

	json_outs�
�
jsx�JSX runtime, using oxc's values. "automatic" (default) is the automatic jsx-runtime transform. "classic" compiles JSX to React.createElement calls; providing React is the caller's concern. Coming from tsc, map the jsx spellings manually: react-jsx is "automatic", react is "classic".2""�
�
jsx_factory�Function the classic JSX runtime compiles elements to; React.createElement by default. Only applies to jsx = "classic". Equivalent to tsc's jsxFactory.2""�
�
jsx_fragment_factory�Expression the classic JSX runtime compiles fragments to; React.Fragment by default. Only applies to jsx = "classic". Equivalent to tsc's jsxFragmentFactory.2""�
�
jsx_import_source�Module the automatic JSX runtime is imported from; "react" by default. Only applies to jsx = "automatic". Equivalent to tsc's jsxImportSource.2""�
�
module�Module format of the JS outputs, using oxc's module values. "preserve" (default) keeps the input module syntax. "esm" keeps ESM syntax and makes TypeScript's CommonJS-specific syntax (`export =`, `import x = require(...)`) an error. "commonjs" transforms that CommonJS-specific syntax: `export =` becomes `module.exports =`, `import x = require(...)` becomes a require call, and a "use strict" directive is added; oxc has no ESM-to-CommonJS transform, so ESM import/export syntax in the sources is an error with "commonjs". Coming from tsc, map the tsconfig module manually: es2015/esnext is "esm", commonjs is "commonjs".2""

out_dir2""�
�
remove_comments�Drop comments from the JS and declaration outputs, keeping legal comments (`/*!`, @license, @preserve) and tooling annotations such as `/* @__PURE__ */`. Equivalent to tsc's removeComments.2False�
�
rewrite_extensions�Rewrite import/export specifiers that end in '.ts', '.tsx', '.mts', or '.cts' to their emitted JS extension, using oxc's rewrite_import_extensions transform. Unlike tsc's rewriteRelativeImportExtensions, any slash-containing specifier is rewritten (including bare package paths; see README limitations). Specifiers with other extensions (e.g. '.js') are left untouched.2False

root_dir2""R
P
source_maps8Emit a .js.map source map file alongside each JS output.2False�
�
source_root�The sourceRoot recorded in every JS and declaration source map. The map sources are then recorded relative to root_dir, since consumers resolve them against the sourceRoot instead of the map's location. Requires source_maps, inline_source_maps or declaration_maps. Equivalent to tsc's sourceRoot.2""z
x
srcsjSource files to transpile: .ts/.tsx and their module variants, plain JS, .json, or targets providing them.2[]�
�
strict_null_checks�Affects only decorator metadata: when False, `T | null` records T's constructor instead of Object. Set to match the tsconfig's strictNullChecks.2True�
�
strip_internal�Omit declarations documented with `/** @internal */` from the .d.ts outputs. JS outputs are unaffected. Equivalent to tsc's stripInternal.2False�
�
target�Downlevel the JS outputs to an ECMAScript target (e.g. "es2017"). Defaults to the latest ES version: syntax is left as written. es5 is not allowed: oxc cannot fully downlevel ES2015 syntax. Transforms that need a runtime helper (e.g. async functions below es2017) import it from @oxc-project/runtime, which must then be added as a runtime dependency. Declaration outputs are unaffected. Equivalent to tsc's target.2""�
�
use_define_for_class_fields�Class-field emit mode. "true" keeps class fields as field definitions, so a field without an initializer is defined as undefined. "false" removes fields without an initializer and assigns the others in the constructor. Unset defaults like tsc's useDefineForClassFields: "true" for target es2022 and above (including the default, esnext), "false" below. Declaration outputs are unaffected.2""�
�
verbatim_module_syntax�Remove only imports and exports marked `type`, so an import whose bindings are unused after type stripping is kept for its side effects. By default any such import is elided. Equivalent to tsc's verbatimModuleSyntax.2False�
 //oxc/private:oxc_transpiler.bzlrt
3
aspect_rules_oxcoxc/privateoxc_transpiler.bzl/
oxc_transpiler_oxc_transpiler
;J
^n
	:defs.bzlr_
)
aspect_tools_telemetry_reportdefs.bzl$
	TELEMETRY	TELEMETRY
4=
?(Public API for the OXC transpiler rules. 