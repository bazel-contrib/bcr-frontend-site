��
pydefs.bzl�py_pex_binary'Build a pex executable from a py_binary"�
�
py_pex_binary'Build a pex executable from a py_binary*
nameA unique name for this target.  
binaryA py_binary target M

inject_env9Environment variables to set when running the pex binary.
2{}�
inherit_path�Whether to inherit the `sys.path` (aka PYTHONPATH) of the environment that the binary runs in.

Use `false` to not inherit `sys.path`; use `fallback` to inherit `sys.path` after packaged
dependencies; and use `prefer` to inherit `sys.path` before packaged dependencies.2""J"false"J
"fallback"J"prefer",
python_shebang2"#!/usr/bin/env python3"�
python_interpreter_constraints�Python interpreter versions this PEX binary is compatible with. A list of semver strings.
The placeholder strings `{major}`, `{minor}`, `{patch}` can be used for gathering version
information from the hermetic python toolchain.2["CPython=={major}.{minor}.*"]"/
py_pex_binary//py/private:py_pex_binary.bzl8,
*
nameA unique name for this target. "
 
binaryA py_binary target O
M

inject_env9Environment variables to set when running the pex binary.
2{}�
�
inherit_path�Whether to inherit the `sys.path` (aka PYTHONPATH) of the environment that the binary runs in.

Use `false` to not inherit `sys.path`; use `fallback` to inherit `sys.path` after packaged
dependencies; and use `prefer` to inherit `sys.path` before packaged dependencies.2""J"false"J
"fallback"J"prefer".
,
python_shebang2"#!/usr/bin/env python3"�
�
python_interpreter_constraints�Python interpreter versions this PEX binary is compatible with. A list of semver strings.
The placeholder strings `{major}`, `{minor}`, `{patch}` can be used for gathering version
information from the hermetic python toolchain.2["CPython=={major}.{minor}.*"]�)py_binary_rule{Run a Python program under Bazel. Most users should use the [py_binary macro](#py_binary) instead of loading this directly."�(
�
py_binary_rule{Run a Python program under Bazel. Most users should use the [py_binary macro](#py_binary) instead of loading this directly.*
nameA unique name for this target. B
env5Environment variables to set when running the binary.
2{}�
main�Script to execute with the Python interpreter.

Must be a label pointing to a `.py` source file.
If such a label is provided, it will be honored.

If no label is provided AND there is only one `srcs` file, that `srcs` file will be used.

If there are more than one `srcs`, a file matching `{name}.py` is searched for.
This is for historical compatibility with the Bazel native `py_binary` and `rules_python`.
Relying on this behavior is STRONGLY discouraged, may produce warnings and may
be deprecated in the future.2None�
venv�The name of the Python virtual environment within which deps should be resolved.

Part of the aspect_rules_py//uv system, has no effect in rules_python's pip.2""k
python_versionSWhether to build this target and its transitive deps for a specific python version.2""�
package_collisions�The action that should be taken when a symlink collision is encountered when creating the venv.
A collision can occur when multiple packages providing the same file are installed into the venv. The possible values are:

* "error": When conflicting symlinks are found, an error is reported and venv creation halts.
* "warning": When conflicting symlinks are found, an warning is reported, however venv creation continues.
* "ignore": When conflicting symlinks are found, no message is reported and venv creation continues.2"error"J"error"J	"warning"J"ignore"}
interpreter_options`Additional options to pass to the Python interpreter in addition to -B and -I passed by rules_py2[]"
srcsPython source files.2[]�
deps>Targets that produce Python code, commonly `py_library` rules.*=
PyInfo3
PyInfo)@rules_python//python/private:py_info.bzl*<
PyVirtualInfo+
PyVirtualInfo//py/private:providers.bzl*
CcInfo
CcInfo<native>2[]�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in the `.runfiles`
folder for this binary/test. The program may optionally use the Runfiles lookup library to
locate the data files, see https://pypi.org/project/bazel-runfiles/.2[]J
imports9List of import directories to be added to the PYTHONPATH.2[]�
resolutions�Satisfy a virtual_dep with a mapping from external package name to the label of an installed package that provides it.
See virtual_deps.	2{}"'
	py_binary//py/private:py_binary.bzl8,
*
nameA unique name for this target. D
B
env5Environment variables to set when running the binary.
2{}�
�
main�Script to execute with the Python interpreter.

Must be a label pointing to a `.py` source file.
If such a label is provided, it will be honored.

If no label is provided AND there is only one `srcs` file, that `srcs` file will be used.

If there are more than one `srcs`, a file matching `{name}.py` is searched for.
This is for historical compatibility with the Bazel native `py_binary` and `rules_python`.
Relying on this behavior is STRONGLY discouraged, may produce warnings and may
be deprecated in the future.2None�
�
venv�The name of the Python virtual environment within which deps should be resolved.

Part of the aspect_rules_py//uv system, has no effect in rules_python's pip.2""m
k
python_versionSWhether to build this target and its transitive deps for a specific python version.2""�
�
package_collisions�The action that should be taken when a symlink collision is encountered when creating the venv.
A collision can occur when multiple packages providing the same file are installed into the venv. The possible values are:

* "error": When conflicting symlinks are found, an error is reported and venv creation halts.
* "warning": When conflicting symlinks are found, an warning is reported, however venv creation continues.
* "ignore": When conflicting symlinks are found, no message is reported and venv creation continues.2"error"J"error"J	"warning"J"ignore"
}
interpreter_options`Additional options to pass to the Python interpreter in addition to -B and -I passed by rules_py2[]$
"
srcsPython source files.2[]�
�
deps>Targets that produce Python code, commonly `py_library` rules.*=
PyInfo3
PyInfo)@rules_python//python/private:py_info.bzl*<
PyVirtualInfo+
PyVirtualInfo//py/private:providers.bzl*
CcInfo
CcInfo<native>2[]�
�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in the `.runfiles`
folder for this binary/test. The program may optionally use the Runfiles lookup library to
locate the data files, see https://pypi.org/project/bazel-runfiles/.2[]L
J
imports9List of import directories to be added to the PYTHONPATH.2[]�
�
resolutions�Satisfy a virtual_dep with a mapping from external package name to the label of an installed package that provides it.
See virtual_deps.	2{}�+py_test_rulewRun a Python program under Bazel. Most users should use the [py_test macro](#py_test) instead of loading this directly."�*
�
py_test_rulewRun a Python program under Bazel. Most users should use the [py_test macro](#py_test) instead of loading this directly.*
nameA unique name for this target. B
env5Environment variables to set when running the binary.
2{}�
main�Script to execute with the Python interpreter.

Must be a label pointing to a `.py` source file.
If such a label is provided, it will be honored.

If no label is provided AND there is only one `srcs` file, that `srcs` file will be used.

If there are more than one `srcs`, a file matching `{name}.py` is searched for.
This is for historical compatibility with the Bazel native `py_binary` and `rules_python`.
Relying on this behavior is STRONGLY discouraged, may produce warnings and may
be deprecated in the future.2None�
venv�The name of the Python virtual environment within which deps should be resolved.

Part of the aspect_rules_py//uv system, has no effect in rules_python's pip.2""k
python_versionSWhether to build this target and its transitive deps for a specific python version.2""�
package_collisions�The action that should be taken when a symlink collision is encountered when creating the venv.
A collision can occur when multiple packages providing the same file are installed into the venv. The possible values are:

* "error": When conflicting symlinks are found, an error is reported and venv creation halts.
* "warning": When conflicting symlinks are found, an warning is reported, however venv creation continues.
* "ignore": When conflicting symlinks are found, no message is reported and venv creation continues.2"error"J"error"J	"warning"J"ignore"}
interpreter_options`Additional options to pass to the Python interpreter in addition to -B and -I passed by rules_py2[]"
srcsPython source files.2[]�
deps>Targets that produce Python code, commonly `py_library` rules.*=
PyInfo3
PyInfo)@rules_python//python/private:py_info.bzl*<
PyVirtualInfo+
PyVirtualInfo//py/private:providers.bzl*
CcInfo
CcInfo<native>2[]�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in the `.runfiles`
folder for this binary/test. The program may optionally use the Runfiles lookup library to
locate the data files, see https://pypi.org/project/bazel-runfiles/.2[]J
imports9List of import directories to be added to the PYTHONPATH.2[]�
resolutions�Satisfy a virtual_dep with a mapping from external package name to the label of an installed package that provides it.
See virtual_deps.	2{}�
env_inherit|Specifies additional environment variables to inherit from the external environment when the test is executed by bazel test.2[]"%
py_test//py/private:py_binary.bzl08,
*
nameA unique name for this target. D
B
env5Environment variables to set when running the binary.
2{}�
�
main�Script to execute with the Python interpreter.

Must be a label pointing to a `.py` source file.
If such a label is provided, it will be honored.

If no label is provided AND there is only one `srcs` file, that `srcs` file will be used.

If there are more than one `srcs`, a file matching `{name}.py` is searched for.
This is for historical compatibility with the Bazel native `py_binary` and `rules_python`.
Relying on this behavior is STRONGLY discouraged, may produce warnings and may
be deprecated in the future.2None�
�
venv�The name of the Python virtual environment within which deps should be resolved.

Part of the aspect_rules_py//uv system, has no effect in rules_python's pip.2""m
k
python_versionSWhether to build this target and its transitive deps for a specific python version.2""�
�
package_collisions�The action that should be taken when a symlink collision is encountered when creating the venv.
A collision can occur when multiple packages providing the same file are installed into the venv. The possible values are:

* "error": When conflicting symlinks are found, an error is reported and venv creation halts.
* "warning": When conflicting symlinks are found, an warning is reported, however venv creation continues.
* "ignore": When conflicting symlinks are found, no message is reported and venv creation continues.2"error"J"error"J	"warning"J"ignore"
}
interpreter_options`Additional options to pass to the Python interpreter in addition to -B and -I passed by rules_py2[]$
"
srcsPython source files.2[]�
�
deps>Targets that produce Python code, commonly `py_library` rules.*=
PyInfo3
PyInfo)@rules_python//python/private:py_info.bzl*<
PyVirtualInfo+
PyVirtualInfo//py/private:providers.bzl*
CcInfo
CcInfo<native>2[]�
�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in the `.runfiles`
folder for this binary/test. The program may optionally use the Runfiles lookup library to
locate the data files, see https://pypi.org/project/bazel-runfiles/.2[]L
J
imports9List of import directories to be added to the PYTHONPATH.2[]�
�
resolutions�Satisfy a virtual_dep with a mapping from external package name to the label of an installed package that provides it.
See virtual_deps.	2{}�
�
env_inherit|Specifies additional environment variables to inherit from the external environment when the test is executed by bazel test.2[]�
py_library"�
�

py_library*
nameA unique name for this target. 
virtual_deps2[]"
srcsPython source files.2[]�
deps>Targets that produce Python code, commonly `py_library` rules.*=
PyInfo3
PyInfo)@rules_python//python/private:py_info.bzl*<
PyVirtualInfo+
PyVirtualInfo//py/private:providers.bzl*
CcInfo
CcInfo<native>2[]�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in the `.runfiles`
folder for this binary/test. The program may optionally use the Runfiles lookup library to
locate the data files, see https://pypi.org/project/bazel-runfiles/.2[]J
imports9List of import directories to be added to the PYTHONPATH.2[]�
resolutions�Satisfy a virtual_dep with a mapping from external package name to the label of an installed package that provides it.
See virtual_deps.	2{}")

py_library//py/private:py_library.bzl*c
DefaultInfo
PyInfo
DefaultInfo<native>3
PyInfo)@rules_python//python/private:py_info.bzl,
*
nameA unique name for this target. 

virtual_deps2[]$
"
srcsPython source files.2[]�
�
deps>Targets that produce Python code, commonly `py_library` rules.*=
PyInfo3
PyInfo)@rules_python//python/private:py_info.bzl*<
PyVirtualInfo+
PyVirtualInfo//py/private:providers.bzl*
CcInfo
CcInfo<native>2[]�
�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in the `.runfiles`
folder for this binary/test. The program may optionally use the Runfiles lookup library to
locate the data files, see https://pypi.org/project/bazel-runfiles/.2[]L
J
imports9List of import directories to be added to the PYTHONPATH.2[]�
�
resolutions�Satisfy a virtual_dep with a mapping from external package name to the label of an installed package that provides it.
See virtual_deps.	2{}�py_unpacked_wheel"�
�
py_unpacked_wheel*
nameA unique name for this target. �
src�The Wheel file, as defined by https://packaging.python.org/en/latest/specifications/binary-distribution-format/#binary-distribution-format "7
py_unpacked_wheel"//py/private:py_unpacked_wheel.bzl*=
PyInfo3
PyInfo)@rules_python//python/private:py_info.bzl,
*
nameA unique name for this target. �
�
src�The Wheel file, as defined by https://packaging.python.org/en/latest/specifications/binary-distribution-format/#binary-distribution-format �	py_pytest_mainLpy_pytest_main wraps the template rendering target and the final py_library.*�
�
py_pytest_mainL
name@The name of the runable target that updates the test entry file. (^

py_library;Use this attribute to override the default py_library rule.<rule py_library>(T
depsFA list containing the pytest library target, e.g., @pypi_pytest//:pkg.[](K
data=A list of data dependencies to pass to the py_library target.[](N
testonly:A boolean indicating if the py_library target is testonly.True(H
kwargs<The extra arguments passed to the template rendering target.(Lpy_pytest_main wraps the template rendering target and the final py_library.21
py_pytest_main//py/private:py_pytest_main.bzlN
L
name@The name of the runable target that updates the test entry file. (`
^

py_library;Use this attribute to override the default py_library rule.<rule py_library>(V
T
depsFA list containing the pytest library target, e.g., @pypi_pytest//:pkg.[](M
K
data=A list of data dependencies to pass to the py_library target.[](P
N
testonly:A boolean indicating if the py_library target is testonly.True(J
H
kwargs<The extra arguments passed to the template rendering target.(�py_venv\Build a Python virtual environment and produce a script to link it into the build directory.*�
�
py_venv
	venv_nameNone(
srcs[](

kwargs(\Build a Python virtual environment and produce a script to link it into the build directory.20
py_venv_link //py/private/py_venv:py_venv.bzl

	venv_nameNone(

srcs[](


kwargs(�py_venv_link\Build a Python virtual environment and produce a script to link it into the build directory.*�
�
py_venv_link
	venv_nameNone(
srcs[](

kwargs(\Build a Python virtual environment and produce a script to link it into the build directory.20
py_venv_link //py/private/py_venv:py_venv.bzl

	venv_nameNone(

srcs[](


kwargs(�$py_image_layer�Produce a separate tar output for each layer of a python app

> Requires `awk` to be installed on the host machine/rbe runner.

For better performance, it is recommended to split the output of a py_binary into multiple layers.
This can be done by grouping files into layers based on their path by using the `layer_groups` attribute.

The matching order for layer groups is as follows:
    1. `layer_groups` are checked first.
    2. If no match is found for `layer_groups`, the `default layer groups` are checked.
    3. Any remaining files are placed into the default layer.

The default layer groups are:
```
{
    "packages": "\.runfiles/.*/site-packages",, # contains third-party deps
    "interpreter": "\.runfiles/python.*-.*/", # contains the python interpreter
}
```
*�
�
py_image_layer!
namebase name for targets ( 
binarya py_binary target (|
rootmPath to where the layers should be rooted. If not specified, the layers will be rooted at the workspace root."/"(�
layer_groups�Additional layer groups to create. They are used to group files into layers based on their path. In the form of: ```{"<name>": "regex_to_match_against_file_paths"}```{}(�
compress�Compression algorithm to use. Default is gzip. See: https://github.com/bazel-contrib/bazel-lib/blob/main/docs/tar.md#tar_rule-compress"gzip"(�
tar_args�Additional arguments to pass to the tar rule. Default is `[]`. See: https://github.com/bazel-contrib/bazel-lib/blob/main/docs/tar.md#tar_rule-args[](�
compute_unused_inputs�Whether to compute unused inputs. Default is 1. See: https://github.com/bazel-contrib/bazel-lib/blob/main/docs/tar.md#tar_rule-compute_unused_inputs1(�
platform�The platform to use for the transition. Default is None. See: https://github.com/bazel-contrib/bazel-lib/blob/main/docs/transitions.md#platform_transition_binary-target_platformNone(�
owner�An owner uid for the uncompressed files. See mtree_mutate: https://github.com/bazel-contrib/bazel-lib/blob/main/docs/tar.md#mutating-the-tar-contentsNone(�
group�A group uid for the uncompressed files. See mtree_mutate: https://github.com/bazel-contrib/bazel-lib/blob/main/docs/tar.md#mutating-the-tar-contentsNone(E
kwargs9attribute that apply to all targets expanded by the macro(�Produce a separate tar output for each layer of a python app

> Requires `awk` to be installed on the host machine/rbe runner.

For better performance, it is recommended to split the output of a py_binary into multiple layers.
This can be done by grouping files into layers based on their path by using the `layer_groups` attribute.

The matching order for layer groups is as follows:
    1. `layer_groups` are checked first.
    2. If no match is found for `layer_groups`, the `default layer groups` are checked.
    3. Any remaining files are placed into the default layer.

The default layer groups are:
```
{
    "packages": "\.runfiles/.*/site-packages",, # contains third-party deps
    "interpreter": "\.runfiles/python.*-.*/", # contains the python interpreter
}
```
""
 A list of labels for each layer.21
py_image_layer//py/private:py_image_layer.bzl#
!
namebase name for targets ("
 
binarya py_binary target (~
|
rootmPath to where the layers should be rooted. If not specified, the layers will be rooted at the workspace root."/"(�
�
layer_groups�Additional layer groups to create. They are used to group files into layers based on their path. In the form of: ```{"<name>": "regex_to_match_against_file_paths"}```{}(�
�
compress�Compression algorithm to use. Default is gzip. See: https://github.com/bazel-contrib/bazel-lib/blob/main/docs/tar.md#tar_rule-compress"gzip"(�
�
tar_args�Additional arguments to pass to the tar rule. Default is `[]`. See: https://github.com/bazel-contrib/bazel-lib/blob/main/docs/tar.md#tar_rule-args[](�
�
compute_unused_inputs�Whether to compute unused inputs. Default is 1. See: https://github.com/bazel-contrib/bazel-lib/blob/main/docs/tar.md#tar_rule-compute_unused_inputs1(�
�
platform�The platform to use for the transition. Default is None. See: https://github.com/bazel-contrib/bazel-lib/blob/main/docs/transitions.md#platform_transition_binary-target_platformNone(�
�
owner�An owner uid for the uncompressed files. See mtree_mutate: https://github.com/bazel-contrib/bazel-lib/blob/main/docs/tar.md#mutating-the-tar-contentsNone(�
�
group�A group uid for the uncompressed files. See mtree_mutate: https://github.com/bazel-contrib/bazel-lib/blob/main/docs/tar.md#mutating-the-tar-contentsNone(G
E
kwargs9attribute that apply to all targets expanded by the macro(Hresolutions.empty*1
/
resolutions.empty2//py/private:virtual.bzl�resolutions.from_requirements*�
�
resolutions.from_requirements

base (C
requirement_fn/<function lambda from //py/private:virtual.bzl>(2.
_from_requirements//py/private:virtual.bzl


base (E
C
requirement_fn/<function lambda from //py/private:virtual.bzl>(�
	py_binary�Wrapper macro for [`py_binary_rule`](#py_binary_rule).

Creates a [py_venv](./venv.md) target to constrain the interpreter and packages used at runtime.
Users can `bazel run [name].venv` to create this virtualenv, then use it in the editor or other tools.
*�
�
	py_binary
nameName of the rule. ("
srcsPython source files.[](�
main�Entry point.
Like rules_python, this is treated as a suffix of a file that should appear among the srcs.
If absent, then `[name].py` is tried. As a final fallback, if the srcs has a single file,
that is used as the main.None(<
kwargs0additional named parameters to `py_binary_rule`.(�Wrapper macro for [`py_binary_rule`](#py_binary_rule).

Creates a [py_venv](./venv.md) target to constrain the interpreter and packages used at runtime.
Users can `bazel run [name].venv` to create this virtualenv, then use it in the editor or other tools.
2
	py_binary//py:defs.bzl

nameName of the rule. ($
"
srcsPython source files.[](�
�
main�Entry point.
Like rules_python, this is treated as a suffix of a file that should appear among the srcs.
If absent, then `[name].py` is tried. As a final fallback, if the srcs has a single file,
that is used as the main.None(>
<
kwargs0additional named parameters to `py_binary_rule`.(�
py_testcIdentical to [py_binary](./py_binary.md), but produces a target that can be used with `bazel test`.*�

�
py_test
nameName of the rule. ("
srcsPython source files.[](�
main�Entry point.
Like rules_python, this is treated as a suffix of a file that should appear among the srcs.
If absent, then `[name].py` is tried. As a final fallback, if the srcs has a single file,
that is used as the main.None(�
pytest_main�If set, generate a [py_pytest_main](#py_pytest_main) script and use it as the main.
The deps should include the pytest package (as well as the coverage package if desired).False(<
kwargs0additional named parameters to `py_binary_rule`.(cIdentical to [py_binary](./py_binary.md), but produces a target that can be used with `bazel test`.2
py_test//py:defs.bzl

nameName of the rule. ($
"
srcsPython source files.[](�
�
main�Entry point.
Like rules_python, this is treated as a suffix of a file that should appear among the srcs.
If absent, then `[name].py` is tried. As a final fallback, if the srcs has a single file,
that is used as the main.None(�
�
pytest_main�If set, generate a [py_pytest_main](#py_pytest_main) script and use it as the main.
The deps should include the pytest package (as well as the coverage package if desired).False(>
<
kwargs0additional named parameters to `py_binary_rule`.(�	Re-implementations of [py_binary](https://bazel.build/reference/be/python#py_binary)
and [py_test](https://bazel.build/reference/be/python#py_test)

## Choosing the Python version

The `python_version` attribute must refer to a python toolchain version
which has been registered in the WORKSPACE or MODULE.bazel file.

When using WORKSPACE, this may look like this:

```starlark
load("@rules_python//python:repositories.bzl", "py_repositories", "python_register_toolchains")

python_register_toolchains(
    name = "python_toolchain_3_8",
    python_version = "3.8.12",
    # setting set_python_version_constraint makes it so that only matches py_* rule
    # which has this exact version set in the `python_version` attribute.
    set_python_version_constraint = True,
)

# It's important to register the default toolchain last it will match any py_* target.
python_register_toolchains(
    name = "python_toolchain",
    python_version = "3.9",
)
```

Configuring for MODULE.bazel may look like this:

```starlark
python = use_extension("@rules_python//python/extensions:python.bzl", "python")
python.toolchain(python_version = "3.8.12", is_default = False)
python.toolchain(python_version = "3.9", is_default = True)
```�
pyextensions.bzl�py_toolsJ�
�
py_tools�
rules_py_tools�
name�Base name for generated repositories, allowing more than one toolchain to be registered.
Overriding the default is only permitted in the root module.2"rules_py_tools"c
is_prereleaseJTrue iff there are no pre-built tool binaries for this version of rules_py2True"//py:extensions.bzl�
�
rules_py_tools�
name�Base name for generated repositories, allowing more than one toolchain to be registered.
Overriding the default is only permitted in the root module.2"rules_py_tools"c
is_prereleaseJTrue iff there are no pre-built tool binaries for this version of rules_py2True�
�
name�Base name for generated repositories, allowing more than one toolchain to be registered.
Overriding the default is only permitted in the root module.2"rules_py_tools"e
c
is_prereleaseJTrue iff there are no pre-built tool binaries for this version of rules_py2True(Module Extensions used from MODULE.bazel�
pytoolchains.bzl�'register_autodetecting_python_toolchain�Registers a Python toolchain that will auto detect the location of Python that can be used with rules_py.

The autodetecting Python toolchain replaces the automatically registered one under bazel, and correctly handles the
Python virtual environment indirection created by rules_py. However it is recommended to instead use one of the prebuilt
Python interpreter toolchains from rules_python, rather than rely on the the correct Python binary being present on the host.*�
�
'register_autodetecting_python_toolchain

name (�Registers a Python toolchain that will auto detect the location of Python that can be used with rules_py.

The autodetecting Python toolchain replaces the automatically registered one under bazel, and correctly handles the
Python virtual environment indirection created by rules_py. However it is recommended to instead use one of the prebuilt
Python interpreter toolchains from rules_python, rather than rely on the the correct Python binary being present on the host.2S
'register_autodetecting_python_toolchain(//py/private/toolchain:autodetecting.bzl


name (�rules_py_toolchainsLCreate a downloaded toolchain for every tool under every supported platform.*�
�
rules_py_toolchains?
name#prefix used in created repositories"rules_py_tools"(o
register[whether to call the register_toolchains, should be True for WORKSPACE and False for bzlmod.True(c
is_prereleaseJTrue iff there are no pre-built tool binaries for this version of rules_pyTrue(LCreate a downloaded toolchain for every tool under every supported platform.2*
rules_py_toolchains//py:toolchains.bzlA
?
name#prefix used in created repositories"rules_py_tools"(q
o
register[whether to call the register_toolchains, should be True for WORKSPACE and False for bzlmod.True(e
c
is_prereleaseJTrue iff there are no pre-built tool binaries for this version of rules_pyTrue(Declare toolchains�
py/unstabledefs.bzl_py_venv*R
B
py_venv

kwargs(2+
py_venv //py/private/py_venv:py_venv.bzl


kwargs(�py_venv_link\Build a Python virtual environment and produce a script to link it into the build directory.*�
�
py_venv_link
	venv_nameNone(
srcs[](

kwargs(\Build a Python virtual environment and produce a script to link it into the build directory.20
py_venv_link //py/private/py_venv:py_venv.bzl

	venv_nameNone(

srcs[](


kwargs(tpy_venv_binary*`
P
py_venv_binary

kwargs(22
py_venv_binary //py/private/py_venv:py_venv.bzl


kwargs(npy_venv_test*\
L
py_venv_test

kwargs(20
py_venv_test //py/private/py_venv:py_venv.bzl


kwargs(rPreview features.

Unstable rules and preview machinery.
No promises are made about compatibility across releases. 