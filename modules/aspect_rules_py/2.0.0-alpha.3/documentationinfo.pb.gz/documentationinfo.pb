�
pycurrent_py_toolchain.bzl�current_py_toolchain�Exposes the resolved Python 3 toolchain as Make variables.

After toolchain resolution, this rule provides `$(PYTHON3)` and
`$(PYTHON3_ROOTPATH)` for Make variable expansion in rules like
`genrule` and `bazel_env`.

An instance is automatically available at
`@python_interpreters//:current_py_toolchain` when using the
`python_interpreters` module extension.

Example usage with `genrule`:

```starlark
genrule(
    name = "run_python",
    outs = ["output.txt"],
    cmd = "$(PYTHON3) -c 'print(42)' > $@",
    toolchains = ["@python_interpreters//:current_py_toolchain"],
)
```

Example usage with `bazel_env`:

```starlark
bazel_env(
    name = "bazel_env",
    toolchains = {
        "python": "@python_interpreters//:current_py_toolchain",
    },
    tools = {
        "python": "$(PYTHON3)",
    },
)
```"�
�
current_py_toolchain�Exposes the resolved Python 3 toolchain as Make variables.

After toolchain resolution, this rule provides `$(PYTHON3)` and
`$(PYTHON3_ROOTPATH)` for Make variable expansion in rules like
`genrule` and `bazel_env`.

An instance is automatically available at
`@python_interpreters//:current_py_toolchain` when using the
`python_interpreters` module extension.

Example usage with `genrule`:

```starlark
genrule(
    name = "run_python",
    outs = ["output.txt"],
    cmd = "$(PYTHON3) -c 'print(42)' > $@",
    toolchains = ["@python_interpreters//:current_py_toolchain"],
)
```

Example usage with `bazel_env`:

```starlark
bazel_env(
    name = "bazel_env",
    toolchains = {
        "python": "@python_interpreters//:current_py_toolchain",
    },
    tools = {
        "python": "$(PYTHON3)",
    },
)
```*
nameA unique name for this target. "I
current_py_toolchain1//py/private/interpreter:current_py_toolchain.bzl,
*
nameA unique name for this target. 1Public entry point for current_py_toolchain rule.��
pydefs.bzl�current_py_toolchain�Exposes the resolved Python 3 toolchain as Make variables.

After toolchain resolution, this rule provides `$(PYTHON3)` and
`$(PYTHON3_ROOTPATH)` for Make variable expansion in rules like
`genrule` and `bazel_env`.

An instance is automatically available at
`@python_interpreters//:current_py_toolchain` when using the
`python_interpreters` module extension.

Example usage with `genrule`:

```starlark
genrule(
    name = "run_python",
    outs = ["output.txt"],
    cmd = "$(PYTHON3) -c 'print(42)' > $@",
    toolchains = ["@python_interpreters//:current_py_toolchain"],
)
```

Example usage with `bazel_env`:

```starlark
bazel_env(
    name = "bazel_env",
    toolchains = {
        "python": "@python_interpreters//:current_py_toolchain",
    },
    tools = {
        "python": "$(PYTHON3)",
    },
)
```"�
�
current_py_toolchain�Exposes the resolved Python 3 toolchain as Make variables.

After toolchain resolution, this rule provides `$(PYTHON3)` and
`$(PYTHON3_ROOTPATH)` for Make variable expansion in rules like
`genrule` and `bazel_env`.

An instance is automatically available at
`@python_interpreters//:current_py_toolchain` when using the
`python_interpreters` module extension.

Example usage with `genrule`:

```starlark
genrule(
    name = "run_python",
    outs = ["output.txt"],
    cmd = "$(PYTHON3) -c 'print(42)' > $@",
    toolchains = ["@python_interpreters//:current_py_toolchain"],
)
```

Example usage with `bazel_env`:

```starlark
bazel_env(
    name = "bazel_env",
    toolchains = {
        "python": "@python_interpreters//:current_py_toolchain",
    },
    tools = {
        "python": "$(PYTHON3)",
    },
)
```*
nameA unique name for this target. "I
current_py_toolchain1//py/private/interpreter:current_py_toolchain.bzl,
*
nameA unique name for this target. �py_pex_binary'Build a pex executable from a py_binary"�
�
py_pex_binary'Build a pex executable from a py_binary*
nameA unique name for this target.  
binaryA py_binary target M

inject_env9Environment variables to set when running the pex binary.
2{}�
inherit_path�Whether to inherit the `sys.path` (aka PYTHONPATH) of the environment that the binary runs in.

Use `false` to not inherit `sys.path`; use `fallback` to inherit `sys.path` after packaged
dependencies; and use `prefer` to inherit `sys.path` before packaged dependencies.2""J"false"J
"fallback"J"prefer",
python_shebang2"#!/usr/bin/env python3"�
python_interpreter_constraints�Python interpreter versions this PEX binary is compatible with. A list of semver strings.
The placeholder strings `{major}`, `{minor}`, `{patch}` can be used for gathering version
information from the hermetic python toolchain.2["CPython=={major}.{minor}.*"]"/
py_pex_binary//py/private:py_pex_binary.bzl8,
*
nameA unique name for this target. "
 
binaryA py_binary target O
M

inject_env9Environment variables to set when running the pex binary.
2{}�
�
inherit_path�Whether to inherit the `sys.path` (aka PYTHONPATH) of the environment that the binary runs in.

Use `false` to not inherit `sys.path`; use `fallback` to inherit `sys.path` after packaged
dependencies; and use `prefer` to inherit `sys.path` before packaged dependencies.2""J"false"J
"fallback"J"prefer".
,
python_shebang2"#!/usr/bin/env python3"�
�
python_interpreter_constraints�Python interpreter versions this PEX binary is compatible with. A list of semver strings.
The placeholder strings `{major}`, `{minor}`, `{patch}` can be used for gathering version
information from the hermetic python toolchain.2["CPython=={major}.{minor}.*"]�
py_library"�
�

py_library*
nameA unique name for this target. 
virtual_deps2[]"
srcsPython source files.2[]�
deps>Targets that produce Python code, commonly `py_library` rules.*=
PyInfo3
PyInfo)@rules_python//python/private:py_info.bzl*<
PyVirtualInfo+
PyVirtualInfo//py/private:providers.bzl*
CcInfo
CcInfo<native>2[]�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in the `.runfiles`
folder for this binary/test. The program may optionally use the Runfiles lookup library to
locate the data files, see https://pypi.org/project/bazel-runfiles/.2[]J
imports9List of import directories to be added to the PYTHONPATH.2[]�
resolutions�Satisfy a virtual_dep with a mapping from external package name to the label of an installed package that provides it.
See virtual_deps.	2{}")

py_library//py/private:py_library.bzl*c
DefaultInfo
PyInfo
DefaultInfo<native>3
PyInfo)@rules_python//python/private:py_info.bzl,
*
nameA unique name for this target. 

virtual_deps2[]$
"
srcsPython source files.2[]�
�
deps>Targets that produce Python code, commonly `py_library` rules.*=
PyInfo3
PyInfo)@rules_python//python/private:py_info.bzl*<
PyVirtualInfo+
PyVirtualInfo//py/private:providers.bzl*
CcInfo
CcInfo<native>2[]�
�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in the `.runfiles`
folder for this binary/test. The program may optionally use the Runfiles lookup library to
locate the data files, see https://pypi.org/project/bazel-runfiles/.2[]L
J
imports9List of import directories to be added to the PYTHONPATH.2[]�
�
resolutions�Satisfy a virtual_dep with a mapping from external package name to the label of an installed package that provides it.
See virtual_deps.	2{}�py_unpacked_wheel"�
�
py_unpacked_wheel*
nameA unique name for this target. �
src�The Wheel file, as defined by https://packaging.python.org/en/latest/specifications/binary-distribution-format/#binary-distribution-format �

top_levels�Names of the top-level packages / modules / *.dist-info directories the wheel installs into its site-packages.

When set, the target emits a `PyWheelsInfo` provider describing this wheel.
Downstream rules (such as `py_binary`) can consume this to assemble a merged
`site-packages/` tree via `ctx.actions.symlink` instead of relying on `.pth`
entries. If left empty (the default), the target behaves as before — other
rules fall back to `.pth`-based import resolution.

Typically populated by the `uv` wheel-install repo rule. Hand-written
`py_unpacked_wheel` targets may populate this to opt into symlink-based
venv assembly.2[]�
console_scripts�Console-script entry points declared by this wheel, in the form `"name=module:func"`.

`py_binary` consumes these via `PyWheelsInfo` to generate executable
wrappers under `<venv>/bin/<name>`. Typically populated from the wheel's
`*.dist-info/entry_points.txt` `[console_scripts]` section.2[]�
namespace_top_levels�Subset of `top_levels` that are PEP 420 namespace packages.

See the equivalent attribute on the `whl_install` rule for the full
story; short version: names listed here suppress collision errors when
multiple wheels claim the same top-level, because Python's namespace
machinery is meant to merge their contributions.2[]"7
py_unpacked_wheel"//py/private:py_unpacked_wheel.bzl*=
PyInfo3
PyInfo)@rules_python//python/private:py_info.bzl,
*
nameA unique name for this target. �
�
src�The Wheel file, as defined by https://packaging.python.org/en/latest/specifications/binary-distribution-format/#binary-distribution-format �
�

top_levels�Names of the top-level packages / modules / *.dist-info directories the wheel installs into its site-packages.

When set, the target emits a `PyWheelsInfo` provider describing this wheel.
Downstream rules (such as `py_binary`) can consume this to assemble a merged
`site-packages/` tree via `ctx.actions.symlink` instead of relying on `.pth`
entries. If left empty (the default), the target behaves as before — other
rules fall back to `.pth`-based import resolution.

Typically populated by the `uv` wheel-install repo rule. Hand-written
`py_unpacked_wheel` targets may populate this to opt into symlink-based
venv assembly.2[]�
�
console_scripts�Console-script entry points declared by this wheel, in the form `"name=module:func"`.

`py_binary` consumes these via `PyWheelsInfo` to generate executable
wrappers under `<venv>/bin/<name>`. Typically populated from the wheel's
`*.dist-info/entry_points.txt` `[console_scripts]` section.2[]�
�
namespace_top_levels�Subset of `top_levels` that are PEP 420 namespace packages.

See the equivalent attribute on the `whl_install` rule for the full
story; short version: names listed here suppress collision errors when
multiple wheels claim the same top-level, because Python's namespace
machinery is meant to merge their contributions.2[]�py_layer_tier"�
�	
py_layer_tier*
nameA unique name for this target. �
groups�Maps @pip//package → group name (whole pip package), @pip//package:glob → group name (pip subpath split), or //some/first_party:lib → group name (first-party PyInfo target). First-party main-repo labels may be written as //pkg:name; fully-qualified forms like @@//pkg:name are also accepted. A pip package may appear as a whole-package key OR with subpath globs, not both.
2{}�
compression�Maps group name → [algorithm, level] for pip-derived layers. Applies to the whole-group tar, each subpath-split tar, and the multi-member merged tar — anything routed through py_layer_tier.groups. Example: {"heavy_pkgs": ["zstd", "1"]}. Untouched groups default to gzip -6.2{}�
interpreter_group�When non-empty, the Python interpreter runfiles resolved from the binary's py toolchain are emitted as their own layer under this name instead of being bundled into the default source layer.2"":
root(Root path in the image. Default: '/app'.2"/app"f
strip_prefixPPrefix stripped from source file paths. Empty means use the binary's short_path.2"""0
py_layer_tier//py/private:py_image_layer.bzl*E
PyLayerTierInfo2
PyLayerTierInfo//py/private:py_image_layer.bzl,
*
nameA unique name for this target. �
�
groups�Maps @pip//package → group name (whole pip package), @pip//package:glob → group name (pip subpath split), or //some/first_party:lib → group name (first-party PyInfo target). First-party main-repo labels may be written as //pkg:name; fully-qualified forms like @@//pkg:name are also accepted. A pip package may appear as a whole-package key OR with subpath globs, not both.
2{}�
�
compression�Maps group name → [algorithm, level] for pip-derived layers. Applies to the whole-group tar, each subpath-split tar, and the multi-member merged tar — anything routed through py_layer_tier.groups. Example: {"heavy_pkgs": ["zstd", "1"]}. Untouched groups default to gzip -6.2{}�
�
interpreter_group�When non-empty, the Python interpreter runfiles resolved from the binary's py toolchain are emitted as their own layer under this name instead of being bundled into the default source layer.2""<
:
root(Root path in the image. Default: '/app'.2"/app"h
f
strip_prefixPPrefix stripped from source file paths. Empty means use the binary's short_path.2""�	py_pytest_mainLpy_pytest_main wraps the template rendering target and the final py_library.*�
�
py_pytest_mainL
name@The name of the runable target that updates the test entry file. (^

py_library;Use this attribute to override the default py_library rule.<rule py_library>(T
depsFA list containing the pytest library target, e.g., @pypi_pytest//:pkg.[](K
data=A list of data dependencies to pass to the py_library target.[](N
testonly:A boolean indicating if the py_library target is testonly.True(H
kwargs<The extra arguments passed to the template rendering target.(Lpy_pytest_main wraps the template rendering target and the final py_library.21
py_pytest_main//py/private:py_pytest_main.bzlN
L
name@The name of the runable target that updates the test entry file. (`
^

py_library;Use this attribute to override the default py_library rule.<rule py_library>(V
T
depsFA list containing the pytest library target, e.g., @pypi_pytest//:pkg.[](M
K
data=A list of data dependencies to pass to the py_library target.[](P
N
testonly:A boolean indicating if the py_library target is testonly.True(J
H
kwargs<The extra arguments passed to the template rendering target.(_py_venv*R
B
py_venv

kwargs(2+
py_venv //py/private/py_venv:py_venv.bzl


kwargs(�py_venv_link�Emit a runnable target that materialises `venv` into the workspace.

`bazel run :<name>` creates a symlink in `$BUILD_WORKING_DIRECTORY`
(typically the workspace root) that points at `venv`'s materialised
venv tree in bazel-bin, so IDEs / LSPs can resolve interpreter and
site-packages via a stable workspace-local path.
*�
�
py_venv_link�
name�Runnable target name. `bazel run :<name>` materialises
the symlink; pick something like `<something>.venv` by
convention so `python.defaultInterpreterPath` readers
recognise it, but any label works. (�
venv�Label of a `py_venv` target to link. Typically the
`:<binary_name>.venv` target auto-emitted by
`py_binary(expose_venv = True, ...)`, or a standalone
`py_venv` shared across many binaries. (�
	link_name~Workspace-relative basename for the created
symlink. Defaults to a safely-escaped version of the
target's package + venv name.None(4
kwargs(Forwarded to the underlying `py_binary`.(�Emit a runnable target that materialises `venv` into the workspace.

`bazel run :<name>` creates a symlink in `$BUILD_WORKING_DIRECTORY`
(typically the workspace root) that points at `venv`'s materialised
venv tree in bazel-bin, so IDEs / LSPs can resolve interpreter and
site-packages via a stable workspace-local path.
20
py_venv_link //py/private/py_venv:py_venv.bzl�
�
name�Runnable target name. `bazel run :<name>` materialises
the symlink; pick something like `<something>.venv` by
convention so `python.defaultInterpreterPath` readers
recognise it, but any label works. (�
�
venv�Label of a `py_venv` target to link. Typically the
`:<binary_name>.venv` target auto-emitted by
`py_binary(expose_venv = True, ...)`, or a standalone
`py_venv` shared across many binaries. (�
�
	link_name~Workspace-relative basename for the created
symlink. Defaults to a safely-escaped version of the
target's package + venv name.None(6
4
kwargs(Forwarded to the underlying `py_binary`.(�#py_image_layer�Create OCI-compatible tars from a py_binary or py_venv target.

Pip-package grouping + compression is resolved from the `//py:layer_tier`
label_flag. Override globally with `--//py:layer_tier=//path:custom_tier`,
or pin a tier to a specific rule via the `py_layer_tier` attr below.

## Output layers

  1. Non-pip deps listed in `groups` → one rule-created tar per group.
  2. First-party py_library targets matched by `py_layer_tier.groups` → one
     rule-created tar per group (aggregated across all matched targets in the
     binary's dep closure).
  3. Solo-group and subpath-split pip tars — built by `_layer_aspect` at each pip
     target's own namespace; globally shared across every rule using that package.
  4. Multi-member merged tars — one per group, built by `_merge_aspect` at the
     binary's namespace from the closure-filtered union of member install_dirs.
  5. Ungrouped pip packages → one squashed rule-created tar.
  6. Remaining first-party Python source files → the "default" layer.
*�
�
py_image_layer)
nameName of the generated target. (,
binaryA py_venv or py_binary target. (�
groups�Maps a NON-PIP dep label to a group name. Each gets its own rule-created
tar. All pip-package grouping (whole-package, subpath, multi-member) belongs
in py_layer_tier — subpath glob keys passed here fail loudly.{}(�
group_execution_requirementsxMaps a group name to execution requirement strings.
The group name "packages" applies to the squashed ungrouped-pip tar.{}(�
group_compress_levels�Maps a group name to a gzip compression level (1-9) for
rule-created tars (non-pip deps, squashed ungrouped pip tar, source). Default 6.
Does NOT apply to aspect-created pip tars (configure via the py_layer_tier target).{}(N
warn_remote_cache_threshold_mb%Threshold for large package warnings.200(J
warn_layer_count0Warn when total layers exceed this. Default: 90.90(/
platformPlatform transition target.None(�

layer_tier�Optional py_layer_tier target pinned for this rule. Sets the
`@aspect_rules_py//py:layer_tier` label_flag via the rule transition,
overriding any command-line value for this rule's subgraph.None($
kwargsForwarded to inner rule.(�Create OCI-compatible tars from a py_binary or py_venv target.

Pip-package grouping + compression is resolved from the `//py:layer_tier`
label_flag. Override globally with `--//py:layer_tier=//path:custom_tier`,
or pin a tier to a specific rule via the `py_layer_tier` attr below.

## Output layers

  1. Non-pip deps listed in `groups` → one rule-created tar per group.
  2. First-party py_library targets matched by `py_layer_tier.groups` → one
     rule-created tar per group (aggregated across all matched targets in the
     binary's dep closure).
  3. Solo-group and subpath-split pip tars — built by `_layer_aspect` at each pip
     target's own namespace; globally shared across every rule using that package.
  4. Multi-member merged tars — one per group, built by `_merge_aspect` at the
     binary's namespace from the closure-filtered union of member install_dirs.
  5. Ungrouped pip packages → one squashed rule-created tar.
  6. Remaining first-party Python source files → the "default" layer.
21
py_image_layer//py/private:py_image_layer.bzl+
)
nameName of the generated target. (.
,
binaryA py_venv or py_binary target. (�
�
groups�Maps a NON-PIP dep label to a group name. Each gets its own rule-created
tar. All pip-package grouping (whole-package, subpath, multi-member) belongs
in py_layer_tier — subpath glob keys passed here fail loudly.{}(�
�
group_execution_requirementsxMaps a group name to execution requirement strings.
The group name "packages" applies to the squashed ungrouped-pip tar.{}(�
�
group_compress_levels�Maps a group name to a gzip compression level (1-9) for
rule-created tars (non-pip deps, squashed ungrouped pip tar, source). Default 6.
Does NOT apply to aspect-created pip tars (configure via the py_layer_tier target).{}(P
N
warn_remote_cache_threshold_mb%Threshold for large package warnings.200(L
J
warn_layer_count0Warn when total layers exceed this. Default: 90.90(1
/
platformPlatform transition target.None(�
�

layer_tier�Optional py_layer_tier target pinned for this rule. Sets the
`@aspect_rules_py//py:layer_tier` label_flag via the rule transition,
overriding any command-line value for this rule's subgraph.None(&
$
kwargsForwarded to inner rule.(Hresolutions.empty*1
/
resolutions.empty2//py/private:virtual.bzl�resolutions.from_requirements*�
�
resolutions.from_requirements

base (C
requirement_fn/<function lambda from //py/private:virtual.bzl>(2.
_from_requirements//py/private:virtual.bzl


base (E
C
requirement_fn/<function lambda from //py/private:virtual.bzl>(�#	py_binary�Build and run a Python binary.

Splits the call into a sibling `py_venv` (which carries srcs / deps
/ imports / virtual_deps / resolutions / package_collisions /
include_*_site_packages / interpreter_options) plus a thin launcher
rule that exec's that venv's interpreter. Set `expose_venv = True`
to make the sibling a first-class `:{name}.venv` target — runnable
(`bazel run :{name}.venv` drops into the hermetic interpreter) and
pairable with `py_venv_link` for IDE integration. For the common
case where you want both the venv target *and* an IDE-pointable
workspace symlink in one step, set `expose_venv_link = True`.
*�
�
	py_binary
nameName of the rule. ("
srcsPython source files.[](�
main�Entry point.
Like rules_python, this is treated as a suffix of a file that should appear among the srcs.
If absent, then `[name].py` is tried. As a final fallback, if the srcs has a single file,
that is used as the main.

Note: the fallback runs at macro-evaluation time and operates
on label strings, not resolved files — it cannot inspect a
generated target's output basename. If `main` would resolve
to a file produced by another rule (e.g. a `genrule` whose
output happens to be `<name>.py`), the macro can't see that
and you must pass `main =` explicitly.None(�
kwargs�additional named parameters forwarded to the
underlying rule and the sibling py_venv. Two extras are
handled by this macro:

* `expose_venv` (bool, default `False`) — when `True`, emit
  a sibling `:{name}.venv` py_venv carrying all venv-shaping
  attrs (deps, imports, package_collisions,
  include_*_site_packages, interpreter_options). The `.venv`
  target is runnable (`bazel run :{name}.venv` drops into
  the hermetic interpreter).
* `expose_venv_link` (bool, default `False`) — when `True`,
  additionally emit a `:{name}.venv_link` py_venv_link.
  `bazel run :{name}.venv_link` materialises a
  workspace-local symlink to the venv tree, suitable for an
  IDE's interpreter setting. Implies `expose_venv = True`;
  passing `expose_venv = False, expose_venv_link = True`
  explicitly is rejected with a clear error. Equivalent to
  declaring an explicit
  `py_venv_link(name = "{name}.venv_link", venv = ":{name}.venv")`
  alongside the binary.(�Build and run a Python binary.

Splits the call into a sibling `py_venv` (which carries srcs / deps
/ imports / virtual_deps / resolutions / package_collisions /
include_*_site_packages / interpreter_options) plus a thin launcher
rule that exec's that venv's interpreter. Set `expose_venv = True`
to make the sibling a first-class `:{name}.venv` target — runnable
(`bazel run :{name}.venv` drops into the hermetic interpreter) and
pairable with `py_venv_link` for IDE integration. For the common
case where you want both the venv target *and* an IDE-pointable
workspace symlink in one step, set `expose_venv_link = True`.
2
	py_binary//py:defs.bzl

nameName of the rule. ($
"
srcsPython source files.[](�
�
main�Entry point.
Like rules_python, this is treated as a suffix of a file that should appear among the srcs.
If absent, then `[name].py` is tried. As a final fallback, if the srcs has a single file,
that is used as the main.

Note: the fallback runs at macro-evaluation time and operates
on label strings, not resolved files — it cannot inspect a
generated target's output basename. If `main` would resolve
to a file produced by another rule (e.g. a `genrule` whose
output happens to be `<name>.py`), the macro can't see that
and you must pass `main =` explicitly.None(�
�
kwargs�additional named parameters forwarded to the
underlying rule and the sibling py_venv. Two extras are
handled by this macro:

* `expose_venv` (bool, default `False`) — when `True`, emit
  a sibling `:{name}.venv` py_venv carrying all venv-shaping
  attrs (deps, imports, package_collisions,
  include_*_site_packages, interpreter_options). The `.venv`
  target is runnable (`bazel run :{name}.venv` drops into
  the hermetic interpreter).
* `expose_venv_link` (bool, default `False`) — when `True`,
  additionally emit a `:{name}.venv_link` py_venv_link.
  `bazel run :{name}.venv_link` materialises a
  workspace-local symlink to the venv tree, suitable for an
  IDE's interpreter setting. Implies `expose_venv = True`;
  passing `expose_venv = False, expose_venv_link = True`
  explicitly is rejected with a clear error. Equivalent to
  declaring an explicit
  `py_venv_link(name = "{name}.venv_link", venv = ":{name}.venv")`
  alongside the binary.(�py_testcIdentical to [py_binary](./py_binary.md), but produces a target that can be used with `bazel test`.*�

�
py_test
nameName of the rule. ("
srcsPython source files.[](�
main�Entry point.
Like rules_python, this is treated as a suffix of a file that should appear among the srcs.
If absent, then `[name].py` is tried. As a final fallback, if the srcs has a single file,
that is used as the main.None(�
pytest_main�If True, use a shared pytest entry point as the main.
The deps should include the pytest package (as well as the coverage package if desired).False(a
kwargsUadditional named parameters forwarded to the
underlying rule and the sibling py_venv.(cIdentical to [py_binary](./py_binary.md), but produces a target that can be used with `bazel test`.2
py_test//py:defs.bzl

nameName of the rule. ($
"
srcsPython source files.[](�
�
main�Entry point.
Like rules_python, this is treated as a suffix of a file that should appear among the srcs.
If absent, then `[name].py` is tried. As a final fallback, if the srcs has a single file,
that is used as the main.None(�
�
pytest_main�If True, use a shared pytest entry point as the main.
The deps should include the pytest package (as well as the coverage package if desired).False(c
a
kwargsUadditional named parameters forwarded to the
underlying rule and the sibling py_venv.(�PyLayerTierInfoKLayer tier for py_image_layer: how pip packages are grouped and compressed.2�

�
PyLayerTierInfoKLayer tier for py_image_layer: how pip packages are grouped and compressed.G
whole_groups7dict[str, str] — normalized pip label → group name.^
subpath_groupsLdict[str, dict[str, list[str]]] — label → {group_name: [glob_patterns]}.J
compression;dict[str, list[str]] — group name → [algorithm, level].W
multi_member_groups@dict[str, True] — group names with 2+ members in whole_groups.V
interpreter_groupAstr — group name for the Python interpreter layer; '' disables.5
root-str — root path in the image (e.g. '/app').b
strip_prefixRstr — prefix stripped from source file paths; empty means use binary short_path."2
PyLayerTierInfo//py/private:py_image_layer.bzlI
G
whole_groups7dict[str, str] — normalized pip label → group name.`
^
subpath_groupsLdict[str, dict[str, list[str]]] — label → {group_name: [glob_patterns]}.L
J
compression;dict[str, list[str]] — group name → [algorithm, level].Y
W
multi_member_groups@dict[str, True] — group names with 2+ members in whole_groups.X
V
interpreter_groupAstr — group name for the Python interpreter layer; '' disables.7
5
root-str — root path in the image (e.g. '/app').d
b
strip_prefixRstr — prefix stripped from source file paths; empty means use binary short_path.�Re-implementations of [py_binary](https://bazel.build/reference/be/python#py_binary)
and [py_test](https://bazel.build/reference/be/python#py_test)

## Choosing the Python version

The `python_version` attribute must refer to a python toolchain version
which has been registered in the `MODULE.bazel` file, e.g.:

```starlark
python = use_extension("@rules_python//python/extensions:python.bzl", "python")
python.toolchain(python_version = "3.8.12", is_default = False)
python.toolchain(python_version = "3.9", is_default = True)
```�W
pyextensions.bzl�Rpython_interpretersJ�Q
�
python_interpreters�
	configureQConfigure the set of python-build-standalone releases to search for interpreters.�
base_url�Base URL for downloading release assets. Defaults to the official PBS GitHub releases URL.
Override this to fetch from a mirror or fork, e.g.
"https://github.com/my-org/python-build-standalone/releases/download".
The URL should point to the directory containing release date directories,
such that {base_url}/{date}/SHA256SUMS is a valid path.

Only honored from the root module.2""�
releases�List of python-build-standalone release dates to search for interpreters,
e.g. ["20260303", "20241002"]. Newer releases are preferred when multiple
contain the same Python minor version.

The special value "latest" resolves to the newest release via the GitHub
releases API. This makes the extension non-reproducible: Bazel will
re-evaluate it on every invocation rather than caching the result.

See https://github.com/astral-sh/python-build-standalone/releases for
available releases.

Only honored from the root module. Non-root modules may include this tag
without error, but it will be silently ignored. �

local�Register a local (non-PBS) Python interpreter as a toolchain.

Exactly one of interpreter_path or env must be set. The interpreter is
probed for version info at repository-rule time. If the interpreter is
unavailable (path missing, env var unset), the toolchain is registered
but inactive — it will never match during toolchain resolution.

Local toolchains are registered before PBS toolchains, giving them higher
priority. Use config_settings to gate activation on a custom flag.

Only honored from the root module.e
config_settingsLAdditional config_setting labels required for this toolchain to be selected.2[]�
env�Environment variable pointing to a Python prefix directory (e.g. "VIRTUAL_ENV").
The interpreter is resolved as $ENV/bin/python3 (or $ENV/Scripts/python.exe on Windows).
If the variable is unset, the toolchain is registered but inactive (never matches).2""V
exec_compatible_with8Additional exec platform constraints for this toolchain.2[]G
interpreter_path-Absolute path to a Python interpreter binary.2""�
python_version�Override the detected Python version. If omitted, the interpreter is probed
at repository-rule evaluation time to determine its version.2""Z
target_compatible_with:Additional target platform constraints for this toolchain.2[]�	
	toolchain�
config_settings�Additional config_setting labels that must match for this toolchain to be selected.
Use this to gate a toolchain on a custom flag, e.g.
["@//:use_hermetic_python"]. The settings are added to the toolchain's
target_settings alongside the version and platform constraints.

Only honored from the root module.2[]�
exec_compatible_with�Additional exec platform constraints appended to each platform variant's
exec_compatible_with list.

Only honored from the root module.2[]9

is_default"Only honored from the root module.2False�
pre_release�Allow pre-release versions (alpha, beta, rc) for this toolchain.

By default, only final release versions are provisioned. Set this to True
to allow pre-release versions like 3.15.0a6 or 3.14.0b1. This is useful
for testing against upcoming Python versions that have no stable release yet.

Only honored from the root module.2Falsex
python_versionbPython version to provision, e.g. '3.11' or '3.11.14'. The newest available patch version is used. �
target_compatible_with�Additional target platform constraints appended to each platform variant's
target_compatible_with list.

Only honored from the root module.2[]"(&//py/private/interpreter:extension.bzl�
�
	configureQConfigure the set of python-build-standalone releases to search for interpreters.�
base_url�Base URL for downloading release assets. Defaults to the official PBS GitHub releases URL.
Override this to fetch from a mirror or fork, e.g.
"https://github.com/my-org/python-build-standalone/releases/download".
The URL should point to the directory containing release date directories,
such that {base_url}/{date}/SHA256SUMS is a valid path.

Only honored from the root module.2""�
releases�List of python-build-standalone release dates to search for interpreters,
e.g. ["20260303", "20241002"]. Newer releases are preferred when multiple
contain the same Python minor version.

The special value "latest" resolves to the newest release via the GitHub
releases API. This makes the extension non-reproducible: Bazel will
re-evaluate it on every invocation rather than caching the result.

See https://github.com/astral-sh/python-build-standalone/releases for
available releases.

Only honored from the root module. Non-root modules may include this tag
without error, but it will be silently ignored. �
�
base_url�Base URL for downloading release assets. Defaults to the official PBS GitHub releases URL.
Override this to fetch from a mirror or fork, e.g.
"https://github.com/my-org/python-build-standalone/releases/download".
The URL should point to the directory containing release date directories,
such that {base_url}/{date}/SHA256SUMS is a valid path.

Only honored from the root module.2""�
�
releases�List of python-build-standalone release dates to search for interpreters,
e.g. ["20260303", "20241002"]. Newer releases are preferred when multiple
contain the same Python minor version.

The special value "latest" resolves to the newest release via the GitHub
releases API. This makes the extension non-reproducible: Bazel will
re-evaluate it on every invocation rather than caching the result.

See https://github.com/astral-sh/python-build-standalone/releases for
available releases.

Only honored from the root module. Non-root modules may include this tag
without error, but it will be silently ignored. �
�

local�Register a local (non-PBS) Python interpreter as a toolchain.

Exactly one of interpreter_path or env must be set. The interpreter is
probed for version info at repository-rule time. If the interpreter is
unavailable (path missing, env var unset), the toolchain is registered
but inactive — it will never match during toolchain resolution.

Local toolchains are registered before PBS toolchains, giving them higher
priority. Use config_settings to gate activation on a custom flag.

Only honored from the root module.e
config_settingsLAdditional config_setting labels required for this toolchain to be selected.2[]�
env�Environment variable pointing to a Python prefix directory (e.g. "VIRTUAL_ENV").
The interpreter is resolved as $ENV/bin/python3 (or $ENV/Scripts/python.exe on Windows).
If the variable is unset, the toolchain is registered but inactive (never matches).2""V
exec_compatible_with8Additional exec platform constraints for this toolchain.2[]G
interpreter_path-Absolute path to a Python interpreter binary.2""�
python_version�Override the detected Python version. If omitted, the interpreter is probed
at repository-rule evaluation time to determine its version.2""Z
target_compatible_with:Additional target platform constraints for this toolchain.2[]g
e
config_settingsLAdditional config_setting labels required for this toolchain to be selected.2[]�
�
env�Environment variable pointing to a Python prefix directory (e.g. "VIRTUAL_ENV").
The interpreter is resolved as $ENV/bin/python3 (or $ENV/Scripts/python.exe on Windows).
If the variable is unset, the toolchain is registered but inactive (never matches).2""X
V
exec_compatible_with8Additional exec platform constraints for this toolchain.2[]I
G
interpreter_path-Absolute path to a Python interpreter binary.2""�
�
python_version�Override the detected Python version. If omitted, the interpreter is probed
at repository-rule evaluation time to determine its version.2""\
Z
target_compatible_with:Additional target platform constraints for this toolchain.2[]�
�	
	toolchain�
config_settings�Additional config_setting labels that must match for this toolchain to be selected.
Use this to gate a toolchain on a custom flag, e.g.
["@//:use_hermetic_python"]. The settings are added to the toolchain's
target_settings alongside the version and platform constraints.

Only honored from the root module.2[]�
exec_compatible_with�Additional exec platform constraints appended to each platform variant's
exec_compatible_with list.

Only honored from the root module.2[]9

is_default"Only honored from the root module.2False�
pre_release�Allow pre-release versions (alpha, beta, rc) for this toolchain.

By default, only final release versions are provisioned. Set this to True
to allow pre-release versions like 3.15.0a6 or 3.14.0b1. This is useful
for testing against upcoming Python versions that have no stable release yet.

Only honored from the root module.2Falsex
python_versionbPython version to provision, e.g. '3.11' or '3.11.14'. The newest available patch version is used. �
target_compatible_with�Additional target platform constraints appended to each platform variant's
target_compatible_with list.

Only honored from the root module.2[]�
�
config_settings�Additional config_setting labels that must match for this toolchain to be selected.
Use this to gate a toolchain on a custom flag, e.g.
["@//:use_hermetic_python"]. The settings are added to the toolchain's
target_settings alongside the version and platform constraints.

Only honored from the root module.2[]�
�
exec_compatible_with�Additional exec platform constraints appended to each platform variant's
exec_compatible_with list.

Only honored from the root module.2[];
9

is_default"Only honored from the root module.2False�
�
pre_release�Allow pre-release versions (alpha, beta, rc) for this toolchain.

By default, only final release versions are provisioned. Set this to True
to allow pre-release versions like 3.15.0a6 or 3.14.0b1. This is useful
for testing against upcoming Python versions that have no stable release yet.

Only honored from the root module.2Falsez
x
python_versionbPython version to provision, e.g. '3.11' or '3.11.14'. The newest available patch version is used. �
�
target_compatible_with�Additional target platform constraints appended to each platform variant's
target_compatible_with list.

Only honored from the root module.2[]�py_toolsJ�
�
py_tools�
rules_py_tools�
name�Base name for generated repositories, allowing more than one toolchain to be registered.
Overriding the default is only permitted in the root module.2"rules_py_tools""//py:extensions.bzl�
�
rules_py_tools�
name�Base name for generated repositories, allowing more than one toolchain to be registered.
Overriding the default is only permitted in the root module.2"rules_py_tools"�
�
name�Base name for generated repositories, allowing more than one toolchain to be registered.
Overriding the default is only permitted in the root module.2"rules_py_tools"(Module Extensions used from MODULE.bazel�
pytoolchains.bzl�rules_py_toolchains+Create toolchain repositories for rules_py.*�
�
rules_py_toolchains?
name#prefix used in created repositories"rules_py_tools"(8
kwargs,unused, retained for backwards compatibility(+Create toolchain repositories for rules_py.2*
rules_py_toolchains//py:toolchains.bzlA
?
name#prefix used in created repositories"rules_py_tools"(:
8
kwargs,unused, retained for backwards compatibility(Declare toolchains 