�
pycurrent_py_toolchain.bzl�current_py_toolchain�Exposes the resolved Python 3 toolchain as Make variables.

After toolchain resolution, this rule provides `$(PYTHON3)` and
`$(PYTHON3_ROOTPATH)` for Make variable expansion in rules like
`genrule` and `bazel_env`.

An instance is automatically available at
`@python_interpreters//:current_py_toolchain` when using the
`python_interpreters` module extension.

Example usage with `genrule`:

```starlark
genrule(
    name = "run_python",
    outs = ["output.txt"],
    cmd = "$(PYTHON3) -c 'print(42)' > $@",
    toolchains = ["@python_interpreters//:current_py_toolchain"],
)
```

Example usage with `bazel_env`:

```starlark
bazel_env(
    name = "bazel_env",
    toolchains = {
        "python": "@python_interpreters//:current_py_toolchain",
    },
    tools = {
        "python": "$(PYTHON3)",
    },
)
```"�
�
current_py_toolchain�Exposes the resolved Python 3 toolchain as Make variables.

After toolchain resolution, this rule provides `$(PYTHON3)` and
`$(PYTHON3_ROOTPATH)` for Make variable expansion in rules like
`genrule` and `bazel_env`.

An instance is automatically available at
`@python_interpreters//:current_py_toolchain` when using the
`python_interpreters` module extension.

Example usage with `genrule`:

```starlark
genrule(
    name = "run_python",
    outs = ["output.txt"],
    cmd = "$(PYTHON3) -c 'print(42)' > $@",
    toolchains = ["@python_interpreters//:current_py_toolchain"],
)
```

Example usage with `bazel_env`:

```starlark
bazel_env(
    name = "bazel_env",
    toolchains = {
        "python": "@python_interpreters//:current_py_toolchain",
    },
    tools = {
        "python": "$(PYTHON3)",
    },
)
```*
nameA unique name for this target. "I
current_py_toolchain1//py/private/interpreter:current_py_toolchain.bzl,
*
nameA unique name for this target. 1Public entry point for current_py_toolchain rule.��
pydefs.bzl�current_py_toolchain�Exposes the resolved Python 3 toolchain as Make variables.

After toolchain resolution, this rule provides `$(PYTHON3)` and
`$(PYTHON3_ROOTPATH)` for Make variable expansion in rules like
`genrule` and `bazel_env`.

An instance is automatically available at
`@python_interpreters//:current_py_toolchain` when using the
`python_interpreters` module extension.

Example usage with `genrule`:

```starlark
genrule(
    name = "run_python",
    outs = ["output.txt"],
    cmd = "$(PYTHON3) -c 'print(42)' > $@",
    toolchains = ["@python_interpreters//:current_py_toolchain"],
)
```

Example usage with `bazel_env`:

```starlark
bazel_env(
    name = "bazel_env",
    toolchains = {
        "python": "@python_interpreters//:current_py_toolchain",
    },
    tools = {
        "python": "$(PYTHON3)",
    },
)
```"�
�
current_py_toolchain�Exposes the resolved Python 3 toolchain as Make variables.

After toolchain resolution, this rule provides `$(PYTHON3)` and
`$(PYTHON3_ROOTPATH)` for Make variable expansion in rules like
`genrule` and `bazel_env`.

An instance is automatically available at
`@python_interpreters//:current_py_toolchain` when using the
`python_interpreters` module extension.

Example usage with `genrule`:

```starlark
genrule(
    name = "run_python",
    outs = ["output.txt"],
    cmd = "$(PYTHON3) -c 'print(42)' > $@",
    toolchains = ["@python_interpreters//:current_py_toolchain"],
)
```

Example usage with `bazel_env`:

```starlark
bazel_env(
    name = "bazel_env",
    toolchains = {
        "python": "@python_interpreters//:current_py_toolchain",
    },
    tools = {
        "python": "$(PYTHON3)",
    },
)
```*
nameA unique name for this target. "I
current_py_toolchain1//py/private/interpreter:current_py_toolchain.bzl,
*
nameA unique name for this target. �whl_filegroup�Extract files matching a regular expression from a wheel file.

An empty pattern will match all files.

Example usage:
```starlark
load("@rules_cc//cc:cc_library.bzl", "cc_library")
load("@rules_python//python:pip.bzl", "whl_filegroup")

whl_filegroup(
    name = "numpy_includes",
    pattern = "numpy/core/include/numpy",
    whl = "@pypi//numpy:whl",
)

cc_library(
    name = "numpy_headers",
    hdrs = [":numpy_includes"],
    includes = ["numpy_includes/numpy/core/include"],
    deps = ["@rules_python//python/cc:current_py_cc_headers"],
)

```

:::{seealso}

The `:extracted_whl_files` target, which is a filegroup of all the files
from the already extracted whl file.
:::"�

�
whl_filegroup�Extract files matching a regular expression from a wheel file.

An empty pattern will match all files.

Example usage:
```starlark
load("@rules_cc//cc:cc_library.bzl", "cc_library")
load("@rules_python//python:pip.bzl", "whl_filegroup")

whl_filegroup(
    name = "numpy_includes",
    pattern = "numpy/core/include/numpy",
    whl = "@pypi//numpy:whl",
)

cc_library(
    name = "numpy_headers",
    hdrs = [":numpy_includes"],
    includes = ["numpy_includes/numpy/core/include"],
    deps = ["@rules_python//python/cc:current_py_cc_headers"],
)

```

:::{seealso}

The `:extracted_whl_files` target, which is a filegroup of all the files
from the already extracted whl file.
:::*
nameA unique name for this target. O
pattern>Only file paths matching this regex pattern will be extracted.2""Z
runfilesEWhether to include the output TreeArtifact in this target's runfiles.2False+
whl The wheel to extract files from. "N
whl_filegroup=@rules_python//python/private/whl_filegroup:whl_filegroup.bzl,
*
nameA unique name for this target. Q
O
pattern>Only file paths matching this regex pattern will be extracted.2""\
Z
runfilesEWhether to include the output TreeArtifact in this target's runfiles.2False-
+
whl The wheel to extract files from. �py_pex_binary'Build a pex executable from a py_binary"�
�
py_pex_binary'Build a pex executable from a py_binary*
nameA unique name for this target.  
binaryA py_binary target M

inject_env9Environment variables to set when running the pex binary.
2{}�
inherit_path�Whether to inherit the `sys.path` (aka PYTHONPATH) of the environment that the binary runs in.

Use `false` to not inherit `sys.path`; use `fallback` to inherit `sys.path` after packaged
dependencies; and use `prefer` to inherit `sys.path` before packaged dependencies.2""J"false"J
"fallback"J"prefer",
python_shebang2"#!/usr/bin/env python3"�
python_interpreter_constraints�Python interpreter versions this PEX binary is compatible with. A list of semver strings.
The placeholder strings `{major}`, `{minor}`, `{patch}` can be used for gathering version
information from the hermetic python toolchain.2["CPython=={major}.{minor}.*"]"/
py_pex_binary//py/private:py_pex_binary.bzl8,
*
nameA unique name for this target. "
 
binaryA py_binary target O
M

inject_env9Environment variables to set when running the pex binary.
2{}�
�
inherit_path�Whether to inherit the `sys.path` (aka PYTHONPATH) of the environment that the binary runs in.

Use `false` to not inherit `sys.path`; use `fallback` to inherit `sys.path` after packaged
dependencies; and use `prefer` to inherit `sys.path` before packaged dependencies.2""J"false"J
"fallback"J"prefer".
,
python_shebang2"#!/usr/bin/env python3"�
�
python_interpreter_constraints�Python interpreter versions this PEX binary is compatible with. A list of semver strings.
The placeholder strings `{major}`, `{minor}`, `{patch}` can be used for gathering version
information from the hermetic python toolchain.2["CPython=={major}.{minor}.*"]�
py_library"�
�

py_library*
nameA unique name for this target. 
virtual_deps2[]"
srcsPython source files.2[]�
deps>Targets that produce Python code, commonly `py_library` rules.*1
PyInfo'
RulesPyInfo//py/private:py_info.bzl*=
PyInfo3
PyInfo)@rules_python//python/private:py_info.bzl*
CcInfo
CcInfo<native>2[]�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in the `.runfiles`
folder for this binary/test. The program may optionally use the Runfiles lookup library to
locate the data files, see https://pypi.org/project/bazel-runfiles/.
Data is analyzed in the inherited caller configuration. Put artifacts
that must match the terminal's Python environment in `deps`.2[]J
imports9List of import directories to be added to the PYTHONPATH.2[]�
resolutions�Satisfy a virtual_dep with a mapping from external package name to the label of an installed package that provides it.
See virtual_deps.	2{}")

py_library//py/private:py_library.bzl*W
DefaultInfo
PyInfo
DefaultInfo<native>'
RulesPyInfo//py/private:py_info.bzl,
*
nameA unique name for this target. 

virtual_deps2[]$
"
srcsPython source files.2[]�
�
deps>Targets that produce Python code, commonly `py_library` rules.*1
PyInfo'
RulesPyInfo//py/private:py_info.bzl*=
PyInfo3
PyInfo)@rules_python//python/private:py_info.bzl*
CcInfo
CcInfo<native>2[]�
�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in the `.runfiles`
folder for this binary/test. The program may optionally use the Runfiles lookup library to
locate the data files, see https://pypi.org/project/bazel-runfiles/.
Data is analyzed in the inherited caller configuration. Put artifacts
that must match the terminal's Python environment in `deps`.2[]L
J
imports9List of import directories to be added to the PYTHONPATH.2[]�
�
resolutions�Satisfy a virtual_dep with a mapping from external package name to the label of an installed package that provides it.
See virtual_deps.	2{}�py_unpacked_wheel"�
�
py_unpacked_wheel*
nameA unique name for this target. �
src�The Wheel file, as defined by https://packaging.python.org/en/latest/specifications/binary-distribution-format/#binary-distribution-format �

top_levels�Complete list of immediate entries the wheel installs into site-packages.

When set, downstream rules can assemble a merged `site-packages/` tree via
`ctx.actions.symlink` instead of relying on `.pth` entries. The list must
include packages, modules, `.pth` files, and `*.dist-info` directories. If left
empty (the default), other rules preserve the complete wheel root and fall back
to `.pth`-based import resolution.

Typically populated by the `uv` wheel-install repo rule. Hand-written
`py_unpacked_wheel` targets may populate this to opt into symlink-based
venv assembly.2[]�
console_scripts�Console-script entry points declared by this wheel, in the form `"name=module:func"`.

`py_binary` consumes these via `PyWheelsInfo` to generate executable
wrappers under `<venv>/bin/<name>`. Typically populated from the wheel's
`*.dist-info/entry_points.txt` `[console_scripts]` section.2[]�
namespace_top_levels�Subset of `top_levels` that are PEP 420 namespace packages.

See the equivalent attribute on the `whl_install` rule for the full
story; short version: names listed here suppress collision errors when
multiple wheels claim the same top-level, because Python's namespace
machinery is meant to merge their contributions.2[]�
namespace_entries�Concrete entries this wheel installs beneath its `namespace_top_levels`.

See the equivalent attribute on the `whl_install` rule for the full
story; short version: `/`-joined paths like `jaraco/functools` that
let venv assembly materialise a merged namespace directory out of
per-entry symlinks, so static tools that inspect `site-packages/`
directly see the package. When empty, namespace merging falls back to
`.pth`-based resolution (runtime-only).2[]"7
py_unpacked_wheel"//py/private:py_unpacked_wheel.bzl*1
PyInfo'
RulesPyInfo//py/private:py_info.bzl,
*
nameA unique name for this target. �
�
src�The Wheel file, as defined by https://packaging.python.org/en/latest/specifications/binary-distribution-format/#binary-distribution-format �
�

top_levels�Complete list of immediate entries the wheel installs into site-packages.

When set, downstream rules can assemble a merged `site-packages/` tree via
`ctx.actions.symlink` instead of relying on `.pth` entries. The list must
include packages, modules, `.pth` files, and `*.dist-info` directories. If left
empty (the default), other rules preserve the complete wheel root and fall back
to `.pth`-based import resolution.

Typically populated by the `uv` wheel-install repo rule. Hand-written
`py_unpacked_wheel` targets may populate this to opt into symlink-based
venv assembly.2[]�
�
console_scripts�Console-script entry points declared by this wheel, in the form `"name=module:func"`.

`py_binary` consumes these via `PyWheelsInfo` to generate executable
wrappers under `<venv>/bin/<name>`. Typically populated from the wheel's
`*.dist-info/entry_points.txt` `[console_scripts]` section.2[]�
�
namespace_top_levels�Subset of `top_levels` that are PEP 420 namespace packages.

See the equivalent attribute on the `whl_install` rule for the full
story; short version: names listed here suppress collision errors when
multiple wheels claim the same top-level, because Python's namespace
machinery is meant to merge their contributions.2[]�
�
namespace_entries�Concrete entries this wheel installs beneath its `namespace_top_levels`.

See the equivalent attribute on the `whl_install` rule for the full
story; short version: `/`-joined paths like `jaraco/functools` that
let venv assembly materialise a merged namespace directory out of
per-entry symlinks, so static tools that inspect `site-packages/`
directly see the package. When empty, namespace merging falls back to
`.pth`-based resolution (runtime-only).2[]�py_layer_tier"�
�	
py_layer_tier*
nameA unique name for this target. �
groups�Maps @pip//package → group name (whole pip package), @pip//package:glob → group name (pip subpath split), or //some/first_party:lib → group name (first-party PyInfo target). First-party main-repo labels may be written as //pkg:name; fully-qualified forms like @@//pkg:name are also accepted. A pip package may appear as a whole-package key OR with subpath globs, not both.
2{}�
compression�Maps group name → [algorithm, level] for pip-derived layers. Applies to the whole-group tar, each subpath-split tar, and the multi-member merged tar — anything routed through py_layer_tier.groups. Example: {"heavy_pkgs": ["zstd", "1"]}. Untouched groups default to gzip -6.2{}�
interpreter_group�When non-empty, the Python interpreter runfiles resolved from the binary's py toolchain are emitted as their own layer under this name instead of being bundled into the default source layer.2"":
root(Root path in the image. Default: '/app'.2"/app"f
strip_prefixPPrefix stripped from source file paths. Empty means use the binary's short_path.2"""0
py_layer_tier//py/private:py_image_layer.bzl*E
PyLayerTierInfo2
PyLayerTierInfo//py/private:py_image_layer.bzl,
*
nameA unique name for this target. �
�
groups�Maps @pip//package → group name (whole pip package), @pip//package:glob → group name (pip subpath split), or //some/first_party:lib → group name (first-party PyInfo target). First-party main-repo labels may be written as //pkg:name; fully-qualified forms like @@//pkg:name are also accepted. A pip package may appear as a whole-package key OR with subpath globs, not both.
2{}�
�
compression�Maps group name → [algorithm, level] for pip-derived layers. Applies to the whole-group tar, each subpath-split tar, and the multi-member merged tar — anything routed through py_layer_tier.groups. Example: {"heavy_pkgs": ["zstd", "1"]}. Untouched groups default to gzip -6.2{}�
�
interpreter_group�When non-empty, the Python interpreter runfiles resolved from the binary's py toolchain are emitted as their own layer under this name instead of being bundled into the default source layer.2""<
:
root(Root path in the image. Default: '/app'.2"/app"h
f
strip_prefixPPrefix stripped from source file paths. Empty means use the binary's short_path.2""�,py_wheel�Builds a Python Wheel.

Wheels are Python distribution format defined in https://www.python.org/dev/peps/pep-0427/.

This macro packages a set of targets into a single wheel.
It wraps the [py_wheel rule](#py_wheel_rule).

Currently only pure-python wheels are supported.

:::{versionchanged} 1.4.0
From now on, an empty `requires_file` is treated as if it were omitted, resulting in a valid
`METADATA` file.
:::

Examples:

```python
# Package some specific py_library targets, without their dependencies
py_wheel(
    name = "minimal_with_py_library",
    # Package data. We're building "example_minimal_library-0.0.1-py3-none-any.whl"
    distribution = "example_minimal_library",
    python_tag = "py3",
    version = "0.0.1",
    deps = [
        "//examples/wheel/lib:module_with_data",
        "//examples/wheel/lib:simple_module",
    ],
)

# Use py_package to collect all transitive dependencies of a target,
# selecting just the files within a specific python package.
py_package(
    name = "example_pkg",
    # Only include these Python packages.
    packages = ["examples.wheel"],
    deps = [":main"],
)

py_wheel(
    name = "minimal_with_py_package",
    # Package data. We're building "example_minimal_package-0.0.1-py3-none-any.whl"
    distribution = "example_minimal_package",
    python_tag = "py3",
    version = "0.0.1",
    deps = [":example_pkg"],
)
```

To publish the wheel to PyPI, the twine package is required and it is installed
by default on `bzlmod` setups. On legacy `WORKSPACE`, `rules_python`
doesn't provide `twine` itself
(see https://github.com/bazel-contrib/rules_python/issues/1016), but
you can install it with `pip_parse`, just like we do any other dependencies.

Once you've installed twine, you can pass its label to the `twine`
attribute of this macro, to get a "[name].publish" target.

Example:

```python
py_wheel(
    name = "my_wheel",
    twine = "@publish_deps//twine",
    ...
)
```

Now you can run a command like the following, which publishes to https://test.pypi.org/

```sh
% TWINE_USERNAME=__token__ TWINE_PASSWORD=pypi-*** \
    bazel run --stamp --embed_label=1.2.4 -- \
    //path/to:my_wheel.publish --repository testpypi
```
*�
�
py_wheel*
nameA unique name for this target. (T
twineCA label of the external location of the py_library target for twineNone(}
twine_binary>A label of the external location of a binary target for twine.+Label("@rules_python//tools/publish:twine")(�
publish_args�arguments passed to twine, e.g. ["--repository-url", "https://pypi.my.org/simple/"].
These are subject to make var expansion, as with the `args` attribute.
Note that you can also pass additional args to the bazel run command as in the example above.[]([
kwargsOother named parameters passed to the underlying [py_wheel rule](#py_wheel_rule)(�Builds a Python Wheel.

Wheels are Python distribution format defined in https://www.python.org/dev/peps/pep-0427/.

This macro packages a set of targets into a single wheel.
It wraps the [py_wheel rule](#py_wheel_rule).

Currently only pure-python wheels are supported.

:::{versionchanged} 1.4.0
From now on, an empty `requires_file` is treated as if it were omitted, resulting in a valid
`METADATA` file.
:::

Examples:

```python
# Package some specific py_library targets, without their dependencies
py_wheel(
    name = "minimal_with_py_library",
    # Package data. We're building "example_minimal_library-0.0.1-py3-none-any.whl"
    distribution = "example_minimal_library",
    python_tag = "py3",
    version = "0.0.1",
    deps = [
        "//examples/wheel/lib:module_with_data",
        "//examples/wheel/lib:simple_module",
    ],
)

# Use py_package to collect all transitive dependencies of a target,
# selecting just the files within a specific python package.
py_package(
    name = "example_pkg",
    # Only include these Python packages.
    packages = ["examples.wheel"],
    deps = [":main"],
)

py_wheel(
    name = "minimal_with_py_package",
    # Package data. We're building "example_minimal_package-0.0.1-py3-none-any.whl"
    distribution = "example_minimal_package",
    python_tag = "py3",
    version = "0.0.1",
    deps = [":example_pkg"],
)
```

To publish the wheel to PyPI, the twine package is required and it is installed
by default on `bzlmod` setups. On legacy `WORKSPACE`, `rules_python`
doesn't provide `twine` itself
(see https://github.com/bazel-contrib/rules_python/issues/1016), but
you can install it with `pip_parse`, just like we do any other dependencies.

Once you've installed twine, you can pass its label to the `twine`
attribute of this macro, to get a "[name].publish" target.

Example:

```python
py_wheel(
    name = "my_wheel",
    twine = "@publish_deps//twine",
    ...
)
```

Now you can run a command like the following, which publishes to https://test.pypi.org/

```sh
% TWINE_USERNAME=__token__ TWINE_PASSWORD=pypi-*** \
    bazel run --stamp --embed_label=1.2.4 -- \
    //path/to:my_wheel.publish --repository testpypi
```
2/
py_wheel#@rules_python//python:packaging.bzl,
*
nameA unique name for this target. (V
T
twineCA label of the external location of the py_library target for twineNone(
}
twine_binary>A label of the external location of a binary target for twine.+Label("@rules_python//tools/publish:twine")(�
�
publish_args�arguments passed to twine, e.g. ["--repository-url", "https://pypi.my.org/simple/"].
These are subject to make var expansion, as with the `args` attribute.
Note that you can also pass additional args to the bazel run command as in the example above.[](]
[
kwargsOother named parameters passed to the underlying [py_wheel rule](#py_wheel_rule)(�
py_runtime�Creates an executable Python program.

This is the public macro wrapping the underlying rule. Args are forwarded
on as-is unless otherwise specified. See
{rule}`py_runtime`
for detailed attribute documentation.

This macro affects the following args:
* `python_version`: cannot be `PY2`
* `srcs_version`: cannot be `PY2` or `PY2ONLY`
* `tags`: May have special marker values added, if not already present.
*�
�

py_runtime=
attrs2Rule attributes forwarded onto {rule}`py_runtime`.(�Creates an executable Python program.

This is the public macro wrapping the underlying rule. Args are forwarded
on as-is unless otherwise specified. See
{rule}`py_runtime`
for detailed attribute documentation.

This macro affects the following args:
* `python_version`: cannot be `PY2`
* `srcs_version`: cannot be `PY2` or `PY2ONLY`
* `tags`: May have special marker values added, if not already present.
22

py_runtime$@rules_python//python:py_runtime.bzl?
=
attrs2Rule attributes forwarded onto {rule}`py_runtime`.(�py_runtime_pair�	A toolchain rule for Python.

This is a macro around the underlying {rule}`py_runtime_pair` rule.

This used to wrap up to two Python runtimes, one for Python 2 and one for Python 3.
However, Python 2 is no longer supported, so it now only wraps a single Python 3
runtime.

Usually the wrapped runtimes are declared using the `py_runtime` rule, but any
rule returning a `PyRuntimeInfo` provider may be used.

This rule returns a `platform_common.ToolchainInfo` provider with the following
schema:

```python
platform_common.ToolchainInfo(
    py2_runtime = None,
    py3_runtime = <PyRuntimeInfo or None>,
)
```

Example usage:

```python
# In your BUILD file...

load("@rules_python//python:py_runtime.bzl", "py_runtime")
load("@rules_python//python:py_runtime_pair.bzl", "py_runtime_pair")

py_runtime(
    name = "my_py3_runtime",
    interpreter_path = "/system/python3",
    python_version = "PY3",
)

py_runtime_pair(
    name = "my_py_runtime_pair",
    py3_runtime = ":my_py3_runtime",
)

toolchain(
    name = "my_toolchain",
    target_compatible_with = <...>,
    toolchain = ":my_py_runtime_pair",
    toolchain_type = "@rules_python//python:toolchain_type",
)
```

```python
# In your WORKSPACE...

register_toolchains("//my_pkg:my_toolchain")
```
*�
�
py_runtime_pair'
namestr, the name of the target ([
py2_runtimeDoptional Label; must be unset or None; an error is raised
otherwise.None(I
py3_runtime2Label; a target with `PyRuntimeInfo` for Python 3.None(2
attrs'Extra attrs passed onto the native rule(�	A toolchain rule for Python.

This is a macro around the underlying {rule}`py_runtime_pair` rule.

This used to wrap up to two Python runtimes, one for Python 2 and one for Python 3.
However, Python 2 is no longer supported, so it now only wraps a single Python 3
runtime.

Usually the wrapped runtimes are declared using the `py_runtime` rule, but any
rule returning a `PyRuntimeInfo` provider may be used.

This rule returns a `platform_common.ToolchainInfo` provider with the following
schema:

```python
platform_common.ToolchainInfo(
    py2_runtime = None,
    py3_runtime = <PyRuntimeInfo or None>,
)
```

Example usage:

```python
# In your BUILD file...

load("@rules_python//python:py_runtime.bzl", "py_runtime")
load("@rules_python//python:py_runtime_pair.bzl", "py_runtime_pair")

py_runtime(
    name = "my_py3_runtime",
    interpreter_path = "/system/python3",
    python_version = "PY3",
)

py_runtime_pair(
    name = "my_py_runtime_pair",
    py3_runtime = ":my_py3_runtime",
)

toolchain(
    name = "my_toolchain",
    target_compatible_with = <...>,
    toolchain = ":my_py_runtime_pair",
    toolchain_type = "@rules_python//python:toolchain_type",
)
```

```python
# In your WORKSPACE...

register_toolchains("//my_pkg:my_toolchain")
```
2<
py_runtime_pair)@rules_python//python:py_runtime_pair.bzl)
'
namestr, the name of the target (]
[
py2_runtimeDoptional Label; must be unset or None; an error is raised
otherwise.None(K
I
py3_runtime2Label; a target with `PyRuntimeInfo` for Python 3.None(4
2
attrs'Extra attrs passed onto the native rule(�py_pytest_main�py_pytest_main wraps the template rendering target and the final py_library.

Low-level escape hatch: prefer [py_pytest_test](#py_pytest_test) for pytest
suites. Use this only for hand-written or wrapped entrypoints (e.g. exposing
an importable `main()` for custom setup/teardown around pytest).
*�

�
py_pytest_mainL
name@The name of the runable target that updates the test entry file. (^

py_library;Use this attribute to override the default py_library rule.<rule py_library>(T
depsFA list containing the pytest library target, e.g., @pypi_pytest//:pkg.[](K
data=A list of data dependencies to pass to the py_library target.[](N
testonly:A boolean indicating if the py_library target is testonly.True(H
kwargs<The extra arguments passed to the template rendering target.(�py_pytest_main wraps the template rendering target and the final py_library.

Low-level escape hatch: prefer [py_pytest_test](#py_pytest_test) for pytest
suites. Use this only for hand-written or wrapped entrypoints (e.g. exposing
an importable `main()` for custom setup/teardown around pytest).
21
py_pytest_main//py/private:py_pytest_main.bzlN
L
name@The name of the runable target that updates the test entry file. (`
^

py_library;Use this attribute to override the default py_library rule.<rule py_library>(V
T
depsFA list containing the pytest library target, e.g., @pypi_pytest//:pkg.[](M
K
data=A list of data dependencies to pass to the py_library target.[](P
N
testonly:A boolean indicating if the py_library target is testonly.True(J
H
kwargs<The extra arguments passed to the template rendering target.(�py_pytest_test�A `py_test` that always runs under pytest.

Pytest is always the driver, so the entrypoint wiring is unambiguous.
Include the `pytest` package (and `coverage`, if you want coverage) in
`deps`.

Every file in `srcs` is a test module that pytest collects (scoped to the
target, not the whole runfiles tree). Put importable support code in `deps`
and pytest's `conftest.py` in `data`; to select tests by name pattern, use
Bazel's `glob()` in the `srcs` list.
*�
�	
py_pytest_test
nameName of the rule. (F
srcs8Python test source files; pytest collects exactly these.[](X
depsJDependencies; must include the pytest package
(e.g. `@pypi_pytest//:pkg`).[](�
pytest_args�Extra arguments baked into the pytest invocation. Setting
this renders a private per-test entrypoint instead of reusing the
shared main.[](q
chdir`Optional directory to change into before pytest runs. Also
forces a private per-test entrypoint.None(x
resolutionsavirtual-dep resolutions, `"string" -> label` (reversed to
the rule's label-keyed-dict form here).None(F
kwargs:forwarded to the underlying test rule and sibling py_venv.(�A `py_test` that always runs under pytest.

Pytest is always the driver, so the entrypoint wiring is unambiguous.
Include the `pytest` package (and `coverage`, if you want coverage) in
`deps`.

Every file in `srcs` is a test module that pytest collects (scoped to the
target, not the whole runfiles tree). Put importable support code in `deps`
and pytest's `conftest.py` in `data`; to select tests by name pattern, use
Bazel's `glob()` in the `srcs` list.
21
py_pytest_test//py/private:py_pytest_test.bzl

nameName of the rule. (H
F
srcs8Python test source files; pytest collects exactly these.[](Z
X
depsJDependencies; must include the pytest package
(e.g. `@pypi_pytest//:pkg`).[](�
�
pytest_args�Extra arguments baked into the pytest invocation. Setting
this renders a private per-test entrypoint instead of reusing the
shared main.[](s
q
chdir`Optional directory to change into before pytest runs. Also
forces a private per-test entrypoint.None(z
x
resolutionsavirtual-dep resolutions, `"string" -> label` (reversed to
the rule's label-keyed-dict form here).None(H
F
kwargs:forwarded to the underlying test rule and sibling py_venv.(�py_unittest_test�A `py_test` that runs under the stdlib `unittest` framework.

Loads each `srcs` file and collects its `unittest.TestCase`s. Integrates
with Bazel coverage, sharding, JUnit XML, and `--test_filter`. No pytest
dependency required.

Every file in `srcs` is a test module. Put importable support code in
`deps`; to select tests by name pattern, use Bazel's `glob()` in the `srcs`
list.

Runtime `args` are parsed by the driver: `-v`/`-q`, `-f`/`--failfast`,
`-b`/`--buffer`, and `-k PATTERN` (native unittest `-k`: repeatable,
ORed, `*` is fnmatch). Unknown args are rejected rather than ignored.
*�
�
py_unittest_test
nameName of the rule. (H
srcs:Python test source files; each is loaded as a test module.[](�
deps�Dependencies. `coverage` is required only for coverage; JUnit XML
is emitted by a built-in writer, so no third-party runner is needed.[](D
resolutions-virtual-dep resolutions, `"string" -> label`.None(F
kwargs:forwarded to the underlying test rule and sibling py_venv.(�A `py_test` that runs under the stdlib `unittest` framework.

Loads each `srcs` file and collects its `unittest.TestCase`s. Integrates
with Bazel coverage, sharding, JUnit XML, and `--test_filter`. No pytest
dependency required.

Every file in `srcs` is a test module. Put importable support code in
`deps`; to select tests by name pattern, use Bazel's `glob()` in the `srcs`
list.

Runtime `args` are parsed by the driver: `-v`/`-q`, `-f`/`--failfast`,
`-b`/`--buffer`, and `-k PATTERN` (native unittest `-k`: repeatable,
ORed, `*` is fnmatch). Unknown args are rejected rather than ignored.
25
py_unittest_test!//py/private:py_unittest_test.bzl

nameName of the rule. (J
H
srcs:Python test source files; each is loaded as a test module.[](�
�
deps�Dependencies. `coverage` is required only for coverage; JUnit XML
is emitted by a built-in writer, so no third-party runner is needed.[](F
D
resolutions-virtual-dep resolutions, `"string" -> label`.None(H
F
kwargs:forwarded to the underlying test rule and sibling py_venv.(_py_venv*R
B
py_venv

kwargs(2+
py_venv //py/private/py_venv:py_venv.bzl


kwargs(�py_venv_link�Emit a runnable target that materialises `venv` into the workspace.

`bazel run :<name>` creates a symlink in `$BUILD_WORKING_DIRECTORY`
(typically the workspace root) that points at the target's complete
runfiles tree. The command prints `venv`'s nested path below that link;
preserving the runfiles directory layout keeps the venv's relative paths
valid for Python and IDEs. This requires directory-based runfiles; a
manifest alone cannot expose a runfiles tree.
*�
�
py_venv_linkX
nameLRunnable target name. `bazel run :<name>` materialises
the runfiles symlink. (�
venv�Label of a `py_venv` target to link. Typically the
`:<binary_name>.venv` target auto-emitted by
`py_binary(expose_venv = True, ...)`, or a standalone
`py_venv` shared across many binaries. (�
	link_name�Workspace-relative basename for the created
runfiles symlink. Defaults to a safely-escaped version of the
target's package + venv name.None(4
kwargs(Forwarded to the underlying `py_binary`.(�Emit a runnable target that materialises `venv` into the workspace.

`bazel run :<name>` creates a symlink in `$BUILD_WORKING_DIRECTORY`
(typically the workspace root) that points at the target's complete
runfiles tree. The command prints `venv`'s nested path below that link;
preserving the runfiles directory layout keeps the venv's relative paths
valid for Python and IDEs. This requires directory-based runfiles; a
manifest alone cannot expose a runfiles tree.
20
py_venv_link //py/private/py_venv:py_venv.bzlZ
X
nameLRunnable target name. `bazel run :<name>` materialises
the runfiles symlink. (�
�
venv�Label of a `py_venv` target to link. Typically the
`:<binary_name>.venv` target auto-emitted by
`py_binary(expose_venv = True, ...)`, or a standalone
`py_venv` shared across many binaries. (�
�
	link_name�Workspace-relative basename for the created
runfiles symlink. Defaults to a safely-escaped version of the
target's package + venv name.None(6
4
kwargs(Forwarded to the underlying `py_binary`.(�#py_image_layer�Create OCI-compatible tars from a py_binary or py_venv target.

Pip-package grouping + compression is resolved from the `//py:layer_tier`
label_flag. Override globally with `--//py:layer_tier=//path:custom_tier`,
or pin a tier to a specific rule via the `py_layer_tier` attr below.

## Output layers

  1. Non-pip deps listed in `groups` → one rule-created tar per group.
  2. First-party py_library targets matched by `py_layer_tier.groups` → one
     rule-created tar per group (aggregated across all matched targets in the
     binary's dep closure).
  3. Solo-group and subpath-split pip tars — built by `_layer_aspect` at each pip
     target's own namespace; globally shared across every rule using that package.
  4. Multi-member merged tars — one per group, built by `_merge_aspect` at the
     binary's namespace from the closure-filtered union of member install_dirs.
  5. Ungrouped pip packages → one squashed rule-created tar.
  6. Remaining first-party Python source files → the "default" layer.
*�
�
py_image_layer)
nameName of the generated target. (,
binaryA py_venv or py_binary target. (�
groups�Maps a NON-PIP dep label to a group name. Each gets its own rule-created
tar. All pip-package grouping (whole-package, subpath, multi-member) belongs
in py_layer_tier — subpath glob keys passed here fail loudly.{}(�
group_execution_requirementsxMaps a group name to execution requirement strings.
The group name "packages" applies to the squashed ungrouped-pip tar.{}(�
group_compress_levels�Maps a group name to a gzip compression level (1-9) for
rule-created tars (non-pip deps, squashed ungrouped pip tar, source). Default 6.
Does NOT apply to aspect-created pip tars (configure via the py_layer_tier target).{}(N
warn_remote_cache_threshold_mb%Threshold for large package warnings.200(J
warn_layer_count0Warn when total layers exceed this. Default: 90.90(/
platformPlatform transition target.None(�

layer_tier�Optional py_layer_tier target pinned for this rule. Sets the
`@aspect_rules_py//py:layer_tier` label_flag via the rule transition,
overriding any command-line value for this rule's subgraph.None($
kwargsForwarded to inner rule.(�Create OCI-compatible tars from a py_binary or py_venv target.

Pip-package grouping + compression is resolved from the `//py:layer_tier`
label_flag. Override globally with `--//py:layer_tier=//path:custom_tier`,
or pin a tier to a specific rule via the `py_layer_tier` attr below.

## Output layers

  1. Non-pip deps listed in `groups` → one rule-created tar per group.
  2. First-party py_library targets matched by `py_layer_tier.groups` → one
     rule-created tar per group (aggregated across all matched targets in the
     binary's dep closure).
  3. Solo-group and subpath-split pip tars — built by `_layer_aspect` at each pip
     target's own namespace; globally shared across every rule using that package.
  4. Multi-member merged tars — one per group, built by `_merge_aspect` at the
     binary's namespace from the closure-filtered union of member install_dirs.
  5. Ungrouped pip packages → one squashed rule-created tar.
  6. Remaining first-party Python source files → the "default" layer.
21
py_image_layer//py/private:py_image_layer.bzl+
)
nameName of the generated target. (.
,
binaryA py_venv or py_binary target. (�
�
groups�Maps a NON-PIP dep label to a group name. Each gets its own rule-created
tar. All pip-package grouping (whole-package, subpath, multi-member) belongs
in py_layer_tier — subpath glob keys passed here fail loudly.{}(�
�
group_execution_requirementsxMaps a group name to execution requirement strings.
The group name "packages" applies to the squashed ungrouped-pip tar.{}(�
�
group_compress_levels�Maps a group name to a gzip compression level (1-9) for
rule-created tars (non-pip deps, squashed ungrouped pip tar, source). Default 6.
Does NOT apply to aspect-created pip tars (configure via the py_layer_tier target).{}(P
N
warn_remote_cache_threshold_mb%Threshold for large package warnings.200(L
J
warn_layer_count0Warn when total layers exceed this. Default: 90.90(1
/
platformPlatform transition target.None(�
�

layer_tier�Optional py_layer_tier target pinned for this rule. Sets the
`@aspect_rules_py//py:layer_tier` label_flag via the rule transition,
overriding any command-line value for this rule's subgraph.None(&
$
kwargsForwarded to inner rule.(�resolutions.from_requirements*�
�
resolutions.from_requirements

base (C
requirement_fn/<function lambda from //py/private:virtual.bzl>(2.
_from_requirements//py/private:virtual.bzl


base (E
C
requirement_fn/<function lambda from //py/private:virtual.bzl>(�$	py_binary�Build and run a Python binary.

Splits the call into a sibling `py_venv` (which carries srcs / deps
/ imports / virtual_deps / resolutions / package_collisions /
include_*_site_packages / interpreter_options) plus a thin launcher
rule that exec's that venv's interpreter. Set `expose_venv = True`
to make the sibling a first-class `:{name}.venv` target — runnable
(`bazel run :{name}.venv` drops into the hermetic interpreter) and
pairable with `py_venv_link` for IDE integration. For the common
case where you want both the venv target *and* an IDE-pointable
workspace symlink in one step, set `expose_venv_link = True`.
*�
�
	py_binary
nameName of the rule. ("
srcsPython source files.[](�
main�Entry point.
Like rules_python, this is treated as a suffix of a file that should appear among the srcs.
If absent, then `[name].py` is tried. As a final fallback, if the srcs has a single file,
that is used as the main.

Note: the fallback runs at macro-evaluation time and operates
on label strings, not resolved files — it cannot inspect a
generated target's output basename. If `main` would resolve
to a file produced by another rule (e.g. a `genrule` whose
output happens to be `<name>.py`), the macro can't see that
and you must pass `main =` explicitly.None(�
kwargs�additional named parameters forwarded to the
underlying rule and the sibling py_venv. Two extras are
handled by this macro:

* `expose_venv` (bool, default `False`) — when `True`, emit
  a sibling `:{name}.venv` py_venv carrying all venv-shaping
  attrs (deps, imports, package_collisions,
  include_*_site_packages, interpreter_options). The `.venv`
  target is runnable (`bazel run :{name}.venv` drops into
  the hermetic interpreter).
* `expose_venv_link` (bool, default `False`) — when `True`,
  additionally emit a `:{name}.venv_link` py_venv_link.
  `bazel run :{name}.venv_link` links the target's runfiles
  tree into the workspace and prints the nested venv path
  suitable for an IDE's interpreter setting. Implies
  `expose_venv = True`; passing
  `expose_venv = False, expose_venv_link = True` explicitly
  is rejected with a clear error. Equivalent to declaring an
  explicit
  `py_venv_link(name = "{name}.venv_link", venv = ":{name}.venv")`
  alongside the binary.(�Build and run a Python binary.

Splits the call into a sibling `py_venv` (which carries srcs / deps
/ imports / virtual_deps / resolutions / package_collisions /
include_*_site_packages / interpreter_options) plus a thin launcher
rule that exec's that venv's interpreter. Set `expose_venv = True`
to make the sibling a first-class `:{name}.venv` target — runnable
(`bazel run :{name}.venv` drops into the hermetic interpreter) and
pairable with `py_venv_link` for IDE integration. For the common
case where you want both the venv target *and* an IDE-pointable
workspace symlink in one step, set `expose_venv_link = True`.
2
	py_binary//py:defs.bzl

nameName of the rule. ($
"
srcsPython source files.[](�
�
main�Entry point.
Like rules_python, this is treated as a suffix of a file that should appear among the srcs.
If absent, then `[name].py` is tried. As a final fallback, if the srcs has a single file,
that is used as the main.

Note: the fallback runs at macro-evaluation time and operates
on label strings, not resolved files — it cannot inspect a
generated target's output basename. If `main` would resolve
to a file produced by another rule (e.g. a `genrule` whose
output happens to be `<name>.py`), the macro can't see that
and you must pass `main =` explicitly.None(�
�
kwargs�additional named parameters forwarded to the
underlying rule and the sibling py_venv. Two extras are
handled by this macro:

* `expose_venv` (bool, default `False`) — when `True`, emit
  a sibling `:{name}.venv` py_venv carrying all venv-shaping
  attrs (deps, imports, package_collisions,
  include_*_site_packages, interpreter_options). The `.venv`
  target is runnable (`bazel run :{name}.venv` drops into
  the hermetic interpreter).
* `expose_venv_link` (bool, default `False`) — when `True`,
  additionally emit a `:{name}.venv_link` py_venv_link.
  `bazel run :{name}.venv_link` links the target's runfiles
  tree into the workspace and prints the nested venv path
  suitable for an IDE's interpreter setting. Implies
  `expose_venv = True`; passing
  `expose_venv = False, expose_venv_link = True` explicitly
  is rejected with a clear error. Equivalent to declaring an
  explicit
  `py_venv_link(name = "{name}.venv_link", venv = ":{name}.venv")`
  alongside the binary.(�py_test�Identical to [py_binary](#function-py_binary), but produces a target that can be used with `bazel test`.

`py_test` is a generic test rule: it runs a Python file as a test, nothing
more. To drive a suite with a framework, use the purpose-oriented macros
[py_pytest_test](#py_pytest_test) (pytest) or
[py_unittest_test](#py_unittest_test) (stdlib unittest).
*�	
�
py_test
nameName of the rule. ("
srcsPython source files.[](�
main�Entry point.
This is treated as a suffix of a file that should appear among the srcs.
If absent, then `[name].py` is tried. As a final fallback, if the srcs has a single file,
that is used as the main.None(a
kwargsUadditional named parameters forwarded to the
underlying rule and the sibling py_venv.(�Identical to [py_binary](#function-py_binary), but produces a target that can be used with `bazel test`.

`py_test` is a generic test rule: it runs a Python file as a test, nothing
more. To drive a suite with a framework, use the purpose-oriented macros
[py_pytest_test](#py_pytest_test) (pytest) or
[py_unittest_test](#py_unittest_test) (stdlib unittest).
2
py_test//py:defs.bzl

nameName of the rule. ($
"
srcsPython source files.[](�
�
main�Entry point.
This is treated as a suffix of a file that should appear among the srcs.
If absent, then `[name].py` is tried. As a final fallback, if the srcs has a single file,
that is used as the main.None(c
a
kwargsUadditional named parameters forwarded to the
underlying rule and the sibling py_venv.(�PyLayerTierInfoKLayer tier for py_image_layer: how pip packages are grouped and compressed.2�

�
PyLayerTierInfoKLayer tier for py_image_layer: how pip packages are grouped and compressed.G
whole_groups7dict[str, str] — normalized pip label → group name.^
subpath_groupsLdict[str, dict[str, list[str]]] — label → {group_name: [glob_patterns]}.J
compression;dict[str, list[str]] — group name → [algorithm, level].W
multi_member_groups@dict[str, True] — group names with 2+ members in whole_groups.V
interpreter_groupAstr — group name for the Python interpreter layer; '' disables.5
root-str — root path in the image (e.g. '/app').b
strip_prefixRstr — prefix stripped from source file paths; empty means use binary short_path."2
PyLayerTierInfo//py/private:py_image_layer.bzlI
G
whole_groups7dict[str, str] — normalized pip label → group name.`
^
subpath_groupsLdict[str, dict[str, list[str]]] — label → {group_name: [glob_patterns]}.L
J
compression;dict[str, list[str]] — group name → [algorithm, level].Y
W
multi_member_groups@dict[str, True] — group names with 2+ members in whole_groups.X
V
interpreter_groupAstr — group name for the Python interpreter layer; '' disables.7
5
root-str — root path in the image (e.g. '/app').d
b
strip_prefixRstr — prefix stripped from source file paths; empty means use binary short_path.�	PyInfoaPython source, import-path, and virtual-dependency information for a target's dependency closure.2�
�
PyInfoaPython source, import-path, and virtual-dependency information for a target's dependency closure.o
transitive_sourcesYdepset[File] — postorder depset of first-party `.py` sources in the transitive closure.Y
importsNdepset[str] — import roots to place on `sys.path` (rlocation-root-relative).w
virtual_dependencies_depset[str] — names of required virtual dependencies, independent of their resolution status.r
virtual_resolutions[depset[struct(virtual, target)] — virtual-dependency-name to concrete-target resolutions."'
RulesPyInfo//py/private:py_info.bzlq
o
transitive_sourcesYdepset[File] — postorder depset of first-party `.py` sources in the transitive closure.[
Y
importsNdepset[str] — import roots to place on `sys.path` (rlocation-root-relative).y
w
virtual_dependencies_depset[str] — names of required virtual dependencies, independent of their resolution status.t
r
virtual_resolutions[depset[struct(virtual, target)] — virtual-dependency-name to concrete-target resolutions.�4PyWheelsInfo�Installed wheel records used by venv assembly and image layering.

Each element of `wheels` describes one wheel in the transitive closure of a
target. Every record carries the complete installed tree. Repository-inspected
wheels also carry their site-packages layout and console scripts; source-built
wheels may leave that analysis-time metadata empty.

Venv rules project known layouts and generate console-script wrappers. Image
rules use `install_tree` to retain each wheel as a package leaf independently
of whether its metadata was available during analysis.2�/
�
PyWheelsInfo�Installed wheel records used by venv assembly and image layering.

Each element of `wheels` describes one wheel in the transitive closure of a
target. Every record carries the complete installed tree. Repository-inspected
wheels also carry their site-packages layout and console scripts; source-built
wheels may leave that analysis-time metadata empty.

Venv rules project known layouts and generate console-script wrappers. Image
rules use `install_tree` to retain each wheel as a package leaf independently
of whether its metadata was available during analysis.�
wheels�Depset of wheel record structs, one per wheel in the transitive closure. rules_py aggregates this field in
postorder. Producers must use `default` or `postorder`, the orders Bazel permits
in that aggregate. For collision classes that select one claimant, permissive
handling gives the later distinct element in the flattened sequence precedence.
Duplicate dependency edges do not create another precedence position. Fields:
  * `top_levels`: tuple[str] — complete set of immediate `site-packages`
    entry names when nonempty; an empty tuple means the layout is unknown.
  * `top_level_dirs`: tuple[str] — subset of non-metadata top_levels that
    are directories in the RECORD-derived install tree rather than single-file
    modules.
  * `namespace_top_levels`: tuple[str] — subset of top_levels that are PEP 420 namespace packages.
  * `namespace_entries`: tuple[str] — `/`-joined paths of the concrete entries beneath
    the namespace top-levels (e.g. `jaraco/functools`), used to materialise a merged
    namespace directory out of per-entry symlinks. May be absent on structs from
    older producers; consumers use `getattr` with a `()` default.
  * `namespace_dirs`: tuple[str] — implicit-namespace directory skeleton under the
    namespace top-levels (site-packages-relative `/`-joined paths). May be absent
    on structs from older producers; consumers use `getattr` with a `()` default.
  * `regular_roots`: tuple[str] — minimal directories under the namespace
    top-levels carrying an `__init__.py`. Cross-referencing a wheel's
    `regular_roots` with another wheel's `namespace_dirs` detects regular
    packages spanning wheels, which venv assembly must physically merge.
    May be absent on structs from older producers.
  * `native_roots`: tuple[str] — collision-relevant top-level directories,
    namespace directories, and regular roots containing RECORD entries with
    native-library suffixes. A colliding root in this set cannot be copied
    into a merge tree without changing the library's physical origin.
  * `site_packages_rfpath`: str — runfiles-root-relative path to the wheel's site-packages.
  * `console_scripts`: tuple[str] — entry points encoded as `"name=module:func"`.
  * `install_tree`: File — complete installed wheel tree.
  * `tl_claims`, `metadata_top_levels`, `cs_claims`: derived fields
    precomputed by `make_wheel_record` so venv assembly's collision
    resolution does per-wheel parsing once instead of per consuming binary.
    Each `tl_claims` entry carries the top-level's namespace, directory,
    native-root, and namespace-entry facts.

Records must be built with `make_wheel_record` so the derived fields are
present and consistent with the raw ones."*
PyWheelsInfo//py/private:providers.bzl�
�
wheels�Depset of wheel record structs, one per wheel in the transitive closure. rules_py aggregates this field in
postorder. Producers must use `default` or `postorder`, the orders Bazel permits
in that aggregate. For collision classes that select one claimant, permissive
handling gives the later distinct element in the flattened sequence precedence.
Duplicate dependency edges do not create another precedence position. Fields:
  * `top_levels`: tuple[str] — complete set of immediate `site-packages`
    entry names when nonempty; an empty tuple means the layout is unknown.
  * `top_level_dirs`: tuple[str] — subset of non-metadata top_levels that
    are directories in the RECORD-derived install tree rather than single-file
    modules.
  * `namespace_top_levels`: tuple[str] — subset of top_levels that are PEP 420 namespace packages.
  * `namespace_entries`: tuple[str] — `/`-joined paths of the concrete entries beneath
    the namespace top-levels (e.g. `jaraco/functools`), used to materialise a merged
    namespace directory out of per-entry symlinks. May be absent on structs from
    older producers; consumers use `getattr` with a `()` default.
  * `namespace_dirs`: tuple[str] — implicit-namespace directory skeleton under the
    namespace top-levels (site-packages-relative `/`-joined paths). May be absent
    on structs from older producers; consumers use `getattr` with a `()` default.
  * `regular_roots`: tuple[str] — minimal directories under the namespace
    top-levels carrying an `__init__.py`. Cross-referencing a wheel's
    `regular_roots` with another wheel's `namespace_dirs` detects regular
    packages spanning wheels, which venv assembly must physically merge.
    May be absent on structs from older producers.
  * `native_roots`: tuple[str] — collision-relevant top-level directories,
    namespace directories, and regular roots containing RECORD entries with
    native-library suffixes. A colliding root in this set cannot be copied
    into a merge tree without changing the library's physical origin.
  * `site_packages_rfpath`: str — runfiles-root-relative path to the wheel's site-packages.
  * `console_scripts`: tuple[str] — entry points encoded as `"name=module:func"`.
  * `install_tree`: File — complete installed wheel tree.
  * `tl_claims`, `metadata_top_levels`, `cs_claims`: derived fields
    precomputed by `make_wheel_record` so venv assembly's collision
    resolution does per-wheel parsing once instead of per consuming binary.
    Each `tl_claims` entry carries the top-level's namespace, directory,
    native-root, and namespace-entry facts.

Records must be built with `make_wheel_record` so the derived fields are
present and consistent with the raw ones.ÑPyRuntimeInfo�Contains information about a Python runtime, as returned by the `py_runtime`
rule.

:::{warning}
This is an **unstable public** API. It may change more frequently and has weaker
compatibility guarantees.
:::

A Python runtime describes either a *platform runtime* or an *in-build runtime*.
A platform runtime accesses a system-installed interpreter at a known path,
whereas an in-build runtime points to a `File` that acts as the interpreter. In
both cases, an "interpreter" is really any executable binary or wrapper script
that is capable of running a Python script passed on the command line, following
the same conventions as the standard CPython interpreter.2��
�J
PyRuntimeInfo�Contains information about a Python runtime, as returned by the `py_runtime`
rule.

:::{warning}
This is an **unstable public** API. It may change more frequently and has weaker
compatibility guarantees.
:::

A Python runtime describes either a *platform runtime* or an *in-build runtime*.
A platform runtime accesses a system-installed interpreter at a known path,
whereas an in-build runtime points to a `File` that acts as the interpreter. In
both cases, an "interpreter" is really any executable binary or wrapper script
that is capable of running a Python script passed on the command line, following
the same conventions as the standard CPython interpreter.c
	abi_flagsV:type: str

The runtime's ABI flags, i.e. `sys.abiflags`.

:::{versionadded} 1.0.0
:::�
bootstrap_template�:type: File

A template of code responsible for the initial startup of a program.

This code is responsible for:

* Locating the target interpreter. Typically it is in runfiles, but not always.
* Setting necessary environment variables, command line flags, or other
  configuration that can't be modified after the interpreter starts.
* Invoking the appropriate entry point. This is usually a second-stage bootstrap
  that performs additional setup prior to running a program's actual entry point.

The {obj}`--bootstrap_impl` flag affects how this stage 1 bootstrap
is expected to behave and the substutitions performed.

* `--bootstrap_impl=system_python` substitutions: `%is_zipfile%`, `%python_binary%`,
  `%target%`, `%workspace_name`, `%coverage_tool%`, `%import_all%`, `%imports%`,
  `%main%`, `%shebang%`
* `--bootstrap_impl=script` substititions: `%is_zipfile%`, `%python_binary%`,
  `%python_binary_actual%`, `%target%`, `%workspace_name`,
  `%shebang%`, `%stage2_bootstrap%`

Substitution definitions:

* `%shebang%`: The shebang to use with the bootstrap; the bootstrap template
  may choose to ignore this.
* `%stage2_bootstrap%`: A runfiles-relative path to the stage 2 bootstrap.
* `%python_binary%`: The path to the target Python interpreter. There are three
  types of paths:
  * An absolute path to a system interpreter (e.g. begins with `/`).
  * A runfiles-relative path to an interpreter (e.g. `somerepo/bin/python3`)
  * A program to search for on PATH, i.e. a word without spaces, e.g. `python3`.

  When `--bootstrap_impl=script` is used, this is always a runfiles-relative
  path to a venv-based interpreter executable.

* `%python_binary_actual%`: The path to the interpreter that
  `%python_binary%` invokes. There are three types of paths:
  * An absolute path to a system interpreter (e.g. begins with `/`).
  * A runfiles-relative path to an interpreter (e.g. `somerepo/bin/python3`)
  * A program to search for on PATH, i.e. a word without spaces, e.g. `python3`.

  Only set for zip builds with `--bootstrap_impl=script`; other builds will use
  an empty string.

* `%workspace_name%`: The name of the workspace the target belongs to.
* `%is_zipfile%`: The string `1` if this template is prepended to a zipfile to
  create a self-executable zip file. The string `0` otherwise.

For the other substitution definitions, see the {obj}`stage2_bootstrap_template`
docs.

:::{versionchanged} 0.33.0
The set of substitutions depends on {obj}`--bootstrap_impl`
:::�
coverage_files�:type: depset[File] | None

The files required at runtime for using `coverage_tool`. Will be `None` if no
`coverage_tool` was provided.�
coverage_tool�:type: File | None

If set, this field is a `File` representing tool used for collecting code
coverage information from python tests. Otherwise, this is `None`.�
files�:type: depset[File] | None

If this is an in-build runtime, this field is a `depset` of `File`s that need to
be added to the runfiles of an executable target that uses this runtime (in
particular, files needed by `interpreter`). The value of `interpreter` need not
be included in this field. If this is a platform runtime then this field is
`None`.d
implementation_nameM:type: str | None

The Python implementation name (`sys.implementation.name`)�
interpreter�:type: File | None

If this is an in-build runtime, this field is a `File` representing the
interpreter. Otherwise, this is `None`. Note that an in-build runtime can use
either a prebuilt, checked-in interpreter or an interpreter built from source.�
interpreter_path�:type: str | None

If this is a platform runtime, this field is the absolute filesystem path to the
interpreter on the target platform. Otherwise, this is `None`.�
interpreter_version_info�:type: struct

Version information about the interpreter this runtime provides.
It should match the format given by `sys.version_info`, however
for simplicity, the micro, releaselevel, and serial values are
optional.
A struct with the following fields:
* `major`: {type}`int`, the major version number
* `minor`: {type}`int`, the minor version number
* `micro`: {type}`int | None`, the micro version number
* `releaselevel`: {type}`str | None`, the release level
* `serial`: {type}`int | None`, the serial number of the release�
pyc_tag�:type: str | None

The tag portion of a pyc filename, e.g. the `cpython-39` infix
of `foo.cpython-39.pyc`. See PEP 3147. If not specified, it will be computed
from {obj}`implementation_name` and {obj}`interpreter_version_info`. If no
pyc_tag is available, then only source-less pyc generation will function
correctly.�
python_versiony:type: str

Indicates whether this runtime uses Python major version 2 or 3. Valid values
are (only) `"PY2"` and `"PY3"`.�
site_init_template�:type: File

The template to use for the binary-specific site-init hook run by the
interpreter at startup.

:::{versionadded} 1.0.0
:::�
stage2_bootstrap_template�:type: File

A template of Python code that runs under the desired interpreter and is
responsible for orchestrating calling the program's actual main code. This
bootstrap is responsible for affecting the current runtime's state, such as
import paths or enabling coverage, so that, when it runs the program's actual
main code, it works properly under Bazel.

The following substitutions are made during template expansion:
* `%main%`: A runfiles-relative path to the program's actual main file. This
  can be a `.py` or `.pyc` file, depending on precompile settings.
* `%coverage_tool%`: Runfiles-relative path to the coverage library's entry point.
  If coverage is not enabled or available, an empty string.
* `%import_all%`: The string `True` if all repositories in the runfiles should
  be added to sys.path. The string `False` otherwise.
* `%imports%`: A colon-delimited string of runfiles-relative paths to add to
  sys.path.
* `%target%`: The name of the target this is for.
* `%workspace_name%`: The name of the workspace the target belongs to.

:::{versionadded} 0.33.0
:::�
stub_shebang�:type: str

"Shebang" expression prepended to the bootstrapping Python stub
script used when executing {obj}`py_binary` targets.  Does not
apply to Windows.�
supports_build_time_venv�:type: bool

True if this toolchain supports the build-time created virtual environment.
False if not or unknown. If build-time venv creation isn't supported, then binaries may
fallback to non-venv solutions or creating a venv at runtime.

In order to use the build-time created virtual environment, a toolchain needs
to meet two criteria:
1. Specifying the underlying executable (e.g. `/usr/bin/python3`, as reported by
   `sys._base_executable`) for the venv executable (`$venv/bin/python3`, as reported
   by `sys.executable`). This typically requires relative symlinking the venv
   path to the underlying path at build time, or using the `PYTHONEXECUTABLE`
   environment variable (Python 3.11+) at runtime.
2. Having the build-time created site-packages directory
   (`<venv>/lib/python{version}/site-packages`) recognized by the runtime
   interpreter. This typically requires the Python version to be known at
   build-time and match at runtime.

:::{versionadded} 1.5.0
:::�
zip_main_template�:type: File

A template of Python code that becomes a zip file's top-level `__main__.py`
file. The top-level `__main__.py` file is used when the zip file is explicitly
passed to a Python interpreter. See PEP 441 for more information about zipapp
support. Note that py_binary-generated zip files are self-executing and
skip calling `__main__.py`.

The following substitutions are made during template expansion:
* `%stage2_bootstrap%`: A runfiles-relative string to the stage 2 bootstrap file.
* `%python_binary%`: The path to the target Python interpreter. There are three
  types of paths:
  * An absolute path to a system interpreter (e.g. begins with `/`).
  * A runfiles-relative path to an interpreter (e.g. `somerepo/bin/python3`)
  * A program to search for on PATH, i.e. a word without spaces, e.g. `python3`.
* `%workspace_name%`: The name of the workspace for the built target.

:::{versionadded} 0.33.0
:::"B
PyRuntimeInfo1@rules_python//python/private:py_runtime_info.bzl*�
PyRuntimeInfo
implementation_nameNone(
interpreter_pathNone(
interpreterNone(
filesNone(
coverage_toolNone(
coverage_filesNone(
pyc_tagNone(
python_version (
stub_shebangNone(
bootstrap_templateNone("
interpreter_version_infoNone(#
stage2_bootstrap_templateNone(
zip_main_templateNone(
	abi_flags""(
site_init_templateNone("
supports_build_time_venvTrue(2H
_PyRuntimeInfo_init1@rules_python//python/private:py_runtime_info.bzle
c
	abi_flagsV:type: str

The runtime's ABI flags, i.e. `sys.abiflags`.

:::{versionadded} 1.0.0
:::�
�
bootstrap_template�:type: File

A template of code responsible for the initial startup of a program.

This code is responsible for:

* Locating the target interpreter. Typically it is in runfiles, but not always.
* Setting necessary environment variables, command line flags, or other
  configuration that can't be modified after the interpreter starts.
* Invoking the appropriate entry point. This is usually a second-stage bootstrap
  that performs additional setup prior to running a program's actual entry point.

The {obj}`--bootstrap_impl` flag affects how this stage 1 bootstrap
is expected to behave and the substutitions performed.

* `--bootstrap_impl=system_python` substitutions: `%is_zipfile%`, `%python_binary%`,
  `%target%`, `%workspace_name`, `%coverage_tool%`, `%import_all%`, `%imports%`,
  `%main%`, `%shebang%`
* `--bootstrap_impl=script` substititions: `%is_zipfile%`, `%python_binary%`,
  `%python_binary_actual%`, `%target%`, `%workspace_name`,
  `%shebang%`, `%stage2_bootstrap%`

Substitution definitions:

* `%shebang%`: The shebang to use with the bootstrap; the bootstrap template
  may choose to ignore this.
* `%stage2_bootstrap%`: A runfiles-relative path to the stage 2 bootstrap.
* `%python_binary%`: The path to the target Python interpreter. There are three
  types of paths:
  * An absolute path to a system interpreter (e.g. begins with `/`).
  * A runfiles-relative path to an interpreter (e.g. `somerepo/bin/python3`)
  * A program to search for on PATH, i.e. a word without spaces, e.g. `python3`.

  When `--bootstrap_impl=script` is used, this is always a runfiles-relative
  path to a venv-based interpreter executable.

* `%python_binary_actual%`: The path to the interpreter that
  `%python_binary%` invokes. There are three types of paths:
  * An absolute path to a system interpreter (e.g. begins with `/`).
  * A runfiles-relative path to an interpreter (e.g. `somerepo/bin/python3`)
  * A program to search for on PATH, i.e. a word without spaces, e.g. `python3`.

  Only set for zip builds with `--bootstrap_impl=script`; other builds will use
  an empty string.

* `%workspace_name%`: The name of the workspace the target belongs to.
* `%is_zipfile%`: The string `1` if this template is prepended to a zipfile to
  create a self-executable zip file. The string `0` otherwise.

For the other substitution definitions, see the {obj}`stage2_bootstrap_template`
docs.

:::{versionchanged} 0.33.0
The set of substitutions depends on {obj}`--bootstrap_impl`
:::�
�
coverage_files�:type: depset[File] | None

The files required at runtime for using `coverage_tool`. Will be `None` if no
`coverage_tool` was provided.�
�
coverage_tool�:type: File | None

If set, this field is a `File` representing tool used for collecting code
coverage information from python tests. Otherwise, this is `None`.�
�
files�:type: depset[File] | None

If this is an in-build runtime, this field is a `depset` of `File`s that need to
be added to the runfiles of an executable target that uses this runtime (in
particular, files needed by `interpreter`). The value of `interpreter` need not
be included in this field. If this is a platform runtime then this field is
`None`.f
d
implementation_nameM:type: str | None

The Python implementation name (`sys.implementation.name`)�
�
interpreter�:type: File | None

If this is an in-build runtime, this field is a `File` representing the
interpreter. Otherwise, this is `None`. Note that an in-build runtime can use
either a prebuilt, checked-in interpreter or an interpreter built from source.�
�
interpreter_path�:type: str | None

If this is a platform runtime, this field is the absolute filesystem path to the
interpreter on the target platform. Otherwise, this is `None`.�
�
interpreter_version_info�:type: struct

Version information about the interpreter this runtime provides.
It should match the format given by `sys.version_info`, however
for simplicity, the micro, releaselevel, and serial values are
optional.
A struct with the following fields:
* `major`: {type}`int`, the major version number
* `minor`: {type}`int`, the minor version number
* `micro`: {type}`int | None`, the micro version number
* `releaselevel`: {type}`str | None`, the release level
* `serial`: {type}`int | None`, the serial number of the release�
�
pyc_tag�:type: str | None

The tag portion of a pyc filename, e.g. the `cpython-39` infix
of `foo.cpython-39.pyc`. See PEP 3147. If not specified, it will be computed
from {obj}`implementation_name` and {obj}`interpreter_version_info`. If no
pyc_tag is available, then only source-less pyc generation will function
correctly.�
�
python_versiony:type: str

Indicates whether this runtime uses Python major version 2 or 3. Valid values
are (only) `"PY2"` and `"PY3"`.�
�
site_init_template�:type: File

The template to use for the binary-specific site-init hook run by the
interpreter at startup.

:::{versionadded} 1.0.0
:::�
�
stage2_bootstrap_template�:type: File

A template of Python code that runs under the desired interpreter and is
responsible for orchestrating calling the program's actual main code. This
bootstrap is responsible for affecting the current runtime's state, such as
import paths or enabling coverage, so that, when it runs the program's actual
main code, it works properly under Bazel.

The following substitutions are made during template expansion:
* `%main%`: A runfiles-relative path to the program's actual main file. This
  can be a `.py` or `.pyc` file, depending on precompile settings.
* `%coverage_tool%`: Runfiles-relative path to the coverage library's entry point.
  If coverage is not enabled or available, an empty string.
* `%import_all%`: The string `True` if all repositories in the runfiles should
  be added to sys.path. The string `False` otherwise.
* `%imports%`: A colon-delimited string of runfiles-relative paths to add to
  sys.path.
* `%target%`: The name of the target this is for.
* `%workspace_name%`: The name of the workspace the target belongs to.

:::{versionadded} 0.33.0
:::�
�
stub_shebang�:type: str

"Shebang" expression prepended to the bootstrapping Python stub
script used when executing {obj}`py_binary` targets.  Does not
apply to Windows.�
�
supports_build_time_venv�:type: bool

True if this toolchain supports the build-time created virtual environment.
False if not or unknown. If build-time venv creation isn't supported, then binaries may
fallback to non-venv solutions or creating a venv at runtime.

In order to use the build-time created virtual environment, a toolchain needs
to meet two criteria:
1. Specifying the underlying executable (e.g. `/usr/bin/python3`, as reported by
   `sys._base_executable`) for the venv executable (`$venv/bin/python3`, as reported
   by `sys.executable`). This typically requires relative symlinking the venv
   path to the underlying path at build time, or using the `PYTHONEXECUTABLE`
   environment variable (Python 3.11+) at runtime.
2. Having the build-time created site-packages directory
   (`<venv>/lib/python{version}/site-packages`) recognized by the runtime
   interpreter. This typically requires the Python version to be known at
   build-time and match at runtime.

:::{versionadded} 1.5.0
:::�
�
zip_main_template�:type: File

A template of Python code that becomes a zip file's top-level `__main__.py`
file. The top-level `__main__.py` file is used when the zip file is explicitly
passed to a Python interpreter. See PEP 441 for more information about zipapp
support. Note that py_binary-generated zip files are self-executing and
skip calling `__main__.py`.

The following substitutions are made during template expansion:
* `%stage2_bootstrap%`: A runfiles-relative string to the stage 2 bootstrap file.
* `%python_binary%`: The path to the target Python interpreter. There are three
  types of paths:
  * An absolute path to a system interpreter (e.g. begins with `/`).
  * A runfiles-relative path to an interpreter (e.g. `somerepo/bin/python3`)
  * A program to search for on PATH, i.e. a word without spaces, e.g. `python3`.
* `%workspace_name%`: The name of the workspace for the built target.

:::{versionadded} 0.33.0
:::�Re-implementations of [py_binary](https://bazel.build/reference/be/python#py_binary)
and [py_test](https://bazel.build/reference/be/python#py_test)

## Choosing the Python version

The `python_version` attribute must refer to a python toolchain version
which has been registered in the `MODULE.bazel` file, e.g.:

```starlark
interpreters = use_extension("@aspect_rules_py//py:extensions.bzl", "python_interpreters")
interpreters.toolchain(python_version = "3.9")
interpreters.toolchain(python_version = "3.12")
use_repo(interpreters, "python_interpreters")

register_toolchains("@python_interpreters//:all")
```�S
pyextensions.bzl�Mpython_interpretersJ�M
�
python_interpreters�
	configureQConfigure the set of python-build-standalone releases to search for interpreters.�
build_config�python-build-standalone build configuration for the non-free-threaded
interpreter, hub-wide. This is the archive suffix PBS publishes, and selects
size/optimization/debug tradeoffs for every provisioned version and platform.

Supported values:
  - "install_only" (default): optimized, minimal redistributable (tar.gz).
  - "install_only_stripped": same as install_only with debug symbols removed
    (smallest download).
  - "<opt>[+<opt>...]-full": a full archive, where each component is one of
    debug, noopt, pgo, lto, in that order. Examples: "pgo+lto-full",
    "lto-full", "noopt-full", "debug-full".

Per-platform availability of the "-full" flavors, the "+static" and
"freethreaded" exclusions, and the Py_DEBUG caveat are documented in
docs/interpreter.md under "Build configuration".

Only honored from the root module.2"install_only"�
base_url�Base URL for downloading release assets. Defaults to the official PBS GitHub releases URL.
Override this to fetch from a mirror or fork, e.g.
"https://github.com/my-org/python-build-standalone/releases/download".
The URL should point to the directory containing release date directories,
such that {base_url}/{date}/SHA256SUMS is a valid path.

Only honored from the root module.2""�
releases�List of python-build-standalone release dates to search for interpreters,
e.g. ["20260303", "20241002"]. Newer releases are preferred when multiple
contain the same Python minor version.

The special value "latest" resolves to the newest release via the GitHub
releases API. This makes the extension non-reproducible: Bazel will
re-evaluate it on every invocation rather than caching the result.

See https://github.com/astral-sh/python-build-standalone/releases for
available releases.

Only honored from the root module. Non-root modules may include this tag
without error, but it will be silently ignored. �

	toolchain�
config_settings�Additional config_setting labels that must match for this toolchain to be selected.
Use this to gate a toolchain on a custom flag, e.g.
["//:use_hermetic_python"]. The settings are added to the toolchain's
target_settings alongside the version and platform constraints.

Only honored from the root module.2[]�
exec_compatible_with�Additional exec platform constraints appended to each platform variant's
exec-tools registration. Target runtime and C toolchains do not run on the
execution platform.

Only honored from the root module.2[]�
pre_release�Allow pre-release versions (alpha, beta, rc) for this toolchain.

By default, only final release versions are provisioned. Set this to True
to allow pre-release versions like 3.15.0a6 or 3.14.0b1. This is useful
for testing against upcoming Python versions that have no stable release yet.

Only honored from the root module.2False�
python_version�Python major.minor version to request, such as 3.11. The newest available patch
version is provisioned. Set pre_release to allow alpha, beta, or
release-candidate versions. �
target_compatible_with�Additional target platform constraints appended to each platform variant's
target_compatible_with list.

Only honored from the root module.2[]"(&//py/private/interpreter:extension.bzl�
�
	configureQConfigure the set of python-build-standalone releases to search for interpreters.�
build_config�python-build-standalone build configuration for the non-free-threaded
interpreter, hub-wide. This is the archive suffix PBS publishes, and selects
size/optimization/debug tradeoffs for every provisioned version and platform.

Supported values:
  - "install_only" (default): optimized, minimal redistributable (tar.gz).
  - "install_only_stripped": same as install_only with debug symbols removed
    (smallest download).
  - "<opt>[+<opt>...]-full": a full archive, where each component is one of
    debug, noopt, pgo, lto, in that order. Examples: "pgo+lto-full",
    "lto-full", "noopt-full", "debug-full".

Per-platform availability of the "-full" flavors, the "+static" and
"freethreaded" exclusions, and the Py_DEBUG caveat are documented in
docs/interpreter.md under "Build configuration".

Only honored from the root module.2"install_only"�
base_url�Base URL for downloading release assets. Defaults to the official PBS GitHub releases URL.
Override this to fetch from a mirror or fork, e.g.
"https://github.com/my-org/python-build-standalone/releases/download".
The URL should point to the directory containing release date directories,
such that {base_url}/{date}/SHA256SUMS is a valid path.

Only honored from the root module.2""�
releases�List of python-build-standalone release dates to search for interpreters,
e.g. ["20260303", "20241002"]. Newer releases are preferred when multiple
contain the same Python minor version.

The special value "latest" resolves to the newest release via the GitHub
releases API. This makes the extension non-reproducible: Bazel will
re-evaluate it on every invocation rather than caching the result.

See https://github.com/astral-sh/python-build-standalone/releases for
available releases.

Only honored from the root module. Non-root modules may include this tag
without error, but it will be silently ignored. �
�
build_config�python-build-standalone build configuration for the non-free-threaded
interpreter, hub-wide. This is the archive suffix PBS publishes, and selects
size/optimization/debug tradeoffs for every provisioned version and platform.

Supported values:
  - "install_only" (default): optimized, minimal redistributable (tar.gz).
  - "install_only_stripped": same as install_only with debug symbols removed
    (smallest download).
  - "<opt>[+<opt>...]-full": a full archive, where each component is one of
    debug, noopt, pgo, lto, in that order. Examples: "pgo+lto-full",
    "lto-full", "noopt-full", "debug-full".

Per-platform availability of the "-full" flavors, the "+static" and
"freethreaded" exclusions, and the Py_DEBUG caveat are documented in
docs/interpreter.md under "Build configuration".

Only honored from the root module.2"install_only"�
�
base_url�Base URL for downloading release assets. Defaults to the official PBS GitHub releases URL.
Override this to fetch from a mirror or fork, e.g.
"https://github.com/my-org/python-build-standalone/releases/download".
The URL should point to the directory containing release date directories,
such that {base_url}/{date}/SHA256SUMS is a valid path.

Only honored from the root module.2""�
�
releases�List of python-build-standalone release dates to search for interpreters,
e.g. ["20260303", "20241002"]. Newer releases are preferred when multiple
contain the same Python minor version.

The special value "latest" resolves to the newest release via the GitHub
releases API. This makes the extension non-reproducible: Bazel will
re-evaluate it on every invocation rather than caching the result.

See https://github.com/astral-sh/python-build-standalone/releases for
available releases.

Only honored from the root module. Non-root modules may include this tag
without error, but it will be silently ignored. �
�

	toolchain�
config_settings�Additional config_setting labels that must match for this toolchain to be selected.
Use this to gate a toolchain on a custom flag, e.g.
["//:use_hermetic_python"]. The settings are added to the toolchain's
target_settings alongside the version and platform constraints.

Only honored from the root module.2[]�
exec_compatible_with�Additional exec platform constraints appended to each platform variant's
exec-tools registration. Target runtime and C toolchains do not run on the
execution platform.

Only honored from the root module.2[]�
pre_release�Allow pre-release versions (alpha, beta, rc) for this toolchain.

By default, only final release versions are provisioned. Set this to True
to allow pre-release versions like 3.15.0a6 or 3.14.0b1. This is useful
for testing against upcoming Python versions that have no stable release yet.

Only honored from the root module.2False�
python_version�Python major.minor version to request, such as 3.11. The newest available patch
version is provisioned. Set pre_release to allow alpha, beta, or
release-candidate versions. �
target_compatible_with�Additional target platform constraints appended to each platform variant's
target_compatible_with list.

Only honored from the root module.2[]�
�
config_settings�Additional config_setting labels that must match for this toolchain to be selected.
Use this to gate a toolchain on a custom flag, e.g.
["//:use_hermetic_python"]. The settings are added to the toolchain's
target_settings alongside the version and platform constraints.

Only honored from the root module.2[]�
�
exec_compatible_with�Additional exec platform constraints appended to each platform variant's
exec-tools registration. Target runtime and C toolchains do not run on the
execution platform.

Only honored from the root module.2[]�
�
pre_release�Allow pre-release versions (alpha, beta, rc) for this toolchain.

By default, only final release versions are provisioned. Set this to True
to allow pre-release versions like 3.15.0a6 or 3.14.0b1. This is useful
for testing against upcoming Python versions that have no stable release yet.

Only honored from the root module.2False�
�
python_version�Python major.minor version to request, such as 3.11. The newest available patch
version is provisioned. Set pre_release to allow alpha, beta, or
release-candidate versions. �
�
target_compatible_with�Additional target platform constraints appended to each platform variant's
target_compatible_with list.

Only honored from the root module.2[]�py_toolsJ�
�
py_tools�
rules_py_tools�
name�Base name for generated repositories, allowing more than one toolchain to be registered.
Overriding the default is only permitted in the root module.2"rules_py_tools""//py:extensions.bzl�
�
rules_py_tools�
name�Base name for generated repositories, allowing more than one toolchain to be registered.
Overriding the default is only permitted in the root module.2"rules_py_tools"�
�
name�Base name for generated repositories, allowing more than one toolchain to be registered.
Overriding the default is only permitted in the root module.2"rules_py_tools"(Module Extensions used from MODULE.bazel�
pytoolchains.bzl�rules_py_toolchains+Create toolchain repositories for rules_py.*�
�
rules_py_toolchains?
name#prefix used in created repositories"rules_py_tools"(+Create toolchain repositories for rules_py.2*
rules_py_toolchains//py:toolchains.bzlA
?
name#prefix used in created repositories"rules_py_tools"(Declare toolchains 