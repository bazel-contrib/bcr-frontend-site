�
'examples/source_map_supportdefs.bzl�	js_binary*�
y
	js_binary

data[]
chdirNone
node_options[]
kwargs23
	js_binary&//examples/source_map_support:defs.bzl


data[]

chdirNone

node_options[]


kwargs�js_test*�
u
js_test

data[]
chdirNone
node_options[]
kwargs21
js_test&//examples/source_map_support:defs.bzl


data[]

chdirNone

node_options[]


kwargs�Macro wrappers around rules_js's `js_binary` and `js_test` that improve the DX of stack traces by automatically
registering source-map-support and removing the runfiles directory prefix.

Use them wherever you would use rules_js's `js_binary` and `js_test`.�`
swcdefs.bzl�3swc_compile�Underlying rule for the `swc` macro.

Most users should use [swc](#swc) instead, as it predicts the output files
and has convenient default values.

Use this if you need more control over how the rule is called,
for example to set your own output labels for `js_outs`."�1
�
swc_compile�Underlying rule for the `swc` macro.

Most users should use [swc](#swc) instead, as it predicts the output files
and has convenient default values.

Use this if you need more control over how the rule is called,
for example to set your own output labels for `js_outs`.*
nameA unique name for this target. @
srcs4source files, typically .ts files in the source tree �
args�Additional arguments to pass to swcx cli (NOT swc!).

NB: this is not the same as the CLI arguments for @swc/cli npm package.
For performance, rules_swc does not call a Node.js program wrapping the swc rust binding.
Instead, we directly spawn the (somewhat experimental) native Rust binary shipped inside the
@swc/core npm package, which the swc project calls "swcx"
Tracking issue for feature parity: https://github.com/swc-project/swc/issues/40172[]�
source_mapsiCreate source map files for emitted JavaScript files.

see https://swc.rs/docs/usage/cli#--source-maps--s2"false"�
source_root�Specify the root path for debuggers to find the reference source code.

see https://swc.rs/docs/usage/cli#--source-root

If not set, then the directory containing the source file is used.2""�

output_dir�Whether to produce a directory output rather than individual files.

If out_dir is also specified, it is used as the name of the output directory.
Otherwise, the directory is named the same as the target.2False�
data�Runtime dependencies to include in binaries/tests that depend on this target.

Follows the same semantics as `js_library` `data` attribute. See
https://docs.aspect.build/rulesets/aspect_rules_js/docs/js_library#data for more info.2[]c
swcrcRlabel of a configuration file for swc, see https://swc.rs/docs/configuration/swcrc2None�
plugins5swc compilation plugins, created with swc_plugin rule*g
DefaultInfo
SwcPluginConfigInfo
DefaultInfo<native>*
SwcPluginConfigInfo//swc:providers.bzl2[]�
out_dir�With output_dir=False, output files will have this directory prefix.

With output_dir=True, this is the name of the output directory.2""{
root_diria subdirectory under the input package which should be consider the root directory of all the input files2""�
emit_isolated_dts�Emit .d.ts files instead of .js for TypeScript sources

EXPERIMENTAL: this API is undocumented, experimental and may change without notice2False�
default_ext�Default extension for output files.

If a source file does not indicate a specific module type, this extension is used.

If unset, extensions will be determined based on the `js_outs` outputs attribute
or source file extensions.2""u
allow_jsaAllow JavaScript sources to be transpiled.

If False, only TypeScript sources will be transpiled.2Truei
js_outsVlist of expected JavaScript output files.

There should be one for each entry in srcs.2[]8�
map_outs�list of expected source map output files.

Can be empty, meaning no source maps should be produced.
If non-empty, there should be one for each entry in srcs.2[]8�
dts_outs�list of expected TypeScript declaration files.

Can be empty, meaning no dts files should be produced.
If non-empty, there should be one for each entry in srcs.2[]8"
swc_compile//swc:defs.bzl,
*
nameA unique name for this target. B
@
srcs4source files, typically .ts files in the source tree �
�
args�Additional arguments to pass to swcx cli (NOT swc!).

NB: this is not the same as the CLI arguments for @swc/cli npm package.
For performance, rules_swc does not call a Node.js program wrapping the swc rust binding.
Instead, we directly spawn the (somewhat experimental) native Rust binary shipped inside the
@swc/core npm package, which the swc project calls "swcx"
Tracking issue for feature parity: https://github.com/swc-project/swc/issues/40172[]�
�
source_mapsiCreate source map files for emitted JavaScript files.

see https://swc.rs/docs/usage/cli#--source-maps--s2"false"�
�
source_root�Specify the root path for debuggers to find the reference source code.

see https://swc.rs/docs/usage/cli#--source-root

If not set, then the directory containing the source file is used.2""�
�

output_dir�Whether to produce a directory output rather than individual files.

If out_dir is also specified, it is used as the name of the output directory.
Otherwise, the directory is named the same as the target.2False�
�
data�Runtime dependencies to include in binaries/tests that depend on this target.

Follows the same semantics as `js_library` `data` attribute. See
https://docs.aspect.build/rulesets/aspect_rules_js/docs/js_library#data for more info.2[]e
c
swcrcRlabel of a configuration file for swc, see https://swc.rs/docs/configuration/swcrc2None�
�
plugins5swc compilation plugins, created with swc_plugin rule*g
DefaultInfo
SwcPluginConfigInfo
DefaultInfo<native>*
SwcPluginConfigInfo//swc:providers.bzl2[]�
�
out_dir�With output_dir=False, output files will have this directory prefix.

With output_dir=True, this is the name of the output directory.2""}
{
root_diria subdirectory under the input package which should be consider the root directory of all the input files2""�
�
emit_isolated_dts�Emit .d.ts files instead of .js for TypeScript sources

EXPERIMENTAL: this API is undocumented, experimental and may change without notice2False�
�
default_ext�Default extension for output files.

If a source file does not indicate a specific module type, this extension is used.

If unset, extensions will be determined based on the `js_outs` outputs attribute
or source file extensions.2""w
u
allow_jsaAllow JavaScript sources to be transpiled.

If False, only TypeScript sources will be transpiled.2Truek
i
js_outsVlist of expected JavaScript output files.

There should be one for each entry in srcs.2[]8�
�
map_outs�list of expected source map output files.

Can be empty, meaning no source maps should be produced.
If non-empty, there should be one for each entry in srcs.2[]8�
�
dts_outs�list of expected TypeScript declaration files.

Can be empty, meaning no dts files should be produced.
If non-empty, there should be one for each entry in srcs.2[]8�"swcExecute the SWC compiler*�"
�
swc 
nameA name for this target 4
srcs*List of labels of TypeScript source files. �
args�Additional options to pass to `swcx` cli, see https://github.com/swc-project/swc/discussions/3859
Note: we do **not** run the [NodeJS wrapper `@swc/cli`](https://swc.rs/docs/usage/cli)[]�
data�Files needed at runtime by binaries or tests that transitively depend on this target.
See https://bazel.build/reference/be/common-definitions#typical-attributes[]?
plugins0List of plugin labels created with `swc_plugin`.[]�

output_dir�Whether to produce a directory output rather than individual files.

If `out_dir` is set, then that is used as the name of the output directory.
Otherwise, the output directory is named the same as the target.False�
swcrc�Label of a .swcrc configuration file for the SWC cli, see https://swc.rs/docs/configuration/swcrc
Instead of a label, you can pass a dictionary matching the JSON schema.
If this attribute isn't specified, and a file `.swcrc` exists in the same folder as this rule, it is used.

Note that some settings in `.swcrc` also appear in `tsconfig.json`.
See the notes in [/docs/tsconfig.md].None�
source_maps�If set, the --source-maps argument is passed to the SWC cli with the value.
See https://swc.rs/docs/usage/cli#--source-maps--s.
True/False are automaticaly converted to "true"/"false" string values the cli expects.False�
out_dir�The base directory for output files relative to the output directory for this package.

If output_dir is True, then this is used as the name of the output directory.None}
root_dirkA subdirectory under the input package which should be considered the root directory of all the input filesNonef
default_extPThe default extension to use for output files. If not set, the default is ".js".".js"�
allow_js�If `True` (default), then .js/.mjs/.cjs input files are transpiled. If `False`,
they are ignored. This can be used to mimic the behavior of tsc when using `ts_project(transpiler)`.True{
kwargsqadditional keyword arguments passed through to underlying [`swc_compile`](#swc_compile), eg. `visibility`, `tags`Execute the SWC compiler2
swc//swc:defs.bzl"
 
nameA name for this target 6
4
srcs*List of labels of TypeScript source files. �
�
args�Additional options to pass to `swcx` cli, see https://github.com/swc-project/swc/discussions/3859
Note: we do **not** run the [NodeJS wrapper `@swc/cli`](https://swc.rs/docs/usage/cli)[]�
�
data�Files needed at runtime by binaries or tests that transitively depend on this target.
See https://bazel.build/reference/be/common-definitions#typical-attributes[]A
?
plugins0List of plugin labels created with `swc_plugin`.[]�
�

output_dir�Whether to produce a directory output rather than individual files.

If `out_dir` is set, then that is used as the name of the output directory.
Otherwise, the output directory is named the same as the target.False�
�
swcrc�Label of a .swcrc configuration file for the SWC cli, see https://swc.rs/docs/configuration/swcrc
Instead of a label, you can pass a dictionary matching the JSON schema.
If this attribute isn't specified, and a file `.swcrc` exists in the same folder as this rule, it is used.

Note that some settings in `.swcrc` also appear in `tsconfig.json`.
See the notes in [/docs/tsconfig.md].None�
�
source_maps�If set, the --source-maps argument is passed to the SWC cli with the value.
See https://swc.rs/docs/usage/cli#--source-maps--s.
True/False are automaticaly converted to "true"/"false" string values the cli expects.False�
�
out_dir�The base directory for output files relative to the output directory for this package.

If output_dir is True, then this is used as the name of the output directory.None
}
root_dirkA subdirectory under the input package which should be considered the root directory of all the input filesNoneh
f
default_extPThe default extension to use for output files. If not set, the default is ".js".".js"�
�
allow_js�If `True` (default), then .js/.mjs/.cjs input files are transpiled. If `False`,
they are ignored. This can be used to mimic the behavior of tsc when using `ts_project(transpiler)`.True}
{
kwargsqadditional keyword arguments passed through to underlying [`swc_compile`](#swc_compile), eg. `visibility`, `tags`�
swc_pluginConfigure an SWC plugin*�
�

swc_plugin 
nameA name for this target �
srcs�Plugin files. Either a directory containing a package.json pointing at a wasm file
as the main entrypoint, or a wasm file. Usually a linked npm package target via rules_js.[]�
config�Optional configuration dict for the plugin. This is passed as a JSON object into the
`jsc.experimental.plugins` entry for the plugin.{}b
kwargsXadditional keyword arguments passed through to underlying rule, eg. `visibility`, `tags`Configure an SWC plugin2

swc_plugin//swc:defs.bzl"
 
nameA name for this target �
�
srcs�Plugin files. Either a directory containing a package.json pointing at a wasm file
as the main entrypoint, or a wasm file. Usually a linked npm package target via rules_js.[]�
�
config�Optional configuration dict for the plugin. This is passed as a JSON object into the
`jsc.experimental.plugins` entry for the plugin.{}d
b
kwargsXadditional keyword arguments passed through to underlying rule, eg. `visibility`, `tags`�API for running the SWC cli under Bazel

The simplest usage relies on the `swcrc` attribute automatically discovering `.swcrc`:

```starlark
load("@aspect_rules_swc//swc:defs.bzl", "swc")

swc(
    name = "compile",
    srcs = ["file.ts"],
)
```�
swcdependencies.bzl`http_archive*N
@
http_archive
kwargs2&
http_archive//swc:dependencies.bzl


kwargshrules_swc_dependencies*L
J
rules_swc_dependencies20
rules_swc_dependencies//swc:dependencies.bzl�Starlark helper to fetch rules_swc dependencies.

These are needed for local dev, and users must install them as well.
See https://docs.bazel.build/versions/main/skylark/deploying.html#dependencies

Replaced by bzlmod for users of Bazel 6.0 and above.�
swcproviders.bzl�SwcPluginConfigInfo*Provides a configuration for an SWC plugin2�
�
SwcPluginConfigInfo*Provides a configuration for an SWC plugin;
label2the label of the target that created this providerE
config;the plugin configuration string, encoded from a JSON object"*
SwcPluginConfigInfo//swc:providers.bzl=
;
label2the label of the target that created this providerG
E
config;the plugin configuration string, encoded from a JSON object'Providers for building derivative rules�-
swcrepositories.bzl�swc_register_toolchains�Convenience macro for users which does typical setup.

- create a repository for each built-in platform like "swc_linux_amd64"
- create a repository exposing toolchains for each platform like "swc_platforms"
- register a toolchain pointing at each platform
Users can avoid this macro and do these steps themselves, if they want more control.
*�
�
swc_register_toolchains=
name3base name for all created repos; we recommend `swc` �
swc_version�version of the swc project, from https://github.com/swc-project/swc/releases
Exactly one of `swc_version` or `swc_version_from` must be set.None�
swc_version_from�label of a json file which declares an `@swc/core` version.

This may be a `package.json` file, with "@swc/core" in the dependencies or
devDependencies property, and the version exactly specified.

With rules_js v1.32.0 or greater, it may also be a `resolved.json` file
produced by `npm_translate_lock`, such as
`@npm//path/to/linked:@swc/core/resolved.json`

Exactly one of `swc_version` or `swc_version_from` must be set.None�
	platformselist of platforms (must be a key in PLATFORMS) to register toolchains for.
Defaults to all platforms.�["darwin-arm64", "darwin-x64", "linux-arm64-gnu", "linux-arm64-musl", "linux-x64-gnu", "linux-x64-musl", "win32-arm64-msvc", "win32-ia32-msvc", "win32-x64-msvc"]�
register�whether to call through to native.register_toolchains.
Should be True for WORKSPACE users, but false when used under bzlmod extensionTrue.
kwargs$passed to each swc_repositories call�Convenience macro for users which does typical setup.

- create a repository for each built-in platform like "swc_linux_amd64"
- create a repository exposing toolchains for each platform like "swc_platforms"
- register a toolchain pointing at each platform
Users can avoid this macro and do these steps themselves, if they want more control.
21
swc_register_toolchains//swc:repositories.bzl?
=
name3base name for all created repos; we recommend `swc` �
�
swc_version�version of the swc project, from https://github.com/swc-project/swc/releases
Exactly one of `swc_version` or `swc_version_from` must be set.None�
�
swc_version_from�label of a json file which declares an `@swc/core` version.

This may be a `package.json` file, with "@swc/core" in the dependencies or
devDependencies property, and the version exactly specified.

With rules_js v1.32.0 or greater, it may also be a `resolved.json` file
produced by `npm_translate_lock`, such as
`@npm//path/to/linked:@swc/core/resolved.json`

Exactly one of `swc_version` or `swc_version_from` must be set.None�
�
	platformselist of platforms (must be a key in PLATFORMS) to register toolchains for.
Defaults to all platforms.�["darwin-arm64", "darwin-x64", "linux-arm64-gnu", "linux-arm64-musl", "linux-x64-gnu", "linux-x64-musl", "win32-arm64-msvc", "win32-ia32-msvc", "win32-x64-msvc"]�
�
register�whether to call through to native.register_toolchains.
Should be True for WORKSPACE users, but false when used under bzlmod extensionTrue0
.
kwargs$passed to each swc_repositories call�swc_repositories5Fetch external dependencies needed to run the SWC cliR�
�
swc_repositories5Fetch external dependencies needed to run the SWC cli.
name"A unique name for this repository. �
repo_mapping�In `WORKSPACE` context only: a dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.

For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).

This attribute is _not_ supported in `MODULE.bazel` context (when invoking a repository rule inside a module extension's implementation function).
Q
swc_version<Explicit version. If provided, the package.json is not read.2""W
swc_version_from;Location of package.json which has a version for @swc/core.2None
platform D
integrity_hashes*A mapping from platform to integrity hash.
2{}**
swc_repositories//swc:repositories.bzl0
.
name"A unique name for this repository. �
�
repo_mapping�In `WORKSPACE` context only: a dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.

For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).

This attribute is _not_ supported in `MODULE.bazel` context (when invoking a repository rule inside a module extension's implementation function).
S
Q
swc_version<Explicit version. If provided, the package.json is not read.2""Y
W
swc_version_from;Location of package.json which has a version for @swc/core.2None

platform F
D
integrity_hashes*A mapping from platform to integrity hash.
2{}�Repository rules for fetching the swc toolchain.

For typical usage, see the snippets provided in the rules_swc release notes.

### Version matching

To keep the swc version in sync with non-Bazel tooling, use `swc_version_from`.

Currently this only works when a single, pinned version appears, see:
https://github.com/aspect-build/rules_ts/issues/308

For example, `package.json`:

```json
{
  "devDependencies": {
    "@swc/core": "1.3.37"
  }
}
```

Allows this in `WORKSPACE`:

```starlark
swc_register_toolchains(
    name = "swc",
    swc_version_from = "//:package.json",
)
```�
swctoolchain.bzl�swc_toolchain�Defines a swc compiler/runtime toolchain.

For usage see https://docs.bazel.build/versions/main/toolchains.html#defining-toolchains."�
�
swc_toolchain�Defines a swc compiler/runtime toolchain.

For usage see https://docs.bazel.build/versions/main/toolchains.html#defining-toolchains.*
nameA unique name for this target. T
target_tool=A hermetically downloaded 'swcx' cli for the target platform.2NoneQ
target_tool_path7Path to an existing 'swcx' cli for the target platform.2"""$
swc_toolchain//swc:toolchain.bzl,
*
nameA unique name for this target. V
T
target_tool=A hermetically downloaded 'swcx' cli for the target platform.2NoneS
Q
target_tool_path7Path to an existing 'swcx' cli for the target platform.2""�SwcInfo4Information about how to invoke the tool executable.2�
�
SwcInfo4Information about how to invoke the tool executable.I

swc_binary;Path to the rust-native 'swcx' cli for the target platform.�

tool_files�Files required in runfiles to make the tool executable available.

May be empty if the target_tool_path points to a locally installed tool binary."
SwcInfo//swc:toolchain.bzlK
I

swc_binary;Path to the rust-native 'swcx' cli for the target platform.�
�

tool_files�Files required in runfiles to make the tool executable available.

May be empty if the target_tool_path points to a locally installed tool binary.<This module implements the language-specific toolchain rule. 