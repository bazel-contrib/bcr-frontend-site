ޣ
tsdefs.bzl�		ts_config�Allows a tsconfig.json file to extend another file.

Normally, you just give a single `tsconfig.json` file as the tsconfig attribute
of a `ts_library` or `ts_project` rule. However, if your `tsconfig.json` uses the `extends`
feature from TypeScript, then the Bazel implementation needs to know about that
extended configuration file as well, to pass them both to the TypeScript compiler."�
�
	ts_config�Allows a tsconfig.json file to extend another file.

Normally, you just give a single `tsconfig.json` file as the tsconfig attribute
of a `ts_library` or `ts_project` rule. However, if your `tsconfig.json` uses the `extends`
feature from TypeScript, then the Bazel implementation needs to know about that
extended configuration file as well, to pass them both to the TypeScript compiler.*
nameA unique name for this target. C
deps5Additional tsconfig.json files referenced via extends2[]C
src8The tsconfig.json file passed to the TypeScript compiler "'
	ts_config//ts/private:ts_config.bzl,
*
nameA unique name for this target. E
C
deps5Additional tsconfig.json files referenced via extends2[]E
C
src8The tsconfig.json file passed to the TypeScript compiler �[ts_project_rule�Implementation rule behind the ts_project macro.
Most users should use [ts_project](#ts_project) instead.

This skips conveniences like validation of the tsconfig attributes, default settings
for srcs and tsconfig, and pre-declaring output files."�Y
�-
ts_project_rule�Implementation rule behind the ts_project macro.
Most users should use [ts_project](#ts_project) instead.

This skips conveniences like validation of the tsconfig attributes, default settings
for srcs and tsconfig, and pre-declaring output files.*
nameA unique name for this target. D
allow_js/https://www.typescriptlang.org/tsconfig#allowJs2FalseG
	composite1https://www.typescriptlang.org/tsconfig#composite2FalseK
declaration3https://www.typescriptlang.org/tsconfig#declaration2FalseR
declaration_map6https://www.typescriptlang.org/tsconfig#declarationMap2FalseB
no_emit.https://www.typescriptlang.org/tsconfig#noEmit2False]
emit_declaration_only;https://www.typescriptlang.org/tsconfig#emitDeclarationOnly2FalseB
extends/https://www.typescriptlang.org/tsconfig#extends2NoneK
incremental3https://www.typescriptlang.org/tsconfig#incremental2FalseD
preserve_jsx+https://www.typescriptlang.org/tsconfig#jsx2FalseY
resolve_json_module9https://www.typescriptlang.org/tsconfig#resolveJsonModule2FalseH

source_map1https://www.typescriptlang.org/tsconfig#sourceMap2FalseS
ts_build_info_file7https://www.typescriptlang.org/tsconfig#tsBuildInfoFile2""Q
generate_trace6https://www.typescriptlang.org/tsconfig/#generateTrace2False�
assets�Files which are needed by a downstream build step such as a bundler.

See more details on the `assets` parameter of the `ts_project` macro.2[]P
argsBhttps://www.typescriptlang.org/docs/handbook/compiler-options.html2[]�
data�Runtime dependencies to include in binaries/tests that depend on this target.

Follows the same semantics as `js_library` `data` attribute. See
https://docs.aspect.build/rulesets/aspect_rules_js/docs/js_library#data for more info.2[]O
declaration_dir6https://www.typescriptlang.org/tsconfig#declarationDir2""�
deps�List of targets that produce TypeScript typings (`.d.ts` files)

Follows the same runfiles semantics as `js_library` `deps` attribute. See
https://docs.aspect.build/rulesets/aspect_rules_js/docs/js_library#deps for more info.2[]?
out_dir.https://www.typescriptlang.org/tsconfig#outDir2""A
root_dir/https://www.typescriptlang.org/tsconfig#rootDir2""#
srcsTypeScript source files �
supports_workers�Whether to use a custom `tsc` compiler which understands Bazel's persistent worker protocol.

See the docs for `supports_workers` on the [`ts_project`](#ts_project-supports_workers) macro.20M
is_typescript_5_or_greater&Whether TypeScript version is >= 5.0.02False�
	transpile�Whether tsc should be used to produce .js outputs

Values are:
- -1: Error if --@aspect_rules_ts//ts:default_to_tsc_transpiler not set, otherwise transpile
- 0: Do not transpile
- 1: Transpile2-1X
pretranspiled_js<Externally transpiled .js to be included in output providers2None[
pretranspiled_dts>Externally transpiled .d.ts to be included in output providers2NoneU
declaration_transpile3Whether tsc should be used to produce .d.ts outputs2False%
tscTypeScript compiler binary 3

tsc_worker!TypeScript compiler worker binary O
tsconfig?tsconfig.json file, see https://www.typescriptlang.org/tsconfig �
eslintconfig�.eslintrc file, or other filenames accepted by ESLint.
see https://eslint.org/docs/latest/use/configure/configuration-files
Note, this is unused in rules_ts, but exists to allow the information to propagate through the dependency graph.
For example, it can be used by the eslint aspect in Aspect's rules_lint.2None�
isolated_typecheck�Whether type-checking should be a separate action.

This allows the transpilation action to run without waiting for typings from dependencies.

Requires a minimum version of typescript 5.6 for the [noCheck](https://www.typescriptlang.org/tsconfig#noCheck)
flag which is automatically set on the transpilation action when the typecheck action is isolated.

Requires [isolatedDeclarations](https://www.typescriptlang.org/tsconfig#isolatedDeclarations)
to be set so that declarations can be emitted without dependencies. The use of `isolatedDeclarations` may
require significant changes to your codebase and should be done as a pre-requisite to enabling `isolated_typecheck`.2False~
validatejwhether to add a Validation Action to verify the other attributes match
settings in the tsconfig.json file2True�
build_progress_messagegCustom progress message for the build action.
You can use {label} and {tsconfig_path} as substitutions.2]"Transpiling{emit_part}{type_check_part} TypeScript project {label} [tsc -p {tsconfig_path}]"�
#isolated_typecheck_progress_messagetCustom progress message for the isolated typecheck action.
You can use {label} and {tsconfig_path} as substitutions.2C"Type-checking TypeScript project {label} [tsc -p {tsconfig_path}]"
	validator [
buildinfo_out@Location in bazel-out where tsc will write a `.tsbuildinfo` file2None8J
js_outs7Locations in bazel-out where tsc will write `.js` files2[]8O
map_outs;Locations in bazel-out where tsc will write `.js.map` files2[]8Y
typing_maps_outs=Locations in bazel-out where tsc will write `.d.ts.map` files2[]8Q
typings_outs9Locations in bazel-out where tsc will write `.d.ts` files2[]8�
resource_set�A predefined function used as the resource_set for actions.

Used with --experimental_action_resource_set to reserve more RAM/CPU, preventing Bazel overscheduling resource-intensive actions.

By default, Bazel allocates 1 CPU and 250M of RAM.
https://github.com/bazelbuild/bazel/blob/058f943037e21710837eda9ca2f85b5f8538c8c5/src/main/java/com/google/devtools/build/lib/actions/AbstractAction.java#L772	"default"")

ts_project//ts/private:ts_project.bzl,
*
nameA unique name for this target. F
D
allow_js/https://www.typescriptlang.org/tsconfig#allowJs2FalseI
G
	composite1https://www.typescriptlang.org/tsconfig#composite2FalseM
K
declaration3https://www.typescriptlang.org/tsconfig#declaration2FalseT
R
declaration_map6https://www.typescriptlang.org/tsconfig#declarationMap2FalseD
B
no_emit.https://www.typescriptlang.org/tsconfig#noEmit2False_
]
emit_declaration_only;https://www.typescriptlang.org/tsconfig#emitDeclarationOnly2FalseD
B
extends/https://www.typescriptlang.org/tsconfig#extends2NoneM
K
incremental3https://www.typescriptlang.org/tsconfig#incremental2FalseF
D
preserve_jsx+https://www.typescriptlang.org/tsconfig#jsx2False[
Y
resolve_json_module9https://www.typescriptlang.org/tsconfig#resolveJsonModule2FalseJ
H

source_map1https://www.typescriptlang.org/tsconfig#sourceMap2FalseU
S
ts_build_info_file7https://www.typescriptlang.org/tsconfig#tsBuildInfoFile2""S
Q
generate_trace6https://www.typescriptlang.org/tsconfig/#generateTrace2False�
�
assets�Files which are needed by a downstream build step such as a bundler.

See more details on the `assets` parameter of the `ts_project` macro.2[]R
P
argsBhttps://www.typescriptlang.org/docs/handbook/compiler-options.html2[]�
�
data�Runtime dependencies to include in binaries/tests that depend on this target.

Follows the same semantics as `js_library` `data` attribute. See
https://docs.aspect.build/rulesets/aspect_rules_js/docs/js_library#data for more info.2[]Q
O
declaration_dir6https://www.typescriptlang.org/tsconfig#declarationDir2""�
�
deps�List of targets that produce TypeScript typings (`.d.ts` files)

Follows the same runfiles semantics as `js_library` `deps` attribute. See
https://docs.aspect.build/rulesets/aspect_rules_js/docs/js_library#deps for more info.2[]A
?
out_dir.https://www.typescriptlang.org/tsconfig#outDir2""C
A
root_dir/https://www.typescriptlang.org/tsconfig#rootDir2""%
#
srcsTypeScript source files �
�
supports_workers�Whether to use a custom `tsc` compiler which understands Bazel's persistent worker protocol.

See the docs for `supports_workers` on the [`ts_project`](#ts_project-supports_workers) macro.20O
M
is_typescript_5_or_greater&Whether TypeScript version is >= 5.0.02False�
�
	transpile�Whether tsc should be used to produce .js outputs

Values are:
- -1: Error if --@aspect_rules_ts//ts:default_to_tsc_transpiler not set, otherwise transpile
- 0: Do not transpile
- 1: Transpile2-1Z
X
pretranspiled_js<Externally transpiled .js to be included in output providers2None]
[
pretranspiled_dts>Externally transpiled .d.ts to be included in output providers2NoneW
U
declaration_transpile3Whether tsc should be used to produce .d.ts outputs2False'
%
tscTypeScript compiler binary 5
3

tsc_worker!TypeScript compiler worker binary Q
O
tsconfig?tsconfig.json file, see https://www.typescriptlang.org/tsconfig �
�
eslintconfig�.eslintrc file, or other filenames accepted by ESLint.
see https://eslint.org/docs/latest/use/configure/configuration-files
Note, this is unused in rules_ts, but exists to allow the information to propagate through the dependency graph.
For example, it can be used by the eslint aspect in Aspect's rules_lint.2None�
�
isolated_typecheck�Whether type-checking should be a separate action.

This allows the transpilation action to run without waiting for typings from dependencies.

Requires a minimum version of typescript 5.6 for the [noCheck](https://www.typescriptlang.org/tsconfig#noCheck)
flag which is automatically set on the transpilation action when the typecheck action is isolated.

Requires [isolatedDeclarations](https://www.typescriptlang.org/tsconfig#isolatedDeclarations)
to be set so that declarations can be emitted without dependencies. The use of `isolatedDeclarations` may
require significant changes to your codebase and should be done as a pre-requisite to enabling `isolated_typecheck`.2False�
~
validatejwhether to add a Validation Action to verify the other attributes match
settings in the tsconfig.json file2True�
�
build_progress_messagegCustom progress message for the build action.
You can use {label} and {tsconfig_path} as substitutions.2]"Transpiling{emit_part}{type_check_part} TypeScript project {label} [tsc -p {tsconfig_path}]"�
�
#isolated_typecheck_progress_messagetCustom progress message for the isolated typecheck action.
You can use {label} and {tsconfig_path} as substitutions.2C"Type-checking TypeScript project {label} [tsc -p {tsconfig_path}]"

	validator ]
[
buildinfo_out@Location in bazel-out where tsc will write a `.tsbuildinfo` file2None8L
J
js_outs7Locations in bazel-out where tsc will write `.js` files2[]8Q
O
map_outs;Locations in bazel-out where tsc will write `.js.map` files2[]8[
Y
typing_maps_outs=Locations in bazel-out where tsc will write `.d.ts.map` files2[]8S
Q
typings_outs9Locations in bazel-out where tsc will write `.d.ts` files2[]8�
�
resource_set�A predefined function used as the resource_set for actions.

Used with --experimental_action_resource_set to reserve more RAM/CPU, preventing Bazel overscheduling resource-intensive actions.

By default, Bazel allocates 1 CPU and 250M of RAM.
https://github.com/bazelbuild/bazel/blob/058f943037e21710837eda9ca2f85b5f8538c8c5/src/main/java/com/google/devtools/build/lib/actions/AbstractAction.java#L772	"default"��
ts_project�Compiles one TypeScript project using `tsc --project`.

This is a drop-in replacement for the `tsc` rule automatically generated for the "typescript"
package, typically loaded from `@npm//typescript:package_json.bzl`.
Unlike bare `tsc`, this rule understands the Bazel interop mechanism (Providers)
so that this rule works with others that produce or consume TypeScript typings (`.d.ts` files).

Some TypeScript options affect which files are emitted, and Bazel needs to predict these ahead-of-time.
As a result, several options from the tsconfig file must be mirrored as attributes to ts_project.
A validation action is run to help ensure that these are correctly mirrored.
See https://www.typescriptlang.org/tsconfig for a listing of the TypeScript options.

If you have problems getting your `ts_project` to work correctly, read the dedicated
[troubleshooting guide](/docs/troubleshooting.md).
*�
�\

ts_project 
namea name for this target �
tsconfig�Label of the tsconfig.json file to use for the compilation.
To support "chaining" of more than one extended config, this label could be a target that
provides `TsConfigInfo` such as `ts_config`.

By default, if a "tsconfig.json" file is in the same folder with the ts_project rule, it is used.

Instead of a label, you can pass a dictionary matching the JSON schema.

See [docs/tsconfig.md](/docs/tsconfig.md) for detailed information.None�
srcs�List of labels of TypeScript source files to be provided to the compiler.

If absent, the default is set as follows:

- Include all TypeScript files in the package, recursively.
- If `allow_js` is set, include all JavaScript files in the package as well.
- If `resolve_json_module` is set, include all JSON files in the package,
  but exclude `package.json`, `package-lock.json`, and `tsconfig*.json`.None�
args�List of strings of additional command-line arguments to pass to tsc.
See https://www.typescriptlang.org/docs/handbook/compiler-options.html#compiler-options
Typically useful arguments for debugging are `--listFiles` and `--listEmittedFiles`.[]�
data�Files needed at runtime by binaries or tests that transitively depend on this target.
See https://bazel.build/reference/be/common-definitions#typical-attributes[]�	
deps�	List of targets that produce TypeScript typings (`.d.ts` files)

If this list contains linked npm packages, npm package store targets or other targets that provide
`JsInfo`, `NpmPackageStoreInfo` providers are gathered from `JsInfo`. This is done directly from
the `npm_package_store_deps` field of these. For linked npm package targets, the underlying
`npm_package_store` target(s) that back the links is used. Gathered `NpmPackageStoreInfo`
providers are propagated to the direct dependencies of downstream linked `npm_package` targets.

NB: Linked npm package targets that are "dev" dependencies do not forward their underlying
`npm_package_store` target(s) through `npm_package_store_deps` and will therefore not be
propagated to the direct dependencies of downstream linked `npm_package` targets. npm packages
that come in from `npm_translate_lock` are considered "dev" dependencies if they are have
`dev: true` set in the pnpm lock file. This should be all packages that are only listed as
"devDependencies" in all `package.json` files within the pnpm workspace. This behavior is
intentional to mimic how `devDependencies` work in published npm packages.[]�
assets�Files which are needed by a downstream build step such as a bundler.

These files are **not** included as inputs to any actions spawned by `ts_project`.
They are not transpiled, and are not visible to the type-checker.
Instead, these files appear among the *outputs* of this target.

A typical use is when your TypeScript code has an import that TS itself doesn't understand
such as

`import './my.scss'`

and the type-checker allows this because you have an "ambient" global type declaration like

`declare module '*.scss' { ... }`

A bundler like webpack will expect to be able to resolve the `./my.scss` import to a file
and doesn't care about the typing declaration. A bundler runs as a build step,
so it does not see files included in the `data` attribute.

Note that `data` is used for files that are resolved by some binary, including a test
target. Behind the scenes, `data` populates Bazel's Runfiles object in `DefaultInfo`,
while this attribute populates the `transitive_sources` of the `JsInfo`.[]�
extends�Label of the tsconfig file referenced in the `extends` section of tsconfig
To support "chaining" of more than one extended config, this label could be a target that
provdes `TsConfigInfo` such as `ts_config`.None�
allow_js�Whether TypeScript will read .js and .jsx files.
When used with `declaration`, TypeScript will generate `.d.ts` files from `.js` files.False�
isolated_typecheck�Whether to type-check asynchronously as a separate bazel action from transpilation.

Any transpiling with `tsc` will only contain the `ts_project(tsconfig)` dependencies, while type-checking
actions will also include the `ts_project(deps)` dependencies.

Requires https://devblogs.microsoft.com/typescript/announcing-typescript-5-6/#the---nocheck-option6
Requires https://www.typescriptlang.org/docs/handbook/release-notes/typescript-5-5.html#isolated-declarationsFalse�
declarationwWhether the `declaration` bit is set in the tsconfig.
Instructs Bazel to expect a `.d.ts` output for each `.ts` source.False�

source_mapwWhether the `sourceMap` bit is set in the tsconfig.
Instructs Bazel to expect a `.js.map` output for each `.ts` source.False�
declaration_map~Whether the `declarationMap` bit is set in the tsconfig.
Instructs Bazel to expect a `.d.ts.map` output for each `.ts` source.False�
resolve_json_module�Boolean; specifies whether TypeScript will read .json files.
If set to True or False and tsconfig is a dict, resolveJsonModule is set in the generated config file.
If set to None and tsconfig is a dict, resolveJsonModule is unset in the generated config and typescript
default or extended tsconfig value will be load bearing.None�
preserve_jsx�Whether the `jsx` value is set to "preserve" in the tsconfig.
Instructs Bazel to expect a `.jsx` or `.jsx.map` output for each `.tsx` source.False�
	composite�Whether the `composite` bit is set in the tsconfig.
Instructs Bazel to expect a `.tsbuildinfo` output and a `.d.ts` output for each `.ts` source.False~
incrementalhWhether the `incremental` bit is set in the tsconfig.
Instructs Bazel to expect a `.tsbuildinfo` output.Falseo
no_emit]Whether the `noEmit` bit is set in the tsconfig.
Instructs Bazel *not* to expect any outputs.False�
emit_declaration_only�Whether the `emitDeclarationOnly` bit is set in the tsconfig.
Instructs Bazel *not* to expect `.js` or `.js.map` outputs for `.ts` sources.False�

transpiler�A custom transpiler tool to run that produces the JavaScript outputs instead of `tsc`.

Under `--@aspect_rules_ts//ts:default_to_tsc_transpiler`, the default is to use `tsc` to produce
`.js` outputs in the same action that does the type-checking to produce `.d.ts` outputs.
This is the simplest configuration, however `tsc` is slower than alternatives.
It also means developers must wait for the type-checking in the developer loop.

Without `--@aspect_rules_ts//ts:default_to_tsc_transpiler`, an explicit value must be set.
This may be the string `"tsc"` to explicitly choose `tsc`, just like the default above.

It may also be any rule or macro with this signature: `(name, srcs, **kwargs)`

If JavaScript outputs are configured to not be emitted the custom transpiler will not be used, such as
when `no_emit = True` or `emit_declaration_only = True`.

See [docs/transpiler.md](/docs/transpiler.md) for more details.None�
declaration_transpiler�A custom transpiler tool to run that produces the TypeScript declaration outputs instead of `tsc`.

It may be any rule or macro with this signature: `(name, srcs, **kwargs)`

If TypeScript declaration outputs are configured to not be emitted the custom declaration transpiler will
not be used, such as when `no_emit = True` or `declaration = False`.

See [docs/transpiler.md](/docs/transpiler.md) for more details.None�
ts_build_info_file�The user-specified value of `tsBuildInfoFile` from the tsconfig.
Helps Bazel to predict the path where the .tsbuildinfo output is written.None�
generate_trace�Whether to generate a trace file for TypeScript compiler performance analysis.
When enabled, creates a trace directory containing performance tracing information that can be
loaded in chrome://tracing. Use the `--@aspect_rules_ts//ts:generate_tsc_trace` flag to enable this by default.None�
tsc�Label of the TypeScript compiler binary to run.
This allows you to use a custom API-compatible compiler in place of the regular `tsc` such as a custom `js_binary` or Angular's `ngc`.
compatible with it such as Angular's `ngc`.

See examples of use in [examples/custom_compiler](https://github.com/aspect-build/rules_ts/blob/main/examples/custom_compiler/BUILD.bazel)"@npm_typescript//:tsc"�

tsc_workerbLabel of a custom TypeScript compiler binary which understands Bazel's persistent worker protocol."@npm_typescript//:tsc_worker"�
validate�Whether to check that the dependencies are valid and the tsconfig JSON settings match the attributes on this target.
Set this to `False` to skip running our validator, in case you have a legitimate reason for these to differ,
e.g. you have a setting enabled just for the editor but you want different behavior when Bazel runs `tsc`.Truej
	validator>Label of the tsconfig validator to run when `validate = True`."@npm_typescript//:validator"�
declaration_dir�String specifying a subdirectory under the bazel-out folder where generated declaration
outputs are written. Equivalent to the TypeScript --declarationDir option.
By default declarations are written to the out_dir.None�
out_dir�String specifying a subdirectory under the bazel-out folder where outputs are written.
Equivalent to the TypeScript --outDir option.

Note that Bazel always requires outputs be written under a subdirectory matching the input package,
so if your rule appears in `path/to/my/package/BUILD.bazel` and out_dir = "foo" then the .js files
will appear in `bazel-out/[arch]/bin/path/to/my/package/foo/*.js`.

By default the out_dir is the package's folder under bazel-out.None�
root_dir�String specifying a subdirectory under the input package which should be consider the
root directory of all the input files.
Equivalent to the TypeScript --rootDir option.
By default it is '.', meaning the source directory where the BUILD file lives.None�
supports_workers�Whether the "Persistent Worker" protocol is enabled.
This uses a custom `tsc` compiler to make rebuilds faster.
Note that this causes some known correctness bugs, see
https://github.com/aspect-build/rules_ts/blob/main/docs/troubleshooting.md#problems-with-persistent-workers.
We do not intend to fix these bugs.

Worker mode can be enabled for all `ts_project`s in a build with the global
`--@aspect_rules_ts//ts:supports_workers` flag.
To enable worker mode for all builds in the workspace, add
`build --@aspect_rules_ts//ts:supports_workers` to the .bazelrc.

This is a "tri-state" attribute, accepting values `[-1, 0, 1]`. The behavior is:

- `-1`: use the value of the global `--@aspect_rules_ts//ts:supports_workers` flag.
- `0`: Override the global flag, disabling workers for this target.
- `1`: Override the global flag, enabling workers for this target.-1f
kwargs\passed through to underlying [`ts_project_rule`](#ts_project_rule), eg. `visibility`, `tags`�Compiles one TypeScript project using `tsc --project`.

This is a drop-in replacement for the `tsc` rule automatically generated for the "typescript"
package, typically loaded from `@npm//typescript:package_json.bzl`.
Unlike bare `tsc`, this rule understands the Bazel interop mechanism (Providers)
so that this rule works with others that produce or consume TypeScript typings (`.d.ts` files).

Some TypeScript options affect which files are emitted, and Bazel needs to predict these ahead-of-time.
As a result, several options from the tsconfig file must be mirrored as attributes to ts_project.
A validation action is run to help ensure that these are correctly mirrored.
See https://www.typescriptlang.org/tsconfig for a listing of the TypeScript options.

If you have problems getting your `ts_project` to work correctly, read the dedicated
[troubleshooting guide](/docs/troubleshooting.md).
2

ts_project//ts:defs.bzl"
 
namea name for this target �
�
tsconfig�Label of the tsconfig.json file to use for the compilation.
To support "chaining" of more than one extended config, this label could be a target that
provides `TsConfigInfo` such as `ts_config`.

By default, if a "tsconfig.json" file is in the same folder with the ts_project rule, it is used.

Instead of a label, you can pass a dictionary matching the JSON schema.

See [docs/tsconfig.md](/docs/tsconfig.md) for detailed information.None�
�
srcs�List of labels of TypeScript source files to be provided to the compiler.

If absent, the default is set as follows:

- Include all TypeScript files in the package, recursively.
- If `allow_js` is set, include all JavaScript files in the package as well.
- If `resolve_json_module` is set, include all JSON files in the package,
  but exclude `package.json`, `package-lock.json`, and `tsconfig*.json`.None�
�
args�List of strings of additional command-line arguments to pass to tsc.
See https://www.typescriptlang.org/docs/handbook/compiler-options.html#compiler-options
Typically useful arguments for debugging are `--listFiles` and `--listEmittedFiles`.[]�
�
data�Files needed at runtime by binaries or tests that transitively depend on this target.
See https://bazel.build/reference/be/common-definitions#typical-attributes[]�	
�	
deps�	List of targets that produce TypeScript typings (`.d.ts` files)

If this list contains linked npm packages, npm package store targets or other targets that provide
`JsInfo`, `NpmPackageStoreInfo` providers are gathered from `JsInfo`. This is done directly from
the `npm_package_store_deps` field of these. For linked npm package targets, the underlying
`npm_package_store` target(s) that back the links is used. Gathered `NpmPackageStoreInfo`
providers are propagated to the direct dependencies of downstream linked `npm_package` targets.

NB: Linked npm package targets that are "dev" dependencies do not forward their underlying
`npm_package_store` target(s) through `npm_package_store_deps` and will therefore not be
propagated to the direct dependencies of downstream linked `npm_package` targets. npm packages
that come in from `npm_translate_lock` are considered "dev" dependencies if they are have
`dev: true` set in the pnpm lock file. This should be all packages that are only listed as
"devDependencies" in all `package.json` files within the pnpm workspace. This behavior is
intentional to mimic how `devDependencies` work in published npm packages.[]�
�
assets�Files which are needed by a downstream build step such as a bundler.

These files are **not** included as inputs to any actions spawned by `ts_project`.
They are not transpiled, and are not visible to the type-checker.
Instead, these files appear among the *outputs* of this target.

A typical use is when your TypeScript code has an import that TS itself doesn't understand
such as

`import './my.scss'`

and the type-checker allows this because you have an "ambient" global type declaration like

`declare module '*.scss' { ... }`

A bundler like webpack will expect to be able to resolve the `./my.scss` import to a file
and doesn't care about the typing declaration. A bundler runs as a build step,
so it does not see files included in the `data` attribute.

Note that `data` is used for files that are resolved by some binary, including a test
target. Behind the scenes, `data` populates Bazel's Runfiles object in `DefaultInfo`,
while this attribute populates the `transitive_sources` of the `JsInfo`.[]�
�
extends�Label of the tsconfig file referenced in the `extends` section of tsconfig
To support "chaining" of more than one extended config, this label could be a target that
provdes `TsConfigInfo` such as `ts_config`.None�
�
allow_js�Whether TypeScript will read .js and .jsx files.
When used with `declaration`, TypeScript will generate `.d.ts` files from `.js` files.False�
�
isolated_typecheck�Whether to type-check asynchronously as a separate bazel action from transpilation.

Any transpiling with `tsc` will only contain the `ts_project(tsconfig)` dependencies, while type-checking
actions will also include the `ts_project(deps)` dependencies.

Requires https://devblogs.microsoft.com/typescript/announcing-typescript-5-6/#the---nocheck-option6
Requires https://www.typescriptlang.org/docs/handbook/release-notes/typescript-5-5.html#isolated-declarationsFalse�
�
declarationwWhether the `declaration` bit is set in the tsconfig.
Instructs Bazel to expect a `.d.ts` output for each `.ts` source.False�
�

source_mapwWhether the `sourceMap` bit is set in the tsconfig.
Instructs Bazel to expect a `.js.map` output for each `.ts` source.False�
�
declaration_map~Whether the `declarationMap` bit is set in the tsconfig.
Instructs Bazel to expect a `.d.ts.map` output for each `.ts` source.False�
�
resolve_json_module�Boolean; specifies whether TypeScript will read .json files.
If set to True or False and tsconfig is a dict, resolveJsonModule is set in the generated config file.
If set to None and tsconfig is a dict, resolveJsonModule is unset in the generated config and typescript
default or extended tsconfig value will be load bearing.None�
�
preserve_jsx�Whether the `jsx` value is set to "preserve" in the tsconfig.
Instructs Bazel to expect a `.jsx` or `.jsx.map` output for each `.tsx` source.False�
�
	composite�Whether the `composite` bit is set in the tsconfig.
Instructs Bazel to expect a `.tsbuildinfo` output and a `.d.ts` output for each `.ts` source.False�
~
incrementalhWhether the `incremental` bit is set in the tsconfig.
Instructs Bazel to expect a `.tsbuildinfo` output.Falseq
o
no_emit]Whether the `noEmit` bit is set in the tsconfig.
Instructs Bazel *not* to expect any outputs.False�
�
emit_declaration_only�Whether the `emitDeclarationOnly` bit is set in the tsconfig.
Instructs Bazel *not* to expect `.js` or `.js.map` outputs for `.ts` sources.False�
�

transpiler�A custom transpiler tool to run that produces the JavaScript outputs instead of `tsc`.

Under `--@aspect_rules_ts//ts:default_to_tsc_transpiler`, the default is to use `tsc` to produce
`.js` outputs in the same action that does the type-checking to produce `.d.ts` outputs.
This is the simplest configuration, however `tsc` is slower than alternatives.
It also means developers must wait for the type-checking in the developer loop.

Without `--@aspect_rules_ts//ts:default_to_tsc_transpiler`, an explicit value must be set.
This may be the string `"tsc"` to explicitly choose `tsc`, just like the default above.

It may also be any rule or macro with this signature: `(name, srcs, **kwargs)`

If JavaScript outputs are configured to not be emitted the custom transpiler will not be used, such as
when `no_emit = True` or `emit_declaration_only = True`.

See [docs/transpiler.md](/docs/transpiler.md) for more details.None�
�
declaration_transpiler�A custom transpiler tool to run that produces the TypeScript declaration outputs instead of `tsc`.

It may be any rule or macro with this signature: `(name, srcs, **kwargs)`

If TypeScript declaration outputs are configured to not be emitted the custom declaration transpiler will
not be used, such as when `no_emit = True` or `declaration = False`.

See [docs/transpiler.md](/docs/transpiler.md) for more details.None�
�
ts_build_info_file�The user-specified value of `tsBuildInfoFile` from the tsconfig.
Helps Bazel to predict the path where the .tsbuildinfo output is written.None�
�
generate_trace�Whether to generate a trace file for TypeScript compiler performance analysis.
When enabled, creates a trace directory containing performance tracing information that can be
loaded in chrome://tracing. Use the `--@aspect_rules_ts//ts:generate_tsc_trace` flag to enable this by default.None�
�
tsc�Label of the TypeScript compiler binary to run.
This allows you to use a custom API-compatible compiler in place of the regular `tsc` such as a custom `js_binary` or Angular's `ngc`.
compatible with it such as Angular's `ngc`.

See examples of use in [examples/custom_compiler](https://github.com/aspect-build/rules_ts/blob/main/examples/custom_compiler/BUILD.bazel)"@npm_typescript//:tsc"�
�

tsc_workerbLabel of a custom TypeScript compiler binary which understands Bazel's persistent worker protocol."@npm_typescript//:tsc_worker"�
�
validate�Whether to check that the dependencies are valid and the tsconfig JSON settings match the attributes on this target.
Set this to `False` to skip running our validator, in case you have a legitimate reason for these to differ,
e.g. you have a setting enabled just for the editor but you want different behavior when Bazel runs `tsc`.Truel
j
	validator>Label of the tsconfig validator to run when `validate = True`."@npm_typescript//:validator"�
�
declaration_dir�String specifying a subdirectory under the bazel-out folder where generated declaration
outputs are written. Equivalent to the TypeScript --declarationDir option.
By default declarations are written to the out_dir.None�
�
out_dir�String specifying a subdirectory under the bazel-out folder where outputs are written.
Equivalent to the TypeScript --outDir option.

Note that Bazel always requires outputs be written under a subdirectory matching the input package,
so if your rule appears in `path/to/my/package/BUILD.bazel` and out_dir = "foo" then the .js files
will appear in `bazel-out/[arch]/bin/path/to/my/package/foo/*.js`.

By default the out_dir is the package's folder under bazel-out.None�
�
root_dir�String specifying a subdirectory under the input package which should be consider the
root directory of all the input files.
Equivalent to the TypeScript --rootDir option.
By default it is '.', meaning the source directory where the BUILD file lives.None�
�
supports_workers�Whether the "Persistent Worker" protocol is enabled.
This uses a custom `tsc` compiler to make rebuilds faster.
Note that this causes some known correctness bugs, see
https://github.com/aspect-build/rules_ts/blob/main/docs/troubleshooting.md#problems-with-persistent-workers.
We do not intend to fix these bugs.

Worker mode can be enabled for all `ts_project`s in a build with the global
`--@aspect_rules_ts//ts:supports_workers` flag.
To enable worker mode for all builds in the workspace, add
`build --@aspect_rules_ts//ts:supports_workers` to the .bazelrc.

This is a "tri-state" attribute, accepting values `[-1, 0, 1]`. The behavior is:

- `-1`: use the value of the global `--@aspect_rules_ts//ts:supports_workers` flag.
- `0`: Override the global flag, disabling workers for this target.
- `1`: Override the global flag, enabling workers for this target.-1h
f
kwargs\passed through to underlying [`ts_project_rule`](#ts_project_rule), eg. `visibility`, `tags`�TsConfigInfo�Provides TypeScript configuration, in the form of a tsconfig.json file
along with any transitively referenced tsconfig.json files chained by the
"extends" feature2�
�
TsConfigInfo�Provides TypeScript configuration, in the form of a tsconfig.json file
along with any transitively referenced tsconfig.json files chained by the
"extends" feature>
deps6all tsconfig.json files needed to configure TypeScript"*
TsConfigInfo//ts/private:ts_config.bzl@
>
deps6all tsconfig.json files needed to configure TypeScript�# Public API for TypeScript rules

The most commonly used is the [ts_project](#ts_project) macro which accepts TypeScript sources as
inputs and produces JavaScript or declaration (.d.ts) outputs.�
tsextensions.bzl�extJ�
�
extg
deps
name2"npm_typescript"

ts_version2""
ts_version_from2None
ts_integrity2"""//ts:extensions.bzl�
g
deps
name2"npm_typescript"

ts_version2""
ts_version_from2None
ts_integrity2""

name2"npm_typescript"


ts_version2""

ts_version_from2None

ts_integrity2""qDefine module extensions for using rules_ts with bzlmod.
See https://bazel.build/docs/bzlmod#extension-definition�.
ts	proto.bzl�!ts_proto_libraryMA macro to generate JavaScript code and TypeScript typings from .proto files.*� 
�
ts_proto_library3
name)name of resulting ts_proto_library target �
node_modules�Label pointing to the linked node_modules target where @bufbuild/protoc-gen-es is linked, e.g. //:node_modules.
Since the generated code depends on @bufbuild/protobuf, this package must also be linked.
If `gen_connect_es = True` then @bufbuild/proto-gen-connect-es should be linked as well.
If `gen_connect_query = True` then @bufbuild/proto-gen-connect-query should be linked as well. Z
protoOthe `proto_library` target that contains the .proto files to generate code for. �
protoc_gen_optionszdict of protoc_gen_es options.
See https://github.com/bufbuild/protobuf-es/tree/main/packages/protoc-gen-es#plugin-options{}�
gen_connect_es�[deprecated] whether protoc_gen_connect_es should generate grpc services, and therefore `*_connect.{js,d.ts}` should be written.False�
gen_connect_query�whether protoc_gen_connect_query should generate [TanStack Query](https://tanstack.com/query) clients, and therefore `*_connectquery.{js,d.ts}` should be written.False�
!gen_connect_query_service_mapping�mapping from source proto file to the named RPC services that file contains.
Needed to predict which files will be generated by gen_connect_query.
See https://github.com/connectrpc/connect-query-es/tree/main/examples/react/basic/src/gen

For example, given `a.proto` which contains a service `Foo` and `b.proto` that contains a service `Bar`,
the mapping would be `{"a.proto": ["Foo"], "b.proto": ["Bar"]}`{}w

copy_filescwhether to copy the resulting `.d.ts` files back to the source tree, for the editor to locate them.True�

proto_srcs�the .proto files that are being generated. Repeats the `srcs` of the `proto_library` target.
This is used only to determine a default for `files_to_copy`.None�
files_to_copy�which files from the protoc output to copy. By default, performs a replacement on `proto_srcs` with the typical output filenames.NoneA
kwargs7additional named arguments to the ts_proto_library ruleMA macro to generate JavaScript code and TypeScript typings from .proto files.2"
ts_proto_library//ts:proto.bzl5
3
name)name of resulting ts_proto_library target �
�
node_modules�Label pointing to the linked node_modules target where @bufbuild/protoc-gen-es is linked, e.g. //:node_modules.
Since the generated code depends on @bufbuild/protobuf, this package must also be linked.
If `gen_connect_es = True` then @bufbuild/proto-gen-connect-es should be linked as well.
If `gen_connect_query = True` then @bufbuild/proto-gen-connect-query should be linked as well. \
Z
protoOthe `proto_library` target that contains the .proto files to generate code for. �
�
protoc_gen_optionszdict of protoc_gen_es options.
See https://github.com/bufbuild/protobuf-es/tree/main/packages/protoc-gen-es#plugin-options{}�
�
gen_connect_es�[deprecated] whether protoc_gen_connect_es should generate grpc services, and therefore `*_connect.{js,d.ts}` should be written.False�
�
gen_connect_query�whether protoc_gen_connect_query should generate [TanStack Query](https://tanstack.com/query) clients, and therefore `*_connectquery.{js,d.ts}` should be written.False�
�
!gen_connect_query_service_mapping�mapping from source proto file to the named RPC services that file contains.
Needed to predict which files will be generated by gen_connect_query.
See https://github.com/connectrpc/connect-query-es/tree/main/examples/react/basic/src/gen

For example, given `a.proto` which contains a service `Foo` and `b.proto` that contains a service `Bar`,
the mapping would be `{"a.proto": ["Foo"], "b.proto": ["Bar"]}`{}y
w

copy_filescwhether to copy the resulting `.d.ts` files back to the source tree, for the editor to locate them.True�
�

proto_srcs�the .proto files that are being generated. Repeats the `srcs` of the `proto_library` target.
This is used only to determine a default for `files_to_copy`.None�
�
files_to_copy�which files from the protoc output to copy. By default, performs a replacement on `proto_srcs` with the typical output filenames.NoneC
A
kwargs7additional named arguments to the ts_proto_library rule�# DEPRECATED: Protocol Buffers and gRPC

> [!WARNING]
> **This API has been replaced** by rules_js: <https://github.com/aspect-build/rules_js/blob/main/js/proto.bzl>
> See updated documentation at <https://docs.aspect.build/bazel/javascript/aspect_rules_js/js_proto>

`ts_proto_library` uses the Connect library from bufbuild, and supports both Web and Node.js:

- https://connectrpc.com/docs/web/getting-started
- https://connectrpc.com/docs/node/getting-started

This Bazel integration follows the "Local Generation" mechanism described at
https://connectrpc.com/docs/web/generating-code#local-generation,
using packages such as `@bufbuild/protoc-gen-es` and `@connectrpc/protoc-gen-connect-query`
as plugins to protoc.

The [aspect configure](https://docs.aspect.build/cli/commands/aspect_configure) command
auto-generates `ts_proto_library` rules as of the 5.7.2 release.
It's also possible to compile this library into your Gazelle binary.

Note: this API surface is not included in `defs.bzl` to avoid eager loads of rules_proto for all rules_ts users.

Installation
------------

If you install rules_ts in `WORKSPACE`, you'll need to install the deps of rules_proto, like this:

```
load("@rules_proto//proto:repositories.bzl", "rules_proto_dependencies")

rules_proto_dependencies()
```

If you use bzlmod/`MODULE.bazel` then no extra install is required.

Future work
-----------

- Allow users to choose other plugins. We intend to wait until http://github.com/bazelbuild/rules_proto supports protoc plugins.
- Allow users to control the output format. Currently it is hard-coded to `js+dts`, and the JS output uses ES Modules. 