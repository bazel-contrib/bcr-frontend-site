�-

auexamplesdefs.bzl�
ab_examplePDefines a raw-vs-Au example pair, plus the tests that keep the pair trustworthy.*�
�

ab_exampleJ
name>Name of the example.  Sources are read from this subdirectory. (C
expected_output,The exact stdout both programs must produce. ('
au_depsDeps for the Au version. (�
raw_deps�Deps for the raw version.  Usually empty: the point of the raw version is that it
uses no units library.  A non-units dependency that both sides share is fine, though --
`eigen_kinematics` needs Eigen in both, since Eigen is the *rep*, not the units.None(N
raw_srcs:Sources for the raw version.  Defaults to `<name>/raw.cc`.None(K
au_srcs8Sources for the Au version.  Defaults to `<name>/au.cc`.None(PDefines a raw-vs-Au example pair, plus the tests that keep the pair trustworthy.2%

ab_example@@au//examples:defs.bzl
@@"	cc_binary�single_example�Defines a standalone example with no plain-C++ counterpart to compare against.

Most examples are an `ab_example` pair.  Use this instead when there is nothing meaningful to
compare against, because the example's subject *is* Au: building a new system of units on top
of it, for instance.  There is no line-alignment invariant to keep here, since there is no
second tab -- only the output check.

An example that defines something reusable (a header, plus the out-of-line definitions it
needs) gets a `cc_library` for that part, with the program depending on it.  That is how a
reader's own project will consume these files, so it is how the example should build them.
*�
�
single_exampleJ
name>Name of the example.  Sources are read from this subdirectory. (A
expected_output*The exact stdout the program must produce. (�
deps�Deps of the example.  Applied to both the library and the program: the program includes
Au headers directly (to print, and to name the units it converts into), so it declares them
directly too, rather than leaning on the library's deps to supply them. (_
main_srcKSources for the program itself, as a list.  Defaults to `[<name>/main.cc]`.None(�
lib_srcssNon-`main` sources, compiled into the library.  In C++14 this is where the
out-of-line unit label definitions live.None(E
hdrs5Headers the example defines and the program includes.None(�Defines a standalone example with no plain-C++ counterpart to compare against.

Most examples are an `ab_example` pair.  Use this instead when there is nothing meaningful to
compare against, because the example's subject *is* Au: building a new system of units on top
of it, for instance.  There is no line-alignment invariant to keep here, since there is no
second tab -- only the output check.

An example that defines something reusable (a header, plus the out-of-line definitions it
needs) gets a `cc_library` for that part, with the program depending on it.  That is how a
reader's own project will consume these files, so it is how the example should build them.
2)
single_example@@au//examples:defs.bzl
||"
cc_library"	cc_binary2	cc_binary�
//cc:defs.bzlrv

rules_ccccdefs.bzl$
	cc_binary	cc_binary
=!=*&

cc_library
cc_library
=.=8
==:l
//shell:sh_test.bzlrS
!
rules_shellshellsh_test.bzl 
sh_testsh_test
>*>1
>>3�Build rules for the code examples shown on the doc website.

Every example on the website is real source from this directory, compiled and run by CI, and
inlined into the docs by `pymdownx.snippets`.  Nothing on those pages can drift out of date with
the library without a test going red.

There are two flavors.  `ab_example` is the common one: a "before and after" pair.  `single_example`
is for examples that have no meaningful plain-C++ counterpart, such as building a whole system of
units on top of Au.

--------------------------------------------------------------------------------------------------

`ab_example`: the "A/B" code examples.

Each A/B example is a pair of complete, runnable programs that solve the same problem: `raw.cc`
(plain C++, no units library) and `au.cc` (the same thing, using Au).  The doc website shows them
as a pair of tabs, so a reader can flip back and forth and compare corresponding lines in place.

That presentation only works if the two stay honest about two things, and `ab_example` enforces
both:

  1. They must produce *identical* output.  This is what lets the page claim "same answer, better
     code" without the reader having to take our word for it.

  2. The regions marked for inclusion in the docs must have the same number of lines, so that
     corresponding constructs sit at the same height in both tabs.  Where Au needs less code, pad
     with a blank line rather than letting the two versions drift out of alignment.

--------------------------------------------------------------------------------------------------

`single_example`: the standalone code examples.

Some examples have no plain-C++ counterpart, because their subject *is* Au: `atomic_units` builds a
whole new system of units on top of the library, and there is no "before" version of that to show.

Invariant 2 above does not apply to these -- with no second tab, there is nothing to line up --
but invariant 1 still holds in adapted form: the program must print exactly `expected_output`.
That check lives in `check_output.sh`, which `check_ab_example.sh` also calls, so both flavors agree
on what correct output means.

These examples usually *define* something reusable rather than just computing something, so
`single_example` splits the target: `hdrs` plus `lib_srcs` become a `cc_library`, and `main_src`
becomes a program that depends on it.  That is the shape a reader copying these files into their own
project will end up with, so it is the shape the example should build.
 