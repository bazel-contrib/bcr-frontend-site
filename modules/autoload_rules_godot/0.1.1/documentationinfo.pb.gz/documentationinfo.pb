��
&
autoload_rules_godotgodotapp.bzlҟ	godot_app�"Package a start pack and the matching runtime into one application.

Select the export platform with --platforms. The public label forwards the
providers, default artifacts, run behavior and output groups of the application
backend that export platform selects: a Linux or macOS bundle, an Android APK or
AAB, or an iOS application. Unsupported wildcard targets are skipped; explicit
unsupported requests fail. Selected application backends need their documented SDKs
and runtime components. `bazel run` starts the application on this host, a device,
an emulator or a Simulator, or from sources in the editor variant, and streams its log
until it exits; see
[Run an application](../../platforms.md#run-an-application). Configure Godot settings and content on the pack/project;
this macro never creates or replaces the pack.

macOS defaults to unsigned. Select --@autoload_rules_godot//godot:macos_signing=adhoc
or certificate to sign a copy. Certificate mode requires macos_signing_identity;
macos_entitlements affects only the selected signer. Unsigned actions never read
signing inputs. The selected launcher and GodotDesktopAppInfo bundle/archive refer
to the same result; executable_path stays bundle-relative. Signing requires local
Darwin execution; certificates additionally require an accessible keychain and
disable action caching and sandboxing. Failures never return unsigned output.
The public <name>.debug_symbols companion bypasses signer analysis, including in
certificate mode without identity; debug_symbols on the selected app does not.

The application delivers the extension libraries, platform libraries and Info.plist
fragments of the add-ons of its start pack and of its loadable_packs.

Example: godot_app(name = "app", pack = ":pack"). Each application backend packages
the runtime component that the runtime toolchain resolves for its platform slice and
variant; register the components with register_toolchains or --extra_toolchains.
See [platform setup](../../platforms.md) and the
[Godot configuration catalogue](../../configuration.md) for config-only capabilities.

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| executable | many | desktop | build bundle/archive; bazel run launches the selected signed or unsigned bundle on this host; bundle is in runfiles |
| executable | many | apk | build rules_android's default APK outputs, including signed/unsigned APKs and deployment metadata; use ApkInfo.signed_apk for the selected distributable; bazel run installs the signed APK on a device or emulator and launches it |
| executable | one | aab | build selected checked AAB; no intermediate APK is exposed; bazel run installs its universal APK on a device or emulator and launches it |
| executable | one | ios | build the `.app` directory for Simulator and non-`opt` builds, else the `.ipa` archive; bazel run installs it on a Simulator or device and launches it |
| executable | one | editor | build nothing but the start pack's project inputs; bazel run runs the project from sources with Godot's editor binary on this host |

### Output groups
| name | contents | availability | prerequisites |
| --- | --- | --- | --- |
| bundle | Selected unpacked application bundle | desktop | matching desktop runtime component; selected macOS signer if enabled |
| archive | Selected desktop distribution archive | desktop | matching desktop runtime component; selected macOS signer if enabled |
| debug_symbols | Desktop debug symbols | desktop | matching C++ toolchain |

### Generated targets
| name | kind | purpose | reason | visibility | testonly | prerequisites | availability |
| --- | --- | --- | --- | --- | --- | --- | --- |
| {name}.debug_symbols | alias | analysis_boundary | Analyze the unsigned symbol producer without signer identities or entitlements; requesting an app output group still analyzes its signer | caller | inherit | the selected operating system's SDK and debug symbol inputs; iOS requires --apple_generate_dsym | always |

### Providers
| name | role | availability |
| --- | --- | --- |
| GodotDesktopAppInfo | Selected bundle/archive and relative executable path | desktop |
| ApkInfo | Selected APK signing and installation metadata | apk |
| AndroidBundleInfo | Selected AAB only; never an intermediate ApkInfo | aab |
| AppleBundleInfo | Selected iOS application (`.app` directory or `.ipa` archive) and metadata | ios |Z�|
�O
	godot_app�"Package a start pack and the matching runtime into one application.

Select the export platform with --platforms. The public label forwards the
providers, default artifacts, run behavior and output groups of the application
backend that export platform selects: a Linux or macOS bundle, an Android APK or
AAB, or an iOS application. Unsupported wildcard targets are skipped; explicit
unsupported requests fail. Selected application backends need their documented SDKs
and runtime components. `bazel run` starts the application on this host, a device,
an emulator or a Simulator, or from sources in the editor variant, and streams its log
until it exits; see
[Run an application](../../platforms.md#run-an-application). Configure Godot settings and content on the pack/project;
this macro never creates or replaces the pack.

macOS defaults to unsigned. Select --@autoload_rules_godot//godot:macos_signing=adhoc
or certificate to sign a copy. Certificate mode requires macos_signing_identity;
macos_entitlements affects only the selected signer. Unsigned actions never read
signing inputs. The selected launcher and GodotDesktopAppInfo bundle/archive refer
to the same result; executable_path stays bundle-relative. Signing requires local
Darwin execution; certificates additionally require an accessible keychain and
disable action caching and sandboxing. Failures never return unsigned output.
The public <name>.debug_symbols companion bypasses signer analysis, including in
certificate mode without identity; debug_symbols on the selected app does not.

The application delivers the extension libraries, platform libraries and Info.plist
fragments of the add-ons of its start pack and of its loadable_packs.

Example: godot_app(name = "app", pack = ":pack"). Each application backend packages
the runtime component that the runtime toolchain resolves for its platform slice and
variant; register the components with register_toolchains or --extra_toolchains.
See [platform setup](../../platforms.md) and the
[Godot configuration catalogue](../../configuration.md) for config-only capabilities.

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| executable | many | desktop | build bundle/archive; bazel run launches the selected signed or unsigned bundle on this host; bundle is in runfiles |
| executable | many | apk | build rules_android's default APK outputs, including signed/unsigned APKs and deployment metadata; use ApkInfo.signed_apk for the selected distributable; bazel run installs the signed APK on a device or emulator and launches it |
| executable | one | aab | build selected checked AAB; no intermediate APK is exposed; bazel run installs its universal APK on a device or emulator and launches it |
| executable | one | ios | build the `.app` directory for Simulator and non-`opt` builds, else the `.ipa` archive; bazel run installs it on a Simulator or device and launches it |
| executable | one | editor | build nothing but the start pack's project inputs; bazel run runs the project from sources with Godot's editor binary on this host |

### Output groups
| name | contents | availability | prerequisites |
| --- | --- | --- | --- |
| bundle | Selected unpacked application bundle | desktop | matching desktop runtime component; selected macOS signer if enabled |
| archive | Selected desktop distribution archive | desktop | matching desktop runtime component; selected macOS signer if enabled |
| debug_symbols | Desktop debug symbols | desktop | matching C++ toolchain |

### Generated targets
| name | kind | purpose | reason | visibility | testonly | prerequisites | availability |
| --- | --- | --- | --- | --- | --- | --- | --- |
| {name}.debug_symbols | alias | analysis_boundary | Analyze the unsigned symbol producer without signer identities or entitlements; requesting an app output group still analyzes its signer | caller | inherit | the selected operating system's SDK and debug symbol inputs; iOS requires --apple_generate_dsym | always |

### Providers
| name | role | availability |
| --- | --- | --- |
| GodotDesktopAppInfo | Selected bundle/archive and relative executable path | desktop |
| ApkInfo | Selected APK signing and installation metadata | apk |
| AndroidBundleInfo | Selected AAB only; never an intermediate ApkInfo | aab |
| AppleBundleInfo | Selected iOS application (`.app` directory or `.ipa` archive) and metadata | ios |�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@�
pack�The start pack: a godot_pack target, which also brings the extension libraries and platform libraries of its add-ons; a raw PCK file is not enough. �
loadable_packs�Packs the application may load later, such as DLC: godot_pack targets whose
add-ons' extension libraries, platform libraries and Info.plist fragments the
application delivers besides the start pack's. The application does not
contain their PCKs.2[]8�
macos_signing_identity�App-specific local certificate identity; required and not '-' in certificate mode. Ad hoc ignores it; unsigned never analyzes it.2""�
macos_entitlementseOptional declared entitlement plist, including generated files; only the selected signer consumes it.2None�
application_id�Android application ID or Apple bundle identifier; required for mobile. On macOS an empty value keeps the pack's application/bundle_identifier; Linux ignores it.2""�
macos_minimum_os_version�Minimum macOS version of the application: the bundle's LSMinimumSystemVersion and the deployment target of the native code its pack compiles, such as extension libraries. The default is Godot's floor; a source-built engine compiles for that floor regardless.2"11.0"�
ios_minimum_os_version�Minimum iOS version of the application. It is part of the application context, so the pack exports with it; the runtime must support it.2"15.0"�
ios_families|Unique nonempty subset of iphone/ipad: the device families of the application's Info.plist and of the pack's export options.2["iphone", "ipad"]{
android_min_sdk_version[Minimum SDK; zero uses the selected engine profile fallback. Distinct from NDK/compile SDK.20|
android_target_sdk_versionYTarget SDK; zero uses the engine profile fallback and resolved target must be >= minimum.20�
android_manifest_values�Values for the manifest placeholders of the Android manifest merge, like Gradle's
`manifestPlaceholders`: `${key}` in the application's manifest and in the
manifests of its platform libraries, such as an SDK's `${appAuthRedirectScheme}`,
becomes the value. A placeholder without a value fails the merge with a message
naming it. Keys the merger treats as overrides (the application ID, SDK versions,
version code and name, `maxSdkVersion`) are rejected with a diagnostic naming
the attribute or pack setting that owns the value. The values are not part of the
application context, so a changed value reruns the manifest merge and packaging,
not the pack's export. Other operating systems ignore them.
2{}�
android_manifest�The application's own Android manifest, the main manifest of the manifest merge;
the manifest Godot's Android export writes merges below it. See
[Android shell files](../../platforms.md#android-shell-files). Not configurable;
other operating systems ignore it.2None8�
android_debug_key^Debug keystore that signs APKs, used in the exec configuration; AABs are signed outside Bazel.2."@rules_android//tools/android:debug_keystore"o
ios_provisioning_profileKOptional provisioning profile file; installed profiles are never looked up.2NoneZ
ios_entitlements>Optional declared entitlement file, including generated files.2None�
ios_infoplists�The application's own Info.plist fragments; each top-level key they set replaces
that key of the generated Info.plist and of the add-ons' fragments. See
[iOS shell files](../../platforms.md#ios-shell-files). Other operating systems ignore
them.2[]�
ios_app_icons�The application's own app icons, as rules_apple's `app_icons` takes them, which
replace those Godot renders. See
[iOS shell files](../../platforms.md#ios-shell-files). Other operating systems ignore
them.2[]�
ios_launch_storyboard�The application's own launch screen, a `.storyboard` or `.xib` file, which
replaces the one Godot's export writes. Other operating systems ignore it.2None�
platform_deps�Platform libraries of this application only: Android Java or native libraries, or iOS libraries and frameworks. Use select() with empty desktop branches; platform libraries other applications reuse belong to the platform_deps of add-ons or extensions.2[]�
platform_resources�Platform resources of this application only: Android primary resource files or iOS bundle resources. Use select() with empty desktop branches; the resources of a platform library stay on that library. An Android resource with the type, name and configuration qualifiers of a shell resource, such as a launcher icon or the `GodotAppSplashTheme` style, and an iOS `PrivacyInfo.xcprivacy` replace the shell's.2[]~
target_compatible_with^Consumer compatibility constraints/select; sole restriction of the supported export platforms.2[]Y
tagsIConventional Bazel tags; helpers additionally exclude wildcard selection.2[]8[
exec_compatible_with;Execution-platform constraints of the application backends.2[]8G
deprecation0Optional conventional Bazel deprecation message.2""8J
exec_properties1Execution properties of the application backends.
2{}Q
features?rules_cc toolchain features, independent of Godot feature tags.2[]
testonly2None8@"1
	godot_app$@autoload_rules_godot//godot:app.bzl�
�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �
�

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@�
�
pack�The start pack: a godot_pack target, which also brings the extension libraries and platform libraries of its add-ons; a raw PCK file is not enough. �
�
loadable_packs�Packs the application may load later, such as DLC: godot_pack targets whose
add-ons' extension libraries, platform libraries and Info.plist fragments the
application delivers besides the start pack's. The application does not
contain their PCKs.2[]8�
�
macos_signing_identity�App-specific local certificate identity; required and not '-' in certificate mode. Ad hoc ignores it; unsigned never analyzes it.2""�
�
macos_entitlementseOptional declared entitlement plist, including generated files; only the selected signer consumes it.2None�
�
application_id�Android application ID or Apple bundle identifier; required for mobile. On macOS an empty value keeps the pack's application/bundle_identifier; Linux ignores it.2""�
�
macos_minimum_os_version�Minimum macOS version of the application: the bundle's LSMinimumSystemVersion and the deployment target of the native code its pack compiles, such as extension libraries. The default is Godot's floor; a source-built engine compiles for that floor regardless.2"11.0"�
�
ios_minimum_os_version�Minimum iOS version of the application. It is part of the application context, so the pack exports with it; the runtime must support it.2"15.0"�
�
ios_families|Unique nonempty subset of iphone/ipad: the device families of the application's Info.plist and of the pack's export options.2["iphone", "ipad"]}
{
android_min_sdk_version[Minimum SDK; zero uses the selected engine profile fallback. Distinct from NDK/compile SDK.20~
|
android_target_sdk_versionYTarget SDK; zero uses the engine profile fallback and resolved target must be >= minimum.20�
�
android_manifest_values�Values for the manifest placeholders of the Android manifest merge, like Gradle's
`manifestPlaceholders`: `${key}` in the application's manifest and in the
manifests of its platform libraries, such as an SDK's `${appAuthRedirectScheme}`,
becomes the value. A placeholder without a value fails the merge with a message
naming it. Keys the merger treats as overrides (the application ID, SDK versions,
version code and name, `maxSdkVersion`) are rejected with a diagnostic naming
the attribute or pack setting that owns the value. The values are not part of the
application context, so a changed value reruns the manifest merge and packaging,
not the pack's export. Other operating systems ignore them.
2{}�
�
android_manifest�The application's own Android manifest, the main manifest of the manifest merge;
the manifest Godot's Android export writes merges below it. See
[Android shell files](../../platforms.md#android-shell-files). Not configurable;
other operating systems ignore it.2None8�
�
android_debug_key^Debug keystore that signs APKs, used in the exec configuration; AABs are signed outside Bazel.2."@rules_android//tools/android:debug_keystore"q
o
ios_provisioning_profileKOptional provisioning profile file; installed profiles are never looked up.2None\
Z
ios_entitlements>Optional declared entitlement file, including generated files.2None�
�
ios_infoplists�The application's own Info.plist fragments; each top-level key they set replaces
that key of the generated Info.plist and of the add-ons' fragments. See
[iOS shell files](../../platforms.md#ios-shell-files). Other operating systems ignore
them.2[]�
�
ios_app_icons�The application's own app icons, as rules_apple's `app_icons` takes them, which
replace those Godot renders. See
[iOS shell files](../../platforms.md#ios-shell-files). Other operating systems ignore
them.2[]�
�
ios_launch_storyboard�The application's own launch screen, a `.storyboard` or `.xib` file, which
replaces the one Godot's export writes. Other operating systems ignore it.2None�
�
platform_deps�Platform libraries of this application only: Android Java or native libraries, or iOS libraries and frameworks. Use select() with empty desktop branches; platform libraries other applications reuse belong to the platform_deps of add-ons or extensions.2[]�
�
platform_resources�Platform resources of this application only: Android primary resource files or iOS bundle resources. Use select() with empty desktop branches; the resources of a platform library stay on that library. An Android resource with the type, name and configuration qualifiers of a shell resource, such as a launcher icon or the `GodotAppSplashTheme` style, and an iOS `PrivacyInfo.xcprivacy` replace the shell's.2[]�
~
target_compatible_with^Consumer compatibility constraints/select; sole restriction of the supported export platforms.2[][
Y
tagsIConventional Bazel tags; helpers additionally exclude wildcard selection.2[]8]
[
exec_compatible_with;Execution-platform constraints of the application backends.2[]8I
G
deprecation0Optional conventional Bazel deprecation message.2""8L
J
exec_properties1Execution properties of the application backends.
2{}S
Q
features?rules_cc toolchain features, independent of Godot feature tags.2[]

testonly2None8@�Build one application from a start pack and the runtime of the selected export platform.

Select the export platform with --platforms; use target_compatible_with for consumer
limits.
Export content and Godot configuration belong to the declared pack/project.��
'
autoload_rules_godotgodotdefs.bzl�5godot_resources�Declare Godot resources as one import unit, imported under the project of each
operation that reaches them.

Produces GodotResourcesInfo and DefaultInfo. Under the project an operation names,
the target imports its own files once per project and target platform, after its
dependencies; outside every operation it imports nothing. deps and runtime_deps
become members of the operations that reach them, and the add-ons in deps come
with them; import_inputs are available only during import. Conflicting resource
paths fail. Under each project, a validation in the _validation output group loads
the target's own scripts and scenes with what deps bring, and every build containing
the target fails on the errors Godot reports. Autoloads, settings, extensions and platform libraries are declared on
the project or a godot_addon, never on resources.

Example:
```starlark
godot_resources(name = "textures", srcs = glob(["textures/**"]))
```

See [resource composition](../../resources.md) for resource paths, generated
files, import ordering and runtime reference cycles.

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| files | many | always | build declared resource files; no run behavior |

### Output groups
none

### Generated targets
none

### Providers
| name | role | availability |
| --- | --- | --- |
| GodotResourcesInfo | Members, import inputs, imports and the add-ons used, transitively | always |"�)
�
godot_resources�Declare Godot resources as one import unit, imported under the project of each
operation that reaches them.

Produces GodotResourcesInfo and DefaultInfo. Under the project an operation names,
the target imports its own files once per project and target platform, after its
dependencies; outside every operation it imports nothing. deps and runtime_deps
become members of the operations that reach them, and the add-ons in deps come
with them; import_inputs are available only during import. Conflicting resource
paths fail. Under each project, a validation in the _validation output group loads
the target's own scripts and scenes with what deps bring, and every build containing
the target fails on the errors Godot reports. Autoloads, settings, extensions and platform libraries are declared on
the project or a godot_addon, never on resources.

Example:
```starlark
godot_resources(name = "textures", srcs = glob(["textures/**"]))
```

See [resource composition](../../resources.md) for resource paths, generated
files, import ordering and runtime reference cycles.

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| files | many | always | build declared resource files; no run behavior |

### Output groups
none

### Generated targets
none

### Providers
| name | role | availability |
| --- | --- | --- |
| GodotResourcesInfo | Members, import inputs, imports and the add-ons used, transitively | always |*
nameA unique name for this target. R
srcsDSource files of these resources; paths are relative to
strip_prefix.2[]j
resource_pathsRSingle-file target to explicit resource path; use for
generated or external files.	2{}c
strip_prefixMPackage-relative prefix removed from srcs paths; empty uses the package
root.2""�
deps�What these resources use: other godot_resources, which become members
of the same operations and are imported first, and the add-ons their
files use, godot_addon, godot_extension and godot_cc_extension targets.
Every operation containing these resources contains those add-ons with
their autoloads, settings, extensions and platform libraries; an
add-on's files are never an input of this import. Platform libraries,
autoloads, settings and Info.plist fragments belong on a godot_addon.2[]�
prefix�Project directory the srcs are placed under, after strip_prefix: files in
`addon/` with `strip_prefix = "addon"` and `prefix = "addons/inventory"`
appear at `res://addons/inventory/`. Use it for an add-on whose package
is not laid out as its project directory. Empty places them relative to
the package or strip_prefix; resource_paths keep their explicit paths.2""�
runtime_deps7Like deps, for resources loaded dynamically at runtime.*V
GodotResourcesInfo@
GodotResourcesInfo*@autoload_rules_godot//godot:providers.bzl2[]�
import_inputs�Files this import reads that are no members of any operation, such as a
glTF's buffers or a scene import's post-import script; scripts and scenes
reach an import only this way.*V
GodotResourcesInfo@
GodotResourcesInfo*@autoload_rules_godot//godot:providers.bzl2[]�
runtime_references�Source path -> runtime destination paths; permits reference cycles without
Bazel target cycles. A destination that names a directory reaches every
project member below it.2{}"E
godot_resources2@autoload_rules_godot//godot/private:resources.bzl,
*
nameA unique name for this target. T
R
srcsDSource files of these resources; paths are relative to
strip_prefix.2[]l
j
resource_pathsRSingle-file target to explicit resource path; use for
generated or external files.	2{}e
c
strip_prefixMPackage-relative prefix removed from srcs paths; empty uses the package
root.2""�
�
deps�What these resources use: other godot_resources, which become members
of the same operations and are imported first, and the add-ons their
files use, godot_addon, godot_extension and godot_cc_extension targets.
Every operation containing these resources contains those add-ons with
their autoloads, settings, extensions and platform libraries; an
add-on's files are never an input of this import. Platform libraries,
autoloads, settings and Info.plist fragments belong on a godot_addon.2[]�
�
prefix�Project directory the srcs are placed under, after strip_prefix: files in
`addon/` with `strip_prefix = "addon"` and `prefix = "addons/inventory"`
appear at `res://addons/inventory/`. Use it for an add-on whose package
is not laid out as its project directory. Empty places them relative to
the package or strip_prefix; resource_paths keep their explicit paths.2""�
�
runtime_deps7Like deps, for resources loaded dynamically at runtime.*V
GodotResourcesInfo@
GodotResourcesInfo*@autoload_rules_godot//godot:providers.bzl2[]�
�
import_inputs�Files this import reads that are no members of any operation, such as a
glTF's buffers or a scene import's post-import script; scripts and scenes
reach an import only this way.*V
GodotResourcesInfo@
GodotResourcesInfo*@autoload_rules_godot//godot:providers.bzl2[]�
�
runtime_references�Source path -> runtime destination paths; permits reference cycles without
Bazel target cycles. A destination that names a directory reaches every
project member below it.2{}�)	godot_run�Run a Godot project or exported PCK with `bazel run`, like py_binary.

The run uses the registered editor toolchain in a fresh, writable copy of the
project, so nothing in the checkout changes. Give it what to run in one of
two ways: a project and the resources it runs in deps, or an exported pack. `args` are Godot's command line, which
Bazel splits like a shell; arguments for the running script follow Godot's `--`
separator.

Example:
```starlark
godot_run(
    name = "game",
    project = ":project",
    deps = [":main", ":assets"],
    headless = False,
)
```

`bazel run :game` opens the game's window. See
[execution and tests](../../development.md#execution-and-tests).

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| executable | one | always | run Godot with project or PCK; project and editor data are runfiles |

### Output groups
none

### Generated targets
none

### Providers
none
*�!
�
	godot_run*
nameName of the executable target. (�
deps�godot_resources and godot_extension targets the run contains, such as
code, assets and add-ons. The project's autoloads and main scene must be
among them.[](�
main�Resource path, with optional res:// prefix, of what Godot starts: a
SceneTree or MainLoop script runs with --script, a .tscn or .scn scene
replaces the main scene. Empty starts the project's main scene.""(e
projectRThe godot_project whose configuration the run uses; defaults to a
minimal project.None(C
pack3An exported godot_pack to run instead of a project.None(�
data�Files available at run time through runfiles, outside the Godot
project. Godot receives Bazel's runfiles directory/manifest variables
when set. Tests also receive TEST_SRCDIR and TEST_WORKSPACE for locating them.[](1
env$Environment variables set for Godot.{}(�
headless�Whether Godot runs without a display: True always, False never,
for a target that must render. Unset follows the
--@autoload_rules_godot//godot:headless flag, which is true by default.None(�
engine_errors�"fail" or "report": what an error Godot reports while the
game's tree exists, such as a script error, does to the run. Godot can
report one and still exit with 0. "fail" ends the run with 1 instead;
"report" keeps Godot's exit status. Either names the number of recorded
errors."fail"(�
additional_packsvPack -> file name in the working directory, for the
running project to load with ProjectSettings.load_resource_pack().{}(:
kwargs.Common attributes such as args and visibility.(�Run a Godot project or exported PCK with `bazel run`, like py_binary.

The run uses the registered editor toolchain in a fresh, writable copy of the
project, so nothing in the checkout changes. Give it what to run in one of
two ways: a project and the resources it runs in deps, or an exported pack. `args` are Godot's command line, which
Bazel splits like a shell; arguments for the running script follow Godot's `--`
separator.

Example:
```starlark
godot_run(
    name = "game",
    project = ":project",
    deps = [":main", ":assets"],
    headless = False,
)
```

`bazel run :game` opens the game's window. See
[execution and tests](../../development.md#execution-and-tests).

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| executable | one | always | run Godot with project or PCK; project and editor data are runfiles |

### Output groups
none

### Generated targets
none

### Providers
none
29
	godot_run,@autoload_rules_godot//godot/private:run.bzl,
*
nameName of the executable target. (�
�
deps�godot_resources and godot_extension targets the run contains, such as
code, assets and add-ons. The project's autoloads and main scene must be
among them.[](�
�
main�Resource path, with optional res:// prefix, of what Godot starts: a
SceneTree or MainLoop script runs with --script, a .tscn or .scn scene
replaces the main scene. Empty starts the project's main scene.""(g
e
projectRThe godot_project whose configuration the run uses; defaults to a
minimal project.None(E
C
pack3An exported godot_pack to run instead of a project.None(�
�
data�Files available at run time through runfiles, outside the Godot
project. Godot receives Bazel's runfiles directory/manifest variables
when set. Tests also receive TEST_SRCDIR and TEST_WORKSPACE for locating them.[](3
1
env$Environment variables set for Godot.{}(�
�
headless�Whether Godot runs without a display: True always, False never,
for a target that must render. Unset follows the
--@autoload_rules_godot//godot:headless flag, which is true by default.None(�
�
engine_errors�"fail" or "report": what an error Godot reports while the
game's tree exists, such as a script error, does to the run. Godot can
report one and still exit with 0. "fail" ends the run with 1 instead;
"report" keeps Godot's exit status. Either names the number of recorded
errors."fail"(�
�
additional_packsvPack -> file name in the working directory, for the
running project to load with ProjectSettings.load_resource_pack().{}(<
:
kwargs.Common attributes such as args and visibility.(�0
godot_test�	Run a Godot project or exported PCK as a Bazel test, like py_test.

The test passes when Godot exits with 0, so a script reports a failed check
with `quit(1)`. Test frameworks run as the main script: godot_gdunit_test sets
up GdUnit this way. Godot receives Bazel's test environment, such as
TEST_SHARD_INDEX, TESTBRIDGE_TEST_ONLY and XML_OUTPUT_FILE, so a test framework
can implement sharding, `--test_filter` and JUnit reports. size, timeout,
shard_count and flaky work as for any Bazel test. The test and its view of the
project are testonly unless testonly = False is passed, so production
targets cannot depend on them.

Example:
```starlark
godot_test(
    name = "smoke_test",
    deps = [":smoke", ":game"],
    main = "smoke_test.gd",
)
```

Watch it with `bazel test :smoke_test --@autoload_rules_godot//godot:headless=false`.
See [execution and tests](../../development.md#execution-and-tests).

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| test | one | always | execute Godot under bazel test; failure follows the exit status and engine_errors; project/editor are runfiles |

### Output groups
none

### Generated targets
none

### Providers
none
*�'
�

godot_test$
nameName of the test target. (�
deps�godot_resources and godot_extension targets the test contains: the
test scripts and fixtures, the code under test, a test framework and
its add-ons. Autoloads and a main scene of the project whose files are
not among them are left out.[](�
main�Resource path, with optional res:// prefix, of what Godot starts: a
SceneTree or MainLoop script runs with --script, a .tscn or .scn scene
replaces the main scene. Empty starts the project's main scene.""(f
projectSThe godot_project whose configuration the test uses; defaults to a
minimal project.None(D
pack4An exported godot_pack to test instead of a project.None(�
data�Files available at run time through runfiles, outside the Godot
project. Godot receives Bazel's runfiles directory/manifest variables
when set. Tests also receive TEST_SRCDIR and TEST_WORKSPACE for locating them.[](1
env$Environment variables set for Godot.{}(�
headless�Whether Godot runs without a display: True always, False never,
for a test that must render. Unset follows the
--@autoload_rules_godot//godot:headless flag, which is true by default.None(�
engine_errors�"fail" or "report": what an error Godot reports while the
game's tree exists, such as a script error, does to the test. "fail"
fails the test and stops it after the first error, since a script error
does not end Godot; "report" keeps Godot's exit status, for a test
framework that provokes errors on purpose. Either names the number of
recorded errors; the errors are in the test's undeclared outputs under
godot/errors.jsonl."fail"(�
additional_packsvPack -> file name in the working directory, for the
running project to load with ProjectSettings.load_resource_pack().{}(F
kwargs:Common test attributes such as args, size and shard_count.(�	Run a Godot project or exported PCK as a Bazel test, like py_test.

The test passes when Godot exits with 0, so a script reports a failed check
with `quit(1)`. Test frameworks run as the main script: godot_gdunit_test sets
up GdUnit this way. Godot receives Bazel's test environment, such as
TEST_SHARD_INDEX, TESTBRIDGE_TEST_ONLY and XML_OUTPUT_FILE, so a test framework
can implement sharding, `--test_filter` and JUnit reports. size, timeout,
shard_count and flaky work as for any Bazel test. The test and its view of the
project are testonly unless testonly = False is passed, so production
targets cannot depend on them.

Example:
```starlark
godot_test(
    name = "smoke_test",
    deps = [":smoke", ":game"],
    main = "smoke_test.gd",
)
```

Watch it with `bazel test :smoke_test --@autoload_rules_godot//godot:headless=false`.
See [execution and tests](../../development.md#execution-and-tests).

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| test | one | always | execute Godot under bazel test; failure follows the exit status and engine_errors; project/editor are runfiles |

### Output groups
none

### Generated targets
none

### Providers
none
2:

godot_test,@autoload_rules_godot//godot/private:run.bzl&
$
nameName of the test target. (�
�
deps�godot_resources and godot_extension targets the test contains: the
test scripts and fixtures, the code under test, a test framework and
its add-ons. Autoloads and a main scene of the project whose files are
not among them are left out.[](�
�
main�Resource path, with optional res:// prefix, of what Godot starts: a
SceneTree or MainLoop script runs with --script, a .tscn or .scn scene
replaces the main scene. Empty starts the project's main scene.""(h
f
projectSThe godot_project whose configuration the test uses; defaults to a
minimal project.None(F
D
pack4An exported godot_pack to test instead of a project.None(�
�
data�Files available at run time through runfiles, outside the Godot
project. Godot receives Bazel's runfiles directory/manifest variables
when set. Tests also receive TEST_SRCDIR and TEST_WORKSPACE for locating them.[](3
1
env$Environment variables set for Godot.{}(�
�
headless�Whether Godot runs without a display: True always, False never,
for a test that must render. Unset follows the
--@autoload_rules_godot//godot:headless flag, which is true by default.None(�
�
engine_errors�"fail" or "report": what an error Godot reports while the
game's tree exists, such as a script error, does to the test. "fail"
fails the test and stops it after the first error, since a script error
does not end Godot; "report" keeps Godot's exit status, for a test
framework that provokes errors on purpose. Either names the number of
recorded errors; the errors are in the test's undeclared outputs under
godot/errors.jsonl."fail"(�
�
additional_packsvPack -> file name in the working directory, for the
running project to load with ProjectSettings.load_resource_pack().{}(H
F
kwargs:Common test attributes such as args, size and shard_count.(�)godot_editor�Open a project in the Godot editor with `bazel run`, editing the checkout.

The editor view is a Godot project under `.godot-editor/<package>/<name>` in the
workspace. Its files from this repository are symbolic links into the
checkout, so what the editor saves changes the checkout. A directory whose
files all come from one checkout directory at the same relative paths is
linked as a whole, so files the editor creates, renames or deletes there
change the checkout too. Generated files, files of other repositories, such
as add-ons, and extension descriptors and libraries are read-only copies;
the editor loads the extension host editor libraries. The project's imports and
Godot's caches come from the build, so the editor opens without
reimporting. Before the editor opens, the run writes the sidecars the
checkout lacks, as godot_metadata_sync does.

The editor view holds the editor part of every add-on of the operation, with its
editor plugin enabled in the view's project.godot. When the editor exits, settings
it changed that come from the authored project.godot are written back to it;
settings the project or its add-ons set are reported with the label that sets them. The runner also
lists files that exist only in the editor view and files in linked directories that
the project does not declare.

Bazel must ignore the editor views: add `.godot-editor` to `.bazelignore`, or
`bazel build //...` finds the linked packages twice. The run fails until it
does. Arguments after `--` go to the editor.

Example:
```starlark
godot_editor(
    name = "edit",
    project = ":project",
    deps = [":game"],
)
```

`bazel run :edit` opens the editor on `.godot-editor/<package>/edit`.

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| executable | one | always | run an editable staged project in Godot; editor and project are runfiles |

### Output groups
none

### Generated targets
none

### Providers
none
*�
�
godot_editor*
nameName of the executable target. (J
project;The godot_project whose configuration the editor view uses. (x
depsjWhat the editor view lists for editing: godot_resources and add-ons,
as an IDE project view lists targets.[](N
envAEnvironment variables set for the editor, besides the user's own.{}(�
write_sidecars�Write the sidecars the checkout lacks before the editor
opens, as godot_metadata_sync does. Without it, the run names them and Godot
writes its own when it finds the files, reimporting assets.True(;
kwargs/Common attributes, such as tags and visibility.(�Open a project in the Godot editor with `bazel run`, editing the checkout.

The editor view is a Godot project under `.godot-editor/<package>/<name>` in the
workspace. Its files from this repository are symbolic links into the
checkout, so what the editor saves changes the checkout. A directory whose
files all come from one checkout directory at the same relative paths is
linked as a whole, so files the editor creates, renames or deletes there
change the checkout too. Generated files, files of other repositories, such
as add-ons, and extension descriptors and libraries are read-only copies;
the editor loads the extension host editor libraries. The project's imports and
Godot's caches come from the build, so the editor opens without
reimporting. Before the editor opens, the run writes the sidecars the
checkout lacks, as godot_metadata_sync does.

The editor view holds the editor part of every add-on of the operation, with its
editor plugin enabled in the view's project.godot. When the editor exits, settings
it changed that come from the authored project.godot are written back to it;
settings the project or its add-ons set are reported with the label that sets them. The runner also
lists files that exist only in the editor view and files in linked directories that
the project does not declare.

Bazel must ignore the editor views: add `.godot-editor` to `.bazelignore`, or
`bazel build //...` finds the linked packages twice. The run fails until it
does. Arguments after `--` go to the editor.

Example:
```starlark
godot_editor(
    name = "edit",
    project = ":project",
    deps = [":game"],
)
```

`bazel run :edit` opens the editor on `.godot-editor/<package>/edit`.

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| executable | one | always | run an editable staged project in Godot; editor and project are runfiles |

### Output groups
none

### Generated targets
none

### Providers
none
2?
godot_editor/@autoload_rules_godot//godot/private:editor.bzl,
*
nameName of the executable target. (L
J
project;The godot_project whose configuration the editor view uses. (z
x
depsjWhat the editor view lists for editing: godot_resources and add-ons,
as an IDE project view lists targets.[](P
N
envAEnvironment variables set for the editor, besides the user's own.{}(�
�
write_sidecars�Write the sidecars the checkout lacks before the editor
opens, as godot_metadata_sync does. Without it, the run names them and Godot
writes its own when it finds the files, reimporting assets.True(=
;
kwargs/Common attributes, such as tags and visibility.(�'godot_metadata_sync�Write the metadata Godot keeps beside a project's checkout files, and test for it.

Godot keeps a script's or shader's UID in a `.uid` file beside it and an
imported asset's import settings, including its UID, in a `.import` file
beside it; both belong in version control. Where a checkout file has none,
the build generates them. `bazel run :<name>` writes those beside their
files in the checkout, where none exists yet, and names the target to
declare each in: commit them and declare them there, which a `glob` does on
its own. Existing files are never replaced; the run names the ones that
exist but are not declared.

With `--@autoload_rules_godot//godot/metadata:node_ids` or
`--@autoload_rules_godot//godot/metadata:resource_uids` at `sync` (default) or
`require`, the run also adds the `unique_id` each node of a checkout `.tscn`
scene lacks and the named file's UID to each `ext_resource` of a `.tscn` or
`.tres` file whose `uid` is missing or stale: the values a pack otherwise
adds only to the copy it exports.

`<name>.test` fails while the build generates a sidecar for a checkout file
and, for a metadata flag at `require`, while a file lacks those values, so
`bazel test //...` keeps the checkout complete. It needs no checkout and
names each sidecar with the command that writes it.

Example:
```starlark
godot_metadata_sync(
    name = "metadata",
    project = ":project",
    deps = [":game"],
)
```

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| executable | one | always | run writes missing metadata to the checkout; editor/project runfiles |

### Output groups
none

### Generated targets
| name | kind | purpose | reason | visibility | testonly | prerequisites | availability |
| --- | --- | --- | --- | --- | --- | --- | --- |
| {name}.test | test | test | Execute missing-metadata validation as a Bazel test; an output group cannot execute tests | caller | true | project imports and execution-platform editor | always |

### Providers
none
*�
�
godot_metadata_sync:
name.Name of the writer; the test is `<name>.test`. (N
project?The godot_project whose configuration the files are read under. (J
deps<The godot_resources whose checkout files get their metadata.[](U
sizeEBazel test size of `<name>.test`; Bazel's default applies when unset.None(U
timeoutBBazel test timeout of `<name>.test`; derived from size when unset.None(K
kwargs?Common attributes of both targets, such as tags and visibility.(�Write the metadata Godot keeps beside a project's checkout files, and test for it.

Godot keeps a script's or shader's UID in a `.uid` file beside it and an
imported asset's import settings, including its UID, in a `.import` file
beside it; both belong in version control. Where a checkout file has none,
the build generates them. `bazel run :<name>` writes those beside their
files in the checkout, where none exists yet, and names the target to
declare each in: commit them and declare them there, which a `glob` does on
its own. Existing files are never replaced; the run names the ones that
exist but are not declared.

With `--@autoload_rules_godot//godot/metadata:node_ids` or
`--@autoload_rules_godot//godot/metadata:resource_uids` at `sync` (default) or
`require`, the run also adds the `unique_id` each node of a checkout `.tscn`
scene lacks and the named file's UID to each `ext_resource` of a `.tscn` or
`.tres` file whose `uid` is missing or stale: the values a pack otherwise
adds only to the copy it exports.

`<name>.test` fails while the build generates a sidecar for a checkout file
and, for a metadata flag at `require`, while a file lacks those values, so
`bazel test //...` keeps the checkout complete. It needs no checkout and
names each sidecar with the command that writes it.

Example:
```starlark
godot_metadata_sync(
    name = "metadata",
    project = ":project",
    deps = [":game"],
)
```

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| executable | one | always | run writes missing metadata to the checkout; editor/project runfiles |

### Output groups
none

### Generated targets
| name | kind | purpose | reason | visibility | testonly | prerequisites | availability |
| --- | --- | --- | --- | --- | --- | --- | --- |
| {name}.test | test | test | Execute missing-metadata validation as a Bazel test; an output group cannot execute tests | caller | true | project imports and execution-platform editor | always |

### Providers
none
2F
godot_metadata_sync/@autoload_rules_godot//godot/private:editor.bzl<
:
name.Name of the writer; the test is `<name>.test`. (P
N
project?The godot_project whose configuration the files are read under. (L
J
deps<The godot_resources whose checkout files get their metadata.[](W
U
sizeEBazel test size of `<name>.test`; Bazel's default applies when unset.None(W
U
timeoutBBazel test timeout of `<name>.test`; derived from size when unset.None(M
K
kwargs?Common attributes of both targets, such as tags and visibility.(�godot_resource_graph�Emit a deterministic file/UID graph for resources; optionally validate references.

Does not execute Godot or modify Bazel dependencies.

Produces a .graph.json file in DefaultInfo from the resource graph of deps under the
project's configuration, without running Godot or adding inferred Bazel
dependencies. validate controls failures for invalid static references;
require_declared additionally requires explicit runtime reference declarations.
Dynamic references remain warnings.

Example:
```starlark
godot_resource_graph(
    name = "graph",
    project = ":project",
    deps = [":game"],
    require_declared = True,
)
```

See [resource graph diagnostics](../../resources.md).

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| files | one | always | build resource graph JSON with selected declaration/validation policy; no run behavior |

### Output groups
none

### Generated targets
none

### Providers
none
*�
�
godot_resource_graph%
nameName of the graph target. (E
project6The godot_project whose configuration the graph reads. (>
deps0The godot_resources whose files the graph scans.[](�
validatewFail on missing static references, invalid UID ownership or
conflicting identities. Dynamic references remain warnings.True(�
require_declared�Require inferred runtime file references to have matching
runtime_references entries. Project configuration references are
implicit; import inputs are checked for availability.False(;
kwargs/Common attributes, such as tags and visibility.(�Emit a deterministic file/UID graph for resources; optionally validate references.

Does not execute Godot or modify Bazel dependencies.

Produces a .graph.json file in DefaultInfo from the resource graph of deps under the
project's configuration, without running Godot or adding inferred Bazel
dependencies. validate controls failures for invalid static references;
require_declared additionally requires explicit runtime reference declarations.
Dynamic references remain warnings.

Example:
```starlark
godot_resource_graph(
    name = "graph",
    project = ":project",
    deps = [":game"],
    require_declared = True,
)
```

See [resource graph diagnostics](../../resources.md).

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| files | one | always | build resource graph JSON with selected declaration/validation policy; no run behavior |

### Output groups
none

### Generated targets
none

### Providers
none
2I
godot_resource_graph1@autoload_rules_godot//godot/private:analysis.bzl'
%
nameName of the graph target. (G
E
project6The godot_project whose configuration the graph reads. (@
>
deps0The godot_resources whose files the graph scans.[](�
�
validatewFail on missing static references, invalid UID ownership or
conflicting identities. Dynamic references remain warnings.True(�
�
require_declared�Require inferred runtime file references to have matching
runtime_references entries. Project configuration references are
implicit; import inputs are checked for availability.False(=
;
kwargs/Common attributes, such as tags and visibility.(�pgodot_addon�Declare an add-on once: its runtime part, its editor part with its roles, its
extensions, platform libraries, Info.plist fragments, autoloads, settings and the
add-ons it needs.

Resources whose files use the add-on list it in their deps; a project lists in its
deps the add-ons no content uses, such as an editor-only add-on, and every add-on
with importer_suffixes its content needs. Every operation containing those resources,
or of that project, contains the add-on: its runtime
part as members, its autoloads and settings merged into the configuration, its
extensions and platform libraries delivered by the applications shipping its packs.
The editor part is a tool: editor views load it, imports of files of its
importer_suffixes run it under a project that names the add-on, and no pack, source
run or application contains it. No export runs its EditorExportPlugin: what one adds
to Godot's own export is declared, as platform_deps, infoplists and pack settings.
Test-only resources that load its scripts, such as suites of its editor tooling, list
`<name>.editor` in their deps; that target is always test-only. A use
never makes the add-on's files inputs of the resources' import. Under the context of
an operation the add-on imports its parts itself, once per project and target
platform, whether content uses it or the project names it, and validates each part's
scripts and scenes as godot_resources validates its own.

Every file lives below directory, by default addons/<name>; srcs and editor_srcs
are placed there after strip_prefix. Two add-ons of one operation with overlapping
directories fail, as does a file in both parts.

Example:
```starlark
godot_addon(
    name = "inventory",
    srcs = glob(["runtime/**"]),
    editor_srcs = glob(["editor/**"]),
    autoloads = {"Inventory": "*res://addons/inventory/runtime/inventory.gd"},
    platform_deps = select({
        "@platforms//os:android": [":inventory_android"],
        "//conditions:default": [],
    }),
)

godot_resources(name = "shop", srcs = ["shop.gd"], deps = [":inventory"])
```

See [add-ons](../../resources.md#add-ons) and [importers](../../resources.md#importers).

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| files | many | always | build the files of both parts; no run behavior |

### Output groups
none

### Generated targets
| name | kind | purpose | reason | visibility | testonly | prerequisites | availability |
| --- | --- | --- | --- | --- | --- | --- | --- |
| {name}.editor | metadata | operation | the editor part as resources of test-only operations, such as suites of its editor tooling, which products cannot reach | caller | true | none | always |

### Providers
| name | role | availability |
| --- | --- | --- |
| GodotAddonInfo | Parts, roles, extensions, platform libraries and contributions of the add-on | always |Z�Y
�8
godot_addon�Declare an add-on once: its runtime part, its editor part with its roles, its
extensions, platform libraries, Info.plist fragments, autoloads, settings and the
add-ons it needs.

Resources whose files use the add-on list it in their deps; a project lists in its
deps the add-ons no content uses, such as an editor-only add-on, and every add-on
with importer_suffixes its content needs. Every operation containing those resources,
or of that project, contains the add-on: its runtime
part as members, its autoloads and settings merged into the configuration, its
extensions and platform libraries delivered by the applications shipping its packs.
The editor part is a tool: editor views load it, imports of files of its
importer_suffixes run it under a project that names the add-on, and no pack, source
run or application contains it. No export runs its EditorExportPlugin: what one adds
to Godot's own export is declared, as platform_deps, infoplists and pack settings.
Test-only resources that load its scripts, such as suites of its editor tooling, list
`<name>.editor` in their deps; that target is always test-only. A use
never makes the add-on's files inputs of the resources' import. Under the context of
an operation the add-on imports its parts itself, once per project and target
platform, whether content uses it or the project names it, and validates each part's
scripts and scenes as godot_resources validates its own.

Every file lives below directory, by default addons/<name>; srcs and editor_srcs
are placed there after strip_prefix. Two add-ons of one operation with overlapping
directories fail, as does a file in both parts.

Example:
```starlark
godot_addon(
    name = "inventory",
    srcs = glob(["runtime/**"]),
    editor_srcs = glob(["editor/**"]),
    autoloads = {"Inventory": "*res://addons/inventory/runtime/inventory.gd"},
    platform_deps = select({
        "@platforms//os:android": [":inventory_android"],
        "//conditions:default": [],
    }),
)

godot_resources(name = "shop", srcs = ["shop.gd"], deps = [":inventory"])
```

See [add-ons](../../resources.md#add-ons) and [importers](../../resources.md#importers).

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| files | many | always | build the files of both parts; no run behavior |

### Output groups
none

### Generated targets
| name | kind | purpose | reason | visibility | testonly | prerequisites | availability |
| --- | --- | --- | --- | --- | --- | --- | --- |
| {name}.editor | metadata | operation | the editor part as resources of test-only operations, such as suites of its editor tooling, which products cannot reach | caller | true | none | always |

### Providers
| name | role | availability |
| --- | --- | --- |
| GodotAddonInfo | Parts, roles, extensions, platform libraries and contributions of the add-on | always |�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@s
	directory^Resource path of the directory every file of the add-on lives below; empty
uses addons/<name>.2""8�
platform_deps�Android or Apple platform libraries the add-on's scripts use, such as an
Android plugin they fetch through Engine.get_singleton(): an
android_library, aar_import, Maven artifact, swift_library, objc_library or
XCFramework import; godot_app links and packages them for every application
shipping a pack that contains the add-on. A library's Android manifest
entries reach the application; an android_library needs
exports_manifest = 1 for that. Use select() with empty branches for other
operating systems.*?
JavaInfo3
JavaInfo'@rules_java//java/private:java_info.bzl*5
CcInfo+
CcInfo!@rules_cc//cc/private:cc_info.bzl2[]
deprecation2None8@
tags2None8@
testonly2None8@
features2None@
exec_properties
2None@"
exec_compatible_with2None8@Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@�
srcs�The runtime part: scripts, scenes and assets that every operation containing
the add-on holds as members, placed below directory after strip_prefix.2None�
editor_srcs�The editor part: its plugin.cfg and the files its editor plugin loads,
placed like srcs. Editor views load it, and processes that convert files of
its importer_suffixes stage it; no pack, source run or application
contains it.2None�
strip_prefix{Package-relative directory whose contents are placed below directory; empty
uses the package root. A file outside it fails.2None�
deps�The add-ons it needs and its extensions: godot_addon, godot_extension and
godot_cc_extension targets. Every extension here is the add-on's, wherever
its descriptor lies: the add-on's parts and importer load it. Every
operation containing this add-on contains its extensions and the add-ons it
needs. The runtime part may use their runtime parts,
the editor part both their parts, and each part imports after those.
Platform libraries go in platform_deps.2None�
importer_suffixes�The file suffixes, lowercase and without a dot, of the importers the add-on
registers, such as `["md"]`; it needs an editor part with a plugin.cfg or an
extension. A project that names the add-on in its deps stages and enables
the importer in exactly the imports of units with an own file of such a
suffix, in the initializations and exports of operations with such files,
and in its editor views. Resources may use the add-on only under a project
that names it. Each build checks the suffixes against the importers Godot
reports for the add-on and fails on a difference.2None�
import_settings�Keys of settings that the add-on's importer reads at import time; they reach
every import of a project that names the add-on, and a change reimports its
units. The other settings never reach imports.2None�

infoplists�Info.plist fragments iOS applications merge into their Info.plist, such as
usage descriptions the add-on's iOS library needs; those of its extensions
join them. Two add-ons with
different values for a key fail; the application's own ios_infoplists win.2None�
	autoloads�Autoload name to the res:// path of a file of the runtime part or of the
runtime part of an add-on it needs, optionally prefixed with '*' for a
singleton. Every operation containing the add-on has the autoload, after
those of the add-ons it needs and before the project's own; a conflicting
value requires the project's autoload_overrides.
2None�
settings�section/property -> Godot literal string of the operations containing the
add-on, never of imports; a conflicting value requires the project's
setting_overrides.
2None"=
godot_addon.@autoload_rules_godot//godot/private:addon.bzl�
�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �
�

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@u
s
	directory^Resource path of the directory every file of the add-on lives below; empty
uses addons/<name>.2""8�
�
platform_deps�Android or Apple platform libraries the add-on's scripts use, such as an
Android plugin they fetch through Engine.get_singleton(): an
android_library, aar_import, Maven artifact, swift_library, objc_library or
XCFramework import; godot_app links and packages them for every application
shipping a pack that contains the add-on. A library's Android manifest
entries reach the application; an android_library needs
exports_manifest = 1 for that. Use select() with empty branches for other
operating systems.*?
JavaInfo3
JavaInfo'@rules_java//java/private:java_info.bzl*5
CcInfo+
CcInfo!@rules_cc//cc/private:cc_info.bzl2[]

deprecation2None8@

tags2None8@

testonly2None8@

features2None@

exec_properties
2None@$
"
exec_compatible_with2None8@\
Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@�
�
srcs�The runtime part: scripts, scenes and assets that every operation containing
the add-on holds as members, placed below directory after strip_prefix.2None�
�
editor_srcs�The editor part: its plugin.cfg and the files its editor plugin loads,
placed like srcs. Editor views load it, and processes that convert files of
its importer_suffixes stage it; no pack, source run or application
contains it.2None�
�
strip_prefix{Package-relative directory whose contents are placed below directory; empty
uses the package root. A file outside it fails.2None�
�
deps�The add-ons it needs and its extensions: godot_addon, godot_extension and
godot_cc_extension targets. Every extension here is the add-on's, wherever
its descriptor lies: the add-on's parts and importer load it. Every
operation containing this add-on contains its extensions and the add-ons it
needs. The runtime part may use their runtime parts,
the editor part both their parts, and each part imports after those.
Platform libraries go in platform_deps.2None�
�
importer_suffixes�The file suffixes, lowercase and without a dot, of the importers the add-on
registers, such as `["md"]`; it needs an editor part with a plugin.cfg or an
extension. A project that names the add-on in its deps stages and enables
the importer in exactly the imports of units with an own file of such a
suffix, in the initializations and exports of operations with such files,
and in its editor views. Resources may use the add-on only under a project
that names it. Each build checks the suffixes against the importers Godot
reports for the add-on and fails on a difference.2None�
�
import_settings�Keys of settings that the add-on's importer reads at import time; they reach
every import of a project that names the add-on, and a change reimports its
units. The other settings never reach imports.2None�
�

infoplists�Info.plist fragments iOS applications merge into their Info.plist, such as
usage descriptions the add-on's iOS library needs; those of its extensions
join them. Two add-ons with
different values for a key fail; the application's own ios_infoplists win.2None�
�
	autoloads�Autoload name to the res:// path of a file of the runtime part or of the
runtime part of an add-on it needs, optionally prefixed with '*' for a
singleton. Every operation containing the add-on has the autoload, after
those of the add-ons it needs and before the project's own; a conflicting
value requires the project's autoload_overrides.
2None�
�
settings�section/property -> Godot literal string of the operations containing the
add-on, never of imports; a conflicting value requires the project's
setting_overrides.
2None�]godot_project�Declare the configuration context of a product: its project.godot, settings,
autoloads, main scene and the add-ons it names.

The project holds no resources. Every operation that runs Godot, such as
godot_pack, godot_run or godot_test, names a project and the
resources it works on; each resources target imports once under the project's
configuration, and every operation of the project for the same target platform
reuses that import. Settings that reach imports are the project's own, filtered by
the import purpose: the main scene, autoloads, settings naming files, keys outside
Godot's own sections and feature overrides the editor never applies stay out of
imports. The autoloads and
settings of the add-ons an operation contains merge with the project's per
operation, the project's last; conflicts require setting_overrides or
autoload_overrides. The add-ons the project names in deps are in every operation of
the project and import their parts under it like used add-ons.
A project is never testonly, also in a package with default_testonly: every resources
target imports under it, production resources included.

Example:
```starlark
godot_project(
    name = "project",
    project_file = "project.godot",
    main_scene = "main.tscn",
)

godot_pack(
    name = "pack",
    project = ":project",
    deps = [":main", ":textures"],
)
```

See [resource and configuration semantics](../../resources.md).

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| metadata | none | always | name the configuration context operations use; no build or run behavior |

### Output groups
none

### Generated targets
| name | kind | purpose | reason | visibility | testonly | prerequisites | availability |
| --- | --- | --- | --- | --- | --- | --- | --- |
| {name}.named_addons | metadata | analysis_boundary | The add-ons the project names, which the operations of the project reach without the project; not for direct use | caller | false | none | always |

### Providers
| name | role | availability |
| --- | --- | --- |
| GodotProjectInfo | The configuration context operations name and resources import under | always |Z�L
�.
godot_project�Declare the configuration context of a product: its project.godot, settings,
autoloads, main scene and the add-ons it names.

The project holds no resources. Every operation that runs Godot, such as
godot_pack, godot_run or godot_test, names a project and the
resources it works on; each resources target imports once under the project's
configuration, and every operation of the project for the same target platform
reuses that import. Settings that reach imports are the project's own, filtered by
the import purpose: the main scene, autoloads, settings naming files, keys outside
Godot's own sections and feature overrides the editor never applies stay out of
imports. The autoloads and
settings of the add-ons an operation contains merge with the project's per
operation, the project's last; conflicts require setting_overrides or
autoload_overrides. The add-ons the project names in deps are in every operation of
the project and import their parts under it like used add-ons.
A project is never testonly, also in a package with default_testonly: every resources
target imports under it, production resources included.

Example:
```starlark
godot_project(
    name = "project",
    project_file = "project.godot",
    main_scene = "main.tscn",
)

godot_pack(
    name = "pack",
    project = ":project",
    deps = [":main", ":textures"],
)
```

See [resource and configuration semantics](../../resources.md).

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| metadata | none | always | name the configuration context operations use; no build or run behavior |

### Output groups
none

### Generated targets
| name | kind | purpose | reason | visibility | testonly | prerequisites | availability |
| --- | --- | --- | --- | --- | --- | --- | --- |
| {name}.named_addons | metadata | analysis_boundary | The add-ons the project names, which the operations of the project reach without the project; not for direct use | caller | false | none | always |

### Providers
| name | role | availability |
| --- | --- | --- |
| GodotProjectInfo | The configuration context operations name and resources import under | always |�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@
deprecation2None8@
tags2None8@
testonly2None8@
features2None@
exec_properties
2None@"
exec_compatible_with2None8@Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@O
project_file;Declared project.godot file used as the base configuration. �
settingsusection/property -> Godot literal string. Every setting the import
purpose keeps affects every import of the project.
2None�
	autoloads�Autoload name to res:// path, optionally prefixed with '*' for a singleton;
conflicts require explicit overrides. An operation whose resources lack the
script leaves the autoload out; a pack without required_packs and a source
run fail instead.
2None]
setting_overrides@Explicitly replace conflicting setting contributions of add-ons.
2None_
autoload_overridesAExplicitly replace conflicting autoload contributions of add-ons.
2None�

main_scene�Resource path of the main scene, with optional res:// prefix. An operation
whose resources lack it leaves it out; a pack without required_packs and a
source run fail instead.2None�
context_filesvSingle-file target to resource path of files bound to the context itself,
such as an application icon a setting names.	2None�
custom_features�The build settings whose values are the project's Godot custom features,
such as bazel_skylib's string_flag (its value) and bool_flag (its name when
true); its packs and source runs have them. See
[Custom features](../../configuration.md#custom-features).*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2None�
settings_from_flags�Build settings whose values become project settings, as flag ->
section/property key, such as
`{"@autoload_rules_godot//godot:build_number": "application/config/build_number"}`.
A string becomes a Godot string, an int an int and a bool a bool; the value
is written also when it is empty or 0. Packs export with the values and
source runs start with them; imports, the editor and every other action
never read them, so a new value reruns only exports. They replace the
authored value; a pack's own settings replace them. A setting of the
project or an add-on with the same key, or a feature override of it in
project.godot or contributed settings, fails: it would conflict with the
value or hide it. No check resolves a res:// path a value names.
See [Settings from build settings](../../configuration.md#settings-from-build-settings).	*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl*F
FlagInfo:
FlagInfo.@autoload_rules_godot//godot/private:flags.bzl2None�
deps�The add-ons the project names: those no content of its operations uses,
such as an editor-only add-on with editor tooling,
extensions every operation loads, and every add-on whose importer the
project's content needs. Every operation of the project contains them, and
they import their parts under the project like used add-ons. Their
importer_suffixes and import_settings apply to the project's imports.
godot_addon, godot_extension and godot_cc_extension targets.*N
GodotAddonInfo<
GodotAddonInfo*@autoload_rules_godot//godot:providers.bzl2None"A
godot_project0@autoload_rules_godot//godot/private:project.bzl�
�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �
�

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@

deprecation2None8@

tags2None8@

testonly2None8@

features2None@

exec_properties
2None@$
"
exec_compatible_with2None8@\
Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@Q
O
project_file;Declared project.godot file used as the base configuration. �
�
settingsusection/property -> Godot literal string. Every setting the import
purpose keeps affects every import of the project.
2None�
�
	autoloads�Autoload name to res:// path, optionally prefixed with '*' for a singleton;
conflicts require explicit overrides. An operation whose resources lack the
script leaves the autoload out; a pack without required_packs and a source
run fail instead.
2None_
]
setting_overrides@Explicitly replace conflicting setting contributions of add-ons.
2Nonea
_
autoload_overridesAExplicitly replace conflicting autoload contributions of add-ons.
2None�
�

main_scene�Resource path of the main scene, with optional res:// prefix. An operation
whose resources lack it leaves it out; a pack without required_packs and a
source run fail instead.2None�
�
context_filesvSingle-file target to resource path of files bound to the context itself,
such as an application icon a setting names.	2None�
�
custom_features�The build settings whose values are the project's Godot custom features,
such as bazel_skylib's string_flag (its value) and bool_flag (its name when
true); its packs and source runs have them. See
[Custom features](../../configuration.md#custom-features).*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2None�
�
settings_from_flags�Build settings whose values become project settings, as flag ->
section/property key, such as
`{"@autoload_rules_godot//godot:build_number": "application/config/build_number"}`.
A string becomes a Godot string, an int an int and a bool a bool; the value
is written also when it is empty or 0. Packs export with the values and
source runs start with them; imports, the editor and every other action
never read them, so a new value reruns only exports. They replace the
authored value; a pack's own settings replace them. A setting of the
project or an add-on with the same key, or a feature override of it in
project.godot or contributed settings, fails: it would conflict with the
value or hide it. No check resolves a res:// path a value names.
See [Settings from build settings](../../configuration.md#settings-from-build-settings).	*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl*F
FlagInfo:
FlagInfo.@autoload_rules_godot//godot/private:flags.bzl2None�
�
deps�The add-ons the project names: those no content of its operations uses,
such as an editor-only add-on with editor tooling,
extensions every operation loads, and every add-on whose importer the
project's content needs. Every operation of the project contains them, and
they import their parts under the project like used add-ons. Their
importer_suffixes and import_settings apply to the project's imports.
godot_addon, godot_extension and godot_cc_extension targets.*N
GodotAddonInfo<
GodotAddonInfo*@autoload_rules_godot//godot:providers.bzl2None�P
godot_pack�Export a project as one PCK for the selected export platform.

The PCK contains extension descriptors, never extension libraries;
see [export membership](../../resources.md#export-membership).
Its extensions and platform libraries stay visible to the aspects of rules_android
and rules_apple in each platform slice. The export itself runs once, in the content
configuration, for all platform slices. Outside optimized builds the PCK is written
without Godot's conversions; see [pack forms](../../resources.md#pack-forms). DefaultInfo contains the PCK; GodotPackInfo
carries the project of each platform slice and the facts of the common export.
OutputGroupInfo.report exposes the export report. required_packs only affects which
files this pack contains; applications do not package the required packs, and
nothing mounts them at runtime.

Example: godot_pack(name = "pack", project = ":project", deps = [":game"]).
See [export behavior](../../resources.md).

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| files | one | always | build output_name.pck; no run behavior |

### Output groups
| name | contents | availability | prerequisites |
| --- | --- | --- | --- |
| report | Godot export JSON report | always | execution-platform editor |
| export_facts | What Godot reports about the export, as JSON | always | execution-platform editor |
| selection | Selected content JSON and the selection's warnings | always | none |

### Generated targets
none

### Providers
| name | role | availability |
| --- | --- | --- |
| GodotPackInfo | The PCK, and the project, operating system and CPUs of the platform slice | always |Z�C
�(

godot_pack�Export a project as one PCK for the selected export platform.

The PCK contains extension descriptors, never extension libraries;
see [export membership](../../resources.md#export-membership).
Its extensions and platform libraries stay visible to the aspects of rules_android
and rules_apple in each platform slice. The export itself runs once, in the content
configuration, for all platform slices. Outside optimized builds the PCK is written
without Godot's conversions; see [pack forms](../../resources.md#pack-forms). DefaultInfo contains the PCK; GodotPackInfo
carries the project of each platform slice and the facts of the common export.
OutputGroupInfo.report exposes the export report. required_packs only affects which
files this pack contains; applications do not package the required packs, and
nothing mounts them at runtime.

Example: godot_pack(name = "pack", project = ":project", deps = [":game"]).
See [export behavior](../../resources.md).

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| files | one | always | build output_name.pck; no run behavior |

### Output groups
| name | contents | availability | prerequisites |
| --- | --- | --- | --- |
| report | Godot export JSON report | always | execution-platform editor |
| export_facts | What Godot reports about the export, as JSON | always | execution-platform editor |
| selection | Selected content JSON and the selection's warnings | always | none |

### Generated targets
none

### Providers
| name | role | availability |
| --- | --- | --- |
| GodotPackInfo | The PCK, and the project, operating system and CPUs of the platform slice | always |�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@�
project8The godot_project whose configuration this pack exports. *R
GodotProjectInfo>
GodotProjectInfo*@autoload_rules_godot//godot:providers.bzl8�
deps�What the pack exports: godot_resources and add-ons, as on godot_resources.
Applications reach the extensions and platform libraries of the pack's
add-ons, the project's named ones included, through the pack.2[]_
tagsOConventional Bazel tags on this pack; internal helpers are additionally manual.2[]8Q
deprecation:Optional Bazel deprecation message for this authored pack.2""8]
featuresKBazel feature requests on export actions, distinct from Godot feature tags.2[]F
exec_properties-Execution properties for this pack's actions.
2{}\
exec_compatible_with<Execution platform constraints for this pack's export tools.2[]8o
target_compatible_withOBazel target compatibility constraints for this pack and its configured export.2[]
testonly2None8@�
preset_settings�Supported preset fields as Godot literals: script_export_mode is 0, 1 or 2. Omitted fields retain Godot defaults. Custom features come from godot_project.custom_features. See [Godot configuration](../../configuration.md).
2None�
settings�Project settings for this export only, as section/property -> Godot literal
string, for example `{"application/config/version": '"2.3.4"'}`. They
replace the project's values in the exported configuration; imports,
initialization and other packs keep the project's, so a change reruns
only this export. Feature overrides such as `key.mobile` apply when the
configured operating system or the project's custom features have the tag. Without an
application/config/version entry here, a nonempty
`--@autoload_rules_godot//godot:app_version` sets that setting.
2None�
export_options�Export preset options for this pack, as option name -> Godot literal
string, for example `{"texture_format/etc2_astc": "true"}`. These are the
options exporters and extensions' export plugins define in the preset's options
section. binary_format/embed_pck and binary_format/architecture are set
by the configured export platform and output layout.
2None�
packing�deps: every member of deps. reachable: what the project configuration,
entry_points, extensions and runtime_deps of used targets reach through
detected and declared references; fails where a reached file may load
undeclared files.2NoneJ"deps"J"reachable"�
entry_points|Declared paths that reachable selection starts from in addition to the main
scene, autoloads and other configured resources.2None�
required_packs�Packs whose resources this pack's references may use instead of packing
them again; a path both declare must have the same source file. This is
membership only, not runtime mounting or load order.*L
GodotPackInfo;
GodotPackInfo*@autoload_rules_godot//godot:providers.bzl2None";

godot_pack-@autoload_rules_godot//godot/private:pack.bzl�
�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �
�

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@�
�
project8The godot_project whose configuration this pack exports. *R
GodotProjectInfo>
GodotProjectInfo*@autoload_rules_godot//godot:providers.bzl8�
�
deps�What the pack exports: godot_resources and add-ons, as on godot_resources.
Applications reach the extensions and platform libraries of the pack's
add-ons, the project's named ones included, through the pack.2[]a
_
tagsOConventional Bazel tags on this pack; internal helpers are additionally manual.2[]8S
Q
deprecation:Optional Bazel deprecation message for this authored pack.2""8_
]
featuresKBazel feature requests on export actions, distinct from Godot feature tags.2[]H
F
exec_properties-Execution properties for this pack's actions.
2{}^
\
exec_compatible_with<Execution platform constraints for this pack's export tools.2[]8q
o
target_compatible_withOBazel target compatibility constraints for this pack and its configured export.2[]

testonly2None8@�
�
preset_settings�Supported preset fields as Godot literals: script_export_mode is 0, 1 or 2. Omitted fields retain Godot defaults. Custom features come from godot_project.custom_features. See [Godot configuration](../../configuration.md).
2None�
�
settings�Project settings for this export only, as section/property -> Godot literal
string, for example `{"application/config/version": '"2.3.4"'}`. They
replace the project's values in the exported configuration; imports,
initialization and other packs keep the project's, so a change reruns
only this export. Feature overrides such as `key.mobile` apply when the
configured operating system or the project's custom features have the tag. Without an
application/config/version entry here, a nonempty
`--@autoload_rules_godot//godot:app_version` sets that setting.
2None�
�
export_options�Export preset options for this pack, as option name -> Godot literal
string, for example `{"texture_format/etc2_astc": "true"}`. These are the
options exporters and extensions' export plugins define in the preset's options
section. binary_format/embed_pck and binary_format/architecture are set
by the configured export platform and output layout.
2None�
�
packing�deps: every member of deps. reachable: what the project configuration,
entry_points, extensions and runtime_deps of used targets reach through
detected and declared references; fails where a reached file may load
undeclared files.2NoneJ"deps"J"reachable"�
�
entry_points|Declared paths that reachable selection starts from in addition to the main
scene, autoloads and other configured resources.2None�
�
required_packs�Packs whose resources this pack's references may use instead of packing
them again; a path both declare must have the same source file. This is
membership only, not runtime mounting or load order.*L
GodotPackInfo;
GodotPackInfo*@autoload_rules_godot//godot:providers.bzl2None^Public core rules for resources, add-ons, projects, PCK exports, runs, tests and editor views.�
.
autoload_rules_godotgodot/enginedefs.bzl�godot_android_runtime�
Join Godot's Android shell library with an engine library into one aar_import runtime.

`shell` is an Android shell AAR file, such as the one of an official release or the
AAR of a source-built shell library. Without `engine_library`, the shell's own JNI
libraries are used. With it, the shell AAR is repacked in the configuration of each
platform slice, as the engine AAR, with that platform slice's engine library as
`jni/<abi>/libgodot_android.so`; the ABI follows the CPU of the platform slice, so
one target per variant serves every CPU, and `engine_library` may be a select()
over the CPU. Delivery copies are stripped as Bazel's `--strip` asks; the
`<name>.debug_symbols` of applications with this runtime contain them unstripped.
The ruleset supplies the shell library's Maven dependencies. Use the result as the
payload of a godot_runtime_component for an Android slot. This macro returns no
value.

Example:
```starlark
godot_android_runtime(
    name = "android_release",
    shell = "@godot_android_shell//:release.aar",
    engine_library = "@godot_android_arm64_release//:libgodot_android.so",
)
```

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| files | many | always | build imported AAR metadata and engine libraries; no run behavior |

### Output groups
none

### Generated targets
none

### Providers
none
*�
�
godot_android_runtime*
namePublic aar_import target name. (-
shell Godot's Android shell .aar file. ([
engine_libraryAOptional engine library .so target of the current platform slice.None(I
kwargs=Remaining aar_import attributes, such as tags and visibility.(�
Join Godot's Android shell library with an engine library into one aar_import runtime.

`shell` is an Android shell AAR file, such as the one of an official release or the
AAR of a source-built shell library. Without `engine_library`, the shell's own JNI
libraries are used. With it, the shell AAR is repacked in the configuration of each
platform slice, as the engine AAR, with that platform slice's engine library as
`jni/<abi>/libgodot_android.so`; the ABI follows the CPU of the platform slice, so
one target per variant serves every CPU, and `engine_library` may be a select()
over the CPU. Delivery copies are stripped as Bazel's `--strip` asks; the
`<name>.debug_symbols` of applications with this runtime contain them unstripped.
The ruleset supplies the shell library's Maven dependencies. Use the result as the
payload of a godot_runtime_component for an Android slot. This macro returns no
value.

Example:
```starlark
godot_android_runtime(
    name = "android_release",
    shell = "@godot_android_shell//:release.aar",
    engine_library = "@godot_android_arm64_release//:libgodot_android.so",
)
```

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| files | many | always | build imported AAR metadata and engine libraries; no run behavior |

### Output groups
none

### Generated targets
none

### Providers
none
2S
godot_android_runtime:@autoload_rules_godot//godot/platforms/private:android.bzl,
*
namePublic aar_import target name. (/
-
shell Godot's Android shell .aar file. (]
[
engine_libraryAOptional engine library .so target of the current platform slice.None(K
I
kwargs=Remaining aar_import attributes, such as tags and visibility.(�4godot_editor_component�Declare one execution-platform editor slot and its toolchain registration.

Creates the provenance-carrying toolchain implementation `<name>` and Bazel's
built-in `toolchain()` `<name>.toolchain`, constrained to the operating system and CPU
of the execution platform and to the engine selected by `--@autoload_rules_godot//godot:engine`.
A registration set is a package of components: register it with its `:all` pattern;
the first registered candidate of the selected engine for a slot wins. The
editor may be an executable target, such as a prebuilt editor archive's `:editor` or
a source recipe's `:godot`, or another editor component, whose payload and provenance
are forwarded.

Example:
```starlark
godot_editor_component(
    name = "editor_macos_arm64",
    editor = "@godot_editor_macos//:editor",
    platform = "macos",
    cpu = "arm64",
    version = "4.7.2",
)
```

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| files | many | always | build the editor payload and its runfiles; no run behavior |

### Output groups
none

### Generated targets
| name | kind | purpose | reason | visibility | testonly | prerequisites | availability |
| --- | --- | --- | --- | --- | --- | --- | --- |
| {name}.toolchain | metadata | analysis_boundary | register the slot with editor_toolchain_type; toolchain resolution is a separate boundary | caller | inherit | none | always |
| {name}.engine | metadata | analysis_boundary | the config_setting on --@autoload_rules_godot//godot:engine that the toolchain requires for a named engine | caller | inherit | none | engine named |

### Providers
| name | role | availability |
| --- | --- | --- |
| ToolchainInfo | godot editor files, executable, version and provenance | always |
| GodotComponentInfo | Provenance of the declared slot | always |Z�%
�
godot_editor_component�Declare one execution-platform editor slot and its toolchain registration.

Creates the provenance-carrying toolchain implementation `<name>` and Bazel's
built-in `toolchain()` `<name>.toolchain`, constrained to the operating system and CPU
of the execution platform and to the engine selected by `--@autoload_rules_godot//godot:engine`.
A registration set is a package of components: register it with its `:all` pattern;
the first registered candidate of the selected engine for a slot wins. The
editor may be an executable target, such as a prebuilt editor archive's `:editor` or
a source recipe's `:godot`, or another editor component, whose payload and provenance
are forwarded.

Example:
```starlark
godot_editor_component(
    name = "editor_macos_arm64",
    editor = "@godot_editor_macos//:editor",
    platform = "macos",
    cpu = "arm64",
    version = "4.7.2",
)
```

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| files | many | always | build the editor payload and its runfiles; no run behavior |

### Output groups
none

### Generated targets
| name | kind | purpose | reason | visibility | testonly | prerequisites | availability |
| --- | --- | --- | --- | --- | --- | --- | --- |
| {name}.toolchain | metadata | analysis_boundary | register the slot with editor_toolchain_type; toolchain resolution is a separate boundary | caller | inherit | none | always |
| {name}.engine | metadata | analysis_boundary | the config_setting on --@autoload_rules_godot//godot:engine that the toolchain requires for a named engine | caller | inherit | none | engine named |

### Providers
| name | role | availability |
| --- | --- | --- |
| ToolchainInfo | godot editor files, executable, version and provenance | always |
| GodotComponentInfo | Provenance of the declared slot | always |�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@�
cpuICPU of the slot as Godot's CPU tag: arm32, arm64, x86_32, x86_64 or rv64. 8J"arm32"J"arm64"J"rv64"J"x86_32"J"x86_64"j
versionYCanonical Godot version of the payload; producer metadata takes precedence where present. 8a
originOOptional human-readable origin recorded in provenance; never part of selection.2""8�
engine�Name of the engine the slot belongs to; the component fills it only in builds whose
--@autoload_rules_godot//godot:engine names that engine. Empty, the default, joins the
default engine, which builds use when the flag is empty.2""8w
tagsgConventional Bazel tags for both generated targets, such as manual for a payload only some builds need.2[]8X
editorJExecutable editor for the execution platform, or another editor component. c
platform?Operating system of the slot's editor platform: linux or macos. 8J"linux"J"macos""T
godot_editor_component:@autoload_rules_godot//godot/engine/private:components.bzl�
�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �
�

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@�
�
cpuICPU of the slot as Godot's CPU tag: arm32, arm64, x86_32, x86_64 or rv64. 8J"arm32"J"arm64"J"rv64"J"x86_32"J"x86_64"l
j
versionYCanonical Godot version of the payload; producer metadata takes precedence where present. 8c
a
originOOptional human-readable origin recorded in provenance; never part of selection.2""8�
�
engine�Name of the engine the slot belongs to; the component fills it only in builds whose
--@autoload_rules_godot//godot:engine names that engine. Empty, the default, joins the
default engine, which builds use when the flag is empty.2""8y
w
tagsgConventional Bazel tags for both generated targets, such as manual for a payload only some builds need.2[]8Z
X
editorJExecutable editor for the execution platform, or another editor component. e
c
platform?Operating system of the slot's editor platform: linux or macos. 8J"linux"J"macos"�?godot_runtime_component�Declare one target-platform runtime slot and its toolchain registration.

Creates the provenance-carrying toolchain implementation `<name>` and Bazel's
built-in `toolchain()` `<name>.toolchain`, constrained to the target platform's operating
system, CPU and iOS environment, with `target_settings` on
`--@autoload_rules_godot//godot:variant` for the template variant and on
`--@autoload_rules_godot//godot:engine` for the engine. The runtime may be a
desktop template file, a target with GodotRuntimeInfo, an iOS XCFramework import or
`:engine_library`, an Android runtime, a `select()` between prepared same-slot
payloads, or another runtime component, whose payload and provenance are forwarded.
Every selected branch must fill the declared slot; slot facts are not configurable.

Example:
```starlark
godot_runtime_component(
    name = "runtime_ios_arm64_simulator_debug",
    runtime = "@godot_ios_arm64_simulator_debug//:engine_library",
    platform = "ios",
    cpu = "arm64",
    environment = "simulator",
    variant = "debug",
    version = "4.7.2",
)
```

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| files | many | always | build the runtime payload; no run behavior |

### Output groups
none

### Generated targets
| name | kind | purpose | reason | visibility | testonly | prerequisites | availability |
| --- | --- | --- | --- | --- | --- | --- | --- |
| {name}.toolchain | metadata | analysis_boundary | register the slot with runtime_toolchain_type; toolchain resolution is a separate boundary | caller | inherit | none | always |
| {name}.engine | metadata | analysis_boundary | the config_setting on --@autoload_rules_godot//godot:engine that the toolchain requires for a named engine | caller | inherit | none | engine named |

### Providers
| name | role | availability |
| --- | --- | --- |
| ToolchainInfo | godot runtime payload, GodotRuntimeInfo where known, version and provenance | always |
| GodotComponentInfo | Provenance of the declared slot | always |Z�/
� 
godot_runtime_component�Declare one target-platform runtime slot and its toolchain registration.

Creates the provenance-carrying toolchain implementation `<name>` and Bazel's
built-in `toolchain()` `<name>.toolchain`, constrained to the target platform's operating
system, CPU and iOS environment, with `target_settings` on
`--@autoload_rules_godot//godot:variant` for the template variant and on
`--@autoload_rules_godot//godot:engine` for the engine. The runtime may be a
desktop template file, a target with GodotRuntimeInfo, an iOS XCFramework import or
`:engine_library`, an Android runtime, a `select()` between prepared same-slot
payloads, or another runtime component, whose payload and provenance are forwarded.
Every selected branch must fill the declared slot; slot facts are not configurable.

Example:
```starlark
godot_runtime_component(
    name = "runtime_ios_arm64_simulator_debug",
    runtime = "@godot_ios_arm64_simulator_debug//:engine_library",
    platform = "ios",
    cpu = "arm64",
    environment = "simulator",
    variant = "debug",
    version = "4.7.2",
)
```

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| files | many | always | build the runtime payload; no run behavior |

### Output groups
none

### Generated targets
| name | kind | purpose | reason | visibility | testonly | prerequisites | availability |
| --- | --- | --- | --- | --- | --- | --- | --- |
| {name}.toolchain | metadata | analysis_boundary | register the slot with runtime_toolchain_type; toolchain resolution is a separate boundary | caller | inherit | none | always |
| {name}.engine | metadata | analysis_boundary | the config_setting on --@autoload_rules_godot//godot:engine that the toolchain requires for a named engine | caller | inherit | none | engine named |

### Providers
| name | role | availability |
| --- | --- | --- |
| ToolchainInfo | godot runtime payload, GodotRuntimeInfo where known, version and provenance | always |
| GodotComponentInfo | Provenance of the declared slot | always |�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@�
cpuICPU of the slot as Godot's CPU tag: arm32, arm64, x86_32, x86_64 or rv64. 8J"arm32"J"arm64"J"rv64"J"x86_32"J"x86_64"j
versionYCanonical Godot version of the payload; producer metadata takes precedence where present. 8a
originOOptional human-readable origin recorded in provenance; never part of selection.2""8�
engine�Name of the engine the slot belongs to; the component fills it only in builds whose
--@autoload_rules_godot//godot:engine names that engine. Empty, the default, joins the
default engine, which builds use when the flag is empty.2""8w
tagsgConventional Bazel tags for both generated targets, such as manual for a payload only some builds need.2[]8v
runtimegRuntime payload for the declared slot, a select() over prepared payloads, or another runtime component. �
platformMOperating system of the slot's target platform: linux, macos, android or ios. 8J"linux"J"macos"J	"android"J"ios"e
variant@Godot template variant the payload implements: debug or release. 8J"debug"J	"release"}
environmentKiOS environment, device or simulator; required for iOS and empty otherwise.2""8J""J"device"J"simulator"�
digest�Optional digest of the artifact behind an opaque payload, such as the archive of
an XCFramework import or an Android shell AAR, recorded in provenance. Source
recipes and prebuilt template files supply their own, which take precedence.2""8"U
godot_runtime_component:@autoload_rules_godot//godot/engine/private:components.bzl�
�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �
�

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@�
�
cpuICPU of the slot as Godot's CPU tag: arm32, arm64, x86_32, x86_64 or rv64. 8J"arm32"J"arm64"J"rv64"J"x86_32"J"x86_64"l
j
versionYCanonical Godot version of the payload; producer metadata takes precedence where present. 8c
a
originOOptional human-readable origin recorded in provenance; never part of selection.2""8�
�
engine�Name of the engine the slot belongs to; the component fills it only in builds whose
--@autoload_rules_godot//godot:engine names that engine. Empty, the default, joins the
default engine, which builds use when the flag is empty.2""8y
w
tagsgConventional Bazel tags for both generated targets, such as manual for a payload only some builds need.2[]8x
v
runtimegRuntime payload for the declared slot, a select() over prepared payloads, or another runtime component. �
�
platformMOperating system of the slot's target platform: linux, macos, android or ios. 8J"linux"J"macos"J	"android"J"ios"g
e
variant@Godot template variant the payload implements: debug or release. 8J"debug"J	"release"
}
environmentKiOS environment, device or simulator; required for iOS and empty otherwise.2""8J""J"device"J"simulator"�
�
digest�Optional digest of the artifact behind an opaque payload, such as the archive of
an XCFramework import or an Android shell AAR, recorded in provenance. Source
recipes and prebuilt template files supply their own, which take precedence.2""8�Engine components and the Android runtime payload.

godot_editor_component and godot_runtime_component declare the editor or the runtime of one
slot and its toolchain registration; godot_android_runtime combines the Android shell
library with the engine library into an Android runtime payload. See
[engines](../../engine.md).��
6
autoload_rules_godotgodot/enginerepositories.bzl�Ggodot_engine_source_build�Declare a source build: its source recipes and its hub, from a module extension.

Call during a module extension's implementation; the helper declares repositories and
cannot run in BUILD files. It applies one build policy to the valid rows its filters
select: one godot_engine_build per row, named `<name>_<platform>_<cpu>[_<environment>]_<build_target>`,
for Android one godot_android_shell named `<name>_android_shell` with the same patches,
and the hub `<name>` with one component per slot in `@<name>//toolchains`, registered
through `@<name>//toolchains:all`. Common inputs apply to every row; declaring the
source build configures no recipe until a build requests its payload.

Example (an extension implementation):
```starlark
godot_engine_source_build(
    name = "godot_source_build",
    source = "@godot_sources//:source.json",
    platforms = ["macos", "ios"],
    build_targets = ["editor", "template_release"],
)
```

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| repository | none | always | repository creation; generated entrypoints described above |

### Output groups
none

### Generated targets
| name | kind | purpose | reason | visibility | testonly | prerequisites | availability |
| --- | --- | --- | --- | --- | --- | --- | --- |
| @{repository}//toolchains:editor_{platform}_{cpu} | files | operation | the editor component of one selected editor row | public | false | editor row selected | editor |
| @{repository}//toolchains:runtime_{platform}_{cpu}_{variant} | files | operation | the runtime component of one selected Linux or macOS template row | public | false | desktop row selected | desktop |
| @{repository}//toolchains:runtime_ios_{cpu}_{environment}_{variant} | files | operation | the runtime component of one selected iOS template row | public | false | iOS row selected | ios |
| @{repository}//toolchains:runtime_android_{cpu}_{variant} | files | operation | the runtime component of one selected Android template row | public | false | Android row selected | android |
| @{repository}//android:{variant} | files | operation | the Android runtime of one template variant: the source build's Android shell library with each CPU's engine library | public | false | Android row selected | android |
| @{repository}//android:plugin_api | files | operation | the shell library's classes for Android plugins to compile against, never packaged; applications package the runtime of their variant | public | false | Android row selected | android |
| @{repository}//toolchains:editor_{platform}_{cpu}.toolchain | metadata | analysis_boundary | register one editor slot alone | public | false | none | editor |
| @{repository}//toolchains:runtime_{platform}_{cpu}_{variant}.toolchain | metadata | analysis_boundary | register one runtime slot alone | public | false | none | desktop |
| @{repository}//toolchains:runtime_ios_{cpu}_{environment}_{variant}.toolchain | metadata | analysis_boundary | register one runtime slot alone | public | false | none | ios |
| @{repository}//toolchains:runtime_android_{cpu}_{variant}.toolchain | metadata | analysis_boundary | register one runtime slot alone | public | false | none | android |

### Providers
none
*�.
�$
godot_engine_source_buildM
nameAHub repository name and the prefix of the generated repositories. (Y
sourceKLabel of the `:source.json` descriptor of a godot_engine_source repository. (?
	platforms.Nonempty list of linux, macos, android or ios. (J
cpus<Optional arm64/x86_64 filter; empty selects every valid CPU.[](a
build_targetsJOptional editor/template_debug/template_release filter; empty selects all.[](\
ios_environmentsBOptional device/simulator filter for iOS rows; empty selects both.[](O
enabled_modulesAs for godot_engine_build.["gdscript", "text_server_fb"](2
custom_modulesAs for godot_engine_build.{}(S
patchesBAs for godot_engine_build; Android shell libraries apply them too.[](.
patch_stripAs for godot_engine_build.1(1
build_optionsAs for godot_engine_build.{}(4

build_nameAs for godot_engine_build."custom"(,
pythonAs for godot_engine_build.None(6
configure_timeoutAs for godot_engine_build.600(�
	lock_file�Optional Label of the lock file that pins every recipe; see
godot_engines.source_build. The hub then declares `:pin`, which writes it.None(�
enginerName of the engine the hub's components belong to; empty joins the
default engine. See godot_engines.source_build.""(�Declare a source build: its source recipes and its hub, from a module extension.

Call during a module extension's implementation; the helper declares repositories and
cannot run in BUILD files. It applies one build policy to the valid rows its filters
select: one godot_engine_build per row, named `<name>_<platform>_<cpu>[_<environment>]_<build_target>`,
for Android one godot_android_shell named `<name>_android_shell` with the same patches,
and the hub `<name>` with one component per slot in `@<name>//toolchains`, registered
through `@<name>//toolchains:all`. Common inputs apply to every row; declaring the
source build configures no recipe until a build requests its payload.

Example (an extension implementation):
```starlark
godot_engine_source_build(
    name = "godot_source_build",
    source = "@godot_sources//:source.json",
    platforms = ["macos", "ios"],
    build_targets = ["editor", "template_release"],
)
```

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| repository | none | always | repository creation; generated entrypoints described above |

### Output groups
none

### Generated targets
| name | kind | purpose | reason | visibility | testonly | prerequisites | availability |
| --- | --- | --- | --- | --- | --- | --- | --- |
| @{repository}//toolchains:editor_{platform}_{cpu} | files | operation | the editor component of one selected editor row | public | false | editor row selected | editor |
| @{repository}//toolchains:runtime_{platform}_{cpu}_{variant} | files | operation | the runtime component of one selected Linux or macOS template row | public | false | desktop row selected | desktop |
| @{repository}//toolchains:runtime_ios_{cpu}_{environment}_{variant} | files | operation | the runtime component of one selected iOS template row | public | false | iOS row selected | ios |
| @{repository}//toolchains:runtime_android_{cpu}_{variant} | files | operation | the runtime component of one selected Android template row | public | false | Android row selected | android |
| @{repository}//android:{variant} | files | operation | the Android runtime of one template variant: the source build's Android shell library with each CPU's engine library | public | false | Android row selected | android |
| @{repository}//android:plugin_api | files | operation | the shell library's classes for Android plugins to compile against, never packaged; applications package the runtime of their variant | public | false | Android row selected | android |
| @{repository}//toolchains:editor_{platform}_{cpu}.toolchain | metadata | analysis_boundary | register one editor slot alone | public | false | none | editor |
| @{repository}//toolchains:runtime_{platform}_{cpu}_{variant}.toolchain | metadata | analysis_boundary | register one runtime slot alone | public | false | none | desktop |
| @{repository}//toolchains:runtime_ios_{cpu}_{environment}_{variant}.toolchain | metadata | analysis_boundary | register one runtime slot alone | public | false | none | ios |
| @{repository}//toolchains:runtime_android_{cpu}_{variant}.toolchain | metadata | analysis_boundary | register one runtime slot alone | public | false | none | android |

### Providers
none
2Q
godot_engine_source_build4@autoload_rules_godot//godot/engine:repositories.bzlO
M
nameAHub repository name and the prefix of the generated repositories. ([
Y
sourceKLabel of the `:source.json` descriptor of a godot_engine_source repository. (A
?
	platforms.Nonempty list of linux, macos, android or ios. (L
J
cpus<Optional arm64/x86_64 filter; empty selects every valid CPU.[](c
a
build_targetsJOptional editor/template_debug/template_release filter; empty selects all.[](^
\
ios_environmentsBOptional device/simulator filter for iOS rows; empty selects both.[](Q
O
enabled_modulesAs for godot_engine_build.["gdscript", "text_server_fb"](4
2
custom_modulesAs for godot_engine_build.{}(U
S
patchesBAs for godot_engine_build; Android shell libraries apply them too.[](0
.
patch_stripAs for godot_engine_build.1(3
1
build_optionsAs for godot_engine_build.{}(6
4

build_nameAs for godot_engine_build."custom"(.
,
pythonAs for godot_engine_build.None(8
6
configure_timeoutAs for godot_engine_build.600(�
�
	lock_file�Optional Label of the lock file that pins every recipe; see
godot_engines.source_build. The hub then declares `:pin`, which writes it.None(�
�
enginerName of the engine the hub's components belong to; empty joins the
default engine. See godot_engines.source_build.""(�godot_engine_source�Acquire one immutable Godot source archive for godot_engine_build recipes.

Call through use_repo_rule in MODULE.bazel, or from a module extension. The
repository exports `:source.json`, the descriptor recipes take as `source`, and the
archive itself; it never extracts or configures the sources. Upstream releases and
fork archives alike are pinned by digest and their canonical Godot version, which
every recipe checks against the extracted version.py.

Example (MODULE.bazel):
```starlark
godot_engine_source = use_repo_rule(
    "@autoload_rules_godot//godot/engine:repositories.bzl", "godot_engine_source",
)
godot_engine_source(
    name = "godot_sources",
    sha256 = "e954996374cbd1cb5d72e0e3781cc537408e6ce73b010b12c6c2f308a820690a",
    strip_prefix = "godot-4.7.2-stable",
    urls = ["https://github.com/godotengine/godot/archive/refs/tags/4.7.2-stable.tar.gz"],
    version = "4.7.2",
)
```

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| repository | none | always | repository creation; generated entrypoints described above |

### Output groups
none

### Generated targets
| name | kind | purpose | reason | visibility | testonly | prerequisites | availability |
| --- | --- | --- | --- | --- | --- | --- | --- |
| @{repository}//:source.json | files | operation | the source descriptor godot_engine_build recipes take as source | public | false | archive acquired | always |
| @{repository}//:{archive} | files | operation | the acquired archive, which recipes extract independently | public | false | archive acquired | always |

### Providers
noneR�
�
godot_engine_source�Acquire one immutable Godot source archive for godot_engine_build recipes.

Call through use_repo_rule in MODULE.bazel, or from a module extension. The
repository exports `:source.json`, the descriptor recipes take as `source`, and the
archive itself; it never extracts or configures the sources. Upstream releases and
fork archives alike are pinned by digest and their canonical Godot version, which
every recipe checks against the extracted version.py.

Example (MODULE.bazel):
```starlark
godot_engine_source = use_repo_rule(
    "@autoload_rules_godot//godot/engine:repositories.bzl", "godot_engine_source",
)
godot_engine_source(
    name = "godot_sources",
    sha256 = "e954996374cbd1cb5d72e0e3781cc537408e6ce73b010b12c6c2f308a820690a",
    strip_prefix = "godot-4.7.2-stable",
    urls = ["https://github.com/godotengine/godot/archive/refs/tags/4.7.2-stable.tar.gz"],
    version = "4.7.2",
)
```

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| repository | none | always | repository creation; generated entrypoints described above |

### Output groups
none

### Generated targets
| name | kind | purpose | reason | visibility | testonly | prerequisites | availability |
| --- | --- | --- | --- | --- | --- | --- | --- |
| @{repository}//:source.json | files | operation | the source descriptor godot_engine_build recipes take as source | public | false | archive acquired | always |
| @{repository}//:{archive} | files | operation | the acquired archive, which recipes extract independently | public | false | archive acquired | always |

### Providers
none.
name"A unique name for this repository. [
urlsOOrdered mirror URLs of the same archive; the first one's suffix names its type. ,
sha256SHA-256 digest of the archive. @
strip_prefix*Top-level directory removed on extraction.2""T
versionECanonical Godot version of the sources, such as 4.7.2 or 4.8.0-beta1. *K
godot_engine_source4@autoload_rules_godot//godot/engine:repositories.bzl0
.
name"A unique name for this repository. ]
[
urlsOOrdered mirror URLs of the same archive; the first one's suffix names its type. .
,
sha256SHA-256 digest of the archive. B
@
strip_prefix*Top-level directory removed on extraction.2""V
T
versionECanonical Godot version of the sources, such as 4.7.2 or 4.8.0-beta1. �Mgodot_engine_build�Configure one fixed Godot source recipe and emit granular rules_cc build targets.

Call through use_repo_rule in MODULE.bazel, or from a module extension. The recipe
extracts the archive of a godot_engine_source descriptor into its own repository,
applies the patches, adds the modules and captures the upstream build graph; SCons
never compiles. Compilation runs later as Bazel actions, only for the outputs a build
requests. The recipe registers nothing: name its outputs as component payloads.
Fetching needs host Python 3.9+ (or the python attribute), patch when patches are
supplied, and the target operating system's SDK. Bazel's repo contents cache, local
or remote (--experimental_remote_repo_contents_cache), reuses Android, iOS and macOS
recipes; Linux recipes configure on every host, because Godot enables Linux features
by the packages installed there.

Example (MODULE.bazel):
```starlark
godot_engine_build = use_repo_rule(
    "@autoload_rules_godot//godot/engine:repositories.bzl", "godot_engine_build",
)
godot_engine_build(
    name = "godot_macos_arm64_release",
    cpu = "arm64",
    build_target = "template_release",
    platform = "macos",
    source = "@godot_sources//:source.json",
)
```

A source contradicting the descriptor's version, unknown or rules_godot-controlled
options, unresolvable modules and rejected patch hunks fail the recipe. See
[source-built engines](../../engine.md) for custom modules, options and patches.

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| repository | none | always | repository creation; generated entrypoints described above |

### Output groups
none

### Generated targets
| name | kind | purpose | reason | visibility | testonly | prerequisites | availability |
| --- | --- | --- | --- | --- | --- | --- | --- |
| @{repository}//:godot | executable | operation | the desktop editor or template executable, a component payload | public | false | desktop recipe | desktop |
| @{repository}//:godot | files | operation | the Android engine library with provenance | public | false | Android recipe | android |
| @{repository}//:engine_library | library | operation | link the engine library through CcInfo; the iOS component payload | public | false | recipe configured with the owning operating system's SDK | always |
| @{repository}//:libgodot_android.so | library | operation | the Android engine library, godot_android_runtime's engine_library | public | false | Android recipe | android |
| @{repository}//:engine_manifest.json | files | operation | inspect captured SCons configuration facts | public | false | recipe configured | always |

### Providers
noneR�8
�'
godot_engine_build�Configure one fixed Godot source recipe and emit granular rules_cc build targets.

Call through use_repo_rule in MODULE.bazel, or from a module extension. The recipe
extracts the archive of a godot_engine_source descriptor into its own repository,
applies the patches, adds the modules and captures the upstream build graph; SCons
never compiles. Compilation runs later as Bazel actions, only for the outputs a build
requests. The recipe registers nothing: name its outputs as component payloads.
Fetching needs host Python 3.9+ (or the python attribute), patch when patches are
supplied, and the target operating system's SDK. Bazel's repo contents cache, local
or remote (--experimental_remote_repo_contents_cache), reuses Android, iOS and macOS
recipes; Linux recipes configure on every host, because Godot enables Linux features
by the packages installed there.

Example (MODULE.bazel):
```starlark
godot_engine_build = use_repo_rule(
    "@autoload_rules_godot//godot/engine:repositories.bzl", "godot_engine_build",
)
godot_engine_build(
    name = "godot_macos_arm64_release",
    cpu = "arm64",
    build_target = "template_release",
    platform = "macos",
    source = "@godot_sources//:source.json",
)
```

A source contradicting the descriptor's version, unknown or rules_godot-controlled
options, unresolvable modules and rejected patch hunks fail the recipe. See
[source-built engines](../../engine.md) for custom modules, options and patches.

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| repository | none | always | repository creation; generated entrypoints described above |

### Output groups
none

### Generated targets
| name | kind | purpose | reason | visibility | testonly | prerequisites | availability |
| --- | --- | --- | --- | --- | --- | --- | --- |
| @{repository}//:godot | executable | operation | the desktop editor or template executable, a component payload | public | false | desktop recipe | desktop |
| @{repository}//:godot | files | operation | the Android engine library with provenance | public | false | Android recipe | android |
| @{repository}//:engine_library | library | operation | link the engine library through CcInfo; the iOS component payload | public | false | recipe configured with the owning operating system's SDK | always |
| @{repository}//:libgodot_android.so | library | operation | the Android engine library, godot_android_runtime's engine_library | public | false | Android recipe | android |
| @{repository}//:engine_manifest.json | files | operation | inspect captured SCons configuration facts | public | false | recipe configured | always |

### Providers
none.
name"A unique name for this repository. P
sourceBThe `:source.json` descriptor of a godot_engine_source repository. j
platform6Target operating system: linux, macos, android or ios. J"linux"J"macos"J	"android"J"ios"/
cpu$Target CPU, such as arm64 or x86_64. �
build_target?Godot build target: editor, template_debug or template_release. J"editor"J"template_debug"J"template_release"{
environmentKiOS environment, device or simulator; required for iOS and empty elsewhere.2""J""J"device"J"simulator"�
enabled_modulesNEnabled Godot modules; their dependencies come from the source's module graph.2["gdscript", "text_server_fb"]~
custom_modulesfEach custom module's config.py label mapped to its module name; the containing
source tree is watched.	2{}_
patchesNPatch files applied in order; any rejected or ambiguous hunk fails the recipe.2[]W
patch_stripCNumber of leading path components removed from each patch filename.21�
build_options�Upstream configure options as string values; import_env_vars lists
comma-separated environment dependencies. Options rules_godot controls, such as
platform, arch, target, the iOS simulator switch and module selection, are
rejected; optimize and debug_symbols follow Bazel's -c, --copt and --per_file_copt.
2{}�

build_name�Build name the engine reports in its version, followed by where its hash
comes from, such as 4.7.2.stable.custom-git.<hash>; letters, digits and
underscores.2"custom"�
pythonwOptional declared Python executable for configure-only graph translation;
otherwise uses python3 on PATH (Python 3.9+).2NoneR
configure_timeout6Maximum configure-only subprocess duration in seconds.2600�
	lock_file�The lock file that pins this recipe's build graph, as a source build's lock_file
names it. With it, the repository configures nothing on this host and declares
`:pin`, which configures the recipe on an execution platform Godot accepts.2NoneQ
lock_key?The recipe's key in the lock file, such as linux_x86_64_editor.2""U
repinFThe target that repins the lock file, named by a stale recipe's error.2"""DEVELOPER_DIR"SDKROOT"PATH"PKG_CONFIG_PATH"GODOT_VERSION_STATUS"SCRIPT_AES256_ENCRYPTION_KEY*J
godot_engine_build4@autoload_rules_godot//godot/engine:repositories.bzl0
.
name"A unique name for this repository. R
P
sourceBThe `:source.json` descriptor of a godot_engine_source repository. l
j
platform6Target operating system: linux, macos, android or ios. J"linux"J"macos"J	"android"J"ios"1
/
cpu$Target CPU, such as arm64 or x86_64. �
�
build_target?Godot build target: editor, template_debug or template_release. J"editor"J"template_debug"J"template_release"}
{
environmentKiOS environment, device or simulator; required for iOS and empty elsewhere.2""J""J"device"J"simulator"�
�
enabled_modulesNEnabled Godot modules; their dependencies come from the source's module graph.2["gdscript", "text_server_fb"]�
~
custom_modulesfEach custom module's config.py label mapped to its module name; the containing
source tree is watched.	2{}a
_
patchesNPatch files applied in order; any rejected or ambiguous hunk fails the recipe.2[]Y
W
patch_stripCNumber of leading path components removed from each patch filename.21�
�
build_options�Upstream configure options as string values; import_env_vars lists
comma-separated environment dependencies. Options rules_godot controls, such as
platform, arch, target, the iOS simulator switch and module selection, are
rejected; optimize and debug_symbols follow Bazel's -c, --copt and --per_file_copt.
2{}�
�

build_name�Build name the engine reports in its version, followed by where its hash
comes from, such as 4.7.2.stable.custom-git.<hash>; letters, digits and
underscores.2"custom"�
�
pythonwOptional declared Python executable for configure-only graph translation;
otherwise uses python3 on PATH (Python 3.9+).2NoneT
R
configure_timeout6Maximum configure-only subprocess duration in seconds.2600�
�
	lock_file�The lock file that pins this recipe's build graph, as a source build's lock_file
names it. With it, the repository configures nothing on this host and declares
`:pin`, which configures the recipe on an execution platform Godot accepts.2NoneS
Q
lock_key?The recipe's key in the lock file, such as linux_x86_64_editor.2""W
U
repinFThe target that repins the lock file, named by a stale recipe's error.2""�#godot_editor_archive�Acquire one checksum-pinned prebuilt editor archive.

Call from a module extension or through use_repo_rule. The repository exposes
`:editor`, the executable with the complete distribution as runfiles, for a
godot_editor_component; it registers nothing. The editor must match the operating
system and CPU of the execution platform of the slot it fills. The declared
version is checked for ruleset support; it is not read from the archive.
godot_engines.prebuilt uses this rule for catalogued releases.

Example (MODULE.bazel; replace URL and digest with a real pinned archive):
```starlark
godot_editor_archive = use_repo_rule(
    "@autoload_rules_godot//godot/engine:repositories.bzl",
    "godot_editor_archive",
)
godot_editor_archive(
    name = "godot_editor_custom",
    urls = ["https://example.com/godot-editor.zip"],
    integrity = "sha256-<base64-digest>",
    binary = "Godot.app/Contents/MacOS/Godot",
    version = "4.7.2",
)
```

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| repository | none | always | repository creation; generated entrypoints described above |

### Output groups
none

### Generated targets
| name | kind | purpose | reason | visibility | testonly | prerequisites | availability |
| --- | --- | --- | --- | --- | --- | --- | --- |
| @{repository}//:editor | executable | operation | run the acquired editor; the payload of an editor component | public | false | repository acquired | always |
| @{repository}//:binary | files | operation | consume the raw editor executable | public | false | repository acquired | always |
| @{repository}//:distribution | files | operation | consume the complete editor distribution | public | false | repository acquired | always |

### Providers
noneR�
�
godot_editor_archive�Acquire one checksum-pinned prebuilt editor archive.

Call from a module extension or through use_repo_rule. The repository exposes
`:editor`, the executable with the complete distribution as runfiles, for a
godot_editor_component; it registers nothing. The editor must match the operating
system and CPU of the execution platform of the slot it fills. The declared
version is checked for ruleset support; it is not read from the archive.
godot_engines.prebuilt uses this rule for catalogued releases.

Example (MODULE.bazel; replace URL and digest with a real pinned archive):
```starlark
godot_editor_archive = use_repo_rule(
    "@autoload_rules_godot//godot/engine:repositories.bzl",
    "godot_editor_archive",
)
godot_editor_archive(
    name = "godot_editor_custom",
    urls = ["https://example.com/godot-editor.zip"],
    integrity = "sha256-<base64-digest>",
    binary = "Godot.app/Contents/MacOS/Godot",
    version = "4.7.2",
)
```

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| repository | none | always | repository creation; generated entrypoints described above |

### Output groups
none

### Generated targets
| name | kind | purpose | reason | visibility | testonly | prerequisites | availability |
| --- | --- | --- | --- | --- | --- | --- | --- |
| @{repository}//:editor | executable | operation | run the acquired editor; the payload of an editor component | public | false | repository acquired | always |
| @{repository}//:binary | files | operation | consume the raw editor executable | public | false | repository acquired | always |
| @{repository}//:distribution | files | operation | consume the complete editor distribution | public | false | repository acquired | always |

### Providers
none.
name"A unique name for this repository. ?
urls3Ordered mirror URLs of the same ZIP or TPZ archive. y
	integrityhSubresource Integrity digest of the archive, including the hash algorithm, such as sha512-...; required. y
versionjCanonical Godot version of the archive's payloads; checked for ruleset support, not read from the archive. ?
binary1Path of the editor executable inside the archive. *L
godot_editor_archive4@autoload_rules_godot//godot/engine:repositories.bzl0
.
name"A unique name for this repository. A
?
urls3Ordered mirror URLs of the same ZIP or TPZ archive. {
y
	integrityhSubresource Integrity digest of the archive, including the hash algorithm, such as sha512-...; required. {
y
versionjCanonical Godot version of the archive's payloads; checked for ruleset support, not read from the archive. A
?
binary1Path of the editor executable inside the archive. �8godot_export_templates_archive�Acquire one checksum-pinned export-template archive.

Call from a module extension or through use_repo_rule. The repository exposes one
runtime target per desktop operating system, CPU and template variant,
such as `:linux_x86_64_release` or `:macos_debug`, each carrying GodotRuntimeInfo,
for godot_runtime_component payloads. Coverage follows the archive contents: an
archive without a debug template omits the debug target, and macos_cpus
describes its macOS layout. An archive with iOS templates also exposes `:ios_debug`
and `:ios_release`, XCFramework imports with the dependent frameworks the
archive carries; they serve device and simulator slots alike. Downloading happens
only when a payload is requested. godot_engines.prebuilt uses this rule for
catalogued releases.

Example (MODULE.bazel; replace URL and digest with a real pinned archive):
```starlark
godot_export_templates_archive = use_repo_rule(
    "@autoload_rules_godot//godot/engine:repositories.bzl",
    "godot_export_templates_archive",
)
godot_export_templates_archive(
    name = "godot_templates_custom",
    urls = ["https://example.com/export_templates.tpz"],
    integrity = "sha512-<base64-digest>",
    version = "4.7.2",
)
```

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| repository | none | always | repository creation; generated entrypoints described above |

### Output groups
none

### Generated targets
| name | kind | purpose | reason | visibility | testonly | prerequisites | availability |
| --- | --- | --- | --- | --- | --- | --- | --- |
| @{repository}//:files | files | operation | inspect acquired export templates | public | false | repository acquired | always |
| @{repository}//:macos_files | files | operation | preserve macOS template bundle resources | public | false | repository acquired | macos_present |
| @{repository}//:linux_{cpu}_{variant} | files | operation | a Linux runtime payload for one CPU and template variant | public | false | variant present in the archive | always |
| @{repository}//:macos_{variant} | files | operation | a universal macOS runtime payload | public | false | universal archive; variant present | macos_universal |
| @{repository}//:macos_{cpu}_{variant} | files | operation | a CPU-specific macOS runtime payload | public | false | CPU-specific archive; variant present | macos_split |
| @{repository}//:ios_{variant} | library | operation | the iOS engine XCFramework import with its dependent frameworks, for device and simulator runtime components | public | false | iOS templates present in the archive | ios |
| @{repository}//:templates/{file} | files | operation | consume the archive's raw template files for custom packaging | public | false | repository acquired | always |

### Providers
noneR�"
�
godot_export_templates_archive�Acquire one checksum-pinned export-template archive.

Call from a module extension or through use_repo_rule. The repository exposes one
runtime target per desktop operating system, CPU and template variant,
such as `:linux_x86_64_release` or `:macos_debug`, each carrying GodotRuntimeInfo,
for godot_runtime_component payloads. Coverage follows the archive contents: an
archive without a debug template omits the debug target, and macos_cpus
describes its macOS layout. An archive with iOS templates also exposes `:ios_debug`
and `:ios_release`, XCFramework imports with the dependent frameworks the
archive carries; they serve device and simulator slots alike. Downloading happens
only when a payload is requested. godot_engines.prebuilt uses this rule for
catalogued releases.

Example (MODULE.bazel; replace URL and digest with a real pinned archive):
```starlark
godot_export_templates_archive = use_repo_rule(
    "@autoload_rules_godot//godot/engine:repositories.bzl",
    "godot_export_templates_archive",
)
godot_export_templates_archive(
    name = "godot_templates_custom",
    urls = ["https://example.com/export_templates.tpz"],
    integrity = "sha512-<base64-digest>",
    version = "4.7.2",
)
```

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| repository | none | always | repository creation; generated entrypoints described above |

### Output groups
none

### Generated targets
| name | kind | purpose | reason | visibility | testonly | prerequisites | availability |
| --- | --- | --- | --- | --- | --- | --- | --- |
| @{repository}//:files | files | operation | inspect acquired export templates | public | false | repository acquired | always |
| @{repository}//:macos_files | files | operation | preserve macOS template bundle resources | public | false | repository acquired | macos_present |
| @{repository}//:linux_{cpu}_{variant} | files | operation | a Linux runtime payload for one CPU and template variant | public | false | variant present in the archive | always |
| @{repository}//:macos_{variant} | files | operation | a universal macOS runtime payload | public | false | universal archive; variant present | macos_universal |
| @{repository}//:macos_{cpu}_{variant} | files | operation | a CPU-specific macOS runtime payload | public | false | CPU-specific archive; variant present | macos_split |
| @{repository}//:ios_{variant} | library | operation | the iOS engine XCFramework import with its dependent frameworks, for device and simulator runtime components | public | false | iOS templates present in the archive | ios |
| @{repository}//:templates/{file} | files | operation | consume the archive's raw template files for custom packaging | public | false | repository acquired | always |

### Providers
none.
name"A unique name for this repository. ?
urls3Ordered mirror URLs of the same ZIP or TPZ archive. y
	integrityhSubresource Integrity digest of the archive, including the hash algorithm, such as sha512-...; required. y
versionjCanonical Godot version of the archive's payloads; checked for ruleset support, not read from the archive. �

macos_cpus�macOS template binary suffixes in the archive: ["universal"] or a subset of ["arm64", "x86_64"]. Empty disables macOS runtimes; archives without macos.zip omit them.2["universal"]�

linux_cpussLinux template binary suffixes in the archive, as Godot's CPU tags such as arm64 or x86_64. A missing binary fails.2&["arm32", "arm64", "x86_32", "x86_64"]*V
godot_export_templates_archive4@autoload_rules_godot//godot/engine:repositories.bzl0
.
name"A unique name for this repository. A
?
urls3Ordered mirror URLs of the same ZIP or TPZ archive. {
y
	integrityhSubresource Integrity digest of the archive, including the hash algorithm, such as sha512-...; required. {
y
versionjCanonical Godot version of the archive's payloads; checked for ruleset support, not read from the archive. �
�

macos_cpus�macOS template binary suffixes in the archive: ["universal"] or a subset of ["arm64", "x86_64"]. Empty disables macOS runtimes; archives without macos.zip omit them.2["universal"]�
�

linux_cpussLinux template binary suffixes in the archive, as Godot's CPU tags such as arm64 or x86_64. A missing binary fails.2&["arm32", "arm64", "x86_32", "x86_64"]�godot_android_shell�Build Godot's Java/Kotlin Android shell library from a source descriptor.

Call through use_repo_rule in MODULE.bazel, or from a module extension. The
repository extracts the source, applies the patches and exposes `:debug` and
`:release`, the Android shell library of each template variant built with rules_android and
rules_kotlin; their `.aar` outputs, such as `:release.aar`, are godot_android_runtime
shells. Java and Kotlin target Godot's language level per target, so no Kotlin
toolchain is registered. The shell library's Maven dependencies come from autoload_rules_godot's
contribution to the shared `maven` repository; repin after adding autoload_rules_godot.

Example (MODULE.bazel):
```starlark
godot_android_shell = use_repo_rule(
    "@autoload_rules_godot//godot/engine:repositories.bzl", "godot_android_shell",
)
godot_android_shell(name = "godot_shell", source = "@godot_sources//:source.json")
```

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| repository | none | always | repository creation; generated entrypoints described above |

### Output groups
none

### Generated targets
| name | kind | purpose | reason | visibility | testonly | prerequisites | availability |
| --- | --- | --- | --- | --- | --- | --- | --- |
| @{repository}//:{variant} | files | operation | the Android shell library of one template variant; its .aar output is a godot_android_runtime shell | public | false | Android SDK | always |

### Providers
noneR�
�
godot_android_shell�Build Godot's Java/Kotlin Android shell library from a source descriptor.

Call through use_repo_rule in MODULE.bazel, or from a module extension. The
repository extracts the source, applies the patches and exposes `:debug` and
`:release`, the Android shell library of each template variant built with rules_android and
rules_kotlin; their `.aar` outputs, such as `:release.aar`, are godot_android_runtime
shells. Java and Kotlin target Godot's language level per target, so no Kotlin
toolchain is registered. The shell library's Maven dependencies come from autoload_rules_godot's
contribution to the shared `maven` repository; repin after adding autoload_rules_godot.

Example (MODULE.bazel):
```starlark
godot_android_shell = use_repo_rule(
    "@autoload_rules_godot//godot/engine:repositories.bzl", "godot_android_shell",
)
godot_android_shell(name = "godot_shell", source = "@godot_sources//:source.json")
```

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| repository | none | always | repository creation; generated entrypoints described above |

### Output groups
none

### Generated targets
| name | kind | purpose | reason | visibility | testonly | prerequisites | availability |
| --- | --- | --- | --- | --- | --- | --- | --- |
| @{repository}//:{variant} | files | operation | the Android shell library of one template variant; its .aar output is a godot_android_runtime shell | public | false | Android SDK | always |

### Providers
none.
name"A unique name for this repository. P
sourceBThe `:source.json` descriptor of a godot_engine_source repository. M
patches<Patch files applied in order, such as a fork's Java changes.2[]W
patch_stripCNumber of leading path components removed from each patch filename.21*K
godot_android_shell4@autoload_rules_godot//godot/engine:repositories.bzl0
.
name"A unique name for this repository. R
P
sourceBThe `:source.json` descriptor of a godot_engine_source repository. O
M
patches<Patch files applied in order, such as a fork's Java changes.2[]Y
W
patch_stripCNumber of leading path components removed from each patch filename.21[Engine acquisition: prebuilt archives, immutable sources and configure-only source recipes.��
1
autoload_rules_godotgodot/extensiondefs.bzl�:godot_cc_extension�Build C/C++ once as a cc_library, link it, and package it as a godot_extension.

iOS takes the archive; other supported operating systems take a shared library
linked from it that finds its shared dependencies beside it and exports only the
entry symbol, so extensions in one process never run each other's godot-cpp. Code
linked by another rule, in any language, goes to godot_extension directly. godot_app
links the extension and its C++ dependencies when one of the packs it ships contains
it. Like godot_extension, the target is an add-on of only that extension.

Creates the named godot_extension target and the private targets `<name>.native`,
the cc_library, `lib<name>_native.so`, the shared library linked from it, and
`<name>.tool`, the extension in the tool configuration that editor actions and the
host editor load. The public target exposes
GodotExtensionInfo, DefaultInfo and, on iOS, CcInfo. It returns no Starlark value.
Compilation uses rules_cc toolchains. The feature tags of the libraries derive from
the target platform's operating system and CPU, the iOS environment and the
variant; features in kwargs keeps its meaning as rules_cc toolchain features. An
editor-specific backend is a select() over @autoload_rules_godot//godot:tool in deps.

Example:
    godot_cc_extension(
        name = "extension",
        srcs = ["extension.cpp"],
        deps = ["@godot_cpp//:godot_cpp"],
        entry_symbol = "my_extension_init",
    )

See [a complete C++ extension](../../gdextension.md).

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| files | many | always | build the descriptor fragment, the extension library and its runtime dependencies; no run behavior |

### Output groups
none

### Generated targets
none

### Providers
| name | role | availability |
| --- | --- | --- |
| GodotExtensionInfo | Configured extension library, descriptor fragment and resource paths | always |
| GodotAddonInfo | The add-on of only this extension, which resources and projects use like any add-on | always |
| CcInfo | Forwarded from the iOS static library; supports iOS static linking | when_cc |
*�)
�
godot_cc_extension$
namePublic extension target. ( 
srcsC/C++ source labels. (2
entry_symbolExported Godot entry function. (~
depsprules_cc dependencies; shared libraries among them are runtime
dependencies placed beside the extension library.[]((
hdrsPrivate extension headers.[](t
datafFiles the descriptor's [dependencies] lists beyond the libraries deps
link, as godot_extension's data.[](d
resource_pathMResource path of the descriptor; empty uses
addons/<name>/<name>.gdextension.""(D
compatibility_minimum Oldest compatible Godot version."4.7.2"(5

reloadableEnable Godot editor reloading.False(�
minimum_os_versions�Minimum operating-system versions the extension libraries
need, by Godot platform (macos, ios); a godot_app whose minimum is lower fails.{}(2

visibilityPublic extension visibility.None( 
tagsBazel target tags.[](�
platform_deps�Android or Apple platform libraries the extension's native code
uses without linking them; godot_extension's platform_deps. Libraries it
links belong to deps.[](g

infoplistsSInfo.plist fragments for the extension's native code;
godot_extension's infoplists.[](�
kwargs�Additional cc_library attributes, such as copts, defines or
linkopts; the attributes every rule has, such as features or
exec_compatible_with, also reach the shared library, and the cc_binary
attributes dynamic_deps, env, link_extra_lib, linkstatic, malloc,
reexport_deps and stamp reach only it.(�Build C/C++ once as a cc_library, link it, and package it as a godot_extension.

iOS takes the archive; other supported operating systems take a shared library
linked from it that finds its shared dependencies beside it and exports only the
entry symbol, so extensions in one process never run each other's godot-cpp. Code
linked by another rule, in any language, goes to godot_extension directly. godot_app
links the extension and its C++ dependencies when one of the packs it ships contains
it. Like godot_extension, the target is an add-on of only that extension.

Creates the named godot_extension target and the private targets `<name>.native`,
the cc_library, `lib<name>_native.so`, the shared library linked from it, and
`<name>.tool`, the extension in the tool configuration that editor actions and the
host editor load. The public target exposes
GodotExtensionInfo, DefaultInfo and, on iOS, CcInfo. It returns no Starlark value.
Compilation uses rules_cc toolchains. The feature tags of the libraries derive from
the target platform's operating system and CPU, the iOS environment and the
variant; features in kwargs keeps its meaning as rules_cc toolchain features. An
editor-specific backend is a select() over @autoload_rules_godot//godot:tool in deps.

Example:
    godot_cc_extension(
        name = "extension",
        srcs = ["extension.cpp"],
        deps = ["@godot_cpp//:godot_cpp"],
        entry_symbol = "my_extension_init",
    )

See [a complete C++ extension](../../gdextension.md).

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| files | many | always | build the descriptor fragment, the extension library and its runtime dependencies; no run behavior |

### Output groups
none

### Generated targets
none

### Providers
| name | role | availability |
| --- | --- | --- |
| GodotExtensionInfo | Configured extension library, descriptor fragment and resource paths | always |
| GodotAddonInfo | The add-on of only this extension, which resources and projects use like any add-on | always |
| CcInfo | Forwarded from the iOS static library; supports iOS static linking | when_cc |
2E
godot_cc_extension/@autoload_rules_godot//godot/extension:defs.bzl&
$
namePublic extension target. ("
 
srcsC/C++ source labels. (4
2
entry_symbolExported Godot entry function. (�
~
depsprules_cc dependencies; shared libraries among them are runtime
dependencies placed beside the extension library.[](*
(
hdrsPrivate extension headers.[](v
t
datafFiles the descriptor's [dependencies] lists beyond the libraries deps
link, as godot_extension's data.[](f
d
resource_pathMResource path of the descriptor; empty uses
addons/<name>/<name>.gdextension.""(F
D
compatibility_minimum Oldest compatible Godot version."4.7.2"(7
5

reloadableEnable Godot editor reloading.False(�
�
minimum_os_versions�Minimum operating-system versions the extension libraries
need, by Godot platform (macos, ios); a godot_app whose minimum is lower fails.{}(4
2

visibilityPublic extension visibility.None("
 
tagsBazel target tags.[](�
�
platform_deps�Android or Apple platform libraries the extension's native code
uses without linking them; godot_extension's platform_deps. Libraries it
links belong to deps.[](i
g

infoplistsSInfo.plist fragments for the extension's native code;
godot_extension's infoplists.[](�
�
kwargs�Additional cc_library attributes, such as copts, defines or
linkopts; the attributes every rule has, such as features or
exec_compatible_with, also reach the shared library, and the cc_binary
attributes dynamic_deps, env, link_extra_lib, linkstatic, malloc,
reexport_deps and stamp reach only it.(�igodot_extension�Declare a GDExtension by its library in each configuration.

The library varies with select() over platform constraints and
@autoload_rules_godot//godot:debug, :release, :editor and :tool; the extension derives its Godot
feature tags from the configuration, the link kind from the library's providers and
its runtime dependencies from the library and data. Each configuration writes a
descriptor fragment with its one library entry; packs merge the fragments of their
platform slices. The extension takes the library as another rule linked it, in any
language, and links nothing itself; godot_cc_extension is the C++ shorthand. Editor
actions and the host editor load the library of the tool configuration, where
@autoload_rules_godot//godot:tool and :editor match; a select() with a branch for each
execution platform's operating system needs no tool branch. Platform libraries that
the native code uses without linking them, and their resources, follow platform_deps
to every application shipping a pack that contains the extension. By itself the
extension is an add-on of only that extension: resources list it in deps, a project
names it in deps. See [extensions](../../gdextension.md).

Example:
```starlark
godot_extension(
    name = "sentry",
    library = select({
        ":linux_x86_64": ":libsentry_linux_x86_64",
        ":android_arm64": ":libsentry_android_arm64",
        "@platforms//os:macos": ":libsentry_macos",
    }),
    # What Sentry's descriptor lists under [dependencies] for Linux.
    data = select({
        ":linux_x86_64": ["bin/linux/crashpad_handler"],
        "//conditions:default": [],
    }),
    entry_symbol = "gdextension_init",
)
```

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| files | many | always | build the descriptor fragment, the extension library and its runtime dependencies; no run behavior |

### Output groups
none

### Generated targets
none

### Providers
| name | role | availability |
| --- | --- | --- |
| GodotExtensionInfo | Configured extension library, descriptor fragment and resource paths | always |
| GodotAddonInfo | The add-on of only this extension, which resources and projects use like any add-on | always |
| CcInfo | Forwarded from a static library or framework; supports iOS linking | when_cc |Z�W
�4
godot_extension�Declare a GDExtension by its library in each configuration.

The library varies with select() over platform constraints and
@autoload_rules_godot//godot:debug, :release, :editor and :tool; the extension derives its Godot
feature tags from the configuration, the link kind from the library's providers and
its runtime dependencies from the library and data. Each configuration writes a
descriptor fragment with its one library entry; packs merge the fragments of their
platform slices. The extension takes the library as another rule linked it, in any
language, and links nothing itself; godot_cc_extension is the C++ shorthand. Editor
actions and the host editor load the library of the tool configuration, where
@autoload_rules_godot//godot:tool and :editor match; a select() with a branch for each
execution platform's operating system needs no tool branch. Platform libraries that
the native code uses without linking them, and their resources, follow platform_deps
to every application shipping a pack that contains the extension. By itself the
extension is an add-on of only that extension: resources list it in deps, a project
names it in deps. See [extensions](../../gdextension.md).

Example:
```starlark
godot_extension(
    name = "sentry",
    library = select({
        ":linux_x86_64": ":libsentry_linux_x86_64",
        ":android_arm64": ":libsentry_android_arm64",
        "@platforms//os:macos": ":libsentry_macos",
    }),
    # What Sentry's descriptor lists under [dependencies] for Linux.
    data = select({
        ":linux_x86_64": ["bin/linux/crashpad_handler"],
        "//conditions:default": [],
    }),
    entry_symbol = "gdextension_init",
)
```

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| files | many | always | build the descriptor fragment, the extension library and its runtime dependencies; no run behavior |

### Output groups
none

### Generated targets
none

### Providers
| name | role | availability |
| --- | --- | --- |
| GodotExtensionInfo | Configured extension library, descriptor fragment and resource paths | always |
| GodotAddonInfo | The add-on of only this extension, which resources and projects use like any add-on | always |
| CcInfo | Forwarded from a static library or framework; supports iOS linking | when_cc |�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@�
platform_deps�Android or Apple platform libraries and their resources that the extension's native code uses without linking them, such as an Android plugin it fetches through Engine::get_singleton(), accepted through JavaInfo or CcInfo. Empty by default; select only libraries for the operating systems the extension supports. A dynamic framework the library loads, as a bundle_only Apple import, belongs here too; libraries the code links belong to the library's C++ deps.*?
JavaInfo3
JavaInfo'@rules_java//java/private:java_info.bzl*5
CcInfo+
CcInfo!@rules_cc//cc/private:cc_info.bzl2[]
expect_failure2None@ 
transitive_configs2None8@
deprecation2None8@
tags2None8@
testonly2None8@
features2None@
compatible_with2None8@
restricted_to2None8@
package_metadata2None8@
aspect_hints2None@P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@
exec_properties
2None@"
exec_compatible_with2None8@(
exec_group_compatible_with2None8@Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@�
library�The extension library of each configuration, varied with select() over platform
constraints and @autoload_rules_godot//godot:debug, :release, :editor and :tool: a linked
library from any rule, which the extension takes as it is and never links.
Accepted: a shared library (cc_shared_library, cc_import(shared_library),
cc_binary(linkshared) or a target with one .so, .dylib or .dll file), a static library on iOS (cc_library,
cc_import(static_library), apple_static_xcframework_import) and a dynamic
framework on iOS and macOS (apple_dynamic_xcframework_import,
apple_dynamic_framework_import, with bundle_only = True as the GDExtension guide
describes). Shared libraries that its CcInfo links, the shared libraries in a
linked library's runfiles and the other frameworks of an Apple import that links
its own are its runtime dependencies. None leaves the extension without a
library in that configuration. Targets link without Bazel's --strip:
applications strip the copy they package and provide this one as debug symbols.2None�
data�Files the descriptor's [dependencies] lists beyond what the library's providers
imply: files the library needs beside it at run time, such as a crash handler
executable. Android takes only lib*.so files; iOS takes none and fails, since its
applications deliver files through platform libraries in platform_deps.2None�
resource_path�Resource path of the .gdextension descriptor, for a vendor's layout; empty uses
addons/<name>/<name>.gdextension, as Godot add-ons place theirs. The libraries
lie in bin/<feature tags>/ beside it.2Noneb
entry_symbolNExported Godot initialization function, identical for every extension library. �
compatibility_minimumiOldest compatible canonical Godot version written into the descriptor; must be
supported by this ruleset.2Nonef

reloadablePWhether the Godot editor may reload this extension after rebuilding its library.2None�
minimum_os_versions�Minimum operating-system versions the extension libraries need, by Godot
platform: macos and ios, as dotted numeric versions. A godot_app that packages
the extension for that operating system fails when its own minimum is lower.
Empty where the libraries run on every version the engine supports.
2None�

infoplists�Info.plist fragments iOS applications merge into their Info.plist for the
extension's native code, such as the usage descriptions or SDK keys a native
backend reads. They reach applications as an add-on's infoplists do, whether the
extension is used by itself or in an add-on's deps; two fragments with different
values for a key fail, and the application's own ios_infoplists win.2None"B
godot_extension/@autoload_rules_godot//godot/extension:defs.bzl�
�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �
�

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@�
�
platform_deps�Android or Apple platform libraries and their resources that the extension's native code uses without linking them, such as an Android plugin it fetches through Engine::get_singleton(), accepted through JavaInfo or CcInfo. Empty by default; select only libraries for the operating systems the extension supports. A dynamic framework the library loads, as a bundle_only Apple import, belongs here too; libraries the code links belong to the library's C++ deps.*?
JavaInfo3
JavaInfo'@rules_java//java/private:java_info.bzl*5
CcInfo+
CcInfo!@rules_cc//cc/private:cc_info.bzl2[]

expect_failure2None@"
 
transitive_configs2None8@

deprecation2None8@

tags2None8@

testonly2None8@

features2None@

compatible_with2None8@

restricted_to2None8@ 

package_metadata2None8@

aspect_hints2None@R
P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@

exec_properties
2None@$
"
exec_compatible_with2None8@*
(
exec_group_compatible_with2None8@\
Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@�
�
library�The extension library of each configuration, varied with select() over platform
constraints and @autoload_rules_godot//godot:debug, :release, :editor and :tool: a linked
library from any rule, which the extension takes as it is and never links.
Accepted: a shared library (cc_shared_library, cc_import(shared_library),
cc_binary(linkshared) or a target with one .so, .dylib or .dll file), a static library on iOS (cc_library,
cc_import(static_library), apple_static_xcframework_import) and a dynamic
framework on iOS and macOS (apple_dynamic_xcframework_import,
apple_dynamic_framework_import, with bundle_only = True as the GDExtension guide
describes). Shared libraries that its CcInfo links, the shared libraries in a
linked library's runfiles and the other frameworks of an Apple import that links
its own are its runtime dependencies. None leaves the extension without a
library in that configuration. Targets link without Bazel's --strip:
applications strip the copy they package and provide this one as debug symbols.2None�
�
data�Files the descriptor's [dependencies] lists beyond what the library's providers
imply: files the library needs beside it at run time, such as a crash handler
executable. Android takes only lib*.so files; iOS takes none and fails, since its
applications deliver files through platform libraries in platform_deps.2None�
�
resource_path�Resource path of the .gdextension descriptor, for a vendor's layout; empty uses
addons/<name>/<name>.gdextension, as Godot add-ons place theirs. The libraries
lie in bin/<feature tags>/ beside it.2Noned
b
entry_symbolNExported Godot initialization function, identical for every extension library. �
�
compatibility_minimumiOldest compatible canonical Godot version written into the descriptor; must be
supported by this ruleset.2Noneh
f

reloadablePWhether the Godot editor may reload this extension after rebuilding its library.2None�
�
minimum_os_versions�Minimum operating-system versions the extension libraries need, by Godot
platform: macos and ios, as dotted numeric versions. A godot_app that packages
the extension for that operating system fails when its own minimum is lower.
Empty where the libraries run on every version the engine supports.
2None�
�

infoplists�Info.plist fragments iOS applications merge into their Info.plist for the
extension's native code, such as the usage descriptions or SDK keys a native
backend reads. They reach applications as an add-on's infoplists do, whether the
extension is used by itself or in an add-on's deps; two fragments with different
values for a key fail, and the application's own ios_infoplists win.2NoneAExtensions, and the extension libraries rules_cc builds for them.�4
9
autoload_rules_godotgodot/extensionrepositories.bzl�3godot_cpp_bindings�Fetch upstream godot-cpp and generate rules_cc build targets without host
SCons/CMake/Python at repository evaluation.

Call through use_repo_rule in MODULE.bazel. Generates :godot_cpp, a C++ library
with declared generated bindings. Generation and compilation run as Bazel
actions, using the pinned build Python; only patch application needs the host
patch tool. Floating-point precision must match the engine build.

Example (MODULE.bazel):
```starlark
godot_cpp_bindings = use_repo_rule(
    "@autoload_rules_godot//godot/extension:repositories.bzl", "godot_cpp_bindings",
)
godot_cpp_bindings(name = "godot_cpp", enabled_classes = ["Node"])
```

Use `deps = ["@godot_cpp//:godot_cpp"]` in godot_cc_extension to compile and
link against the repository's generated bindings and upstream C++ library.
The repository name determines the dependency label; with name = "godot_cpp", the
public library target is @godot_cpp//:godot_cpp. Its CcInfo propagates headers,
include paths and link inputs through the C++ toolchain.

See [godot-cpp integration](../../gdextension.md).

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| repository | none | always | repository creation; generated entrypoints described above |

### Output groups
none

### Generated targets
| name | kind | purpose | reason | visibility | testonly | prerequisites | availability |
| --- | --- | --- | --- | --- | --- | --- | --- |
| @{repository}//:godot_cpp | library | operation | link the generated C++ bindings through CcInfo | public | false | repository acquired | always |
| @{repository}//:{api_path} | files | operation | inspect the selected upstream extension API dataset | public | false | repository acquired | always |
| @{repository}//:LICENSE.md | files | operation | distribute the upstream binding license | public | false | repository acquired | always |

### Providers
noneR�$
�
godot_cpp_bindings�Fetch upstream godot-cpp and generate rules_cc build targets without host
SCons/CMake/Python at repository evaluation.

Call through use_repo_rule in MODULE.bazel. Generates :godot_cpp, a C++ library
with declared generated bindings. Generation and compilation run as Bazel
actions, using the pinned build Python; only patch application needs the host
patch tool. Floating-point precision must match the engine build.

Example (MODULE.bazel):
```starlark
godot_cpp_bindings = use_repo_rule(
    "@autoload_rules_godot//godot/extension:repositories.bzl", "godot_cpp_bindings",
)
godot_cpp_bindings(name = "godot_cpp", enabled_classes = ["Node"])
```

Use `deps = ["@godot_cpp//:godot_cpp"]` in godot_cc_extension to compile and
link against the repository's generated bindings and upstream C++ library.
The repository name determines the dependency label; with name = "godot_cpp", the
public library target is @godot_cpp//:godot_cpp. Its CcInfo propagates headers,
include paths and link inputs through the C++ toolchain.

See [godot-cpp integration](../../gdextension.md).

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| repository | none | always | repository creation; generated entrypoints described above |

### Output groups
none

### Generated targets
| name | kind | purpose | reason | visibility | testonly | prerequisites | availability |
| --- | --- | --- | --- | --- | --- | --- | --- |
| @{repository}//:godot_cpp | library | operation | link the generated C++ bindings through CcInfo | public | false | repository acquired | always |
| @{repository}//:{api_path} | files | operation | inspect the selected upstream extension API dataset | public | false | repository acquired | always |
| @{repository}//:LICENSE.md | files | operation | distribute the upstream binding license | public | false | repository acquired | always |

### Providers
none.
name"A unique name for this repository. �
urlsDOrdered download URLs for the same checksum-pinned upstream archive.2e["https://codeload.github.com/godotengine/godot-cpp/tar.gz/507ed9d840c01a3c5b2a39af8bb4000bfac30bf5"]�
sha256USHA-256 digest of the archive; update together with urls when using a custom
version.2B"30da4ac295997061a6af81ae531510efd4e6a86e506eb4466edc0898ef3fe048"�
strip_prefix\Directory prefix removed from paths; for archives this must match their
top-level directory.24"godot-cpp-507ed9d840c01a3c5b2a39af8bb4000bfac30bf5"e
patchesTPatch files applied in order; any rejected or ambiguous hunk fails repository
setup.2[]W
patch_stripCNumber of leading path components removed from each patch filename.21�
api_pathPPath within godot-cpp to the extension API JSON selected for binding
generation.2$"gdextension/extension_api-4-7.json"l
enabled_classesSUpstream build-profile whitelist; required core classes and ancestors are
retained.2[]K
bits/Pointer width for generated bindings, 32 or 64.2"64"J"32"J"64"o
	precisionBFloating-point precision, single or double; must match the engine.2"single"J"single"J"double"d
debug_featuresJMatch upstream template_debug behavior; disable for release-only bindings.2True*M
godot_cpp_bindings7@autoload_rules_godot//godot/extension:repositories.bzl0
.
name"A unique name for this repository. �
�
urlsDOrdered download URLs for the same checksum-pinned upstream archive.2e["https://codeload.github.com/godotengine/godot-cpp/tar.gz/507ed9d840c01a3c5b2a39af8bb4000bfac30bf5"]�
�
sha256USHA-256 digest of the archive; update together with urls when using a custom
version.2B"30da4ac295997061a6af81ae531510efd4e6a86e506eb4466edc0898ef3fe048"�
�
strip_prefix\Directory prefix removed from paths; for archives this must match their
top-level directory.24"godot-cpp-507ed9d840c01a3c5b2a39af8bb4000bfac30bf5"g
e
patchesTPatch files applied in order; any rejected or ambiguous hunk fails repository
setup.2[]Y
W
patch_stripCNumber of leading path components removed from each patch filename.21�
�
api_pathPPath within godot-cpp to the extension API JSON selected for binding
generation.2$"gdextension/extension_api-4-7.json"n
l
enabled_classesSUpstream build-profile whitelist; required core classes and ancestors are
retained.2[]M
K
bits/Pointer width for generated bindings, 32 or 64.2"64"J"32"J"64"q
o
	precisionBFloating-point precision, single or double; must match the engine.2"single"J"single"J"double"f
d
debug_featuresJMatch upstream template_debug behavior; disable for release-only bindings.2TrueCOptional, checksum-pinned godot-cpp repository built with rules_cc.��
-
autoload_rules_godotgodotextensions.bzl�godot_engines�&Declare Godot engines and generate their registration hubs.

The prebuilt tag acquires one version's editors and export templates, from the
built-in catalogue or from explicit pins, and generates a hub whose `toolchains`
package declares one public component per slot. The source tag acquires an immutable
source archive; the source_build tag builds source recipes from it for the slots it selects and generates a hub
of the same layout. Register hubs from the root module; registration order decides
between candidates for the same slot. Hubs use only public primitives: the archive,
source and recipe repository rules and the component macros. Downloads and
configuration happen only for payloads a build requests.

Example (MODULE.bazel):
```starlark
godot_engines = use_extension("@autoload_rules_godot//godot:extensions.bzl", "godot_engines")
godot_engines.prebuilt(name = "godot_prebuilt", version = "4.7.2")
godot_engines.source(
    name = "godot_sources",
    sha256 = "e954996374cbd1cb5d72e0e3781cc537408e6ce73b010b12c6c2f308a820690a",
    strip_prefix = "godot-4.7.2-stable",
    urls = ["https://github.com/godotengine/godot/archive/refs/tags/4.7.2-stable.tar.gz"],
    version = "4.7.2",
)
godot_engines.source_build(
    name = "godot_source_build",
    platforms = ["ios"],
    source = "@godot_sources//:source.json",
)
use_repo(godot_engines, "godot_source_build", "godot_prebuilt", "godot_sources")
register_toolchains(
    "@godot_source_build//toolchains:all",  # wins for the iOS slots it covers
    "@godot_prebuilt//toolchains:all",
)
```

A root request owns its name; identical dependency requests share repositories and
conflicting ones fail. See [engines](../../engine.md).

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| repository | none | always | repository creation; generated entrypoints described above |

### Output groups
none

### Generated targets
| name | kind | purpose | reason | visibility | testonly | prerequisites | availability |
| --- | --- | --- | --- | --- | --- | --- | --- |
| @{repository}//toolchains:editor_{platform}_{cpu} | files | operation | the editor component of one editor slot; register the package with :all | public | false | editor archive for the editor platform | always |
| @{repository}//toolchains:runtime_linux_{cpu}_{variant} | files | operation | the Linux runtime component of one runtime slot | public | false | template archive contains the slot | desktop |
| @{repository}//toolchains:runtime_macos_{cpu}_{variant} | files | operation | the macOS runtime component of one runtime slot | public | false | template archive contains the slot | desktop |
| @{repository}//toolchains:runtime_ios_{cpu}_{environment}_{variant} | files | operation | the iOS runtime component of one device or simulator slot | public | false | template archive contains the slot | ios |
| @{repository}//toolchains:runtime_android_{cpu}_{variant} | files | operation | the Android runtime component of one slot | public | false | Android shell AAR pinned | android_shell |
| @{repository}//android:{variant} | files | operation | the Android runtime of one template variant the components use | public | false | Android shell library pinned or a source build with Android rows | android_shell |
| @{repository}//android:plugin_api | files | operation | the shell library's classes for Android plugins to compile against, never packaged; applications package the runtime of their variant | public | false | Android shell library pinned or a source build with Android rows | android_shell |
| @{repository}//:source.json | files | operation | the descriptor of a source tag, for source_build tags and godot_engine_build recipes | public | false | source tag | source |
| @{repository}//:{archive} | files | operation | the archive of a source tag | public | false | source tag | source |
| @{repository}//toolchains:editor_{platform}_{cpu}.toolchain | metadata | analysis_boundary | register one editor slot alone, ahead of or instead of the whole set | public | false | none | always |
| @{repository}//toolchains:runtime_linux_{cpu}_{variant}.toolchain | metadata | analysis_boundary | register one runtime slot alone, ahead of or instead of the whole set | public | false | none | desktop |
| @{repository}//toolchains:runtime_macos_{cpu}_{variant}.toolchain | metadata | analysis_boundary | register one runtime slot alone, ahead of or instead of the whole set | public | false | none | desktop |
| @{repository}//toolchains:runtime_ios_{cpu}_{environment}_{variant}.toolchain | metadata | analysis_boundary | register one runtime slot alone, ahead of or instead of the whole set | public | false | none | ios |
| @{repository}//toolchains:runtime_android_{cpu}_{variant}.toolchain | metadata | analysis_boundary | register one runtime slot alone, ahead of or instead of the whole set | public | false | none | android_shell |

### Providers
noneJ�
�J
godot_engines�&Declare Godot engines and generate their registration hubs.

The prebuilt tag acquires one version's editors and export templates, from the
built-in catalogue or from explicit pins, and generates a hub whose `toolchains`
package declares one public component per slot. The source tag acquires an immutable
source archive; the source_build tag builds source recipes from it for the slots it selects and generates a hub
of the same layout. Register hubs from the root module; registration order decides
between candidates for the same slot. Hubs use only public primitives: the archive,
source and recipe repository rules and the component macros. Downloads and
configuration happen only for payloads a build requests.

Example (MODULE.bazel):
```starlark
godot_engines = use_extension("@autoload_rules_godot//godot:extensions.bzl", "godot_engines")
godot_engines.prebuilt(name = "godot_prebuilt", version = "4.7.2")
godot_engines.source(
    name = "godot_sources",
    sha256 = "e954996374cbd1cb5d72e0e3781cc537408e6ce73b010b12c6c2f308a820690a",
    strip_prefix = "godot-4.7.2-stable",
    urls = ["https://github.com/godotengine/godot/archive/refs/tags/4.7.2-stable.tar.gz"],
    version = "4.7.2",
)
godot_engines.source_build(
    name = "godot_source_build",
    platforms = ["ios"],
    source = "@godot_sources//:source.json",
)
use_repo(godot_engines, "godot_source_build", "godot_prebuilt", "godot_sources")
register_toolchains(
    "@godot_source_build//toolchains:all",  # wins for the iOS slots it covers
    "@godot_prebuilt//toolchains:all",
)
```

A root request owns its name; identical dependency requests share repositories and
conflicting ones fail. See [engines](../../engine.md).

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| repository | none | always | repository creation; generated entrypoints described above |

### Output groups
none

### Generated targets
| name | kind | purpose | reason | visibility | testonly | prerequisites | availability |
| --- | --- | --- | --- | --- | --- | --- | --- |
| @{repository}//toolchains:editor_{platform}_{cpu} | files | operation | the editor component of one editor slot; register the package with :all | public | false | editor archive for the editor platform | always |
| @{repository}//toolchains:runtime_linux_{cpu}_{variant} | files | operation | the Linux runtime component of one runtime slot | public | false | template archive contains the slot | desktop |
| @{repository}//toolchains:runtime_macos_{cpu}_{variant} | files | operation | the macOS runtime component of one runtime slot | public | false | template archive contains the slot | desktop |
| @{repository}//toolchains:runtime_ios_{cpu}_{environment}_{variant} | files | operation | the iOS runtime component of one device or simulator slot | public | false | template archive contains the slot | ios |
| @{repository}//toolchains:runtime_android_{cpu}_{variant} | files | operation | the Android runtime component of one slot | public | false | Android shell AAR pinned | android_shell |
| @{repository}//android:{variant} | files | operation | the Android runtime of one template variant the components use | public | false | Android shell library pinned or a source build with Android rows | android_shell |
| @{repository}//android:plugin_api | files | operation | the shell library's classes for Android plugins to compile against, never packaged; applications package the runtime of their variant | public | false | Android shell library pinned or a source build with Android rows | android_shell |
| @{repository}//:source.json | files | operation | the descriptor of a source tag, for source_build tags and godot_engine_build recipes | public | false | source tag | source |
| @{repository}//:{archive} | files | operation | the archive of a source tag | public | false | source tag | source |
| @{repository}//toolchains:editor_{platform}_{cpu}.toolchain | metadata | analysis_boundary | register one editor slot alone, ahead of or instead of the whole set | public | false | none | always |
| @{repository}//toolchains:runtime_linux_{cpu}_{variant}.toolchain | metadata | analysis_boundary | register one runtime slot alone, ahead of or instead of the whole set | public | false | none | desktop |
| @{repository}//toolchains:runtime_macos_{cpu}_{variant}.toolchain | metadata | analysis_boundary | register one runtime slot alone, ahead of or instead of the whole set | public | false | none | desktop |
| @{repository}//toolchains:runtime_ios_{cpu}_{environment}_{variant}.toolchain | metadata | analysis_boundary | register one runtime slot alone, ahead of or instead of the whole set | public | false | none | ios |
| @{repository}//toolchains:runtime_android_{cpu}_{variant}.toolchain | metadata | analysis_boundary | register one runtime slot alone, ahead of or instead of the whole set | public | false | none | android_shell |

### Providers
none�
prebuilt�Acquire one version's prebuilt editors and export templates and generate a hub.
Catalogued versions need only version; explicit pins replace catalogue entries.S
nameGHub repository name; editor and template repositories use it as prefix. K
version<Exact canonical Godot version, such as 4.7.2 or 4.8.0-beta1. �
editor_urls�Editor archive URLs by editor platform, such as linux_x86_64, linux_arm64, macos (universal), macos_arm64 or macos_x86_64; replaces the catalogue's editors.2{}Z
editor_integrity@Subresource Integrity digest per editor platform in editor_urls.
2{}}
editor_binariesdEditor executable path inside each archive; defaults to the official layout of a catalogued version.
2{}Y
templates_urlsAExport-template archive URLs; replaces the catalogue's templates.2[]]
templates_integrity@Subresource Integrity digest of the templates in templates_urls.2""�
templates_macos_cpuslmacOS layout of the templates in templates_urls: ["universal"] (default) or a subset of ["arm64", "x86_64"].2[]�
templates_linux_cpus�Linux template CPUs of the templates in templates_urls, as Godot's CPU tags; empty means those of Godot's official templates: arm32, arm64, x86_32 and x86_64.2[]�
ios_simulator_cpus�CPUs with usable code in the templates' iOS simulator XCFramework slice; replaces the catalogue's value. Empty for an uncatalogued version means no simulator runtimes.2[]�
android_shell_urlsqAndroid shell AAR URLs, a template_release build with every ABI's engine library; replaces the catalogue's shell.2[]_
android_shell_integrity>Subresource Integrity digest of the AAR in android_shell_urls.2""�
android_debug_shell_urlsqAndroid shell AAR URLs of a template_debug build with every ABI's engine library; official releases publish none.2[]k
android_debug_shell_integrityDSubresource Integrity digest of the AAR in android_debug_shell_urls.2""�
engine�Name of the engine the hub's components belong to, such as `petri`; builds select it
with `--@autoload_rules_godot//godot:engine=petri`, and only then do these components fill
slots. Empty, the default, joins the default engine.2""�
sourceBAcquire one immutable source archive, as godot_engine_source does.G
name;Repository name; source_build tags name its `:source.json`. 4
urls(Ordered mirror URLs of the same archive. ,
sha256SHA-256 digest of the archive. @
strip_prefix*Top-level directory removed on extraction.2""T
versionECanonical Godot version of the sources, as their version.py names it. �
source_build�Build one source build and generate its hub, as godot_engine_source_build does:
one source recipe and one component per valid slot the filters select.F
name:Hub repository name and prefix of the recipe repositories. ]
sourceOThe `:source.json` of a godot_engines.source or godot_engine_source repository. ?
	platforms.Nonempty list of linux, macos, android or ios. >
cpus0Optional arm64/x86_64 filter; empty selects all.2[]a
build_targetsJOptional editor/template_debug/template_release filter; empty selects all.2[]\
ios_environmentsBOptional device/simulator filter for iOS rows; empty selects both.2[]}
enabled_modulesHEnabled Godot modules; dependencies come from the source's module graph.2["gdscript", "text_server_fb"]W
custom_modules?Each custom module's config.py label mapped to its module name.	2{}\
patchesKPatch files applied in order to every recipe and the Android shell library.2[]I
patch_strip5Leading path components removed from patch filenames.21M
build_options6Upstream configure options, as for godot_engine_build.
2{}I

build_name/Build name the engines report in their version.2"custom"L
python:Optional declared Python for configure-only graph capture.2NoneN
configure_timeout2Maximum configure duration per recipe, in seconds.2600�
engine�Name of the engine the hub's components belong to, such as `petri`; builds select it
with `--@autoload_rules_godot//godot:engine=petri`, and only then do these components fill
slots. Empty, the default, joins the default engine.2""�
	lock_file�Optional lock file that pins every recipe's build graph, such as
`//engines:godot_custom.lock.json`. With it, no recipe is configured on this host;
`bazel run @<name>//:pin` writes it, configuring each recipe on an execution platform
Godot accepts, such as a remote Linux executor for Linux recipes.2None"-+@autoload_rules_godot//godot:extensions.bzl�!
�
prebuilt�Acquire one version's prebuilt editors and export templates and generate a hub.
Catalogued versions need only version; explicit pins replace catalogue entries.S
nameGHub repository name; editor and template repositories use it as prefix. K
version<Exact canonical Godot version, such as 4.7.2 or 4.8.0-beta1. �
editor_urls�Editor archive URLs by editor platform, such as linux_x86_64, linux_arm64, macos (universal), macos_arm64 or macos_x86_64; replaces the catalogue's editors.2{}Z
editor_integrity@Subresource Integrity digest per editor platform in editor_urls.
2{}}
editor_binariesdEditor executable path inside each archive; defaults to the official layout of a catalogued version.
2{}Y
templates_urlsAExport-template archive URLs; replaces the catalogue's templates.2[]]
templates_integrity@Subresource Integrity digest of the templates in templates_urls.2""�
templates_macos_cpuslmacOS layout of the templates in templates_urls: ["universal"] (default) or a subset of ["arm64", "x86_64"].2[]�
templates_linux_cpus�Linux template CPUs of the templates in templates_urls, as Godot's CPU tags; empty means those of Godot's official templates: arm32, arm64, x86_32 and x86_64.2[]�
ios_simulator_cpus�CPUs with usable code in the templates' iOS simulator XCFramework slice; replaces the catalogue's value. Empty for an uncatalogued version means no simulator runtimes.2[]�
android_shell_urlsqAndroid shell AAR URLs, a template_release build with every ABI's engine library; replaces the catalogue's shell.2[]_
android_shell_integrity>Subresource Integrity digest of the AAR in android_shell_urls.2""�
android_debug_shell_urlsqAndroid shell AAR URLs of a template_debug build with every ABI's engine library; official releases publish none.2[]k
android_debug_shell_integrityDSubresource Integrity digest of the AAR in android_debug_shell_urls.2""�
engine�Name of the engine the hub's components belong to, such as `petri`; builds select it
with `--@autoload_rules_godot//godot:engine=petri`, and only then do these components fill
slots. Empty, the default, joins the default engine.2""U
S
nameGHub repository name; editor and template repositories use it as prefix. M
K
version<Exact canonical Godot version, such as 4.7.2 or 4.8.0-beta1. �
�
editor_urls�Editor archive URLs by editor platform, such as linux_x86_64, linux_arm64, macos (universal), macos_arm64 or macos_x86_64; replaces the catalogue's editors.2{}\
Z
editor_integrity@Subresource Integrity digest per editor platform in editor_urls.
2{}
}
editor_binariesdEditor executable path inside each archive; defaults to the official layout of a catalogued version.
2{}[
Y
templates_urlsAExport-template archive URLs; replaces the catalogue's templates.2[]_
]
templates_integrity@Subresource Integrity digest of the templates in templates_urls.2""�
�
templates_macos_cpuslmacOS layout of the templates in templates_urls: ["universal"] (default) or a subset of ["arm64", "x86_64"].2[]�
�
templates_linux_cpus�Linux template CPUs of the templates in templates_urls, as Godot's CPU tags; empty means those of Godot's official templates: arm32, arm64, x86_32 and x86_64.2[]�
�
ios_simulator_cpus�CPUs with usable code in the templates' iOS simulator XCFramework slice; replaces the catalogue's value. Empty for an uncatalogued version means no simulator runtimes.2[]�
�
android_shell_urlsqAndroid shell AAR URLs, a template_release build with every ABI's engine library; replaces the catalogue's shell.2[]a
_
android_shell_integrity>Subresource Integrity digest of the AAR in android_shell_urls.2""�
�
android_debug_shell_urlsqAndroid shell AAR URLs of a template_debug build with every ABI's engine library; official releases publish none.2[]m
k
android_debug_shell_integrityDSubresource Integrity digest of the AAR in android_debug_shell_urls.2""�
�
engine�Name of the engine the hub's components belong to, such as `petri`; builds select it
with `--@autoload_rules_godot//godot:engine=petri`, and only then do these components fill
slots. Empty, the default, joins the default engine.2""�
�
sourceBAcquire one immutable source archive, as godot_engine_source does.G
name;Repository name; source_build tags name its `:source.json`. 4
urls(Ordered mirror URLs of the same archive. ,
sha256SHA-256 digest of the archive. @
strip_prefix*Top-level directory removed on extraction.2""T
versionECanonical Godot version of the sources, as their version.py names it. I
G
name;Repository name; source_build tags name its `:source.json`. 6
4
urls(Ordered mirror URLs of the same archive. .
,
sha256SHA-256 digest of the archive. B
@
strip_prefix*Top-level directory removed on extraction.2""V
T
versionECanonical Godot version of the sources, as their version.py names it. �
�
source_build�Build one source build and generate its hub, as godot_engine_source_build does:
one source recipe and one component per valid slot the filters select.F
name:Hub repository name and prefix of the recipe repositories. ]
sourceOThe `:source.json` of a godot_engines.source or godot_engine_source repository. ?
	platforms.Nonempty list of linux, macos, android or ios. >
cpus0Optional arm64/x86_64 filter; empty selects all.2[]a
build_targetsJOptional editor/template_debug/template_release filter; empty selects all.2[]\
ios_environmentsBOptional device/simulator filter for iOS rows; empty selects both.2[]}
enabled_modulesHEnabled Godot modules; dependencies come from the source's module graph.2["gdscript", "text_server_fb"]W
custom_modules?Each custom module's config.py label mapped to its module name.	2{}\
patchesKPatch files applied in order to every recipe and the Android shell library.2[]I
patch_strip5Leading path components removed from patch filenames.21M
build_options6Upstream configure options, as for godot_engine_build.
2{}I

build_name/Build name the engines report in their version.2"custom"L
python:Optional declared Python for configure-only graph capture.2NoneN
configure_timeout2Maximum configure duration per recipe, in seconds.2600�
engine�Name of the engine the hub's components belong to, such as `petri`; builds select it
with `--@autoload_rules_godot//godot:engine=petri`, and only then do these components fill
slots. Empty, the default, joins the default engine.2""�
	lock_file�Optional lock file that pins every recipe's build graph, such as
`//engines:godot_custom.lock.json`. With it, no recipe is configured on this host;
`bazel run @<name>//:pin` writes it, configuring each recipe on an execution platform
Godot accepts, such as a remote Linux executor for Linux recipes.2NoneH
F
name:Hub repository name and prefix of the recipe repositories. _
]
sourceOThe `:source.json` of a godot_engines.source or godot_engine_source repository. A
?
	platforms.Nonempty list of linux, macos, android or ios. @
>
cpus0Optional arm64/x86_64 filter; empty selects all.2[]c
a
build_targetsJOptional editor/template_debug/template_release filter; empty selects all.2[]^
\
ios_environmentsBOptional device/simulator filter for iOS rows; empty selects both.2[]
}
enabled_modulesHEnabled Godot modules; dependencies come from the source's module graph.2["gdscript", "text_server_fb"]Y
W
custom_modules?Each custom module's config.py label mapped to its module name.	2{}^
\
patchesKPatch files applied in order to every recipe and the Android shell library.2[]K
I
patch_strip5Leading path components removed from patch filenames.21O
M
build_options6Upstream configure options, as for godot_engine_build.
2{}K
I

build_name/Build name the engines report in their version.2"custom"N
L
python:Optional declared Python for configure-only graph capture.2NoneP
N
configure_timeout2Maximum configure duration per recipe, in seconds.2600�
�
engine�Name of the engine the hub's components belong to, such as `petri`; builds select it
with `--@autoload_rules_godot//godot:engine=petri`, and only then do these components fill
slots. Empty, the default, joins the default engine.2""�
�
	lock_file�Optional lock file that pins every recipe's build graph, such as
`//engines:godot_custom.lock.json`. With it, no recipe is configured on this host;
`bazel run @<name>//:pin` writes it, configuring each recipe on an execution platform
Godot accepts, such as a remote Linux executor for Linux recipes.2None�>godot_android_toolchains�Register Android SDK and NDK toolchains for each execution platform. Experimental: the
extension, its tag and its generated repository may change without notice.

rules_android and rules_android_ndk resolve their tools from this host's SDK and NDK for
every execution platform, so a remote Linux executor, such as BuildBuddy's, would run
this host's `aapt2` and clang. This extension registers this host's NDK
(`ANDROID_NDK_HOME`) for this host's operating system only, and SDK, Android and NDK
toolchains for linux/x86_64 execution platforms: on hosts other than Linux, of the
checksum-pinned Linux build tools 35.0.0, SDK platforms 35 and 36 and NDK r29, which
Bazel downloads only when toolchain resolution selects them; on a Linux host, of this
host's SDK and NDK. Actions on this host keep rules_android's toolchains of the host SDK
(`ANDROID_HOME`). The Linux SDK follows `--@androidsdk//:api_level`; on hosts other than
Linux, another API level fails analysis for Linux executors.

The generated hub `android_toolchains` replaces `@androidndk//:all` of rules_android_ndk.
Register it with `--extra_toolchains`, which gives it priority over the toolchains
rules_android registers in its own module.

Example (MODULE.bazel):
```starlark
godot_android_toolchains = use_extension(
    "@autoload_rules_godot//godot:extensions.bzl",
    "godot_android_toolchains",
)
godot_android_toolchains.configure(ndk_api_level = 24)
use_repo(godot_android_toolchains, "android_toolchains")
```

Example (.bazelrc):
```
build:android --extra_toolchains=@android_toolchains//:all
```

The root module's tag applies; without one, the dependencies' tags must agree. See
[remote execution of Android builds](../../platforms.md#remote-execution-of-android-builds).

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| repository | none | always | repository creation; generated entrypoints described below |

### Output groups
none

### Generated targets
| name | kind | purpose | reason | visibility | testonly | prerequisites | availability |
| --- | --- | --- | --- | --- | --- | --- | --- |
| @android_toolchains//:ndk_{target_system} | metadata | analysis_boundary | the C++ toolchain of this host's NDK for one Android CPU, on this host's operating system; register the package with :all | public | false | ANDROID_NDK_HOME | always |
| @android_toolchains//:ndk_linux_x86_64_{target_system} | metadata | analysis_boundary | the C++ toolchain of the Linux NDK for one Android CPU, on linux/x86_64 execution platforms; this host's NDK on a Linux host | public | false | none | always |
| @android_toolchains//:sdk_linux_x86_64 | metadata | analysis_boundary | the Linux SDK of the selected API level, on linux/x86_64 execution platforms; this host's SDK on a Linux host | public | false | none | always |
| @android_toolchains//:android_linux_x86_64 | metadata | analysis_boundary | rules_android's Android toolchain with the Linux aapt2, on linux/x86_64 execution platforms; rules_android's default on a Linux host | public | false | none | always |
| @android_toolchains//:aapt | executable | operation | aapt of the configured platform's SDK, the Linux SDK's for linux/x86_64 and this host's otherwise, for the data of a test that inspects an application on its execution platform | public | false | ANDROID_HOME | always |
| @android_toolchains//:aapt2 | executable | operation | aapt2 of the configured platform's SDK, as :aapt | public | false | ANDROID_HOME | always |

### Providers
noneJ�"
�
godot_android_toolchains�Register Android SDK and NDK toolchains for each execution platform. Experimental: the
extension, its tag and its generated repository may change without notice.

rules_android and rules_android_ndk resolve their tools from this host's SDK and NDK for
every execution platform, so a remote Linux executor, such as BuildBuddy's, would run
this host's `aapt2` and clang. This extension registers this host's NDK
(`ANDROID_NDK_HOME`) for this host's operating system only, and SDK, Android and NDK
toolchains for linux/x86_64 execution platforms: on hosts other than Linux, of the
checksum-pinned Linux build tools 35.0.0, SDK platforms 35 and 36 and NDK r29, which
Bazel downloads only when toolchain resolution selects them; on a Linux host, of this
host's SDK and NDK. Actions on this host keep rules_android's toolchains of the host SDK
(`ANDROID_HOME`). The Linux SDK follows `--@androidsdk//:api_level`; on hosts other than
Linux, another API level fails analysis for Linux executors.

The generated hub `android_toolchains` replaces `@androidndk//:all` of rules_android_ndk.
Register it with `--extra_toolchains`, which gives it priority over the toolchains
rules_android registers in its own module.

Example (MODULE.bazel):
```starlark
godot_android_toolchains = use_extension(
    "@autoload_rules_godot//godot:extensions.bzl",
    "godot_android_toolchains",
)
godot_android_toolchains.configure(ndk_api_level = 24)
use_repo(godot_android_toolchains, "android_toolchains")
```

Example (.bazelrc):
```
build:android --extra_toolchains=@android_toolchains//:all
```

The root module's tag applies; without one, the dependencies' tags must agree. See
[remote execution of Android builds](../../platforms.md#remote-execution-of-android-builds).

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| repository | none | always | repository creation; generated entrypoints described below |

### Output groups
none

### Generated targets
| name | kind | purpose | reason | visibility | testonly | prerequisites | availability |
| --- | --- | --- | --- | --- | --- | --- | --- |
| @android_toolchains//:ndk_{target_system} | metadata | analysis_boundary | the C++ toolchain of this host's NDK for one Android CPU, on this host's operating system; register the package with :all | public | false | ANDROID_NDK_HOME | always |
| @android_toolchains//:ndk_linux_x86_64_{target_system} | metadata | analysis_boundary | the C++ toolchain of the Linux NDK for one Android CPU, on linux/x86_64 execution platforms; this host's NDK on a Linux host | public | false | none | always |
| @android_toolchains//:sdk_linux_x86_64 | metadata | analysis_boundary | the Linux SDK of the selected API level, on linux/x86_64 execution platforms; this host's SDK on a Linux host | public | false | none | always |
| @android_toolchains//:android_linux_x86_64 | metadata | analysis_boundary | rules_android's Android toolchain with the Linux aapt2, on linux/x86_64 execution platforms; rules_android's default on a Linux host | public | false | none | always |
| @android_toolchains//:aapt | executable | operation | aapt of the configured platform's SDK, the Linux SDK's for linux/x86_64 and this host's otherwise, for the data of a test that inspects an application on its execution platform | public | false | ANDROID_HOME | always |
| @android_toolchains//:aapt2 | executable | operation | aapt2 of the configured platform's SDK, as :aapt | public | false | ANDROID_HOME | always |

### Providers
none�
	configure,Configure the NDK of the Android toolchains.�
ndk_api_level�Native API level the NDK compiles C++ for, the minimum Android version of
native code, such as 24. It applies to this host's NDK and the Linux NDK
alike, so local and remote compiles agree. "-+@autoload_rules_godot//godot:extensions.bzl�
�
	configure,Configure the NDK of the Android toolchains.�
ndk_api_level�Native API level the NDK compiles C++ for, the minimum Android version of
native code, such as 24. It applies to this host's NDK and the Linux NDK
alike, so local and remote compiles agree. �
�
ndk_api_level�Native API level the NDK compiles C++ for, the minimum Android version of
native code, such as 24. It applies to this host's NDK and the Linux NDK
alike, so local and remote compiles agree. �Bzlmod setup of Godot engines (prebuilt releases, sources and source builds) and of
experimental Android toolchains for each execution platform.�$
.
autoload_rules_godotgodot/gdunitdefs.bzl�$godot_gdunit_test�Run GdUnit4 test suites as a Bazel test.

A godot_test whose main script is rules_godot's GdUnit test adapter. A suite is a
script of the suites targets, generated ones included, that extends GdUnit's
`GdUnitTestSuite`; helper scripts and sidecars beside the suites are none. The
suites declare what they use in their deps: the code under test and GdUnit
itself, pinned in your module like any other resources. The adapter follows
Bazel's test contract: shard_count distributes the suites round-robin,
`--test_filter` keeps the suites whose `res://` path contains it, the JUnit
report becomes the test's XML result and all GdUnit reports appear among its
undeclared outputs. The test fails when a test fails, when no test runs or when
the suites targets hold no suite; a shard or `--test_filter` that leaves no
suite passes. Orphan nodes fail no test, as GdUnit's command line judges them;
the log names the tests that left them. GdUnit's assertions provoke engine
errors deliberately, so only the exit code decides.

Arguments after Godot's `--` in args, and those from `--test_arg`, are GdUnit
options, as pytest receives a py_pytest_test's arguments.

Example:
```starlark
load("@autoload_rules_godot//godot/gdunit:defs.bzl", "godot_gdunit_test")

godot_resources(
    name = "unit_suites",
    srcs = glob(["test/**/*_test.gd"]),
    deps = [":game", "@gdunit4"],
)

godot_gdunit_test(
    name = "unit_tests",
    project = ":project",
    suites = [":unit_suites"],
    shard_count = 4,
)
```

Run one suite with `bazel test :unit_tests --test_filter=inventory_test`. See
[GdUnit tests](../../development.md#gdunit).

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| test | one | always | execute GdUnit suites under bazel test; JUnit reports are test outputs; editor/project are runfiles |

### Output groups
none

### Generated targets
none

### Providers
none
*�
�
godot_gdunit_test$
nameName of the test target. (�
suites�godot_resources targets whose own files are the suites. Their deps
bring what the suites use, including the pinned GdUnit add-on under
addons/gdUnit4, helpers and fixtures; those files are not suites. (N
kwargsBgodot_test arguments, such as args, project, size and
shard_count.(�Run GdUnit4 test suites as a Bazel test.

A godot_test whose main script is rules_godot's GdUnit test adapter. A suite is a
script of the suites targets, generated ones included, that extends GdUnit's
`GdUnitTestSuite`; helper scripts and sidecars beside the suites are none. The
suites declare what they use in their deps: the code under test and GdUnit
itself, pinned in your module like any other resources. The adapter follows
Bazel's test contract: shard_count distributes the suites round-robin,
`--test_filter` keeps the suites whose `res://` path contains it, the JUnit
report becomes the test's XML result and all GdUnit reports appear among its
undeclared outputs. The test fails when a test fails, when no test runs or when
the suites targets hold no suite; a shard or `--test_filter` that leaves no
suite passes. Orphan nodes fail no test, as GdUnit's command line judges them;
the log names the tests that left them. GdUnit's assertions provoke engine
errors deliberately, so only the exit code decides.

Arguments after Godot's `--` in args, and those from `--test_arg`, are GdUnit
options, as pytest receives a py_pytest_test's arguments.

Example:
```starlark
load("@autoload_rules_godot//godot/gdunit:defs.bzl", "godot_gdunit_test")

godot_resources(
    name = "unit_suites",
    srcs = glob(["test/**/*_test.gd"]),
    deps = [":game", "@gdunit4"],
)

godot_gdunit_test(
    name = "unit_tests",
    project = ":project",
    suites = [":unit_suites"],
    shard_count = 4,
)
```

Run one suite with `bazel test :unit_tests --test_filter=inventory_test`. See
[GdUnit tests](../../development.md#gdunit).

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| test | one | always | execute GdUnit suites under bazel test; JUnit reports are test outputs; editor/project are runfiles |

### Output groups
none

### Generated targets
none

### Providers
none
2D
godot_gdunit_test/@autoload_rules_godot//godot/private:gdunit.bzl&
$
nameName of the test target. (�
�
suites�godot_resources targets whose own files are the suites. Their deps
bring what the suites use, including the pinned GdUnit add-on under
addons/gdUnit4, helpers and fixtures; those files are not suites. (P
N
kwargsBgodot_test arguments, such as args, project, size and
shard_count.('Run GdUnit4 test suites as Bazel tests.�(
1
autoload_rules_godotgodot/platformsdefs.bzl�%godot_export_platform�Create an export platform and, for mobile, its private platform slices.

A child platform, `platform(parents = [":android_arm64"])` for an export platform
named `android_arm64`, keeps the export platform's operating system, CPUs
and platform slices. The child's own constraints, flags and execution properties
apply only to application packaging and a desktop runtime: content export, the
project's extension libraries and mobile platform slices build for this export
platform or its platform slices, and a desktop export platform is its own platform
slice. Put properties those actions need on `parents`, `constraint_values` or
`exec_properties` here. A child that sets another operating system, CPU or iOS
environment fails analysis.

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| metadata | none | always | select operating system and CPUs; no run behavior |

### Output groups
none

### Generated targets
none

### Providers
| name | role | availability |
| --- | --- | --- |
| PlatformInfo | Bazel target platform constraints | always |
*�
�
godot_export_platformM
nameAPublic export platform target name, selected through --platforms. (G
operating_system/Operating system: linux, macos, android or ios. (�
cpus�Nonempty unique list of `@platforms//cpu` constraint values Godot can
express: `armv7`, `aarch64` (or its alias `arm64`), `x86_32`, `x86_64` and
`riscv64`. Desktops take one CPU, an iOS device `aarch64` and the iOS
Simulator `aarch64` or `x86_64`. Whether a CPU builds is decided by the
registered runtime components: an application for a CPU without one
fails analysis. ([
environmentDiOS device (default) or simulator; omit for other operating systems.None(�
parents�At most one parent platform for custom properties every platform slice
shares.
The export platform's operating system, CPU, environment and mobile
CPU flags replace its own.[](�
constraint_values�Additional constraints shared by the export platform and its platform slices.
Operating system, CPU and iOS environment constraints are owned by
this macro.[](e
exec_propertiesLExecution properties shared by the export platform and every
platform slice.{}(i

visibilitySVisibility of the public export platform; generated platform slices
remain private.None(�Create an export platform and, for mobile, its private platform slices.

A child platform, `platform(parents = [":android_arm64"])` for an export platform
named `android_arm64`, keeps the export platform's operating system, CPUs
and platform slices. The child's own constraints, flags and execution properties
apply only to application packaging and a desktop runtime: content export, the
project's extension libraries and mobile platform slices build for this export
platform or its platform slices, and a desktop export platform is its own platform
slice. Put properties those actions need on `parents`, `constraint_values` or
`exec_properties` here. A child that sets another operating system, CPU or iOS
environment fails analysis.

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| metadata | none | always | select operating system and CPUs; no run behavior |

### Output groups
none

### Generated targets
none

### Providers
| name | role | availability |
| --- | --- | --- |
| PlatformInfo | Bazel target platform constraints | always |
2H
godot_export_platform/@autoload_rules_godot//godot/platforms:defs.bzlO
M
nameAPublic export platform target name, selected through --platforms. (I
G
operating_system/Operating system: linux, macos, android or ios. (�
�
cpus�Nonempty unique list of `@platforms//cpu` constraint values Godot can
express: `armv7`, `aarch64` (or its alias `arm64`), `x86_32`, `x86_64` and
`riscv64`. Desktops take one CPU, an iOS device `aarch64` and the iOS
Simulator `aarch64` or `x86_64`. Whether a CPU builds is decided by the
registered runtime components: an application for a CPU without one
fails analysis. (]
[
environmentDiOS device (default) or simulator; omit for other operating systems.None(�
�
parents�At most one parent platform for custom properties every platform slice
shares.
The export platform's operating system, CPU, environment and mobile
CPU flags replace its own.[](�
�
constraint_values�Additional constraints shared by the export platform and its platform slices.
Operating system, CPU and iOS environment constraints are owned by
this macro.[](g
e
exec_propertiesLExecution properties shared by the export platform and every
platform slice.{}(k
i

visibilitySVisibility of the public export platform; generated platform slices
remain private.None(�Declare an operating system and consumer-selected CPU set as one export platform.

Example: `godot_export_platform(name = "android", operating_system = "android",
cpus = ["@platforms//cpu:armv7", "@platforms//cpu:aarch64"])`.

Select the resulting label with --platforms. C++ compiler, debug symbol, signing and
variant settings stay independent of it. See the platform guide for engine and SDK setup.�
,
autoload_rules_godotgodotproviders.bzl�.GodotResourcesInfo�Godot resources, their import units and explicit dependency metadata. Produced by godot_resources and consumed by godot_resources and the operations that name them; an add-on's runtime and editor parts carry one each.2�,
�
GodotResourcesInfo�Godot resources, their import units and explicit dependency metadata. Produced by godot_resources and consumed by godot_resources and the operations that name them; an add-on's runtime and editor parts carry one each.�
imports�depset[File] of the import results of these resources and their dependencies under the context of the operation that reached them; empty without a context�
units�list[dict] of import units, dependencies first: owner is a label string; outputs is list[string] of its own resource paths; deps is list[string] of nearest dependency unit owners�

unit_heads�list[string] of the owner labels of the import units this target stands for when another unit depends on it: its own unit, or, without files of its own, the units its dependencies stand for; a dependent unit imports after them�
resource_path_manifests�depset of JSON resource path manifests, one per contributing target, that together map every path an import of these resources stages to its File's path_
member_resource_pathsFdict of resource paths to the source or generated Files of the membersv
import_resource_paths]dict of resource paths to the Files of the import inputs, disjoint from member_resource_pathsh
member_ownersWdict[string, string] of the members' resource paths to the label strings declaring themn
import_owners]dict[string, string] of the import inputs' resource paths to the label strings declaring them�
ignored_resource_paths�dict of the resource paths of the members and import inputs Godot ignores to their Files: hidden ones and those below a directory whose .gdignore or project.godot the same target declares. Each target decides it once for its own files; staging still takes them from member_resource_paths and import_resource_pathsb
relationshipsQdepset of (source, target, kind, owner) string tuples; runtime cycles are allowed�
addons�postorder depset of GodotAddonInfo the files of these resources and their dependencies use, with the add-ons those need, dependencies first; never an import input�
class_fragments�depset[File] of the class fragments of these resources' scripts and their dependencies', which validations merge into Godot's global script class cache; empty without a context�

interfaces�depset[File] of the interfaces of these resources and their dependencies under the context, which their dependents' validations stage in place of the files interfaced_resource_paths names and of the import results; empty without a context�
interfaced_resource_paths�depset[string] of the resource paths of the members that interfaces replace for dependents' validations: scripts, imported assets and their .import files; empty without a context�
validations�depset[File] of the validation outputs of these resources and their dependencies under the context, each in its target's _validation output group; empty without a context"@
GodotResourcesInfo*@autoload_rules_godot//godot:providers.bzl�
�
imports�depset[File] of the import results of these resources and their dependencies under the context of the operation that reached them; empty without a context�
�
units�list[dict] of import units, dependencies first: owner is a label string; outputs is list[string] of its own resource paths; deps is list[string] of nearest dependency unit owners�
�

unit_heads�list[string] of the owner labels of the import units this target stands for when another unit depends on it: its own unit, or, without files of its own, the units its dependencies stand for; a dependent unit imports after them�
�
resource_path_manifests�depset of JSON resource path manifests, one per contributing target, that together map every path an import of these resources stages to its File's patha
_
member_resource_pathsFdict of resource paths to the source or generated Files of the membersx
v
import_resource_paths]dict of resource paths to the Files of the import inputs, disjoint from member_resource_pathsj
h
member_ownersWdict[string, string] of the members' resource paths to the label strings declaring themp
n
import_owners]dict[string, string] of the import inputs' resource paths to the label strings declaring them�
�
ignored_resource_paths�dict of the resource paths of the members and import inputs Godot ignores to their Files: hidden ones and those below a directory whose .gdignore or project.godot the same target declares. Each target decides it once for its own files; staging still takes them from member_resource_paths and import_resource_pathsd
b
relationshipsQdepset of (source, target, kind, owner) string tuples; runtime cycles are allowed�
�
addons�postorder depset of GodotAddonInfo the files of these resources and their dependencies use, with the add-ons those need, dependencies first; never an import input�
�
class_fragments�depset[File] of the class fragments of these resources' scripts and their dependencies', which validations merge into Godot's global script class cache; empty without a context�
�

interfaces�depset[File] of the interfaces of these resources and their dependencies under the context, which their dependents' validations stage in place of the files interfaced_resource_paths names and of the import results; empty without a context�
�
interfaced_resource_paths�depset[string] of the resource paths of the members that interfaces replace for dependents' validations: scripts, imported assets and their .import files; empty without a context�
�
validations�depset[File] of the validation outputs of these resources and their dependencies under the context, each in its target's _validation output group; empty without a context�&GodotAddonInfo�An add-on: its runtime part, its editor part with its roles, its extensions, platform libraries and Info.plist fragments, its autoloads and settings, and the add-ons it needs. Produced by godot_addon and, as an add-on of only that extension, by godot_extension and godot_cc_extension; consumed by resources that use it, projects that name it and the operations containing it.2�#
�
GodotAddonInfo�An add-on: its runtime part, its editor part with its roles, its extensions, platform libraries and Info.plist fragments, its autoloads and settings, and the add-ons it needs. Produced by godot_addon and, as an add-on of only that extension, by godot_extension and godot_cc_extension; consumed by resources that use it, projects that name it and the operations containing it.
labelLabel of the add-on�
	directory�string: resource path of the directory every file of the add-on lives below, without a trailing slash; empty for an extension-only add-on, whose files are its extension's�
runtime_files}GodotResourcesInfo of the runtime part: members of every operation containing the add-on, one import unit owned by the add-on�
editor_files�GodotResourcesInfo of the editor part: the plugin.cfg and the files its editor plugin loads, which only the Godot processes of its roles stage and no pack, source run or application containsg
plugin_configVstring: resource path of the editor part's plugin.cfg, or empty without an editor part�
importer_suffixes�sorted list[string] of the lowercase file suffixes, without a dot, the add-on's importers convert; empty without an importer role�
importer_resource_paths�dict of resource paths to the Files an importer of the add-on needs to run: both parts of the add-on and of the add-ons it needs, and the editor files of their extensions; empty without an importer role�
importer_resource_path_manifest�JSON File of importer_resource_paths by execution path, which the imports staging the importer read; None without an importer role and under a context, since imports take the add-on from their project's index�
import_settings}sorted list of the keys of its settings its importer reads at import time, which the Godot processes staging the importer setO

extensionsAlist of GodotExtensionInfo of the extensions in the add-on's depss
platform_libraries]list[Target] of Android and Apple libraries of the add-on and its extensions, sorted by labelk
platform_contributionsQstruct with infoplists, a depset[File] of Info.plist fragments applications merge\
	autoloadsOlist of (name, res:// path, owner) autoload contributions, in declaration orderE
settings9list of (key, Godot literal, owner) setting contributionsn
addonsdpostorder depset of GodotAddonInfo the add-on needs, with the add-ons those need, dependencies first"<
GodotAddonInfo*@autoload_rules_godot//godot:providers.bzl

labelLabel of the add-on�
�
	directory�string: resource path of the directory every file of the add-on lives below, without a trailing slash; empty for an extension-only add-on, whose files are its extension's�
�
runtime_files}GodotResourcesInfo of the runtime part: members of every operation containing the add-on, one import unit owned by the add-on�
�
editor_files�GodotResourcesInfo of the editor part: the plugin.cfg and the files its editor plugin loads, which only the Godot processes of its roles stage and no pack, source run or application containsi
g
plugin_configVstring: resource path of the editor part's plugin.cfg, or empty without an editor part�
�
importer_suffixes�sorted list[string] of the lowercase file suffixes, without a dot, the add-on's importers convert; empty without an importer role�
�
importer_resource_paths�dict of resource paths to the Files an importer of the add-on needs to run: both parts of the add-on and of the add-ons it needs, and the editor files of their extensions; empty without an importer role�
�
importer_resource_path_manifest�JSON File of importer_resource_paths by execution path, which the imports staging the importer read; None without an importer role and under a context, since imports take the add-on from their project's index�
�
import_settings}sorted list of the keys of its settings its importer reads at import time, which the Godot processes staging the importer setQ
O

extensionsAlist of GodotExtensionInfo of the extensions in the add-on's depsu
s
platform_libraries]list[Target] of Android and Apple libraries of the add-on and its extensions, sorted by labelm
k
platform_contributionsQstruct with infoplists, a depset[File] of Info.plist fragments applications merge^
\
	autoloadsOlist of (name, res:// path, owner) autoload contributions, in declaration orderG
E
settings9list of (key, Godot literal, owner) setting contributionsp
n
addonsdpostorder depset of GodotAddonInfo the add-on needs, with the add-ons those need, dependencies first�'GodotProjectInfo�The configuration context of one product: its authored project.godot, settings, autoloads, main scene and the add-ons it names. Produced by godot_project; operations name it as their project, and resources import under the context their operation sets.2�%
�
GodotProjectInfo�The configuration context of one product: its authored project.godot, settings, autoloads, main scene and the add-ons it names. Produced by godot_project; operations name it as their project, and resources import under the context their operation sets.T
labelKLabel of the godot_project, or of //godot/private:no_project for no context�
import_configuration�project.godot File every import of the context reads: the authored file, the project's settings and the import settings of the add-ons it names, filtered by the import purpose; None for no context�

importable�tree artifact File listing the file suffixes Godot imports under this context, the importers of the add-ons it names included, one empty file per suffix; None for no context�
	importers�dict of lowercase file suffixes to the GodotAddonInfo, outside every context, of the add-ons the project names whose importer role declares that suffix, in the order of named_addonsk
authored_project_fileRproject.godot File the configuration starts from, as declared; None for no context�
authored_autoloads�JSON File of the authored project.godot's autoloads, name to value as written, which content validations register; None for no contexta
settingsUdict[string, string] of the project's own settings, section/property to Godot literalY
setting_overridesDdict[string, string] of settings replacing conflicting contributionsU
	autoloadsHdict[string, string] of the project's own autoloads, name to res:// path[
autoload_overridesEdict[string, string] of autoloads replacing conflicting contributionsH

main_scene:string: declared resource path of the main scene, or emptyg
context_filesVdict of resource paths to the Files bound to the context, such as the application icon�
named_addons�postorder depset of GodotAddonInfo of the add-ons the project names in deps, with the add-ons those need, dependencies first, reached outside every context; every operation of the project contains them and they import their parts under its context�
custom_features�sorted list[string] of the Godot custom features the project's custom-feature build settings give in this configuration; packs export with them and source runs start with them; empty for no context�
flag_settings�dict of the setting keys settings_from_flags sets to the Godot literals of the flags' values in this configuration; packs export with them and source runs start with them">
GodotProjectInfo*@autoload_rules_godot//godot:providers.bzlV
T
labelKLabel of the godot_project, or of //godot/private:no_project for no context�
�
import_configuration�project.godot File every import of the context reads: the authored file, the project's settings and the import settings of the add-ons it names, filtered by the import purpose; None for no context�
�

importable�tree artifact File listing the file suffixes Godot imports under this context, the importers of the add-ons it names included, one empty file per suffix; None for no context�
�
	importers�dict of lowercase file suffixes to the GodotAddonInfo, outside every context, of the add-ons the project names whose importer role declares that suffix, in the order of named_addonsm
k
authored_project_fileRproject.godot File the configuration starts from, as declared; None for no context�
�
authored_autoloads�JSON File of the authored project.godot's autoloads, name to value as written, which content validations register; None for no contextc
a
settingsUdict[string, string] of the project's own settings, section/property to Godot literal[
Y
setting_overridesDdict[string, string] of settings replacing conflicting contributionsW
U
	autoloadsHdict[string, string] of the project's own autoloads, name to res:// path]
[
autoload_overridesEdict[string, string] of autoloads replacing conflicting contributionsJ
H

main_scene:string: declared resource path of the main scene, or emptyi
g
context_filesVdict of resource paths to the Files bound to the context, such as the application icon�
�
named_addons�postorder depset of GodotAddonInfo of the add-ons the project names in deps, with the add-ons those need, dependencies first, reached outside every context; every operation of the project contains them and they import their parts under its context�
�
custom_features�sorted list[string] of the Godot custom features the project's custom-feature build settings give in this configuration; packs export with them and source runs start with them; empty for no context�
�
flag_settings�dict of the setting keys settings_from_flags sets to the Godot literals of the flags' values in this configuration; packs export with them and source runs start with them�&GodotPackInfoxA Godot-exported PCK and its declared project. Produced by godot_pack; consumed by run/test rules and application rules.2�%
�
GodotPackInfoxA Godot-exported PCK and its declared project. Produced by godot_pack; consumed by run/test rules and application rules.V
	pack_fileIFile: exported .pck with extension descriptors but no extension libraries)

pack_filesdepset[File] of PCK outputs�
project�what the pack delivers in the current platform slice: member_resource_paths, which include the project's context files, runtime_extensions, export_extensions, platform_libraries and infoplists; common content is exported separatelyg
operating_systemSstring: the operating system the pack is exported for: linux, macos, android or ios6
cpus.list[string]: canonical full requested CPU setC
environment4string: device or simulator for iOS, otherwise empty�
	available�depset of JSON Files {pack, resources} of this pack and every pack it requires; resources maps each contained path to its source pathd
export_optionsRdict[string, string] of the export preset options the pack sets, as Godot literals�
facts�File: JSON of what Godot decides for the pack's export, which application rules write their shell files from: features, the export's feature tags; options, every export option of the operating system with its value or default; settings, the project settings with the export's feature overrides; versions, the values of the version options as Godot's exporter reads them; name_translations, the project's name by locale of its translations{
versionpstring: canonical version of the editor that exported the pack; diagnostic only, never compared with the runtimeU
editor_componentAGodotComponentInfo of the editor component that exported the pack�
variantustring: release or debug, the template variant of the export and of the runtime it needs; debug in the editor variant�
icons�list[File] of the application icons Godot renders for the pack's operating system, which only applications using them build: for Android a resource directory with the launcher icons, for iOS an asset catalog with the AppIcon set, for macOS a directory with icon.icns; empty for other operating systems�
splash�list[File] of the splash images Godot renders for the pack's operating system: for Android a resource directory with the splash screen's drawables, for iOS an asset catalog with the launch screen's SplashImage, Godot's boot splash unless the project sets one; empty for other operating systems";
GodotPackInfo*@autoload_rules_godot//godot:providers.bzlX
V
	pack_fileIFile: exported .pck with extension descriptors but no extension libraries+
)

pack_filesdepset[File] of PCK outputs�
�
project�what the pack delivers in the current platform slice: member_resource_paths, which include the project's context files, runtime_extensions, export_extensions, platform_libraries and infoplists; common content is exported separatelyi
g
operating_systemSstring: the operating system the pack is exported for: linux, macos, android or ios8
6
cpus.list[string]: canonical full requested CPU setE
C
environment4string: device or simulator for iOS, otherwise empty�
�
	available�depset of JSON Files {pack, resources} of this pack and every pack it requires; resources maps each contained path to its source pathf
d
export_optionsRdict[string, string] of the export preset options the pack sets, as Godot literals�
�
facts�File: JSON of what Godot decides for the pack's export, which application rules write their shell files from: features, the export's feature tags; options, every export option of the operating system with its value or default; settings, the project settings with the export's feature overrides; versions, the values of the version options as Godot's exporter reads them; name_translations, the project's name by locale of its translations}
{
versionpstring: canonical version of the editor that exported the pack; diagnostic only, never compared with the runtimeW
U
editor_componentAGodotComponentInfo of the editor component that exported the pack�
�
variantustring: release or debug, the template variant of the export and of the runtime it needs; debug in the editor variant�
�
icons�list[File] of the application icons Godot renders for the pack's operating system, which only applications using them build: for Android a resource directory with the launcher icons, for iOS an asset catalog with the AppIcon set, for macOS a directory with icon.icns; empty for other operating systems�
�
splash�list[File] of the splash images Godot renders for the pack's operating system: for Android a resource directory with the splash screen's drawables, for iOS an asset catalog with the launch screen's SplashImage, Godot's boot splash unless the project sets one; empty for other operating systems�GodotRuntimeInfo�A prebuilt or source-built engine runtime for one target platform. Produced by export-template archives and source recipes; carried by runtime components and consumed by desktop packaging.2�
�
GodotRuntimeInfo�A prebuilt or source-built engine runtime for one target platform. Produced by export-template archives and source recipes; carried by runtime components and consumed by desktop packaging.[

executableMFile of the executable runtime, or None when the runtime is an engine library!
filesdepset of runtime inputsu
platformistring: the Godot platform, that is the operating system the runtime is for: linux, macos, ios or android=
cpu6string: target CPU identifier, such as arm64 or x86_64N
environment?string: device or simulator for iOS; empty for non-iOS runtimes�
facts_sourcerstring: where the runtime's facts come from: source for a source recipe, declared for a prebuilt or opaque payloadP
originFstring: producer or imported target label used in mismatch diagnostics�
version�string: actual runtime version; declared imports use canonical versions, while source producers may retain an unnumbered prerelease channeli
bundle_filesYdict of desktop bundle-relative paths to the Files the runtime executable needs beside itN
variantCstring: release or debug, the Godot template variant of the runtime�
debug_symbols�File or None: .dSYM directory the linker wrote for a source recipe executable, as rules_cc's cc_binary does on Apple platforms with --apple_generate_dsym�

minimum_os�string: the deployment target the runtime was built for on Apple platforms, such as 11.0 for a macOS source recipe; empty where the producer does not declare one, as for prebuilt and imported payloads">
GodotRuntimeInfo*@autoload_rules_godot//godot:providers.bzl]
[

executableMFile of the executable runtime, or None when the runtime is an engine library#
!
filesdepset of runtime inputsw
u
platformistring: the Godot platform, that is the operating system the runtime is for: linux, macos, ios or android?
=
cpu6string: target CPU identifier, such as arm64 or x86_64P
N
environment?string: device or simulator for iOS; empty for non-iOS runtimes�
�
facts_sourcerstring: where the runtime's facts come from: source for a source recipe, declared for a prebuilt or opaque payloadR
P
originFstring: producer or imported target label used in mismatch diagnostics�
�
version�string: actual runtime version; declared imports use canonical versions, while source producers may retain an unnumbered prerelease channelk
i
bundle_filesYdict of desktop bundle-relative paths to the Files the runtime executable needs beside itP
N
variantCstring: release or debug, the Godot template variant of the runtime�
�
debug_symbols�File or None: .dSYM directory the linker wrote for a source recipe executable, as rules_cc's cc_binary does on Apple platforms with --apple_generate_dsym�
�

minimum_os�string: the deployment target the runtime was built for on Apple platforms, such as 11.0 for a macOS source recipe; empty where the producer does not declare one, as for prebuilt and imported payloads�GodotComponentInfo�The provenance of one engine component slot. Produced by godot_editor_component/godot_runtime_component; carried as provenance on the resolved editor and runtime toolchains for diagnostics, never as a compatibility condition.2�
�

GodotComponentInfo�The provenance of one engine component slot. Produced by godot_editor_component/godot_runtime_component; carried as provenance on the resolved editor and runtime toolchains for diagnostics, never as a compatibility condition.E
	component8string: label of the component that declares the payload[
engineQstring: name of the engine the component belongs to; empty for the default engine!
rolestring: editor or runtime�
platform�string: the Godot platform, that is the operating system of the editor platform for editors and of the target platform for runtimes: linux, macos, ios or android
cpustring: arm64 or x86_64L
environment=string: device or simulator for iOS runtimes; empty otherwiseC
variant8string: debug or release for runtimes; empty for editorsO
versionDstring: producer version where known, otherwise the declared versionD
kind<string: source for source-built payloads, prebuilt otherwise+
origin!string: producer or payload labelg
digest]string: source or artifact content digest where the producer supplies one; empty when unknown�
customizationsqdict of requested build customization (patches, modules, options) where the producer supplies it; empty otherwise"@
GodotComponentInfo*@autoload_rules_godot//godot:providers.bzlG
E
	component8string: label of the component that declares the payload]
[
engineQstring: name of the engine the component belongs to; empty for the default engine#
!
rolestring: editor or runtime�
�
platform�string: the Godot platform, that is the operating system of the editor platform for editors and of the target platform for runtimes: linux, macos, ios or android 

cpustring: arm64 or x86_64N
L
environment=string: device or simulator for iOS runtimes; empty otherwiseE
C
variant8string: debug or release for runtimes; empty for editorsQ
O
versionDstring: producer version where known, otherwise the declared versionF
D
kind<string: source for source-built payloads, prebuilt otherwise-
+
origin!string: producer or payload labeli
g
digest]string: source or artifact content digest where the producer supplies one; empty when unknown�
�
customizationsqdict of requested build customization (patches, modules, options) where the producer supplies it; empty otherwise�/GodotExtensionInfo�A GDExtension in one configuration: its configured extension library, its descriptor fragment and the resource paths of both, and those of its tool view. Produced by godot_extension/godot_cc_extension; consumed by resources, projects and application rules.2�-
�
GodotExtensionInfo�A GDExtension in one configuration: its configured extension library, its descriptor fragment and the resource paths of both, and those of its tool view. Produced by godot_extension/godot_cc_extension; consumed by resources, projects and application rules.i
files`depset of the descriptor fragment, the configured extension library and its runtime dependencies�
library�struct, or None where the extension has no library in this configuration: the configured extension library, with
tags (string: Godot's feature tags of the configuration joined with '.', such as android.arm64.release),
operating_system (linux, macos, android or ios),
cpu (Godot's CPU tag, such as arm32 or arm64),
environment (device or simulator on iOS, otherwise empty),
link_kind (static, dynamic or framework, from the library's providers),
file (File: the static archive, shared library or framework binary),
resource_path (string: where the descriptor fragment names it),
cc_info (CcInfo that links a static library or framework, otherwise None),
runtime_dependencies (dict of resource paths, beside the library, to the Files it needs at run time: dynamic libraries and frameworks of its providers and the extension's data),
debug_symbols (File: the .dSYM directory the linker wrote for it, or None)�
runtime_resource_paths�dict of resource paths to the Files that packs, source runs and applications place in the project: the descriptor fragment, the configured extension library and its runtime dependencies; empty where the extension has no library in this configuration�
editor_resource_paths�dict of resource paths to the Files editor actions such as exports stage: the runtime_resource_paths of the tool view, configured for their execution platform; empty where the tool configuration has no library�
host_editor_resource_paths�dict of resource paths to the Files of the tool view configured for the host, which godot_editor and bazel run for a target platform the host cannot run stage�
runtime_descriptor�the descriptor fragment File of this configuration: one [libraries] entry and its [dependencies] entry with the configuration's feature tags. Packs merge the fragments of their platform slices�
descriptor_pathsthe resource path of the descriptor in runtime_resource_paths, editor_resource_paths and host_editor_resource_paths[
entry_symbolKstring: GDExtension initialization symbol shared by all extension libraries~
platform_librarieshlist[Target] of Android and Apple libraries from the extension's deps that applications link and package�
platform_contributions�struct with infoplists, a depset[File] of the Info.plist fragments iOS applications merge for the extension, as GodotAddonInfo.platform_contributions�
minimum_os_versions�dict of macos and ios to the minimum operating-system version the extension's libraries need there; an application whose minimum is lower fails. Empty where the libraries run on every version the engine supports"@
GodotExtensionInfo*@autoload_rules_godot//godot:providers.bzlk
i
files`depset of the descriptor fragment, the configured extension library and its runtime dependencies�
�
library�struct, or None where the extension has no library in this configuration: the configured extension library, with
tags (string: Godot's feature tags of the configuration joined with '.', such as android.arm64.release),
operating_system (linux, macos, android or ios),
cpu (Godot's CPU tag, such as arm32 or arm64),
environment (device or simulator on iOS, otherwise empty),
link_kind (static, dynamic or framework, from the library's providers),
file (File: the static archive, shared library or framework binary),
resource_path (string: where the descriptor fragment names it),
cc_info (CcInfo that links a static library or framework, otherwise None),
runtime_dependencies (dict of resource paths, beside the library, to the Files it needs at run time: dynamic libraries and frameworks of its providers and the extension's data),
debug_symbols (File: the .dSYM directory the linker wrote for it, or None)�
�
runtime_resource_paths�dict of resource paths to the Files that packs, source runs and applications place in the project: the descriptor fragment, the configured extension library and its runtime dependencies; empty where the extension has no library in this configuration�
�
editor_resource_paths�dict of resource paths to the Files editor actions such as exports stage: the runtime_resource_paths of the tool view, configured for their execution platform; empty where the tool configuration has no library�
�
host_editor_resource_paths�dict of resource paths to the Files of the tool view configured for the host, which godot_editor and bazel run for a target platform the host cannot run stage�
�
runtime_descriptor�the descriptor fragment File of this configuration: one [libraries] entry and its [dependencies] entry with the configuration's feature tags. Packs merge the fragments of their platform slices�
�
descriptor_pathsthe resource path of the descriptor in runtime_resource_paths, editor_resource_paths and host_editor_resource_paths]
[
entry_symbolKstring: GDExtension initialization symbol shared by all extension libraries�
~
platform_librarieshlist[Target] of Android and Apple libraries from the extension's deps that applications link and package�
�
platform_contributions�struct with infoplists, a depset[File] of the Info.plist fragments iOS applications merge for the extension, as GodotAddonInfo.platform_contributions�
�
minimum_os_versions�dict of macos and ios to the minimum operating-system version the extension's libraries need there; an application whose minimum is lower fails. Empty where the libraries run on every version the engine supports�GodotDesktopAppInfo�Selected desktop application bundle and distributable archive.

Produced by godot_app on desktops; macOS fields refer to the unsigned or signed
bundle the macos_signing setting selects. executable_path stays relative to that
bundle.
In a consuming rule implementation, read `ctx.attr.app[GodotDesktopAppInfo].archive`
to obtain the distributable File. The bundle field contains the application
tree artifact; executable_path locates the runtime executable inside it.2�

�
GodotDesktopAppInfo�Selected desktop application bundle and distributable archive.

Produced by godot_app on desktops; macOS fields refer to the unsigned or signed
bundle the macos_signing setting selects. executable_path stays relative to that
bundle.
In a consuming rule implementation, read `ctx.attr.app[GodotDesktopAppInfo].archive`
to obtain the distributable File. The bundle field contains the application
tree artifact; executable_path locates the runtime executable inside it.C
bundle9File: tree artifact containing the application directory.R
archiveGFile: deterministic ZIP (macos) or tar.gz (linux) distribution archive.+
operating_systemstring: linux or macos.M
executable_path:string: POSIX executable path relative to the bundle root.v
runtime_componentaGodotComponentInfo of the runtime component packaged in the bundle, or None for an opaque runtime"A
GodotDesktopAppInfo*@autoload_rules_godot//godot:providers.bzlE
C
bundle9File: tree artifact containing the application directory.T
R
archiveGFile: deterministic ZIP (macos) or tar.gz (linux) distribution archive.-
+
operating_systemstring: linux or macos.O
M
executable_path:string: POSIX executable path relative to the bundle root.x
v
runtime_componentaGodotComponentInfo of the runtime component packaged in the bundle, or None for an opaque runtime�Public interfaces between resource, engine, extension and packaging rules.

Read these providers in a consuming rule's implementation after declaring a
provider constraint on the input attribute. Fields describe Bazel artifacts
and stable resource identities.

Example:
```starlark
load("@autoload_rules_godot//godot:providers.bzl", "GodotPackInfo")

def _consume_impl(ctx):
    pack = ctx.attr.pack[GodotPackInfo]
    return [DefaultInfo(files = depset([pack.pack_file]))]

consume_pack = rule(
    implementation = _consume_impl,
    attrs = {"pack": attr.label(providers = [GodotPackInfo])},
)
```

The same indexing pattern applies to every provider below. See
[resource composition](../../resources.md), [engines](../../engine.md) and
[extensions](../../gdextension.md) for producer and consumer examples.�Y
9
autoload_rules_godotgodot/testingartifact_tests.bzl�4android_bundle_test�Test an Android App Bundle the way Google Play delivers it, without a device.

The test validates the bundle with bundletool, generates its universal APK and
checks that the APK stores `assets/main.pck` uncompressed and carries the export's
command line, that the base manifest declares `application_id` and Godot's
activity, and every listed manifest entry, native library, Java class and PCK
resource. With `debug_symbols`, each library of the application's symbol ZIP must
match the stripped library the APK packages by GNU build ID and keep its symbol
table. The test fails with the list of what is missing. It writes the evidence,
such as the PCK's resource paths, to `bundle.json` among the test's undeclared
outputs.

The inspection runs on the execution platform with the host JDK, so a bundle built
for an Android platform is inspected on the machine running the test. Build the
bundle with `--@autoload_rules_godot//godot:android_format=aab`; see
[App Bundles](../../platforms.md#app-bundles-for-store-upload).

Example:
```starlark
android_bundle_test(
    name = "app_packages_extension_test",
    bundle = ":app",
    bundletool = "@bundletool//file",
    application_id = "org.example.game",
    apk_libraries = ["lib/arm64-v8a/libgame_native.so"],
    pck_files = ["main/main.gd"],
)
```

`@bundletool//file` is an `http_file` of the checksum-pinned `bundletool-all` JAR
in the caller's `MODULE.bazel`.

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| test | one | always | inspect the bundle under bazel test on the execution platform; bundle.json is an undeclared test output |

### Output groups
none

### Generated targets
none

### Providers
none"�&
�
android_bundle_test�Test an Android App Bundle the way Google Play delivers it, without a device.

The test validates the bundle with bundletool, generates its universal APK and
checks that the APK stores `assets/main.pck` uncompressed and carries the export's
command line, that the base manifest declares `application_id` and Godot's
activity, and every listed manifest entry, native library, Java class and PCK
resource. With `debug_symbols`, each library of the application's symbol ZIP must
match the stripped library the APK packages by GNU build ID and keep its symbol
table. The test fails with the list of what is missing. It writes the evidence,
such as the PCK's resource paths, to `bundle.json` among the test's undeclared
outputs.

The inspection runs on the execution platform with the host JDK, so a bundle built
for an Android platform is inspected on the machine running the test. Build the
bundle with `--@autoload_rules_godot//godot:android_format=aab`; see
[App Bundles](../../platforms.md#app-bundles-for-store-upload).

Example:
```starlark
android_bundle_test(
    name = "app_packages_extension_test",
    bundle = ":app",
    bundletool = "@bundletool//file",
    application_id = "org.example.game",
    apk_libraries = ["lib/arm64-v8a/libgame_native.so"],
    pck_files = ["main/main.gd"],
)
```

`@bundletool//file` is an `http_file` of the checksum-pinned `bundletool-all` JAR
in the caller's `MODULE.bazel`.

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| test | one | always | inspect the bundle under bazel test on the execution platform; bundle.json is an undeclared test output |

### Output groups
none

### Generated targets
none

### Providers
none*
nameA unique name for this target. �
bundle�The App Bundle to test: a godot_app built with the aab Android format, or another target providing rules_android's AndroidBundleInfo. *Q
AndroidBundleInfo<
AndroidBundleInfo'@rules_android//providers:providers.bzl�

bundletoolnThe bundletool-all .jar that validates the bundle and generates its APK; it carries aapt2. Pin it by checksum. e
application_idOThe package name the base manifest must declare, as godot_app's application_id. �
debug_symbols�The application's `<name>.debug_symbols` ZIP of `<abi>/<name>.so` entries.
Each library in it must be the one the APK packages stripped, by GNU build ID,
and keep its symbol table. Unset, the test checks no symbols.2Nonev
symbol_libraries\`<abi>/<name>.so` paths debug_symbols must contain, such as `arm64-v8a/libgodot_android.so`.2[]�

debug_infokWhether the libraries of debug_symbols must also carry DWARF, as a release build with `--copt=-g` keeps it.2False�
apk_librariesjAPK paths of native libraries the universal APK must contain, such as `lib/arm64-v8a/libgodot_android.so`.2[]k
	pck_filesXResource paths `assets/main.pck` must contain, without `res://`, such as `main/main.gd`.2[]m
manifest_entriesSText the base manifest bundletool prints must contain, such as a
permission's name.2[]�
classes�Fully qualified Java classes the universal APK's dex files must define, such as a plugin's entry class; a class only referenced does not count.2[]"[
android_bundle_testD@autoload_rules_godot//godot/testing/private:android_bundle_test.bzl08,
*
nameA unique name for this target. �
�
bundle�The App Bundle to test: a godot_app built with the aab Android format, or another target providing rules_android's AndroidBundleInfo. *Q
AndroidBundleInfo<
AndroidBundleInfo'@rules_android//providers:providers.bzl�
�

bundletoolnThe bundletool-all .jar that validates the bundle and generates its APK; it carries aapt2. Pin it by checksum. g
e
application_idOThe package name the base manifest must declare, as godot_app's application_id. �
�
debug_symbols�The application's `<name>.debug_symbols` ZIP of `<abi>/<name>.so` entries.
Each library in it must be the one the APK packages stripped, by GNU build ID,
and keep its symbol table. Unset, the test checks no symbols.2Nonex
v
symbol_libraries\`<abi>/<name>.so` paths debug_symbols must contain, such as `arm64-v8a/libgodot_android.so`.2[]�
�

debug_infokWhether the libraries of debug_symbols must also carry DWARF, as a release build with `--copt=-g` keeps it.2False�
�
apk_librariesjAPK paths of native libraries the universal APK must contain, such as `lib/arm64-v8a/libgodot_android.so`.2[]m
k
	pck_filesXResource paths `assets/main.pck` must contain, without `res://`, such as `main/main.gd`.2[]o
m
manifest_entriesSText the base manifest bundletool prints must contain, such as a
permission's name.2[]�
�
classes�Fully qualified Java classes the universal APK's dex files must define, such as a plugin's entry class; a class only referenced does not count.2[]� ios_app_test�	Test what an iOS application contains, without a simulator or device.

The test reads the application's `.app` directory or unpacks its `.ipa` and checks
that its executable defines every listed C symbol, local ones included, that every
listed file exists in the bundle and that its `Info.plist` has every listed key.
With `debug_symbols`, the application's dSYM must exist and carry the executable's
UUID for each CPU. The test fails with the list of what the application lacks; at
least one check must be requested.

A statically linked extension shows as its entry symbol, such as the
`entry_symbol` of godot_cc_extension. The inspection uses Apple's `nm`, so it runs
on a macOS execution platform with Xcode; see [iOS](../../platforms.md#ios).

Example:
```starlark
ios_app_test(
    name = "app_links_extension_test",
    app = ":app",
    symbols = ["game_native_init"],
    infoplist_keys = ["CFBundleShortVersionString"],
)
```

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| test | one | always | inspect the application under bazel test on a macOS execution platform |

### Output groups
none

### Generated targets
none

### Providers
none"�
�
ios_app_test�	Test what an iOS application contains, without a simulator or device.

The test reads the application's `.app` directory or unpacks its `.ipa` and checks
that its executable defines every listed C symbol, local ones included, that every
listed file exists in the bundle and that its `Info.plist` has every listed key.
With `debug_symbols`, the application's dSYM must exist and carry the executable's
UUID for each CPU. The test fails with the list of what the application lacks; at
least one check must be requested.

A statically linked extension shows as its entry symbol, such as the
`entry_symbol` of godot_cc_extension. The inspection uses Apple's `nm`, so it runs
on a macOS execution platform with Xcode; see [iOS](../../platforms.md#ios).

Example:
```starlark
ios_app_test(
    name = "app_links_extension_test",
    app = ":app",
    symbols = ["game_native_init"],
    infoplist_keys = ["CFBundleShortVersionString"],
)
```

### Default outputs
| kind | cardinality | availability | behavior |
| --- | --- | --- | --- |
| test | one | always | inspect the application under bazel test on a macOS execution platform |

### Output groups
none

### Generated targets
none

### Providers
none*
nameA unique name for this target. �
app�The iOS application to test: a godot_app built for an iOS export platform, or another target providing rules_apple's AppleBundleInfo. *P
AppleBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl�
symbols{C symbol names the executable must define, without the leading underscore of Mach-O symbols, such as `native_counter_init`.2[]d
filesUPaths relative to the `.app` bundle that must exist, such as a bundled resource file.2[]u
infoplist_keys]Keys the application's `Info.plist` must contain, such as a usage description an add-on adds.2[]�
debug_symbols�The application's `<name>.debug_symbols`, whose dSYM must carry the
executable's UUIDs. Build with `--apple_generate_dsym`; unset, the test
checks no dSYM.2None"M
ios_app_test=@autoload_rules_godot//godot/testing/private:ios_app_test.bzl08,
*
nameA unique name for this target. �
�
app�The iOS application to test: a godot_app built for an iOS export platform, or another target providing rules_apple's AppleBundleInfo. *P
AppleBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl�
�
symbols{C symbol names the executable must define, without the leading underscore of Mach-O symbols, such as `native_counter_init`.2[]f
d
filesUPaths relative to the `.app` bundle that must exist, such as a bundled resource file.2[]w
u
infoplist_keys]Keys the application's `Info.plist` must contain, such as a usage description an add-on adds.2[]�
�
debug_symbols�The application's `<name>.debug_symbols`, whose dSYM must carry the
executable's UUIDs. Build with `--apple_generate_dsym`; unset, the test
checks no dSYM.2None�Test what a built Android App Bundle or iOS application contains, without a device.

`android_bundle_test` inspects the APK bundletool generates from a godot_app's App Bundle;
`ios_app_test` inspects a godot_app's iOS application. Both run as ordinary Bazel tests on
the execution platform, so a mobile build can be checked where it is built, such as for
the native libraries of an add-on or the resources of the pack. Neither installs nor runs
the application. See [platform prerequisites](../../platforms.md) for the Android SDK and
Xcode setup the applications need. 