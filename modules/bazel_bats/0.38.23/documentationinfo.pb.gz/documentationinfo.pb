�$


bazel_batsdeps.bzl�bazel_bats_dependencies*�
�
bazel_bats_dependencies
version"1.7.0"(N
sha256B"ac70c2a153f108b1ac549c2eaa4154dea4a7c1cc421e3352f0ce6ea49435454e"(
bats_assert_versionNone(
bats_assert_sha256None(
bats_support_versionNone(
bats_support_sha256None(22
bazel_bats_dependencies@@bazel_bats//:deps.bzl
cc�
 //tools/build_defs/repo:http.bzlrj
.
bazel_toolstools/build_defs/repohttp.bzl*
http_archivehttp_archive
7C
E�
!//tools/build_defs/repo:utils.bzlr]
/
bazel_toolstools/build_defs/repo	utils.bzl
maybemaybe
8=
?�	BATS_SUPPORT_BUILD_CONTENT�
filegroup(
    name = "load_files",
    srcs = [
        "load.bash",
    ] + glob([
        "src/**/*.bash",
    ]),
    visibility = ["//visibility:public"],
)
j��
filegroup(
    name = "load_files",
    srcs = [
        "load.bash",
    ] + glob([
        "src/**/*.bash",
    ]),
    visibility = ["//visibility:public"],
)
�	BATS_ASSERT_BUILD_CONTENT�
filegroup(
    name = "load_files",
    srcs = [
        "load.bash",
    ] + glob([
        "src/**/*.bash",
    ]),
    visibility = ["//visibility:public"],
)
j��
filegroup(
    name = "load_files",
    srcs = [
        "load.bash",
    ] + glob([
        "src/**/*.bash",
    ]),
    visibility = ["//visibility:public"],
)
�	BATS_CORE_BUILD_CONTENT�
load("@rules_shell//shell:sh_binary.bzl", "sh_binary")
load("@rules_shell//shell:sh_library.bzl", "sh_library")
load("@rules_shell//shell:sh_test.bzl", "sh_test")

sh_library(
    name = "bats_lib",
    srcs = glob(["libexec/**"]),
)

sh_binary(
    name = "bats",
    srcs = ["bin/bats"],
    visibility = ["//visibility:public"],
    deps = [":bats_lib"],
)

sh_library(
    name = "file_setup_teardown_lib",
    srcs = ["test/file_setup_teardown.bats"],
    visibility = ["//visibility:public"],
    data = glob(["test/fixtures/file_setup_teardown/**"]),
)

sh_library(
    name = "junit_formatter_lib",
    srcs = ["test/junit-formatter.bats"],
    visibility = ["//visibility:public"],
    data = glob(["test/fixtures/junit-formatter/**"]),
)

sh_library(
    name = "parallel_lib",
    srcs = ["test/parallel.bats"],
    visibility = ["//visibility:public"],
    data = glob([
        "test/concurrent-coordination.bash",
        "test/fixtures/parallel/**",
    ]),
)

sh_library(
    name = "run_lib",
    srcs = ["test/run.bats"],
    visibility = ["//visibility:public"],
    data = glob(["test/fixtures/run/**"]),
)

sh_library(
    name = "suite_lib",
    srcs = ["test/suite.bats"],
    visibility = ["//visibility:public"],
    data = glob(["test/fixtures/suite/**"]),
)

sh_library(
    name = "test_helper",
    srcs = ["test/test_helper.bash"],
    visibility = ["//visibility:public"],
)

sh_library(
    name = "trace_lib",
    srcs = ["test/trace.bats"],
    visibility = ["//visibility:public"],
    data = glob(["test/fixtures/trace/**"]),
)

exports_files(glob(["test/*.bats"]))
j��
load("@rules_shell//shell:sh_binary.bzl", "sh_binary")
load("@rules_shell//shell:sh_library.bzl", "sh_library")
load("@rules_shell//shell:sh_test.bzl", "sh_test")

sh_library(
    name = "bats_lib",
    srcs = glob(["libexec/**"]),
)

sh_binary(
    name = "bats",
    srcs = ["bin/bats"],
    visibility = ["//visibility:public"],
    deps = [":bats_lib"],
)

sh_library(
    name = "file_setup_teardown_lib",
    srcs = ["test/file_setup_teardown.bats"],
    visibility = ["//visibility:public"],
    data = glob(["test/fixtures/file_setup_teardown/**"]),
)

sh_library(
    name = "junit_formatter_lib",
    srcs = ["test/junit-formatter.bats"],
    visibility = ["//visibility:public"],
    data = glob(["test/fixtures/junit-formatter/**"]),
)

sh_library(
    name = "parallel_lib",
    srcs = ["test/parallel.bats"],
    visibility = ["//visibility:public"],
    data = glob([
        "test/concurrent-coordination.bash",
        "test/fixtures/parallel/**",
    ]),
)

sh_library(
    name = "run_lib",
    srcs = ["test/run.bats"],
    visibility = ["//visibility:public"],
    data = glob(["test/fixtures/run/**"]),
)

sh_library(
    name = "suite_lib",
    srcs = ["test/suite.bats"],
    visibility = ["//visibility:public"],
    data = glob(["test/fixtures/suite/**"]),
)

sh_library(
    name = "test_helper",
    srcs = ["test/test_helper.bash"],
    visibility = ["//visibility:public"],
)

sh_library(
    name = "trace_lib",
    srcs = ["test/trace.bats"],
    visibility = ["//visibility:public"],
    data = glob(["test/fixtures/trace/**"]),
)

exports_files(glob(["test/*.bats"]))
�x


bazel_batsexpansion.bzl�!expansion.expand_with_manual_dict�Recursively expands all values in `source_env_dict` using the given lookup data.

All keys of `source_env_dict` are returned in the resultant dict with values expanded by
lookups via `resolution_dict` dict.
This function does not modify any of the given parameters.
*�	
�	
!expansion.expand_with_manual_dict�
resolution_dict�(Required) A dictionary with resolved key/value pairs to be used for
lookup when resolving values. This may come from toolchains (via
`ctx.var`) or other sources. (�
source_env_dict�(Required) The source for all desired expansions. All key/value pairs
will appear within the returned dictionary, with all values fully
expanded by lookups in `resolution_dict`. (�
validate_expansion�(Optional) If set to True, all expanded strings will be validated to
ensure that no unexpanded (but seemingly expandable) values remain. If
any unexpanded values are found, `fail()` will be called. The
validation logic is the same as
`expansion.validate_expansions_in_dict()`.
Default value is False.False(�Recursively expands all values in `source_env_dict` using the given lookup data.

All keys of `source_env_dict` are returned in the resultant dict with values expanded by
lookups via `resolution_dict` dict.
This function does not modify any of the given parameters.
"i
gA new dict with all key/values from `source_env_dict`, where all values have been recursively
expanded.28
_expand_with_manual_dict@@bazel_bats//:expansion.bzl
���.expansion.expand_with_manual_dict_and_location�Recursively expands all values in `source_env_dict` using the given logic / lookup data.

All keys of `source_env_dict` are returned in the resultant dict with values expanded by
location expansion logic via `expand_location` and by lookups via `resolution_dict` dict.
This function does not modify any of the given parameters.
*�
�
.expansion.expand_with_manual_dict_and_location�
expand_location�(Required) A function that takes in a string and properly replaces
`$(location ...)` (and similar) with the corresponding values. This
likely should correspond to `ctx.expand_location()`. (�
resolution_dict�(Required) A dictionary with resolved key/value pairs to be used for
lookup when resolving values. This may come from toolchains (via
`ctx.var`) or other sources. (�
source_env_dict�(Required) The source for all desired expansions. All key/value pairs
will appear within the returned dictionary, with all values fully
expanded by the logic expansion logic of `expand_location` and by
lookup in `resolution_dict`. (�
validate_expansion�(Optional) If set to True, all expanded strings will be validated to
ensure that no unexpanded (but seemingly expandable) values remain. If
any unexpanded values are found, `fail()` will be called. The
validation logic is the same as
`expansion.validate_expansions_in_dict()`.
Default value is False.False(�Recursively expands all values in `source_env_dict` using the given logic / lookup data.

All keys of `source_env_dict` are returned in the resultant dict with values expanded by
location expansion logic via `expand_location` and by lookups via `resolution_dict` dict.
This function does not modify any of the given parameters.
"i
gA new dict with all key/values from `source_env_dict`, where all values have been recursively
expanded.2E
%_expand_with_manual_dict_and_location@@bazel_bats//:expansion.bzl
��� expansion.expand_with_toolchains�Recursively expands all values in `source_env_dict` using the given lookup data.

All keys of `source_env_dict` are returned in the resultant dict with values expanded by
lookups via `ctx.var` dict (unioned with optional `additional_lookup_dict` parameter).
Expansion occurs recursively through all given dicts.
This function does not modify any of the given parameters.
*�
�
 expansion.expand_with_toolchains�
ctx�(Required) The bazel context object. This is used to access the `ctx.var` member
for use as the "resolution dict". This makes use of providers from toolchains for
environment variable expansion. (�
source_env_dict�(Required) The source for all desired expansions. All key/value pairs
will appear within the returned dictionary, with all values fully
expanded by lookups in `ctx.var` and optional `additional_lookup_dict`. (v
additional_lookup_dictT(Optional) Additional dict to be used with `ctx.var` (union) for
variable expansion.None(�
validate_expansion�(Optional) If set to True, all expanded strings will be validated
to ensure that no unexpanded (but seemingly expandable) values
remain. If any unexpanded values are found, `fail()` will be
called. The validation logic is the same as
`expansion.validate_expansions_in_dict()`.
Default value is False.False(�Recursively expands all values in `source_env_dict` using the given lookup data.

All keys of `source_env_dict` are returned in the resultant dict with values expanded by
lookups via `ctx.var` dict (unioned with optional `additional_lookup_dict` parameter).
Expansion occurs recursively through all given dicts.
This function does not modify any of the given parameters.
"i
gA new dict with all key/values from `source_env_dict`, where all values have been recursively
expanded.27
_expand_with_toolchains@@bazel_bats//:expansion.bzl
���-expansion.expand_with_toolchains_and_location�Recursively expands all values in `source_env_dict` using the `ctx` logic / lookup data.

All keys of `source_env_dict` are returned in the resultant dict with values expanded by
location expansion logic via `ctx.expand_location` and by lookups via `ctx.var` dict (unioned
with optional `additional_lookup_dict` parameter).
This function does not modify any of the given parameters.
*�
�
-expansion.expand_with_toolchains_and_location�
ctx�(Required) The bazel context object. This is used to access the `ctx.var` member
for use as the "resolution dict". This makes use of providers from toolchains for
environment variable expansion. This object is also used for the
`ctx.expand_location` method to handle `$(location ...)` (and similar) expansion
logic. (�
depsx(Required) The set of targets used with `ctx.expand_location` for expanding
`$(location ...)` (and similar) expressions. (�
source_env_dict�(Required) The source for all desired expansions. All key/value pairs
will appear within the returned dictionary, with all values fully
expanded by the logic expansion logic of `expand_location` and by
lookups in `ctx.var` and optional `additional_lookup_dict`. (v
additional_lookup_dictT(Optional) Additional dict to be used with `ctx.var` (union) for
variable expansion.None(�
validate_expansion�(Optional) If set to True, all expanded strings will be validated
to ensure that no unexpanded (but seemingly expandable) values
remain. If any unexpanded values are found, `fail()` will be
called. The validation logic is the same as
`expansion.validate_expansions_in_dict()`.
Default value is False.False(�Recursively expands all values in `source_env_dict` using the `ctx` logic / lookup data.

All keys of `source_env_dict` are returned in the resultant dict with values expanded by
location expansion logic via `ctx.expand_location` and by lookups via `ctx.var` dict (unioned
with optional `additional_lookup_dict` parameter).
This function does not modify any of the given parameters.
"i
gA new dict with all key/values from `source_env_dict`, where all values have been recursively
expanded.2D
$_expand_with_toolchains_and_location@@bazel_bats//:expansion.bzl
���2expansion.expand_with_toolchains_and_location_attr�Recursively expands all values in "env" attr dict using the `ctx` logic / lookup data.

All keys of `env` attribute are returned in the resultant dict with values expanded by
location expansion logic via `ctx.expand_location` and by lookups via `ctx.var` dict (unioned
with optional `additional_lookup_dict` parameter).
This function does not modify any of the given parameters.
*�
�
2expansion.expand_with_toolchains_and_location_attr�
ctx�(Required) The bazel context object. This is used to access the `ctx.var` member
for use as the "resolution dict". This makes use of providers from toolchains for
environment variable expansion. This object is also used for the
`ctx.expand_location` method to handle `$(location ...)` (and similar) expansion
logic. This object is also used to retrieve various necessary attributes via
`ctx.attr.<attr_name>`. (�
deps_attr_name�(Optional) The name of the attribute which contains the set of targets used
with `ctx.expand_location` for expanding `$(location ...)` (and similar)
expressions.
Default value is "deps"."deps"(�
env_attr_name�(Optional) The name of the attribute that is used as the source for all
desired expansions. All key/value pairs will appear within the returned
dictionary, with all values fully expanded by lookups in `ctx.var` and
optional `additional_lookup_dict`.
Default value is "env"."env"(v
additional_lookup_dictT(Optional) Additional dict to be used with `ctx.var` (union) for
variable expansion.None(�
validate_expansion�(Optional) If set to True, all expanded strings will be validated
to ensure that no unexpanded (but seemingly expandable) values
remain. If any unexpanded values are found, `fail()` will be
called. The validation logic is the same as
`expansion.validate_expansions_in_dict()`.
Default value is False.False(�Recursively expands all values in "env" attr dict using the `ctx` logic / lookup data.

All keys of `env` attribute are returned in the resultant dict with values expanded by
location expansion logic via `ctx.expand_location` and by lookups via `ctx.var` dict (unioned
with optional `additional_lookup_dict` parameter).
This function does not modify any of the given parameters.
"�
�A new dict with all key/values from source attribute (default "env" attribute), where all
values have been recursively expanded.2I
)_expand_with_toolchains_and_location_attr@@bazel_bats//:expansion.bzl
���%expansion.expand_with_toolchains_attr�Recursively expands all values in "env" attr dict using the `ctx` lookup data.

All keys of `env` attribute are returned in the resultant dict with values expanded by
lookups via `ctx.var` dict (unioned with optional `additional_lookup_dict` parameter).
The attribute used can be changed (instead of `env`) via the optional `env_attr_name` paramter.
This function does not modify any of the given parameters.
*�
�
%expansion.expand_with_toolchains_attr�
ctx�(Required) The bazel context object. This is used to access the `ctx.var` member
for use as the "resolution dict". This makes use of providers from toolchains for
environment variable expansion. This object is also used to retrieve various
necessary attributes via `ctx.attr.<attr_name>`. (�
env_attr_name�(Optional) The name of the attribute that is used as the source for all
desired expansions. All key/value pairs will appear within the returned
dictionary, with all values fully expanded by lookups in `ctx.var` and
optional `additional_lookup_dict`.
Default value is "env"."env"(v
additional_lookup_dictT(Optional) Additional dict to be used with `ctx.var` (union) for
variable expansion.None(�
validate_expansion�(Optional) If set to True, all expanded strings will be validated
to ensure that no unexpanded (but seemingly expandable) values
remain. If any unexpanded values are found, `fail()` will be
called. The validation logic is the same as
`expansion.validate_expansions_in_dict()`.
Default value is False.False(�Recursively expands all values in "env" attr dict using the `ctx` lookup data.

All keys of `env` attribute are returned in the resultant dict with values expanded by
lookups via `ctx.var` dict (unioned with optional `additional_lookup_dict` parameter).
The attribute used can be changed (instead of `env`) via the optional `env_attr_name` paramter.
This function does not modify any of the given parameters.
"�
�A new dict with all key/values from source attribute (default "env" attribute), where all
values have been recursively expanded.2<
_expand_with_toolchains_attr@@bazel_bats//:expansion.bzl
���expansion.validate_expansions�Validates all given strings to no longer have unexpanded expressions.

Validates all expanded strings in `expanded_values` to ensure that no unexpanded (but seemingly
expandable) values remain.
Any unterminated or unexpanded expressions of the form `$VAR`, $(VAR)`, or `${VAR}` will result
in an error (with fail message).
*�
�
expansion.validate_expansionsD
expanded_values-(Required) List of string values to validate. (�
fail_instead_of_return�(Optional) If set to True, `fail()` will be called upon first
invalid (unexpanded) value found. If set to False, error
messages will be collected and returned (no failure will
occur); it will be the caller's responsibility to check the
returned list.
Default value is True.True(�Validates all given strings to no longer have unexpanded expressions.

Validates all expanded strings in `expanded_values` to ensure that no unexpanded (but seemingly
expandable) values remain.
Any unterminated or unexpanded expressions of the form `$VAR`, $(VAR)`, or `${VAR}` will result
in an error (with fail message).
"�
�A list with all found invalid (unexpanded) values. Will be an empty list if all values are
completely expanded. This function will not return if there were unexpanded substrings and if
`fail_instead_of_return` is set to True (due to `fail()` being called).24
_validate_expansions@@bazel_bats//:expansion.bzl
���
	expansion�
Module containing functions that aid in environment variable expansion.

This could be replaced with the same impl via Skylib dependency, if/when PR is merged.
See https://github.com/bazelbuild/bazel-skylib/pull/486.
z�
	expansion
���
Module containing functions that aid in environment variable expansion.

This could be replaced with the same impl via Skylib dependency, if/when PR is merged.
See https://github.com/bazelbuild/bazel-skylib/pull/486.
"f
expand_with_manual_dict
��_expand_with_manual_dict"!expansion.expand_with_manual_dict"�
$expand_with_manual_dict_and_location
��%_expand_with_manual_dict_and_location".expansion.expand_with_manual_dict_and_location"c
expand_with_toolchains
��_expand_with_toolchains" expansion.expand_with_toolchains"r
expand_with_toolchains_attr
��_expand_with_toolchains_attr"%expansion.expand_with_toolchains_attr"�
#expand_with_toolchains_and_location
��$_expand_with_toolchains_and_location"-expansion.expand_with_toolchains_and_location"�
(expand_with_toolchains_and_location_attr
��)_expand_with_toolchains_and_location_attr"2expansion.expand_with_toolchains_and_location_attr"Z
validate_expansions
��_validate_expansions"expansion.validate_expansions*@@bazel_bats//:expansion.bzl�
Module containing functions that aid in environment variable expansion.

This could be replaced with the same impl via Skylib dependency, if/when PR is merged.
See https://github.com/bazelbuild/bazel-skylib/pull/486.
�


bazel_batsextensions.bzl�
bazel_bats_depsJ�

�
bazel_bats_deps�
	bats_core:
sha256*The sha256 hash of the dependency archive.2"";
version*The version of the dependency to download.2""�
bats_assert:
sha256*The sha256 hash of the dependency archive.2"";
version*The version of the dependency to download.2""�
bats_support:
sha256*The sha256 hash of the dependency archive.2"";
version*The version of the dependency to download.2"""0
bazel_bats_deps@@bazel_bats//:extensions.bzl
*#*#�
�
	bats_core:
sha256*The sha256 hash of the dependency archive.2"";
version*The version of the dependency to download.2""<
:
sha256*The sha256 hash of the dependency archive.2""=
;
version*The version of the dependency to download.2""�
�
bats_assert:
sha256*The sha256 hash of the dependency archive.2"";
version*The version of the dependency to download.2""<
:
sha256*The sha256 hash of the dependency archive.2""=
;
version*The version of the dependency to download.2""�
�
bats_support:
sha256*The sha256 hash of the dependency archive.2"";
version*The version of the dependency to download.2""<
:
sha256*The sha256 hash of the dependency archive.2""=
;
version*The version of the dependency to download.2""w
	:deps.bzlrh


bazel_batsdeps.bzl@
bazel_bats_dependenciesbazel_bats_dependencies
!8
:�
 //tools/build_defs/repo:http.bzlrj
.
bazel_toolstools/build_defs/repohttp.bzl*
http_archivehttp_archive
7C
E�
!//tools/build_defs/repo:utils.bzlr]
/
bazel_toolstools/build_defs/repo	utils.bzl
maybemaybe
8=
?�


bazel_bats	rules.bzl�	bats_test�A rule for creating a test target for running one or more `*.bats` test files.

This rule can run one or more bats files, utilizing the `bats-core` framework. Optionally,
`bats-assert` (extension library) can be used for these tests.

`bats_test()` is a macro that handles proper target definition internally.


Runs a BATS test on the supplied source files."�
�
	bats_test�A rule for creating a test target for running one or more `*.bats` test files.

This rule can run one or more bats files, utilizing the `bats-core` framework. Optionally,
`bats-assert` (extension library) can be used for these tests.

`bats_test()` is a macro that handles proper target definition internally.


Runs a BATS test on the supplied source files.*
nameA unique name for this target. 5
	bats_args"List of arguments passed to `bats`2[]5
data'List of data dependencies for the test.2[]6
deps(List of other dependencies for the test.2[]I
env<A list of key-value pairs of environment variables to define
2{}0
srcs"Source files to run a BATS test on2[]"&

_bats_test@@bazel_bats//:rules.bzl
��,
*
nameA unique name for this target. 7
5
	bats_args"List of arguments passed to `bats`2[]7
5
data'List of data dependencies for the test.2[]8
6
deps(List of other dependencies for the test.2[]K
I
env<A list of key-value pairs of environment variables to define
2{}2
0
srcs"Source files to run a BATS test on2[]�bats_test_suite�A rule for creating a test suite for a set of `bats_test` targets.

The rule can be used to generate `bats_test` targets for each source file and a `test_suite`
which encapsulates all tests.
b�
�
�
bats_test_suite)
nameThe name of the `test_suite`. (;
srcs/All test sources, typically `glob(["*.bats"])`. (�
kwargs�Additional keyword arguments for the underyling `bats_test` targets. The
`tags` argument is also passed to the generated `test_suite` target.(�A rule for creating a test suite for a set of `bats_test` targets.

The rule can be used to generate `bats_test` targets for each source file and a `test_suite`
which encapsulates all tests.
2+
bats_test_suite@@bazel_bats//:rules.bzl
��"	bats_test*	bats_test2native.test_suite�
�
	bats_test�A rule for creating a test target for running one or more `*.bats` test files.

This rule can run one or more bats files, utilizing the `bats-core` framework. Optionally,
`bats-assert` (extension library) can be used for these tests.

`bats_test()` is a macro that handles proper target definition internally.


Runs a BATS test on the supplied source files.*
nameA unique name for this target. 5
	bats_args"List of arguments passed to `bats`2[]5
data'List of data dependencies for the test.2[]6
deps(List of other dependencies for the test.2[]I
env<A list of key-value pairs of environment variables to define
2{}0
srcs"Source files to run a BATS test on2[]"&

_bats_test@@bazel_bats//:rules.bzl,
*
nameA unique name for this target. 7
5
	bats_args"List of arguments passed to `bats`2[]7
5
data'List of data dependencies for the test.2[]8
6
deps(List of other dependencies for the test.2[]K
I
env<A list of key-value pairs of environment variables to define
2{}2
0
srcs"Source files to run a BATS test on2[]e
:expansion.bzlrQ


bazel_batsexpansion.bzl$
	expansion	expansion
&/
1 