V
@@bazel_bats//D/home/sol/.bazel/execroot/_main/work/external/bazel_bats/BUILD.bazel 