��
%
bazel_cc_metacc_metacc_meta.bzl�&make_cc_meta_deviations�Make a set of deviations for targets to be treated differently.

Using this rule, special-cases can be created for various reasons.
See the "known issues" section of the README.md for examples of when it might be
necessary to treat certain targets differently.

The deviations are structured as a dictionary of dictionaries. The top-level
key is the Label of target to which the deviations should be applied.
A deviation set is dictionary that can contain a few elements (all optional):

 - "exports": a list of include paths that should be added to the set of include
              paths that cc_meta discovered for that target. This can be used for
              false-negatives, unusual include path specifications or deeply-wrapped
              targets.
 - "alwaysused": a bool to signal that this target should always be considered as
                 used, even if the dependent is not including any of its headers. By
                 default, targets with the attribute "alwayslink = True" will be
                 considered used. In some cases, with wrapped targets for example,
                 it might be required to externally mark additional targets as used.
                 Adding 'alwayslink = True' to a target has the same effect.
 - "forward_exports": a bool to signal that this target should be considered as
                      exporting all of its direct dependencies' exports. Note that
                      this is not recursive, it only forwards direct exports. Applying
                      this rule recursively is fraught with issues, so that option does
                      not exist (sorry).
                      Adding "cc_meta_forward_exports" to a target's 'tags' attribute
                      has the same effect (preferred, if possible).
 - "skip": a bool to signal that this target should not be analyzed. Note, however, that
           the other deviations will still be applied. In other words, listing "exports"
           and setting "skip" to true results that target not being analyzed but having
           that specific set of exports (only). Similarly, in conjunction with
           "forward_exports", the target would have only its direct dependencies' exports.
           Adding "cc_meta_skip" to a target's 'tags' attribute has the same effect
           (preferred, if possible).
"�
�
make_cc_meta_deviations�Make a set of deviations for targets to be treated differently.

Using this rule, special-cases can be created for various reasons.
See the "known issues" section of the README.md for examples of when it might be
necessary to treat certain targets differently.

The deviations are structured as a dictionary of dictionaries. The top-level
key is the Label of target to which the deviations should be applied.
A deviation set is dictionary that can contain a few elements (all optional):

 - "exports": a list of include paths that should be added to the set of include
              paths that cc_meta discovered for that target. This can be used for
              false-negatives, unusual include path specifications or deeply-wrapped
              targets.
 - "alwaysused": a bool to signal that this target should always be considered as
                 used, even if the dependent is not including any of its headers. By
                 default, targets with the attribute "alwayslink = True" will be
                 considered used. In some cases, with wrapped targets for example,
                 it might be required to externally mark additional targets as used.
                 Adding 'alwayslink = True' to a target has the same effect.
 - "forward_exports": a bool to signal that this target should be considered as
                      exporting all of its direct dependencies' exports. Note that
                      this is not recursive, it only forwards direct exports. Applying
                      this rule recursively is fraught with issues, so that option does
                      not exist (sorry).
                      Adding "cc_meta_forward_exports" to a target's 'tags' attribute
                      has the same effect (preferred, if possible).
 - "skip": a bool to signal that this target should not be analyzed. Note, however, that
           the other deviations will still be applied. In other words, listing "exports"
           and setting "skip" to true results that target not being analyzed but having
           that specific set of exports (only). Similarly, in conjunction with
           "forward_exports", the target would have only its direct dependencies' exports.
           Adding "cc_meta_skip" to a target's 'tags' attribute has the same effect
           (preferred, if possible).
*
nameA unique name for this target. 

deviations	2{}"@
_make_cc_meta_deviations$@@bazel_cc_meta//cc_meta:cc_meta.bzl
33,
*
nameA unique name for this target. 


deviations	2{}Ȟrefresh_cc_meta#Create a C++ metadata refresh rule."��
�N
refresh_cc_meta#Create a C++ metadata refresh rule.*
nameA unique name for this target. �	
config_settings�	
Config settings to change for this target.

The keys are labels for settings, and the values are strings for the new value
to use. Pass `Label` objects or canonical label strings for the keys to ensure
they resolve as expected (canonical labels start with `@@` and can be
obtained by calling `str(Label(...))`).

Most `@rules_python//python/config_setting` settings can be used here, which
allows, for example, making only a certain `py_binary` use
{obj}`--boostrap_impl=script`.

Additional or custom config settings can be registered using the
{obj}`add_transition_setting` API. This allows, for example, forcing a
particular CPU, or defining a custom setting that `select()` uses elsewhere
to pick between `pip.parse` hubs. See the [How to guide on multiple
versions of a library] for a more concrete example.

:::{note}
These values are transitioned on, so will affect the analysis graph and the
associated memory overhead. The more unique configurations in your overall
build, the more memory and (often unnecessary) re-analysis and re-building
can occur. See
https://bazel.build/extending/config#memory-performance-considerations for
more information about risks and considerations.
:::

:::{versionadded} 1.7.0
:::
	2{}�
data�
The list of files need by this library at runtime. See comments about
the [`data` attribute typically defined by rules](https://bazel.build/reference/be/common-definitions#typical-attributes).

There is no `py_embed_data` like there is `cc_embed_data` and `go_embed_data`.
This is because Python has a concept of runtime resources.
2[]�
deps�
List of additional libraries to be linked in to the target.
See comments about
the [`deps` attribute typically defined by
rules](https://bazel.build/reference/be/common-definitions#typical-attributes).
These are typically `py_library` rules.

Targets that only provide data files used at runtime belong in the `data`
attribute.

:::{note}
The order of this list can matter because it affects the order that information
from dependencies is merged in, which can be relevant depending on the ordering
mode of depsets that are merged.

* {obj}`PyInfo.venv_symlinks` uses default ordering.

See {obj}`PyInfo` for more information about the ordering of its depsets and
how its fields are merged.
:::
*
PyInfo*
CcInfo*
BuiltinPyInfo2[]
distribs2[]�
env�Dictionary of strings; optional; values are subject to `$(location)` and "Make
variable" substitution.

Specifies additional environment variables to set when the target is executed by
`test` or `run`.

2{}�
imports�
List of import directories to be added to the PYTHONPATH.

Subject to "Make variable" substitution. These import directories will be added
for this rule and all rules that depend on it (note: not the rules this rule
depends on. Each directory will be added to `PYTHONPATH` by `py_binary` rules
that depend on this rule. The strings are repo-runfiles-root relative,

Absolute paths (paths that start with `/`) and paths that references a path
above the execution root are not allowed and will result in an error.
2[]�
interpreter_args�
Arguments that are only applicable to the interpreter.

The args an interpreter supports are specific to the interpreter. For
CPython, see https://docs.python.org/3/using/cmdline.html.

:::{note}
Only supported for {obj}`--bootstrap_impl=script`. Ignored otherwise.
:::

:::{seealso}
The {any}`RULES_PYTHON_ADDITIONAL_INTERPRETER_ARGS` environment variable
:::

:::{versionadded} 1.3.0
:::
2[]�
legacy_create_init�Whether to implicitly create empty `__init__.py` files in the runfiles tree.
These are created in every directory containing Python source code or shared
libraries, and every parent directory of those directories, excluding the repo
root directory. The default, `-1` (auto), means true unless
`--incompatible_default_to_explicit_init_py` is used. If false, the user is
responsible for creating (possibly empty) `__init__.py` files and adding them to
the `srcs` of Python targets as required.
2-1
licenses2[]�
main�Optional; the name of the source file that is the main entry point of the
application. This file must also be listed in `srcs`. If left unspecified,
`name`, with `.py` appended, is used instead. If `name` does not match any
filename in `srcs`, `main` must be specified.

This is mutually exclusive with {obj}`main_module`.
2None�
main_module�
Module name to execute as the main program.

When set, `srcs` is not required, and it is assumed the module is
provided by a dependency.

See https://docs.python.org/3/using/cmdline.html#cmdoption-m for more
information about running modules as the main program.

This is mutually exclusive with {obj}`main`.

:::{versionadded} 1.3.0
:::
:::{versionchanged} 1.7.0
Support added for {obj}`--bootstrap_impl=system_python`.
:::
2""�

precompile�
Whether py source files **for this target** should be precompiled.

Values:

* `inherit`: Allow the downstream binary decide if precompiled files are used.
* `enabled`: Compile Python source files at build time.
* `disabled`: Don't compile Python source files at build time.

:::{seealso}

* The {flag}`--precompile` flag, which can override this attribute in some cases
  and will affect all targets when building.
* The {obj}`pyc_collection` attribute for transitively enabling precompiling on
  a per-target basis.
* The [Precompiling](precompiling) docs for a guide about using precompiling.
:::
2	"inherit"�
precompile_invalidation_mode�
How precompiled files should be verified to be up-to-date with their associated
source files. Possible values are:
* `auto`: The effective value will be automatically determined by other build
  settings.
* `checked_hash`: Use the pyc file if the hash of the source file matches the hash
  recorded in the pyc file. This is most useful when working with code that
  you may modify.
* `unchecked_hash`: Always use the pyc file; don't check the pyc's hash against
  the source file. This is most useful when the code won't be modified.

For more information on pyc invalidation modes, see
https://docs.python.org/3/library/py_compile.html#py_compile.PycInvalidationMode
2"auto"�
precompile_optimize_level�
The optimization level for precompiled files.

For more information about optimization levels, see the `compile()` function's
`optimize` arg docs at https://docs.python.org/3/library/functions.html#compile

NOTE: The value `-1` means "current interpreter", which will be the interpreter
used _at build time when pycs are generated_, not the interpreter used at
runtime when the code actually runs.
20�
precompile_source_retention�
Determines, when a source file is compiled, if the source file is kept
in the resulting output or not. Valid values are:

* `inherit`: Inherit the value from the {flag}`--precompile_source_retention` flag.
* `keep_source`: Include the original Python source.
* `omit_source`: Don't include the original py source.
2	"inherit"�
pyc_collection�
Determines whether pyc files from dependencies should be manually included.

Valid values are:
* `inherit`: Inherit the value from {flag}`--precompile`.
* `include_pyc`: Add implicitly generated pyc files from dependencies. i.e.
  pyc files for targets that specify {attr}`precompile="inherit"`.
* `disabled`: Don't add implicitly generated pyc files. Note that
  pyc files may still come from dependencies that enable precompiling at the
  target level.
2	"inherit"�
pyi_deps�
Dependencies providing type definitions the library needs.

These are dependencies that satisfy imports guarded by `typing.TYPE_CHECKING`.
These are build-time only dependencies and not included as part of a runnable
program (packaging rules may include them, however).

:::{versionadded} 1.1.0
:::
*
PyInfo*
CcInfo*
BuiltinPyInfo2[]�
pyi_srcs�
Type definition files for the library.

These are typically `.pyi` files, but other file types for type-checker specific
formats are allowed. These files are build-time only dependencies and not included
as part of a runnable program (packaging rules may include them, however).

:::{versionadded} 1.1.0
:::
2[]�
python_version�
The Python version this target should use.

The value should be in `X.Y` or `X.Y.Z` (or compatible) format. If empty or
unspecified, the incoming configuration's {obj}`--python_version` flag is
inherited. For backwards compatibility, the values `PY2` and `PY3` are
accepted, but treated as an empty/unspecified value.

:::{note}
In order for the requested version to be used, there must be a
toolchain configured to match the Python version. If there isn't, then it
may be silently ignored, or an error may occur, depending on the toolchain
configuration.
:::

:::{versionchanged} 1.1.0

This attribute was changed from only accepting `PY2` and `PY3` values to
accepting arbitrary Python versions.
:::
2""�
srcs�
The list of Python source files that are processed to create the target. This
includes all your checked-in code and may include generated source files.  The
`.py` files belong in `srcs` and library targets belong in `deps`. Other binary
files that may be needed at run time belong in `data`.
2[]4
srcs_versionDefunct, unused, does nothing.2""�
stamp�
Whether to encode build information into the binary. Possible values:

* `stamp = 1`: Always stamp the build information into the binary, even in
  `--nostamp` builds. **This setting should be avoided**, since it potentially kills
  remote caching for the binary and any downstream actions that depend on it.
* `stamp = 0`: Always replace build information by constant values. This gives
  good build result caching.
* `stamp = -1`: Embedding of build information is controlled by the
  `--[no]stamp` flag.

Stamped binaries are not rebuilt unless their dependencies change.

WARNING: Stamping can harm build performance by reducing cache hits and should
be avoided if possible.
2-1
��,
*
nameA unique name for this target. �	
�	
config_settings�	
Config settings to change for this target.

The keys are labels for settings, and the values are strings for the new value
to use. Pass `Label` objects or canonical label strings for the keys to ensure
they resolve as expected (canonical labels start with `@@` and can be
obtained by calling `str(Label(...))`).

Most `@rules_python//python/config_setting` settings can be used here, which
allows, for example, making only a certain `py_binary` use
{obj}`--boostrap_impl=script`.

Additional or custom config settings can be registered using the
{obj}`add_transition_setting` API. This allows, for example, forcing a
particular CPU, or defining a custom setting that `select()` uses elsewhere
to pick between `pip.parse` hubs. See the [How to guide on multiple
versions of a library] for a more concrete example.

:::{note}
These values are transitioned on, so will affect the analysis graph and the
associated memory overhead. The more unique configurations in your overall
build, the more memory and (often unnecessary) re-analysis and re-building
can occur. See
https://bazel.build/extending/config#memory-performance-considerations for
more information about risks and considerations.
:::

:::{versionadded} 1.7.0
:::
	2{}�
�
data�
The list of files need by this library at runtime. See comments about
the [`data` attribute typically defined by rules](https://bazel.build/reference/be/common-definitions#typical-attributes).

There is no `py_embed_data` like there is `cc_embed_data` and `go_embed_data`.
This is because Python has a concept of runtime resources.
2[]�
�
deps�
List of additional libraries to be linked in to the target.
See comments about
the [`deps` attribute typically defined by
rules](https://bazel.build/reference/be/common-definitions#typical-attributes).
These are typically `py_library` rules.

Targets that only provide data files used at runtime belong in the `data`
attribute.

:::{note}
The order of this list can matter because it affects the order that information
from dependencies is merged in, which can be relevant depending on the ordering
mode of depsets that are merged.

* {obj}`PyInfo.venv_symlinks` uses default ordering.

See {obj}`PyInfo` for more information about the ordering of its depsets and
how its fields are merged.
:::
*
PyInfo*
CcInfo*
BuiltinPyInfo2[]

distribs2[]�
�
env�Dictionary of strings; optional; values are subject to `$(location)` and "Make
variable" substitution.

Specifies additional environment variables to set when the target is executed by
`test` or `run`.

2{}�
�
imports�
List of import directories to be added to the PYTHONPATH.

Subject to "Make variable" substitution. These import directories will be added
for this rule and all rules that depend on it (note: not the rules this rule
depends on. Each directory will be added to `PYTHONPATH` by `py_binary` rules
that depend on this rule. The strings are repo-runfiles-root relative,

Absolute paths (paths that start with `/`) and paths that references a path
above the execution root are not allowed and will result in an error.
2[]�
�
interpreter_args�
Arguments that are only applicable to the interpreter.

The args an interpreter supports are specific to the interpreter. For
CPython, see https://docs.python.org/3/using/cmdline.html.

:::{note}
Only supported for {obj}`--bootstrap_impl=script`. Ignored otherwise.
:::

:::{seealso}
The {any}`RULES_PYTHON_ADDITIONAL_INTERPRETER_ARGS` environment variable
:::

:::{versionadded} 1.3.0
:::
2[]�
�
legacy_create_init�Whether to implicitly create empty `__init__.py` files in the runfiles tree.
These are created in every directory containing Python source code or shared
libraries, and every parent directory of those directories, excluding the repo
root directory. The default, `-1` (auto), means true unless
`--incompatible_default_to_explicit_init_py` is used. If false, the user is
responsible for creating (possibly empty) `__init__.py` files and adding them to
the `srcs` of Python targets as required.
2-1

licenses2[]�
�
main�Optional; the name of the source file that is the main entry point of the
application. This file must also be listed in `srcs`. If left unspecified,
`name`, with `.py` appended, is used instead. If `name` does not match any
filename in `srcs`, `main` must be specified.

This is mutually exclusive with {obj}`main_module`.
2None�
�
main_module�
Module name to execute as the main program.

When set, `srcs` is not required, and it is assumed the module is
provided by a dependency.

See https://docs.python.org/3/using/cmdline.html#cmdoption-m for more
information about running modules as the main program.

This is mutually exclusive with {obj}`main`.

:::{versionadded} 1.3.0
:::
:::{versionchanged} 1.7.0
Support added for {obj}`--bootstrap_impl=system_python`.
:::
2""�
�

precompile�
Whether py source files **for this target** should be precompiled.

Values:

* `inherit`: Allow the downstream binary decide if precompiled files are used.
* `enabled`: Compile Python source files at build time.
* `disabled`: Don't compile Python source files at build time.

:::{seealso}

* The {flag}`--precompile` flag, which can override this attribute in some cases
  and will affect all targets when building.
* The {obj}`pyc_collection` attribute for transitively enabling precompiling on
  a per-target basis.
* The [Precompiling](precompiling) docs for a guide about using precompiling.
:::
2	"inherit"�
�
precompile_invalidation_mode�
How precompiled files should be verified to be up-to-date with their associated
source files. Possible values are:
* `auto`: The effective value will be automatically determined by other build
  settings.
* `checked_hash`: Use the pyc file if the hash of the source file matches the hash
  recorded in the pyc file. This is most useful when working with code that
  you may modify.
* `unchecked_hash`: Always use the pyc file; don't check the pyc's hash against
  the source file. This is most useful when the code won't be modified.

For more information on pyc invalidation modes, see
https://docs.python.org/3/library/py_compile.html#py_compile.PycInvalidationMode
2"auto"�
�
precompile_optimize_level�
The optimization level for precompiled files.

For more information about optimization levels, see the `compile()` function's
`optimize` arg docs at https://docs.python.org/3/library/functions.html#compile

NOTE: The value `-1` means "current interpreter", which will be the interpreter
used _at build time when pycs are generated_, not the interpreter used at
runtime when the code actually runs.
20�
�
precompile_source_retention�
Determines, when a source file is compiled, if the source file is kept
in the resulting output or not. Valid values are:

* `inherit`: Inherit the value from the {flag}`--precompile_source_retention` flag.
* `keep_source`: Include the original Python source.
* `omit_source`: Don't include the original py source.
2	"inherit"�
�
pyc_collection�
Determines whether pyc files from dependencies should be manually included.

Valid values are:
* `inherit`: Inherit the value from {flag}`--precompile`.
* `include_pyc`: Add implicitly generated pyc files from dependencies. i.e.
  pyc files for targets that specify {attr}`precompile="inherit"`.
* `disabled`: Don't add implicitly generated pyc files. Note that
  pyc files may still come from dependencies that enable precompiling at the
  target level.
2	"inherit"�
�
pyi_deps�
Dependencies providing type definitions the library needs.

These are dependencies that satisfy imports guarded by `typing.TYPE_CHECKING`.
These are build-time only dependencies and not included as part of a runnable
program (packaging rules may include them, however).

:::{versionadded} 1.1.0
:::
*
PyInfo*
CcInfo*
BuiltinPyInfo2[]�
�
pyi_srcs�
Type definition files for the library.

These are typically `.pyi` files, but other file types for type-checker specific
formats are allowed. These files are build-time only dependencies and not included
as part of a runnable program (packaging rules may include them, however).

:::{versionadded} 1.1.0
:::
2[]�
�
python_version�
The Python version this target should use.

The value should be in `X.Y` or `X.Y.Z` (or compatible) format. If empty or
unspecified, the incoming configuration's {obj}`--python_version` flag is
inherited. For backwards compatibility, the values `PY2` and `PY3` are
accepted, but treated as an empty/unspecified value.

:::{note}
In order for the requested version to be used, there must be a
toolchain configured to match the Python version. If there isn't, then it
may be silently ignored, or an error may occur, depending on the toolchain
configuration.
:::

:::{versionchanged} 1.1.0

This attribute was changed from only accepting `PY2` and `PY3` values to
accepting arbitrary Python versions.
:::
2""�
�
srcs�
The list of Python source files that are processed to create the target. This
includes all your checked-in code and may include generated source files.  The
`.py` files belong in `srcs` and library targets belong in `deps`. Other binary
files that may be needed at run time belong in `data`.
2[]6
4
srcs_versionDefunct, unused, does nothing.2""�
�
stamp�
Whether to encode build information into the binary. Possible values:

* `stamp = 1`: Always stamp the build information into the binary, even in
  `--nostamp` builds. **This setting should be avoided**, since it potentially kills
  remote caching for the binary and any downstream actions that depend on it.
* `stamp = 0`: Always replace build information by constant values. This gives
  good build result caching.
* `stamp = -1`: Embedding of build information is controlled by the
  `--[no]stamp` flag.

Stamped binaries are not rebuilt unless their dependencies change.

WARNING: Stamping can harm build performance by reducing cache hits and should
be avoided if possible.
2-1�cc_meta_aspect_factory�Create a C++ metadata aspect to gather information about C++ sources.

Use the factory in a `.bzl` file to instantiate an aspect:
```starlark
load("@bazel_cc_meta//cc_meta:cc_meta.bzl", "cc_meta_aspect_factory")

your_cc_meta_aspect = cc_meta_aspect_factory(<aspect_options>)
```
*�
�
cc_meta_aspect_factoryG

deviations3List of targets created by make_cc_meta_deviations.[](2
skipped_tagsList of string tags to skip.[](�Create a C++ metadata aspect to gather information about C++ sources.

Use the factory in a `.bzl` file to instantiate an aspect:
```starlark
load("@bazel_cc_meta//cc_meta:cc_meta.bzl", "cc_meta_aspect_factory")

your_cc_meta_aspect = cc_meta_aspect_factory(<aspect_options>)
```
2>
cc_meta_aspect_factory$@@bazel_cc_meta//cc_meta:cc_meta.bzl
���CcMetaDeviationsInfoODeviations for targets to be treated differently (see make_cc_meta_deviations).2�
�
CcMetaDeviationsInfoODeviations for targets to be treated differently (see make_cc_meta_deviations).E

deviations7Dictionary with structure { target_label: json-string }"<
CcMetaDeviationsInfo$@@bazel_cc_meta//cc_meta:cc_meta.bzl
  G
E

deviations7Dictionary with structure { target_label: json-string }�
CcMetaInfo&Metadata information about cc targets.2�
�

CcMetaInfo&Metadata information about cc targets.2
compile_commands_jsoncompile_command.json file3
deps_issues_jsonissues with target dependencies1
direct_exportsinclude paths of public headers6
direct_exports_jsoninclude paths of public headers0
direct_imports_jsondirect includes json file"2

CcMetaInfo$@@bazel_cc_meta//cc_meta:cc_meta.bzl
4
2
compile_commands_jsoncompile_command.json file5
3
deps_issues_jsonissues with target dependencies3
1
direct_exportsinclude paths of public headers8
6
direct_exports_jsoninclude paths of public headers2
0
direct_imports_jsondirect includes json filey
//lib:collections.bzlr^
$
bazel_skyliblibcollections.bzl(
collectionscollections
-8
:a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.�
//cc:action_names.bzlr�
 
rules_ccccaction_names.bzl:
ASSEMBLE_ACTION_NAMEASSEMBLE_ACTION_NAME
)=@
CPP_COMPILE_ACTION_NAMECPP_COMPILE_ACTION_NAME
AX<
C_COMPILE_ACTION_NAMEC_COMPILE_ACTION_NAME
\qG
OBJCPP_COMPILE_ACTION_NAMEOBJCPP_COMPILE_ACTION_NAME
u�D
OBJC_COMPILE_ACTION_NAMEOBJC_COMPILE_ACTION_NAME
��R
PREPROCESS_ASSEMBLE_ACTION_NAMEPREPROCESS_ASSEMBLE_ACTION_NAME
��
�[
//cc:defs.bzlrH

rules_ccccdefs.bzl
CcInfoCcInfo
!'
)�
//cc:find_cc_toolchain.bzlr�
%
rules_ccccfind_cc_toolchain.bzl6
find_cpp_toolchainfind_cpp_toolchain
.@2
use_cc_toolchainuse_cc_toolchain
DT
Vy
//cc/common:cc_common.bzlrZ
$
rules_cc	cc/commoncc_common.bzl$
	cc_common	cc_common
-6
8m
//python:defs.bzlrV
 
rules_pythonpythondefs.bzl$
	py_binary	py_binary
	)	2
		4'Some aspects for the cc_meta extraction�
5
bazel_cc_metaexamples/custom_deviationsdefs.bzl�custom_cc_meta_aspect:�
�
custom_cc_meta_aspectdeps"*
nameA unique name for this target. *M
custom_cc_meta_aspect4@@bazel_cc_meta//examples/custom_deviations:defs.bzl
��,
*
nameA unique name for this target. �
//cc_meta:cc_meta.bzlru
%
bazel_cc_metacc_metacc_meta.bzl>
cc_meta_aspect_factorycc_meta_aspect_factory
.D
F.Bazel module to create a custom cc_meta aspect�

bazel_cc_metadefs.bzl�default_cc_meta_aspect:�
�
default_cc_meta_aspectdeps"*
nameA unique name for this target. *4
default_cc_meta_aspect@@bazel_cc_meta//:defs.bzl
��,
*
nameA unique name for this target. �
//cc_meta:cc_meta.bzlru
%
bazel_cc_metacc_metacc_meta.bzl>
cc_meta_aspect_factorycc_meta_aspect_factory
.D
F)Some common rules for the roci repository 