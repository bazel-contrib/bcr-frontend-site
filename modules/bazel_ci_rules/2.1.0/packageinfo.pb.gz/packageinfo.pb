X
@@bazel_ci_rules//B/home/sol/.bazel/execroot/_main/work/external/bazel_ci_rules/BUILD 