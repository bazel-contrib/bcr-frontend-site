�8

bazel_env.bzlbazel_env.bzl�8	bazel_env�Makes Bazel-managed tools and toolchains available under stable paths.

Build this target to make the given tools and toolchains available under stable,
platform-independent paths:

* tools are staged in `bazel-out/bazel_env-opt/bin/path/to/pkg/name/bin`
* toolchains are staged in `bazel-out/bazel_env-opt/bin/path/to/pkg/name/toolchains`

The `bin` directory is regenerated as a whole on each build, so tools removed from `tools`
also disappear from `PATH` with the next build.

Run this target with `bazel run` for instructions on how to make the tools available on `PATH`
using [`direnv`](https://direnv.net/). This also prints a list of all tools and toolchains.
*�2
�
	bazel_env!
nameThe name of the rule. (�
tools�A dictionary mapping tool names to their targets or paths. The name is used as the
basename of the tool in the `bin` directory and will be available on `PATH`.

If a target is provided, the corresponding executable is staged in the `bin` directory
together with its runfiles.

If a path is provided, Make variables provided by `toolchains` are expanded in it and
all the files of referenced toolchains are staged as runfiles. If a referenced toolchain
is a C++ toolchain, the tool runs with the environment Bazel sets for its compile
actions, which compiler wrappers such as the one of the Apple C++ toolchain require.{}(�

toolchains�A dictionary mapping toolchain names to their targets. The name is used as the
basename of the toolchain directory in the `toolchains` directory. The directory is
a symlink to the repository root of the (single) repository containing the toolchain.

With Bazel 9.0.0-pre.20250311.1 and later, toolchain_type targets can be used directly.
In older versions, use a "resolved" toolchain target such as
`@bazel_tools//tools/cpp:current_cc_toolchain` instead.{}(�

watch_dirs�A dictionary mapping tool names to directories that will be monitored by
`bazel_env`. When any file within these directories changes, it triggers
a rebuild of `bazel_env`. Paths are relative to the workspace root.

Use the tool name "_common" for directories which are common to all tools.

This attribute is fully optional. It allows you to provide a heuristic
set of directories that approximates what Bazel tracks during the
analysis phase. This can significantly improve performance,
at the cost of manually maintaining the directory list.

When changes are detected, a message will be displayed listing the changed
files (marked as "modified" or "new") before the rebuild begins.{}(�
watch_files�A dictionary mapping tool names to specific files that will be monitored
by `bazel_env`. When any of these files are modified, `bazel_env` will
be rebuilt. Paths are relative to the workspace root.

Use the tool name "_common" for files which are common to all tools.

Like `watch_dirs`, this attribute is optional. It gives you fine-grained
control over rebuild triggers by specifying individual files rather than
entire directories. This is useful when only a small set of known files
affect the tool's behavior, providing even lower overhead while still
mimicking Bazel's file-tracking during the analysis phase.

When changes are detected, a message will be displayed listing the changed
files (marked as "modified" or "new") before the rebuild begins.

Prefer to use this over the `watch_dirs` attribute for better performance.{}(�
kwargs�Additional arguments to pass to the main `bazel_env` target. It is usually not
necessary to provide any and the target should have private visibility.(�Makes Bazel-managed tools and toolchains available under stable paths.

Build this target to make the given tools and toolchains available under stable,
platform-independent paths:

* tools are staged in `bazel-out/bazel_env-opt/bin/path/to/pkg/name/bin`
* toolchains are staged in `bazel-out/bazel_env-opt/bin/path/to/pkg/name/toolchains`

The `bin` directory is regenerated as a whole on each build, so tools removed from `tools`
also disappear from `PATH` with the next build.

Run this target with `bazel run` for instructions on how to make the tools available on `PATH`
using [`direnv`](https://direnv.net/). This also prints a list of all tools and toolchains.
2
	bazel_env@bazel_env.bzl#
!
nameThe name of the rule. (�
�
tools�A dictionary mapping tool names to their targets or paths. The name is used as the
basename of the tool in the `bin` directory and will be available on `PATH`.

If a target is provided, the corresponding executable is staged in the `bin` directory
together with its runfiles.

If a path is provided, Make variables provided by `toolchains` are expanded in it and
all the files of referenced toolchains are staged as runfiles. If a referenced toolchain
is a C++ toolchain, the tool runs with the environment Bazel sets for its compile
actions, which compiler wrappers such as the one of the Apple C++ toolchain require.{}(�
�

toolchains�A dictionary mapping toolchain names to their targets. The name is used as the
basename of the toolchain directory in the `toolchains` directory. The directory is
a symlink to the repository root of the (single) repository containing the toolchain.

With Bazel 9.0.0-pre.20250311.1 and later, toolchain_type targets can be used directly.
In older versions, use a "resolved" toolchain target such as
`@bazel_tools//tools/cpp:current_cc_toolchain` instead.{}(�
�

watch_dirs�A dictionary mapping tool names to directories that will be monitored by
`bazel_env`. When any file within these directories changes, it triggers
a rebuild of `bazel_env`. Paths are relative to the workspace root.

Use the tool name "_common" for directories which are common to all tools.

This attribute is fully optional. It allows you to provide a heuristic
set of directories that approximates what Bazel tracks during the
analysis phase. This can significantly improve performance,
at the cost of manually maintaining the directory list.

When changes are detected, a message will be displayed listing the changed
files (marked as "modified" or "new") before the rebuild begins.{}(�
�
watch_files�A dictionary mapping tool names to specific files that will be monitored
by `bazel_env`. When any of these files are modified, `bazel_env` will
be rebuilt. Paths are relative to the workspace root.

Use the tool name "_common" for files which are common to all tools.

Like `watch_dirs`, this attribute is optional. It gives you fine-grained
control over rebuild triggers by specifying individual files rather than
entire directories. This is useful when only a small set of known files
affect the tool's behavior, providing even lower overhead while still
mimicking Bazel's file-tracking during the analysis phase.

When changes are detected, a message will be displayed listing the changed
files (marked as "modified" or "new") before the rebuild begins.

Prefer to use this over the `watch_dirs` attribute for better performance.{}(�
�
kwargs�Additional arguments to pass to the main `bazel_env` target. It is usually not
necessary to provide any and the target should have private visibility.( 