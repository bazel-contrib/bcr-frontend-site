�
!
bazel_gomockrules
gomock.bzl*�ModuleInfo request error: invalid argument: Traceback (most recent call last):
	File "external/bazel_gomock/rules/gomock.bzl", line 28, column 59, in <toplevel>
		load("@rules_go//go/private:providers.bzl", "GoArchive", "GoInfo")
Error: file '@rules_go//go/private:providers.bzl' does not contain symbol 'GoInfo' 