�
bzl_library.bzl�bzl_library_rule>Creates a logical collection of Starlark .bzl and .star files."�
�
bzl_library_rule>Creates a logical collection of Starlark .bzl and .star files.*
nameA unique name for this target. 
srcs2[]
deps2[]"&
bzl_library_rule//:bzl_library.bzl,
*
nameA unique name for this target. 

srcs2[]

deps2[]�bzl_libraryWrapper for bzl_library.*�
�
bzl_library
namename (X
srcsJList of `.bzl` and `.star` files that are processed to create this target.[](z
depslList of other `bzl_library` or `filegroup` targets that are required by the Starlark files listed in `srcs`.[](:
kwargs.additional arguments for the bzl_library rule.(Wrapper for bzl_library.2!
bzl_library//:bzl_library.bzl

namename (Z
X
srcsJList of `.bzl` and `.star` files that are processed to create this target.[](|
z
depslList of other `bzl_library` or `filegroup` targets that are required by the Starlark files listed in `srcs`.[](<
:
kwargs.additional arguments for the bzl_library rule.(�A library rule and macro for grouping Starlark sources.

Drop-in replacement for bzl_library in bazel_skylib, with exceptions:
- We support .bzl and .star extensions, while bzl_library accepts .bzl and .scl.
- Generates [starlark_doc_extract](https://bazel.build/versions/8.3.0/reference/be/general#starlark_doc_extract)
  targets, one for each element of `srcs`, ensuring that the sources list all their dependencies.
  Fixes https://github.com/bazelbuild/bazel-skylib/issues/568�
lib
base64.bzl�base64.decodeDecode a base64 encoded string.*�
�
base64.decode!
database64-encoded string (Decode a base64 encoded string."&
$A string containing the decoded data2"
decode//lib/private:base64.bzl#
!
database64-encoded string (�base64.encodeBase64 encode a string.*�
�
base64.encode
datastring to encode (Base64 encode a string."
The base64-encoded string2"
encode//lib/private:base64.bzl

datastring to encode (kUtility functions for encoding and decoding strings with base64.

See https://en.wikipedia.org/wiki/Base64.�	
libbats.bzl�	bats_test"�
�
	bats_test*
nameA unique name for this target. 
srcs
Test files2[]/
data!Runtime dependencies of the test.2[]�
env�Environment variables of the action.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables) and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution.
2{}"#
	bats_test//lib/private:bats.bzl08,
*
nameA unique name for this target. 

srcs
Test files2[]1
/
data!Runtime dependencies of the test.2[]�
�
env�Environment variables of the action.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables) and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution.
2{}�A test rule that invokes the [Bash Automated Testing System](https://github.com/bats-core/bats-core).

For example, a `bats_test` target containing a single .bat and basic configuration:

```starlark
bats_test(
    name = "my_test",
    size = "small",
    srcs = [
        "my_test.bats",
    ],
    data = [
        "data.bin",
    ],
    env = {
        "DATA_PATH": "$(location :data.bin)",
    },
    args = ["--timing"],
)
```�.
libcopy_directory.bzl�copy_directory�Copies a directory to another location.

This rule uses a precompiled binary to perform the copy, so no shell is required.

If using this rule with source directories, it is recommended that you use the
`--host_jvm_args=-DBAZEL_TRACK_SOURCE_DIRECTORIES=1` startup option so that changes
to files within source directories are detected. See
https://github.com/bazelbuild/bazel/commit/c64421bc35214f0414e4f4226cc953e8c55fa0d2
for more context.
*�
�

copy_directory
nameName of the rule. (V
srcKThe directory to make a copy of. Can be a source directory or TreeArtifact. (B
out7Path of the output directory, relative to this package. (�
hardlink�Controls when to use hardlinks to files instead of making copies.

Creating hardlinks is much faster than making copies of files with the caveat that
hardlinks share file permissions with their source.

Since Bazel removes write permissions on files in the output tree after an action completes,
hardlinks to source files within source directories is not recommended since write
permissions will be inadvertently removed from sources files.

- "auto": hardlinks are used if src is a tree artifact already in the output tree
- "off": files are always copied
- "on": hardlinks are always used (not recommended)"auto"(8
kwargs,further keyword arguments, e.g. `visibility`(�Copies a directory to another location.

This rule uses a precompiled binary to perform the copy, so no shell is required.

If using this rule with source directories, it is recommended that you use the
`--host_jvm_args=-DBAZEL_TRACK_SOURCE_DIRECTORIES=1` startup option so that changes
to files within source directories are detected. See
https://github.com/bazelbuild/bazel/commit/c64421bc35214f0414e4f4226cc953e8c55fa0d2
for more context.
22
copy_directory //lib/private:copy_directory.bzl

nameName of the rule. (X
V
srcKThe directory to make a copy of. Can be a source directory or TreeArtifact. (D
B
out7Path of the output directory, relative to this package. (�
�
hardlink�Controls when to use hardlinks to files instead of making copies.

Creating hardlinks is much faster than making copies of files with the caveat that
hardlinks share file permissions with their source.

Since Bazel removes write permissions on files in the output tree after an action completes,
hardlinks to source files within source directories is not recommended since write
permissions will be inadvertently removed from sources files.

- "auto": hardlinks are used if src is a tree artifact already in the output tree
- "off": files are always copied
- "on": hardlinks are always used (not recommended)"auto"(:
8
kwargs,further keyword arguments, e.g. `visibility`(�copy_directory_bin_action�Factory function that creates an action to copy a directory from src to dst using a tool binary.

The tool binary will typically be the `@bazel_lib//tools/copy_directory` `go_binary`
either built from source or provided by a toolchain.

This helper is used by the copy_directory rule. It is exposed as a public API so it can be used
within other rule implementations.
*�
�	
copy_directory_bin_action
ctxThe rule context. ((
srcThe source directory to copy. (<
dst1The directory to copy to. Must be a TreeArtifact. (8
copy_directory_binCopy to directory tool binary. (�
copy_directory_toolchainOThe toolchain type for Auto Exec Groups. The default is probably what you want.,Label("//lib:copy_directory_toolchain_type")(�
hardlinkzControls when to use hardlinks to files instead of making copies.

See copy_directory rule documentation for more details."auto"(0
verboseprint verbose logs to stdoutFalse(�
preserve_mtimewpreserve the modified time from the source.
See the caveats above about interactions with remote execution and caching.False(�Factory function that creates an action to copy a directory from src to dst using a tool binary.

The tool binary will typically be the `@bazel_lib//tools/copy_directory` `go_binary`
either built from source or provided by a toolchain.

This helper is used by the copy_directory rule. It is exposed as a public API so it can be used
within other rule implementations.
2=
copy_directory_bin_action //lib/private:copy_directory.bzl

ctxThe rule context. (*
(
srcThe source directory to copy. (>
<
dst1The directory to copy to. Must be a TreeArtifact. (:
8
copy_directory_binCopy to directory tool binary. (�
�
copy_directory_toolchainOThe toolchain type for Auto Exec Groups. The default is probably what you want.,Label("//lib:copy_directory_toolchain_type")(�
�
hardlinkzControls when to use hardlinks to files instead of making copies.

See copy_directory rule documentation for more details."auto"(2
0
verboseprint verbose logs to stdoutFalse(�
�
preserve_mtimewpreserve the modified time from the source.
See the caveats above about interactions with remote execution and caching.False(�A rule that copies a directory to another place.

The rule uses a precompiled binary to perform the copy, so no shell is required.

## Preserving modification times

`copy_directory` and `copy_to_directory` have a `preserve_mtime` attribute, however
there are two caveats to consider when using this feature:

1. Remote Execution / Caching: These layers will reset the modify time and are
    incompatible with this feature. To avoid these failures the [no-remote tag](https://bazel.build/reference/be/common-definitions)
    can be added.
2. Caching: Changes to only the modified time will not re-trigger cached actions. This can
    be worked around by using a clean build when these types of changes occur. For tests the
    [external tag](https://bazel.build/reference/be/common-definitions) can be used but this will result in tests never being cached.�.
libcopy_file.bzl�	copy_file�Copies a file or directory to another location.

`native.genrule()` is sometimes used to copy files (often wishing to rename them). The 'copy_file' rule does this with a simpler interface than genrule.

This rule uses a hermetic uutils/coreutils `cp` binary, no shell is required.

If using this rule with source directories, it is recommended that you use the
`--host_jvm_args=-DBAZEL_TRACK_SOURCE_DIRECTORIES=1` startup option so that changes
to files within source directories are detected. See
https://github.com/bazelbuild/bazel/commit/c64421bc35214f0414e4f4226cc953e8c55fa0d2
for more context.
*�
�
	copy_file
nameName of the rule. (h
src]A Label. The file to make a copy of.
(Can also be the label of a rule that generates a file.) (=
out2Path of the output file, relative to this package. (�
is_executable�A boolean. Whether to make the output file executable. When
True, the rule's output can be executed using `bazel run` and can be
in the srcs of binary and test rules that require executable sources.
WARNING: If `allow_symlink` is True, `src` must also be executable.False(�
allow_symlink�A boolean. Whether to allow symlinking instead of copying.
When False, the output is always a hard copy. When True, the output
*can* be a symlink, but there is no guarantee that a symlink is
created (i.e., at the time of writing, we don't create symlinks on
Windows). Set this to True if you need fast copying and your tools can
handle symlinks (which most UNIX tools can).False(8
kwargs,further keyword arguments, e.g. `visibility`(�Copies a file or directory to another location.

`native.genrule()` is sometimes used to copy files (often wishing to rename them). The 'copy_file' rule does this with a simpler interface than genrule.

This rule uses a hermetic uutils/coreutils `cp` binary, no shell is required.

If using this rule with source directories, it is recommended that you use the
`--host_jvm_args=-DBAZEL_TRACK_SOURCE_DIRECTORIES=1` startup option so that changes
to files within source directories are detected. See
https://github.com/bazelbuild/bazel/commit/c64421bc35214f0414e4f4226cc953e8c55fa0d2
for more context.
2(
	copy_file//lib/private:copy_file.bzl

nameName of the rule. (j
h
src]A Label. The file to make a copy of.
(Can also be the label of a rule that generates a file.) (?
=
out2Path of the output file, relative to this package. (�
�
is_executable�A boolean. Whether to make the output file executable. When
True, the rule's output can be executed using `bazel run` and can be
in the srcs of binary and test rules that require executable sources.
WARNING: If `allow_symlink` is True, `src` must also be executable.False(�
�
allow_symlink�A boolean. Whether to allow symlinking instead of copying.
When False, the output is always a hard copy. When True, the output
*can* be a symlink, but there is no guarantee that a symlink is
created (i.e., at the time of writing, we don't create symlinks on
Windows). Set this to True if you need fast copying and your tools can
handle symlinks (which most UNIX tools can).False(:
8
kwargs,further keyword arguments, e.g. `visibility`(�copy_file_action�Factory function that creates an action to copy a file from src to dst.

If src is a TreeArtifact, dir_path must be specified as the path within
the TreeArtifact to the file to copy.

This helper is used by copy_file. It is exposed as a public API so it can be used within
other rule implementations.

To use `copy_file_action` in your own rules, you need to include the toolchains it uses
in your rule definition. For example:

```starlark
load("@bazel_lib//lib:copy_file.bzl", "COPY_FILE_TOOLCHAINS")

my_rule = rule(
    ...,
    toolchains = COPY_FILE_TOOLCHAINS,
)
```

Additionally, you must ensure that the coreutils toolchain is has been registered in your
WORKSPACE if you are not using bzlmod:

```starlark
load("@bazel_lib//lib:repositories.bzl", "register_coreutils_toolchains")

register_coreutils_toolchains()
```
*�

�
copy_file_action
ctxThe rule context. (P
srcEThe source file to copy or TreeArtifact to copy a single file out of. ( 
dstThe destination file. (c
dir_pathOIf src is a TreeArtifact, the path within the TreeArtifact to the file to copy.None(�Factory function that creates an action to copy a file from src to dst.

If src is a TreeArtifact, dir_path must be specified as the path within
the TreeArtifact to the file to copy.

This helper is used by copy_file. It is exposed as a public API so it can be used within
other rule implementations.

To use `copy_file_action` in your own rules, you need to include the toolchains it uses
in your rule definition. For example:

```starlark
load("@bazel_lib//lib:copy_file.bzl", "COPY_FILE_TOOLCHAINS")

my_rule = rule(
    ...,
    toolchains = COPY_FILE_TOOLCHAINS,
)
```

Additionally, you must ensure that the coreutils toolchain is has been registered in your
WORKSPACE if you are not using bzlmod:

```starlark
load("@bazel_lib//lib:repositories.bzl", "register_coreutils_toolchains")

register_coreutils_toolchains()
```
2/
copy_file_action//lib/private:copy_file.bzl

ctxThe rule context. (R
P
srcEThe source file to copy or TreeArtifact to copy a single file out of. ("
 
dstThe destination file. (e
c
dir_pathOIf src is a TreeArtifact, the path within the TreeArtifact to the file to copy.None(�A rule that copies a file to another place.

`native.genrule()` is sometimes used to copy files (often wishing to rename them).
The `copy_file` rule does this with a simpler interface than genrule.

This rule uses a hermetic uutils/coreutils `cp` binary, no shell is required.

This fork of bazel-skylib's copy_file adds `DirectoryPathInfo` support and allows multiple
`copy_file` rules in the same package.�%
libcopy_to_bin.bzl�copy_file_to_bin_action�Factory function that creates an action to copy a file to the output tree.

File are copied to the same workspace-relative path. The resulting files is
returned.

If the file passed in is already in the output tree is then it is returned
without a copy action.

To use `copy_file_to_bin_action` in your own rules, you need to include the toolchains it uses
in your rule definition. For example:

```starlark
load("@bazel_lib//lib:copy_to_bin.bzl", "COPY_FILE_TO_BIN_TOOLCHAINS")

my_rule = rule(
    ...,
    toolchains = COPY_FILE_TO_BIN_TOOLCHAINS,
)
```

Additionally, you must ensure that the coreutils toolchain is has been registered in your
WORKSPACE if you are not using bzlmod:

```starlark
load("@bazel_lib//lib:repositories.bzl", "register_coreutils_toolchains")

register_coreutils_toolchains()
```
*�
�
copy_file_to_bin_action
ctxThe rule context. (
fileThe file to copy. (�Factory function that creates an action to copy a file to the output tree.

File are copied to the same workspace-relative path. The resulting files is
returned.

If the file passed in is already in the output tree is then it is returned
without a copy action.

To use `copy_file_to_bin_action` in your own rules, you need to include the toolchains it uses
in your rule definition. For example:

```starlark
load("@bazel_lib//lib:copy_to_bin.bzl", "COPY_FILE_TO_BIN_TOOLCHAINS")

my_rule = rule(
    ...,
    toolchains = COPY_FILE_TO_BIN_TOOLCHAINS,
)
```

Additionally, you must ensure that the coreutils toolchain is has been registered in your
WORKSPACE if you are not using bzlmod:

```starlark
load("@bazel_lib//lib:repositories.bzl", "register_coreutils_toolchains")

register_coreutils_toolchains()
```
"
A File in the output tree.28
copy_file_to_bin_action//lib/private:copy_to_bin.bzl

ctxThe rule context. (

fileThe file to copy. (�copy_files_to_bin_actions�Factory function that creates actions to copy files to the output tree.

Files are copied to the same workspace-relative path. The resulting list of
files is returned.

If a file passed in is already in the output tree is then it is added
directly to the result without a copy action.
*�
�
copy_files_to_bin_actions
ctxThe rule context. ("
filesList of File objects. (�Factory function that creates actions to copy files to the output tree.

Files are copied to the same workspace-relative path. The resulting list of
files is returned.

If a file passed in is already in the output tree is then it is added
directly to the result without a copy action.
"*
(List of File objects in the output tree.2:
copy_files_to_bin_actions//lib/private:copy_to_bin.bzl

ctxThe rule context. ($
"
filesList of File objects. (�copy_to_bin�Copies a source file to output tree at the same workspace-relative path.

e.g. `<execroot>/path/to/file -> <execroot>/bazel-out/<platform>/bin/path/to/file`

If a file passed in is already in the output tree is then it is added directly to the
DefaultInfo provided by the rule without a copy.

This is useful to populate the output folder with all files needed at runtime, even
those which aren't outputs of a Bazel rule.

This way you can run a binary in the output folder (execroot or runfiles_root)
without that program needing to rely on a runfiles helper library or be aware that
files are divided between the source tree and the output tree.
*�
�
copy_to_bin
nameName of the rule. (.
srcs"A list of labels. File(s) to copy. (8
kwargs,further keyword arguments, e.g. `visibility`(�Copies a source file to output tree at the same workspace-relative path.

e.g. `<execroot>/path/to/file -> <execroot>/bazel-out/<platform>/bin/path/to/file`

If a file passed in is already in the output tree is then it is added directly to the
DefaultInfo provided by the rule without a copy.

This is useful to populate the output folder with all files needed at runtime, even
those which aren't outputs of a Bazel rule.

This way you can run a binary in the output folder (execroot or runfiles_root)
without that program needing to rely on a runfiles helper library or be aware that
files are divided between the source tree and the output tree.
2,
copy_to_bin//lib/private:copy_to_bin.bzl

nameName of the rule. (0
.
srcs"A list of labels. File(s) to copy. (:
8
kwargs,further keyword arguments, e.g. `visibility`(�A rule that copies source files to the output tree.

This rule uses a Bash command (diff) on Linux/macOS/non-Windows, and a cmd.exe
command (fc.exe) on Windows (no Bash is required).

Originally authored in rules_nodejs
https://github.com/bazel-contrib/rules_nodejs/blob/8b5d27400db51e7027fe95ae413eeabea4856f8e/internal/common/copy_to_bin.bzlӮ
libcopy_to_directory.bzlcopy_to_directory�Copies files and directories to an output directory.

Files and directories can be arranged as needed in the output directory using
the `root_paths`, `include_srcs_patterns`, `exclude_srcs_patterns` and `replace_prefixes` attributes.

Filters and transformations are applied in the following order:

1. `include_external_repositories`

2. `include_srcs_packages`

3. `exclude_srcs_packages`

4. `root_paths`

5. `include_srcs_patterns`

6. `exclude_srcs_patterns`

7. `replace_prefixes`

For more information each filters / transformations applied, see
the documentation for the specific filter / transformation attribute.


Glob patterns are supported. Standard wildcards (globbing patterns) plus the `**` doublestar (aka. super-asterisk)
are supported with the underlying globbing library, https://github.com/bmatcuk/doublestar. This is the same
globbing library used by [gazelle](https://github.com/bazelbuild/bazel-gazelle). See https://github.com/bmatcuk/doublestar#patterns
for more information on supported globbing patterns."�{
�A
copy_to_directory�Copies files and directories to an output directory.

Files and directories can be arranged as needed in the output directory using
the `root_paths`, `include_srcs_patterns`, `exclude_srcs_patterns` and `replace_prefixes` attributes.

Filters and transformations are applied in the following order:

1. `include_external_repositories`

2. `include_srcs_packages`

3. `exclude_srcs_packages`

4. `root_paths`

5. `include_srcs_patterns`

6. `exclude_srcs_patterns`

7. `replace_prefixes`

For more information each filters / transformations applied, see
the documentation for the specific filter / transformation attribute.


Glob patterns are supported. Standard wildcards (globbing patterns) plus the `**` doublestar (aka. super-asterisk)
are supported with the underlying globbing library, https://github.com/bmatcuk/doublestar. This is the same
globbing library used by [gazelle](https://github.com/bazelbuild/bazel-gazelle). See https://github.com/bmatcuk/doublestar#patterns
for more information on supported globbing patterns.*
nameA unique name for this target. u
srcsgFiles and/or directories or targets that provide `DirectoryPathInfo` to copy into the output directory.2[]q
outdPath of the output directory, relative to this package.

If not set, the name of the target is used.2""e
add_directory_to_runfiles@Whether to add the outputted directory to the target's runfiles.2True�

root_paths�List of paths (with glob support) that are roots in the output directory.

If any parent directory of a file being copied matches one of the root paths
patterns specified, the output directory path will be the path relative to the root path
instead of the path relative to the file's workspace. If there are multiple
root paths that match, the longest match wins.

Matching is done on the parent directory of the output file path so a trailing '**' glob patterm
will match only up to the last path segment of the dirname and will not include the basename.
Only complete path segments are matched. Partial matches on the last segment of the root path
are ignored.

Forward slashes (`/`) should be used as path separators.

A `"."` value expands to the target's package path (`ctx.label.package`).

Defaults to `["."]` which results in the output directory path of files in the
target's package and and sub-packages are relative to the target's package and
files outside of that retain their full workspace relative paths.

Globs are supported (see rule docstring above).2["."]�	
include_external_repositories�	List of external repository names (with glob support) to include in the output directory.

Files from external repositories are only copied into the output directory if
the external repository they come from matches one of the external repository patterns
specified or if they are in the same external repository as this target.

When copied from an external repository, the file path in the output directory
defaults to the file's path within the external repository. The external repository
name is _not_ included in that path.

For example, the following copies `@external_repo//path/to:file` to
`path/to/file` within the output directory.

```
copy_to_directory(
    name = "dir",
    include_external_repositories = ["external_*"],
    srcs = ["@external_repo//path/to:file"],
)
```

Files that come from matching external are subject to subsequent filters and
transformations to determine if they are copied and what their path in the output
directory will be. The external repository name of the file from an external
repository is not included in the output directory path and is considered in subsequent
filters and transformations.

Globs are supported (see rule docstring above).2[]�
include_srcs_packages�List of Bazel packages (with glob support) to include in output directory.

Files in srcs are only copied to the output directory if
the Bazel package of the file matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators. A first character of `"."`
will be replaced by the target's package path.

Defaults to `["**"]` which includes sources from all packages.

Files that have matching Bazel packages are subject to subsequent filters and
transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).2["**"]�
exclude_srcs_packages�List of Bazel packages (with glob support) to exclude from output directory.

Files in srcs are not copied to the output directory if
the Bazel package of the file matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators. A first character of `"."`
will be replaced by the target's package path.

Files that have do not have matching Bazel packages are subject to subsequent
filters and transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).2[]�
include_srcs_patterns�List of paths (with glob support) to include in output directory.

Files in srcs are only copied to the output directory if their output
directory path, after applying `root_paths`, matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators.

Defaults to `["**"]` which includes all sources.

Files that have matching output directory paths are subject to subsequent
filters and transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).2["**"]�
exclude_srcs_patterns�List of paths (with glob support) to exclude from output directory.

Files in srcs are not copied to the output directory if their output
directory path, after applying `root_paths`, matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators.

Files that do not have matching output directory paths are subject to subsequent
filters and transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).2[]�
replace_prefixes�Map of paths prefixes (with glob support) to replace in the output directory path when copying files.

If the output directory path for a file starts with or fully matches a
a key in the dict then the matching portion of the output directory path is
replaced with the dict value for that key. The final path segment
matched can be a partial match of that segment and only the matching portion will
be replaced. If there are multiple keys that match, the longest match wins.

Forward slashes (`/`) should be used as path separators.

Replace prefix transformation are the final step in the list of filters and transformations.
The final output path of a file being copied into the output directory
is determined at this step.

Globs are supported (see rule docstring above).
2{}�
allow_overwrites�If True, allow files to be overwritten if the same output file is copied to twice.

The order of srcs matters as the last copy of a particular file will win when overwriting.
Performance of copy_to_directory will be slightly degraded when allow_overwrites is True
since copies cannot be parallelized out as they are calculated. Instead all copy paths
must be calculated before any copies can be started.2False�
hardlink�Controls when to use hardlinks to files instead of making copies.

Creating hardlinks is much faster than making copies of files with the caveat that
hardlinks share file permissions with their source.

Since Bazel removes write permissions on files in the output tree after an action completes,
hardlinks to source files are not recommended since write permissions will be inadvertently
removed from sources files.

- `auto`: hardlinks are used for generated files already in the output tree
- `off`: all files are copied
- `on`: hardlinks are used for all files (not recommended)2"auto"�
preserve_mtime�If True, the last modified time of copied files is preserved.
See the [caveats on copy_directory](/docs/copy_directory.md#preserving-modification-times)
about interactions with remote execution and caching.2False>
verbose*If true, prints out verbose logs to stdout2False"0
copy_to_directory//lib:copy_to_directory.bzl*&
DefaultInfo
DefaultInfo<native>,
*
nameA unique name for this target. w
u
srcsgFiles and/or directories or targets that provide `DirectoryPathInfo` to copy into the output directory.2[]s
q
outdPath of the output directory, relative to this package.

If not set, the name of the target is used.2""g
e
add_directory_to_runfiles@Whether to add the outputted directory to the target's runfiles.2True�
�

root_paths�List of paths (with glob support) that are roots in the output directory.

If any parent directory of a file being copied matches one of the root paths
patterns specified, the output directory path will be the path relative to the root path
instead of the path relative to the file's workspace. If there are multiple
root paths that match, the longest match wins.

Matching is done on the parent directory of the output file path so a trailing '**' glob patterm
will match only up to the last path segment of the dirname and will not include the basename.
Only complete path segments are matched. Partial matches on the last segment of the root path
are ignored.

Forward slashes (`/`) should be used as path separators.

A `"."` value expands to the target's package path (`ctx.label.package`).

Defaults to `["."]` which results in the output directory path of files in the
target's package and and sub-packages are relative to the target's package and
files outside of that retain their full workspace relative paths.

Globs are supported (see rule docstring above).2["."]�	
�	
include_external_repositories�	List of external repository names (with glob support) to include in the output directory.

Files from external repositories are only copied into the output directory if
the external repository they come from matches one of the external repository patterns
specified or if they are in the same external repository as this target.

When copied from an external repository, the file path in the output directory
defaults to the file's path within the external repository. The external repository
name is _not_ included in that path.

For example, the following copies `@external_repo//path/to:file` to
`path/to/file` within the output directory.

```
copy_to_directory(
    name = "dir",
    include_external_repositories = ["external_*"],
    srcs = ["@external_repo//path/to:file"],
)
```

Files that come from matching external are subject to subsequent filters and
transformations to determine if they are copied and what their path in the output
directory will be. The external repository name of the file from an external
repository is not included in the output directory path and is considered in subsequent
filters and transformations.

Globs are supported (see rule docstring above).2[]�
�
include_srcs_packages�List of Bazel packages (with glob support) to include in output directory.

Files in srcs are only copied to the output directory if
the Bazel package of the file matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators. A first character of `"."`
will be replaced by the target's package path.

Defaults to `["**"]` which includes sources from all packages.

Files that have matching Bazel packages are subject to subsequent filters and
transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).2["**"]�
�
exclude_srcs_packages�List of Bazel packages (with glob support) to exclude from output directory.

Files in srcs are not copied to the output directory if
the Bazel package of the file matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators. A first character of `"."`
will be replaced by the target's package path.

Files that have do not have matching Bazel packages are subject to subsequent
filters and transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).2[]�
�
include_srcs_patterns�List of paths (with glob support) to include in output directory.

Files in srcs are only copied to the output directory if their output
directory path, after applying `root_paths`, matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators.

Defaults to `["**"]` which includes all sources.

Files that have matching output directory paths are subject to subsequent
filters and transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).2["**"]�
�
exclude_srcs_patterns�List of paths (with glob support) to exclude from output directory.

Files in srcs are not copied to the output directory if their output
directory path, after applying `root_paths`, matches one of the patterns specified.

Forward slashes (`/`) should be used as path separators.

Files that do not have matching output directory paths are subject to subsequent
filters and transformations to determine if they are copied and what their path in the output
directory will be.

Globs are supported (see rule docstring above).2[]�
�
replace_prefixes�Map of paths prefixes (with glob support) to replace in the output directory path when copying files.

If the output directory path for a file starts with or fully matches a
a key in the dict then the matching portion of the output directory path is
replaced with the dict value for that key. The final path segment
matched can be a partial match of that segment and only the matching portion will
be replaced. If there are multiple keys that match, the longest match wins.

Forward slashes (`/`) should be used as path separators.

Replace prefix transformation are the final step in the list of filters and transformations.
The final output path of a file being copied into the output directory
is determined at this step.

Globs are supported (see rule docstring above).
2{}�
�
allow_overwrites�If True, allow files to be overwritten if the same output file is copied to twice.

The order of srcs matters as the last copy of a particular file will win when overwriting.
Performance of copy_to_directory will be slightly degraded when allow_overwrites is True
since copies cannot be parallelized out as they are calculated. Instead all copy paths
must be calculated before any copies can be started.2False�
�
hardlink�Controls when to use hardlinks to files instead of making copies.

Creating hardlinks is much faster than making copies of files with the caveat that
hardlinks share file permissions with their source.

Since Bazel removes write permissions on files in the output tree after an action completes,
hardlinks to source files are not recommended since write permissions will be inadvertently
removed from sources files.

- `auto`: hardlinks are used for generated files already in the output tree
- `off`: all files are copied
- `on`: hardlinks are used for all files (not recommended)2"auto"�
�
preserve_mtime�If True, the last modified time of copied files is preserved.
See the [caveats on copy_directory](/docs/copy_directory.md#preserving-modification-times)
about interactions with remote execution and caching.2False@
>
verbose*If true, prints out verbose logs to stdout2False�copy_to_directory_lib.impl*v
g
copy_to_directory_lib.impl	
ctx (2>
_copy_to_directory_impl#//lib/private:copy_to_directory.bzl
	
ctx (�)copy_to_directory_bin_action�Factory function to copy files to a directory using a tool binary.

The tool binary will typically be the `@bazel_lib//tools/copy_to_directory` `go_binary`
either built from source or provided by a toolchain.

This helper is used by copy_to_directory. It is exposed as a public API so it can be used within
other rule implementations where additional_files can also be passed in.
*�%
�
copy_to_directory_bin_action
ctxThe rule context. (P
nameDName of target creating this action used for config file generation. (<
dst1The directory to copy to. Must be a TreeArtifact. (;
copy_to_directory_binCopy to directory tool binary. (�
copy_to_directory_toolchainOThe toolchain type for Auto Exec Groups. The default is probably what you want./Label("//lib:copy_to_directory_toolchain_type")(?
files0List of files to copy into the output directory.[](d
targetsSList of targets that provide `DirectoryPathInfo` to copy into the output directory.[](�

root_pathsqList of paths that are roots in the output directory.

See copy_to_directory rule documentation for more details.["."](�
include_external_repositories�List of external repository names to include in the output directory.

See copy_to_directory rule documentation for more details.[](�
include_srcs_packagesrList of Bazel packages to include in output directory.

See copy_to_directory rule documentation for more details.["**"](�
exclude_srcs_packages�List of Bazel packages (with glob support) to exclude from output directory.

See copy_to_directory rule documentation for more details.[](�
include_srcs_patterns}List of paths (with glob support) to include in output directory.

See copy_to_directory rule documentation for more details.["**"](�
exclude_srcs_patternsList of paths (with glob support) to exclude from output directory.

See copy_to_directory rule documentation for more details.[](�
replace_prefixes�Map of paths prefixes to replace in the output directory path when copying files.

See copy_to_directory rule documentation for more details.{}(�
allow_overwrites�If True, allow files to be overwritten if the same output file is copied to twice.

See copy_to_directory rule documentation for more details.False(�
hardlink}Controls when to use hardlinks to files instead of making copies.

See copy_to_directory rule documentation for more details."auto"(O
preserve_mtime4If true, preserve the modified time from the source.False(>
verbose*If true, prints out verbose logs to stdoutFalse(�Factory function to copy files to a directory using a tool binary.

The tool binary will typically be the `@bazel_lib//tools/copy_to_directory` `go_binary`
either built from source or provided by a toolchain.

This helper is used by copy_to_directory. It is exposed as a public API so it can be used within
other rule implementations where additional_files can also be passed in.
2C
copy_to_directory_bin_action#//lib/private:copy_to_directory.bzl

ctxThe rule context. (R
P
nameDName of target creating this action used for config file generation. (>
<
dst1The directory to copy to. Must be a TreeArtifact. (=
;
copy_to_directory_binCopy to directory tool binary. (�
�
copy_to_directory_toolchainOThe toolchain type for Auto Exec Groups. The default is probably what you want./Label("//lib:copy_to_directory_toolchain_type")(A
?
files0List of files to copy into the output directory.[](f
d
targetsSList of targets that provide `DirectoryPathInfo` to copy into the output directory.[](�
�

root_pathsqList of paths that are roots in the output directory.

See copy_to_directory rule documentation for more details.["."](�
�
include_external_repositories�List of external repository names to include in the output directory.

See copy_to_directory rule documentation for more details.[](�
�
include_srcs_packagesrList of Bazel packages to include in output directory.

See copy_to_directory rule documentation for more details.["**"](�
�
exclude_srcs_packages�List of Bazel packages (with glob support) to exclude from output directory.

See copy_to_directory rule documentation for more details.[](�
�
include_srcs_patterns}List of paths (with glob support) to include in output directory.

See copy_to_directory rule documentation for more details.["**"](�
�
exclude_srcs_patternsList of paths (with glob support) to exclude from output directory.

See copy_to_directory rule documentation for more details.[](�
�
replace_prefixes�Map of paths prefixes to replace in the output directory path when copying files.

See copy_to_directory rule documentation for more details.{}(�
�
allow_overwrites�If True, allow files to be overwritten if the same output file is copied to twice.

See copy_to_directory rule documentation for more details.False(�
�
hardlink}Controls when to use hardlinks to files instead of making copies.

See copy_to_directory rule documentation for more details."auto"(Q
O
preserve_mtime4If true, preserve the modified time from the source.False(@
>
verbose*If true, prints out verbose logs to stdoutFalse(2Copy files and directories to an output directory.�
libdiff_test.bzl�
	diff_testQA test that compares two files.

The test succeeds if the files' contents match.
*�	
�
	diff_test&
nameThe name of the test rule. (@
file13Label of the file to compare to <code>file2</code>. (�
file2�Label of the file to compare to <code>file1</code>, or a list of strings which are the lines to expect <code>file1</code> to contain. (P
	diff_args=Arguments to pass to the `diff` command. (Ignored on Windows)[](/
sizestandard attribute for tests"small"(�
kwargs�The <a href="https://docs.bazel.build/versions/main/be/common-definitions.html#common-attributes-tests">common attributes for tests</a>.(QA test that compares two files.

The test succeeds if the files' contents match.
2(
	diff_test//lib/private:diff_test.bzl(
&
nameThe name of the test rule. (B
@
file13Label of the file to compare to <code>file2</code>. (�
�
file2�Label of the file to compare to <code>file1</code>, or a list of strings which are the lines to expect <code>file1</code> to contain. (R
P
	diff_args=Arguments to pass to the `diff` command. (Ignored on Windows)[](1
/
sizestandard attribute for tests"small"(�
�
kwargs�The <a href="https://docs.bazel.build/versions/main/be/common-definitions.html#common-attributes-tests">common attributes for tests</a>.(�A test rule that compares two binary files or two directories.

Similar to `bazel-skylib`'s [`diff_test`](https://github.com/bazelbuild/bazel-skylib/blob/main/rules/diff_test.bzl)
but also supports comparing directories.

The rule uses a Bash command (diff) on Linux/macOS/non-Windows, and a cmd.exe
command (fc.exe) on Windows (no Bash is required).

See also: [rules_diff](https://gitlab.arm.com/bazel/rules_diff)�#
libdirectory_path.bzl�directory_path}Provide DirectoryPathInfo to reference some path within a directory.

Otherwise there is no way to give a Bazel label for it."�
�
directory_path}Provide DirectoryPathInfo to reference some path within a directory.

Otherwise there is no way to give a Bazel label for it.*
nameA unique name for this target. ?
	directory.a TreeArtifact (ctx.actions.declare_directory) *
pathpath relative to the directory "2
directory_path //lib/private:directory_path.bzl*J
DirectoryPathInfo5
DirectoryPathInfo //lib/private:directory_path.bzl,
*
nameA unique name for this target. A
?
	directory.a TreeArtifact (ctx.actions.declare_directory) ,
*
pathpath relative to the directory �make_directory_pathIHelper function to generate a directory_path target and return its label.*�
�
make_directory_pathA
name5unique name for the generated `directory_path` target (R
	directoryA`directory` attribute passed to generated `directory_path` target (H
path<`path` attribute passed to generated `directory_path` target (A
kwargs5parameters to pass to generated `output_files` target(IHelper function to generate a directory_path target and return its label."
The label `name`27
make_directory_path //lib/private:directory_path.bzlC
A
name5unique name for the generated `directory_path` target (T
R
	directoryA`directory` attribute passed to generated `directory_path` target (J
H
path<`path` attribute passed to generated `directory_path` target (C
A
kwargs5parameters to pass to generated `output_files` target(�make_directory_paths�Helper function to convert a dict of directory to path mappings to directory_path targets and labels.

For example,

```
make_directory_paths("my_name", {
    "//directory/artifact:target_1": "file/path",
    "//directory/artifact:target_2": ["file/path1", "file/path2"],
})
```

generates the targets,

```
directory_path(
    name = "my_name_0",
    directory = "//directory/artifact:target_1",
    path = "file/path"
)

directory_path(
    name = "my_name_1",
    directory = "//directory/artifact:target_2",
    path = "file/path1"
)

directory_path(
    name = "my_name_2",
    directory = "//directory/artifact:target_2",
    path = "file/path2"
)
```

and the list of targets is returned,

```
[
    "my_name_0",
    "my_name_1",
    "my_name_2",
]
```
*�
�	
make_directory_paths�
nametThe target name to use for the generated targets & labels.

The names are generated as zero-indexed `name + "_" + i` (I
dict=The dictionary of directory keys to path or path list values. (B
kwargs6additional parameters to pass to each generated target(�Helper function to convert a dict of directory to path mappings to directory_path targets and labels.

For example,

```
make_directory_paths("my_name", {
    "//directory/artifact:target_1": "file/path",
    "//directory/artifact:target_2": ["file/path1", "file/path2"],
})
```

generates the targets,

```
directory_path(
    name = "my_name_0",
    directory = "//directory/artifact:target_1",
    path = "file/path"
)

directory_path(
    name = "my_name_1",
    directory = "//directory/artifact:target_2",
    path = "file/path1"
)

directory_path(
    name = "my_name_2",
    directory = "//directory/artifact:target_2",
    path = "file/path2"
)
```

and the list of targets is returned,

```
[
    "my_name_0",
    "my_name_1",
    "my_name_2",
]
```
"L
JThe label of the generated `directory_path` targets named `name + "_" + i`28
make_directory_paths //lib/private:directory_path.bzl�
�
nametThe target name to use for the generated targets & labels.

The names are generated as zero-indexed `name + "_" + i` (K
I
dict=The dictionary of directory keys to path or path list values. (D
B
kwargs6additional parameters to pass to each generated target(�DirectoryPathInfoRJoins a label pointing to a TreeArtifact with a path nested within that directory.2�
�
DirectoryPathInfoRJoins a label pointing to a TreeArtifact with a path nested within that directory.;
	directory.a TreeArtifact (ctx.actions.declare_directory)&
pathpath relative to the directory"5
DirectoryPathInfo //lib/private:directory_path.bzl=
;
	directory.a TreeArtifact (ctx.actions.declare_directory)(
&
pathpath relative to the directoryvRule and corresponding provider that joins a label pointing to a TreeArtifact
with a path nested within that directory�3
libexpand_make_vars.bzl�expand_locations�Expand location templates.

Expands all `$(execpath ...)`, `$(rootpath ...)` and deprecated `$(location ...)` templates in the
given string by replacing with the expanded path. Expansion only works for labels that point to direct dependencies
of this rule or that are explicitly listed in the optional argument targets.

See https://docs.bazel.build/versions/main/be/make-variables.html#predefined_label_variables.

Use `$(rootpath)` and `$(rootpaths)` to expand labels to the runfiles path that a built binary can use
to find its dependencies. This path is of the format:
- `./file`
- `path/to/file`
- `../external_repo/path/to/file`

Use `$(execpath)` and `$(execpaths)` to expand labels to the execroot (where Bazel runs build actions).
This is of the format:
- `./file`
- `path/to/file`
- `external/external_repo/path/to/file`
- `<bin_dir>/path/to/file`
- `<bin_dir>/external/external_repo/path/to/file`

The deprecated `$(location)` and `$(locations)` expansions returns either the execpath or rootpath depending on the context.
*�
�

expand_locations
ctxcontext ("
inputString to be expanded (C
targets2List of targets for additional lookup information.[](�Expand location templates.

Expands all `$(execpath ...)`, `$(rootpath ...)` and deprecated `$(location ...)` templates in the
given string by replacing with the expanded path. Expansion only works for labels that point to direct dependencies
of this rule or that are explicitly listed in the optional argument targets.

See https://docs.bazel.build/versions/main/be/make-variables.html#predefined_label_variables.

Use `$(rootpath)` and `$(rootpaths)` to expand labels to the runfiles path that a built binary can use
to find its dependencies. This path is of the format:
- `./file`
- `path/to/file`
- `../external_repo/path/to/file`

Use `$(execpath)` and `$(execpaths)` to expand labels to the execroot (where Bazel runs build actions).
This is of the format:
- `./file`
- `path/to/file`
- `external/external_repo/path/to/file`
- `<bin_dir>/path/to/file`
- `<bin_dir>/external/external_repo/path/to/file`

The deprecated `$(location)` and `$(locations)` expansions returns either the execpath or rootpath depending on the context.
"(
&The expanded path or the original path*E
CUse vanilla `ctx.expand_location(input, targets = targets)` instead26
expand_locations"//lib/private:expand_locations.bzl

ctxcontext ($
"
inputString to be expanded (E
C
targets2List of targets for additional lookup information.[](�expand_variables�Expand make variables and substitute like genrule does.

Bazel [pre-defined variables](https://bazel.build/reference/be/make-variables#predefined_variables)
are expanded however only `$@`, `$(@D)` and `$(RULEDIR)` of
[pre-defined genrule variables](https://bazel.build/reference/be/make-variables#predefined_genrule_variables)
are supported.

This function is the same as ctx.expand_make_variables with the additional
genrule-like substitutions of:

  - `$<`: The input file if it is a single file. Else triggers a build error.

  - `$@`: The output file if it is a single file. Else triggers a build error.

  - `$(@D)`: The output directory.

    If there is only one file name in outs, this expands to the directory containing that file.

    If there is only one directory in outs, this expands to the single output directory.

    If there are multiple files, this instead expands to the package's root directory in the bin tree,
    even if all generated files belong to the same subdirectory!

  - `$(RULEDIR)`: The output directory of the rule, that is, the directory
    corresponding to the name of the package containing the rule under the bin tree.

  - `$(BUILD_FILE_PATH)`: ctx.build_file_path

  - `$(VERSION_FILE)`: ctx.version_file.path

  - `$(INFO_FILE)`: ctx.info_file.path

  - `$(TARGET)`: ctx.label

  - `$(WORKSPACE)`: ctx.workspace_name

See https://docs.bazel.build/versions/main/be/general.html#genrule.cmd and
https://docs.bazel.build/versions/main/be/make-variables.html#predefined_genrule_variables
for more information of how these special variables are expanded.
*�
�
expand_variables 
ctxstarlark rule context (
sexpression to expand (O
outsAdeclared outputs of the rule, for expanding references to outputs[](O
inputs?declared inputs of the rule, for expanding references to inputs[](f
attribute_nameJname of the attribute containing the expression. Used for error reporting."args"(�Expand make variables and substitute like genrule does.

Bazel [pre-defined variables](https://bazel.build/reference/be/make-variables#predefined_variables)
are expanded however only `$@`, `$(@D)` and `$(RULEDIR)` of
[pre-defined genrule variables](https://bazel.build/reference/be/make-variables#predefined_genrule_variables)
are supported.

This function is the same as ctx.expand_make_variables with the additional
genrule-like substitutions of:

  - `$<`: The input file if it is a single file. Else triggers a build error.

  - `$@`: The output file if it is a single file. Else triggers a build error.

  - `$(@D)`: The output directory.

    If there is only one file name in outs, this expands to the directory containing that file.

    If there is only one directory in outs, this expands to the single output directory.

    If there are multiple files, this instead expands to the package's root directory in the bin tree,
    even if all generated files belong to the same subdirectory!

  - `$(RULEDIR)`: The output directory of the rule, that is, the directory
    corresponding to the name of the package containing the rule under the bin tree.

  - `$(BUILD_FILE_PATH)`: ctx.build_file_path

  - `$(VERSION_FILE)`: ctx.version_file.path

  - `$(INFO_FILE)`: ctx.info_file.path

  - `$(TARGET)`: ctx.label

  - `$(WORKSPACE)`: ctx.workspace_name

See https://docs.bazel.build/versions/main/be/general.html#genrule.cmd and
https://docs.bazel.build/versions/main/be/make-variables.html#predefined_genrule_variables
for more information of how these special variables are expanded.
"!
`s` with the variables expanded26
expand_variables"//lib/private:expand_variables.bzl"
 
ctxstarlark rule context (

sexpression to expand (Q
O
outsAdeclared outputs of the rule, for expanding references to outputs[](Q
O
inputs?declared inputs of the rule, for expanding references to inputs[](h
f
attribute_nameJname of the attribute containing the expression. Used for error reporting."args"("Public API for expanding variables�0
libexpand_template.bzl�*expand_template_rule�Template expansion

This performs a simple search over the template file for the keys in substitutions,
and replaces them with the corresponding values.

Values may also use location templates as documented in
[expand_locations](https://github.com/bazel-contrib/bazel-lib/blob/main/docs/expand_make_vars.md#expand_locations)
as well as [configuration variables](https://docs.bazel.build/versions/main/skylark/lib/ctx.html#var)
such as `$(BINDIR)`, `$(TARGET_CPU)`, and `$(COMPILATION_MODE)` as documented in
[expand_variables](https://github.com/bazel-contrib/bazel-lib/blob/main/docs/expand_make_vars.md#expand_variables)."�%
�
expand_template_rule�Template expansion

This performs a simple search over the template file for the keys in substitutions,
and replaces them with the corresponding values.

Values may also use location templates as documented in
[expand_locations](https://github.com/bazel-contrib/bazel-lib/blob/main/docs/expand_make_vars.md#expand_locations)
as well as [configuration variables](https://docs.bazel.build/versions/main/skylark/lib/ctx.html#var)
such as `$(BINDIR)`, `$(TARGET_CPU)`, and `$(COMPILATION_MODE)` as documented in
[expand_variables](https://github.com/bazel-contrib/bazel-lib/blob/main/docs/expand_make_vars.md#expand_variables).*
nameA unique name for this target. @
data2List of targets for additional lookup information.2[]H
is_executable.Whether to mark the output file as executable.2False�
out�Where to write the expanded file.

If the `template` is a source file, then `out` defaults to
be named the same as the template file and outputted to the same
workspace-relative path. In this case there will be no pre-declared
label for the output file. It can be referenced by the target label
instead. This pattern is similar to `copy_to_bin` but with substitutions on
the copy.

Otherwise, `out` defaults to `[name].txt`.2None8�
stamp_substitutions�Mapping of strings to substitutions.

There are overlaid on top of substitutions when stamping is enabled
for the target.

Substitutions can contain $(execpath :target) and $(rootpath :target)
expansions, $(MAKEVAR) expansions and {{STAMP_VAR}} expansions when
stamping is enabled for the target.
2{}�
substitutions�Mapping of strings to substitutions.

Substitutions can contain $(execpath :target) and $(rootpath :target)
expansions, $(MAKEVAR) expansions and {{STAMP_VAR}} expansions when
stamping is enabled for the target.
2{},
templateThe template file to expand. �
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.2-1"4
expand_template!//lib/private:expand_template.bzl,
*
nameA unique name for this target. B
@
data2List of targets for additional lookup information.2[]J
H
is_executable.Whether to mark the output file as executable.2False�
�
out�Where to write the expanded file.

If the `template` is a source file, then `out` defaults to
be named the same as the template file and outputted to the same
workspace-relative path. In this case there will be no pre-declared
label for the output file. It can be referenced by the target label
instead. This pattern is similar to `copy_to_bin` but with substitutions on
the copy.

Otherwise, `out` defaults to `[name].txt`.2None8�
�
stamp_substitutions�Mapping of strings to substitutions.

There are overlaid on top of substitutions when stamping is enabled
for the target.

Substitutions can contain $(execpath :target) and $(rootpath :target)
expansions, $(MAKEVAR) expansions and {{STAMP_VAR}} expansions when
stamping is enabled for the target.
2{}�
�
substitutions�Mapping of strings to substitutions.

Substitutions can contain $(execpath :target) and $(rootpath :target)
expansions, $(MAKEVAR) expansions and {{STAMP_VAR}} expansions when
stamping is enabled for the target.
2{}.
,
templateThe template file to expand. �
�
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.2-1�expand_template)Wrapper macro for `expand_template_rule`.*�
�
expand_template"
namename of resulting rule (|
templatelthe label of a template file, or a list of strings
which are lines representing the content of the template. (=
kwargs1other named parameters to `expand_template_rule`.()Wrapper macro for `expand_template_rule`.2,
expand_template//lib:expand_template.bzl$
"
namename of resulting rule (~
|
templatelthe label of a template file, or a list of strings
which are lines representing the content of the template. (?
=
kwargs1other named parameters to `expand_template_rule`.(Public API for expand template�
libextensions.bzl<hostJ2
&
host
host"//lib:extensions.bzl

host�
toolchainsJ�
�

toolchains,
copy_directory
name2"copy_directory"2
copy_to_directory
name2"copy_to_directory"8
	coreutils
name2"coreutils"
version2"0.5.0"
zstd
name2"zstd".
expand_template
name2"expand_template"(
spawn_binary
name2"spawn_binary"5
bats
name2"bats"
core_version2	"v1.10.0""//lib:extensions.bzlL
,
copy_directory
name2"copy_directory"

name2"copy_directory"U
2
copy_to_directory
name2"copy_to_directory"

name2"copy_to_directory"k
8
	coreutils
name2"coreutils"
version2"0.5.0"

name2"coreutils"

version2"0.5.0".

zstd
name2"zstd"

name2"zstd"O
.
expand_template
name2"expand_template"

name2"expand_template"F
(
spawn_binary
name2"spawn_binary"

name2"spawn_binary"j
5
bats
name2"bats"
core_version2	"v1.10.0"

name2"bats"

core_version2	"v1.10.0"%Module extensions for use with bzlmod�
libglob_match.bzl�
glob_match�Test if the passed path matches the glob expression.

`*` A single asterisk stands for zero or more arbitrary characters except for the the path separator `/` if `match_path_separator` is False

`?` The question mark stands for exactly one character except for the the path separator `/` if `match_path_separator` is False

`**` A double asterisk stands for an arbitrary sequence of 0 or more characters. It is only allowed when preceded by either the beginning of the string or a slash. Likewise it must be followed by a slash or the end of the pattern.
*�
�

glob_match
exprthe glob expression (?
path3the path against which to match the glob expression (u
match_path_separatorTwhether or not to match the path separator '/' when matching `*` and `?` expressionsFalse(�Test if the passed path matches the glob expression.

`*` A single asterisk stands for zero or more arbitrary characters except for the the path separator `/` if `match_path_separator` is False

`?` The question mark stands for exactly one character except for the the path separator `/` if `match_path_separator` is False

`**` A double asterisk stands for an arbitrary sequence of 0 or more characters. It is only allowed when preceded by either the beginning of the string or a slash. Likewise it must be followed by a slash or the end of the pattern.
".
,True if the path matches the glob expression2*

glob_match//lib/private:glob_match.bzl!

exprthe glob expression (A
?
path3the path against which to match the glob expression (w
u
match_path_separatorTwhether or not to match the path separator '/' when matching `*` and `?` expressionsFalse(�is_glob5Determine if the passed string is a global expression*�
�
is_glob)
exprthe potential glob expression (5Determine if the passed string is a global expression"2
0True if the passed string is a global expression2'
is_glob//lib/private:glob_match.bzl+
)
exprthe potential glob expression (
Public API�
libhost_repo.bzl�	host_repo+Exposes information about the host platformR�
�
	host_repo+Exposes information about the host platform.
name"A unique name for this repository. �
repo_mapping�In `WORKSPACE` context only: a dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.

For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).

This attribute is _not_ supported in `MODULE.bazel` context (when invoking a repository rule inside a module extension's implementation function).
*(
	host_repo//lib/private:host_repo.bzl0
.
name"A unique name for this repository. �
�
repo_mapping�In `WORKSPACE` context only: a dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.

For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).

This attribute is _not_ supported in `MODULE.bazel` context (when invoking a repository rule inside a module extension's implementation function).

Public API�"
lib	lists.bzl�every�Check if every item of `arr` passes function `f`.

Example:
  `every(lambda i: i.endswith(".js"), ["app.js", "lib.js"]) // True`
*�
�
every*
f!Function to execute on every item (
arrList to iterate over (�Check if every item of `arr` passes function `f`.

Example:
  `every(lambda i: i.endswith(".js"), ["app.js", "lib.js"]) // True`
"
True or False2 
every//lib/private:lists.bzl,
*
f!Function to execute on every item (!

arrList to iterate over (�filter�Filter a list `arr` by applying a function `f` to each item.

Example:
  `filter(lambda i: i.endswith(".js"), ["app.ts", "app.js", "lib.ts", "lib.js"]) // ["app.js", "lib.js"]`
*�
�
filter*
f!Function to execute on every item (
arrList to iterate over (�Filter a list `arr` by applying a function `f` to each item.

Example:
  `filter(lambda i: i.endswith(".js"), ["app.ts", "app.js", "lib.ts", "lib.js"]) // ["app.js", "lib.js"]`
">
<A new list containing items that passed the filter function.2!
filter//lib/private:lists.bzl,
*
f!Function to execute on every item (!

arrList to iterate over (�find�Find a particular item from list `arr` by a given function `f`.

Unlike `pick`, the `find` method returns a tuple of the index and the value of first item passing by `f`.
Furthermore `find` does not fail if no item passes `f`.
In this case `(-1, None)` is returned.
*�
�
find*
f!Function to execute on every item (
arrList to iterate over (�Find a particular item from list `arr` by a given function `f`.

Unlike `pick`, the `find` method returns a tuple of the index and the value of first item passing by `f`.
Furthermore `find` does not fail if no item passes `f`.
In this case `(-1, None)` is returned.
"
Tuple (index, item)2
find//lib/private:lists.bzl,
*
f!Function to execute on every item (!

arrList to iterate over (�map}Apply a function `f` with each item of `arr` and return a new list.

Example:
  `map(lambda i: i*2, [1, 2, 3]) // [2, 4, 6]`
*�
�
map*
f!Function to execute on every item (
arrList to iterate over (}Apply a function `f` with each item of `arr` and return a new list.

Example:
  `map(lambda i: i*2, [1, 2, 3]) // [2, 4, 6]`
"#
!A new list with all mapped items.2
map//lib/private:lists.bzl,
*
f!Function to execute on every item (!

arrList to iterate over (�onceFCheck if exactly one item in list `arr` passes the given function `f`.*�
�
once*
f!Function to execute on every item (
arrList to iterate over (FCheck if exactly one item in list `arr` passes the given function `f`."
True or False2
once//lib/private:lists.bzl,
*
f!Function to execute on every item (!

arrList to iterate over (�pick�Pick a particular item in list `arr` by a given function `f`.

Unlike `filter`, the `pick` method returns the first item _found_ by `f`.
If no item has passed `f`, the function will _fail_.
*�
�
pick*
f!Function to execute on every item (
arrList to iterate over (�Pick a particular item in list `arr` by a given function `f`.

Unlike `filter`, the `pick` method returns the first item _found_ by `f`.
If no item has passed `f`, the function will _fail_.
"
item2
pick//lib/private:lists.bzl,
*
f!Function to execute on every item (!

arrList to iterate over (�some�Check if at least one item of `arr` passes function `f`.

Example:
  `some(lambda i: i.endswith(".js"), ["app.js", "lib.ts"]) // True`
*�
�
some*
f!Function to execute on every item (
arrList to iterate over (�Check if at least one item of `arr` passes function `f`.

Example:
  `some(lambda i: i.endswith(".js"), ["app.js", "lib.ts"]) // True`
"
True or False2
some//lib/private:lists.bzl,
*
f!Function to execute on every item (!

arrList to iterate over (�uniquewReturn a new list with unique items in it.

Example:
  `unique(["foo", "bar", "foo", "baz"]) // ["foo", "bar", "baz"]`
*�
�
unique
arrList to iterate over (wReturn a new list with unique items in it.

Example:
  `unique(["foo", "bar", "foo", "baz"]) // ["foo", "bar", "baz"]`
"
A new list with unique items2!
unique//lib/private:lists.bzl!

arrList to iterate over (Functions for lists�
liboutput_files.bzl�output_filesjA rule that provides file(s) specific via DefaultInfo from a given target's DefaultInfo or OutputGroupInfo"�
�
output_filesjA rule that provides file(s) specific via DefaultInfo from a given target's DefaultInfo or OutputGroupInfo*
nameA unique name for this target. ^
targetPthe target to look in for requested paths in its' DefaultInfo or OutputGroupInfo �
paths�the paths of the file(s), relative to their roots, to provide via DefaultInfo from the given target's DefaultInfo or OutputGroupInfo d
output_groupNif set, we look in the specified output group for paths instead of DefaultInfo2""".
output_files//lib/private:output_files.bzl*&
DefaultInfo
DefaultInfo<native>,
*
nameA unique name for this target. `
^
targetPthe target to look in for requested paths in its' DefaultInfo or OutputGroupInfo �
�
paths�the paths of the file(s), relative to their roots, to provide via DefaultInfo from the given target's DefaultInfo or OutputGroupInfo f
d
output_groupNif set, we look in the specified output group for paths instead of DefaultInfo2""�make_output_filesGHelper function to generate a output_files target and return its label.*�
�
make_output_files?
name3unique name for the generated `output_files` target (J
target<`target` attribute passed to generated `output_files` target (H
paths;`paths` attribute passed to generated `output_files` target (A
kwargs5parameters to pass to generated `output_files` target(GHelper function to generate a output_files target and return its label."
The label `name`23
make_output_files//lib/private:output_files.bzlA
?
name3unique name for the generated `output_files` target (L
J
target<`target` attribute passed to generated `output_files` target (J
H
paths;`paths` attribute passed to generated `output_files` target (C
A
kwargs5parameters to pass to generated `output_files` target(�A rule that provides file(s) specific via DefaultInfo from a given target's DefaultInfo or OutputGroupInfo.

See also [select_file](https://github.com/bazelbuild/bazel-skylib/blob/main/docs/select_file_doc.md) from bazel-skylib.�
libparams_file.bzl�params_filejGenerates a UTF-8 encoded params file from a list of arguments.

Handles variable substitutions for args.
*�
�
params_file
nameName of the rule. (=
out2Path of the output file, relative to this package. (�
args�
Arguments to concatenate into a params file.

- Subject to 'Make variable' substitution. See https://docs.bazel.build/versions/main/be/make-variables.html.

- Subject to predefined source/output path variables substitutions.

  The predefined variables `execpath`, `execpaths`, `rootpath`, `rootpaths`, `location`, and `locations` take
  label parameters (e.g. `$(execpath //foo:bar)`) and substitute the file paths denoted by that label.

  See https://docs.bazel.build/versions/main/be/make-variables.html#predefined_label_variables for more info.

  NB: This $(location) substitution returns the manifest file path which differs from the `*_binary` & `*_test`
  args and genrule bazel substitutions. This will be fixed in a future major release.
  See docs string of `expand_location_into_runfiles` macro in `internal/common/expand_into_runfiles.bzl`
  for more info.

- Subject to predefined variables & custom variable substitutions.

  Predefined "Make" variables such as `$(COMPILATION_MODE)` and `$(TARGET_CPU)` are expanded.
  See https://docs.bazel.build/versions/main/be/make-variables.html#predefined_variables.

  Custom variables are also expanded including variables set through the Bazel CLI with `--define=SOME_VAR=SOME_VALUE`.
  See https://docs.bazel.build/versions/main/be/make-variables.html#custom_variables.

  Predefined genrule variables are not supported in this context.[](8
data*Data for `$(location)` expansions in args.[](�
newline�Line endings to use. One of [`"auto"`, `"unix"`, `"windows"`].

- `"auto"` for platform-determined
- `"unix"` for LF
- `"windows"` for CRLF"auto"((
kwargsundocumented named arguments(jGenerates a UTF-8 encoded params file from a list of arguments.

Handles variable substitutions for args.
2$
params_file//lib:params_file.bzl

nameName of the rule. (?
=
out2Path of the output file, relative to this package. (�
�
args�
Arguments to concatenate into a params file.

- Subject to 'Make variable' substitution. See https://docs.bazel.build/versions/main/be/make-variables.html.

- Subject to predefined source/output path variables substitutions.

  The predefined variables `execpath`, `execpaths`, `rootpath`, `rootpaths`, `location`, and `locations` take
  label parameters (e.g. `$(execpath //foo:bar)`) and substitute the file paths denoted by that label.

  See https://docs.bazel.build/versions/main/be/make-variables.html#predefined_label_variables for more info.

  NB: This $(location) substitution returns the manifest file path which differs from the `*_binary` & `*_test`
  args and genrule bazel substitutions. This will be fixed in a future major release.
  See docs string of `expand_location_into_runfiles` macro in `internal/common/expand_into_runfiles.bzl`
  for more info.

- Subject to predefined variables & custom variable substitutions.

  Predefined "Make" variables such as `$(COMPILATION_MODE)` and `$(TARGET_CPU)` are expanded.
  See https://docs.bazel.build/versions/main/be/make-variables.html#predefined_variables.

  Custom variables are also expanded including variables set through the Bazel CLI with `--define=SOME_VAR=SOME_VALUE`.
  See https://docs.bazel.build/versions/main/be/make-variables.html#custom_variables.

  Predefined genrule variables are not supported in this context.[](:
8
data*Data for `$(location)` expansions in args.[](�
�
newline�Line endings to use. One of [`"auto"`, `"unix"`, `"windows"`].

- `"auto"` for platform-determined
- `"unix"` for LF
- `"windows"` for CRLF"auto"(*
(
kwargsundocumented named arguments(params_file public API�(
lib	paths.bzl�
relative_file�Resolves a relative path between two files, "to_file" and "frm_file".

If neither of the paths begin with ../ it is assumed that they share the same root. When finding the relative path,
the incoming files are treated as actual files (not folders) so the resulting relative path may differ when compared
to passing the same arguments to python's "os.path.relpath()" or NodeJs's "path.relative()".

For example, 'relative_file("../foo/foo.txt", "bar/bar.txt")' will return '../../foo/foo.txt'
*�
�
relative_file>
to_file/the path with file name to resolve to, from frm (7
frm_file'the path with file name to resolve from (�Resolves a relative path between two files, "to_file" and "frm_file".

If neither of the paths begin with ../ it is assumed that they share the same root. When finding the relative path,
the incoming files are treated as actual files (not folders) so the resulting relative path may differ when compared
to passing the same arguments to python's "os.path.relpath()" or NodeJs's "path.relative()".

For example, 'relative_file("../foo/foo.txt", "bar/bar.txt")' will return '../../foo/foo.txt'
"E
CThe relative path from frm_file to to_file, including the file name2)
_relative_file//lib/private:paths.bzl@
>
to_file/the path with file name to resolve to, from frm (9
7
frm_file'the path with file name to resolve from (�to_output_relative_pathDThe relative path from bazel-out/[arch]/bin to the given File object*�
�
to_output_relative_path
filea `File` object (DThe relative path from bazel-out/[arch]/bin to the given File object")
'The output relative path for the `File`23
_to_output_relative_path//lib/private:paths.bzl

filea `File` object (�to_repository_relative_path�The repository relative path for a `File`

This is the full runfiles path of a `File` excluding its workspace name.

This differs from  root path (a.k.a. [short_path](https://bazel.build/rules/lib/File#short_path)) and
rlocation path as it does not include the repository name if the `File` is from an external repository.
*�
�
to_repository_relative_path
filea `File` object (�The repository relative path for a `File`

This is the full runfiles path of a `File` excluding its workspace name.

This differs from  root path (a.k.a. [short_path](https://bazel.build/rules/lib/File#short_path)) and
rlocation path as it does not include the repository name if the `File` is from an external repository.
"-
+The repository relative path for the `File`27
_to_repository_relative_path//lib/private:paths.bzl

filea `File` object (�to_rlocation_path�The rlocation path for a `File`

This produces the same value as the `rlocationpath` predefined source/output path variable.

From https://bazel.build/reference/be/make-variables#predefined_genrule_variables:

> `rlocationpath`: The path a built binary can pass to the `Rlocation` function of a runfiles
> library to find a dependency at runtime, either in the runfiles directory (if available)
> or using the runfiles manifest.

> This is similar to root path (a.k.a. [short_path](https://bazel.build/rules/lib/File#short_path))
> in that it does not contain configuration prefixes, but differs in that it always starts with the
> name of the repository.

> The rlocation path of a `File` in an external repository repo will start with `repo/`, followed by the
> repository-relative path.

> Passing this path to a binary and resolving it to a file system path using the runfiles libraries
> is the preferred approach to find dependencies at runtime. Compared to root path, it has the
> advantage that it works on all platforms and even if the runfiles directory is not available.
*�

�	
to_rlocation_path*
ctxstarlark rule execution context (
filea `File` object (�The rlocation path for a `File`

This produces the same value as the `rlocationpath` predefined source/output path variable.

From https://bazel.build/reference/be/make-variables#predefined_genrule_variables:

> `rlocationpath`: The path a built binary can pass to the `Rlocation` function of a runfiles
> library to find a dependency at runtime, either in the runfiles directory (if available)
> or using the runfiles manifest.

> This is similar to root path (a.k.a. [short_path](https://bazel.build/rules/lib/File#short_path))
> in that it does not contain configuration prefixes, but differs in that it always starts with the
> name of the repository.

> The rlocation path of a `File` in an external repository repo will start with `repo/`, followed by the
> repository-relative path.

> Passing this path to a binary and resolving it to a file system path using the runfiles libraries
> is the preferred approach to find dependencies at runtime. Compared to root path, it has the
> advantage that it works on all platforms and even if the runfiles directory is not available.
""
 The rlocationpath for the `File`2-
_to_rlocation_path//lib/private:paths.bzl,
*
ctxstarlark rule execution context (

filea `File` object (&Utilities for working with file paths.�
libplatform_utils.bzl�&platform_utils.host_platform_is_darwin*h
f
&platform_utils.host_platform_is_darwin2<
_host_platform_is_darwin //lib/private:platform_utils.bzl�%platform_utils.host_platform_is_linux*f
d
%platform_utils.host_platform_is_linux2;
_host_platform_is_linux //lib/private:platform_utils.bzl�'platform_utils.host_platform_is_windows*j
h
'platform_utils.host_platform_is_windows2=
_host_platform_is_windows //lib/private:platform_utils.bzl
Public API�.
librepo_utils.bzl�repo_utils.arch�Returns a normalized name of the host CPU architecture.

Alias architectures names are normalized:

x86_64 => amd64
aarch64 => arm64

The result can be used to generate repository names for host toolchain
repositories for toolchains that use these normalized names.

Common architecture names are:

- amd64
- arm64
- s390x
- ppc64le
*�
�
repo_utils.arch
rctxrctx (�Returns a normalized name of the host CPU architecture.

Alias architectures names are normalized:

x86_64 => amd64
aarch64 => arm64

The result can be used to generate repository names for host toolchain
repositories for toolchains that use these normalized names.

Common architecture names are:

- amd64
- arm64
- s390x
- ppc64le
".
,The normalized host CPU architecture string.2%
_arch//lib/private:repo_utils.bzl

rctxrctx (�repo_utils.get_env_varCFind an environment variable in system. Doesn't %-escape the value!*�
�
repo_utils.get_env_var
rctxrctx (%
nameenvironment variable name (F
default7default value to return if env var is not set in system (CFind an environment variable in system. Doesn't %-escape the value!"@
>The environment variable value or the default if it is not set2,
_get_env_var//lib/private:repo_utils.bzl

rctxrctx ('
%
nameenvironment variable name (H
F
default7default value to return if env var is not set in system (�repo_utils.get_home_directory*p
`
repo_utils.get_home_directory

rctx (23
_get_home_directory//lib/private:repo_utils.bzl


rctx (�repo_utils.is_darwin3Returns true if the host operating system is Darwin*�
�
repo_utils.is_darwin

rctx (3Returns true if the host operating system is Darwin2*

_is_darwin//lib/private:repo_utils.bzl


rctx (�repo_utils.is_linux2Returns true if the host operating system is Linux*�
�
repo_utils.is_linux

rctx (2Returns true if the host operating system is Linux2)
	_is_linux//lib/private:repo_utils.bzl


rctx (�repo_utils.is_windows4Returns true if the host operating system is Windows*�
�
repo_utils.is_windows

rctx (4Returns true if the host operating system is Windows2+
_is_windows//lib/private:repo_utils.bzl


rctx (�repo_utils.os-Returns the name of the host operating system*�
�
repo_utils.os
rctxrctx (-Returns the name of the host operating system"Q
OThe string "windows", "linux", "freebsd" or "darwin" that describes the host os2#
_os//lib/private:repo_utils.bzl

rctxrctx (�repo_utils.platform�Returns a normalized name of the host os and CPU architecture.

Alias architectures names are normalized:

x86_64 => amd64
aarch64 => arm64

The result can be used to generate repository names for host toolchain
repositories for toolchains that use these normalized names.

Common os & architecture pairs that are returned are,

- darwin_amd64
- darwin_arm64
- linux_amd64
- linux_arm64
- linux_s390x
- linux_ppc64le
- windows_amd64
*�
�
repo_utils.platform
rctxrctx (�Returns a normalized name of the host os and CPU architecture.

Alias architectures names are normalized:

x86_64 => amd64
aarch64 => arm64

The result can be used to generate repository names for host toolchain
repositories for toolchains that use these normalized names.

Common os & architecture pairs that are returned are,

- darwin_amd64
- darwin_arm64
- linux_amd64
- linux_arm64
- linux_s390x
- linux_ppc64le
- windows_amd64
"J
HThe normalized `<os>_<arch>` string of the host os and CPU architecture.2)
	_platform//lib/private:repo_utils.bzl

rctxrctx (�patch�Implementation of patching an already extracted repository.

This rule is intended to be used in the implementation function of
a repository rule. If the parameters `patches`, `patch_tool`,
`patch_args`, `patch_cmds` and `patch_cmds_win` are not specified
then they are taken from `ctx.attr`.
*�
�	
patchW
ctxLThe repository context of the repository rule calling this utility
function. (O
patches<The patch files to apply. List of strings, Labels, or paths.None(i

patch_cmdsSBash commands to run for patching, passed one at a
time to bash -c. List of stringsNone(�
patch_cmds_win�Powershell commands to run for patching, passed
one at a time to powershell /c. List of strings. If the
boolean value of this parameter is false, patch_cmds will be
used and this parameter will be ignored.None(U

patch_tool?Path of the patch tool to execute for applying
patches. String.None(K

patch_args5Arguments to pass to the patch tool. List of strings.None(\
authLAn optional dict specifying authentication information for some of the URLs.None(<
patch_directory!Directory to apply the patches inNone(�Implementation of patching an already extracted repository.

This rule is intended to be used in the implementation function of
a repository rule. If the parameters `patches`, `patch_tool`,
`patch_args`, `patch_cmds` and `patch_cmds_win` are not specified
then they are taken from `ctx.attr`.
2 
patch//lib/private:patch.bzlY
W
ctxLThe repository context of the repository rule calling this utility
function. (Q
O
patches<The patch files to apply. List of strings, Labels, or paths.None(k
i

patch_cmdsSBash commands to run for patching, passed one at a
time to bash -c. List of stringsNone(�
�
patch_cmds_win�Powershell commands to run for patching, passed
one at a time to powershell /c. List of strings. If the
boolean value of this parameter is false, patch_cmds will be
used and this parameter will be ignored.None(W
U

patch_tool?Path of the patch tool to execute for applying
patches. String.None(M
K

patch_args5Arguments to pass to the patch tool. List of strings.None(^
\
authLAn optional dict specifying authentication information for some of the URLs.None(>
<
patch_directory!Directory to apply the patches inNone(
Public API�3
librepositories.bzl�bazel_lib_dependenciesLoad dependencies*_
]
bazel_lib_dependenciesLoad dependencies20
bazel_lib_dependencies//lib:repositories.bzl�register_zstd_toolchains)Registers zstd toolchain and repositories*�
�
register_zstd_toolchainsN
name<override the prefix for the generated toolchain repositories"zstd"(�
register�whether to call through to native.register_toolchains.
Should be True for WORKSPACE users, but false when used under bzlmod extensionTrue()Registers zstd toolchain and repositories22
register_zstd_toolchains//lib:repositories.bzlP
N
name<override the prefix for the generated toolchain repositories"zstd"(�
�
register�whether to call through to native.register_toolchains.
Should be True for WORKSPACE users, but false when used under bzlmod extensionTrue(�	register_bats_toolchains)Registers bats toolchain and repositories*�	
�
register_bats_toolchainsN
name<override the prefix for the generated toolchain repositories"bats"(5
core_versionbats-core version to use	"v1.10.0"(:
support_versionbats-support version to use"v0.3.0"(8
assert_versionbats-assert version to use"v2.1.0"(4
file_versionbats-file version to use"v0.4.0"(2
	librariesadditional labels for libraries[](�
register�whether to call through to native.register_toolchains.
Should be True for WORKSPACE users, but false when used under bzlmod extensionTrue()Registers bats toolchain and repositories22
register_bats_toolchains//lib:repositories.bzlP
N
name<override the prefix for the generated toolchain repositories"bats"(7
5
core_versionbats-core version to use	"v1.10.0"(<
:
support_versionbats-support version to use"v0.3.0"(:
8
assert_versionbats-assert version to use"v2.1.0"(6
4
file_versionbats-file version to use"v0.4.0"(4
2
	librariesadditional labels for libraries[](�
�
register�whether to call through to native.register_toolchains.
Should be True for WORKSPACE users, but false when used under bzlmod extensionTrue(�register_coreutils_toolchains.Registers coreutils toolchain and repositories*�
�
register_coreutils_toolchainsS
name<override the prefix for the generated toolchain repositories"coreutils"(l
versionVthe version of coreutils to execute (see https://github.com/uutils/coreutils/releases)"0.5.0"(�
register�whether to call through to native.register_toolchains.
Should be True for WORKSPACE users, but false when used under bzlmod extensionTrue(.Registers coreutils toolchain and repositories27
register_coreutils_toolchains//lib:repositories.bzlU
S
name<override the prefix for the generated toolchain repositories"coreutils"(n
l
versionVthe version of coreutils to execute (see https://github.com/uutils/coreutils/releases)"0.5.0"(�
�
register�whether to call through to native.register_toolchains.
Should be True for WORKSPACE users, but false when used under bzlmod extensionTrue(�"register_copy_directory_toolchains3Registers copy_directory toolchain and repositories*�
�
"register_copy_directory_toolchainsX
name<override the prefix for the generated toolchain repositories"copy_directory"(�
register�whether to call through to native.register_toolchains.
Should be True for WORKSPACE users, but false when used under bzlmod extensionTrue(3Registers copy_directory toolchain and repositories2<
"register_copy_directory_toolchains//lib:repositories.bzlZ
X
name<override the prefix for the generated toolchain repositories"copy_directory"(�
�
register�whether to call through to native.register_toolchains.
Should be True for WORKSPACE users, but false when used under bzlmod extensionTrue(�%register_copy_to_directory_toolchains6Registers copy_to_directory toolchain and repositories*�
�
%register_copy_to_directory_toolchains[
name<override the prefix for the generated toolchain repositories"copy_to_directory"(�
register�whether to call through to native.register_toolchains.
Should be True for WORKSPACE users, but false when used under bzlmod extensionTrue(6Registers copy_to_directory toolchain and repositories2?
%register_copy_to_directory_toolchains//lib:repositories.bzl]
[
name<override the prefix for the generated toolchain repositories"copy_to_directory"(�
�
register�whether to call through to native.register_toolchains.
Should be True for WORKSPACE users, but false when used under bzlmod extensionTrue(�#register_expand_template_toolchains4Registers expand_template toolchain and repositories*�
�
#register_expand_template_toolchainsY
name<override the prefix for the generated toolchain repositories"expand_template"(�
register�whether to call through to native.register_toolchains.
Should be True for WORKSPACE users, but false when used under bzlmod extensionTrue(4Registers expand_template toolchain and repositories2=
#register_expand_template_toolchains//lib:repositories.bzl[
Y
name<override the prefix for the generated toolchain repositories"expand_template"(�
�
register�whether to call through to native.register_toolchains.
Should be True for WORKSPACE users, but false when used under bzlmod extensionTrue(� register_spawn_binary_toolchains1Registers spawn_binary toolchain and repositories*�
�
 register_spawn_binary_toolchainsV
name<override the prefix for the generated toolchain repositories"spawn_binary"(�
register�whether to call through to native.register_toolchains.
Should be True for WORKSPACE users, but false when used under bzlmod extensionTrue(1Registers spawn_binary toolchain and repositories2:
 register_spawn_binary_toolchains//lib:repositories.bzlX
V
name<override the prefix for the generated toolchain repositories"spawn_binary"(�
�
register�whether to call through to native.register_toolchains.
Should be True for WORKSPACE users, but false when used under bzlmod extensionTrue(�bazel_lib_register_toolchains�Register all bazel-lib toolchains at their default versions.

To be more selective about which toolchains and versions to register,
call the individual toolchain registration macros.*�
�
bazel_lib_register_toolchains�Register all bazel-lib toolchains at their default versions.

To be more selective about which toolchains and versions to register,
call the individual toolchain registration macros.27
bazel_lib_register_toolchains//lib:repositories.bzl:Macros for loading dependencies and registering toolchains�
libresource_sets.bzleresource_set*S
C
resource_set

attr (2'
resource_set//lib:resource_sets.bzl


attr (�resource_set_for8return an appropriate resource_set for the given values.*�
�
resource_set_for�
	cpu_cores�(int) the number of cores to request. 0 means "use the bazel
default". If the value is larger than the hard-coded max value, it will
be clamped to the max value.0(�
mem_mb�(int) megabytes of memory to request. 0 means "use the bazel
default". The value will be rounded up to a supported ram value, and
will be clamped to the max value.0(8return an appropriate resource_set for the given values."W
Ua resource_set function, as required by `ctx.actions.run` and `ctx.actions.run_shell`2+
resource_set_for//lib:resource_sets.bzl�
�
	cpu_cores�(int) the number of cores to request. 0 means "use the bazel
default". If the value is larger than the hard-coded max value, it will
be clamped to the max value.0(�
�
mem_mb�(int) megabytes of memory to request. 0 means "use the bazel
default". The value will be rounded up to a supported ram value, and
will be clamped to the max value.0(�Utilities for rules that expose resource_set on ctx.actions.run[_shell]

Workaround for https://github.com/bazelbuild/bazel/issues/15187

Note, this workaround only provides some fixed values for either CPU or Memory.

Rule authors who are ALSO the BUILD author might know better, and can
write custom resource_set functions for use within their own repository.
This seems to be the use case that Google engineers imagined.�y
librun_binary.bzl�w
run_binary�Runs a binary as a build action.

This rule does not require Bash (unlike `native.genrule`).

By default the binary is spawned directly. When any of the `stdout`, `stderr`,
`exit_code_out`, `chdir`, `silent_on_success`, or `fail_on` attributes is set, the binary is
instead launched through a small wrapper (`spawn_binary`) that provides these
features. This is handy both to feed a program's output into a downstream action
when the program has no flag to write it to a file, and to silence the output of
otherwise-noisy successful build steps. The wrapper is only used when such a
feature is requested, so the common case incurs no extra overhead.
*�r
�;

run_binary
nameThe target name (�
tool�The tool to run in the action.

Must be the label of a *_binary rule of a rule that generates an executable file, or of
a file that can be executed as a subprocess (e.g. an .exe or .bat file on Windows or a
binary with executable permission on Linux). This label is available for `$(location)`
expansion in `args` and `env`. ({
srcsmAdditional inputs of the action.

These labels are available for `$(location)` expansion in `args` and `env`.[](�
args�Command line arguments of the binary.

Subject to `$(location)` and make variable expansions via
[expand_location](./expand_make_vars#expand_locations)
and [expand_make_vars](./expand_make_vars).[](�
env�Environment variables of the action.

Subject to `$(location)` and make variable expansions via
[expand_location](./expand_make_vars#expand_locations)
and [expand_make_vars](./expand_make_vars).{}(�
outs�Output files generated by the action.

These labels are available for `$(location)` expansion in `args` and `env`.

Output files cannot be nested within output directories in out_dirs.[](�
out_dirs�Output directories generated by the action.

These labels are _not_ available for `$(location)` expansion in `args` and `env` since
they are not pre-declared labels created via `attr.output_list()`. Output directories are
declared instead by `ctx.actions.declare_directory`.

Output directories cannot be nested within other output directories in out_dirs.[](�
stdout�Output file to capture the stdout of the binary to.

When set, the binary is launched through a small wrapper that redirects its
standard output to this file. The file can later be used as an input to
another target, subject to the same semantics as `outs`. If the binary also
creates declared outputs, those must still be created.

Standard input is always passed through to the binary unchanged. When none of
the wrapper features are set, the binary is spawned directly without the wrapper.None(�
stderr�Output file to capture the stderr of the binary to.

Behaves like `stdout`, but for the standard error stream. The file can later
be used as an input to another target, subject to the same semantics as `outs`.None(�
exit_code_out�Output file to capture the exit code of the binary to.

When set, the binary is allowed to exit non-zero without failing the action:
its exit code is written to this file (as a decimal string) and the action
itself succeeds. Any declared `outs`/`out_dirs` must still be created. This is
useful to record the result of a tool whose failure should be handled by a
downstream target rather than breaking the build.

When `fail_on` is also set, only the listed exit codes fail the action; the
exit code is still written to this file.None(�
chdir�Working directory to run the binary in.

When set, the binary is run with this as its working directory instead of the
execution root. Subject to `$(location)` and make variable expansions. Note
that paths in `args`/`env` are expanded relative to the execution root, so a
program that receives such paths and is also given a `chdir` typically needs
absolute paths (for example via `$(execpath ...)` combined with `$(RULEDIR)`).None(�
silent_on_success�Suppress the binary's output unless it fails.

When True, stdout and stderr that are not being captured to a file are buffered
and only forwarded to the console if the action is treated as a failure. With
`fail_on`, that means exit codes listed in `fail_on`; otherwise a non-zero
exit code. This silences logspam from successful build steps while preserving
diagnostics on failure.False(�
fail_on�Exit codes that should fail the action.

When set, the binary is launched through the spawn_binary wrapper and only the
listed exit codes cause the action to fail. All other exit codes are treated
as success. This is useful for tools such as `diff` that use non-zero exit
codes for non-error conditions (for example exit `1` when files differ and
exit `2` on error, or exit `0` when `grep` finds a match). Can be combined
with `exit_code_out` to record the exit code while still failing the action
on specific codes. `silent_on_success` uses the same success/failure decision
when deciding whether to forward buffered output.[](c
mnemonicHA one-word description of the action, for example, CppCompile or GoLink."RunBinary"(�
progress_message�Progress message to show to the user during the build, for example,
"Compiling foo.cc to create foo.o". The message may contain %{label}, %{input}, or
%{output} patterns, which are substituted with label string, first input, or output's
path, respectively. Prefer to use patterns instead of static strings, because the former
are more efficient.None(�
execution_requirements�Information for scheduling the action.

For example,

```
execution_requirements = {
    "no-cache": "1",
},
```

See https://docs.bazel.build/versions/main/be/common-definitions.html#common.tags for useful keys.None(�
use_default_shell_env�Passed to the underlying ctx.actions.run.

May introduce non-determinism when True; use with care!
See e.g. https://github.com/bazelbuild/bazel/issues/4912

Refer to https://bazel.build/rules/lib/builtins/actions#run for more details.False(�

stamp�
Whether to include build status files as inputs to the tool. Possible values:

- `stamp = 0` (default): Never include build status files as inputs to the tool.
    This gives good build result caching.
    Most tools don't use the status files, so including them in `--stamp` builds makes those
    builds have many needless cache misses.
    (Note: this default is different from most rules with an integer-typed `stamp` attribute.)
- `stamp = 1`: Always include build status files as inputs to the tool, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = -1`: Inclusion of build status files as inputs is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.

When stamping is enabled, an additional two environment variables will be set for the action:
    - `BAZEL_STABLE_STATUS_FILE`
    - `BAZEL_VOLATILE_STATUS_FILE`

These files can be read and parsed by the action, for example to pass some values to a linker.0(�
tools�A list of tool dependencies for this action.

These are treated similarly to srcs, except that they are built in
the exec configuration. Any code that will be executed as part of
the action should generally be listed here instead of in srcs.[]( 
kwargsAdditional arguments(�Runs a binary as a build action.

This rule does not require Bash (unlike `native.genrule`).

By default the binary is spawned directly. When any of the `stdout`, `stderr`,
`exit_code_out`, `chdir`, `silent_on_success`, or `fail_on` attributes is set, the binary is
instead launched through a small wrapper (`spawn_binary`) that provides these
features. This is handy both to feed a program's output into a downstream action
when the program has no flag to write it to a file, and to silence the output of
otherwise-noisy successful build steps. The wrapper is only used when such a
feature is requested, so the common case incurs no extra overhead.
2*

run_binary//lib/private:run_binary.bzl

nameThe target name (�
�
tool�The tool to run in the action.

Must be the label of a *_binary rule of a rule that generates an executable file, or of
a file that can be executed as a subprocess (e.g. an .exe or .bat file on Windows or a
binary with executable permission on Linux). This label is available for `$(location)`
expansion in `args` and `env`. (}
{
srcsmAdditional inputs of the action.

These labels are available for `$(location)` expansion in `args` and `env`.[](�
�
args�Command line arguments of the binary.

Subject to `$(location)` and make variable expansions via
[expand_location](./expand_make_vars#expand_locations)
and [expand_make_vars](./expand_make_vars).[](�
�
env�Environment variables of the action.

Subject to `$(location)` and make variable expansions via
[expand_location](./expand_make_vars#expand_locations)
and [expand_make_vars](./expand_make_vars).{}(�
�
outs�Output files generated by the action.

These labels are available for `$(location)` expansion in `args` and `env`.

Output files cannot be nested within output directories in out_dirs.[](�
�
out_dirs�Output directories generated by the action.

These labels are _not_ available for `$(location)` expansion in `args` and `env` since
they are not pre-declared labels created via `attr.output_list()`. Output directories are
declared instead by `ctx.actions.declare_directory`.

Output directories cannot be nested within other output directories in out_dirs.[](�
�
stdout�Output file to capture the stdout of the binary to.

When set, the binary is launched through a small wrapper that redirects its
standard output to this file. The file can later be used as an input to
another target, subject to the same semantics as `outs`. If the binary also
creates declared outputs, those must still be created.

Standard input is always passed through to the binary unchanged. When none of
the wrapper features are set, the binary is spawned directly without the wrapper.None(�
�
stderr�Output file to capture the stderr of the binary to.

Behaves like `stdout`, but for the standard error stream. The file can later
be used as an input to another target, subject to the same semantics as `outs`.None(�
�
exit_code_out�Output file to capture the exit code of the binary to.

When set, the binary is allowed to exit non-zero without failing the action:
its exit code is written to this file (as a decimal string) and the action
itself succeeds. Any declared `outs`/`out_dirs` must still be created. This is
useful to record the result of a tool whose failure should be handled by a
downstream target rather than breaking the build.

When `fail_on` is also set, only the listed exit codes fail the action; the
exit code is still written to this file.None(�
�
chdir�Working directory to run the binary in.

When set, the binary is run with this as its working directory instead of the
execution root. Subject to `$(location)` and make variable expansions. Note
that paths in `args`/`env` are expanded relative to the execution root, so a
program that receives such paths and is also given a `chdir` typically needs
absolute paths (for example via `$(execpath ...)` combined with `$(RULEDIR)`).None(�
�
silent_on_success�Suppress the binary's output unless it fails.

When True, stdout and stderr that are not being captured to a file are buffered
and only forwarded to the console if the action is treated as a failure. With
`fail_on`, that means exit codes listed in `fail_on`; otherwise a non-zero
exit code. This silences logspam from successful build steps while preserving
diagnostics on failure.False(�
�
fail_on�Exit codes that should fail the action.

When set, the binary is launched through the spawn_binary wrapper and only the
listed exit codes cause the action to fail. All other exit codes are treated
as success. This is useful for tools such as `diff` that use non-zero exit
codes for non-error conditions (for example exit `1` when files differ and
exit `2` on error, or exit `0` when `grep` finds a match). Can be combined
with `exit_code_out` to record the exit code while still failing the action
on specific codes. `silent_on_success` uses the same success/failure decision
when deciding whether to forward buffered output.[](e
c
mnemonicHA one-word description of the action, for example, CppCompile or GoLink."RunBinary"(�
�
progress_message�Progress message to show to the user during the build, for example,
"Compiling foo.cc to create foo.o". The message may contain %{label}, %{input}, or
%{output} patterns, which are substituted with label string, first input, or output's
path, respectively. Prefer to use patterns instead of static strings, because the former
are more efficient.None(�
�
execution_requirements�Information for scheduling the action.

For example,

```
execution_requirements = {
    "no-cache": "1",
},
```

See https://docs.bazel.build/versions/main/be/common-definitions.html#common.tags for useful keys.None(�
�
use_default_shell_env�Passed to the underlying ctx.actions.run.

May introduce non-determinism when True; use with care!
See e.g. https://github.com/bazelbuild/bazel/issues/4912

Refer to https://bazel.build/rules/lib/builtins/actions#run for more details.False(�

�

stamp�
Whether to include build status files as inputs to the tool. Possible values:

- `stamp = 0` (default): Never include build status files as inputs to the tool.
    This gives good build result caching.
    Most tools don't use the status files, so including them in `--stamp` builds makes those
    builds have many needless cache misses.
    (Note: this default is different from most rules with an integer-typed `stamp` attribute.)
- `stamp = 1`: Always include build status files as inputs to the tool, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = -1`: Inclusion of build status files as inputs is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.

When stamping is enabled, an additional two environment variables will be set for the action:
    - `BAZEL_STABLE_STATUS_FILE`
    - `BAZEL_VOLATILE_STATUS_FILE`

These files can be read and parsed by the action, for example to pass some values to a linker.0(�
�
tools�A list of tool dependencies for this action.

These are treated similarly to srcs, except that they are built in
the exec configuration. Any code that will be executed as part of
the action should generally be listed here instead of in srcs.[]("
 
kwargsAdditional arguments(�Runs a binary as a build action. This rule does not require Bash (unlike native.genrule()).

This fork of bazel-skylib's run_binary adds directory output support and better makevar expansions.�!
libstamping.bzl�maybe_stampPProvide the bazel-out/stable_status.txt and bazel-out/volatile_status.txt files.*�
�
maybe_stamp
ctxThe rule context (PProvide the bazel-out/stable_status.txt and bazel-out/volatile_status.txt files."�
�If stamping is not enabled for this rule under the current build, returns None.
Otherwise, returns a struct containing (volatile_status_file, stable_status_file) keys2!
maybe_stamp//lib:stamping.bzl

ctxThe rule context (�# Version Stamping

Bazel is generally only a build tool, and is unaware of your version control system.
However, when publishing releases, you may want to embed version information in the resulting distribution.
Bazel supports this with the concept of a "Workspace status" which is evaluated before each build.
See [the Bazel workspace status docs](https://docs.bazel.build/versions/master/user-manual.html#workspace_status)

To stamp a build, you pass the `--stamp` argument to Bazel.

> Note: https://github.com/bazelbuild/bazel/issues/14341 proposes that Bazel enforce this by
> only giving constant values to rule implementations when stamping isn't enabled.

Stamping is typically performed on a later action in the graph, like on a linking or packaging rule (`pkg_*`).
This means that a changed status variable only causes that action, not re-compilation and thus does not cause cascading re-builds.

Bazel provides a couple of statuses by default, such as `BUILD_EMBED_LABEL` which is the value of the `--embed_label`
argument, as well as `BUILD_HOST`, `BUILD_TIMESTAMP`, and `BUILD_USER`.
You can supply more with the workspace status script, see below.

Some rules accept an attribute that uses the status variables.
They will usually say something like "subject to stamp variable replacements".

## Stamping with a Workspace status script

To define additional statuses, pass the `--workspace_status_command` flag to `bazel`.
This slows down every build, so you should avoid passing this flag unless you need to stamp this build.
The value of this flag is a path to a script that prints space-separated key/value pairs, one per line, such as

```bash
#!/usr/bin/env bash
echo STABLE_GIT_COMMIT $(git rev-parse HEAD)
```
> For a more full-featured script, take a look at this [example in Angular]

Make sure you set the executable bit, eg. `chmod +x tools/bazel_stamp_vars.sh`.

> **NOTE** keys that start with `STABLE_` will cause a re-build when they change.
> Other keys will NOT cause a re-build, so stale values can appear in your app.
> Non-stable (volatile) keys should typically be things like timestamps that always vary between builds.

You might like to encode your setup using an entry in `.bazelrc` such as:

```sh
# This tells Bazel how to interact with the version control system
# Enable this with --config=release
build:release --stamp --workspace_status_command=./tools/bazel_stamp_vars.sh
```

[example in Angular]: https://github.com/angular/angular/blob/df274b478e6597cb1a2f31bb9f599281065aa250/dev-infra/release/env-stamp.ts

## Writing a custom rule which reads stamp variables

First, load the helpers:

```starlark
load("@bazel_lib//lib:stamping.bzl", "STAMP_ATTRS", "maybe_stamp")
```

In your rule implementation, call the `maybe_stamp` function.
If it returns `None` then this build doesn't have stamping enabled.
Otherwise you can use the returned struct to access two files.

1. The `stable_status` file contains the keys which were prefixed with `STABLE_`, see above.
2. The `volatile_status` file contains the rest of the keys.

```starlark
def _rule_impl(ctx):
    args = ctx.actions.args()
    inputs = []
    stamp = maybe_stamp(ctx)
    if stamp:
        args.add("--volatile_status_file", stamp.volatile_status_file.path)
        args.add("--stable_status_file", stamp.stable_status_file.path)
        inputs.extend([stamp.volatile_status_file, stamp.stable_status_file])

    # ... call actions which parse the stamp files and do something with the values ...
```

Finally, in the declaration of the rule, include the `STAMP_ATTRS` to declare attributes
which are read by that `maybe_stamp` function above.

```starlark
my_stamp_aware_rule = rule(
    attrs = dict({
        # ... my attributes ...
    }, **STAMP_ATTRS),
)
```�
libstrings.bzl�chr�returns a string encoding a codepoint

chr returns a string that encodes the single Unicode code
point whose value is specified by the integer `i`
*�
�
chr"
iposition of the character (�returns a string encoding a codepoint

chr returns a string that encodes the single Unicode code
point whose value is specified by the integer `i`
" 
unicode string of the position2 
chr//lib/private:strings.bzl$
"
iposition of the character (�ord�returns the codepoint of a character

ord(c) returns the integer value of the sole Unicode code point
encoded by the string `c`.

If `c` does not encode exactly one Unicode code point, `ord` fails.
Each invalid code within the string is treated as if it encodes the
Unicode replacement character, U+FFFD.
*�
�
ord2
c)character whose codepoint to be returned. (�returns the codepoint of a character

ord(c) returns the integer value of the sole Unicode code point
encoded by the string `c`.

If `c` does not encode exactly one Unicode code point, `ord` fails.
Each invalid code within the string is treated as if it encodes the
Unicode replacement character, U+FFFD.
"
codepoint of `c` argument.2 
ord//lib/private:strings.bzl4
2
c)character whose codepoint to be returned. (�hex,Format integer to hexadecimal representation*�
�
hex
numbernumber to format (,Format integer to hexadecimal representation"3
1hexadecimal representation of the number argument2 
hex//lib/private:strings.bzl 

numbernumber to format (�
split_args�Split a string into a list space separated arguments

Unlike the naive `.split(" ")`, this function takes quoted strings
and escapes into account.
*�
�

split_args
sinput string (�Split a string into a list space separated arguments

Unlike the naive `.split(" ")`, this function takes quoted strings
and escapes into account.
"A
?list of strings with each an argument found in the input string2'

split_args//lib/private:strings.bzl

sinput string (Utilities for strings�
libtesting.bzl�assert_containsGenerates a test target which fails if the file doesn't contain the string.

Depends on bash, as it creates an sh_test target.
*�
�
assert_contains
nametarget to create (
actualLabel of a file (8
expected(a string which should appear in the file (/
sizestandard attribute for tests"small"(@
kwargs4additional named arguments for the resulting sh_test(Generates a test target which fails if the file doesn't contain the string.

Depends on bash, as it creates an sh_test target.
2$
assert_contains//lib:testing.bzl

nametarget to create (

actualLabel of a file (:
8
expected(a string which should appear in the file (1
/
sizestandard attribute for tests"small"(B
@
kwargs4additional named arguments for the resulting sh_test(�assert_outputsBAssert that the default outputs of a target are the expected ones.*�
�
assert_outputs+
namename of the resulting diff_test (6
actual(string of the label to check the outputs (d
expectedTa list of rootpaths of expected outputs, as they would appear in a runfiles manifest (B
kwargs6additional named arguments for the resulting diff_test(BAssert that the default outputs of a target are the expected ones.2#
assert_outputs//lib:testing.bzl-
+
namename of the resulting diff_test (8
6
actual(string of the label to check the outputs (f
d
expectedTa list of rootpaths of expected outputs, as they would appear in a runfiles manifest (D
B
kwargs6additional named arguments for the resulting diff_test(�assert_archive_containsEAssert that an archive file contains at least the given file entries.*�
�
assert_archive_contains0
name$name of the resulting sh_test target (1
archive"Label of the the .tar or .zip file (i
expectedYa (partial) file listing, either as a Label of a file containing it, or a list of strings (S
typeC"tar" or "zip". If None, a type will be inferred from the filename.None(@
kwargs4additional named arguments for the resulting sh_test(EAssert that an archive file contains at least the given file entries.2,
assert_archive_contains//lib:testing.bzl2
0
name$name of the resulting sh_test target (3
1
archive"Label of the the .tar or .zip file (k
i
expectedYa (partial) file listing, either as a Label of a file containing it, or a list of strings (U
S
typeC"tar" or "zip". If None, a type will be inferred from the filename.None(B
@
kwargs4additional named arguments for the resulting sh_test(�assert_directory_containsAAssert that a directory contains at least the given file entries.*�
�
assert_directory_contains0
name$name of the resulting sh_test target (0
	directoryLabel of the directory artifact (i
expectedYa (partial) file listing, either as a Label of a file containing it, or a list of strings (@
kwargs4additional named arguments for the resulting sh_test(AAssert that a directory contains at least the given file entries.2.
assert_directory_contains//lib:testing.bzl2
0
name$name of the resulting sh_test target (2
0
	directoryLabel of the directory artifact (k
i
expectedYa (partial) file listing, either as a Label of a file containing it, or a list of strings (B
@
kwargs4additional named arguments for the resulting sh_test("Helpers for making test assertions�
libtransitions.bzl�platform_transition_filegrouppTransitions the srcs to use the provided platform. The filegroup will contain artifacts for the target platform."�
�
platform_transition_filegrouppTransitions the srcs to use the provided platform. The filegroup will contain artifacts for the target platform.*
nameA unique name for this target. B
target_platform+The target platform to transition the srcs. B
srcs4The input to be transitioned to the target platform.2[]"6
platform_transition_filegroup//lib:transitions.bzl,
*
nameA unique name for this target. D
B
target_platform+The target platform to transition the srcs. D
B
srcs4The input to be transitioned to the target platform.2[]�platform_transition_binaryTTransitions the binary to use the provided platform. Will forward RunEnvironmentInfo"�
�
platform_transition_binaryTTransitions the binary to use the provided platform. Will forward RunEnvironmentInfo*
nameA unique name for this target. 
basename2""
binary2NoneD
target_platform-The target platform to transition the binary. "3
platform_transition_binary//lib:transitions.bzl8,
*
nameA unique name for this target. 

basename2""

binary2NoneF
D
target_platform-The target platform to transition the binary. �platform_transition_testRTransitions the test to use the provided platform. Will forward RunEnvironmentInfo"�
�
platform_transition_testRTransitions the test to use the provided platform. Will forward RunEnvironmentInfo*
nameA unique name for this target. 
basename2""
binary2NoneD
target_platform-The target platform to transition the binary. "1
platform_transition_test//lib:transitions.bzl08,
*
nameA unique name for this target. 

basename2""

binary2NoneF
D
target_platform-The target platform to transition the binary. #Rules for working with transitions.��
lib	utils.bzl�	utils.consistent_label_str�Generate a consistent label string for all Bazel versions.

Starting in Bazel 6, the workspace name is empty for the local workspace and there's no other
way to determine it. This behavior differs from Bazel 5 where the local workspace name was fully
qualified in str(label).

This utility function is meant for use in rules and requires the rule context to determine the
user's workspace name (`ctx.workspace_name`).
*�
�
utils.consistent_label_str
ctxThe rule context. (
labelA Label. (�Generate a consistent label string for all Bazel versions.

Starting in Bazel 6, the workspace name is empty for the local workspace and there's no other
way to determine it. This behavior differs from Bazel 5 where the local workspace name was fully
qualified in str(label).

This utility function is meant for use in rules and requires the rule context to determine the
user's workspace name (`ctx.workspace_name`).
"�
�String representation of the label including the repository name if the label is from an
external repository. For labels in the user's repository the label will start with `@//`.20
_consistent_label_str//lib/private:utils.bzl

ctxThe rule context. (

labelA Label. (�utils.default_timeout�Provide a sane default for *_test timeout attribute.

The [test-encyclopedia](https://bazel.build/reference/test-encyclopedia) says:

> Tests may return arbitrarily fast regardless of timeout.
> A test is not penalized for an overgenerous timeout, although a warning may be issued:
> you should generally set your timeout as tight as you can without incurring any flakiness.

However Bazel's default for timeout is medium, which is dumb given this guidance.

It also says:

> Tests which do not explicitly specify a timeout have one implied based on the test's size as follows

Therefore if size is specified, we should allow timeout to take its implied default.
If neither is set, then we can fix Bazel's wrong default here to avoid warnings under
`--test_verbose_timeout_warnings`.

This function can be used in a macro which wraps a testing rule.
*�	
�
utils.default_timeout/
size#the size attribute of a test target (5
timeout&the timeout attribute of a test target (�Provide a sane default for *_test timeout attribute.

The [test-encyclopedia](https://bazel.build/reference/test-encyclopedia) says:

> Tests may return arbitrarily fast regardless of timeout.
> A test is not penalized for an overgenerous timeout, although a warning may be issued:
> you should generally set your timeout as tight as you can without incurring any flakiness.

However Bazel's default for timeout is medium, which is dumb given this guidance.

It also says:

> Tests which do not explicitly specify a timeout have one implied based on the test's size as follows

Therefore if size is specified, we should allow timeout to take its implied default.
If neither is set, then we can fix Bazel's wrong default here to avoid warnings under
`--test_verbose_timeout_warnings`.

This function can be used in a macro which wraps a testing rule.
".
,"short" if neither is set, otherwise timeout2+
_default_timeout//lib/private:utils.bzl1
/
size#the size attribute of a test target (7
5
timeout&the timeout attribute of a test target (�utils.file_exists�Check whether a file exists.

Useful in macros to set defaults for a configuration file if it is present.
This can only be called during the loading phase, not from a rule implementation.
*�
�
utils.file_existsI
path=a label, or a string which is a path relative to this package (�Check whether a file exists.

Useful in macros to set defaults for a configuration file if it is present.
This can only be called during the loading phase, not from a rule implementation.
2'
_file_exists//lib/private:utils.bzlK
I
path=a label, or a string which is a path relative to this package (�utils.glob_directories*�
a
utils.glob_directories
include (

kwargs(2,
_glob_directories//lib/private:utils.bzl

include (


kwargs(�utils.is_bazel_6_or_greater�Detects if the Bazel version being used is greater than or equal to 6 (including Bazel 6 pre-releases and RCs).

Detecting Bazel 6 or greater is particularly useful in rules as slightly different code paths may be needed to
support bzlmod which was added in Bazel 6.

Unlike the undocumented `native.bazel_version`, which only works in WORKSPACE and repository rules, this function can
be used in rules and BUILD files.

An alternate approach to make the Bazel version available in BUILD files and rules would be to
use the [host_repo](https://github.com/bazel-contrib/bazel-lib/blob/main/docs/host_repo.md) repository rule
which contains the bazel_version in the exported `host` struct:

WORKSPACE:
```
load("@bazel_lib//lib:host_repo.bzl", "host_repo")
host_repo(name = "bazel_lib_host")
```

BUILD.bazel:
```
load("@bazel_lib_host//:defs.bzl", "host")
print(host.bazel_version)
```

That approach, however, incurs a cost in the user's WORKSPACE.
*�
�
utils.is_bazel_6_or_greater�Detects if the Bazel version being used is greater than or equal to 6 (including Bazel 6 pre-releases and RCs).

Detecting Bazel 6 or greater is particularly useful in rules as slightly different code paths may be needed to
support bzlmod which was added in Bazel 6.

Unlike the undocumented `native.bazel_version`, which only works in WORKSPACE and repository rules, this function can
be used in rules and BUILD files.

An alternate approach to make the Bazel version available in BUILD files and rules would be to
use the [host_repo](https://github.com/bazel-contrib/bazel-lib/blob/main/docs/host_repo.md) repository rule
which contains the bazel_version in the exported `host` struct:

WORKSPACE:
```
load("@bazel_lib//lib:host_repo.bzl", "host_repo")
host_repo(name = "bazel_lib_host")
```

BUILD.bazel:
```
load("@bazel_lib_host//:defs.bzl", "host")
print(host.bazel_version)
```

That approach, however, incurs a cost in the user's WORKSPACE.
"e
cTrue if the Bazel version being used is greater than or equal to 6 (including pre-releases and RCs)21
_is_bazel_6_or_greater//lib/private:utils.bzl�utils.is_bazel_7_or_greater�Detects if the Bazel version being used is greater than or equal to 7 (including Bazel 7 pre-releases and RCs).

Unlike the undocumented `native.bazel_version`, which only works in WORKSPACE and repository rules, this function can
be used in rules and BUILD files.

An alternate approach to make the Bazel version available in BUILD files and rules would be to
use the [host_repo](https://github.com/bazel-contrib/bazel-lib/blob/main/docs/host_repo.md) repository rule
which contains the bazel_version in the exported `host` struct:

WORKSPACE:
```
load("@bazel_lib//lib:host_repo.bzl", "host_repo")
host_repo(name = "bazel_lib_host")
```

BUILD.bazel:
```
load("@bazel_lib_host//:defs.bzl", "host")
print(host.bazel_version)
```

That approach, however, incurs a cost in the user's WORKSPACE.
*�
�
utils.is_bazel_7_or_greater�Detects if the Bazel version being used is greater than or equal to 7 (including Bazel 7 pre-releases and RCs).

Unlike the undocumented `native.bazel_version`, which only works in WORKSPACE and repository rules, this function can
be used in rules and BUILD files.

An alternate approach to make the Bazel version available in BUILD files and rules would be to
use the [host_repo](https://github.com/bazel-contrib/bazel-lib/blob/main/docs/host_repo.md) repository rule
which contains the bazel_version in the exported `host` struct:

WORKSPACE:
```
load("@bazel_lib//lib:host_repo.bzl", "host_repo")
host_repo(name = "bazel_lib_host")
```

BUILD.bazel:
```
load("@bazel_lib_host//:defs.bzl", "host")
print(host.bazel_version)
```

That approach, however, incurs a cost in the user's WORKSPACE.
"e
cTrue if the Bazel version being used is greater than or equal to 7 (including pre-releases and RCs)21
_is_bazel_7_or_greater//lib/private:utils.bzl�utils.is_bzlmod_enabled,Detect the value of the --enable_bzlmod flag*w
u
utils.is_bzlmod_enabled,Detect the value of the --enable_bzlmod flag2,
is_bzlmod_enabled//lib/private:utils.bzl�utils.is_external_labellReturns True if the given Label (or stringy version of a label) represents a target outside of the workspace*�
�
utils.is_external_label
parama string or label (lReturns True if the given Label (or stringy version of a label) represents a target outside of the workspace"
a bool2-
_is_external_label//lib/private:utils.bzl 

parama string or label (�utils.maybe_http_archive�Adapts a maybe(http_archive, ...) to look like an http_archive.

This makes WORKSPACE dependencies easier to read and update.

Typical usage looks like,

```
load("//lib:utils.bzl", http_archive = "maybe_http_archive")

http_archive(
    name = "aspect_rules_js",
    sha256 = "5bb643d9e119832a383e67f946dc752b6d719d66d1df9b46d840509ceb53e1f1",
    strip_prefix = "rules_js-1.6.2",
    url = "https://github.com/aspect-build/rules_js/archive/refs/tags/v1.6.2.tar.gz",
)
```

instead of the classic maybe pattern of,

```
load("@bazel_tools//tools/build_defs/repo:http.bzl", "http_archive")
load("@bazel_tools//tools/build_defs/repo:utils.bzl", "maybe")

maybe(
    http_archive,
    name = "aspect_rules_js",
    sha256 = "5bb643d9e119832a383e67f946dc752b6d719d66d1df9b46d840509ceb53e1f1",
    strip_prefix = "rules_js-1.6.2",
    url = "https://github.com/aspect-build/rules_js/archive/refs/tags/v1.6.2.tar.gz",
)
```
*�
�
utils.maybe_http_archive9
kwargs-all arguments to pass-forward to http_archive(�Adapts a maybe(http_archive, ...) to look like an http_archive.

This makes WORKSPACE dependencies easier to read and update.

Typical usage looks like,

```
load("//lib:utils.bzl", http_archive = "maybe_http_archive")

http_archive(
    name = "aspect_rules_js",
    sha256 = "5bb643d9e119832a383e67f946dc752b6d719d66d1df9b46d840509ceb53e1f1",
    strip_prefix = "rules_js-1.6.2",
    url = "https://github.com/aspect-build/rules_js/archive/refs/tags/v1.6.2.tar.gz",
)
```

instead of the classic maybe pattern of,

```
load("@bazel_tools//tools/build_defs/repo:http.bzl", "http_archive")
load("@bazel_tools//tools/build_defs/repo:utils.bzl", "maybe")

maybe(
    http_archive,
    name = "aspect_rules_js",
    sha256 = "5bb643d9e119832a383e67f946dc752b6d719d66d1df9b46d840509ceb53e1f1",
    strip_prefix = "rules_js-1.6.2",
    url = "https://github.com/aspect-build/rules_js/archive/refs/tags/v1.6.2.tar.gz",
)
```
2.
_maybe_http_archive//lib/private:utils.bzl;
9
kwargs-all arguments to pass-forward to http_archive(�utils.path_to_workspace_root2Returns the path to the workspace root under bazel*�
�
utils.path_to_workspace_root2Returns the path to the workspace root under bazel"
Path to the workspace root22
_path_to_workspace_root//lib/private:utils.bzl�-utils.propagate_common_binary_rule_attributes�Returns a dict of rule parameters filtered from the input dict that only contains the ones that are common to all binary rules

These are listed in Bazel's documentation:
https://bazel.build/reference/be/common-definitions#common-attributes
https://bazel.build/reference/be/common-definitions#common-attributes-binary
*�
�
-utils.propagate_common_binary_rule_attributes)
attrsDict of parameters to filter (�Returns a dict of rule parameters filtered from the input dict that only contains the ones that are common to all binary rules

These are listed in Bazel's documentation:
https://bazel.build/reference/be/common-definitions#common-attributes
https://bazel.build/reference/be/common-definitions#common-attributes-binary
"B
@The dict of parameters, containing only common binary attributes2C
(_propagate_common_binary_rule_attributes//lib/private:utils.bzl+
)
attrsDict of parameters to filter (�&utils.propagate_common_rule_attributes�Returns a dict of rule parameters filtered from the input dict that only contains the ones that are common to all rules

These are listed in Bazel's documentation:
https://bazel.build/reference/be/common-definitions#common-attributes
*�
�
&utils.propagate_common_rule_attributes)
attrsDict of parameters to filter (�Returns a dict of rule parameters filtered from the input dict that only contains the ones that are common to all rules

These are listed in Bazel's documentation:
https://bazel.build/reference/be/common-definitions#common-attributes
";
9The dict of parameters, containing only common attributes2<
!_propagate_common_rule_attributes//lib/private:utils.bzl+
)
attrsDict of parameters to filter (�+utils.propagate_common_test_rule_attributes�Returns a dict of rule parameters filtered from the input dict that only contains the ones that are common to all test rules

These are listed in Bazel's documentation:
https://bazel.build/reference/be/common-definitions#common-attributes
https://bazel.build/reference/be/common-definitions#common-attributes-tests
*�
�
+utils.propagate_common_test_rule_attributes)
attrsDict of parameters to filter (�Returns a dict of rule parameters filtered from the input dict that only contains the ones that are common to all test rules

These are listed in Bazel's documentation:
https://bazel.build/reference/be/common-definitions#common-attributes
https://bazel.build/reference/be/common-definitions#common-attributes-tests
"@
>The dict of parameters, containing only common test attributes2A
&_propagate_common_test_rule_attributes//lib/private:utils.bzl+
)
attrsDict of parameters to filter (�utils.propagate_well_known_tags�Returns a list of tags filtered from the input set that only contains the ones that are considered "well known"

These are listed in Bazel's documentation:
https://docs.bazel.build/versions/main/test-encyclopedia.html#tag-conventions
https://docs.bazel.build/versions/main/be/common-definitions.html#common-attributes
*�
�
utils.propagate_well_known_tags$
tagsList of tags to filter[](�Returns a list of tags filtered from the input set that only contains the ones that are considered "well known"

These are listed in Bazel's documentation:
https://docs.bazel.build/versions/main/test-encyclopedia.html#tag-conventions
https://docs.bazel.build/versions/main/be/common-definitions.html#common-attributes
"4
2List of tags that only contains the well known set25
_propagate_well_known_tags//lib/private:utils.bzl&
$
tagsList of tags to filter[](�utils.to_labelOConverts a string to a Label. If Label is supplied, the same label is returned.*�
�
utils.to_label5
param(a string representing a label or a Label (OConverts a string to a Label. If Label is supplied, the same label is returned."	
a Label2$
	_to_label//lib/private:utils.bzl7
5
param(a string representing a label or a Label (�default_timeout�Provide a sane default for *_test timeout attribute.

The [test-encyclopedia](https://bazel.build/reference/test-encyclopedia) says:

> Tests may return arbitrarily fast regardless of timeout.
> A test is not penalized for an overgenerous timeout, although a warning may be issued:
> you should generally set your timeout as tight as you can without incurring any flakiness.

However Bazel's default for timeout is medium, which is dumb given this guidance.

It also says:

> Tests which do not explicitly specify a timeout have one implied based on the test's size as follows

Therefore if size is specified, we should allow timeout to take its implied default.
If neither is set, then we can fix Bazel's wrong default here to avoid warnings under
`--test_verbose_timeout_warnings`.

This function can be used in a macro which wraps a testing rule.
*�	
�
default_timeout/
size#the size attribute of a test target (5
timeout&the timeout attribute of a test target (�Provide a sane default for *_test timeout attribute.

The [test-encyclopedia](https://bazel.build/reference/test-encyclopedia) says:

> Tests may return arbitrarily fast regardless of timeout.
> A test is not penalized for an overgenerous timeout, although a warning may be issued:
> you should generally set your timeout as tight as you can without incurring any flakiness.

However Bazel's default for timeout is medium, which is dumb given this guidance.

It also says:

> Tests which do not explicitly specify a timeout have one implied based on the test's size as follows

Therefore if size is specified, we should allow timeout to take its implied default.
If neither is set, then we can fix Bazel's wrong default here to avoid warnings under
`--test_verbose_timeout_warnings`.

This function can be used in a macro which wraps a testing rule.
".
,"short" if neither is set, otherwise timeout2+
_default_timeout//lib/private:utils.bzl1
/
size#the size attribute of a test target (7
5
timeout&the timeout attribute of a test target (�file_exists�Check whether a file exists.

Useful in macros to set defaults for a configuration file if it is present.
This can only be called during the loading phase, not from a rule implementation.
*�
�
file_existsI
path=a label, or a string which is a path relative to this package (�Check whether a file exists.

Useful in macros to set defaults for a configuration file if it is present.
This can only be called during the loading phase, not from a rule implementation.
2'
_file_exists//lib/private:utils.bzlK
I
path=a label, or a string which is a path relative to this package (�glob_directories*|
[
glob_directories
include (

kwargs(2,
_glob_directories//lib/private:utils.bzl

include (


kwargs(�is_bazel_6_or_greater�Detects if the Bazel version being used is greater than or equal to 6 (including Bazel 6 pre-releases and RCs).

Detecting Bazel 6 or greater is particularly useful in rules as slightly different code paths may be needed to
support bzlmod which was added in Bazel 6.

Unlike the undocumented `native.bazel_version`, which only works in WORKSPACE and repository rules, this function can
be used in rules and BUILD files.

An alternate approach to make the Bazel version available in BUILD files and rules would be to
use the [host_repo](https://github.com/bazel-contrib/bazel-lib/blob/main/docs/host_repo.md) repository rule
which contains the bazel_version in the exported `host` struct:

WORKSPACE:
```
load("@bazel_lib//lib:host_repo.bzl", "host_repo")
host_repo(name = "bazel_lib_host")
```

BUILD.bazel:
```
load("@bazel_lib_host//:defs.bzl", "host")
print(host.bazel_version)
```

That approach, however, incurs a cost in the user's WORKSPACE.
*�
�
is_bazel_6_or_greater�Detects if the Bazel version being used is greater than or equal to 6 (including Bazel 6 pre-releases and RCs).

Detecting Bazel 6 or greater is particularly useful in rules as slightly different code paths may be needed to
support bzlmod which was added in Bazel 6.

Unlike the undocumented `native.bazel_version`, which only works in WORKSPACE and repository rules, this function can
be used in rules and BUILD files.

An alternate approach to make the Bazel version available in BUILD files and rules would be to
use the [host_repo](https://github.com/bazel-contrib/bazel-lib/blob/main/docs/host_repo.md) repository rule
which contains the bazel_version in the exported `host` struct:

WORKSPACE:
```
load("@bazel_lib//lib:host_repo.bzl", "host_repo")
host_repo(name = "bazel_lib_host")
```

BUILD.bazel:
```
load("@bazel_lib_host//:defs.bzl", "host")
print(host.bazel_version)
```

That approach, however, incurs a cost in the user's WORKSPACE.
"e
cTrue if the Bazel version being used is greater than or equal to 6 (including pre-releases and RCs)21
_is_bazel_6_or_greater//lib/private:utils.bzl�is_bazel_7_or_greater�Detects if the Bazel version being used is greater than or equal to 7 (including Bazel 7 pre-releases and RCs).

Unlike the undocumented `native.bazel_version`, which only works in WORKSPACE and repository rules, this function can
be used in rules and BUILD files.

An alternate approach to make the Bazel version available in BUILD files and rules would be to
use the [host_repo](https://github.com/bazel-contrib/bazel-lib/blob/main/docs/host_repo.md) repository rule
which contains the bazel_version in the exported `host` struct:

WORKSPACE:
```
load("@bazel_lib//lib:host_repo.bzl", "host_repo")
host_repo(name = "bazel_lib_host")
```

BUILD.bazel:
```
load("@bazel_lib_host//:defs.bzl", "host")
print(host.bazel_version)
```

That approach, however, incurs a cost in the user's WORKSPACE.
*�
�
is_bazel_7_or_greater�Detects if the Bazel version being used is greater than or equal to 7 (including Bazel 7 pre-releases and RCs).

Unlike the undocumented `native.bazel_version`, which only works in WORKSPACE and repository rules, this function can
be used in rules and BUILD files.

An alternate approach to make the Bazel version available in BUILD files and rules would be to
use the [host_repo](https://github.com/bazel-contrib/bazel-lib/blob/main/docs/host_repo.md) repository rule
which contains the bazel_version in the exported `host` struct:

WORKSPACE:
```
load("@bazel_lib//lib:host_repo.bzl", "host_repo")
host_repo(name = "bazel_lib_host")
```

BUILD.bazel:
```
load("@bazel_lib_host//:defs.bzl", "host")
print(host.bazel_version)
```

That approach, however, incurs a cost in the user's WORKSPACE.
"e
cTrue if the Bazel version being used is greater than or equal to 7 (including pre-releases and RCs)21
_is_bazel_7_or_greater//lib/private:utils.bzl�is_bzlmod_enabled,Detect the value of the --enable_bzlmod flag*q
o
is_bzlmod_enabled,Detect the value of the --enable_bzlmod flag2,
is_bzlmod_enabled//lib/private:utils.bzl�is_external_labellReturns True if the given Label (or stringy version of a label) represents a target outside of the workspace*�
�
is_external_label
parama string or label (lReturns True if the given Label (or stringy version of a label) represents a target outside of the workspace"
a bool2-
_is_external_label//lib/private:utils.bzl 

parama string or label (�maybe_http_archive�Adapts a maybe(http_archive, ...) to look like an http_archive.

This makes WORKSPACE dependencies easier to read and update.

Typical usage looks like,

```
load("//lib:utils.bzl", http_archive = "maybe_http_archive")

http_archive(
    name = "aspect_rules_js",
    sha256 = "5bb643d9e119832a383e67f946dc752b6d719d66d1df9b46d840509ceb53e1f1",
    strip_prefix = "rules_js-1.6.2",
    url = "https://github.com/aspect-build/rules_js/archive/refs/tags/v1.6.2.tar.gz",
)
```

instead of the classic maybe pattern of,

```
load("@bazel_tools//tools/build_defs/repo:http.bzl", "http_archive")
load("@bazel_tools//tools/build_defs/repo:utils.bzl", "maybe")

maybe(
    http_archive,
    name = "aspect_rules_js",
    sha256 = "5bb643d9e119832a383e67f946dc752b6d719d66d1df9b46d840509ceb53e1f1",
    strip_prefix = "rules_js-1.6.2",
    url = "https://github.com/aspect-build/rules_js/archive/refs/tags/v1.6.2.tar.gz",
)
```
*�
�
maybe_http_archive9
kwargs-all arguments to pass-forward to http_archive(�Adapts a maybe(http_archive, ...) to look like an http_archive.

This makes WORKSPACE dependencies easier to read and update.

Typical usage looks like,

```
load("//lib:utils.bzl", http_archive = "maybe_http_archive")

http_archive(
    name = "aspect_rules_js",
    sha256 = "5bb643d9e119832a383e67f946dc752b6d719d66d1df9b46d840509ceb53e1f1",
    strip_prefix = "rules_js-1.6.2",
    url = "https://github.com/aspect-build/rules_js/archive/refs/tags/v1.6.2.tar.gz",
)
```

instead of the classic maybe pattern of,

```
load("@bazel_tools//tools/build_defs/repo:http.bzl", "http_archive")
load("@bazel_tools//tools/build_defs/repo:utils.bzl", "maybe")

maybe(
    http_archive,
    name = "aspect_rules_js",
    sha256 = "5bb643d9e119832a383e67f946dc752b6d719d66d1df9b46d840509ceb53e1f1",
    strip_prefix = "rules_js-1.6.2",
    url = "https://github.com/aspect-build/rules_js/archive/refs/tags/v1.6.2.tar.gz",
)
```
2.
_maybe_http_archive//lib/private:utils.bzl;
9
kwargs-all arguments to pass-forward to http_archive(�path_to_workspace_root2Returns the path to the workspace root under bazel*�
�
path_to_workspace_root2Returns the path to the workspace root under bazel"
Path to the workspace root22
_path_to_workspace_root//lib/private:utils.bzl�propagate_well_known_tags�Returns a list of tags filtered from the input set that only contains the ones that are considered "well known"

These are listed in Bazel's documentation:
https://docs.bazel.build/versions/main/test-encyclopedia.html#tag-conventions
https://docs.bazel.build/versions/main/be/common-definitions.html#common-attributes
*�
�
propagate_well_known_tags$
tagsList of tags to filter[](�Returns a list of tags filtered from the input set that only contains the ones that are considered "well known"

These are listed in Bazel's documentation:
https://docs.bazel.build/versions/main/test-encyclopedia.html#tag-conventions
https://docs.bazel.build/versions/main/be/common-definitions.html#common-attributes
"4
2List of tags that only contains the well known set25
_propagate_well_known_tags//lib/private:utils.bzl&
$
tagsList of tags to filter[](� propagate_common_rule_attributes�Returns a dict of rule parameters filtered from the input dict that only contains the ones that are common to all rules

These are listed in Bazel's documentation:
https://bazel.build/reference/be/common-definitions#common-attributes
*�
�
 propagate_common_rule_attributes)
attrsDict of parameters to filter (�Returns a dict of rule parameters filtered from the input dict that only contains the ones that are common to all rules

These are listed in Bazel's documentation:
https://bazel.build/reference/be/common-definitions#common-attributes
";
9The dict of parameters, containing only common attributes2<
!_propagate_common_rule_attributes//lib/private:utils.bzl+
)
attrsDict of parameters to filter (�%propagate_common_test_rule_attributes�Returns a dict of rule parameters filtered from the input dict that only contains the ones that are common to all test rules

These are listed in Bazel's documentation:
https://bazel.build/reference/be/common-definitions#common-attributes
https://bazel.build/reference/be/common-definitions#common-attributes-tests
*�
�
%propagate_common_test_rule_attributes)
attrsDict of parameters to filter (�Returns a dict of rule parameters filtered from the input dict that only contains the ones that are common to all test rules

These are listed in Bazel's documentation:
https://bazel.build/reference/be/common-definitions#common-attributes
https://bazel.build/reference/be/common-definitions#common-attributes-tests
"@
>The dict of parameters, containing only common test attributes2A
&_propagate_common_test_rule_attributes//lib/private:utils.bzl+
)
attrsDict of parameters to filter (�'propagate_common_binary_rule_attributes�Returns a dict of rule parameters filtered from the input dict that only contains the ones that are common to all binary rules

These are listed in Bazel's documentation:
https://bazel.build/reference/be/common-definitions#common-attributes
https://bazel.build/reference/be/common-definitions#common-attributes-binary
*�
�
'propagate_common_binary_rule_attributes)
attrsDict of parameters to filter (�Returns a dict of rule parameters filtered from the input dict that only contains the ones that are common to all binary rules

These are listed in Bazel's documentation:
https://bazel.build/reference/be/common-definitions#common-attributes
https://bazel.build/reference/be/common-definitions#common-attributes-binary
"B
@The dict of parameters, containing only common binary attributes2C
(_propagate_common_binary_rule_attributes//lib/private:utils.bzl+
)
attrsDict of parameters to filter (�to_labelOConverts a string to a Label. If Label is supplied, the same label is returned.*�
�
to_label5
param(a string representing a label or a Label (OConverts a string to a Label. If Label is supplied, the same label is returned."	
a Label2$
	_to_label//lib/private:utils.bzl7
5
param(a string representing a label or a Label (�	consistent_label_str�Generate a consistent label string for all Bazel versions.

Starting in Bazel 6, the workspace name is empty for the local workspace and there's no other
way to determine it. This behavior differs from Bazel 5 where the local workspace name was fully
qualified in str(label).

This utility function is meant for use in rules and requires the rule context to determine the
user's workspace name (`ctx.workspace_name`).
*�
�
consistent_label_str
ctxThe rule context. (
labelA Label. (�Generate a consistent label string for all Bazel versions.

Starting in Bazel 6, the workspace name is empty for the local workspace and there's no other
way to determine it. This behavior differs from Bazel 5 where the local workspace name was fully
qualified in str(label).

This utility function is meant for use in rules and requires the rule context to determine the
user's workspace name (`ctx.workspace_name`).
"�
�String representation of the label including the repository name if the label is from an
external repository. For labels in the user's repository the label will start with `@//`.20
_consistent_label_str//lib/private:utils.bzl

ctxThe rule context. (

labelA Label. (�General-purpose Starlark utility functions

## Usage example

```starlark
load("@bazel_lib//lib:utils.bzl", "utils")

out_label = utils.to_label(out_file)
```�
libwindows_utils.bzl�%create_windows_native_launcher_script�Create a Windows Batch file to launch the given shell script.

The rule should specify @bazel_tools//tools/sh:toolchain_type as a required toolchain.
*�
�
%create_windows_native_launcher_script
ctxRule context (,
shell_scriptThe bash launcher script (�Create a Windows Batch file to launch the given shell script.

The rule should specify @bazel_tools//tools/sh:toolchain_type as a required toolchain.
"
A windows launcher script2@
%create_windows_native_launcher_script//lib:windows_utils.bzl

ctxRule context (.
,
shell_scriptThe bash launcher script ($Helpers for rules running on windows�p
libwrite_source_files.bzl�-write_source_files�Write one or more files and/or directories to the source tree.

By default, `diff_test` targets are generated that ensure the source tree files and/or directories to be written to
are up to date and the rule also checks that all source tree files and/or directories to be written to exist.
To disable the exists check and up-to-date tests set `diff_test` to `False`.
*�*
�
write_source_filesi
name]Name of the runnable target that creates or updates the source tree files and/or directories. (�
files�A dict where the keys are files or directories in the source tree to write to and the values are labels
pointing to the desired content, typically file or directory outputs of other targets.

Destination files and directories must be within the same containing Bazel package as this target if
`check_that_out_file_exists` is True. See `check_that_out_file_exists` docstring for more info.{}(�

executable�Whether source tree files written should be made executable.

This applies to all source tree files written by this target. This attribute is not propagated to `additional_update_targets`.

To set different executable permissions on different source tree files use multiple `write_source_files` targets.False(}
additional_update_targetsZList of other `write_source_files` or `write_source_file` targets to call in the same run.[](�
suggested_update_targetnLabel of the `write_source_files` or `write_source_file` target to suggest running when files are out of date.None(a
	diff_testLTest that the source tree files and/or directories exist and are up to date.True(�
diff_test_failure_message�Text to print when the diff test fails, with templating options for
relevant targets.

Substitutions are performed on the failure message, with the following substitutions being available:

`{{DEFAULT_MESSAGE}}`: Prints the default error message, listing the target(s) that
  may be run to update the file(s).

`{{TARGET}}`: The target to update the individual file that does not match in the
  diff test.

`{{SUGGESTED_UPDATE_TARGET}}`: The suggested_update_target if specified, or the
  target which will update all of the files which do not match."{{DEFAULT_MESSAGE}}"(P
	diff_args=Arguments to pass to the `diff` command. (Ignored on Windows)[](�
file_missing_failure_messagenText to print when the output file is missing. Subject to the same
substitutions as diff_test_failure_message."{{DEFAULT_MESSAGE}}"(�
check_that_out_file_exists�Test that each output file exists and print a helpful error message if it doesn't.

If `True`, destination files and directories must be in the same containing Bazel package as the target since the underlying
mechanism for this check is limited to files in the same Bazel package.True(H
kwargs<Other common named parameters such as `tags` or `visibility`(�Write one or more files and/or directories to the source tree.

By default, `diff_test` targets are generated that ensure the source tree files and/or directories to be written to
are up to date and the rule also checks that all source tree files and/or directories to be written to exist.
To disable the exists check and up-to-date tests set `diff_test` to `False`.
22
write_source_files//lib:write_source_files.bzlk
i
name]Name of the runnable target that creates or updates the source tree files and/or directories. (�
�
files�A dict where the keys are files or directories in the source tree to write to and the values are labels
pointing to the desired content, typically file or directory outputs of other targets.

Destination files and directories must be within the same containing Bazel package as this target if
`check_that_out_file_exists` is True. See `check_that_out_file_exists` docstring for more info.{}(�
�

executable�Whether source tree files written should be made executable.

This applies to all source tree files written by this target. This attribute is not propagated to `additional_update_targets`.

To set different executable permissions on different source tree files use multiple `write_source_files` targets.False(
}
additional_update_targetsZList of other `write_source_files` or `write_source_file` targets to call in the same run.[](�
�
suggested_update_targetnLabel of the `write_source_files` or `write_source_file` target to suggest running when files are out of date.None(c
a
	diff_testLTest that the source tree files and/or directories exist and are up to date.True(�
�
diff_test_failure_message�Text to print when the diff test fails, with templating options for
relevant targets.

Substitutions are performed on the failure message, with the following substitutions being available:

`{{DEFAULT_MESSAGE}}`: Prints the default error message, listing the target(s) that
  may be run to update the file(s).

`{{TARGET}}`: The target to update the individual file that does not match in the
  diff test.

`{{SUGGESTED_UPDATE_TARGET}}`: The suggested_update_target if specified, or the
  target which will update all of the files which do not match."{{DEFAULT_MESSAGE}}"(R
P
	diff_args=Arguments to pass to the `diff` command. (Ignored on Windows)[](�
�
file_missing_failure_messagenText to print when the output file is missing. Subject to the same
substitutions as diff_test_failure_message."{{DEFAULT_MESSAGE}}"(�
�
check_that_out_file_exists�Test that each output file exists and print a helpful error message if it doesn't.

If `True`, destination files and directories must be in the same containing Bazel package as the target since the underlying
mechanism for this check is limited to files in the same Bazel package.True(J
H
kwargs<Other common named parameters such as `tags` or `visibility`(�,write_source_file�Write a file or directory to the source tree.

By default, a `diff_test` target ("{name}_test") is generated that ensure the source tree file or directory to be written to
is up to date and the rule also checks that the source tree file or directory to be written to exists.
To disable the exists check and up-to-date test set `diff_test` to `False`.
*�)
�
write_source_fileb
nameVName of the runnable target that creates or updates the source tree file or directory. (�
in_file�File or directory to use as the desired content to write to `out_file`.

This is typically a file or directory output of another target. If `in_file` is a directory then entire directory contents are copied.None(�
out_file�The file or directory to write to in the source tree.

The output file or directory must be within the same containing Bazel package as this target if `check_that_out_file_exists` is `True`.
See `check_that_out_file_exists` docstring for more info.None(|

executableeWhether source tree file or files within the source tree directory written should be made executable.False(}
additional_update_targetsZList of other `write_source_files` or `write_source_file` targets to call in the same run.[](�
suggested_update_targetnLabel of the `write_source_files` or `write_source_file` target to suggest running when files are out of date.None(Y
	diff_testDTest that the source tree file or directory exist and is up to date.True(�
diff_test_failure_message�Text to print when the diff test fails, with templating options for
relevant targets.

Substitutions are performed on the failure message, with the following substitutions being available:

`{{DEFAULT_MESSAGE}}`: Prints the default error message, listing the target(s) that
  may be run to update the file(s).

`{{TARGET}}`: The target to update the individual file that does not match in the
  diff test.

`{{SUGGESTED_UPDATE_TARGET}}`: The suggested_update_target if specified."{{DEFAULT_MESSAGE}}"(�
file_missing_failure_messagenText to print when the output file is missing. Subject to the same
substitutions as diff_test_failure_message."{{DEFAULT_MESSAGE}}"(P
	diff_args=Arguments to pass to the `diff` command. (Ignored on Windows)[](�
check_that_out_file_exists�Test that the output file exists and print a helpful error message if it doesn't.

If `True`, the output file or directory must be in the same containing Bazel package as the target since the underlying mechanism
for this check is limited to files in the same Bazel package.True(i
	verbosityRVerbosity of message when the copy target is run. One of `full`, `short`, `quiet`."full"(H
kwargs<Other common named parameters such as `tags` or `visibility`(�Write a file or directory to the source tree.

By default, a `diff_test` target ("{name}_test") is generated that ensure the source tree file or directory to be written to
is up to date and the rule also checks that the source tree file or directory to be written to exists.
To disable the exists check and up-to-date test set `diff_test` to `False`.
"A
?Name of the generated test target if requested, otherwise None.28
write_source_file#//lib/private:write_source_file.bzld
b
nameVName of the runnable target that creates or updates the source tree file or directory. (�
�
in_file�File or directory to use as the desired content to write to `out_file`.

This is typically a file or directory output of another target. If `in_file` is a directory then entire directory contents are copied.None(�
�
out_file�The file or directory to write to in the source tree.

The output file or directory must be within the same containing Bazel package as this target if `check_that_out_file_exists` is `True`.
See `check_that_out_file_exists` docstring for more info.None(~
|

executableeWhether source tree file or files within the source tree directory written should be made executable.False(
}
additional_update_targetsZList of other `write_source_files` or `write_source_file` targets to call in the same run.[](�
�
suggested_update_targetnLabel of the `write_source_files` or `write_source_file` target to suggest running when files are out of date.None([
Y
	diff_testDTest that the source tree file or directory exist and is up to date.True(�
�
diff_test_failure_message�Text to print when the diff test fails, with templating options for
relevant targets.

Substitutions are performed on the failure message, with the following substitutions being available:

`{{DEFAULT_MESSAGE}}`: Prints the default error message, listing the target(s) that
  may be run to update the file(s).

`{{TARGET}}`: The target to update the individual file that does not match in the
  diff test.

`{{SUGGESTED_UPDATE_TARGET}}`: The suggested_update_target if specified."{{DEFAULT_MESSAGE}}"(�
�
file_missing_failure_messagenText to print when the output file is missing. Subject to the same
substitutions as diff_test_failure_message."{{DEFAULT_MESSAGE}}"(R
P
	diff_args=Arguments to pass to the `diff` command. (Ignored on Windows)[](�
�
check_that_out_file_exists�Test that the output file exists and print a helpful error message if it doesn't.

If `True`, the output file or directory must be in the same containing Bazel package as the target since the underlying mechanism
for this check is limited to files in the same Bazel package.True(k
i
	verbosityRVerbosity of message when the copy target is run. One of `full`, `short`, `quiet`."full"(J
H
kwargs<Other common named parameters such as `tags` or `visibility`(�WriteSourceFileInfo&Provider for write_source_file targets2�
�
WriteSourceFileInfo&Provider for write_source_file targets6

executable(Executable that updates the source files":
WriteSourceFileInfo#//lib/private:write_source_file.bzl8
6

executable(Executable that updates the source files�write_source_files provides a workaround for the restriction that `bazel build` cannot write to the source tree.

Read more about the philosophy of writing to the source tree: <https://blog.aspect.build/bazel-can-write-to-the-source-folder>

## Usage

```starlark
load("@bazel_lib//lib:write_source_files.bzl", "write_source_files")

write_source_files(
    name = "write_foobar",
    files = {
        "foobar.json": "//some/generated:file",
    },
)
```

To update the source file, run:

```bash
bazel run //:write_foobar
```

The generated `diff_test` will fail if the file is out of date and print out instructions on
how to update it.

If the file does not exist, Bazel will fail at analysis time and print out instructions on
how to create it.

You can declare a tree of generated source file targets:

```starlark
load("@bazel_lib//lib:write_source_files.bzl", "write_source_files")

write_source_files(
    name = "write_all",
    additional_update_targets = [
        # Other write_source_files targets to run when this target is run
        "//a/b/c:write_foo",
        "//a/b:write_bar",
    ]
)
```

And update them with a single run:

```bash
bazel run //:write_all
```

When a file is out of date, you can leave a suggestion to run a target further up in the tree by specifying `suggested_update_target`.
For example,

```starlark
write_source_files(
    name = "write_foo",
    files = {
        "foo.json": ":generated-foo",
    },
    suggested_update_target = "//:write_all"
)
```

A test failure from `foo.json` being out of date will yield the following message:

```
//a/b:c:foo.json is out of date. To update this and other generated files, run:

    bazel run //:write_all

To update *only* this file, run:

    bazel run //a/b/c:write_foo
```

You can also add a more customized error message using the `diff_test_failure_message` argument:

```starlark
write_source_file(
    name = "write_foo",
    out_file = "foo.json",
    in_file = ":generated-foo",
    diff_test_failure_message = "Failed to build Foo; please run {{TARGET}} to update."
)
```

A test failure from `foo.json` being out of date will then yield:

```
Failed to build Foo; please run //a/b/c:write_foo to update.
```

If you have many `write_source_files` targets that you want to update as a group, we recommend wrapping
`write_source_files` in a macro that defaults `suggested_update_target` to the umbrella update target.

NOTE: If you run formatters or linters on your codebase, it is advised that you exclude/ignore the outputs of this
    rule from those formatters/linters so as to avoid causing collisions and failing tests.�
toolsintegrity.bzl�Release binary integrity hashes.

This file contents are entirely replaced during release publishing.
The checked in content is only here to allow load() statements in the sources to resolve.�
tools/release
hashes.bzl�hashes*|
Q
hashes

name (	
src (

kwargs(2$
hashes//tools/release:hashes.bzl


name (
	
src (


kwargs(�Rule for generating integrity files

Default output is a .sha256 file but .sha1 and .md5 files are also available
via output groups.

Based on https://github.com/bazelbuild/examples/blob/main/rules/implicit_output/hash.bzlY
toolsversion.bzlAversion information. replaced with stamped info with each release 