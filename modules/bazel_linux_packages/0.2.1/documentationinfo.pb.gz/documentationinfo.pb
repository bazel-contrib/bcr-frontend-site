�
5
bazel_linux_packagesapt/privatedeb_download.bzl�
 //apt/private:deb_repository.bzlrw
7
bazel_linux_packagesapt/privatedeb_repository.bzl.
deb_repositorydeb_repository
@N
P�
//apt/private:deb_resolver.bzlr
5
bazel_linux_packagesapt/privatedeb_resolver.bzl8
dependency_resolverdependency_resolver
>Q
S�
//apt/private:lockfile.bzlre
1
bazel_linux_packagesapt/privatelockfile.bzl"
lockfilelockfile
:B
Du
//apt/private:util.bzlrY
-
bazel_linux_packagesapt/privateutil.bzl
utilutil
6:
<�
$//apt/private:version_constraint.bzlr�
;
bazel_linux_packagesapt/privateversion_constraint.bzl6
version_constraintversion_constraint
DV
Xa
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.Frepository rule for downloading and uncompressing debian archive files�
4
bazel_linux_packagesapt/privatedeb_install.bzl�deb_installR�
�
deb_install.
name"A unique name for this repository. 
	add_files	 
apparent_name 
architecture 

build_file ,
&fix_absolute_interpreter_with_patchelf ,
&fix_relative_interpreter_with_patchelf 
fix_rpath_with_patchelf 
patchelf_dirs 
post_install_cmd �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 
source *B
deb_install3@@bazel_linux_packages//apt/private:deb_install.bzl
��0
.
name"A unique name for this repository. 

	add_files	 

apparent_name 

architecture 


build_file .
,
&fix_absolute_interpreter_with_patchelf .
,
&fix_relative_interpreter_with_patchelf 

fix_rpath_with_patchelf 

patchelf_dirs 

post_install_cmd �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 

source u
//apt/private:util.bzlrY
-
bazel_linux_packagesapt/privateutil.bzl
utilutil
6:
<Arepository rule for extracting debian archives into a install dir�
7
bazel_linux_packagesapt/privatedeb_repository.bzl�	index_integritiesR�	
�
index_integrities.
name"A unique name for this repository. 
architectures 

components �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 
suites 	
uri *K
index_integrities6@@bazel_linux_packages//apt/private:deb_repository.bzl
�$�$0
.
name"A unique name for this repository. 

architectures 


components �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 

suites 
	
uri u
//apt/private:util.bzlrY
-
bazel_linux_packagesapt/privateutil.bzl
utilutil
6:
<�
$//apt/private:version_constraint.bzlr�
;
bazel_linux_packagesapt/privateversion_constraint.bzl6
version_constraintversion_constraint
DV
X�	INTEGRITY_ERROR�
Please add the following to your `MODULE.bazel` to make downloading the
package indices reproducible.

apt.index_integrity(
    integrities = {integrities}
)
j��
Please add the following to your `MODULE.bazel` to make downloading the
package indices reproducible.

apt.index_integrity(
    integrities = {integrities}
)
(https://wiki.debian.org/DebianRepository�
5
bazel_linux_packagesapt/privatedeb_resolver.bzl�
//apt/private:version.bzlrf
0
bazel_linux_packagesapt/privateversion.bzl$
versionversion_lib
8C
P�
$//apt/private:version_constraint.bzlr�
;
bazel_linux_packagesapt/privateversion_constraint.bzl6
version_constraintversion_constraint
DV
Xpackage resolutionT
4
bazel_linux_packagesapt/privateintegrities.bzlGenerated index integrities.�
1
bazel_linux_packagesapt/privatelockfile.bzlu
//apt/private:util.bzlrY
-
bazel_linux_packagesapt/privateutil.bzl
utilutil
6:
<lock�
-
bazel_linux_packagesapt/privateutil.bzly
//lib:repo_utils.bzlr_
'
aspect_bazel_liblibrepo_utils.bzl&

repo_utils
repo_utils
0:
<	utilities�
0
bazel_linux_packagesapt/privateversion.bzle
//lib:strings.bzlrN
$
aspect_bazel_liblibstrings.bzl
ordord
-0
2parse debian version strings�
;
bazel_linux_packagesapt/privateversion_constraint.bzl�
//apt/private:version.bzlrf
0
bazel_linux_packagesapt/privateversion.bzl$
versionversion_lib
8C
Pversion constraint utilities��
+
bazel_linux_packagesaptextensions.bzl��aptJ��
�f
apt�
index_integrityQ
Optional tag to extend the list of integrity hashes for the package index URLs.
F
integrities3URL -> integrity mapping for the package index URLs
 �!
download�
Download/extract a set of `packages` from the Ubuntu/Debian repositories.

The packages are only extracted, no install hooks will be executed.
In most cases you need to consider how to handle library paths. See the
[Handle Library Paths](../README.md#handle-library-paths) for details.

The `lockfile` attribute is mandatory, but does not need to exist during the
initial setup. If the attribute is set to a non-existing file a mostly empty
repository that only exposes the target to copy the lockfile into the
workspace is created.

The `suites`, `architectures`, `components`, `uri` parameters roughly follow
[DEB822](https://manpages.debian.org/unstable/apt/sources.list.5.en.html#DEB822-STYLE_FORMAT).
This allows you copy and adapt from the sources.list.

For example
```
Types: deb
URIs: http://deb.debian.org/debian
Suites: trixie
Components: main
Architectures: amd64 armel
```

would be translated into
```
apt.download(
    ...
    architectures = ["amd64", "armel"],
    components = ["main"],
    suites = ["trixie"],
    uri = "http://deb.debian.org/debian",
    ...
)
```

It is strogly advised to use archive URLs to ensure stability of the
retrieved package index files to be able to re-generate the same lockfiles.
- Ubuntu: https://snapshot.ubuntu.com/ubuntu/20250115T150000Z
- Debian: https://snapshot.debian.org/archive/debian/20250115T150000Z


Multiple `download()` tags are allowed but need unique names.
1
name%Base name of the generated repository �
	add_files�
            Experimental: add files to the install dir.

            The keys are paths into the install dir. The label may
            only refer to a single file.
            "{arch}" in keys will be replaced by the value as returned by `uname -m`).
            	2{}`
architecturesBArchitectures for which to download the package lists (see DEB822)2	["amd64"]q

build_fileAExperimental: BUILD.bazel template for the generated install dir.2//apt:install.BUILD.bazel.tmplS

components9Deb components to download the packages from (see DEB822)2["main"]�
extra_patchelf_dirs�
            Additional paths to inspect for executable/library files to fix with `patchelf`

            Note that this will not recursively inspect subdirectories.
            "{arch}" will be replaced by the value as returned by `uname -m`).
            2[]�
&fix_absolute_interpreter_with_patchelf�
            Whether to absolutize the interpreter while fixing executables/libraries using `patchelf`

            Only has an effect if `fix_rpath_with_patchelf` is set to `True`.
            Mutually exclusive with `fix_relative_interpreter_with_patchelf`.

            Note that this will destroy remote-executability and cache-reuse across different systems
            if the path to the source/build directory is not exactly the same.
            2False�
&fix_relative_interpreter_with_patchelf�
            Whether to fix the interpreter of executables using `patchelf`

            Only has an effect if `fix_rpath_with_patchelf` is set to `True`.
            Mutually exclusive with `fix_absolute_interpreter_with_patchelf`.
            2Falsef
fix_rpath_with_patchelfBWhether to fix the RPATH of executables/libraries using `patchelf`2False]
lockfileMThe lock file to use for the index (it is fine for the file to not exist yet) $
packagesPackages to download �
patchelf_dirs�
            Paths to inspect for executable/library files to fix with `patchelf`

            Note that this will not recursively inspect subdirectories.
            "{arch}" will be replaced by the value as returned by `uname -m`).
            2?["lib/{arch}-linux-gnu", "usr/lib/{arch}-linux-gnu", "usr/bin"]�
post_install_cmd�
            Experimental: run a command after the install.

            The keys are the unused, the values the command to run as given to `rctx.execute()`.
             p
resolve_transitiveRWhether dependencies of dependencies should be resolved and added to the lockfile.2TrueC
suites5Deb suites to download the packages from (see DEB822) l
uriaDeb mirror to download the packages from (see URIs in DEB822 but only allows what basel supports) �!
ubuntu�
Download/extract a set of `packages` from the Ubuntu/Debian repositories.

The packages are only extracted, no install hooks will be executed.
In most cases you need to consider how to handle library paths. See the
[Handle Library Paths](../README.md#handle-library-paths) for details.

The `lockfile` attribute is mandatory, but does not need to exist during the
initial setup. If the attribute is set to a non-existing file a mostly empty
repository that only exposes the target to copy the lockfile into the
workspace is created.

The `suites`, `architectures`, `components`, `uri` parameters roughly follow
[DEB822](https://manpages.debian.org/unstable/apt/sources.list.5.en.html#DEB822-STYLE_FORMAT).
This allows you copy and adapt from the sources.list.

For example
```
Types: deb
URIs: http://deb.debian.org/debian
Suites: trixie
Components: main
Architectures: amd64 armel
```

would be translated into
```
apt.ubuntu(
    ...
    architectures = ["amd64", "armel"],
    components = ["main"],
    suites = ["trixie"],
    uri = "http://deb.debian.org/debian",
    ...
)
```

It is strogly advised to use archive URLs to ensure stability of the
retrieved package index files to be able to re-generate the same lockfiles.
- Ubuntu: https://snapshot.ubuntu.com/ubuntu/20250115T150000Z
- Debian: https://snapshot.debian.org/archive/debian/20250115T150000Z


Multiple `ubuntu()` tags are allowed but need unique names.
1
name%Base name of the generated repository �
	add_files�
            Experimental: add files to the install dir.

            The keys are paths into the install dir. The label may
            only refer to a single file.
            "{arch}" in keys will be replaced by the value as returned by `uname -m`).
            	2{}`
architecturesBArchitectures for which to download the package lists (see DEB822)2	["amd64"]q

build_fileAExperimental: BUILD.bazel template for the generated install dir.2//apt:install.BUILD.bazel.tmplS

components9Deb components to download the packages from (see DEB822)2["main"]�
extra_patchelf_dirs�
            Additional paths to inspect for executable/library files to fix with `patchelf`

            Note that this will not recursively inspect subdirectories.
            "{arch}" will be replaced by the value as returned by `uname -m`).
            2[]�
&fix_absolute_interpreter_with_patchelf�
            Whether to absolutize the interpreter while fixing executables/libraries using `patchelf`

            Only has an effect if `fix_rpath_with_patchelf` is set to `True`.
            Mutually exclusive with `fix_relative_interpreter_with_patchelf`.

            Note that this will destroy remote-executability and cache-reuse across different systems
            if the path to the source/build directory is not exactly the same.
            2False�
&fix_relative_interpreter_with_patchelf�
            Whether to fix the interpreter of executables using `patchelf`

            Only has an effect if `fix_rpath_with_patchelf` is set to `True`.
            Mutually exclusive with `fix_absolute_interpreter_with_patchelf`.
            2Falsef
fix_rpath_with_patchelfBWhether to fix the RPATH of executables/libraries using `patchelf`2False]
lockfileMThe lock file to use for the index (it is fine for the file to not exist yet) $
packagesPackages to download �
patchelf_dirs�
            Paths to inspect for executable/library files to fix with `patchelf`

            Note that this will not recursively inspect subdirectories.
            "{arch}" will be replaced by the value as returned by `uname -m`).
            2?["lib/{arch}-linux-gnu", "usr/lib/{arch}-linux-gnu", "usr/bin"]�
post_install_cmd�
            Experimental: run a command after the install.

            The keys are the unused, the values the command to run as given to `rctx.execute()`.
             p
resolve_transitiveRWhether dependencies of dependencies should be resolved and added to the lockfile.2TrueC
suites5Deb suites to download the packages from (see DEB822) �
uriaDeb mirror to download the packages from (see URIs in DEB822 but only allows what basel supports)25"https://snapshot.ubuntu.com/ubuntu/20250219T154000Z"�!
debian�
Download/extract a set of `packages` from the Ubuntu/Debian repositories.

The packages are only extracted, no install hooks will be executed.
In most cases you need to consider how to handle library paths. See the
[Handle Library Paths](../README.md#handle-library-paths) for details.

The `lockfile` attribute is mandatory, but does not need to exist during the
initial setup. If the attribute is set to a non-existing file a mostly empty
repository that only exposes the target to copy the lockfile into the
workspace is created.

The `suites`, `architectures`, `components`, `uri` parameters roughly follow
[DEB822](https://manpages.debian.org/unstable/apt/sources.list.5.en.html#DEB822-STYLE_FORMAT).
This allows you copy and adapt from the sources.list.

For example
```
Types: deb
URIs: http://deb.debian.org/debian
Suites: trixie
Components: main
Architectures: amd64 armel
```

would be translated into
```
apt.debian(
    ...
    architectures = ["amd64", "armel"],
    components = ["main"],
    suites = ["trixie"],
    uri = "http://deb.debian.org/debian",
    ...
)
```

It is strogly advised to use archive URLs to ensure stability of the
retrieved package index files to be able to re-generate the same lockfiles.
- Ubuntu: https://snapshot.ubuntu.com/ubuntu/20250115T150000Z
- Debian: https://snapshot.debian.org/archive/debian/20250115T150000Z


Multiple `debian()` tags are allowed but need unique names.
1
name%Base name of the generated repository �
	add_files�
            Experimental: add files to the install dir.

            The keys are paths into the install dir. The label may
            only refer to a single file.
            "{arch}" in keys will be replaced by the value as returned by `uname -m`).
            	2{}`
architecturesBArchitectures for which to download the package lists (see DEB822)2	["amd64"]q

build_fileAExperimental: BUILD.bazel template for the generated install dir.2//apt:install.BUILD.bazel.tmplS

components9Deb components to download the packages from (see DEB822)2["main"]�
extra_patchelf_dirs�
            Additional paths to inspect for executable/library files to fix with `patchelf`

            Note that this will not recursively inspect subdirectories.
            "{arch}" will be replaced by the value as returned by `uname -m`).
            2[]�
&fix_absolute_interpreter_with_patchelf�
            Whether to absolutize the interpreter while fixing executables/libraries using `patchelf`

            Only has an effect if `fix_rpath_with_patchelf` is set to `True`.
            Mutually exclusive with `fix_relative_interpreter_with_patchelf`.

            Note that this will destroy remote-executability and cache-reuse across different systems
            if the path to the source/build directory is not exactly the same.
            2False�
&fix_relative_interpreter_with_patchelf�
            Whether to fix the interpreter of executables using `patchelf`

            Only has an effect if `fix_rpath_with_patchelf` is set to `True`.
            Mutually exclusive with `fix_absolute_interpreter_with_patchelf`.
            2Falsef
fix_rpath_with_patchelfBWhether to fix the RPATH of executables/libraries using `patchelf`2False]
lockfileMThe lock file to use for the index (it is fine for the file to not exist yet) $
packagesPackages to download �
patchelf_dirs�
            Paths to inspect for executable/library files to fix with `patchelf`

            Note that this will not recursively inspect subdirectories.
            "{arch}" will be replaced by the value as returned by `uname -m`).
            2?["lib/{arch}-linux-gnu", "usr/lib/{arch}-linux-gnu", "usr/bin"]�
post_install_cmd�
            Experimental: run a command after the install.

            The keys are the unused, the values the command to run as given to `rctx.execute()`.
             p
resolve_transitiveRWhether dependencies of dependencies should be resolved and added to the lockfile.2TrueC
suites5Deb suites to download the packages from (see DEB822) �
uriaDeb mirror to download the packages from (see URIs in DEB822 but only allows what basel supports)2="https://snapshot.debian.org/archive/debian/20250201T023325Z""1
apt*@@bazel_linux_packages//apt:extensions.bzl
���
�
index_integrityQ
Optional tag to extend the list of integrity hashes for the package index URLs.
F
integrities3URL -> integrity mapping for the package index URLs
 H
F
integrities3URL -> integrity mapping for the package index URLs
 �2
�
download�
Download/extract a set of `packages` from the Ubuntu/Debian repositories.

The packages are only extracted, no install hooks will be executed.
In most cases you need to consider how to handle library paths. See the
[Handle Library Paths](../README.md#handle-library-paths) for details.

The `lockfile` attribute is mandatory, but does not need to exist during the
initial setup. If the attribute is set to a non-existing file a mostly empty
repository that only exposes the target to copy the lockfile into the
workspace is created.

The `suites`, `architectures`, `components`, `uri` parameters roughly follow
[DEB822](https://manpages.debian.org/unstable/apt/sources.list.5.en.html#DEB822-STYLE_FORMAT).
This allows you copy and adapt from the sources.list.

For example
```
Types: deb
URIs: http://deb.debian.org/debian
Suites: trixie
Components: main
Architectures: amd64 armel
```

would be translated into
```
apt.download(
    ...
    architectures = ["amd64", "armel"],
    components = ["main"],
    suites = ["trixie"],
    uri = "http://deb.debian.org/debian",
    ...
)
```

It is strogly advised to use archive URLs to ensure stability of the
retrieved package index files to be able to re-generate the same lockfiles.
- Ubuntu: https://snapshot.ubuntu.com/ubuntu/20250115T150000Z
- Debian: https://snapshot.debian.org/archive/debian/20250115T150000Z


Multiple `download()` tags are allowed but need unique names.
1
name%Base name of the generated repository �
	add_files�
Experimental: add files to the install dir.

The keys are paths into the install dir. The label may
only refer to a single file.
"{arch}" in keys will be replaced by the value as returned by `uname -m`).
	2{}`
architecturesBArchitectures for which to download the package lists (see DEB822)2	["amd64"]q

build_fileAExperimental: BUILD.bazel template for the generated install dir.2//apt:install.BUILD.bazel.tmplS

components9Deb components to download the packages from (see DEB822)2["main"]�
extra_patchelf_dirs�
Additional paths to inspect for executable/library files to fix with `patchelf`

Note that this will not recursively inspect subdirectories.
"{arch}" will be replaced by the value as returned by `uname -m`).
2[]�
&fix_absolute_interpreter_with_patchelf�
Whether to absolutize the interpreter while fixing executables/libraries using `patchelf`

Only has an effect if `fix_rpath_with_patchelf` is set to `True`.
Mutually exclusive with `fix_relative_interpreter_with_patchelf`.

Note that this will destroy remote-executability and cache-reuse across different systems
if the path to the source/build directory is not exactly the same.
2False�
&fix_relative_interpreter_with_patchelf�
Whether to fix the interpreter of executables using `patchelf`

Only has an effect if `fix_rpath_with_patchelf` is set to `True`.
Mutually exclusive with `fix_absolute_interpreter_with_patchelf`.
2Falsef
fix_rpath_with_patchelfBWhether to fix the RPATH of executables/libraries using `patchelf`2False]
lockfileMThe lock file to use for the index (it is fine for the file to not exist yet) $
packagesPackages to download �
patchelf_dirs�
Paths to inspect for executable/library files to fix with `patchelf`

Note that this will not recursively inspect subdirectories.
"{arch}" will be replaced by the value as returned by `uname -m`).
2?["lib/{arch}-linux-gnu", "usr/lib/{arch}-linux-gnu", "usr/bin"]�
post_install_cmd�
Experimental: run a command after the install.

The keys are the unused, the values the command to run as given to `rctx.execute()`.
 p
resolve_transitiveRWhether dependencies of dependencies should be resolved and added to the lockfile.2TrueC
suites5Deb suites to download the packages from (see DEB822) l
uriaDeb mirror to download the packages from (see URIs in DEB822 but only allows what basel supports) 3
1
name%Base name of the generated repository �
�
	add_files�
Experimental: add files to the install dir.

The keys are paths into the install dir. The label may
only refer to a single file.
"{arch}" in keys will be replaced by the value as returned by `uname -m`).
	2{}b
`
architecturesBArchitectures for which to download the package lists (see DEB822)2	["amd64"]s
q

build_fileAExperimental: BUILD.bazel template for the generated install dir.2//apt:install.BUILD.bazel.tmplU
S

components9Deb components to download the packages from (see DEB822)2["main"]�
�
extra_patchelf_dirs�
Additional paths to inspect for executable/library files to fix with `patchelf`

Note that this will not recursively inspect subdirectories.
"{arch}" will be replaced by the value as returned by `uname -m`).
2[]�
�
&fix_absolute_interpreter_with_patchelf�
Whether to absolutize the interpreter while fixing executables/libraries using `patchelf`

Only has an effect if `fix_rpath_with_patchelf` is set to `True`.
Mutually exclusive with `fix_relative_interpreter_with_patchelf`.

Note that this will destroy remote-executability and cache-reuse across different systems
if the path to the source/build directory is not exactly the same.
2False�
�
&fix_relative_interpreter_with_patchelf�
Whether to fix the interpreter of executables using `patchelf`

Only has an effect if `fix_rpath_with_patchelf` is set to `True`.
Mutually exclusive with `fix_absolute_interpreter_with_patchelf`.
2Falseh
f
fix_rpath_with_patchelfBWhether to fix the RPATH of executables/libraries using `patchelf`2False_
]
lockfileMThe lock file to use for the index (it is fine for the file to not exist yet) &
$
packagesPackages to download �
�
patchelf_dirs�
Paths to inspect for executable/library files to fix with `patchelf`

Note that this will not recursively inspect subdirectories.
"{arch}" will be replaced by the value as returned by `uname -m`).
2?["lib/{arch}-linux-gnu", "usr/lib/{arch}-linux-gnu", "usr/bin"]�
�
post_install_cmd�
Experimental: run a command after the install.

The keys are the unused, the values the command to run as given to `rctx.execute()`.
 r
p
resolve_transitiveRWhether dependencies of dependencies should be resolved and added to the lockfile.2TrueE
C
suites5Deb suites to download the packages from (see DEB822) n
l
uriaDeb mirror to download the packages from (see URIs in DEB822 but only allows what basel supports) �3
�
ubuntu�
Download/extract a set of `packages` from the Ubuntu/Debian repositories.

The packages are only extracted, no install hooks will be executed.
In most cases you need to consider how to handle library paths. See the
[Handle Library Paths](../README.md#handle-library-paths) for details.

The `lockfile` attribute is mandatory, but does not need to exist during the
initial setup. If the attribute is set to a non-existing file a mostly empty
repository that only exposes the target to copy the lockfile into the
workspace is created.

The `suites`, `architectures`, `components`, `uri` parameters roughly follow
[DEB822](https://manpages.debian.org/unstable/apt/sources.list.5.en.html#DEB822-STYLE_FORMAT).
This allows you copy and adapt from the sources.list.

For example
```
Types: deb
URIs: http://deb.debian.org/debian
Suites: trixie
Components: main
Architectures: amd64 armel
```

would be translated into
```
apt.ubuntu(
    ...
    architectures = ["amd64", "armel"],
    components = ["main"],
    suites = ["trixie"],
    uri = "http://deb.debian.org/debian",
    ...
)
```

It is strogly advised to use archive URLs to ensure stability of the
retrieved package index files to be able to re-generate the same lockfiles.
- Ubuntu: https://snapshot.ubuntu.com/ubuntu/20250115T150000Z
- Debian: https://snapshot.debian.org/archive/debian/20250115T150000Z


Multiple `ubuntu()` tags are allowed but need unique names.
1
name%Base name of the generated repository �
	add_files�
Experimental: add files to the install dir.

The keys are paths into the install dir. The label may
only refer to a single file.
"{arch}" in keys will be replaced by the value as returned by `uname -m`).
	2{}`
architecturesBArchitectures for which to download the package lists (see DEB822)2	["amd64"]q

build_fileAExperimental: BUILD.bazel template for the generated install dir.2//apt:install.BUILD.bazel.tmplS

components9Deb components to download the packages from (see DEB822)2["main"]�
extra_patchelf_dirs�
Additional paths to inspect for executable/library files to fix with `patchelf`

Note that this will not recursively inspect subdirectories.
"{arch}" will be replaced by the value as returned by `uname -m`).
2[]�
&fix_absolute_interpreter_with_patchelf�
Whether to absolutize the interpreter while fixing executables/libraries using `patchelf`

Only has an effect if `fix_rpath_with_patchelf` is set to `True`.
Mutually exclusive with `fix_relative_interpreter_with_patchelf`.

Note that this will destroy remote-executability and cache-reuse across different systems
if the path to the source/build directory is not exactly the same.
2False�
&fix_relative_interpreter_with_patchelf�
Whether to fix the interpreter of executables using `patchelf`

Only has an effect if `fix_rpath_with_patchelf` is set to `True`.
Mutually exclusive with `fix_absolute_interpreter_with_patchelf`.
2Falsef
fix_rpath_with_patchelfBWhether to fix the RPATH of executables/libraries using `patchelf`2False]
lockfileMThe lock file to use for the index (it is fine for the file to not exist yet) $
packagesPackages to download �
patchelf_dirs�
Paths to inspect for executable/library files to fix with `patchelf`

Note that this will not recursively inspect subdirectories.
"{arch}" will be replaced by the value as returned by `uname -m`).
2?["lib/{arch}-linux-gnu", "usr/lib/{arch}-linux-gnu", "usr/bin"]�
post_install_cmd�
Experimental: run a command after the install.

The keys are the unused, the values the command to run as given to `rctx.execute()`.
 p
resolve_transitiveRWhether dependencies of dependencies should be resolved and added to the lockfile.2TrueC
suites5Deb suites to download the packages from (see DEB822) �
uriaDeb mirror to download the packages from (see URIs in DEB822 but only allows what basel supports)25"https://snapshot.ubuntu.com/ubuntu/20250219T154000Z"3
1
name%Base name of the generated repository �
�
	add_files�
Experimental: add files to the install dir.

The keys are paths into the install dir. The label may
only refer to a single file.
"{arch}" in keys will be replaced by the value as returned by `uname -m`).
	2{}b
`
architecturesBArchitectures for which to download the package lists (see DEB822)2	["amd64"]s
q

build_fileAExperimental: BUILD.bazel template for the generated install dir.2//apt:install.BUILD.bazel.tmplU
S

components9Deb components to download the packages from (see DEB822)2["main"]�
�
extra_patchelf_dirs�
Additional paths to inspect for executable/library files to fix with `patchelf`

Note that this will not recursively inspect subdirectories.
"{arch}" will be replaced by the value as returned by `uname -m`).
2[]�
�
&fix_absolute_interpreter_with_patchelf�
Whether to absolutize the interpreter while fixing executables/libraries using `patchelf`

Only has an effect if `fix_rpath_with_patchelf` is set to `True`.
Mutually exclusive with `fix_relative_interpreter_with_patchelf`.

Note that this will destroy remote-executability and cache-reuse across different systems
if the path to the source/build directory is not exactly the same.
2False�
�
&fix_relative_interpreter_with_patchelf�
Whether to fix the interpreter of executables using `patchelf`

Only has an effect if `fix_rpath_with_patchelf` is set to `True`.
Mutually exclusive with `fix_absolute_interpreter_with_patchelf`.
2Falseh
f
fix_rpath_with_patchelfBWhether to fix the RPATH of executables/libraries using `patchelf`2False_
]
lockfileMThe lock file to use for the index (it is fine for the file to not exist yet) &
$
packagesPackages to download �
�
patchelf_dirs�
Paths to inspect for executable/library files to fix with `patchelf`

Note that this will not recursively inspect subdirectories.
"{arch}" will be replaced by the value as returned by `uname -m`).
2?["lib/{arch}-linux-gnu", "usr/lib/{arch}-linux-gnu", "usr/bin"]�
�
post_install_cmd�
Experimental: run a command after the install.

The keys are the unused, the values the command to run as given to `rctx.execute()`.
 r
p
resolve_transitiveRWhether dependencies of dependencies should be resolved and added to the lockfile.2TrueE
C
suites5Deb suites to download the packages from (see DEB822) �
�
uriaDeb mirror to download the packages from (see URIs in DEB822 but only allows what basel supports)25"https://snapshot.ubuntu.com/ubuntu/20250219T154000Z"�3
�
debian�
Download/extract a set of `packages` from the Ubuntu/Debian repositories.

The packages are only extracted, no install hooks will be executed.
In most cases you need to consider how to handle library paths. See the
[Handle Library Paths](../README.md#handle-library-paths) for details.

The `lockfile` attribute is mandatory, but does not need to exist during the
initial setup. If the attribute is set to a non-existing file a mostly empty
repository that only exposes the target to copy the lockfile into the
workspace is created.

The `suites`, `architectures`, `components`, `uri` parameters roughly follow
[DEB822](https://manpages.debian.org/unstable/apt/sources.list.5.en.html#DEB822-STYLE_FORMAT).
This allows you copy and adapt from the sources.list.

For example
```
Types: deb
URIs: http://deb.debian.org/debian
Suites: trixie
Components: main
Architectures: amd64 armel
```

would be translated into
```
apt.debian(
    ...
    architectures = ["amd64", "armel"],
    components = ["main"],
    suites = ["trixie"],
    uri = "http://deb.debian.org/debian",
    ...
)
```

It is strogly advised to use archive URLs to ensure stability of the
retrieved package index files to be able to re-generate the same lockfiles.
- Ubuntu: https://snapshot.ubuntu.com/ubuntu/20250115T150000Z
- Debian: https://snapshot.debian.org/archive/debian/20250115T150000Z


Multiple `debian()` tags are allowed but need unique names.
1
name%Base name of the generated repository �
	add_files�
Experimental: add files to the install dir.

The keys are paths into the install dir. The label may
only refer to a single file.
"{arch}" in keys will be replaced by the value as returned by `uname -m`).
	2{}`
architecturesBArchitectures for which to download the package lists (see DEB822)2	["amd64"]q

build_fileAExperimental: BUILD.bazel template for the generated install dir.2//apt:install.BUILD.bazel.tmplS

components9Deb components to download the packages from (see DEB822)2["main"]�
extra_patchelf_dirs�
Additional paths to inspect for executable/library files to fix with `patchelf`

Note that this will not recursively inspect subdirectories.
"{arch}" will be replaced by the value as returned by `uname -m`).
2[]�
&fix_absolute_interpreter_with_patchelf�
Whether to absolutize the interpreter while fixing executables/libraries using `patchelf`

Only has an effect if `fix_rpath_with_patchelf` is set to `True`.
Mutually exclusive with `fix_relative_interpreter_with_patchelf`.

Note that this will destroy remote-executability and cache-reuse across different systems
if the path to the source/build directory is not exactly the same.
2False�
&fix_relative_interpreter_with_patchelf�
Whether to fix the interpreter of executables using `patchelf`

Only has an effect if `fix_rpath_with_patchelf` is set to `True`.
Mutually exclusive with `fix_absolute_interpreter_with_patchelf`.
2Falsef
fix_rpath_with_patchelfBWhether to fix the RPATH of executables/libraries using `patchelf`2False]
lockfileMThe lock file to use for the index (it is fine for the file to not exist yet) $
packagesPackages to download �
patchelf_dirs�
Paths to inspect for executable/library files to fix with `patchelf`

Note that this will not recursively inspect subdirectories.
"{arch}" will be replaced by the value as returned by `uname -m`).
2?["lib/{arch}-linux-gnu", "usr/lib/{arch}-linux-gnu", "usr/bin"]�
post_install_cmd�
Experimental: run a command after the install.

The keys are the unused, the values the command to run as given to `rctx.execute()`.
 p
resolve_transitiveRWhether dependencies of dependencies should be resolved and added to the lockfile.2TrueC
suites5Deb suites to download the packages from (see DEB822) �
uriaDeb mirror to download the packages from (see URIs in DEB822 but only allows what basel supports)2="https://snapshot.debian.org/archive/debian/20250201T023325Z"3
1
name%Base name of the generated repository �
�
	add_files�
Experimental: add files to the install dir.

The keys are paths into the install dir. The label may
only refer to a single file.
"{arch}" in keys will be replaced by the value as returned by `uname -m`).
	2{}b
`
architecturesBArchitectures for which to download the package lists (see DEB822)2	["amd64"]s
q

build_fileAExperimental: BUILD.bazel template for the generated install dir.2//apt:install.BUILD.bazel.tmplU
S

components9Deb components to download the packages from (see DEB822)2["main"]�
�
extra_patchelf_dirs�
Additional paths to inspect for executable/library files to fix with `patchelf`

Note that this will not recursively inspect subdirectories.
"{arch}" will be replaced by the value as returned by `uname -m`).
2[]�
�
&fix_absolute_interpreter_with_patchelf�
Whether to absolutize the interpreter while fixing executables/libraries using `patchelf`

Only has an effect if `fix_rpath_with_patchelf` is set to `True`.
Mutually exclusive with `fix_relative_interpreter_with_patchelf`.

Note that this will destroy remote-executability and cache-reuse across different systems
if the path to the source/build directory is not exactly the same.
2False�
�
&fix_relative_interpreter_with_patchelf�
Whether to fix the interpreter of executables using `patchelf`

Only has an effect if `fix_rpath_with_patchelf` is set to `True`.
Mutually exclusive with `fix_absolute_interpreter_with_patchelf`.
2Falseh
f
fix_rpath_with_patchelfBWhether to fix the RPATH of executables/libraries using `patchelf`2False_
]
lockfileMThe lock file to use for the index (it is fine for the file to not exist yet) &
$
packagesPackages to download �
�
patchelf_dirs�
Paths to inspect for executable/library files to fix with `patchelf`

Note that this will not recursively inspect subdirectories.
"{arch}" will be replaced by the value as returned by `uname -m`).
2?["lib/{arch}-linux-gnu", "usr/lib/{arch}-linux-gnu", "usr/bin"]�
�
post_install_cmd�
Experimental: run a command after the install.

The keys are the unused, the values the command to run as given to `rctx.execute()`.
 r
p
resolve_transitiveRWhether dependencies of dependencies should be resolved and added to the lockfile.2TrueE
C
suites5Deb suites to download the packages from (see DEB822) �
�
uriaDeb mirror to download the packages from (see URIs in DEB822 but only allows what basel supports)2="https://snapshot.debian.org/archive/debian/20250201T023325Z"�
//apt/private:deb_download.bzlrq
5
bazel_linux_packagesapt/privatedeb_download.bzl*
deb_downloaddeb_download
>J
L�
//apt/private:deb_install.bzlrn
4
bazel_linux_packagesapt/privatedeb_install.bzl(
deb_installdeb_install
=H
J�
 //apt/private:deb_repository.bzlrw
7
bazel_linux_packagesapt/privatedeb_repository.bzl.
deb_repositorydeb_repository
@N
P�
//apt/private:integrities.bzlrn
4
bazel_linux_packagesapt/privateintegrities.bzl(
INTEGRITIESINTEGRITIES
=H
J�	DEFAULT_DEBIAN_URL;https://snapshot.debian.org/archive/debian/20250201T023325Zj=;https://snapshot.debian.org/archive/debian/20250201T023325Z�	DEFAULT_UBUNTU_URL3https://snapshot.ubuntu.com/ubuntu/20250219T154000Zj53https://snapshot.ubuntu.com/ubuntu/20250219T154000Z�	DOC�
Download/extract a set of `packages` from the Ubuntu/Debian repositories.

The packages are only extracted, no install hooks will be executed.
In most cases you need to consider how to handle library paths. See the
[Handle Library Paths](../README.md#handle-library-paths) for details.

The `lockfile` attribute is mandatory, but does not need to exist during the
initial setup. If the attribute is set to a non-existing file a mostly empty
repository that only exposes the target to copy the lockfile into the
workspace is created.

The `suites`, `architectures`, `components`, `uri` parameters roughly follow
[DEB822](https://manpages.debian.org/unstable/apt/sources.list.5.en.html#DEB822-STYLE_FORMAT).
This allows you copy and adapt from the sources.list.

For example
```
Types: deb
URIs: http://deb.debian.org/debian
Suites: trixie
Components: main
Architectures: amd64 armel
```

would be translated into
```
apt.{tag}(
    ...
    architectures = ["amd64", "armel"],
    components = ["main"],
    suites = ["trixie"],
    uri = "http://deb.debian.org/debian",
    ...
)
```

It is strogly advised to use archive URLs to ensure stability of the
retrieved package index files to be able to re-generate the same lockfiles.
- Ubuntu: https://snapshot.ubuntu.com/ubuntu/20250115T150000Z
- Debian: https://snapshot.debian.org/archive/debian/20250115T150000Z


Multiple `{tag}()` tags are allowed but need unique names.
j��
Download/extract a set of `packages` from the Ubuntu/Debian repositories.

The packages are only extracted, no install hooks will be executed.
In most cases you need to consider how to handle library paths. See the
[Handle Library Paths](../README.md#handle-library-paths) for details.

The `lockfile` attribute is mandatory, but does not need to exist during the
initial setup. If the attribute is set to a non-existing file a mostly empty
repository that only exposes the target to copy the lockfile into the
workspace is created.

The `suites`, `architectures`, `components`, `uri` parameters roughly follow
[DEB822](https://manpages.debian.org/unstable/apt/sources.list.5.en.html#DEB822-STYLE_FORMAT).
This allows you copy and adapt from the sources.list.

For example
```
Types: deb
URIs: http://deb.debian.org/debian
Suites: trixie
Components: main
Architectures: amd64 armel
```

would be translated into
```
apt.{tag}(
    ...
    architectures = ["amd64", "armel"],
    components = ["main"],
    suites = ["trixie"],
    uri = "http://deb.debian.org/debian",
    ...
)
```

It is strogly advised to use archive URLs to ensure stability of the
retrieved package index files to be able to re-generate the same lockfiles.
- Ubuntu: https://snapshot.ubuntu.com/ubuntu/20250115T150000Z
- Debian: https://snapshot.debian.org/archive/debian/20250115T150000Z


Multiple `{tag}()` tags are allowed but need unique names.
�
# Extension for downloading and extracting Debian/Ubuntu packages.

## Usage
Place the following in your `MODULE.bazel`. Then:
- run `bazel run @busybox//:lock` to create a lockfile and
- run `bazel run @busybox//:bin/busybox` to download/extract the package and run the binary.

```py
apt = use_extension("@bazel_linux_packages//apt:extensions.bzl", "apt")
apt.ubuntu(
    name = "busybox",
    lockfile = "//:focal.lock.json",
    packages = ["busybox"],
    suites = ["focal"],
)
use_repo(apt, "busybox")
```
�

)
bazel_linux_packagesinternaldeb.bzl�deb_archiveR�
�
deb_archive.
name"A unique name for this repository. 
	integrity �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 

urls *7
deb_archive(@@bazel_linux_packages//internal:deb.bzl
0
.
name"A unique name for this repository. 

	integrity �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 


urls �
Internal helper to download host tooling from debian archives.
These tools are used for the repository setup of the use requested
repositories.
 