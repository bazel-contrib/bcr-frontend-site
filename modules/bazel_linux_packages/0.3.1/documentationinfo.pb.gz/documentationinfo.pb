��
aptextensions.bzl�aptJ�
�f
apt�
index_integrityOOptional tag to extend the list of integrity hashes for the package index URLs.F
integrities3URL -> integrity mapping for the package index URLs
 �

source�Define a Debian/Ubuntu repository to download from.

The `suites`, `architectures`, `components`, `uri` parameters roughly follow
[DEB822](https://manpages.debian.org/unstable/apt/sources.list.5.en.html#DEB822-STYLE_FORMAT).
This allows you copy and adapt from the sources.list.

For example
```
Types: deb
URIs: http://deb.debian.org/debian
Suites: trixie
Components: main
Architectures: amd64 armel
```

would be translated into
```
apt.source(
    ...
    architectures = ["amd64", "armel"],
    components = ["main"],
    suites = ["trixie"],
    uri = "http://deb.debian.org/debian",
    ...
)
```

It is strogly advised to use archive URLs to ensure stability of the
retrieved package index files to be able to re-generate the same lockfiles.
- Ubuntu: https://snapshot.ubuntu.com/ubuntu/20250115T150000Z
- Debian: https://snapshot.debian.org/archive/debian/20250115T150000Z


Multiple `source()` tags are allowed but need unique names.C
suites5Deb suites to download the packages from (see DEB822) `
architecturesBArchitectures for which to download the package lists (see DEB822)2	["amd64"]S

components9Deb components to download the packages from (see DEB822)2["main"],
name Name of the generated repository l
uriaDeb mirror to download the packages from (see URIs in DEB822 but only allows what basel supports) �
download�Download/extract a set of `packages` from the Ubuntu/Debian repositories.

The packages are only extracted, no install hooks will be executed.
In most cases you need to consider how to handle library paths. See the
[Handle Library Paths](../README.md#handle-library-paths) for details.

The `lockfile` attribute is mandatory, but does not need to exist during the
initial setup. If the attribute is set to a non-existing file a mostly empty
repository that only exposes the target to copy the lockfile into the
workspace is created.1
name%Base name of the generated repository $
packagesPackages to download ]
lockfileMThe lock file to use for the index (it is fine for the file to not exist yet) p
resolve_transitiveRWhether dependencies of dependencies should be resolved and added to the lockfile.2Truef
fix_rpath_with_patchelfBWhether to fix the RPATH of executables/libraries using `patchelf`2False�
&fix_relative_interpreter_with_patchelf�Whether to fix the interpreter of executables using `patchelf`

Only has an effect if `fix_rpath_with_patchelf` is set to `True`.
Mutually exclusive with `fix_absolute_interpreter_with_patchelf`.2False�
&fix_absolute_interpreter_with_patchelf�Whether to absolutize the interpreter while fixing executables/libraries using `patchelf`

Only has an effect if `fix_rpath_with_patchelf` is set to `True`.
Mutually exclusive with `fix_relative_interpreter_with_patchelf`.

Note that this will destroy remote-executability and cache-reuse across different systems
if the path to the source/build directory is not exactly the same.2False�
patchelf_dirs�Paths to inspect for executable/library files to fix with `patchelf`

Note that this will not recursively inspect subdirectories.
"{arch}" will be replaced by the value as returned by `uname -m`).2?["lib/{arch}-linux-gnu", "usr/lib/{arch}-linux-gnu", "usr/bin"]�
extra_patchelf_dirs�Additional paths to inspect for executable/library files to fix with `patchelf`

Note that this will not recursively inspect subdirectories.
"{arch}" will be replaced by the value as returned by `uname -m`).2[]�
	add_files�Experimental: add files to the install dir.

The keys are paths into the install dir. The label may
only refer to a single file.
"{arch}" in keys will be replaced by the value as returned by `uname -m`).2{}�
post_install_cmd�Experimental: run a command after the install.

The keys are the unused, the values the command to run as given to `rctx.execute()`.2{}s

build_fileAExperimental: BUILD.bazel template for the generated install dir.2 "//apt:install.BUILD.bazel.tmpl"_
glob_patternEExperimental: `glob()` pattern for the default `build_file` template.2["**"]w
glob_excludesNExperimental: `glob()` pattern excludes for the default `build_file` template.2["usr/share/man/**"]G
sources8Names of source() repositories to download packages from |
architectureseArchitectures for which to create the install (defaults to architectures from `sources` if not given)2[]�!
ubuntu�Download/extract a set of `packages` from the Ubuntu/Debian repositories.

The packages are only extracted, no install hooks will be executed.
In most cases you need to consider how to handle library paths. See the
[Handle Library Paths](../README.md#handle-library-paths) for details.

The `lockfile` attribute is mandatory, but does not need to exist during the
initial setup. If the attribute is set to a non-existing file a mostly empty
repository that only exposes the target to copy the lockfile into the
workspace is created.

Define a Debian/Ubuntu repository to download from.

The `suites`, `architectures`, `components`, `uri` parameters roughly follow
[DEB822](https://manpages.debian.org/unstable/apt/sources.list.5.en.html#DEB822-STYLE_FORMAT).
This allows you copy and adapt from the sources.list.

For example
```
Types: deb
URIs: http://deb.debian.org/debian
Suites: trixie
Components: main
Architectures: amd64 armel
```

would be translated into
```
apt.ubuntu(
    ...
    architectures = ["amd64", "armel"],
    components = ["main"],
    suites = ["trixie"],
    uri = "http://deb.debian.org/debian",
    ...
)
```

It is strogly advised to use archive URLs to ensure stability of the
retrieved package index files to be able to re-generate the same lockfiles.
- Ubuntu: https://snapshot.ubuntu.com/ubuntu/20250115T150000Z
- Debian: https://snapshot.debian.org/archive/debian/20250115T150000Z


Multiple `ubuntu()` tags are allowed but need unique names.1
name%Base name of the generated repository $
packagesPackages to download ]
lockfileMThe lock file to use for the index (it is fine for the file to not exist yet) p
resolve_transitiveRWhether dependencies of dependencies should be resolved and added to the lockfile.2Truef
fix_rpath_with_patchelfBWhether to fix the RPATH of executables/libraries using `patchelf`2False�
&fix_relative_interpreter_with_patchelf�Whether to fix the interpreter of executables using `patchelf`

Only has an effect if `fix_rpath_with_patchelf` is set to `True`.
Mutually exclusive with `fix_absolute_interpreter_with_patchelf`.2False�
&fix_absolute_interpreter_with_patchelf�Whether to absolutize the interpreter while fixing executables/libraries using `patchelf`

Only has an effect if `fix_rpath_with_patchelf` is set to `True`.
Mutually exclusive with `fix_relative_interpreter_with_patchelf`.

Note that this will destroy remote-executability and cache-reuse across different systems
if the path to the source/build directory is not exactly the same.2False�
patchelf_dirs�Paths to inspect for executable/library files to fix with `patchelf`

Note that this will not recursively inspect subdirectories.
"{arch}" will be replaced by the value as returned by `uname -m`).2?["lib/{arch}-linux-gnu", "usr/lib/{arch}-linux-gnu", "usr/bin"]�
extra_patchelf_dirs�Additional paths to inspect for executable/library files to fix with `patchelf`

Note that this will not recursively inspect subdirectories.
"{arch}" will be replaced by the value as returned by `uname -m`).2[]�
	add_files�Experimental: add files to the install dir.

The keys are paths into the install dir. The label may
only refer to a single file.
"{arch}" in keys will be replaced by the value as returned by `uname -m`).2{}�
post_install_cmd�Experimental: run a command after the install.

The keys are the unused, the values the command to run as given to `rctx.execute()`.2{}s

build_fileAExperimental: BUILD.bazel template for the generated install dir.2 "//apt:install.BUILD.bazel.tmpl"_
glob_patternEExperimental: `glob()` pattern for the default `build_file` template.2["**"]w
glob_excludesNExperimental: `glob()` pattern excludes for the default `build_file` template.2["usr/share/man/**"]C
suites5Deb suites to download the packages from (see DEB822) `
architecturesBArchitectures for which to download the package lists (see DEB822)2	["amd64"]S

components9Deb components to download the packages from (see DEB822)2["main"]�
uriaDeb mirror to download the packages from (see URIs in DEB822 but only allows what basel supports)25"https://snapshot.ubuntu.com/ubuntu/20250219T154000Z"�!
debian�Download/extract a set of `packages` from the Ubuntu/Debian repositories.

The packages are only extracted, no install hooks will be executed.
In most cases you need to consider how to handle library paths. See the
[Handle Library Paths](../README.md#handle-library-paths) for details.

The `lockfile` attribute is mandatory, but does not need to exist during the
initial setup. If the attribute is set to a non-existing file a mostly empty
repository that only exposes the target to copy the lockfile into the
workspace is created.

Define a Debian/Ubuntu repository to download from.

The `suites`, `architectures`, `components`, `uri` parameters roughly follow
[DEB822](https://manpages.debian.org/unstable/apt/sources.list.5.en.html#DEB822-STYLE_FORMAT).
This allows you copy and adapt from the sources.list.

For example
```
Types: deb
URIs: http://deb.debian.org/debian
Suites: trixie
Components: main
Architectures: amd64 armel
```

would be translated into
```
apt.debian(
    ...
    architectures = ["amd64", "armel"],
    components = ["main"],
    suites = ["trixie"],
    uri = "http://deb.debian.org/debian",
    ...
)
```

It is strogly advised to use archive URLs to ensure stability of the
retrieved package index files to be able to re-generate the same lockfiles.
- Ubuntu: https://snapshot.ubuntu.com/ubuntu/20250115T150000Z
- Debian: https://snapshot.debian.org/archive/debian/20250115T150000Z


Multiple `debian()` tags are allowed but need unique names.1
name%Base name of the generated repository $
packagesPackages to download ]
lockfileMThe lock file to use for the index (it is fine for the file to not exist yet) p
resolve_transitiveRWhether dependencies of dependencies should be resolved and added to the lockfile.2Truef
fix_rpath_with_patchelfBWhether to fix the RPATH of executables/libraries using `patchelf`2False�
&fix_relative_interpreter_with_patchelf�Whether to fix the interpreter of executables using `patchelf`

Only has an effect if `fix_rpath_with_patchelf` is set to `True`.
Mutually exclusive with `fix_absolute_interpreter_with_patchelf`.2False�
&fix_absolute_interpreter_with_patchelf�Whether to absolutize the interpreter while fixing executables/libraries using `patchelf`

Only has an effect if `fix_rpath_with_patchelf` is set to `True`.
Mutually exclusive with `fix_relative_interpreter_with_patchelf`.

Note that this will destroy remote-executability and cache-reuse across different systems
if the path to the source/build directory is not exactly the same.2False�
patchelf_dirs�Paths to inspect for executable/library files to fix with `patchelf`

Note that this will not recursively inspect subdirectories.
"{arch}" will be replaced by the value as returned by `uname -m`).2?["lib/{arch}-linux-gnu", "usr/lib/{arch}-linux-gnu", "usr/bin"]�
extra_patchelf_dirs�Additional paths to inspect for executable/library files to fix with `patchelf`

Note that this will not recursively inspect subdirectories.
"{arch}" will be replaced by the value as returned by `uname -m`).2[]�
	add_files�Experimental: add files to the install dir.

The keys are paths into the install dir. The label may
only refer to a single file.
"{arch}" in keys will be replaced by the value as returned by `uname -m`).2{}�
post_install_cmd�Experimental: run a command after the install.

The keys are the unused, the values the command to run as given to `rctx.execute()`.2{}s

build_fileAExperimental: BUILD.bazel template for the generated install dir.2 "//apt:install.BUILD.bazel.tmpl"_
glob_patternEExperimental: `glob()` pattern for the default `build_file` template.2["**"]w
glob_excludesNExperimental: `glob()` pattern excludes for the default `build_file` template.2["usr/share/man/**"]C
suites5Deb suites to download the packages from (see DEB822) `
architecturesBArchitectures for which to download the package lists (see DEB822)2	["amd64"]S

components9Deb components to download the packages from (see DEB822)2["main"]�
uriaDeb mirror to download the packages from (see URIs in DEB822 but only allows what basel supports)2="https://snapshot.debian.org/archive/debian/20250201T023325Z""//apt:extensions.bzl�
�
index_integrityOOptional tag to extend the list of integrity hashes for the package index URLs.F
integrities3URL -> integrity mapping for the package index URLs
 H
F
integrities3URL -> integrity mapping for the package index URLs
 �
�

source�Define a Debian/Ubuntu repository to download from.

The `suites`, `architectures`, `components`, `uri` parameters roughly follow
[DEB822](https://manpages.debian.org/unstable/apt/sources.list.5.en.html#DEB822-STYLE_FORMAT).
This allows you copy and adapt from the sources.list.

For example
```
Types: deb
URIs: http://deb.debian.org/debian
Suites: trixie
Components: main
Architectures: amd64 armel
```

would be translated into
```
apt.source(
    ...
    architectures = ["amd64", "armel"],
    components = ["main"],
    suites = ["trixie"],
    uri = "http://deb.debian.org/debian",
    ...
)
```

It is strogly advised to use archive URLs to ensure stability of the
retrieved package index files to be able to re-generate the same lockfiles.
- Ubuntu: https://snapshot.ubuntu.com/ubuntu/20250115T150000Z
- Debian: https://snapshot.debian.org/archive/debian/20250115T150000Z


Multiple `source()` tags are allowed but need unique names.C
suites5Deb suites to download the packages from (see DEB822) `
architecturesBArchitectures for which to download the package lists (see DEB822)2	["amd64"]S

components9Deb components to download the packages from (see DEB822)2["main"],
name Name of the generated repository l
uriaDeb mirror to download the packages from (see URIs in DEB822 but only allows what basel supports) E
C
suites5Deb suites to download the packages from (see DEB822) b
`
architecturesBArchitectures for which to download the package lists (see DEB822)2	["amd64"]U
S

components9Deb components to download the packages from (see DEB822)2["main"].
,
name Name of the generated repository n
l
uriaDeb mirror to download the packages from (see URIs in DEB822 but only allows what basel supports) �,
�
download�Download/extract a set of `packages` from the Ubuntu/Debian repositories.

The packages are only extracted, no install hooks will be executed.
In most cases you need to consider how to handle library paths. See the
[Handle Library Paths](../README.md#handle-library-paths) for details.

The `lockfile` attribute is mandatory, but does not need to exist during the
initial setup. If the attribute is set to a non-existing file a mostly empty
repository that only exposes the target to copy the lockfile into the
workspace is created.1
name%Base name of the generated repository $
packagesPackages to download ]
lockfileMThe lock file to use for the index (it is fine for the file to not exist yet) p
resolve_transitiveRWhether dependencies of dependencies should be resolved and added to the lockfile.2Truef
fix_rpath_with_patchelfBWhether to fix the RPATH of executables/libraries using `patchelf`2False�
&fix_relative_interpreter_with_patchelf�Whether to fix the interpreter of executables using `patchelf`

Only has an effect if `fix_rpath_with_patchelf` is set to `True`.
Mutually exclusive with `fix_absolute_interpreter_with_patchelf`.2False�
&fix_absolute_interpreter_with_patchelf�Whether to absolutize the interpreter while fixing executables/libraries using `patchelf`

Only has an effect if `fix_rpath_with_patchelf` is set to `True`.
Mutually exclusive with `fix_relative_interpreter_with_patchelf`.

Note that this will destroy remote-executability and cache-reuse across different systems
if the path to the source/build directory is not exactly the same.2False�
patchelf_dirs�Paths to inspect for executable/library files to fix with `patchelf`

Note that this will not recursively inspect subdirectories.
"{arch}" will be replaced by the value as returned by `uname -m`).2?["lib/{arch}-linux-gnu", "usr/lib/{arch}-linux-gnu", "usr/bin"]�
extra_patchelf_dirs�Additional paths to inspect for executable/library files to fix with `patchelf`

Note that this will not recursively inspect subdirectories.
"{arch}" will be replaced by the value as returned by `uname -m`).2[]�
	add_files�Experimental: add files to the install dir.

The keys are paths into the install dir. The label may
only refer to a single file.
"{arch}" in keys will be replaced by the value as returned by `uname -m`).2{}�
post_install_cmd�Experimental: run a command after the install.

The keys are the unused, the values the command to run as given to `rctx.execute()`.2{}s

build_fileAExperimental: BUILD.bazel template for the generated install dir.2 "//apt:install.BUILD.bazel.tmpl"_
glob_patternEExperimental: `glob()` pattern for the default `build_file` template.2["**"]w
glob_excludesNExperimental: `glob()` pattern excludes for the default `build_file` template.2["usr/share/man/**"]G
sources8Names of source() repositories to download packages from |
architectureseArchitectures for which to create the install (defaults to architectures from `sources` if not given)2[]3
1
name%Base name of the generated repository &
$
packagesPackages to download _
]
lockfileMThe lock file to use for the index (it is fine for the file to not exist yet) r
p
resolve_transitiveRWhether dependencies of dependencies should be resolved and added to the lockfile.2Trueh
f
fix_rpath_with_patchelfBWhether to fix the RPATH of executables/libraries using `patchelf`2False�
�
&fix_relative_interpreter_with_patchelf�Whether to fix the interpreter of executables using `patchelf`

Only has an effect if `fix_rpath_with_patchelf` is set to `True`.
Mutually exclusive with `fix_absolute_interpreter_with_patchelf`.2False�
�
&fix_absolute_interpreter_with_patchelf�Whether to absolutize the interpreter while fixing executables/libraries using `patchelf`

Only has an effect if `fix_rpath_with_patchelf` is set to `True`.
Mutually exclusive with `fix_relative_interpreter_with_patchelf`.

Note that this will destroy remote-executability and cache-reuse across different systems
if the path to the source/build directory is not exactly the same.2False�
�
patchelf_dirs�Paths to inspect for executable/library files to fix with `patchelf`

Note that this will not recursively inspect subdirectories.
"{arch}" will be replaced by the value as returned by `uname -m`).2?["lib/{arch}-linux-gnu", "usr/lib/{arch}-linux-gnu", "usr/bin"]�
�
extra_patchelf_dirs�Additional paths to inspect for executable/library files to fix with `patchelf`

Note that this will not recursively inspect subdirectories.
"{arch}" will be replaced by the value as returned by `uname -m`).2[]�
�
	add_files�Experimental: add files to the install dir.

The keys are paths into the install dir. The label may
only refer to a single file.
"{arch}" in keys will be replaced by the value as returned by `uname -m`).2{}�
�
post_install_cmd�Experimental: run a command after the install.

The keys are the unused, the values the command to run as given to `rctx.execute()`.2{}u
s

build_fileAExperimental: BUILD.bazel template for the generated install dir.2 "//apt:install.BUILD.bazel.tmpl"a
_
glob_patternEExperimental: `glob()` pattern for the default `build_file` template.2["**"]y
w
glob_excludesNExperimental: `glob()` pattern excludes for the default `build_file` template.2["usr/share/man/**"]I
G
sources8Names of source() repositories to download packages from ~
|
architectureseArchitectures for which to create the install (defaults to architectures from `sources` if not given)2[]�6
�!
ubuntu�Download/extract a set of `packages` from the Ubuntu/Debian repositories.

The packages are only extracted, no install hooks will be executed.
In most cases you need to consider how to handle library paths. See the
[Handle Library Paths](../README.md#handle-library-paths) for details.

The `lockfile` attribute is mandatory, but does not need to exist during the
initial setup. If the attribute is set to a non-existing file a mostly empty
repository that only exposes the target to copy the lockfile into the
workspace is created.

Define a Debian/Ubuntu repository to download from.

The `suites`, `architectures`, `components`, `uri` parameters roughly follow
[DEB822](https://manpages.debian.org/unstable/apt/sources.list.5.en.html#DEB822-STYLE_FORMAT).
This allows you copy and adapt from the sources.list.

For example
```
Types: deb
URIs: http://deb.debian.org/debian
Suites: trixie
Components: main
Architectures: amd64 armel
```

would be translated into
```
apt.ubuntu(
    ...
    architectures = ["amd64", "armel"],
    components = ["main"],
    suites = ["trixie"],
    uri = "http://deb.debian.org/debian",
    ...
)
```

It is strogly advised to use archive URLs to ensure stability of the
retrieved package index files to be able to re-generate the same lockfiles.
- Ubuntu: https://snapshot.ubuntu.com/ubuntu/20250115T150000Z
- Debian: https://snapshot.debian.org/archive/debian/20250115T150000Z


Multiple `ubuntu()` tags are allowed but need unique names.1
name%Base name of the generated repository $
packagesPackages to download ]
lockfileMThe lock file to use for the index (it is fine for the file to not exist yet) p
resolve_transitiveRWhether dependencies of dependencies should be resolved and added to the lockfile.2Truef
fix_rpath_with_patchelfBWhether to fix the RPATH of executables/libraries using `patchelf`2False�
&fix_relative_interpreter_with_patchelf�Whether to fix the interpreter of executables using `patchelf`

Only has an effect if `fix_rpath_with_patchelf` is set to `True`.
Mutually exclusive with `fix_absolute_interpreter_with_patchelf`.2False�
&fix_absolute_interpreter_with_patchelf�Whether to absolutize the interpreter while fixing executables/libraries using `patchelf`

Only has an effect if `fix_rpath_with_patchelf` is set to `True`.
Mutually exclusive with `fix_relative_interpreter_with_patchelf`.

Note that this will destroy remote-executability and cache-reuse across different systems
if the path to the source/build directory is not exactly the same.2False�
patchelf_dirs�Paths to inspect for executable/library files to fix with `patchelf`

Note that this will not recursively inspect subdirectories.
"{arch}" will be replaced by the value as returned by `uname -m`).2?["lib/{arch}-linux-gnu", "usr/lib/{arch}-linux-gnu", "usr/bin"]�
extra_patchelf_dirs�Additional paths to inspect for executable/library files to fix with `patchelf`

Note that this will not recursively inspect subdirectories.
"{arch}" will be replaced by the value as returned by `uname -m`).2[]�
	add_files�Experimental: add files to the install dir.

The keys are paths into the install dir. The label may
only refer to a single file.
"{arch}" in keys will be replaced by the value as returned by `uname -m`).2{}�
post_install_cmd�Experimental: run a command after the install.

The keys are the unused, the values the command to run as given to `rctx.execute()`.2{}s

build_fileAExperimental: BUILD.bazel template for the generated install dir.2 "//apt:install.BUILD.bazel.tmpl"_
glob_patternEExperimental: `glob()` pattern for the default `build_file` template.2["**"]w
glob_excludesNExperimental: `glob()` pattern excludes for the default `build_file` template.2["usr/share/man/**"]C
suites5Deb suites to download the packages from (see DEB822) `
architecturesBArchitectures for which to download the package lists (see DEB822)2	["amd64"]S

components9Deb components to download the packages from (see DEB822)2["main"]�
uriaDeb mirror to download the packages from (see URIs in DEB822 but only allows what basel supports)25"https://snapshot.ubuntu.com/ubuntu/20250219T154000Z"3
1
name%Base name of the generated repository &
$
packagesPackages to download _
]
lockfileMThe lock file to use for the index (it is fine for the file to not exist yet) r
p
resolve_transitiveRWhether dependencies of dependencies should be resolved and added to the lockfile.2Trueh
f
fix_rpath_with_patchelfBWhether to fix the RPATH of executables/libraries using `patchelf`2False�
�
&fix_relative_interpreter_with_patchelf�Whether to fix the interpreter of executables using `patchelf`

Only has an effect if `fix_rpath_with_patchelf` is set to `True`.
Mutually exclusive with `fix_absolute_interpreter_with_patchelf`.2False�
�
&fix_absolute_interpreter_with_patchelf�Whether to absolutize the interpreter while fixing executables/libraries using `patchelf`

Only has an effect if `fix_rpath_with_patchelf` is set to `True`.
Mutually exclusive with `fix_relative_interpreter_with_patchelf`.

Note that this will destroy remote-executability and cache-reuse across different systems
if the path to the source/build directory is not exactly the same.2False�
�
patchelf_dirs�Paths to inspect for executable/library files to fix with `patchelf`

Note that this will not recursively inspect subdirectories.
"{arch}" will be replaced by the value as returned by `uname -m`).2?["lib/{arch}-linux-gnu", "usr/lib/{arch}-linux-gnu", "usr/bin"]�
�
extra_patchelf_dirs�Additional paths to inspect for executable/library files to fix with `patchelf`

Note that this will not recursively inspect subdirectories.
"{arch}" will be replaced by the value as returned by `uname -m`).2[]�
�
	add_files�Experimental: add files to the install dir.

The keys are paths into the install dir. The label may
only refer to a single file.
"{arch}" in keys will be replaced by the value as returned by `uname -m`).2{}�
�
post_install_cmd�Experimental: run a command after the install.

The keys are the unused, the values the command to run as given to `rctx.execute()`.2{}u
s

build_fileAExperimental: BUILD.bazel template for the generated install dir.2 "//apt:install.BUILD.bazel.tmpl"a
_
glob_patternEExperimental: `glob()` pattern for the default `build_file` template.2["**"]y
w
glob_excludesNExperimental: `glob()` pattern excludes for the default `build_file` template.2["usr/share/man/**"]E
C
suites5Deb suites to download the packages from (see DEB822) b
`
architecturesBArchitectures for which to download the package lists (see DEB822)2	["amd64"]U
S

components9Deb components to download the packages from (see DEB822)2["main"]�
�
uriaDeb mirror to download the packages from (see URIs in DEB822 but only allows what basel supports)25"https://snapshot.ubuntu.com/ubuntu/20250219T154000Z"�7
�!
debian�Download/extract a set of `packages` from the Ubuntu/Debian repositories.

The packages are only extracted, no install hooks will be executed.
In most cases you need to consider how to handle library paths. See the
[Handle Library Paths](../README.md#handle-library-paths) for details.

The `lockfile` attribute is mandatory, but does not need to exist during the
initial setup. If the attribute is set to a non-existing file a mostly empty
repository that only exposes the target to copy the lockfile into the
workspace is created.

Define a Debian/Ubuntu repository to download from.

The `suites`, `architectures`, `components`, `uri` parameters roughly follow
[DEB822](https://manpages.debian.org/unstable/apt/sources.list.5.en.html#DEB822-STYLE_FORMAT).
This allows you copy and adapt from the sources.list.

For example
```
Types: deb
URIs: http://deb.debian.org/debian
Suites: trixie
Components: main
Architectures: amd64 armel
```

would be translated into
```
apt.debian(
    ...
    architectures = ["amd64", "armel"],
    components = ["main"],
    suites = ["trixie"],
    uri = "http://deb.debian.org/debian",
    ...
)
```

It is strogly advised to use archive URLs to ensure stability of the
retrieved package index files to be able to re-generate the same lockfiles.
- Ubuntu: https://snapshot.ubuntu.com/ubuntu/20250115T150000Z
- Debian: https://snapshot.debian.org/archive/debian/20250115T150000Z


Multiple `debian()` tags are allowed but need unique names.1
name%Base name of the generated repository $
packagesPackages to download ]
lockfileMThe lock file to use for the index (it is fine for the file to not exist yet) p
resolve_transitiveRWhether dependencies of dependencies should be resolved and added to the lockfile.2Truef
fix_rpath_with_patchelfBWhether to fix the RPATH of executables/libraries using `patchelf`2False�
&fix_relative_interpreter_with_patchelf�Whether to fix the interpreter of executables using `patchelf`

Only has an effect if `fix_rpath_with_patchelf` is set to `True`.
Mutually exclusive with `fix_absolute_interpreter_with_patchelf`.2False�
&fix_absolute_interpreter_with_patchelf�Whether to absolutize the interpreter while fixing executables/libraries using `patchelf`

Only has an effect if `fix_rpath_with_patchelf` is set to `True`.
Mutually exclusive with `fix_relative_interpreter_with_patchelf`.

Note that this will destroy remote-executability and cache-reuse across different systems
if the path to the source/build directory is not exactly the same.2False�
patchelf_dirs�Paths to inspect for executable/library files to fix with `patchelf`

Note that this will not recursively inspect subdirectories.
"{arch}" will be replaced by the value as returned by `uname -m`).2?["lib/{arch}-linux-gnu", "usr/lib/{arch}-linux-gnu", "usr/bin"]�
extra_patchelf_dirs�Additional paths to inspect for executable/library files to fix with `patchelf`

Note that this will not recursively inspect subdirectories.
"{arch}" will be replaced by the value as returned by `uname -m`).2[]�
	add_files�Experimental: add files to the install dir.

The keys are paths into the install dir. The label may
only refer to a single file.
"{arch}" in keys will be replaced by the value as returned by `uname -m`).2{}�
post_install_cmd�Experimental: run a command after the install.

The keys are the unused, the values the command to run as given to `rctx.execute()`.2{}s

build_fileAExperimental: BUILD.bazel template for the generated install dir.2 "//apt:install.BUILD.bazel.tmpl"_
glob_patternEExperimental: `glob()` pattern for the default `build_file` template.2["**"]w
glob_excludesNExperimental: `glob()` pattern excludes for the default `build_file` template.2["usr/share/man/**"]C
suites5Deb suites to download the packages from (see DEB822) `
architecturesBArchitectures for which to download the package lists (see DEB822)2	["amd64"]S

components9Deb components to download the packages from (see DEB822)2["main"]�
uriaDeb mirror to download the packages from (see URIs in DEB822 but only allows what basel supports)2="https://snapshot.debian.org/archive/debian/20250201T023325Z"3
1
name%Base name of the generated repository &
$
packagesPackages to download _
]
lockfileMThe lock file to use for the index (it is fine for the file to not exist yet) r
p
resolve_transitiveRWhether dependencies of dependencies should be resolved and added to the lockfile.2Trueh
f
fix_rpath_with_patchelfBWhether to fix the RPATH of executables/libraries using `patchelf`2False�
�
&fix_relative_interpreter_with_patchelf�Whether to fix the interpreter of executables using `patchelf`

Only has an effect if `fix_rpath_with_patchelf` is set to `True`.
Mutually exclusive with `fix_absolute_interpreter_with_patchelf`.2False�
�
&fix_absolute_interpreter_with_patchelf�Whether to absolutize the interpreter while fixing executables/libraries using `patchelf`

Only has an effect if `fix_rpath_with_patchelf` is set to `True`.
Mutually exclusive with `fix_relative_interpreter_with_patchelf`.

Note that this will destroy remote-executability and cache-reuse across different systems
if the path to the source/build directory is not exactly the same.2False�
�
patchelf_dirs�Paths to inspect for executable/library files to fix with `patchelf`

Note that this will not recursively inspect subdirectories.
"{arch}" will be replaced by the value as returned by `uname -m`).2?["lib/{arch}-linux-gnu", "usr/lib/{arch}-linux-gnu", "usr/bin"]�
�
extra_patchelf_dirs�Additional paths to inspect for executable/library files to fix with `patchelf`

Note that this will not recursively inspect subdirectories.
"{arch}" will be replaced by the value as returned by `uname -m`).2[]�
�
	add_files�Experimental: add files to the install dir.

The keys are paths into the install dir. The label may
only refer to a single file.
"{arch}" in keys will be replaced by the value as returned by `uname -m`).2{}�
�
post_install_cmd�Experimental: run a command after the install.

The keys are the unused, the values the command to run as given to `rctx.execute()`.2{}u
s

build_fileAExperimental: BUILD.bazel template for the generated install dir.2 "//apt:install.BUILD.bazel.tmpl"a
_
glob_patternEExperimental: `glob()` pattern for the default `build_file` template.2["**"]y
w
glob_excludesNExperimental: `glob()` pattern excludes for the default `build_file` template.2["usr/share/man/**"]E
C
suites5Deb suites to download the packages from (see DEB822) b
`
architecturesBArchitectures for which to download the package lists (see DEB822)2	["amd64"]U
S

components9Deb components to download the packages from (see DEB822)2["main"]�
�
uriaDeb mirror to download the packages from (see URIs in DEB822 but only allows what basel supports)2="https://snapshot.debian.org/archive/debian/20250201T023325Z"�# Extension for downloading and extracting Debian/Ubuntu packages.

## Usage
Place the following in your `MODULE.bazel`. Then:
- run `bazel run @busybox//:lock` to create a lockfile and
- run `bazel run @busybox//:bin/busybox` to download/extract the package and run the binary.

```py
apt = use_extension("@bazel_linux_packages//apt:extensions.bzl", "apt")
apt.ubuntu(
    name = "busybox",
    lockfile = "//:focal.lock.json",
    packages = ["busybox"],
    suites = ["focal"],
)
use_repo(apt, "busybox")
``` 