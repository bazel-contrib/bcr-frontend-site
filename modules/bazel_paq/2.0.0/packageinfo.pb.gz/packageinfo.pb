�
@@bazel_paq//o/home/sol/.cache/bazel/_bazel_sol/dee7d2116cbeda440a9fb8e57dc802ae/execroot/_main/work/external/bazel_paq/BUILD 