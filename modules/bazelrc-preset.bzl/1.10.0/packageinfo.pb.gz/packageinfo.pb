`
@@bazelrc-preset.bzl//F/home/sol/.bazel/execroot/_main/work/external/bazelrc-preset.bzl/BUILDo
@@bazelrc-preset.bzl//privateN/home/sol/.bazel/execroot/_main/work/external/bazelrc-preset.bzl/private/BUILD 