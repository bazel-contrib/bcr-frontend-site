�

bison	bison.bzl�bison�Runs GNU Bison on a grammar file to produce parser source and optionally a header.

This rule configures `BISON_PKGDATADIR` and `M4` environment variables
automatically. The interface follows the same pattern as `bazel_skylib`'s
`run_binary`: provide `srcs`, `outs`, and `args` with `$(execpath ...)`
expansions for input and output paths.

The m4 binary and bison data directory can be overridden globally via the
`//:m4` and `//:bison_pkgdatadir` label_flags, or per-target via the `m4`
and `bison_pkgdatadir` attrs.

Example:
    load("@bison//:bison.bzl", "bison")

    bison(
        name = "parser",
        srcs = ["parser.y"],
        outs = ["parser.c", "parser.h"],
        args = ["-o", "$(execpath parser.c)", "-d", "$(execpath parser.y)"],
    )
"�
�
bison�Runs GNU Bison on a grammar file to produce parser source and optionally a header.

This rule configures `BISON_PKGDATADIR` and `M4` environment variables
automatically. The interface follows the same pattern as `bazel_skylib`'s
`run_binary`: provide `srcs`, `outs`, and `args` with `$(execpath ...)`
expansions for input and output paths.

The m4 binary and bison data directory can be overridden globally via the
`//:m4` and `//:bison_pkgdatadir` label_flags, or per-target via the `m4`
and `bison_pkgdatadir` attrs.

Example:
    load("@bison//:bison.bzl", "bison")

    bison(
        name = "parser",
        srcs = ["parser.y"],
        outs = ["parser.c", "parser.h"],
        args = ["-o", "$(execpath parser.c)", "-d", "$(execpath parser.y)"],
    )
*
nameA unique name for this target. \
argsPArguments to pass to bison. Supports $(execpath ...) for input and output paths. -
bisonThe bison binary to use.2//:bison�
bison_pkgdatadir�Bison's data directory (containing m4sugar, skeletons, etc.).  If this
resolves to a single directory, it is used directly.  If it resolves to
files, the path is truncated at the `data` component.  Override globally
with --@bison//:bison_pkgdatadir=<label>.2//:bison_pkgdatadirR
m4CThe m4 binary to use. Override globally with --@bison//:m4=<label>.2//:m4+
outsOutput files produced by bison. 8
srcs,Source files (grammars) to provide to bison. "
bison@@bison//:bison.bzl
DD,
*
nameA unique name for this target. ^
\
argsPArguments to pass to bison. Supports $(execpath ...) for input and output paths. /
-
bisonThe bison binary to use.2//:bison�
�
bison_pkgdatadir�Bison's data directory (containing m4sugar, skeletons, etc.).  If this
resolves to a single directory, it is used directly.  If it resolves to
files, the path is truncated at the `data` component.  Override globally
with --@bison//:bison_pkgdatadir=<label>.2//:bison_pkgdatadirT
R
m4CThe m4 binary to use. Override globally with --@bison//:m4=<label>.2//:m4-
+
outsOutput files produced by bison. :
8
srcs,Source files (grammars) to provide to bison. KRule for running GNU Bison with M4 and PKGDATADIR configured automatically. 