\
@@boost.context//G/home/sol/.bazel/execroot/_main/work/external/boost.context/BUILD.bazel 