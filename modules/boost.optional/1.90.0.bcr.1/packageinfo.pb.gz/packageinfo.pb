^
@@boost.optional//H/home/sol/.bazel/execroot/_main/work/external/boost.optional/BUILD.bazel 