`
@@boost.parameter//I/home/sol/.bazel/execroot/_main/work/external/boost.parameter/BUILD.bazel 