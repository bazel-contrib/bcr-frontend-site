�
3
build_stack_rules_protocmd/gencopygencopy.bzl�gencopy_actionIgencopy_action declares a bazel action that runs the gencopy.bash script.*�
�
gencopy_action
ctxthe context object. (C
config5a struct to be written as json, for the gencopy tool. (:
runfiles*additional runfiles needed for the action. (Igencopy_action declares a bazel action that runs the gencopy.bash script."Q
Oa list containing the config_json File, the script File, and a Runfiles object.2D
gencopy_action2@@build_stack_rules_proto//cmd/gencopy:gencopy.bzl
11�gencopy_config*q
a
gencopy_config	
ctx (2D
gencopy_config2@@build_stack_rules_proto//cmd/gencopy:gencopy.bzl
((a
//lib:shell.bzlrL

bazel_skyliblib	shell.bzl
shellshell
',
.Ngencopy.bzl provides an action for copying generated files into the workspace.�
J
build_stack_rules_proto%example/golden/testdata/starlark_javadefs.bzl�java_wrapper*�
v
java_wrapper
_kwargs(2Y
java_wrapperI@@build_stack_rules_proto//example/golden/testdata/starlark_java:defs.bzl
��
;
build_stack_rules_proto
extensionsproto_repository.bzl��proto_repositoryJ��
�L
proto_repository�K
archive~declare an http_archive repository that is post-processed by a custom version of gazelle that includes the 'protobuf' language
nameThe repo name. �
auth_patterns�An optional dict mapping host names to custom authorization patterns.

If a URL's host name is present in this dict the value will be used as a pattern when
generating the authorization header for the http request. This enables the use of custom
authorization schemes used in a lot of common cloud storage providers.

The pattern currently supports 2 tokens: <code>&lt;login&gt;</code> and
<code>&lt;password&gt;</code>, which are replaced with their equivalent value
in the netrc file for the same host name. After formatting, the result is set
as the value for the <code>Authorization</code> field of the HTTP request.

Example attribute and netrc for a http download to an oauth2 enabled API using a bearer token:

<pre>
auth_patterns = {
    "storage.cloudprovider.com": "Bearer &lt;password&gt;"
}
</pre>

netrc:

<pre>
machine storage.cloudprovider.com
        password RANDOM-TOKEN
</pre>

The final HTTP request would have the following header:

<pre>
Authorization: Bearer RANDOM-TOKEN
</pre>

2{}�
build_config�A file that Gazelle should read to learn about external repositories before
            generating build files. This is useful for dependency resolution. For example,
            a `go_repository` rule in this file establishes a mapping between a
            repository name like `golang.org/x/tools` and a workspace name like
            `org_golang_x_tools`. Workspace directives like
            `# gazelle:repository_macro` are recognized.

            `go_repository` rules will be re-evaluated when parts of WORKSPACE related
            to Gazelle's configuration are changed, including Gazelle directives and
            `go_repository` `name` and `importpath` attributes.
            Their content should still be fetched from a local cache, but build files
            will be regenerated. If this is not desirable, `build_config` may be set
            to a less frequently updated file or `None` to disable this functionality.2/@bazel_gazelle_go_repository_config//:WORKSPACE�
build_directives�A list of directives to be written to the root level build file before
            Calling Gazelle to generate build files. Each string in the list will be
            prefixed with `#` automatically. A common use case is to pass a list of
            Gazelle directives.2[]�
build_external�One of `"external"`, `"static"` or `"vendored"`.

            This sets Gazelle's `-external` command line flag. In `"static"` mode,
            Gazelle will not call out to the network to resolve imports.

            **NOTE:** This cannot be used to ignore the `vendor` directory in a
            repository. The `-external` flag only controls how Gazelle resolves
            imports which are not present in the repository. Use
            `build_extra_args = ["-exclude=vendor"]` instead.2"static"u
build_extra_args[A list of additional command line arguments to pass to Gazelle when generating build files.2[]�
build_file_generation�One of `"auto"`, `"on"`, `"off"`, `"clean"`.

            Whether Gazelle should generate build files in the repository. In `"auto"`
            mode, Gazelle will run if there is no build file in the repository root
            directory. In `"clean"` mode, Gazelle will first remove any existing build
            files.2"auto"�
build_file_name�Comma-separated list of names Gazelle will consider to be build files.
            If a repository contains files named `build` that aren't related to Bazel,
            it may help to set this to `"BUILD.bazel"`, especially on case-insensitive
            file systems.2"BUILD.bazel,BUILD"�
build_file_proto_mode�One of `"default"`, `"legacy"`, `"disable"`, `"disable_global"` or `"package"`.

            This sets Gazelle's `-proto` command line flag. See [Directives] for more
            information on each mode.2""�
build_naming_convention�Sets the library naming convention to use when resolving dependencies against this external
            repository. If unset, the convention from the external workspace is used.
            Legal values are `go_default_library`, `import`, and `import_alias`.

            See the `gazelle:go_naming_convention` directive in [Directives] for more information.2"import_alias"H

build_tags4This sets Gazelle's `-build_tags` command line flag.2[]�
canonical_id�If the repository is downloaded via HTTP (`urls` is set) and this is set, restrict cache hits to those cases where the
            repository was added to the cache with the same canonical id.2"">
cfgs0the list of base proto configurations to include2[]�
commit�If the repository is downloaded using a version control tool, this is the
            commit or revision to check out. With git, this would be a sha1 commit id.
            `commit` and `tag` may not both be set.2""�

debug_mode�Enables logging of fetch_repo and Gazelle output during succcesful runs. Gazelle can be noisy
            so this defaults to `False`. However, setting to `True` can be useful for debugging build failures and
            unexpected behavior for the given rule.
            2Falset
deleted_files]list of paths that should be deleted after download and extract (and before gazelle generate)2[]�

importpath�The Go import path that matches the root directory of this repository.

            In module mode (when `version` is set), this must be the module path. If
            neither `urls` nor `remote` is specified, `go_repository` will
            automatically find the true path of the module, applying import path
            redirection.

            If build files are generated for this repository, libraries will have their
            `importpath` attributes prefixed with this `importpath` string.  2""?
imports.list of csv files that provide resolve records2[]H
imports_out(name of CSV file that should be produced2"imports.csv"C
&internal_only_do_not_use_apparent_nameInternal usage only2""`
	languages&the default set of languages to enable2)["proto", "protobuf", "proto_go_modules"]a

local_pathM If specified, `go_repository` will load the module from this local directory2""R

patch_args9Arguments passed to the patch tool when applying patches.2["-p0"]P

patch_cmds<Commands to run in the repository after patches are applied.2[]�

patch_tool�The patch tool used to apply `patches`. If this is specified, Bazel will
            use the specifed patch tool instead of the Bazel-native patch implementation.2""Q
patches@A list of patches to apply to the repository after gazelle runs.2[]�
remote�The VCS location where the repository should be downloaded from. This is
            usually inferred from `importpath`, but you can set `remote` to download
            from a private repository or a fork.2""�
replace�A replacement for the module named by `importpath`. The module named by
            `replace` will be downloaded at `version` and verified with `sum`.

            NOTE: There is no `go_repository` equivalent to file path `replace`
            directives. Use `local_repository` instead.2""Y
reresolve_known_proto_imports/this should be set to true for @googleapis repo2False�
sha256�If the repository is downloaded via HTTP (`urls` is set), this is the
            SHA-256 sum of the downloaded archive. When set, Bazel will verify the archive
            against this sum before extracting it.

            **CAUTION:** Do not use this with services that prepare source archives on
            demand, such as codeload.github.com. Any minor change in the server software
            can cause differences in file order, alignment, and compression that break
            SHA-256 sums.2""�
strip_prefix�If the repository is downloaded via HTTP (`urls` is set), this is a
            directory prefix to strip. See [`http_archive.strip_prefix`].2""�
sum�A hash of the module contents. In module mode, `go_repository` will verify
            the downloaded module matches this sum. May only be set when `version`
            is also set.

            A value for `sum` may be found in the `go.sum` file or by running
            `go mod download -json <module>@<version>`.2""�
tag�If the repository is downloaded using a version control tool, this is the
            named revision to check out. `commit` and `tag` may not both be set.2""�
type�One of `"zip"`, `"tar.gz"`, `"tgz"`, `"tar.bz2"`, `"tar.xz"`.

            If the repository is downloaded via HTTP (`urls` is set), this is the
            file format of the repository archive. This is normally inferred from the
            downloaded file name.2""�
urls�A list of HTTP(S) URLs where an archive containing the project can be
            downloaded. Bazel will attempt to download from the first URL; the others
            are mirrors.2[]�
vcs�One of `"git"`, `"hg"`, `"svn"`, `"bzr"`.

            The version control system to use. This is usually determined automatically,
            but it may be necessary to set this when `remote` is set and the VCS cannot
            be inferred. You must have the corresponding tool installed on your host.2""�
version�If specified, `go_repository` will download the module at this version
            using `go mod download`. `sum` must also be set. `commit`, `tag`,
            and `urls` may not be set. 2"""N
proto_repository:@@build_stack_rules_proto//extensions:proto_repository.bzl
R$R$��
�D
archive~declare an http_archive repository that is post-processed by a custom version of gazelle that includes the 'protobuf' language
nameThe repo name. �
auth_patterns�An optional dict mapping host names to custom authorization patterns.

If a URL's host name is present in this dict the value will be used as a pattern when
generating the authorization header for the http request. This enables the use of custom
authorization schemes used in a lot of common cloud storage providers.

The pattern currently supports 2 tokens: <code>&lt;login&gt;</code> and
<code>&lt;password&gt;</code>, which are replaced with their equivalent value
in the netrc file for the same host name. After formatting, the result is set
as the value for the <code>Authorization</code> field of the HTTP request.

Example attribute and netrc for a http download to an oauth2 enabled API using a bearer token:

<pre>
auth_patterns = {
    "storage.cloudprovider.com": "Bearer &lt;password&gt;"
}
</pre>

netrc:

<pre>
machine storage.cloudprovider.com
        password RANDOM-TOKEN
</pre>

The final HTTP request would have the following header:

<pre>
Authorization: Bearer RANDOM-TOKEN
</pre>

2{}�
build_config�A file that Gazelle should read to learn about external repositories before
generating build files. This is useful for dependency resolution. For example,
a `go_repository` rule in this file establishes a mapping between a
repository name like `golang.org/x/tools` and a workspace name like
`org_golang_x_tools`. Workspace directives like
`# gazelle:repository_macro` are recognized.

`go_repository` rules will be re-evaluated when parts of WORKSPACE related
to Gazelle's configuration are changed, including Gazelle directives and
`go_repository` `name` and `importpath` attributes.
Their content should still be fetched from a local cache, but build files
will be regenerated. If this is not desirable, `build_config` may be set
to a less frequently updated file or `None` to disable this functionality.2/@bazel_gazelle_go_repository_config//:WORKSPACE�
build_directives�A list of directives to be written to the root level build file before
Calling Gazelle to generate build files. Each string in the list will be
prefixed with `#` automatically. A common use case is to pass a list of
Gazelle directives.2[]�
build_external�One of `"external"`, `"static"` or `"vendored"`.

This sets Gazelle's `-external` command line flag. In `"static"` mode,
Gazelle will not call out to the network to resolve imports.

**NOTE:** This cannot be used to ignore the `vendor` directory in a
repository. The `-external` flag only controls how Gazelle resolves
imports which are not present in the repository. Use
`build_extra_args = ["-exclude=vendor"]` instead.2"static"u
build_extra_args[A list of additional command line arguments to pass to Gazelle when generating build files.2[]�
build_file_generation�One of `"auto"`, `"on"`, `"off"`, `"clean"`.

Whether Gazelle should generate build files in the repository. In `"auto"`
mode, Gazelle will run if there is no build file in the repository root
directory. In `"clean"` mode, Gazelle will first remove any existing build
files.2"auto"�
build_file_name�Comma-separated list of names Gazelle will consider to be build files.
If a repository contains files named `build` that aren't related to Bazel,
it may help to set this to `"BUILD.bazel"`, especially on case-insensitive
file systems.2"BUILD.bazel,BUILD"�
build_file_proto_mode�One of `"default"`, `"legacy"`, `"disable"`, `"disable_global"` or `"package"`.

This sets Gazelle's `-proto` command line flag. See [Directives] for more
information on each mode.2""�
build_naming_convention�Sets the library naming convention to use when resolving dependencies against this external
repository. If unset, the convention from the external workspace is used.
Legal values are `go_default_library`, `import`, and `import_alias`.

See the `gazelle:go_naming_convention` directive in [Directives] for more information.2"import_alias"H

build_tags4This sets Gazelle's `-build_tags` command line flag.2[]�
canonical_id�If the repository is downloaded via HTTP (`urls` is set) and this is set, restrict cache hits to those cases where the
repository was added to the cache with the same canonical id.2"">
cfgs0the list of base proto configurations to include2[]�
commit�If the repository is downloaded using a version control tool, this is the
commit or revision to check out. With git, this would be a sha1 commit id.
`commit` and `tag` may not both be set.2""�

debug_mode�Enables logging of fetch_repo and Gazelle output during succcesful runs. Gazelle can be noisy
so this defaults to `False`. However, setting to `True` can be useful for debugging build failures and
unexpected behavior for the given rule.
2Falset
deleted_files]list of paths that should be deleted after download and extract (and before gazelle generate)2[]�

importpath�The Go import path that matches the root directory of this repository.

In module mode (when `version` is set), this must be the module path. If
neither `urls` nor `remote` is specified, `go_repository` will
automatically find the true path of the module, applying import path
redirection.

If build files are generated for this repository, libraries will have their
`importpath` attributes prefixed with this `importpath` string.  2""?
imports.list of csv files that provide resolve records2[]H
imports_out(name of CSV file that should be produced2"imports.csv"C
&internal_only_do_not_use_apparent_nameInternal usage only2""`
	languages&the default set of languages to enable2)["proto", "protobuf", "proto_go_modules"]`

local_pathLIf specified, `go_repository` will load the module from this local directory2""R

patch_args9Arguments passed to the patch tool when applying patches.2["-p0"]P

patch_cmds<Commands to run in the repository after patches are applied.2[]�

patch_tool�The patch tool used to apply `patches`. If this is specified, Bazel will
use the specifed patch tool instead of the Bazel-native patch implementation.2""Q
patches@A list of patches to apply to the repository after gazelle runs.2[]�
remote�The VCS location where the repository should be downloaded from. This is
usually inferred from `importpath`, but you can set `remote` to download
from a private repository or a fork.2""�
replace�A replacement for the module named by `importpath`. The module named by
`replace` will be downloaded at `version` and verified with `sum`.

NOTE: There is no `go_repository` equivalent to file path `replace`
directives. Use `local_repository` instead.2""Y
reresolve_known_proto_imports/this should be set to true for @googleapis repo2False�
sha256�If the repository is downloaded via HTTP (`urls` is set), this is the
SHA-256 sum of the downloaded archive. When set, Bazel will verify the archive
against this sum before extracting it.

**CAUTION:** Do not use this with services that prepare source archives on
demand, such as codeload.github.com. Any minor change in the server software
can cause differences in file order, alignment, and compression that break
SHA-256 sums.2""�
strip_prefix�If the repository is downloaded via HTTP (`urls` is set), this is a
directory prefix to strip. See [`http_archive.strip_prefix`].2""�
sum�A hash of the module contents. In module mode, `go_repository` will verify
the downloaded module matches this sum. May only be set when `version`
is also set.

A value for `sum` may be found in the `go.sum` file or by running
`go mod download -json <module>@<version>`.2""�
tag�If the repository is downloaded using a version control tool, this is the
named revision to check out. `commit` and `tag` may not both be set.2""�
type�One of `"zip"`, `"tar.gz"`, `"tgz"`, `"tar.bz2"`, `"tar.xz"`.

If the repository is downloaded via HTTP (`urls` is set), this is the
file format of the repository archive. This is normally inferred from the
downloaded file name.2""�
urls�A list of HTTP(S) URLs where an archive containing the project can be
downloaded. Bazel will attempt to download from the first URL; the others
are mirrors.2[]�
vcs�One of `"git"`, `"hg"`, `"svn"`, `"bzr"`.

The version control system to use. This is usually determined automatically,
but it may be necessary to set this when `remote` is set and the VCS cannot
be inferred. You must have the corresponding tool installed on your host.2""�
version�If specified, `go_repository` will download the module at this version
using `go mod download`. `sum` must also be set. `commit`, `tag`,
and `urls` may not be set. 2""

nameThe repo name. �
�
auth_patterns�An optional dict mapping host names to custom authorization patterns.

If a URL's host name is present in this dict the value will be used as a pattern when
generating the authorization header for the http request. This enables the use of custom
authorization schemes used in a lot of common cloud storage providers.

The pattern currently supports 2 tokens: <code>&lt;login&gt;</code> and
<code>&lt;password&gt;</code>, which are replaced with their equivalent value
in the netrc file for the same host name. After formatting, the result is set
as the value for the <code>Authorization</code> field of the HTTP request.

Example attribute and netrc for a http download to an oauth2 enabled API using a bearer token:

<pre>
auth_patterns = {
    "storage.cloudprovider.com": "Bearer &lt;password&gt;"
}
</pre>

netrc:

<pre>
machine storage.cloudprovider.com
        password RANDOM-TOKEN
</pre>

The final HTTP request would have the following header:

<pre>
Authorization: Bearer RANDOM-TOKEN
</pre>

2{}�
�
build_config�A file that Gazelle should read to learn about external repositories before
generating build files. This is useful for dependency resolution. For example,
a `go_repository` rule in this file establishes a mapping between a
repository name like `golang.org/x/tools` and a workspace name like
`org_golang_x_tools`. Workspace directives like
`# gazelle:repository_macro` are recognized.

`go_repository` rules will be re-evaluated when parts of WORKSPACE related
to Gazelle's configuration are changed, including Gazelle directives and
`go_repository` `name` and `importpath` attributes.
Their content should still be fetched from a local cache, but build files
will be regenerated. If this is not desirable, `build_config` may be set
to a less frequently updated file or `None` to disable this functionality.2/@bazel_gazelle_go_repository_config//:WORKSPACE�
�
build_directives�A list of directives to be written to the root level build file before
Calling Gazelle to generate build files. Each string in the list will be
prefixed with `#` automatically. A common use case is to pass a list of
Gazelle directives.2[]�
�
build_external�One of `"external"`, `"static"` or `"vendored"`.

This sets Gazelle's `-external` command line flag. In `"static"` mode,
Gazelle will not call out to the network to resolve imports.

**NOTE:** This cannot be used to ignore the `vendor` directory in a
repository. The `-external` flag only controls how Gazelle resolves
imports which are not present in the repository. Use
`build_extra_args = ["-exclude=vendor"]` instead.2"static"w
u
build_extra_args[A list of additional command line arguments to pass to Gazelle when generating build files.2[]�
�
build_file_generation�One of `"auto"`, `"on"`, `"off"`, `"clean"`.

Whether Gazelle should generate build files in the repository. In `"auto"`
mode, Gazelle will run if there is no build file in the repository root
directory. In `"clean"` mode, Gazelle will first remove any existing build
files.2"auto"�
�
build_file_name�Comma-separated list of names Gazelle will consider to be build files.
If a repository contains files named `build` that aren't related to Bazel,
it may help to set this to `"BUILD.bazel"`, especially on case-insensitive
file systems.2"BUILD.bazel,BUILD"�
�
build_file_proto_mode�One of `"default"`, `"legacy"`, `"disable"`, `"disable_global"` or `"package"`.

This sets Gazelle's `-proto` command line flag. See [Directives] for more
information on each mode.2""�
�
build_naming_convention�Sets the library naming convention to use when resolving dependencies against this external
repository. If unset, the convention from the external workspace is used.
Legal values are `go_default_library`, `import`, and `import_alias`.

See the `gazelle:go_naming_convention` directive in [Directives] for more information.2"import_alias"J
H

build_tags4This sets Gazelle's `-build_tags` command line flag.2[]�
�
canonical_id�If the repository is downloaded via HTTP (`urls` is set) and this is set, restrict cache hits to those cases where the
repository was added to the cache with the same canonical id.2""@
>
cfgs0the list of base proto configurations to include2[]�
�
commit�If the repository is downloaded using a version control tool, this is the
commit or revision to check out. With git, this would be a sha1 commit id.
`commit` and `tag` may not both be set.2""�
�

debug_mode�Enables logging of fetch_repo and Gazelle output during succcesful runs. Gazelle can be noisy
so this defaults to `False`. However, setting to `True` can be useful for debugging build failures and
unexpected behavior for the given rule.
2Falsev
t
deleted_files]list of paths that should be deleted after download and extract (and before gazelle generate)2[]�
�

importpath�The Go import path that matches the root directory of this repository.

In module mode (when `version` is set), this must be the module path. If
neither `urls` nor `remote` is specified, `go_repository` will
automatically find the true path of the module, applying import path
redirection.

If build files are generated for this repository, libraries will have their
`importpath` attributes prefixed with this `importpath` string.  2""A
?
imports.list of csv files that provide resolve records2[]J
H
imports_out(name of CSV file that should be produced2"imports.csv"E
C
&internal_only_do_not_use_apparent_nameInternal usage only2""b
`
	languages&the default set of languages to enable2)["proto", "protobuf", "proto_go_modules"]b
`

local_pathLIf specified, `go_repository` will load the module from this local directory2""T
R

patch_args9Arguments passed to the patch tool when applying patches.2["-p0"]R
P

patch_cmds<Commands to run in the repository after patches are applied.2[]�
�

patch_tool�The patch tool used to apply `patches`. If this is specified, Bazel will
use the specifed patch tool instead of the Bazel-native patch implementation.2""S
Q
patches@A list of patches to apply to the repository after gazelle runs.2[]�
�
remote�The VCS location where the repository should be downloaded from. This is
usually inferred from `importpath`, but you can set `remote` to download
from a private repository or a fork.2""�
�
replace�A replacement for the module named by `importpath`. The module named by
`replace` will be downloaded at `version` and verified with `sum`.

NOTE: There is no `go_repository` equivalent to file path `replace`
directives. Use `local_repository` instead.2""[
Y
reresolve_known_proto_imports/this should be set to true for @googleapis repo2False�
�
sha256�If the repository is downloaded via HTTP (`urls` is set), this is the
SHA-256 sum of the downloaded archive. When set, Bazel will verify the archive
against this sum before extracting it.

**CAUTION:** Do not use this with services that prepare source archives on
demand, such as codeload.github.com. Any minor change in the server software
can cause differences in file order, alignment, and compression that break
SHA-256 sums.2""�
�
strip_prefix�If the repository is downloaded via HTTP (`urls` is set), this is a
directory prefix to strip. See [`http_archive.strip_prefix`].2""�
�
sum�A hash of the module contents. In module mode, `go_repository` will verify
the downloaded module matches this sum. May only be set when `version`
is also set.

A value for `sum` may be found in the `go.sum` file or by running
`go mod download -json <module>@<version>`.2""�
�
tag�If the repository is downloaded using a version control tool, this is the
named revision to check out. `commit` and `tag` may not both be set.2""�
�
type�One of `"zip"`, `"tar.gz"`, `"tgz"`, `"tar.bz2"`, `"tar.xz"`.

If the repository is downloaded via HTTP (`urls` is set), this is the
file format of the repository archive. This is normally inferred from the
downloaded file name.2""�
�
urls�A list of HTTP(S) URLs where an archive containing the project can be
downloaded. Bazel will attempt to download from the first URL; the others
are mirrors.2[]�
�
vcs�One of `"git"`, `"hg"`, `"svn"`, `"bzr"`.

The version control system to use. This is usually determined automatically,
but it may be necessary to set this when `remote` is set and the VCS cannot
be inferred. You must have the corresponding tool installed on your host.2""�
�
version�If specified, `go_repository` will download the module at this version
using `go mod download`. `sum` must also be set. `commit`, `tag`,
and `urls` may not be set. 2""q
:features.bzlr^

bazel_featuresfeatures.bzl.
bazel_featuresbazel_features
)7
9�
"//rules/proto:proto_repository.bzlr�
<
build_stack_rules_protorules/protoproto_repository.bzl>
proto_repository_attrsproto_repository_attrs
E[<
proto_repositoryproto_repository_repo_rule
^x
�9proto_repostitory.bzl provides the proto_repository rule.�
=
build_stack_rules_protoplugin/gogo/protobufvariants.bzlf	GOGO_VARIANTSjS2Q
combo
gogo

gogofast

gogofaster
	gogoslick
	gogotypes

gostringvariants.bzl
��
8
build_stack_rules_protorules/ccgrpc_cc_library.bzl��grpc_cc_library�5
<p>Use <code>cc_library()</code> for C++-compiled libraries.
  The result is  either a <code>.so</code>, <code>.lo</code>,
  or <code>.a</code>, depending on what is needed.
</p>

<p>
  If you build something with static linking that depends on
  a <code>cc_library</code>, the output of a depended-on library rule
  is the <code>.a</code> file. If you specify
   <code>alwayslink=True</code>, you get the <code>.lo</code> file.
</p>

<p>
  The actual output file name is <code>lib<i>foo</i>.so</code> for
  the shared library, where <i>foo</i> is the name of the rule.  The
  other kinds of libraries end with <code>.lo</code> and <code>.a</code>,
  respectively.  If you need a specific shared library name, for
  example, to define a Python module, use a genrule to copy the library
  to the desired name.
</p>

<h4 id="hdrs">Header inclusion checking</h4>

<p>
  All header files that are used in the build must be declared in
  the <code>hdrs</code> or <code>srcs</code> of <code>cc_*</code> rules.
  This is enforced.
</p>

<p>
  For <code>cc_library</code> rules, headers in <code>hdrs</code> comprise the
  public interface of the library and can be directly included both
  from the files in <code>hdrs</code> and <code>srcs</code> of the library
  itself as well as from files in <code>hdrs</code> and <code>srcs</code>
  of <code>cc_*</code> rules that list the library in their <code>deps</code>.
  Headers in <code>srcs</code> must only be directly included from the files
  in <code>hdrs</code> and <code>srcs</code> of the library itself. When
  deciding whether to put a header into <code>hdrs</code> or <code>srcs</code>,
  you should ask whether you want consumers of this library to be able to
  directly include it. This is roughly the same decision as
  between <code>public</code> and <code>private</code> visibility in programming languages.
</p>

<p>
  <code>cc_binary</code> and <code>cc_test</code> rules do not have an exported
  interface, so they also do not have a <code>hdrs</code> attribute. All headers
  that belong to the binary or test directly should be listed in
  the <code>srcs</code>.
</p>

<p>
  To illustrate these rules, look at the following example.
</p>

<pre><code class="lang-starlark">
cc_binary(
    name = "foo",
    srcs = [
        "foo.cc",
        "foo.h",
    ],
    deps = [":bar"],
)

cc_library(
    name = "bar",
    srcs = [
        "bar.cc",
        "bar-impl.h",
    ],
    hdrs = ["bar.h"],
    deps = [":baz"],
)

cc_library(
    name = "baz",
    srcs = [
        "baz.cc",
        "baz-impl.h",
    ],
    hdrs = ["baz.h"],
)
</code></pre>

<p>
  The allowed direct inclusions in this example are listed in the table below.
  For example <code>foo.cc</code> is allowed to directly
  include <code>foo.h</code> and <code>bar.h</code>, but not <code>baz.h</code>.
</p>

<table class="table table-striped table-bordered table-condensed">
  <thead>
    <tr><th>Including file</th><th>Allowed inclusions</th></tr>
  </thead>
  <tbody>
    <tr><td>foo.h</td><td>bar.h</td></tr>
    <tr><td>foo.cc</td><td>foo.h bar.h</td></tr>
    <tr><td>bar.h</td><td>bar-impl.h baz.h</td></tr>
    <tr><td>bar-impl.h</td><td>bar.h baz.h</td></tr>
    <tr><td>bar.cc</td><td>bar.h bar-impl.h baz.h</td></tr>
    <tr><td>baz.h</td><td>baz-impl.h</td></tr>
    <tr><td>baz-impl.h</td><td>baz.h</td></tr>
    <tr><td>baz.cc</td><td>baz.h baz-impl.h</td></tr>
  </tbody>
</table>

<p>
  The inclusion checking rules only apply to <em>direct</em>
  inclusions. In the example above <code>foo.cc</code> is allowed to
  include <code>bar.h</code>, which may include <code>baz.h</code>, which in
  turn is allowed to include <code>baz-impl.h</code>. Technically, the
  compilation of a <code>.cc</code> file may transitively include any header
  file in the <code>hdrs</code> or <code>srcs</code> in
  any <code>cc_library</code> in the transitive <code>deps</code> closure. In
  this case the compiler may read <code>baz.h</code> and <code>baz-impl.h</code>
  when compiling <code>foo.cc</code>, but <code>foo.cc</code> must not
  contain <code>#include "baz.h"</code>. For that to be
  allowed, <code>baz</code> must be added to the <code>deps</code>
  of <code>foo</code>.
</p>

<p>
  Bazel depends on toolchain support to enforce the inclusion checking rules.
  The <code>layering_check</code> feature has to be supported by the toolchain
  and requested explicitly, for example via the
  <code>--features=layering_check</code> command-line flag or the
  <code>features</code> parameter of the
  <a href="${link package}"><code>package</code></a> function. The toolchains
  provided by Bazel only support this feature with clang on Unix and macOS.
</p>

<h4 id="cc_library_examples">Examples</h4>

<p id="alwayslink_lib_example">
   We use the <code>alwayslink</code> flag to force the linker to link in
   this code although the main binary code doesn't reference it.
</p>

<pre><code class="lang-starlark">
cc_library(
    name = "ast_inspector_lib",
    srcs = ["ast_inspector_lib.cc"],
    hdrs = ["ast_inspector_lib.h"],
    visibility = ["//visibility:public"],
    deps = ["//third_party/llvm/llvm/tools/clang:frontend"],
    # alwayslink as we want to be able to call things in this library at
    # debug time, even if they aren't used anywhere in the code.
    alwayslink = True,
)
</code></pre>


<p>The following example comes from
   <code>third_party/python2_4_3/BUILD</code>.
   Some of the code uses the <code>dl</code> library (to load
   another, dynamic library), so this
   rule specifies the <code>-ldl</code> link option to link the
   <code>dl</code> library.
</p>

<pre><code class="lang-starlark">
cc_library(
    name = "python2_4_3",
    linkopts = [
        "-ldl",
        "-lutil",
    ],
    deps = ["//third_party/expat"],
)
</code></pre>

<p>The following example comes from <code>third_party/kde/BUILD</code>.
   We keep pre-built <code>.so</code> files in the depot.
   The header files live in a subdirectory named <code>include</code>.
</p>

<pre><code class="lang-starlark">
cc_library(
    name = "kde",
    srcs = [
        "lib/libDCOP.so",
        "lib/libkdesu.so",
        "lib/libkhtml.so",
        "lib/libkparts.so",
        <var>...more .so files...</var>,
    ],
    includes = ["include"],
    deps = ["//third_party/X11"],
)
</code></pre>

<p>The following example comes from <code>third_party/gles/BUILD</code>.
   Third-party code often needs some <code>defines</code> and
   <code>linkopts</code>.
</p>

<pre><code class="lang-starlark">
cc_library(
    name = "gles",
    srcs = [
        "GLES/egl.h",
        "GLES/gl.h",
        "ddx.c",
        "egl.c",
    ],
    defines = [
        "USE_FLOAT",
        "__GL_FLOAT",
        "__GL_COMMON",
    ],
    linkopts = ["-ldl"],  # uses dlopen(), dl library
    deps = [
        "es",
        "//third_party/X11",
    ],
)
</code></pre>
"��
�
grpc_cc_library�5
<p>Use <code>cc_library()</code> for C++-compiled libraries.
  The result is  either a <code>.so</code>, <code>.lo</code>,
  or <code>.a</code>, depending on what is needed.
</p>

<p>
  If you build something with static linking that depends on
  a <code>cc_library</code>, the output of a depended-on library rule
  is the <code>.a</code> file. If you specify
   <code>alwayslink=True</code>, you get the <code>.lo</code> file.
</p>

<p>
  The actual output file name is <code>lib<i>foo</i>.so</code> for
  the shared library, where <i>foo</i> is the name of the rule.  The
  other kinds of libraries end with <code>.lo</code> and <code>.a</code>,
  respectively.  If you need a specific shared library name, for
  example, to define a Python module, use a genrule to copy the library
  to the desired name.
</p>

<h4 id="hdrs">Header inclusion checking</h4>

<p>
  All header files that are used in the build must be declared in
  the <code>hdrs</code> or <code>srcs</code> of <code>cc_*</code> rules.
  This is enforced.
</p>

<p>
  For <code>cc_library</code> rules, headers in <code>hdrs</code> comprise the
  public interface of the library and can be directly included both
  from the files in <code>hdrs</code> and <code>srcs</code> of the library
  itself as well as from files in <code>hdrs</code> and <code>srcs</code>
  of <code>cc_*</code> rules that list the library in their <code>deps</code>.
  Headers in <code>srcs</code> must only be directly included from the files
  in <code>hdrs</code> and <code>srcs</code> of the library itself. When
  deciding whether to put a header into <code>hdrs</code> or <code>srcs</code>,
  you should ask whether you want consumers of this library to be able to
  directly include it. This is roughly the same decision as
  between <code>public</code> and <code>private</code> visibility in programming languages.
</p>

<p>
  <code>cc_binary</code> and <code>cc_test</code> rules do not have an exported
  interface, so they also do not have a <code>hdrs</code> attribute. All headers
  that belong to the binary or test directly should be listed in
  the <code>srcs</code>.
</p>

<p>
  To illustrate these rules, look at the following example.
</p>

<pre><code class="lang-starlark">
cc_binary(
    name = "foo",
    srcs = [
        "foo.cc",
        "foo.h",
    ],
    deps = [":bar"],
)

cc_library(
    name = "bar",
    srcs = [
        "bar.cc",
        "bar-impl.h",
    ],
    hdrs = ["bar.h"],
    deps = [":baz"],
)

cc_library(
    name = "baz",
    srcs = [
        "baz.cc",
        "baz-impl.h",
    ],
    hdrs = ["baz.h"],
)
</code></pre>

<p>
  The allowed direct inclusions in this example are listed in the table below.
  For example <code>foo.cc</code> is allowed to directly
  include <code>foo.h</code> and <code>bar.h</code>, but not <code>baz.h</code>.
</p>

<table class="table table-striped table-bordered table-condensed">
  <thead>
    <tr><th>Including file</th><th>Allowed inclusions</th></tr>
  </thead>
  <tbody>
    <tr><td>foo.h</td><td>bar.h</td></tr>
    <tr><td>foo.cc</td><td>foo.h bar.h</td></tr>
    <tr><td>bar.h</td><td>bar-impl.h baz.h</td></tr>
    <tr><td>bar-impl.h</td><td>bar.h baz.h</td></tr>
    <tr><td>bar.cc</td><td>bar.h bar-impl.h baz.h</td></tr>
    <tr><td>baz.h</td><td>baz-impl.h</td></tr>
    <tr><td>baz-impl.h</td><td>baz.h</td></tr>
    <tr><td>baz.cc</td><td>baz.h baz-impl.h</td></tr>
  </tbody>
</table>

<p>
  The inclusion checking rules only apply to <em>direct</em>
  inclusions. In the example above <code>foo.cc</code> is allowed to
  include <code>bar.h</code>, which may include <code>baz.h</code>, which in
  turn is allowed to include <code>baz-impl.h</code>. Technically, the
  compilation of a <code>.cc</code> file may transitively include any header
  file in the <code>hdrs</code> or <code>srcs</code> in
  any <code>cc_library</code> in the transitive <code>deps</code> closure. In
  this case the compiler may read <code>baz.h</code> and <code>baz-impl.h</code>
  when compiling <code>foo.cc</code>, but <code>foo.cc</code> must not
  contain <code>#include "baz.h"</code>. For that to be
  allowed, <code>baz</code> must be added to the <code>deps</code>
  of <code>foo</code>.
</p>

<p>
  Bazel depends on toolchain support to enforce the inclusion checking rules.
  The <code>layering_check</code> feature has to be supported by the toolchain
  and requested explicitly, for example via the
  <code>--features=layering_check</code> command-line flag or the
  <code>features</code> parameter of the
  <a href="${link package}"><code>package</code></a> function. The toolchains
  provided by Bazel only support this feature with clang on Unix and macOS.
</p>

<h4 id="cc_library_examples">Examples</h4>

<p id="alwayslink_lib_example">
   We use the <code>alwayslink</code> flag to force the linker to link in
   this code although the main binary code doesn't reference it.
</p>

<pre><code class="lang-starlark">
cc_library(
    name = "ast_inspector_lib",
    srcs = ["ast_inspector_lib.cc"],
    hdrs = ["ast_inspector_lib.h"],
    visibility = ["//visibility:public"],
    deps = ["//third_party/llvm/llvm/tools/clang:frontend"],
    # alwayslink as we want to be able to call things in this library at
    # debug time, even if they aren't used anywhere in the code.
    alwayslink = True,
)
</code></pre>


<p>The following example comes from
   <code>third_party/python2_4_3/BUILD</code>.
   Some of the code uses the <code>dl</code> library (to load
   another, dynamic library), so this
   rule specifies the <code>-ldl</code> link option to link the
   <code>dl</code> library.
</p>

<pre><code class="lang-starlark">
cc_library(
    name = "python2_4_3",
    linkopts = [
        "-ldl",
        "-lutil",
    ],
    deps = ["//third_party/expat"],
)
</code></pre>

<p>The following example comes from <code>third_party/kde/BUILD</code>.
   We keep pre-built <code>.so</code> files in the depot.
   The header files live in a subdirectory named <code>include</code>.
</p>

<pre><code class="lang-starlark">
cc_library(
    name = "kde",
    srcs = [
        "lib/libDCOP.so",
        "lib/libkdesu.so",
        "lib/libkhtml.so",
        "lib/libkparts.so",
        <var>...more .so files...</var>,
    ],
    includes = ["include"],
    deps = ["//third_party/X11"],
)
</code></pre>

<p>The following example comes from <code>third_party/gles/BUILD</code>.
   Third-party code often needs some <code>defines</code> and
   <code>linkopts</code>.
</p>

<pre><code class="lang-starlark">
cc_library(
    name = "gles",
    srcs = [
        "GLES/egl.h",
        "GLES/gl.h",
        "ddx.c",
        "egl.c",
    ],
    defines = [
        "USE_FLOAT",
        "__GL_FLOAT",
        "__GL_COMMON",
    ],
    linkopts = ["-ldl"],  # uses dlopen(), dl library
    deps = [
        "es",
        "//third_party/X11",
    ],
)
</code></pre>
*
nameA unique name for this target. �
additional_compiler_inputs�
Any additional files you might want to pass to the compiler command line, such as sanitizer
ignorelists, for example. Files specified here can then be used in copts with the
$(location) function.
2[]�
additional_linker_inputs�
Dependencies that are only made available to the C++ linker command.
<p>
  Unlike <code>deps</code>, which is conceptually made for both compilation and
  linking dependencies, <code>additional_linker_inputs</code> is specifically
  made for only the latter, and signals a dependency that is required only for
  linking (for example, files that are referenced in <code>linkopts</code>).
</p>
<p>
  For example, compiled Windows .res files can be provided here to be embedded in
  the binary target.
</p>
2[]�

alwayslink�
If 1, any binary that depends (directly or indirectly) on this C++
library will link in all the object files for the files listed in
<code>srcs</code>, even if some contain no symbols referenced by the binary.
This is useful if your code isn't explicitly called by code in
the binary, e.g., if your code registers to receive some callback
provided by some service.

<p>If alwayslink doesn't work with VS 2017 on Windows, that is due to a
<a href="https://github.com/bazelbuild/bazel/issues/3949">known issue</a>,
please upgrade your VS 2017 to the latest version.</p>
2False�
	conlyopts�
Add these options to the C compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
2[]�
copts�
Add these options to the C/C++ compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
<p>
  Each string in this attribute is added in the given order to <code>COPTS</code> before
  compiling the binary target. The flags take effect only for compiling this target, not
  its dependencies, so be careful about header files included elsewhere.
  All paths should be relative to the workspace, not to the current package.
  This attribute should not be needed outside of <code>third_party</code>.
</p>
<p>
  If the package declares the <a href="${link package.features}">feature</a>
  <code>no_copts_tokenization</code>, Bourne shell tokenization applies only to strings
  that consist of a single "Make" variable.
</p>
2[]�
cxxopts�
Add these options to the C++ compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
2[]�
data�
The list of files needed by this library at runtime.

See general comments about <code>data</code>
at <a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>If a <code>data</code> is the name of a generated file, then this
   <code>cc_library</code> rule automatically depends on the generating
   rule.
</p>
<p>If a <code>data</code> is a rule name, then this
   <code>cc_library</code> rule automatically depends on that rule,
   and that rule's <code>outs</code> are automatically added to
   this <code>cc_library</code>'s data files.
</p>
<p>Your C++ code can access these data files like so:</p>
<pre><code class="lang-starlark">
  const std::string path = devtools_build::GetDataDependencyFilepath(
      "my/test/data/file");
</code></pre>
2[]�
defines�
List of defines to add to the compile line of this and all dependent targets.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
Each string, which must consist of a single Bourne shell token,
is prepended with <code>-D</code> and added to the compile command line to this target,
as well as to every rule that depends on it. Be very careful, since this may have
far-reaching effects -- the defines are added to every target that depends on
this target.  When in doubt, add define values to
<a href="#cc_binary.local_defines"><code>local_defines</code></a> instead.
2[]�
deps�
The list of other libraries that the library target depends upon.

<p>These can be <code>cc_library</code> or <code>objc_library</code> targets.</p>

<p>See general comments about <code>deps</code>
  at <a href="${link common-definitions#typical-attributes}">Typical attributes defined by
  most build rules</a>.
</p>
<p>These should be names of C++ library rules.
   When you build a binary that links this rule's library,
   you will also link the libraries in <code>deps</code>.
</p>
<p>Despite the "deps" name, not all of this library's clients
   belong here.  Run-time data dependencies belong in <code>data</code>.
   Source files generated by other rules belong in <code>srcs</code>.
</p>
<p>To link in a pre-compiled third-party library, add its name to
   the <code>srcs</code> instead.
</p>
<p>To depend on something without linking it to this library, add its
   name to the <code>data</code> instead.
</p>
*
CcInfo2[]�
hdrs�
The list of header files published by
this library to be directly included by sources in dependent rules.
<p>This is the strongly preferred location for declaring header files that
 describe the interface for the library. These headers will be made
 available for inclusion by sources in this rule or in dependent rules.
 Headers not meant to be included by a client of this library should be
 listed in the <code>srcs</code> attribute instead, even if they are
 included by a published header. See <a href="#hdrs">"Header inclusion
 checking"</a> for a more detailed description. </p>
<p>Permitted <code>headers</code> file types:
  <code>.h</code>,
  <code>.hh</code>,
  <code>.hpp</code>,
  <code>.hxx</code>.
</p>
2[]&

hdrs_checkDeprecated, no-op.2""�
implementation_deps�
The list of other libraries that the library target depends on. Unlike with
<code>deps</code>, the headers and include paths of these libraries (and all their
transitive deps) are only used for compilation of this library, and not libraries that
depend on it. Libraries specified with <code>implementation_deps</code> are still linked in
binary targets that depend on this library.
*
CcInfo2[]�
include_prefix�
The prefix to add to the paths of the headers of this rule.

<p>When set, the headers in the <code>hdrs</code> attribute of this rule are accessible
at is the value of this attribute prepended to their repository-relative path.

<p>The prefix in the <code>strip_include_prefix</code> attribute is removed before this
prefix is added.

<p>This attribute is only legal under <code>third_party</code>.
2""�
includes�
List of include dirs to be added to the compile line.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution.
Each string is prepended with the package path and passed to the C++ toolchain for
expansion via the "include_paths" CROSSTOOL feature. A toolchain running on a POSIX system
with typical feature definitions will produce
<code>-isystem path_to_package/include_entry</code>.
This should only be used for third-party libraries that
do not conform to the Google style of writing #include statements.
Unlike <a href="#cc_binary.copts">COPTS</a>, these flags are added for this rule
and every rule that depends on it. (Note: not the rules it depends upon!) Be
very careful, since this may have far-reaching effects.  When in doubt, add
"-I" flags to <a href="#cc_binary.copts">COPTS</a> instead.
<p>
The added <code>include</code> paths will include generated files as well as
files in the source tree.
</p>
2[]
licenses2[]�
linkopts�
See <a href="${link cc_binary.linkopts}"><code>cc_binary.linkopts</code></a>.
The <code>linkopts</code> attribute is also applied to any target that
depends, directly or indirectly, on this library via <code>deps</code>
attributes (or via other attributes that are treated similarly:
the <a href="${link cc_binary.malloc}"><code>malloc</code></a>
attribute of <a href="${link cc_binary}"><code>cc_binary</code></a>). Dependency
linkopts take precedence over dependent linkopts (i.e. dependency linkopts
appear later in the command line). Linkopts specified in
<a href='../user-manual.html#flag--linkopt'><code>--linkopt</code></a>
take precedence over rule linkopts.
</p>
<p>
Note that the <code>linkopts</code> attribute only applies
when creating <code>.so</code> files or executables, not
when creating <code>.a</code> or <code>.lo</code> files.
So if the <code>linkstatic=True</code> attribute is set, the
<code>linkopts</code> attribute has no effect on the creation of
this library, only on other targets which depend on this library.
</p>
<p>
Also, it is important to note that "-Wl,-soname" or "-Xlinker -soname"
options are not supported and should never be specified in this attribute.
</p>
<p> The <code>.so</code> files produced by <code>cc_library</code>
rules are not linked against the libraries that they depend
on.  If you're trying to create a shared library for use
outside of the main repository, e.g. for manual use
with <code>dlopen()</code> or <code>LD_PRELOAD</code>,
it may be better to use a <code>cc_binary</code> rule
with the <code>linkshared=True</code> attribute.
See <a href="${link cc_binary.linkshared}"><code>cc_binary.linkshared</code></a>.
</p>
2[]�
	linkstamp�
Simultaneously compiles and links the specified C++ source file into the final
binary. This trickery is required to introduce timestamp
information into binaries; if we compiled the source file to an
object file in the usual way, the timestamp would be incorrect.
A linkstamp compilation may not include any particular set of
compiler flags and so should not depend on any particular
header, compiler option, or other build variable.
<em class='harmful'>This option should only be needed in the
<code>base</code> package.</em>
2None�

linkstatic�
For <a href="${link cc_binary}"><code>cc_binary</code></a> and
<a href="${link cc_test}"><code>cc_test</code></a>: link the binary in static
mode. For <code>cc_library.link_static</code>: see below.
<p>By default this option is on for <code>cc_binary</code> and off for the rest.</p>
<p>
  If enabled and this is a binary or test, this option tells the build tool to link in
  <code>.a</code>'s instead of <code>.so</code>'s for user libraries whenever possible.
  System libraries such as libc (but <i>not</i> the C/C++ runtime libraries,
  see below) are still linked dynamically, as are libraries for which
  there is no static library. So the resulting executable will still be dynamically
  linked, hence only <i>mostly</i> static.
</p>
<p>
There are really three different ways to link an executable:
</p>
<ul>
<li> STATIC with fully_static_link feature, in which everything is linked statically;
  e.g. "<code>gcc -static foo.o libbar.a libbaz.a -lm</code>".<br/>
  This mode is enabled by specifying <code>fully_static_link</code> in the
  <a href="${link common-definitions#features}"><code>features</code></a> attribute.</li>
<li> STATIC, in which all user libraries are linked statically (if a static
  version is available), but where system libraries (excluding C/C++ runtime libraries)
  are linked dynamically, e.g. "<code>gcc foo.o libfoo.a libbaz.a -lm</code>".<br/>
  This mode is enabled by specifying <code>linkstatic=True</code>.</li>
<li> DYNAMIC, in which all libraries are linked dynamically (if a dynamic version is
  available), e.g. "<code>gcc foo.o libfoo.so libbaz.so -lm</code>".<br/>
  This mode is enabled by specifying <code>linkstatic=False</code>.</li>
</ul>
<p>
If the <code>linkstatic</code> attribute or <code>fully_static_link</code> in
<code>features</code> is used outside of <code>//third_party</code>
please include a comment near the rule to explain why.
</p>
<p>
The <code>linkstatic</code> attribute has a different meaning if used on a
<a href="${link cc_library}"><code>cc_library()</code></a> rule.
For a C++ library, <code>linkstatic=True</code> indicates that only
static linking is allowed, so no <code>.so</code> will be produced. linkstatic=False does
not prevent static libraries from being created. The attribute is meant to control the
creation of dynamic libraries.
</p>
<p>
There should be very little code built with <code>linkstatic=False</code> in production.
If <code>linkstatic=False</code>, then the build tool will create symlinks to
depended-upon shared libraries in the <code>*.runfiles</code> area.
</p>
2False�
local_defines�
List of defines to add to the compile line.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
Each string, which must consist of a single Bourne shell token,
is prepended with <code>-D</code> and added to the compile command line for this target,
but not to its dependents. Unlike <code>defines</code>, the defines are only added to the
compile command line for this target.
2[]�
module_interfaces�
The list of files are regarded as C++20 Modules Interface.

<p>
C++ Standard has no restriction about module interface file extension
<ul>
<li>Clang use cppm </li>
<li>GCC can use any source file extension </li>
<li>MSVC use ixx </li>
</ul>
</p>
<p>The use is guarded by the flag
<code>--experimental_cpp_modules</code>.</p>
2[]�
srcs�
The list of C and C++ files that are processed to create the library target.
These are C/C++ source and header files, either non-generated (normal source
code) or generated.
<p>All <code>.cc</code>, <code>.c</code>, and <code>.cpp</code> files will
   be compiled. These might be generated files: if a named file is in
   the <code>outs</code> of some other rule, this <code>cc_library</code>
   will automatically depend on that other rule.
</p>
<p>Pure assembler files (.s, .asm) are not preprocessed and are typically built using
the assembler. Preprocessed assembly files (.S) are preprocessed and are typically built
using the C/C++ compiler.
</p>
<p>A <code>.h</code> file will not be compiled, but will be available for
   inclusion by sources in this rule. Both <code>.cc</code> and
   <code>.h</code> files can directly include headers listed in
   these <code>srcs</code> or in the <code>hdrs</code> of this rule or any
   rule listed in the <code>deps</code> argument.
</p>
<p>All <code>#include</code>d files must be mentioned in the
   <code>hdrs</code> attribute of this or referenced <code>cc_library</code>
   rules, or they should be listed in <code>srcs</code> if they are private
   to this library. See <a href="#hdrs">"Header inclusion checking"</a> for
   a more detailed description.
</p>
<p><code>.so</code>, <code>.lo</code>, and <code>.a</code> files are
   pre-compiled files. Your library might have these as
   <code>srcs</code> if it uses third-party code for which we don't
   have source code.
</p>
<p>If the <code>srcs</code> attribute includes the label of another rule,
   <code>cc_library</code> will use the output files of that rule as source files to
   compile. This is useful for one-off generation of source code (for more than occasional
   use, it's better to implement a Starlark rule class and use the <code>cc_common</code>
   API)
</p>
<p>
  Permitted <code>srcs</code> file types:
</p>
<ul>
<li>C and C++ source files: <code>.c</code>, <code>.cc</code>, <code>.cpp</code>,
  <code>.cxx</code>, <code>.c++</code>, <code>.C</code></li>
<li>C and C++ header files: <code>.h</code>, <code>.hh</code>, <code>.hpp</code>,
  <code>.hxx</code>, <code>.inc</code>, <code>.inl</code>, <code>.H</code></li>
<li>Assembler with C preprocessor: <code>.S</code></li>
<li>Archive: <code>.a</code>, <code>.pic.a</code></li>
<li>"Always link" library: <code>.lo</code>, <code>.pic.lo</code></li>
<li>Shared library, versioned or unversioned: <code>.so</code>,
  <code>.so.<i>version</i></code></li>
<li>Object file: <code>.o</code>, <code>.pic.o</code></li>
</ul>

<p>
  ... and any rules that produce those files (e.g. <code>cc_embed_data</code>).
  Different extensions denote different programming languages in
  accordance with gcc convention.
</p>
2[]�
strip_include_prefix�
The prefix to strip from the paths of the headers of this rule.

<p>When set, the headers in the <code>hdrs</code> attribute of this rule are accessible
at their path with this prefix cut off.

<p>If it's a relative path, it's taken as a package-relative one. If it's an absolute one,
it's understood as a repository-relative path.

<p>The prefix in the <code>include_prefix</code> attribute is added after this prefix is
stripped.

<p>This attribute is only legal under <code>third_party</code>.
2""�
textual_hdrs�
The list of header files published by
this library to be textually included by sources in dependent rules.
<p>This is the location for declaring header files that cannot be compiled on their own;
 that is, they always need to be textually included by other source files to build valid
 code.</p>
2[]�
win_def_file�
The Windows DEF file to be passed to linker.
<p>This attribute should only be used when Windows is the target platform.
It can be used to <a href="https://msdn.microsoft.com/en-us/library/d91k01sh.aspx">
export symbols</a> during linking a shared library.</p>
2None
,
*
nameA unique name for this target. �
�
additional_compiler_inputs�
Any additional files you might want to pass to the compiler command line, such as sanitizer
ignorelists, for example. Files specified here can then be used in copts with the
$(location) function.
2[]�
�
additional_linker_inputs�
Dependencies that are only made available to the C++ linker command.
<p>
  Unlike <code>deps</code>, which is conceptually made for both compilation and
  linking dependencies, <code>additional_linker_inputs</code> is specifically
  made for only the latter, and signals a dependency that is required only for
  linking (for example, files that are referenced in <code>linkopts</code>).
</p>
<p>
  For example, compiled Windows .res files can be provided here to be embedded in
  the binary target.
</p>
2[]�
�

alwayslink�
If 1, any binary that depends (directly or indirectly) on this C++
library will link in all the object files for the files listed in
<code>srcs</code>, even if some contain no symbols referenced by the binary.
This is useful if your code isn't explicitly called by code in
the binary, e.g., if your code registers to receive some callback
provided by some service.

<p>If alwayslink doesn't work with VS 2017 on Windows, that is due to a
<a href="https://github.com/bazelbuild/bazel/issues/3949">known issue</a>,
please upgrade your VS 2017 to the latest version.</p>
2False�
�
	conlyopts�
Add these options to the C compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
2[]�
�
copts�
Add these options to the C/C++ compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
<p>
  Each string in this attribute is added in the given order to <code>COPTS</code> before
  compiling the binary target. The flags take effect only for compiling this target, not
  its dependencies, so be careful about header files included elsewhere.
  All paths should be relative to the workspace, not to the current package.
  This attribute should not be needed outside of <code>third_party</code>.
</p>
<p>
  If the package declares the <a href="${link package.features}">feature</a>
  <code>no_copts_tokenization</code>, Bourne shell tokenization applies only to strings
  that consist of a single "Make" variable.
</p>
2[]�
�
cxxopts�
Add these options to the C++ compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
2[]�
�
data�
The list of files needed by this library at runtime.

See general comments about <code>data</code>
at <a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>If a <code>data</code> is the name of a generated file, then this
   <code>cc_library</code> rule automatically depends on the generating
   rule.
</p>
<p>If a <code>data</code> is a rule name, then this
   <code>cc_library</code> rule automatically depends on that rule,
   and that rule's <code>outs</code> are automatically added to
   this <code>cc_library</code>'s data files.
</p>
<p>Your C++ code can access these data files like so:</p>
<pre><code class="lang-starlark">
  const std::string path = devtools_build::GetDataDependencyFilepath(
      "my/test/data/file");
</code></pre>
2[]�
�
defines�
List of defines to add to the compile line of this and all dependent targets.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
Each string, which must consist of a single Bourne shell token,
is prepended with <code>-D</code> and added to the compile command line to this target,
as well as to every rule that depends on it. Be very careful, since this may have
far-reaching effects -- the defines are added to every target that depends on
this target.  When in doubt, add define values to
<a href="#cc_binary.local_defines"><code>local_defines</code></a> instead.
2[]�
�
deps�
The list of other libraries that the library target depends upon.

<p>These can be <code>cc_library</code> or <code>objc_library</code> targets.</p>

<p>See general comments about <code>deps</code>
  at <a href="${link common-definitions#typical-attributes}">Typical attributes defined by
  most build rules</a>.
</p>
<p>These should be names of C++ library rules.
   When you build a binary that links this rule's library,
   you will also link the libraries in <code>deps</code>.
</p>
<p>Despite the "deps" name, not all of this library's clients
   belong here.  Run-time data dependencies belong in <code>data</code>.
   Source files generated by other rules belong in <code>srcs</code>.
</p>
<p>To link in a pre-compiled third-party library, add its name to
   the <code>srcs</code> instead.
</p>
<p>To depend on something without linking it to this library, add its
   name to the <code>data</code> instead.
</p>
*
CcInfo2[]�
�
hdrs�
The list of header files published by
this library to be directly included by sources in dependent rules.
<p>This is the strongly preferred location for declaring header files that
 describe the interface for the library. These headers will be made
 available for inclusion by sources in this rule or in dependent rules.
 Headers not meant to be included by a client of this library should be
 listed in the <code>srcs</code> attribute instead, even if they are
 included by a published header. See <a href="#hdrs">"Header inclusion
 checking"</a> for a more detailed description. </p>
<p>Permitted <code>headers</code> file types:
  <code>.h</code>,
  <code>.hh</code>,
  <code>.hpp</code>,
  <code>.hxx</code>.
</p>
2[](
&

hdrs_checkDeprecated, no-op.2""�
�
implementation_deps�
The list of other libraries that the library target depends on. Unlike with
<code>deps</code>, the headers and include paths of these libraries (and all their
transitive deps) are only used for compilation of this library, and not libraries that
depend on it. Libraries specified with <code>implementation_deps</code> are still linked in
binary targets that depend on this library.
*
CcInfo2[]�
�
include_prefix�
The prefix to add to the paths of the headers of this rule.

<p>When set, the headers in the <code>hdrs</code> attribute of this rule are accessible
at is the value of this attribute prepended to their repository-relative path.

<p>The prefix in the <code>strip_include_prefix</code> attribute is removed before this
prefix is added.

<p>This attribute is only legal under <code>third_party</code>.
2""�
�
includes�
List of include dirs to be added to the compile line.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution.
Each string is prepended with the package path and passed to the C++ toolchain for
expansion via the "include_paths" CROSSTOOL feature. A toolchain running on a POSIX system
with typical feature definitions will produce
<code>-isystem path_to_package/include_entry</code>.
This should only be used for third-party libraries that
do not conform to the Google style of writing #include statements.
Unlike <a href="#cc_binary.copts">COPTS</a>, these flags are added for this rule
and every rule that depends on it. (Note: not the rules it depends upon!) Be
very careful, since this may have far-reaching effects.  When in doubt, add
"-I" flags to <a href="#cc_binary.copts">COPTS</a> instead.
<p>
The added <code>include</code> paths will include generated files as well as
files in the source tree.
</p>
2[]

licenses2[]�
�
linkopts�
See <a href="${link cc_binary.linkopts}"><code>cc_binary.linkopts</code></a>.
The <code>linkopts</code> attribute is also applied to any target that
depends, directly or indirectly, on this library via <code>deps</code>
attributes (or via other attributes that are treated similarly:
the <a href="${link cc_binary.malloc}"><code>malloc</code></a>
attribute of <a href="${link cc_binary}"><code>cc_binary</code></a>). Dependency
linkopts take precedence over dependent linkopts (i.e. dependency linkopts
appear later in the command line). Linkopts specified in
<a href='../user-manual.html#flag--linkopt'><code>--linkopt</code></a>
take precedence over rule linkopts.
</p>
<p>
Note that the <code>linkopts</code> attribute only applies
when creating <code>.so</code> files or executables, not
when creating <code>.a</code> or <code>.lo</code> files.
So if the <code>linkstatic=True</code> attribute is set, the
<code>linkopts</code> attribute has no effect on the creation of
this library, only on other targets which depend on this library.
</p>
<p>
Also, it is important to note that "-Wl,-soname" or "-Xlinker -soname"
options are not supported and should never be specified in this attribute.
</p>
<p> The <code>.so</code> files produced by <code>cc_library</code>
rules are not linked against the libraries that they depend
on.  If you're trying to create a shared library for use
outside of the main repository, e.g. for manual use
with <code>dlopen()</code> or <code>LD_PRELOAD</code>,
it may be better to use a <code>cc_binary</code> rule
with the <code>linkshared=True</code> attribute.
See <a href="${link cc_binary.linkshared}"><code>cc_binary.linkshared</code></a>.
</p>
2[]�
�
	linkstamp�
Simultaneously compiles and links the specified C++ source file into the final
binary. This trickery is required to introduce timestamp
information into binaries; if we compiled the source file to an
object file in the usual way, the timestamp would be incorrect.
A linkstamp compilation may not include any particular set of
compiler flags and so should not depend on any particular
header, compiler option, or other build variable.
<em class='harmful'>This option should only be needed in the
<code>base</code> package.</em>
2None�
�

linkstatic�
For <a href="${link cc_binary}"><code>cc_binary</code></a> and
<a href="${link cc_test}"><code>cc_test</code></a>: link the binary in static
mode. For <code>cc_library.link_static</code>: see below.
<p>By default this option is on for <code>cc_binary</code> and off for the rest.</p>
<p>
  If enabled and this is a binary or test, this option tells the build tool to link in
  <code>.a</code>'s instead of <code>.so</code>'s for user libraries whenever possible.
  System libraries such as libc (but <i>not</i> the C/C++ runtime libraries,
  see below) are still linked dynamically, as are libraries for which
  there is no static library. So the resulting executable will still be dynamically
  linked, hence only <i>mostly</i> static.
</p>
<p>
There are really three different ways to link an executable:
</p>
<ul>
<li> STATIC with fully_static_link feature, in which everything is linked statically;
  e.g. "<code>gcc -static foo.o libbar.a libbaz.a -lm</code>".<br/>
  This mode is enabled by specifying <code>fully_static_link</code> in the
  <a href="${link common-definitions#features}"><code>features</code></a> attribute.</li>
<li> STATIC, in which all user libraries are linked statically (if a static
  version is available), but where system libraries (excluding C/C++ runtime libraries)
  are linked dynamically, e.g. "<code>gcc foo.o libfoo.a libbaz.a -lm</code>".<br/>
  This mode is enabled by specifying <code>linkstatic=True</code>.</li>
<li> DYNAMIC, in which all libraries are linked dynamically (if a dynamic version is
  available), e.g. "<code>gcc foo.o libfoo.so libbaz.so -lm</code>".<br/>
  This mode is enabled by specifying <code>linkstatic=False</code>.</li>
</ul>
<p>
If the <code>linkstatic</code> attribute or <code>fully_static_link</code> in
<code>features</code> is used outside of <code>//third_party</code>
please include a comment near the rule to explain why.
</p>
<p>
The <code>linkstatic</code> attribute has a different meaning if used on a
<a href="${link cc_library}"><code>cc_library()</code></a> rule.
For a C++ library, <code>linkstatic=True</code> indicates that only
static linking is allowed, so no <code>.so</code> will be produced. linkstatic=False does
not prevent static libraries from being created. The attribute is meant to control the
creation of dynamic libraries.
</p>
<p>
There should be very little code built with <code>linkstatic=False</code> in production.
If <code>linkstatic=False</code>, then the build tool will create symlinks to
depended-upon shared libraries in the <code>*.runfiles</code> area.
</p>
2False�
�
local_defines�
List of defines to add to the compile line.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
Each string, which must consist of a single Bourne shell token,
is prepended with <code>-D</code> and added to the compile command line for this target,
but not to its dependents. Unlike <code>defines</code>, the defines are only added to the
compile command line for this target.
2[]�
�
module_interfaces�
The list of files are regarded as C++20 Modules Interface.

<p>
C++ Standard has no restriction about module interface file extension
<ul>
<li>Clang use cppm </li>
<li>GCC can use any source file extension </li>
<li>MSVC use ixx </li>
</ul>
</p>
<p>The use is guarded by the flag
<code>--experimental_cpp_modules</code>.</p>
2[]�
�
srcs�
The list of C and C++ files that are processed to create the library target.
These are C/C++ source and header files, either non-generated (normal source
code) or generated.
<p>All <code>.cc</code>, <code>.c</code>, and <code>.cpp</code> files will
   be compiled. These might be generated files: if a named file is in
   the <code>outs</code> of some other rule, this <code>cc_library</code>
   will automatically depend on that other rule.
</p>
<p>Pure assembler files (.s, .asm) are not preprocessed and are typically built using
the assembler. Preprocessed assembly files (.S) are preprocessed and are typically built
using the C/C++ compiler.
</p>
<p>A <code>.h</code> file will not be compiled, but will be available for
   inclusion by sources in this rule. Both <code>.cc</code> and
   <code>.h</code> files can directly include headers listed in
   these <code>srcs</code> or in the <code>hdrs</code> of this rule or any
   rule listed in the <code>deps</code> argument.
</p>
<p>All <code>#include</code>d files must be mentioned in the
   <code>hdrs</code> attribute of this or referenced <code>cc_library</code>
   rules, or they should be listed in <code>srcs</code> if they are private
   to this library. See <a href="#hdrs">"Header inclusion checking"</a> for
   a more detailed description.
</p>
<p><code>.so</code>, <code>.lo</code>, and <code>.a</code> files are
   pre-compiled files. Your library might have these as
   <code>srcs</code> if it uses third-party code for which we don't
   have source code.
</p>
<p>If the <code>srcs</code> attribute includes the label of another rule,
   <code>cc_library</code> will use the output files of that rule as source files to
   compile. This is useful for one-off generation of source code (for more than occasional
   use, it's better to implement a Starlark rule class and use the <code>cc_common</code>
   API)
</p>
<p>
  Permitted <code>srcs</code> file types:
</p>
<ul>
<li>C and C++ source files: <code>.c</code>, <code>.cc</code>, <code>.cpp</code>,
  <code>.cxx</code>, <code>.c++</code>, <code>.C</code></li>
<li>C and C++ header files: <code>.h</code>, <code>.hh</code>, <code>.hpp</code>,
  <code>.hxx</code>, <code>.inc</code>, <code>.inl</code>, <code>.H</code></li>
<li>Assembler with C preprocessor: <code>.S</code></li>
<li>Archive: <code>.a</code>, <code>.pic.a</code></li>
<li>"Always link" library: <code>.lo</code>, <code>.pic.lo</code></li>
<li>Shared library, versioned or unversioned: <code>.so</code>,
  <code>.so.<i>version</i></code></li>
<li>Object file: <code>.o</code>, <code>.pic.o</code></li>
</ul>

<p>
  ... and any rules that produce those files (e.g. <code>cc_embed_data</code>).
  Different extensions denote different programming languages in
  accordance with gcc convention.
</p>
2[]�
�
strip_include_prefix�
The prefix to strip from the paths of the headers of this rule.

<p>When set, the headers in the <code>hdrs</code> attribute of this rule are accessible
at their path with this prefix cut off.

<p>If it's a relative path, it's taken as a package-relative one. If it's an absolute one,
it's understood as a repository-relative path.

<p>The prefix in the <code>include_prefix</code> attribute is added after this prefix is
stripped.

<p>This attribute is only legal under <code>third_party</code>.
2""�
�
textual_hdrs�
The list of header files published by
this library to be textually included by sources in dependent rules.
<p>This is the location for declaring header files that cannot be compiled on their own;
 that is, they always need to be textually included by other source files to build valid
 code.</p>
2[]�
�
win_def_file�
The Windows DEF file to be passed to linker.
<p>This attribute should only be used when Windows is the target platform.
It can be used to <a href="https://msdn.microsoft.com/en-us/library/d91k01sh.aspx">
export symbols</a> during linking a shared library.</p>
2Nonec
//cc:defs.bzlrP

rules_ccccdefs.bzl&

cc_library
cc_library
!+
-@grpc_cc_library.bzl provides a cc_library for gRPC source files.��
9
build_stack_rules_protorules/ccproto_cc_library.bzl��proto_cc_library�5
<p>Use <code>cc_library()</code> for C++-compiled libraries.
  The result is  either a <code>.so</code>, <code>.lo</code>,
  or <code>.a</code>, depending on what is needed.
</p>

<p>
  If you build something with static linking that depends on
  a <code>cc_library</code>, the output of a depended-on library rule
  is the <code>.a</code> file. If you specify
   <code>alwayslink=True</code>, you get the <code>.lo</code> file.
</p>

<p>
  The actual output file name is <code>lib<i>foo</i>.so</code> for
  the shared library, where <i>foo</i> is the name of the rule.  The
  other kinds of libraries end with <code>.lo</code> and <code>.a</code>,
  respectively.  If you need a specific shared library name, for
  example, to define a Python module, use a genrule to copy the library
  to the desired name.
</p>

<h4 id="hdrs">Header inclusion checking</h4>

<p>
  All header files that are used in the build must be declared in
  the <code>hdrs</code> or <code>srcs</code> of <code>cc_*</code> rules.
  This is enforced.
</p>

<p>
  For <code>cc_library</code> rules, headers in <code>hdrs</code> comprise the
  public interface of the library and can be directly included both
  from the files in <code>hdrs</code> and <code>srcs</code> of the library
  itself as well as from files in <code>hdrs</code> and <code>srcs</code>
  of <code>cc_*</code> rules that list the library in their <code>deps</code>.
  Headers in <code>srcs</code> must only be directly included from the files
  in <code>hdrs</code> and <code>srcs</code> of the library itself. When
  deciding whether to put a header into <code>hdrs</code> or <code>srcs</code>,
  you should ask whether you want consumers of this library to be able to
  directly include it. This is roughly the same decision as
  between <code>public</code> and <code>private</code> visibility in programming languages.
</p>

<p>
  <code>cc_binary</code> and <code>cc_test</code> rules do not have an exported
  interface, so they also do not have a <code>hdrs</code> attribute. All headers
  that belong to the binary or test directly should be listed in
  the <code>srcs</code>.
</p>

<p>
  To illustrate these rules, look at the following example.
</p>

<pre><code class="lang-starlark">
cc_binary(
    name = "foo",
    srcs = [
        "foo.cc",
        "foo.h",
    ],
    deps = [":bar"],
)

cc_library(
    name = "bar",
    srcs = [
        "bar.cc",
        "bar-impl.h",
    ],
    hdrs = ["bar.h"],
    deps = [":baz"],
)

cc_library(
    name = "baz",
    srcs = [
        "baz.cc",
        "baz-impl.h",
    ],
    hdrs = ["baz.h"],
)
</code></pre>

<p>
  The allowed direct inclusions in this example are listed in the table below.
  For example <code>foo.cc</code> is allowed to directly
  include <code>foo.h</code> and <code>bar.h</code>, but not <code>baz.h</code>.
</p>

<table class="table table-striped table-bordered table-condensed">
  <thead>
    <tr><th>Including file</th><th>Allowed inclusions</th></tr>
  </thead>
  <tbody>
    <tr><td>foo.h</td><td>bar.h</td></tr>
    <tr><td>foo.cc</td><td>foo.h bar.h</td></tr>
    <tr><td>bar.h</td><td>bar-impl.h baz.h</td></tr>
    <tr><td>bar-impl.h</td><td>bar.h baz.h</td></tr>
    <tr><td>bar.cc</td><td>bar.h bar-impl.h baz.h</td></tr>
    <tr><td>baz.h</td><td>baz-impl.h</td></tr>
    <tr><td>baz-impl.h</td><td>baz.h</td></tr>
    <tr><td>baz.cc</td><td>baz.h baz-impl.h</td></tr>
  </tbody>
</table>

<p>
  The inclusion checking rules only apply to <em>direct</em>
  inclusions. In the example above <code>foo.cc</code> is allowed to
  include <code>bar.h</code>, which may include <code>baz.h</code>, which in
  turn is allowed to include <code>baz-impl.h</code>. Technically, the
  compilation of a <code>.cc</code> file may transitively include any header
  file in the <code>hdrs</code> or <code>srcs</code> in
  any <code>cc_library</code> in the transitive <code>deps</code> closure. In
  this case the compiler may read <code>baz.h</code> and <code>baz-impl.h</code>
  when compiling <code>foo.cc</code>, but <code>foo.cc</code> must not
  contain <code>#include "baz.h"</code>. For that to be
  allowed, <code>baz</code> must be added to the <code>deps</code>
  of <code>foo</code>.
</p>

<p>
  Bazel depends on toolchain support to enforce the inclusion checking rules.
  The <code>layering_check</code> feature has to be supported by the toolchain
  and requested explicitly, for example via the
  <code>--features=layering_check</code> command-line flag or the
  <code>features</code> parameter of the
  <a href="${link package}"><code>package</code></a> function. The toolchains
  provided by Bazel only support this feature with clang on Unix and macOS.
</p>

<h4 id="cc_library_examples">Examples</h4>

<p id="alwayslink_lib_example">
   We use the <code>alwayslink</code> flag to force the linker to link in
   this code although the main binary code doesn't reference it.
</p>

<pre><code class="lang-starlark">
cc_library(
    name = "ast_inspector_lib",
    srcs = ["ast_inspector_lib.cc"],
    hdrs = ["ast_inspector_lib.h"],
    visibility = ["//visibility:public"],
    deps = ["//third_party/llvm/llvm/tools/clang:frontend"],
    # alwayslink as we want to be able to call things in this library at
    # debug time, even if they aren't used anywhere in the code.
    alwayslink = True,
)
</code></pre>


<p>The following example comes from
   <code>third_party/python2_4_3/BUILD</code>.
   Some of the code uses the <code>dl</code> library (to load
   another, dynamic library), so this
   rule specifies the <code>-ldl</code> link option to link the
   <code>dl</code> library.
</p>

<pre><code class="lang-starlark">
cc_library(
    name = "python2_4_3",
    linkopts = [
        "-ldl",
        "-lutil",
    ],
    deps = ["//third_party/expat"],
)
</code></pre>

<p>The following example comes from <code>third_party/kde/BUILD</code>.
   We keep pre-built <code>.so</code> files in the depot.
   The header files live in a subdirectory named <code>include</code>.
</p>

<pre><code class="lang-starlark">
cc_library(
    name = "kde",
    srcs = [
        "lib/libDCOP.so",
        "lib/libkdesu.so",
        "lib/libkhtml.so",
        "lib/libkparts.so",
        <var>...more .so files...</var>,
    ],
    includes = ["include"],
    deps = ["//third_party/X11"],
)
</code></pre>

<p>The following example comes from <code>third_party/gles/BUILD</code>.
   Third-party code often needs some <code>defines</code> and
   <code>linkopts</code>.
</p>

<pre><code class="lang-starlark">
cc_library(
    name = "gles",
    srcs = [
        "GLES/egl.h",
        "GLES/gl.h",
        "ddx.c",
        "egl.c",
    ],
    defines = [
        "USE_FLOAT",
        "__GL_FLOAT",
        "__GL_COMMON",
    ],
    linkopts = ["-ldl"],  # uses dlopen(), dl library
    deps = [
        "es",
        "//third_party/X11",
    ],
)
</code></pre>
"��
�
proto_cc_library�5
<p>Use <code>cc_library()</code> for C++-compiled libraries.
  The result is  either a <code>.so</code>, <code>.lo</code>,
  or <code>.a</code>, depending on what is needed.
</p>

<p>
  If you build something with static linking that depends on
  a <code>cc_library</code>, the output of a depended-on library rule
  is the <code>.a</code> file. If you specify
   <code>alwayslink=True</code>, you get the <code>.lo</code> file.
</p>

<p>
  The actual output file name is <code>lib<i>foo</i>.so</code> for
  the shared library, where <i>foo</i> is the name of the rule.  The
  other kinds of libraries end with <code>.lo</code> and <code>.a</code>,
  respectively.  If you need a specific shared library name, for
  example, to define a Python module, use a genrule to copy the library
  to the desired name.
</p>

<h4 id="hdrs">Header inclusion checking</h4>

<p>
  All header files that are used in the build must be declared in
  the <code>hdrs</code> or <code>srcs</code> of <code>cc_*</code> rules.
  This is enforced.
</p>

<p>
  For <code>cc_library</code> rules, headers in <code>hdrs</code> comprise the
  public interface of the library and can be directly included both
  from the files in <code>hdrs</code> and <code>srcs</code> of the library
  itself as well as from files in <code>hdrs</code> and <code>srcs</code>
  of <code>cc_*</code> rules that list the library in their <code>deps</code>.
  Headers in <code>srcs</code> must only be directly included from the files
  in <code>hdrs</code> and <code>srcs</code> of the library itself. When
  deciding whether to put a header into <code>hdrs</code> or <code>srcs</code>,
  you should ask whether you want consumers of this library to be able to
  directly include it. This is roughly the same decision as
  between <code>public</code> and <code>private</code> visibility in programming languages.
</p>

<p>
  <code>cc_binary</code> and <code>cc_test</code> rules do not have an exported
  interface, so they also do not have a <code>hdrs</code> attribute. All headers
  that belong to the binary or test directly should be listed in
  the <code>srcs</code>.
</p>

<p>
  To illustrate these rules, look at the following example.
</p>

<pre><code class="lang-starlark">
cc_binary(
    name = "foo",
    srcs = [
        "foo.cc",
        "foo.h",
    ],
    deps = [":bar"],
)

cc_library(
    name = "bar",
    srcs = [
        "bar.cc",
        "bar-impl.h",
    ],
    hdrs = ["bar.h"],
    deps = [":baz"],
)

cc_library(
    name = "baz",
    srcs = [
        "baz.cc",
        "baz-impl.h",
    ],
    hdrs = ["baz.h"],
)
</code></pre>

<p>
  The allowed direct inclusions in this example are listed in the table below.
  For example <code>foo.cc</code> is allowed to directly
  include <code>foo.h</code> and <code>bar.h</code>, but not <code>baz.h</code>.
</p>

<table class="table table-striped table-bordered table-condensed">
  <thead>
    <tr><th>Including file</th><th>Allowed inclusions</th></tr>
  </thead>
  <tbody>
    <tr><td>foo.h</td><td>bar.h</td></tr>
    <tr><td>foo.cc</td><td>foo.h bar.h</td></tr>
    <tr><td>bar.h</td><td>bar-impl.h baz.h</td></tr>
    <tr><td>bar-impl.h</td><td>bar.h baz.h</td></tr>
    <tr><td>bar.cc</td><td>bar.h bar-impl.h baz.h</td></tr>
    <tr><td>baz.h</td><td>baz-impl.h</td></tr>
    <tr><td>baz-impl.h</td><td>baz.h</td></tr>
    <tr><td>baz.cc</td><td>baz.h baz-impl.h</td></tr>
  </tbody>
</table>

<p>
  The inclusion checking rules only apply to <em>direct</em>
  inclusions. In the example above <code>foo.cc</code> is allowed to
  include <code>bar.h</code>, which may include <code>baz.h</code>, which in
  turn is allowed to include <code>baz-impl.h</code>. Technically, the
  compilation of a <code>.cc</code> file may transitively include any header
  file in the <code>hdrs</code> or <code>srcs</code> in
  any <code>cc_library</code> in the transitive <code>deps</code> closure. In
  this case the compiler may read <code>baz.h</code> and <code>baz-impl.h</code>
  when compiling <code>foo.cc</code>, but <code>foo.cc</code> must not
  contain <code>#include "baz.h"</code>. For that to be
  allowed, <code>baz</code> must be added to the <code>deps</code>
  of <code>foo</code>.
</p>

<p>
  Bazel depends on toolchain support to enforce the inclusion checking rules.
  The <code>layering_check</code> feature has to be supported by the toolchain
  and requested explicitly, for example via the
  <code>--features=layering_check</code> command-line flag or the
  <code>features</code> parameter of the
  <a href="${link package}"><code>package</code></a> function. The toolchains
  provided by Bazel only support this feature with clang on Unix and macOS.
</p>

<h4 id="cc_library_examples">Examples</h4>

<p id="alwayslink_lib_example">
   We use the <code>alwayslink</code> flag to force the linker to link in
   this code although the main binary code doesn't reference it.
</p>

<pre><code class="lang-starlark">
cc_library(
    name = "ast_inspector_lib",
    srcs = ["ast_inspector_lib.cc"],
    hdrs = ["ast_inspector_lib.h"],
    visibility = ["//visibility:public"],
    deps = ["//third_party/llvm/llvm/tools/clang:frontend"],
    # alwayslink as we want to be able to call things in this library at
    # debug time, even if they aren't used anywhere in the code.
    alwayslink = True,
)
</code></pre>


<p>The following example comes from
   <code>third_party/python2_4_3/BUILD</code>.
   Some of the code uses the <code>dl</code> library (to load
   another, dynamic library), so this
   rule specifies the <code>-ldl</code> link option to link the
   <code>dl</code> library.
</p>

<pre><code class="lang-starlark">
cc_library(
    name = "python2_4_3",
    linkopts = [
        "-ldl",
        "-lutil",
    ],
    deps = ["//third_party/expat"],
)
</code></pre>

<p>The following example comes from <code>third_party/kde/BUILD</code>.
   We keep pre-built <code>.so</code> files in the depot.
   The header files live in a subdirectory named <code>include</code>.
</p>

<pre><code class="lang-starlark">
cc_library(
    name = "kde",
    srcs = [
        "lib/libDCOP.so",
        "lib/libkdesu.so",
        "lib/libkhtml.so",
        "lib/libkparts.so",
        <var>...more .so files...</var>,
    ],
    includes = ["include"],
    deps = ["//third_party/X11"],
)
</code></pre>

<p>The following example comes from <code>third_party/gles/BUILD</code>.
   Third-party code often needs some <code>defines</code> and
   <code>linkopts</code>.
</p>

<pre><code class="lang-starlark">
cc_library(
    name = "gles",
    srcs = [
        "GLES/egl.h",
        "GLES/gl.h",
        "ddx.c",
        "egl.c",
    ],
    defines = [
        "USE_FLOAT",
        "__GL_FLOAT",
        "__GL_COMMON",
    ],
    linkopts = ["-ldl"],  # uses dlopen(), dl library
    deps = [
        "es",
        "//third_party/X11",
    ],
)
</code></pre>
*
nameA unique name for this target. �
additional_compiler_inputs�
Any additional files you might want to pass to the compiler command line, such as sanitizer
ignorelists, for example. Files specified here can then be used in copts with the
$(location) function.
2[]�
additional_linker_inputs�
Dependencies that are only made available to the C++ linker command.
<p>
  Unlike <code>deps</code>, which is conceptually made for both compilation and
  linking dependencies, <code>additional_linker_inputs</code> is specifically
  made for only the latter, and signals a dependency that is required only for
  linking (for example, files that are referenced in <code>linkopts</code>).
</p>
<p>
  For example, compiled Windows .res files can be provided here to be embedded in
  the binary target.
</p>
2[]�

alwayslink�
If 1, any binary that depends (directly or indirectly) on this C++
library will link in all the object files for the files listed in
<code>srcs</code>, even if some contain no symbols referenced by the binary.
This is useful if your code isn't explicitly called by code in
the binary, e.g., if your code registers to receive some callback
provided by some service.

<p>If alwayslink doesn't work with VS 2017 on Windows, that is due to a
<a href="https://github.com/bazelbuild/bazel/issues/3949">known issue</a>,
please upgrade your VS 2017 to the latest version.</p>
2False�
	conlyopts�
Add these options to the C compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
2[]�
copts�
Add these options to the C/C++ compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
<p>
  Each string in this attribute is added in the given order to <code>COPTS</code> before
  compiling the binary target. The flags take effect only for compiling this target, not
  its dependencies, so be careful about header files included elsewhere.
  All paths should be relative to the workspace, not to the current package.
  This attribute should not be needed outside of <code>third_party</code>.
</p>
<p>
  If the package declares the <a href="${link package.features}">feature</a>
  <code>no_copts_tokenization</code>, Bourne shell tokenization applies only to strings
  that consist of a single "Make" variable.
</p>
2[]�
cxxopts�
Add these options to the C++ compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
2[]�
data�
The list of files needed by this library at runtime.

See general comments about <code>data</code>
at <a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>If a <code>data</code> is the name of a generated file, then this
   <code>cc_library</code> rule automatically depends on the generating
   rule.
</p>
<p>If a <code>data</code> is a rule name, then this
   <code>cc_library</code> rule automatically depends on that rule,
   and that rule's <code>outs</code> are automatically added to
   this <code>cc_library</code>'s data files.
</p>
<p>Your C++ code can access these data files like so:</p>
<pre><code class="lang-starlark">
  const std::string path = devtools_build::GetDataDependencyFilepath(
      "my/test/data/file");
</code></pre>
2[]�
defines�
List of defines to add to the compile line of this and all dependent targets.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
Each string, which must consist of a single Bourne shell token,
is prepended with <code>-D</code> and added to the compile command line to this target,
as well as to every rule that depends on it. Be very careful, since this may have
far-reaching effects -- the defines are added to every target that depends on
this target.  When in doubt, add define values to
<a href="#cc_binary.local_defines"><code>local_defines</code></a> instead.
2[]�
deps�
The list of other libraries that the library target depends upon.

<p>These can be <code>cc_library</code> or <code>objc_library</code> targets.</p>

<p>See general comments about <code>deps</code>
  at <a href="${link common-definitions#typical-attributes}">Typical attributes defined by
  most build rules</a>.
</p>
<p>These should be names of C++ library rules.
   When you build a binary that links this rule's library,
   you will also link the libraries in <code>deps</code>.
</p>
<p>Despite the "deps" name, not all of this library's clients
   belong here.  Run-time data dependencies belong in <code>data</code>.
   Source files generated by other rules belong in <code>srcs</code>.
</p>
<p>To link in a pre-compiled third-party library, add its name to
   the <code>srcs</code> instead.
</p>
<p>To depend on something without linking it to this library, add its
   name to the <code>data</code> instead.
</p>
*
CcInfo2[]�
hdrs�
The list of header files published by
this library to be directly included by sources in dependent rules.
<p>This is the strongly preferred location for declaring header files that
 describe the interface for the library. These headers will be made
 available for inclusion by sources in this rule or in dependent rules.
 Headers not meant to be included by a client of this library should be
 listed in the <code>srcs</code> attribute instead, even if they are
 included by a published header. See <a href="#hdrs">"Header inclusion
 checking"</a> for a more detailed description. </p>
<p>Permitted <code>headers</code> file types:
  <code>.h</code>,
  <code>.hh</code>,
  <code>.hpp</code>,
  <code>.hxx</code>.
</p>
2[]&

hdrs_checkDeprecated, no-op.2""�
implementation_deps�
The list of other libraries that the library target depends on. Unlike with
<code>deps</code>, the headers and include paths of these libraries (and all their
transitive deps) are only used for compilation of this library, and not libraries that
depend on it. Libraries specified with <code>implementation_deps</code> are still linked in
binary targets that depend on this library.
*
CcInfo2[]�
include_prefix�
The prefix to add to the paths of the headers of this rule.

<p>When set, the headers in the <code>hdrs</code> attribute of this rule are accessible
at is the value of this attribute prepended to their repository-relative path.

<p>The prefix in the <code>strip_include_prefix</code> attribute is removed before this
prefix is added.

<p>This attribute is only legal under <code>third_party</code>.
2""�
includes�
List of include dirs to be added to the compile line.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution.
Each string is prepended with the package path and passed to the C++ toolchain for
expansion via the "include_paths" CROSSTOOL feature. A toolchain running on a POSIX system
with typical feature definitions will produce
<code>-isystem path_to_package/include_entry</code>.
This should only be used for third-party libraries that
do not conform to the Google style of writing #include statements.
Unlike <a href="#cc_binary.copts">COPTS</a>, these flags are added for this rule
and every rule that depends on it. (Note: not the rules it depends upon!) Be
very careful, since this may have far-reaching effects.  When in doubt, add
"-I" flags to <a href="#cc_binary.copts">COPTS</a> instead.
<p>
The added <code>include</code> paths will include generated files as well as
files in the source tree.
</p>
2[]
licenses2[]�
linkopts�
See <a href="${link cc_binary.linkopts}"><code>cc_binary.linkopts</code></a>.
The <code>linkopts</code> attribute is also applied to any target that
depends, directly or indirectly, on this library via <code>deps</code>
attributes (or via other attributes that are treated similarly:
the <a href="${link cc_binary.malloc}"><code>malloc</code></a>
attribute of <a href="${link cc_binary}"><code>cc_binary</code></a>). Dependency
linkopts take precedence over dependent linkopts (i.e. dependency linkopts
appear later in the command line). Linkopts specified in
<a href='../user-manual.html#flag--linkopt'><code>--linkopt</code></a>
take precedence over rule linkopts.
</p>
<p>
Note that the <code>linkopts</code> attribute only applies
when creating <code>.so</code> files or executables, not
when creating <code>.a</code> or <code>.lo</code> files.
So if the <code>linkstatic=True</code> attribute is set, the
<code>linkopts</code> attribute has no effect on the creation of
this library, only on other targets which depend on this library.
</p>
<p>
Also, it is important to note that "-Wl,-soname" or "-Xlinker -soname"
options are not supported and should never be specified in this attribute.
</p>
<p> The <code>.so</code> files produced by <code>cc_library</code>
rules are not linked against the libraries that they depend
on.  If you're trying to create a shared library for use
outside of the main repository, e.g. for manual use
with <code>dlopen()</code> or <code>LD_PRELOAD</code>,
it may be better to use a <code>cc_binary</code> rule
with the <code>linkshared=True</code> attribute.
See <a href="${link cc_binary.linkshared}"><code>cc_binary.linkshared</code></a>.
</p>
2[]�
	linkstamp�
Simultaneously compiles and links the specified C++ source file into the final
binary. This trickery is required to introduce timestamp
information into binaries; if we compiled the source file to an
object file in the usual way, the timestamp would be incorrect.
A linkstamp compilation may not include any particular set of
compiler flags and so should not depend on any particular
header, compiler option, or other build variable.
<em class='harmful'>This option should only be needed in the
<code>base</code> package.</em>
2None�

linkstatic�
For <a href="${link cc_binary}"><code>cc_binary</code></a> and
<a href="${link cc_test}"><code>cc_test</code></a>: link the binary in static
mode. For <code>cc_library.link_static</code>: see below.
<p>By default this option is on for <code>cc_binary</code> and off for the rest.</p>
<p>
  If enabled and this is a binary or test, this option tells the build tool to link in
  <code>.a</code>'s instead of <code>.so</code>'s for user libraries whenever possible.
  System libraries such as libc (but <i>not</i> the C/C++ runtime libraries,
  see below) are still linked dynamically, as are libraries for which
  there is no static library. So the resulting executable will still be dynamically
  linked, hence only <i>mostly</i> static.
</p>
<p>
There are really three different ways to link an executable:
</p>
<ul>
<li> STATIC with fully_static_link feature, in which everything is linked statically;
  e.g. "<code>gcc -static foo.o libbar.a libbaz.a -lm</code>".<br/>
  This mode is enabled by specifying <code>fully_static_link</code> in the
  <a href="${link common-definitions#features}"><code>features</code></a> attribute.</li>
<li> STATIC, in which all user libraries are linked statically (if a static
  version is available), but where system libraries (excluding C/C++ runtime libraries)
  are linked dynamically, e.g. "<code>gcc foo.o libfoo.a libbaz.a -lm</code>".<br/>
  This mode is enabled by specifying <code>linkstatic=True</code>.</li>
<li> DYNAMIC, in which all libraries are linked dynamically (if a dynamic version is
  available), e.g. "<code>gcc foo.o libfoo.so libbaz.so -lm</code>".<br/>
  This mode is enabled by specifying <code>linkstatic=False</code>.</li>
</ul>
<p>
If the <code>linkstatic</code> attribute or <code>fully_static_link</code> in
<code>features</code> is used outside of <code>//third_party</code>
please include a comment near the rule to explain why.
</p>
<p>
The <code>linkstatic</code> attribute has a different meaning if used on a
<a href="${link cc_library}"><code>cc_library()</code></a> rule.
For a C++ library, <code>linkstatic=True</code> indicates that only
static linking is allowed, so no <code>.so</code> will be produced. linkstatic=False does
not prevent static libraries from being created. The attribute is meant to control the
creation of dynamic libraries.
</p>
<p>
There should be very little code built with <code>linkstatic=False</code> in production.
If <code>linkstatic=False</code>, then the build tool will create symlinks to
depended-upon shared libraries in the <code>*.runfiles</code> area.
</p>
2False�
local_defines�
List of defines to add to the compile line.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
Each string, which must consist of a single Bourne shell token,
is prepended with <code>-D</code> and added to the compile command line for this target,
but not to its dependents. Unlike <code>defines</code>, the defines are only added to the
compile command line for this target.
2[]�
module_interfaces�
The list of files are regarded as C++20 Modules Interface.

<p>
C++ Standard has no restriction about module interface file extension
<ul>
<li>Clang use cppm </li>
<li>GCC can use any source file extension </li>
<li>MSVC use ixx </li>
</ul>
</p>
<p>The use is guarded by the flag
<code>--experimental_cpp_modules</code>.</p>
2[]�
srcs�
The list of C and C++ files that are processed to create the library target.
These are C/C++ source and header files, either non-generated (normal source
code) or generated.
<p>All <code>.cc</code>, <code>.c</code>, and <code>.cpp</code> files will
   be compiled. These might be generated files: if a named file is in
   the <code>outs</code> of some other rule, this <code>cc_library</code>
   will automatically depend on that other rule.
</p>
<p>Pure assembler files (.s, .asm) are not preprocessed and are typically built using
the assembler. Preprocessed assembly files (.S) are preprocessed and are typically built
using the C/C++ compiler.
</p>
<p>A <code>.h</code> file will not be compiled, but will be available for
   inclusion by sources in this rule. Both <code>.cc</code> and
   <code>.h</code> files can directly include headers listed in
   these <code>srcs</code> or in the <code>hdrs</code> of this rule or any
   rule listed in the <code>deps</code> argument.
</p>
<p>All <code>#include</code>d files must be mentioned in the
   <code>hdrs</code> attribute of this or referenced <code>cc_library</code>
   rules, or they should be listed in <code>srcs</code> if they are private
   to this library. See <a href="#hdrs">"Header inclusion checking"</a> for
   a more detailed description.
</p>
<p><code>.so</code>, <code>.lo</code>, and <code>.a</code> files are
   pre-compiled files. Your library might have these as
   <code>srcs</code> if it uses third-party code for which we don't
   have source code.
</p>
<p>If the <code>srcs</code> attribute includes the label of another rule,
   <code>cc_library</code> will use the output files of that rule as source files to
   compile. This is useful for one-off generation of source code (for more than occasional
   use, it's better to implement a Starlark rule class and use the <code>cc_common</code>
   API)
</p>
<p>
  Permitted <code>srcs</code> file types:
</p>
<ul>
<li>C and C++ source files: <code>.c</code>, <code>.cc</code>, <code>.cpp</code>,
  <code>.cxx</code>, <code>.c++</code>, <code>.C</code></li>
<li>C and C++ header files: <code>.h</code>, <code>.hh</code>, <code>.hpp</code>,
  <code>.hxx</code>, <code>.inc</code>, <code>.inl</code>, <code>.H</code></li>
<li>Assembler with C preprocessor: <code>.S</code></li>
<li>Archive: <code>.a</code>, <code>.pic.a</code></li>
<li>"Always link" library: <code>.lo</code>, <code>.pic.lo</code></li>
<li>Shared library, versioned or unversioned: <code>.so</code>,
  <code>.so.<i>version</i></code></li>
<li>Object file: <code>.o</code>, <code>.pic.o</code></li>
</ul>

<p>
  ... and any rules that produce those files (e.g. <code>cc_embed_data</code>).
  Different extensions denote different programming languages in
  accordance with gcc convention.
</p>
2[]�
strip_include_prefix�
The prefix to strip from the paths of the headers of this rule.

<p>When set, the headers in the <code>hdrs</code> attribute of this rule are accessible
at their path with this prefix cut off.

<p>If it's a relative path, it's taken as a package-relative one. If it's an absolute one,
it's understood as a repository-relative path.

<p>The prefix in the <code>include_prefix</code> attribute is added after this prefix is
stripped.

<p>This attribute is only legal under <code>third_party</code>.
2""�
textual_hdrs�
The list of header files published by
this library to be textually included by sources in dependent rules.
<p>This is the location for declaring header files that cannot be compiled on their own;
 that is, they always need to be textually included by other source files to build valid
 code.</p>
2[]�
win_def_file�
The Windows DEF file to be passed to linker.
<p>This attribute should only be used when Windows is the target platform.
It can be used to <a href="https://msdn.microsoft.com/en-us/library/d91k01sh.aspx">
export symbols</a> during linking a shared library.</p>
2None
,
*
nameA unique name for this target. �
�
additional_compiler_inputs�
Any additional files you might want to pass to the compiler command line, such as sanitizer
ignorelists, for example. Files specified here can then be used in copts with the
$(location) function.
2[]�
�
additional_linker_inputs�
Dependencies that are only made available to the C++ linker command.
<p>
  Unlike <code>deps</code>, which is conceptually made for both compilation and
  linking dependencies, <code>additional_linker_inputs</code> is specifically
  made for only the latter, and signals a dependency that is required only for
  linking (for example, files that are referenced in <code>linkopts</code>).
</p>
<p>
  For example, compiled Windows .res files can be provided here to be embedded in
  the binary target.
</p>
2[]�
�

alwayslink�
If 1, any binary that depends (directly or indirectly) on this C++
library will link in all the object files for the files listed in
<code>srcs</code>, even if some contain no symbols referenced by the binary.
This is useful if your code isn't explicitly called by code in
the binary, e.g., if your code registers to receive some callback
provided by some service.

<p>If alwayslink doesn't work with VS 2017 on Windows, that is due to a
<a href="https://github.com/bazelbuild/bazel/issues/3949">known issue</a>,
please upgrade your VS 2017 to the latest version.</p>
2False�
�
	conlyopts�
Add these options to the C compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
2[]�
�
copts�
Add these options to the C/C++ compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
<p>
  Each string in this attribute is added in the given order to <code>COPTS</code> before
  compiling the binary target. The flags take effect only for compiling this target, not
  its dependencies, so be careful about header files included elsewhere.
  All paths should be relative to the workspace, not to the current package.
  This attribute should not be needed outside of <code>third_party</code>.
</p>
<p>
  If the package declares the <a href="${link package.features}">feature</a>
  <code>no_copts_tokenization</code>, Bourne shell tokenization applies only to strings
  that consist of a single "Make" variable.
</p>
2[]�
�
cxxopts�
Add these options to the C++ compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
2[]�
�
data�
The list of files needed by this library at runtime.

See general comments about <code>data</code>
at <a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>If a <code>data</code> is the name of a generated file, then this
   <code>cc_library</code> rule automatically depends on the generating
   rule.
</p>
<p>If a <code>data</code> is a rule name, then this
   <code>cc_library</code> rule automatically depends on that rule,
   and that rule's <code>outs</code> are automatically added to
   this <code>cc_library</code>'s data files.
</p>
<p>Your C++ code can access these data files like so:</p>
<pre><code class="lang-starlark">
  const std::string path = devtools_build::GetDataDependencyFilepath(
      "my/test/data/file");
</code></pre>
2[]�
�
defines�
List of defines to add to the compile line of this and all dependent targets.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
Each string, which must consist of a single Bourne shell token,
is prepended with <code>-D</code> and added to the compile command line to this target,
as well as to every rule that depends on it. Be very careful, since this may have
far-reaching effects -- the defines are added to every target that depends on
this target.  When in doubt, add define values to
<a href="#cc_binary.local_defines"><code>local_defines</code></a> instead.
2[]�
�
deps�
The list of other libraries that the library target depends upon.

<p>These can be <code>cc_library</code> or <code>objc_library</code> targets.</p>

<p>See general comments about <code>deps</code>
  at <a href="${link common-definitions#typical-attributes}">Typical attributes defined by
  most build rules</a>.
</p>
<p>These should be names of C++ library rules.
   When you build a binary that links this rule's library,
   you will also link the libraries in <code>deps</code>.
</p>
<p>Despite the "deps" name, not all of this library's clients
   belong here.  Run-time data dependencies belong in <code>data</code>.
   Source files generated by other rules belong in <code>srcs</code>.
</p>
<p>To link in a pre-compiled third-party library, add its name to
   the <code>srcs</code> instead.
</p>
<p>To depend on something without linking it to this library, add its
   name to the <code>data</code> instead.
</p>
*
CcInfo2[]�
�
hdrs�
The list of header files published by
this library to be directly included by sources in dependent rules.
<p>This is the strongly preferred location for declaring header files that
 describe the interface for the library. These headers will be made
 available for inclusion by sources in this rule or in dependent rules.
 Headers not meant to be included by a client of this library should be
 listed in the <code>srcs</code> attribute instead, even if they are
 included by a published header. See <a href="#hdrs">"Header inclusion
 checking"</a> for a more detailed description. </p>
<p>Permitted <code>headers</code> file types:
  <code>.h</code>,
  <code>.hh</code>,
  <code>.hpp</code>,
  <code>.hxx</code>.
</p>
2[](
&

hdrs_checkDeprecated, no-op.2""�
�
implementation_deps�
The list of other libraries that the library target depends on. Unlike with
<code>deps</code>, the headers and include paths of these libraries (and all their
transitive deps) are only used for compilation of this library, and not libraries that
depend on it. Libraries specified with <code>implementation_deps</code> are still linked in
binary targets that depend on this library.
*
CcInfo2[]�
�
include_prefix�
The prefix to add to the paths of the headers of this rule.

<p>When set, the headers in the <code>hdrs</code> attribute of this rule are accessible
at is the value of this attribute prepended to their repository-relative path.

<p>The prefix in the <code>strip_include_prefix</code> attribute is removed before this
prefix is added.

<p>This attribute is only legal under <code>third_party</code>.
2""�
�
includes�
List of include dirs to be added to the compile line.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution.
Each string is prepended with the package path and passed to the C++ toolchain for
expansion via the "include_paths" CROSSTOOL feature. A toolchain running on a POSIX system
with typical feature definitions will produce
<code>-isystem path_to_package/include_entry</code>.
This should only be used for third-party libraries that
do not conform to the Google style of writing #include statements.
Unlike <a href="#cc_binary.copts">COPTS</a>, these flags are added for this rule
and every rule that depends on it. (Note: not the rules it depends upon!) Be
very careful, since this may have far-reaching effects.  When in doubt, add
"-I" flags to <a href="#cc_binary.copts">COPTS</a> instead.
<p>
The added <code>include</code> paths will include generated files as well as
files in the source tree.
</p>
2[]

licenses2[]�
�
linkopts�
See <a href="${link cc_binary.linkopts}"><code>cc_binary.linkopts</code></a>.
The <code>linkopts</code> attribute is also applied to any target that
depends, directly or indirectly, on this library via <code>deps</code>
attributes (or via other attributes that are treated similarly:
the <a href="${link cc_binary.malloc}"><code>malloc</code></a>
attribute of <a href="${link cc_binary}"><code>cc_binary</code></a>). Dependency
linkopts take precedence over dependent linkopts (i.e. dependency linkopts
appear later in the command line). Linkopts specified in
<a href='../user-manual.html#flag--linkopt'><code>--linkopt</code></a>
take precedence over rule linkopts.
</p>
<p>
Note that the <code>linkopts</code> attribute only applies
when creating <code>.so</code> files or executables, not
when creating <code>.a</code> or <code>.lo</code> files.
So if the <code>linkstatic=True</code> attribute is set, the
<code>linkopts</code> attribute has no effect on the creation of
this library, only on other targets which depend on this library.
</p>
<p>
Also, it is important to note that "-Wl,-soname" or "-Xlinker -soname"
options are not supported and should never be specified in this attribute.
</p>
<p> The <code>.so</code> files produced by <code>cc_library</code>
rules are not linked against the libraries that they depend
on.  If you're trying to create a shared library for use
outside of the main repository, e.g. for manual use
with <code>dlopen()</code> or <code>LD_PRELOAD</code>,
it may be better to use a <code>cc_binary</code> rule
with the <code>linkshared=True</code> attribute.
See <a href="${link cc_binary.linkshared}"><code>cc_binary.linkshared</code></a>.
</p>
2[]�
�
	linkstamp�
Simultaneously compiles and links the specified C++ source file into the final
binary. This trickery is required to introduce timestamp
information into binaries; if we compiled the source file to an
object file in the usual way, the timestamp would be incorrect.
A linkstamp compilation may not include any particular set of
compiler flags and so should not depend on any particular
header, compiler option, or other build variable.
<em class='harmful'>This option should only be needed in the
<code>base</code> package.</em>
2None�
�

linkstatic�
For <a href="${link cc_binary}"><code>cc_binary</code></a> and
<a href="${link cc_test}"><code>cc_test</code></a>: link the binary in static
mode. For <code>cc_library.link_static</code>: see below.
<p>By default this option is on for <code>cc_binary</code> and off for the rest.</p>
<p>
  If enabled and this is a binary or test, this option tells the build tool to link in
  <code>.a</code>'s instead of <code>.so</code>'s for user libraries whenever possible.
  System libraries such as libc (but <i>not</i> the C/C++ runtime libraries,
  see below) are still linked dynamically, as are libraries for which
  there is no static library. So the resulting executable will still be dynamically
  linked, hence only <i>mostly</i> static.
</p>
<p>
There are really three different ways to link an executable:
</p>
<ul>
<li> STATIC with fully_static_link feature, in which everything is linked statically;
  e.g. "<code>gcc -static foo.o libbar.a libbaz.a -lm</code>".<br/>
  This mode is enabled by specifying <code>fully_static_link</code> in the
  <a href="${link common-definitions#features}"><code>features</code></a> attribute.</li>
<li> STATIC, in which all user libraries are linked statically (if a static
  version is available), but where system libraries (excluding C/C++ runtime libraries)
  are linked dynamically, e.g. "<code>gcc foo.o libfoo.a libbaz.a -lm</code>".<br/>
  This mode is enabled by specifying <code>linkstatic=True</code>.</li>
<li> DYNAMIC, in which all libraries are linked dynamically (if a dynamic version is
  available), e.g. "<code>gcc foo.o libfoo.so libbaz.so -lm</code>".<br/>
  This mode is enabled by specifying <code>linkstatic=False</code>.</li>
</ul>
<p>
If the <code>linkstatic</code> attribute or <code>fully_static_link</code> in
<code>features</code> is used outside of <code>//third_party</code>
please include a comment near the rule to explain why.
</p>
<p>
The <code>linkstatic</code> attribute has a different meaning if used on a
<a href="${link cc_library}"><code>cc_library()</code></a> rule.
For a C++ library, <code>linkstatic=True</code> indicates that only
static linking is allowed, so no <code>.so</code> will be produced. linkstatic=False does
not prevent static libraries from being created. The attribute is meant to control the
creation of dynamic libraries.
</p>
<p>
There should be very little code built with <code>linkstatic=False</code> in production.
If <code>linkstatic=False</code>, then the build tool will create symlinks to
depended-upon shared libraries in the <code>*.runfiles</code> area.
</p>
2False�
�
local_defines�
List of defines to add to the compile line.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
Each string, which must consist of a single Bourne shell token,
is prepended with <code>-D</code> and added to the compile command line for this target,
but not to its dependents. Unlike <code>defines</code>, the defines are only added to the
compile command line for this target.
2[]�
�
module_interfaces�
The list of files are regarded as C++20 Modules Interface.

<p>
C++ Standard has no restriction about module interface file extension
<ul>
<li>Clang use cppm </li>
<li>GCC can use any source file extension </li>
<li>MSVC use ixx </li>
</ul>
</p>
<p>The use is guarded by the flag
<code>--experimental_cpp_modules</code>.</p>
2[]�
�
srcs�
The list of C and C++ files that are processed to create the library target.
These are C/C++ source and header files, either non-generated (normal source
code) or generated.
<p>All <code>.cc</code>, <code>.c</code>, and <code>.cpp</code> files will
   be compiled. These might be generated files: if a named file is in
   the <code>outs</code> of some other rule, this <code>cc_library</code>
   will automatically depend on that other rule.
</p>
<p>Pure assembler files (.s, .asm) are not preprocessed and are typically built using
the assembler. Preprocessed assembly files (.S) are preprocessed and are typically built
using the C/C++ compiler.
</p>
<p>A <code>.h</code> file will not be compiled, but will be available for
   inclusion by sources in this rule. Both <code>.cc</code> and
   <code>.h</code> files can directly include headers listed in
   these <code>srcs</code> or in the <code>hdrs</code> of this rule or any
   rule listed in the <code>deps</code> argument.
</p>
<p>All <code>#include</code>d files must be mentioned in the
   <code>hdrs</code> attribute of this or referenced <code>cc_library</code>
   rules, or they should be listed in <code>srcs</code> if they are private
   to this library. See <a href="#hdrs">"Header inclusion checking"</a> for
   a more detailed description.
</p>
<p><code>.so</code>, <code>.lo</code>, and <code>.a</code> files are
   pre-compiled files. Your library might have these as
   <code>srcs</code> if it uses third-party code for which we don't
   have source code.
</p>
<p>If the <code>srcs</code> attribute includes the label of another rule,
   <code>cc_library</code> will use the output files of that rule as source files to
   compile. This is useful for one-off generation of source code (for more than occasional
   use, it's better to implement a Starlark rule class and use the <code>cc_common</code>
   API)
</p>
<p>
  Permitted <code>srcs</code> file types:
</p>
<ul>
<li>C and C++ source files: <code>.c</code>, <code>.cc</code>, <code>.cpp</code>,
  <code>.cxx</code>, <code>.c++</code>, <code>.C</code></li>
<li>C and C++ header files: <code>.h</code>, <code>.hh</code>, <code>.hpp</code>,
  <code>.hxx</code>, <code>.inc</code>, <code>.inl</code>, <code>.H</code></li>
<li>Assembler with C preprocessor: <code>.S</code></li>
<li>Archive: <code>.a</code>, <code>.pic.a</code></li>
<li>"Always link" library: <code>.lo</code>, <code>.pic.lo</code></li>
<li>Shared library, versioned or unversioned: <code>.so</code>,
  <code>.so.<i>version</i></code></li>
<li>Object file: <code>.o</code>, <code>.pic.o</code></li>
</ul>

<p>
  ... and any rules that produce those files (e.g. <code>cc_embed_data</code>).
  Different extensions denote different programming languages in
  accordance with gcc convention.
</p>
2[]�
�
strip_include_prefix�
The prefix to strip from the paths of the headers of this rule.

<p>When set, the headers in the <code>hdrs</code> attribute of this rule are accessible
at their path with this prefix cut off.

<p>If it's a relative path, it's taken as a package-relative one. If it's an absolute one,
it's understood as a repository-relative path.

<p>The prefix in the <code>include_prefix</code> attribute is added after this prefix is
stripped.

<p>This attribute is only legal under <code>third_party</code>.
2""�
�
textual_hdrs�
The list of header files published by
this library to be textually included by sources in dependent rules.
<p>This is the location for declaring header files that cannot be compiled on their own;
 that is, they always need to be textually included by other source files to build valid
 code.</p>
2[]�
�
win_def_file�
The Windows DEF file to be passed to linker.
<p>This attribute should only be used when Windows is the target platform.
It can be used to <a href="https://msdn.microsoft.com/en-us/library/d91k01sh.aspx">
export symbols</a> during linking a shared library.</p>
2Nonec
//cc:defs.bzlrP

rules_ccccdefs.bzl&

cc_library
cc_library
!+
-;proto_cc_library.bzl provides a cc_library for proto files.�E
9
build_stack_rules_protorules/goproto_go_library.bzl�Dproto_go_library�This builds a Go library from a set of source files that are all part of
the same package.<br><br>
***Note:*** For targets generated by Gazelle, `name` is typically the last component of the path,
or `go_default_library`, with the old naming convention.<br><br>
**Providers:**
<ul>
  <li>[GoInfo]</li>
  <li>[GoArchive]</li>
</ul>
"�A
�!
proto_go_library�This builds a Go library from a set of source files that are all part of
the same package.<br><br>
***Note:*** For targets generated by Gazelle, `name` is typically the last component of the path,
or `go_default_library`, with the old naming convention.<br><br>
**Providers:**
<ul>
  <li>[GoInfo]</li>
  <li>[GoArchive]</li>
</ul>
*
nameA unique name for this target. �
cdeps�
List of other libraries that the c code depends on.
This can be anything that would be allowed in [cc_library deps] Only valid if `cgo = True`.
2[]�
cgo�
If `True`, the package may contain [cgo] code, and `srcs` may contain C, C++, Objective-C, and Objective-C++ files
and non-Go assembly files. When cgo is enabled, these files will be compiled with the C/C++ toolchain and
included in the package. Note that this attribute does not force cgo to be enabled. Cgo is enabled for
non-cross-compiling builds when a C/C++ toolchain is configured.
2False�
	clinkopts�
List of flags to add to the C link command.
Subject to ["Make variable"] substitution and [Bourne shell tokenization]. Only valid if `cgo = True`.
2[]�
copts�
List of flags to add to the C compilation command.
Subject to ["Make variable"] substitution and [Bourne shell tokenization]. Only valid if `cgo = True`.
2[]�
cppopts�
List of flags to add to the C/C++ preprocessor command.
Subject to ["Make variable"] substitution and [Bourne shell tokenization].
Only valid if `cgo = True`.
2[]�
cxxopts�
List of flags to add to the C++ compilation command.
Subject to ["Make variable"] substitution and [Bourne shell tokenization]. Only valid if `cgo = True`.
2[]�
data�
List of files needed by this rule at run-time.
This may include data files needed or other programs that may be executed.
The [bazel] package may be used to locate run files; they may appear in different places
depending on the operating system and environment. See [data dependencies] for more information on data files.
2[]�
deps�
List of Go libraries this package imports directly.
These may be `go_library` rules or compatible rules with the [GoInfo] provider.
*
GoInfo2[]�
embed�
List of Go libraries whose sources should be compiled together with this package's sources.
Labels listed here must name `go_library`, `go_proto_library`, or other compatible targets with
the [GoInfo] provider. Embedded libraries must have the same `importpath` as the embedding library.
At most one embedded library may have `cgo = True`, and the embedding library may not also have `cgo = True`.
See [Embedding] for more information.
*
GoInfo2[]�
	embedsrcs�
The list of files that may be embedded into the compiled package using `//go:embed`
directives. All files must be in the same logical directory or a subdirectory as source files.
All source files containing `//go:embed` directives must be in the same logical directory.
It's okay to mix static and generated source files and static and generated embeddable files.
2[]�
	gc_goopts�
List of flags to add to the Go compilation command when using the gc compiler.
Subject to ["Make variable"] substitution and [Bourne shell tokenization].
2[]�
	importmap�
The actual import path of this library. By default, this is `importpath`. This is mostly only visible to the compiler and linker,
but it may also be seen in stack traces. This must be unique among packages passed to the linker.
It may be set to something different than `importpath` to prevent conflicts between multiple packages
with the same path (for example, from different vendor directories).
2""�

importpath�
The source import path of this library. Other libraries can import this library using this path.
This must either be specified in `go_library` or inherited from one of the libraries in `embed`.
2""
importpath_aliases2[]�
srcs�
The list of Go source files that are compiled to create the package.
Only `.go`, `.s`, and `.syso` files are permitted, unless the `cgo` attribute is set,
in which case, `.c .cc .cpp .cxx .h .hh .hpp .hxx .inc .m .mm` files are also permitted.
Files may be filtered at build time using Go [build constraints].
2[]|
x_defsl
Map of defines to add to the go link command. See [Defines and stamping] for examples of how to use these.

2{}
,
*
nameA unique name for this target. �
�
cdeps�
List of other libraries that the c code depends on.
This can be anything that would be allowed in [cc_library deps] Only valid if `cgo = True`.
2[]�
�
cgo�
If `True`, the package may contain [cgo] code, and `srcs` may contain C, C++, Objective-C, and Objective-C++ files
and non-Go assembly files. When cgo is enabled, these files will be compiled with the C/C++ toolchain and
included in the package. Note that this attribute does not force cgo to be enabled. Cgo is enabled for
non-cross-compiling builds when a C/C++ toolchain is configured.
2False�
�
	clinkopts�
List of flags to add to the C link command.
Subject to ["Make variable"] substitution and [Bourne shell tokenization]. Only valid if `cgo = True`.
2[]�
�
copts�
List of flags to add to the C compilation command.
Subject to ["Make variable"] substitution and [Bourne shell tokenization]. Only valid if `cgo = True`.
2[]�
�
cppopts�
List of flags to add to the C/C++ preprocessor command.
Subject to ["Make variable"] substitution and [Bourne shell tokenization].
Only valid if `cgo = True`.
2[]�
�
cxxopts�
List of flags to add to the C++ compilation command.
Subject to ["Make variable"] substitution and [Bourne shell tokenization]. Only valid if `cgo = True`.
2[]�
�
data�
List of files needed by this rule at run-time.
This may include data files needed or other programs that may be executed.
The [bazel] package may be used to locate run files; they may appear in different places
depending on the operating system and environment. See [data dependencies] for more information on data files.
2[]�
�
deps�
List of Go libraries this package imports directly.
These may be `go_library` rules or compatible rules with the [GoInfo] provider.
*
GoInfo2[]�
�
embed�
List of Go libraries whose sources should be compiled together with this package's sources.
Labels listed here must name `go_library`, `go_proto_library`, or other compatible targets with
the [GoInfo] provider. Embedded libraries must have the same `importpath` as the embedding library.
At most one embedded library may have `cgo = True`, and the embedding library may not also have `cgo = True`.
See [Embedding] for more information.
*
GoInfo2[]�
�
	embedsrcs�
The list of files that may be embedded into the compiled package using `//go:embed`
directives. All files must be in the same logical directory or a subdirectory as source files.
All source files containing `//go:embed` directives must be in the same logical directory.
It's okay to mix static and generated source files and static and generated embeddable files.
2[]�
�
	gc_goopts�
List of flags to add to the Go compilation command when using the gc compiler.
Subject to ["Make variable"] substitution and [Bourne shell tokenization].
2[]�
�
	importmap�
The actual import path of this library. By default, this is `importpath`. This is mostly only visible to the compiler and linker,
but it may also be seen in stack traces. This must be unique among packages passed to the linker.
It may be set to something different than `importpath` to prevent conflicts between multiple packages
with the same path (for example, from different vendor directories).
2""�
�

importpath�
The source import path of this library. Other libraries can import this library using this path.
This must either be specified in `go_library` or inherited from one of the libraries in `embed`.
2""

importpath_aliases2[]�
�
srcs�
The list of Go source files that are compiled to create the package.
Only `.go`, `.s`, and `.syso` files are permitted, unless the `cgo` attribute is set,
in which case, `.c .cc .cpp .cxx .h .hh .hpp .hxx .inc .m .mm` files are also permitted.
Files may be filtered at build time using Go [build constraints].
2[]~
|
x_defsl
Map of defines to add to the go link command. See [Defines and stamping] for examples of how to use these.

2{}a
//go:def.bzlrO

rules_gogodef.bzl&

go_library
go_library
 *
,;proto_go_library.bzl provides a go_library for proto files.�
9
build_stack_rules_protorules/goproto_go_modules.bzl�proto_go_modules"�
�
proto_go_modules*
nameA unique name for this target. g
depsLlist of libraries that provide GoArchive (proto_go_library, go_library, ...)*
	GoArchive2[]�
imports�list of go importpaths that represent top-level proto imports that are desired.  The transitive set of proto import dependencies will be computed from this set2[]b
modules;list of labels that provide ProtoGoModulesInfo (go_modules)*
ProtoGoModulesInfo2[]
srcroot2"local""L
proto_go_modules8@@build_stack_rules_proto//rules/go:proto_go_modules.bzl
vv,
*
nameA unique name for this target. i
g
depsLlist of libraries that provide GoArchive (proto_go_library, go_library, ...)*
	GoArchive2[]�
�
imports�list of go importpaths that represent top-level proto imports that are desired.  The transitive set of proto import dependencies will be computed from this set2[]d
b
modules;list of labels that provide ProtoGoModulesInfo (go_modules)*
ProtoGoModulesInfo2[]

srcroot2"local"�ProtoGoModulesInfo$info provided from a go_modules rule2�
�
ProtoGoModulesInfo$info provided from a go_modules rule+
direct!List[GoArchive] deps of this rule(
label[Label]: the label of this rule"N
ProtoGoModulesInfo8@@build_stack_rules_proto//rules/go:proto_go_modules.bzl
-
+
direct!List[GoArchive] deps of this rule*
(
label[Label]: the label of this rule_
//go:def.bzlrM

rules_gogodef.bzl$
	GoArchive	GoArchive
 )
+{
//go/private:common.bzlr^
"
rules_go
go/private
common.bzl*
GO_TOOLCHAINGO_TOOLCHAIN
+7
99proto_go_modules.bzl provides the 'proto_go_modules' rule��
<
build_stack_rules_proto
rules/javagrpc_java_library.bzl��grpc_java_library�
<p>This rule compiles and links sources into a <code>.jar</code> file.</p>

<h4>Implicit outputs</h4>
<ul>
  <li><code>lib<var>name</var>.jar</code>: A Java archive containing the class files.</li>
  <li><code>lib<var>name</var>-src.jar</code>: An archive containing the sources ("source
    jar").</li>
</ul>
"�
�J
grpc_java_library�
<p>This rule compiles and links sources into a <code>.jar</code> file.</p>

<h4>Implicit outputs</h4>
<ul>
  <li><code>lib<var>name</var>.jar</code>: A Java archive containing the class files.</li>
  <li><code>lib<var>name</var>-src.jar</code>: An archive containing the sources ("source
    jar").</li>
</ul>
*
nameA unique name for this target. �
add_exports�
Allow this library to access the given <code>module</code> or <code>package</code>.
<p>
This corresponds to the javac and JVM --add-exports= flags.
2[]�
	add_opens�
Allow this library to reflectively access the given <code>module</code> or
<code>package</code>.
<p>
This corresponds to the javac and JVM --add-opens= flags.
2[]I
bootclasspathRestricted API, do not use!*
BootClassPathInfo2None�
data�
The list of files needed by this library at runtime.
See general comments about <code>data</code> at
<a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>
  When building a <code>java_library</code>, Bazel doesn't put these files anywhere; if the
  <code>data</code> files are generated files then Bazel generates them. When building a
  test that depends on this <code>java_library</code> Bazel copies or links the
  <code>data</code> files into the runfiles area.
</p>
2[]�
deps�
The list of libraries to link into this library.
See general comments about <code>deps</code> at
<a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>
  The jars built by <code>java_library</code> rules listed in <code>deps</code> will be on
  the compile-time classpath of this rule. Furthermore the transitive closure of their
  <code>deps</code>, <code>runtime_deps</code> and <code>exports</code> will be on the
  runtime classpath.
</p>
<p>
  By contrast, targets in the <code>data</code> attribute are included in the runfiles but
  on neither the compile-time nor runtime classpath.
</p>
*
CcInfo*

JavaInfo2[]�
exported_plugins�
The list of <code><a href="#${link java_plugin}">java_plugin</a></code>s (e.g. annotation
processors) to export to libraries that directly depend on this library.
<p>
  The specified list of <code>java_plugin</code>s will be applied to any library which
  directly depends on this library, just as if that library had explicitly declared these
  labels in <code><a href="${link java_library.plugins}">plugins</a></code>.
</p>
*
JavaPluginInfo2[]�
exports�
Exported libraries.
<p>
  Listing rules here will make them available to parent rules, as if the parents explicitly
  depended on these rules. This is not true for regular (non-exported) <code>deps</code>.
</p>
<p>
  Summary: a rule <i>X</i> can access the code in <i>Y</i> if there exists a dependency
  path between them that begins with a <code>deps</code> edge followed by zero or more
  <code>exports</code> edges. Let's see some examples to illustrate this.
</p>
<p>
  Assume <i>A</i> depends on <i>B</i> and <i>B</i> depends on <i>C</i>. In this case
  C is a <em>transitive</em> dependency of A, so changing C's sources and rebuilding A will
  correctly rebuild everything. However A will not be able to use classes in C. To allow
  that, either A has to declare C in its <code>deps</code>, or B can make it easier for A
  (and anything that may depend on A) by declaring C in its (B's) <code>exports</code>
  attribute.
</p>
<p>
  The closure of exported libraries is available to all direct parent rules. Take a slightly
  different example: A depends on B, B depends on C and D, and also exports C but not D.
  Now A has access to C but not to D. Now, if C and D exported some libraries, C' and D'
  respectively, A could only access C' but not D'.
</p>
<p>
  Important: an exported rule is not a regular dependency. Sticking to the previous example,
  if B exports C and wants to also use C, it has to also list it in its own
  <code>deps</code>.
</p>
*

JavaInfo*
CcInfo2[]:
javabuilder_jvm_flagsRestricted API, do not use!2[]�
	javacopts�
Extra compiler options for this library.
Subject to <a href="make-variables.html">"Make variable"</a> substitution and
<a href="common-definitions.html#sh-tokenization">Bourne shell tokenization</a>.
<p>These compiler options are passed to javac after the global compiler options.</p>
2[]
licenses2[]�
	neverlink�
Whether this library should only be used for compilation and not at runtime.
Useful if the library will be provided by the runtime environment during execution. Examples
of such libraries are the IDE APIs for IDE plug-ins or <code>tools.jar</code> for anything
running on a standard JDK.
<p>
  Note that <code>neverlink = True</code> does not prevent the compiler from inlining material
  from this library into compilation targets that depend on it, as permitted by the Java
  Language Specification (e.g., <code>static final</code> constants of <code>String</code>
  or of primitive types). The preferred use case is therefore when the runtime library is
  identical to the compilation library.
</p>
<p>
  If the runtime library differs from the compilation library then you must ensure that it
  differs only in places that the JLS forbids compilers to inline (and that must hold for
  all future versions of the JLS).
</p>
2False�
plugins�
Java compiler plugins to run at compile-time.
Every <code>java_plugin</code> specified in this attribute will be run whenever this rule
is built. A library may also inherit plugins from dependencies that use
<code><a href="#java_library.exported_plugins">exported_plugins</a></code>. Resources
generated by the plugin will be included in the resulting jar of this rule.
*
JavaPluginInfo2[]�
proguard_specs�
Files to be used as Proguard specification.
These will describe the set of specifications to be used by Proguard. If specified,
they will be added to any <code>android_binary</code> target depending on this library.

The files included here must only have idempotent rules, namely -dontnote, -dontwarn,
assumenosideeffects, and rules that start with -keep. Other options can only appear in
<code>android_binary</code>'s proguard_specs, to ensure non-tautological merges.
2[]�
resource_strip_prefix�
The path prefix to strip from Java resources.
<p>
If specified, this path prefix is stripped from every file in the <code>resources</code>
attribute. It is an error for a resource file not to be under this directory. If not
specified (the default), the path of resource file is determined according to the same
logic as the Java package of source files. For example, a source file at
<code>stuff/java/foo/bar/a.txt</code> will be located at <code>foo/bar/a.txt</code>.
</p>
2""�
	resources�
A list of data files to include in a Java jar.
<p>
Resources may be source files or generated files.
</p>

<p>
If resources are specified, they will be bundled in the jar along with the usual
<code>.class</code> files produced by compilation. The location of the resources inside
of the jar file is determined by the project structure. Bazel first looks for Maven's
<a href="https://maven.apache.org/guides/introduction/introduction-to-the-standard-directory-layout.html">standard directory layout</a>,
(a "src" directory followed by a "resources" directory grandchild). If that is not
found, Bazel then looks for the topmost directory named "java" or "javatests" (so, for
example, if a resource is at <code>&lt;workspace root&gt;/x/java/y/java/z</code>, the
path of the resource will be <code>y/java/z</code>. This heuristic cannot be overridden,
however, the <code>resource_strip_prefix</code> attribute can be used to specify a
specific alternative directory for resource files.
2[]�
runtime_deps�
Libraries to make available to the final binary or test at runtime only.
Like ordinary <code>deps</code>, these will appear on the runtime classpath, but unlike
them, not on the compile-time classpath. Dependencies needed only at runtime should be
listed here. Dependency-analysis tools should ignore targets that appear in both
<code>runtime_deps</code> and <code>deps</code>.
*
CcInfo*

JavaInfo2[]�

srcs�

The list of source files that are processed to create the target.
This attribute is almost always required; see exceptions below.
<p>
Source files of type <code>.java</code> are compiled. In case of generated
<code>.java</code> files it is generally advisable to put the generating rule's name
here instead of the name of the file itself. This not only improves readability but
makes the rule more resilient to future changes: if the generating rule generates
different files in the future, you only need to fix one place: the <code>outs</code> of
the generating rule. You should not list the generating rule in <code>deps</code>
because it is a no-op.
</p>
<p>
Source files of type <code>.srcjar</code> are unpacked and compiled. (This is useful if
you need to generate a set of <code>.java</code> files with a genrule.)
</p>
<p>
Rules: if the rule (typically <code>genrule</code> or <code>filegroup</code>) generates
any of the files listed above, they will be used the same way as described for source
files.
</p>
<p>
Source files of type <code>.properties</code> are treated as resources.
</p>

<p>All other files are ignored, as long as there is at least one file of a
file type described above. Otherwise an error is raised.</p>

<p>
This argument is almost always required, except if you specify the <code>runtime_deps</code> argument.
</p>
2[]
,
*
nameA unique name for this target. �
�
add_exports�
Allow this library to access the given <code>module</code> or <code>package</code>.
<p>
This corresponds to the javac and JVM --add-exports= flags.
2[]�
�
	add_opens�
Allow this library to reflectively access the given <code>module</code> or
<code>package</code>.
<p>
This corresponds to the javac and JVM --add-opens= flags.
2[]K
I
bootclasspathRestricted API, do not use!*
BootClassPathInfo2None�
�
data�
The list of files needed by this library at runtime.
See general comments about <code>data</code> at
<a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>
  When building a <code>java_library</code>, Bazel doesn't put these files anywhere; if the
  <code>data</code> files are generated files then Bazel generates them. When building a
  test that depends on this <code>java_library</code> Bazel copies or links the
  <code>data</code> files into the runfiles area.
</p>
2[]�
�
deps�
The list of libraries to link into this library.
See general comments about <code>deps</code> at
<a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>
  The jars built by <code>java_library</code> rules listed in <code>deps</code> will be on
  the compile-time classpath of this rule. Furthermore the transitive closure of their
  <code>deps</code>, <code>runtime_deps</code> and <code>exports</code> will be on the
  runtime classpath.
</p>
<p>
  By contrast, targets in the <code>data</code> attribute are included in the runfiles but
  on neither the compile-time nor runtime classpath.
</p>
*
CcInfo*

JavaInfo2[]�
�
exported_plugins�
The list of <code><a href="#${link java_plugin}">java_plugin</a></code>s (e.g. annotation
processors) to export to libraries that directly depend on this library.
<p>
  The specified list of <code>java_plugin</code>s will be applied to any library which
  directly depends on this library, just as if that library had explicitly declared these
  labels in <code><a href="${link java_library.plugins}">plugins</a></code>.
</p>
*
JavaPluginInfo2[]�
�
exports�
Exported libraries.
<p>
  Listing rules here will make them available to parent rules, as if the parents explicitly
  depended on these rules. This is not true for regular (non-exported) <code>deps</code>.
</p>
<p>
  Summary: a rule <i>X</i> can access the code in <i>Y</i> if there exists a dependency
  path between them that begins with a <code>deps</code> edge followed by zero or more
  <code>exports</code> edges. Let's see some examples to illustrate this.
</p>
<p>
  Assume <i>A</i> depends on <i>B</i> and <i>B</i> depends on <i>C</i>. In this case
  C is a <em>transitive</em> dependency of A, so changing C's sources and rebuilding A will
  correctly rebuild everything. However A will not be able to use classes in C. To allow
  that, either A has to declare C in its <code>deps</code>, or B can make it easier for A
  (and anything that may depend on A) by declaring C in its (B's) <code>exports</code>
  attribute.
</p>
<p>
  The closure of exported libraries is available to all direct parent rules. Take a slightly
  different example: A depends on B, B depends on C and D, and also exports C but not D.
  Now A has access to C but not to D. Now, if C and D exported some libraries, C' and D'
  respectively, A could only access C' but not D'.
</p>
<p>
  Important: an exported rule is not a regular dependency. Sticking to the previous example,
  if B exports C and wants to also use C, it has to also list it in its own
  <code>deps</code>.
</p>
*

JavaInfo*
CcInfo2[]<
:
javabuilder_jvm_flagsRestricted API, do not use!2[]�
�
	javacopts�
Extra compiler options for this library.
Subject to <a href="make-variables.html">"Make variable"</a> substitution and
<a href="common-definitions.html#sh-tokenization">Bourne shell tokenization</a>.
<p>These compiler options are passed to javac after the global compiler options.</p>
2[]

licenses2[]�
�
	neverlink�
Whether this library should only be used for compilation and not at runtime.
Useful if the library will be provided by the runtime environment during execution. Examples
of such libraries are the IDE APIs for IDE plug-ins or <code>tools.jar</code> for anything
running on a standard JDK.
<p>
  Note that <code>neverlink = True</code> does not prevent the compiler from inlining material
  from this library into compilation targets that depend on it, as permitted by the Java
  Language Specification (e.g., <code>static final</code> constants of <code>String</code>
  or of primitive types). The preferred use case is therefore when the runtime library is
  identical to the compilation library.
</p>
<p>
  If the runtime library differs from the compilation library then you must ensure that it
  differs only in places that the JLS forbids compilers to inline (and that must hold for
  all future versions of the JLS).
</p>
2False�
�
plugins�
Java compiler plugins to run at compile-time.
Every <code>java_plugin</code> specified in this attribute will be run whenever this rule
is built. A library may also inherit plugins from dependencies that use
<code><a href="#java_library.exported_plugins">exported_plugins</a></code>. Resources
generated by the plugin will be included in the resulting jar of this rule.
*
JavaPluginInfo2[]�
�
proguard_specs�
Files to be used as Proguard specification.
These will describe the set of specifications to be used by Proguard. If specified,
they will be added to any <code>android_binary</code> target depending on this library.

The files included here must only have idempotent rules, namely -dontnote, -dontwarn,
assumenosideeffects, and rules that start with -keep. Other options can only appear in
<code>android_binary</code>'s proguard_specs, to ensure non-tautological merges.
2[]�
�
resource_strip_prefix�
The path prefix to strip from Java resources.
<p>
If specified, this path prefix is stripped from every file in the <code>resources</code>
attribute. It is an error for a resource file not to be under this directory. If not
specified (the default), the path of resource file is determined according to the same
logic as the Java package of source files. For example, a source file at
<code>stuff/java/foo/bar/a.txt</code> will be located at <code>foo/bar/a.txt</code>.
</p>
2""�
�
	resources�
A list of data files to include in a Java jar.
<p>
Resources may be source files or generated files.
</p>

<p>
If resources are specified, they will be bundled in the jar along with the usual
<code>.class</code> files produced by compilation. The location of the resources inside
of the jar file is determined by the project structure. Bazel first looks for Maven's
<a href="https://maven.apache.org/guides/introduction/introduction-to-the-standard-directory-layout.html">standard directory layout</a>,
(a "src" directory followed by a "resources" directory grandchild). If that is not
found, Bazel then looks for the topmost directory named "java" or "javatests" (so, for
example, if a resource is at <code>&lt;workspace root&gt;/x/java/y/java/z</code>, the
path of the resource will be <code>y/java/z</code>. This heuristic cannot be overridden,
however, the <code>resource_strip_prefix</code> attribute can be used to specify a
specific alternative directory for resource files.
2[]�
�
runtime_deps�
Libraries to make available to the final binary or test at runtime only.
Like ordinary <code>deps</code>, these will appear on the runtime classpath, but unlike
them, not on the compile-time classpath. Dependencies needed only at runtime should be
listed here. Dependency-analysis tools should ignore targets that appear in both
<code>runtime_deps</code> and <code>deps</code>.
*
CcInfo*

JavaInfo2[]�

�

srcs�

The list of source files that are processed to create the target.
This attribute is almost always required; see exceptions below.
<p>
Source files of type <code>.java</code> are compiled. In case of generated
<code>.java</code> files it is generally advisable to put the generating rule's name
here instead of the name of the file itself. This not only improves readability but
makes the rule more resilient to future changes: if the generating rule generates
different files in the future, you only need to fix one place: the <code>outs</code> of
the generating rule. You should not list the generating rule in <code>deps</code>
because it is a no-op.
</p>
<p>
Source files of type <code>.srcjar</code> are unpacked and compiled. (This is useful if
you need to generate a set of <code>.java</code> files with a genrule.)
</p>
<p>
Rules: if the rule (typically <code>genrule</code> or <code>filegroup</code>) generates
any of the files listed above, they will be used the same way as described for source
files.
</p>
<p>
Source files of type <code>.properties</code> are treated as resources.
</p>

<p>All other files are ignored, as long as there is at least one file of a
file type described above. Otherwise an error is raised.</p>

<p>
This argument is almost always required, except if you specify the <code>runtime_deps</code> argument.
</p>
2[]}
//java:java_library.bzlr`
$

rules_javajavajava_library.bzl*
java_libraryjava_library
-9
;=grpc_java_library.bzl provides a java_library for grpc files.Ę
=
build_stack_rules_proto
rules/javaproto_java_library.bzl��proto_java_library�
<p>This rule compiles and links sources into a <code>.jar</code> file.</p>

<h4>Implicit outputs</h4>
<ul>
  <li><code>lib<var>name</var>.jar</code>: A Java archive containing the class files.</li>
  <li><code>lib<var>name</var>-src.jar</code>: An archive containing the sources ("source
    jar").</li>
</ul>
"�
�J
proto_java_library�
<p>This rule compiles and links sources into a <code>.jar</code> file.</p>

<h4>Implicit outputs</h4>
<ul>
  <li><code>lib<var>name</var>.jar</code>: A Java archive containing the class files.</li>
  <li><code>lib<var>name</var>-src.jar</code>: An archive containing the sources ("source
    jar").</li>
</ul>
*
nameA unique name for this target. �
add_exports�
Allow this library to access the given <code>module</code> or <code>package</code>.
<p>
This corresponds to the javac and JVM --add-exports= flags.
2[]�
	add_opens�
Allow this library to reflectively access the given <code>module</code> or
<code>package</code>.
<p>
This corresponds to the javac and JVM --add-opens= flags.
2[]I
bootclasspathRestricted API, do not use!*
BootClassPathInfo2None�
data�
The list of files needed by this library at runtime.
See general comments about <code>data</code> at
<a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>
  When building a <code>java_library</code>, Bazel doesn't put these files anywhere; if the
  <code>data</code> files are generated files then Bazel generates them. When building a
  test that depends on this <code>java_library</code> Bazel copies or links the
  <code>data</code> files into the runfiles area.
</p>
2[]�
deps�
The list of libraries to link into this library.
See general comments about <code>deps</code> at
<a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>
  The jars built by <code>java_library</code> rules listed in <code>deps</code> will be on
  the compile-time classpath of this rule. Furthermore the transitive closure of their
  <code>deps</code>, <code>runtime_deps</code> and <code>exports</code> will be on the
  runtime classpath.
</p>
<p>
  By contrast, targets in the <code>data</code> attribute are included in the runfiles but
  on neither the compile-time nor runtime classpath.
</p>
*
CcInfo*

JavaInfo2[]�
exported_plugins�
The list of <code><a href="#${link java_plugin}">java_plugin</a></code>s (e.g. annotation
processors) to export to libraries that directly depend on this library.
<p>
  The specified list of <code>java_plugin</code>s will be applied to any library which
  directly depends on this library, just as if that library had explicitly declared these
  labels in <code><a href="${link java_library.plugins}">plugins</a></code>.
</p>
*
JavaPluginInfo2[]�
exports�
Exported libraries.
<p>
  Listing rules here will make them available to parent rules, as if the parents explicitly
  depended on these rules. This is not true for regular (non-exported) <code>deps</code>.
</p>
<p>
  Summary: a rule <i>X</i> can access the code in <i>Y</i> if there exists a dependency
  path between them that begins with a <code>deps</code> edge followed by zero or more
  <code>exports</code> edges. Let's see some examples to illustrate this.
</p>
<p>
  Assume <i>A</i> depends on <i>B</i> and <i>B</i> depends on <i>C</i>. In this case
  C is a <em>transitive</em> dependency of A, so changing C's sources and rebuilding A will
  correctly rebuild everything. However A will not be able to use classes in C. To allow
  that, either A has to declare C in its <code>deps</code>, or B can make it easier for A
  (and anything that may depend on A) by declaring C in its (B's) <code>exports</code>
  attribute.
</p>
<p>
  The closure of exported libraries is available to all direct parent rules. Take a slightly
  different example: A depends on B, B depends on C and D, and also exports C but not D.
  Now A has access to C but not to D. Now, if C and D exported some libraries, C' and D'
  respectively, A could only access C' but not D'.
</p>
<p>
  Important: an exported rule is not a regular dependency. Sticking to the previous example,
  if B exports C and wants to also use C, it has to also list it in its own
  <code>deps</code>.
</p>
*

JavaInfo*
CcInfo2[]:
javabuilder_jvm_flagsRestricted API, do not use!2[]�
	javacopts�
Extra compiler options for this library.
Subject to <a href="make-variables.html">"Make variable"</a> substitution and
<a href="common-definitions.html#sh-tokenization">Bourne shell tokenization</a>.
<p>These compiler options are passed to javac after the global compiler options.</p>
2[]
licenses2[]�
	neverlink�
Whether this library should only be used for compilation and not at runtime.
Useful if the library will be provided by the runtime environment during execution. Examples
of such libraries are the IDE APIs for IDE plug-ins or <code>tools.jar</code> for anything
running on a standard JDK.
<p>
  Note that <code>neverlink = True</code> does not prevent the compiler from inlining material
  from this library into compilation targets that depend on it, as permitted by the Java
  Language Specification (e.g., <code>static final</code> constants of <code>String</code>
  or of primitive types). The preferred use case is therefore when the runtime library is
  identical to the compilation library.
</p>
<p>
  If the runtime library differs from the compilation library then you must ensure that it
  differs only in places that the JLS forbids compilers to inline (and that must hold for
  all future versions of the JLS).
</p>
2False�
plugins�
Java compiler plugins to run at compile-time.
Every <code>java_plugin</code> specified in this attribute will be run whenever this rule
is built. A library may also inherit plugins from dependencies that use
<code><a href="#java_library.exported_plugins">exported_plugins</a></code>. Resources
generated by the plugin will be included in the resulting jar of this rule.
*
JavaPluginInfo2[]�
proguard_specs�
Files to be used as Proguard specification.
These will describe the set of specifications to be used by Proguard. If specified,
they will be added to any <code>android_binary</code> target depending on this library.

The files included here must only have idempotent rules, namely -dontnote, -dontwarn,
assumenosideeffects, and rules that start with -keep. Other options can only appear in
<code>android_binary</code>'s proguard_specs, to ensure non-tautological merges.
2[]�
resource_strip_prefix�
The path prefix to strip from Java resources.
<p>
If specified, this path prefix is stripped from every file in the <code>resources</code>
attribute. It is an error for a resource file not to be under this directory. If not
specified (the default), the path of resource file is determined according to the same
logic as the Java package of source files. For example, a source file at
<code>stuff/java/foo/bar/a.txt</code> will be located at <code>foo/bar/a.txt</code>.
</p>
2""�
	resources�
A list of data files to include in a Java jar.
<p>
Resources may be source files or generated files.
</p>

<p>
If resources are specified, they will be bundled in the jar along with the usual
<code>.class</code> files produced by compilation. The location of the resources inside
of the jar file is determined by the project structure. Bazel first looks for Maven's
<a href="https://maven.apache.org/guides/introduction/introduction-to-the-standard-directory-layout.html">standard directory layout</a>,
(a "src" directory followed by a "resources" directory grandchild). If that is not
found, Bazel then looks for the topmost directory named "java" or "javatests" (so, for
example, if a resource is at <code>&lt;workspace root&gt;/x/java/y/java/z</code>, the
path of the resource will be <code>y/java/z</code>. This heuristic cannot be overridden,
however, the <code>resource_strip_prefix</code> attribute can be used to specify a
specific alternative directory for resource files.
2[]�
runtime_deps�
Libraries to make available to the final binary or test at runtime only.
Like ordinary <code>deps</code>, these will appear on the runtime classpath, but unlike
them, not on the compile-time classpath. Dependencies needed only at runtime should be
listed here. Dependency-analysis tools should ignore targets that appear in both
<code>runtime_deps</code> and <code>deps</code>.
*
CcInfo*

JavaInfo2[]�

srcs�

The list of source files that are processed to create the target.
This attribute is almost always required; see exceptions below.
<p>
Source files of type <code>.java</code> are compiled. In case of generated
<code>.java</code> files it is generally advisable to put the generating rule's name
here instead of the name of the file itself. This not only improves readability but
makes the rule more resilient to future changes: if the generating rule generates
different files in the future, you only need to fix one place: the <code>outs</code> of
the generating rule. You should not list the generating rule in <code>deps</code>
because it is a no-op.
</p>
<p>
Source files of type <code>.srcjar</code> are unpacked and compiled. (This is useful if
you need to generate a set of <code>.java</code> files with a genrule.)
</p>
<p>
Rules: if the rule (typically <code>genrule</code> or <code>filegroup</code>) generates
any of the files listed above, they will be used the same way as described for source
files.
</p>
<p>
Source files of type <code>.properties</code> are treated as resources.
</p>

<p>All other files are ignored, as long as there is at least one file of a
file type described above. Otherwise an error is raised.</p>

<p>
This argument is almost always required, except if you specify the <code>runtime_deps</code> argument.
</p>
2[]
,
*
nameA unique name for this target. �
�
add_exports�
Allow this library to access the given <code>module</code> or <code>package</code>.
<p>
This corresponds to the javac and JVM --add-exports= flags.
2[]�
�
	add_opens�
Allow this library to reflectively access the given <code>module</code> or
<code>package</code>.
<p>
This corresponds to the javac and JVM --add-opens= flags.
2[]K
I
bootclasspathRestricted API, do not use!*
BootClassPathInfo2None�
�
data�
The list of files needed by this library at runtime.
See general comments about <code>data</code> at
<a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>
  When building a <code>java_library</code>, Bazel doesn't put these files anywhere; if the
  <code>data</code> files are generated files then Bazel generates them. When building a
  test that depends on this <code>java_library</code> Bazel copies or links the
  <code>data</code> files into the runfiles area.
</p>
2[]�
�
deps�
The list of libraries to link into this library.
See general comments about <code>deps</code> at
<a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>
  The jars built by <code>java_library</code> rules listed in <code>deps</code> will be on
  the compile-time classpath of this rule. Furthermore the transitive closure of their
  <code>deps</code>, <code>runtime_deps</code> and <code>exports</code> will be on the
  runtime classpath.
</p>
<p>
  By contrast, targets in the <code>data</code> attribute are included in the runfiles but
  on neither the compile-time nor runtime classpath.
</p>
*
CcInfo*

JavaInfo2[]�
�
exported_plugins�
The list of <code><a href="#${link java_plugin}">java_plugin</a></code>s (e.g. annotation
processors) to export to libraries that directly depend on this library.
<p>
  The specified list of <code>java_plugin</code>s will be applied to any library which
  directly depends on this library, just as if that library had explicitly declared these
  labels in <code><a href="${link java_library.plugins}">plugins</a></code>.
</p>
*
JavaPluginInfo2[]�
�
exports�
Exported libraries.
<p>
  Listing rules here will make them available to parent rules, as if the parents explicitly
  depended on these rules. This is not true for regular (non-exported) <code>deps</code>.
</p>
<p>
  Summary: a rule <i>X</i> can access the code in <i>Y</i> if there exists a dependency
  path between them that begins with a <code>deps</code> edge followed by zero or more
  <code>exports</code> edges. Let's see some examples to illustrate this.
</p>
<p>
  Assume <i>A</i> depends on <i>B</i> and <i>B</i> depends on <i>C</i>. In this case
  C is a <em>transitive</em> dependency of A, so changing C's sources and rebuilding A will
  correctly rebuild everything. However A will not be able to use classes in C. To allow
  that, either A has to declare C in its <code>deps</code>, or B can make it easier for A
  (and anything that may depend on A) by declaring C in its (B's) <code>exports</code>
  attribute.
</p>
<p>
  The closure of exported libraries is available to all direct parent rules. Take a slightly
  different example: A depends on B, B depends on C and D, and also exports C but not D.
  Now A has access to C but not to D. Now, if C and D exported some libraries, C' and D'
  respectively, A could only access C' but not D'.
</p>
<p>
  Important: an exported rule is not a regular dependency. Sticking to the previous example,
  if B exports C and wants to also use C, it has to also list it in its own
  <code>deps</code>.
</p>
*

JavaInfo*
CcInfo2[]<
:
javabuilder_jvm_flagsRestricted API, do not use!2[]�
�
	javacopts�
Extra compiler options for this library.
Subject to <a href="make-variables.html">"Make variable"</a> substitution and
<a href="common-definitions.html#sh-tokenization">Bourne shell tokenization</a>.
<p>These compiler options are passed to javac after the global compiler options.</p>
2[]

licenses2[]�
�
	neverlink�
Whether this library should only be used for compilation and not at runtime.
Useful if the library will be provided by the runtime environment during execution. Examples
of such libraries are the IDE APIs for IDE plug-ins or <code>tools.jar</code> for anything
running on a standard JDK.
<p>
  Note that <code>neverlink = True</code> does not prevent the compiler from inlining material
  from this library into compilation targets that depend on it, as permitted by the Java
  Language Specification (e.g., <code>static final</code> constants of <code>String</code>
  or of primitive types). The preferred use case is therefore when the runtime library is
  identical to the compilation library.
</p>
<p>
  If the runtime library differs from the compilation library then you must ensure that it
  differs only in places that the JLS forbids compilers to inline (and that must hold for
  all future versions of the JLS).
</p>
2False�
�
plugins�
Java compiler plugins to run at compile-time.
Every <code>java_plugin</code> specified in this attribute will be run whenever this rule
is built. A library may also inherit plugins from dependencies that use
<code><a href="#java_library.exported_plugins">exported_plugins</a></code>. Resources
generated by the plugin will be included in the resulting jar of this rule.
*
JavaPluginInfo2[]�
�
proguard_specs�
Files to be used as Proguard specification.
These will describe the set of specifications to be used by Proguard. If specified,
they will be added to any <code>android_binary</code> target depending on this library.

The files included here must only have idempotent rules, namely -dontnote, -dontwarn,
assumenosideeffects, and rules that start with -keep. Other options can only appear in
<code>android_binary</code>'s proguard_specs, to ensure non-tautological merges.
2[]�
�
resource_strip_prefix�
The path prefix to strip from Java resources.
<p>
If specified, this path prefix is stripped from every file in the <code>resources</code>
attribute. It is an error for a resource file not to be under this directory. If not
specified (the default), the path of resource file is determined according to the same
logic as the Java package of source files. For example, a source file at
<code>stuff/java/foo/bar/a.txt</code> will be located at <code>foo/bar/a.txt</code>.
</p>
2""�
�
	resources�
A list of data files to include in a Java jar.
<p>
Resources may be source files or generated files.
</p>

<p>
If resources are specified, they will be bundled in the jar along with the usual
<code>.class</code> files produced by compilation. The location of the resources inside
of the jar file is determined by the project structure. Bazel first looks for Maven's
<a href="https://maven.apache.org/guides/introduction/introduction-to-the-standard-directory-layout.html">standard directory layout</a>,
(a "src" directory followed by a "resources" directory grandchild). If that is not
found, Bazel then looks for the topmost directory named "java" or "javatests" (so, for
example, if a resource is at <code>&lt;workspace root&gt;/x/java/y/java/z</code>, the
path of the resource will be <code>y/java/z</code>. This heuristic cannot be overridden,
however, the <code>resource_strip_prefix</code> attribute can be used to specify a
specific alternative directory for resource files.
2[]�
�
runtime_deps�
Libraries to make available to the final binary or test at runtime only.
Like ordinary <code>deps</code>, these will appear on the runtime classpath, but unlike
them, not on the compile-time classpath. Dependencies needed only at runtime should be
listed here. Dependency-analysis tools should ignore targets that appear in both
<code>runtime_deps</code> and <code>deps</code>.
*
CcInfo*

JavaInfo2[]�

�

srcs�

The list of source files that are processed to create the target.
This attribute is almost always required; see exceptions below.
<p>
Source files of type <code>.java</code> are compiled. In case of generated
<code>.java</code> files it is generally advisable to put the generating rule's name
here instead of the name of the file itself. This not only improves readability but
makes the rule more resilient to future changes: if the generating rule generates
different files in the future, you only need to fix one place: the <code>outs</code> of
the generating rule. You should not list the generating rule in <code>deps</code>
because it is a no-op.
</p>
<p>
Source files of type <code>.srcjar</code> are unpacked and compiled. (This is useful if
you need to generate a set of <code>.java</code> files with a genrule.)
</p>
<p>
Rules: if the rule (typically <code>genrule</code> or <code>filegroup</code>) generates
any of the files listed above, they will be used the same way as described for source
files.
</p>
<p>
Source files of type <code>.properties</code> are treated as resources.
</p>

<p>All other files are ignored, as long as there is at least one file of a
file type described above. Otherwise an error is raised.</p>

<p>
This argument is almost always required, except if you specify the <code>runtime_deps</code> argument.
</p>
2[]}
//java:java_library.bzlr`
$

rules_javajavajava_library.bzl*
java_libraryjava_library
-9
;?proto_java_library.bzl provides a java_library for proto files.�
7
build_stack_rules_protorules/privateexecution.bzl�executable_extension*�
q
executable_extension	
ctx (2N
executable_extension6@@build_stack_rules_proto//rules/private:execution.bzl
--�
D
build_stack_rules_protorules/privateproto_repository_tools.bzl�	proto_repository_toolsR�	
�
proto_repository_tools.
name"A unique name for this repository. 
go_cache �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 "GOCACHE"GOPATH"GO_REPOSITORY_USE_HOST_CACHE*]
proto_repository_toolsC@@build_stack_rules_proto//rules/private:proto_repository_tools.bzl
i)i)0
.
name"A unique name for this repository. 

go_cache �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
///rules/private:proto_repository_tools_srcs.bzlr�
I
build_stack_rules_protorules/privateproto_repository_tools_srcs.bzlH
PROTO_REPOSITORY_TOOLS_SRCSPROTO_REPOSITORY_TOOLS_SRCS
Rm
o�
//internal:common.bzlr�

gazelleinternal
common.bzl(
env_executeenv_execute
(3:
executable_extensionexecutable_extension
7K
M�
"//internal:go_repository_cache.bzlrl
,
gazelleinternalgo_repository_cache.bzl.
read_cache_envread_cache_env
5C
E��
I
build_stack_rules_protorules/privateproto_repository_tools_srcs.bzl��	PROTO_REPOSITORY_TOOLS_SRCSj��2��
(&@build_stack_rules_proto//:BUILD.bazel
64@build_stack_rules_proto//cmd/examplegen:BUILD.bazel
42@build_stack_rules_proto//cmd/examplegen:config.go
86@build_stack_rules_proto//cmd/examplegen:examplegen.go
75@build_stack_rules_proto//cmd/examplegen:generator.go
64@build_stack_rules_proto//cmd/examplegen:template.go
31@build_stack_rules_proto//cmd/gazelle:BUILD.bazel
/-@build_stack_rules_proto//cmd/gazelle:diff.go
53@build_stack_rules_proto//cmd/gazelle:fix-update.go
.,@build_stack_rules_proto//cmd/gazelle:fix.go
CA@build_stack_rules_proto//cmd/gazelle/internal/wspace:BUILD.bazel
A?@build_stack_rules_proto//cmd/gazelle/internal/wspace:finder.go
0.@build_stack_rules_proto//cmd/gazelle:langs.go
/-@build_stack_rules_proto//cmd/gazelle:main.go
75@build_stack_rules_proto//cmd/gazelle:metaresolver.go
0.@build_stack_rules_proto//cmd/gazelle:print.go
31@build_stack_rules_proto//cmd/gazelle:profiler.go
75@build_stack_rules_proto//cmd/gazelle:update-repos.go
1/@build_stack_rules_proto//cmd/gazelle:wspace.go
31@build_stack_rules_proto//cmd/gencopy:BUILD.bazel
20@build_stack_rules_proto//cmd/gencopy:gencopy.go
/-@build_stack_rules_proto//example:BUILD.bazel
64@build_stack_rules_proto//example/assets:BUILD.bazel
42@build_stack_rules_proto//example/assets:api.pb.go
<:@build_stack_rules_proto//example/assets:api_request.pb.go
=;@build_stack_rules_proto//example/assets:api_response.pb.go
64@build_stack_rules_proto//example/golden:BUILD.bazel
64@build_stack_rules_proto//example/person:BUILD.bazel
53@build_stack_rules_proto//example/place:BUILD.bazel
:8@build_stack_rules_proto//example/routeguide:BUILD.bazel
=;@build_stack_rules_proto//example/routeguide/cc:BUILD.bazel
?=@build_stack_rules_proto//example/routeguide/java:BUILD.bazel
@>@build_stack_rules_proto//example/routeguide/scala:BUILD.bazel
53@build_stack_rules_proto//example/thing:BUILD.bazel
20@build_stack_rules_proto//extensions:BUILD.bazel
75@build_stack_rules_proto//google/protobuf:BUILD.bazel
86@build_stack_rules_proto//language/example:BUILD.bazel
75@build_stack_rules_proto//language/example:example.go
A?@build_stack_rules_proto//language/proto_go_modules:BUILD.bazel
A?@build_stack_rules_proto//language/proto_go_modules:language.go
=;@build_stack_rules_proto//language/proto_go_modules:rule.go
97@build_stack_rules_proto//language/protobuf:BUILD.bazel
97@build_stack_rules_proto//language/protobuf:protobuf.go
+)@build_stack_rules_proto//pkg:BUILD.bazel
64@build_stack_rules_proto//pkg/goldentest:BUILD.bazel
31@build_stack_rules_proto//pkg/goldentest:cases.go
97@build_stack_rules_proto//pkg/language/noop:BUILD.bazel
53@build_stack_rules_proto//pkg/language/noop:noop.go
=;@build_stack_rules_proto//pkg/language/protobuf:BUILD.bazel
;9@build_stack_rules_proto//pkg/language/protobuf:config.go
86@build_stack_rules_proto//pkg/language/protobuf:fix.go
=;@build_stack_rules_proto//pkg/language/protobuf:generate.go
:8@build_stack_rules_proto//pkg/language/protobuf:kinds.go
97@build_stack_rules_proto//pkg/language/protobuf:lang.go
><@build_stack_rules_proto//pkg/language/protobuf:lifecycle.go
=;@build_stack_rules_proto//pkg/language/protobuf:override.go
<:@build_stack_rules_proto//pkg/language/protobuf:resolve.go
A?@build_stack_rules_proto//pkg/plugin/akka/akka_grpc:BUILD.bazel
MK@build_stack_rules_proto//pkg/plugin/akka/akka_grpc:protoc_gen_akka_grpc.go
;9@build_stack_rules_proto//pkg/plugin/bufbuild:BUILD.bazel
DB@build_stack_rules_proto//pkg/plugin/bufbuild:connect_es_plugin.go
<:@build_stack_rules_proto//pkg/plugin/bufbuild:es_plugin.go
:8@build_stack_rules_proto//pkg/plugin/builtin:BUILD.bazel
<:@build_stack_rules_proto//pkg/plugin/builtin:cpp_plugin.go
?=@build_stack_rules_proto//pkg/plugin/builtin:csharp_plugin.go
53@build_stack_rules_proto//pkg/plugin/builtin:doc.go
?=@build_stack_rules_proto//pkg/plugin/builtin:grpc_grpc_cpp.go
=;@build_stack_rules_proto//pkg/plugin/builtin:java_plugin.go
CA@build_stack_rules_proto//pkg/plugin/builtin:js_closure_plugin.go
B@@build_stack_rules_proto//pkg/plugin/builtin:js_common_plugin.go
=;@build_stack_rules_proto//pkg/plugin/builtin:objc_plugin.go
<:@build_stack_rules_proto//pkg/plugin/builtin:php_plugin.go
<:@build_stack_rules_proto//pkg/plugin/builtin:pyi_plugin.go
?=@build_stack_rules_proto//pkg/plugin/builtin:python_plugin.go
=;@build_stack_rules_proto//pkg/plugin/builtin:ruby_plugin.go
@>@build_stack_rules_proto//pkg/plugin/gogo/protobuf:BUILD.bazel
GE@build_stack_rules_proto//pkg/plugin/gogo/protobuf:protoc-gen-gogo.go
B@@build_stack_rules_proto//pkg/plugin/golang/protobuf:BUILD.bazel
GE@build_stack_rules_proto//pkg/plugin/golang/protobuf:protoc-gen-go.go
<:@build_stack_rules_proto//pkg/plugin/grpc/grpc:BUILD.bazel
JH@build_stack_rules_proto//pkg/plugin/grpc/grpc:protoc-gen-grpc-python.go
><@build_stack_rules_proto//pkg/plugin/grpc/grpcgo:BUILD.bazel
HF@build_stack_rules_proto//pkg/plugin/grpc/grpcgo:protoc-gen-go-grpc.go
@>@build_stack_rules_proto//pkg/plugin/grpc/grpcjava:BUILD.bazel
LJ@build_stack_rules_proto//pkg/plugin/grpc/grpcjava:protoc-gen-grpc-java.go
@>@build_stack_rules_proto//pkg/plugin/grpc/grpcnode:BUILD.bazel
LJ@build_stack_rules_proto//pkg/plugin/grpc/grpcnode:protoc-gen-grpc-node.go
?=@build_stack_rules_proto//pkg/plugin/grpc/grpcweb:BUILD.bazel
JH@build_stack_rules_proto//pkg/plugin/grpc/grpcweb:protoc-gen-grpc-web.go
LJ@build_stack_rules_proto//pkg/plugin/grpcecosystem/grpcgateway:BUILD.bazel
[Y@build_stack_rules_proto//pkg/plugin/grpcecosystem/grpcgateway:protoc-gen-grpc-gateway.go
B@@build_stack_rules_proto//pkg/plugin/scalapb/scalapb:BUILD.bazel
JH@build_stack_rules_proto//pkg/plugin/scalapb/scalapb:protoc_gen_scala.go
CA@build_stack_rules_proto//pkg/plugin/scalapb/zio_grpc:BUILD.bazel
NL@build_stack_rules_proto//pkg/plugin/scalapb/zio_grpc:protoc_gen_zio_grpc.go
A?@build_stack_rules_proto//pkg/plugin/stackb/grpc_js:BUILD.bazel
KI@build_stack_rules_proto//pkg/plugin/stackb/grpc_js:protoc-gen-grpc-js.go
DB@build_stack_rules_proto//pkg/plugin/stephenh/ts-proto:BUILD.bazel
OM@build_stack_rules_proto//pkg/plugin/stephenh/ts-proto:protoc-gen-ts-proto.go
64@build_stack_rules_proto//pkg/plugintest:BUILD.bazel
20@build_stack_rules_proto//pkg/plugintest:case.go
1/@build_stack_rules_proto//pkg/plugintest:doc.go
31@build_stack_rules_proto//pkg/plugintest:utils.go
20@build_stack_rules_proto//pkg/protoc:BUILD.bazel
64@build_stack_rules_proto//pkg/protoc:depsresolver.go
.,@build_stack_rules_proto//pkg/protoc:file.go
0.@build_stack_rules_proto//pkg/protoc:intent.go
97@build_stack_rules_proto//pkg/protoc:language_config.go
@>@build_stack_rules_proto//pkg/protoc:language_plugin_config.go
75@build_stack_rules_proto//pkg/protoc:language_rule.go
><@build_stack_rules_proto//pkg/protoc:language_rule_config.go
=;@build_stack_rules_proto//pkg/protoc:other_proto_library.go
1/@build_stack_rules_proto//pkg/protoc:package.go
86@build_stack_rules_proto//pkg/protoc:package_config.go
0.@build_stack_rules_proto//pkg/protoc:plugin.go
><@build_stack_rules_proto//pkg/protoc:plugin_configuration.go
86@build_stack_rules_proto//pkg/protoc:plugin_context.go
97@build_stack_rules_proto//pkg/protoc:plugin_registry.go
75@build_stack_rules_proto//pkg/protoc:proto_compile.go
@>@build_stack_rules_proto//pkg/protoc:proto_compiled_sources.go
><@build_stack_rules_proto//pkg/protoc:proto_descriptor_set.go
75@build_stack_rules_proto//pkg/protoc:proto_library.go
><@build_stack_rules_proto//pkg/protoc:protoc_configuration.go
20@build_stack_rules_proto//pkg/protoc:registry.go
20@build_stack_rules_proto//pkg/protoc:resolver.go
1/@build_stack_rules_proto//pkg/protoc:rewrite.go
75@build_stack_rules_proto//pkg/protoc:rule_provider.go
75@build_stack_rules_proto//pkg/protoc:rule_registry.go
31@build_stack_rules_proto//pkg/protoc:ruleindex.go
97@build_stack_rules_proto//pkg/protoc:starlark_plugin.go
75@build_stack_rules_proto//pkg/protoc:starlark_rule.go
75@build_stack_rules_proto//pkg/protoc:starlark_util.go
42@build_stack_rules_proto//pkg/protoc:syntaxutil.go
1/@build_stack_rules_proto//pkg/protoc:yconfig.go
97@build_stack_rules_proto//pkg/rule/rules_cc:BUILD.bazel
;9@build_stack_rules_proto//pkg/rule/rules_cc:cc_library.go
@>@build_stack_rules_proto//pkg/rule/rules_cc:grpc_cc_library.go
A?@build_stack_rules_proto//pkg/rule/rules_cc:proto_cc_library.go
><@build_stack_rules_proto//pkg/rule/rules_closure:BUILD.bazel
HF@build_stack_rules_proto//pkg/rule/rules_closure:closure_js_library.go
MK@build_stack_rules_proto//pkg/rule/rules_closure:grpc_closure_js_library.go
NL@build_stack_rules_proto//pkg/rule/rules_closure:proto_closure_js_library.go
97@build_stack_rules_proto//pkg/rule/rules_go:BUILD.bazel
;9@build_stack_rules_proto//pkg/rule/rules_go:go_library.go
;9@build_stack_rules_proto//pkg/rule/rules_java:BUILD.bazel
DB@build_stack_rules_proto//pkg/rule/rules_java:grpc_java_library.go
?=@build_stack_rules_proto//pkg/rule/rules_java:java_library.go
EC@build_stack_rules_proto//pkg/rule/rules_java:proto_java_library.go
=;@build_stack_rules_proto//pkg/rule/rules_nodejs:BUILD.bazel
HF@build_stack_rules_proto//pkg/rule/rules_nodejs:grpc_nodejs_library.go
HF@build_stack_rules_proto//pkg/rule/rules_nodejs:grpc_web_js_library.go
?=@build_stack_rules_proto//pkg/rule/rules_nodejs:js_library.go
IG@build_stack_rules_proto//pkg/rule/rules_nodejs:proto_nodejs_library.go
EC@build_stack_rules_proto//pkg/rule/rules_nodejs:proto_ts_library.go
=;@build_stack_rules_proto//pkg/rule/rules_python:BUILD.bazel
DB@build_stack_rules_proto//pkg/rule/rules_python:grpc_py_library.go
EC@build_stack_rules_proto//pkg/rule/rules_python:proto_py_library.go
?=@build_stack_rules_proto//pkg/rule/rules_python:py_library.go
<:@build_stack_rules_proto//pkg/rule/rules_scala:BUILD.bazel
A?@build_stack_rules_proto//pkg/rule/rules_scala:scala_library.go
GE@build_stack_rules_proto//pkg/rule/rules_scala:scala_proto_library.go
.,@build_stack_rules_proto//pkg/tools:tools.go
.,@build_stack_rules_proto//plugin:BUILD.bazel
=;@build_stack_rules_proto//plugin/akka/akka-grpc:BUILD.bazel
75@build_stack_rules_proto//plugin/bufbuild:BUILD.bazel
64@build_stack_rules_proto//plugin/builtin:BUILD.bazel
<:@build_stack_rules_proto//plugin/gogo/protobuf:BUILD.bazel
><@build_stack_rules_proto//plugin/golang/protobuf:BUILD.bazel
86@build_stack_rules_proto//plugin/grpc/grpc:BUILD.bazel
;9@build_stack_rules_proto//plugin/grpc/grpc-go:BUILD.bazel
=;@build_stack_rules_proto//plugin/grpc/grpc-java:BUILD.bazel
=;@build_stack_rules_proto//plugin/grpc/grpc-node:BUILD.bazel
<:@build_stack_rules_proto//plugin/grpc/grpc-web:BUILD.bazel
><@build_stack_rules_proto//plugin/scalapb/scalapb:BUILD.bazel
?=@build_stack_rules_proto//plugin/scalapb/zio-grpc:BUILD.bazel
=;@build_stack_rules_proto//plugin/stackb/grpc_js:BUILD.bazel
@>@build_stack_rules_proto//plugin/stephenh/ts-proto:BUILD.bazel
-+@build_stack_rules_proto//rules:BUILD.bazel
0.@build_stack_rules_proto//rules/cc:BUILD.bazel
0.@build_stack_rules_proto//rules/go:BUILD.bazel
20@build_stack_rules_proto//rules/java:BUILD.bazel
53@build_stack_rules_proto//rules/private:BUILD.bazel
GE@build_stack_rules_proto//rules/private:list_repository_tools_srcs.go
31@build_stack_rules_proto//rules/proto:BUILD.bazel
0.@build_stack_rules_proto//rules/py:BUILD.bazel
31@build_stack_rules_proto//rules/scala:BUILD.bazel
0.@build_stack_rules_proto//rules/ts:BUILD.bazel
1/@build_stack_rules_proto//toolchain:BUILD.bazel
75@build_stack_rules_proto//toolchain/scala:BUILD.bazel
-+@build_stack_rules_proto//tools:BUILD.bazel
WU@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/config:config.go
ZX@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/config:constants.go
SQ@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/flag:flag.go
`^@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/internal/module:module.go
b`@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/internal/version:version.go
`^@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/internal/wspace:finder.go
US@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/label:label.go
WU@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/language:base.go
ge@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/language/go:build_constraints.go
\Z@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/language/go:config.go
_]@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/language/go:constants.go
[Y@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/language/go:embed.go
^\@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/language/go:fileinfo.go
YW@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/language/go:fix.go
^\@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/language/go:generate.go
[Y@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/language/go:kinds.go
ZX@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/language/go:lang.go
][@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/language/go:modules.go
][@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/language/go:package.go
ca@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/language/go:platform_info.go
][@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/language/go:resolve.go
fd@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/language/go:std_package_list.go
b`@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/language/go:stdlib_links.go
\Z@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/language/go:update.go
[Y@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/language/go:utils.go
ZX@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/language/go:work.go
WU@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/language:lang.go
\Z@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/language:lifecycle.go
_]@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/language/proto:config.go
b`@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/language/proto:constants.go
a_@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/language/proto:fileinfo.go
\Z@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/language/proto:fix.go
a_@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/language/proto:generate.go
^\@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/language/proto:kinds.go
ig@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/language/proto:known_go_imports.go
fd@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/language/proto:known_imports.go
lj@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/language/proto:known_proto_imports.go
][@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/language/proto:lang.go
`^@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/language/proto:package.go
`^@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/language/proto:resolve.go
YW@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/language:update.go
TR@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/merger:fix.go
WU@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/merger:merger.go
XV@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/pathtools:path.go
US@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/repo:remote.go
SQ@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/repo:repo.go
XV@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/resolve:config.go
WU@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/resolve:index.go
YW@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/rule:directives.go
SQ@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/rule:expr.go
TR@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/rule:merge.go
WU@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/rule:platform.go
_]@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/rule:platform_strings.go
SQ@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/rule:rule.go
ZX@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/rule:sort_labels.go
TR@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/rule:types.go
TR@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/rule:value.go
ZX@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/testtools:config.go
YW@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/testtools:files.go
TR@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/walk:cache.go
US@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/walk:config.go
VT@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/walk:dirinfo.go
SQ@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/walk:walk.go
PN@build_stack_rules_proto//vendor/github.com/bazelbuild/buildtools/build:lex.go
TR@build_stack_rules_proto//vendor/github.com/bazelbuild/buildtools/build:parse.y.go
RP@build_stack_rules_proto//vendor/github.com/bazelbuild/buildtools/build:print.go
RP@build_stack_rules_proto//vendor/github.com/bazelbuild/buildtools/build:quote.go
TR@build_stack_rules_proto//vendor/github.com/bazelbuild/buildtools/build:rewrite.go
QO@build_stack_rules_proto//vendor/github.com/bazelbuild/buildtools/build:rule.go
SQ@build_stack_rules_proto//vendor/github.com/bazelbuild/buildtools/build:syntax.go
RP@build_stack_rules_proto//vendor/github.com/bazelbuild/buildtools/build:utils.go
QO@build_stack_rules_proto//vendor/github.com/bazelbuild/buildtools/build:walk.go
TR@build_stack_rules_proto//vendor/github.com/bazelbuild/buildtools/labels:labels.go
XV@build_stack_rules_proto//vendor/github.com/bazelbuild/buildtools/tables:jsonparser.go
TR@build_stack_rules_proto//vendor/github.com/bazelbuild/buildtools/tables:tables.go
ZX@build_stack_rules_proto//vendor/github.com/bazelbuild/rules_go/go/runfiles:directory.go
SQ@build_stack_rules_proto//vendor/github.com/bazelbuild/rules_go/go/runfiles:fs.go
WU@build_stack_rules_proto//vendor/github.com/bazelbuild/rules_go/go/runfiles:global.go
YW@build_stack_rules_proto//vendor/github.com/bazelbuild/rules_go/go/runfiles:manifest.go
YW@build_stack_rules_proto//vendor/github.com/bazelbuild/rules_go/go/runfiles:runfiles.go
YW@build_stack_rules_proto//vendor/github.com/bazelbuild/rules_go/go/tools/bazel:bazel.go
\Z@build_stack_rules_proto//vendor/github.com/bazelbuild/rules_go/go/tools/bazel:runfiles.go
NL@build_stack_rules_proto//vendor/github.com/bmatcuk/doublestar:doublestar.go
QO@build_stack_rules_proto//vendor/github.com/bmatcuk/doublestar/v4:doublestar.go
KI@build_stack_rules_proto//vendor/github.com/bmatcuk/doublestar/v4:glob.go
RP@build_stack_rules_proto//vendor/github.com/bmatcuk/doublestar/v4:globoptions.go
OM@build_stack_rules_proto//vendor/github.com/bmatcuk/doublestar/v4:globwalk.go
LJ@build_stack_rules_proto//vendor/github.com/bmatcuk/doublestar/v4:match.go
LJ@build_stack_rules_proto//vendor/github.com/bmatcuk/doublestar/v4:utils.go
OM@build_stack_rules_proto//vendor/github.com/bmatcuk/doublestar/v4:validate.go
LJ@build_stack_rules_proto//vendor/github.com/davecgh/go-spew/spew:bypass.go
PN@build_stack_rules_proto//vendor/github.com/davecgh/go-spew/spew:bypasssafe.go
LJ@build_stack_rules_proto//vendor/github.com/davecgh/go-spew/spew:common.go
LJ@build_stack_rules_proto//vendor/github.com/davecgh/go-spew/spew:config.go
IG@build_stack_rules_proto//vendor/github.com/davecgh/go-spew/spew:doc.go
JH@build_stack_rules_proto//vendor/github.com/davecgh/go-spew/spew:dump.go
LJ@build_stack_rules_proto//vendor/github.com/davecgh/go-spew/spew:format.go
JH@build_stack_rules_proto//vendor/github.com/davecgh/go-spew/spew:spew.go
GE@build_stack_rules_proto//vendor/github.com/emicklei/proto:comment.go
GE@build_stack_rules_proto//vendor/github.com/emicklei/proto:edition.go
DB@build_stack_rules_proto//vendor/github.com/emicklei/proto:enum.go
JH@build_stack_rules_proto//vendor/github.com/emicklei/proto:extensions.go
EC@build_stack_rules_proto//vendor/github.com/emicklei/proto:field.go
EC@build_stack_rules_proto//vendor/github.com/emicklei/proto:group.go
FD@build_stack_rules_proto//vendor/github.com/emicklei/proto:import.go
HF@build_stack_rules_proto//vendor/github.com/emicklei/proto:literals.go
GE@build_stack_rules_proto//vendor/github.com/emicklei/proto:message.go
LJ@build_stack_rules_proto//vendor/github.com/emicklei/proto:noop_visitor.go
EC@build_stack_rules_proto//vendor/github.com/emicklei/proto:oneof.go
FD@build_stack_rules_proto//vendor/github.com/emicklei/proto:option.go
GE@build_stack_rules_proto//vendor/github.com/emicklei/proto:package.go
OM@build_stack_rules_proto//vendor/github.com/emicklei/proto:parent_accessor.go
FD@build_stack_rules_proto//vendor/github.com/emicklei/proto:parser.go
EC@build_stack_rules_proto//vendor/github.com/emicklei/proto:proto.go
EC@build_stack_rules_proto//vendor/github.com/emicklei/proto:range.go
HF@build_stack_rules_proto//vendor/github.com/emicklei/proto:reserved.go
GE@build_stack_rules_proto//vendor/github.com/emicklei/proto:service.go
FD@build_stack_rules_proto//vendor/github.com/emicklei/proto:syntax.go
EC@build_stack_rules_proto//vendor/github.com/emicklei/proto:token.go
GE@build_stack_rules_proto//vendor/github.com/emicklei/proto:visitor.go
DB@build_stack_rules_proto//vendor/github.com/emicklei/proto:walk.go
JH@build_stack_rules_proto//vendor/github.com/gogo/protobuf/proto:clone.go
PN@build_stack_rules_proto//vendor/github.com/gogo/protobuf/proto:custom_gogo.go
KI@build_stack_rules_proto//vendor/github.com/gogo/protobuf/proto:decode.go
OM@build_stack_rules_proto//vendor/github.com/gogo/protobuf/proto:deprecated.go
LJ@build_stack_rules_proto//vendor/github.com/gogo/protobuf/proto:discard.go
MK@build_stack_rules_proto//vendor/github.com/gogo/protobuf/proto:duration.go
RP@build_stack_rules_proto//vendor/github.com/gogo/protobuf/proto:duration_gogo.go
KI@build_stack_rules_proto//vendor/github.com/gogo/protobuf/proto:encode.go
PN@build_stack_rules_proto//vendor/github.com/gogo/protobuf/proto:encode_gogo.go
JH@build_stack_rules_proto//vendor/github.com/gogo/protobuf/proto:equal.go
OM@build_stack_rules_proto//vendor/github.com/gogo/protobuf/proto:extensions.go
TR@build_stack_rules_proto//vendor/github.com/gogo/protobuf/proto:extensions_gogo.go
HF@build_stack_rules_proto//vendor/github.com/gogo/protobuf/proto:lib.go
MK@build_stack_rules_proto//vendor/github.com/gogo/protobuf/proto:lib_gogo.go
PN@build_stack_rules_proto//vendor/github.com/gogo/protobuf/proto:message_set.go
TR@build_stack_rules_proto//vendor/github.com/gogo/protobuf/proto:pointer_reflect.go
YW@build_stack_rules_proto//vendor/github.com/gogo/protobuf/proto:pointer_reflect_gogo.go
SQ@build_stack_rules_proto//vendor/github.com/gogo/protobuf/proto:pointer_unsafe.go
XV@build_stack_rules_proto//vendor/github.com/gogo/protobuf/proto:pointer_unsafe_gogo.go
OM@build_stack_rules_proto//vendor/github.com/gogo/protobuf/proto:properties.go
TR@build_stack_rules_proto//vendor/github.com/gogo/protobuf/proto:properties_gogo.go
NL@build_stack_rules_proto//vendor/github.com/gogo/protobuf/proto:skip_gogo.go
RP@build_stack_rules_proto//vendor/github.com/gogo/protobuf/proto:table_marshal.go
WU@build_stack_rules_proto//vendor/github.com/gogo/protobuf/proto:table_marshal_gogo.go
PN@build_stack_rules_proto//vendor/github.com/gogo/protobuf/proto:table_merge.go
TR@build_stack_rules_proto//vendor/github.com/gogo/protobuf/proto:table_unmarshal.go
YW@build_stack_rules_proto//vendor/github.com/gogo/protobuf/proto:table_unmarshal_gogo.go
IG@build_stack_rules_proto//vendor/github.com/gogo/protobuf/proto:text.go
NL@build_stack_rules_proto//vendor/github.com/gogo/protobuf/proto:text_gogo.go
PN@build_stack_rules_proto//vendor/github.com/gogo/protobuf/proto:text_parser.go
NL@build_stack_rules_proto//vendor/github.com/gogo/protobuf/proto:timestamp.go
SQ@build_stack_rules_proto//vendor/github.com/gogo/protobuf/proto:timestamp_gogo.go
MK@build_stack_rules_proto//vendor/github.com/gogo/protobuf/proto:wrappers.go
RP@build_stack_rules_proto//vendor/github.com/gogo/protobuf/proto:wrappers_gogo.go
QO@build_stack_rules_proto//vendor/github.com/google/go-cmp/cmp/cmpopts:equate.go
QO@build_stack_rules_proto//vendor/github.com/google/go-cmp/cmp/cmpopts:ignore.go
OM@build_stack_rules_proto//vendor/github.com/google/go-cmp/cmp/cmpopts:sort.go
XV@build_stack_rules_proto//vendor/github.com/google/go-cmp/cmp/cmpopts:struct_filter.go
PN@build_stack_rules_proto//vendor/github.com/google/go-cmp/cmp/cmpopts:xform.go
JH@build_stack_rules_proto//vendor/github.com/google/go-cmp/cmp:compare.go
IG@build_stack_rules_proto//vendor/github.com/google/go-cmp/cmp:export.go
^\@build_stack_rules_proto//vendor/github.com/google/go-cmp/cmp/internal/diff:debug_disable.go
][@build_stack_rules_proto//vendor/github.com/google/go-cmp/cmp/internal/diff:debug_enable.go
US@build_stack_rules_proto//vendor/github.com/google/go-cmp/cmp/internal/diff:diff.go
WU@build_stack_rules_proto//vendor/github.com/google/go-cmp/cmp/internal/flags:flags.go
YW@build_stack_rules_proto//vendor/github.com/google/go-cmp/cmp/internal/function:func.go
VT@build_stack_rules_proto//vendor/github.com/google/go-cmp/cmp/internal/value:name.go
YW@build_stack_rules_proto//vendor/github.com/google/go-cmp/cmp/internal/value:pointer.go
VT@build_stack_rules_proto//vendor/github.com/google/go-cmp/cmp/internal/value:sort.go
JH@build_stack_rules_proto//vendor/github.com/google/go-cmp/cmp:options.go
GE@build_stack_rules_proto//vendor/github.com/google/go-cmp/cmp:path.go
IG@build_stack_rules_proto//vendor/github.com/google/go-cmp/cmp:report.go
QO@build_stack_rules_proto//vendor/github.com/google/go-cmp/cmp:report_compare.go
TR@build_stack_rules_proto//vendor/github.com/google/go-cmp/cmp:report_references.go
QO@build_stack_rules_proto//vendor/github.com/google/go-cmp/cmp:report_reflect.go
PN@build_stack_rules_proto//vendor/github.com/google/go-cmp/cmp:report_slices.go
NL@build_stack_rules_proto//vendor/github.com/google/go-cmp/cmp:report_text.go
OM@build_stack_rules_proto//vendor/github.com/google/go-cmp/cmp:report_value.go
SQ@build_stack_rules_proto//vendor/github.com/pmezard/go-difflib/difflib:difflib.go
ZX@build_stack_rules_proto//vendor/github.com/stretchr/testify/assert:assertion_compare.go
YW@build_stack_rules_proto//vendor/github.com/stretchr/testify/assert:assertion_format.go
ZX@build_stack_rules_proto//vendor/github.com/stretchr/testify/assert:assertion_forward.go
XV@build_stack_rules_proto//vendor/github.com/stretchr/testify/assert:assertion_order.go
SQ@build_stack_rules_proto//vendor/github.com/stretchr/testify/assert:assertions.go
LJ@build_stack_rules_proto//vendor/github.com/stretchr/testify/assert:doc.go
OM@build_stack_rules_proto//vendor/github.com/stretchr/testify/assert:errors.go
[Y@build_stack_rules_proto//vendor/github.com/stretchr/testify/assert:forward_assertions.go
XV@build_stack_rules_proto//vendor/github.com/stretchr/testify/assert:http_assertions.go
YW@build_stack_rules_proto//vendor/github.com/stretchr/testify/assert/yaml:yaml_custom.go
ZX@build_stack_rules_proto//vendor/github.com/stretchr/testify/assert/yaml:yaml_default.go
WU@build_stack_rules_proto//vendor/github.com/stretchr/testify/assert/yaml:yaml_fail.go
NL@build_stack_rules_proto//vendor/go.starlark.net/internal/compile:compile.go
MK@build_stack_rules_proto//vendor/go.starlark.net/internal/compile:serial.go
JH@build_stack_rules_proto//vendor/go.starlark.net/internal/spell:spell.go
EC@build_stack_rules_proto//vendor/go.starlark.net/resolve:binding.go
EC@build_stack_rules_proto//vendor/go.starlark.net/resolve:resolve.go
DB@build_stack_rules_proto//vendor/go.starlark.net/starlark:debug.go
CA@build_stack_rules_proto//vendor/go.starlark.net/starlark:eval.go
HF@build_stack_rules_proto//vendor/go.starlark.net/starlark:hashtable.go
B@@build_stack_rules_proto//vendor/go.starlark.net/starlark:int.go
JH@build_stack_rules_proto//vendor/go.starlark.net/starlark:int_generic.go
JH@build_stack_rules_proto//vendor/go.starlark.net/starlark:int_posix64.go
EC@build_stack_rules_proto//vendor/go.starlark.net/starlark:interp.go
CA@build_stack_rules_proto//vendor/go.starlark.net/starlark:iter.go
FD@build_stack_rules_proto//vendor/go.starlark.net/starlark:library.go
FD@build_stack_rules_proto//vendor/go.starlark.net/starlark:profile.go
EC@build_stack_rules_proto//vendor/go.starlark.net/starlark:unpack.go
DB@build_stack_rules_proto//vendor/go.starlark.net/starlark:value.go
KI@build_stack_rules_proto//vendor/go.starlark.net/starlarkstruct:module.go
KI@build_stack_rules_proto//vendor/go.starlark.net/starlarkstruct:struct.go
DB@build_stack_rules_proto//vendor/go.starlark.net/syntax:options.go
B@@build_stack_rules_proto//vendor/go.starlark.net/syntax:parse.go
B@@build_stack_rules_proto//vendor/go.starlark.net/syntax:quote.go
A?@build_stack_rules_proto//vendor/go.starlark.net/syntax:scan.go
CA@build_stack_rules_proto//vendor/go.starlark.net/syntax:syntax.go
A?@build_stack_rules_proto//vendor/go.starlark.net/syntax:walk.go
QO@build_stack_rules_proto//vendor/golang.org/x/mod/internal/lazyregexp:lazyre.go
DB@build_stack_rules_proto//vendor/golang.org/x/mod/modfile:print.go
CA@build_stack_rules_proto//vendor/golang.org/x/mod/modfile:read.go
CA@build_stack_rules_proto//vendor/golang.org/x/mod/modfile:rule.go
CA@build_stack_rules_proto//vendor/golang.org/x/mod/modfile:work.go
DB@build_stack_rules_proto//vendor/golang.org/x/mod/module:module.go
DB@build_stack_rules_proto//vendor/golang.org/x/mod/module:pseudo.go
DB@build_stack_rules_proto//vendor/golang.org/x/mod/semver:semver.go
IG@build_stack_rules_proto//vendor/golang.org/x/net/http/httpguts:guts.go
LJ@build_stack_rules_proto//vendor/golang.org/x/net/http/httpguts:httplex.go
B@@build_stack_rules_proto//vendor/golang.org/x/net/http2:ascii.go
DB@build_stack_rules_proto//vendor/golang.org/x/net/http2:ciphers.go
MK@build_stack_rules_proto//vendor/golang.org/x/net/http2:client_conn_pool.go
CA@build_stack_rules_proto//vendor/golang.org/x/net/http2:config.go
IG@build_stack_rules_proto//vendor/golang.org/x/net/http2:config_go124.go
MK@build_stack_rules_proto//vendor/golang.org/x/net/http2:config_pre_go124.go
GE@build_stack_rules_proto//vendor/golang.org/x/net/http2:databuffer.go
CA@build_stack_rules_proto//vendor/golang.org/x/net/http2:errors.go
A?@build_stack_rules_proto//vendor/golang.org/x/net/http2:flow.go
B@@build_stack_rules_proto//vendor/golang.org/x/net/http2:frame.go
DB@build_stack_rules_proto//vendor/golang.org/x/net/http2:gotrack.go
IG@build_stack_rules_proto//vendor/golang.org/x/net/http2/hpack:encode.go
HF@build_stack_rules_proto//vendor/golang.org/x/net/http2/hpack:hpack.go
JH@build_stack_rules_proto//vendor/golang.org/x/net/http2/hpack:huffman.go
OM@build_stack_rules_proto//vendor/golang.org/x/net/http2/hpack:static_table.go
IG@build_stack_rules_proto//vendor/golang.org/x/net/http2/hpack:tables.go
B@@build_stack_rules_proto//vendor/golang.org/x/net/http2:http2.go
A?@build_stack_rules_proto//vendor/golang.org/x/net/http2:pipe.go
CA@build_stack_rules_proto//vendor/golang.org/x/net/http2:server.go
B@@build_stack_rules_proto//vendor/golang.org/x/net/http2:timer.go
FD@build_stack_rules_proto//vendor/golang.org/x/net/http2:transport.go
HF@build_stack_rules_proto//vendor/golang.org/x/net/http2:unencrypted.go
B@@build_stack_rules_proto//vendor/golang.org/x/net/http2:write.go
GE@build_stack_rules_proto//vendor/golang.org/x/net/http2:writesched.go
PN@build_stack_rules_proto//vendor/golang.org/x/net/http2:writesched_priority.go
NL@build_stack_rules_proto//vendor/golang.org/x/net/http2:writesched_random.go
RP@build_stack_rules_proto//vendor/golang.org/x/net/http2:writesched_roundrobin.go
A?@build_stack_rules_proto//vendor/golang.org/x/net/idna:go118.go
FD@build_stack_rules_proto//vendor/golang.org/x/net/idna:idna10.0.0.go
EC@build_stack_rules_proto//vendor/golang.org/x/net/idna:idna9.0.0.go
EC@build_stack_rules_proto//vendor/golang.org/x/net/idna:pre_go118.go
DB@build_stack_rules_proto//vendor/golang.org/x/net/idna:punycode.go
HF@build_stack_rules_proto//vendor/golang.org/x/net/idna:tables10.0.0.go
HF@build_stack_rules_proto//vendor/golang.org/x/net/idna:tables11.0.0.go
HF@build_stack_rules_proto//vendor/golang.org/x/net/idna:tables12.0.0.go
HF@build_stack_rules_proto//vendor/golang.org/x/net/idna:tables13.0.0.go
HF@build_stack_rules_proto//vendor/golang.org/x/net/idna:tables15.0.0.go
GE@build_stack_rules_proto//vendor/golang.org/x/net/idna:tables9.0.0.go
@>@build_stack_rules_proto//vendor/golang.org/x/net/idna:trie.go
FD@build_stack_rules_proto//vendor/golang.org/x/net/idna:trie12.0.0.go
FD@build_stack_rules_proto//vendor/golang.org/x/net/idna:trie13.0.0.go
CA@build_stack_rules_proto//vendor/golang.org/x/net/idna:trieval.go
PN@build_stack_rules_proto//vendor/golang.org/x/net/internal/httpcommon:ascii.go
TR@build_stack_rules_proto//vendor/golang.org/x/net/internal/httpcommon:headermap.go
RP@build_stack_rules_proto//vendor/golang.org/x/net/internal/httpcommon:request.go
US@build_stack_rules_proto//vendor/golang.org/x/net/internal/timeseries:timeseries.go
CA@build_stack_rules_proto//vendor/golang.org/x/net/trace:events.go
FD@build_stack_rules_proto//vendor/golang.org/x/net/trace:histogram.go
B@@build_stack_rules_proto//vendor/golang.org/x/net/trace:trace.go
IG@build_stack_rules_proto//vendor/golang.org/x/sync/errgroup:errgroup.go
FD@build_stack_rules_proto//vendor/golang.org/x/sys/execabs:execabs.go
LJ@build_stack_rules_proto//vendor/golang.org/x/sys/execabs:execabs_go118.go
LJ@build_stack_rules_proto//vendor/golang.org/x/sys/execabs:execabs_go119.go
JH@build_stack_rules_proto//vendor/golang.org/x/sys/unix:affinity_linux.go
CA@build_stack_rules_proto//vendor/golang.org/x/sys/unix:aliases.go
@>@build_stack_rules_proto//vendor/golang.org/x/sys/unix:auxv.go
LJ@build_stack_rules_proto//vendor/golang.org/x/sys/unix:auxv_unsupported.go
KI@build_stack_rules_proto//vendor/golang.org/x/sys/unix:bluetooth_linux.go
FD@build_stack_rules_proto//vendor/golang.org/x/sys/unix:bpxsvc_zos.go
GE@build_stack_rules_proto//vendor/golang.org/x/sys/unix:cap_freebsd.go
EC@build_stack_rules_proto//vendor/golang.org/x/sys/unix:constants.go
GE@build_stack_rules_proto//vendor/golang.org/x/sys/unix:dev_aix_ppc.go
IG@build_stack_rules_proto//vendor/golang.org/x/sys/unix:dev_aix_ppc64.go
FD@build_stack_rules_proto//vendor/golang.org/x/sys/unix:dev_darwin.go
IG@build_stack_rules_proto//vendor/golang.org/x/sys/unix:dev_dragonfly.go
GE@build_stack_rules_proto//vendor/golang.org/x/sys/unix:dev_freebsd.go
EC@build_stack_rules_proto//vendor/golang.org/x/sys/unix:dev_linux.go
FD@build_stack_rules_proto//vendor/golang.org/x/sys/unix:dev_netbsd.go
GE@build_stack_rules_proto//vendor/golang.org/x/sys/unix:dev_openbsd.go
CA@build_stack_rules_proto//vendor/golang.org/x/sys/unix:dev_zos.go
B@@build_stack_rules_proto//vendor/golang.org/x/sys/unix:dirent.go
FD@build_stack_rules_proto//vendor/golang.org/x/sys/unix:endian_big.go
IG@build_stack_rules_proto//vendor/golang.org/x/sys/unix:endian_little.go
DB@build_stack_rules_proto//vendor/golang.org/x/sys/unix:env_unix.go
A?@build_stack_rules_proto//vendor/golang.org/x/sys/unix:fcntl.go
HF@build_stack_rules_proto//vendor/golang.org/x/sys/unix:fcntl_darwin.go
MK@build_stack_rules_proto//vendor/golang.org/x/sys/unix:fcntl_linux_32bit.go
A?@build_stack_rules_proto//vendor/golang.org/x/sys/unix:fdset.go
A?@build_stack_rules_proto//vendor/golang.org/x/sys/unix:gccgo.go
MK@build_stack_rules_proto//vendor/golang.org/x/sys/unix:gccgo_linux_amd64.go
GE@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ifreq_linux.go
GE@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ioctl_linux.go
HF@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ioctl_signed.go
JH@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ioctl_unsigned.go
EC@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ioctl_zos.go
IG@build_stack_rules_proto//vendor/golang.org/x/sys/unix:mmap_nomremap.go
B@@build_stack_rules_proto//vendor/golang.org/x/sys/unix:mremap.go
IG@build_stack_rules_proto//vendor/golang.org/x/sys/unix:pagesize_unix.go
JH@build_stack_rules_proto//vendor/golang.org/x/sys/unix:pledge_openbsd.go
IG@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ptrace_darwin.go
FD@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ptrace_ios.go
@>@build_stack_rules_proto//vendor/golang.org/x/sys/unix:race.go
A?@build_stack_rules_proto//vendor/golang.org/x/sys/unix:race0.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/unix:readdirent_getdents.go
TR@build_stack_rules_proto//vendor/golang.org/x/sys/unix:readdirent_getdirentries.go
NL@build_stack_rules_proto//vendor/golang.org/x/sys/unix:sockcmsg_dragonfly.go
JH@build_stack_rules_proto//vendor/golang.org/x/sys/unix:sockcmsg_linux.go
IG@build_stack_rules_proto//vendor/golang.org/x/sys/unix:sockcmsg_unix.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/unix:sockcmsg_unix_other.go
HF@build_stack_rules_proto//vendor/golang.org/x/sys/unix:sockcmsg_zos.go
CA@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall.go
GE@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_aix.go
KI@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_aix_ppc.go
MK@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_aix_ppc64.go
GE@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_bsd.go
JH@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_darwin.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_darwin_amd64.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_darwin_arm64.go
TR@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_darwin_libSystem.go
MK@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_dragonfly.go
SQ@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_dragonfly_amd64.go
KI@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_freebsd.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_freebsd_386.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_freebsd_amd64.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_freebsd_arm.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_freebsd_arm64.go
SQ@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_freebsd_riscv64.go
HF@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_hurd.go
LJ@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_hurd_386.go
KI@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_illumos.go
IG@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_linux.go
MK@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_linux_386.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_linux_alarm.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_linux_amd64.go
RP@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_linux_amd64_gc.go
MK@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_linux_arm.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_linux_arm64.go
LJ@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_linux_gc.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_linux_gc_386.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_linux_gc_arm.go
SQ@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_linux_gccgo_386.go
SQ@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_linux_gccgo_arm.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_linux_loong64.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_linux_mips64x.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_linux_mipsx.go
MK@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_linux_ppc.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_linux_ppc64x.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_linux_riscv64.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_linux_s390x.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_linux_sparc64.go
JH@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_netbsd.go
NL@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_netbsd_386.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_netbsd_amd64.go
NL@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_netbsd_arm.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_netbsd_arm64.go
KI@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_openbsd.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_openbsd_386.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_openbsd_amd64.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_openbsd_arm.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_openbsd_arm64.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_openbsd_libc.go
RP@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_openbsd_mips64.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_openbsd_ppc64.go
SQ@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_openbsd_riscv64.go
KI@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_solaris.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_solaris_amd64.go
HF@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_unix.go
KI@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_unix_gc.go
RP@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_unix_gc_ppc64x.go
MK@build_stack_rules_proto//vendor/golang.org/x/sys/unix:syscall_zos_s390x.go
IG@build_stack_rules_proto//vendor/golang.org/x/sys/unix:sysvshm_linux.go
HF@build_stack_rules_proto//vendor/golang.org/x/sys/unix:sysvshm_unix.go
NL@build_stack_rules_proto//vendor/golang.org/x/sys/unix:sysvshm_unix_other.go
FD@build_stack_rules_proto//vendor/golang.org/x/sys/unix:timestruct.go
JH@build_stack_rules_proto//vendor/golang.org/x/sys/unix:unveil_openbsd.go
LJ@build_stack_rules_proto//vendor/golang.org/x/sys/unix:vgetrandom_linux.go
RP@build_stack_rules_proto//vendor/golang.org/x/sys/unix:vgetrandom_unsupported.go
EC@build_stack_rules_proto//vendor/golang.org/x/sys/unix:xattr_bsd.go
KI@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zerrors_aix_ppc.go
MK@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zerrors_aix_ppc64.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zerrors_darwin_amd64.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zerrors_darwin_arm64.go
SQ@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zerrors_dragonfly_amd64.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zerrors_freebsd_386.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zerrors_freebsd_amd64.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zerrors_freebsd_arm.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zerrors_freebsd_arm64.go
SQ@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zerrors_freebsd_riscv64.go
IG@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zerrors_linux.go
MK@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zerrors_linux_386.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zerrors_linux_amd64.go
MK@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zerrors_linux_arm.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zerrors_linux_arm64.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zerrors_linux_loong64.go
NL@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zerrors_linux_mips.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zerrors_linux_mips64.go
RP@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zerrors_linux_mips64le.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zerrors_linux_mipsle.go
MK@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zerrors_linux_ppc.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zerrors_linux_ppc64.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zerrors_linux_ppc64le.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zerrors_linux_riscv64.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zerrors_linux_s390x.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zerrors_linux_sparc64.go
NL@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zerrors_netbsd_386.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zerrors_netbsd_amd64.go
NL@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zerrors_netbsd_arm.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zerrors_netbsd_arm64.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zerrors_openbsd_386.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zerrors_openbsd_amd64.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zerrors_openbsd_arm.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zerrors_openbsd_arm64.go
RP@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zerrors_openbsd_mips64.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zerrors_openbsd_ppc64.go
SQ@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zerrors_openbsd_riscv64.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zerrors_solaris_amd64.go
MK@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zerrors_zos_s390x.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zptrace_armnn_linux.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zptrace_linux_arm64.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zptrace_mipsnn_linux.go
RP@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zptrace_mipsnnle_linux.go
MK@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zptrace_x86_linux.go
LJ@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_aix_ppc.go
NL@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_aix_ppc64.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_aix_ppc64_gc.go
TR@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_aix_ppc64_gccgo.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_darwin_amd64.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_darwin_arm64.go
TR@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_dragonfly_amd64.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_freebsd_386.go
RP@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_freebsd_amd64.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_freebsd_arm.go
RP@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_freebsd_arm64.go
TR@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_freebsd_riscv64.go
RP@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_illumos_amd64.go
JH@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_linux.go
NL@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_linux_386.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_linux_amd64.go
NL@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_linux_arm.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_linux_arm64.go
RP@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_linux_loong64.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_linux_mips.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_linux_mips64.go
SQ@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_linux_mips64le.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_linux_mipsle.go
NL@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_linux_ppc.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_linux_ppc64.go
RP@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_linux_ppc64le.go
RP@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_linux_riscv64.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_linux_s390x.go
RP@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_linux_sparc64.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_netbsd_386.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_netbsd_amd64.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_netbsd_arm.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_netbsd_arm64.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_openbsd_386.go
RP@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_openbsd_amd64.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_openbsd_arm.go
RP@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_openbsd_arm64.go
SQ@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_openbsd_mips64.go
RP@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_openbsd_ppc64.go
TR@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_openbsd_riscv64.go
RP@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_solaris_amd64.go
NL@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsyscall_zos_s390x.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysctl_openbsd_386.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysctl_openbsd_amd64.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysctl_openbsd_arm.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysctl_openbsd_arm64.go
RP@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysctl_openbsd_mips64.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysctl_openbsd_ppc64.go
SQ@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysctl_openbsd_riscv64.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysnum_darwin_amd64.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysnum_darwin_arm64.go
SQ@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysnum_dragonfly_amd64.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysnum_freebsd_386.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysnum_freebsd_amd64.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysnum_freebsd_arm.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysnum_freebsd_arm64.go
SQ@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysnum_freebsd_riscv64.go
MK@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysnum_linux_386.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysnum_linux_amd64.go
MK@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysnum_linux_arm.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysnum_linux_arm64.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysnum_linux_loong64.go
NL@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysnum_linux_mips.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysnum_linux_mips64.go
RP@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysnum_linux_mips64le.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysnum_linux_mipsle.go
MK@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysnum_linux_ppc.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysnum_linux_ppc64.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysnum_linux_ppc64le.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysnum_linux_riscv64.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysnum_linux_s390x.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysnum_linux_sparc64.go
NL@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysnum_netbsd_386.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysnum_netbsd_amd64.go
NL@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysnum_netbsd_arm.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysnum_netbsd_arm64.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysnum_openbsd_386.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysnum_openbsd_amd64.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysnum_openbsd_arm.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysnum_openbsd_arm64.go
RP@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysnum_openbsd_mips64.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysnum_openbsd_ppc64.go
SQ@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysnum_openbsd_riscv64.go
MK@build_stack_rules_proto//vendor/golang.org/x/sys/unix:zsysnum_zos_s390x.go
JH@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ztypes_aix_ppc.go
LJ@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ztypes_aix_ppc64.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ztypes_darwin_amd64.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ztypes_darwin_arm64.go
RP@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ztypes_dragonfly_amd64.go
NL@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ztypes_freebsd_386.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ztypes_freebsd_amd64.go
NL@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ztypes_freebsd_arm.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ztypes_freebsd_arm64.go
RP@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ztypes_freebsd_riscv64.go
HF@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ztypes_linux.go
LJ@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ztypes_linux_386.go
NL@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ztypes_linux_amd64.go
LJ@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ztypes_linux_arm.go
NL@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ztypes_linux_arm64.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ztypes_linux_loong64.go
MK@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ztypes_linux_mips.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ztypes_linux_mips64.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ztypes_linux_mips64le.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ztypes_linux_mipsle.go
LJ@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ztypes_linux_ppc.go
NL@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ztypes_linux_ppc64.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ztypes_linux_ppc64le.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ztypes_linux_riscv64.go
NL@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ztypes_linux_s390x.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ztypes_linux_sparc64.go
MK@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ztypes_netbsd_386.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ztypes_netbsd_amd64.go
MK@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ztypes_netbsd_arm.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ztypes_netbsd_arm64.go
NL@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ztypes_openbsd_386.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ztypes_openbsd_amd64.go
NL@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ztypes_openbsd_arm.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ztypes_openbsd_arm64.go
QO@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ztypes_openbsd_mips64.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ztypes_openbsd_ppc64.go
RP@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ztypes_openbsd_riscv64.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ztypes_solaris_amd64.go
LJ@build_stack_rules_proto//vendor/golang.org/x/sys/unix:ztypes_zos_s390x.go
FD@build_stack_rules_proto//vendor/golang.org/x/sys/windows:aliases.go
JH@build_stack_rules_proto//vendor/golang.org/x/sys/windows:dll_windows.go
JH@build_stack_rules_proto//vendor/golang.org/x/sys/windows:env_windows.go
GE@build_stack_rules_proto//vendor/golang.org/x/sys/windows:eventlog.go
KI@build_stack_rules_proto//vendor/golang.org/x/sys/windows:exec_windows.go
MK@build_stack_rules_proto//vendor/golang.org/x/sys/windows:memory_windows.go
HF@build_stack_rules_proto//vendor/golang.org/x/sys/windows:mksyscall.go
CA@build_stack_rules_proto//vendor/golang.org/x/sys/windows:race.go
DB@build_stack_rules_proto//vendor/golang.org/x/sys/windows:race0.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/windows:security_windows.go
FD@build_stack_rules_proto//vendor/golang.org/x/sys/windows:service.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/windows:setupapi_windows.go
B@@build_stack_rules_proto//vendor/golang.org/x/sys/windows:str.go
FD@build_stack_rules_proto//vendor/golang.org/x/sys/windows:syscall.go
NL@build_stack_rules_proto//vendor/golang.org/x/sys/windows:syscall_windows.go
LJ@build_stack_rules_proto//vendor/golang.org/x/sys/windows:types_windows.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/windows:types_windows_386.go
RP@build_stack_rules_proto//vendor/golang.org/x/sys/windows:types_windows_amd64.go
PN@build_stack_rules_proto//vendor/golang.org/x/sys/windows:types_windows_arm.go
RP@build_stack_rules_proto//vendor/golang.org/x/sys/windows:types_windows_arm64.go
NL@build_stack_rules_proto//vendor/golang.org/x/sys/windows:zerrors_windows.go
VT@build_stack_rules_proto//vendor/golang.org/x/sys/windows:zknownfolderids_windows.go
OM@build_stack_rules_proto//vendor/golang.org/x/sys/windows:zsyscall_windows.go
PN@build_stack_rules_proto//vendor/golang.org/x/text/secure/bidirule:bidirule.go
VT@build_stack_rules_proto//vendor/golang.org/x/text/secure/bidirule:bidirule10.0.0.go
US@build_stack_rules_proto//vendor/golang.org/x/text/secure/bidirule:bidirule9.0.0.go
KI@build_stack_rules_proto//vendor/golang.org/x/text/transform:transform.go
IG@build_stack_rules_proto//vendor/golang.org/x/text/unicode/bidi:bidi.go
LJ@build_stack_rules_proto//vendor/golang.org/x/text/unicode/bidi:bracket.go
IG@build_stack_rules_proto//vendor/golang.org/x/text/unicode/bidi:core.go
IG@build_stack_rules_proto//vendor/golang.org/x/text/unicode/bidi:prop.go
QO@build_stack_rules_proto//vendor/golang.org/x/text/unicode/bidi:tables10.0.0.go
QO@build_stack_rules_proto//vendor/golang.org/x/text/unicode/bidi:tables11.0.0.go
QO@build_stack_rules_proto//vendor/golang.org/x/text/unicode/bidi:tables12.0.0.go
QO@build_stack_rules_proto//vendor/golang.org/x/text/unicode/bidi:tables13.0.0.go
QO@build_stack_rules_proto//vendor/golang.org/x/text/unicode/bidi:tables15.0.0.go
PN@build_stack_rules_proto//vendor/golang.org/x/text/unicode/bidi:tables9.0.0.go
LJ@build_stack_rules_proto//vendor/golang.org/x/text/unicode/bidi:trieval.go
PN@build_stack_rules_proto//vendor/golang.org/x/text/unicode/norm:composition.go
MK@build_stack_rules_proto//vendor/golang.org/x/text/unicode/norm:forminfo.go
JH@build_stack_rules_proto//vendor/golang.org/x/text/unicode/norm:input.go
IG@build_stack_rules_proto//vendor/golang.org/x/text/unicode/norm:iter.go
NL@build_stack_rules_proto//vendor/golang.org/x/text/unicode/norm:normalize.go
OM@build_stack_rules_proto//vendor/golang.org/x/text/unicode/norm:readwriter.go
QO@build_stack_rules_proto//vendor/golang.org/x/text/unicode/norm:tables10.0.0.go
QO@build_stack_rules_proto//vendor/golang.org/x/text/unicode/norm:tables11.0.0.go
QO@build_stack_rules_proto//vendor/golang.org/x/text/unicode/norm:tables12.0.0.go
QO@build_stack_rules_proto//vendor/golang.org/x/text/unicode/norm:tables13.0.0.go
QO@build_stack_rules_proto//vendor/golang.org/x/text/unicode/norm:tables15.0.0.go
PN@build_stack_rules_proto//vendor/golang.org/x/text/unicode/norm:tables9.0.0.go
NL@build_stack_rules_proto//vendor/golang.org/x/text/unicode/norm:transform.go
IG@build_stack_rules_proto//vendor/golang.org/x/text/unicode/norm:trie.go
IG@build_stack_rules_proto//vendor/golang.org/x/tools/go/vcs:discovery.go
CA@build_stack_rules_proto//vendor/golang.org/x/tools/go/vcs:env.go
DB@build_stack_rules_proto//vendor/golang.org/x/tools/go/vcs:http.go
CA@build_stack_rules_proto//vendor/golang.org/x/tools/go/vcs:vcs.go
`^@build_stack_rules_proto//vendor/google.golang.org/genproto/googleapis/rpc/status:status.pb.go
RP@build_stack_rules_proto//vendor/google.golang.org/grpc/attributes:attributes.go
LJ@build_stack_rules_proto//vendor/google.golang.org/grpc/backoff:backoff.go
DB@build_stack_rules_proto//vendor/google.golang.org/grpc:backoff.go
NL@build_stack_rules_proto//vendor/google.golang.org/grpc/balancer:balancer.go
SQ@build_stack_rules_proto//vendor/google.golang.org/grpc/balancer/base:balancer.go
OM@build_stack_rules_proto//vendor/google.golang.org/grpc/balancer/base:base.go
ZX@build_stack_rules_proto//vendor/google.golang.org/grpc/balancer:conn_state_evaluator.go
ge@build_stack_rules_proto//vendor/google.golang.org/grpc/balancer/endpointsharding:endpointsharding.go
XV@build_stack_rules_proto//vendor/google.golang.org/grpc/balancer/grpclb/state:state.go
a_@build_stack_rules_proto//vendor/google.golang.org/grpc/balancer/pickfirst/internal:internal.go
YW@build_stack_rules_proto//vendor/google.golang.org/grpc/balancer/pickfirst:pickfirst.go
ki@build_stack_rules_proto//vendor/google.golang.org/grpc/balancer/pickfirst/pickfirstleaf:pickfirstleaf.go
[Y@build_stack_rules_proto//vendor/google.golang.org/grpc/balancer/roundrobin:roundrobin.go
MK@build_stack_rules_proto//vendor/google.golang.org/grpc/balancer:subconn.go
MK@build_stack_rules_proto//vendor/google.golang.org/grpc:balancer_wrapper.go
ec@build_stack_rules_proto//vendor/google.golang.org/grpc/binarylog/grpc_binarylog_v1:binarylog.pb.go
A?@build_stack_rules_proto//vendor/google.golang.org/grpc:call.go
NL@build_stack_rules_proto//vendor/google.golang.org/grpc/channelz:channelz.go
GE@build_stack_rules_proto//vendor/google.golang.org/grpc:clientconn.go
XV@build_stack_rules_proto//vendor/google.golang.org/grpc/cmd/protoc-gen-go-grpc:grpc.go
XV@build_stack_rules_proto//vendor/google.golang.org/grpc/cmd/protoc-gen-go-grpc:main.go
B@@build_stack_rules_proto//vendor/google.golang.org/grpc:codec.go
NL@build_stack_rules_proto//vendor/google.golang.org/grpc/codes:code_string.go
HF@build_stack_rules_proto//vendor/google.golang.org/grpc/codes:codes.go
VT@build_stack_rules_proto//vendor/google.golang.org/grpc/connectivity:connectivity.go
TR@build_stack_rules_proto//vendor/google.golang.org/grpc/credentials:credentials.go
ZX@build_stack_rules_proto//vendor/google.golang.org/grpc/credentials/insecure:insecure.go
LJ@build_stack_rules_proto//vendor/google.golang.org/grpc/credentials:tls.go
HF@build_stack_rules_proto//vendor/google.golang.org/grpc:dialoptions.go
@>@build_stack_rules_proto//vendor/google.golang.org/grpc:doc.go
NL@build_stack_rules_proto//vendor/google.golang.org/grpc/encoding:encoding.go
QO@build_stack_rules_proto//vendor/google.golang.org/grpc/encoding:encoding_v2.go
QO@build_stack_rules_proto//vendor/google.golang.org/grpc/encoding/proto:proto.go
^\@build_stack_rules_proto//vendor/google.golang.org/grpc/experimental/stats:metricregistry.go
WU@build_stack_rules_proto//vendor/google.golang.org/grpc/experimental/stats:metrics.go
NL@build_stack_rules_proto//vendor/google.golang.org/grpc/grpclog:component.go
LJ@build_stack_rules_proto//vendor/google.golang.org/grpc/grpclog:grpclog.go
US@build_stack_rules_proto//vendor/google.golang.org/grpc/grpclog/internal:grpclog.go
TR@build_stack_rules_proto//vendor/google.golang.org/grpc/grpclog/internal:logger.go
VT@build_stack_rules_proto//vendor/google.golang.org/grpc/grpclog/internal:loggerv2.go
KI@build_stack_rules_proto//vendor/google.golang.org/grpc/grpclog:logger.go
MK@build_stack_rules_proto//vendor/google.golang.org/grpc/grpclog:loggerv2.go
HF@build_stack_rules_proto//vendor/google.golang.org/grpc:interceptor.go
US@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/backoff:backoff.go
db@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/balancer/gracefulswitch:config.go
lj@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/balancer/gracefulswitch:gracefulswitch.go
WU@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/balancerload:load.go
YW@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/binarylog:binarylog.go
b`@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/binarylog:binarylog_testutil.go
ZX@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/binarylog:env_config.go
][@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/binarylog:method_logger.go
TR@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/binarylog:sink.go
VT@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/buffer:unbounded.go
VT@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/channelz:channel.go
YW@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/channelz:channelmap.go
TR@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/channelz:funcs.go
VT@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/channelz:logging.go
US@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/channelz:server.go
US@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/channelz:socket.go
YW@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/channelz:subchannel.go
\Z@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/channelz:syscall_linux.go
_]@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/channelz:syscall_nonlinux.go
TR@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/channelz:trace.go
][@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/credentials:credentials.go
XV@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/credentials:spiffe.go
][@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/credentials:syscallconn.go
VT@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/credentials:util.go
YW@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/envconfig:envconfig.go
][@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/envconfig:observability.go
SQ@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/envconfig:xds.go
RP@build_stack_rules_proto//vendor/google.golang.org/grpc/internal:experimental.go
[Y@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/grpclog:prefix_logger.go
b`@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/grpcsync:callback_serializer.go
TR@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/grpcsync:event.go
US@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/grpcsync:pubsub.go
YW@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/grpcutil:compressor.go
^\@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/grpcutil:encode_duration.go
WU@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/grpcutil:grpcutil.go
WU@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/grpcutil:metadata.go
US@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/grpcutil:method.go
TR@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/grpcutil:regex.go
OM@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/idle:idle.go
NL@build_stack_rules_proto//vendor/google.golang.org/grpc/internal:internal.go
WU@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/metadata:metadata.go
SQ@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/pretty:pretty.go
ec@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/proxyattributes:proxyattributes.go
^\@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/resolver:config_selector.go
tr@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/resolver/delegatingresolver:delegatingresolver.go
_]@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/resolver/dns:dns_resolver.go
db@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/resolver/dns/internal:internal.go
fd@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/resolver/passthrough:passthrough.go
XV@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/resolver/unix:unix.go
\Z@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/serviceconfig:duration.go
a_@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/serviceconfig:serviceconfig.go
RP@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/stats:labels.go
a_@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/stats:metrics_recorder_list.go
SQ@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/status:status.go
[Y@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/syscall:syscall_linux.go
^\@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/syscall:syscall_nonlinux.go
ZX@build_stack_rules_proto//vendor/google.golang.org/grpc/internal:tcp_keepalive_others.go
XV@build_stack_rules_proto//vendor/google.golang.org/grpc/internal:tcp_keepalive_unix.go
[Y@build_stack_rules_proto//vendor/google.golang.org/grpc/internal:tcp_keepalive_windows.go
][@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/transport:bdp_estimator.go
][@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/transport:client_stream.go
ZX@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/transport:controlbuf.go
XV@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/transport:defaults.go
[Y@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/transport:flowcontrol.go
^\@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/transport:handler_server.go
\Z@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/transport:http2_client.go
\Z@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/transport:http2_server.go
YW@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/transport:http_util.go
WU@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/transport:logging.go
ge@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/transport/networktype:networktype.go
US@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/transport:proxy.go
][@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/transport:server_stream.go
YW@build_stack_rules_proto//vendor/google.golang.org/grpc/internal/transport:transport.go
PN@build_stack_rules_proto//vendor/google.golang.org/grpc/keepalive:keepalive.go
LJ@build_stack_rules_proto//vendor/google.golang.org/grpc/mem:buffer_pool.go
MK@build_stack_rules_proto//vendor/google.golang.org/grpc/mem:buffer_slice.go
HF@build_stack_rules_proto//vendor/google.golang.org/grpc/mem:buffers.go
NL@build_stack_rules_proto//vendor/google.golang.org/grpc/metadata:metadata.go
FD@build_stack_rules_proto//vendor/google.golang.org/grpc/peer:peer.go
KI@build_stack_rules_proto//vendor/google.golang.org/grpc:picker_wrapper.go
FD@build_stack_rules_proto//vendor/google.golang.org/grpc:preloader.go
VT@build_stack_rules_proto//vendor/google.golang.org/grpc/resolver/dns:dns_resolver.go
IG@build_stack_rules_proto//vendor/google.golang.org/grpc/resolver:map.go
NL@build_stack_rules_proto//vendor/google.golang.org/grpc/resolver:resolver.go
MK@build_stack_rules_proto//vendor/google.golang.org/grpc:resolver_wrapper.go
EC@build_stack_rules_proto//vendor/google.golang.org/grpc:rpc_util.go
CA@build_stack_rules_proto//vendor/google.golang.org/grpc:server.go
KI@build_stack_rules_proto//vendor/google.golang.org/grpc:service_config.go
XV@build_stack_rules_proto//vendor/google.golang.org/grpc/serviceconfig:serviceconfig.go
KI@build_stack_rules_proto//vendor/google.golang.org/grpc/stats:handlers.go
JH@build_stack_rules_proto//vendor/google.golang.org/grpc/stats:metrics.go
HF@build_stack_rules_proto//vendor/google.golang.org/grpc/stats:stats.go
JH@build_stack_rules_proto//vendor/google.golang.org/grpc/status:status.go
CA@build_stack_rules_proto//vendor/google.golang.org/grpc:stream.go
NL@build_stack_rules_proto//vendor/google.golang.org/grpc:stream_interfaces.go
DB@build_stack_rules_proto//vendor/google.golang.org/grpc/tap:tap.go
B@@build_stack_rules_proto//vendor/google.golang.org/grpc:trace.go
JH@build_stack_rules_proto//vendor/google.golang.org/grpc:trace_notrace.go
LJ@build_stack_rules_proto//vendor/google.golang.org/grpc:trace_withtrace.go
DB@build_stack_rules_proto//vendor/google.golang.org/grpc:version.go
fd@build_stack_rules_proto//vendor/google.golang.org/protobuf/cmd/protoc-gen-go/internal_gengo:init.go
mk@build_stack_rules_proto//vendor/google.golang.org/protobuf/cmd/protoc-gen-go/internal_gengo:init_opaque.go
fd@build_stack_rules_proto//vendor/google.golang.org/protobuf/cmd/protoc-gen-go/internal_gengo:main.go
hf@build_stack_rules_proto//vendor/google.golang.org/protobuf/cmd/protoc-gen-go/internal_gengo:opaque.go
ig@build_stack_rules_proto//vendor/google.golang.org/protobuf/cmd/protoc-gen-go/internal_gengo:reflect.go
rp@build_stack_rules_proto//vendor/google.golang.org/protobuf/cmd/protoc-gen-go/internal_gengo:well_known_types.go
WU@build_stack_rules_proto//vendor/google.golang.org/protobuf/cmd/protoc-gen-go:main.go
[Y@build_stack_rules_proto//vendor/google.golang.org/protobuf/compiler/protogen:protogen.go
db@build_stack_rules_proto//vendor/google.golang.org/protobuf/compiler/protogen:protogen_apilevel.go
b`@build_stack_rules_proto//vendor/google.golang.org/protobuf/compiler/protogen:protogen_opaque.go
ZX@build_stack_rules_proto//vendor/google.golang.org/protobuf/encoding/protojson:decode.go
WU@build_stack_rules_proto//vendor/google.golang.org/protobuf/encoding/protojson:doc.go
ZX@build_stack_rules_proto//vendor/google.golang.org/protobuf/encoding/protojson:encode.go
db@build_stack_rules_proto//vendor/google.golang.org/protobuf/encoding/protojson:well_known_types.go
ZX@build_stack_rules_proto//vendor/google.golang.org/protobuf/encoding/prototext:decode.go
WU@build_stack_rules_proto//vendor/google.golang.org/protobuf/encoding/prototext:doc.go
ZX@build_stack_rules_proto//vendor/google.golang.org/protobuf/encoding/prototext:encode.go
XV@build_stack_rules_proto//vendor/google.golang.org/protobuf/encoding/protowire:wire.go
ZX@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/descfmt:stringer.go
ZX@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/descopts:options.go
VT@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/detrand:rand.go
b`@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/editiondefaults:defaults.go
b`@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/editionssupport:editions.go
a_@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/encoding/defval:default.go
^\@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/encoding/json:decode.go
ec@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/encoding/json:decode_number.go
ec@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/encoding/json:decode_string.go
db@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/encoding/json:decode_token.go
^\@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/encoding/json:encode.go
hf@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/encoding/messageset:messageset.go
ZX@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/encoding/tag:tag.go
^\@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/encoding/text:decode.go
ec@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/encoding/text:decode_number.go
ec@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/encoding/text:decode_string.go
db@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/encoding/text:decode_token.go
[Y@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/encoding/text:doc.go
^\@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/encoding/text:encode.go
WU@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/errors:errors.go
XV@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/filedesc:build.go
WU@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/filedesc:desc.go
\Z@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/filedesc:desc_init.go
\Z@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/filedesc:desc_lazy.go
\Z@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/filedesc:desc_list.go
`^@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/filedesc:desc_list_gen.go
[Y@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/filedesc:editions.go
^\@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/filedesc:placeholder.go
[Y@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/filedesc:presence.go
XV@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/filetype:build.go
US@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/flags:flags.go
db@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/flags:proto_legacy_disable.go
ca@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/flags:proto_legacy_enable.go
WU@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/genid:any_gen.go
WU@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/genid:api_gen.go
^\@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/genid:descriptor_gen.go
SQ@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/genid:doc.go
\Z@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/genid:duration_gen.go
YW@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/genid:empty_gen.go
^\@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/genid:field_mask_gen.go
_]@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/genid:go_features_gen.go
VT@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/genid:goname.go
YW@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/genid:map_entry.go
TR@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/genid:name.go
b`@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/genid:source_context_gen.go
ZX@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/genid:struct_gen.go
][@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/genid:timestamp_gen.go
XV@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/genid:type_gen.go
XV@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/genid:wrappers.go
\Z@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/genid:wrappers_gen.go
YW@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:api_export.go
`^@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:api_export_opaque.go
US@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:bitmap.go
ZX@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:bitmap_race.go
XV@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:checkinit.go
^\@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:codec_extension.go
ZX@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:codec_field.go
a_@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:codec_field_opaque.go
XV@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:codec_gen.go
XV@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:codec_map.go
\Z@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:codec_message.go
ca@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:codec_message_opaque.go
_]@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:codec_messageset.go
[Y@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:codec_tables.go
[Y@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:codec_unsafe.go
VT@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:convert.go
[Y@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:convert_list.go
ZX@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:convert_map.go
US@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:decode.go
US@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:encode.go
SQ@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:enum.go
TR@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:equal.go
XV@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:extension.go
SQ@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:lazy.go
ZX@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:legacy_enum.go
\Z@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:legacy_export.go
_]@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:legacy_extension.go
ZX@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:legacy_file.go
][@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:legacy_message.go
TR@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:merge.go
XV@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:merge_gen.go
VT@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:message.go
][@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:message_opaque.go
a_@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:message_opaque_gen.go
^\@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:message_reflect.go
db@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:message_reflect_field.go
hf@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:message_reflect_field_gen.go
b`@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:message_reflect_gen.go
][@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:pointer_unsafe.go
db@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:pointer_unsafe_opaque.go
WU@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:presence.go
WU@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/impl:validate.go
WU@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/msgfmt:format.go
US@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/order:order.go
US@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/order:range.go
WU@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/pragma:pragma.go
`^@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/protolazy:bufferreader.go
XV@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/protolazy:lazy.go
b`@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/protolazy:pointer_unsafe.go
RP@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/set:ints.go
VT@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/strs:strings.go
][@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/strs:strings_unsafe.go
YW@build_stack_rules_proto//vendor/google.golang.org/protobuf/internal/version:version.go
PN@build_stack_rules_proto//vendor/google.golang.org/protobuf/proto:checkinit.go
MK@build_stack_rules_proto//vendor/google.golang.org/protobuf/proto:decode.go
QO@build_stack_rules_proto//vendor/google.golang.org/protobuf/proto:decode_gen.go
JH@build_stack_rules_proto//vendor/google.golang.org/protobuf/proto:doc.go
MK@build_stack_rules_proto//vendor/google.golang.org/protobuf/proto:encode.go
QO@build_stack_rules_proto//vendor/google.golang.org/protobuf/proto:encode_gen.go
LJ@build_stack_rules_proto//vendor/google.golang.org/protobuf/proto:equal.go
PN@build_stack_rules_proto//vendor/google.golang.org/protobuf/proto:extension.go
LJ@build_stack_rules_proto//vendor/google.golang.org/protobuf/proto:merge.go
QO@build_stack_rules_proto//vendor/google.golang.org/protobuf/proto:messageset.go
LJ@build_stack_rules_proto//vendor/google.golang.org/protobuf/proto:proto.go
TR@build_stack_rules_proto//vendor/google.golang.org/protobuf/proto:proto_methods.go
TR@build_stack_rules_proto//vendor/google.golang.org/protobuf/proto:proto_reflect.go
LJ@build_stack_rules_proto//vendor/google.golang.org/protobuf/proto:reset.go
KI@build_stack_rules_proto//vendor/google.golang.org/protobuf/proto:size.go
OM@build_stack_rules_proto//vendor/google.golang.org/protobuf/proto:size_gen.go
TR@build_stack_rules_proto//vendor/google.golang.org/protobuf/proto:wrapperopaque.go
OM@build_stack_rules_proto//vendor/google.golang.org/protobuf/proto:wrappers.go
SQ@build_stack_rules_proto//vendor/google.golang.org/protobuf/protoadapt:convert.go
WU@build_stack_rules_proto//vendor/google.golang.org/protobuf/reflect/protodesc:desc.go
\Z@build_stack_rules_proto//vendor/google.golang.org/protobuf/reflect/protodesc:desc_init.go
_]@build_stack_rules_proto//vendor/google.golang.org/protobuf/reflect/protodesc:desc_resolve.go
`^@build_stack_rules_proto//vendor/google.golang.org/protobuf/reflect/protodesc:desc_validate.go
[Y@build_stack_rules_proto//vendor/google.golang.org/protobuf/reflect/protodesc:editions.go
XV@build_stack_rules_proto//vendor/google.golang.org/protobuf/reflect/protodesc:proto.go
WU@build_stack_rules_proto//vendor/google.golang.org/protobuf/reflect/protopath:path.go
WU@build_stack_rules_proto//vendor/google.golang.org/protobuf/reflect/protopath:step.go
YW@build_stack_rules_proto//vendor/google.golang.org/protobuf/reflect/protorange:range.go
][@build_stack_rules_proto//vendor/google.golang.org/protobuf/reflect/protoreflect:methods.go
[Y@build_stack_rules_proto//vendor/google.golang.org/protobuf/reflect/protoreflect:proto.go
\Z@build_stack_rules_proto//vendor/google.golang.org/protobuf/reflect/protoreflect:source.go
`^@build_stack_rules_proto//vendor/google.golang.org/protobuf/reflect/protoreflect:source_gen.go
ZX@build_stack_rules_proto//vendor/google.golang.org/protobuf/reflect/protoreflect:type.go
[Y@build_stack_rules_proto//vendor/google.golang.org/protobuf/reflect/protoreflect:value.go
a_@build_stack_rules_proto//vendor/google.golang.org/protobuf/reflect/protoreflect:value_equal.go
a_@build_stack_rules_proto//vendor/google.golang.org/protobuf/reflect/protoreflect:value_union.go
b`@build_stack_rules_proto//vendor/google.golang.org/protobuf/reflect/protoreflect:value_unsafe.go
_]@build_stack_rules_proto//vendor/google.golang.org/protobuf/reflect/protoregistry:registry.go
ZX@build_stack_rules_proto//vendor/google.golang.org/protobuf/runtime/protoiface:legacy.go
[Y@build_stack_rules_proto//vendor/google.golang.org/protobuf/runtime/protoiface:methods.go
WU@build_stack_rules_proto//vendor/google.golang.org/protobuf/runtime/protoimpl:impl.go
ZX@build_stack_rules_proto//vendor/google.golang.org/protobuf/runtime/protoimpl:version.go
a_@build_stack_rules_proto//vendor/google.golang.org/protobuf/types/descriptorpb:descriptor.pb.go
XV@build_stack_rules_proto//vendor/google.golang.org/protobuf/types/dynamicpb:dynamic.go
VT@build_stack_rules_proto//vendor/google.golang.org/protobuf/types/dynamicpb:types.go
b`@build_stack_rules_proto//vendor/google.golang.org/protobuf/types/gofeaturespb:go_features.pb.go
YW@build_stack_rules_proto//vendor/google.golang.org/protobuf/types/known/anypb:any.pb.go
ca@build_stack_rules_proto//vendor/google.golang.org/protobuf/types/known/durationpb:duration.pb.go
ec@build_stack_rules_proto//vendor/google.golang.org/protobuf/types/known/timestamppb:timestamp.pb.go
YW@build_stack_rules_proto//vendor/google.golang.org/protobuf/types/pluginpb:plugin.pb.go
;9@build_stack_rules_proto//vendor/gopkg.in/yaml.v3:apic.go
=;@build_stack_rules_proto//vendor/gopkg.in/yaml.v3:decode.go
?=@build_stack_rules_proto//vendor/gopkg.in/yaml.v3:emitterc.go
=;@build_stack_rules_proto//vendor/gopkg.in/yaml.v3:encode.go
><@build_stack_rules_proto//vendor/gopkg.in/yaml.v3:parserc.go
><@build_stack_rules_proto//vendor/gopkg.in/yaml.v3:readerc.go
><@build_stack_rules_proto//vendor/gopkg.in/yaml.v3:resolve.go
?=@build_stack_rules_proto//vendor/gopkg.in/yaml.v3:scannerc.go
=;@build_stack_rules_proto//vendor/gopkg.in/yaml.v3:sorter.go
><@build_stack_rules_proto//vendor/gopkg.in/yaml.v3:writerc.go
;9@build_stack_rules_proto//vendor/gopkg.in/yaml.v3:yaml.go
<:@build_stack_rules_proto//vendor/gopkg.in/yaml.v3:yamlh.go
CA@build_stack_rules_proto//vendor/gopkg.in/yaml.v3:yamlprivateh.go=Code generated by list_repository_tools_srcs.go; DO NOT EDIT.�
<
build_stack_rules_protorules/protoproto_repository.bzl*�ModuleInfo request error: invalid argument: Traceback (most recent call last):
	File "external/build_stack_rules_proto/rules/proto/proto_repository.bzl", line 18, column 79, in <toplevel>
		load("@gazelle//internal:common.bzl", "env_execute", "executable_extension", "watch")
Error: file '@gazelle//internal:common.bzl' does not contain symbol 'watch'�
8
build_stack_rules_protorules/pygrpc_py_library.bzl�grpc_py_library*�
i
grpc_py_library

kwargs(2J
grpc_py_library7@@build_stack_rules_proto//rules/py:grpc_py_library.bzl
*
py_libraryo
//python:defs.bzlrX
 
rules_pythonpythondefs.bzl&

py_library
py_library
)3
59grpc_py_library.bzl provides a py_library for grpc files.�
9
build_stack_rules_protorules/pyproto_py_library.bzl�proto_py_library*�
l
proto_py_library

kwargs(2L
proto_py_library8@@build_stack_rules_proto//rules/py:proto_py_library.bzl
*
py_libraryo
//python:defs.bzlrX
 
rules_pythonpythondefs.bzl&

py_library
py_library
)3
5;proto_py_library.bzl provides a py_library for proto files.�
>
build_stack_rules_protorules/scalagrpc_scala_library.bzl�grpc_scala_library"�
�
grpc_scala_library*
nameA unique name for this target. 

build_ijar2True
data2[]
deps*

JavaInfo2[]
expect_java_output2True
exports2[]_
java_compile_toolchain*
JavaToolchainInfo2.@rules_java//toolchains:current_java_toolchain
javac_jvm_flags2[]
	javacopts2[]

main_class2""
	neverlink2False
plugins2[]
print_compile_time2False
resource_jars2[]
resource_strip_prefix2""
	resources2[] 
runtime_deps*

JavaInfo2[]
scala_version2""
scalac_jvm_flags2[]

scalacopts2[]
srcs2[]1
)unused_dependency_checker_ignored_targets2[]&
unused_dependency_checker_mode2""
,
*
nameA unique name for this target. 


build_ijar2True

data2[]

deps*

JavaInfo2[]

expect_java_output2True

exports2[]a
_
java_compile_toolchain*
JavaToolchainInfo2.@rules_java//toolchains:current_java_toolchain

javac_jvm_flags2[]

	javacopts2[]


main_class2""

	neverlink2False

plugins2[]

print_compile_time2False

resource_jars2[]

resource_strip_prefix2""

	resources2[]"
 
runtime_deps*

JavaInfo2[]

scala_version2""

scalac_jvm_flags2[]


scalacopts2[]

srcs2[]3
1
)unused_dependency_checker_ignored_targets2[](
&
unused_dependency_checker_mode2""t
//scala:scala.bzlr]

rules_scalascala	scala.bzl,
scala_libraryscala_library
(5
7?grpc_scala_library.bzl provides a scala_library for grpc files.�
B
build_stack_rules_protorules/scalagrpc_zio_scala_library.bzl�grpc_zio_scala_library"�
�
grpc_zio_scala_library*
nameA unique name for this target. 

build_ijar2True
data2[]
deps*

JavaInfo2[]
expect_java_output2True
exports2[]_
java_compile_toolchain*
JavaToolchainInfo2.@rules_java//toolchains:current_java_toolchain
javac_jvm_flags2[]
	javacopts2[]

main_class2""
	neverlink2False
plugins2[]
print_compile_time2False
resource_jars2[]
resource_strip_prefix2""
	resources2[] 
runtime_deps*

JavaInfo2[]
scala_version2""
scalac_jvm_flags2[]

scalacopts2[]
srcs2[]1
)unused_dependency_checker_ignored_targets2[]&
unused_dependency_checker_mode2""
,
*
nameA unique name for this target. 


build_ijar2True

data2[]

deps*

JavaInfo2[]

expect_java_output2True

exports2[]a
_
java_compile_toolchain*
JavaToolchainInfo2.@rules_java//toolchains:current_java_toolchain

javac_jvm_flags2[]

	javacopts2[]


main_class2""

	neverlink2False

plugins2[]

print_compile_time2False

resource_jars2[]

resource_strip_prefix2""

	resources2[]"
 
runtime_deps*

JavaInfo2[]

scala_version2""

scalac_jvm_flags2[]


scalacopts2[]

srcs2[]3
1
)unused_dependency_checker_ignored_targets2[](
&
unused_dependency_checker_mode2""t
//scala:scala.bzlr]

rules_scalascala	scala.bzl,
scala_libraryscala_library
(5
7Cgrpc_zio_scala_library.bzl provides a scala_library for grpc files.�
?
build_stack_rules_protorules/scalaproto_scala_library.bzl�proto_scala_library"�
�
proto_scala_library*
nameA unique name for this target. 

build_ijar2True
data2[]
deps*

JavaInfo2[]
expect_java_output2True
exports2[]_
java_compile_toolchain*
JavaToolchainInfo2.@rules_java//toolchains:current_java_toolchain
javac_jvm_flags2[]
	javacopts2[]

main_class2""
	neverlink2False
plugins2[]
print_compile_time2False
resource_jars2[]
resource_strip_prefix2""
	resources2[] 
runtime_deps*

JavaInfo2[]
scala_version2""
scalac_jvm_flags2[]

scalacopts2[]
srcs2[]1
)unused_dependency_checker_ignored_targets2[]&
unused_dependency_checker_mode2""
,
*
nameA unique name for this target. 


build_ijar2True

data2[]

deps*

JavaInfo2[]

expect_java_output2True

exports2[]a
_
java_compile_toolchain*
JavaToolchainInfo2.@rules_java//toolchains:current_java_toolchain

javac_jvm_flags2[]

	javacopts2[]


main_class2""

	neverlink2False

plugins2[]

print_compile_time2False

resource_jars2[]

resource_strip_prefix2""

	resources2[]"
 
runtime_deps*

JavaInfo2[]

scala_version2""

scalac_jvm_flags2[]


scalacopts2[]

srcs2[]3
1
)unused_dependency_checker_ignored_targets2[](
&
unused_dependency_checker_mode2""t
//scala:scala.bzlr]

rules_scalascala	scala.bzl,
scala_libraryscala_library
(5
7Aproto_scala_library.bzl provides a scala_library for proto files.�
?
build_stack_rules_protorules/scalascala_proto_library.bzl�scala_proto_library*�
x
scala_proto_library

kwargs(2U
scala_proto_library>@@build_stack_rules_proto//rules/scala:scala_proto_library.bzl
*_scala_proto_library�
//scala_proto:scala_proto.bzlrv
+
rules_scalascala_protoscala_proto.bzl9
scala_proto_library_scala_proto_library
3G
`oscala_proto_library.bzl is a thin wrapper for @io_bazel_rules_scala//scala:scala_proto.bzl%scala_proto_library.�
9
build_stack_rules_protorules/tsproto_ts_library.bzl�proto_ts_library2Compiles a Typescript library from generated code.*�
�
proto_ts_library

name (
declarationTrue(
tsconfigNone(

kwargs(2Compiles a Typescript library from generated code.2L
proto_ts_library8@@build_stack_rules_proto//rules/ts:proto_ts_library.bzl
*
ts_project2
ts_projectj
//ts:defs.bzlrW

aspect_rules_tstsdefs.bzl&

ts_project
ts_project
(2
47proto_ts_library.bzl provides the proto_ts_library rule�
-
build_stack_rules_protorulesexample.bzl�gazelle_testdata_exampleFgazelle_testdata_example rule runs an go_bazel_test for an example dir*�
�
gazelle_testdata_example5
kwargs)the kwargs dict passed to 'go_bazel_test'(Fgazelle_testdata_example rule runs an go_bazel_test for an example dir2H
gazelle_testdata_example,@@build_stack_rules_proto//rules:example.bzl
MM"_examplegen*go_bazel_test�
 //go/tools/bazel_testing:def.bzlri
+
rules_gogo/tools/bazel_testingdef.bzl,
go_bazel_testgo_bazel_test
4A
C7example.bzl provides the gazelle_testdata_example rule.�
6
build_stack_rules_protorulesgolden_filegroup.bzl�golden_filegroup6golden_filegroup is used identically to native.gencopy*�
�
golden_filegroup 
namethe name of the rule (V
sources_target_suffix1the suffix for the _proto_compiled_sources target".files"(?
test_target_suffixthe suffix for the test target".test"(G
run_target_suffix%the suffix for the update/copy target	".update"(=
	extension#the golden file extension to append	".golden"(,
kwargs remainder of non-positional args(6golden_filegroup is used identically to native.gencopy2I
golden_filegroup5@@build_stack_rules_proto//rules:golden_filegroup.bzl
''"_files"proto_compile_gencopy_test"proto_compile_gencopy_run*native.filegroup2native.filegroup�
!//rules:proto_compile_gencopy.bzlr�
;
build_stack_rules_protorulesproto_compile_gencopy.bzlD
proto_compile_gencopy_runproto_compile_gencopy_run
F
proto_compile_gencopy_testproto_compile_gencopy_test
 
�
//rules:providers.bzlrs
/
build_stack_rules_protorulesproviders.bzl2
ProtoCompileInfoProtoCompileInfo
8H
J�golden_filegroup wraps native.filegroup with .update and .test targets

golden_filegroup is a drop-in replacement for native.filegroup that provides
two additional targets used to copying source back into the source tree and
asserting that the file(s) remain consistent with the source control version
of the file (the golden files).

For any golden_filegroup target `//:a` that srcs `a.txt`, `//:a.update` copies
`a.txt` back into the source tree as `a.txt.golden'`; `//:a.test` asserts that
`a.txt` and `a.txt.golden'` are identical.
�
3
build_stack_rules_protorulesproto_compile.bzl�proto_compile"�
�
proto_compile*
nameA unique name for this target. ,
argsList of additional protoc args2[]H
default_info0If false, do not return the DefaultInfo provider2TrueF
options7List of additional options, keyed by proto_plugin label Y
output_file_suffix=If set, copy the output files to a new set having this suffix2""�
output_mappingsrstrings of the form A=B where A is a file named in attr.outputs and B is the actual file generated in the execroot2[]Q
outputsDList of source files we expect to be generated (relative to package):
outs,Output location, keyed by proto_plugin label
2{}C
plugins!List of ProtoPluginInfo providers *
ProtoPluginInfo7
protoThe single ProtoInfo provider *
	ProtoInfo9
protoc'Overrides the protoc from the toolchain2NoneT
srcsFList of source files we expect to be regenerated (relative to package)2[]'
verboseThe verbosity flag.2False"C
proto_compile2@@build_stack_rules_proto//rules:proto_compile.bzl
��,
*
nameA unique name for this target. .
,
argsList of additional protoc args2[]J
H
default_info0If false, do not return the DefaultInfo provider2TrueH
F
options7List of additional options, keyed by proto_plugin label [
Y
output_file_suffix=If set, copy the output files to a new set having this suffix2""�
�
output_mappingsrstrings of the form A=B where A is a file named in attr.outputs and B is the actual file generated in the execroot2[]S
Q
outputsDList of source files we expect to be generated (relative to package)<
:
outs,Output location, keyed by proto_plugin label
2{}E
C
plugins!List of ProtoPluginInfo providers *
ProtoPluginInfo9
7
protoThe single ProtoInfo provider *
	ProtoInfo;
9
protoc'Overrides the protoc from the toolchain2NoneV
T
srcsFList of source files we expect to be regenerated (relative to package)2[])
'
verboseThe verbosity flag.2False�get_protoc_executable*
o
get_protoc_executable	
ctx (2K
get_protoc_executable2@@build_stack_rules_proto//rules:proto_compile.bzl
77y
is_windows*i
Y

is_windows	
ctx (2@

is_windows2@@build_stack_rules_proto//rules:proto_compile.bzl
]]�
//rules:providers.bzlr�
/
build_stack_rules_protorulesproviders.bzl2
ProtoCompileInfoProtoCompileInfo
8H0
ProtoPluginInfoProtoPluginInfo
L[
]j
//proto:defs.bzlrT

rules_protoprotodefs.bzl$
	ProtoInfo	ProtoInfo
'0
2qproto_compile.bzl provides the proto_compile rule.

This runs the protoc tool and generates output source files.
�
:
build_stack_rules_protorulesproto_compile_assets.bzl�
!//rules:proto_compile_gencopy.bzlr�
;
build_stack_rules_protorulesproto_compile_gencopy.bzlD
proto_compile_gencopy_runproto_compile_gencopy_run
D]
_6proto_compile_assets.bzl provides the files copy rule.�
;
build_stack_rules_protorulesproto_compile_gencopy.bzl�	proto_compile_gencopy_run"�	
�
proto_compile_gencopy_run*
nameA unique name for this target. @
depsThe ProtoCompileInfo providers*
ProtoCompileInfo2[]D
	extension1optional file extension to add to the copied file2""1
	file_modeThe target unix file mode.2"0644"l
modeYThe gencopy mode.  For update, overwrite existing files.  For check, assert file equality2"check"X
packageGThe target package for the rule. If empty, default to ctx.label.package2""I
update_target_label_name)The label.name used to regenerate targets "W
proto_compile_gencopy_run:@@build_stack_rules_proto//rules:proto_compile_gencopy.bzl
-!-!,
*
nameA unique name for this target. B
@
depsThe ProtoCompileInfo providers*
ProtoCompileInfo2[]F
D
	extension1optional file extension to add to the copied file2""3
1
	file_modeThe target unix file mode.2"0644"n
l
modeYThe gencopy mode.  For update, overwrite existing files.  For check, assert file equality2"check"Z
X
packageGThe target package for the rule. If empty, default to ctx.label.package2""K
I
update_target_label_name)The label.name used to regenerate targets �	proto_compile_gencopy_test"�	
�
proto_compile_gencopy_test*
nameA unique name for this target. @
depsThe ProtoCompileInfo providers*
ProtoCompileInfo2[]D
	extension1optional file extension to add to the copied file2""1
	file_modeThe target unix file mode.2"0644"l
modeYThe gencopy mode.  For update, overwrite existing files.  For check, assert file equality2"check"X
packageGThe target package for the rule. If empty, default to ctx.label.package2""
srcsThe source files2[]I
update_target_label_name)The label.name used to regenerate targets "X
proto_compile_gencopy_test:@@build_stack_rules_proto//rules:proto_compile_gencopy.bzl
i"i",
*
nameA unique name for this target. B
@
depsThe ProtoCompileInfo providers*
ProtoCompileInfo2[]F
D
	extension1optional file extension to add to the copied file2""3
1
	file_modeThe target unix file mode.2"0644"n
l
modeYThe gencopy mode.  For update, overwrite existing files.  For check, assert file equality2"check"Z
X
packageGThe target package for the rule. If empty, default to ctx.label.package2"" 

srcsThe source files2[]K
I
update_target_label_name)The label.name used to regenerate targets �
//cmd/gencopy:gencopy.bzlr�
3
build_stack_rules_protocmd/gencopygencopy.bzl.
gencopy_actiongencopy_action
<J,
gencopy_attrsgencopy_attrs
N[.
gencopy_configgencopy_config
_m
o�
//rules:providers.bzlrs
/
build_stack_rules_protorulesproviders.bzl2
ProtoCompileInfoProtoCompileInfo
8H
Jgproto_compile_gencopy.bzl provides the proto_compile_gencopy_run and proto_compile_gencopy_test rules.
�
B
build_stack_rules_protorules proto_compiled_source_update.bzl�proto_compiled_source_update*�
�
proto_compiled_source_update

kwargs(2a
proto_compiled_source_updateA@@build_stack_rules_proto//rules:proto_compiled_source_update.bzl
"proto_compile_gencopy_run�
!//rules:proto_compile_gencopy.bzlr�
;
build_stack_rules_protorulesproto_compile_gencopy.bzlD
proto_compile_gencopy_runproto_compile_gencopy_run
D]
_Pproto_compiled_source_update.bzl provides the proto_compiled_source_update rule.�
<
build_stack_rules_protorulesproto_compiled_sources.bzl�proto_compiled_sourcesproto_compiled_sources macro."�
�
proto_compiled_sourcesproto_compiled_sources macro.*
nameA unique name for this target. ,
argsList of additional protoc args2[]H
default_info0If false, do not return the DefaultInfo provider2TrueF
options7List of additional options, keyed by proto_plugin label Y
output_file_suffix=If set, copy the output files to a new set having this suffix2""�
output_mappingsrstrings of the form A=B where A is a file named in attr.outputs and B is the actual file generated in the execroot2[]Q
outputsDList of source files we expect to be generated (relative to package):
outs,Output location, keyed by proto_plugin label
2{}C
plugins!List of ProtoPluginInfo providers *
ProtoPluginInfo7
protoThe single ProtoInfo provider *
	ProtoInfo9
protoc'Overrides the protoc from the toolchain2NoneT
srcsFList of source files we expect to be regenerated (relative to package)2[]'
verboseThe verbosity flag.2False
,
*
nameA unique name for this target. .
,
argsList of additional protoc args2[]J
H
default_info0If false, do not return the DefaultInfo provider2TrueH
F
options7List of additional options, keyed by proto_plugin label [
Y
output_file_suffix=If set, copy the output files to a new set having this suffix2""�
�
output_mappingsrstrings of the form A=B where A is a file named in attr.outputs and B is the actual file generated in the execroot2[]S
Q
outputsDList of source files we expect to be generated (relative to package)<
:
outs,Output location, keyed by proto_plugin label
2{}E
C
plugins!List of ProtoPluginInfo providers *
ProtoPluginInfo9
7
protoThe single ProtoInfo provider *
	ProtoInfo;
9
protoc'Overrides the protoc from the toolchain2NoneV
T
srcsFList of source files we expect to be regenerated (relative to package)2[])
'
verboseThe verbosity flag.2False�
//rules:proto_compile.bzlrq
3
build_stack_rules_protorulesproto_compile.bzl,
proto_compileproto_compile
<I
K�
!//rules:proto_compile_gencopy.bzlr�
;
build_stack_rules_protorulesproto_compile_gencopy.bzlD
proto_compile_gencopy_runproto_compile_gencopy_run
D]F
proto_compile_gencopy_testproto_compile_gencopy_test
a{
}�proto_compiled_sources provides the proto_compiled_sources macro which contains three rules.

1.  The main target of the macro is the 'proto_compile' rule (e.g. //proto:foo_py_proto_compile).  
    This rule runs 'protoc' and generates output files.

2. A 'proto_compile_gencopy_run' rule (e.g. bazel run //proto:foo_py_proto_compile.update) is used 
   to copy the generated sources back into the workspace package.

3. A 'proto_compile_gencopy_test' rule (e.g. bazel test //proto:foo_py_proto_compile_test) is used 
   to compare the generated sources with those in workspace package, preventing drift between the 
   source of truth (proto file) and the workspace copy (presumably under source control).  
   This is be used to force developers to update the generated files when making proto file changes. 
�
:
build_stack_rules_protorulesproto_descriptor_set.bzl�rules_proto_descriptor_set*�
�
rules_proto_descriptor_set

kwargs(2W
rules_proto_descriptor_set9@@build_stack_rules_proto//rules:proto_descriptor_set.bzl
*_proto_descriptor_set�
//proto:defs.bzlrk

rules_protoprotodefs.bzl;
proto_descriptor_set_proto_descriptor_set
&;
UOproto_descriptor_set.bzl wraps the proto_descriptor_set rule from @rules_proto.�
3
build_stack_rules_protorulesproto_gazelle.bzl�proto_gazelle8proto_gazelle is the macro that calls the gazelle runner"�
�
proto_gazelle8proto_gazelle is the macro that calls the gazelle runner*
nameA unique name for this target. 

build_tags2[]
cfgs2[]
command2"update"
data2[]
env
2{}
external2""

extra_args2[];
gazelle2.@@build_stack_rules_proto//cmd/gazelle:gazelle
imports2[]
mode2""
prefix2"""E
_gazelle_runner2@@build_stack_rules_proto//rules:proto_gazelle.bzl
��,
*
nameA unique name for this target. 


build_tags2[]

cfgs2[]

command2"update"

data2[]

env
2{}

external2""


extra_args2[]=
;
gazelle2.@@build_stack_rules_proto//cmd/gazelle:gazelle

imports2[]

mode2""

prefix2""q
:go_env.bzlr`
0
"bazel_gazelle_go_repository_config
go_env.bzl
GO_ENVGO_ENV

�
	:defs.bzlr{
)
bazel_gazelle_is_bazel_moduledefs.bzl@
GAZELLE_IS_BAZEL_MODULEGAZELLE_IS_BAZEL_MODULE

a
//lib:shell.bzlrL

bazel_skyliblib	shell.bzl
shellshell

t
//shell:sh_binary.bzlrY
#
rules_shellshellsh_binary.bzl$
	sh_binary	sh_binary
,5
7�	DEFAULT_LANGUAGESj�2�
31@bazel_gazelle//language/proto:go_default_library
0.@bazel_gazelle//language/go:go_default_library
-+@build_stack_rules_proto//language/protobuf
53@build_stack_rules_proto//language/proto_go_modules3proto_gazelle.bzl provides the proto_gazelle rule.
�
2
build_stack_rules_protorulesproto_plugin.bzl�proto_plugin"�
�	
proto_plugin*
nameA unique name for this target. >
data0Additional files required for running the plugin2[]�

exclusions�Exclusion filters to apply when generating outputs with this plugin. Used to prevent generating files that are included in the protobuf library, for example. Can exclude either by proto name prefix or by proto folder prefix2[]@
mods2content modifications to apply to the output files
2{}J
options9A list of options to pass to the compiler for this plugin2[]}
outgThe output scheme for the plugin.  Can be a string like '.' or a symbol such as {BIN_DIR} or {PACKAGE}.2"{BIN_DIR}"�
protoc_plugin_name�The name used for the plugin binary on the protoc command line. Useful for targeting built-in plugins. Uses plugin name when not set2""s
supplementary_proto_depsDAdditional proto files/descriptors to be placed on the argument list*
	ProtoInfo2[]�
tool�The plugin binary. If absent, it is assumed the plugin is built-in to protoc itself and builtin_plugin_name will be used if available, otherwise the plugin name2Nonel
use_built_in_shell_environmentAWhether the tool should use the built in shell environment or not2False"A
proto_plugin1@@build_stack_rules_proto//rules:proto_plugin.bzl
,
*
nameA unique name for this target. @
>
data0Additional files required for running the plugin2[]�
�

exclusions�Exclusion filters to apply when generating outputs with this plugin. Used to prevent generating files that are included in the protobuf library, for example. Can exclude either by proto name prefix or by proto folder prefix2[]B
@
mods2content modifications to apply to the output files
2{}L
J
options9A list of options to pass to the compiler for this plugin2[]
}
outgThe output scheme for the plugin.  Can be a string like '.' or a symbol such as {BIN_DIR} or {PACKAGE}.2"{BIN_DIR}"�
�
protoc_plugin_name�The name used for the plugin binary on the protoc command line. Useful for targeting built-in plugins. Uses plugin name when not set2""u
s
supplementary_proto_depsDAdditional proto files/descriptors to be placed on the argument list*
	ProtoInfo2[]�
�
tool�The plugin binary. If absent, it is assumed the plugin is built-in to protoc itself and builtin_plugin_name will be used if available, otherwise the plugin name2Nonen
l
use_built_in_shell_environmentAWhether the tool should use the built in shell environment or not2False�
//rules:providers.bzlrq
/
build_stack_rules_protorulesproviders.bzl0
ProtoPluginInfoProtoPluginInfo
8G
Ij
//proto:defs.bzlrT

rules_protoprotodefs.bzl$
	ProtoInfo	ProtoInfo
'0
2xproto_plugin.bzl provides the "proto_plugin" rule.

A "proto_plugin" rule wraps metadata about a proto compiler plugin.
�
2
build_stack_rules_protorulesprotogenrule.bzl�protogenrule2protogenrule is used identically to native.gencopy*�
�
protogenrule 
namethe name of the rule (G
run_target_suffix%the suffix for the update/copy target	".update"(Y
sources_target_suffix1the suffix for the _proto_compiled_sources target"d_sources"(?
test_target_suffixthe suffix for the test target"_test"(,
kwargs remainder of non-positional args(2protogenrule is used identically to native.gencopy2A
protogenrule1@@build_stack_rules_proto//rules:protogenrule.bzl
%%"_proto_compiled_sources"proto_compile_gencopy_test"proto_compile_gencopy_run*native.genrule2native.genrule�
!//rules:proto_compile_gencopy.bzlr�
;
build_stack_rules_protorulesproto_compile_gencopy.bzlD
proto_compile_gencopy_runproto_compile_gencopy_run
F
proto_compile_gencopy_testproto_compile_gencopy_test
 
�
//rules:providers.bzlrs
/
build_stack_rules_protorulesproviders.bzl2
ProtoCompileInfoProtoCompileInfo

�protogenrule wraps native.genrule with supplemental .update and _test targets

protogenrule is a drop-in replacement for native.genrule that provides two additional targets
used to copying source back into the monorepo and asserting that the
generated file(s) remain consistent with the source control version of the file.

For any protogenrule target `//:a` that outputs `a.txt`, `//:a.update`
copies `a.txt` back into the source tree as `a.txt'`; `//:a_test` asserts that
`a.txt` and `a.txt'` are identical.
�
/
build_stack_rules_protorulesproviders.bzl�ProtoCompileInfoLProtoCompileInfo provides downstream rules with the outputs of proto_compile2�
�
ProtoCompileInfoLProtoCompileInfo provides downstream rules with the outputs of proto_compile2
label)The proto_compile rule label (type Label);
outputs0The output files from the rule (type List[File])�
output_files_by_rel_path�The output files from the rule (type Dict[String,List[File]]).  The keys are the package-relative paths of the file and values are the file objects."B
ProtoCompileInfo.@@build_stack_rules_proto//rules:providers.bzl
4
2
label)The proto_compile rule label (type Label)=
;
outputs0The output files from the rule (type List[File])�
�
output_files_by_rel_path�The output files from the rule (type Dict[String,List[File]]).  The keys are the package-relative paths of the file and values are the file objects.�ProtoPluginInfoIProtoPluginInfo provides metadata about how a protoc plugin should be run2�
�	
ProtoPluginInfoIProtoPluginInfo provides metadata about how a protoc plugin should be run
nameThe proto plugin name
labelThe proto plugin labelD
options9A list of options to pass to the compiler for this plugin$
toolThe plugin binary executable*
tool_targetThe plugin tool target attrc
use_built_in_shell_environmentAWhether the tool should use the built in shell environment or not�
protoc_plugin_name�The name used for the plugin binary on the protoc command line. Useful for targeting built-in plugins. Uses plugin name when not set�

exclusions�Exclusion filters to apply when generating outputs with this plugin. Used to prevent generating files that are included in the protobuf library, for example. Can exclude either by proto name prefix or by proto folder prefix4
mods,awk expressions to apply to the output files8
data0Additional files required for running the pluginE
out>The format for the --x_out argument.  Defaults to to {BIN_DIR}~
supplementary_proto_depsbAdditional proto dependencies whose descriptors/files should be included in all protoc invocations:
deps2The list of workspace dependencies for this plugin"A
ProtoPluginInfo.@@build_stack_rules_proto//rules:providers.bzl


nameThe proto plugin name!

labelThe proto plugin labelF
D
options9A list of options to pass to the compiler for this plugin&
$
toolThe plugin binary executable,
*
tool_targetThe plugin tool target attre
c
use_built_in_shell_environmentAWhether the tool should use the built in shell environment or not�
�
protoc_plugin_name�The name used for the plugin binary on the protoc command line. Useful for targeting built-in plugins. Uses plugin name when not set�
�

exclusions�Exclusion filters to apply when generating outputs with this plugin. Used to prevent generating files that are included in the protobuf library, for example. Can exclude either by proto name prefix or by proto folder prefix6
4
mods,awk expressions to apply to the output files:
8
data0Additional files required for running the pluginG
E
out>The format for the --x_out argument.  Defaults to to {BIN_DIR}�
~
supplementary_proto_depsbAdditional proto dependencies whose descriptors/files should be included in all protoc invocations<
:
deps2The list of workspace dependencies for this pluginproviders.bzl
�
3
build_stack_rules_proto	toolchaintoolchain.bzl�protoc"�
�
protoc*
nameA unique name for this target. *
toolThe protocol compiler tool2None"<
protoc2@@build_stack_rules_proto//toolchain:toolchain.bzl
		,
*
nameA unique name for this target. ,
*
toolThe protocol compiler tool2None0toolchain.bzl provides the protoc toolchain rule�
Z
build_stack_rules_proto6vendor/github.com/bazelbuild/bazel-gazelle/language/godef.bzl�std_package_list"�
�
std_package_list*
nameA unique name for this target. 	
out "m
std_package_listY@@build_stack_rules_proto//vendor/github.com/bazelbuild/bazel-gazelle/language/go:def.bzl
,
*
nameA unique name for this target. 
	
out a
//go:def.bzlrO

rules_gogodef.bzl&

go_context
go_context
 *
,�
X
build_stack_rules_proto-vendor/github.com/bazelbuild/buildtools/buildbuild_defs.bzl�extract_go_src"�
�
extract_go_src*
nameA unique name for this target. 
library*
GoInfo2None"i
extract_go_srcW@@build_stack_rules_proto//vendor/github.com/bazelbuild/buildtools/build:build_defs.bzl
KK,
*
nameA unique name for this target. 

library*
GoInfo2None�genfile_check_test=Asserts that any checked-in generated code matches bazel gen.*�
�
genfile_check_test
srcchecked in file (
gengenerated file (=Asserts that any checked-in generated code matches bazel gen.2m
genfile_check_testW@@build_stack_rules_proto//vendor/github.com/bazelbuild/buildtools/build:build_defs.bzl
UU"	sh_binary�go_proto_checkedin_test:Asserts that any checked-in .pb.go code matches bazel gen.*�
�
go_proto_checkedin_test
srcchecked in file (/
protogenerated file"go_default_library"(:Asserts that any checked-in .pb.go code matches bazel gen.2r
go_proto_checkedin_testW@@build_stack_rules_proto//vendor/github.com/bazelbuild/buildtools/build:build_defs.bzl
��"extract_go_src�go_yaccRuns go tool yacc -o $out $src.*�
�
go_yacc	
src (	
out (

visibilityNone(Runs go tool yacc -o $out $src.2b
go_yaccW@@build_stack_rules_proto//vendor/github.com/bazelbuild/buildtools/build:build_defs.bzl
>>"_go_yacc]
//go:def.bzlrK

rules_gogodef.bzl"
GoSourceGoSource

t
//shell:sh_binary.bzlrY
#
rules_shellshellsh_binary.bzl$
	sh_binary	sh_binary
,5
7l
//shell:sh_test.bzlrS
!
rules_shellshellsh_test.bzl 
sh_testsh_test
*1
3�Provides go_yacc and genfile_check_test

Copyright 2016 Google Inc. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
 