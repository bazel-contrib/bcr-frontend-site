�4
)
cargo_env.bzl	cargo_envcargo_env.bzl�	cargo_env�Generates a Cargo environment file for cargo builds.

An example of using this rule is:
```
cargo_env(
    name = "cargo_env",
    include_directories = ["@my_library//:headers_directory"],
    env = {
        "SOME_VALUE": "value",
    },
    env_directories = {
        "SOME_PACKAGE_PATH": "@some_package//:source_files",
    },
    env_files = {
        "SOME_FILE_PATH": "@some_package//:generated_file",
    },
)
```
"�
�
	cargo_env�Generates a Cargo environment file for cargo builds.

An example of using this rule is:
```
cargo_env(
    name = "cargo_env",
    include_directories = ["@my_library//:headers_directory"],
    env = {
        "SOME_VALUE": "value",
    },
    env_directories = {
        "SOME_PACKAGE_PATH": "@some_package//:source_files",
    },
    env_files = {
        "SOME_FILE_PATH": "@some_package//:generated_file",
    },
)
```
*
nameA unique name for this target. A
env4Map of environment variable names to literal values.
2{}�
env_directories�Map of environment variable names to targets. Uses DirectoryInfo.path when available; otherwise uses the target repository root. Includes the target files and default runfiles. Example: {"MY_INCLUDE_PATH": "@my_package//:include_directory"}	2{}�
	env_fileswMap of environment variable names to targets that provide exactly one file. The file path is resolved through runfiles.	2{}R
include_directories$Include directories for C++ to find.*
DirectoryInfo2[]"5
	cargo_env(@@cargo_env.bzl//cargo_env:cargo_env.bzl
��,
*
nameA unique name for this target. C
A
env4Map of environment variable names to literal values.
2{}�
�
env_directories�Map of environment variable names to targets. Uses DirectoryInfo.path when available; otherwise uses the target repository root. Includes the target files and default runfiles. Example: {"MY_INCLUDE_PATH": "@my_package//:include_directory"}	2{}�
�
	env_fileswMap of environment variable names to targets that provide exactly one file. The file path is resolved through runfiles.	2{}T
R
include_directories$Include directories for C++ to find.*
DirectoryInfo2[]�env_wrapper�
<p>
  The <code>sh_binary</code> rule is used to declare executable shell scripts.
  (<code>sh_binary</code> is a misnomer: its outputs aren't necessarily binaries.) This rule ensures
  that all dependencies are built, and appear in the <code>runfiles</code> area at execution time.
  We recommend that you name your <code>sh_binary()</code> rules after the name of the script minus
  the extension (e.g. <code>.sh</code>); the rule name and the file name must be distinct.
  <code>sh_binary</code> respects shebangs, so any available interpreter may be used (eg.
  <code>#!/bin/zsh</code>)
</p>
<h4 id="sh_binary_examples">Example</h4>
<p>For a simple shell script with no dependencies and some data files:
</p>
<pre class="code">
sh_binary(
    name = "foo",
    srcs = ["foo.sh"],
    data = glob(["datafiles/*.txt"]),
)
</pre>
"�
�
env_wrapper�
<p>
  The <code>sh_binary</code> rule is used to declare executable shell scripts.
  (<code>sh_binary</code> is a misnomer: its outputs aren't necessarily binaries.) This rule ensures
  that all dependencies are built, and appear in the <code>runfiles</code> area at execution time.
  We recommend that you name your <code>sh_binary()</code> rules after the name of the script minus
  the extension (e.g. <code>.sh</code>); the rule name and the file name must be distinct.
  <code>sh_binary</code> respects shebangs, so any available interpreter may be used (eg.
  <code>#!/bin/zsh</code>)
</p>
<h4 id="sh_binary_examples">Example</h4>
<p>For a simple shell script with no dependencies and some data files:
</p>
<pre class="code">
sh_binary(
    name = "foo",
    srcs = ["foo.sh"],
    data = glob(["datafiles/*.txt"]),
)
</pre>
*
nameA unique name for this target. 
data2[]�
deps�
The list of "library" targets to be aggregated into this target.
See general comments about <code>deps</code>
at <a href="${link common-definitions#typical.deps}">Typical attributes defined by
most build rules</a>.
<p>
  This attribute should be used to list other <code>sh_library</code> rules that provide
  interpreted program source code depended on by the code in <code>srcs</code>. The files
  provided by these rules will be present among the <code>runfiles</code> of this target.
</p>
*
ShInfo2[]
env
2{}
env_inherit2[]�
srcs�
The file containing the shell script.
<p>
  This attribute must be a singleton list, whose element is the shell script.
  This script must be executable, and may be a source file or a generated file.
  All other files required at runtime (whether scripts or data) belong in the
  <code>data</code> attribute.
</p>
2[]S
use_bash_launcher5Use a bash launcher initializing the runfiles library2False
��,
*
nameA unique name for this target. 

data2[]�
�
deps�
The list of "library" targets to be aggregated into this target.
See general comments about <code>deps</code>
at <a href="${link common-definitions#typical.deps}">Typical attributes defined by
most build rules</a>.
<p>
  This attribute should be used to list other <code>sh_library</code> rules that provide
  interpreted program source code depended on by the code in <code>srcs</code>. The files
  provided by these rules will be present among the <code>runfiles</code> of this target.
</p>
*
ShInfo2[]

env
2{}

env_inherit2[]�
�
srcs�
The file containing the shell script.
<p>
  This attribute must be a singleton list, whose element is the shell script.
  This script must be executable, and may be a source file or a generated file.
  All other files required at runtime (whether scripts or data) belong in the
  <code>data</code> attribute.
</p>
2[]U
S
use_bash_launcher5Use a bash launcher initializing the runfiles library2False�
//lib:expand_template.bzlrg
%
	bazel_liblibexpand_template.bzl0
expand_templateexpand_template
.=
?a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.a
//lib:shell.bzlrL

bazel_skyliblib	shell.bzl
shellshell
',
.�
//rules/directory:providers.bzlrl
.
bazel_skylibrules/directoryproviders.bzl,
DirectoryInfoDirectoryInfo
7D
Ft
//shell:sh_binary.bzlrY
#
rules_shellshellsh_binary.bzl$
	sh_binary	sh_binary
,5
7mGenerates a Cargo environment file and wrapper scripts for cargo builds using dependencies provided by Bazel.�0

cargo_env.bzlcargo_env.bzl�	cargo_env�Generates a Cargo environment file for cargo builds.

An example of using this rule is:
```
cargo_env(
    name = "cargo_env",
    include_directories = ["@my_library//:headers_directory"],
    env = {
        "SOME_VALUE": "value",
    },
    env_directories = {
        "SOME_PACKAGE_PATH": "@some_package//:source_files",
    },
    env_files = {
        "SOME_FILE_PATH": "@some_package//:generated_file",
    },
)
```
"�
�
	cargo_env�Generates a Cargo environment file for cargo builds.

An example of using this rule is:
```
cargo_env(
    name = "cargo_env",
    include_directories = ["@my_library//:headers_directory"],
    env = {
        "SOME_VALUE": "value",
    },
    env_directories = {
        "SOME_PACKAGE_PATH": "@some_package//:source_files",
    },
    env_files = {
        "SOME_FILE_PATH": "@some_package//:generated_file",
    },
)
```
*
nameA unique name for this target. A
env4Map of environment variable names to literal values.
2{}�
env_directories�Map of environment variable names to targets. Uses DirectoryInfo.path when available; otherwise uses the target repository root. Includes the target files and default runfiles. Example: {"MY_INCLUDE_PATH": "@my_package//:include_directory"}	2{}�
	env_fileswMap of environment variable names to targets that provide exactly one file. The file path is resolved through runfiles.	2{}R
include_directories$Include directories for C++ to find.*
DirectoryInfo2[]",
	cargo_env@@cargo_env.bzl//:cargo_env.bzl
��,
*
nameA unique name for this target. C
A
env4Map of environment variable names to literal values.
2{}�
�
env_directories�Map of environment variable names to targets. Uses DirectoryInfo.path when available; otherwise uses the target repository root. Includes the target files and default runfiles. Example: {"MY_INCLUDE_PATH": "@my_package//:include_directory"}	2{}�
�
	env_fileswMap of environment variable names to targets that provide exactly one file. The file path is resolved through runfiles.	2{}T
R
include_directories$Include directories for C++ to find.*
DirectoryInfo2[]�env_wrapper�
<p>
  The <code>sh_binary</code> rule is used to declare executable shell scripts.
  (<code>sh_binary</code> is a misnomer: its outputs aren't necessarily binaries.) This rule ensures
  that all dependencies are built, and appear in the <code>runfiles</code> area at execution time.
  We recommend that you name your <code>sh_binary()</code> rules after the name of the script minus
  the extension (e.g. <code>.sh</code>); the rule name and the file name must be distinct.
  <code>sh_binary</code> respects shebangs, so any available interpreter may be used (eg.
  <code>#!/bin/zsh</code>)
</p>
<h4 id="sh_binary_examples">Example</h4>
<p>For a simple shell script with no dependencies and some data files:
</p>
<pre class="code">
sh_binary(
    name = "foo",
    srcs = ["foo.sh"],
    data = glob(["datafiles/*.txt"]),
)
</pre>
"�
�
env_wrapper�
<p>
  The <code>sh_binary</code> rule is used to declare executable shell scripts.
  (<code>sh_binary</code> is a misnomer: its outputs aren't necessarily binaries.) This rule ensures
  that all dependencies are built, and appear in the <code>runfiles</code> area at execution time.
  We recommend that you name your <code>sh_binary()</code> rules after the name of the script minus
  the extension (e.g. <code>.sh</code>); the rule name and the file name must be distinct.
  <code>sh_binary</code> respects shebangs, so any available interpreter may be used (eg.
  <code>#!/bin/zsh</code>)
</p>
<h4 id="sh_binary_examples">Example</h4>
<p>For a simple shell script with no dependencies and some data files:
</p>
<pre class="code">
sh_binary(
    name = "foo",
    srcs = ["foo.sh"],
    data = glob(["datafiles/*.txt"]),
)
</pre>
*
nameA unique name for this target. 
data2[]�
deps�
The list of "library" targets to be aggregated into this target.
See general comments about <code>deps</code>
at <a href="${link common-definitions#typical.deps}">Typical attributes defined by
most build rules</a>.
<p>
  This attribute should be used to list other <code>sh_library</code> rules that provide
  interpreted program source code depended on by the code in <code>srcs</code>. The files
  provided by these rules will be present among the <code>runfiles</code> of this target.
</p>
*
ShInfo2[]
env
2{}
env_inherit2[]�
srcs�
The file containing the shell script.
<p>
  This attribute must be a singleton list, whose element is the shell script.
  This script must be executable, and may be a source file or a generated file.
  All other files required at runtime (whether scripts or data) belong in the
  <code>data</code> attribute.
</p>
2[]S
use_bash_launcher5Use a bash launcher initializing the runfiles library2False
��,
*
nameA unique name for this target. 

data2[]�
�
deps�
The list of "library" targets to be aggregated into this target.
See general comments about <code>deps</code>
at <a href="${link common-definitions#typical.deps}">Typical attributes defined by
most build rules</a>.
<p>
  This attribute should be used to list other <code>sh_library</code> rules that provide
  interpreted program source code depended on by the code in <code>srcs</code>. The files
  provided by these rules will be present among the <code>runfiles</code> of this target.
</p>
*
ShInfo2[]

env
2{}

env_inherit2[]�
�
srcs�
The file containing the shell script.
<p>
  This attribute must be a singleton list, whose element is the shell script.
  This script must be executable, and may be a source file or a generated file.
  All other files required at runtime (whether scripts or data) belong in the
  <code>data</code> attribute.
</p>
2[]U
S
use_bash_launcher5Use a bash launcher initializing the runfiles library2False�
//cargo_env:cargo_env.bzlr�
)
cargo_env.bzl	cargo_envcargo_env.bzl%
	cargo_env
_cargo_env
1;)
env_wrapper_env_wrapper
KW
hDre-export to allow syntax sugar: load("@cargo_env.bzl", "cargo_env") 