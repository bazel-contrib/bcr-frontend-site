�#
 
ceres-solverbazel	ceres.bzl�ceres_library*�
x
ceres_library

name ()
restrict_schur_specializationsFalse(20
ceres_library@@ceres-solver//bazel:ceres.bzl
��"native.cc_library2native.cc_library�!	
CERES_SRCSj�!2�!
%#internal/ceres/accelerate_sparse.cc
internal/ceres/array_utils.cc
+)internal/ceres/block_evaluate_preparer.cc
/-internal/ceres/block_jacobi_preconditioner.cc
)'internal/ceres/block_jacobian_writer.cc
42internal/ceres/block_random_access_dense_matrix.cc
75internal/ceres/block_random_access_diagonal_matrix.cc
.,internal/ceres/block_random_access_matrix.cc
53internal/ceres/block_random_access_sparse_matrix.cc
'%internal/ceres/block_sparse_matrix.cc
#!internal/ceres/block_structure.cc
internal/ceres/c_api.cc
internal/ceres/callbacks.cc
.,internal/ceres/canonical_views_clustering.cc
internal/ceres/cgnr_solver.cc
64internal/ceres/compressed_col_sparse_matrix_utils.cc
20internal/ceres/compressed_row_jacobian_writer.cc
0.internal/ceres/compressed_row_sparse_matrix.cc
-+internal/ceres/conditioned_cost_function.cc
internal/ceres/context.cc
 internal/ceres/context_impl.cc
0.internal/ceres/coordinate_descent_minimizer.cc
internal/ceres/corrector.cc
!internal/ceres/cost_function.cc
internal/ceres/covariance.cc
#!internal/ceres/covariance_impl.cc
" internal/ceres/dense_cholesky.cc
0.internal/ceres/dense_normal_cholesky_solver.cc
internal/ceres/dense_qr.cc
#!internal/ceres/dense_qr_solver.cc
'%internal/ceres/dense_sparse_matrix.cc
$"internal/ceres/detect_structure.cc
#!internal/ceres/dogleg_strategy.cc
:8internal/ceres/dynamic_compressed_row_jacobian_writer.cc
86internal/ceres/dynamic_compressed_row_sparse_matrix.cc
97internal/ceres/dynamic_sparse_normal_cholesky_solver.cc
internal/ceres/eigensparse.cc
'%internal/ceres/evaluation_callback.cc
internal/ceres/evaluator.cc
internal/ceres/file.cc
(&internal/ceres/first_order_function.cc
%#internal/ceres/float_suitesparse.cc
#!internal/ceres/function_sample.cc
$"internal/ceres/gradient_checker.cc
31internal/ceres/gradient_checking_cost_function.cc
$"internal/ceres/gradient_problem.cc
+)internal/ceres/gradient_problem_solver.cc
-+internal/ceres/implicit_schur_complement.cc
*(internal/ceres/inner_product_computer.cc
internal/ceres/is_close.cc
&$internal/ceres/iteration_callback.cc
%#internal/ceres/iterative_refiner.cc
53internal/ceres/iterative_schur_complement_solver.cc
0.internal/ceres/levenberg_marquardt_strategy.cc
internal/ceres/line_search.cc
)'internal/ceres/line_search_direction.cc
)'internal/ceres/line_search_minimizer.cc
,*internal/ceres/line_search_preprocessor.cc
1/internal/ceres/linear_least_squares_problems.cc
#!internal/ceres/linear_operator.cc
!internal/ceres/linear_solver.cc
!internal/ceres/loss_function.cc
,*internal/ceres/low_rank_inverse_hessian.cc
internal/ceres/manifold.cc
internal/ceres/minimizer.cc
 internal/ceres/normal_prior.cc
 internal/ceres/parallel_for.cc
#!internal/ceres/parallel_invoke.cc
" internal/ceres/parallel_utils.cc
,*internal/ceres/parameter_block_ordering.cc
+)internal/ceres/partitioned_matrix_view.cc
internal/ceres/polynomial.cc
97internal/ceres/power_series_expansion_preconditioner.cc
" internal/ceres/preconditioner.cc
 internal/ceres/preprocessor.cc
internal/ceres/problem.cc
 internal/ceres/problem_impl.cc
internal/ceres/program.cc
#!internal/ceres/reorder_program.cc
" internal/ceres/residual_block.cc
(&internal/ceres/residual_block_utils.cc
+)internal/ceres/schur_complement_solver.cc
$"internal/ceres/schur_eliminator.cc
/-internal/ceres/schur_jacobi_preconditioner.cc
#!internal/ceres/schur_templates.cc
-+internal/ceres/scratch_evaluate_preparer.cc
-+internal/ceres/single_linkage_clustering.cc
internal/ceres/solver.cc
 internal/ceres/solver_utils.cc
#!internal/ceres/sparse_cholesky.cc
!internal/ceres/sparse_matrix.cc
1/internal/ceres/sparse_normal_cholesky_solver.cc
 internal/ceres/stringprintf.cc
)'internal/ceres/subset_preconditioner.cc
internal/ceres/suitesparse.cc
internal/ceres/thread_pool.cc
)'internal/ceres/thread_token_provider.cc
)'internal/ceres/triplet_sparse_matrix.cc
*(internal/ceres/trust_region_minimizer.cc
-+internal/ceres/trust_region_preprocessor.cc
/-internal/ceres/trust_region_step_evaluator.cc
)'internal/ceres/trust_region_strategy.cc
internal/ceres/types.cc
31internal/ceres/visibility_based_preconditioner.cc
internal/ceres/visibility.cc
internal/ceres/wall_time.cc 