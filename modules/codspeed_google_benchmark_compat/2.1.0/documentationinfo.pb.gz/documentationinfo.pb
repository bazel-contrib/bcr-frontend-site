�
=
 codspeed_google_benchmark_compatbazelbenchmark_deps.bzl*�ModuleInfo request error: invalid argument: Traceback (most recent call last):
	File "external/bazel_tools/tools/build_defs/repo/http.bzl", line 266, column 21, in <toplevel>
		_http_archive_attrs = {
Error in string: in call to string(), parameter 'doc' got value of type 'FakeDeepStructure', want 'string or NoneType' 