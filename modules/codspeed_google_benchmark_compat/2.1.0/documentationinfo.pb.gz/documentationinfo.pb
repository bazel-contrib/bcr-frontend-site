�
=
 codspeed_google_benchmark_compatbazelbenchmark_deps.bzl*�ModuleInfo request error: invalid argument: Traceback (most recent call last):
	File "external/codspeed_google_benchmark_compat/bazel/benchmark_deps.bzl", line 5, column 54, in <toplevel>
		load("@bazel_tools//tools/build_defs/repo:git.bzl", "new_git_repository")
Error: file '@bazel_tools//tools/build_defs/repo:git.bzl' does not contain symbol 'new_git_repository' 