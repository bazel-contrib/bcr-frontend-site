�R
D
(com_github_benchsci_rules_nodejs_gazelleinternalweb_assets.bzl�O
web_assets�A library of JavaScript sources. Provides JsInfo, the primary provider used in rules_js
and derivative rule sets.

Declaration files are handled separately from sources since they are generally not needed at
runtime and build rules, such as ts_project, are optimal in their build graph if they only depend
on declarations from `deps` since these they don't need the JavaScript source files from deps to
typecheck.

Linked npm dependences are also handled separately from sources since not all rules require them and it
is optimal for these rules to not depend on them in the build graph.

NB: `js_library` copies all source files to the output tree before providing them in JsInfo. See
https://github.com/aspect-build/rules_js/tree/dbb5af0d2a9a2bb50e4cf4a96dbc582b27567155/docs#javascript
for more context on why we do this."�I
�'

web_assets�A library of JavaScript sources. Provides JsInfo, the primary provider used in rules_js
and derivative rule sets.

Declaration files are handled separately from sources since they are generally not needed at
runtime and build rules, such as ts_project, are optimal in their build graph if they only depend
on declarations from `deps` since these they don't need the JavaScript source files from deps to
typecheck.

Linked npm dependences are also handled separately from sources since not all rules require them and it
is optimal for these rules to not depend on them in the build graph.

NB: `js_library` copies all source files to the output tree before providing them in JsInfo. See
https://github.com/aspect-build/rules_js/tree/dbb5af0d2a9a2bb50e4cf4a96dbc582b27567155/docs#javascript
for more context on why we do this.*
nameA unique name for this target. �
data�Runtime dependencies to include in binaries/tests that depend on this target.

    The transitive npm dependencies, transitive sources, default outputs and runfiles of targets in the `data` attribute
    are added to the runfiles of this target. They should appear in the '*.runfiles' area of any executable which has
    a runtime dependency on this target.

    If this list contains linked npm packages, npm package store targets or other targets that provide
`JsInfo`, `NpmPackageStoreInfo` providers are gathered from `JsInfo`. This is done directly from
the `npm_package_store_deps` field of these. For linked npm package targets, the underlying
`npm_package_store` target(s) that back the links is used. Gathered `NpmPackageStoreInfo`
providers are propagated to the direct dependencies of downstream linked `npm_package` targets.

NB: Linked npm package targets that are "dev" dependencies do not forward their underlying
`npm_package_store` target(s) through `npm_package_store_deps` and will therefore not be
propagated to the direct dependencies of downstream linked `npm_package` targets. npm packages
that come in from `npm_translate_lock` are considered "dev" dependencies if they are have
`dev: true` set in the pnpm lock file. This should be all packages that are only listed as
"devDependencies" in all `package.json` files within the pnpm workspace. This behavior is
intentional to mimic how `devDependencies` work in published npm packages.

2[]�
declarations�Same as `srcs` except all files are also provided as "declarations" available to downstream rules for type checking.

For example, a js_library with only `.js` files that are intended to be imported as `.js` files by downstream type checking
rules such as `ts_project` would list those files in `declarations`:

```
js_library(
    name = "js_lib",
    declarations = ["index.js"],
)
```
2[]�
deps�Dependencies of this target.

        This may include other js_library targets or other targets that provide JsInfo

        The transitive npm dependencies, transitive sources & runfiles of targets in the `deps` attribute are added to the
        runfiles of this target. They should appear in the '*.runfiles' area of any executable which is output by or has a
        runtime dependency on this target.

        If this list contains linked npm packages, npm package store targets or other targets that provide
`JsInfo`, `NpmPackageStoreInfo` providers are gathered from `JsInfo`. This is done directly from
the `npm_package_store_deps` field of these. For linked npm package targets, the underlying
`npm_package_store` target(s) that back the links is used. Gathered `NpmPackageStoreInfo`
providers are propagated to the direct dependencies of downstream linked `npm_package` targets.

NB: Linked npm package targets that are "dev" dependencies do not forward their underlying
`npm_package_store` target(s) through `npm_package_store_deps` and will therefore not be
propagated to the direct dependencies of downstream linked `npm_package` targets. npm packages
that come in from `npm_translate_lock` are considered "dev" dependencies if they are have
`dev: true` set in the pnpm lock file. This should be all packages that are only listed as
"devDependencies" in all `package.json` files within the pnpm workspace. This behavior is
intentional to mimic how `devDependencies` work in published npm packages.

*
JsInfo2[]�
srcs�Source files that are included in this library.

This includes all your checked-in code and any generated source files.

The transitive npm dependencies, transitive sources & runfiles of targets in the `srcs` attribute are added to the
runfiles of this target. They should appear in the '*.runfiles' area of any executable which is output by or has a
runtime dependency on this target.

Source files that are JSON files, declaration files or directory artifacts will be automatically provided as
"declarations" available to downstream rules for type checking. To explicitly provide source files as "declarations"
available to downstream rules for type checking that do not match these criteria, move those files to the `declarations`
attribute instead.
2[]
		,
*
nameA unique name for this target. �
�
data�Runtime dependencies to include in binaries/tests that depend on this target.

    The transitive npm dependencies, transitive sources, default outputs and runfiles of targets in the `data` attribute
    are added to the runfiles of this target. They should appear in the '*.runfiles' area of any executable which has
    a runtime dependency on this target.

    If this list contains linked npm packages, npm package store targets or other targets that provide
`JsInfo`, `NpmPackageStoreInfo` providers are gathered from `JsInfo`. This is done directly from
the `npm_package_store_deps` field of these. For linked npm package targets, the underlying
`npm_package_store` target(s) that back the links is used. Gathered `NpmPackageStoreInfo`
providers are propagated to the direct dependencies of downstream linked `npm_package` targets.

NB: Linked npm package targets that are "dev" dependencies do not forward their underlying
`npm_package_store` target(s) through `npm_package_store_deps` and will therefore not be
propagated to the direct dependencies of downstream linked `npm_package` targets. npm packages
that come in from `npm_translate_lock` are considered "dev" dependencies if they are have
`dev: true` set in the pnpm lock file. This should be all packages that are only listed as
"devDependencies" in all `package.json` files within the pnpm workspace. This behavior is
intentional to mimic how `devDependencies` work in published npm packages.

2[]�
�
declarations�Same as `srcs` except all files are also provided as "declarations" available to downstream rules for type checking.

For example, a js_library with only `.js` files that are intended to be imported as `.js` files by downstream type checking
rules such as `ts_project` would list those files in `declarations`:

```
js_library(
    name = "js_lib",
    declarations = ["index.js"],
)
```
2[]�
�
deps�Dependencies of this target.

        This may include other js_library targets or other targets that provide JsInfo

        The transitive npm dependencies, transitive sources & runfiles of targets in the `deps` attribute are added to the
        runfiles of this target. They should appear in the '*.runfiles' area of any executable which is output by or has a
        runtime dependency on this target.

        If this list contains linked npm packages, npm package store targets or other targets that provide
`JsInfo`, `NpmPackageStoreInfo` providers are gathered from `JsInfo`. This is done directly from
the `npm_package_store_deps` field of these. For linked npm package targets, the underlying
`npm_package_store` target(s) that back the links is used. Gathered `NpmPackageStoreInfo`
providers are propagated to the direct dependencies of downstream linked `npm_package` targets.

NB: Linked npm package targets that are "dev" dependencies do not forward their underlying
`npm_package_store` target(s) through `npm_package_store_deps` and will therefore not be
propagated to the direct dependencies of downstream linked `npm_package` targets. npm packages
that come in from `npm_translate_lock` are considered "dev" dependencies if they are have
`dev: true` set in the pnpm lock file. This should be all packages that are only listed as
"devDependencies" in all `package.json` files within the pnpm workspace. This behavior is
intentional to mimic how `devDependencies` work in published npm packages.

*
JsInfo2[]�
�
srcs�Source files that are included in this library.

This includes all your checked-in code and any generated source files.

The transitive npm dependencies, transitive sources & runfiles of targets in the `srcs` attribute are added to the
runfiles of this target. They should appear in the '*.runfiles' area of any executable which is output by or has a
runtime dependency on this target.

Source files that are JSON files, declaration files or directory artifacts will be automatically provided as
"declarations" available to downstream rules for type checking. To explicitly provide source files as "declarations"
available to downstream rules for type checking that do not match these criteria, move those files to the `declarations`
attribute instead.
2[]j
//js:defs.bzlrW

aspect_rules_jsjsdefs.bzl&

js_library
js_library
(2
4�web_assets

This is a simple macro for "web_assets" that echo's "js_library"
This is kept seperate so that users can override it with gazelle's map_kind directive
��
4
(com_github_benchsci_rules_nodejs_gazelledefs.bzl�O	web_asset�A library of JavaScript sources. Provides JsInfo, the primary provider used in rules_js
and derivative rule sets.

Declaration files are handled separately from sources since they are generally not needed at
runtime and build rules, such as ts_project, are optimal in their build graph if they only depend
on declarations from `deps` since these they don't need the JavaScript source files from deps to
typecheck.

Linked npm dependences are also handled separately from sources since not all rules require them and it
is optimal for these rules to not depend on them in the build graph.

NB: `js_library` copies all source files to the output tree before providing them in JsInfo. See
https://github.com/aspect-build/rules_js/tree/dbb5af0d2a9a2bb50e4cf4a96dbc582b27567155/docs#javascript
for more context on why we do this."�I
�'
	web_asset�A library of JavaScript sources. Provides JsInfo, the primary provider used in rules_js
and derivative rule sets.

Declaration files are handled separately from sources since they are generally not needed at
runtime and build rules, such as ts_project, are optimal in their build graph if they only depend
on declarations from `deps` since these they don't need the JavaScript source files from deps to
typecheck.

Linked npm dependences are also handled separately from sources since not all rules require them and it
is optimal for these rules to not depend on them in the build graph.

NB: `js_library` copies all source files to the output tree before providing them in JsInfo. See
https://github.com/aspect-build/rules_js/tree/dbb5af0d2a9a2bb50e4cf4a96dbc582b27567155/docs#javascript
for more context on why we do this.*
nameA unique name for this target. �
data�Runtime dependencies to include in binaries/tests that depend on this target.

    The transitive npm dependencies, transitive sources, default outputs and runfiles of targets in the `data` attribute
    are added to the runfiles of this target. They should appear in the '*.runfiles' area of any executable which has
    a runtime dependency on this target.

    If this list contains linked npm packages, npm package store targets or other targets that provide
`JsInfo`, `NpmPackageStoreInfo` providers are gathered from `JsInfo`. This is done directly from
the `npm_package_store_deps` field of these. For linked npm package targets, the underlying
`npm_package_store` target(s) that back the links is used. Gathered `NpmPackageStoreInfo`
providers are propagated to the direct dependencies of downstream linked `npm_package` targets.

NB: Linked npm package targets that are "dev" dependencies do not forward their underlying
`npm_package_store` target(s) through `npm_package_store_deps` and will therefore not be
propagated to the direct dependencies of downstream linked `npm_package` targets. npm packages
that come in from `npm_translate_lock` are considered "dev" dependencies if they are have
`dev: true` set in the pnpm lock file. This should be all packages that are only listed as
"devDependencies" in all `package.json` files within the pnpm workspace. This behavior is
intentional to mimic how `devDependencies` work in published npm packages.

2[]�
declarations�Same as `srcs` except all files are also provided as "declarations" available to downstream rules for type checking.

For example, a js_library with only `.js` files that are intended to be imported as `.js` files by downstream type checking
rules such as `ts_project` would list those files in `declarations`:

```
js_library(
    name = "js_lib",
    declarations = ["index.js"],
)
```
2[]�
deps�Dependencies of this target.

        This may include other js_library targets or other targets that provide JsInfo

        The transitive npm dependencies, transitive sources & runfiles of targets in the `deps` attribute are added to the
        runfiles of this target. They should appear in the '*.runfiles' area of any executable which is output by or has a
        runtime dependency on this target.

        If this list contains linked npm packages, npm package store targets or other targets that provide
`JsInfo`, `NpmPackageStoreInfo` providers are gathered from `JsInfo`. This is done directly from
the `npm_package_store_deps` field of these. For linked npm package targets, the underlying
`npm_package_store` target(s) that back the links is used. Gathered `NpmPackageStoreInfo`
providers are propagated to the direct dependencies of downstream linked `npm_package` targets.

NB: Linked npm package targets that are "dev" dependencies do not forward their underlying
`npm_package_store` target(s) through `npm_package_store_deps` and will therefore not be
propagated to the direct dependencies of downstream linked `npm_package` targets. npm packages
that come in from `npm_translate_lock` are considered "dev" dependencies if they are have
`dev: true` set in the pnpm lock file. This should be all packages that are only listed as
"devDependencies" in all `package.json` files within the pnpm workspace. This behavior is
intentional to mimic how `devDependencies` work in published npm packages.

*
JsInfo2[]�
srcs�Source files that are included in this library.

This includes all your checked-in code and any generated source files.

The transitive npm dependencies, transitive sources & runfiles of targets in the `srcs` attribute are added to the
runfiles of this target. They should appear in the '*.runfiles' area of any executable which is output by or has a
runtime dependency on this target.

Source files that are JSON files, declaration files or directory artifacts will be automatically provided as
"declarations" available to downstream rules for type checking. To explicitly provide source files as "declarations"
available to downstream rules for type checking that do not match these criteria, move those files to the `declarations`
attribute instead.
2[]
		,
*
nameA unique name for this target. �
�
data�Runtime dependencies to include in binaries/tests that depend on this target.

    The transitive npm dependencies, transitive sources, default outputs and runfiles of targets in the `data` attribute
    are added to the runfiles of this target. They should appear in the '*.runfiles' area of any executable which has
    a runtime dependency on this target.

    If this list contains linked npm packages, npm package store targets or other targets that provide
`JsInfo`, `NpmPackageStoreInfo` providers are gathered from `JsInfo`. This is done directly from
the `npm_package_store_deps` field of these. For linked npm package targets, the underlying
`npm_package_store` target(s) that back the links is used. Gathered `NpmPackageStoreInfo`
providers are propagated to the direct dependencies of downstream linked `npm_package` targets.

NB: Linked npm package targets that are "dev" dependencies do not forward their underlying
`npm_package_store` target(s) through `npm_package_store_deps` and will therefore not be
propagated to the direct dependencies of downstream linked `npm_package` targets. npm packages
that come in from `npm_translate_lock` are considered "dev" dependencies if they are have
`dev: true` set in the pnpm lock file. This should be all packages that are only listed as
"devDependencies" in all `package.json` files within the pnpm workspace. This behavior is
intentional to mimic how `devDependencies` work in published npm packages.

2[]�
�
declarations�Same as `srcs` except all files are also provided as "declarations" available to downstream rules for type checking.

For example, a js_library with only `.js` files that are intended to be imported as `.js` files by downstream type checking
rules such as `ts_project` would list those files in `declarations`:

```
js_library(
    name = "js_lib",
    declarations = ["index.js"],
)
```
2[]�
�
deps�Dependencies of this target.

        This may include other js_library targets or other targets that provide JsInfo

        The transitive npm dependencies, transitive sources & runfiles of targets in the `deps` attribute are added to the
        runfiles of this target. They should appear in the '*.runfiles' area of any executable which is output by or has a
        runtime dependency on this target.

        If this list contains linked npm packages, npm package store targets or other targets that provide
`JsInfo`, `NpmPackageStoreInfo` providers are gathered from `JsInfo`. This is done directly from
the `npm_package_store_deps` field of these. For linked npm package targets, the underlying
`npm_package_store` target(s) that back the links is used. Gathered `NpmPackageStoreInfo`
providers are propagated to the direct dependencies of downstream linked `npm_package` targets.

NB: Linked npm package targets that are "dev" dependencies do not forward their underlying
`npm_package_store` target(s) through `npm_package_store_deps` and will therefore not be
propagated to the direct dependencies of downstream linked `npm_package` targets. npm packages
that come in from `npm_translate_lock` are considered "dev" dependencies if they are have
`dev: true` set in the pnpm lock file. This should be all packages that are only listed as
"devDependencies" in all `package.json` files within the pnpm workspace. This behavior is
intentional to mimic how `devDependencies` work in published npm packages.

*
JsInfo2[]�
�
srcs�Source files that are included in this library.

This includes all your checked-in code and any generated source files.

The transitive npm dependencies, transitive sources & runfiles of targets in the `srcs` attribute are added to the
runfiles of this target. They should appear in the '*.runfiles' area of any executable which is output by or has a
runtime dependency on this target.

Source files that are JSON files, declaration files or directory artifacts will be automatically provided as
"declarations" available to downstream rules for type checking. To explicitly provide source files as "declarations"
available to downstream rules for type checking that do not match these criteria, move those files to the `declarations`
attribute instead.
2[]�O
web_assets�A library of JavaScript sources. Provides JsInfo, the primary provider used in rules_js
and derivative rule sets.

Declaration files are handled separately from sources since they are generally not needed at
runtime and build rules, such as ts_project, are optimal in their build graph if they only depend
on declarations from `deps` since these they don't need the JavaScript source files from deps to
typecheck.

Linked npm dependences are also handled separately from sources since not all rules require them and it
is optimal for these rules to not depend on them in the build graph.

NB: `js_library` copies all source files to the output tree before providing them in JsInfo. See
https://github.com/aspect-build/rules_js/tree/dbb5af0d2a9a2bb50e4cf4a96dbc582b27567155/docs#javascript
for more context on why we do this."�I
�'

web_assets�A library of JavaScript sources. Provides JsInfo, the primary provider used in rules_js
and derivative rule sets.

Declaration files are handled separately from sources since they are generally not needed at
runtime and build rules, such as ts_project, are optimal in their build graph if they only depend
on declarations from `deps` since these they don't need the JavaScript source files from deps to
typecheck.

Linked npm dependences are also handled separately from sources since not all rules require them and it
is optimal for these rules to not depend on them in the build graph.

NB: `js_library` copies all source files to the output tree before providing them in JsInfo. See
https://github.com/aspect-build/rules_js/tree/dbb5af0d2a9a2bb50e4cf4a96dbc582b27567155/docs#javascript
for more context on why we do this.*
nameA unique name for this target. �
data�Runtime dependencies to include in binaries/tests that depend on this target.

    The transitive npm dependencies, transitive sources, default outputs and runfiles of targets in the `data` attribute
    are added to the runfiles of this target. They should appear in the '*.runfiles' area of any executable which has
    a runtime dependency on this target.

    If this list contains linked npm packages, npm package store targets or other targets that provide
`JsInfo`, `NpmPackageStoreInfo` providers are gathered from `JsInfo`. This is done directly from
the `npm_package_store_deps` field of these. For linked npm package targets, the underlying
`npm_package_store` target(s) that back the links is used. Gathered `NpmPackageStoreInfo`
providers are propagated to the direct dependencies of downstream linked `npm_package` targets.

NB: Linked npm package targets that are "dev" dependencies do not forward their underlying
`npm_package_store` target(s) through `npm_package_store_deps` and will therefore not be
propagated to the direct dependencies of downstream linked `npm_package` targets. npm packages
that come in from `npm_translate_lock` are considered "dev" dependencies if they are have
`dev: true` set in the pnpm lock file. This should be all packages that are only listed as
"devDependencies" in all `package.json` files within the pnpm workspace. This behavior is
intentional to mimic how `devDependencies` work in published npm packages.

2[]�
declarations�Same as `srcs` except all files are also provided as "declarations" available to downstream rules for type checking.

For example, a js_library with only `.js` files that are intended to be imported as `.js` files by downstream type checking
rules such as `ts_project` would list those files in `declarations`:

```
js_library(
    name = "js_lib",
    declarations = ["index.js"],
)
```
2[]�
deps�Dependencies of this target.

        This may include other js_library targets or other targets that provide JsInfo

        The transitive npm dependencies, transitive sources & runfiles of targets in the `deps` attribute are added to the
        runfiles of this target. They should appear in the '*.runfiles' area of any executable which is output by or has a
        runtime dependency on this target.

        If this list contains linked npm packages, npm package store targets or other targets that provide
`JsInfo`, `NpmPackageStoreInfo` providers are gathered from `JsInfo`. This is done directly from
the `npm_package_store_deps` field of these. For linked npm package targets, the underlying
`npm_package_store` target(s) that back the links is used. Gathered `NpmPackageStoreInfo`
providers are propagated to the direct dependencies of downstream linked `npm_package` targets.

NB: Linked npm package targets that are "dev" dependencies do not forward their underlying
`npm_package_store` target(s) through `npm_package_store_deps` and will therefore not be
propagated to the direct dependencies of downstream linked `npm_package` targets. npm packages
that come in from `npm_translate_lock` are considered "dev" dependencies if they are have
`dev: true` set in the pnpm lock file. This should be all packages that are only listed as
"devDependencies" in all `package.json` files within the pnpm workspace. This behavior is
intentional to mimic how `devDependencies` work in published npm packages.

*
JsInfo2[]�
srcs�Source files that are included in this library.

This includes all your checked-in code and any generated source files.

The transitive npm dependencies, transitive sources & runfiles of targets in the `srcs` attribute are added to the
runfiles of this target. They should appear in the '*.runfiles' area of any executable which is output by or has a
runtime dependency on this target.

Source files that are JSON files, declaration files or directory artifacts will be automatically provided as
"declarations" available to downstream rules for type checking. To explicitly provide source files as "declarations"
available to downstream rules for type checking that do not match these criteria, move those files to the `declarations`
attribute instead.
2[]
		,
*
nameA unique name for this target. �
�
data�Runtime dependencies to include in binaries/tests that depend on this target.

    The transitive npm dependencies, transitive sources, default outputs and runfiles of targets in the `data` attribute
    are added to the runfiles of this target. They should appear in the '*.runfiles' area of any executable which has
    a runtime dependency on this target.

    If this list contains linked npm packages, npm package store targets or other targets that provide
`JsInfo`, `NpmPackageStoreInfo` providers are gathered from `JsInfo`. This is done directly from
the `npm_package_store_deps` field of these. For linked npm package targets, the underlying
`npm_package_store` target(s) that back the links is used. Gathered `NpmPackageStoreInfo`
providers are propagated to the direct dependencies of downstream linked `npm_package` targets.

NB: Linked npm package targets that are "dev" dependencies do not forward their underlying
`npm_package_store` target(s) through `npm_package_store_deps` and will therefore not be
propagated to the direct dependencies of downstream linked `npm_package` targets. npm packages
that come in from `npm_translate_lock` are considered "dev" dependencies if they are have
`dev: true` set in the pnpm lock file. This should be all packages that are only listed as
"devDependencies" in all `package.json` files within the pnpm workspace. This behavior is
intentional to mimic how `devDependencies` work in published npm packages.

2[]�
�
declarations�Same as `srcs` except all files are also provided as "declarations" available to downstream rules for type checking.

For example, a js_library with only `.js` files that are intended to be imported as `.js` files by downstream type checking
rules such as `ts_project` would list those files in `declarations`:

```
js_library(
    name = "js_lib",
    declarations = ["index.js"],
)
```
2[]�
�
deps�Dependencies of this target.

        This may include other js_library targets or other targets that provide JsInfo

        The transitive npm dependencies, transitive sources & runfiles of targets in the `deps` attribute are added to the
        runfiles of this target. They should appear in the '*.runfiles' area of any executable which is output by or has a
        runtime dependency on this target.

        If this list contains linked npm packages, npm package store targets or other targets that provide
`JsInfo`, `NpmPackageStoreInfo` providers are gathered from `JsInfo`. This is done directly from
the `npm_package_store_deps` field of these. For linked npm package targets, the underlying
`npm_package_store` target(s) that back the links is used. Gathered `NpmPackageStoreInfo`
providers are propagated to the direct dependencies of downstream linked `npm_package` targets.

NB: Linked npm package targets that are "dev" dependencies do not forward their underlying
`npm_package_store` target(s) through `npm_package_store_deps` and will therefore not be
propagated to the direct dependencies of downstream linked `npm_package` targets. npm packages
that come in from `npm_translate_lock` are considered "dev" dependencies if they are have
`dev: true` set in the pnpm lock file. This should be all packages that are only listed as
"devDependencies" in all `package.json` files within the pnpm workspace. This behavior is
intentional to mimic how `devDependencies` work in published npm packages.

*
JsInfo2[]�
�
srcs�Source files that are included in this library.

This includes all your checked-in code and any generated source files.

The transitive npm dependencies, transitive sources & runfiles of targets in the `srcs` attribute are added to the
runfiles of this target. They should appear in the '*.runfiles' area of any executable which is output by or has a
runtime dependency on this target.

Source files that are JSON files, declaration files or directory artifacts will be automatically provided as
"declarations" available to downstream rules for type checking. To explicitly provide source files as "declarations"
available to downstream rules for type checking that do not match these criteria, move those files to the `declarations`
attribute instead.
2[]�
//internal:web_assets.bzlr}
D
(com_github_benchsci_rules_nodejs_gazelleinternalweb_assets.bzl'

web_assets_web_assets
LW
g�
4
(com_github_benchsci_rules_nodejs_gazelledeps.bzlwgazelle_deps*e
U
gazelle_deps2E
gazelle_deps5@@com_github_benchsci_rules_nodejs_gazelle//:deps.bzl
`
	:deps.bzlrQ

gazelledeps.bzl,
go_repositorygo_repository
+
- 