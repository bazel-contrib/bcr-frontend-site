�

cpiormt_command.bzl�rmt_command_h�Write an `rmt-command.h` defining `DEFAULT_RMT_COMMAND`.

Upstream builds this header in `lib/Makefile.am` from `$(DEFAULT_RMT_DIR)`,
which `m4/rmt.m4` fills in from either the `DEFAULT_RMT_DIR` variable or
`--with-rmt=FILE`.  The value becomes `rmt_command` in `lib/rtapelib.c`, which
passes it to the remote shell as the program to run *on the remote host* when
an archive is named `[user@]host:path`.  It therefore describes a remote
filesystem rather than the build or execution platform, which is why upstream
makes it configurable and why nothing here can infer it.

cpio has no runtime override for it -- `--rsh-command` only selects the
transport -- so it has to be a build setting.  The path is free-form, so
`select()` over `config_setting`s cannot express it and this rule reads the
flag value directly.
"�
�

rmt_command_h�Write an `rmt-command.h` defining `DEFAULT_RMT_COMMAND`.

Upstream builds this header in `lib/Makefile.am` from `$(DEFAULT_RMT_DIR)`,
which `m4/rmt.m4` fills in from either the `DEFAULT_RMT_DIR` variable or
`--with-rmt=FILE`.  The value becomes `rmt_command` in `lib/rtapelib.c`, which
passes it to the remote shell as the program to run *on the remote host* when
an archive is named `[user@]host:path`.  It therefore describes a remote
filesystem rather than the build or execution platform, which is why upstream
makes it configurable and why nothing here can infer it.

cpio has no runtime override for it -- `--rsh-command` only selects the
transport -- so it has to be a build setting.  The path is free-form, so
`select()` over `config_setting`s cannot express it and this rule reads the
flag value directly.
*
nameA unique name for this target. �
command�A `string_flag` holding the path to the `rmt` program on the remote host.

Failing the build on an empty value keeps the flag from silently compiling in
a `DEFAULT_RMT_COMMAND` of `""`, which `execl` would reject only once a remote
archive was actually opened.
 *
BuildSettingInfo:
out/The generated header, relative to this package. ")
rmt_command_h@@cpio//:rmt_command.bzl
,
*
nameA unique name for this target. �
�
command�A `string_flag` holding the path to the `rmt` program on the remote host.

Failing the build on an empty value keeps the flag from silently compiling in
a `DEFAULT_RMT_COMMAND` of `""`, which `execl` would reject only once a remote
archive was actually opened.
 *
BuildSettingInfo<
:
out/The generated header, relative to this package. �
//rules:common_settings.bzlrn
*
bazel_skylibrulescommon_settings.bzl2
BuildSettingInfoBuildSettingInfo
3C
E2Generate `lib/rmt-command.h` from a build setting. 