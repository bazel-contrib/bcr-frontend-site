�#
,
crispy-doomsrccrispy_config_checks.bzlt
//autoconf:checks.bzlrY
)
rules_cc_autoconfautoconf
checks.bzl
checkschecks
28
:�"	CRISPY_CONFIG_CHECKSj�!2�!
��{"code":"","define":"PACKAGE_NAME","define_value":"\"Crispy Doom\"","define_value_fail":"\"Crispy Doom\"","language":"c","name":"ac_cv_define_PACKAGE_NAME","type":"define"}
��{"code":"","define":"PACKAGE_TARNAME","define_value":"\"crispy-doom\"","define_value_fail":"\"crispy-doom\"","language":"c","name":"ac_cv_define_PACKAGE_TARNAME","type":"define"}
��{"code":"","define":"PACKAGE_VERSION","define_value":"\"7.1.0\"","define_value_fail":"\"7.1.0\"","language":"c","name":"ac_cv_define_PACKAGE_VERSION","type":"define"}
��{"code":"","define":"PACKAGE_STRING","define_value":"\"Crispy Doom 7.1.0\"","define_value_fail":"\"Crispy Doom 7.1.0\"","language":"c","name":"ac_cv_define_PACKAGE_STRING","type":"define"}
��{"code":"","define":"PROGRAM_PREFIX","define_value":"\"crispy-\"","define_value_fail":"\"crispy-\"","language":"c","name":"ac_cv_define_PROGRAM_PREFIX","type":"define"}
zx{"code":"#include <dirent.h>\n","define":"HAVE_DIRENT_H","language":"c","name":"ac_cv_header_dirent_h","type":"compile"}
�~{"code":"#include <linux/kd.h>\n","define":"HAVE_LINUX_KD_H","language":"c","name":"ac_cv_header_linux_kd_h","type":"compile"}
��{"code":"#include <dev/isa/spkrio.h>\n","define":"HAVE_DEV_ISA_SPKRIO_H","language":"c","name":"ac_cv_header_dev_isa_spkrio_h","type":"compile"}
��{"code":"#include <dev/speaker/speaker.h>\n","define":"HAVE_DEV_SPEAKER_SPEAKER_H","language":"c","name":"ac_cv_header_dev_speaker_speaker_h","type":"compile"}
��{"code":"/* Override any GCC internal prototype to avoid an error.\n   Use char because int might match the return type of a GCC\n   builtin and then its argument prototype would still apply.\n   MSVC does not have GCC builtins, so we can safely use int. */\n#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n/* Since MSVC 2015, many CRT functions (printf, scanf, etc.) are inline\n   in UCRT headers and not exported as linker symbols. Link against\n   legacy_stdio_definitions.lib to make them available for link tests. */\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint qsort ();\n#else\nchar qsort ();\n#endif\n\nint main(void) {\n    return qsort();\n}\n","define":"HAVE_QSORT","language":"c","name":"ac_cv_func_qsort","type":"function"}
��{"code":"/* Override any GCC internal prototype to avoid an error.\n   Use char because int might match the return type of a GCC\n   builtin and then its argument prototype would still apply.\n   MSVC does not have GCC builtins, so we can safely use int. */\n#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\n/* Since MSVC 2015, many CRT functions (printf, scanf, etc.) are inline\n   in UCRT headers and not exported as linker symbols. Link against\n   legacy_stdio_definitions.lib to make them available for link tests. */\n#pragma comment(lib, \"legacy_stdio_definitions.lib\")\nint mmap ();\n#else\nchar mmap ();\n#endif\n\nint main(void) {\n    return mmap();\n}\n","define":"HAVE_MMAP","language":"c","name":"ac_cv_func_mmap","type":"function"}
��{"code":"#include <string.h>\n\nint main(void) {\n#ifndef strcasecmp\n#ifdef __cplusplus\n  (void) strcasecmp;\n#else\n  (void) strcasecmp;\n#endif\n#endif\n\n  ;\n  return 0;\n}\n","define":"ac_cv_have_decl_strcasecmp","define_value":1,"language":"c","name":"ac_cv_have_decl_strcasecmp","type":"decl"}
��{"code":"","condition":"ac_cv_have_decl_strcasecmp","define":"HAVE_DECL_STRCASECMP","define_value":1,"define_value_fail":0,"language":"c","name":"ac_cv_define_HAVE_DECL_STRCASECMP","type":"define"}
��{"code":"#include <string.h>\n\nint main(void) {\n#ifndef strncasecmp\n#ifdef __cplusplus\n  (void) strncasecmp;\n#else\n  (void) strncasecmp;\n#endif\n#endif\n\n  ;\n  return 0;\n}\n","define":"ac_cv_have_decl_strncasecmp","define_value":1,"language":"c","name":"ac_cv_have_decl_strncasecmp","type":"decl"}
��{"code":"","condition":"ac_cv_have_decl_strncasecmp","define":"HAVE_DECL_STRNCASECMP","define_value":1,"define_value_fail":0,"language":"c","name":"ac_cv_define_HAVE_DECL_STRNCASECMP","type":"define"}
��{"code":"","define":"HAVE_LIBZ","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_HAVE_LIBZ","type":"define"}
��{"code":"","define":"DISABLE_SDL2NET","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_DISABLE_SDL2NET","type":"define"}8Autoconf checks used to generate Crispy Doom's config.h. 