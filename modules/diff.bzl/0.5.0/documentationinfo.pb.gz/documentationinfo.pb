�
diffdefs.bzl�cmp@Runs cmp (binary diff) between two files and returns the output.*�
�
cmp 
nameThe name of the rule (!
srcsThe files to compare. (1
args#Additional arguments to pass to cmp[](V
outGThe output file to write the output of cmp to. Defaults to ${name}.out.None(@
kwargs4Additional arguments to pass to the underlying rule.(@Runs cmp (binary diff) between two files and returns the output.2
cmp//diff:defs.bzl"
 
nameThe name of the rule (#
!
srcsThe files to compare. (3
1
args#Additional arguments to pass to cmp[](X
V
outGThe output file to write the output of cmp to. Defaults to ${name}.out.None(B
@
kwargs4Additional arguments to pass to the underlying rule.(�diff�Runs a diff between files and return a patch.

Examples:

Create a patch between two files.

```starlark
diff(
    name = "patch"
    srcs = ["a.txt", "b.txt"],
    patch = "a.patch"
)
```

Use `--from-file` to create a patch from one file to several files.

```starlark
diff(
    name = "patch"
    args = ["--unified", "--from-file", "$(execpath a.txt)"],
    srcs = ["a.txt", "b.txt", "c.txt"],
    patch = "a.patch"
)
```

_By default, diff creates a unified format patch by passing `["--unified"]`
to `args`. If overriding arguments, --unified must be added explicitly._
*�	
�
diff 
nameThe name of the rule (!
srcsThe files to compare. (=
args$Additional arguments to pass to diff["--unified"](Q
patch@The output file to write the diff to. Defaults to ${name}.patch.None(?
kwargs3Additional arguments to pass to the underlying rule(�Runs a diff between files and return a patch.

Examples:

Create a patch between two files.

```starlark
diff(
    name = "patch"
    srcs = ["a.txt", "b.txt"],
    patch = "a.patch"
)
```

Use `--from-file` to create a patch from one file to several files.

```starlark
diff(
    name = "patch"
    args = ["--unified", "--from-file", "$(execpath a.txt)"],
    srcs = ["a.txt", "b.txt", "c.txt"],
    patch = "a.patch"
)
```

_By default, diff creates a unified format patch by passing `["--unified"]`
to `args`. If overriding arguments, --unified must be added explicitly._
2
diff//diff:defs.bzl"
 
nameThe name of the rule (#
!
srcsThe files to compare. (?
=
args$Additional arguments to pass to diff["--unified"](S
Q
patch@The output file to write the diff to. Defaults to ${name}.patch.None(A
?
kwargs3Additional arguments to pass to the underlying rule(Public diff.bzl API re-exports�
diffextensions.bzl�	diffutils�Module extension for installing a diffutils toolchain based on prebuilt GNU diffutils
binaries from https://github.com/kormide/diffutils-prebuilt.

Every module can define a toolchain version under the default name, "diffutils".
The latest of those versions will be selected (the rest discarded),
and will always be registered by diff.bzl.

Additionally, the root module can define arbitrarily many more toolchain versions under different
names (the latest version will be picked for each name) and can register them as it sees fit,
effectively overriding the default named toolchain due to toolchain resolution precedence.J�
�
	diffutils�Module extension for installing a diffutils toolchain based on prebuilt GNU diffutils
binaries from https://github.com/kormide/diffutils-prebuilt.

Every module can define a toolchain version under the default name, "diffutils".
The latest of those versions will be selected (the rest discarded),
and will always be registered by diff.bzl.

Additionally, the root module can define arbitrarily many more toolchain versions under different
names (the latest version will be picked for each name) and can register them as it sees fit,
effectively overriding the default named toolchain due to toolchain resolution precedence.�
	toolchain�
name�Base name for generated repositories, allowing more than one diffutils toolchain to be registered.
Overriding the default is only permitted in the root module.

A host toolchain repo is set up using {name} so that hermetically fetched diffutils binaries
can be run with bazel run, e.g.,

```bash
bazel run @diffutils//:diff $FILE1 $FILE2
```2"diffutils"S
diffutils_version4Explicit version of GNU prebuilt diffutils binaries.2"3.12""//diff:extensions.bzl�
�
	toolchain�
name�Base name for generated repositories, allowing more than one diffutils toolchain to be registered.
Overriding the default is only permitted in the root module.

A host toolchain repo is set up using {name} so that hermetically fetched diffutils binaries
can be run with bazel run, e.g.,

```bash
bazel run @diffutils//:diff $FILE1 $FILE2
```2"diffutils"S
diffutils_version4Explicit version of GNU prebuilt diffutils binaries.2"3.12"�
�
name�Base name for generated repositories, allowing more than one diffutils toolchain to be registered.
Overriding the default is only permitted in the root module.

A host toolchain repo is set up using {name} so that hermetically fetched diffutils binaries
can be run with bazel run, e.g.,

```bash
bazel run @diffutils//:diff $FILE1 $FILE2
```2"diffutils"U
S
diffutils_version4Explicit version of GNU prebuilt diffutils binaries.2"3.12"Extensions for bzlmod�
diffrepositories.bzl�diffutils_register_toolchains�Convenience macro for users which does typical setup.

- creates a repository for each built-in platform like "diff_linux_amd64"
- creates a repository exposing toolchains for each platform in "diffutils_toolchains"
- registers a toolchain pointing at each platform
Users can avoid this macro and do these steps themselves, if they want more control.
*�
�
diffutils_register_toolchains<
name0base name for all created repos, like "diff1_14" (K
diffutils_version2Version of diffutils prebuilt binaries to download (�
register�whether to call through to native.register_toolchains.
Should be True for WORKSPACE users, but false when used under bzlmod extensionTrue(1
kwargs%passed to each diff_repositories call(�Convenience macro for users which does typical setup.

- creates a repository for each built-in platform like "diff_linux_amd64"
- creates a repository exposing toolchains for each platform in "diffutils_toolchains"
- registers a toolchain pointing at each platform
Users can avoid this macro and do these steps themselves, if they want more control.
28
diffutils_register_toolchains//diff:repositories.bzl>
<
name0base name for all created repos, like "diff1_14" (M
K
diffutils_version2Version of diffutils prebuilt binaries to download (�
�
register�whether to call through to native.register_toolchains.
Should be True for WORKSPACE users, but false when used under bzlmod extensionTrue(3
1
kwargs%passed to each diff_repositories call(�diffutils_repository3Fetch external tools needed for diffutils toolchainR�
�
diffutils_repository3Fetch external tools needed for diffutils toolchain.
name"A unique name for this repository. J
diffutils_version)Version of diffutils binaries to download J"3.12"�
platform!Platform to download binaries for J"linux_amd64"J"linux_arm64"J"darwin_amd64"J"darwin_arm64"J"windows_amd64"*/
diffutils_repository//diff:repositories.bzl0
.
name"A unique name for this repository. L
J
diffutils_version)Version of diffutils binaries to download J"3.12"�
�
platform!Platform to download binaries for J"linux_amd64"J"linux_arm64"J"darwin_amd64"J"darwin_arm64"J"windows_amd64"�diffutils_host_alias_repo�Creates a diffutils repository with a shorter name meant for the host platform, which contains
a BUILD.bazel file that exports symlinks to the host platform's binaries.R�
�
diffutils_host_alias_repo�Creates a diffutils repository with a shorter name meant for the host platform, which contains
a BUILD.bazel file that exports symlinks to the host platform's binaries..
name"A unique name for this repository. *4
diffutils_host_alias_repo//diff:repositories.bzl0
.
name"A unique name for this repository. �Declare runtime dependencies

These are needed for local dev, and users must install them as well.
See https://docs.bazel.build/versions/main/skylark/deploying.html#dependencies�
difftoolchain.bzl�diffutils_toolchaintDefines a diff toolchain.

For usage see https://docs.bazel.build/versions/main/toolchains.html#defining-toolchains."�
�
diffutils_toolchaintDefines a diff toolchain.

For usage see https://docs.bazel.build/versions/main/toolchains.html#defining-toolchains.*
nameA unique name for this target. 4
cmp_bin%A hermetically downloaded cmp binary. 6
diff_bin&A hermetically downloaded diff binary. 8
	diff3_bin'A hermetically downloaded diff3 binary. 8
	sdiff_bin'A hermetically downloaded sdiff binary. "+
diffutils_toolchain//diff:toolchain.bzl,
*
nameA unique name for this target. 6
4
cmp_bin%A hermetically downloaded cmp binary. 8
6
diff_bin&A hermetically downloaded diff binary. :
8
	diff3_bin'A hermetically downloaded diff3 binary. :
8
	sdiff_bin'A hermetically downloaded sdiff binary. �DiffutilsInfo3Information about how to invoke the tool executable2�
�
DiffutilsInfo3Information about how to invoke the tool executable
cmp_bindiffutils cmp binary!
diff_bindiffutils diff binary#
	diff3_bindiffutils diff3 binary#
	sdiff_bindiffutils sdiff binary"%
DiffutilsInfo//diff:toolchain.bzl!

cmp_bindiffutils cmp binary#
!
diff_bindiffutils diff binary%
#
	diff3_bindiffutils diff3 binary%
#
	sdiff_bindiffutils sdiff binary/Implement the language-specific toolchain rule.�
 
diff.bzldiffextensions.bzl�	diffutils�Module extension for installing a diffutils toolchain based on prebuilt GNU diffutils
binaries from https://github.com/kormide/diffutils-prebuilt.

Every module can define a toolchain version under the default name, "diffutils".
The latest of those versions will be selected (the rest discarded),
and will always be registered by diff.bzl.

Additionally, the root module can define arbitrarily many more toolchain versions under different
names (the latest version will be picked for each name) and can register them as it sees fit,
effectively overriding the default named toolchain due to toolchain resolution precedence.J�
�
	diffutils�Module extension for installing a diffutils toolchain based on prebuilt GNU diffutils
binaries from https://github.com/kormide/diffutils-prebuilt.

Every module can define a toolchain version under the default name, "diffutils".
The latest of those versions will be selected (the rest discarded),
and will always be registered by diff.bzl.

Additionally, the root module can define arbitrarily many more toolchain versions under different
names (the latest version will be picked for each name) and can register them as it sees fit,
effectively overriding the default named toolchain due to toolchain resolution precedence.�
	toolchain�
name�Base name for generated repositories, allowing more than one diffutils toolchain to be registered.
Overriding the default is only permitted in the root module.

A host toolchain repo is set up using {name} so that hermetically fetched diffutils binaries
can be run with bazel run, e.g.,

```bash
bazel run @diffutils//:diff $FILE1 $FILE2
```2"diffutils"S
diffutils_version4Explicit version of GNU prebuilt diffutils binaries.2"3.12"" @diff.bzl//diff:extensions.bzl�
�
	toolchain�
name�Base name for generated repositories, allowing more than one diffutils toolchain to be registered.
Overriding the default is only permitted in the root module.

A host toolchain repo is set up using {name} so that hermetically fetched diffutils binaries
can be run with bazel run, e.g.,

```bash
bazel run @diffutils//:diff $FILE1 $FILE2
```2"diffutils"S
diffutils_version4Explicit version of GNU prebuilt diffutils binaries.2"3.12"�
�
name�Base name for generated repositories, allowing more than one diffutils toolchain to be registered.
Overriding the default is only permitted in the root module.

A host toolchain repo is set up using {name} so that hermetically fetched diffutils binaries
can be run with bazel run, e.g.,

```bash
bazel run @diffutils//:diff $FILE1 $FILE2
```2"diffutils"U
S
diffutils_version4Explicit version of GNU prebuilt diffutils binaries.2"3.12"Extensions for bzlmod�

diff.bzldiffdefs.bzl�cmp@Runs cmp (binary diff) between two files and returns the output.*�
�
cmp 
nameThe name of the rule (!
srcsThe files to compare. (1
args#Additional arguments to pass to cmp[](V
outGThe output file to write the output of cmp to. Defaults to ${name}.out.None(@
kwargs4Additional arguments to pass to the underlying rule.(@Runs cmp (binary diff) between two files and returns the output.2
cmp@diff.bzl//diff:defs.bzl"
 
nameThe name of the rule (#
!
srcsThe files to compare. (3
1
args#Additional arguments to pass to cmp[](X
V
outGThe output file to write the output of cmp to. Defaults to ${name}.out.None(B
@
kwargs4Additional arguments to pass to the underlying rule.(�diff�Runs a diff between files and return a patch.

Examples:

Create a patch between two files.

```starlark
diff(
    name = "patch"
    srcs = ["a.txt", "b.txt"],
    patch = "a.patch"
)
```

Use `--from-file` to create a patch from one file to several files.

```starlark
diff(
    name = "patch"
    args = ["--unified", "--from-file", "$(execpath a.txt)"],
    srcs = ["a.txt", "b.txt", "c.txt"],
    patch = "a.patch"
)
```

_By default, diff creates a unified format patch by passing `["--unified"]`
to `args`. If overriding arguments, --unified must be added explicitly._
*�	
�
diff 
nameThe name of the rule (!
srcsThe files to compare. (=
args$Additional arguments to pass to diff["--unified"](Q
patch@The output file to write the diff to. Defaults to ${name}.patch.None(?
kwargs3Additional arguments to pass to the underlying rule(�Runs a diff between files and return a patch.

Examples:

Create a patch between two files.

```starlark
diff(
    name = "patch"
    srcs = ["a.txt", "b.txt"],
    patch = "a.patch"
)
```

Use `--from-file` to create a patch from one file to several files.

```starlark
diff(
    name = "patch"
    args = ["--unified", "--from-file", "$(execpath a.txt)"],
    srcs = ["a.txt", "b.txt", "c.txt"],
    patch = "a.patch"
)
```

_By default, diff creates a unified format patch by passing `["--unified"]`
to `args`. If overriding arguments, --unified must be added explicitly._
2 
diff@diff.bzl//diff:defs.bzl"
 
nameThe name of the rule (#
!
srcsThe files to compare. (?
=
args$Additional arguments to pass to diff["--unified"](S
Q
patch@The output file to write the diff to. Defaults to ${name}.patch.None(A
?
kwargs3Additional arguments to pass to the underlying rule(Public diff.bzl API re-exports 