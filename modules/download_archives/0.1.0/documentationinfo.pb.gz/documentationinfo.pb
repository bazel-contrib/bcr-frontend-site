��
0
download_archivesdownload/archivesdefs.bzl��download_archives�h
This repository rule wraps [`rctx.download_and_extract`] and creates a Bazel
repo under `@<REPO_NAME>`, downloading and extracting *one archive* from *one*
of the sources for *each* of the archive versions in the [repo JSON index].

When downloading the archive, if a source fails it will try the next one, and
only fail if all sources are exhausted.

To construct the arguments passed to [`rctx.download_and_extract`] it uses the
["materialized repo `context`"], which includes at minimum the materialized
`url` from which to download the archive.

### Repo structure

```
  @<REPO_NAME>/
   |
   |-- <VERSION>/
   |   |-- BUILD.bazel
   |   `-- <SOURCE>/
   |       |-- BUILD.bazel
   |       |-- ...
   |       `-- ...
   |
   |-- BUILD.bazel
   |-- index.json
   |-- lock.json
   |-- metadata.json
   |-- repo.bzl
   `-- patches/
       |-- <VERSION>/
           `-- <SOURCE>/
               |-- <PATCH_NAME>
               `-- ...
```

TL;DR, the repo can be used as follows:

- `@<REPO_NAME>//:<REPO_NAME>`: points to the `:files` target of the
  `DEFAULT_VERSION`.
- `@<REPO_NAME>//:<TARGET>`: points to the specific `TARGET` of the
  `DEFAULT_VERSION`.
- `@<REPO_NAME>//<VERSION>:<TARGET>`: points to the specific `TARGET` of that
  `VERSION`.

The `archives` repository rule creates a `@<REPO_NAME>` Bazel repo with a
public `//<VERSION>` package for every version in the index.

Each `//<VERSION>` package has three targets:
- `:files`: to access all the files in the downloaded archive.
- `:dir`: the path to the directory where the archive was extracted.
- `:<VERSION>`: `alias` of `:files`.

and two constants:
- `VERSION`: the version of the archive.
- `SOURCE`: the source from which the archive was downloaded.

Each `//<VERSION>` package has an *internal* `<SOURCE>` sub-package with
the actual files from the downloaded archive for that specific `version` and
`source`. The targets in the `//<VERSION>` package are aliases for targets in
the `//<VERSION>/<SOURCE>` sub-packages.

The root package `//` has three targets:
- `:files`: to access all the files in the `DEFAULT_VERSION` package.
- `:dir`: the path to the directory of the `DEFAULT_VERSION` package.
- `:<REPO_NAME>`: `alias` of `:files`.

and two constants:
- `VERSION`: the `DEFAULT_VERSION` of the archive.
- `SOURCE`: the source from which the default version was downloaded.

The root package also has the following:
- `//:index.json`: a copy of the repo index JSON file.
- `//:lock.json`: the repo lock file (see below).
- `//:metadata.json`: the repo metadata.
- `//:repo.bzl`: extension with the following constants:
  - `REPO_NAME`: The short repo name.
  - `SOURCES`: a mapping of the downloaded `version`s to the `source` from
    which the archive was downloaded.
  - `DEFAULT_VERSION`: the default `version` of the archive.
  - `LOCK`: a `dict` with the contents of the repo `lock.json`.
  - `METADATA`: the free-form metadata map straight from the repo JSON index,
    if any.
- `//patches`: a package with `<VERSION>/<SOURCE>` sub-packages with the
  applied patches applied to that archive, if any (see ["Patching"] below).

The repo lock file contains a mapping of the downloaded `version` to a "lock
object" with the following properties:
  - `source`: the source from which the archive was downloaded.
  - `url`: the URL from which the archive was downloaded.
  - `integrity`: the SRI ([Subresource Integrity (SRI)]) of the downloaded archive.
  - `patches`: the list of patches applied to the archive after download, if any.

["Patching"]: #patching
[Subresource Integrity (SRI)]: https://w3c.github.io/webappsec-subresource-integrity/
["materialized repo `context`"]: ../../lib/index.md#materialized-repo-context
[`rctx.download_and_extract`]: https://bazel.build/rules/lib/builtins/repository_ctx#download_and_extract
[repo JSON index]: ../../lib/index.md

### Selecting `versions` and `sources`

Users can also override the default selection of versions and sources with the
`versions` and `sources` arguments.

Note that selecting specific versions and/or arguments will change the values
of `VERSIONS` and `DEFAULT_VERSION`.

### Version scheme

The `version_scheme` attribute defines the format used for versions in both the
`index` and `patches`. The supported schemes are those in [`version_utils`'
`version` extension], with `SCHEME.SEMVER` ([semantic versioning]) being the
default.

[semantic versioning]: https://semver.org
[`version_utils`' `version` extension]: https://github.com/jjmaestro/bazel_version_utils/blob/main/docs/version/version.md

### Patching

The downloaded archive can also be patched by passing a `patches` argument, a
map of `Label`s of [unified diff format] patch files (applied from the root of
the downloaded archive) to "patch specs" that determine if the patch is to be
applied.

The "patch spec" format is `<VERSION_SPEC>[/<SOURCE>]`, where:

- `<VERSION_SPEC>` is a version constraints requirement spec that
  to specify the versions to which the patch applies.
- `<SOURCE>` (optional, defaults to `*`) is the source of the downloaded
  archive to which the patch should be applied. It's optional and it can also
  be `*`, a wildcard to apply the patch to the archives downloaded from any
  source.

The `<VERSION_SPEC>` syntax is specified with the `spec_syntax` attribute. It's
one of the syntaxes supported by [`version_utils`' `spec` extension] and the
default is `SYNTAX.SIMPLE`.

This helps to maintain patches that apply to e.g.:

- a specific version and source: `1.24.5/github`
- a specific version and all sources: `1.24.5/*` or `1.24.5`
- a range of versions and all sources: `>=1.24.5, <2.0.0/*`
- all versions and sources: `*` or `*/*`

Finally, to simplify patch maintenance, it's good practice to keep a dedicated
"patched branch" for each version we want to maintain, making it easy to
generate the list of patches using [`git format-patch`].

[unified diff format]: https://en.wikipedia.org/wiki/Diff#Unified_format
+[`version_utils` `spec` extension]: https://github.com/jjmaestro/bazel_version_utils/blob/main/docs/specs/spec.md
[`git format-patch`]: https://git-scm.com/docs/git-format-patch

### Usage:

Here's an example that shows how to create a `@wget_src` repo for [GNU wget]:

[GNU wget]: https://www.gnu.org/software/wget/

#### 1. Create the repo index

First, define a `repo.json` JSON index file in a package. Don't forget to add a
`BUILD.bazel` file in it if one doesn't already exists).

E.g. for a `//third-party/wget` package:

```sh
mkdir -p third-party/wget
touch third-party/wget/BUILD.bazel
```

Then add the following to the `repo.json` file:

```json
{
  "version": 1,
  "sources": {
    "github.com": {
      "owner": "mirror",
      "repo": "wget",
      "tag": "v{version}",
      "url": "https://{source}/{owner}/{repo}/archive/refs/tags/{tag}.tar.gz",
      "strip_prefix": "{repo}-{version}"
    },
    "gitlab.com": {
      "owner": "gnuwget",
      "repo": "wget",
      "tag": "v{version}",
      "filename": "{repo}-{tag}",
      "url": "https://{source}/{owner}/{repo}/-/archive/{tag}/{filename}.tar.gz",
      "strip_prefix": "{filename}"
    }
  },
  "versions": {
    "1.24.5": {
      "integrity": {
        "gitlab.com": "sha256-1Yw1cok0niLv563o07/BrjbCQIflWxK8UFlav9srtcw="
      }
    },
    "1.21.3": {
      "integrity": {
        "github.com": "sha256-VbH6fHnent2TtbYxbNoatK4RNkY3MVPXokJhRzPZBg8=",
        "gitlab.com": "sha256-3w3ImvW4t/H2eMkZbUH+F1zkARSI3cIJSgJFg4ULPU4="
      }
    }
  }
}
```

#### 2. Add the `download_archives` repo to `MODULE.bazel`

Then, add the following to `MODULE.bazel`:

```starlark
download_archives = use_repo_rule("@download_archives//download/archives:defs.bzl", "download_archives")

download_archives(
    name = "wget_src",
    index = "//third-party/wget:repo.json",
    # NOTE:
    # This is how you would add a custom patch for one of the versions. See
    # "Patching" docs for more information about patches.
    # patches = {
    #    "//third-party/wget/patches:0001-1.24.5-test-patch.patch": ">=1.24.5/*",
    # },
    # NOTE:
    # This is needed because the archives have different integrity across the
    # mirrors (see v1.21.3)
    strict_integrity = False,
)
```

#### 3. Test it

To test the Bazel repo, run `bazel fetch @wget_src`. This will attempt to
download and extract all the versions defined in the repo index from the
available sources.

As mentioned before, it will stop downloading any other source for a specific
version when there's a successful download from one source. And, if all
downloads from all sources of a given version fail, it will `fail` with an
error.

Note that in the `repo.json` JSON index file there's one `integrity` missing
for one of the sources (version `1.24.5`, source `github.com`). When this
happens a warning message is printed when the archive download begins asking
the user to add the integrity to the index. And, if the archive is successfully
downloaded, a message with the [Subresource Integrity (SRI)] (`integrity`) and
`SHA256` hex digest will be printed so that it's easy to copy-paste one of them
in the index.

Also note that we set `strict_integrity = False` because the archives for
version `1.21.3` have different integrity hashes across sources. With
`strict_integrity = True`, this would cause the download to fail. Since this
can make builds non-reproducible, the default remains `True`. The option exists
because many artifacts share identical source code but differ in packaging or
other details, resulting in mismatched integrities.

Once installed, the `@wget_src` repo will have the following:

- helper constants available to import from `@wget_src//:repo.bzl`:
  - `REPO_NAME = "wget_src"`
  - `VERSIONS = {"1.24.5": "github.com", "1.21.3": "github.com"}`
  - `DEFAULT_VERSION = "1.24.5"`
  - `LOCK = {...}` (the contents of the repo `lock.json`)

- specific `<VERSION>/<SOURCE>` repos:
  - `@wget_src//1.24.5/github.com`
  - `@wget_src//1.21.3/github.com`

- `alias` repos:
  - `@wget_src` --> `@wget_src//1.24.5/github.com`
  - `@wget_src//1.24.5` --> `@wget_src//1.24.5/github.com`
  - `@wget_src//1.21.3` --> `@wget_src//1.21.3/github.com`

<details>
<summary><h4>More details</h4></summary>

To list all the targets in the repo, run `bazel query @wget_src//...`:

```sh
@wget_src//:dir
@wget_src//:files
@wget_src//:wget_src
@wget_src//1.21.3:1.21.3
@wget_src//1.21.3:dir
@wget_src//1.21.3:files
@wget_src//1.21.3/github.com:dir
@wget_src//1.21.3/github.com:files
@wget_src//1.21.3/github.com:github.com
@wget_src//1.24.5:1.24.5
@wget_src//1.24.5:dir
@wget_src//1.24.5:files
@wget_src//1.24.5/github.com:dir
@wget_src//1.24.5/github.com:files
@wget_src//1.24.5/github.com:github.com
```

In cases where we have many versions and sources in the index we can select the
versions and/or sources from which to download using the `versions` and
`sources` arguments:

```starlark
download_archives(
    name = "wget_src",
    index = "//third-party/wget:repo.json",
    versions = ["1.21.3"],
    sources = ["gitlab.com"],
)
```

Selecting `versions` and `sources` changes what's installed and available in
the `@wget_src` repo:

- helper constants available to import from `@wget_src//:repo.bzl`:
  - `REPO_NAME = "wget_src"`
  - `VERSIONS = {"1.21.3": "gitlab.com"}`
  - `DEFAULT_VERSION = "1.21.3"`

- specific `<VERSION>/<SOURCE>` repos:
  - `@wget_src//1.21.3/gitlab.com`

- `alias` repos:
  - `@wget_src` --> `@wget_src//1.21.3/gitlab.com`
  - `@wget_src//1.21.3` --> `@wget_src//1.21.3/gitlab.com`

Again, let's list all the targets with `bazel query @wget_src//...`:

```sh
@wget_src//:dir
@wget_src//:files
@wget_src//:wget_src
@wget_src//1.21.3:1.21.3
@wget_src//1.21.3:dir
@wget_src//1.21.3:files
@wget_src//1.21.3/gitlab.com:dir
@wget_src//1.21.3/gitlab.com:files
@wget_src//1.21.3/gitlab.com:gitlab.com
```

Similarly, remember that the sources are used as "mirrors" so if the first one
fails to download, the next source will be attempted. Thus, the `VERSIONS`
helper constant, the `alias` repos and the repo `lock.json` will all change
accordingly.

For example, imagine that `github` has version `1.24.5` available but not
`1.21.3`. Then, the download will fall back to the `gitlab.com` source and, if
successful, the `@wget_src` repo will have the following:

- helper constants available to import from `@wget_src//:repo.bzl`:
  - `REPO_NAME = "wget_src"`
  - `VERSIONS = {"1.24.5": "github.com", "1.21.3": "gitlab.com"}`
  - `DEFAULT_VERSION = "1.24.5"`
  - `LOCK = {...}` (the new contents of the repo `lock.json`)

- specific `<VERSION>/<SOURCE>` repos:
  - `@wget_src//1.24.5/github.com`
  - `@wget_src//1.21.3/gitlab.com`

- `alias` repos:
  - `@wget_src` --> `@wget_src//1.24.5/github`
  - `@wget_src//1.24.5` --> `@wget_src//1.24.5/github.com`
  - `@wget_src//1.21.3` --> `@wget_src//1.21.3/gitlab.com`


In this case, the list of targets would look like:

```sh
@wget_src//:dir
@wget_src//:files
@wget_src//:wget_src
@wget_src//1.21.3:1.21.3
@wget_src//1.21.3:dir
@wget_src//1.21.3:files
@wget_src//1.21.3/gitlab.com:dir
@wget_src//1.21.3/gitlab.com:files
@wget_src//1.21.3/gitlab.com:gitlab.com
@wget_src//1.24.5:1.24.5
@wget_src//1.24.5:dir
@wget_src//1.24.5:files
@wget_src//1.24.5/github.com:dir
@wget_src//1.24.5/github.com:files
@wget_src//1.24.5/github.com:github.com
```

</details>
R��
�y
download_archives�h
This repository rule wraps [`rctx.download_and_extract`] and creates a Bazel
repo under `@<REPO_NAME>`, downloading and extracting *one archive* from *one*
of the sources for *each* of the archive versions in the [repo JSON index].

When downloading the archive, if a source fails it will try the next one, and
only fail if all sources are exhausted.

To construct the arguments passed to [`rctx.download_and_extract`] it uses the
["materialized repo `context`"], which includes at minimum the materialized
`url` from which to download the archive.

### Repo structure

```
  @<REPO_NAME>/
   |
   |-- <VERSION>/
   |   |-- BUILD.bazel
   |   `-- <SOURCE>/
   |       |-- BUILD.bazel
   |       |-- ...
   |       `-- ...
   |
   |-- BUILD.bazel
   |-- index.json
   |-- lock.json
   |-- metadata.json
   |-- repo.bzl
   `-- patches/
       |-- <VERSION>/
           `-- <SOURCE>/
               |-- <PATCH_NAME>
               `-- ...
```

TL;DR, the repo can be used as follows:

- `@<REPO_NAME>//:<REPO_NAME>`: points to the `:files` target of the
  `DEFAULT_VERSION`.
- `@<REPO_NAME>//:<TARGET>`: points to the specific `TARGET` of the
  `DEFAULT_VERSION`.
- `@<REPO_NAME>//<VERSION>:<TARGET>`: points to the specific `TARGET` of that
  `VERSION`.

The `archives` repository rule creates a `@<REPO_NAME>` Bazel repo with a
public `//<VERSION>` package for every version in the index.

Each `//<VERSION>` package has three targets:
- `:files`: to access all the files in the downloaded archive.
- `:dir`: the path to the directory where the archive was extracted.
- `:<VERSION>`: `alias` of `:files`.

and two constants:
- `VERSION`: the version of the archive.
- `SOURCE`: the source from which the archive was downloaded.

Each `//<VERSION>` package has an *internal* `<SOURCE>` sub-package with
the actual files from the downloaded archive for that specific `version` and
`source`. The targets in the `//<VERSION>` package are aliases for targets in
the `//<VERSION>/<SOURCE>` sub-packages.

The root package `//` has three targets:
- `:files`: to access all the files in the `DEFAULT_VERSION` package.
- `:dir`: the path to the directory of the `DEFAULT_VERSION` package.
- `:<REPO_NAME>`: `alias` of `:files`.

and two constants:
- `VERSION`: the `DEFAULT_VERSION` of the archive.
- `SOURCE`: the source from which the default version was downloaded.

The root package also has the following:
- `//:index.json`: a copy of the repo index JSON file.
- `//:lock.json`: the repo lock file (see below).
- `//:metadata.json`: the repo metadata.
- `//:repo.bzl`: extension with the following constants:
  - `REPO_NAME`: The short repo name.
  - `SOURCES`: a mapping of the downloaded `version`s to the `source` from
    which the archive was downloaded.
  - `DEFAULT_VERSION`: the default `version` of the archive.
  - `LOCK`: a `dict` with the contents of the repo `lock.json`.
  - `METADATA`: the free-form metadata map straight from the repo JSON index,
    if any.
- `//patches`: a package with `<VERSION>/<SOURCE>` sub-packages with the
  applied patches applied to that archive, if any (see ["Patching"] below).

The repo lock file contains a mapping of the downloaded `version` to a "lock
object" with the following properties:
  - `source`: the source from which the archive was downloaded.
  - `url`: the URL from which the archive was downloaded.
  - `integrity`: the SRI ([Subresource Integrity (SRI)]) of the downloaded archive.
  - `patches`: the list of patches applied to the archive after download, if any.

["Patching"]: #patching
[Subresource Integrity (SRI)]: https://w3c.github.io/webappsec-subresource-integrity/
["materialized repo `context`"]: ../../lib/index.md#materialized-repo-context
[`rctx.download_and_extract`]: https://bazel.build/rules/lib/builtins/repository_ctx#download_and_extract
[repo JSON index]: ../../lib/index.md

### Selecting `versions` and `sources`

Users can also override the default selection of versions and sources with the
`versions` and `sources` arguments.

Note that selecting specific versions and/or arguments will change the values
of `VERSIONS` and `DEFAULT_VERSION`.

### Version scheme

The `version_scheme` attribute defines the format used for versions in both the
`index` and `patches`. The supported schemes are those in [`version_utils`'
`version` extension], with `SCHEME.SEMVER` ([semantic versioning]) being the
default.

[semantic versioning]: https://semver.org
[`version_utils`' `version` extension]: https://github.com/jjmaestro/bazel_version_utils/blob/main/docs/version/version.md

### Patching

The downloaded archive can also be patched by passing a `patches` argument, a
map of `Label`s of [unified diff format] patch files (applied from the root of
the downloaded archive) to "patch specs" that determine if the patch is to be
applied.

The "patch spec" format is `<VERSION_SPEC>[/<SOURCE>]`, where:

- `<VERSION_SPEC>` is a version constraints requirement spec that
  to specify the versions to which the patch applies.
- `<SOURCE>` (optional, defaults to `*`) is the source of the downloaded
  archive to which the patch should be applied. It's optional and it can also
  be `*`, a wildcard to apply the patch to the archives downloaded from any
  source.

The `<VERSION_SPEC>` syntax is specified with the `spec_syntax` attribute. It's
one of the syntaxes supported by [`version_utils`' `spec` extension] and the
default is `SYNTAX.SIMPLE`.

This helps to maintain patches that apply to e.g.:

- a specific version and source: `1.24.5/github`
- a specific version and all sources: `1.24.5/*` or `1.24.5`
- a range of versions and all sources: `>=1.24.5, <2.0.0/*`
- all versions and sources: `*` or `*/*`

Finally, to simplify patch maintenance, it's good practice to keep a dedicated
"patched branch" for each version we want to maintain, making it easy to
generate the list of patches using [`git format-patch`].

[unified diff format]: https://en.wikipedia.org/wiki/Diff#Unified_format
+[`version_utils` `spec` extension]: https://github.com/jjmaestro/bazel_version_utils/blob/main/docs/specs/spec.md
[`git format-patch`]: https://git-scm.com/docs/git-format-patch

### Usage:

Here's an example that shows how to create a `@wget_src` repo for [GNU wget]:

[GNU wget]: https://www.gnu.org/software/wget/

#### 1. Create the repo index

First, define a `repo.json` JSON index file in a package. Don't forget to add a
`BUILD.bazel` file in it if one doesn't already exists).

E.g. for a `//third-party/wget` package:

```sh
mkdir -p third-party/wget
touch third-party/wget/BUILD.bazel
```

Then add the following to the `repo.json` file:

```json
{
  "version": 1,
  "sources": {
    "github.com": {
      "owner": "mirror",
      "repo": "wget",
      "tag": "v{version}",
      "url": "https://{source}/{owner}/{repo}/archive/refs/tags/{tag}.tar.gz",
      "strip_prefix": "{repo}-{version}"
    },
    "gitlab.com": {
      "owner": "gnuwget",
      "repo": "wget",
      "tag": "v{version}",
      "filename": "{repo}-{tag}",
      "url": "https://{source}/{owner}/{repo}/-/archive/{tag}/{filename}.tar.gz",
      "strip_prefix": "{filename}"
    }
  },
  "versions": {
    "1.24.5": {
      "integrity": {
        "gitlab.com": "sha256-1Yw1cok0niLv563o07/BrjbCQIflWxK8UFlav9srtcw="
      }
    },
    "1.21.3": {
      "integrity": {
        "github.com": "sha256-VbH6fHnent2TtbYxbNoatK4RNkY3MVPXokJhRzPZBg8=",
        "gitlab.com": "sha256-3w3ImvW4t/H2eMkZbUH+F1zkARSI3cIJSgJFg4ULPU4="
      }
    }
  }
}
```

#### 2. Add the `download_archives` repo to `MODULE.bazel`

Then, add the following to `MODULE.bazel`:

```starlark
download_archives = use_repo_rule("@download_archives//download/archives:defs.bzl", "download_archives")

download_archives(
    name = "wget_src",
    index = "//third-party/wget:repo.json",
    # NOTE:
    # This is how you would add a custom patch for one of the versions. See
    # "Patching" docs for more information about patches.
    # patches = {
    #    "//third-party/wget/patches:0001-1.24.5-test-patch.patch": ">=1.24.5/*",
    # },
    # NOTE:
    # This is needed because the archives have different integrity across the
    # mirrors (see v1.21.3)
    strict_integrity = False,
)
```

#### 3. Test it

To test the Bazel repo, run `bazel fetch @wget_src`. This will attempt to
download and extract all the versions defined in the repo index from the
available sources.

As mentioned before, it will stop downloading any other source for a specific
version when there's a successful download from one source. And, if all
downloads from all sources of a given version fail, it will `fail` with an
error.

Note that in the `repo.json` JSON index file there's one `integrity` missing
for one of the sources (version `1.24.5`, source `github.com`). When this
happens a warning message is printed when the archive download begins asking
the user to add the integrity to the index. And, if the archive is successfully
downloaded, a message with the [Subresource Integrity (SRI)] (`integrity`) and
`SHA256` hex digest will be printed so that it's easy to copy-paste one of them
in the index.

Also note that we set `strict_integrity = False` because the archives for
version `1.21.3` have different integrity hashes across sources. With
`strict_integrity = True`, this would cause the download to fail. Since this
can make builds non-reproducible, the default remains `True`. The option exists
because many artifacts share identical source code but differ in packaging or
other details, resulting in mismatched integrities.

Once installed, the `@wget_src` repo will have the following:

- helper constants available to import from `@wget_src//:repo.bzl`:
  - `REPO_NAME = "wget_src"`
  - `VERSIONS = {"1.24.5": "github.com", "1.21.3": "github.com"}`
  - `DEFAULT_VERSION = "1.24.5"`
  - `LOCK = {...}` (the contents of the repo `lock.json`)

- specific `<VERSION>/<SOURCE>` repos:
  - `@wget_src//1.24.5/github.com`
  - `@wget_src//1.21.3/github.com`

- `alias` repos:
  - `@wget_src` --> `@wget_src//1.24.5/github.com`
  - `@wget_src//1.24.5` --> `@wget_src//1.24.5/github.com`
  - `@wget_src//1.21.3` --> `@wget_src//1.21.3/github.com`

<details>
<summary><h4>More details</h4></summary>

To list all the targets in the repo, run `bazel query @wget_src//...`:

```sh
@wget_src//:dir
@wget_src//:files
@wget_src//:wget_src
@wget_src//1.21.3:1.21.3
@wget_src//1.21.3:dir
@wget_src//1.21.3:files
@wget_src//1.21.3/github.com:dir
@wget_src//1.21.3/github.com:files
@wget_src//1.21.3/github.com:github.com
@wget_src//1.24.5:1.24.5
@wget_src//1.24.5:dir
@wget_src//1.24.5:files
@wget_src//1.24.5/github.com:dir
@wget_src//1.24.5/github.com:files
@wget_src//1.24.5/github.com:github.com
```

In cases where we have many versions and sources in the index we can select the
versions and/or sources from which to download using the `versions` and
`sources` arguments:

```starlark
download_archives(
    name = "wget_src",
    index = "//third-party/wget:repo.json",
    versions = ["1.21.3"],
    sources = ["gitlab.com"],
)
```

Selecting `versions` and `sources` changes what's installed and available in
the `@wget_src` repo:

- helper constants available to import from `@wget_src//:repo.bzl`:
  - `REPO_NAME = "wget_src"`
  - `VERSIONS = {"1.21.3": "gitlab.com"}`
  - `DEFAULT_VERSION = "1.21.3"`

- specific `<VERSION>/<SOURCE>` repos:
  - `@wget_src//1.21.3/gitlab.com`

- `alias` repos:
  - `@wget_src` --> `@wget_src//1.21.3/gitlab.com`
  - `@wget_src//1.21.3` --> `@wget_src//1.21.3/gitlab.com`

Again, let's list all the targets with `bazel query @wget_src//...`:

```sh
@wget_src//:dir
@wget_src//:files
@wget_src//:wget_src
@wget_src//1.21.3:1.21.3
@wget_src//1.21.3:dir
@wget_src//1.21.3:files
@wget_src//1.21.3/gitlab.com:dir
@wget_src//1.21.3/gitlab.com:files
@wget_src//1.21.3/gitlab.com:gitlab.com
```

Similarly, remember that the sources are used as "mirrors" so if the first one
fails to download, the next source will be attempted. Thus, the `VERSIONS`
helper constant, the `alias` repos and the repo `lock.json` will all change
accordingly.

For example, imagine that `github` has version `1.24.5` available but not
`1.21.3`. Then, the download will fall back to the `gitlab.com` source and, if
successful, the `@wget_src` repo will have the following:

- helper constants available to import from `@wget_src//:repo.bzl`:
  - `REPO_NAME = "wget_src"`
  - `VERSIONS = {"1.24.5": "github.com", "1.21.3": "gitlab.com"}`
  - `DEFAULT_VERSION = "1.24.5"`
  - `LOCK = {...}` (the new contents of the repo `lock.json`)

- specific `<VERSION>/<SOURCE>` repos:
  - `@wget_src//1.24.5/github.com`
  - `@wget_src//1.21.3/gitlab.com`

- `alias` repos:
  - `@wget_src` --> `@wget_src//1.24.5/github`
  - `@wget_src//1.24.5` --> `@wget_src//1.24.5/github.com`
  - `@wget_src//1.21.3` --> `@wget_src//1.21.3/gitlab.com`


In this case, the list of targets would look like:

```sh
@wget_src//:dir
@wget_src//:files
@wget_src//:wget_src
@wget_src//1.21.3:1.21.3
@wget_src//1.21.3:dir
@wget_src//1.21.3:files
@wget_src//1.21.3/gitlab.com:dir
@wget_src//1.21.3/gitlab.com:files
@wget_src//1.21.3/gitlab.com:gitlab.com
@wget_src//1.24.5:1.24.5
@wget_src//1.24.5:dir
@wget_src//1.24.5:files
@wget_src//1.24.5/github.com:dir
@wget_src//1.24.5/github.com:files
@wget_src//1.24.5/github.com:github.com
```

</details>
.
name"A unique name for this repository. )
indexLabel of the repo JSON index �
patches�
Diff files to apply as patches at the root of the downloaded archive.
The `dict` values represent "patch specs" in the
`<VERSION_SPEC>/<SOURCE>` format, and determine when patches apply to
the downloaded archive. Patches must be in standard [unified diff
format], created from the root of the archive. All patches are applied
from the root of the archive with `patch -p1`. For more details, see
["Patching"].
	2{}�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
sources�
Source names from which to download the archive. If none is specified,
it will use all of the sources available in the repo index to try to
download and extract the archive.
2[]�
spec_syntax�
The syntax of the version constraints specification. The available
syntaxes are those supported by `version_utils` (see `SYNTAX` in
[`version_utils`' `spec`
extension](https://github.com/jjmaestro/bazel_version_utils/blob/main/spec/spec.bzl)).
Defaults to `SYNTAX.SIMPLE`.
2"simple"�
strict_integrity�
If `True`, all sources of a given archive version must share the same
integrity hash. If they differ, the download will fail. Defaults to
`True`.
2True�
version_scheme�
The scheme of the versions in `index` and `patches`. The available
version schemes are those supported by `version_utils` (see `SCHEME` in
[`version_utils`' `version`
extension](https://github.com/jjmaestro/bazel_version_utils/blob/main/version/version.bzl)).
Defaults to `SCHEME.SEMVER`.
2"semver"�
versions}
Versions of the archive to download. If none is specified it will
download all of the versions available in the repo index.
2[]*D
download_archives/@@download_archives//download/archives:defs.bzl
��0
.
name"A unique name for this repository. +
)
indexLabel of the repo JSON index �
�
patches�
Diff files to apply as patches at the root of the downloaded archive.
The `dict` values represent "patch specs" in the
`<VERSION_SPEC>/<SOURCE>` format, and determine when patches apply to
the downloaded archive. Patches must be in standard [unified diff
format], created from the root of the archive. All patches are applied
from the root of the archive with `patch -p1`. For more details, see
["Patching"].
	2{}�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
�
sources�
Source names from which to download the archive. If none is specified,
it will use all of the sources available in the repo index to try to
download and extract the archive.
2[]�
�
spec_syntax�
The syntax of the version constraints specification. The available
syntaxes are those supported by `version_utils` (see `SYNTAX` in
[`version_utils`' `spec`
extension](https://github.com/jjmaestro/bazel_version_utils/blob/main/spec/spec.bzl)).
Defaults to `SYNTAX.SIMPLE`.
2"simple"�
�
strict_integrity�
If `True`, all sources of a given archive version must share the same
integrity hash. If they differ, the download will fail. Defaults to
`True`.
2True�
�
version_scheme�
The scheme of the versions in `index` and `patches`. The available
version schemes are those supported by `version_utils` (see `SCHEME` in
[`version_utils`' `version`
extension](https://github.com/jjmaestro/bazel_version_utils/blob/main/version/version.bzl)).
Defaults to `SCHEME.SEMVER`.
2"semver"�
�
versions}
Versions of the archive to download. If none is specified it will
download all of the versions available in the repo index.
2[]�
"//download/archives:repository.bzlrk
6
download_archivesdownload/archivesrepository.bzl#
archives	_archives
>G
Udefs��
6
download_archivesdownload/archivesrepository.bzl��archives�h
This repository rule wraps [`rctx.download_and_extract`] and creates a Bazel
repo under `@<REPO_NAME>`, downloading and extracting *one archive* from *one*
of the sources for *each* of the archive versions in the [repo JSON index].

When downloading the archive, if a source fails it will try the next one, and
only fail if all sources are exhausted.

To construct the arguments passed to [`rctx.download_and_extract`] it uses the
["materialized repo `context`"], which includes at minimum the materialized
`url` from which to download the archive.

### Repo structure

```
  @<REPO_NAME>/
   |
   |-- <VERSION>/
   |   |-- BUILD.bazel
   |   `-- <SOURCE>/
   |       |-- BUILD.bazel
   |       |-- ...
   |       `-- ...
   |
   |-- BUILD.bazel
   |-- index.json
   |-- lock.json
   |-- metadata.json
   |-- repo.bzl
   `-- patches/
       |-- <VERSION>/
           `-- <SOURCE>/
               |-- <PATCH_NAME>
               `-- ...
```

TL;DR, the repo can be used as follows:

- `@<REPO_NAME>//:<REPO_NAME>`: points to the `:files` target of the
  `DEFAULT_VERSION`.
- `@<REPO_NAME>//:<TARGET>`: points to the specific `TARGET` of the
  `DEFAULT_VERSION`.
- `@<REPO_NAME>//<VERSION>:<TARGET>`: points to the specific `TARGET` of that
  `VERSION`.

The `archives` repository rule creates a `@<REPO_NAME>` Bazel repo with a
public `//<VERSION>` package for every version in the index.

Each `//<VERSION>` package has three targets:
- `:files`: to access all the files in the downloaded archive.
- `:dir`: the path to the directory where the archive was extracted.
- `:<VERSION>`: `alias` of `:files`.

and two constants:
- `VERSION`: the version of the archive.
- `SOURCE`: the source from which the archive was downloaded.

Each `//<VERSION>` package has an *internal* `<SOURCE>` sub-package with
the actual files from the downloaded archive for that specific `version` and
`source`. The targets in the `//<VERSION>` package are aliases for targets in
the `//<VERSION>/<SOURCE>` sub-packages.

The root package `//` has three targets:
- `:files`: to access all the files in the `DEFAULT_VERSION` package.
- `:dir`: the path to the directory of the `DEFAULT_VERSION` package.
- `:<REPO_NAME>`: `alias` of `:files`.

and two constants:
- `VERSION`: the `DEFAULT_VERSION` of the archive.
- `SOURCE`: the source from which the default version was downloaded.

The root package also has the following:
- `//:index.json`: a copy of the repo index JSON file.
- `//:lock.json`: the repo lock file (see below).
- `//:metadata.json`: the repo metadata.
- `//:repo.bzl`: extension with the following constants:
  - `REPO_NAME`: The short repo name.
  - `SOURCES`: a mapping of the downloaded `version`s to the `source` from
    which the archive was downloaded.
  - `DEFAULT_VERSION`: the default `version` of the archive.
  - `LOCK`: a `dict` with the contents of the repo `lock.json`.
  - `METADATA`: the free-form metadata map straight from the repo JSON index,
    if any.
- `//patches`: a package with `<VERSION>/<SOURCE>` sub-packages with the
  applied patches applied to that archive, if any (see ["Patching"] below).

The repo lock file contains a mapping of the downloaded `version` to a "lock
object" with the following properties:
  - `source`: the source from which the archive was downloaded.
  - `url`: the URL from which the archive was downloaded.
  - `integrity`: the SRI ([Subresource Integrity (SRI)]) of the downloaded archive.
  - `patches`: the list of patches applied to the archive after download, if any.

["Patching"]: #patching
[Subresource Integrity (SRI)]: https://w3c.github.io/webappsec-subresource-integrity/
["materialized repo `context`"]: ../../lib/index.md#materialized-repo-context
[`rctx.download_and_extract`]: https://bazel.build/rules/lib/builtins/repository_ctx#download_and_extract
[repo JSON index]: ../../lib/index.md

### Selecting `versions` and `sources`

Users can also override the default selection of versions and sources with the
`versions` and `sources` arguments.

Note that selecting specific versions and/or arguments will change the values
of `VERSIONS` and `DEFAULT_VERSION`.

### Version scheme

The `version_scheme` attribute defines the format used for versions in both the
`index` and `patches`. The supported schemes are those in [`version_utils`'
`version` extension], with `SCHEME.SEMVER` ([semantic versioning]) being the
default.

[semantic versioning]: https://semver.org
[`version_utils`' `version` extension]: https://github.com/jjmaestro/bazel_version_utils/blob/main/docs/version/version.md

### Patching

The downloaded archive can also be patched by passing a `patches` argument, a
map of `Label`s of [unified diff format] patch files (applied from the root of
the downloaded archive) to "patch specs" that determine if the patch is to be
applied.

The "patch spec" format is `<VERSION_SPEC>[/<SOURCE>]`, where:

- `<VERSION_SPEC>` is a version constraints requirement spec that
  to specify the versions to which the patch applies.
- `<SOURCE>` (optional, defaults to `*`) is the source of the downloaded
  archive to which the patch should be applied. It's optional and it can also
  be `*`, a wildcard to apply the patch to the archives downloaded from any
  source.

The `<VERSION_SPEC>` syntax is specified with the `spec_syntax` attribute. It's
one of the syntaxes supported by [`version_utils`' `spec` extension] and the
default is `SYNTAX.SIMPLE`.

This helps to maintain patches that apply to e.g.:

- a specific version and source: `1.24.5/github`
- a specific version and all sources: `1.24.5/*` or `1.24.5`
- a range of versions and all sources: `>=1.24.5, <2.0.0/*`
- all versions and sources: `*` or `*/*`

Finally, to simplify patch maintenance, it's good practice to keep a dedicated
"patched branch" for each version we want to maintain, making it easy to
generate the list of patches using [`git format-patch`].

[unified diff format]: https://en.wikipedia.org/wiki/Diff#Unified_format
+[`version_utils` `spec` extension]: https://github.com/jjmaestro/bazel_version_utils/blob/main/docs/specs/spec.md
[`git format-patch`]: https://git-scm.com/docs/git-format-patch

### Usage:

Here's an example that shows how to create a `@wget_src` repo for [GNU wget]:

[GNU wget]: https://www.gnu.org/software/wget/

#### 1. Create the repo index

First, define a `repo.json` JSON index file in a package. Don't forget to add a
`BUILD.bazel` file in it if one doesn't already exists).

E.g. for a `//third-party/wget` package:

```sh
mkdir -p third-party/wget
touch third-party/wget/BUILD.bazel
```

Then add the following to the `repo.json` file:

```json
{
  "version": 1,
  "sources": {
    "github.com": {
      "owner": "mirror",
      "repo": "wget",
      "tag": "v{version}",
      "url": "https://{source}/{owner}/{repo}/archive/refs/tags/{tag}.tar.gz",
      "strip_prefix": "{repo}-{version}"
    },
    "gitlab.com": {
      "owner": "gnuwget",
      "repo": "wget",
      "tag": "v{version}",
      "filename": "{repo}-{tag}",
      "url": "https://{source}/{owner}/{repo}/-/archive/{tag}/{filename}.tar.gz",
      "strip_prefix": "{filename}"
    }
  },
  "versions": {
    "1.24.5": {
      "integrity": {
        "gitlab.com": "sha256-1Yw1cok0niLv563o07/BrjbCQIflWxK8UFlav9srtcw="
      }
    },
    "1.21.3": {
      "integrity": {
        "github.com": "sha256-VbH6fHnent2TtbYxbNoatK4RNkY3MVPXokJhRzPZBg8=",
        "gitlab.com": "sha256-3w3ImvW4t/H2eMkZbUH+F1zkARSI3cIJSgJFg4ULPU4="
      }
    }
  }
}
```

#### 2. Add the `download_archives` repo to `MODULE.bazel`

Then, add the following to `MODULE.bazel`:

```starlark
download_archives = use_repo_rule("@download_archives//download/archives:defs.bzl", "download_archives")

download_archives(
    name = "wget_src",
    index = "//third-party/wget:repo.json",
    # NOTE:
    # This is how you would add a custom patch for one of the versions. See
    # "Patching" docs for more information about patches.
    # patches = {
    #    "//third-party/wget/patches:0001-1.24.5-test-patch.patch": ">=1.24.5/*",
    # },
    # NOTE:
    # This is needed because the archives have different integrity across the
    # mirrors (see v1.21.3)
    strict_integrity = False,
)
```

#### 3. Test it

To test the Bazel repo, run `bazel fetch @wget_src`. This will attempt to
download and extract all the versions defined in the repo index from the
available sources.

As mentioned before, it will stop downloading any other source for a specific
version when there's a successful download from one source. And, if all
downloads from all sources of a given version fail, it will `fail` with an
error.

Note that in the `repo.json` JSON index file there's one `integrity` missing
for one of the sources (version `1.24.5`, source `github.com`). When this
happens a warning message is printed when the archive download begins asking
the user to add the integrity to the index. And, if the archive is successfully
downloaded, a message with the [Subresource Integrity (SRI)] (`integrity`) and
`SHA256` hex digest will be printed so that it's easy to copy-paste one of them
in the index.

Also note that we set `strict_integrity = False` because the archives for
version `1.21.3` have different integrity hashes across sources. With
`strict_integrity = True`, this would cause the download to fail. Since this
can make builds non-reproducible, the default remains `True`. The option exists
because many artifacts share identical source code but differ in packaging or
other details, resulting in mismatched integrities.

Once installed, the `@wget_src` repo will have the following:

- helper constants available to import from `@wget_src//:repo.bzl`:
  - `REPO_NAME = "wget_src"`
  - `VERSIONS = {"1.24.5": "github.com", "1.21.3": "github.com"}`
  - `DEFAULT_VERSION = "1.24.5"`
  - `LOCK = {...}` (the contents of the repo `lock.json`)

- specific `<VERSION>/<SOURCE>` repos:
  - `@wget_src//1.24.5/github.com`
  - `@wget_src//1.21.3/github.com`

- `alias` repos:
  - `@wget_src` --> `@wget_src//1.24.5/github.com`
  - `@wget_src//1.24.5` --> `@wget_src//1.24.5/github.com`
  - `@wget_src//1.21.3` --> `@wget_src//1.21.3/github.com`

<details>
<summary><h4>More details</h4></summary>

To list all the targets in the repo, run `bazel query @wget_src//...`:

```sh
@wget_src//:dir
@wget_src//:files
@wget_src//:wget_src
@wget_src//1.21.3:1.21.3
@wget_src//1.21.3:dir
@wget_src//1.21.3:files
@wget_src//1.21.3/github.com:dir
@wget_src//1.21.3/github.com:files
@wget_src//1.21.3/github.com:github.com
@wget_src//1.24.5:1.24.5
@wget_src//1.24.5:dir
@wget_src//1.24.5:files
@wget_src//1.24.5/github.com:dir
@wget_src//1.24.5/github.com:files
@wget_src//1.24.5/github.com:github.com
```

In cases where we have many versions and sources in the index we can select the
versions and/or sources from which to download using the `versions` and
`sources` arguments:

```starlark
download_archives(
    name = "wget_src",
    index = "//third-party/wget:repo.json",
    versions = ["1.21.3"],
    sources = ["gitlab.com"],
)
```

Selecting `versions` and `sources` changes what's installed and available in
the `@wget_src` repo:

- helper constants available to import from `@wget_src//:repo.bzl`:
  - `REPO_NAME = "wget_src"`
  - `VERSIONS = {"1.21.3": "gitlab.com"}`
  - `DEFAULT_VERSION = "1.21.3"`

- specific `<VERSION>/<SOURCE>` repos:
  - `@wget_src//1.21.3/gitlab.com`

- `alias` repos:
  - `@wget_src` --> `@wget_src//1.21.3/gitlab.com`
  - `@wget_src//1.21.3` --> `@wget_src//1.21.3/gitlab.com`

Again, let's list all the targets with `bazel query @wget_src//...`:

```sh
@wget_src//:dir
@wget_src//:files
@wget_src//:wget_src
@wget_src//1.21.3:1.21.3
@wget_src//1.21.3:dir
@wget_src//1.21.3:files
@wget_src//1.21.3/gitlab.com:dir
@wget_src//1.21.3/gitlab.com:files
@wget_src//1.21.3/gitlab.com:gitlab.com
```

Similarly, remember that the sources are used as "mirrors" so if the first one
fails to download, the next source will be attempted. Thus, the `VERSIONS`
helper constant, the `alias` repos and the repo `lock.json` will all change
accordingly.

For example, imagine that `github` has version `1.24.5` available but not
`1.21.3`. Then, the download will fall back to the `gitlab.com` source and, if
successful, the `@wget_src` repo will have the following:

- helper constants available to import from `@wget_src//:repo.bzl`:
  - `REPO_NAME = "wget_src"`
  - `VERSIONS = {"1.24.5": "github.com", "1.21.3": "gitlab.com"}`
  - `DEFAULT_VERSION = "1.24.5"`
  - `LOCK = {...}` (the new contents of the repo `lock.json`)

- specific `<VERSION>/<SOURCE>` repos:
  - `@wget_src//1.24.5/github.com`
  - `@wget_src//1.21.3/gitlab.com`

- `alias` repos:
  - `@wget_src` --> `@wget_src//1.24.5/github`
  - `@wget_src//1.24.5` --> `@wget_src//1.24.5/github.com`
  - `@wget_src//1.21.3` --> `@wget_src//1.21.3/gitlab.com`


In this case, the list of targets would look like:

```sh
@wget_src//:dir
@wget_src//:files
@wget_src//:wget_src
@wget_src//1.21.3:1.21.3
@wget_src//1.21.3:dir
@wget_src//1.21.3:files
@wget_src//1.21.3/gitlab.com:dir
@wget_src//1.21.3/gitlab.com:files
@wget_src//1.21.3/gitlab.com:gitlab.com
@wget_src//1.24.5:1.24.5
@wget_src//1.24.5:dir
@wget_src//1.24.5:files
@wget_src//1.24.5/github.com:dir
@wget_src//1.24.5/github.com:files
@wget_src//1.24.5/github.com:github.com
```

</details>
R��
�y
archives�h
This repository rule wraps [`rctx.download_and_extract`] and creates a Bazel
repo under `@<REPO_NAME>`, downloading and extracting *one archive* from *one*
of the sources for *each* of the archive versions in the [repo JSON index].

When downloading the archive, if a source fails it will try the next one, and
only fail if all sources are exhausted.

To construct the arguments passed to [`rctx.download_and_extract`] it uses the
["materialized repo `context`"], which includes at minimum the materialized
`url` from which to download the archive.

### Repo structure

```
  @<REPO_NAME>/
   |
   |-- <VERSION>/
   |   |-- BUILD.bazel
   |   `-- <SOURCE>/
   |       |-- BUILD.bazel
   |       |-- ...
   |       `-- ...
   |
   |-- BUILD.bazel
   |-- index.json
   |-- lock.json
   |-- metadata.json
   |-- repo.bzl
   `-- patches/
       |-- <VERSION>/
           `-- <SOURCE>/
               |-- <PATCH_NAME>
               `-- ...
```

TL;DR, the repo can be used as follows:

- `@<REPO_NAME>//:<REPO_NAME>`: points to the `:files` target of the
  `DEFAULT_VERSION`.
- `@<REPO_NAME>//:<TARGET>`: points to the specific `TARGET` of the
  `DEFAULT_VERSION`.
- `@<REPO_NAME>//<VERSION>:<TARGET>`: points to the specific `TARGET` of that
  `VERSION`.

The `archives` repository rule creates a `@<REPO_NAME>` Bazel repo with a
public `//<VERSION>` package for every version in the index.

Each `//<VERSION>` package has three targets:
- `:files`: to access all the files in the downloaded archive.
- `:dir`: the path to the directory where the archive was extracted.
- `:<VERSION>`: `alias` of `:files`.

and two constants:
- `VERSION`: the version of the archive.
- `SOURCE`: the source from which the archive was downloaded.

Each `//<VERSION>` package has an *internal* `<SOURCE>` sub-package with
the actual files from the downloaded archive for that specific `version` and
`source`. The targets in the `//<VERSION>` package are aliases for targets in
the `//<VERSION>/<SOURCE>` sub-packages.

The root package `//` has three targets:
- `:files`: to access all the files in the `DEFAULT_VERSION` package.
- `:dir`: the path to the directory of the `DEFAULT_VERSION` package.
- `:<REPO_NAME>`: `alias` of `:files`.

and two constants:
- `VERSION`: the `DEFAULT_VERSION` of the archive.
- `SOURCE`: the source from which the default version was downloaded.

The root package also has the following:
- `//:index.json`: a copy of the repo index JSON file.
- `//:lock.json`: the repo lock file (see below).
- `//:metadata.json`: the repo metadata.
- `//:repo.bzl`: extension with the following constants:
  - `REPO_NAME`: The short repo name.
  - `SOURCES`: a mapping of the downloaded `version`s to the `source` from
    which the archive was downloaded.
  - `DEFAULT_VERSION`: the default `version` of the archive.
  - `LOCK`: a `dict` with the contents of the repo `lock.json`.
  - `METADATA`: the free-form metadata map straight from the repo JSON index,
    if any.
- `//patches`: a package with `<VERSION>/<SOURCE>` sub-packages with the
  applied patches applied to that archive, if any (see ["Patching"] below).

The repo lock file contains a mapping of the downloaded `version` to a "lock
object" with the following properties:
  - `source`: the source from which the archive was downloaded.
  - `url`: the URL from which the archive was downloaded.
  - `integrity`: the SRI ([Subresource Integrity (SRI)]) of the downloaded archive.
  - `patches`: the list of patches applied to the archive after download, if any.

["Patching"]: #patching
[Subresource Integrity (SRI)]: https://w3c.github.io/webappsec-subresource-integrity/
["materialized repo `context`"]: ../../lib/index.md#materialized-repo-context
[`rctx.download_and_extract`]: https://bazel.build/rules/lib/builtins/repository_ctx#download_and_extract
[repo JSON index]: ../../lib/index.md

### Selecting `versions` and `sources`

Users can also override the default selection of versions and sources with the
`versions` and `sources` arguments.

Note that selecting specific versions and/or arguments will change the values
of `VERSIONS` and `DEFAULT_VERSION`.

### Version scheme

The `version_scheme` attribute defines the format used for versions in both the
`index` and `patches`. The supported schemes are those in [`version_utils`'
`version` extension], with `SCHEME.SEMVER` ([semantic versioning]) being the
default.

[semantic versioning]: https://semver.org
[`version_utils`' `version` extension]: https://github.com/jjmaestro/bazel_version_utils/blob/main/docs/version/version.md

### Patching

The downloaded archive can also be patched by passing a `patches` argument, a
map of `Label`s of [unified diff format] patch files (applied from the root of
the downloaded archive) to "patch specs" that determine if the patch is to be
applied.

The "patch spec" format is `<VERSION_SPEC>[/<SOURCE>]`, where:

- `<VERSION_SPEC>` is a version constraints requirement spec that
  to specify the versions to which the patch applies.
- `<SOURCE>` (optional, defaults to `*`) is the source of the downloaded
  archive to which the patch should be applied. It's optional and it can also
  be `*`, a wildcard to apply the patch to the archives downloaded from any
  source.

The `<VERSION_SPEC>` syntax is specified with the `spec_syntax` attribute. It's
one of the syntaxes supported by [`version_utils`' `spec` extension] and the
default is `SYNTAX.SIMPLE`.

This helps to maintain patches that apply to e.g.:

- a specific version and source: `1.24.5/github`
- a specific version and all sources: `1.24.5/*` or `1.24.5`
- a range of versions and all sources: `>=1.24.5, <2.0.0/*`
- all versions and sources: `*` or `*/*`

Finally, to simplify patch maintenance, it's good practice to keep a dedicated
"patched branch" for each version we want to maintain, making it easy to
generate the list of patches using [`git format-patch`].

[unified diff format]: https://en.wikipedia.org/wiki/Diff#Unified_format
+[`version_utils` `spec` extension]: https://github.com/jjmaestro/bazel_version_utils/blob/main/docs/specs/spec.md
[`git format-patch`]: https://git-scm.com/docs/git-format-patch

### Usage:

Here's an example that shows how to create a `@wget_src` repo for [GNU wget]:

[GNU wget]: https://www.gnu.org/software/wget/

#### 1. Create the repo index

First, define a `repo.json` JSON index file in a package. Don't forget to add a
`BUILD.bazel` file in it if one doesn't already exists).

E.g. for a `//third-party/wget` package:

```sh
mkdir -p third-party/wget
touch third-party/wget/BUILD.bazel
```

Then add the following to the `repo.json` file:

```json
{
  "version": 1,
  "sources": {
    "github.com": {
      "owner": "mirror",
      "repo": "wget",
      "tag": "v{version}",
      "url": "https://{source}/{owner}/{repo}/archive/refs/tags/{tag}.tar.gz",
      "strip_prefix": "{repo}-{version}"
    },
    "gitlab.com": {
      "owner": "gnuwget",
      "repo": "wget",
      "tag": "v{version}",
      "filename": "{repo}-{tag}",
      "url": "https://{source}/{owner}/{repo}/-/archive/{tag}/{filename}.tar.gz",
      "strip_prefix": "{filename}"
    }
  },
  "versions": {
    "1.24.5": {
      "integrity": {
        "gitlab.com": "sha256-1Yw1cok0niLv563o07/BrjbCQIflWxK8UFlav9srtcw="
      }
    },
    "1.21.3": {
      "integrity": {
        "github.com": "sha256-VbH6fHnent2TtbYxbNoatK4RNkY3MVPXokJhRzPZBg8=",
        "gitlab.com": "sha256-3w3ImvW4t/H2eMkZbUH+F1zkARSI3cIJSgJFg4ULPU4="
      }
    }
  }
}
```

#### 2. Add the `download_archives` repo to `MODULE.bazel`

Then, add the following to `MODULE.bazel`:

```starlark
download_archives = use_repo_rule("@download_archives//download/archives:defs.bzl", "download_archives")

download_archives(
    name = "wget_src",
    index = "//third-party/wget:repo.json",
    # NOTE:
    # This is how you would add a custom patch for one of the versions. See
    # "Patching" docs for more information about patches.
    # patches = {
    #    "//third-party/wget/patches:0001-1.24.5-test-patch.patch": ">=1.24.5/*",
    # },
    # NOTE:
    # This is needed because the archives have different integrity across the
    # mirrors (see v1.21.3)
    strict_integrity = False,
)
```

#### 3. Test it

To test the Bazel repo, run `bazel fetch @wget_src`. This will attempt to
download and extract all the versions defined in the repo index from the
available sources.

As mentioned before, it will stop downloading any other source for a specific
version when there's a successful download from one source. And, if all
downloads from all sources of a given version fail, it will `fail` with an
error.

Note that in the `repo.json` JSON index file there's one `integrity` missing
for one of the sources (version `1.24.5`, source `github.com`). When this
happens a warning message is printed when the archive download begins asking
the user to add the integrity to the index. And, if the archive is successfully
downloaded, a message with the [Subresource Integrity (SRI)] (`integrity`) and
`SHA256` hex digest will be printed so that it's easy to copy-paste one of them
in the index.

Also note that we set `strict_integrity = False` because the archives for
version `1.21.3` have different integrity hashes across sources. With
`strict_integrity = True`, this would cause the download to fail. Since this
can make builds non-reproducible, the default remains `True`. The option exists
because many artifacts share identical source code but differ in packaging or
other details, resulting in mismatched integrities.

Once installed, the `@wget_src` repo will have the following:

- helper constants available to import from `@wget_src//:repo.bzl`:
  - `REPO_NAME = "wget_src"`
  - `VERSIONS = {"1.24.5": "github.com", "1.21.3": "github.com"}`
  - `DEFAULT_VERSION = "1.24.5"`
  - `LOCK = {...}` (the contents of the repo `lock.json`)

- specific `<VERSION>/<SOURCE>` repos:
  - `@wget_src//1.24.5/github.com`
  - `@wget_src//1.21.3/github.com`

- `alias` repos:
  - `@wget_src` --> `@wget_src//1.24.5/github.com`
  - `@wget_src//1.24.5` --> `@wget_src//1.24.5/github.com`
  - `@wget_src//1.21.3` --> `@wget_src//1.21.3/github.com`

<details>
<summary><h4>More details</h4></summary>

To list all the targets in the repo, run `bazel query @wget_src//...`:

```sh
@wget_src//:dir
@wget_src//:files
@wget_src//:wget_src
@wget_src//1.21.3:1.21.3
@wget_src//1.21.3:dir
@wget_src//1.21.3:files
@wget_src//1.21.3/github.com:dir
@wget_src//1.21.3/github.com:files
@wget_src//1.21.3/github.com:github.com
@wget_src//1.24.5:1.24.5
@wget_src//1.24.5:dir
@wget_src//1.24.5:files
@wget_src//1.24.5/github.com:dir
@wget_src//1.24.5/github.com:files
@wget_src//1.24.5/github.com:github.com
```

In cases where we have many versions and sources in the index we can select the
versions and/or sources from which to download using the `versions` and
`sources` arguments:

```starlark
download_archives(
    name = "wget_src",
    index = "//third-party/wget:repo.json",
    versions = ["1.21.3"],
    sources = ["gitlab.com"],
)
```

Selecting `versions` and `sources` changes what's installed and available in
the `@wget_src` repo:

- helper constants available to import from `@wget_src//:repo.bzl`:
  - `REPO_NAME = "wget_src"`
  - `VERSIONS = {"1.21.3": "gitlab.com"}`
  - `DEFAULT_VERSION = "1.21.3"`

- specific `<VERSION>/<SOURCE>` repos:
  - `@wget_src//1.21.3/gitlab.com`

- `alias` repos:
  - `@wget_src` --> `@wget_src//1.21.3/gitlab.com`
  - `@wget_src//1.21.3` --> `@wget_src//1.21.3/gitlab.com`

Again, let's list all the targets with `bazel query @wget_src//...`:

```sh
@wget_src//:dir
@wget_src//:files
@wget_src//:wget_src
@wget_src//1.21.3:1.21.3
@wget_src//1.21.3:dir
@wget_src//1.21.3:files
@wget_src//1.21.3/gitlab.com:dir
@wget_src//1.21.3/gitlab.com:files
@wget_src//1.21.3/gitlab.com:gitlab.com
```

Similarly, remember that the sources are used as "mirrors" so if the first one
fails to download, the next source will be attempted. Thus, the `VERSIONS`
helper constant, the `alias` repos and the repo `lock.json` will all change
accordingly.

For example, imagine that `github` has version `1.24.5` available but not
`1.21.3`. Then, the download will fall back to the `gitlab.com` source and, if
successful, the `@wget_src` repo will have the following:

- helper constants available to import from `@wget_src//:repo.bzl`:
  - `REPO_NAME = "wget_src"`
  - `VERSIONS = {"1.24.5": "github.com", "1.21.3": "gitlab.com"}`
  - `DEFAULT_VERSION = "1.24.5"`
  - `LOCK = {...}` (the new contents of the repo `lock.json`)

- specific `<VERSION>/<SOURCE>` repos:
  - `@wget_src//1.24.5/github.com`
  - `@wget_src//1.21.3/gitlab.com`

- `alias` repos:
  - `@wget_src` --> `@wget_src//1.24.5/github`
  - `@wget_src//1.24.5` --> `@wget_src//1.24.5/github.com`
  - `@wget_src//1.21.3` --> `@wget_src//1.21.3/gitlab.com`


In this case, the list of targets would look like:

```sh
@wget_src//:dir
@wget_src//:files
@wget_src//:wget_src
@wget_src//1.21.3:1.21.3
@wget_src//1.21.3:dir
@wget_src//1.21.3:files
@wget_src//1.21.3/gitlab.com:dir
@wget_src//1.21.3/gitlab.com:files
@wget_src//1.21.3/gitlab.com:gitlab.com
@wget_src//1.24.5:1.24.5
@wget_src//1.24.5:dir
@wget_src//1.24.5:files
@wget_src//1.24.5/github.com:dir
@wget_src//1.24.5/github.com:files
@wget_src//1.24.5/github.com:github.com
```

</details>
.
name"A unique name for this repository. )
indexLabel of the repo JSON index �
patches�
Diff files to apply as patches at the root of the downloaded archive.
The `dict` values represent "patch specs" in the
`<VERSION_SPEC>/<SOURCE>` format, and determine when patches apply to
the downloaded archive. Patches must be in standard [unified diff
format], created from the root of the archive. All patches are applied
from the root of the archive with `patch -p1`. For more details, see
["Patching"].
	2{}�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
sources�
Source names from which to download the archive. If none is specified,
it will use all of the sources available in the repo index to try to
download and extract the archive.
2[]�
spec_syntax�
The syntax of the version constraints specification. The available
syntaxes are those supported by `version_utils` (see `SYNTAX` in
[`version_utils`' `spec`
extension](https://github.com/jjmaestro/bazel_version_utils/blob/main/spec/spec.bzl)).
Defaults to `SYNTAX.SIMPLE`.
2"simple"�
strict_integrity�
If `True`, all sources of a given archive version must share the same
integrity hash. If they differ, the download will fail. Defaults to
`True`.
2True�
version_scheme�
The scheme of the versions in `index` and `patches`. The available
version schemes are those supported by `version_utils` (see `SCHEME` in
[`version_utils`' `version`
extension](https://github.com/jjmaestro/bazel_version_utils/blob/main/version/version.bzl)).
Defaults to `SCHEME.SEMVER`.
2"semver"�
versions}
Versions of the archive to download. If none is specified it will
download all of the versions available in the repo index.
2[]*A
archives5@@download_archives//download/archives:repository.bzl
��0
.
name"A unique name for this repository. +
)
indexLabel of the repo JSON index �
�
patches�
Diff files to apply as patches at the root of the downloaded archive.
The `dict` values represent "patch specs" in the
`<VERSION_SPEC>/<SOURCE>` format, and determine when patches apply to
the downloaded archive. Patches must be in standard [unified diff
format], created from the root of the archive. All patches are applied
from the root of the archive with `patch -p1`. For more details, see
["Patching"].
	2{}�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
�
sources�
Source names from which to download the archive. If none is specified,
it will use all of the sources available in the repo index to try to
download and extract the archive.
2[]�
�
spec_syntax�
The syntax of the version constraints specification. The available
syntaxes are those supported by `version_utils` (see `SYNTAX` in
[`version_utils`' `spec`
extension](https://github.com/jjmaestro/bazel_version_utils/blob/main/spec/spec.bzl)).
Defaults to `SYNTAX.SIMPLE`.
2"simple"�
�
strict_integrity�
If `True`, all sources of a given archive version must share the same
integrity hash. If they differ, the download will fail. Defaults to
`True`.
2True�
�
version_scheme�
The scheme of the versions in `index` and `patches`. The available
version schemes are those supported by `version_utils` (see `SCHEME` in
[`version_utils`' `version`
extension](https://github.com/jjmaestro/bazel_version_utils/blob/main/version/version.bzl)).
Defaults to `SCHEME.SEMVER`.
2"semver"�
�
versions}
Versions of the archive to download. If none is specified it will
download all of the versions available in the repo index.
2[]f
//lib:index.bzlrQ
#
download_archiveslib	index.bzl
indexIndex

+
0


;`
//spec:spec.bzlrK

version_utilsspecspec.bzl
specSpec
'+
5r
//version:version.bzlrW
%
version_utilsversionversion.bzl 
versionVersion
-4
A�	BUILD_VERSION�"""Generated by download_archives. DO NOT EDIT."""

load("//:repo.bzl", "VERSIONS")

package(default_visibility = ["//visibility:public"])

VERSION = "{version}"

SOURCE = VERSIONS[VERSION]

alias(
    name = "files",
    actual = "//{{}}/{{}}:files".format(VERSION, SOURCE),
)

alias(
    name = "dir",
    actual = "//{{}}/{{}}:dir".format(VERSION, SOURCE),
)

alias(
    name = "{alias}",
    actual = ":files",
)
j��"""Generated by download_archives. DO NOT EDIT."""

load("//:repo.bzl", "VERSIONS")

package(default_visibility = ["//visibility:public"])

VERSION = "{version}"

SOURCE = VERSIONS[VERSION]

alias(
    name = "files",
    actual = "//{{}}/{{}}:files".format(VERSION, SOURCE),
)

alias(
    name = "dir",
    actual = "//{{}}/{{}}:dir".format(VERSION, SOURCE),
)

alias(
    name = "{alias}",
    actual = ":files",
)
��	DOC�h
This repository rule wraps [`rctx.download_and_extract`] and creates a Bazel
repo under `@<REPO_NAME>`, downloading and extracting *one archive* from *one*
of the sources for *each* of the archive versions in the [repo JSON index].

When downloading the archive, if a source fails it will try the next one, and
only fail if all sources are exhausted.

To construct the arguments passed to [`rctx.download_and_extract`] it uses the
["materialized repo `context`"], which includes at minimum the materialized
`url` from which to download the archive.

### Repo structure

```
  @<REPO_NAME>/
   |
   |-- <VERSION>/
   |   |-- BUILD.bazel
   |   `-- <SOURCE>/
   |       |-- BUILD.bazel
   |       |-- ...
   |       `-- ...
   |
   |-- BUILD.bazel
   |-- index.json
   |-- lock.json
   |-- metadata.json
   |-- repo.bzl
   `-- patches/
       |-- <VERSION>/
           `-- <SOURCE>/
               |-- <PATCH_NAME>
               `-- ...
```

TL;DR, the repo can be used as follows:

- `@<REPO_NAME>//:<REPO_NAME>`: points to the `:files` target of the
  `DEFAULT_VERSION`.
- `@<REPO_NAME>//:<TARGET>`: points to the specific `TARGET` of the
  `DEFAULT_VERSION`.
- `@<REPO_NAME>//<VERSION>:<TARGET>`: points to the specific `TARGET` of that
  `VERSION`.

The `archives` repository rule creates a `@<REPO_NAME>` Bazel repo with a
public `//<VERSION>` package for every version in the index.

Each `//<VERSION>` package has three targets:
- `:files`: to access all the files in the downloaded archive.
- `:dir`: the path to the directory where the archive was extracted.
- `:<VERSION>`: `alias` of `:files`.

and two constants:
- `VERSION`: the version of the archive.
- `SOURCE`: the source from which the archive was downloaded.

Each `//<VERSION>` package has an *internal* `<SOURCE>` sub-package with
the actual files from the downloaded archive for that specific `version` and
`source`. The targets in the `//<VERSION>` package are aliases for targets in
the `//<VERSION>/<SOURCE>` sub-packages.

The root package `//` has three targets:
- `:files`: to access all the files in the `DEFAULT_VERSION` package.
- `:dir`: the path to the directory of the `DEFAULT_VERSION` package.
- `:<REPO_NAME>`: `alias` of `:files`.

and two constants:
- `VERSION`: the `DEFAULT_VERSION` of the archive.
- `SOURCE`: the source from which the default version was downloaded.

The root package also has the following:
- `//:index.json`: a copy of the repo index JSON file.
- `//:lock.json`: the repo lock file (see below).
- `//:metadata.json`: the repo metadata.
- `//:repo.bzl`: extension with the following constants:
  - `REPO_NAME`: The short repo name.
  - `SOURCES`: a mapping of the downloaded `version`s to the `source` from
    which the archive was downloaded.
  - `DEFAULT_VERSION`: the default `version` of the archive.
  - `LOCK`: a `dict` with the contents of the repo `lock.json`.
  - `METADATA`: the free-form metadata map straight from the repo JSON index,
    if any.
- `//patches`: a package with `<VERSION>/<SOURCE>` sub-packages with the
  applied patches applied to that archive, if any (see ["Patching"] below).

The repo lock file contains a mapping of the downloaded `version` to a "lock
object" with the following properties:
  - `source`: the source from which the archive was downloaded.
  - `url`: the URL from which the archive was downloaded.
  - `integrity`: the SRI ([Subresource Integrity (SRI)]) of the downloaded archive.
  - `patches`: the list of patches applied to the archive after download, if any.

["Patching"]: #patching
[Subresource Integrity (SRI)]: https://w3c.github.io/webappsec-subresource-integrity/
["materialized repo `context`"]: ../../lib/index.md#materialized-repo-context
[`rctx.download_and_extract`]: https://bazel.build/rules/lib/builtins/repository_ctx#download_and_extract
[repo JSON index]: ../../lib/index.md

### Selecting `versions` and `sources`

Users can also override the default selection of versions and sources with the
`versions` and `sources` arguments.

Note that selecting specific versions and/or arguments will change the values
of `VERSIONS` and `DEFAULT_VERSION`.

### Version scheme

The `version_scheme` attribute defines the format used for versions in both the
`index` and `patches`. The supported schemes are those in [`version_utils`'
`version` extension], with `SCHEME.SEMVER` ([semantic versioning]) being the
default.

[semantic versioning]: https://semver.org
[`version_utils`' `version` extension]: https://github.com/jjmaestro/bazel_version_utils/blob/main/docs/version/version.md

### Patching

The downloaded archive can also be patched by passing a `patches` argument, a
map of `Label`s of [unified diff format] patch files (applied from the root of
the downloaded archive) to "patch specs" that determine if the patch is to be
applied.

The "patch spec" format is `<VERSION_SPEC>[/<SOURCE>]`, where:

- `<VERSION_SPEC>` is a version constraints requirement spec that
  to specify the versions to which the patch applies.
- `<SOURCE>` (optional, defaults to `*`) is the source of the downloaded
  archive to which the patch should be applied. It's optional and it can also
  be `*`, a wildcard to apply the patch to the archives downloaded from any
  source.

The `<VERSION_SPEC>` syntax is specified with the `spec_syntax` attribute. It's
one of the syntaxes supported by [`version_utils`' `spec` extension] and the
default is `SYNTAX.SIMPLE`.

This helps to maintain patches that apply to e.g.:

- a specific version and source: `1.24.5/github`
- a specific version and all sources: `1.24.5/*` or `1.24.5`
- a range of versions and all sources: `>=1.24.5, <2.0.0/*`
- all versions and sources: `*` or `*/*`

Finally, to simplify patch maintenance, it's good practice to keep a dedicated
"patched branch" for each version we want to maintain, making it easy to
generate the list of patches using [`git format-patch`].

[unified diff format]: https://en.wikipedia.org/wiki/Diff#Unified_format
+[`version_utils` `spec` extension]: https://github.com/jjmaestro/bazel_version_utils/blob/main/docs/specs/spec.md
[`git format-patch`]: https://git-scm.com/docs/git-format-patch

### Usage:

Here's an example that shows how to create a `@wget_src` repo for [GNU wget]:

[GNU wget]: https://www.gnu.org/software/wget/

#### 1. Create the repo index

First, define a `repo.json` JSON index file in a package. Don't forget to add a
`BUILD.bazel` file in it if one doesn't already exists).

E.g. for a `//third-party/wget` package:

```sh
mkdir -p third-party/wget
touch third-party/wget/BUILD.bazel
```

Then add the following to the `repo.json` file:

```json
{
  "version": 1,
  "sources": {
    "github.com": {
      "owner": "mirror",
      "repo": "wget",
      "tag": "v{version}",
      "url": "https://{source}/{owner}/{repo}/archive/refs/tags/{tag}.tar.gz",
      "strip_prefix": "{repo}-{version}"
    },
    "gitlab.com": {
      "owner": "gnuwget",
      "repo": "wget",
      "tag": "v{version}",
      "filename": "{repo}-{tag}",
      "url": "https://{source}/{owner}/{repo}/-/archive/{tag}/{filename}.tar.gz",
      "strip_prefix": "{filename}"
    }
  },
  "versions": {
    "1.24.5": {
      "integrity": {
        "gitlab.com": "sha256-1Yw1cok0niLv563o07/BrjbCQIflWxK8UFlav9srtcw="
      }
    },
    "1.21.3": {
      "integrity": {
        "github.com": "sha256-VbH6fHnent2TtbYxbNoatK4RNkY3MVPXokJhRzPZBg8=",
        "gitlab.com": "sha256-3w3ImvW4t/H2eMkZbUH+F1zkARSI3cIJSgJFg4ULPU4="
      }
    }
  }
}
```

#### 2. Add the `download_archives` repo to `MODULE.bazel`

Then, add the following to `MODULE.bazel`:

```starlark
download_archives = use_repo_rule("@download_archives//download/archives:defs.bzl", "download_archives")

download_archives(
    name = "wget_src",
    index = "//third-party/wget:repo.json",
    # NOTE:
    # This is how you would add a custom patch for one of the versions. See
    # "Patching" docs for more information about patches.
    # patches = {
    #    "//third-party/wget/patches:0001-1.24.5-test-patch.patch": ">=1.24.5/*",
    # },
    # NOTE:
    # This is needed because the archives have different integrity across the
    # mirrors (see v1.21.3)
    strict_integrity = False,
)
```

#### 3. Test it

To test the Bazel repo, run `bazel fetch @wget_src`. This will attempt to
download and extract all the versions defined in the repo index from the
available sources.

As mentioned before, it will stop downloading any other source for a specific
version when there's a successful download from one source. And, if all
downloads from all sources of a given version fail, it will `fail` with an
error.

Note that in the `repo.json` JSON index file there's one `integrity` missing
for one of the sources (version `1.24.5`, source `github.com`). When this
happens a warning message is printed when the archive download begins asking
the user to add the integrity to the index. And, if the archive is successfully
downloaded, a message with the [Subresource Integrity (SRI)] (`integrity`) and
`SHA256` hex digest will be printed so that it's easy to copy-paste one of them
in the index.

Also note that we set `strict_integrity = False` because the archives for
version `1.21.3` have different integrity hashes across sources. With
`strict_integrity = True`, this would cause the download to fail. Since this
can make builds non-reproducible, the default remains `True`. The option exists
because many artifacts share identical source code but differ in packaging or
other details, resulting in mismatched integrities.

Once installed, the `@wget_src` repo will have the following:

- helper constants available to import from `@wget_src//:repo.bzl`:
  - `REPO_NAME = "wget_src"`
  - `VERSIONS = {"1.24.5": "github.com", "1.21.3": "github.com"}`
  - `DEFAULT_VERSION = "1.24.5"`
  - `LOCK = {...}` (the contents of the repo `lock.json`)

- specific `<VERSION>/<SOURCE>` repos:
  - `@wget_src//1.24.5/github.com`
  - `@wget_src//1.21.3/github.com`

- `alias` repos:
  - `@wget_src` --> `@wget_src//1.24.5/github.com`
  - `@wget_src//1.24.5` --> `@wget_src//1.24.5/github.com`
  - `@wget_src//1.21.3` --> `@wget_src//1.21.3/github.com`

<details>
<summary><h4>More details</h4></summary>

To list all the targets in the repo, run `bazel query @wget_src//...`:

```sh
@wget_src//:dir
@wget_src//:files
@wget_src//:wget_src
@wget_src//1.21.3:1.21.3
@wget_src//1.21.3:dir
@wget_src//1.21.3:files
@wget_src//1.21.3/github.com:dir
@wget_src//1.21.3/github.com:files
@wget_src//1.21.3/github.com:github.com
@wget_src//1.24.5:1.24.5
@wget_src//1.24.5:dir
@wget_src//1.24.5:files
@wget_src//1.24.5/github.com:dir
@wget_src//1.24.5/github.com:files
@wget_src//1.24.5/github.com:github.com
```

In cases where we have many versions and sources in the index we can select the
versions and/or sources from which to download using the `versions` and
`sources` arguments:

```starlark
download_archives(
    name = "wget_src",
    index = "//third-party/wget:repo.json",
    versions = ["1.21.3"],
    sources = ["gitlab.com"],
)
```

Selecting `versions` and `sources` changes what's installed and available in
the `@wget_src` repo:

- helper constants available to import from `@wget_src//:repo.bzl`:
  - `REPO_NAME = "wget_src"`
  - `VERSIONS = {"1.21.3": "gitlab.com"}`
  - `DEFAULT_VERSION = "1.21.3"`

- specific `<VERSION>/<SOURCE>` repos:
  - `@wget_src//1.21.3/gitlab.com`

- `alias` repos:
  - `@wget_src` --> `@wget_src//1.21.3/gitlab.com`
  - `@wget_src//1.21.3` --> `@wget_src//1.21.3/gitlab.com`

Again, let's list all the targets with `bazel query @wget_src//...`:

```sh
@wget_src//:dir
@wget_src//:files
@wget_src//:wget_src
@wget_src//1.21.3:1.21.3
@wget_src//1.21.3:dir
@wget_src//1.21.3:files
@wget_src//1.21.3/gitlab.com:dir
@wget_src//1.21.3/gitlab.com:files
@wget_src//1.21.3/gitlab.com:gitlab.com
```

Similarly, remember that the sources are used as "mirrors" so if the first one
fails to download, the next source will be attempted. Thus, the `VERSIONS`
helper constant, the `alias` repos and the repo `lock.json` will all change
accordingly.

For example, imagine that `github` has version `1.24.5` available but not
`1.21.3`. Then, the download will fall back to the `gitlab.com` source and, if
successful, the `@wget_src` repo will have the following:

- helper constants available to import from `@wget_src//:repo.bzl`:
  - `REPO_NAME = "wget_src"`
  - `VERSIONS = {"1.24.5": "github.com", "1.21.3": "gitlab.com"}`
  - `DEFAULT_VERSION = "1.24.5"`
  - `LOCK = {...}` (the new contents of the repo `lock.json`)

- specific `<VERSION>/<SOURCE>` repos:
  - `@wget_src//1.24.5/github.com`
  - `@wget_src//1.21.3/gitlab.com`

- `alias` repos:
  - `@wget_src` --> `@wget_src//1.24.5/github`
  - `@wget_src//1.24.5` --> `@wget_src//1.24.5/github.com`
  - `@wget_src//1.21.3` --> `@wget_src//1.21.3/gitlab.com`


In this case, the list of targets would look like:

```sh
@wget_src//:dir
@wget_src//:files
@wget_src//:wget_src
@wget_src//1.21.3:1.21.3
@wget_src//1.21.3:dir
@wget_src//1.21.3:files
@wget_src//1.21.3/gitlab.com:dir
@wget_src//1.21.3/gitlab.com:files
@wget_src//1.21.3/gitlab.com:gitlab.com
@wget_src//1.24.5:1.24.5
@wget_src//1.24.5:dir
@wget_src//1.24.5:files
@wget_src//1.24.5/github.com:dir
@wget_src//1.24.5/github.com:files
@wget_src//1.24.5/github.com:github.com
```

</details>
j�h�h
This repository rule wraps [`rctx.download_and_extract`] and creates a Bazel
repo under `@<REPO_NAME>`, downloading and extracting *one archive* from *one*
of the sources for *each* of the archive versions in the [repo JSON index].

When downloading the archive, if a source fails it will try the next one, and
only fail if all sources are exhausted.

To construct the arguments passed to [`rctx.download_and_extract`] it uses the
["materialized repo `context`"], which includes at minimum the materialized
`url` from which to download the archive.

### Repo structure

```
  @<REPO_NAME>/
   |
   |-- <VERSION>/
   |   |-- BUILD.bazel
   |   `-- <SOURCE>/
   |       |-- BUILD.bazel
   |       |-- ...
   |       `-- ...
   |
   |-- BUILD.bazel
   |-- index.json
   |-- lock.json
   |-- metadata.json
   |-- repo.bzl
   `-- patches/
       |-- <VERSION>/
           `-- <SOURCE>/
               |-- <PATCH_NAME>
               `-- ...
```

TL;DR, the repo can be used as follows:

- `@<REPO_NAME>//:<REPO_NAME>`: points to the `:files` target of the
  `DEFAULT_VERSION`.
- `@<REPO_NAME>//:<TARGET>`: points to the specific `TARGET` of the
  `DEFAULT_VERSION`.
- `@<REPO_NAME>//<VERSION>:<TARGET>`: points to the specific `TARGET` of that
  `VERSION`.

The `archives` repository rule creates a `@<REPO_NAME>` Bazel repo with a
public `//<VERSION>` package for every version in the index.

Each `//<VERSION>` package has three targets:
- `:files`: to access all the files in the downloaded archive.
- `:dir`: the path to the directory where the archive was extracted.
- `:<VERSION>`: `alias` of `:files`.

and two constants:
- `VERSION`: the version of the archive.
- `SOURCE`: the source from which the archive was downloaded.

Each `//<VERSION>` package has an *internal* `<SOURCE>` sub-package with
the actual files from the downloaded archive for that specific `version` and
`source`. The targets in the `//<VERSION>` package are aliases for targets in
the `//<VERSION>/<SOURCE>` sub-packages.

The root package `//` has three targets:
- `:files`: to access all the files in the `DEFAULT_VERSION` package.
- `:dir`: the path to the directory of the `DEFAULT_VERSION` package.
- `:<REPO_NAME>`: `alias` of `:files`.

and two constants:
- `VERSION`: the `DEFAULT_VERSION` of the archive.
- `SOURCE`: the source from which the default version was downloaded.

The root package also has the following:
- `//:index.json`: a copy of the repo index JSON file.
- `//:lock.json`: the repo lock file (see below).
- `//:metadata.json`: the repo metadata.
- `//:repo.bzl`: extension with the following constants:
  - `REPO_NAME`: The short repo name.
  - `SOURCES`: a mapping of the downloaded `version`s to the `source` from
    which the archive was downloaded.
  - `DEFAULT_VERSION`: the default `version` of the archive.
  - `LOCK`: a `dict` with the contents of the repo `lock.json`.
  - `METADATA`: the free-form metadata map straight from the repo JSON index,
    if any.
- `//patches`: a package with `<VERSION>/<SOURCE>` sub-packages with the
  applied patches applied to that archive, if any (see ["Patching"] below).

The repo lock file contains a mapping of the downloaded `version` to a "lock
object" with the following properties:
  - `source`: the source from which the archive was downloaded.
  - `url`: the URL from which the archive was downloaded.
  - `integrity`: the SRI ([Subresource Integrity (SRI)]) of the downloaded archive.
  - `patches`: the list of patches applied to the archive after download, if any.

["Patching"]: #patching
[Subresource Integrity (SRI)]: https://w3c.github.io/webappsec-subresource-integrity/
["materialized repo `context`"]: ../../lib/index.md#materialized-repo-context
[`rctx.download_and_extract`]: https://bazel.build/rules/lib/builtins/repository_ctx#download_and_extract
[repo JSON index]: ../../lib/index.md

### Selecting `versions` and `sources`

Users can also override the default selection of versions and sources with the
`versions` and `sources` arguments.

Note that selecting specific versions and/or arguments will change the values
of `VERSIONS` and `DEFAULT_VERSION`.

### Version scheme

The `version_scheme` attribute defines the format used for versions in both the
`index` and `patches`. The supported schemes are those in [`version_utils`'
`version` extension], with `SCHEME.SEMVER` ([semantic versioning]) being the
default.

[semantic versioning]: https://semver.org
[`version_utils`' `version` extension]: https://github.com/jjmaestro/bazel_version_utils/blob/main/docs/version/version.md

### Patching

The downloaded archive can also be patched by passing a `patches` argument, a
map of `Label`s of [unified diff format] patch files (applied from the root of
the downloaded archive) to "patch specs" that determine if the patch is to be
applied.

The "patch spec" format is `<VERSION_SPEC>[/<SOURCE>]`, where:

- `<VERSION_SPEC>` is a version constraints requirement spec that
  to specify the versions to which the patch applies.
- `<SOURCE>` (optional, defaults to `*`) is the source of the downloaded
  archive to which the patch should be applied. It's optional and it can also
  be `*`, a wildcard to apply the patch to the archives downloaded from any
  source.

The `<VERSION_SPEC>` syntax is specified with the `spec_syntax` attribute. It's
one of the syntaxes supported by [`version_utils`' `spec` extension] and the
default is `SYNTAX.SIMPLE`.

This helps to maintain patches that apply to e.g.:

- a specific version and source: `1.24.5/github`
- a specific version and all sources: `1.24.5/*` or `1.24.5`
- a range of versions and all sources: `>=1.24.5, <2.0.0/*`
- all versions and sources: `*` or `*/*`

Finally, to simplify patch maintenance, it's good practice to keep a dedicated
"patched branch" for each version we want to maintain, making it easy to
generate the list of patches using [`git format-patch`].

[unified diff format]: https://en.wikipedia.org/wiki/Diff#Unified_format
+[`version_utils` `spec` extension]: https://github.com/jjmaestro/bazel_version_utils/blob/main/docs/specs/spec.md
[`git format-patch`]: https://git-scm.com/docs/git-format-patch

### Usage:

Here's an example that shows how to create a `@wget_src` repo for [GNU wget]:

[GNU wget]: https://www.gnu.org/software/wget/

#### 1. Create the repo index

First, define a `repo.json` JSON index file in a package. Don't forget to add a
`BUILD.bazel` file in it if one doesn't already exists).

E.g. for a `//third-party/wget` package:

```sh
mkdir -p third-party/wget
touch third-party/wget/BUILD.bazel
```

Then add the following to the `repo.json` file:

```json
{
  "version": 1,
  "sources": {
    "github.com": {
      "owner": "mirror",
      "repo": "wget",
      "tag": "v{version}",
      "url": "https://{source}/{owner}/{repo}/archive/refs/tags/{tag}.tar.gz",
      "strip_prefix": "{repo}-{version}"
    },
    "gitlab.com": {
      "owner": "gnuwget",
      "repo": "wget",
      "tag": "v{version}",
      "filename": "{repo}-{tag}",
      "url": "https://{source}/{owner}/{repo}/-/archive/{tag}/{filename}.tar.gz",
      "strip_prefix": "{filename}"
    }
  },
  "versions": {
    "1.24.5": {
      "integrity": {
        "gitlab.com": "sha256-1Yw1cok0niLv563o07/BrjbCQIflWxK8UFlav9srtcw="
      }
    },
    "1.21.3": {
      "integrity": {
        "github.com": "sha256-VbH6fHnent2TtbYxbNoatK4RNkY3MVPXokJhRzPZBg8=",
        "gitlab.com": "sha256-3w3ImvW4t/H2eMkZbUH+F1zkARSI3cIJSgJFg4ULPU4="
      }
    }
  }
}
```

#### 2. Add the `download_archives` repo to `MODULE.bazel`

Then, add the following to `MODULE.bazel`:

```starlark
download_archives = use_repo_rule("@download_archives//download/archives:defs.bzl", "download_archives")

download_archives(
    name = "wget_src",
    index = "//third-party/wget:repo.json",
    # NOTE:
    # This is how you would add a custom patch for one of the versions. See
    # "Patching" docs for more information about patches.
    # patches = {
    #    "//third-party/wget/patches:0001-1.24.5-test-patch.patch": ">=1.24.5/*",
    # },
    # NOTE:
    # This is needed because the archives have different integrity across the
    # mirrors (see v1.21.3)
    strict_integrity = False,
)
```

#### 3. Test it

To test the Bazel repo, run `bazel fetch @wget_src`. This will attempt to
download and extract all the versions defined in the repo index from the
available sources.

As mentioned before, it will stop downloading any other source for a specific
version when there's a successful download from one source. And, if all
downloads from all sources of a given version fail, it will `fail` with an
error.

Note that in the `repo.json` JSON index file there's one `integrity` missing
for one of the sources (version `1.24.5`, source `github.com`). When this
happens a warning message is printed when the archive download begins asking
the user to add the integrity to the index. And, if the archive is successfully
downloaded, a message with the [Subresource Integrity (SRI)] (`integrity`) and
`SHA256` hex digest will be printed so that it's easy to copy-paste one of them
in the index.

Also note that we set `strict_integrity = False` because the archives for
version `1.21.3` have different integrity hashes across sources. With
`strict_integrity = True`, this would cause the download to fail. Since this
can make builds non-reproducible, the default remains `True`. The option exists
because many artifacts share identical source code but differ in packaging or
other details, resulting in mismatched integrities.

Once installed, the `@wget_src` repo will have the following:

- helper constants available to import from `@wget_src//:repo.bzl`:
  - `REPO_NAME = "wget_src"`
  - `VERSIONS = {"1.24.5": "github.com", "1.21.3": "github.com"}`
  - `DEFAULT_VERSION = "1.24.5"`
  - `LOCK = {...}` (the contents of the repo `lock.json`)

- specific `<VERSION>/<SOURCE>` repos:
  - `@wget_src//1.24.5/github.com`
  - `@wget_src//1.21.3/github.com`

- `alias` repos:
  - `@wget_src` --> `@wget_src//1.24.5/github.com`
  - `@wget_src//1.24.5` --> `@wget_src//1.24.5/github.com`
  - `@wget_src//1.21.3` --> `@wget_src//1.21.3/github.com`

<details>
<summary><h4>More details</h4></summary>

To list all the targets in the repo, run `bazel query @wget_src//...`:

```sh
@wget_src//:dir
@wget_src//:files
@wget_src//:wget_src
@wget_src//1.21.3:1.21.3
@wget_src//1.21.3:dir
@wget_src//1.21.3:files
@wget_src//1.21.3/github.com:dir
@wget_src//1.21.3/github.com:files
@wget_src//1.21.3/github.com:github.com
@wget_src//1.24.5:1.24.5
@wget_src//1.24.5:dir
@wget_src//1.24.5:files
@wget_src//1.24.5/github.com:dir
@wget_src//1.24.5/github.com:files
@wget_src//1.24.5/github.com:github.com
```

In cases where we have many versions and sources in the index we can select the
versions and/or sources from which to download using the `versions` and
`sources` arguments:

```starlark
download_archives(
    name = "wget_src",
    index = "//third-party/wget:repo.json",
    versions = ["1.21.3"],
    sources = ["gitlab.com"],
)
```

Selecting `versions` and `sources` changes what's installed and available in
the `@wget_src` repo:

- helper constants available to import from `@wget_src//:repo.bzl`:
  - `REPO_NAME = "wget_src"`
  - `VERSIONS = {"1.21.3": "gitlab.com"}`
  - `DEFAULT_VERSION = "1.21.3"`

- specific `<VERSION>/<SOURCE>` repos:
  - `@wget_src//1.21.3/gitlab.com`

- `alias` repos:
  - `@wget_src` --> `@wget_src//1.21.3/gitlab.com`
  - `@wget_src//1.21.3` --> `@wget_src//1.21.3/gitlab.com`

Again, let's list all the targets with `bazel query @wget_src//...`:

```sh
@wget_src//:dir
@wget_src//:files
@wget_src//:wget_src
@wget_src//1.21.3:1.21.3
@wget_src//1.21.3:dir
@wget_src//1.21.3:files
@wget_src//1.21.3/gitlab.com:dir
@wget_src//1.21.3/gitlab.com:files
@wget_src//1.21.3/gitlab.com:gitlab.com
```

Similarly, remember that the sources are used as "mirrors" so if the first one
fails to download, the next source will be attempted. Thus, the `VERSIONS`
helper constant, the `alias` repos and the repo `lock.json` will all change
accordingly.

For example, imagine that `github` has version `1.24.5` available but not
`1.21.3`. Then, the download will fall back to the `gitlab.com` source and, if
successful, the `@wget_src` repo will have the following:

- helper constants available to import from `@wget_src//:repo.bzl`:
  - `REPO_NAME = "wget_src"`
  - `VERSIONS = {"1.24.5": "github.com", "1.21.3": "gitlab.com"}`
  - `DEFAULT_VERSION = "1.24.5"`
  - `LOCK = {...}` (the new contents of the repo `lock.json`)

- specific `<VERSION>/<SOURCE>` repos:
  - `@wget_src//1.24.5/github.com`
  - `@wget_src//1.21.3/gitlab.com`

- `alias` repos:
  - `@wget_src` --> `@wget_src//1.24.5/github`
  - `@wget_src//1.24.5` --> `@wget_src//1.24.5/github.com`
  - `@wget_src//1.21.3` --> `@wget_src//1.21.3/gitlab.com`


In this case, the list of targets would look like:

```sh
@wget_src//:dir
@wget_src//:files
@wget_src//:wget_src
@wget_src//1.21.3:1.21.3
@wget_src//1.21.3:dir
@wget_src//1.21.3:files
@wget_src//1.21.3/gitlab.com:dir
@wget_src//1.21.3/gitlab.com:files
@wget_src//1.21.3/gitlab.com:gitlab.com
@wget_src//1.24.5:1.24.5
@wget_src//1.24.5:dir
@wget_src//1.24.5:files
@wget_src//1.24.5/github.com:dir
@wget_src//1.24.5/github.com:files
@wget_src//1.24.5/github.com:github.com
```

</details>
�	REPO�"""Generated by download_archives. DO NOT EDIT."""

REPO_NAME = "{repo_name}"
VERSIONS = {versions}
DEFAULT_VERSION = "{default_version}"
METADATA = {metadata}
LOCK = {lock}
j��"""Generated by download_archives. DO NOT EDIT."""

REPO_NAME = "{repo_name}"
VERSIONS = {versions}
DEFAULT_VERSION = "{default_version}"
METADATA = {metadata}
LOCK = {lock}
�	BUILD_PATCHES�"""Generated by download_archives. DO NOT EDIT."""

package(default_visibility = ["//visibility:public"])

exports_files(glob(
    [
        "*.patch",
        "*.diff",
    ],
    allow_empty = True,
))
j��"""Generated by download_archives. DO NOT EDIT."""

package(default_visibility = ["//visibility:public"])

exports_files(glob(
    [
        "*.patch",
        "*.diff",
    ],
    allow_empty = True,
))
�
	
BUILD_ROOT�"""Generated by download_archives. DO NOT EDIT."""

load("@bazel_skylib//:bzl_library.bzl", "bzl_library")
load("//:repo.bzl", "DEFAULT_VERSION", "VERSIONS")

package(default_visibility = ["//visibility:public"])

exports_files([
    "repo.bzl",
    "index.json",
    "lock.json",
    "metadata.json",
])

bzl_library(
    name = "repo",
    srcs = ["repo.bzl"],
)

VERSION = DEFAULT_VERSION

SOURCE = VERSIONS[VERSION]

alias(
    name = "files",
    actual = "//{{}}/{{}}:files".format(VERSION, SOURCE),
)

alias(
    name = "dir",
    actual = "//{{}}/{{}}:dir".format(VERSION, SOURCE),
)

alias(
    name = "{alias}",
    actual = ":files",
)
j��"""Generated by download_archives. DO NOT EDIT."""

load("@bazel_skylib//:bzl_library.bzl", "bzl_library")
load("//:repo.bzl", "DEFAULT_VERSION", "VERSIONS")

package(default_visibility = ["//visibility:public"])

exports_files([
    "repo.bzl",
    "index.json",
    "lock.json",
    "metadata.json",
])

bzl_library(
    name = "repo",
    srcs = ["repo.bzl"],
)

VERSION = DEFAULT_VERSION

SOURCE = VERSIONS[VERSION]

alias(
    name = "files",
    actual = "//{{}}/{{}}:files".format(VERSION, SOURCE),
)

alias(
    name = "dir",
    actual = "//{{}}/{{}}:dir".format(VERSION, SOURCE),
)

alias(
    name = "{alias}",
    actual = ":files",
)
�	BUILD_SOURCE�"""Generated by download_archives. DO NOT EDIT."""

# source packages are only visible to their version package
package(default_visibility = ["//:__subpackages__"])

filegroup(
    name = "files",
    srcs = glob(["**"]),
)

# NOTE:
# When using ':dir' we get a warning:
#   WARNING: input '' of <TARGET> is a directory;
#   dependency checking of directories is unsound
# but... yeah, sometimes, we really just want the directory!
filegroup(
    name = "dir",
    srcs = ["."],
)

alias(
    name = "{alias}",
    actual = ":files",
)
j��"""Generated by download_archives. DO NOT EDIT."""

# source packages are only visible to their version package
package(default_visibility = ["//:__subpackages__"])

filegroup(
    name = "files",
    srcs = glob(["**"]),
)

# NOTE:
# When using ':dir' we get a warning:
#   WARNING: input '' of <TARGET> is a directory;
#   dependency checking of directories is unsound
# but... yeah, sometimes, we really just want the directory!
filegroup(
    name = "dir",
    srcs = ["."],
)

alias(
    name = "{alias}",
    actual = ":files",
)
�	BUILD_TARGETS�
alias(
    name = "files",
    actual = "//{{}}/{{}}:files".format(VERSION, SOURCE),
)

alias(
    name = "dir",
    actual = "//{{}}/{{}}:dir".format(VERSION, SOURCE),
)

alias(
    name = "{alias}",
    actual = ":files",
)
j��
alias(
    name = "files",
    actual = "//{{}}/{{}}:files".format(VERSION, SOURCE),
)

alias(
    name = "dir",
    actual = "//{{}}/{{}}:dir".format(VERSION, SOURCE),
)

alias(
    name = "{alias}",
    actual = ":files",
)
�
# `archives` repository rule

Repository rule to create and maintain Bazel external repos. It helps reduce
boilerplate code by keeping a JSON index file with all of the metadata required
to download and extract an archive: the archive's `version`(s) and the
`source`(s) from which to try to download the archive.
�`
#
download_archiveslib	index.bzlz
//lib:integrity.bzlra
'
download_archiveslibintegrity.bzl&
	integrity	Integrity
�/�8
��Gn
//lib:schema.bzlrX
$
download_archiveslib
schema.bzl 
schemaSchema
�,�2
��>j
//lib:utils.bzlrU
#
download_archiveslib	utils.bzl
utilsUtils
�+�0
��;�]
# repo JSON index

The repo JSON index is a JSON object that contains all of the metadata required
to download an archive.

In summary, the index is structured (and potentially templated) metadata that's
used to generate (materialize) the URLs from which to download the archives for
each `version`.

## Structure

The index JSON object has the following properties:
- `version` (`int`): the version of the JSON index object.
- `versions` (`dict[version, version_context] | list[version]`): maps `version`
  names to [`version` context]s. If a `list` of versions is provided, it will
  be expanded to a `dict` of `version`s mapped to empty `version` contexts.
- `sources` (`dict[source, source_context]`): maps `source` names to [URL
  `source` context]s.
- `metadata` (`dict[any, any]`): free-form "metadata map", useful to add
  information about the archive that we want to have available in the repo
  (e.g. requirements, version compatibility, external dependencies, etc).

The index JSON object is parsed, validated and converted to an `index`
`struct` with the following properties:
- `version` (`int`): the version of the index struct, matching the version of
  the JSON index object.
- `name` (`str`): the short repo name.
- `repos` (`dict[version, list[repo]]`): maps the archive `version` to the
  `repo` `struct`s. These `struct`s will be used by the `install` repository
  rule to download the versions of the archive.

Each `repo` `struct` has the following properties:
  - `name`: the short repo name
  - `version`: the `version` name
  - `source`: the `source` name
  - `context`: the [`materialized` repo context] which will have, at the very
    least, the `url` from which to download the archive.

## Contexts

### `materialized` repo context

The `materialized` context is built by:

- adding all the properties in the [`default` context], the [`version` context]
  and the [URL `source` context]. Note that *all* of the properties
  in the `version` and URL `source` contexts can be templated using string
  replacements.

- materializing one by one with the context available up to that point
- adding the materialized property to the materialization context so that its
  materialized value is available to the properties after it for string replacement.

Thus, for materialization purposes, **the order of the properties matters**:
**only properties previously defined can be used as string replacements**.

This way, there's a lot of flexibility to define almost any type of `source`
URL format.

### `default` context

The `default` context is a context that's automatically seeded with the values
of `repo_name`, `version` and `source`.

### `version` context

The `version` context object contains properties whose values **change with
each version**. These properties are required to generate (materialize) the
corresponding `source` properties.

The properties can have any name except the following reserved names:
`integrity_algo`, `integrity_hex_digest` and `integrity_sri` (see [Special
context properties]).

These property values can be specific to one source ("per-source") or can apply
to all sources ("global").

The per-source `version` context is a "fully expanded" `dict`-of-`dict`s that
map `version` properties to `source`s:

```json
{
  (...)
  "versions": {
    "1.1": {
      "ext": {
        "example.com": "tar.gz"
      }
    },
    "1.0": {
      "ext": {
        "example.com": "tgz"
      }
    }
  }
}
```

If certain properties apply to all sources, the "global" context provides a
more compact syntax, just a key-value `dict` where the values are not `dict`
i.e. they don't explicitly map to a `source`, e.g.

```json
{
  "version": 1,
  "sources": {
    "example.com": {
      "url": "https://{source}/{version}.{ext}"
    }
  },
  "versions": {
    "1.1": {
      "ext": "tar.gz",
    },
    "1.0": {
      "ext": "tgz",
    }
  }
}
```

where `versions` expands to the "fully expanded" per-source `version` context,
as before.

Finally, a special case of the "global" `version` context can be just a `list`
of versions where each `version` will be expanded to an empty `version`
context, e.g.:

```json
{
  "version": 1,
  "sources": {
    "example.com": {
      "url": "https://{source}/{version}.tgz"
    }
  },
  "versions": ["1.0"]
}
```

where `versions` expands to:

```json
{
  (...)
  "versions": {
    "1.0": {}
  }
}
```

Finally, note that *all* of the property values in the `version` context can be
templated using string replacements. See [`materialized` repo context] for more
details.

### URL `source` context

The URL `source` context object contains properties whose values **change with
each source**. These properties are required to generate (materialize) the only
mandatory `source` property: the `url` to download the archive.

The properties can have any name except the following reserved names:
`integrity_algo`, `integrity_hex_digest` and `integrity_sri` (see [Special
context properties]).

E.g. the simplest index JSON example we had before:

```json
{
  "version": 1,
  "sources": {
    "example.com": {
      "url": "https://{source}/{version}.tgz"
    }
  },
  "versions": ["1.0"]
}
```

will materialize the following `url`: `"https://example.com/1.0.tgz"`.

Note that *all* of the property values in the URL `source` context can be
templated using string replacements. See [`materialized` repo context] for more
details.


### Special context properties

There are two context properties that are "special": `integrity` and `sha256`.

The `sha256` property is expected to have the `SHA256` hex digest of the
archive and the `integrity` property, the [Subresource Integrity (SRI)] of the
archive. However, for convenience, the `integrity` property also accepts hex
digests.

Both are optional and mutually exclusive, only one of them should be set / used
per version and source. If not present, a warning message will be printed
asking to add it to the index. This is important because the integrity of the
archives is crucial to the safety and reproducibility of the builds.

Note that if one of these properties is present, a special "expansion" will
always add *four* special properties to the context: `integrity_algo`,
`integrity_hex_digest`, `integrity_sri` and `integrity` corresponding to the
integrity algorithm, hex digest and SRI, plus `sha256` if the SRI or hex digest
is of a `SHA256` algorithm.

## Examples

### Example 1:

```json
{
  "version": 1,
  "sources": {
    "example.com": {
      "url": "https://{source}/{version}.tgz"
    }
  },
  "versions": ["1.0"]
}
```

In this example, the `materialized` context **before** it's actually
materialized will consist of the `default` context properties (`repo_name`,
`version` and `source`) plus the `url` property from the URL `source` context:
```starlark
{
    "repo_name": <REPO>,
    "version": "1.0",
    "source": "example.com",
    "url": "https://{source}/{version}.tgz",
}
```

Thus, the final `materialized` repo context will be:
```starlark
{
    "repo_name": <REPO>,
    "version": "1.0",
    "source": "example.com",
    "url": "https://example.com/1.0.tgz",
}
```

### Example 2:

```json
{
  "version": 1,
  "urls": {
    "mirror1": {
      "domain": "example.com",
      "tag": "v{version}",
      "filename": "foobar-{tag}",
      "strip_prefix": "{filename}",
      "url": "https://{domain}/{tag}/{filename}-{sha256}.tgz"
    },
    "mirror2": {
      "url": "https://{source}.mirrors.com/{repo_name}/{version}/{sha256}.tgz"
    }
  },
  "versions": {
    "1.1": {
      "sha256": {
        "mirror1": "fcde2b2edba56bf408601fb721fe9b5c338d10ee429ea04fae5511b68fbf8fb9",
        "mirror2": "c3ab8ff13720e8ad9047dd39466b3c8974e592c2fa383d4a3960714caef0c4f2"
    },
    "1.0": {
      "sha256": "2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae"
    }
  }
}
```

In this example, the `materialized` repo contexts  **before** actually being
materialized will consist of:
```starlark

# version: 1.0, source: mirror1
{
    "repo_name": <REPO>,
    "version": "1.0",
    "source": "mirror1",

    # version context with special context properties expanded
    "integrity": "sha256-LCa0a2j/xo/5m0U8HTBBNBNCLXBkg7+g+YpeiGJm564=",
    "integrity_algo": "sha256",
    "integrity_sri": "sha256-LCa0a2j/xo/5m0U8HTBBNBNCLXBkg7+g+YpeiGJm564=",
    "integrity_hex_digest": "2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae",
    "sha256": "2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae",

    # source context
    "domain": "example.com",
    "tag": "v{version}",
    "filename": "foobar-{tag}",
    "strip_prefix": "{filename}",
    "url": "https://{domain}/{tag}/{filename}-{sha256}.tgz",
}

# version: 1.0, source: mirror2
{
    "repo_name": <REPO>,
    "version": "1.0",
    "source": "mirror2",

    # version context with special context properties expanded
    "integrity": "sha256-LCa0a2j/xo/5m0U8HTBBNBNCLXBkg7+g+YpeiGJm564=",
    "integrity_algo": "sha256",
    "integrity_sri": "sha256-LCa0a2j/xo/5m0U8HTBBNBNCLXBkg7+g+YpeiGJm564=",
    "integrity_hex_digest": "2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae",
    "sha256": "2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae",

    # source context
    "url": "https://{source}.mirrors.com/{repo_name}/{version}/{sha256}.tgz"
}

# version: 1.1, source: mirror1
{
    "repo_name": <REPO>,
    "version": "1.1",
    "source": "mirror1",

    # version context with special context properties expanded
    "integrity": "sha256-/N4rLtula/QIYB+3If6bXDONEO5CnqBPrlURto+/j7k=",
    "integrity_algo": "sha256",
    "integrity_sri": "sha256-/N4rLtula/QIYB+3If6bXDONEO5CnqBPrlURto+/j7k=",
    "integrity_hex_digest": "fcde2b2edba56bf408601fb721fe9b5c338d10ee429ea04fae5511b68fbf8fb9",
    "sha256": "fcde2b2edba56bf408601fb721fe9b5c338d10ee429ea04fae5511b68fbf8fb9",

    # source context
    "domain": "example.com",
    "tag": "v{version}",
    "filename": "foobar-{tag}",
    "strip_prefix": "{filename}",
    "url": "https://{domain}/{tag}/{filename}-{sha256}.tgz",
}

# version: 1.1, source: mirror2
{
    "repo_name": <REPO>,
    "version": "1.1",
    "source": "mirror2",

    # version context with special context properties expanded
    "integrity": "sha256-w6uP8Tcg6K2QR905Rms8iXTlksL6OD1KOWBxTK7wxPI=",
    "integrity_algo": "sha256",
    "integrity_sri": "sha256-w6uP8Tcg6K2QR905Rms8iXTlksL6OD1KOWBxTK7wxPI=",
    "integrity_hex_digest": "c3ab8ff13720e8ad9047dd39466b3c8974e592c2fa383d4a3960714caef0c4f2",
    "sha256": "c3ab8ff13720e8ad9047dd39466b3c8974e592c2fa383d4a3960714caef0c4f2",

    # source context
    "url": "https://{source}.mirrors.com/{repo_name}/{version}/{sha256}.tgz"
}
```

And the final `materialized` context for e.g. version `1.1` and `source`
`mirror1` will be:

```starlark
# version: 1.1, source: mirror1
{
    "repo_name": <REPO>,
    "version": "1.1",
    "source": "mirror1",

    # version context with special context properties expanded
    "integrity": "sha256-/N4rLtula/QIYB+3If6bXDONEO5CnqBPrlURto+/j7k=",
    "integrity_algo": "sha256",
    "integrity_sri": "sha256-/N4rLtula/QIYB+3If6bXDONEO5CnqBPrlURto+/j7k=",
    "integrity_hex_digest": "fcde2b2edba56bf408601fb721fe9b5c338d10ee429ea04fae5511b68fbf8fb9",
    "sha256": "fcde2b2edba56bf408601fb721fe9b5c338d10ee429ea04fae5511b68fbf8fb9",

    # source context
    "domain": "example.com",
    "tag": "v1.1",
    "filename": "foobar-v1.1",
    "strip_prefix": "foobar-v1.1",
    "url": "https://example.com/v1.1/foobar-v1.1-fcde2b2edba56bf408601fb721fe9b5c338d10ee429ea04fae5511b68fbf8fb9.tgz",
}
```

[`materialized` repo context]: #materialized-repo-context
[`default` context]: #default-context
[`version` context]: #version-context
[URL `source` context]: #url-source-context
[Special context properties]: #special-context-properties
[Subresource Integrity (SRI)]: https://w3c.github.io/webappsec-subresource-integrity/
�
'
download_archiveslibintegrity.bzli
//lib:base64.bzlrS
#
aspect_bazel_liblib
base64.bzl
base64base64
,2
4�
//lib:strings.bzlr�
$
aspect_bazel_liblibstrings.bzl
chrchr
-0
hexhex
47
ordord
;>
@\
# Subresource Integrity (SRI)

See: https://w3c.github.io/webappsec-subresource-integrity/
�
$
download_archiveslib
schema.bzlv
//lib:integrity.bzlr]
'
download_archiveslibintegrity.bzl$
	integrity	Integrity
/8
Grepo JSON index schema0
#
download_archiveslib	utils.bzl	utils.bzl 