ϭ
0
download_archivesdownload/archivesdefs.bzl��download_archives��
This repository rule wraps [`rctx.download_and_extract`] and creates a Bazel
repo under `@<NAME>`, downloading and extracting *one archive* from *one*
of the sources for *each* of the archive versions in the [repo JSON index].

When downloading the archive, if a source fails it will try the next one, and
only fail if all sources are exhausted.

To construct the arguments passed to [`rctx.download_and_extract`] it uses the
["materialized repo `context`"], which includes at minimum the materialized
`url` from which to download the archive.

### Repo structure

```
  @<NAME>/
   |
   |-- <VERSION>/
   |   |-- BUILD.bazel
   |   `-- <SOURCE>/
   |       |-- BUILD.bazel
   |       |-- ...
   |       `-- ...
   |
   |-- BUILD.bazel
   |-- index.json
   |-- lock.json
   |-- metadata.json
   |-- repo.bzl
   `-- patches/
       |-- <VERSION>/
           `-- <SOURCE>/
               |-- <PATCH_NAME>
               `-- ...
```

TL;DR, the repo can be used as follows:

- `@<NAME>//:<NAME>`: points to the `:files` target of the
  `DEFAULT_VERSION`.
- `@<NAME>//:<TARGET>`: points to the specific `TARGET` of the
  `DEFAULT_VERSION`.
- `@<NAME>//<VERSION>:<TARGET>`: points to the specific `TARGET` of that
  `VERSION`.

The `archives` repository rule creates a `@<NAME>` Bazel repo with a
public `//<VERSION>` package for every version in the index.

Each `//<VERSION>` package has the following targets:
- `:files`: to access all the files in the downloaded archive.
- `:dir`: the directory the archive was extracted into, as a tree artifact
  keyed on the archive and its patches (see `//lib:dir.bzl`).
- `:dir_path`: that same directory as Bazel extracted it, for its path alone
  (see `//lib:dir.bzl` for why it is no good for its contents).
- `:<VERSION>`: `alias` of `:files`.
- `:<OUTPUT>`: one per subpath rendered by the index [`matrix`] `output`, to
  access only the files of that partition of the extracted tree. There are
  none of these when the index has no `matrix` or no `output`.

and two constants:
- `VERSION`: the version of the archive.
- `SOURCE`: the source from which the archive was downloaded.

Each `//<VERSION>` package has an *internal* `<SOURCE>` sub-package with
the actual files from the downloaded archive for that specific `version` and
`source`. The targets in the `//<VERSION>` package are aliases for targets in
the `//<VERSION>/<SOURCE>` sub-packages.

The root package `//` has the following targets:
- `:files`: to access all the files in the `DEFAULT_VERSION` package.
- `:dir`: the directory of the `DEFAULT_VERSION` package, as above.
- `:dir_path`: the path of that directory, as above.
- `:<NAME>`: `alias` of `:files`.
- `:<OUTPUT>`: one per [`matrix`] `output` of the `DEFAULT_VERSION` package,
  as above.

and two constants:
- `VERSION`: the `DEFAULT_VERSION` of the archive.
- `SOURCE`: the source from which the default version was downloaded.

The root package also has the following:
- `//:index.json`: a copy of the repo index JSON file.
- `//:lock.json`: the repo lock file (see below).
- `//:metadata.json`: the repo metadata.
- `//:repo.bzl`: extension with the following constants:
  - `REPO_NAME`: The short repo name.
  - `VERSIONS`: a mapping of the downloaded `version`s to the `source` from
    which the archive was downloaded.
  - `DEFAULT_VERSION`: the default `version` of the archive.
  - `LOCK`: a `dict` with the contents of the repo `lock.json`.
  - `METADATA`: the free-form metadata map straight from the repo JSON index,
    if any.
- `//patches`: a package with `<VERSION>/<SOURCE>` sub-packages with the
  applied patches applied to that archive, if any (see ["Patching"] below).

The repo lock file contains a mapping of the downloaded `version` to a "lock
object" with the following properties:
  - `source`: the source from which the archive was downloaded.
  - `url`: the URL from which the archive was downloaded.
  - `integrity`: the SRI ([Subresource Integrity (SRI)]) of the downloaded archive.
  - `patches`: the list of patches applied to the archive after download, if any.

### Selecting `versions` and `sources`

Users can also override the default selection of versions and sources with the
`versions` and `sources` arguments.

Note that selecting specific versions and/or arguments will change the values
of `VERSIONS` and `DEFAULT_VERSION`.

### Downloading a `matrix` of archives

Some archives are published as a *set* of files per version rather than as a
single file, e.g. a toolchain that publishes one archive per (target triple,
component). The index [`matrix`] describes that set, and the index `output`
decides how the combinations lay out in the extracted tree: combinations that
render the same `output` merge into a single tree, the rest partition it.

E.g. this index downloads four archives for version `1.97.1`, one per
(`triple`, `component`) combination, and partitions them by `triple`:

```json
{
  "version": 1,
  "sources": {
    "static.rust-lang.org": {
      "url": "https://{source}/dist/{component}-{version}-{triple}.tar.xz",
      "strip_prefix": "{component}-{version}-{triple}/{piece}"
    }
  },
  "matrix": [
    {
      "key": "triple",
      "values": ["x86_64-unknown-linux-gnu", "aarch64-unknown-linux-gnu"]
    },
    {
      "key": "component",
      "values": {
        "cargo": {"piece": "cargo"},
        "rustfmt": {"piece": "rustfmt-preview"}
      }
    }
  ],
  "output": "{triple}",
  "versions": {
    "1.97.1": {
      "x86_64-unknown-linux-gnu": {
        "cargo": "sha256-4b5Xkw2Cfk73/RSNy0jgUv/AqIsGpKKO9EhIOqvsG2E=",
        "rustfmt": "sha256-kH/pfWr73h7KGzTJksduFAbUIuLm8TeBPTgqzsfrTRQ="
      },
      "aarch64-unknown-linux-gnu": {
        "cargo": "sha256-j3C8rM6lukvRh8P9TWTiRZK04Wr1E0lyAfWQnWFpHb4=",
        "rustfmt": "sha256-Pb3hXTB5SSQZWuRG89LOtUKhMTBtIq55EsdjTUFGIqg="
      }
    }
  }
}
```

which lays out the repo as:

```
  @rust_toolchain/
   |
   |-- 1.97.1/
   |   |-- BUILD.bazel
   |   `-- static.rust-lang.org/
   |       |-- BUILD.bazel
   |       |-- aarch64-unknown-linux-gnu/
   |       |   |-- bin/
   |       |   `-- ...
   |       `-- x86_64-unknown-linux-gnu/
   |           |-- bin/
   |           `-- ...
   (...)
```

So, on top of `:files`, which is all of the combinations, each rendered
`output` gets its own target:

- `@rust_toolchain//1.97.1:x86_64-unknown-linux-gnu`
- `@rust_toolchain//1.97.1:aarch64-unknown-linux-gnu`

Note that the `cargo` and `rustfmt` archives of a triple *merge* into that
triple's tree, giving one usable prefix with both binaries in `bin/`, while the
two triples stay apart.

### Version scheme

The `version_scheme` attribute defines the format used for versions in both the
`index` and `patches`. The supported schemes are those in [`version_utils`'
`version` extension], with `SCHEME.SEMVER` ([semantic versioning]) being the
default.

[semantic versioning]: https://semver.org
[`version_utils`' `version` extension]: https://github.com/jjmaestro/bazel_version_utils/blob/main/docs/version/version.md

### Patching

The downloaded archive can also be patched by passing a `patches` argument, a
map of `Label`s of [unified diff format] patch files (applied from the root of
the downloaded archive) to "patch specs" that determine if the patch is to be
applied.

The "patch spec" format is `<VERSION_SPEC>[/<SOURCE>]`, where:

- `<VERSION_SPEC>` is a version constraints requirement spec that
  to specify the versions to which the patch applies.
- `<SOURCE>` (optional, defaults to `*`) is the source of the downloaded
  archive to which the patch should be applied. It's optional and it can also
  be `*`, a wildcard to apply the patch to the archives downloaded from any
  source.

The `<VERSION_SPEC>` syntax is specified with the `spec_syntax` attribute. It's
one of the syntaxes supported by [`version_utils`' `spec` extension] and the
default is `SYNTAX.SIMPLE`.

This helps to maintain patches that apply to e.g.:

- a specific version and source: `1.24.5/github`
- a specific version and all sources: `1.24.5/*` or `1.24.5`
- a range of versions and all sources: `>=1.24.5, <2.0.0/*`
- all versions and sources: `*` or `*/*`

Finally, to simplify patch maintenance, it's good practice to keep a dedicated
"patched branch" for each version we want to maintain, making it easy to
generate the list of patches using [`git format-patch`].

[unified diff format]: https://en.wikipedia.org/wiki/Diff#Unified_format
[`version_utils` `spec` extension]: https://github.com/jjmaestro/bazel_version_utils/blob/main/docs/specs/spec.md
[`git format-patch`]: https://git-scm.com/docs/git-format-patch

### Usage:

Here's an example that shows how to create a `@wget_src` repo for [GNU wget]:

[GNU wget]: https://www.gnu.org/software/wget/

#### 1. Create the repo index

First, define a `repo.json` JSON index file in a package. Don't forget to add a
`BUILD.bazel` file in it if one doesn't already exists).

E.g. for a `//third-party/wget` package:

```sh
mkdir -p third-party/wget
touch third-party/wget/BUILD.bazel
```

Then add the following to the `repo.json` file:

```json
{
  "version": 1,
  "sources": {
    "github.com": {
      "owner": "mirror",
      "repo": "wget",
      "tag": "v{version}",
      "url": "https://{source}/{owner}/{repo}/archive/refs/tags/{tag}.tar.gz",
      "strip_prefix": "{repo}-{version}"
    },
    "gitlab.com": {
      "owner": "gnuwget",
      "repo": "wget",
      "tag": "v{version}",
      "filename": "{repo}-{tag}",
      "url": "https://{source}/{owner}/{repo}/-/archive/{tag}/{filename}.tar.gz",
      "strip_prefix": "{filename}"
    }
  },
  "versions": {
    "1.24.5": {
      "integrity": {
        "gitlab.com": "sha256-1Yw1cok0niLv563o07/BrjbCQIflWxK8UFlav9srtcw="
      }
    },
    "1.21.3": {
      "integrity": {
        "github.com": "sha256-VbH6fHnent2TtbYxbNoatK4RNkY3MVPXokJhRzPZBg8=",
        "gitlab.com": "sha256-3w3ImvW4t/H2eMkZbUH+F1zkARSI3cIJSgJFg4ULPU4="
      }
    }
  }
}
```

#### 2. Add the `download_archives` repo to `MODULE.bazel`

Then, add the following to `MODULE.bazel`:

```starlark
download_archives = use_repo_rule("@download_archives//download/archives:defs.bzl", "download_archives")

download_archives(
    name = "wget_src",
    index = "//third-party/wget:repo.json",
    # NOTE:
    # This is how you would add a custom patch for one of the versions. See
    # "Patching" docs for more information about patches.
    # patches = {
    #    "//third-party/wget/patches:0001-1.24.5-test-patch.patch": ">=1.24.5/*",
    # },
    # NOTE:
    # This is needed because the archives have different integrity across the
    # mirrors (see v1.21.3)
    strict_integrity = False,
)
```

#### 3. Test it

To test the Bazel repo, run `bazel fetch @wget_src`. This will attempt to
download and extract all the versions defined in the repo index from the
available sources.

As mentioned before, it will stop downloading any other source for a specific
version when there's a successful download from one source. And, if all
downloads from all sources of a given version fail, it will `fail` with an
error.

Note that in the `repo.json` JSON index file there's one `integrity` missing
for one of the sources (version `1.24.5`, source `github.com`). When this
happens a warning message is printed when the archive download begins asking
the user to add the integrity to the index. And, if the archive is successfully
downloaded, a message with the [Subresource Integrity (SRI)] (`integrity`) and
`SHA256` hex digest will be printed so that it's easy to copy-paste one of them
in the index.

Also note that we set `strict_integrity = False` because the archives for
version `1.21.3` have different integrity hashes across sources. With
`strict_integrity = True`, this would cause the download to fail. Since this
can make builds non-reproducible, the default remains `True`. The option exists
because many artifacts share identical source code but differ in packaging or
other details, resulting in mismatched integrities.

Once installed, the `@wget_src` repo will have the following:

- helper constants available to import from `@wget_src//:repo.bzl`:
  - `REPO_NAME = "wget_src"`
  - `VERSIONS = {"1.24.5": "github.com", "1.21.3": "github.com"}`
  - `DEFAULT_VERSION = "1.24.5"`
  - `LOCK = {...}` (the contents of the repo `lock.json`)

- specific `<VERSION>/<SOURCE>` repos:
  - `@wget_src//1.24.5/github.com`
  - `@wget_src//1.21.3/github.com`

- `alias` repos:
  - `@wget_src` --> `@wget_src//1.24.5/github.com`
  - `@wget_src//1.24.5` --> `@wget_src//1.24.5/github.com`
  - `@wget_src//1.21.3` --> `@wget_src//1.21.3/github.com`

<details>
<summary><h4>More details</h4></summary>

To list all the targets in the repo, run `bazel query @wget_src//...`:

```sh
@wget_src//:dir
@wget_src//:files
@wget_src//:wget_src
@wget_src//1.21.3:1.21.3
@wget_src//1.21.3:dir
@wget_src//1.21.3:files
@wget_src//1.21.3/github.com:dir
@wget_src//1.21.3/github.com:files
@wget_src//1.21.3/github.com:github.com
@wget_src//1.24.5:1.24.5
@wget_src//1.24.5:dir
@wget_src//1.24.5:files
@wget_src//1.24.5/github.com:dir
@wget_src//1.24.5/github.com:files
@wget_src//1.24.5/github.com:github.com
```

In cases where we have many versions and sources in the index we can select the
versions and/or sources from which to download using the `versions` and
`sources` arguments:

```starlark
download_archives(
    name = "wget_src",
    index = "//third-party/wget:repo.json",
    versions = ["1.21.3"],
    sources = ["gitlab.com"],
)
```

Selecting `versions` and `sources` changes what's installed and available in
the `@wget_src` repo:

- helper constants available to import from `@wget_src//:repo.bzl`:
  - `REPO_NAME = "wget_src"`
  - `VERSIONS = {"1.21.3": "gitlab.com"}`
  - `DEFAULT_VERSION = "1.21.3"`

- specific `<VERSION>/<SOURCE>` repos:
  - `@wget_src//1.21.3/gitlab.com`

- `alias` repos:
  - `@wget_src` --> `@wget_src//1.21.3/gitlab.com`
  - `@wget_src//1.21.3` --> `@wget_src//1.21.3/gitlab.com`

Again, let's list all the targets with `bazel query @wget_src//...`:

```sh
@wget_src//:dir
@wget_src//:files
@wget_src//:wget_src
@wget_src//1.21.3:1.21.3
@wget_src//1.21.3:dir
@wget_src//1.21.3:files
@wget_src//1.21.3/gitlab.com:dir
@wget_src//1.21.3/gitlab.com:files
@wget_src//1.21.3/gitlab.com:gitlab.com
```

Similarly, remember that the sources are used as "mirrors" so if the first one
fails to download, the next source will be attempted. Thus, the `VERSIONS`
helper constant, the `alias` repos and the repo `lock.json` will all change
accordingly.

For example, imagine that `github` has version `1.24.5` available but not
`1.21.3`. Then, the download will fall back to the `gitlab.com` source and, if
successful, the `@wget_src` repo will have the following:

- helper constants available to import from `@wget_src//:repo.bzl`:
  - `REPO_NAME = "wget_src"`
  - `VERSIONS = {"1.24.5": "github.com", "1.21.3": "gitlab.com"}`
  - `DEFAULT_VERSION = "1.24.5"`
  - `LOCK = {...}` (the new contents of the repo `lock.json`)

- specific `<VERSION>/<SOURCE>` repos:
  - `@wget_src//1.24.5/github.com`
  - `@wget_src//1.21.3/gitlab.com`

- `alias` repos:
  - `@wget_src` --> `@wget_src//1.24.5/github`
  - `@wget_src//1.24.5` --> `@wget_src//1.24.5/github.com`
  - `@wget_src//1.21.3` --> `@wget_src//1.21.3/gitlab.com`


In this case, the list of targets would look like:

```sh
@wget_src//:dir
@wget_src//:files
@wget_src//:wget_src
@wget_src//1.21.3:1.21.3
@wget_src//1.21.3:dir
@wget_src//1.21.3:files
@wget_src//1.21.3/gitlab.com:dir
@wget_src//1.21.3/gitlab.com:files
@wget_src//1.21.3/gitlab.com:gitlab.com
@wget_src//1.24.5:1.24.5
@wget_src//1.24.5:dir
@wget_src//1.24.5:files
@wget_src//1.24.5/github.com:dir
@wget_src//1.24.5/github.com:files
@wget_src//1.24.5/github.com:github.com
```

</details>

### Per-version downloads (module extension)

For repositories with many versions, use the `download_archives` module
extension from `extensions.bzl` instead of this rule. The module extension
creates one download repository per version, so archives are only downloaded
when a build references a specific version:

```starlark
download = use_extension(
    "@download_archives//download/archives:extensions.bzl",
    "download_archives",
)

download.archives(
    name = "my_src",
    index = "//third-party:repo.json",
)

use_repo(download, "my_src")
```

Building `@my_src//18.1:files` downloads only version 18.1, not all versions
in the index.

["Patching"]: #patching
[`matrix`]: ../../lib/index.md#matrix
[Subresource Integrity (SRI)]: https://w3c.github.io/webappsec-subresource-integrity/
["materialized repo `context`"]: ../../lib/index.md#materialized-repo-context
[`rctx.download_and_extract`]: https://bazel.build/rules/lib/builtins/repository_ctx#download_and_extract
[repo JSON index]: ../../lib/index.md
R��
��
download_archives��
This repository rule wraps [`rctx.download_and_extract`] and creates a Bazel
repo under `@<NAME>`, downloading and extracting *one archive* from *one*
of the sources for *each* of the archive versions in the [repo JSON index].

When downloading the archive, if a source fails it will try the next one, and
only fail if all sources are exhausted.

To construct the arguments passed to [`rctx.download_and_extract`] it uses the
["materialized repo `context`"], which includes at minimum the materialized
`url` from which to download the archive.

### Repo structure

```
  @<NAME>/
   |
   |-- <VERSION>/
   |   |-- BUILD.bazel
   |   `-- <SOURCE>/
   |       |-- BUILD.bazel
   |       |-- ...
   |       `-- ...
   |
   |-- BUILD.bazel
   |-- index.json
   |-- lock.json
   |-- metadata.json
   |-- repo.bzl
   `-- patches/
       |-- <VERSION>/
           `-- <SOURCE>/
               |-- <PATCH_NAME>
               `-- ...
```

TL;DR, the repo can be used as follows:

- `@<NAME>//:<NAME>`: points to the `:files` target of the
  `DEFAULT_VERSION`.
- `@<NAME>//:<TARGET>`: points to the specific `TARGET` of the
  `DEFAULT_VERSION`.
- `@<NAME>//<VERSION>:<TARGET>`: points to the specific `TARGET` of that
  `VERSION`.

The `archives` repository rule creates a `@<NAME>` Bazel repo with a
public `//<VERSION>` package for every version in the index.

Each `//<VERSION>` package has the following targets:
- `:files`: to access all the files in the downloaded archive.
- `:dir`: the directory the archive was extracted into, as a tree artifact
  keyed on the archive and its patches (see `//lib:dir.bzl`).
- `:dir_path`: that same directory as Bazel extracted it, for its path alone
  (see `//lib:dir.bzl` for why it is no good for its contents).
- `:<VERSION>`: `alias` of `:files`.
- `:<OUTPUT>`: one per subpath rendered by the index [`matrix`] `output`, to
  access only the files of that partition of the extracted tree. There are
  none of these when the index has no `matrix` or no `output`.

and two constants:
- `VERSION`: the version of the archive.
- `SOURCE`: the source from which the archive was downloaded.

Each `//<VERSION>` package has an *internal* `<SOURCE>` sub-package with
the actual files from the downloaded archive for that specific `version` and
`source`. The targets in the `//<VERSION>` package are aliases for targets in
the `//<VERSION>/<SOURCE>` sub-packages.

The root package `//` has the following targets:
- `:files`: to access all the files in the `DEFAULT_VERSION` package.
- `:dir`: the directory of the `DEFAULT_VERSION` package, as above.
- `:dir_path`: the path of that directory, as above.
- `:<NAME>`: `alias` of `:files`.
- `:<OUTPUT>`: one per [`matrix`] `output` of the `DEFAULT_VERSION` package,
  as above.

and two constants:
- `VERSION`: the `DEFAULT_VERSION` of the archive.
- `SOURCE`: the source from which the default version was downloaded.

The root package also has the following:
- `//:index.json`: a copy of the repo index JSON file.
- `//:lock.json`: the repo lock file (see below).
- `//:metadata.json`: the repo metadata.
- `//:repo.bzl`: extension with the following constants:
  - `REPO_NAME`: The short repo name.
  - `VERSIONS`: a mapping of the downloaded `version`s to the `source` from
    which the archive was downloaded.
  - `DEFAULT_VERSION`: the default `version` of the archive.
  - `LOCK`: a `dict` with the contents of the repo `lock.json`.
  - `METADATA`: the free-form metadata map straight from the repo JSON index,
    if any.
- `//patches`: a package with `<VERSION>/<SOURCE>` sub-packages with the
  applied patches applied to that archive, if any (see ["Patching"] below).

The repo lock file contains a mapping of the downloaded `version` to a "lock
object" with the following properties:
  - `source`: the source from which the archive was downloaded.
  - `url`: the URL from which the archive was downloaded.
  - `integrity`: the SRI ([Subresource Integrity (SRI)]) of the downloaded archive.
  - `patches`: the list of patches applied to the archive after download, if any.

### Selecting `versions` and `sources`

Users can also override the default selection of versions and sources with the
`versions` and `sources` arguments.

Note that selecting specific versions and/or arguments will change the values
of `VERSIONS` and `DEFAULT_VERSION`.

### Downloading a `matrix` of archives

Some archives are published as a *set* of files per version rather than as a
single file, e.g. a toolchain that publishes one archive per (target triple,
component). The index [`matrix`] describes that set, and the index `output`
decides how the combinations lay out in the extracted tree: combinations that
render the same `output` merge into a single tree, the rest partition it.

E.g. this index downloads four archives for version `1.97.1`, one per
(`triple`, `component`) combination, and partitions them by `triple`:

```json
{
  "version": 1,
  "sources": {
    "static.rust-lang.org": {
      "url": "https://{source}/dist/{component}-{version}-{triple}.tar.xz",
      "strip_prefix": "{component}-{version}-{triple}/{piece}"
    }
  },
  "matrix": [
    {
      "key": "triple",
      "values": ["x86_64-unknown-linux-gnu", "aarch64-unknown-linux-gnu"]
    },
    {
      "key": "component",
      "values": {
        "cargo": {"piece": "cargo"},
        "rustfmt": {"piece": "rustfmt-preview"}
      }
    }
  ],
  "output": "{triple}",
  "versions": {
    "1.97.1": {
      "x86_64-unknown-linux-gnu": {
        "cargo": "sha256-4b5Xkw2Cfk73/RSNy0jgUv/AqIsGpKKO9EhIOqvsG2E=",
        "rustfmt": "sha256-kH/pfWr73h7KGzTJksduFAbUIuLm8TeBPTgqzsfrTRQ="
      },
      "aarch64-unknown-linux-gnu": {
        "cargo": "sha256-j3C8rM6lukvRh8P9TWTiRZK04Wr1E0lyAfWQnWFpHb4=",
        "rustfmt": "sha256-Pb3hXTB5SSQZWuRG89LOtUKhMTBtIq55EsdjTUFGIqg="
      }
    }
  }
}
```

which lays out the repo as:

```
  @rust_toolchain/
   |
   |-- 1.97.1/
   |   |-- BUILD.bazel
   |   `-- static.rust-lang.org/
   |       |-- BUILD.bazel
   |       |-- aarch64-unknown-linux-gnu/
   |       |   |-- bin/
   |       |   `-- ...
   |       `-- x86_64-unknown-linux-gnu/
   |           |-- bin/
   |           `-- ...
   (...)
```

So, on top of `:files`, which is all of the combinations, each rendered
`output` gets its own target:

- `@rust_toolchain//1.97.1:x86_64-unknown-linux-gnu`
- `@rust_toolchain//1.97.1:aarch64-unknown-linux-gnu`

Note that the `cargo` and `rustfmt` archives of a triple *merge* into that
triple's tree, giving one usable prefix with both binaries in `bin/`, while the
two triples stay apart.

### Version scheme

The `version_scheme` attribute defines the format used for versions in both the
`index` and `patches`. The supported schemes are those in [`version_utils`'
`version` extension], with `SCHEME.SEMVER` ([semantic versioning]) being the
default.

[semantic versioning]: https://semver.org
[`version_utils`' `version` extension]: https://github.com/jjmaestro/bazel_version_utils/blob/main/docs/version/version.md

### Patching

The downloaded archive can also be patched by passing a `patches` argument, a
map of `Label`s of [unified diff format] patch files (applied from the root of
the downloaded archive) to "patch specs" that determine if the patch is to be
applied.

The "patch spec" format is `<VERSION_SPEC>[/<SOURCE>]`, where:

- `<VERSION_SPEC>` is a version constraints requirement spec that
  to specify the versions to which the patch applies.
- `<SOURCE>` (optional, defaults to `*`) is the source of the downloaded
  archive to which the patch should be applied. It's optional and it can also
  be `*`, a wildcard to apply the patch to the archives downloaded from any
  source.

The `<VERSION_SPEC>` syntax is specified with the `spec_syntax` attribute. It's
one of the syntaxes supported by [`version_utils`' `spec` extension] and the
default is `SYNTAX.SIMPLE`.

This helps to maintain patches that apply to e.g.:

- a specific version and source: `1.24.5/github`
- a specific version and all sources: `1.24.5/*` or `1.24.5`
- a range of versions and all sources: `>=1.24.5, <2.0.0/*`
- all versions and sources: `*` or `*/*`

Finally, to simplify patch maintenance, it's good practice to keep a dedicated
"patched branch" for each version we want to maintain, making it easy to
generate the list of patches using [`git format-patch`].

[unified diff format]: https://en.wikipedia.org/wiki/Diff#Unified_format
[`version_utils` `spec` extension]: https://github.com/jjmaestro/bazel_version_utils/blob/main/docs/specs/spec.md
[`git format-patch`]: https://git-scm.com/docs/git-format-patch

### Usage:

Here's an example that shows how to create a `@wget_src` repo for [GNU wget]:

[GNU wget]: https://www.gnu.org/software/wget/

#### 1. Create the repo index

First, define a `repo.json` JSON index file in a package. Don't forget to add a
`BUILD.bazel` file in it if one doesn't already exists).

E.g. for a `//third-party/wget` package:

```sh
mkdir -p third-party/wget
touch third-party/wget/BUILD.bazel
```

Then add the following to the `repo.json` file:

```json
{
  "version": 1,
  "sources": {
    "github.com": {
      "owner": "mirror",
      "repo": "wget",
      "tag": "v{version}",
      "url": "https://{source}/{owner}/{repo}/archive/refs/tags/{tag}.tar.gz",
      "strip_prefix": "{repo}-{version}"
    },
    "gitlab.com": {
      "owner": "gnuwget",
      "repo": "wget",
      "tag": "v{version}",
      "filename": "{repo}-{tag}",
      "url": "https://{source}/{owner}/{repo}/-/archive/{tag}/{filename}.tar.gz",
      "strip_prefix": "{filename}"
    }
  },
  "versions": {
    "1.24.5": {
      "integrity": {
        "gitlab.com": "sha256-1Yw1cok0niLv563o07/BrjbCQIflWxK8UFlav9srtcw="
      }
    },
    "1.21.3": {
      "integrity": {
        "github.com": "sha256-VbH6fHnent2TtbYxbNoatK4RNkY3MVPXokJhRzPZBg8=",
        "gitlab.com": "sha256-3w3ImvW4t/H2eMkZbUH+F1zkARSI3cIJSgJFg4ULPU4="
      }
    }
  }
}
```

#### 2. Add the `download_archives` repo to `MODULE.bazel`

Then, add the following to `MODULE.bazel`:

```starlark
download_archives = use_repo_rule("@download_archives//download/archives:defs.bzl", "download_archives")

download_archives(
    name = "wget_src",
    index = "//third-party/wget:repo.json",
    # NOTE:
    # This is how you would add a custom patch for one of the versions. See
    # "Patching" docs for more information about patches.
    # patches = {
    #    "//third-party/wget/patches:0001-1.24.5-test-patch.patch": ">=1.24.5/*",
    # },
    # NOTE:
    # This is needed because the archives have different integrity across the
    # mirrors (see v1.21.3)
    strict_integrity = False,
)
```

#### 3. Test it

To test the Bazel repo, run `bazel fetch @wget_src`. This will attempt to
download and extract all the versions defined in the repo index from the
available sources.

As mentioned before, it will stop downloading any other source for a specific
version when there's a successful download from one source. And, if all
downloads from all sources of a given version fail, it will `fail` with an
error.

Note that in the `repo.json` JSON index file there's one `integrity` missing
for one of the sources (version `1.24.5`, source `github.com`). When this
happens a warning message is printed when the archive download begins asking
the user to add the integrity to the index. And, if the archive is successfully
downloaded, a message with the [Subresource Integrity (SRI)] (`integrity`) and
`SHA256` hex digest will be printed so that it's easy to copy-paste one of them
in the index.

Also note that we set `strict_integrity = False` because the archives for
version `1.21.3` have different integrity hashes across sources. With
`strict_integrity = True`, this would cause the download to fail. Since this
can make builds non-reproducible, the default remains `True`. The option exists
because many artifacts share identical source code but differ in packaging or
other details, resulting in mismatched integrities.

Once installed, the `@wget_src` repo will have the following:

- helper constants available to import from `@wget_src//:repo.bzl`:
  - `REPO_NAME = "wget_src"`
  - `VERSIONS = {"1.24.5": "github.com", "1.21.3": "github.com"}`
  - `DEFAULT_VERSION = "1.24.5"`
  - `LOCK = {...}` (the contents of the repo `lock.json`)

- specific `<VERSION>/<SOURCE>` repos:
  - `@wget_src//1.24.5/github.com`
  - `@wget_src//1.21.3/github.com`

- `alias` repos:
  - `@wget_src` --> `@wget_src//1.24.5/github.com`
  - `@wget_src//1.24.5` --> `@wget_src//1.24.5/github.com`
  - `@wget_src//1.21.3` --> `@wget_src//1.21.3/github.com`

<details>
<summary><h4>More details</h4></summary>

To list all the targets in the repo, run `bazel query @wget_src//...`:

```sh
@wget_src//:dir
@wget_src//:files
@wget_src//:wget_src
@wget_src//1.21.3:1.21.3
@wget_src//1.21.3:dir
@wget_src//1.21.3:files
@wget_src//1.21.3/github.com:dir
@wget_src//1.21.3/github.com:files
@wget_src//1.21.3/github.com:github.com
@wget_src//1.24.5:1.24.5
@wget_src//1.24.5:dir
@wget_src//1.24.5:files
@wget_src//1.24.5/github.com:dir
@wget_src//1.24.5/github.com:files
@wget_src//1.24.5/github.com:github.com
```

In cases where we have many versions and sources in the index we can select the
versions and/or sources from which to download using the `versions` and
`sources` arguments:

```starlark
download_archives(
    name = "wget_src",
    index = "//third-party/wget:repo.json",
    versions = ["1.21.3"],
    sources = ["gitlab.com"],
)
```

Selecting `versions` and `sources` changes what's installed and available in
the `@wget_src` repo:

- helper constants available to import from `@wget_src//:repo.bzl`:
  - `REPO_NAME = "wget_src"`
  - `VERSIONS = {"1.21.3": "gitlab.com"}`
  - `DEFAULT_VERSION = "1.21.3"`

- specific `<VERSION>/<SOURCE>` repos:
  - `@wget_src//1.21.3/gitlab.com`

- `alias` repos:
  - `@wget_src` --> `@wget_src//1.21.3/gitlab.com`
  - `@wget_src//1.21.3` --> `@wget_src//1.21.3/gitlab.com`

Again, let's list all the targets with `bazel query @wget_src//...`:

```sh
@wget_src//:dir
@wget_src//:files
@wget_src//:wget_src
@wget_src//1.21.3:1.21.3
@wget_src//1.21.3:dir
@wget_src//1.21.3:files
@wget_src//1.21.3/gitlab.com:dir
@wget_src//1.21.3/gitlab.com:files
@wget_src//1.21.3/gitlab.com:gitlab.com
```

Similarly, remember that the sources are used as "mirrors" so if the first one
fails to download, the next source will be attempted. Thus, the `VERSIONS`
helper constant, the `alias` repos and the repo `lock.json` will all change
accordingly.

For example, imagine that `github` has version `1.24.5` available but not
`1.21.3`. Then, the download will fall back to the `gitlab.com` source and, if
successful, the `@wget_src` repo will have the following:

- helper constants available to import from `@wget_src//:repo.bzl`:
  - `REPO_NAME = "wget_src"`
  - `VERSIONS = {"1.24.5": "github.com", "1.21.3": "gitlab.com"}`
  - `DEFAULT_VERSION = "1.24.5"`
  - `LOCK = {...}` (the new contents of the repo `lock.json`)

- specific `<VERSION>/<SOURCE>` repos:
  - `@wget_src//1.24.5/github.com`
  - `@wget_src//1.21.3/gitlab.com`

- `alias` repos:
  - `@wget_src` --> `@wget_src//1.24.5/github`
  - `@wget_src//1.24.5` --> `@wget_src//1.24.5/github.com`
  - `@wget_src//1.21.3` --> `@wget_src//1.21.3/gitlab.com`


In this case, the list of targets would look like:

```sh
@wget_src//:dir
@wget_src//:files
@wget_src//:wget_src
@wget_src//1.21.3:1.21.3
@wget_src//1.21.3:dir
@wget_src//1.21.3:files
@wget_src//1.21.3/gitlab.com:dir
@wget_src//1.21.3/gitlab.com:files
@wget_src//1.21.3/gitlab.com:gitlab.com
@wget_src//1.24.5:1.24.5
@wget_src//1.24.5:dir
@wget_src//1.24.5:files
@wget_src//1.24.5/github.com:dir
@wget_src//1.24.5/github.com:files
@wget_src//1.24.5/github.com:github.com
```

</details>

### Per-version downloads (module extension)

For repositories with many versions, use the `download_archives` module
extension from `extensions.bzl` instead of this rule. The module extension
creates one download repository per version, so archives are only downloaded
when a build references a specific version:

```starlark
download = use_extension(
    "@download_archives//download/archives:extensions.bzl",
    "download_archives",
)

download.archives(
    name = "my_src",
    index = "//third-party:repo.json",
)

use_repo(download, "my_src")
```

Building `@my_src//18.1:files` downloads only version 18.1, not all versions
in the index.

["Patching"]: #patching
[`matrix`]: ../../lib/index.md#matrix
[Subresource Integrity (SRI)]: https://w3c.github.io/webappsec-subresource-integrity/
["materialized repo `context`"]: ../../lib/index.md#materialized-repo-context
[`rctx.download_and_extract`]: https://bazel.build/rules/lib/builtins/repository_ctx#download_and_extract
[repo JSON index]: ../../lib/index.md
.
name"A unique name for this repository. /
index"Label of the repo JSON index file. �
lazy�
Internal. When True, creates index-only repos with stub BUILD files
that alias to per-version download repositories instead of downloading
archives eagerly. Used by the `download_archives` module extension,
should not be set directly.
2False�
patches�
Diff files to apply as patches at the root of the downloaded archive.
The `dict` values represent "patch specs" in the
`<VERSION_SPEC>/<SOURCE>` format, and determine when patches apply to
the downloaded archive. Patches must be in standard [unified diff
format], created from the root of the archive. All patches are applied
from the root of the archive with `patch -p1`. For more details, see
["Patching"].
	2{}�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 {
sourcesj
Source names from which to download the archive. If none, all sources
from the index are tried in order.
2[]�
spec_syntax�
The syntax of the version constraints specification. The available
syntaxes are those supported by `version_utils` (see `SYNTAX` in
[`version_utils`' `spec`
extension](https://github.com/jjmaestro/bazel_version_utils/blob/main/spec/spec.bzl)).
Defaults to `SYNTAX.SIMPLE`.
2"simple"�
strict_integrity�
If `True`, all sources of a given archive version must share the same
integrity hash. If they differ, the download will fail. Defaults to
`True`.
2True�
version_scheme�
The scheme of the versions in `index` and `patches`. The available
version schemes are those supported by `version_utils` (see `SCHEME` in
[`version_utils`' `version`
extension](https://github.com/jjmaestro/bazel_version_utils/blob/main/version/version.bzl)).
Defaults to `SCHEME.SEMVER`.
2"semver"�
versions}
Versions of the archive to download. If none is specified it will
download all of the versions available in the repo index.
2[]*D
download_archives/@@download_archives//download/archives:defs.bzl
��0
.
name"A unique name for this repository. 1
/
index"Label of the repo JSON index file. �
�
lazy�
Internal. When True, creates index-only repos with stub BUILD files
that alias to per-version download repositories instead of downloading
archives eagerly. Used by the `download_archives` module extension,
should not be set directly.
2False�
�
patches�
Diff files to apply as patches at the root of the downloaded archive.
The `dict` values represent "patch specs" in the
`<VERSION_SPEC>/<SOURCE>` format, and determine when patches apply to
the downloaded archive. Patches must be in standard [unified diff
format], created from the root of the archive. All patches are applied
from the root of the archive with `patch -p1`. For more details, see
["Patching"].
	2{}�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 }
{
sourcesj
Source names from which to download the archive. If none, all sources
from the index are tried in order.
2[]�
�
spec_syntax�
The syntax of the version constraints specification. The available
syntaxes are those supported by `version_utils` (see `SYNTAX` in
[`version_utils`' `spec`
extension](https://github.com/jjmaestro/bazel_version_utils/blob/main/spec/spec.bzl)).
Defaults to `SYNTAX.SIMPLE`.
2"simple"�
�
strict_integrity�
If `True`, all sources of a given archive version must share the same
integrity hash. If they differ, the download will fail. Defaults to
`True`.
2True�
�
version_scheme�
The scheme of the versions in `index` and `patches`. The available
version schemes are those supported by `version_utils` (see `SCHEME` in
[`version_utils`' `version`
extension](https://github.com/jjmaestro/bazel_version_utils/blob/main/version/version.bzl)).
Defaults to `SCHEME.SEMVER`.
2"semver"�
�
versions}
Versions of the archive to download. If none is specified it will
download all of the versions available in the repo index.
2[]�
"//download/archives:repository.bzlrk
6
download_archivesdownload/archivesrepository.bzl#
archives	_archives
>G
Udefs��
6
download_archivesdownload/archivesextensions.bzl�archives�Create a `@<NAME>` index repo and `@<NAME>-<VERSION>` download repos.

The index repo parses the JSON index, generates per-version BUILD files
with aliases pointing to the download repos, and writes repo metadata.
No archives are downloaded at this stage.

Each download repo parses the same index for its version and uses the
same download logic as the eager `archives` rule — trying each source
in order with full per-source download args from the materialized context.
*�	
�
archives(
ctxThe module extension context. (*
nameName for the index repository. (/
index"Label of the repo JSON index file. (>
patches-Dict of patch labels to version spec strings.{}(A
version_scheme#Version scheme (default: `SEMVER`)."semver"(;
spec_syntax Spec syntax (default: `SIMPLE`)."simple"(7
versions%Optional list of versions to include.[](1
sources Optional list of sources to use.[](O
strict_integrity3If True, all sources must share the same integrity.True(�Create a `@<NAME>` index repo and `@<NAME>-<VERSION>` download repos.

The index repo parses the JSON index, generates per-version BUILD files
with aliases pointing to the download repos, and writes repo metadata.
No archives are downloaded at this stage.

Each download repo parses the same index for its version and uses the
same download logic as the eager `archives` rule — trying each source
in order with full per-source download args from the materialized context.
"H
FList of per-version download repo names (`["<NAME>-<VERSION>", ...]`).2A
archives5@@download_archives//download/archives:extensions.bzl
]]2	_archives�ydownload_archives�#
Module extension for per-version archive downloads.

Use `download.archives(...)` to declare archive repositories. Each
declaration creates an index repository (`@<NAME>`) and one download
repository per version (`@<NAME>-<VERSION>`). Archives are only
downloaded when a build references a specific version.

### How it works

The module extension creates two kinds of repositories:

**Index repository (`@<NAME>`)**: created eagerly when the extension is
evaluated. It parses the [repo JSON index], generates per-version BUILD files
with aliases pointing to the download repositories, and writes repo metadata.
No archives are downloaded at this stage. It contains:
- Per-version packages with aliases: `@<NAME>//<VERSION>:files`, `:dir`
- Per-version `source.bzl` with `SOURCE` and `URL` of the actual download
- `repo.bzl` with `VERSIONS`, `DEFAULT_VERSION`, `METADATA`, `LOCK`
- `index.json`, `lock.json`, `metadata.json`

**Download repositories (`@<NAME>-<VERSION>`)**: one per version, created
lazily. Each download repository parses the same index for its version and
uses the same download logic as the `archives` rule, trying each source in
order with full per-source download args from the ["materialized repo
`context`"]. Each contains:
- `:files`: all files in the downloaded archive.
- `:dir`: the path to the directory where the archive was extracted.
- `:<VERSION>`: alias of `:files`.
- `source.bzl`: exports `SOURCE` (the source name) and `URL` (the URL used).

### Version scheme

The `version_scheme` attribute defines the format used for versions in both the
`index` and `patches`. The supported schemes are those in [`version_utils`'
`version` extension], with `SCHEME.SEMVER` ([semantic versioning]) being the
default.

[semantic versioning]: https://semver.org
[`version_utils`' `version` extension]: https://github.com/jjmaestro/bazel_version_utils/blob/main/docs/version/version.md

### Patching

The downloaded archive can also be patched by passing a `patches` argument, a
map of `Label`s of [unified diff format] patch files (applied from the root of
the downloaded archive) to "patch specs" that determine if the patch is to be
applied.

The "patch spec" format is `<VERSION_SPEC>[/<SOURCE>]`, where:

- `<VERSION_SPEC>` is a version constraints requirement spec that
  to specify the versions to which the patch applies.
- `<SOURCE>` (optional, defaults to `*`) is the source of the downloaded
  archive to which the patch should be applied. It's optional and it can also
  be `*`, a wildcard to apply the patch to the archives downloaded from any
  source.

The `<VERSION_SPEC>` syntax is specified with the `spec_syntax` attribute. It's
one of the syntaxes supported by [`version_utils`' `spec` extension] and the
default is `SYNTAX.SIMPLE`.

This helps to maintain patches that apply to e.g.:

- a specific version and source: `1.24.5/github`
- a specific version and all sources: `1.24.5/*` or `1.24.5`
- a range of versions and all sources: `>=1.24.5, <2.0.0/*`
- all versions and sources: `*` or `*/*`

Finally, to simplify patch maintenance, it's good practice to keep a dedicated
"patched branch" for each version we want to maintain, making it easy to
generate the list of patches using [`git format-patch`].

[unified diff format]: https://en.wikipedia.org/wiki/Diff#Unified_format
[`version_utils` `spec` extension]: https://github.com/jjmaestro/bazel_version_utils/blob/main/docs/specs/spec.md
[`git format-patch`]: https://git-scm.com/docs/git-format-patch

### Usage:

```starlark
download = use_extension(
    "@download_archives//download/archives:extensions.bzl",
    "download_archives",
)

download.archives(
    name = "my_src",
    index = "//third-party:repo.json",
)

use_repo(download, "my_src")
```

Building `@my_src//18.1:files` downloads only version 18.1, not all versions
in the index.

To expose the per-version download repositories as direct dependencies (e.g.
for use in `use_repo`), set `expose_internal_repos = True`:

```starlark
download.archives(
    name = "my_src",
    index = "//third-party:repo.json",
    expose_internal_repos = True,
)

use_repo(download, "my_src", "my_src-18.1")
```

["Patching"]: #patching
[`matrix`]: ../../lib/index.md#matrix
[Subresource Integrity (SRI)]: https://w3c.github.io/webappsec-subresource-integrity/
["materialized repo `context`"]: ../../lib/index.md#materialized-repo-context
[`rctx.download_and_extract`]: https://bazel.build/rules/lib/builtins/repository_ctx#download_and_extract
[repo JSON index]: ../../lib/index.md
J�V
�7
download_archives�#
Module extension for per-version archive downloads.

Use `download.archives(...)` to declare archive repositories. Each
declaration creates an index repository (`@<NAME>`) and one download
repository per version (`@<NAME>-<VERSION>`). Archives are only
downloaded when a build references a specific version.

### How it works

The module extension creates two kinds of repositories:

**Index repository (`@<NAME>`)**: created eagerly when the extension is
evaluated. It parses the [repo JSON index], generates per-version BUILD files
with aliases pointing to the download repositories, and writes repo metadata.
No archives are downloaded at this stage. It contains:
- Per-version packages with aliases: `@<NAME>//<VERSION>:files`, `:dir`
- Per-version `source.bzl` with `SOURCE` and `URL` of the actual download
- `repo.bzl` with `VERSIONS`, `DEFAULT_VERSION`, `METADATA`, `LOCK`
- `index.json`, `lock.json`, `metadata.json`

**Download repositories (`@<NAME>-<VERSION>`)**: one per version, created
lazily. Each download repository parses the same index for its version and
uses the same download logic as the `archives` rule, trying each source in
order with full per-source download args from the ["materialized repo
`context`"]. Each contains:
- `:files`: all files in the downloaded archive.
- `:dir`: the path to the directory where the archive was extracted.
- `:<VERSION>`: alias of `:files`.
- `source.bzl`: exports `SOURCE` (the source name) and `URL` (the URL used).

### Version scheme

The `version_scheme` attribute defines the format used for versions in both the
`index` and `patches`. The supported schemes are those in [`version_utils`'
`version` extension], with `SCHEME.SEMVER` ([semantic versioning]) being the
default.

[semantic versioning]: https://semver.org
[`version_utils`' `version` extension]: https://github.com/jjmaestro/bazel_version_utils/blob/main/docs/version/version.md

### Patching

The downloaded archive can also be patched by passing a `patches` argument, a
map of `Label`s of [unified diff format] patch files (applied from the root of
the downloaded archive) to "patch specs" that determine if the patch is to be
applied.

The "patch spec" format is `<VERSION_SPEC>[/<SOURCE>]`, where:

- `<VERSION_SPEC>` is a version constraints requirement spec that
  to specify the versions to which the patch applies.
- `<SOURCE>` (optional, defaults to `*`) is the source of the downloaded
  archive to which the patch should be applied. It's optional and it can also
  be `*`, a wildcard to apply the patch to the archives downloaded from any
  source.

The `<VERSION_SPEC>` syntax is specified with the `spec_syntax` attribute. It's
one of the syntaxes supported by [`version_utils`' `spec` extension] and the
default is `SYNTAX.SIMPLE`.

This helps to maintain patches that apply to e.g.:

- a specific version and source: `1.24.5/github`
- a specific version and all sources: `1.24.5/*` or `1.24.5`
- a range of versions and all sources: `>=1.24.5, <2.0.0/*`
- all versions and sources: `*` or `*/*`

Finally, to simplify patch maintenance, it's good practice to keep a dedicated
"patched branch" for each version we want to maintain, making it easy to
generate the list of patches using [`git format-patch`].

[unified diff format]: https://en.wikipedia.org/wiki/Diff#Unified_format
[`version_utils` `spec` extension]: https://github.com/jjmaestro/bazel_version_utils/blob/main/docs/specs/spec.md
[`git format-patch`]: https://git-scm.com/docs/git-format-patch

### Usage:

```starlark
download = use_extension(
    "@download_archives//download/archives:extensions.bzl",
    "download_archives",
)

download.archives(
    name = "my_src",
    index = "//third-party:repo.json",
)

use_repo(download, "my_src")
```

Building `@my_src//18.1:files` downloads only version 18.1, not all versions
in the index.

To expose the per-version download repositories as direct dependencies (e.g.
for use in `use_repo`), set `expose_internal_repos = True`:

```starlark
download.archives(
    name = "my_src",
    index = "//third-party:repo.json",
    expose_internal_repos = True,
)

use_repo(download, "my_src", "my_src-18.1")
```

["Patching"]: #patching
[`matrix`]: ../../lib/index.md#matrix
[Subresource Integrity (SRI)]: https://w3c.github.io/webappsec-subresource-integrity/
["materialized repo `context`"]: ../../lib/index.md#materialized-repo-context
[`rctx.download_and_extract`]: https://bazel.build/rules/lib/builtins/repository_ctx#download_and_extract
[repo JSON index]: ../../lib/index.md
�
archives�
Declare an archive repository with per-version downloads.

Creates an index repository (`@<NAME>`) with per-version aliases, and
one download repository (`@<NAME>-<VERSION>`) per version. Archives
are only downloaded when a build references a specific version.
*
nameName for the index repository. �
expose_internal_repos�
            When True, the per-version download repositories
            (`@<NAME>-<VERSION>`) are exposed as direct dependencies, allowing
            them to be listed in `use_repo` and referenced directly. Defaults
            to False.
            2False/
index"Label of the repo JSON index file. �
patches�
        Diff files to apply as patches at the root of the downloaded archive.
        The `dict` values represent "patch specs" in the
        `<VERSION_SPEC>/<SOURCE>` format, and determine when patches apply to
        the downloaded archive. Patches must be in standard [unified diff
        format], created from the root of the archive. All patches are applied
        from the root of the archive with `patch -p1`. For more details, see
        ["Patching"].
        	2{}�
sources�
        Source names from which to download the archive. If none, all sources
        from the index are tried in order.
        2[]�
spec_syntax�
        The syntax of the version constraints specification. The available
        syntaxes are those supported by `version_utils` (see `SYNTAX` in
        [`version_utils`' `spec`
        extension](https://github.com/jjmaestro/bazel_version_utils/blob/main/spec/spec.bzl)).
        Defaults to `SYNTAX.SIMPLE`.
        2"simple"�
strict_integrity�
        If `True`, all sources of a given archive version must share the same
        integrity hash. If they differ, the download will fail. Defaults to
        `True`.
        2True�
version_scheme�
        The scheme of the versions in `index` and `patches`. The available
        version schemes are those supported by `version_utils` (see `SCHEME` in
        [`version_utils`' `version`
        extension](https://github.com/jjmaestro/bazel_version_utils/blob/main/version/version.bzl)).
        Defaults to `SCHEME.SEMVER`.
        2"semver"�
versions�
        Versions of the archive to download. If none is specified it will
        download all of the versions available in the repo index.
        2[]"J
download_archives5@@download_archives//download/archives:extensions.bzl
�%�%�
�
archives�
Declare an archive repository with per-version downloads.

Creates an index repository (`@<NAME>`) with per-version aliases, and
one download repository (`@<NAME>-<VERSION>`) per version. Archives
are only downloaded when a build references a specific version.
*
nameName for the index repository. �
expose_internal_repos�
When True, the per-version download repositories
(`@<NAME>-<VERSION>`) are exposed as direct dependencies, allowing
them to be listed in `use_repo` and referenced directly. Defaults
to False.
2False/
index"Label of the repo JSON index file. �
patches�
Diff files to apply as patches at the root of the downloaded archive.
The `dict` values represent "patch specs" in the
`<VERSION_SPEC>/<SOURCE>` format, and determine when patches apply to
the downloaded archive. Patches must be in standard [unified diff
format], created from the root of the archive. All patches are applied
from the root of the archive with `patch -p1`. For more details, see
["Patching"].
	2{}{
sourcesj
Source names from which to download the archive. If none, all sources
from the index are tried in order.
2[]�
spec_syntax�
The syntax of the version constraints specification. The available
syntaxes are those supported by `version_utils` (see `SYNTAX` in
[`version_utils`' `spec`
extension](https://github.com/jjmaestro/bazel_version_utils/blob/main/spec/spec.bzl)).
Defaults to `SYNTAX.SIMPLE`.
2"simple"�
strict_integrity�
If `True`, all sources of a given archive version must share the same
integrity hash. If they differ, the download will fail. Defaults to
`True`.
2True�
version_scheme�
The scheme of the versions in `index` and `patches`. The available
version schemes are those supported by `version_utils` (see `SCHEME` in
[`version_utils`' `version`
extension](https://github.com/jjmaestro/bazel_version_utils/blob/main/version/version.bzl)).
Defaults to `SCHEME.SEMVER`.
2"semver"�
versions}
Versions of the archive to download. If none is specified it will
download all of the versions available in the repo index.
2[],
*
nameName for the index repository. �
�
expose_internal_repos�
When True, the per-version download repositories
(`@<NAME>-<VERSION>`) are exposed as direct dependencies, allowing
them to be listed in `use_repo` and referenced directly. Defaults
to False.
2False1
/
index"Label of the repo JSON index file. �
�
patches�
Diff files to apply as patches at the root of the downloaded archive.
The `dict` values represent "patch specs" in the
`<VERSION_SPEC>/<SOURCE>` format, and determine when patches apply to
the downloaded archive. Patches must be in standard [unified diff
format], created from the root of the archive. All patches are applied
from the root of the archive with `patch -p1`. For more details, see
["Patching"].
	2{}}
{
sourcesj
Source names from which to download the archive. If none, all sources
from the index are tried in order.
2[]�
�
spec_syntax�
The syntax of the version constraints specification. The available
syntaxes are those supported by `version_utils` (see `SYNTAX` in
[`version_utils`' `spec`
extension](https://github.com/jjmaestro/bazel_version_utils/blob/main/spec/spec.bzl)).
Defaults to `SYNTAX.SIMPLE`.
2"simple"�
�
strict_integrity�
If `True`, all sources of a given archive version must share the same
integrity hash. If they differ, the download will fail. Defaults to
`True`.
2True�
�
version_scheme�
The scheme of the versions in `index` and `patches`. The available
version schemes are those supported by `version_utils` (see `SCHEME` in
[`version_utils`' `version`
extension](https://github.com/jjmaestro/bazel_version_utils/blob/main/version/version.bzl)).
Defaults to `SCHEME.SEMVER`.
2"semver"�
�
versions}
Versions of the archive to download. If none is specified it will
download all of the versions available in the repo index.
2[]�
"//download/archives:repository.bzlr�
6
download_archivesdownload/archivesrepository.bzl
ATTRS_ATTRS
		-
DOC_LINK_REFS_DOC_LINK_REFS


+
DOC_PATCHING_DOC_PATCHING
7
DOC_VERSION_SCHEME_DOC_VERSION_SCHEME
#
archives	_archives

f
//lib:index.bzlrQ
#
download_archiveslib	index.bzl
indexIndex
+0
;`
//spec:spec.bzlrK

version_utilsspecspec.bzl
specSpec
'+
5r
//version:version.bzlrW
%
version_utilsversionversion.bzl 
versionVersion
-4
A]
# `download_archives` module extension

Module extension for per-version archive downloads.
��
6
download_archivesdownload/archivesrepository.bzl�archives��
This repository rule wraps [`rctx.download_and_extract`] and creates a Bazel
repo under `@<NAME>`, downloading and extracting *one archive* from *one*
of the sources for *each* of the archive versions in the [repo JSON index].

When downloading the archive, if a source fails it will try the next one, and
only fail if all sources are exhausted.

To construct the arguments passed to [`rctx.download_and_extract`] it uses the
["materialized repo `context`"], which includes at minimum the materialized
`url` from which to download the archive.

### Repo structure

```
  @<NAME>/
   |
   |-- <VERSION>/
   |   |-- BUILD.bazel
   |   `-- <SOURCE>/
   |       |-- BUILD.bazel
   |       |-- ...
   |       `-- ...
   |
   |-- BUILD.bazel
   |-- index.json
   |-- lock.json
   |-- metadata.json
   |-- repo.bzl
   `-- patches/
       |-- <VERSION>/
           `-- <SOURCE>/
               |-- <PATCH_NAME>
               `-- ...
```

TL;DR, the repo can be used as follows:

- `@<NAME>//:<NAME>`: points to the `:files` target of the
  `DEFAULT_VERSION`.
- `@<NAME>//:<TARGET>`: points to the specific `TARGET` of the
  `DEFAULT_VERSION`.
- `@<NAME>//<VERSION>:<TARGET>`: points to the specific `TARGET` of that
  `VERSION`.

The `archives` repository rule creates a `@<NAME>` Bazel repo with a
public `//<VERSION>` package for every version in the index.

Each `//<VERSION>` package has the following targets:
- `:files`: to access all the files in the downloaded archive.
- `:dir`: the directory the archive was extracted into, as a tree artifact
  keyed on the archive and its patches (see `//lib:dir.bzl`).
- `:dir_path`: that same directory as Bazel extracted it, for its path alone
  (see `//lib:dir.bzl` for why it is no good for its contents).
- `:<VERSION>`: `alias` of `:files`.
- `:<OUTPUT>`: one per subpath rendered by the index [`matrix`] `output`, to
  access only the files of that partition of the extracted tree. There are
  none of these when the index has no `matrix` or no `output`.

and two constants:
- `VERSION`: the version of the archive.
- `SOURCE`: the source from which the archive was downloaded.

Each `//<VERSION>` package has an *internal* `<SOURCE>` sub-package with
the actual files from the downloaded archive for that specific `version` and
`source`. The targets in the `//<VERSION>` package are aliases for targets in
the `//<VERSION>/<SOURCE>` sub-packages.

The root package `//` has the following targets:
- `:files`: to access all the files in the `DEFAULT_VERSION` package.
- `:dir`: the directory of the `DEFAULT_VERSION` package, as above.
- `:dir_path`: the path of that directory, as above.
- `:<NAME>`: `alias` of `:files`.
- `:<OUTPUT>`: one per [`matrix`] `output` of the `DEFAULT_VERSION` package,
  as above.

and two constants:
- `VERSION`: the `DEFAULT_VERSION` of the archive.
- `SOURCE`: the source from which the default version was downloaded.

The root package also has the following:
- `//:index.json`: a copy of the repo index JSON file.
- `//:lock.json`: the repo lock file (see below).
- `//:metadata.json`: the repo metadata.
- `//:repo.bzl`: extension with the following constants:
  - `REPO_NAME`: The short repo name.
  - `VERSIONS`: a mapping of the downloaded `version`s to the `source` from
    which the archive was downloaded.
  - `DEFAULT_VERSION`: the default `version` of the archive.
  - `LOCK`: a `dict` with the contents of the repo `lock.json`.
  - `METADATA`: the free-form metadata map straight from the repo JSON index,
    if any.
- `//patches`: a package with `<VERSION>/<SOURCE>` sub-packages with the
  applied patches applied to that archive, if any (see ["Patching"] below).

The repo lock file contains a mapping of the downloaded `version` to a "lock
object" with the following properties:
  - `source`: the source from which the archive was downloaded.
  - `url`: the URL from which the archive was downloaded.
  - `integrity`: the SRI ([Subresource Integrity (SRI)]) of the downloaded archive.
  - `patches`: the list of patches applied to the archive after download, if any.

### Selecting `versions` and `sources`

Users can also override the default selection of versions and sources with the
`versions` and `sources` arguments.

Note that selecting specific versions and/or arguments will change the values
of `VERSIONS` and `DEFAULT_VERSION`.

### Downloading a `matrix` of archives

Some archives are published as a *set* of files per version rather than as a
single file, e.g. a toolchain that publishes one archive per (target triple,
component). The index [`matrix`] describes that set, and the index `output`
decides how the combinations lay out in the extracted tree: combinations that
render the same `output` merge into a single tree, the rest partition it.

E.g. this index downloads four archives for version `1.97.1`, one per
(`triple`, `component`) combination, and partitions them by `triple`:

```json
{
  "version": 1,
  "sources": {
    "static.rust-lang.org": {
      "url": "https://{source}/dist/{component}-{version}-{triple}.tar.xz",
      "strip_prefix": "{component}-{version}-{triple}/{piece}"
    }
  },
  "matrix": [
    {
      "key": "triple",
      "values": ["x86_64-unknown-linux-gnu", "aarch64-unknown-linux-gnu"]
    },
    {
      "key": "component",
      "values": {
        "cargo": {"piece": "cargo"},
        "rustfmt": {"piece": "rustfmt-preview"}
      }
    }
  ],
  "output": "{triple}",
  "versions": {
    "1.97.1": {
      "x86_64-unknown-linux-gnu": {
        "cargo": "sha256-4b5Xkw2Cfk73/RSNy0jgUv/AqIsGpKKO9EhIOqvsG2E=",
        "rustfmt": "sha256-kH/pfWr73h7KGzTJksduFAbUIuLm8TeBPTgqzsfrTRQ="
      },
      "aarch64-unknown-linux-gnu": {
        "cargo": "sha256-j3C8rM6lukvRh8P9TWTiRZK04Wr1E0lyAfWQnWFpHb4=",
        "rustfmt": "sha256-Pb3hXTB5SSQZWuRG89LOtUKhMTBtIq55EsdjTUFGIqg="
      }
    }
  }
}
```

which lays out the repo as:

```
  @rust_toolchain/
   |
   |-- 1.97.1/
   |   |-- BUILD.bazel
   |   `-- static.rust-lang.org/
   |       |-- BUILD.bazel
   |       |-- aarch64-unknown-linux-gnu/
   |       |   |-- bin/
   |       |   `-- ...
   |       `-- x86_64-unknown-linux-gnu/
   |           |-- bin/
   |           `-- ...
   (...)
```

So, on top of `:files`, which is all of the combinations, each rendered
`output` gets its own target:

- `@rust_toolchain//1.97.1:x86_64-unknown-linux-gnu`
- `@rust_toolchain//1.97.1:aarch64-unknown-linux-gnu`

Note that the `cargo` and `rustfmt` archives of a triple *merge* into that
triple's tree, giving one usable prefix with both binaries in `bin/`, while the
two triples stay apart.

### Version scheme

The `version_scheme` attribute defines the format used for versions in both the
`index` and `patches`. The supported schemes are those in [`version_utils`'
`version` extension], with `SCHEME.SEMVER` ([semantic versioning]) being the
default.

[semantic versioning]: https://semver.org
[`version_utils`' `version` extension]: https://github.com/jjmaestro/bazel_version_utils/blob/main/docs/version/version.md

### Patching

The downloaded archive can also be patched by passing a `patches` argument, a
map of `Label`s of [unified diff format] patch files (applied from the root of
the downloaded archive) to "patch specs" that determine if the patch is to be
applied.

The "patch spec" format is `<VERSION_SPEC>[/<SOURCE>]`, where:

- `<VERSION_SPEC>` is a version constraints requirement spec that
  to specify the versions to which the patch applies.
- `<SOURCE>` (optional, defaults to `*`) is the source of the downloaded
  archive to which the patch should be applied. It's optional and it can also
  be `*`, a wildcard to apply the patch to the archives downloaded from any
  source.

The `<VERSION_SPEC>` syntax is specified with the `spec_syntax` attribute. It's
one of the syntaxes supported by [`version_utils`' `spec` extension] and the
default is `SYNTAX.SIMPLE`.

This helps to maintain patches that apply to e.g.:

- a specific version and source: `1.24.5/github`
- a specific version and all sources: `1.24.5/*` or `1.24.5`
- a range of versions and all sources: `>=1.24.5, <2.0.0/*`
- all versions and sources: `*` or `*/*`

Finally, to simplify patch maintenance, it's good practice to keep a dedicated
"patched branch" for each version we want to maintain, making it easy to
generate the list of patches using [`git format-patch`].

[unified diff format]: https://en.wikipedia.org/wiki/Diff#Unified_format
[`version_utils` `spec` extension]: https://github.com/jjmaestro/bazel_version_utils/blob/main/docs/specs/spec.md
[`git format-patch`]: https://git-scm.com/docs/git-format-patch

### Usage:

Here's an example that shows how to create a `@wget_src` repo for [GNU wget]:

[GNU wget]: https://www.gnu.org/software/wget/

#### 1. Create the repo index

First, define a `repo.json` JSON index file in a package. Don't forget to add a
`BUILD.bazel` file in it if one doesn't already exists).

E.g. for a `//third-party/wget` package:

```sh
mkdir -p third-party/wget
touch third-party/wget/BUILD.bazel
```

Then add the following to the `repo.json` file:

```json
{
  "version": 1,
  "sources": {
    "github.com": {
      "owner": "mirror",
      "repo": "wget",
      "tag": "v{version}",
      "url": "https://{source}/{owner}/{repo}/archive/refs/tags/{tag}.tar.gz",
      "strip_prefix": "{repo}-{version}"
    },
    "gitlab.com": {
      "owner": "gnuwget",
      "repo": "wget",
      "tag": "v{version}",
      "filename": "{repo}-{tag}",
      "url": "https://{source}/{owner}/{repo}/-/archive/{tag}/{filename}.tar.gz",
      "strip_prefix": "{filename}"
    }
  },
  "versions": {
    "1.24.5": {
      "integrity": {
        "gitlab.com": "sha256-1Yw1cok0niLv563o07/BrjbCQIflWxK8UFlav9srtcw="
      }
    },
    "1.21.3": {
      "integrity": {
        "github.com": "sha256-VbH6fHnent2TtbYxbNoatK4RNkY3MVPXokJhRzPZBg8=",
        "gitlab.com": "sha256-3w3ImvW4t/H2eMkZbUH+F1zkARSI3cIJSgJFg4ULPU4="
      }
    }
  }
}
```

#### 2. Add the `download_archives` repo to `MODULE.bazel`

Then, add the following to `MODULE.bazel`:

```starlark
download_archives = use_repo_rule("@download_archives//download/archives:defs.bzl", "download_archives")

download_archives(
    name = "wget_src",
    index = "//third-party/wget:repo.json",
    # NOTE:
    # This is how you would add a custom patch for one of the versions. See
    # "Patching" docs for more information about patches.
    # patches = {
    #    "//third-party/wget/patches:0001-1.24.5-test-patch.patch": ">=1.24.5/*",
    # },
    # NOTE:
    # This is needed because the archives have different integrity across the
    # mirrors (see v1.21.3)
    strict_integrity = False,
)
```

#### 3. Test it

To test the Bazel repo, run `bazel fetch @wget_src`. This will attempt to
download and extract all the versions defined in the repo index from the
available sources.

As mentioned before, it will stop downloading any other source for a specific
version when there's a successful download from one source. And, if all
downloads from all sources of a given version fail, it will `fail` with an
error.

Note that in the `repo.json` JSON index file there's one `integrity` missing
for one of the sources (version `1.24.5`, source `github.com`). When this
happens a warning message is printed when the archive download begins asking
the user to add the integrity to the index. And, if the archive is successfully
downloaded, a message with the [Subresource Integrity (SRI)] (`integrity`) and
`SHA256` hex digest will be printed so that it's easy to copy-paste one of them
in the index.

Also note that we set `strict_integrity = False` because the archives for
version `1.21.3` have different integrity hashes across sources. With
`strict_integrity = True`, this would cause the download to fail. Since this
can make builds non-reproducible, the default remains `True`. The option exists
because many artifacts share identical source code but differ in packaging or
other details, resulting in mismatched integrities.

Once installed, the `@wget_src` repo will have the following:

- helper constants available to import from `@wget_src//:repo.bzl`:
  - `REPO_NAME = "wget_src"`
  - `VERSIONS = {"1.24.5": "github.com", "1.21.3": "github.com"}`
  - `DEFAULT_VERSION = "1.24.5"`
  - `LOCK = {...}` (the contents of the repo `lock.json`)

- specific `<VERSION>/<SOURCE>` repos:
  - `@wget_src//1.24.5/github.com`
  - `@wget_src//1.21.3/github.com`

- `alias` repos:
  - `@wget_src` --> `@wget_src//1.24.5/github.com`
  - `@wget_src//1.24.5` --> `@wget_src//1.24.5/github.com`
  - `@wget_src//1.21.3` --> `@wget_src//1.21.3/github.com`

<details>
<summary><h4>More details</h4></summary>

To list all the targets in the repo, run `bazel query @wget_src//...`:

```sh
@wget_src//:dir
@wget_src//:files
@wget_src//:wget_src
@wget_src//1.21.3:1.21.3
@wget_src//1.21.3:dir
@wget_src//1.21.3:files
@wget_src//1.21.3/github.com:dir
@wget_src//1.21.3/github.com:files
@wget_src//1.21.3/github.com:github.com
@wget_src//1.24.5:1.24.5
@wget_src//1.24.5:dir
@wget_src//1.24.5:files
@wget_src//1.24.5/github.com:dir
@wget_src//1.24.5/github.com:files
@wget_src//1.24.5/github.com:github.com
```

In cases where we have many versions and sources in the index we can select the
versions and/or sources from which to download using the `versions` and
`sources` arguments:

```starlark
download_archives(
    name = "wget_src",
    index = "//third-party/wget:repo.json",
    versions = ["1.21.3"],
    sources = ["gitlab.com"],
)
```

Selecting `versions` and `sources` changes what's installed and available in
the `@wget_src` repo:

- helper constants available to import from `@wget_src//:repo.bzl`:
  - `REPO_NAME = "wget_src"`
  - `VERSIONS = {"1.21.3": "gitlab.com"}`
  - `DEFAULT_VERSION = "1.21.3"`

- specific `<VERSION>/<SOURCE>` repos:
  - `@wget_src//1.21.3/gitlab.com`

- `alias` repos:
  - `@wget_src` --> `@wget_src//1.21.3/gitlab.com`
  - `@wget_src//1.21.3` --> `@wget_src//1.21.3/gitlab.com`

Again, let's list all the targets with `bazel query @wget_src//...`:

```sh
@wget_src//:dir
@wget_src//:files
@wget_src//:wget_src
@wget_src//1.21.3:1.21.3
@wget_src//1.21.3:dir
@wget_src//1.21.3:files
@wget_src//1.21.3/gitlab.com:dir
@wget_src//1.21.3/gitlab.com:files
@wget_src//1.21.3/gitlab.com:gitlab.com
```

Similarly, remember that the sources are used as "mirrors" so if the first one
fails to download, the next source will be attempted. Thus, the `VERSIONS`
helper constant, the `alias` repos and the repo `lock.json` will all change
accordingly.

For example, imagine that `github` has version `1.24.5` available but not
`1.21.3`. Then, the download will fall back to the `gitlab.com` source and, if
successful, the `@wget_src` repo will have the following:

- helper constants available to import from `@wget_src//:repo.bzl`:
  - `REPO_NAME = "wget_src"`
  - `VERSIONS = {"1.24.5": "github.com", "1.21.3": "gitlab.com"}`
  - `DEFAULT_VERSION = "1.24.5"`
  - `LOCK = {...}` (the new contents of the repo `lock.json`)

- specific `<VERSION>/<SOURCE>` repos:
  - `@wget_src//1.24.5/github.com`
  - `@wget_src//1.21.3/gitlab.com`

- `alias` repos:
  - `@wget_src` --> `@wget_src//1.24.5/github`
  - `@wget_src//1.24.5` --> `@wget_src//1.24.5/github.com`
  - `@wget_src//1.21.3` --> `@wget_src//1.21.3/gitlab.com`


In this case, the list of targets would look like:

```sh
@wget_src//:dir
@wget_src//:files
@wget_src//:wget_src
@wget_src//1.21.3:1.21.3
@wget_src//1.21.3:dir
@wget_src//1.21.3:files
@wget_src//1.21.3/gitlab.com:dir
@wget_src//1.21.3/gitlab.com:files
@wget_src//1.21.3/gitlab.com:gitlab.com
@wget_src//1.24.5:1.24.5
@wget_src//1.24.5:dir
@wget_src//1.24.5:files
@wget_src//1.24.5/github.com:dir
@wget_src//1.24.5/github.com:files
@wget_src//1.24.5/github.com:github.com
```

</details>

### Per-version downloads (module extension)

For repositories with many versions, use the `download_archives` module
extension from `extensions.bzl` instead of this rule. The module extension
creates one download repository per version, so archives are only downloaded
when a build references a specific version:

```starlark
download = use_extension(
    "@download_archives//download/archives:extensions.bzl",
    "download_archives",
)

download.archives(
    name = "my_src",
    index = "//third-party:repo.json",
)

use_repo(download, "my_src")
```

Building `@my_src//18.1:files` downloads only version 18.1, not all versions
in the index.

["Patching"]: #patching
[`matrix`]: ../../lib/index.md#matrix
[Subresource Integrity (SRI)]: https://w3c.github.io/webappsec-subresource-integrity/
["materialized repo `context`"]: ../../lib/index.md#materialized-repo-context
[`rctx.download_and_extract`]: https://bazel.build/rules/lib/builtins/repository_ctx#download_and_extract
[repo JSON index]: ../../lib/index.md
R��
��
archives��
This repository rule wraps [`rctx.download_and_extract`] and creates a Bazel
repo under `@<NAME>`, downloading and extracting *one archive* from *one*
of the sources for *each* of the archive versions in the [repo JSON index].

When downloading the archive, if a source fails it will try the next one, and
only fail if all sources are exhausted.

To construct the arguments passed to [`rctx.download_and_extract`] it uses the
["materialized repo `context`"], which includes at minimum the materialized
`url` from which to download the archive.

### Repo structure

```
  @<NAME>/
   |
   |-- <VERSION>/
   |   |-- BUILD.bazel
   |   `-- <SOURCE>/
   |       |-- BUILD.bazel
   |       |-- ...
   |       `-- ...
   |
   |-- BUILD.bazel
   |-- index.json
   |-- lock.json
   |-- metadata.json
   |-- repo.bzl
   `-- patches/
       |-- <VERSION>/
           `-- <SOURCE>/
               |-- <PATCH_NAME>
               `-- ...
```

TL;DR, the repo can be used as follows:

- `@<NAME>//:<NAME>`: points to the `:files` target of the
  `DEFAULT_VERSION`.
- `@<NAME>//:<TARGET>`: points to the specific `TARGET` of the
  `DEFAULT_VERSION`.
- `@<NAME>//<VERSION>:<TARGET>`: points to the specific `TARGET` of that
  `VERSION`.

The `archives` repository rule creates a `@<NAME>` Bazel repo with a
public `//<VERSION>` package for every version in the index.

Each `//<VERSION>` package has the following targets:
- `:files`: to access all the files in the downloaded archive.
- `:dir`: the directory the archive was extracted into, as a tree artifact
  keyed on the archive and its patches (see `//lib:dir.bzl`).
- `:dir_path`: that same directory as Bazel extracted it, for its path alone
  (see `//lib:dir.bzl` for why it is no good for its contents).
- `:<VERSION>`: `alias` of `:files`.
- `:<OUTPUT>`: one per subpath rendered by the index [`matrix`] `output`, to
  access only the files of that partition of the extracted tree. There are
  none of these when the index has no `matrix` or no `output`.

and two constants:
- `VERSION`: the version of the archive.
- `SOURCE`: the source from which the archive was downloaded.

Each `//<VERSION>` package has an *internal* `<SOURCE>` sub-package with
the actual files from the downloaded archive for that specific `version` and
`source`. The targets in the `//<VERSION>` package are aliases for targets in
the `//<VERSION>/<SOURCE>` sub-packages.

The root package `//` has the following targets:
- `:files`: to access all the files in the `DEFAULT_VERSION` package.
- `:dir`: the directory of the `DEFAULT_VERSION` package, as above.
- `:dir_path`: the path of that directory, as above.
- `:<NAME>`: `alias` of `:files`.
- `:<OUTPUT>`: one per [`matrix`] `output` of the `DEFAULT_VERSION` package,
  as above.

and two constants:
- `VERSION`: the `DEFAULT_VERSION` of the archive.
- `SOURCE`: the source from which the default version was downloaded.

The root package also has the following:
- `//:index.json`: a copy of the repo index JSON file.
- `//:lock.json`: the repo lock file (see below).
- `//:metadata.json`: the repo metadata.
- `//:repo.bzl`: extension with the following constants:
  - `REPO_NAME`: The short repo name.
  - `VERSIONS`: a mapping of the downloaded `version`s to the `source` from
    which the archive was downloaded.
  - `DEFAULT_VERSION`: the default `version` of the archive.
  - `LOCK`: a `dict` with the contents of the repo `lock.json`.
  - `METADATA`: the free-form metadata map straight from the repo JSON index,
    if any.
- `//patches`: a package with `<VERSION>/<SOURCE>` sub-packages with the
  applied patches applied to that archive, if any (see ["Patching"] below).

The repo lock file contains a mapping of the downloaded `version` to a "lock
object" with the following properties:
  - `source`: the source from which the archive was downloaded.
  - `url`: the URL from which the archive was downloaded.
  - `integrity`: the SRI ([Subresource Integrity (SRI)]) of the downloaded archive.
  - `patches`: the list of patches applied to the archive after download, if any.

### Selecting `versions` and `sources`

Users can also override the default selection of versions and sources with the
`versions` and `sources` arguments.

Note that selecting specific versions and/or arguments will change the values
of `VERSIONS` and `DEFAULT_VERSION`.

### Downloading a `matrix` of archives

Some archives are published as a *set* of files per version rather than as a
single file, e.g. a toolchain that publishes one archive per (target triple,
component). The index [`matrix`] describes that set, and the index `output`
decides how the combinations lay out in the extracted tree: combinations that
render the same `output` merge into a single tree, the rest partition it.

E.g. this index downloads four archives for version `1.97.1`, one per
(`triple`, `component`) combination, and partitions them by `triple`:

```json
{
  "version": 1,
  "sources": {
    "static.rust-lang.org": {
      "url": "https://{source}/dist/{component}-{version}-{triple}.tar.xz",
      "strip_prefix": "{component}-{version}-{triple}/{piece}"
    }
  },
  "matrix": [
    {
      "key": "triple",
      "values": ["x86_64-unknown-linux-gnu", "aarch64-unknown-linux-gnu"]
    },
    {
      "key": "component",
      "values": {
        "cargo": {"piece": "cargo"},
        "rustfmt": {"piece": "rustfmt-preview"}
      }
    }
  ],
  "output": "{triple}",
  "versions": {
    "1.97.1": {
      "x86_64-unknown-linux-gnu": {
        "cargo": "sha256-4b5Xkw2Cfk73/RSNy0jgUv/AqIsGpKKO9EhIOqvsG2E=",
        "rustfmt": "sha256-kH/pfWr73h7KGzTJksduFAbUIuLm8TeBPTgqzsfrTRQ="
      },
      "aarch64-unknown-linux-gnu": {
        "cargo": "sha256-j3C8rM6lukvRh8P9TWTiRZK04Wr1E0lyAfWQnWFpHb4=",
        "rustfmt": "sha256-Pb3hXTB5SSQZWuRG89LOtUKhMTBtIq55EsdjTUFGIqg="
      }
    }
  }
}
```

which lays out the repo as:

```
  @rust_toolchain/
   |
   |-- 1.97.1/
   |   |-- BUILD.bazel
   |   `-- static.rust-lang.org/
   |       |-- BUILD.bazel
   |       |-- aarch64-unknown-linux-gnu/
   |       |   |-- bin/
   |       |   `-- ...
   |       `-- x86_64-unknown-linux-gnu/
   |           |-- bin/
   |           `-- ...
   (...)
```

So, on top of `:files`, which is all of the combinations, each rendered
`output` gets its own target:

- `@rust_toolchain//1.97.1:x86_64-unknown-linux-gnu`
- `@rust_toolchain//1.97.1:aarch64-unknown-linux-gnu`

Note that the `cargo` and `rustfmt` archives of a triple *merge* into that
triple's tree, giving one usable prefix with both binaries in `bin/`, while the
two triples stay apart.

### Version scheme

The `version_scheme` attribute defines the format used for versions in both the
`index` and `patches`. The supported schemes are those in [`version_utils`'
`version` extension], with `SCHEME.SEMVER` ([semantic versioning]) being the
default.

[semantic versioning]: https://semver.org
[`version_utils`' `version` extension]: https://github.com/jjmaestro/bazel_version_utils/blob/main/docs/version/version.md

### Patching

The downloaded archive can also be patched by passing a `patches` argument, a
map of `Label`s of [unified diff format] patch files (applied from the root of
the downloaded archive) to "patch specs" that determine if the patch is to be
applied.

The "patch spec" format is `<VERSION_SPEC>[/<SOURCE>]`, where:

- `<VERSION_SPEC>` is a version constraints requirement spec that
  to specify the versions to which the patch applies.
- `<SOURCE>` (optional, defaults to `*`) is the source of the downloaded
  archive to which the patch should be applied. It's optional and it can also
  be `*`, a wildcard to apply the patch to the archives downloaded from any
  source.

The `<VERSION_SPEC>` syntax is specified with the `spec_syntax` attribute. It's
one of the syntaxes supported by [`version_utils`' `spec` extension] and the
default is `SYNTAX.SIMPLE`.

This helps to maintain patches that apply to e.g.:

- a specific version and source: `1.24.5/github`
- a specific version and all sources: `1.24.5/*` or `1.24.5`
- a range of versions and all sources: `>=1.24.5, <2.0.0/*`
- all versions and sources: `*` or `*/*`

Finally, to simplify patch maintenance, it's good practice to keep a dedicated
"patched branch" for each version we want to maintain, making it easy to
generate the list of patches using [`git format-patch`].

[unified diff format]: https://en.wikipedia.org/wiki/Diff#Unified_format
[`version_utils` `spec` extension]: https://github.com/jjmaestro/bazel_version_utils/blob/main/docs/specs/spec.md
[`git format-patch`]: https://git-scm.com/docs/git-format-patch

### Usage:

Here's an example that shows how to create a `@wget_src` repo for [GNU wget]:

[GNU wget]: https://www.gnu.org/software/wget/

#### 1. Create the repo index

First, define a `repo.json` JSON index file in a package. Don't forget to add a
`BUILD.bazel` file in it if one doesn't already exists).

E.g. for a `//third-party/wget` package:

```sh
mkdir -p third-party/wget
touch third-party/wget/BUILD.bazel
```

Then add the following to the `repo.json` file:

```json
{
  "version": 1,
  "sources": {
    "github.com": {
      "owner": "mirror",
      "repo": "wget",
      "tag": "v{version}",
      "url": "https://{source}/{owner}/{repo}/archive/refs/tags/{tag}.tar.gz",
      "strip_prefix": "{repo}-{version}"
    },
    "gitlab.com": {
      "owner": "gnuwget",
      "repo": "wget",
      "tag": "v{version}",
      "filename": "{repo}-{tag}",
      "url": "https://{source}/{owner}/{repo}/-/archive/{tag}/{filename}.tar.gz",
      "strip_prefix": "{filename}"
    }
  },
  "versions": {
    "1.24.5": {
      "integrity": {
        "gitlab.com": "sha256-1Yw1cok0niLv563o07/BrjbCQIflWxK8UFlav9srtcw="
      }
    },
    "1.21.3": {
      "integrity": {
        "github.com": "sha256-VbH6fHnent2TtbYxbNoatK4RNkY3MVPXokJhRzPZBg8=",
        "gitlab.com": "sha256-3w3ImvW4t/H2eMkZbUH+F1zkARSI3cIJSgJFg4ULPU4="
      }
    }
  }
}
```

#### 2. Add the `download_archives` repo to `MODULE.bazel`

Then, add the following to `MODULE.bazel`:

```starlark
download_archives = use_repo_rule("@download_archives//download/archives:defs.bzl", "download_archives")

download_archives(
    name = "wget_src",
    index = "//third-party/wget:repo.json",
    # NOTE:
    # This is how you would add a custom patch for one of the versions. See
    # "Patching" docs for more information about patches.
    # patches = {
    #    "//third-party/wget/patches:0001-1.24.5-test-patch.patch": ">=1.24.5/*",
    # },
    # NOTE:
    # This is needed because the archives have different integrity across the
    # mirrors (see v1.21.3)
    strict_integrity = False,
)
```

#### 3. Test it

To test the Bazel repo, run `bazel fetch @wget_src`. This will attempt to
download and extract all the versions defined in the repo index from the
available sources.

As mentioned before, it will stop downloading any other source for a specific
version when there's a successful download from one source. And, if all
downloads from all sources of a given version fail, it will `fail` with an
error.

Note that in the `repo.json` JSON index file there's one `integrity` missing
for one of the sources (version `1.24.5`, source `github.com`). When this
happens a warning message is printed when the archive download begins asking
the user to add the integrity to the index. And, if the archive is successfully
downloaded, a message with the [Subresource Integrity (SRI)] (`integrity`) and
`SHA256` hex digest will be printed so that it's easy to copy-paste one of them
in the index.

Also note that we set `strict_integrity = False` because the archives for
version `1.21.3` have different integrity hashes across sources. With
`strict_integrity = True`, this would cause the download to fail. Since this
can make builds non-reproducible, the default remains `True`. The option exists
because many artifacts share identical source code but differ in packaging or
other details, resulting in mismatched integrities.

Once installed, the `@wget_src` repo will have the following:

- helper constants available to import from `@wget_src//:repo.bzl`:
  - `REPO_NAME = "wget_src"`
  - `VERSIONS = {"1.24.5": "github.com", "1.21.3": "github.com"}`
  - `DEFAULT_VERSION = "1.24.5"`
  - `LOCK = {...}` (the contents of the repo `lock.json`)

- specific `<VERSION>/<SOURCE>` repos:
  - `@wget_src//1.24.5/github.com`
  - `@wget_src//1.21.3/github.com`

- `alias` repos:
  - `@wget_src` --> `@wget_src//1.24.5/github.com`
  - `@wget_src//1.24.5` --> `@wget_src//1.24.5/github.com`
  - `@wget_src//1.21.3` --> `@wget_src//1.21.3/github.com`

<details>
<summary><h4>More details</h4></summary>

To list all the targets in the repo, run `bazel query @wget_src//...`:

```sh
@wget_src//:dir
@wget_src//:files
@wget_src//:wget_src
@wget_src//1.21.3:1.21.3
@wget_src//1.21.3:dir
@wget_src//1.21.3:files
@wget_src//1.21.3/github.com:dir
@wget_src//1.21.3/github.com:files
@wget_src//1.21.3/github.com:github.com
@wget_src//1.24.5:1.24.5
@wget_src//1.24.5:dir
@wget_src//1.24.5:files
@wget_src//1.24.5/github.com:dir
@wget_src//1.24.5/github.com:files
@wget_src//1.24.5/github.com:github.com
```

In cases where we have many versions and sources in the index we can select the
versions and/or sources from which to download using the `versions` and
`sources` arguments:

```starlark
download_archives(
    name = "wget_src",
    index = "//third-party/wget:repo.json",
    versions = ["1.21.3"],
    sources = ["gitlab.com"],
)
```

Selecting `versions` and `sources` changes what's installed and available in
the `@wget_src` repo:

- helper constants available to import from `@wget_src//:repo.bzl`:
  - `REPO_NAME = "wget_src"`
  - `VERSIONS = {"1.21.3": "gitlab.com"}`
  - `DEFAULT_VERSION = "1.21.3"`

- specific `<VERSION>/<SOURCE>` repos:
  - `@wget_src//1.21.3/gitlab.com`

- `alias` repos:
  - `@wget_src` --> `@wget_src//1.21.3/gitlab.com`
  - `@wget_src//1.21.3` --> `@wget_src//1.21.3/gitlab.com`

Again, let's list all the targets with `bazel query @wget_src//...`:

```sh
@wget_src//:dir
@wget_src//:files
@wget_src//:wget_src
@wget_src//1.21.3:1.21.3
@wget_src//1.21.3:dir
@wget_src//1.21.3:files
@wget_src//1.21.3/gitlab.com:dir
@wget_src//1.21.3/gitlab.com:files
@wget_src//1.21.3/gitlab.com:gitlab.com
```

Similarly, remember that the sources are used as "mirrors" so if the first one
fails to download, the next source will be attempted. Thus, the `VERSIONS`
helper constant, the `alias` repos and the repo `lock.json` will all change
accordingly.

For example, imagine that `github` has version `1.24.5` available but not
`1.21.3`. Then, the download will fall back to the `gitlab.com` source and, if
successful, the `@wget_src` repo will have the following:

- helper constants available to import from `@wget_src//:repo.bzl`:
  - `REPO_NAME = "wget_src"`
  - `VERSIONS = {"1.24.5": "github.com", "1.21.3": "gitlab.com"}`
  - `DEFAULT_VERSION = "1.24.5"`
  - `LOCK = {...}` (the new contents of the repo `lock.json`)

- specific `<VERSION>/<SOURCE>` repos:
  - `@wget_src//1.24.5/github.com`
  - `@wget_src//1.21.3/gitlab.com`

- `alias` repos:
  - `@wget_src` --> `@wget_src//1.24.5/github`
  - `@wget_src//1.24.5` --> `@wget_src//1.24.5/github.com`
  - `@wget_src//1.21.3` --> `@wget_src//1.21.3/gitlab.com`


In this case, the list of targets would look like:

```sh
@wget_src//:dir
@wget_src//:files
@wget_src//:wget_src
@wget_src//1.21.3:1.21.3
@wget_src//1.21.3:dir
@wget_src//1.21.3:files
@wget_src//1.21.3/gitlab.com:dir
@wget_src//1.21.3/gitlab.com:files
@wget_src//1.21.3/gitlab.com:gitlab.com
@wget_src//1.24.5:1.24.5
@wget_src//1.24.5:dir
@wget_src//1.24.5:files
@wget_src//1.24.5/github.com:dir
@wget_src//1.24.5/github.com:files
@wget_src//1.24.5/github.com:github.com
```

</details>

### Per-version downloads (module extension)

For repositories with many versions, use the `download_archives` module
extension from `extensions.bzl` instead of this rule. The module extension
creates one download repository per version, so archives are only downloaded
when a build references a specific version:

```starlark
download = use_extension(
    "@download_archives//download/archives:extensions.bzl",
    "download_archives",
)

download.archives(
    name = "my_src",
    index = "//third-party:repo.json",
)

use_repo(download, "my_src")
```

Building `@my_src//18.1:files` downloads only version 18.1, not all versions
in the index.

["Patching"]: #patching
[`matrix`]: ../../lib/index.md#matrix
[Subresource Integrity (SRI)]: https://w3c.github.io/webappsec-subresource-integrity/
["materialized repo `context`"]: ../../lib/index.md#materialized-repo-context
[`rctx.download_and_extract`]: https://bazel.build/rules/lib/builtins/repository_ctx#download_and_extract
[repo JSON index]: ../../lib/index.md
.
name"A unique name for this repository. /
index"Label of the repo JSON index file. �
lazy�
Internal. When True, creates index-only repos with stub BUILD files
that alias to per-version download repositories instead of downloading
archives eagerly. Used by the `download_archives` module extension,
should not be set directly.
2False�
patches�
Diff files to apply as patches at the root of the downloaded archive.
The `dict` values represent "patch specs" in the
`<VERSION_SPEC>/<SOURCE>` format, and determine when patches apply to
the downloaded archive. Patches must be in standard [unified diff
format], created from the root of the archive. All patches are applied
from the root of the archive with `patch -p1`. For more details, see
["Patching"].
	2{}�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 {
sourcesj
Source names from which to download the archive. If none, all sources
from the index are tried in order.
2[]�
spec_syntax�
The syntax of the version constraints specification. The available
syntaxes are those supported by `version_utils` (see `SYNTAX` in
[`version_utils`' `spec`
extension](https://github.com/jjmaestro/bazel_version_utils/blob/main/spec/spec.bzl)).
Defaults to `SYNTAX.SIMPLE`.
2"simple"�
strict_integrity�
If `True`, all sources of a given archive version must share the same
integrity hash. If they differ, the download will fail. Defaults to
`True`.
2True�
version_scheme�
The scheme of the versions in `index` and `patches`. The available
version schemes are those supported by `version_utils` (see `SCHEME` in
[`version_utils`' `version`
extension](https://github.com/jjmaestro/bazel_version_utils/blob/main/version/version.bzl)).
Defaults to `SCHEME.SEMVER`.
2"semver"�
versions}
Versions of the archive to download. If none is specified it will
download all of the versions available in the repo index.
2[]*A
archives5@@download_archives//download/archives:repository.bzl
��0
.
name"A unique name for this repository. 1
/
index"Label of the repo JSON index file. �
�
lazy�
Internal. When True, creates index-only repos with stub BUILD files
that alias to per-version download repositories instead of downloading
archives eagerly. Used by the `download_archives` module extension,
should not be set directly.
2False�
�
patches�
Diff files to apply as patches at the root of the downloaded archive.
The `dict` values represent "patch specs" in the
`<VERSION_SPEC>/<SOURCE>` format, and determine when patches apply to
the downloaded archive. Patches must be in standard [unified diff
format], created from the root of the archive. All patches are applied
from the root of the archive with `patch -p1`. For more details, see
["Patching"].
	2{}�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 }
{
sourcesj
Source names from which to download the archive. If none, all sources
from the index are tried in order.
2[]�
�
spec_syntax�
The syntax of the version constraints specification. The available
syntaxes are those supported by `version_utils` (see `SYNTAX` in
[`version_utils`' `spec`
extension](https://github.com/jjmaestro/bazel_version_utils/blob/main/spec/spec.bzl)).
Defaults to `SYNTAX.SIMPLE`.
2"simple"�
�
strict_integrity�
If `True`, all sources of a given archive version must share the same
integrity hash. If they differ, the download will fail. Defaults to
`True`.
2True�
�
version_scheme�
The scheme of the versions in `index` and `patches`. The available
version schemes are those supported by `version_utils` (see `SCHEME` in
[`version_utils`' `version`
extension](https://github.com/jjmaestro/bazel_version_utils/blob/main/version/version.bzl)).
Defaults to `SCHEME.SEMVER`.
2"semver"�
�
versions}
Versions of the archive to download. If none is specified it will
download all of the versions available in the repo index.
2[]r
//lib:download.bzlrZ
&
download_archiveslibdownload.bzl"
downloadDownload

.
6


Df
//lib:index.bzlrQ
#
download_archiveslib	index.bzl
indexIndex
+0
;f
//lib:utils.bzlrQ
#
download_archiveslib	utils.bzl
utilsUtils
+0
;`
//spec:spec.bzlrK

version_utilsspecspec.bzl
specSpec
'+
5r
//version:version.bzlrW
%
version_utilsversionversion.bzl 
versionVersion
-4
A�	DOC_LINK_REFS�
["Patching"]: #patching
[`matrix`]: ../../lib/index.md#matrix
[Subresource Integrity (SRI)]: https://w3c.github.io/webappsec-subresource-integrity/
["materialized repo `context`"]: ../../lib/index.md#materialized-repo-context
[`rctx.download_and_extract`]: https://bazel.build/rules/lib/builtins/repository_ctx#download_and_extract
[repo JSON index]: ../../lib/index.md
j��
["Patching"]: #patching
[`matrix`]: ../../lib/index.md#matrix
[Subresource Integrity (SRI)]: https://w3c.github.io/webappsec-subresource-integrity/
["materialized repo `context`"]: ../../lib/index.md#materialized-repo-context
[`rctx.download_and_extract`]: https://bazel.build/rules/lib/builtins/repository_ctx#download_and_extract
[repo JSON index]: ../../lib/index.md
�	DOC_PATCHING�
### Patching

The downloaded archive can also be patched by passing a `patches` argument, a
map of `Label`s of [unified diff format] patch files (applied from the root of
the downloaded archive) to "patch specs" that determine if the patch is to be
applied.

The "patch spec" format is `<VERSION_SPEC>[/<SOURCE>]`, where:

- `<VERSION_SPEC>` is a version constraints requirement spec that
  to specify the versions to which the patch applies.
- `<SOURCE>` (optional, defaults to `*`) is the source of the downloaded
  archive to which the patch should be applied. It's optional and it can also
  be `*`, a wildcard to apply the patch to the archives downloaded from any
  source.

The `<VERSION_SPEC>` syntax is specified with the `spec_syntax` attribute. It's
one of the syntaxes supported by [`version_utils`' `spec` extension] and the
default is `SYNTAX.SIMPLE`.

This helps to maintain patches that apply to e.g.:

- a specific version and source: `1.24.5/github`
- a specific version and all sources: `1.24.5/*` or `1.24.5`
- a range of versions and all sources: `>=1.24.5, <2.0.0/*`
- all versions and sources: `*` or `*/*`

Finally, to simplify patch maintenance, it's good practice to keep a dedicated
"patched branch" for each version we want to maintain, making it easy to
generate the list of patches using [`git format-patch`].

[unified diff format]: https://en.wikipedia.org/wiki/Diff#Unified_format
[`version_utils` `spec` extension]: https://github.com/jjmaestro/bazel_version_utils/blob/main/docs/specs/spec.md
[`git format-patch`]: https://git-scm.com/docs/git-format-patch
j��
### Patching

The downloaded archive can also be patched by passing a `patches` argument, a
map of `Label`s of [unified diff format] patch files (applied from the root of
the downloaded archive) to "patch specs" that determine if the patch is to be
applied.

The "patch spec" format is `<VERSION_SPEC>[/<SOURCE>]`, where:

- `<VERSION_SPEC>` is a version constraints requirement spec that
  to specify the versions to which the patch applies.
- `<SOURCE>` (optional, defaults to `*`) is the source of the downloaded
  archive to which the patch should be applied. It's optional and it can also
  be `*`, a wildcard to apply the patch to the archives downloaded from any
  source.

The `<VERSION_SPEC>` syntax is specified with the `spec_syntax` attribute. It's
one of the syntaxes supported by [`version_utils`' `spec` extension] and the
default is `SYNTAX.SIMPLE`.

This helps to maintain patches that apply to e.g.:

- a specific version and source: `1.24.5/github`
- a specific version and all sources: `1.24.5/*` or `1.24.5`
- a range of versions and all sources: `>=1.24.5, <2.0.0/*`
- all versions and sources: `*` or `*/*`

Finally, to simplify patch maintenance, it's good practice to keep a dedicated
"patched branch" for each version we want to maintain, making it easy to
generate the list of patches using [`git format-patch`].

[unified diff format]: https://en.wikipedia.org/wiki/Diff#Unified_format
[`version_utils` `spec` extension]: https://github.com/jjmaestro/bazel_version_utils/blob/main/docs/specs/spec.md
[`git format-patch`]: https://git-scm.com/docs/git-format-patch
�	DOC_VERSION_SCHEME�
### Version scheme

The `version_scheme` attribute defines the format used for versions in both the
`index` and `patches`. The supported schemes are those in [`version_utils`'
`version` extension], with `SCHEME.SEMVER` ([semantic versioning]) being the
default.

[semantic versioning]: https://semver.org
[`version_utils`' `version` extension]: https://github.com/jjmaestro/bazel_version_utils/blob/main/docs/version/version.md
j��
### Version scheme

The `version_scheme` attribute defines the format used for versions in both the
`index` and `patches`. The supported schemes are those in [`version_utils`'
`version` extension], with `SCHEME.SEMVER` ([semantic versioning]) being the
default.

[semantic versioning]: https://semver.org
[`version_utils`' `version` extension]: https://github.com/jjmaestro/bazel_version_utils/blob/main/docs/version/version.md
�
# `archives` repository rule

Repository rule to create and maintain Bazel external repos. It helps reduce
boilerplate code by keeping a JSON index file with all of the metadata required
to download and extract an archive: the archive's `version`(s) and the
`source`(s) from which to try to download the archive.
�
!
download_archiveslibdir.bzl�dir_treet
Copy an extracted archive directory into a tree artifact, keyed on the
files that decide what the directory holds.
"�
�
dir_treet
Copy an extracted archive directory into a tree artifact, keyed on the
files that decide what the directory holds.
*
nameA unique name for this target. w
keyjFiles whose contents decide what `src` holds: the repo `lock.json` and the patches applied to the archive.2[]=
src2The extracted archive directory, i.e. `:dir_path`. ",
dir_tree @@download_archives//lib:dir.bzl
OO,
*
nameA unique name for this target. y
w
keyjFiles whose contents decide what `src` holds: the repo `lock.json` and the patches applied to the archive.2[]?
=
src2The extracted archive directory, i.e. `:dir_path`. �
# `dir_tree`

Copies an extracted archive into a tree artifact, keyed on what the archive is
rather than only on the directory holding it.

## Why

An extracted archive is a directory, and a build that wants a source tree wants
it as one: autotools, cmake and cargo all take a directory rather than a file
list, and a directory is the only form that carries the symlinks, the empty
directories, and any subtree a nested `BUILD` file would cut a glob short at.

What taking a directory costs is that Bazel does not hash its contents, and says
so of every such input:

```text
WARNING: input '' of <TARGET> is a directory;
dependency checking of directories is unsound
```

An action reading one is not re-run when the tree changes, and this repository
rule re-downloading and re-patching does not help, because nothing downstream
can observe that it did. The failure mode is a patch that is silently ignored:
adding one to a version already built changes the extracted tree and nothing
else, so the build goes on compiling the tree it staged first.

So `dir_tree` copies the directory and declares beside it, as `key`, the files
that decide what the directory holds: the repo `lock.json`, whose `url` and
`integrity` are the archive it was unpacked from, and the patches then applied
to it, taken by content rather than by label since editing a patch is the
ordinary way to work on one. A change to either re-keys the copy.

None of which makes a directory dependency sound, and this does not pretend to:
an edit reaching the extracted tree by some other route still goes unnoticed. It
closes the routes this repository rule itself takes.

The copy is the `copy_directory` toolchain binary with `--hardlink`, the tree
being copied again only when the repo has re-extracted it wholesale, so there is
nothing to gain by copying bytes.
�
&
download_archiveslibdownload.bzl�download.apply_patch8Apply a patch with path rewriting for nested extraction.*�
�
download.apply_patch

rctx (
version (
source (
patch (8Apply a patch with path rewriting for nested extraction.25
_apply_patch%@@download_archives//lib:download.bzl
ll�download.check_strict_integrity<Fail if repos for a version have different integrity hashes.*�
�
download.check_strict_integrity
repos (
version (
_fail (<Fail if repos for a version have different integrity hashes.2@
_check_strict_integrity%@@download_archives//lib:download.bzl
##�download.make_download_argsHBuild rctx.download_and_extract kwargs from a materialized repo context.*�
�
download.make_download_args
	repo_path (
repo_context (%
_print<built-in function print>(HBuild rctx.download_and_extract kwargs from a materialized repo context.2<
_make_download_args%@@download_archives//lib:download.bzl
::�download.try_sources�Try downloading a version from each source in order.

Handles the full download-level workflow: strict integrity check, download,
integrity warning, source.bzl generation, and patch application. Archives
are extracted to `version/source/` and patches are rewritten to match the
nested layout.
*�	
�	
download.try_sources
rctxRepository context. (-
	repo_nameName for log/error messages. ((
versionVersion being downloaded. (:
repos-List of repo struct sources to try, in order. (�
patches�label_keyed_string_dict of patch labels to version specs.
Matching is computed per-source; only the winning source's patches
are applied.{}(4
spec_syntaxSpec syntax for patch matching.""(:
version_scheme"Version scheme for patch matching.""(X
strict_integrity;If True, fail when sources have different integrity
hashes.False(C
_printPrint function for warnings.<built-in function print>(q
_failFail function for errors.K<unknown object build.stack.devtools.build.constellate.StarlarkEvaluator$7>(�Try downloading a version from each source in order.

Handles the full download-level workflow: strict integrity check, download,
integrity warning, source.bzl generation, and patch application. Archives
are extracted to `version/source/` and patches are rewritten to match the
nested layout.
"j
hstruct(source, url, integrity, sha256, output, patches) on first
success, or None if all sources failed.25
_try_sources%@@download_archives//lib:download.bzl
���download5Shared download helpers for archive repository rules.z�
download
��5Shared download helpers for archive repository rules."b
check_strict_integrity
��_check_strict_integrity"download.check_strict_integrity"V
make_download_args
��_make_download_args"download.make_download_args"A
apply_patch
��_apply_patch"download.apply_patch"A
try_sources
��_try_sources"download.try_sources*%@@download_archives//lib:download.bzlf
//lib:utils.bzlrQ
#
download_archiveslib	utils.bzl
utilsUtils
+0
;5Shared download helpers for archive repository rules.��
#
download_archiveslib	index.bzl�index.__test__._select_keys*�
�
index.__test__._select_keys	
key (

keys (
selected (
prefixNone(

keep_firstTrue(
reverseFalse(V
_failK<unknown object build.stack.devtools.build.constellate.StarlarkEvaluator$7>(22
_select_keys"@@download_archives//lib:index.bzl
���	index.new*�
�
	index.new
	repo_name (

index_json (
versionsNone(
sourcesNone(%
_print<built-in function print>(V
_failK<unknown object build.stack.devtools.build.constellate.StarlarkEvaluator$7>(2*
_new"@@download_archives//lib:index.bzl
����index�
# repo JSON index

The repo JSON index is a JSON object that contains all of the metadata required
to download an archive.

In summary, the index is structured (and potentially templated) metadata that's
used to generate (materialize) the URLs from which to download the archives for
each `version`.

## Structure

The index JSON object has the following properties:
- `version` (`int`): the version of the JSON index object.
- `versions` (`dict[version, version_context] | list[version]`): maps `version`
  names to [`version` context]s. If a `list` of versions is provided, it will
  be expanded to a `dict` of `version`s mapped to empty `version` contexts.
- `sources` (`dict[source, source_context]`): maps `source` names to [URL
  `source` context]s.
- `matrix` (`list[axis]`, optional): expands each `version` into a *combination
  of archives* instead of a single one. See [`matrix`].
- `output` (`str`, optional): template that decides the subpath each `matrix`
  combination is extracted into. See [`output`: merging and partitioning].
- `metadata` (`dict[any, any]`): free-form "metadata map", useful to add
  information about the archive that we want to have available in the repo
  (e.g. requirements, version compatibility, external dependencies, etc).

The index JSON object is parsed, validated and converted to an `index`
`struct` with the following properties:
- `version` (`int`): the version of the index struct, matching the version of
  the JSON index object.
- `name` (`str`): the short repo name.
- `repos` (`dict[version, list[repo]]`): maps the archive `version` to the
  `repo` `struct`s. These `struct`s will be used by the `install` repository
  rule to download the versions of the archive.

Each `repo` `struct` has the following properties:
  - `name`: the short repo name
  - `version`: the `version` name
  - `source`: the `source` name
  - `context`: the [`materialized` repo context] which will have, at the very
    least, the `url` from which to download the archive.
  - `contexts`: the list of `struct(output, context)`, one per [`matrix`]
    combination, each with the combination's `materialized` repo `context` and
    its materialized `output` subpath. Without a `matrix` this is a
    single-element list holding `context` and an empty `output`.

## Contexts

### `materialized` repo context

The `materialized` context is built by:

- adding all the properties in the [`default` context], the [`version` context]
  and the [URL `source` context]. Note that *all* of the properties
  in the `version` and URL `source` contexts can be templated using string
  replacements.

- materializing one by one with the context available up to that point
- adding the materialized property to the materialization context so that its
  materialized value is available to the properties after it for string replacement.

Thus, for materialization purposes, **the order of the properties matters**:
**only properties previously defined can be used as string replacements**.

This way, there's a lot of flexibility to define almost any type of `source`
URL format.

### `default` context

The `default` context is a context that's automatically seeded with the values
of `repo_name`, `version` and `source`.

### `version` context

The `version` context object contains properties whose values **change with
each version**. These properties are required to generate (materialize) the
corresponding `source` properties.

The properties can have any name except the following reserved names:
`integrity_algo`, `integrity_hex_digest` and `integrity_sri` (see [Special
context properties]).

These property values can be specific to one source ("per-source") or can apply
to all sources ("global").

The per-source `version` context is a "fully expanded" `dict`-of-`dict`s that
map `version` properties to `source`s:

```json
{
  (...)
  "versions": {
    "1.1": {
      "ext": {
        "example.com": "tar.gz"
      }
    },
    "1.0": {
      "ext": {
        "example.com": "tgz"
      }
    }
  }
}
```

If certain properties apply to all sources, the "global" context provides a
more compact syntax, just a key-value `dict` where the values are not `dict`
i.e. they don't explicitly map to a `source`, e.g.

```json
{
  "version": 1,
  "sources": {
    "example.com": {
      "url": "https://{source}/{version}.{ext}"
    }
  },
  "versions": {
    "1.1": {
      "ext": "tar.gz",
    },
    "1.0": {
      "ext": "tgz",
    }
  }
}
```

where `versions` expands to the "fully expanded" per-source `version` context,
as before.

Finally, a special case of the "global" `version` context can be just a `list`
of versions where each `version` will be expanded to an empty `version`
context, e.g.:

```json
{
  "version": 1,
  "sources": {
    "example.com": {
      "url": "https://{source}/{version}.tgz"
    }
  },
  "versions": ["1.0"]
}
```

where `versions` expands to:

```json
{
  (...)
  "versions": {
    "1.0": {}
  }
}
```

Finally, note that *all* of the property values in the `version` context can be
templated using string replacements. See [`materialized` repo context] for more
details.

### URL `source` context

The URL `source` context object contains properties whose values **change with
each source**. These properties are required to generate (materialize) the only
mandatory `source` property: the `url` to download the archive.

The properties can have any name except the following reserved names:
`integrity_algo`, `integrity_hex_digest` and `integrity_sri` (see [Special
context properties]).

E.g. the simplest index JSON example we had before:

```json
{
  "version": 1,
  "sources": {
    "example.com": {
      "url": "https://{source}/{version}.tgz"
    }
  },
  "versions": ["1.0"]
}
```

will materialize the following `url`: `"https://example.com/1.0.tgz"`.

Note that *all* of the property values in the URL `source` context can be
templated using string replacements. See [`materialized` repo context] for more
details.


## `matrix`

Some archives are not published as *one* file per version but as a *set* of
files. E.g. a toolchain publishes one archive per (target triple, component)
and all of them together make up the toolchain.

The `matrix` describes that set as an ordered list of *axes*:

```json
{
  "version": 1,
  "sources": {
    "static.rust-lang.org": {
      "url": "https://{source}/dist/{component}-{version}-{triple}.tar.xz",
      "strip_prefix": "{component}-{version}-{triple}/{piece}"
    }
  },
  "matrix": [
    {
      "key": "triple",
      "values": ["x86_64-unknown-linux-gnu", "aarch64-unknown-linux-gnu"]
    },
    {
      "key": "component",
      "values": {
        "cargo": {"piece": "cargo"},
        "rust-std": {"piece": "rust-std-{triple}"},
        "rustfmt": {"piece": "rustfmt-preview"}
      }
    }
  ],
  "output": "{triple}"
}
```

Each axis is an object with two mandatory properties:

- `key` (`str`): the name of the context property that the axis sets. The value
  selected for the axis is available for string replacement as `{<key>}`.
- `values` (`list[str] | dict[str, dict]`): the values of the axis. The `dict`
  form maps each value to *extra context properties* that apply only when that
  value is selected (`piece`, above, which is the sub-directory to strip
  because it differs per component).

The archive is downloaded once *per combination*, i.e. the cartesian product of
all the axes, in matrix order and with the last axis varying fastest. Without a
`matrix` there's exactly one combination with no properties, which is the
pre-`matrix` behavior.

### `matrix` combinations and the repo `context`

The properties of a combination are added to the [`materialized` repo context]
right after the [`default` context] and before the [`version` context] and the
[URL `source` context], so both of those can reference them (e.g. the `url` and
the `strip_prefix` above).

They are materialized in axis order, so an axis can reference the axes before
it: `rust-std`'s `piece` is `"rust-std-{triple}"` because `triple` is the first
axis.

### `matrix` integrity

With a `matrix` there is one archive, and thus one integrity, per combination,
so the [`version` context] nests the integrities by axis value, in matrix
order:

```json
{
  (...)
  "versions": {
    "1.97.1": {
      "x86_64-unknown-linux-gnu": {
        "cargo": "sha256-4b5Xkw2Cfk73/RSNy0jgUv/AqIsGpKKO9EhIOqvsG2E=",
        "rust-std": "sha256-HB5wSugBJrfeNPcuooJffQFzbewgcy5aiibz3Ek5s74="
      }
    }
  }
}
```

As with the non-`matrix` [`version` context], the leaf is either the integrity
itself ("global", the same archive in all sources) or a `dict` that maps each
`source` to its integrity ("per-source").

### `output`: merging and partitioning

`output` is a template, materialized with each combination's context, that
decides the subpath *under the archive's `<VERSION>/<SOURCE>` directory* into
which that combination is extracted.

Combinations that render the *same* `output` are extracted on top of each other
and *merge* into a single tree; combinations that render *different* `output`s
*partition* the tree. In the example above, `"output": "{triple}"` merges all
the components of a triple into one usable toolchain prefix while keeping the
two triples apart.

Every rendered `output` also gets its own `filegroup` in the generated repo, so
consumers can depend on one partition instead of on the whole tree.

When `output` is not set, all combinations extract into the same directory,
i.e. everything merges.

Finally, note that a `source` is only used if *all* of its combinations
download successfully. Otherwise, the next source is tried. This keeps a
partial mirror from leaving behind a half-materialized tree.

TODO: combinations are always downloaded eagerly, all of them, even in the
per-version lazy mode of the `download_archives` module extension. Consider a
hub-and-spoke layout with one download repo per combination so that e.g. only
the triple that's actually built gets downloaded.

### Special context properties

There are two context properties that are "special": `integrity` and `sha256`.

The `sha256` property is expected to have the `SHA256` hex digest of the
archive and the `integrity` property, the [Subresource Integrity (SRI)] of the
archive. However, for convenience, the `integrity` property also accepts hex
digests.

Both are optional and mutually exclusive, only one of them should be set / used
per version and source. If not present, a warning message will be printed
asking to add it to the index. This is important because the integrity of the
archives is crucial to the safety and reproducibility of the builds.

Note that if one of these properties is present, a special "expansion" will
always add *four* special properties to the context: `integrity_algo`,
`integrity_hex_digest`, `integrity_sri` and `integrity` corresponding to the
integrity algorithm, hex digest and SRI, plus `sha256` if the SRI or hex digest
is of a `SHA256` algorithm.

## Examples

### Example 1:

```json
{
  "version": 1,
  "sources": {
    "example.com": {
      "url": "https://{source}/{version}.tgz"
    }
  },
  "versions": ["1.0"]
}
```

In this example, the `materialized` context **before** it's actually
materialized will consist of the `default` context properties (`repo_name`,
`version` and `source`) plus the `url` property from the URL `source` context:
```starlark
{
    "repo_name": <REPO>,
    "version": "1.0",
    "source": "example.com",
    "url": "https://{source}/{version}.tgz",
}
```

Thus, the final `materialized` repo context will be:
```starlark
{
    "repo_name": <REPO>,
    "version": "1.0",
    "source": "example.com",
    "url": "https://example.com/1.0.tgz",
}
```

### Example 2:

```json
{
  "version": 1,
  "urls": {
    "mirror1": {
      "domain": "example.com",
      "tag": "v{version}",
      "filename": "foobar-{tag}",
      "strip_prefix": "{filename}",
      "url": "https://{domain}/{tag}/{filename}-{sha256}.tgz"
    },
    "mirror2": {
      "url": "https://{source}.mirrors.com/{repo_name}/{version}/{sha256}.tgz"
    }
  },
  "versions": {
    "1.1": {
      "sha256": {
        "mirror1": "fcde2b2edba56bf408601fb721fe9b5c338d10ee429ea04fae5511b68fbf8fb9",
        "mirror2": "c3ab8ff13720e8ad9047dd39466b3c8974e592c2fa383d4a3960714caef0c4f2"
    },
    "1.0": {
      "sha256": "2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae"
    }
  }
}
```

In this example, the `materialized` repo contexts  **before** actually being
materialized will consist of:
```starlark

# version: 1.0, source: mirror1
{
    "repo_name": <REPO>,
    "version": "1.0",
    "source": "mirror1",

    # version context with special context properties expanded
    "integrity": "sha256-LCa0a2j/xo/5m0U8HTBBNBNCLXBkg7+g+YpeiGJm564=",
    "integrity_algo": "sha256",
    "integrity_sri": "sha256-LCa0a2j/xo/5m0U8HTBBNBNCLXBkg7+g+YpeiGJm564=",
    "integrity_hex_digest": "2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae",
    "sha256": "2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae",

    # source context
    "domain": "example.com",
    "tag": "v{version}",
    "filename": "foobar-{tag}",
    "strip_prefix": "{filename}",
    "url": "https://{domain}/{tag}/{filename}-{sha256}.tgz",
}

# version: 1.0, source: mirror2
{
    "repo_name": <REPO>,
    "version": "1.0",
    "source": "mirror2",

    # version context with special context properties expanded
    "integrity": "sha256-LCa0a2j/xo/5m0U8HTBBNBNCLXBkg7+g+YpeiGJm564=",
    "integrity_algo": "sha256",
    "integrity_sri": "sha256-LCa0a2j/xo/5m0U8HTBBNBNCLXBkg7+g+YpeiGJm564=",
    "integrity_hex_digest": "2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae",
    "sha256": "2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae",

    # source context
    "url": "https://{source}.mirrors.com/{repo_name}/{version}/{sha256}.tgz"
}

# version: 1.1, source: mirror1
{
    "repo_name": <REPO>,
    "version": "1.1",
    "source": "mirror1",

    # version context with special context properties expanded
    "integrity": "sha256-/N4rLtula/QIYB+3If6bXDONEO5CnqBPrlURto+/j7k=",
    "integrity_algo": "sha256",
    "integrity_sri": "sha256-/N4rLtula/QIYB+3If6bXDONEO5CnqBPrlURto+/j7k=",
    "integrity_hex_digest": "fcde2b2edba56bf408601fb721fe9b5c338d10ee429ea04fae5511b68fbf8fb9",
    "sha256": "fcde2b2edba56bf408601fb721fe9b5c338d10ee429ea04fae5511b68fbf8fb9",

    # source context
    "domain": "example.com",
    "tag": "v{version}",
    "filename": "foobar-{tag}",
    "strip_prefix": "{filename}",
    "url": "https://{domain}/{tag}/{filename}-{sha256}.tgz",
}

# version: 1.1, source: mirror2
{
    "repo_name": <REPO>,
    "version": "1.1",
    "source": "mirror2",

    # version context with special context properties expanded
    "integrity": "sha256-w6uP8Tcg6K2QR905Rms8iXTlksL6OD1KOWBxTK7wxPI=",
    "integrity_algo": "sha256",
    "integrity_sri": "sha256-w6uP8Tcg6K2QR905Rms8iXTlksL6OD1KOWBxTK7wxPI=",
    "integrity_hex_digest": "c3ab8ff13720e8ad9047dd39466b3c8974e592c2fa383d4a3960714caef0c4f2",
    "sha256": "c3ab8ff13720e8ad9047dd39466b3c8974e592c2fa383d4a3960714caef0c4f2",

    # source context
    "url": "https://{source}.mirrors.com/{repo_name}/{version}/{sha256}.tgz"
}
```

And the final `materialized` context for e.g. version `1.1` and `source`
`mirror1` will be:

```starlark
# version: 1.1, source: mirror1
{
    "repo_name": <REPO>,
    "version": "1.1",
    "source": "mirror1",

    # version context with special context properties expanded
    "integrity": "sha256-/N4rLtula/QIYB+3If6bXDONEO5CnqBPrlURto+/j7k=",
    "integrity_algo": "sha256",
    "integrity_sri": "sha256-/N4rLtula/QIYB+3If6bXDONEO5CnqBPrlURto+/j7k=",
    "integrity_hex_digest": "fcde2b2edba56bf408601fb721fe9b5c338d10ee429ea04fae5511b68fbf8fb9",
    "sha256": "fcde2b2edba56bf408601fb721fe9b5c338d10ee429ea04fae5511b68fbf8fb9",

    # source context
    "domain": "example.com",
    "tag": "v1.1",
    "filename": "foobar-v1.1",
    "strip_prefix": "foobar-v1.1",
    "url": "https://example.com/v1.1/foobar-v1.1-fcde2b2edba56bf408601fb721fe9b5c338d10ee429ea04fae5511b68fbf8fb9.tgz",
}
```

[`materialized` repo context]: #materialized-repo-context
[`default` context]: #default-context
[`version` context]: #version-context
[URL `source` context]: #url-source-context
[`matrix`]: #matrix
[`output`: merging and partitioning]: #output-merging-and-partitioning
[Special context properties]: #special-context-properties
[Subresource Integrity (SRI)]: https://w3c.github.io/webappsec-subresource-integrity/
z��
index
���
# repo JSON index

The repo JSON index is a JSON object that contains all of the metadata required
to download an archive.

In summary, the index is structured (and potentially templated) metadata that's
used to generate (materialize) the URLs from which to download the archives for
each `version`.

## Structure

The index JSON object has the following properties:
- `version` (`int`): the version of the JSON index object.
- `versions` (`dict[version, version_context] | list[version]`): maps `version`
  names to [`version` context]s. If a `list` of versions is provided, it will
  be expanded to a `dict` of `version`s mapped to empty `version` contexts.
- `sources` (`dict[source, source_context]`): maps `source` names to [URL
  `source` context]s.
- `matrix` (`list[axis]`, optional): expands each `version` into a *combination
  of archives* instead of a single one. See [`matrix`].
- `output` (`str`, optional): template that decides the subpath each `matrix`
  combination is extracted into. See [`output`: merging and partitioning].
- `metadata` (`dict[any, any]`): free-form "metadata map", useful to add
  information about the archive that we want to have available in the repo
  (e.g. requirements, version compatibility, external dependencies, etc).

The index JSON object is parsed, validated and converted to an `index`
`struct` with the following properties:
- `version` (`int`): the version of the index struct, matching the version of
  the JSON index object.
- `name` (`str`): the short repo name.
- `repos` (`dict[version, list[repo]]`): maps the archive `version` to the
  `repo` `struct`s. These `struct`s will be used by the `install` repository
  rule to download the versions of the archive.

Each `repo` `struct` has the following properties:
  - `name`: the short repo name
  - `version`: the `version` name
  - `source`: the `source` name
  - `context`: the [`materialized` repo context] which will have, at the very
    least, the `url` from which to download the archive.
  - `contexts`: the list of `struct(output, context)`, one per [`matrix`]
    combination, each with the combination's `materialized` repo `context` and
    its materialized `output` subpath. Without a `matrix` this is a
    single-element list holding `context` and an empty `output`.

## Contexts

### `materialized` repo context

The `materialized` context is built by:

- adding all the properties in the [`default` context], the [`version` context]
  and the [URL `source` context]. Note that *all* of the properties
  in the `version` and URL `source` contexts can be templated using string
  replacements.

- materializing one by one with the context available up to that point
- adding the materialized property to the materialization context so that its
  materialized value is available to the properties after it for string replacement.

Thus, for materialization purposes, **the order of the properties matters**:
**only properties previously defined can be used as string replacements**.

This way, there's a lot of flexibility to define almost any type of `source`
URL format.

### `default` context

The `default` context is a context that's automatically seeded with the values
of `repo_name`, `version` and `source`.

### `version` context

The `version` context object contains properties whose values **change with
each version**. These properties are required to generate (materialize) the
corresponding `source` properties.

The properties can have any name except the following reserved names:
`integrity_algo`, `integrity_hex_digest` and `integrity_sri` (see [Special
context properties]).

These property values can be specific to one source ("per-source") or can apply
to all sources ("global").

The per-source `version` context is a "fully expanded" `dict`-of-`dict`s that
map `version` properties to `source`s:

```json
{
  (...)
  "versions": {
    "1.1": {
      "ext": {
        "example.com": "tar.gz"
      }
    },
    "1.0": {
      "ext": {
        "example.com": "tgz"
      }
    }
  }
}
```

If certain properties apply to all sources, the "global" context provides a
more compact syntax, just a key-value `dict` where the values are not `dict`
i.e. they don't explicitly map to a `source`, e.g.

```json
{
  "version": 1,
  "sources": {
    "example.com": {
      "url": "https://{source}/{version}.{ext}"
    }
  },
  "versions": {
    "1.1": {
      "ext": "tar.gz",
    },
    "1.0": {
      "ext": "tgz",
    }
  }
}
```

where `versions` expands to the "fully expanded" per-source `version` context,
as before.

Finally, a special case of the "global" `version` context can be just a `list`
of versions where each `version` will be expanded to an empty `version`
context, e.g.:

```json
{
  "version": 1,
  "sources": {
    "example.com": {
      "url": "https://{source}/{version}.tgz"
    }
  },
  "versions": ["1.0"]
}
```

where `versions` expands to:

```json
{
  (...)
  "versions": {
    "1.0": {}
  }
}
```

Finally, note that *all* of the property values in the `version` context can be
templated using string replacements. See [`materialized` repo context] for more
details.

### URL `source` context

The URL `source` context object contains properties whose values **change with
each source**. These properties are required to generate (materialize) the only
mandatory `source` property: the `url` to download the archive.

The properties can have any name except the following reserved names:
`integrity_algo`, `integrity_hex_digest` and `integrity_sri` (see [Special
context properties]).

E.g. the simplest index JSON example we had before:

```json
{
  "version": 1,
  "sources": {
    "example.com": {
      "url": "https://{source}/{version}.tgz"
    }
  },
  "versions": ["1.0"]
}
```

will materialize the following `url`: `"https://example.com/1.0.tgz"`.

Note that *all* of the property values in the URL `source` context can be
templated using string replacements. See [`materialized` repo context] for more
details.


## `matrix`

Some archives are not published as *one* file per version but as a *set* of
files. E.g. a toolchain publishes one archive per (target triple, component)
and all of them together make up the toolchain.

The `matrix` describes that set as an ordered list of *axes*:

```json
{
  "version": 1,
  "sources": {
    "static.rust-lang.org": {
      "url": "https://{source}/dist/{component}-{version}-{triple}.tar.xz",
      "strip_prefix": "{component}-{version}-{triple}/{piece}"
    }
  },
  "matrix": [
    {
      "key": "triple",
      "values": ["x86_64-unknown-linux-gnu", "aarch64-unknown-linux-gnu"]
    },
    {
      "key": "component",
      "values": {
        "cargo": {"piece": "cargo"},
        "rust-std": {"piece": "rust-std-{triple}"},
        "rustfmt": {"piece": "rustfmt-preview"}
      }
    }
  ],
  "output": "{triple}"
}
```

Each axis is an object with two mandatory properties:

- `key` (`str`): the name of the context property that the axis sets. The value
  selected for the axis is available for string replacement as `{<key>}`.
- `values` (`list[str] | dict[str, dict]`): the values of the axis. The `dict`
  form maps each value to *extra context properties* that apply only when that
  value is selected (`piece`, above, which is the sub-directory to strip
  because it differs per component).

The archive is downloaded once *per combination*, i.e. the cartesian product of
all the axes, in matrix order and with the last axis varying fastest. Without a
`matrix` there's exactly one combination with no properties, which is the
pre-`matrix` behavior.

### `matrix` combinations and the repo `context`

The properties of a combination are added to the [`materialized` repo context]
right after the [`default` context] and before the [`version` context] and the
[URL `source` context], so both of those can reference them (e.g. the `url` and
the `strip_prefix` above).

They are materialized in axis order, so an axis can reference the axes before
it: `rust-std`'s `piece` is `"rust-std-{triple}"` because `triple` is the first
axis.

### `matrix` integrity

With a `matrix` there is one archive, and thus one integrity, per combination,
so the [`version` context] nests the integrities by axis value, in matrix
order:

```json
{
  (...)
  "versions": {
    "1.97.1": {
      "x86_64-unknown-linux-gnu": {
        "cargo": "sha256-4b5Xkw2Cfk73/RSNy0jgUv/AqIsGpKKO9EhIOqvsG2E=",
        "rust-std": "sha256-HB5wSugBJrfeNPcuooJffQFzbewgcy5aiibz3Ek5s74="
      }
    }
  }
}
```

As with the non-`matrix` [`version` context], the leaf is either the integrity
itself ("global", the same archive in all sources) or a `dict` that maps each
`source` to its integrity ("per-source").

### `output`: merging and partitioning

`output` is a template, materialized with each combination's context, that
decides the subpath *under the archive's `<VERSION>/<SOURCE>` directory* into
which that combination is extracted.

Combinations that render the *same* `output` are extracted on top of each other
and *merge* into a single tree; combinations that render *different* `output`s
*partition* the tree. In the example above, `"output": "{triple}"` merges all
the components of a triple into one usable toolchain prefix while keeping the
two triples apart.

Every rendered `output` also gets its own `filegroup` in the generated repo, so
consumers can depend on one partition instead of on the whole tree.

When `output` is not set, all combinations extract into the same directory,
i.e. everything merges.

Finally, note that a `source` is only used if *all* of its combinations
download successfully. Otherwise, the next source is tried. This keeps a
partial mirror from leaving behind a half-materialized tree.

TODO: combinations are always downloaded eagerly, all of them, even in the
per-version lazy mode of the `download_archives` module extension. Consider a
hub-and-spoke layout with one download repo per combination so that e.g. only
the triple that's actually built gets downloaded.

### Special context properties

There are two context properties that are "special": `integrity` and `sha256`.

The `sha256` property is expected to have the `SHA256` hex digest of the
archive and the `integrity` property, the [Subresource Integrity (SRI)] of the
archive. However, for convenience, the `integrity` property also accepts hex
digests.

Both are optional and mutually exclusive, only one of them should be set / used
per version and source. If not present, a warning message will be printed
asking to add it to the index. This is important because the integrity of the
archives is crucial to the safety and reproducibility of the builds.

Note that if one of these properties is present, a special "expansion" will
always add *four* special properties to the context: `integrity_algo`,
`integrity_hex_digest`, `integrity_sri` and `integrity` corresponding to the
integrity algorithm, hex digest and SRI, plus `sha256` if the SRI or hex digest
is of a `SHA256` algorithm.

## Examples

### Example 1:

```json
{
  "version": 1,
  "sources": {
    "example.com": {
      "url": "https://{source}/{version}.tgz"
    }
  },
  "versions": ["1.0"]
}
```

In this example, the `materialized` context **before** it's actually
materialized will consist of the `default` context properties (`repo_name`,
`version` and `source`) plus the `url` property from the URL `source` context:
```starlark
{
    "repo_name": <REPO>,
    "version": "1.0",
    "source": "example.com",
    "url": "https://{source}/{version}.tgz",
}
```

Thus, the final `materialized` repo context will be:
```starlark
{
    "repo_name": <REPO>,
    "version": "1.0",
    "source": "example.com",
    "url": "https://example.com/1.0.tgz",
}
```

### Example 2:

```json
{
  "version": 1,
  "urls": {
    "mirror1": {
      "domain": "example.com",
      "tag": "v{version}",
      "filename": "foobar-{tag}",
      "strip_prefix": "{filename}",
      "url": "https://{domain}/{tag}/{filename}-{sha256}.tgz"
    },
    "mirror2": {
      "url": "https://{source}.mirrors.com/{repo_name}/{version}/{sha256}.tgz"
    }
  },
  "versions": {
    "1.1": {
      "sha256": {
        "mirror1": "fcde2b2edba56bf408601fb721fe9b5c338d10ee429ea04fae5511b68fbf8fb9",
        "mirror2": "c3ab8ff13720e8ad9047dd39466b3c8974e592c2fa383d4a3960714caef0c4f2"
    },
    "1.0": {
      "sha256": "2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae"
    }
  }
}
```

In this example, the `materialized` repo contexts  **before** actually being
materialized will consist of:
```starlark

# version: 1.0, source: mirror1
{
    "repo_name": <REPO>,
    "version": "1.0",
    "source": "mirror1",

    # version context with special context properties expanded
    "integrity": "sha256-LCa0a2j/xo/5m0U8HTBBNBNCLXBkg7+g+YpeiGJm564=",
    "integrity_algo": "sha256",
    "integrity_sri": "sha256-LCa0a2j/xo/5m0U8HTBBNBNCLXBkg7+g+YpeiGJm564=",
    "integrity_hex_digest": "2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae",
    "sha256": "2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae",

    # source context
    "domain": "example.com",
    "tag": "v{version}",
    "filename": "foobar-{tag}",
    "strip_prefix": "{filename}",
    "url": "https://{domain}/{tag}/{filename}-{sha256}.tgz",
}

# version: 1.0, source: mirror2
{
    "repo_name": <REPO>,
    "version": "1.0",
    "source": "mirror2",

    # version context with special context properties expanded
    "integrity": "sha256-LCa0a2j/xo/5m0U8HTBBNBNCLXBkg7+g+YpeiGJm564=",
    "integrity_algo": "sha256",
    "integrity_sri": "sha256-LCa0a2j/xo/5m0U8HTBBNBNCLXBkg7+g+YpeiGJm564=",
    "integrity_hex_digest": "2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae",
    "sha256": "2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae",

    # source context
    "url": "https://{source}.mirrors.com/{repo_name}/{version}/{sha256}.tgz"
}

# version: 1.1, source: mirror1
{
    "repo_name": <REPO>,
    "version": "1.1",
    "source": "mirror1",

    # version context with special context properties expanded
    "integrity": "sha256-/N4rLtula/QIYB+3If6bXDONEO5CnqBPrlURto+/j7k=",
    "integrity_algo": "sha256",
    "integrity_sri": "sha256-/N4rLtula/QIYB+3If6bXDONEO5CnqBPrlURto+/j7k=",
    "integrity_hex_digest": "fcde2b2edba56bf408601fb721fe9b5c338d10ee429ea04fae5511b68fbf8fb9",
    "sha256": "fcde2b2edba56bf408601fb721fe9b5c338d10ee429ea04fae5511b68fbf8fb9",

    # source context
    "domain": "example.com",
    "tag": "v{version}",
    "filename": "foobar-{tag}",
    "strip_prefix": "{filename}",
    "url": "https://{domain}/{tag}/{filename}-{sha256}.tgz",
}

# version: 1.1, source: mirror2
{
    "repo_name": <REPO>,
    "version": "1.1",
    "source": "mirror2",

    # version context with special context properties expanded
    "integrity": "sha256-w6uP8Tcg6K2QR905Rms8iXTlksL6OD1KOWBxTK7wxPI=",
    "integrity_algo": "sha256",
    "integrity_sri": "sha256-w6uP8Tcg6K2QR905Rms8iXTlksL6OD1KOWBxTK7wxPI=",
    "integrity_hex_digest": "c3ab8ff13720e8ad9047dd39466b3c8974e592c2fa383d4a3960714caef0c4f2",
    "sha256": "c3ab8ff13720e8ad9047dd39466b3c8974e592c2fa383d4a3960714caef0c4f2",

    # source context
    "url": "https://{source}.mirrors.com/{repo_name}/{version}/{sha256}.tgz"
}
```

And the final `materialized` context for e.g. version `1.1` and `source`
`mirror1` will be:

```starlark
# version: 1.1, source: mirror1
{
    "repo_name": <REPO>,
    "version": "1.1",
    "source": "mirror1",

    # version context with special context properties expanded
    "integrity": "sha256-/N4rLtula/QIYB+3If6bXDONEO5CnqBPrlURto+/j7k=",
    "integrity_algo": "sha256",
    "integrity_sri": "sha256-/N4rLtula/QIYB+3If6bXDONEO5CnqBPrlURto+/j7k=",
    "integrity_hex_digest": "fcde2b2edba56bf408601fb721fe9b5c338d10ee429ea04fae5511b68fbf8fb9",
    "sha256": "fcde2b2edba56bf408601fb721fe9b5c338d10ee429ea04fae5511b68fbf8fb9",

    # source context
    "domain": "example.com",
    "tag": "v1.1",
    "filename": "foobar-v1.1",
    "strip_prefix": "foobar-v1.1",
    "url": "https://example.com/v1.1/foobar-v1.1-fcde2b2edba56bf408601fb721fe9b5c338d10ee429ea04fae5511b68fbf8fb9.tgz",
}
```

[`materialized` repo context]: #materialized-repo-context
[`default` context]: #default-context
[`version` context]: #version-context
[URL `source` context]: #url-source-context
[`matrix`]: #matrix
[`output`: merging and partitioning]: #output-merging-and-partitioning
[Special context properties]: #special-context-properties
[Subresource Integrity (SRI)]: https://w3c.github.io/webappsec-subresource-integrity/
"&
new
��_new"	index.new"*
__test__
��"index.__test__*"@@download_archives//lib:index.bzlz
//lib:integrity.bzlra
'
download_archiveslibintegrity.bzl&
	integrity	Integrity
�/�8
��Gn
//lib:matrix.bzlrX
$
download_archiveslib
matrix.bzl 
matrixMatrix
�,�2
��>n
//lib:schema.bzlrX
$
download_archiveslib
schema.bzl 
schemaSchema
�,�2
��>j
//lib:utils.bzlrU
#
download_archiveslib	utils.bzl
utilsUtils
�+�0
��;�
# repo JSON index

The repo JSON index is a JSON object that contains all of the metadata required
to download an archive.

In summary, the index is structured (and potentially templated) metadata that's
used to generate (materialize) the URLs from which to download the archives for
each `version`.

## Structure

The index JSON object has the following properties:
- `version` (`int`): the version of the JSON index object.
- `versions` (`dict[version, version_context] | list[version]`): maps `version`
  names to [`version` context]s. If a `list` of versions is provided, it will
  be expanded to a `dict` of `version`s mapped to empty `version` contexts.
- `sources` (`dict[source, source_context]`): maps `source` names to [URL
  `source` context]s.
- `matrix` (`list[axis]`, optional): expands each `version` into a *combination
  of archives* instead of a single one. See [`matrix`].
- `output` (`str`, optional): template that decides the subpath each `matrix`
  combination is extracted into. See [`output`: merging and partitioning].
- `metadata` (`dict[any, any]`): free-form "metadata map", useful to add
  information about the archive that we want to have available in the repo
  (e.g. requirements, version compatibility, external dependencies, etc).

The index JSON object is parsed, validated and converted to an `index`
`struct` with the following properties:
- `version` (`int`): the version of the index struct, matching the version of
  the JSON index object.
- `name` (`str`): the short repo name.
- `repos` (`dict[version, list[repo]]`): maps the archive `version` to the
  `repo` `struct`s. These `struct`s will be used by the `install` repository
  rule to download the versions of the archive.

Each `repo` `struct` has the following properties:
  - `name`: the short repo name
  - `version`: the `version` name
  - `source`: the `source` name
  - `context`: the [`materialized` repo context] which will have, at the very
    least, the `url` from which to download the archive.
  - `contexts`: the list of `struct(output, context)`, one per [`matrix`]
    combination, each with the combination's `materialized` repo `context` and
    its materialized `output` subpath. Without a `matrix` this is a
    single-element list holding `context` and an empty `output`.

## Contexts

### `materialized` repo context

The `materialized` context is built by:

- adding all the properties in the [`default` context], the [`version` context]
  and the [URL `source` context]. Note that *all* of the properties
  in the `version` and URL `source` contexts can be templated using string
  replacements.

- materializing one by one with the context available up to that point
- adding the materialized property to the materialization context so that its
  materialized value is available to the properties after it for string replacement.

Thus, for materialization purposes, **the order of the properties matters**:
**only properties previously defined can be used as string replacements**.

This way, there's a lot of flexibility to define almost any type of `source`
URL format.

### `default` context

The `default` context is a context that's automatically seeded with the values
of `repo_name`, `version` and `source`.

### `version` context

The `version` context object contains properties whose values **change with
each version**. These properties are required to generate (materialize) the
corresponding `source` properties.

The properties can have any name except the following reserved names:
`integrity_algo`, `integrity_hex_digest` and `integrity_sri` (see [Special
context properties]).

These property values can be specific to one source ("per-source") or can apply
to all sources ("global").

The per-source `version` context is a "fully expanded" `dict`-of-`dict`s that
map `version` properties to `source`s:

```json
{
  (...)
  "versions": {
    "1.1": {
      "ext": {
        "example.com": "tar.gz"
      }
    },
    "1.0": {
      "ext": {
        "example.com": "tgz"
      }
    }
  }
}
```

If certain properties apply to all sources, the "global" context provides a
more compact syntax, just a key-value `dict` where the values are not `dict`
i.e. they don't explicitly map to a `source`, e.g.

```json
{
  "version": 1,
  "sources": {
    "example.com": {
      "url": "https://{source}/{version}.{ext}"
    }
  },
  "versions": {
    "1.1": {
      "ext": "tar.gz",
    },
    "1.0": {
      "ext": "tgz",
    }
  }
}
```

where `versions` expands to the "fully expanded" per-source `version` context,
as before.

Finally, a special case of the "global" `version` context can be just a `list`
of versions where each `version` will be expanded to an empty `version`
context, e.g.:

```json
{
  "version": 1,
  "sources": {
    "example.com": {
      "url": "https://{source}/{version}.tgz"
    }
  },
  "versions": ["1.0"]
}
```

where `versions` expands to:

```json
{
  (...)
  "versions": {
    "1.0": {}
  }
}
```

Finally, note that *all* of the property values in the `version` context can be
templated using string replacements. See [`materialized` repo context] for more
details.

### URL `source` context

The URL `source` context object contains properties whose values **change with
each source**. These properties are required to generate (materialize) the only
mandatory `source` property: the `url` to download the archive.

The properties can have any name except the following reserved names:
`integrity_algo`, `integrity_hex_digest` and `integrity_sri` (see [Special
context properties]).

E.g. the simplest index JSON example we had before:

```json
{
  "version": 1,
  "sources": {
    "example.com": {
      "url": "https://{source}/{version}.tgz"
    }
  },
  "versions": ["1.0"]
}
```

will materialize the following `url`: `"https://example.com/1.0.tgz"`.

Note that *all* of the property values in the URL `source` context can be
templated using string replacements. See [`materialized` repo context] for more
details.


## `matrix`

Some archives are not published as *one* file per version but as a *set* of
files. E.g. a toolchain publishes one archive per (target triple, component)
and all of them together make up the toolchain.

The `matrix` describes that set as an ordered list of *axes*:

```json
{
  "version": 1,
  "sources": {
    "static.rust-lang.org": {
      "url": "https://{source}/dist/{component}-{version}-{triple}.tar.xz",
      "strip_prefix": "{component}-{version}-{triple}/{piece}"
    }
  },
  "matrix": [
    {
      "key": "triple",
      "values": ["x86_64-unknown-linux-gnu", "aarch64-unknown-linux-gnu"]
    },
    {
      "key": "component",
      "values": {
        "cargo": {"piece": "cargo"},
        "rust-std": {"piece": "rust-std-{triple}"},
        "rustfmt": {"piece": "rustfmt-preview"}
      }
    }
  ],
  "output": "{triple}"
}
```

Each axis is an object with two mandatory properties:

- `key` (`str`): the name of the context property that the axis sets. The value
  selected for the axis is available for string replacement as `{<key>}`.
- `values` (`list[str] | dict[str, dict]`): the values of the axis. The `dict`
  form maps each value to *extra context properties* that apply only when that
  value is selected (`piece`, above, which is the sub-directory to strip
  because it differs per component).

The archive is downloaded once *per combination*, i.e. the cartesian product of
all the axes, in matrix order and with the last axis varying fastest. Without a
`matrix` there's exactly one combination with no properties, which is the
pre-`matrix` behavior.

### `matrix` combinations and the repo `context`

The properties of a combination are added to the [`materialized` repo context]
right after the [`default` context] and before the [`version` context] and the
[URL `source` context], so both of those can reference them (e.g. the `url` and
the `strip_prefix` above).

They are materialized in axis order, so an axis can reference the axes before
it: `rust-std`'s `piece` is `"rust-std-{triple}"` because `triple` is the first
axis.

### `matrix` integrity

With a `matrix` there is one archive, and thus one integrity, per combination,
so the [`version` context] nests the integrities by axis value, in matrix
order:

```json
{
  (...)
  "versions": {
    "1.97.1": {
      "x86_64-unknown-linux-gnu": {
        "cargo": "sha256-4b5Xkw2Cfk73/RSNy0jgUv/AqIsGpKKO9EhIOqvsG2E=",
        "rust-std": "sha256-HB5wSugBJrfeNPcuooJffQFzbewgcy5aiibz3Ek5s74="
      }
    }
  }
}
```

As with the non-`matrix` [`version` context], the leaf is either the integrity
itself ("global", the same archive in all sources) or a `dict` that maps each
`source` to its integrity ("per-source").

### `output`: merging and partitioning

`output` is a template, materialized with each combination's context, that
decides the subpath *under the archive's `<VERSION>/<SOURCE>` directory* into
which that combination is extracted.

Combinations that render the *same* `output` are extracted on top of each other
and *merge* into a single tree; combinations that render *different* `output`s
*partition* the tree. In the example above, `"output": "{triple}"` merges all
the components of a triple into one usable toolchain prefix while keeping the
two triples apart.

Every rendered `output` also gets its own `filegroup` in the generated repo, so
consumers can depend on one partition instead of on the whole tree.

When `output` is not set, all combinations extract into the same directory,
i.e. everything merges.

Finally, note that a `source` is only used if *all* of its combinations
download successfully. Otherwise, the next source is tried. This keeps a
partial mirror from leaving behind a half-materialized tree.

TODO: combinations are always downloaded eagerly, all of them, even in the
per-version lazy mode of the `download_archives` module extension. Consider a
hub-and-spoke layout with one download repo per combination so that e.g. only
the triple that's actually built gets downloaded.

### Special context properties

There are two context properties that are "special": `integrity` and `sha256`.

The `sha256` property is expected to have the `SHA256` hex digest of the
archive and the `integrity` property, the [Subresource Integrity (SRI)] of the
archive. However, for convenience, the `integrity` property also accepts hex
digests.

Both are optional and mutually exclusive, only one of them should be set / used
per version and source. If not present, a warning message will be printed
asking to add it to the index. This is important because the integrity of the
archives is crucial to the safety and reproducibility of the builds.

Note that if one of these properties is present, a special "expansion" will
always add *four* special properties to the context: `integrity_algo`,
`integrity_hex_digest`, `integrity_sri` and `integrity` corresponding to the
integrity algorithm, hex digest and SRI, plus `sha256` if the SRI or hex digest
is of a `SHA256` algorithm.

## Examples

### Example 1:

```json
{
  "version": 1,
  "sources": {
    "example.com": {
      "url": "https://{source}/{version}.tgz"
    }
  },
  "versions": ["1.0"]
}
```

In this example, the `materialized` context **before** it's actually
materialized will consist of the `default` context properties (`repo_name`,
`version` and `source`) plus the `url` property from the URL `source` context:
```starlark
{
    "repo_name": <REPO>,
    "version": "1.0",
    "source": "example.com",
    "url": "https://{source}/{version}.tgz",
}
```

Thus, the final `materialized` repo context will be:
```starlark
{
    "repo_name": <REPO>,
    "version": "1.0",
    "source": "example.com",
    "url": "https://example.com/1.0.tgz",
}
```

### Example 2:

```json
{
  "version": 1,
  "urls": {
    "mirror1": {
      "domain": "example.com",
      "tag": "v{version}",
      "filename": "foobar-{tag}",
      "strip_prefix": "{filename}",
      "url": "https://{domain}/{tag}/{filename}-{sha256}.tgz"
    },
    "mirror2": {
      "url": "https://{source}.mirrors.com/{repo_name}/{version}/{sha256}.tgz"
    }
  },
  "versions": {
    "1.1": {
      "sha256": {
        "mirror1": "fcde2b2edba56bf408601fb721fe9b5c338d10ee429ea04fae5511b68fbf8fb9",
        "mirror2": "c3ab8ff13720e8ad9047dd39466b3c8974e592c2fa383d4a3960714caef0c4f2"
    },
    "1.0": {
      "sha256": "2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae"
    }
  }
}
```

In this example, the `materialized` repo contexts  **before** actually being
materialized will consist of:
```starlark

# version: 1.0, source: mirror1
{
    "repo_name": <REPO>,
    "version": "1.0",
    "source": "mirror1",

    # version context with special context properties expanded
    "integrity": "sha256-LCa0a2j/xo/5m0U8HTBBNBNCLXBkg7+g+YpeiGJm564=",
    "integrity_algo": "sha256",
    "integrity_sri": "sha256-LCa0a2j/xo/5m0U8HTBBNBNCLXBkg7+g+YpeiGJm564=",
    "integrity_hex_digest": "2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae",
    "sha256": "2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae",

    # source context
    "domain": "example.com",
    "tag": "v{version}",
    "filename": "foobar-{tag}",
    "strip_prefix": "{filename}",
    "url": "https://{domain}/{tag}/{filename}-{sha256}.tgz",
}

# version: 1.0, source: mirror2
{
    "repo_name": <REPO>,
    "version": "1.0",
    "source": "mirror2",

    # version context with special context properties expanded
    "integrity": "sha256-LCa0a2j/xo/5m0U8HTBBNBNCLXBkg7+g+YpeiGJm564=",
    "integrity_algo": "sha256",
    "integrity_sri": "sha256-LCa0a2j/xo/5m0U8HTBBNBNCLXBkg7+g+YpeiGJm564=",
    "integrity_hex_digest": "2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae",
    "sha256": "2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae",

    # source context
    "url": "https://{source}.mirrors.com/{repo_name}/{version}/{sha256}.tgz"
}

# version: 1.1, source: mirror1
{
    "repo_name": <REPO>,
    "version": "1.1",
    "source": "mirror1",

    # version context with special context properties expanded
    "integrity": "sha256-/N4rLtula/QIYB+3If6bXDONEO5CnqBPrlURto+/j7k=",
    "integrity_algo": "sha256",
    "integrity_sri": "sha256-/N4rLtula/QIYB+3If6bXDONEO5CnqBPrlURto+/j7k=",
    "integrity_hex_digest": "fcde2b2edba56bf408601fb721fe9b5c338d10ee429ea04fae5511b68fbf8fb9",
    "sha256": "fcde2b2edba56bf408601fb721fe9b5c338d10ee429ea04fae5511b68fbf8fb9",

    # source context
    "domain": "example.com",
    "tag": "v{version}",
    "filename": "foobar-{tag}",
    "strip_prefix": "{filename}",
    "url": "https://{domain}/{tag}/{filename}-{sha256}.tgz",
}

# version: 1.1, source: mirror2
{
    "repo_name": <REPO>,
    "version": "1.1",
    "source": "mirror2",

    # version context with special context properties expanded
    "integrity": "sha256-w6uP8Tcg6K2QR905Rms8iXTlksL6OD1KOWBxTK7wxPI=",
    "integrity_algo": "sha256",
    "integrity_sri": "sha256-w6uP8Tcg6K2QR905Rms8iXTlksL6OD1KOWBxTK7wxPI=",
    "integrity_hex_digest": "c3ab8ff13720e8ad9047dd39466b3c8974e592c2fa383d4a3960714caef0c4f2",
    "sha256": "c3ab8ff13720e8ad9047dd39466b3c8974e592c2fa383d4a3960714caef0c4f2",

    # source context
    "url": "https://{source}.mirrors.com/{repo_name}/{version}/{sha256}.tgz"
}
```

And the final `materialized` context for e.g. version `1.1` and `source`
`mirror1` will be:

```starlark
# version: 1.1, source: mirror1
{
    "repo_name": <REPO>,
    "version": "1.1",
    "source": "mirror1",

    # version context with special context properties expanded
    "integrity": "sha256-/N4rLtula/QIYB+3If6bXDONEO5CnqBPrlURto+/j7k=",
    "integrity_algo": "sha256",
    "integrity_sri": "sha256-/N4rLtula/QIYB+3If6bXDONEO5CnqBPrlURto+/j7k=",
    "integrity_hex_digest": "fcde2b2edba56bf408601fb721fe9b5c338d10ee429ea04fae5511b68fbf8fb9",
    "sha256": "fcde2b2edba56bf408601fb721fe9b5c338d10ee429ea04fae5511b68fbf8fb9",

    # source context
    "domain": "example.com",
    "tag": "v1.1",
    "filename": "foobar-v1.1",
    "strip_prefix": "foobar-v1.1",
    "url": "https://example.com/v1.1/foobar-v1.1-fcde2b2edba56bf408601fb721fe9b5c338d10ee429ea04fae5511b68fbf8fb9.tgz",
}
```

[`materialized` repo context]: #materialized-repo-context
[`default` context]: #default-context
[`version` context]: #version-context
[URL `source` context]: #url-source-context
[`matrix`]: #matrix
[`output`: merging and partitioning]: #output-merging-and-partitioning
[Special context properties]: #special-context-properties
[Subresource Integrity (SRI)]: https://w3c.github.io/webappsec-subresource-integrity/
�
'
download_archiveslibintegrity.bzl�(integrity.__test__._digest_base64_to_hex*�
�
(integrity.__test__._digest_base64_to_hex
digest_base64 (2?
_digest_base64_to_hex&@@download_archives//lib:integrity.bzl
&&�(integrity.__test__._digest_hex_to_base64*�
}
(integrity.__test__._digest_hex_to_base64

digest_hex (2?
_digest_hex_to_base64&@@download_archives//lib:integrity.bzl
--�integrity.is_valid*j
Z
integrity.is_valid
	integrity (23
	_is_valid&@@download_archives//lib:integrity.bzl
CC�integrity.new*�
�
integrity.new
	integrity (V
_failK<unknown object build.stack.devtools.build.constellate.StarlarkEvaluator$7>(2.
_new&@@download_archives//lib:integrity.bzl
II�	integrity\
# Subresource Integrity (SRI)

See: https://w3c.github.io/webappsec-subresource-integrity/
z�
	integrity
bb\
# Subresource Integrity (SRI)

See: https://w3c.github.io/webappsec-subresource-integrity/
"(
new
cc_new"integrity.new"7
is_valid
dd	_is_valid"integrity.is_valid",
__test__
ee"integrity.__test__*&@@download_archives//lib:integrity.bzli
//lib:base64.bzlrS
#
aspect_bazel_liblib
base64.bzl
base64base64
,2
4�
//lib:strings.bzlr�
$
aspect_bazel_liblibstrings.bzl
chrchr
-0
hexhex
47
ordord
;>
@\
# Subresource Integrity (SRI)

See: https://w3c.github.io/webappsec-subresource-integrity/
�
$
download_archiveslib
matrix.bzl�matrix.axis_valuesHValues of the first axis, i.e. the top-level keys of a `matrix` version.*�
�
matrix.axis_valuesJ
matrix<The index `matrix`, a list of `{"key": ..., "values": ...}`. (HValues of the first axis, i.e. the top-level keys of a `matrix` version."G
EThe list of values of the first axis, empty when there's no `matrix`.23
_axis_values#@@download_archives//lib:matrix.bzl
�
matrix.combos�Expand a `matrix` into its ordered list of combinations.

Each combination is a `dict` of context properties: one entry per axis
mapping the axis `key` to the selected value, plus any extra properties
that a `dict`-shaped axis attaches to that value. The extra properties are
NOT materialized here: they are templates, materialized per source
alongside the source properties so that they can reference the whole
context.
*�
�
matrix.combosJ
matrix<The index `matrix`, a list of `{"key": ..., "values": ...}`. (q
_failFail function for errors.K<unknown object build.stack.devtools.build.constellate.StarlarkEvaluator$7>(�Expand a `matrix` into its ordered list of combinations.

Each combination is a `dict` of context properties: one entry per axis
mapping the axis `key` to the selected value, plus any extra properties
that a `dict`-shaped axis attaches to that value. The extra properties are
NOT materialized here: they are templates, materialized per source
alongside the source properties so that they can reference the whole
context.
"�
�A list of `dict`s, one per combination, in matrix order (the last axis
varies fastest). Without a `matrix`, a single empty combination.2.
_combos#@@download_archives//lib:matrix.bzl
�matrix.integrity�Look up a combination's integrity by walking the `version` context.

With a `matrix` there is one archive, and thus one integrity, per
combination, so the integrities are nested by axis value, in matrix order,
e.g. `versions[<version>][<triple>][<component>]`. The leaf is either the
integrity itself ("global") or a `{source: integrity}` `dict`
("per-source").
*�
�
matrix.integrity%
versionThe `version` context. (E
source_name2The `source` name, to pick from a per-source leaf. (J
matrix<The index `matrix`, a list of `{"key": ..., "values": ...}`. (5
combo(One of the combinations of the `matrix`. (�Look up a combination's integrity by walking the `version` context.

With a `matrix` there is one archive, and thus one integrity, per
combination, so the integrities are nested by axis value, in matrix order,
e.g. `versions[<version>][<triple>][<component>]`. The leaf is either the
integrity itself ("global") or a `{source: integrity}` `dict`
("per-source").
"E
CThe integrity of the combination's archive, `None` if it's missing.21

_integrity#@@download_archives//lib:matrix.bzl
CC�matrix.pathDThe combination's axis values, joined, to name it in error messages.*�
�
matrix.path
matrix (
combo (DThe combination's axis values, joined, to name it in error messages.2,
_path#@@download_archives//lib:matrix.bzl
ee�matrixHindex `matrix`: expansion into the combinations of archives of a versionz�
matrix
iiHindex `matrix`: expansion into the combinations of archives of a version"=
axis_values
jj_axis_values"matrix.axis_values".
combos
kk_combos"matrix.combos"7
	integrity
ll
_integrity"matrix.integrity"(
path
mm_path"matrix.path*#@@download_archives//lib:matrix.bzlHindex `matrix`: expansion into the combinations of archives of a version�
$
download_archiveslib
schema.bzl� schema.__test__._expand_versions*�
z
 schema.__test__._expand_versions
versions (
sources (27
_expand_versions#@@download_archives//lib:schema.bzl
[[�schema.validate_v1*�
�
schema.validate_v1
	repo_name (
index (%
_print<built-in function print>(V
_failK<unknown object build.stack.devtools.build.constellate.StarlarkEvaluator$7>(23
_validate_v1#@@download_archives//lib:schema.bzl
���schemarepo JSON index schemaz�
schema
��repo JSON index schema"?
validate_v1
��_validate_v1"schema.validate_v1"+
__test__
��"schema.__test__*#@@download_archives//lib:schema.bzlv
//lib:integrity.bzlr]
'
download_archiveslibintegrity.bzl$
	integrity	Integrity
/8
Gj
//lib:matrix.bzlrT
$
download_archiveslib
matrix.bzl
matrixMatrix
,2
>repo JSON index schema�
#
download_archiveslib	utils.bzl�utils.dedupeBReturn the list without duplicates, keeping the first occurrences.*�
�
utils.dedupe
list_ (BReturn the list without duplicates, keeping the first occurrences.2-
_dedupe"@@download_archives//lib:utils.bzl
uutils.get_dupes*`
P
utils.get_dupes
list_ (20

_get_dupes"@@download_archives//lib:utils.bzl
�utils.matching_patchesIReturn the patch keys from `patches` that match the given version/source.*�
�
utils.matching_patches
patches (
version (
source (
spec_syntax"simple"(
version_scheme"semver"(IReturn the patch keys from `patches` that match the given version/source.27
_matching_patches"@@download_archives//lib:utils.bzl
**�utils.replace_in_place(Replace a dict key with one or more k-v.*�
�
utils.replace_in_place
d (
	k_replace (
replacement (V
_failK<unknown object build.stack.devtools.build.constellate.StarlarkEvaluator$7>((Replace a dict key with one or more k-v.27
_replace_in_place"@@download_archives//lib:utils.bzl
�utils	utils.bzlz�
utils
BB	utils.bzl"-
dedupe
CC_dedupe"utils.dedupe"6
	get_dupes
DD
_get_dupes"utils.get_dupes"K
replace_in_place
EE_replace_in_place"utils.replace_in_place"K
matching_patches
FF_matching_patches"utils.matching_patches*"@@download_archives//lib:utils.bzl`
//spec:spec.bzlrK

version_utilsspecspec.bzl
specSpec
'+
5r
//version:version.bzlrW
%
version_utilsversionversion.bzl 
versionVersion
-4
A	utils.bzl 