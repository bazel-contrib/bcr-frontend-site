�.
,
download_utilsdownload/archivedefs.bzl�-download_archive�Download an archive and extract the contents.

```py
download_archive = use_repo_rule("@download_utils//download/archive:defs.bzl", "download_archive")
download_archive(
    name = "archive",
    urls = ["https://some.thing/archive.tar"],
)
```
R�+
�
download_archive�Download an archive and extract the contents.

```py
download_archive = use_repo_rule("@download_utils//download/archive:defs.bzl", "download_archive")
download_archive(
    name = "archive",
    urls = ["https://some.thing/archive.tar"],
)
```
.
name"A unique name for this repository. �
buildzThe template for the `BUILD.bazel` file.

Receives a `{{srcs}}` substitution value for exposing the downloaded resources.
2:BUILD.tmpl.bazel�
commands�A collection of commands to run on the downloaded resources.

```py
download_archive(
    commands = {
        # Make a script executable in the unpacked archive
        "chmod": [
            "$(location @coreutils//:entrypoint)",
            "chmod",
            "u+x",
            "some-script.sh",
        ],
    },
    tools = [
        # A hermetically downloaded `coreutils` multi-call executable
        "@coreutils//:entrypoint",
    ],
)
```

It is **strongly** recommended to use hermetically provided executables in the commands.
 P
	extension=The extension of the archive when not available from the URL.2""�
	integrity�The archive subresource integrity.

Not providing an integrity will output the calculated integrity to the terminal.

It is **strongly** recommended to provide an integrity to enable reproducible downloads.

Unsecure URLs **must** have an integrity provided.
2""�
links�Creates links in the downloaded repository as `{"<target>": "<link>"}`

```py
download_archive(
    links = {
        "etc/test/fixture.txt": "fixture.txt",
    },
)
```

Depending on the platform, either symbolic or hard links are created.

2{}C
patches2Patches to apply to the repository after creation.2[]�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
srcs�Globs for source files in the unpacked repository.

Will be provided to the `build` template file as a `{{srcs}}` substitution.

The default template will expose the sources as a `:srcs` `filegroup` target.
2["**"]G
strip_prefix1A prefix to remove from each file in the archive.2""?
timeout-Seconds before a command execution is killed.2600�
tools�Labels to hermetic executable files.

The labels often point to downloaded executables.

Each tool can be resolved in the `commands` attribute via the `$(location )` helper.
2[]�
urlsuURLs to download the file.

Multiple URLs can be provided to enable downloading from mirrors in the case of failure.
 *?
download_archive+@@download_utils//download/archive:defs.bzl
''0
.
name"A unique name for this repository. �
�
buildzThe template for the `BUILD.bazel` file.

Receives a `{{srcs}}` substitution value for exposing the downloaded resources.
2:BUILD.tmpl.bazel�
�
commands�A collection of commands to run on the downloaded resources.

```py
download_archive(
    commands = {
        # Make a script executable in the unpacked archive
        "chmod": [
            "$(location @coreutils//:entrypoint)",
            "chmod",
            "u+x",
            "some-script.sh",
        ],
    },
    tools = [
        # A hermetically downloaded `coreutils` multi-call executable
        "@coreutils//:entrypoint",
    ],
)
```

It is **strongly** recommended to use hermetically provided executables in the commands.
 R
P
	extension=The extension of the archive when not available from the URL.2""�
�
	integrity�The archive subresource integrity.

Not providing an integrity will output the calculated integrity to the terminal.

It is **strongly** recommended to provide an integrity to enable reproducible downloads.

Unsecure URLs **must** have an integrity provided.
2""�
�
links�Creates links in the downloaded repository as `{"<target>": "<link>"}`

```py
download_archive(
    links = {
        "etc/test/fixture.txt": "fixture.txt",
    },
)
```

Depending on the platform, either symbolic or hard links are created.

2{}E
C
patches2Patches to apply to the repository after creation.2[]�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
�
srcs�Globs for source files in the unpacked repository.

Will be provided to the `build` template file as a `{{srcs}}` substitution.

The default template will expose the sources as a `:srcs` `filegroup` target.
2["**"]I
G
strip_prefix1A prefix to remove from each file in the archive.2""A
?
timeout-Seconds before a command execution is killed.2600�
�
tools�Labels to hermetic executable files.

The labels often point to downloaded executables.

Each tool can be resolved in the `commands` attribute via the `$(location )` helper.
2[]�
�
urlsuURLs to download the file.

Multiple URLs can be provided to enable downloading from mirrors in the case of failure.
 �
!//download/archive:repository.bzlre
2
download_utilsdownload/archiverepository.bzl!
archive_archive
:B
O�9
2
download_utilsdownload/archiverepository.bzl�implementation*q
a
implementation

rctx (2C
implementation1@@download_utils//download/archive:repository.bzl
�-archive�Download an archive and extract the contents.

```py
download_archive = use_repo_rule("@download_utils//download/archive:defs.bzl", "download_archive")
download_archive(
    name = "archive",
    urls = ["https://some.thing/archive.tar"],
)
```
R�+
�
archive�Download an archive and extract the contents.

```py
download_archive = use_repo_rule("@download_utils//download/archive:defs.bzl", "download_archive")
download_archive(
    name = "archive",
    urls = ["https://some.thing/archive.tar"],
)
```
.
name"A unique name for this repository. �
buildzThe template for the `BUILD.bazel` file.

Receives a `{{srcs}}` substitution value for exposing the downloaded resources.
2:BUILD.tmpl.bazel�
commands�A collection of commands to run on the downloaded resources.

```py
download_archive(
    commands = {
        # Make a script executable in the unpacked archive
        "chmod": [
            "$(location @coreutils//:entrypoint)",
            "chmod",
            "u+x",
            "some-script.sh",
        ],
    },
    tools = [
        # A hermetically downloaded `coreutils` multi-call executable
        "@coreutils//:entrypoint",
    ],
)
```

It is **strongly** recommended to use hermetically provided executables in the commands.
 P
	extension=The extension of the archive when not available from the URL.2""�
	integrity�The archive subresource integrity.

Not providing an integrity will output the calculated integrity to the terminal.

It is **strongly** recommended to provide an integrity to enable reproducible downloads.

Unsecure URLs **must** have an integrity provided.
2""�
links�Creates links in the downloaded repository as `{"<target>": "<link>"}`

```py
download_archive(
    links = {
        "etc/test/fixture.txt": "fixture.txt",
    },
)
```

Depending on the platform, either symbolic or hard links are created.

2{}C
patches2Patches to apply to the repository after creation.2[]�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
srcs�Globs for source files in the unpacked repository.

Will be provided to the `build` template file as a `{{srcs}}` substitution.

The default template will expose the sources as a `:srcs` `filegroup` target.
2["**"]G
strip_prefix1A prefix to remove from each file in the archive.2""?
timeout-Seconds before a command execution is killed.2600�
tools�Labels to hermetic executable files.

The labels often point to downloaded executables.

Each tool can be resolved in the `commands` attribute via the `$(location )` helper.
2[]�
urlsuURLs to download the file.

Multiple URLs can be provided to enable downloading from mirrors in the case of failure.
 *<
archive1@@download_utils//download/archive:repository.bzl
''0
.
name"A unique name for this repository. �
�
buildzThe template for the `BUILD.bazel` file.

Receives a `{{srcs}}` substitution value for exposing the downloaded resources.
2:BUILD.tmpl.bazel�
�
commands�A collection of commands to run on the downloaded resources.

```py
download_archive(
    commands = {
        # Make a script executable in the unpacked archive
        "chmod": [
            "$(location @coreutils//:entrypoint)",
            "chmod",
            "u+x",
            "some-script.sh",
        ],
    },
    tools = [
        # A hermetically downloaded `coreutils` multi-call executable
        "@coreutils//:entrypoint",
    ],
)
```

It is **strongly** recommended to use hermetically provided executables in the commands.
 R
P
	extension=The extension of the archive when not available from the URL.2""�
�
	integrity�The archive subresource integrity.

Not providing an integrity will output the calculated integrity to the terminal.

It is **strongly** recommended to provide an integrity to enable reproducible downloads.

Unsecure URLs **must** have an integrity provided.
2""�
�
links�Creates links in the downloaded repository as `{"<target>": "<link>"}`

```py
download_archive(
    links = {
        "etc/test/fixture.txt": "fixture.txt",
    },
)
```

Depending on the platform, either symbolic or hard links are created.

2{}E
C
patches2Patches to apply to the repository after creation.2[]�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
�
srcs�Globs for source files in the unpacked repository.

Will be provided to the `build` template file as a `{{srcs}}` substitution.

The default template will expose the sources as a `:srcs` `filegroup` target.
2["**"]I
G
strip_prefix1A prefix to remove from each file in the archive.2""A
?
timeout-Seconds before a command execution is killed.2600�
�
tools�Labels to hermetic executable files.

The labels often point to downloaded executables.

Each tool can be resolved in the `commands` attribute via the `$(location )` helper.
2[]�
�
urlsuURLs to download the file.

Multiple URLs can be provided to enable downloading from mirrors in the case of failure.
 �
//lib:build.bzlrm
 
download_utilslib	build.bzl
buildbuild
).
ATTRS_BUILD
17
B�
//lib:commands.bzlry
#
download_utilslibcommands.bzl"
commandscommands
,4 
ATTRS	_COMMANDS
7@
K�
//lib:download_and_extract.bzlr�
/
download_utilslibdownload_and_extract.bzl:
download_and_extractdownload_and_extract
8L,
ATTRS_DOWNLOAD_AND_EXTRACT
Od
o�
//lib:links.bzlrm
 
download_utilslib	links.bzl
linkslinks
).
ATTRS_LINKS
17
B�
//lib:patch.bzlrm
 
download_utilslib	patch.bzl
patchpatch
).
ATTRS_PATCH
17
Bk
//lib:workspace.bzlrR
$
download_utilslibworkspace.bzl
writewrite
-2
4�	DOC�Download an archive and extract the contents.

```py
download_archive = use_repo_rule("@download_utils//download/archive:defs.bzl", "download_archive")
download_archive(
    name = "archive",
    urls = ["https://some.thing/archive.tar"],
)
```
j��Download an archive and extract the contents.

```py
download_archive = use_repo_rule("@download_utils//download/archive:defs.bzl", "download_archive")
download_archive(
    name = "archive",
    urls = ["https://some.thing/archive.tar"],
)
```
�0
(
download_utilsdownload/debdefs.bzl�/download_deb�Downloads an unpacks the nested data from a Debian package.

To download and unpack the Debian package, use `download_archive`.  This would provide access to the control information for the package.

```py
download_deb = use_repo_rule("@download_utils//download/deb:defs.bzl", "download_deb")
download_deb(
    name = "deb",
    integrity = "sha256-vMiq8kFBwoSrVEE+Tcs08RvaiNp6MsboWlXS7p1clO0=",
    urls = ["https://some.thing/test_1.0-1_all.deb"],
)
```
R�+
�
download_deb�Downloads an unpacks the nested data from a Debian package.

To download and unpack the Debian package, use `download_archive`.  This would provide access to the control information for the package.

```py
download_deb = use_repo_rule("@download_utils//download/deb:defs.bzl", "download_deb")
download_deb(
    name = "deb",
    integrity = "sha256-vMiq8kFBwoSrVEE+Tcs08RvaiNp6MsboWlXS7p1clO0=",
    urls = ["https://some.thing/test_1.0-1_all.deb"],
)
```
.
name"A unique name for this repository. �
buildzThe template for the `BUILD.bazel` file.

Receives a `{{srcs}}` substitution value for exposing the downloaded resources.
2:BUILD.tmpl.bazel�
commands�A collection of commands to run on the downloaded resources.

```py
download_archive(
    commands = {
        # Make a script executable in the unpacked archive
        "chmod": [
            "$(location @coreutils//:entrypoint)",
            "chmod",
            "u+x",
            "some-script.sh",
        ],
    },
    tools = [
        # A hermetically downloaded `coreutils` multi-call executable
        "@coreutils//:entrypoint",
    ],
)
```

It is **strongly** recommended to use hermetically provided executables in the commands.
 �
	integrity�The archive subresource integrity.

Not providing an integrity will output the calculated integrity to the terminal.

It is **strongly** recommended to provide an integrity to enable reproducible downloads.

Unsecure URLs **must** have an integrity provided.
2""�
links�Creates links in the downloaded repository as `{"<target>": "<link>"}`

```py
download_archive(
    links = {
        "etc/test/fixture.txt": "fixture.txt",
    },
)
```

Depending on the platform, either symbolic or hard links are created.

2{}C
patches2Patches to apply to the repository after creation.2[]�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
srcs�Globs for source files in the unpacked repository.

Will be provided to the `build` template file as a `{{srcs}}` substitution.

The default template will expose the sources as a `:srcs` `filegroup` target.
2["**"]G
strip_prefix1A prefix to remove from each file in the archive.2""?
timeout-Seconds before a command execution is killed.2600�
tools�Labels to hermetic executable files.

The labels often point to downloaded executables.

Each tool can be resolved in the `commands` attribute via the `$(location )` helper.
2[]�
urlsuURLs to download the file.

Multiple URLs can be provided to enable downloading from mirrors in the case of failure.
 *7
download_deb'@@download_utils//download/deb:defs.bzl
%%0
.
name"A unique name for this repository. �
�
buildzThe template for the `BUILD.bazel` file.

Receives a `{{srcs}}` substitution value for exposing the downloaded resources.
2:BUILD.tmpl.bazel�
�
commands�A collection of commands to run on the downloaded resources.

```py
download_archive(
    commands = {
        # Make a script executable in the unpacked archive
        "chmod": [
            "$(location @coreutils//:entrypoint)",
            "chmod",
            "u+x",
            "some-script.sh",
        ],
    },
    tools = [
        # A hermetically downloaded `coreutils` multi-call executable
        "@coreutils//:entrypoint",
    ],
)
```

It is **strongly** recommended to use hermetically provided executables in the commands.
 �
�
	integrity�The archive subresource integrity.

Not providing an integrity will output the calculated integrity to the terminal.

It is **strongly** recommended to provide an integrity to enable reproducible downloads.

Unsecure URLs **must** have an integrity provided.
2""�
�
links�Creates links in the downloaded repository as `{"<target>": "<link>"}`

```py
download_archive(
    links = {
        "etc/test/fixture.txt": "fixture.txt",
    },
)
```

Depending on the platform, either symbolic or hard links are created.

2{}E
C
patches2Patches to apply to the repository after creation.2[]�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
�
srcs�Globs for source files in the unpacked repository.

Will be provided to the `build` template file as a `{{srcs}}` substitution.

The default template will expose the sources as a `:srcs` `filegroup` target.
2["**"]I
G
strip_prefix1A prefix to remove from each file in the archive.2""A
?
timeout-Seconds before a command execution is killed.2600�
�
tools�Labels to hermetic executable files.

The labels often point to downloaded executables.

Each tool can be resolved in the `commands` attribute via the `$(location )` helper.
2[]�
�
urlsuURLs to download the file.

Multiple URLs can be provided to enable downloading from mirrors in the case of failure.
 |
//download/deb:repository.bzlrY
.
download_utilsdownload/debrepository.bzl
deb_deb
6:
C�>
.
download_utilsdownload/debrepository.bzl�implementation*m
]
implementation

rctx (2?
implementation-@@download_utils//download/deb:repository.bzl
�/deb�Downloads an unpacks the nested data from a Debian package.

To download and unpack the Debian package, use `download_archive`.  This would provide access to the control information for the package.

```py
download_deb = use_repo_rule("@download_utils//download/deb:defs.bzl", "download_deb")
download_deb(
    name = "deb",
    integrity = "sha256-vMiq8kFBwoSrVEE+Tcs08RvaiNp6MsboWlXS7p1clO0=",
    urls = ["https://some.thing/test_1.0-1_all.deb"],
)
```
R�+
�
deb�Downloads an unpacks the nested data from a Debian package.

To download and unpack the Debian package, use `download_archive`.  This would provide access to the control information for the package.

```py
download_deb = use_repo_rule("@download_utils//download/deb:defs.bzl", "download_deb")
download_deb(
    name = "deb",
    integrity = "sha256-vMiq8kFBwoSrVEE+Tcs08RvaiNp6MsboWlXS7p1clO0=",
    urls = ["https://some.thing/test_1.0-1_all.deb"],
)
```
.
name"A unique name for this repository. �
buildzThe template for the `BUILD.bazel` file.

Receives a `{{srcs}}` substitution value for exposing the downloaded resources.
2:BUILD.tmpl.bazel�
commands�A collection of commands to run on the downloaded resources.

```py
download_archive(
    commands = {
        # Make a script executable in the unpacked archive
        "chmod": [
            "$(location @coreutils//:entrypoint)",
            "chmod",
            "u+x",
            "some-script.sh",
        ],
    },
    tools = [
        # A hermetically downloaded `coreutils` multi-call executable
        "@coreutils//:entrypoint",
    ],
)
```

It is **strongly** recommended to use hermetically provided executables in the commands.
 �
	integrity�The archive subresource integrity.

Not providing an integrity will output the calculated integrity to the terminal.

It is **strongly** recommended to provide an integrity to enable reproducible downloads.

Unsecure URLs **must** have an integrity provided.
2""�
links�Creates links in the downloaded repository as `{"<target>": "<link>"}`

```py
download_archive(
    links = {
        "etc/test/fixture.txt": "fixture.txt",
    },
)
```

Depending on the platform, either symbolic or hard links are created.

2{}C
patches2Patches to apply to the repository after creation.2[]�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
srcs�Globs for source files in the unpacked repository.

Will be provided to the `build` template file as a `{{srcs}}` substitution.

The default template will expose the sources as a `:srcs` `filegroup` target.
2["**"]G
strip_prefix1A prefix to remove from each file in the archive.2""?
timeout-Seconds before a command execution is killed.2600�
tools�Labels to hermetic executable files.

The labels often point to downloaded executables.

Each tool can be resolved in the `commands` attribute via the `$(location )` helper.
2[]�
urlsuURLs to download the file.

Multiple URLs can be provided to enable downloading from mirrors in the case of failure.
 *4
deb-@@download_utils//download/deb:repository.bzl
%%0
.
name"A unique name for this repository. �
�
buildzThe template for the `BUILD.bazel` file.

Receives a `{{srcs}}` substitution value for exposing the downloaded resources.
2:BUILD.tmpl.bazel�
�
commands�A collection of commands to run on the downloaded resources.

```py
download_archive(
    commands = {
        # Make a script executable in the unpacked archive
        "chmod": [
            "$(location @coreutils//:entrypoint)",
            "chmod",
            "u+x",
            "some-script.sh",
        ],
    },
    tools = [
        # A hermetically downloaded `coreutils` multi-call executable
        "@coreutils//:entrypoint",
    ],
)
```

It is **strongly** recommended to use hermetically provided executables in the commands.
 �
�
	integrity�The archive subresource integrity.

Not providing an integrity will output the calculated integrity to the terminal.

It is **strongly** recommended to provide an integrity to enable reproducible downloads.

Unsecure URLs **must** have an integrity provided.
2""�
�
links�Creates links in the downloaded repository as `{"<target>": "<link>"}`

```py
download_archive(
    links = {
        "etc/test/fixture.txt": "fixture.txt",
    },
)
```

Depending on the platform, either symbolic or hard links are created.

2{}E
C
patches2Patches to apply to the repository after creation.2[]�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
�
srcs�Globs for source files in the unpacked repository.

Will be provided to the `build` template file as a `{{srcs}}` substitution.

The default template will expose the sources as a `:srcs` `filegroup` target.
2["**"]I
G
strip_prefix1A prefix to remove from each file in the archive.2""A
?
timeout-Seconds before a command execution is killed.2600�
�
tools�Labels to hermetic executable files.

The labels often point to downloaded executables.

Each tool can be resolved in the `commands` attribute via the `$(location )` helper.
2[]�
�
urlsuURLs to download the file.

Multiple URLs can be provided to enable downloading from mirrors in the case of failure.
 �
//lib:build.bzlrm
 
download_utilslib	build.bzl
buildbuild
).
ATTRS_BUILD
17
B�
//lib:commands.bzlry
#
download_utilslibcommands.bzl"
commandscommands
,4 
ATTRS	_COMMANDS
7@
K�
//lib:download_and_extract.bzlr�
/
download_utilslibdownload_and_extract.bzl:
download_and_extractdownload_and_extract
8L,
ATTRS_DOWNLOAD_AND_EXTRACT
Od
o�
//lib:links.bzlrm
 
download_utilslib	links.bzl
linkslinks
).
ATTRS_LINKS
17
B�
//lib:patch.bzlrm
 
download_utilslib	patch.bzl
patchpatch
).
ATTRS_PATCH
17
Bk
//lib:workspace.bzlrR
$
download_utilslibworkspace.bzl
writewrite
-2
4�	DOC�Downloads an unpacks the nested data from a Debian package.

To download and unpack the Debian package, use `download_archive`.  This would provide access to the control information for the package.

```py
download_deb = use_repo_rule("@download_utils//download/deb:defs.bzl", "download_deb")
download_deb(
    name = "deb",
    integrity = "sha256-vMiq8kFBwoSrVEE+Tcs08RvaiNp6MsboWlXS7p1clO0=",
    urls = ["https://some.thing/test_1.0-1_all.deb"],
)
```
j��Downloads an unpacks the nested data from a Debian package.

To download and unpack the Debian package, use `download_archive`.  This would provide access to the control information for the package.

```py
download_deb = use_repo_rule("@download_utils//download/deb:defs.bzl", "download_deb")
download_deb(
    name = "deb",
    integrity = "sha256-vMiq8kFBwoSrVEE+Tcs08RvaiNp6MsboWlXS7p1clO0=",
    urls = ["https://some.thing/test_1.0-1_all.deb"],
)
```
�$
)
download_utilsdownload/filedefs.bzl�#download_file�Download a single file.

```py
download_file = use_repo_rule("@download_utils//download/file:defs.bzl", "download_file")
download_file(
    name = "file",
    output = "executable",
    executable = True,
    urls = ["https://some.thing/executable-amd64-linux"],
)
```
R�!
�
download_file�Download a single file.

```py
download_file = use_repo_rule("@download_utils//download/file:defs.bzl", "download_file")
download_file(
    name = "file",
    output = "executable",
    executable = True,
    urls = ["https://some.thing/executable-amd64-linux"],
)
```
.
name"A unique name for this repository. F
build(The template for the `BUILD.bazel` file.2:BUILD.tmpl.bazel�
commands�A collection of commands to run on the downloaded resources.

```py
download_archive(
    commands = {
        # Make a script executable in the unpacked archive
        "chmod": [
            "$(location @coreutils//:entrypoint)",
            "chmod",
            "u+x",
            "some-script.sh",
        ],
    },
    tools = [
        # A hermetically downloaded `coreutils` multi-call executable
        "@coreutils//:entrypoint",
    ],
)
```

It is **strongly** recommended to use hermetically provided executables in the commands.
 >

executable'Mark the downloaded file as executable.2False5
	integrity"The archive subresource integrity.2""�
links�Creates links in the downloaded repository as `{"<target>": "<link>"}`

```py
download_archive(
    links = {
        "etc/test/fixture.txt": "fixture.txt",
    },
)
```

Depending on the platform, either symbolic or hard links are created.

2{}9
output+The output filename for the downloaded file C
patches2Patches to apply to the repository after creation.2[]�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 ?
timeout-Seconds before a command execution is killed.2600�
tools�Labels to hermetic executable files.

The labels often point to downloaded executables.

Each tool can be resolved in the `commands` attribute via the `$(location )` helper.
2[]&
urlsURLs to download the file. *9
download_file(@@download_utils//download/file:defs.bzl
))0
.
name"A unique name for this repository. H
F
build(The template for the `BUILD.bazel` file.2:BUILD.tmpl.bazel�
�
commands�A collection of commands to run on the downloaded resources.

```py
download_archive(
    commands = {
        # Make a script executable in the unpacked archive
        "chmod": [
            "$(location @coreutils//:entrypoint)",
            "chmod",
            "u+x",
            "some-script.sh",
        ],
    },
    tools = [
        # A hermetically downloaded `coreutils` multi-call executable
        "@coreutils//:entrypoint",
    ],
)
```

It is **strongly** recommended to use hermetically provided executables in the commands.
 @
>

executable'Mark the downloaded file as executable.2False7
5
	integrity"The archive subresource integrity.2""�
�
links�Creates links in the downloaded repository as `{"<target>": "<link>"}`

```py
download_archive(
    links = {
        "etc/test/fixture.txt": "fixture.txt",
    },
)
```

Depending on the platform, either symbolic or hard links are created.

2{};
9
output+The output filename for the downloaded file E
C
patches2Patches to apply to the repository after creation.2[]�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 A
?
timeout-Seconds before a command execution is killed.2600�
�
tools�Labels to hermetic executable files.

The labels often point to downloaded executables.

Each tool can be resolved in the `commands` attribute via the `$(location )` helper.
2[](
&
urlsURLs to download the file. �
//download/file:repository.bzlr\
/
download_utilsdownload/filerepository.bzl
file_file
7<
F�/
/
download_utilsdownload/filerepository.bzl�implementation*n
^
implementation

rctx (2@
implementation.@@download_utils//download/file:repository.bzl
�#file�Download a single file.

```py
download_file = use_repo_rule("@download_utils//download/file:defs.bzl", "download_file")
download_file(
    name = "file",
    output = "executable",
    executable = True,
    urls = ["https://some.thing/executable-amd64-linux"],
)
```
R� 
�
file�Download a single file.

```py
download_file = use_repo_rule("@download_utils//download/file:defs.bzl", "download_file")
download_file(
    name = "file",
    output = "executable",
    executable = True,
    urls = ["https://some.thing/executable-amd64-linux"],
)
```
.
name"A unique name for this repository. F
build(The template for the `BUILD.bazel` file.2:BUILD.tmpl.bazel�
commands�A collection of commands to run on the downloaded resources.

```py
download_archive(
    commands = {
        # Make a script executable in the unpacked archive
        "chmod": [
            "$(location @coreutils//:entrypoint)",
            "chmod",
            "u+x",
            "some-script.sh",
        ],
    },
    tools = [
        # A hermetically downloaded `coreutils` multi-call executable
        "@coreutils//:entrypoint",
    ],
)
```

It is **strongly** recommended to use hermetically provided executables in the commands.
 >

executable'Mark the downloaded file as executable.2False5
	integrity"The archive subresource integrity.2""�
links�Creates links in the downloaded repository as `{"<target>": "<link>"}`

```py
download_archive(
    links = {
        "etc/test/fixture.txt": "fixture.txt",
    },
)
```

Depending on the platform, either symbolic or hard links are created.

2{}9
output+The output filename for the downloaded file C
patches2Patches to apply to the repository after creation.2[]�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 ?
timeout-Seconds before a command execution is killed.2600�
tools�Labels to hermetic executable files.

The labels often point to downloaded executables.

Each tool can be resolved in the `commands` attribute via the `$(location )` helper.
2[]&
urlsURLs to download the file. *6
file.@@download_utils//download/file:repository.bzl
))0
.
name"A unique name for this repository. H
F
build(The template for the `BUILD.bazel` file.2:BUILD.tmpl.bazel�
�
commands�A collection of commands to run on the downloaded resources.

```py
download_archive(
    commands = {
        # Make a script executable in the unpacked archive
        "chmod": [
            "$(location @coreutils//:entrypoint)",
            "chmod",
            "u+x",
            "some-script.sh",
        ],
    },
    tools = [
        # A hermetically downloaded `coreutils` multi-call executable
        "@coreutils//:entrypoint",
    ],
)
```

It is **strongly** recommended to use hermetically provided executables in the commands.
 @
>

executable'Mark the downloaded file as executable.2False7
5
	integrity"The archive subresource integrity.2""�
�
links�Creates links in the downloaded repository as `{"<target>": "<link>"}`

```py
download_archive(
    links = {
        "etc/test/fixture.txt": "fixture.txt",
    },
)
```

Depending on the platform, either symbolic or hard links are created.

2{};
9
output+The output filename for the downloaded file E
C
patches2Patches to apply to the repository after creation.2[]�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 A
?
timeout-Seconds before a command execution is killed.2600�
�
tools�Labels to hermetic executable files.

The labels often point to downloaded executables.

Each tool can be resolved in the `commands` attribute via the `$(location )` helper.
2[](
&
urlsURLs to download the file. �
//lib:build.bzlrm
 
download_utilslib	build.bzl
buildbuild
).
ATTRS_BUILD
17
B�
//lib:commands.bzlry
#
download_utilslibcommands.bzl"
commandscommands
,4 
ATTRS	_COMMANDS
7@
K�
//lib:download.bzlry
#
download_utilslibdownload.bzl"
downloaddownload
,4 
ATTRS	_DOWNLOAD
7@
K�
//lib:links.bzlrm
 
download_utilslib	links.bzl
linkslinks
).
ATTRS_LINKS
17
B�
//lib:patch.bzlrm
 
download_utilslib	patch.bzl
patchpatch
).
ATTRS_PATCH
17
Bk
//lib:workspace.bzlrR
$
download_utilslibworkspace.bzl
writewrite
-2
4�	DOC�Download a single file.

```py
download_file = use_repo_rule("@download_utils//download/file:defs.bzl", "download_file")
download_file(
    name = "file",
    output = "executable",
    executable = True,
    urls = ["https://some.thing/executable-amd64-linux"],
)
```
j��Download a single file.

```py
download_file = use_repo_rule("@download_utils//download/file:defs.bzl", "download_file")
download_file(
    name = "file",
    output = "executable",
    executable = True,
    urls = ["https://some.thing/executable-amd64-linux"],
)
```
�1
0
download_utilsdownload/templatearchive.bzl�implementation*�
w
implementation	
ctx (
attrs (

data (2A
implementation/@@download_utils//download/template:archive.bzl
XX�
!//download/archive:repository.bzlr�
2
download_utilsdownload/archiverepository.bzl
ATTRS_ARCHIVE
:B
archive_rule
NS
`�
"//download/template:repository.bzlr�
3
download_utilsdownload/templaterepository.bzl
ATTRS_ATTRS
;A/
implementation_implementation
M\
p�,	DOC�Download and extract archives using templated attributes.

Use this tag with the `download_template` module extension to materialize one or more external repositories by expanding attribute templates with substitutions (e.g., `versions` and `triplets`). Each expanded instance produces a repository that can be referenced via `use_repo`.

# Concepts

- Attribute templating: Fields like `name`, `urls`, and `strip_prefix` can contain `{variables}`.
- Triplets: Each `triplet` (e.g., `amd64-linux-gnu`) is split into `{cpu}`, `{os}`, and `{libc}` for reuse.
- Substitutions: Provide your own key/value mappings, which may reference other substitutions.
- Built-ins: `download_utils` adds helpful variables such as `{rust.archive.basename}`.
- Lock workflow: `bazel mod tidy` creates a lock file with resolved URLs; integrities are added via a helper command.

# Examples

## Archive downloads expanded by `version` and `triplet`

```python
download = use_extension("@download_utils//download/template:defs.bzl", "download_template")

download.archive(
    name = "coreutils-{version}-{triplet}",
    srcs = ["entrypoint"],
    links = {
        "coreutils{executable.extension}": "entrypoint",
    },
    lock = "//coreutils:lock.json",
    strip_prefix = "coreutils-{version}-{rust.triplet}",
    substitutions = {
        "version": ["0.1.0"],
        "triplets": [
            "arm64-linux-gnu",
            "amd64-linux-gnu",
            "arm64-linux-musl",
            "amd64-linux-musl",
            "amd64-windows-msvc",
            "arm64-macos-darwin",
            "amd64-macos-darwin",
        ],
    },
    urls = [
        "https://github.com/uutils/coreutils/releases/download/{version}/coreutils-{version}-{rust.archive.basename}",
    ],
)

use_repo(
    download,
    "coreutils-0.1.0-amd64-linux-gnu",
    "coreutils-0.1.0-amd64-linux-musl",
    "coreutils-0.1.0-amd64-macos-darwin",
    "coreutils-0.1.0-amd64-windows-msvc",
    "coreutils-0.1.0-arm64-linux-gnu",
    "coreutils-0.1.0-arm64-linux-musl",
    "coreutils-0.1.0-arm64-macos-darwin",
)
```

## Lock and integrity workflow

- Generate or update the lock (URLs are resolved; integrities are initially blank):
  - Run: `bazel mod tidy`
- Populate integrities from downloaded artifacts:
```console
$ bazel run @download_utils//download/template/lock coreutils/lock.json
```
- Alternatively, fill integrities from upstream checksum files.

## Mirroring uploads

- Provide an upload destination and mirror binaries, then run:
```console
$ bazel run @download_utils//download/template/lock:upload coreutils/lock.json
```

# Notes
- The `lock` attribute tracks the expanded URLs and integrities for reproducible downloads.
- Built-in substitutions are defined in `@download_utils//:MODULE.bazel` via `download.substitutions` calls.
- You can add more substitutions in your own modules.
j��Download and extract archives using templated attributes.

Use this tag with the `download_template` module extension to materialize one or more external repositories by expanding attribute templates with substitutions (e.g., `versions` and `triplets`). Each expanded instance produces a repository that can be referenced via `use_repo`.

# Concepts

- Attribute templating: Fields like `name`, `urls`, and `strip_prefix` can contain `{variables}`.
- Triplets: Each `triplet` (e.g., `amd64-linux-gnu`) is split into `{cpu}`, `{os}`, and `{libc}` for reuse.
- Substitutions: Provide your own key/value mappings, which may reference other substitutions.
- Built-ins: `download_utils` adds helpful variables such as `{rust.archive.basename}`.
- Lock workflow: `bazel mod tidy` creates a lock file with resolved URLs; integrities are added via a helper command.

# Examples

## Archive downloads expanded by `version` and `triplet`

```python
download = use_extension("@download_utils//download/template:defs.bzl", "download_template")

download.archive(
    name = "coreutils-{version}-{triplet}",
    srcs = ["entrypoint"],
    links = {
        "coreutils{executable.extension}": "entrypoint",
    },
    lock = "//coreutils:lock.json",
    strip_prefix = "coreutils-{version}-{rust.triplet}",
    substitutions = {
        "version": ["0.1.0"],
        "triplets": [
            "arm64-linux-gnu",
            "amd64-linux-gnu",
            "arm64-linux-musl",
            "amd64-linux-musl",
            "amd64-windows-msvc",
            "arm64-macos-darwin",
            "amd64-macos-darwin",
        ],
    },
    urls = [
        "https://github.com/uutils/coreutils/releases/download/{version}/coreutils-{version}-{rust.archive.basename}",
    ],
)

use_repo(
    download,
    "coreutils-0.1.0-amd64-linux-gnu",
    "coreutils-0.1.0-amd64-linux-musl",
    "coreutils-0.1.0-amd64-macos-darwin",
    "coreutils-0.1.0-amd64-windows-msvc",
    "coreutils-0.1.0-arm64-linux-gnu",
    "coreutils-0.1.0-arm64-linux-musl",
    "coreutils-0.1.0-arm64-macos-darwin",
)
```

## Lock and integrity workflow

- Generate or update the lock (URLs are resolved; integrities are initially blank):
  - Run: `bazel mod tidy`
- Populate integrities from downloaded artifacts:
```console
$ bazel run @download_utils//download/template/lock coreutils/lock.json
```
- Alternatively, fill integrities from upstream checksum files.

## Mirroring uploads

- Provide an upload destination and mirror binaries, then run:
```console
$ bazel run @download_utils//download/template/lock:upload coreutils/lock.json
```

# Notes
- The `lock` attribute tracks the expanded URLs and integrities for reproducible downloads.
- Built-in substitutions are defined in `@download_utils//:MODULE.bazel` via `download.substitutions` calls.
- You can add more substitutions in your own modules.
�-
,
download_utilsdownload/templatedeb.bzl�implementation*�
s
implementation	
ctx (
attrs (

data (2=
implementation+@@download_utils//download/template:deb.bzl
KK�
//download/deb:repository.bzlrw
.
download_utilsdownload/debrepository.bzl
ATTRS_DEB
6:
deb_rule
FK
T�
"//download/template:repository.bzlr�
3
download_utilsdownload/templaterepository.bzl
ATTRS_ATTRS
;A/
implementation_implementation
M\
p�)	DOC�Download and extract Debian packages using templated attributes.

Use this tag with the `download_template` module extension to expand attribute templates (for example, versions and triplets) and materialize one or more external repositories from .deb files. Each expansion produces a repository that you can reference via `use_repo`.

# Concepts

- Attribute templating: Fields like `name`, `urls`, and `strip_prefix` can contain `{variables}`.
- Triplets: Each `triplet` (for example, `amd64-linux-gnu`) is split into `{cpu}`, `{os}`, and `{libc}`.
- Substitutions: Provide your own key/value mappings; values may reference other substitutions.
- Built-ins: `download_utils` provides helpful variables such as `{rust.archive.basename}`.
- Data archive: This tag extracts the payload from the .deb (the `data.tar.*` archive).

# Examples

## Debian package expanded by version and triplet

```python
download = use_extension("@download_utils//download/template:defs.bzl", "download_template")
download.deb(
    name = "busybox-{version}-{cpu}-{os}",
    srcs = ["busybox"],
    links = {"busybox": "entrypoint"},
    lock = "//busybox:lock.json",
    strip_prefix = "usr/bin",
    substitutions = {
        "version": ["1.36.1"],
        "revision": ["6"],
        "triplet": [
            "arm64-linux-gnu",
            "amd64-linux-gnu",
        ],
    },
    uploads = [
        "https://gitlab.arm.com/api/v4/projects/bazel%2Fdownload_utils/packages/generic/busybox-static/{version}/busybox-static_{version}-{revision}_{cpu}.deb",
    ],
    urls = [
        "https://gitlab.arm.com/api/v4/projects/bazel%2Fdownload_utils/packages/generic/busybox-static/{version}/busybox-static_{version}-{revision}_{cpu}.deb",
        "https://snapshot-cloudflare.debian.org/archive/debian/20240210T223313Z/pool/main/b/busybox/busybox-static_{version}-{revision}_{cpu}.deb",
    ],
)
```

## Lock and integrity workflow

- Generate or update the lock (URLs resolved; integrities initially blank):
  - Run: `bazel mod tidy`
- Populate integrities from downloaded artifacts:
```console
$ bazel run @download_utils//download/template/lock busybox/lock.json
```
- Alternatively, fill integrities from upstream checksum files.

## Mirroring uploads

- Provide an upload destination and mirror binaries, then run:
```console
$ bazel run @download_utils//download/template/lock:upload busybox/lock.json
```

# Notes

- Built-in substitutions are defined in `@download_utils//:MODULE.bazel` via `download.substitutions`.
- You can add more substitutions in your own modules.
- This tag extracts only the data archive inside the .deb (`data.tar.*`).
j��Download and extract Debian packages using templated attributes.

Use this tag with the `download_template` module extension to expand attribute templates (for example, versions and triplets) and materialize one or more external repositories from .deb files. Each expansion produces a repository that you can reference via `use_repo`.

# Concepts

- Attribute templating: Fields like `name`, `urls`, and `strip_prefix` can contain `{variables}`.
- Triplets: Each `triplet` (for example, `amd64-linux-gnu`) is split into `{cpu}`, `{os}`, and `{libc}`.
- Substitutions: Provide your own key/value mappings; values may reference other substitutions.
- Built-ins: `download_utils` provides helpful variables such as `{rust.archive.basename}`.
- Data archive: This tag extracts the payload from the .deb (the `data.tar.*` archive).

# Examples

## Debian package expanded by version and triplet

```python
download = use_extension("@download_utils//download/template:defs.bzl", "download_template")
download.deb(
    name = "busybox-{version}-{cpu}-{os}",
    srcs = ["busybox"],
    links = {"busybox": "entrypoint"},
    lock = "//busybox:lock.json",
    strip_prefix = "usr/bin",
    substitutions = {
        "version": ["1.36.1"],
        "revision": ["6"],
        "triplet": [
            "arm64-linux-gnu",
            "amd64-linux-gnu",
        ],
    },
    uploads = [
        "https://gitlab.arm.com/api/v4/projects/bazel%2Fdownload_utils/packages/generic/busybox-static/{version}/busybox-static_{version}-{revision}_{cpu}.deb",
    ],
    urls = [
        "https://gitlab.arm.com/api/v4/projects/bazel%2Fdownload_utils/packages/generic/busybox-static/{version}/busybox-static_{version}-{revision}_{cpu}.deb",
        "https://snapshot-cloudflare.debian.org/archive/debian/20240210T223313Z/pool/main/b/busybox/busybox-static_{version}-{revision}_{cpu}.deb",
    ],
)
```

## Lock and integrity workflow

- Generate or update the lock (URLs resolved; integrities initially blank):
  - Run: `bazel mod tidy`
- Populate integrities from downloaded artifacts:
```console
$ bazel run @download_utils//download/template/lock busybox/lock.json
```
- Alternatively, fill integrities from upstream checksum files.

## Mirroring uploads

- Provide an upload destination and mirror binaries, then run:
```console
$ bazel run @download_utils//download/template/lock:upload busybox/lock.json
```

# Notes

- Built-in substitutions are defined in `@download_utils//:MODULE.bazel` via `download.substitutions`.
- You can add more substitutions in your own modules.
- This tag extracts only the data archive inside the .deb (`data.tar.*`).
��
-
download_utilsdownload/templatedefs.bzl��download_template�Templated downloads module extension for archives, single files, and Debian packages.

# Overview

- Use this module extension via `use_extension` to declare templated downloads.
- Tags:
  - `archive`, `file`, `deb`: define artifacts to fetch.
  - `substitution`, `substitutions`: provide values for template variables.
- Attribute templating: fields like `name`, `urls`, and `strip_prefix` can contain `{variables}`.
- Triplets: a `triplet` like `amd64-linux-gnu` is split into `{cpu}`, `{os}`, and `{libc}`.
- Built-ins: `download_utils` provides helpful variables such as `{rust.archive.basename}`.

# Example

```python
download = use_extension("@download_utils//download/template:defs.bzl", "download_template")

# Provide substitutions from JSON files
download.substitutions(
    srcs = ["//download/template:rust.cpu.json"],
)

# Provide a direct substitution
download.substitution(
    key = "version",
    match = "//conditions:default",
    select = {"//conditions:default": "1.2.3"},
)

# Define an archive download expanded by triplet
download.archive(
    name = "pkg-{version}-{triplet}",
    lock = "//pkg:lock.json",
    strip_prefix = "pkg-{version}",
    substitutions = {
        "triplet": ["amd64-linux-gnu", "arm64-linux-gnu"],
    },
    urls = [
        "https://example.com/pkg-{version}-{rust.archive.basename}",
    ],
)

# Make the generated repositories available
use_repo(
    download,
    "pkg-1.2.3-amd64-linux-gnu",
    "pkg-1.2.3-arm64-linux-gnu",
)
```

# Lock and integrity workflow

- Generate or update the lock (URLs resolved; integrities initially blank):
  - Run: `bazel mod tidy`
- Populate integrities from downloaded artifacts:
  - Run: `bazel run @download_utils//download/template/lock <path/to/lock.json>`
- Optionally mirror binaries:
  - Run: `bazel run @download_utils//download/template/lock:upload <path/to/lock.json>`

# Notes

- Built-in substitutions are defined in `@download_utils//:MODULE.bazel` via `download.substitutions`.
- You can add more substitutions in your own modules with the `substitution` and `substitutions` tags.
- For post-processing commands in repository rules, prefer hermetic tools referenced via `$(location ...)`.
J��
ٝ
download_template�Templated downloads module extension for archives, single files, and Debian packages.

# Overview

- Use this module extension via `use_extension` to declare templated downloads.
- Tags:
  - `archive`, `file`, `deb`: define artifacts to fetch.
  - `substitution`, `substitutions`: provide values for template variables.
- Attribute templating: fields like `name`, `urls`, and `strip_prefix` can contain `{variables}`.
- Triplets: a `triplet` like `amd64-linux-gnu` is split into `{cpu}`, `{os}`, and `{libc}`.
- Built-ins: `download_utils` provides helpful variables such as `{rust.archive.basename}`.

# Example

```python
download = use_extension("@download_utils//download/template:defs.bzl", "download_template")

# Provide substitutions from JSON files
download.substitutions(
    srcs = ["//download/template:rust.cpu.json"],
)

# Provide a direct substitution
download.substitution(
    key = "version",
    match = "//conditions:default",
    select = {"//conditions:default": "1.2.3"},
)

# Define an archive download expanded by triplet
download.archive(
    name = "pkg-{version}-{triplet}",
    lock = "//pkg:lock.json",
    strip_prefix = "pkg-{version}",
    substitutions = {
        "triplet": ["amd64-linux-gnu", "arm64-linux-gnu"],
    },
    urls = [
        "https://example.com/pkg-{version}-{rust.archive.basename}",
    ],
)

# Make the generated repositories available
use_repo(
    download,
    "pkg-1.2.3-amd64-linux-gnu",
    "pkg-1.2.3-arm64-linux-gnu",
)
```

# Lock and integrity workflow

- Generate or update the lock (URLs resolved; integrities initially blank):
  - Run: `bazel mod tidy`
- Populate integrities from downloaded artifacts:
  - Run: `bazel run @download_utils//download/template/lock <path/to/lock.json>`
- Optionally mirror binaries:
  - Run: `bazel run @download_utils//download/template/lock:upload <path/to/lock.json>`

# Notes

- Built-in substitutions are defined in `@download_utils//:MODULE.bazel` via `download.substitutions`.
- You can add more substitutions in your own modules with the `substitution` and `substitutions` tags.
- For post-processing commands in repository rules, prefer hermetic tools referenced via `$(location ...)`.
�*
archive�Download and extract archives using templated attributes.

Use this tag with the `download_template` module extension to materialize one or more external repositories by expanding attribute templates with substitutions (e.g., `versions` and `triplets`). Each expanded instance produces a repository that can be referenced via `use_repo`.

# Concepts

- Attribute templating: Fields like `name`, `urls`, and `strip_prefix` can contain `{variables}`.
- Triplets: Each `triplet` (e.g., `amd64-linux-gnu`) is split into `{cpu}`, `{os}`, and `{libc}` for reuse.
- Substitutions: Provide your own key/value mappings, which may reference other substitutions.
- Built-ins: `download_utils` adds helpful variables such as `{rust.archive.basename}`.
- Lock workflow: `bazel mod tidy` creates a lock file with resolved URLs; integrities are added via a helper command.

# Examples

## Archive downloads expanded by `version` and `triplet`

```python
download = use_extension("@download_utils//download/template:defs.bzl", "download_template")

download.archive(
    name = "coreutils-{version}-{triplet}",
    srcs = ["entrypoint"],
    links = {
        "coreutils{executable.extension}": "entrypoint",
    },
    lock = "//coreutils:lock.json",
    strip_prefix = "coreutils-{version}-{rust.triplet}",
    substitutions = {
        "version": ["0.1.0"],
        "triplets": [
            "arm64-linux-gnu",
            "amd64-linux-gnu",
            "arm64-linux-musl",
            "amd64-linux-musl",
            "amd64-windows-msvc",
            "arm64-macos-darwin",
            "amd64-macos-darwin",
        ],
    },
    urls = [
        "https://github.com/uutils/coreutils/releases/download/{version}/coreutils-{version}-{rust.archive.basename}",
    ],
)

use_repo(
    download,
    "coreutils-0.1.0-amd64-linux-gnu",
    "coreutils-0.1.0-amd64-linux-musl",
    "coreutils-0.1.0-amd64-macos-darwin",
    "coreutils-0.1.0-amd64-windows-msvc",
    "coreutils-0.1.0-arm64-linux-gnu",
    "coreutils-0.1.0-arm64-linux-musl",
    "coreutils-0.1.0-arm64-macos-darwin",
)
```

## Lock and integrity workflow

- Generate or update the lock (URLs are resolved; integrities are initially blank):
  - Run: `bazel mod tidy`
- Populate integrities from downloaded artifacts:
```console
$ bazel run @download_utils//download/template/lock coreutils/lock.json
```
- Alternatively, fill integrities from upstream checksum files.

## Mirroring uploads

- Provide an upload destination and mirror binaries, then run:
```console
$ bazel run @download_utils//download/template/lock:upload coreutils/lock.json
```

# Notes
- The `lock` attribute tracks the expanded URLs and integrities for reproducible downloads.
- Built-in substitutions are defined in `@download_utils//:MODULE.bazel` via `download.substitutions` calls.
- You can add more substitutions in your own modules.
�
name�The templated name for each download repository. This needs to be unique across all download repositories that the extension creates. �
buildzThe template for the `BUILD.bazel` file.

Receives a `{{srcs}}` substitution value for exposing the downloaded resources.
2:BUILD.tmpl.bazel�
commands�A collection of commands to run on the downloaded resources.

```py
download_archive(
    commands = {
        # Make a script executable in the unpacked archive
        "chmod": [
            "$(location @coreutils//:entrypoint)",
            "chmod",
            "u+x",
            "some-script.sh",
        ],
    },
    tools = [
        # A hermetically downloaded `coreutils` multi-call executable
        "@coreutils//:entrypoint",
    ],
)
```

It is **strongly** recommended to use hermetically provided executables in the commands.
 P
	extension=The extension of the archive when not available from the URL.2""�
links�Creates links in the downloaded repository as `{"<target>": "<link>"}`

```py
download_archive(
    links = {
        "etc/test/fixture.txt": "fixture.txt",
    },
)
```

Depending on the platform, either symbolic or hard links are created.

2{}�
lock�A JSON lockfile that has URLs and sub-resource integrity (SRI) values for the values. The value can be set to `null` to allow uncached downloads. C
patches2Patches to apply to the repository after creation.2[]�
srcs�Globs for source files in the unpacked repository.

Will be provided to the `build` template file as a `{{srcs}}` substitution.

The default template will expose the sources as a `:srcs` `filegroup` target.
2["**"]G
strip_prefix1A prefix to remove from each file in the archive.2""i
substitutionsTSubstitution values for the templates. All permutations will result in a repository. ?
timeout-Seconds before a command execution is killed.2600�
tools�Labels to hermetic executable files.

The labels often point to downloaded executables.

Each tool can be resolved in the `commands` attribute via the `$(location )` helper.
2[]�
uploads�Upload locations to mirror the download URLs. Use `bazel run @download_utils//download/template/lock --upload <lockfile>` to upload. Can use the same substitutions that a URL uses. For example, if a download URL is `https://foo.com/{version}/abc.tar.gz` and upload URL can use `{version}` such as `https://mirror.com/{version}/abc.tar.gz`2[]�
urlsuURLs to download the file.

Multiple URLs can be provided to enable downloading from mirrors in the case of failure.
 �"
file�Download single files using templated attributes.

Use this tag with the `download_template` module extension to expand attribute templates (for example, versions and triplets) and materialize one or more external repositories from single-file downloads. Each expansion produces a repository that you can reference via `use_repo`.

# Concepts

- Attribute templating: fields like `name`, `output`, and `urls` can contain `{variables}`.
- Triplets: each `triplet` (for example, `amd64-linux-gnu`) is split into `{cpu}`, `{os}`, and `{libc}`.
- Substitutions: provide your own key/value mappings; values may reference other substitutions.
- Built-ins: `download_utils` provides helpful variables such as `{executable.extension}`.

# Examples

## File download expanded by version and triplet

```python
download = use_extension("@download_utils//download/template:defs.bzl", "download_template")

download.file(
    name = "shfmt-{version}-{triplet}",
    lock = "//shfmt:lock.json",
    output = "shfmt{executable.extension}",
    substitutions = {
        "version": ["3.11.0"],
        "triplets": [
            "arm64-linux-gnu",
            "amd64-linux-gnu",
        ],
    },
    executable = True,
    links = {"shfmt{executable.extension}": "entrypoint"},
    urls = [
        "https://github.com/mvdan/sh/releases/download/v{version}/shfmt_v{version}_{os}_{cpu}",
    ],
)

use_repo(
    download,
    "shfmt-3.11.0-amd64-linux-gnu",
    "shfmt-3.11.0-arm64-linux-gnu",
)
```

## Lock and integrity workflow

- Generate or update the lock (URLs resolved; integrities initially blank):
  - Run: `bazel mod tidy`
- Populate integrities from downloaded artifacts:
```console
$ bazel run @download_utils//download/template/lock shfmt/lock.json
```

## Mirroring uploads

- Provide an upload destination and mirror binaries, then run:
```console
$ bazel run @download_utils//download/template/lock:upload shfmt/lock.json
```

# Notes
- Built-in substitutions are defined in `@download_utils//:MODULE.bazel` via `download.substitutions`.
- You can add more substitutions in your own modules.
- This tag downloads a single file (not an archive), which is useful for standalone binaries.
�
name�The templated name for each download repository. This needs to be unique across all download repositories that the extension creates. F
build(The template for the `BUILD.bazel` file.2:BUILD.tmpl.bazel�
commands�A collection of commands to run on the downloaded resources.

```py
download_archive(
    commands = {
        # Make a script executable in the unpacked archive
        "chmod": [
            "$(location @coreutils//:entrypoint)",
            "chmod",
            "u+x",
            "some-script.sh",
        ],
    },
    tools = [
        # A hermetically downloaded `coreutils` multi-call executable
        "@coreutils//:entrypoint",
    ],
)
```

It is **strongly** recommended to use hermetically provided executables in the commands.
 >

executable'Mark the downloaded file as executable.2False�
links�Creates links in the downloaded repository as `{"<target>": "<link>"}`

```py
download_archive(
    links = {
        "etc/test/fixture.txt": "fixture.txt",
    },
)
```

Depending on the platform, either symbolic or hard links are created.

2{}�
lock�A JSON lockfile that has URLs and sub-resource integrity (SRI) values for the values. The value can be set to `null` to allow uncached downloads. 9
output+The output filename for the downloaded file C
patches2Patches to apply to the repository after creation.2[]i
substitutionsTSubstitution values for the templates. All permutations will result in a repository. ?
timeout-Seconds before a command execution is killed.2600�
tools�Labels to hermetic executable files.

The labels often point to downloaded executables.

Each tool can be resolved in the `commands` attribute via the `$(location )` helper.
2[]�
uploads�Upload locations to mirror the download URLs. Use `bazel run @download_utils//download/template/lock --upload <lockfile>` to upload. Can use the same substitutions that a URL uses. For example, if a download URL is `https://foo.com/{version}/abc.tar.gz` and upload URL can use `{version}` such as `https://mirror.com/{version}/abc.tar.gz`2[]&
urlsURLs to download the file. �(
deb�Download and extract Debian packages using templated attributes.

Use this tag with the `download_template` module extension to expand attribute templates (for example, versions and triplets) and materialize one or more external repositories from .deb files. Each expansion produces a repository that you can reference via `use_repo`.

# Concepts

- Attribute templating: Fields like `name`, `urls`, and `strip_prefix` can contain `{variables}`.
- Triplets: Each `triplet` (for example, `amd64-linux-gnu`) is split into `{cpu}`, `{os}`, and `{libc}`.
- Substitutions: Provide your own key/value mappings; values may reference other substitutions.
- Built-ins: `download_utils` provides helpful variables such as `{rust.archive.basename}`.
- Data archive: This tag extracts the payload from the .deb (the `data.tar.*` archive).

# Examples

## Debian package expanded by version and triplet

```python
download = use_extension("@download_utils//download/template:defs.bzl", "download_template")
download.deb(
    name = "busybox-{version}-{cpu}-{os}",
    srcs = ["busybox"],
    links = {"busybox": "entrypoint"},
    lock = "//busybox:lock.json",
    strip_prefix = "usr/bin",
    substitutions = {
        "version": ["1.36.1"],
        "revision": ["6"],
        "triplet": [
            "arm64-linux-gnu",
            "amd64-linux-gnu",
        ],
    },
    uploads = [
        "https://gitlab.arm.com/api/v4/projects/bazel%2Fdownload_utils/packages/generic/busybox-static/{version}/busybox-static_{version}-{revision}_{cpu}.deb",
    ],
    urls = [
        "https://gitlab.arm.com/api/v4/projects/bazel%2Fdownload_utils/packages/generic/busybox-static/{version}/busybox-static_{version}-{revision}_{cpu}.deb",
        "https://snapshot-cloudflare.debian.org/archive/debian/20240210T223313Z/pool/main/b/busybox/busybox-static_{version}-{revision}_{cpu}.deb",
    ],
)
```

## Lock and integrity workflow

- Generate or update the lock (URLs resolved; integrities initially blank):
  - Run: `bazel mod tidy`
- Populate integrities from downloaded artifacts:
```console
$ bazel run @download_utils//download/template/lock busybox/lock.json
```
- Alternatively, fill integrities from upstream checksum files.

## Mirroring uploads

- Provide an upload destination and mirror binaries, then run:
```console
$ bazel run @download_utils//download/template/lock:upload busybox/lock.json
```

# Notes

- Built-in substitutions are defined in `@download_utils//:MODULE.bazel` via `download.substitutions`.
- You can add more substitutions in your own modules.
- This tag extracts only the data archive inside the .deb (`data.tar.*`).
�
name�The templated name for each download repository. This needs to be unique across all download repositories that the extension creates. �
buildzThe template for the `BUILD.bazel` file.

Receives a `{{srcs}}` substitution value for exposing the downloaded resources.
2:BUILD.tmpl.bazel�
commands�A collection of commands to run on the downloaded resources.

```py
download_archive(
    commands = {
        # Make a script executable in the unpacked archive
        "chmod": [
            "$(location @coreutils//:entrypoint)",
            "chmod",
            "u+x",
            "some-script.sh",
        ],
    },
    tools = [
        # A hermetically downloaded `coreutils` multi-call executable
        "@coreutils//:entrypoint",
    ],
)
```

It is **strongly** recommended to use hermetically provided executables in the commands.
 �
links�Creates links in the downloaded repository as `{"<target>": "<link>"}`

```py
download_archive(
    links = {
        "etc/test/fixture.txt": "fixture.txt",
    },
)
```

Depending on the platform, either symbolic or hard links are created.

2{}�
lock�A JSON lockfile that has URLs and sub-resource integrity (SRI) values for the values. The value can be set to `null` to allow uncached downloads. C
patches2Patches to apply to the repository after creation.2[]�
srcs�Globs for source files in the unpacked repository.

Will be provided to the `build` template file as a `{{srcs}}` substitution.

The default template will expose the sources as a `:srcs` `filegroup` target.
2["**"]G
strip_prefix1A prefix to remove from each file in the archive.2""i
substitutionsTSubstitution values for the templates. All permutations will result in a repository. ?
timeout-Seconds before a command execution is killed.2600�
tools�Labels to hermetic executable files.

The labels often point to downloaded executables.

Each tool can be resolved in the `commands` attribute via the `$(location )` helper.
2[]�
uploads�Upload locations to mirror the download URLs. Use `bazel run @download_utils//download/template/lock --upload <lockfile>` to upload. Can use the same substitutions that a URL uses. For example, if a download URL is `https://foo.com/{version}/abc.tar.gz` and upload URL can use `{version}` such as `https://mirror.com/{version}/abc.tar.gz`2[]�
urlsuURLs to download the file.

Multiple URLs can be provided to enable downloading from mirrors in the case of failure.
 �

substitution�Provide a single templated substitution for `download_template` rules.

Define a `key` whose `value` is selected by evaluating a templated `match` string against a `select` map. The `match` string can reference other substitutions using `{variable}` and values in `select` may also contain `{variable}` placeholders.

# Example

```py
download = use_extension("//download/template:defs.bzl", "download_template")

# Derive a vendor name from the current OS
download.substitution(
    key = "rust.vendor",
    match = "{os}",
    select = {
        "macos": "apple",
        "windows": "pc",
        "//conditions:default": "unknown",
    },
)

# Use the substitution in a templated download
download.archive(
    name = "pkg-{version}-{triplet}",
    urls = ["https://example.com/pkg-{version}-{rust.vendor}-{cpu}.tar.xz"],
    lock = "//pkg:lock.json",
    substitutions = {
        "version": ["1.2.3"],
        "triplet": ["amd64-linux-gnu", "arm64-linux-gnu"],
    },
)
```

Consider `substitutions` to load multiple substitutions from JSON files.
6
key+The replacement key for the template value. J
match'A templated string to match in `select`2"//conditions:default"c
selectUA dictionary that matches `match` to provide a value. Can use replacements in values.
 �
substitutions�Provide multiple substitutions for templated downloads from JSON files.

Use this tag with the `download_template` module extension to load one or more JSON files that define substitution values used by templated attributes (for example `{version}`, `{triplet}`, `{cpu}`, `{os}`, `{libc}`).

# Example

```py
download = use_extension("//download/template:defs.bzl", "download_template")
download.substitutions(
    srcs = [
        "//download/template:rust.cpu.json",
        "//download/template:rust.vendor.json",
    ],
)
```

# JSON schema

Each JSON file contains a map from substitution key to either:
- A string value, used as the default:
  ```json
  { "key": "value" }
  ```
- A single-entry map of match -> select, where `select` is a map of cases:
  ```json
  { "key": { "{variable}": { "case1": "value1", "//conditions:default": "fallback" } } }
  ```

# JSON
```json
{
  "rust.vendor": {
    "{os}": {
      "macos": "apple",
      "windows": "pc",
      "//conditions:default": "unknown"
    }
  },
  "rust.os": {
    "//conditions:default": "{os}"
  }
}
```

# Notes
- The match string (for example, `"{os}"`) and `select` values may include other substitutions like `"{cpu}"` or `"{libc}"`.
- If a value is a plain string, it is treated as `select = {"//conditions:default": "<value>"}`.
- Substitutions are resolved iteratively; unresolved values depending on yet-to-be-defined keys are retried up to a recursion limit.
- Provide only one match entry per key; if multiple are needed, split into separate keys.
<
srcs.JSON files to read the substitution data from.2[]"A
download_template,@@download_utils//download/template:defs.bzl
�%�%�?
�*
archive�Download and extract archives using templated attributes.

Use this tag with the `download_template` module extension to materialize one or more external repositories by expanding attribute templates with substitutions (e.g., `versions` and `triplets`). Each expanded instance produces a repository that can be referenced via `use_repo`.

# Concepts

- Attribute templating: Fields like `name`, `urls`, and `strip_prefix` can contain `{variables}`.
- Triplets: Each `triplet` (e.g., `amd64-linux-gnu`) is split into `{cpu}`, `{os}`, and `{libc}` for reuse.
- Substitutions: Provide your own key/value mappings, which may reference other substitutions.
- Built-ins: `download_utils` adds helpful variables such as `{rust.archive.basename}`.
- Lock workflow: `bazel mod tidy` creates a lock file with resolved URLs; integrities are added via a helper command.

# Examples

## Archive downloads expanded by `version` and `triplet`

```python
download = use_extension("@download_utils//download/template:defs.bzl", "download_template")

download.archive(
    name = "coreutils-{version}-{triplet}",
    srcs = ["entrypoint"],
    links = {
        "coreutils{executable.extension}": "entrypoint",
    },
    lock = "//coreutils:lock.json",
    strip_prefix = "coreutils-{version}-{rust.triplet}",
    substitutions = {
        "version": ["0.1.0"],
        "triplets": [
            "arm64-linux-gnu",
            "amd64-linux-gnu",
            "arm64-linux-musl",
            "amd64-linux-musl",
            "amd64-windows-msvc",
            "arm64-macos-darwin",
            "amd64-macos-darwin",
        ],
    },
    urls = [
        "https://github.com/uutils/coreutils/releases/download/{version}/coreutils-{version}-{rust.archive.basename}",
    ],
)

use_repo(
    download,
    "coreutils-0.1.0-amd64-linux-gnu",
    "coreutils-0.1.0-amd64-linux-musl",
    "coreutils-0.1.0-amd64-macos-darwin",
    "coreutils-0.1.0-amd64-windows-msvc",
    "coreutils-0.1.0-arm64-linux-gnu",
    "coreutils-0.1.0-arm64-linux-musl",
    "coreutils-0.1.0-arm64-macos-darwin",
)
```

## Lock and integrity workflow

- Generate or update the lock (URLs are resolved; integrities are initially blank):
  - Run: `bazel mod tidy`
- Populate integrities from downloaded artifacts:
```console
$ bazel run @download_utils//download/template/lock coreutils/lock.json
```
- Alternatively, fill integrities from upstream checksum files.

## Mirroring uploads

- Provide an upload destination and mirror binaries, then run:
```console
$ bazel run @download_utils//download/template/lock:upload coreutils/lock.json
```

# Notes
- The `lock` attribute tracks the expanded URLs and integrities for reproducible downloads.
- Built-in substitutions are defined in `@download_utils//:MODULE.bazel` via `download.substitutions` calls.
- You can add more substitutions in your own modules.
�
name�The templated name for each download repository. This needs to be unique across all download repositories that the extension creates. �
buildzThe template for the `BUILD.bazel` file.

Receives a `{{srcs}}` substitution value for exposing the downloaded resources.
2:BUILD.tmpl.bazel�
commands�A collection of commands to run on the downloaded resources.

```py
download_archive(
    commands = {
        # Make a script executable in the unpacked archive
        "chmod": [
            "$(location @coreutils//:entrypoint)",
            "chmod",
            "u+x",
            "some-script.sh",
        ],
    },
    tools = [
        # A hermetically downloaded `coreutils` multi-call executable
        "@coreutils//:entrypoint",
    ],
)
```

It is **strongly** recommended to use hermetically provided executables in the commands.
 P
	extension=The extension of the archive when not available from the URL.2""�
links�Creates links in the downloaded repository as `{"<target>": "<link>"}`

```py
download_archive(
    links = {
        "etc/test/fixture.txt": "fixture.txt",
    },
)
```

Depending on the platform, either symbolic or hard links are created.

2{}�
lock�A JSON lockfile that has URLs and sub-resource integrity (SRI) values for the values. The value can be set to `null` to allow uncached downloads. C
patches2Patches to apply to the repository after creation.2[]�
srcs�Globs for source files in the unpacked repository.

Will be provided to the `build` template file as a `{{srcs}}` substitution.

The default template will expose the sources as a `:srcs` `filegroup` target.
2["**"]G
strip_prefix1A prefix to remove from each file in the archive.2""i
substitutionsTSubstitution values for the templates. All permutations will result in a repository. ?
timeout-Seconds before a command execution is killed.2600�
tools�Labels to hermetic executable files.

The labels often point to downloaded executables.

Each tool can be resolved in the `commands` attribute via the `$(location )` helper.
2[]�
uploads�Upload locations to mirror the download URLs. Use `bazel run @download_utils//download/template/lock --upload <lockfile>` to upload. Can use the same substitutions that a URL uses. For example, if a download URL is `https://foo.com/{version}/abc.tar.gz` and upload URL can use `{version}` such as `https://mirror.com/{version}/abc.tar.gz`2[]�
urlsuURLs to download the file.

Multiple URLs can be provided to enable downloading from mirrors in the case of failure.
 �
�
name�The templated name for each download repository. This needs to be unique across all download repositories that the extension creates. �
�
buildzThe template for the `BUILD.bazel` file.

Receives a `{{srcs}}` substitution value for exposing the downloaded resources.
2:BUILD.tmpl.bazel�
�
commands�A collection of commands to run on the downloaded resources.

```py
download_archive(
    commands = {
        # Make a script executable in the unpacked archive
        "chmod": [
            "$(location @coreutils//:entrypoint)",
            "chmod",
            "u+x",
            "some-script.sh",
        ],
    },
    tools = [
        # A hermetically downloaded `coreutils` multi-call executable
        "@coreutils//:entrypoint",
    ],
)
```

It is **strongly** recommended to use hermetically provided executables in the commands.
 R
P
	extension=The extension of the archive when not available from the URL.2""�
�
links�Creates links in the downloaded repository as `{"<target>": "<link>"}`

```py
download_archive(
    links = {
        "etc/test/fixture.txt": "fixture.txt",
    },
)
```

Depending on the platform, either symbolic or hard links are created.

2{}�
�
lock�A JSON lockfile that has URLs and sub-resource integrity (SRI) values for the values. The value can be set to `null` to allow uncached downloads. E
C
patches2Patches to apply to the repository after creation.2[]�
�
srcs�Globs for source files in the unpacked repository.

Will be provided to the `build` template file as a `{{srcs}}` substitution.

The default template will expose the sources as a `:srcs` `filegroup` target.
2["**"]I
G
strip_prefix1A prefix to remove from each file in the archive.2""k
i
substitutionsTSubstitution values for the templates. All permutations will result in a repository. A
?
timeout-Seconds before a command execution is killed.2600�
�
tools�Labels to hermetic executable files.

The labels often point to downloaded executables.

Each tool can be resolved in the `commands` attribute via the `$(location )` helper.
2[]�
�
uploads�Upload locations to mirror the download URLs. Use `bazel run @download_utils//download/template/lock --upload <lockfile>` to upload. Can use the same substitutions that a URL uses. For example, if a download URL is `https://foo.com/{version}/abc.tar.gz` and upload URL can use `{version}` such as `https://mirror.com/{version}/abc.tar.gz`2[]�
�
urlsuURLs to download the file.

Multiple URLs can be provided to enable downloading from mirrors in the case of failure.
 �3
�"
file�Download single files using templated attributes.

Use this tag with the `download_template` module extension to expand attribute templates (for example, versions and triplets) and materialize one or more external repositories from single-file downloads. Each expansion produces a repository that you can reference via `use_repo`.

# Concepts

- Attribute templating: fields like `name`, `output`, and `urls` can contain `{variables}`.
- Triplets: each `triplet` (for example, `amd64-linux-gnu`) is split into `{cpu}`, `{os}`, and `{libc}`.
- Substitutions: provide your own key/value mappings; values may reference other substitutions.
- Built-ins: `download_utils` provides helpful variables such as `{executable.extension}`.

# Examples

## File download expanded by version and triplet

```python
download = use_extension("@download_utils//download/template:defs.bzl", "download_template")

download.file(
    name = "shfmt-{version}-{triplet}",
    lock = "//shfmt:lock.json",
    output = "shfmt{executable.extension}",
    substitutions = {
        "version": ["3.11.0"],
        "triplets": [
            "arm64-linux-gnu",
            "amd64-linux-gnu",
        ],
    },
    executable = True,
    links = {"shfmt{executable.extension}": "entrypoint"},
    urls = [
        "https://github.com/mvdan/sh/releases/download/v{version}/shfmt_v{version}_{os}_{cpu}",
    ],
)

use_repo(
    download,
    "shfmt-3.11.0-amd64-linux-gnu",
    "shfmt-3.11.0-arm64-linux-gnu",
)
```

## Lock and integrity workflow

- Generate or update the lock (URLs resolved; integrities initially blank):
  - Run: `bazel mod tidy`
- Populate integrities from downloaded artifacts:
```console
$ bazel run @download_utils//download/template/lock shfmt/lock.json
```

## Mirroring uploads

- Provide an upload destination and mirror binaries, then run:
```console
$ bazel run @download_utils//download/template/lock:upload shfmt/lock.json
```

# Notes
- Built-in substitutions are defined in `@download_utils//:MODULE.bazel` via `download.substitutions`.
- You can add more substitutions in your own modules.
- This tag downloads a single file (not an archive), which is useful for standalone binaries.
�
name�The templated name for each download repository. This needs to be unique across all download repositories that the extension creates. F
build(The template for the `BUILD.bazel` file.2:BUILD.tmpl.bazel�
commands�A collection of commands to run on the downloaded resources.

```py
download_archive(
    commands = {
        # Make a script executable in the unpacked archive
        "chmod": [
            "$(location @coreutils//:entrypoint)",
            "chmod",
            "u+x",
            "some-script.sh",
        ],
    },
    tools = [
        # A hermetically downloaded `coreutils` multi-call executable
        "@coreutils//:entrypoint",
    ],
)
```

It is **strongly** recommended to use hermetically provided executables in the commands.
 >

executable'Mark the downloaded file as executable.2False�
links�Creates links in the downloaded repository as `{"<target>": "<link>"}`

```py
download_archive(
    links = {
        "etc/test/fixture.txt": "fixture.txt",
    },
)
```

Depending on the platform, either symbolic or hard links are created.

2{}�
lock�A JSON lockfile that has URLs and sub-resource integrity (SRI) values for the values. The value can be set to `null` to allow uncached downloads. 9
output+The output filename for the downloaded file C
patches2Patches to apply to the repository after creation.2[]i
substitutionsTSubstitution values for the templates. All permutations will result in a repository. ?
timeout-Seconds before a command execution is killed.2600�
tools�Labels to hermetic executable files.

The labels often point to downloaded executables.

Each tool can be resolved in the `commands` attribute via the `$(location )` helper.
2[]�
uploads�Upload locations to mirror the download URLs. Use `bazel run @download_utils//download/template/lock --upload <lockfile>` to upload. Can use the same substitutions that a URL uses. For example, if a download URL is `https://foo.com/{version}/abc.tar.gz` and upload URL can use `{version}` such as `https://mirror.com/{version}/abc.tar.gz`2[]&
urlsURLs to download the file. �
�
name�The templated name for each download repository. This needs to be unique across all download repositories that the extension creates. H
F
build(The template for the `BUILD.bazel` file.2:BUILD.tmpl.bazel�
�
commands�A collection of commands to run on the downloaded resources.

```py
download_archive(
    commands = {
        # Make a script executable in the unpacked archive
        "chmod": [
            "$(location @coreutils//:entrypoint)",
            "chmod",
            "u+x",
            "some-script.sh",
        ],
    },
    tools = [
        # A hermetically downloaded `coreutils` multi-call executable
        "@coreutils//:entrypoint",
    ],
)
```

It is **strongly** recommended to use hermetically provided executables in the commands.
 @
>

executable'Mark the downloaded file as executable.2False�
�
links�Creates links in the downloaded repository as `{"<target>": "<link>"}`

```py
download_archive(
    links = {
        "etc/test/fixture.txt": "fixture.txt",
    },
)
```

Depending on the platform, either symbolic or hard links are created.

2{}�
�
lock�A JSON lockfile that has URLs and sub-resource integrity (SRI) values for the values. The value can be set to `null` to allow uncached downloads. ;
9
output+The output filename for the downloaded file E
C
patches2Patches to apply to the repository after creation.2[]k
i
substitutionsTSubstitution values for the templates. All permutations will result in a repository. A
?
timeout-Seconds before a command execution is killed.2600�
�
tools�Labels to hermetic executable files.

The labels often point to downloaded executables.

Each tool can be resolved in the `commands` attribute via the `$(location )` helper.
2[]�
�
uploads�Upload locations to mirror the download URLs. Use `bazel run @download_utils//download/template/lock --upload <lockfile>` to upload. Can use the same substitutions that a URL uses. For example, if a download URL is `https://foo.com/{version}/abc.tar.gz` and upload URL can use `{version}` such as `https://mirror.com/{version}/abc.tar.gz`2[](
&
urlsURLs to download the file. �<
�(
deb�Download and extract Debian packages using templated attributes.

Use this tag with the `download_template` module extension to expand attribute templates (for example, versions and triplets) and materialize one or more external repositories from .deb files. Each expansion produces a repository that you can reference via `use_repo`.

# Concepts

- Attribute templating: Fields like `name`, `urls`, and `strip_prefix` can contain `{variables}`.
- Triplets: Each `triplet` (for example, `amd64-linux-gnu`) is split into `{cpu}`, `{os}`, and `{libc}`.
- Substitutions: Provide your own key/value mappings; values may reference other substitutions.
- Built-ins: `download_utils` provides helpful variables such as `{rust.archive.basename}`.
- Data archive: This tag extracts the payload from the .deb (the `data.tar.*` archive).

# Examples

## Debian package expanded by version and triplet

```python
download = use_extension("@download_utils//download/template:defs.bzl", "download_template")
download.deb(
    name = "busybox-{version}-{cpu}-{os}",
    srcs = ["busybox"],
    links = {"busybox": "entrypoint"},
    lock = "//busybox:lock.json",
    strip_prefix = "usr/bin",
    substitutions = {
        "version": ["1.36.1"],
        "revision": ["6"],
        "triplet": [
            "arm64-linux-gnu",
            "amd64-linux-gnu",
        ],
    },
    uploads = [
        "https://gitlab.arm.com/api/v4/projects/bazel%2Fdownload_utils/packages/generic/busybox-static/{version}/busybox-static_{version}-{revision}_{cpu}.deb",
    ],
    urls = [
        "https://gitlab.arm.com/api/v4/projects/bazel%2Fdownload_utils/packages/generic/busybox-static/{version}/busybox-static_{version}-{revision}_{cpu}.deb",
        "https://snapshot-cloudflare.debian.org/archive/debian/20240210T223313Z/pool/main/b/busybox/busybox-static_{version}-{revision}_{cpu}.deb",
    ],
)
```

## Lock and integrity workflow

- Generate or update the lock (URLs resolved; integrities initially blank):
  - Run: `bazel mod tidy`
- Populate integrities from downloaded artifacts:
```console
$ bazel run @download_utils//download/template/lock busybox/lock.json
```
- Alternatively, fill integrities from upstream checksum files.

## Mirroring uploads

- Provide an upload destination and mirror binaries, then run:
```console
$ bazel run @download_utils//download/template/lock:upload busybox/lock.json
```

# Notes

- Built-in substitutions are defined in `@download_utils//:MODULE.bazel` via `download.substitutions`.
- You can add more substitutions in your own modules.
- This tag extracts only the data archive inside the .deb (`data.tar.*`).
�
name�The templated name for each download repository. This needs to be unique across all download repositories that the extension creates. �
buildzThe template for the `BUILD.bazel` file.

Receives a `{{srcs}}` substitution value for exposing the downloaded resources.
2:BUILD.tmpl.bazel�
commands�A collection of commands to run on the downloaded resources.

```py
download_archive(
    commands = {
        # Make a script executable in the unpacked archive
        "chmod": [
            "$(location @coreutils//:entrypoint)",
            "chmod",
            "u+x",
            "some-script.sh",
        ],
    },
    tools = [
        # A hermetically downloaded `coreutils` multi-call executable
        "@coreutils//:entrypoint",
    ],
)
```

It is **strongly** recommended to use hermetically provided executables in the commands.
 �
links�Creates links in the downloaded repository as `{"<target>": "<link>"}`

```py
download_archive(
    links = {
        "etc/test/fixture.txt": "fixture.txt",
    },
)
```

Depending on the platform, either symbolic or hard links are created.

2{}�
lock�A JSON lockfile that has URLs and sub-resource integrity (SRI) values for the values. The value can be set to `null` to allow uncached downloads. C
patches2Patches to apply to the repository after creation.2[]�
srcs�Globs for source files in the unpacked repository.

Will be provided to the `build` template file as a `{{srcs}}` substitution.

The default template will expose the sources as a `:srcs` `filegroup` target.
2["**"]G
strip_prefix1A prefix to remove from each file in the archive.2""i
substitutionsTSubstitution values for the templates. All permutations will result in a repository. ?
timeout-Seconds before a command execution is killed.2600�
tools�Labels to hermetic executable files.

The labels often point to downloaded executables.

Each tool can be resolved in the `commands` attribute via the `$(location )` helper.
2[]�
uploads�Upload locations to mirror the download URLs. Use `bazel run @download_utils//download/template/lock --upload <lockfile>` to upload. Can use the same substitutions that a URL uses. For example, if a download URL is `https://foo.com/{version}/abc.tar.gz` and upload URL can use `{version}` such as `https://mirror.com/{version}/abc.tar.gz`2[]�
urlsuURLs to download the file.

Multiple URLs can be provided to enable downloading from mirrors in the case of failure.
 �
�
name�The templated name for each download repository. This needs to be unique across all download repositories that the extension creates. �
�
buildzThe template for the `BUILD.bazel` file.

Receives a `{{srcs}}` substitution value for exposing the downloaded resources.
2:BUILD.tmpl.bazel�
�
commands�A collection of commands to run on the downloaded resources.

```py
download_archive(
    commands = {
        # Make a script executable in the unpacked archive
        "chmod": [
            "$(location @coreutils//:entrypoint)",
            "chmod",
            "u+x",
            "some-script.sh",
        ],
    },
    tools = [
        # A hermetically downloaded `coreutils` multi-call executable
        "@coreutils//:entrypoint",
    ],
)
```

It is **strongly** recommended to use hermetically provided executables in the commands.
 �
�
links�Creates links in the downloaded repository as `{"<target>": "<link>"}`

```py
download_archive(
    links = {
        "etc/test/fixture.txt": "fixture.txt",
    },
)
```

Depending on the platform, either symbolic or hard links are created.

2{}�
�
lock�A JSON lockfile that has URLs and sub-resource integrity (SRI) values for the values. The value can be set to `null` to allow uncached downloads. E
C
patches2Patches to apply to the repository after creation.2[]�
�
srcs�Globs for source files in the unpacked repository.

Will be provided to the `build` template file as a `{{srcs}}` substitution.

The default template will expose the sources as a `:srcs` `filegroup` target.
2["**"]I
G
strip_prefix1A prefix to remove from each file in the archive.2""k
i
substitutionsTSubstitution values for the templates. All permutations will result in a repository. A
?
timeout-Seconds before a command execution is killed.2600�
�
tools�Labels to hermetic executable files.

The labels often point to downloaded executables.

Each tool can be resolved in the `commands` attribute via the `$(location )` helper.
2[]�
�
uploads�Upload locations to mirror the download URLs. Use `bazel run @download_utils//download/template/lock --upload <lockfile>` to upload. Can use the same substitutions that a URL uses. For example, if a download URL is `https://foo.com/{version}/abc.tar.gz` and upload URL can use `{version}` such as `https://mirror.com/{version}/abc.tar.gz`2[]�
�
urlsuURLs to download the file.

Multiple URLs can be provided to enable downloading from mirrors in the case of failure.
 �
�

substitution�Provide a single templated substitution for `download_template` rules.

Define a `key` whose `value` is selected by evaluating a templated `match` string against a `select` map. The `match` string can reference other substitutions using `{variable}` and values in `select` may also contain `{variable}` placeholders.

# Example

```py
download = use_extension("//download/template:defs.bzl", "download_template")

# Derive a vendor name from the current OS
download.substitution(
    key = "rust.vendor",
    match = "{os}",
    select = {
        "macos": "apple",
        "windows": "pc",
        "//conditions:default": "unknown",
    },
)

# Use the substitution in a templated download
download.archive(
    name = "pkg-{version}-{triplet}",
    urls = ["https://example.com/pkg-{version}-{rust.vendor}-{cpu}.tar.xz"],
    lock = "//pkg:lock.json",
    substitutions = {
        "version": ["1.2.3"],
        "triplet": ["amd64-linux-gnu", "arm64-linux-gnu"],
    },
)
```

Consider `substitutions` to load multiple substitutions from JSON files.
6
key+The replacement key for the template value. J
match'A templated string to match in `select`2"//conditions:default"c
selectUA dictionary that matches `match` to provide a value. Can use replacements in values.
 8
6
key+The replacement key for the template value. L
J
match'A templated string to match in `select`2"//conditions:default"e
c
selectUA dictionary that matches `match` to provide a value. Can use replacements in values.
 �
�
substitutions�Provide multiple substitutions for templated downloads from JSON files.

Use this tag with the `download_template` module extension to load one or more JSON files that define substitution values used by templated attributes (for example `{version}`, `{triplet}`, `{cpu}`, `{os}`, `{libc}`).

# Example

```py
download = use_extension("//download/template:defs.bzl", "download_template")
download.substitutions(
    srcs = [
        "//download/template:rust.cpu.json",
        "//download/template:rust.vendor.json",
    ],
)
```

# JSON schema

Each JSON file contains a map from substitution key to either:
- A string value, used as the default:
  ```json
  { "key": "value" }
  ```
- A single-entry map of match -> select, where `select` is a map of cases:
  ```json
  { "key": { "{variable}": { "case1": "value1", "//conditions:default": "fallback" } } }
  ```

# JSON
```json
{
  "rust.vendor": {
    "{os}": {
      "macos": "apple",
      "windows": "pc",
      "//conditions:default": "unknown"
    }
  },
  "rust.os": {
    "//conditions:default": "{os}"
  }
}
```

# Notes
- The match string (for example, `"{os}"`) and `select` values may include other substitutions like `"{cpu}"` or `"{libc}"`.
- If a value is a plain string, it is treated as `select = {"//conditions:default": "<value>"}`.
- Substitutions are resolved iteratively; unresolved values depending on yet-to-be-defined keys are retried up to a recursion limit.
- Provide only one match entry per key; if multiple are needed, split into separate keys.
<
srcs.JSON files to read the substitution data from.2[]>
<
srcs.JSON files to read the substitution data from.2[]�
!//download/template:extension.bzlrg
2
download_utilsdownload/templateextension.bzl#
template	_template
:C
Q�
2
download_utilsdownload/templateextension.bzl�implementation*q
a
implementation

mctx (2C
implementation1@@download_utils//download/template:extension.bzl
yy��download_template�Templated downloads module extension for archives, single files, and Debian packages.

# Overview

- Use this module extension via `use_extension` to declare templated downloads.
- Tags:
  - `archive`, `file`, `deb`: define artifacts to fetch.
  - `substitution`, `substitutions`: provide values for template variables.
- Attribute templating: fields like `name`, `urls`, and `strip_prefix` can contain `{variables}`.
- Triplets: a `triplet` like `amd64-linux-gnu` is split into `{cpu}`, `{os}`, and `{libc}`.
- Built-ins: `download_utils` provides helpful variables such as `{rust.archive.basename}`.

# Example

```python
download = use_extension("@download_utils//download/template:defs.bzl", "download_template")

# Provide substitutions from JSON files
download.substitutions(
    srcs = ["//download/template:rust.cpu.json"],
)

# Provide a direct substitution
download.substitution(
    key = "version",
    match = "//conditions:default",
    select = {"//conditions:default": "1.2.3"},
)

# Define an archive download expanded by triplet
download.archive(
    name = "pkg-{version}-{triplet}",
    lock = "//pkg:lock.json",
    strip_prefix = "pkg-{version}",
    substitutions = {
        "triplet": ["amd64-linux-gnu", "arm64-linux-gnu"],
    },
    urls = [
        "https://example.com/pkg-{version}-{rust.archive.basename}",
    ],
)

# Make the generated repositories available
use_repo(
    download,
    "pkg-1.2.3-amd64-linux-gnu",
    "pkg-1.2.3-arm64-linux-gnu",
)
```

# Lock and integrity workflow

- Generate or update the lock (URLs resolved; integrities initially blank):
  - Run: `bazel mod tidy`
- Populate integrities from downloaded artifacts:
  - Run: `bazel run @download_utils//download/template/lock <path/to/lock.json>`
- Optionally mirror binaries:
  - Run: `bazel run @download_utils//download/template/lock:upload <path/to/lock.json>`

# Notes

- Built-in substitutions are defined in `@download_utils//:MODULE.bazel` via `download.substitutions`.
- You can add more substitutions in your own modules with the `substitution` and `substitutions` tags.
- For post-processing commands in repository rules, prefer hermetic tools referenced via `$(location ...)`.
J��
ޝ
download_template�Templated downloads module extension for archives, single files, and Debian packages.

# Overview

- Use this module extension via `use_extension` to declare templated downloads.
- Tags:
  - `archive`, `file`, `deb`: define artifacts to fetch.
  - `substitution`, `substitutions`: provide values for template variables.
- Attribute templating: fields like `name`, `urls`, and `strip_prefix` can contain `{variables}`.
- Triplets: a `triplet` like `amd64-linux-gnu` is split into `{cpu}`, `{os}`, and `{libc}`.
- Built-ins: `download_utils` provides helpful variables such as `{rust.archive.basename}`.

# Example

```python
download = use_extension("@download_utils//download/template:defs.bzl", "download_template")

# Provide substitutions from JSON files
download.substitutions(
    srcs = ["//download/template:rust.cpu.json"],
)

# Provide a direct substitution
download.substitution(
    key = "version",
    match = "//conditions:default",
    select = {"//conditions:default": "1.2.3"},
)

# Define an archive download expanded by triplet
download.archive(
    name = "pkg-{version}-{triplet}",
    lock = "//pkg:lock.json",
    strip_prefix = "pkg-{version}",
    substitutions = {
        "triplet": ["amd64-linux-gnu", "arm64-linux-gnu"],
    },
    urls = [
        "https://example.com/pkg-{version}-{rust.archive.basename}",
    ],
)

# Make the generated repositories available
use_repo(
    download,
    "pkg-1.2.3-amd64-linux-gnu",
    "pkg-1.2.3-arm64-linux-gnu",
)
```

# Lock and integrity workflow

- Generate or update the lock (URLs resolved; integrities initially blank):
  - Run: `bazel mod tidy`
- Populate integrities from downloaded artifacts:
  - Run: `bazel run @download_utils//download/template/lock <path/to/lock.json>`
- Optionally mirror binaries:
  - Run: `bazel run @download_utils//download/template/lock:upload <path/to/lock.json>`

# Notes

- Built-in substitutions are defined in `@download_utils//:MODULE.bazel` via `download.substitutions`.
- You can add more substitutions in your own modules with the `substitution` and `substitutions` tags.
- For post-processing commands in repository rules, prefer hermetic tools referenced via `$(location ...)`.
�*
archive�Download and extract archives using templated attributes.

Use this tag with the `download_template` module extension to materialize one or more external repositories by expanding attribute templates with substitutions (e.g., `versions` and `triplets`). Each expanded instance produces a repository that can be referenced via `use_repo`.

# Concepts

- Attribute templating: Fields like `name`, `urls`, and `strip_prefix` can contain `{variables}`.
- Triplets: Each `triplet` (e.g., `amd64-linux-gnu`) is split into `{cpu}`, `{os}`, and `{libc}` for reuse.
- Substitutions: Provide your own key/value mappings, which may reference other substitutions.
- Built-ins: `download_utils` adds helpful variables such as `{rust.archive.basename}`.
- Lock workflow: `bazel mod tidy` creates a lock file with resolved URLs; integrities are added via a helper command.

# Examples

## Archive downloads expanded by `version` and `triplet`

```python
download = use_extension("@download_utils//download/template:defs.bzl", "download_template")

download.archive(
    name = "coreutils-{version}-{triplet}",
    srcs = ["entrypoint"],
    links = {
        "coreutils{executable.extension}": "entrypoint",
    },
    lock = "//coreutils:lock.json",
    strip_prefix = "coreutils-{version}-{rust.triplet}",
    substitutions = {
        "version": ["0.1.0"],
        "triplets": [
            "arm64-linux-gnu",
            "amd64-linux-gnu",
            "arm64-linux-musl",
            "amd64-linux-musl",
            "amd64-windows-msvc",
            "arm64-macos-darwin",
            "amd64-macos-darwin",
        ],
    },
    urls = [
        "https://github.com/uutils/coreutils/releases/download/{version}/coreutils-{version}-{rust.archive.basename}",
    ],
)

use_repo(
    download,
    "coreutils-0.1.0-amd64-linux-gnu",
    "coreutils-0.1.0-amd64-linux-musl",
    "coreutils-0.1.0-amd64-macos-darwin",
    "coreutils-0.1.0-amd64-windows-msvc",
    "coreutils-0.1.0-arm64-linux-gnu",
    "coreutils-0.1.0-arm64-linux-musl",
    "coreutils-0.1.0-arm64-macos-darwin",
)
```

## Lock and integrity workflow

- Generate or update the lock (URLs are resolved; integrities are initially blank):
  - Run: `bazel mod tidy`
- Populate integrities from downloaded artifacts:
```console
$ bazel run @download_utils//download/template/lock coreutils/lock.json
```
- Alternatively, fill integrities from upstream checksum files.

## Mirroring uploads

- Provide an upload destination and mirror binaries, then run:
```console
$ bazel run @download_utils//download/template/lock:upload coreutils/lock.json
```

# Notes
- The `lock` attribute tracks the expanded URLs and integrities for reproducible downloads.
- Built-in substitutions are defined in `@download_utils//:MODULE.bazel` via `download.substitutions` calls.
- You can add more substitutions in your own modules.
�
name�The templated name for each download repository. This needs to be unique across all download repositories that the extension creates. �
buildzThe template for the `BUILD.bazel` file.

Receives a `{{srcs}}` substitution value for exposing the downloaded resources.
2:BUILD.tmpl.bazel�
commands�A collection of commands to run on the downloaded resources.

```py
download_archive(
    commands = {
        # Make a script executable in the unpacked archive
        "chmod": [
            "$(location @coreutils//:entrypoint)",
            "chmod",
            "u+x",
            "some-script.sh",
        ],
    },
    tools = [
        # A hermetically downloaded `coreutils` multi-call executable
        "@coreutils//:entrypoint",
    ],
)
```

It is **strongly** recommended to use hermetically provided executables in the commands.
 P
	extension=The extension of the archive when not available from the URL.2""�
links�Creates links in the downloaded repository as `{"<target>": "<link>"}`

```py
download_archive(
    links = {
        "etc/test/fixture.txt": "fixture.txt",
    },
)
```

Depending on the platform, either symbolic or hard links are created.

2{}�
lock�A JSON lockfile that has URLs and sub-resource integrity (SRI) values for the values. The value can be set to `null` to allow uncached downloads. C
patches2Patches to apply to the repository after creation.2[]�
srcs�Globs for source files in the unpacked repository.

Will be provided to the `build` template file as a `{{srcs}}` substitution.

The default template will expose the sources as a `:srcs` `filegroup` target.
2["**"]G
strip_prefix1A prefix to remove from each file in the archive.2""i
substitutionsTSubstitution values for the templates. All permutations will result in a repository. ?
timeout-Seconds before a command execution is killed.2600�
tools�Labels to hermetic executable files.

The labels often point to downloaded executables.

Each tool can be resolved in the `commands` attribute via the `$(location )` helper.
2[]�
uploads�Upload locations to mirror the download URLs. Use `bazel run @download_utils//download/template/lock --upload <lockfile>` to upload. Can use the same substitutions that a URL uses. For example, if a download URL is `https://foo.com/{version}/abc.tar.gz` and upload URL can use `{version}` such as `https://mirror.com/{version}/abc.tar.gz`2[]�
urlsuURLs to download the file.

Multiple URLs can be provided to enable downloading from mirrors in the case of failure.
 �"
file�Download single files using templated attributes.

Use this tag with the `download_template` module extension to expand attribute templates (for example, versions and triplets) and materialize one or more external repositories from single-file downloads. Each expansion produces a repository that you can reference via `use_repo`.

# Concepts

- Attribute templating: fields like `name`, `output`, and `urls` can contain `{variables}`.
- Triplets: each `triplet` (for example, `amd64-linux-gnu`) is split into `{cpu}`, `{os}`, and `{libc}`.
- Substitutions: provide your own key/value mappings; values may reference other substitutions.
- Built-ins: `download_utils` provides helpful variables such as `{executable.extension}`.

# Examples

## File download expanded by version and triplet

```python
download = use_extension("@download_utils//download/template:defs.bzl", "download_template")

download.file(
    name = "shfmt-{version}-{triplet}",
    lock = "//shfmt:lock.json",
    output = "shfmt{executable.extension}",
    substitutions = {
        "version": ["3.11.0"],
        "triplets": [
            "arm64-linux-gnu",
            "amd64-linux-gnu",
        ],
    },
    executable = True,
    links = {"shfmt{executable.extension}": "entrypoint"},
    urls = [
        "https://github.com/mvdan/sh/releases/download/v{version}/shfmt_v{version}_{os}_{cpu}",
    ],
)

use_repo(
    download,
    "shfmt-3.11.0-amd64-linux-gnu",
    "shfmt-3.11.0-arm64-linux-gnu",
)
```

## Lock and integrity workflow

- Generate or update the lock (URLs resolved; integrities initially blank):
  - Run: `bazel mod tidy`
- Populate integrities from downloaded artifacts:
```console
$ bazel run @download_utils//download/template/lock shfmt/lock.json
```

## Mirroring uploads

- Provide an upload destination and mirror binaries, then run:
```console
$ bazel run @download_utils//download/template/lock:upload shfmt/lock.json
```

# Notes
- Built-in substitutions are defined in `@download_utils//:MODULE.bazel` via `download.substitutions`.
- You can add more substitutions in your own modules.
- This tag downloads a single file (not an archive), which is useful for standalone binaries.
�
name�The templated name for each download repository. This needs to be unique across all download repositories that the extension creates. F
build(The template for the `BUILD.bazel` file.2:BUILD.tmpl.bazel�
commands�A collection of commands to run on the downloaded resources.

```py
download_archive(
    commands = {
        # Make a script executable in the unpacked archive
        "chmod": [
            "$(location @coreutils//:entrypoint)",
            "chmod",
            "u+x",
            "some-script.sh",
        ],
    },
    tools = [
        # A hermetically downloaded `coreutils` multi-call executable
        "@coreutils//:entrypoint",
    ],
)
```

It is **strongly** recommended to use hermetically provided executables in the commands.
 >

executable'Mark the downloaded file as executable.2False�
links�Creates links in the downloaded repository as `{"<target>": "<link>"}`

```py
download_archive(
    links = {
        "etc/test/fixture.txt": "fixture.txt",
    },
)
```

Depending on the platform, either symbolic or hard links are created.

2{}�
lock�A JSON lockfile that has URLs and sub-resource integrity (SRI) values for the values. The value can be set to `null` to allow uncached downloads. 9
output+The output filename for the downloaded file C
patches2Patches to apply to the repository after creation.2[]i
substitutionsTSubstitution values for the templates. All permutations will result in a repository. ?
timeout-Seconds before a command execution is killed.2600�
tools�Labels to hermetic executable files.

The labels often point to downloaded executables.

Each tool can be resolved in the `commands` attribute via the `$(location )` helper.
2[]�
uploads�Upload locations to mirror the download URLs. Use `bazel run @download_utils//download/template/lock --upload <lockfile>` to upload. Can use the same substitutions that a URL uses. For example, if a download URL is `https://foo.com/{version}/abc.tar.gz` and upload URL can use `{version}` such as `https://mirror.com/{version}/abc.tar.gz`2[]&
urlsURLs to download the file. �(
deb�Download and extract Debian packages using templated attributes.

Use this tag with the `download_template` module extension to expand attribute templates (for example, versions and triplets) and materialize one or more external repositories from .deb files. Each expansion produces a repository that you can reference via `use_repo`.

# Concepts

- Attribute templating: Fields like `name`, `urls`, and `strip_prefix` can contain `{variables}`.
- Triplets: Each `triplet` (for example, `amd64-linux-gnu`) is split into `{cpu}`, `{os}`, and `{libc}`.
- Substitutions: Provide your own key/value mappings; values may reference other substitutions.
- Built-ins: `download_utils` provides helpful variables such as `{rust.archive.basename}`.
- Data archive: This tag extracts the payload from the .deb (the `data.tar.*` archive).

# Examples

## Debian package expanded by version and triplet

```python
download = use_extension("@download_utils//download/template:defs.bzl", "download_template")
download.deb(
    name = "busybox-{version}-{cpu}-{os}",
    srcs = ["busybox"],
    links = {"busybox": "entrypoint"},
    lock = "//busybox:lock.json",
    strip_prefix = "usr/bin",
    substitutions = {
        "version": ["1.36.1"],
        "revision": ["6"],
        "triplet": [
            "arm64-linux-gnu",
            "amd64-linux-gnu",
        ],
    },
    uploads = [
        "https://gitlab.arm.com/api/v4/projects/bazel%2Fdownload_utils/packages/generic/busybox-static/{version}/busybox-static_{version}-{revision}_{cpu}.deb",
    ],
    urls = [
        "https://gitlab.arm.com/api/v4/projects/bazel%2Fdownload_utils/packages/generic/busybox-static/{version}/busybox-static_{version}-{revision}_{cpu}.deb",
        "https://snapshot-cloudflare.debian.org/archive/debian/20240210T223313Z/pool/main/b/busybox/busybox-static_{version}-{revision}_{cpu}.deb",
    ],
)
```

## Lock and integrity workflow

- Generate or update the lock (URLs resolved; integrities initially blank):
  - Run: `bazel mod tidy`
- Populate integrities from downloaded artifacts:
```console
$ bazel run @download_utils//download/template/lock busybox/lock.json
```
- Alternatively, fill integrities from upstream checksum files.

## Mirroring uploads

- Provide an upload destination and mirror binaries, then run:
```console
$ bazel run @download_utils//download/template/lock:upload busybox/lock.json
```

# Notes

- Built-in substitutions are defined in `@download_utils//:MODULE.bazel` via `download.substitutions`.
- You can add more substitutions in your own modules.
- This tag extracts only the data archive inside the .deb (`data.tar.*`).
�
name�The templated name for each download repository. This needs to be unique across all download repositories that the extension creates. �
buildzThe template for the `BUILD.bazel` file.

Receives a `{{srcs}}` substitution value for exposing the downloaded resources.
2:BUILD.tmpl.bazel�
commands�A collection of commands to run on the downloaded resources.

```py
download_archive(
    commands = {
        # Make a script executable in the unpacked archive
        "chmod": [
            "$(location @coreutils//:entrypoint)",
            "chmod",
            "u+x",
            "some-script.sh",
        ],
    },
    tools = [
        # A hermetically downloaded `coreutils` multi-call executable
        "@coreutils//:entrypoint",
    ],
)
```

It is **strongly** recommended to use hermetically provided executables in the commands.
 �
links�Creates links in the downloaded repository as `{"<target>": "<link>"}`

```py
download_archive(
    links = {
        "etc/test/fixture.txt": "fixture.txt",
    },
)
```

Depending on the platform, either symbolic or hard links are created.

2{}�
lock�A JSON lockfile that has URLs and sub-resource integrity (SRI) values for the values. The value can be set to `null` to allow uncached downloads. C
patches2Patches to apply to the repository after creation.2[]�
srcs�Globs for source files in the unpacked repository.

Will be provided to the `build` template file as a `{{srcs}}` substitution.

The default template will expose the sources as a `:srcs` `filegroup` target.
2["**"]G
strip_prefix1A prefix to remove from each file in the archive.2""i
substitutionsTSubstitution values for the templates. All permutations will result in a repository. ?
timeout-Seconds before a command execution is killed.2600�
tools�Labels to hermetic executable files.

The labels often point to downloaded executables.

Each tool can be resolved in the `commands` attribute via the `$(location )` helper.
2[]�
uploads�Upload locations to mirror the download URLs. Use `bazel run @download_utils//download/template/lock --upload <lockfile>` to upload. Can use the same substitutions that a URL uses. For example, if a download URL is `https://foo.com/{version}/abc.tar.gz` and upload URL can use `{version}` such as `https://mirror.com/{version}/abc.tar.gz`2[]�
urlsuURLs to download the file.

Multiple URLs can be provided to enable downloading from mirrors in the case of failure.
 �

substitution�Provide a single templated substitution for `download_template` rules.

Define a `key` whose `value` is selected by evaluating a templated `match` string against a `select` map. The `match` string can reference other substitutions using `{variable}` and values in `select` may also contain `{variable}` placeholders.

# Example

```py
download = use_extension("//download/template:defs.bzl", "download_template")

# Derive a vendor name from the current OS
download.substitution(
    key = "rust.vendor",
    match = "{os}",
    select = {
        "macos": "apple",
        "windows": "pc",
        "//conditions:default": "unknown",
    },
)

# Use the substitution in a templated download
download.archive(
    name = "pkg-{version}-{triplet}",
    urls = ["https://example.com/pkg-{version}-{rust.vendor}-{cpu}.tar.xz"],
    lock = "//pkg:lock.json",
    substitutions = {
        "version": ["1.2.3"],
        "triplet": ["amd64-linux-gnu", "arm64-linux-gnu"],
    },
)
```

Consider `substitutions` to load multiple substitutions from JSON files.
6
key+The replacement key for the template value. J
match'A templated string to match in `select`2"//conditions:default"c
selectUA dictionary that matches `match` to provide a value. Can use replacements in values.
 �
substitutions�Provide multiple substitutions for templated downloads from JSON files.

Use this tag with the `download_template` module extension to load one or more JSON files that define substitution values used by templated attributes (for example `{version}`, `{triplet}`, `{cpu}`, `{os}`, `{libc}`).

# Example

```py
download = use_extension("//download/template:defs.bzl", "download_template")
download.substitutions(
    srcs = [
        "//download/template:rust.cpu.json",
        "//download/template:rust.vendor.json",
    ],
)
```

# JSON schema

Each JSON file contains a map from substitution key to either:
- A string value, used as the default:
  ```json
  { "key": "value" }
  ```
- A single-entry map of match -> select, where `select` is a map of cases:
  ```json
  { "key": { "{variable}": { "case1": "value1", "//conditions:default": "fallback" } } }
  ```

# JSON
```json
{
  "rust.vendor": {
    "{os}": {
      "macos": "apple",
      "windows": "pc",
      "//conditions:default": "unknown"
    }
  },
  "rust.os": {
    "//conditions:default": "{os}"
  }
}
```

# Notes
- The match string (for example, `"{os}"`) and `select` values may include other substitutions like `"{cpu}"` or `"{libc}"`.
- If a value is a plain string, it is treated as `select = {"//conditions:default": "<value>"}`.
- Substitutions are resolved iteratively; unresolved values depending on yet-to-be-defined keys are retried up to a recursion limit.
- Provide only one match entry per key; if multiple are needed, split into separate keys.
<
srcs.JSON files to read the substitution data from.2[]"F
download_template1@@download_utils//download/template:extension.bzl
�%�%�?
�*
archive�Download and extract archives using templated attributes.

Use this tag with the `download_template` module extension to materialize one or more external repositories by expanding attribute templates with substitutions (e.g., `versions` and `triplets`). Each expanded instance produces a repository that can be referenced via `use_repo`.

# Concepts

- Attribute templating: Fields like `name`, `urls`, and `strip_prefix` can contain `{variables}`.
- Triplets: Each `triplet` (e.g., `amd64-linux-gnu`) is split into `{cpu}`, `{os}`, and `{libc}` for reuse.
- Substitutions: Provide your own key/value mappings, which may reference other substitutions.
- Built-ins: `download_utils` adds helpful variables such as `{rust.archive.basename}`.
- Lock workflow: `bazel mod tidy` creates a lock file with resolved URLs; integrities are added via a helper command.

# Examples

## Archive downloads expanded by `version` and `triplet`

```python
download = use_extension("@download_utils//download/template:defs.bzl", "download_template")

download.archive(
    name = "coreutils-{version}-{triplet}",
    srcs = ["entrypoint"],
    links = {
        "coreutils{executable.extension}": "entrypoint",
    },
    lock = "//coreutils:lock.json",
    strip_prefix = "coreutils-{version}-{rust.triplet}",
    substitutions = {
        "version": ["0.1.0"],
        "triplets": [
            "arm64-linux-gnu",
            "amd64-linux-gnu",
            "arm64-linux-musl",
            "amd64-linux-musl",
            "amd64-windows-msvc",
            "arm64-macos-darwin",
            "amd64-macos-darwin",
        ],
    },
    urls = [
        "https://github.com/uutils/coreutils/releases/download/{version}/coreutils-{version}-{rust.archive.basename}",
    ],
)

use_repo(
    download,
    "coreutils-0.1.0-amd64-linux-gnu",
    "coreutils-0.1.0-amd64-linux-musl",
    "coreutils-0.1.0-amd64-macos-darwin",
    "coreutils-0.1.0-amd64-windows-msvc",
    "coreutils-0.1.0-arm64-linux-gnu",
    "coreutils-0.1.0-arm64-linux-musl",
    "coreutils-0.1.0-arm64-macos-darwin",
)
```

## Lock and integrity workflow

- Generate or update the lock (URLs are resolved; integrities are initially blank):
  - Run: `bazel mod tidy`
- Populate integrities from downloaded artifacts:
```console
$ bazel run @download_utils//download/template/lock coreutils/lock.json
```
- Alternatively, fill integrities from upstream checksum files.

## Mirroring uploads

- Provide an upload destination and mirror binaries, then run:
```console
$ bazel run @download_utils//download/template/lock:upload coreutils/lock.json
```

# Notes
- The `lock` attribute tracks the expanded URLs and integrities for reproducible downloads.
- Built-in substitutions are defined in `@download_utils//:MODULE.bazel` via `download.substitutions` calls.
- You can add more substitutions in your own modules.
�
name�The templated name for each download repository. This needs to be unique across all download repositories that the extension creates. �
buildzThe template for the `BUILD.bazel` file.

Receives a `{{srcs}}` substitution value for exposing the downloaded resources.
2:BUILD.tmpl.bazel�
commands�A collection of commands to run on the downloaded resources.

```py
download_archive(
    commands = {
        # Make a script executable in the unpacked archive
        "chmod": [
            "$(location @coreutils//:entrypoint)",
            "chmod",
            "u+x",
            "some-script.sh",
        ],
    },
    tools = [
        # A hermetically downloaded `coreutils` multi-call executable
        "@coreutils//:entrypoint",
    ],
)
```

It is **strongly** recommended to use hermetically provided executables in the commands.
 P
	extension=The extension of the archive when not available from the URL.2""�
links�Creates links in the downloaded repository as `{"<target>": "<link>"}`

```py
download_archive(
    links = {
        "etc/test/fixture.txt": "fixture.txt",
    },
)
```

Depending on the platform, either symbolic or hard links are created.

2{}�
lock�A JSON lockfile that has URLs and sub-resource integrity (SRI) values for the values. The value can be set to `null` to allow uncached downloads. C
patches2Patches to apply to the repository after creation.2[]�
srcs�Globs for source files in the unpacked repository.

Will be provided to the `build` template file as a `{{srcs}}` substitution.

The default template will expose the sources as a `:srcs` `filegroup` target.
2["**"]G
strip_prefix1A prefix to remove from each file in the archive.2""i
substitutionsTSubstitution values for the templates. All permutations will result in a repository. ?
timeout-Seconds before a command execution is killed.2600�
tools�Labels to hermetic executable files.

The labels often point to downloaded executables.

Each tool can be resolved in the `commands` attribute via the `$(location )` helper.
2[]�
uploads�Upload locations to mirror the download URLs. Use `bazel run @download_utils//download/template/lock --upload <lockfile>` to upload. Can use the same substitutions that a URL uses. For example, if a download URL is `https://foo.com/{version}/abc.tar.gz` and upload URL can use `{version}` such as `https://mirror.com/{version}/abc.tar.gz`2[]�
urlsuURLs to download the file.

Multiple URLs can be provided to enable downloading from mirrors in the case of failure.
 �
�
name�The templated name for each download repository. This needs to be unique across all download repositories that the extension creates. �
�
buildzThe template for the `BUILD.bazel` file.

Receives a `{{srcs}}` substitution value for exposing the downloaded resources.
2:BUILD.tmpl.bazel�
�
commands�A collection of commands to run on the downloaded resources.

```py
download_archive(
    commands = {
        # Make a script executable in the unpacked archive
        "chmod": [
            "$(location @coreutils//:entrypoint)",
            "chmod",
            "u+x",
            "some-script.sh",
        ],
    },
    tools = [
        # A hermetically downloaded `coreutils` multi-call executable
        "@coreutils//:entrypoint",
    ],
)
```

It is **strongly** recommended to use hermetically provided executables in the commands.
 R
P
	extension=The extension of the archive when not available from the URL.2""�
�
links�Creates links in the downloaded repository as `{"<target>": "<link>"}`

```py
download_archive(
    links = {
        "etc/test/fixture.txt": "fixture.txt",
    },
)
```

Depending on the platform, either symbolic or hard links are created.

2{}�
�
lock�A JSON lockfile that has URLs and sub-resource integrity (SRI) values for the values. The value can be set to `null` to allow uncached downloads. E
C
patches2Patches to apply to the repository after creation.2[]�
�
srcs�Globs for source files in the unpacked repository.

Will be provided to the `build` template file as a `{{srcs}}` substitution.

The default template will expose the sources as a `:srcs` `filegroup` target.
2["**"]I
G
strip_prefix1A prefix to remove from each file in the archive.2""k
i
substitutionsTSubstitution values for the templates. All permutations will result in a repository. A
?
timeout-Seconds before a command execution is killed.2600�
�
tools�Labels to hermetic executable files.

The labels often point to downloaded executables.

Each tool can be resolved in the `commands` attribute via the `$(location )` helper.
2[]�
�
uploads�Upload locations to mirror the download URLs. Use `bazel run @download_utils//download/template/lock --upload <lockfile>` to upload. Can use the same substitutions that a URL uses. For example, if a download URL is `https://foo.com/{version}/abc.tar.gz` and upload URL can use `{version}` such as `https://mirror.com/{version}/abc.tar.gz`2[]�
�
urlsuURLs to download the file.

Multiple URLs can be provided to enable downloading from mirrors in the case of failure.
 �3
�"
file�Download single files using templated attributes.

Use this tag with the `download_template` module extension to expand attribute templates (for example, versions and triplets) and materialize one or more external repositories from single-file downloads. Each expansion produces a repository that you can reference via `use_repo`.

# Concepts

- Attribute templating: fields like `name`, `output`, and `urls` can contain `{variables}`.
- Triplets: each `triplet` (for example, `amd64-linux-gnu`) is split into `{cpu}`, `{os}`, and `{libc}`.
- Substitutions: provide your own key/value mappings; values may reference other substitutions.
- Built-ins: `download_utils` provides helpful variables such as `{executable.extension}`.

# Examples

## File download expanded by version and triplet

```python
download = use_extension("@download_utils//download/template:defs.bzl", "download_template")

download.file(
    name = "shfmt-{version}-{triplet}",
    lock = "//shfmt:lock.json",
    output = "shfmt{executable.extension}",
    substitutions = {
        "version": ["3.11.0"],
        "triplets": [
            "arm64-linux-gnu",
            "amd64-linux-gnu",
        ],
    },
    executable = True,
    links = {"shfmt{executable.extension}": "entrypoint"},
    urls = [
        "https://github.com/mvdan/sh/releases/download/v{version}/shfmt_v{version}_{os}_{cpu}",
    ],
)

use_repo(
    download,
    "shfmt-3.11.0-amd64-linux-gnu",
    "shfmt-3.11.0-arm64-linux-gnu",
)
```

## Lock and integrity workflow

- Generate or update the lock (URLs resolved; integrities initially blank):
  - Run: `bazel mod tidy`
- Populate integrities from downloaded artifacts:
```console
$ bazel run @download_utils//download/template/lock shfmt/lock.json
```

## Mirroring uploads

- Provide an upload destination and mirror binaries, then run:
```console
$ bazel run @download_utils//download/template/lock:upload shfmt/lock.json
```

# Notes
- Built-in substitutions are defined in `@download_utils//:MODULE.bazel` via `download.substitutions`.
- You can add more substitutions in your own modules.
- This tag downloads a single file (not an archive), which is useful for standalone binaries.
�
name�The templated name for each download repository. This needs to be unique across all download repositories that the extension creates. F
build(The template for the `BUILD.bazel` file.2:BUILD.tmpl.bazel�
commands�A collection of commands to run on the downloaded resources.

```py
download_archive(
    commands = {
        # Make a script executable in the unpacked archive
        "chmod": [
            "$(location @coreutils//:entrypoint)",
            "chmod",
            "u+x",
            "some-script.sh",
        ],
    },
    tools = [
        # A hermetically downloaded `coreutils` multi-call executable
        "@coreutils//:entrypoint",
    ],
)
```

It is **strongly** recommended to use hermetically provided executables in the commands.
 >

executable'Mark the downloaded file as executable.2False�
links�Creates links in the downloaded repository as `{"<target>": "<link>"}`

```py
download_archive(
    links = {
        "etc/test/fixture.txt": "fixture.txt",
    },
)
```

Depending on the platform, either symbolic or hard links are created.

2{}�
lock�A JSON lockfile that has URLs and sub-resource integrity (SRI) values for the values. The value can be set to `null` to allow uncached downloads. 9
output+The output filename for the downloaded file C
patches2Patches to apply to the repository after creation.2[]i
substitutionsTSubstitution values for the templates. All permutations will result in a repository. ?
timeout-Seconds before a command execution is killed.2600�
tools�Labels to hermetic executable files.

The labels often point to downloaded executables.

Each tool can be resolved in the `commands` attribute via the `$(location )` helper.
2[]�
uploads�Upload locations to mirror the download URLs. Use `bazel run @download_utils//download/template/lock --upload <lockfile>` to upload. Can use the same substitutions that a URL uses. For example, if a download URL is `https://foo.com/{version}/abc.tar.gz` and upload URL can use `{version}` such as `https://mirror.com/{version}/abc.tar.gz`2[]&
urlsURLs to download the file. �
�
name�The templated name for each download repository. This needs to be unique across all download repositories that the extension creates. H
F
build(The template for the `BUILD.bazel` file.2:BUILD.tmpl.bazel�
�
commands�A collection of commands to run on the downloaded resources.

```py
download_archive(
    commands = {
        # Make a script executable in the unpacked archive
        "chmod": [
            "$(location @coreutils//:entrypoint)",
            "chmod",
            "u+x",
            "some-script.sh",
        ],
    },
    tools = [
        # A hermetically downloaded `coreutils` multi-call executable
        "@coreutils//:entrypoint",
    ],
)
```

It is **strongly** recommended to use hermetically provided executables in the commands.
 @
>

executable'Mark the downloaded file as executable.2False�
�
links�Creates links in the downloaded repository as `{"<target>": "<link>"}`

```py
download_archive(
    links = {
        "etc/test/fixture.txt": "fixture.txt",
    },
)
```

Depending on the platform, either symbolic or hard links are created.

2{}�
�
lock�A JSON lockfile that has URLs and sub-resource integrity (SRI) values for the values. The value can be set to `null` to allow uncached downloads. ;
9
output+The output filename for the downloaded file E
C
patches2Patches to apply to the repository after creation.2[]k
i
substitutionsTSubstitution values for the templates. All permutations will result in a repository. A
?
timeout-Seconds before a command execution is killed.2600�
�
tools�Labels to hermetic executable files.

The labels often point to downloaded executables.

Each tool can be resolved in the `commands` attribute via the `$(location )` helper.
2[]�
�
uploads�Upload locations to mirror the download URLs. Use `bazel run @download_utils//download/template/lock --upload <lockfile>` to upload. Can use the same substitutions that a URL uses. For example, if a download URL is `https://foo.com/{version}/abc.tar.gz` and upload URL can use `{version}` such as `https://mirror.com/{version}/abc.tar.gz`2[](
&
urlsURLs to download the file. �<
�(
deb�Download and extract Debian packages using templated attributes.

Use this tag with the `download_template` module extension to expand attribute templates (for example, versions and triplets) and materialize one or more external repositories from .deb files. Each expansion produces a repository that you can reference via `use_repo`.

# Concepts

- Attribute templating: Fields like `name`, `urls`, and `strip_prefix` can contain `{variables}`.
- Triplets: Each `triplet` (for example, `amd64-linux-gnu`) is split into `{cpu}`, `{os}`, and `{libc}`.
- Substitutions: Provide your own key/value mappings; values may reference other substitutions.
- Built-ins: `download_utils` provides helpful variables such as `{rust.archive.basename}`.
- Data archive: This tag extracts the payload from the .deb (the `data.tar.*` archive).

# Examples

## Debian package expanded by version and triplet

```python
download = use_extension("@download_utils//download/template:defs.bzl", "download_template")
download.deb(
    name = "busybox-{version}-{cpu}-{os}",
    srcs = ["busybox"],
    links = {"busybox": "entrypoint"},
    lock = "//busybox:lock.json",
    strip_prefix = "usr/bin",
    substitutions = {
        "version": ["1.36.1"],
        "revision": ["6"],
        "triplet": [
            "arm64-linux-gnu",
            "amd64-linux-gnu",
        ],
    },
    uploads = [
        "https://gitlab.arm.com/api/v4/projects/bazel%2Fdownload_utils/packages/generic/busybox-static/{version}/busybox-static_{version}-{revision}_{cpu}.deb",
    ],
    urls = [
        "https://gitlab.arm.com/api/v4/projects/bazel%2Fdownload_utils/packages/generic/busybox-static/{version}/busybox-static_{version}-{revision}_{cpu}.deb",
        "https://snapshot-cloudflare.debian.org/archive/debian/20240210T223313Z/pool/main/b/busybox/busybox-static_{version}-{revision}_{cpu}.deb",
    ],
)
```

## Lock and integrity workflow

- Generate or update the lock (URLs resolved; integrities initially blank):
  - Run: `bazel mod tidy`
- Populate integrities from downloaded artifacts:
```console
$ bazel run @download_utils//download/template/lock busybox/lock.json
```
- Alternatively, fill integrities from upstream checksum files.

## Mirroring uploads

- Provide an upload destination and mirror binaries, then run:
```console
$ bazel run @download_utils//download/template/lock:upload busybox/lock.json
```

# Notes

- Built-in substitutions are defined in `@download_utils//:MODULE.bazel` via `download.substitutions`.
- You can add more substitutions in your own modules.
- This tag extracts only the data archive inside the .deb (`data.tar.*`).
�
name�The templated name for each download repository. This needs to be unique across all download repositories that the extension creates. �
buildzThe template for the `BUILD.bazel` file.

Receives a `{{srcs}}` substitution value for exposing the downloaded resources.
2:BUILD.tmpl.bazel�
commands�A collection of commands to run on the downloaded resources.

```py
download_archive(
    commands = {
        # Make a script executable in the unpacked archive
        "chmod": [
            "$(location @coreutils//:entrypoint)",
            "chmod",
            "u+x",
            "some-script.sh",
        ],
    },
    tools = [
        # A hermetically downloaded `coreutils` multi-call executable
        "@coreutils//:entrypoint",
    ],
)
```

It is **strongly** recommended to use hermetically provided executables in the commands.
 �
links�Creates links in the downloaded repository as `{"<target>": "<link>"}`

```py
download_archive(
    links = {
        "etc/test/fixture.txt": "fixture.txt",
    },
)
```

Depending on the platform, either symbolic or hard links are created.

2{}�
lock�A JSON lockfile that has URLs and sub-resource integrity (SRI) values for the values. The value can be set to `null` to allow uncached downloads. C
patches2Patches to apply to the repository after creation.2[]�
srcs�Globs for source files in the unpacked repository.

Will be provided to the `build` template file as a `{{srcs}}` substitution.

The default template will expose the sources as a `:srcs` `filegroup` target.
2["**"]G
strip_prefix1A prefix to remove from each file in the archive.2""i
substitutionsTSubstitution values for the templates. All permutations will result in a repository. ?
timeout-Seconds before a command execution is killed.2600�
tools�Labels to hermetic executable files.

The labels often point to downloaded executables.

Each tool can be resolved in the `commands` attribute via the `$(location )` helper.
2[]�
uploads�Upload locations to mirror the download URLs. Use `bazel run @download_utils//download/template/lock --upload <lockfile>` to upload. Can use the same substitutions that a URL uses. For example, if a download URL is `https://foo.com/{version}/abc.tar.gz` and upload URL can use `{version}` such as `https://mirror.com/{version}/abc.tar.gz`2[]�
urlsuURLs to download the file.

Multiple URLs can be provided to enable downloading from mirrors in the case of failure.
 �
�
name�The templated name for each download repository. This needs to be unique across all download repositories that the extension creates. �
�
buildzThe template for the `BUILD.bazel` file.

Receives a `{{srcs}}` substitution value for exposing the downloaded resources.
2:BUILD.tmpl.bazel�
�
commands�A collection of commands to run on the downloaded resources.

```py
download_archive(
    commands = {
        # Make a script executable in the unpacked archive
        "chmod": [
            "$(location @coreutils//:entrypoint)",
            "chmod",
            "u+x",
            "some-script.sh",
        ],
    },
    tools = [
        # A hermetically downloaded `coreutils` multi-call executable
        "@coreutils//:entrypoint",
    ],
)
```

It is **strongly** recommended to use hermetically provided executables in the commands.
 �
�
links�Creates links in the downloaded repository as `{"<target>": "<link>"}`

```py
download_archive(
    links = {
        "etc/test/fixture.txt": "fixture.txt",
    },
)
```

Depending on the platform, either symbolic or hard links are created.

2{}�
�
lock�A JSON lockfile that has URLs and sub-resource integrity (SRI) values for the values. The value can be set to `null` to allow uncached downloads. E
C
patches2Patches to apply to the repository after creation.2[]�
�
srcs�Globs for source files in the unpacked repository.

Will be provided to the `build` template file as a `{{srcs}}` substitution.

The default template will expose the sources as a `:srcs` `filegroup` target.
2["**"]I
G
strip_prefix1A prefix to remove from each file in the archive.2""k
i
substitutionsTSubstitution values for the templates. All permutations will result in a repository. A
?
timeout-Seconds before a command execution is killed.2600�
�
tools�Labels to hermetic executable files.

The labels often point to downloaded executables.

Each tool can be resolved in the `commands` attribute via the `$(location )` helper.
2[]�
�
uploads�Upload locations to mirror the download URLs. Use `bazel run @download_utils//download/template/lock --upload <lockfile>` to upload. Can use the same substitutions that a URL uses. For example, if a download URL is `https://foo.com/{version}/abc.tar.gz` and upload URL can use `{version}` such as `https://mirror.com/{version}/abc.tar.gz`2[]�
�
urlsuURLs to download the file.

Multiple URLs can be provided to enable downloading from mirrors in the case of failure.
 �
�

substitution�Provide a single templated substitution for `download_template` rules.

Define a `key` whose `value` is selected by evaluating a templated `match` string against a `select` map. The `match` string can reference other substitutions using `{variable}` and values in `select` may also contain `{variable}` placeholders.

# Example

```py
download = use_extension("//download/template:defs.bzl", "download_template")

# Derive a vendor name from the current OS
download.substitution(
    key = "rust.vendor",
    match = "{os}",
    select = {
        "macos": "apple",
        "windows": "pc",
        "//conditions:default": "unknown",
    },
)

# Use the substitution in a templated download
download.archive(
    name = "pkg-{version}-{triplet}",
    urls = ["https://example.com/pkg-{version}-{rust.vendor}-{cpu}.tar.xz"],
    lock = "//pkg:lock.json",
    substitutions = {
        "version": ["1.2.3"],
        "triplet": ["amd64-linux-gnu", "arm64-linux-gnu"],
    },
)
```

Consider `substitutions` to load multiple substitutions from JSON files.
6
key+The replacement key for the template value. J
match'A templated string to match in `select`2"//conditions:default"c
selectUA dictionary that matches `match` to provide a value. Can use replacements in values.
 8
6
key+The replacement key for the template value. L
J
match'A templated string to match in `select`2"//conditions:default"e
c
selectUA dictionary that matches `match` to provide a value. Can use replacements in values.
 �
�
substitutions�Provide multiple substitutions for templated downloads from JSON files.

Use this tag with the `download_template` module extension to load one or more JSON files that define substitution values used by templated attributes (for example `{version}`, `{triplet}`, `{cpu}`, `{os}`, `{libc}`).

# Example

```py
download = use_extension("//download/template:defs.bzl", "download_template")
download.substitutions(
    srcs = [
        "//download/template:rust.cpu.json",
        "//download/template:rust.vendor.json",
    ],
)
```

# JSON schema

Each JSON file contains a map from substitution key to either:
- A string value, used as the default:
  ```json
  { "key": "value" }
  ```
- A single-entry map of match -> select, where `select` is a map of cases:
  ```json
  { "key": { "{variable}": { "case1": "value1", "//conditions:default": "fallback" } } }
  ```

# JSON
```json
{
  "rust.vendor": {
    "{os}": {
      "macos": "apple",
      "windows": "pc",
      "//conditions:default": "unknown"
    }
  },
  "rust.os": {
    "//conditions:default": "{os}"
  }
}
```

# Notes
- The match string (for example, `"{os}"`) and `select` values may include other substitutions like `"{cpu}"` or `"{libc}"`.
- If a value is a plain string, it is treated as `select = {"//conditions:default": "<value>"}`.
- Substitutions are resolved iteratively; unresolved values depending on yet-to-be-defined keys are retried up to a recursion limit.
- Provide only one match entry per key; if multiple are needed, split into separate keys.
<
srcs.JSON files to read the substitution data from.2[]>
<
srcs.JSON files to read the substitution data from.2[]��template�Templated downloads module extension for archives, single files, and Debian packages.

# Overview

- Use this module extension via `use_extension` to declare templated downloads.
- Tags:
  - `archive`, `file`, `deb`: define artifacts to fetch.
  - `substitution`, `substitutions`: provide values for template variables.
- Attribute templating: fields like `name`, `urls`, and `strip_prefix` can contain `{variables}`.
- Triplets: a `triplet` like `amd64-linux-gnu` is split into `{cpu}`, `{os}`, and `{libc}`.
- Built-ins: `download_utils` provides helpful variables such as `{rust.archive.basename}`.

# Example

```python
download = use_extension("@download_utils//download/template:defs.bzl", "download_template")

# Provide substitutions from JSON files
download.substitutions(
    srcs = ["//download/template:rust.cpu.json"],
)

# Provide a direct substitution
download.substitution(
    key = "version",
    match = "//conditions:default",
    select = {"//conditions:default": "1.2.3"},
)

# Define an archive download expanded by triplet
download.archive(
    name = "pkg-{version}-{triplet}",
    lock = "//pkg:lock.json",
    strip_prefix = "pkg-{version}",
    substitutions = {
        "triplet": ["amd64-linux-gnu", "arm64-linux-gnu"],
    },
    urls = [
        "https://example.com/pkg-{version}-{rust.archive.basename}",
    ],
)

# Make the generated repositories available
use_repo(
    download,
    "pkg-1.2.3-amd64-linux-gnu",
    "pkg-1.2.3-arm64-linux-gnu",
)
```

# Lock and integrity workflow

- Generate or update the lock (URLs resolved; integrities initially blank):
  - Run: `bazel mod tidy`
- Populate integrities from downloaded artifacts:
  - Run: `bazel run @download_utils//download/template/lock <path/to/lock.json>`
- Optionally mirror binaries:
  - Run: `bazel run @download_utils//download/template/lock:upload <path/to/lock.json>`

# Notes

- Built-in substitutions are defined in `@download_utils//:MODULE.bazel` via `download.substitutions`.
- You can add more substitutions in your own modules with the `substitution` and `substitutions` tags.
- For post-processing commands in repository rules, prefer hermetic tools referenced via `$(location ...)`.
J��
̝
template�Templated downloads module extension for archives, single files, and Debian packages.

# Overview

- Use this module extension via `use_extension` to declare templated downloads.
- Tags:
  - `archive`, `file`, `deb`: define artifacts to fetch.
  - `substitution`, `substitutions`: provide values for template variables.
- Attribute templating: fields like `name`, `urls`, and `strip_prefix` can contain `{variables}`.
- Triplets: a `triplet` like `amd64-linux-gnu` is split into `{cpu}`, `{os}`, and `{libc}`.
- Built-ins: `download_utils` provides helpful variables such as `{rust.archive.basename}`.

# Example

```python
download = use_extension("@download_utils//download/template:defs.bzl", "download_template")

# Provide substitutions from JSON files
download.substitutions(
    srcs = ["//download/template:rust.cpu.json"],
)

# Provide a direct substitution
download.substitution(
    key = "version",
    match = "//conditions:default",
    select = {"//conditions:default": "1.2.3"},
)

# Define an archive download expanded by triplet
download.archive(
    name = "pkg-{version}-{triplet}",
    lock = "//pkg:lock.json",
    strip_prefix = "pkg-{version}",
    substitutions = {
        "triplet": ["amd64-linux-gnu", "arm64-linux-gnu"],
    },
    urls = [
        "https://example.com/pkg-{version}-{rust.archive.basename}",
    ],
)

# Make the generated repositories available
use_repo(
    download,
    "pkg-1.2.3-amd64-linux-gnu",
    "pkg-1.2.3-arm64-linux-gnu",
)
```

# Lock and integrity workflow

- Generate or update the lock (URLs resolved; integrities initially blank):
  - Run: `bazel mod tidy`
- Populate integrities from downloaded artifacts:
  - Run: `bazel run @download_utils//download/template/lock <path/to/lock.json>`
- Optionally mirror binaries:
  - Run: `bazel run @download_utils//download/template/lock:upload <path/to/lock.json>`

# Notes

- Built-in substitutions are defined in `@download_utils//:MODULE.bazel` via `download.substitutions`.
- You can add more substitutions in your own modules with the `substitution` and `substitutions` tags.
- For post-processing commands in repository rules, prefer hermetic tools referenced via `$(location ...)`.
�*
archive�Download and extract archives using templated attributes.

Use this tag with the `download_template` module extension to materialize one or more external repositories by expanding attribute templates with substitutions (e.g., `versions` and `triplets`). Each expanded instance produces a repository that can be referenced via `use_repo`.

# Concepts

- Attribute templating: Fields like `name`, `urls`, and `strip_prefix` can contain `{variables}`.
- Triplets: Each `triplet` (e.g., `amd64-linux-gnu`) is split into `{cpu}`, `{os}`, and `{libc}` for reuse.
- Substitutions: Provide your own key/value mappings, which may reference other substitutions.
- Built-ins: `download_utils` adds helpful variables such as `{rust.archive.basename}`.
- Lock workflow: `bazel mod tidy` creates a lock file with resolved URLs; integrities are added via a helper command.

# Examples

## Archive downloads expanded by `version` and `triplet`

```python
download = use_extension("@download_utils//download/template:defs.bzl", "download_template")

download.archive(
    name = "coreutils-{version}-{triplet}",
    srcs = ["entrypoint"],
    links = {
        "coreutils{executable.extension}": "entrypoint",
    },
    lock = "//coreutils:lock.json",
    strip_prefix = "coreutils-{version}-{rust.triplet}",
    substitutions = {
        "version": ["0.1.0"],
        "triplets": [
            "arm64-linux-gnu",
            "amd64-linux-gnu",
            "arm64-linux-musl",
            "amd64-linux-musl",
            "amd64-windows-msvc",
            "arm64-macos-darwin",
            "amd64-macos-darwin",
        ],
    },
    urls = [
        "https://github.com/uutils/coreutils/releases/download/{version}/coreutils-{version}-{rust.archive.basename}",
    ],
)

use_repo(
    download,
    "coreutils-0.1.0-amd64-linux-gnu",
    "coreutils-0.1.0-amd64-linux-musl",
    "coreutils-0.1.0-amd64-macos-darwin",
    "coreutils-0.1.0-amd64-windows-msvc",
    "coreutils-0.1.0-arm64-linux-gnu",
    "coreutils-0.1.0-arm64-linux-musl",
    "coreutils-0.1.0-arm64-macos-darwin",
)
```

## Lock and integrity workflow

- Generate or update the lock (URLs are resolved; integrities are initially blank):
  - Run: `bazel mod tidy`
- Populate integrities from downloaded artifacts:
```console
$ bazel run @download_utils//download/template/lock coreutils/lock.json
```
- Alternatively, fill integrities from upstream checksum files.

## Mirroring uploads

- Provide an upload destination and mirror binaries, then run:
```console
$ bazel run @download_utils//download/template/lock:upload coreutils/lock.json
```

# Notes
- The `lock` attribute tracks the expanded URLs and integrities for reproducible downloads.
- Built-in substitutions are defined in `@download_utils//:MODULE.bazel` via `download.substitutions` calls.
- You can add more substitutions in your own modules.
�
name�The templated name for each download repository. This needs to be unique across all download repositories that the extension creates. �
buildzThe template for the `BUILD.bazel` file.

Receives a `{{srcs}}` substitution value for exposing the downloaded resources.
2:BUILD.tmpl.bazel�
commands�A collection of commands to run on the downloaded resources.

```py
download_archive(
    commands = {
        # Make a script executable in the unpacked archive
        "chmod": [
            "$(location @coreutils//:entrypoint)",
            "chmod",
            "u+x",
            "some-script.sh",
        ],
    },
    tools = [
        # A hermetically downloaded `coreutils` multi-call executable
        "@coreutils//:entrypoint",
    ],
)
```

It is **strongly** recommended to use hermetically provided executables in the commands.
 P
	extension=The extension of the archive when not available from the URL.2""�
links�Creates links in the downloaded repository as `{"<target>": "<link>"}`

```py
download_archive(
    links = {
        "etc/test/fixture.txt": "fixture.txt",
    },
)
```

Depending on the platform, either symbolic or hard links are created.

2{}�
lock�A JSON lockfile that has URLs and sub-resource integrity (SRI) values for the values. The value can be set to `null` to allow uncached downloads. C
patches2Patches to apply to the repository after creation.2[]�
srcs�Globs for source files in the unpacked repository.

Will be provided to the `build` template file as a `{{srcs}}` substitution.

The default template will expose the sources as a `:srcs` `filegroup` target.
2["**"]G
strip_prefix1A prefix to remove from each file in the archive.2""i
substitutionsTSubstitution values for the templates. All permutations will result in a repository. ?
timeout-Seconds before a command execution is killed.2600�
tools�Labels to hermetic executable files.

The labels often point to downloaded executables.

Each tool can be resolved in the `commands` attribute via the `$(location )` helper.
2[]�
uploads�Upload locations to mirror the download URLs. Use `bazel run @download_utils//download/template/lock --upload <lockfile>` to upload. Can use the same substitutions that a URL uses. For example, if a download URL is `https://foo.com/{version}/abc.tar.gz` and upload URL can use `{version}` such as `https://mirror.com/{version}/abc.tar.gz`2[]�
urlsuURLs to download the file.

Multiple URLs can be provided to enable downloading from mirrors in the case of failure.
 �"
file�Download single files using templated attributes.

Use this tag with the `download_template` module extension to expand attribute templates (for example, versions and triplets) and materialize one or more external repositories from single-file downloads. Each expansion produces a repository that you can reference via `use_repo`.

# Concepts

- Attribute templating: fields like `name`, `output`, and `urls` can contain `{variables}`.
- Triplets: each `triplet` (for example, `amd64-linux-gnu`) is split into `{cpu}`, `{os}`, and `{libc}`.
- Substitutions: provide your own key/value mappings; values may reference other substitutions.
- Built-ins: `download_utils` provides helpful variables such as `{executable.extension}`.

# Examples

## File download expanded by version and triplet

```python
download = use_extension("@download_utils//download/template:defs.bzl", "download_template")

download.file(
    name = "shfmt-{version}-{triplet}",
    lock = "//shfmt:lock.json",
    output = "shfmt{executable.extension}",
    substitutions = {
        "version": ["3.11.0"],
        "triplets": [
            "arm64-linux-gnu",
            "amd64-linux-gnu",
        ],
    },
    executable = True,
    links = {"shfmt{executable.extension}": "entrypoint"},
    urls = [
        "https://github.com/mvdan/sh/releases/download/v{version}/shfmt_v{version}_{os}_{cpu}",
    ],
)

use_repo(
    download,
    "shfmt-3.11.0-amd64-linux-gnu",
    "shfmt-3.11.0-arm64-linux-gnu",
)
```

## Lock and integrity workflow

- Generate or update the lock (URLs resolved; integrities initially blank):
  - Run: `bazel mod tidy`
- Populate integrities from downloaded artifacts:
```console
$ bazel run @download_utils//download/template/lock shfmt/lock.json
```

## Mirroring uploads

- Provide an upload destination and mirror binaries, then run:
```console
$ bazel run @download_utils//download/template/lock:upload shfmt/lock.json
```

# Notes
- Built-in substitutions are defined in `@download_utils//:MODULE.bazel` via `download.substitutions`.
- You can add more substitutions in your own modules.
- This tag downloads a single file (not an archive), which is useful for standalone binaries.
�
name�The templated name for each download repository. This needs to be unique across all download repositories that the extension creates. F
build(The template for the `BUILD.bazel` file.2:BUILD.tmpl.bazel�
commands�A collection of commands to run on the downloaded resources.

```py
download_archive(
    commands = {
        # Make a script executable in the unpacked archive
        "chmod": [
            "$(location @coreutils//:entrypoint)",
            "chmod",
            "u+x",
            "some-script.sh",
        ],
    },
    tools = [
        # A hermetically downloaded `coreutils` multi-call executable
        "@coreutils//:entrypoint",
    ],
)
```

It is **strongly** recommended to use hermetically provided executables in the commands.
 >

executable'Mark the downloaded file as executable.2False�
links�Creates links in the downloaded repository as `{"<target>": "<link>"}`

```py
download_archive(
    links = {
        "etc/test/fixture.txt": "fixture.txt",
    },
)
```

Depending on the platform, either symbolic or hard links are created.

2{}�
lock�A JSON lockfile that has URLs and sub-resource integrity (SRI) values for the values. The value can be set to `null` to allow uncached downloads. 9
output+The output filename for the downloaded file C
patches2Patches to apply to the repository after creation.2[]i
substitutionsTSubstitution values for the templates. All permutations will result in a repository. ?
timeout-Seconds before a command execution is killed.2600�
tools�Labels to hermetic executable files.

The labels often point to downloaded executables.

Each tool can be resolved in the `commands` attribute via the `$(location )` helper.
2[]�
uploads�Upload locations to mirror the download URLs. Use `bazel run @download_utils//download/template/lock --upload <lockfile>` to upload. Can use the same substitutions that a URL uses. For example, if a download URL is `https://foo.com/{version}/abc.tar.gz` and upload URL can use `{version}` such as `https://mirror.com/{version}/abc.tar.gz`2[]&
urlsURLs to download the file. �(
deb�Download and extract Debian packages using templated attributes.

Use this tag with the `download_template` module extension to expand attribute templates (for example, versions and triplets) and materialize one or more external repositories from .deb files. Each expansion produces a repository that you can reference via `use_repo`.

# Concepts

- Attribute templating: Fields like `name`, `urls`, and `strip_prefix` can contain `{variables}`.
- Triplets: Each `triplet` (for example, `amd64-linux-gnu`) is split into `{cpu}`, `{os}`, and `{libc}`.
- Substitutions: Provide your own key/value mappings; values may reference other substitutions.
- Built-ins: `download_utils` provides helpful variables such as `{rust.archive.basename}`.
- Data archive: This tag extracts the payload from the .deb (the `data.tar.*` archive).

# Examples

## Debian package expanded by version and triplet

```python
download = use_extension("@download_utils//download/template:defs.bzl", "download_template")
download.deb(
    name = "busybox-{version}-{cpu}-{os}",
    srcs = ["busybox"],
    links = {"busybox": "entrypoint"},
    lock = "//busybox:lock.json",
    strip_prefix = "usr/bin",
    substitutions = {
        "version": ["1.36.1"],
        "revision": ["6"],
        "triplet": [
            "arm64-linux-gnu",
            "amd64-linux-gnu",
        ],
    },
    uploads = [
        "https://gitlab.arm.com/api/v4/projects/bazel%2Fdownload_utils/packages/generic/busybox-static/{version}/busybox-static_{version}-{revision}_{cpu}.deb",
    ],
    urls = [
        "https://gitlab.arm.com/api/v4/projects/bazel%2Fdownload_utils/packages/generic/busybox-static/{version}/busybox-static_{version}-{revision}_{cpu}.deb",
        "https://snapshot-cloudflare.debian.org/archive/debian/20240210T223313Z/pool/main/b/busybox/busybox-static_{version}-{revision}_{cpu}.deb",
    ],
)
```

## Lock and integrity workflow

- Generate or update the lock (URLs resolved; integrities initially blank):
  - Run: `bazel mod tidy`
- Populate integrities from downloaded artifacts:
```console
$ bazel run @download_utils//download/template/lock busybox/lock.json
```
- Alternatively, fill integrities from upstream checksum files.

## Mirroring uploads

- Provide an upload destination and mirror binaries, then run:
```console
$ bazel run @download_utils//download/template/lock:upload busybox/lock.json
```

# Notes

- Built-in substitutions are defined in `@download_utils//:MODULE.bazel` via `download.substitutions`.
- You can add more substitutions in your own modules.
- This tag extracts only the data archive inside the .deb (`data.tar.*`).
�
name�The templated name for each download repository. This needs to be unique across all download repositories that the extension creates. �
buildzThe template for the `BUILD.bazel` file.

Receives a `{{srcs}}` substitution value for exposing the downloaded resources.
2:BUILD.tmpl.bazel�
commands�A collection of commands to run on the downloaded resources.

```py
download_archive(
    commands = {
        # Make a script executable in the unpacked archive
        "chmod": [
            "$(location @coreutils//:entrypoint)",
            "chmod",
            "u+x",
            "some-script.sh",
        ],
    },
    tools = [
        # A hermetically downloaded `coreutils` multi-call executable
        "@coreutils//:entrypoint",
    ],
)
```

It is **strongly** recommended to use hermetically provided executables in the commands.
 �
links�Creates links in the downloaded repository as `{"<target>": "<link>"}`

```py
download_archive(
    links = {
        "etc/test/fixture.txt": "fixture.txt",
    },
)
```

Depending on the platform, either symbolic or hard links are created.

2{}�
lock�A JSON lockfile that has URLs and sub-resource integrity (SRI) values for the values. The value can be set to `null` to allow uncached downloads. C
patches2Patches to apply to the repository after creation.2[]�
srcs�Globs for source files in the unpacked repository.

Will be provided to the `build` template file as a `{{srcs}}` substitution.

The default template will expose the sources as a `:srcs` `filegroup` target.
2["**"]G
strip_prefix1A prefix to remove from each file in the archive.2""i
substitutionsTSubstitution values for the templates. All permutations will result in a repository. ?
timeout-Seconds before a command execution is killed.2600�
tools�Labels to hermetic executable files.

The labels often point to downloaded executables.

Each tool can be resolved in the `commands` attribute via the `$(location )` helper.
2[]�
uploads�Upload locations to mirror the download URLs. Use `bazel run @download_utils//download/template/lock --upload <lockfile>` to upload. Can use the same substitutions that a URL uses. For example, if a download URL is `https://foo.com/{version}/abc.tar.gz` and upload URL can use `{version}` such as `https://mirror.com/{version}/abc.tar.gz`2[]�
urlsuURLs to download the file.

Multiple URLs can be provided to enable downloading from mirrors in the case of failure.
 �

substitution�Provide a single templated substitution for `download_template` rules.

Define a `key` whose `value` is selected by evaluating a templated `match` string against a `select` map. The `match` string can reference other substitutions using `{variable}` and values in `select` may also contain `{variable}` placeholders.

# Example

```py
download = use_extension("//download/template:defs.bzl", "download_template")

# Derive a vendor name from the current OS
download.substitution(
    key = "rust.vendor",
    match = "{os}",
    select = {
        "macos": "apple",
        "windows": "pc",
        "//conditions:default": "unknown",
    },
)

# Use the substitution in a templated download
download.archive(
    name = "pkg-{version}-{triplet}",
    urls = ["https://example.com/pkg-{version}-{rust.vendor}-{cpu}.tar.xz"],
    lock = "//pkg:lock.json",
    substitutions = {
        "version": ["1.2.3"],
        "triplet": ["amd64-linux-gnu", "arm64-linux-gnu"],
    },
)
```

Consider `substitutions` to load multiple substitutions from JSON files.
6
key+The replacement key for the template value. J
match'A templated string to match in `select`2"//conditions:default"c
selectUA dictionary that matches `match` to provide a value. Can use replacements in values.
 �
substitutions�Provide multiple substitutions for templated downloads from JSON files.

Use this tag with the `download_template` module extension to load one or more JSON files that define substitution values used by templated attributes (for example `{version}`, `{triplet}`, `{cpu}`, `{os}`, `{libc}`).

# Example

```py
download = use_extension("//download/template:defs.bzl", "download_template")
download.substitutions(
    srcs = [
        "//download/template:rust.cpu.json",
        "//download/template:rust.vendor.json",
    ],
)
```

# JSON schema

Each JSON file contains a map from substitution key to either:
- A string value, used as the default:
  ```json
  { "key": "value" }
  ```
- A single-entry map of match -> select, where `select` is a map of cases:
  ```json
  { "key": { "{variable}": { "case1": "value1", "//conditions:default": "fallback" } } }
  ```

# JSON
```json
{
  "rust.vendor": {
    "{os}": {
      "macos": "apple",
      "windows": "pc",
      "//conditions:default": "unknown"
    }
  },
  "rust.os": {
    "//conditions:default": "{os}"
  }
}
```

# Notes
- The match string (for example, `"{os}"`) and `select` values may include other substitutions like `"{cpu}"` or `"{libc}"`.
- If a value is a plain string, it is treated as `select = {"//conditions:default": "<value>"}`.
- Substitutions are resolved iteratively; unresolved values depending on yet-to-be-defined keys are retried up to a recursion limit.
- Provide only one match entry per key; if multiple are needed, split into separate keys.
<
srcs.JSON files to read the substitution data from.2[]"=
template1@@download_utils//download/template:extension.bzl
�%�%�?
�*
archive�Download and extract archives using templated attributes.

Use this tag with the `download_template` module extension to materialize one or more external repositories by expanding attribute templates with substitutions (e.g., `versions` and `triplets`). Each expanded instance produces a repository that can be referenced via `use_repo`.

# Concepts

- Attribute templating: Fields like `name`, `urls`, and `strip_prefix` can contain `{variables}`.
- Triplets: Each `triplet` (e.g., `amd64-linux-gnu`) is split into `{cpu}`, `{os}`, and `{libc}` for reuse.
- Substitutions: Provide your own key/value mappings, which may reference other substitutions.
- Built-ins: `download_utils` adds helpful variables such as `{rust.archive.basename}`.
- Lock workflow: `bazel mod tidy` creates a lock file with resolved URLs; integrities are added via a helper command.

# Examples

## Archive downloads expanded by `version` and `triplet`

```python
download = use_extension("@download_utils//download/template:defs.bzl", "download_template")

download.archive(
    name = "coreutils-{version}-{triplet}",
    srcs = ["entrypoint"],
    links = {
        "coreutils{executable.extension}": "entrypoint",
    },
    lock = "//coreutils:lock.json",
    strip_prefix = "coreutils-{version}-{rust.triplet}",
    substitutions = {
        "version": ["0.1.0"],
        "triplets": [
            "arm64-linux-gnu",
            "amd64-linux-gnu",
            "arm64-linux-musl",
            "amd64-linux-musl",
            "amd64-windows-msvc",
            "arm64-macos-darwin",
            "amd64-macos-darwin",
        ],
    },
    urls = [
        "https://github.com/uutils/coreutils/releases/download/{version}/coreutils-{version}-{rust.archive.basename}",
    ],
)

use_repo(
    download,
    "coreutils-0.1.0-amd64-linux-gnu",
    "coreutils-0.1.0-amd64-linux-musl",
    "coreutils-0.1.0-amd64-macos-darwin",
    "coreutils-0.1.0-amd64-windows-msvc",
    "coreutils-0.1.0-arm64-linux-gnu",
    "coreutils-0.1.0-arm64-linux-musl",
    "coreutils-0.1.0-arm64-macos-darwin",
)
```

## Lock and integrity workflow

- Generate or update the lock (URLs are resolved; integrities are initially blank):
  - Run: `bazel mod tidy`
- Populate integrities from downloaded artifacts:
```console
$ bazel run @download_utils//download/template/lock coreutils/lock.json
```
- Alternatively, fill integrities from upstream checksum files.

## Mirroring uploads

- Provide an upload destination and mirror binaries, then run:
```console
$ bazel run @download_utils//download/template/lock:upload coreutils/lock.json
```

# Notes
- The `lock` attribute tracks the expanded URLs and integrities for reproducible downloads.
- Built-in substitutions are defined in `@download_utils//:MODULE.bazel` via `download.substitutions` calls.
- You can add more substitutions in your own modules.
�
name�The templated name for each download repository. This needs to be unique across all download repositories that the extension creates. �
buildzThe template for the `BUILD.bazel` file.

Receives a `{{srcs}}` substitution value for exposing the downloaded resources.
2:BUILD.tmpl.bazel�
commands�A collection of commands to run on the downloaded resources.

```py
download_archive(
    commands = {
        # Make a script executable in the unpacked archive
        "chmod": [
            "$(location @coreutils//:entrypoint)",
            "chmod",
            "u+x",
            "some-script.sh",
        ],
    },
    tools = [
        # A hermetically downloaded `coreutils` multi-call executable
        "@coreutils//:entrypoint",
    ],
)
```

It is **strongly** recommended to use hermetically provided executables in the commands.
 P
	extension=The extension of the archive when not available from the URL.2""�
links�Creates links in the downloaded repository as `{"<target>": "<link>"}`

```py
download_archive(
    links = {
        "etc/test/fixture.txt": "fixture.txt",
    },
)
```

Depending on the platform, either symbolic or hard links are created.

2{}�
lock�A JSON lockfile that has URLs and sub-resource integrity (SRI) values for the values. The value can be set to `null` to allow uncached downloads. C
patches2Patches to apply to the repository after creation.2[]�
srcs�Globs for source files in the unpacked repository.

Will be provided to the `build` template file as a `{{srcs}}` substitution.

The default template will expose the sources as a `:srcs` `filegroup` target.
2["**"]G
strip_prefix1A prefix to remove from each file in the archive.2""i
substitutionsTSubstitution values for the templates. All permutations will result in a repository. ?
timeout-Seconds before a command execution is killed.2600�
tools�Labels to hermetic executable files.

The labels often point to downloaded executables.

Each tool can be resolved in the `commands` attribute via the `$(location )` helper.
2[]�
uploads�Upload locations to mirror the download URLs. Use `bazel run @download_utils//download/template/lock --upload <lockfile>` to upload. Can use the same substitutions that a URL uses. For example, if a download URL is `https://foo.com/{version}/abc.tar.gz` and upload URL can use `{version}` such as `https://mirror.com/{version}/abc.tar.gz`2[]�
urlsuURLs to download the file.

Multiple URLs can be provided to enable downloading from mirrors in the case of failure.
 �
�
name�The templated name for each download repository. This needs to be unique across all download repositories that the extension creates. �
�
buildzThe template for the `BUILD.bazel` file.

Receives a `{{srcs}}` substitution value for exposing the downloaded resources.
2:BUILD.tmpl.bazel�
�
commands�A collection of commands to run on the downloaded resources.

```py
download_archive(
    commands = {
        # Make a script executable in the unpacked archive
        "chmod": [
            "$(location @coreutils//:entrypoint)",
            "chmod",
            "u+x",
            "some-script.sh",
        ],
    },
    tools = [
        # A hermetically downloaded `coreutils` multi-call executable
        "@coreutils//:entrypoint",
    ],
)
```

It is **strongly** recommended to use hermetically provided executables in the commands.
 R
P
	extension=The extension of the archive when not available from the URL.2""�
�
links�Creates links in the downloaded repository as `{"<target>": "<link>"}`

```py
download_archive(
    links = {
        "etc/test/fixture.txt": "fixture.txt",
    },
)
```

Depending on the platform, either symbolic or hard links are created.

2{}�
�
lock�A JSON lockfile that has URLs and sub-resource integrity (SRI) values for the values. The value can be set to `null` to allow uncached downloads. E
C
patches2Patches to apply to the repository after creation.2[]�
�
srcs�Globs for source files in the unpacked repository.

Will be provided to the `build` template file as a `{{srcs}}` substitution.

The default template will expose the sources as a `:srcs` `filegroup` target.
2["**"]I
G
strip_prefix1A prefix to remove from each file in the archive.2""k
i
substitutionsTSubstitution values for the templates. All permutations will result in a repository. A
?
timeout-Seconds before a command execution is killed.2600�
�
tools�Labels to hermetic executable files.

The labels often point to downloaded executables.

Each tool can be resolved in the `commands` attribute via the `$(location )` helper.
2[]�
�
uploads�Upload locations to mirror the download URLs. Use `bazel run @download_utils//download/template/lock --upload <lockfile>` to upload. Can use the same substitutions that a URL uses. For example, if a download URL is `https://foo.com/{version}/abc.tar.gz` and upload URL can use `{version}` such as `https://mirror.com/{version}/abc.tar.gz`2[]�
�
urlsuURLs to download the file.

Multiple URLs can be provided to enable downloading from mirrors in the case of failure.
 �3
�"
file�Download single files using templated attributes.

Use this tag with the `download_template` module extension to expand attribute templates (for example, versions and triplets) and materialize one or more external repositories from single-file downloads. Each expansion produces a repository that you can reference via `use_repo`.

# Concepts

- Attribute templating: fields like `name`, `output`, and `urls` can contain `{variables}`.
- Triplets: each `triplet` (for example, `amd64-linux-gnu`) is split into `{cpu}`, `{os}`, and `{libc}`.
- Substitutions: provide your own key/value mappings; values may reference other substitutions.
- Built-ins: `download_utils` provides helpful variables such as `{executable.extension}`.

# Examples

## File download expanded by version and triplet

```python
download = use_extension("@download_utils//download/template:defs.bzl", "download_template")

download.file(
    name = "shfmt-{version}-{triplet}",
    lock = "//shfmt:lock.json",
    output = "shfmt{executable.extension}",
    substitutions = {
        "version": ["3.11.0"],
        "triplets": [
            "arm64-linux-gnu",
            "amd64-linux-gnu",
        ],
    },
    executable = True,
    links = {"shfmt{executable.extension}": "entrypoint"},
    urls = [
        "https://github.com/mvdan/sh/releases/download/v{version}/shfmt_v{version}_{os}_{cpu}",
    ],
)

use_repo(
    download,
    "shfmt-3.11.0-amd64-linux-gnu",
    "shfmt-3.11.0-arm64-linux-gnu",
)
```

## Lock and integrity workflow

- Generate or update the lock (URLs resolved; integrities initially blank):
  - Run: `bazel mod tidy`
- Populate integrities from downloaded artifacts:
```console
$ bazel run @download_utils//download/template/lock shfmt/lock.json
```

## Mirroring uploads

- Provide an upload destination and mirror binaries, then run:
```console
$ bazel run @download_utils//download/template/lock:upload shfmt/lock.json
```

# Notes
- Built-in substitutions are defined in `@download_utils//:MODULE.bazel` via `download.substitutions`.
- You can add more substitutions in your own modules.
- This tag downloads a single file (not an archive), which is useful for standalone binaries.
�
name�The templated name for each download repository. This needs to be unique across all download repositories that the extension creates. F
build(The template for the `BUILD.bazel` file.2:BUILD.tmpl.bazel�
commands�A collection of commands to run on the downloaded resources.

```py
download_archive(
    commands = {
        # Make a script executable in the unpacked archive
        "chmod": [
            "$(location @coreutils//:entrypoint)",
            "chmod",
            "u+x",
            "some-script.sh",
        ],
    },
    tools = [
        # A hermetically downloaded `coreutils` multi-call executable
        "@coreutils//:entrypoint",
    ],
)
```

It is **strongly** recommended to use hermetically provided executables in the commands.
 >

executable'Mark the downloaded file as executable.2False�
links�Creates links in the downloaded repository as `{"<target>": "<link>"}`

```py
download_archive(
    links = {
        "etc/test/fixture.txt": "fixture.txt",
    },
)
```

Depending on the platform, either symbolic or hard links are created.

2{}�
lock�A JSON lockfile that has URLs and sub-resource integrity (SRI) values for the values. The value can be set to `null` to allow uncached downloads. 9
output+The output filename for the downloaded file C
patches2Patches to apply to the repository after creation.2[]i
substitutionsTSubstitution values for the templates. All permutations will result in a repository. ?
timeout-Seconds before a command execution is killed.2600�
tools�Labels to hermetic executable files.

The labels often point to downloaded executables.

Each tool can be resolved in the `commands` attribute via the `$(location )` helper.
2[]�
uploads�Upload locations to mirror the download URLs. Use `bazel run @download_utils//download/template/lock --upload <lockfile>` to upload. Can use the same substitutions that a URL uses. For example, if a download URL is `https://foo.com/{version}/abc.tar.gz` and upload URL can use `{version}` such as `https://mirror.com/{version}/abc.tar.gz`2[]&
urlsURLs to download the file. �
�
name�The templated name for each download repository. This needs to be unique across all download repositories that the extension creates. H
F
build(The template for the `BUILD.bazel` file.2:BUILD.tmpl.bazel�
�
commands�A collection of commands to run on the downloaded resources.

```py
download_archive(
    commands = {
        # Make a script executable in the unpacked archive
        "chmod": [
            "$(location @coreutils//:entrypoint)",
            "chmod",
            "u+x",
            "some-script.sh",
        ],
    },
    tools = [
        # A hermetically downloaded `coreutils` multi-call executable
        "@coreutils//:entrypoint",
    ],
)
```

It is **strongly** recommended to use hermetically provided executables in the commands.
 @
>

executable'Mark the downloaded file as executable.2False�
�
links�Creates links in the downloaded repository as `{"<target>": "<link>"}`

```py
download_archive(
    links = {
        "etc/test/fixture.txt": "fixture.txt",
    },
)
```

Depending on the platform, either symbolic or hard links are created.

2{}�
�
lock�A JSON lockfile that has URLs and sub-resource integrity (SRI) values for the values. The value can be set to `null` to allow uncached downloads. ;
9
output+The output filename for the downloaded file E
C
patches2Patches to apply to the repository after creation.2[]k
i
substitutionsTSubstitution values for the templates. All permutations will result in a repository. A
?
timeout-Seconds before a command execution is killed.2600�
�
tools�Labels to hermetic executable files.

The labels often point to downloaded executables.

Each tool can be resolved in the `commands` attribute via the `$(location )` helper.
2[]�
�
uploads�Upload locations to mirror the download URLs. Use `bazel run @download_utils//download/template/lock --upload <lockfile>` to upload. Can use the same substitutions that a URL uses. For example, if a download URL is `https://foo.com/{version}/abc.tar.gz` and upload URL can use `{version}` such as `https://mirror.com/{version}/abc.tar.gz`2[](
&
urlsURLs to download the file. �<
�(
deb�Download and extract Debian packages using templated attributes.

Use this tag with the `download_template` module extension to expand attribute templates (for example, versions and triplets) and materialize one or more external repositories from .deb files. Each expansion produces a repository that you can reference via `use_repo`.

# Concepts

- Attribute templating: Fields like `name`, `urls`, and `strip_prefix` can contain `{variables}`.
- Triplets: Each `triplet` (for example, `amd64-linux-gnu`) is split into `{cpu}`, `{os}`, and `{libc}`.
- Substitutions: Provide your own key/value mappings; values may reference other substitutions.
- Built-ins: `download_utils` provides helpful variables such as `{rust.archive.basename}`.
- Data archive: This tag extracts the payload from the .deb (the `data.tar.*` archive).

# Examples

## Debian package expanded by version and triplet

```python
download = use_extension("@download_utils//download/template:defs.bzl", "download_template")
download.deb(
    name = "busybox-{version}-{cpu}-{os}",
    srcs = ["busybox"],
    links = {"busybox": "entrypoint"},
    lock = "//busybox:lock.json",
    strip_prefix = "usr/bin",
    substitutions = {
        "version": ["1.36.1"],
        "revision": ["6"],
        "triplet": [
            "arm64-linux-gnu",
            "amd64-linux-gnu",
        ],
    },
    uploads = [
        "https://gitlab.arm.com/api/v4/projects/bazel%2Fdownload_utils/packages/generic/busybox-static/{version}/busybox-static_{version}-{revision}_{cpu}.deb",
    ],
    urls = [
        "https://gitlab.arm.com/api/v4/projects/bazel%2Fdownload_utils/packages/generic/busybox-static/{version}/busybox-static_{version}-{revision}_{cpu}.deb",
        "https://snapshot-cloudflare.debian.org/archive/debian/20240210T223313Z/pool/main/b/busybox/busybox-static_{version}-{revision}_{cpu}.deb",
    ],
)
```

## Lock and integrity workflow

- Generate or update the lock (URLs resolved; integrities initially blank):
  - Run: `bazel mod tidy`
- Populate integrities from downloaded artifacts:
```console
$ bazel run @download_utils//download/template/lock busybox/lock.json
```
- Alternatively, fill integrities from upstream checksum files.

## Mirroring uploads

- Provide an upload destination and mirror binaries, then run:
```console
$ bazel run @download_utils//download/template/lock:upload busybox/lock.json
```

# Notes

- Built-in substitutions are defined in `@download_utils//:MODULE.bazel` via `download.substitutions`.
- You can add more substitutions in your own modules.
- This tag extracts only the data archive inside the .deb (`data.tar.*`).
�
name�The templated name for each download repository. This needs to be unique across all download repositories that the extension creates. �
buildzThe template for the `BUILD.bazel` file.

Receives a `{{srcs}}` substitution value for exposing the downloaded resources.
2:BUILD.tmpl.bazel�
commands�A collection of commands to run on the downloaded resources.

```py
download_archive(
    commands = {
        # Make a script executable in the unpacked archive
        "chmod": [
            "$(location @coreutils//:entrypoint)",
            "chmod",
            "u+x",
            "some-script.sh",
        ],
    },
    tools = [
        # A hermetically downloaded `coreutils` multi-call executable
        "@coreutils//:entrypoint",
    ],
)
```

It is **strongly** recommended to use hermetically provided executables in the commands.
 �
links�Creates links in the downloaded repository as `{"<target>": "<link>"}`

```py
download_archive(
    links = {
        "etc/test/fixture.txt": "fixture.txt",
    },
)
```

Depending on the platform, either symbolic or hard links are created.

2{}�
lock�A JSON lockfile that has URLs and sub-resource integrity (SRI) values for the values. The value can be set to `null` to allow uncached downloads. C
patches2Patches to apply to the repository after creation.2[]�
srcs�Globs for source files in the unpacked repository.

Will be provided to the `build` template file as a `{{srcs}}` substitution.

The default template will expose the sources as a `:srcs` `filegroup` target.
2["**"]G
strip_prefix1A prefix to remove from each file in the archive.2""i
substitutionsTSubstitution values for the templates. All permutations will result in a repository. ?
timeout-Seconds before a command execution is killed.2600�
tools�Labels to hermetic executable files.

The labels often point to downloaded executables.

Each tool can be resolved in the `commands` attribute via the `$(location )` helper.
2[]�
uploads�Upload locations to mirror the download URLs. Use `bazel run @download_utils//download/template/lock --upload <lockfile>` to upload. Can use the same substitutions that a URL uses. For example, if a download URL is `https://foo.com/{version}/abc.tar.gz` and upload URL can use `{version}` such as `https://mirror.com/{version}/abc.tar.gz`2[]�
urlsuURLs to download the file.

Multiple URLs can be provided to enable downloading from mirrors in the case of failure.
 �
�
name�The templated name for each download repository. This needs to be unique across all download repositories that the extension creates. �
�
buildzThe template for the `BUILD.bazel` file.

Receives a `{{srcs}}` substitution value for exposing the downloaded resources.
2:BUILD.tmpl.bazel�
�
commands�A collection of commands to run on the downloaded resources.

```py
download_archive(
    commands = {
        # Make a script executable in the unpacked archive
        "chmod": [
            "$(location @coreutils//:entrypoint)",
            "chmod",
            "u+x",
            "some-script.sh",
        ],
    },
    tools = [
        # A hermetically downloaded `coreutils` multi-call executable
        "@coreutils//:entrypoint",
    ],
)
```

It is **strongly** recommended to use hermetically provided executables in the commands.
 �
�
links�Creates links in the downloaded repository as `{"<target>": "<link>"}`

```py
download_archive(
    links = {
        "etc/test/fixture.txt": "fixture.txt",
    },
)
```

Depending on the platform, either symbolic or hard links are created.

2{}�
�
lock�A JSON lockfile that has URLs and sub-resource integrity (SRI) values for the values. The value can be set to `null` to allow uncached downloads. E
C
patches2Patches to apply to the repository after creation.2[]�
�
srcs�Globs for source files in the unpacked repository.

Will be provided to the `build` template file as a `{{srcs}}` substitution.

The default template will expose the sources as a `:srcs` `filegroup` target.
2["**"]I
G
strip_prefix1A prefix to remove from each file in the archive.2""k
i
substitutionsTSubstitution values for the templates. All permutations will result in a repository. A
?
timeout-Seconds before a command execution is killed.2600�
�
tools�Labels to hermetic executable files.

The labels often point to downloaded executables.

Each tool can be resolved in the `commands` attribute via the `$(location )` helper.
2[]�
�
uploads�Upload locations to mirror the download URLs. Use `bazel run @download_utils//download/template/lock --upload <lockfile>` to upload. Can use the same substitutions that a URL uses. For example, if a download URL is `https://foo.com/{version}/abc.tar.gz` and upload URL can use `{version}` such as `https://mirror.com/{version}/abc.tar.gz`2[]�
�
urlsuURLs to download the file.

Multiple URLs can be provided to enable downloading from mirrors in the case of failure.
 �
�

substitution�Provide a single templated substitution for `download_template` rules.

Define a `key` whose `value` is selected by evaluating a templated `match` string against a `select` map. The `match` string can reference other substitutions using `{variable}` and values in `select` may also contain `{variable}` placeholders.

# Example

```py
download = use_extension("//download/template:defs.bzl", "download_template")

# Derive a vendor name from the current OS
download.substitution(
    key = "rust.vendor",
    match = "{os}",
    select = {
        "macos": "apple",
        "windows": "pc",
        "//conditions:default": "unknown",
    },
)

# Use the substitution in a templated download
download.archive(
    name = "pkg-{version}-{triplet}",
    urls = ["https://example.com/pkg-{version}-{rust.vendor}-{cpu}.tar.xz"],
    lock = "//pkg:lock.json",
    substitutions = {
        "version": ["1.2.3"],
        "triplet": ["amd64-linux-gnu", "arm64-linux-gnu"],
    },
)
```

Consider `substitutions` to load multiple substitutions from JSON files.
6
key+The replacement key for the template value. J
match'A templated string to match in `select`2"//conditions:default"c
selectUA dictionary that matches `match` to provide a value. Can use replacements in values.
 8
6
key+The replacement key for the template value. L
J
match'A templated string to match in `select`2"//conditions:default"e
c
selectUA dictionary that matches `match` to provide a value. Can use replacements in values.
 �
�
substitutions�Provide multiple substitutions for templated downloads from JSON files.

Use this tag with the `download_template` module extension to load one or more JSON files that define substitution values used by templated attributes (for example `{version}`, `{triplet}`, `{cpu}`, `{os}`, `{libc}`).

# Example

```py
download = use_extension("//download/template:defs.bzl", "download_template")
download.substitutions(
    srcs = [
        "//download/template:rust.cpu.json",
        "//download/template:rust.vendor.json",
    ],
)
```

# JSON schema

Each JSON file contains a map from substitution key to either:
- A string value, used as the default:
  ```json
  { "key": "value" }
  ```
- A single-entry map of match -> select, where `select` is a map of cases:
  ```json
  { "key": { "{variable}": { "case1": "value1", "//conditions:default": "fallback" } } }
  ```

# JSON
```json
{
  "rust.vendor": {
    "{os}": {
      "macos": "apple",
      "windows": "pc",
      "//conditions:default": "unknown"
    }
  },
  "rust.os": {
    "//conditions:default": "{os}"
  }
}
```

# Notes
- The match string (for example, `"{os}"`) and `select` values may include other substitutions like `"{cpu}"` or `"{libc}"`.
- If a value is a plain string, it is treated as `select = {"//conditions:default": "<value>"}`.
- Substitutions are resolved iteratively; unresolved values depending on yet-to-be-defined keys are retried up to a recursion limit.
- Provide only one match entry per key; if multiple are needed, split into separate keys.
<
srcs.JSON files to read the substitution data from.2[]>
<
srcs.JSON files to read the substitution data from.2[]�
//download/template:archive.bzlr�
0
download_utilsdownload/templatearchive.bzl 
archivearchive
9@(
implementation_archive
CK
_�
//download/template:deb.bzlr|
,
download_utilsdownload/templatedeb.bzl
debdeb
58$
implementation_deb
;?
S�
//download/template:file.bzlr�
-
download_utilsdownload/templatefile.bzl
filefile
6:%
implementation_file
=B
V�
$//download/template:substitution.bzlrq
5
download_utilsdownload/templatesubstitution.bzl*
substitutionsubstitution
>J
L�
%//download/template:substitutions.bzlr�
6
download_utilsdownload/templatesubstitutions.bzl,
substitutionssubstitutions
?L
read_load
OT
^�"	DOC�Templated downloads module extension for archives, single files, and Debian packages.

# Overview

- Use this module extension via `use_extension` to declare templated downloads.
- Tags:
  - `archive`, `file`, `deb`: define artifacts to fetch.
  - `substitution`, `substitutions`: provide values for template variables.
- Attribute templating: fields like `name`, `urls`, and `strip_prefix` can contain `{variables}`.
- Triplets: a `triplet` like `amd64-linux-gnu` is split into `{cpu}`, `{os}`, and `{libc}`.
- Built-ins: `download_utils` provides helpful variables such as `{rust.archive.basename}`.

# Example

```python
download = use_extension("@download_utils//download/template:defs.bzl", "download_template")

# Provide substitutions from JSON files
download.substitutions(
    srcs = ["//download/template:rust.cpu.json"],
)

# Provide a direct substitution
download.substitution(
    key = "version",
    match = "//conditions:default",
    select = {"//conditions:default": "1.2.3"},
)

# Define an archive download expanded by triplet
download.archive(
    name = "pkg-{version}-{triplet}",
    lock = "//pkg:lock.json",
    strip_prefix = "pkg-{version}",
    substitutions = {
        "triplet": ["amd64-linux-gnu", "arm64-linux-gnu"],
    },
    urls = [
        "https://example.com/pkg-{version}-{rust.archive.basename}",
    ],
)

# Make the generated repositories available
use_repo(
    download,
    "pkg-1.2.3-amd64-linux-gnu",
    "pkg-1.2.3-arm64-linux-gnu",
)
```

# Lock and integrity workflow

- Generate or update the lock (URLs resolved; integrities initially blank):
  - Run: `bazel mod tidy`
- Populate integrities from downloaded artifacts:
  - Run: `bazel run @download_utils//download/template/lock <path/to/lock.json>`
- Optionally mirror binaries:
  - Run: `bazel run @download_utils//download/template/lock:upload <path/to/lock.json>`

# Notes

- Built-in substitutions are defined in `@download_utils//:MODULE.bazel` via `download.substitutions`.
- You can add more substitutions in your own modules with the `substitution` and `substitutions` tags.
- For post-processing commands in repository rules, prefer hermetic tools referenced via `$(location ...)`.
j��Templated downloads module extension for archives, single files, and Debian packages.

# Overview

- Use this module extension via `use_extension` to declare templated downloads.
- Tags:
  - `archive`, `file`, `deb`: define artifacts to fetch.
  - `substitution`, `substitutions`: provide values for template variables.
- Attribute templating: fields like `name`, `urls`, and `strip_prefix` can contain `{variables}`.
- Triplets: a `triplet` like `amd64-linux-gnu` is split into `{cpu}`, `{os}`, and `{libc}`.
- Built-ins: `download_utils` provides helpful variables such as `{rust.archive.basename}`.

# Example

```python
download = use_extension("@download_utils//download/template:defs.bzl", "download_template")

# Provide substitutions from JSON files
download.substitutions(
    srcs = ["//download/template:rust.cpu.json"],
)

# Provide a direct substitution
download.substitution(
    key = "version",
    match = "//conditions:default",
    select = {"//conditions:default": "1.2.3"},
)

# Define an archive download expanded by triplet
download.archive(
    name = "pkg-{version}-{triplet}",
    lock = "//pkg:lock.json",
    strip_prefix = "pkg-{version}",
    substitutions = {
        "triplet": ["amd64-linux-gnu", "arm64-linux-gnu"],
    },
    urls = [
        "https://example.com/pkg-{version}-{rust.archive.basename}",
    ],
)

# Make the generated repositories available
use_repo(
    download,
    "pkg-1.2.3-amd64-linux-gnu",
    "pkg-1.2.3-arm64-linux-gnu",
)
```

# Lock and integrity workflow

- Generate or update the lock (URLs resolved; integrities initially blank):
  - Run: `bazel mod tidy`
- Populate integrities from downloaded artifacts:
  - Run: `bazel run @download_utils//download/template/lock <path/to/lock.json>`
- Optionally mirror binaries:
  - Run: `bazel run @download_utils//download/template/lock:upload <path/to/lock.json>`

# Notes

- Built-in substitutions are defined in `@download_utils//:MODULE.bazel` via `download.substitutions`.
- You can add more substitutions in your own modules with the `substitution` and `substitutions` tags.
- For post-processing commands in repository rules, prefer hermetic tools referenced via `$(location ...)`.
�&
-
download_utilsdownload/templatefile.bzl�implementation*�
t
implementation	
ctx (
attrs (

data (2>
implementation,@@download_utils//download/template:file.bzl
JJ�
//download/file:repository.bzlrz
/
download_utilsdownload/filerepository.bzl
ATTRS_FILE
7<
file_rule
HM
W�
"//download/template:repository.bzlr�
3
download_utilsdownload/templaterepository.bzl
ATTRS_ATTRS
;A/
implementation_implementation
M\
p�"	DOC�Download single files using templated attributes.

Use this tag with the `download_template` module extension to expand attribute templates (for example, versions and triplets) and materialize one or more external repositories from single-file downloads. Each expansion produces a repository that you can reference via `use_repo`.

# Concepts

- Attribute templating: fields like `name`, `output`, and `urls` can contain `{variables}`.
- Triplets: each `triplet` (for example, `amd64-linux-gnu`) is split into `{cpu}`, `{os}`, and `{libc}`.
- Substitutions: provide your own key/value mappings; values may reference other substitutions.
- Built-ins: `download_utils` provides helpful variables such as `{executable.extension}`.

# Examples

## File download expanded by version and triplet

```python
download = use_extension("@download_utils//download/template:defs.bzl", "download_template")

download.file(
    name = "shfmt-{version}-{triplet}",
    lock = "//shfmt:lock.json",
    output = "shfmt{executable.extension}",
    substitutions = {
        "version": ["3.11.0"],
        "triplets": [
            "arm64-linux-gnu",
            "amd64-linux-gnu",
        ],
    },
    executable = True,
    links = {"shfmt{executable.extension}": "entrypoint"},
    urls = [
        "https://github.com/mvdan/sh/releases/download/v{version}/shfmt_v{version}_{os}_{cpu}",
    ],
)

use_repo(
    download,
    "shfmt-3.11.0-amd64-linux-gnu",
    "shfmt-3.11.0-arm64-linux-gnu",
)
```

## Lock and integrity workflow

- Generate or update the lock (URLs resolved; integrities initially blank):
  - Run: `bazel mod tidy`
- Populate integrities from downloaded artifacts:
```console
$ bazel run @download_utils//download/template/lock shfmt/lock.json
```

## Mirroring uploads

- Provide an upload destination and mirror binaries, then run:
```console
$ bazel run @download_utils//download/template/lock:upload shfmt/lock.json
```

# Notes
- Built-in substitutions are defined in `@download_utils//:MODULE.bazel` via `download.substitutions`.
- You can add more substitutions in your own modules.
- This tag downloads a single file (not an archive), which is useful for standalone binaries.
j��Download single files using templated attributes.

Use this tag with the `download_template` module extension to expand attribute templates (for example, versions and triplets) and materialize one or more external repositories from single-file downloads. Each expansion produces a repository that you can reference via `use_repo`.

# Concepts

- Attribute templating: fields like `name`, `output`, and `urls` can contain `{variables}`.
- Triplets: each `triplet` (for example, `amd64-linux-gnu`) is split into `{cpu}`, `{os}`, and `{libc}`.
- Substitutions: provide your own key/value mappings; values may reference other substitutions.
- Built-ins: `download_utils` provides helpful variables such as `{executable.extension}`.

# Examples

## File download expanded by version and triplet

```python
download = use_extension("@download_utils//download/template:defs.bzl", "download_template")

download.file(
    name = "shfmt-{version}-{triplet}",
    lock = "//shfmt:lock.json",
    output = "shfmt{executable.extension}",
    substitutions = {
        "version": ["3.11.0"],
        "triplets": [
            "arm64-linux-gnu",
            "amd64-linux-gnu",
        ],
    },
    executable = True,
    links = {"shfmt{executable.extension}": "entrypoint"},
    urls = [
        "https://github.com/mvdan/sh/releases/download/v{version}/shfmt_v{version}_{os}_{cpu}",
    ],
)

use_repo(
    download,
    "shfmt-3.11.0-amd64-linux-gnu",
    "shfmt-3.11.0-arm64-linux-gnu",
)
```

## Lock and integrity workflow

- Generate or update the lock (URLs resolved; integrities initially blank):
  - Run: `bazel mod tidy`
- Populate integrities from downloaded artifacts:
```console
$ bazel run @download_utils//download/template/lock shfmt/lock.json
```

## Mirroring uploads

- Provide an upload destination and mirror binaries, then run:
```console
$ bazel run @download_utils//download/template/lock:upload shfmt/lock.json
```

# Notes
- Built-in substitutions are defined in `@download_utils//:MODULE.bazel` via `download.substitutions`.
- You can add more substitutions in your own modules.
- This tag downloads a single file (not an archive), which is useful for standalone binaries.
�
7
download_utilsdownload/templateinterpolations.bzl�interpolations*w
g
interpolations
value (2H
interpolations6@@download_utils//download/template:interpolations.bzl
::]
//lib:sets.bzlrI

bazel_skyliblibsets.bzl
setssets
&*
,i
//lib:structs.bzlrR
 
bazel_skyliblibstructs.bzl 
structsstructs
)0
2a
//lib:types.bzlrL

bazel_skyliblib	types.bzl
typestypes
',
.�
/
download_utilsdownload/template
render.bzlwrender*k
[
render
value (

data (28
render.@@download_utils//download/template:render.bzl
99i
//lib:structs.bzlrR
 
bazel_skyliblibstructs.bzl 
structsstructs
)0
2a
//lib:types.bzlrL

bazel_skyliblib	types.bzl
typestypes
',
.�
3
download_utilsdownload/templaterepository.bzl�implementation*�
�
implementation	
ctx (

rule (
attrs (

data (2D
implementation2@@download_utils//download/template:repository.bzl
eei
//lib:structs.bzlrR
 
bazel_skyliblibstructs.bzl 
structsstructs
)0
2a
//lib:types.bzlrL

bazel_skyliblib	types.bzl
typestypes
',
.�
&//download/template:interpolations.bzlrx
7
download_utilsdownload/templateinterpolations.bzl/
interpolations_interpolations
?N
b�
//download/template:render.bzlr_
/
download_utilsdownload/template
render.bzl
renderrender
8>
@�
%//download/template:substitutions.bzlrh
6
download_utilsdownload/templatesubstitutions.bzl 
resolveresolve
?F
H�
5
download_utilsdownload/templatesubstitution.bzl�resolve*�
�
resolve
substitution (
substitutionsstruct()(:
no_match_error&"No match found for `{key}`: {select}"(6
no_key_error$"No substitution for {key}: {value}"(2?
resolve4@@download_utils//download/template:substitution.bzl
��i
//lib:structs.bzlrR
 
bazel_skyliblibstructs.bzl 
structsstructs
)0
2a
//lib:types.bzlrL

bazel_skyliblib	types.bzl
typestypes
',
.�	DOC�Provide a single templated substitution for `download_template` rules.

Define a `key` whose `value` is selected by evaluating a templated `match` string against a `select` map. The `match` string can reference other substitutions using `{variable}` and values in `select` may also contain `{variable}` placeholders.

# Example

```py
download = use_extension("//download/template:defs.bzl", "download_template")

# Derive a vendor name from the current OS
download.substitution(
    key = "rust.vendor",
    match = "{os}",
    select = {
        "macos": "apple",
        "windows": "pc",
        "//conditions:default": "unknown",
    },
)

# Use the substitution in a templated download
download.archive(
    name = "pkg-{version}-{triplet}",
    urls = ["https://example.com/pkg-{version}-{rust.vendor}-{cpu}.tar.xz"],
    lock = "//pkg:lock.json",
    substitutions = {
        "version": ["1.2.3"],
        "triplet": ["amd64-linux-gnu", "arm64-linux-gnu"],
    },
)
```

Consider `substitutions` to load multiple substitutions from JSON files.
j��Provide a single templated substitution for `download_template` rules.

Define a `key` whose `value` is selected by evaluating a templated `match` string against a `select` map. The `match` string can reference other substitutions using `{variable}` and values in `select` may also contain `{variable}` placeholders.

# Example

```py
download = use_extension("//download/template:defs.bzl", "download_template")

# Derive a vendor name from the current OS
download.substitution(
    key = "rust.vendor",
    match = "{os}",
    select = {
        "macos": "apple",
        "windows": "pc",
        "//conditions:default": "unknown",
    },
)

# Use the substitution in a templated download
download.archive(
    name = "pkg-{version}-{triplet}",
    urls = ["https://example.com/pkg-{version}-{rust.vendor}-{cpu}.tar.xz"],
    lock = "//pkg:lock.json",
    substitutions = {
        "version": ["1.2.3"],
        "triplet": ["amd64-linux-gnu", "arm64-linux-gnu"],
    },
)
```

Consider `substitutions` to load multiple substitutions from JSON files.
�
6
download_utilsdownload/templatesubstitutions.bzlvread*l
\
read	
ctx (

srcs (2=
read5@@download_utils//download/template:substitutions.bzl
JJ�resolve*�
�
resolve
iterable (
substitutions (
interpolations (:
no_match_error&"No match found for `{key}`: {select}"(2@
resolve5@@download_utils//download/template:substitutions.bzl
i
//lib:structs.bzlrR
 
bazel_skyliblibstructs.bzl 
structsstructs
)0
2a
//lib:types.bzlrL

bazel_skyliblib	types.bzl
typestypes
',
.�
&//download/template:interpolations.bzlrx
7
download_utilsdownload/templateinterpolations.bzl/
interpolations_interpolations
?N
b�
$//download/template:substitution.bzlrh
5
download_utilsdownload/templatesubstitution.bzl!
resolve_resolve
=E
R�	DOC�Provide multiple substitutions for templated downloads from JSON files.

Use this tag with the `download_template` module extension to load one or more JSON files that define substitution values used by templated attributes (for example `{version}`, `{triplet}`, `{cpu}`, `{os}`, `{libc}`).

# Example

```py
download = use_extension("//download/template:defs.bzl", "download_template")
download.substitutions(
    srcs = [
        "//download/template:rust.cpu.json",
        "//download/template:rust.vendor.json",
    ],
)
```

# JSON schema

Each JSON file contains a map from substitution key to either:
- A string value, used as the default:
  ```json
  { "key": "value" }
  ```
- A single-entry map of match -> select, where `select` is a map of cases:
  ```json
  { "key": { "{variable}": { "case1": "value1", "//conditions:default": "fallback" } } }
  ```

# JSON
```json
{
  "rust.vendor": {
    "{os}": {
      "macos": "apple",
      "windows": "pc",
      "//conditions:default": "unknown"
    }
  },
  "rust.os": {
    "//conditions:default": "{os}"
  }
}
```

# Notes
- The match string (for example, `"{os}"`) and `select` values may include other substitutions like `"{cpu}"` or `"{libc}"`.
- If a value is a plain string, it is treated as `select = {"//conditions:default": "<value>"}`.
- Substitutions are resolved iteratively; unresolved values depending on yet-to-be-defined keys are retried up to a recursion limit.
- Provide only one match entry per key; if multiple are needed, split into separate keys.
j��Provide multiple substitutions for templated downloads from JSON files.

Use this tag with the `download_template` module extension to load one or more JSON files that define substitution values used by templated attributes (for example `{version}`, `{triplet}`, `{cpu}`, `{os}`, `{libc}`).

# Example

```py
download = use_extension("//download/template:defs.bzl", "download_template")
download.substitutions(
    srcs = [
        "//download/template:rust.cpu.json",
        "//download/template:rust.vendor.json",
    ],
)
```

# JSON schema

Each JSON file contains a map from substitution key to either:
- A string value, used as the default:
  ```json
  { "key": "value" }
  ```
- A single-entry map of match -> select, where `select` is a map of cases:
  ```json
  { "key": { "{variable}": { "case1": "value1", "//conditions:default": "fallback" } } }
  ```

# JSON
```json
{
  "rust.vendor": {
    "{os}": {
      "macos": "apple",
      "windows": "pc",
      "//conditions:default": "unknown"
    }
  },
  "rust.os": {
    "//conditions:default": "{os}"
  }
}
```

# Notes
- The match string (for example, `"{os}"`) and `select` values may include other substitutions like `"{cpu}"` or `"{libc}"`.
- If a value is a plain string, it is treated as `select = {"//conditions:default": "<value>"}`.
- Substitutions are resolved iteratively; unresolved values depending on yet-to-be-defined keys are retried up to a recursion limit.
- Provide only one match entry per key; if multiple are needed, split into separate keys.
�
 
download_utilslib	build.bzl�buildJA mixin for `download` repository rules that patches files after download.*�
�
build,
rctx The download repository context. (JA mixin for `download` repository rules that patches files after download."
A map of canonical arguments2(
build@@download_utils//lib:build.bzl
�
#
download_utilslibcommands.bzl*�ModuleInfo request error: invalid argument: Traceback (most recent call last):
	File "external/download_utils/lib/separator.bzl", line 3, column 73, in <toplevel>
		SEPARATOR = Label("@separator").workspace_name.removesuffix("separator")[-1]
Error: index out of range (index is -1, but sequence has 0 elements)�
#
download_utilslibdownload.bzl�download(A mixin for `download` repository rules.*�
�
download,
rctx The download repository context. ((A mixin for `download` repository rules."
A map of canonical arguments2.
download"@@download_utils//lib:download.bzl
�
!//tools/build_defs/repo:utils.bzlr�
/
bazel_toolstools/build_defs/repo	utils.bzl0
read_user_netrcread_user_netrc
8G$
	use_netrc	use_netrc
KT
Vs
//lib:workspace.bzlrZ
$
download_utilslibworkspace.bzl$
	workspace	workspace
-6
8�
/
download_utilslibdownload_and_extract.bzl�download_and_extract(A mixin for `download` repository rules.*�
�
download_and_extract,
rctx The download repository context. (.
	extensionThe extension of the download (E
nested5A mutually exclusive set of nested archives to unpack()((A mixin for `download` repository rules."
A map of canonical arguments2F
download_and_extract.@@download_utils//lib:download_and_extract.bzl
((�
!//tools/build_defs/repo:utils.bzlr�
/
bazel_toolstools/build_defs/repo	utils.bzl0
read_user_netrcread_user_netrc
8G$
	use_netrc	use_netrc
KT
Vs
//lib:workspace.bzlrZ
$
download_utilslibworkspace.bzl$
	workspace	workspace
-6
8�

download_utilslibid.bzl�idKRetrives the default canonical ID for `download` or `download_and_extract`.*�
�
id,
rctx The download repository context. (
urlsThe download URLS (KRetrives the default canonical ID for `download` or `download_and_extract`."
A canonical ID to use2"
id@@download_utils//lib:id.bzl
�
!//tools/build_defs/repo:cache.bzlr�
/
bazel_toolstools/build_defs/repo	cache.bzlB
get_default_canonical_idget_default_canonical_id
8P
R�
 
download_utilslib	links.bzl�links;A mixin for `download` repository rules that creates links.*�
�
links,
rctx The download repository context. (;A mixin for `download` repository rules that creates links."
A map of canonical arguments2(
links@@download_utils//lib:links.bzl
�
#
download_utilslibmetadata.bzl�metadata5Generate metadata files based on templates passed in.*�
�
metadata,
rctx The download repository context. (.
	canonicalThe final canonical arguments (5Generate metadata files based on templates passed in."
A map of canonical arguments2.
metadata"@@download_utils//lib:metadata.bzl
%%k
//lib:workspace.bzlrR
$
download_utilslibworkspace.bzl
writewrite
-2
4�
 
download_utilslib	patch.bzl�patchJA mixin for `download` repository rules that patches files after download.*�
�
patch,
rctx The download repository context. (JA mixin for `download` repository rules that patches files after download."
A map of canonical arguments2(
patch@@download_utils//lib:patch.bzl


�
$
download_utilslibseparator.bzl*�ModuleInfo request error: invalid argument: Traceback (most recent call last):
	File "external/download_utils/lib/separator.bzl", line 3, column 73, in <toplevel>
		SEPARATOR = Label("@separator").workspace_name.removesuffix("separator")[-1]
Error: index out of range (index is -1, but sequence has 0 elements)�
$
download_utilslibworkspace.bzl�	workspace.Retrieve the `%workspace%` replacement string.*�
�
	workspace,
rctx The download repository context. (.Retrieve the `%workspace%` replacement string.";
9A string to use as replacement for `%workspace%` in URIS.20
	workspace#@@download_utils//lib:workspace.bzl
�writeIGenerate a `WORKSPACE` file that is stamped with the canonical arguments.*�
�
write,
rctx The download repository context. (.
	canonicalThe final canonical arguments (IGenerate a `WORKSPACE` file that is stamped with the canonical arguments.2,
write#@@download_utils//lib:workspace.bzl
 