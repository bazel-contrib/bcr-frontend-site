�
=
	envoy_api!bazel/cc_proto_descriptor_librarybuilddefs.bzl�cc_proto_descriptor_library"�
�
cc_proto_descriptor_library*
nameA unique name for this target. 
deps*
	ProtoInfo2[]"[
cc_proto_descriptor_library<@@envoy_api//bazel/cc_proto_descriptor_library:builddefs.bzl
�#�#,
*
nameA unique name for this target. 

deps*
	ProtoInfo2[]�!cc_proto_descriptor_library_copts"�
�
!cc_proto_descriptor_library_copts*
nameA unique name for this target. 
copts2[]"a
!cc_proto_descriptor_library_copts<@@envoy_api//bazel/cc_proto_descriptor_library:builddefs.bzl
�)�),
*
nameA unique name for this target. 

copts2[]�'cc_proto_descriptor_library_aspect_impl*�
�
'cc_proto_descriptor_library_aspect_impl
target (	
ctx (2g
'cc_proto_descriptor_library_aspect_impl<@@envoy_api//bazel/cc_proto_descriptor_library:builddefs.bzl
���&cc_proto_descriptor_library_copts_impl*�
�
&cc_proto_descriptor_library_copts_impl	
ctx (2f
&cc_proto_descriptor_library_copts_impl<@@envoy_api//bazel/cc_proto_descriptor_library:builddefs.bzl
���use_cpp_toolchain*v
f
use_cpp_toolchain2Q
use_cpp_toolchain<@@envoy_api//bazel/cc_proto_descriptor_library:builddefs.bzl
�!CcProtoDescriptorLibraryCoptsInfo6Provides copts for cc proto descriptor library targets2�
�
!CcProtoDescriptorLibraryCoptsInfo6Provides copts for cc proto descriptor library targets0
copts'copts for cc_proto_descriptor_library()"a
!CcProtoDescriptorLibraryCoptsInfo<@@envoy_api//bazel/cc_proto_descriptor_library:builddefs.bzl
�-�-2
0
copts'copts for cc_proto_descriptor_library()�CcProtoDescriptorWrappedCcInfoProvider for cc_info for protos2�
�
CcProtoDescriptorWrappedCcInfoProvider for cc_info for protos
cc_info(Undocumented)"^
CcProtoDescriptorWrappedCcInfo<@@envoy_api//bazel/cc_proto_descriptor_library:builddefs.bzl
�*�*

cc_info(Undocumented)�GeneratedSrcsInfo&Provides generated headers and sources2�
�
GeneratedSrcsInfo&Provides generated headers and sources
srcslist of srcs
hdrslist of hdrs"
includeslist of extra includes"Q
GeneratedSrcsInfo<@@envoy_api//bazel/cc_proto_descriptor_library:builddefs.bzl
��

srcslist of srcs

hdrslist of hdrs$
"
includeslist of extra includes�"cc_proto_descriptor_library_aspect:�
�
"cc_proto_descriptor_library_aspectdeps"*
nameA unique name for this target. *b
"cc_proto_descriptor_library_aspect<@@envoy_api//bazel/cc_proto_descriptor_library:builddefs.bzl
�,�,,
*
nameA unique name for this target. a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.�
//bazel/common:proto_info.bzlr^
(
protobufbazel/commonproto_info.bzl$
	ProtoInfo	ProtoInfo
1:
<y
//cc/common:cc_common.bzlrZ
$
rules_cc	cc/commoncc_common.bzl$
	cc_common	cc_common
-6
8o
//cc/common:cc_info.bzlrR
"
rules_cc	cc/commoncc_info.bzl
CcInfoCcInfo
+1
3�
//tools/cpp:toolchain_utils.bzlru
-
bazel_tools	tools/cpptoolchain_utils.bzl6
find_cpp_toolchainfind_cpp_toolchain
6H
J`Public rules for using cc proto descriptor library with protos:
- cc_proto_descriptor_library()
|
(
	envoy_apibazelapi_build_system.bzl*PModuleInfo request error: invalid argument: cycle with @@rules_go//proto:def.bzl�
*
	envoy_apibazelenvoy_http_archive.bzl�envoy_http_archive*�
�
envoy_http_archive

name (
	locations (
location_nameNone(

kwargs(2?
envoy_http_archive)@@envoy_api//bazel:envoy_http_archive.bzl
*http_archive2http_archive�
 //tools/build_defs/repo:http.bzlrj
.
bazel_toolstools/build_defs/repohttp.bzl*
http_archivehttp_archive
7C
E�

"
	envoy_apibazelextensions.bzl�non_module_deps�
Extension for Envoy API dependencies not available in BCR.

This extension creates the following repositories:
- prometheus_metrics_model: Prometheus client model
- com_github_chrusty_protoc_gen_jsonschema: Proto to JSON schema compiler
- envoy_toolshed: Tooling and libraries for Envoy development

For WORKSPACE mode, call api_dependencies() directly from WORKSPACE.
This extension should only be used in MODULE.bazel files.
J�
�
non_module_deps�
Extension for Envoy API dependencies not available in BCR.

This extension creates the following repositories:
- prometheus_metrics_model: Prometheus client model
- com_github_chrusty_protoc_gen_jsonschema: Proto to JSON schema compiler
- envoy_toolshed: Tooling and libraries for Envoy development

For WORKSPACE mode, call api_dependencies() directly from WORKSPACE.
This extension should only be used in MODULE.bazel files.
"4
non_module_deps!@@envoy_api//bazel:extensions.bzl
##�
//bazel:repositories.bzlrh
$
	envoy_apibazelrepositories.bzl2
api_dependenciesapi_dependencies
-=
?�Non-BCR dependencies for Envoy Data Plane API.

This extension provides repositories that are not available in Bazel Central Registry (BCR).
�
%
	envoy_apibazelexternal_deps.bzl�load_repository_locations*�

load_repository_locations
repository_locations_spec (2A
load_repository_locations$@@envoy_api//bazel:external_deps.bzl
PP�
&//bazel:repository_locations_utils.bzlr�
2
	envoy_apibazelrepository_locations_utils.bzlN
load_repository_locations_specload_repository_locations_spec
;Y
[�	DEPENDENCY_ANNOTATIONSj�2�
cpe

extensions
implied_untracked_deps
project_desc
project_name
project_url
release_date
use_category
	version�	USE_CATEGORIESj�2�
api
build
controlplane
dataplane_core
dataplane_ext
observability_core
observability_ext
other
	test_only
docs

devtoolsN	 USE_CATEGORIES_WITH_CPE_OPTIONALj(2&
build
other
	test_only
api-
+
	envoy_apibazelexternal_proto_deps.bzl�p
$
	envoy_apibazelrepositories.bzl�api_dependencies*n
^
api_dependencies
bzlmodFalse(27
api_dependencies#@@envoy_api//bazel:repositories.bzl
�external_http_archive*�
m
external_http_archive

name (

kwargs(2<
external_http_archive#@@envoy_api//bazel:repositories.bzl
*envoy_http_archive�
//bazel:envoy_http_archive.bzlrr
*
	envoy_apibazelenvoy_http_archive.bzl6
envoy_http_archiveenvoy_http_archive
3E
G�
//bazel:external_deps.bzlr{
%
	envoy_apibazelexternal_deps.bzlD
load_repository_locationsload_repository_locations
.G
I�
 //bazel:repository_locations.bzlr�
,
	envoy_apibazelrepository_locations.bzlD
REPOSITORY_LOCATIONS_SPECREPOSITORY_LOCATIONS_SPEC
5N
P�	PROMETHEUSMETRICS_BUILD_CONTENT�
load("@envoy_api//bazel:api_build_system.bzl", "api_cc_py_proto_library")
load("@io_bazel_rules_go//proto:def.bzl", "go_proto_library")

api_cc_py_proto_library(
    name = "client_model",
    srcs = [
        "io/prometheus/client/metrics.proto",
    ],
    visibility = ["//visibility:public"],
)

go_proto_library(
    name = "client_model_go_proto",
    importpath = "github.com/prometheus/client_model/go",
    proto = ":client_model",
    visibility = ["//visibility:public"],
)
j��
load("@envoy_api//bazel:api_build_system.bzl", "api_cc_py_proto_library")
load("@io_bazel_rules_go//proto:def.bzl", "go_proto_library")

api_cc_py_proto_library(
    name = "client_model",
    srcs = [
        "io/prometheus/client/metrics.proto",
    ],
    visibility = ["//visibility:public"],
)

go_proto_library(
    name = "client_model_go_proto",
    importpath = "github.com/prometheus/client_model/go",
    proto = ":client_model",
    visibility = ["//visibility:public"],
)
�	ZIPKINAPI_BUILD_CONTENT�

load("@envoy_api//bazel:api_build_system.bzl", "api_cc_py_proto_library")
load("@io_bazel_rules_go//proto:def.bzl", "go_proto_library")

api_cc_py_proto_library(
    name = "zipkin",
    srcs = [
        "zipkin-jsonv2.proto",
        "zipkin.proto",
    ],
    visibility = ["//visibility:public"],
)

go_proto_library(
    name = "zipkin_go_proto",
    proto = ":zipkin",
    visibility = ["//visibility:public"],
)
j��

load("@envoy_api//bazel:api_build_system.bzl", "api_cc_py_proto_library")
load("@io_bazel_rules_go//proto:def.bzl", "go_proto_library")

api_cc_py_proto_library(
    name = "zipkin",
    srcs = [
        "zipkin-jsonv2.proto",
        "zipkin.proto",
    ],
    visibility = ["//visibility:public"],
)

go_proto_library(
    name = "zipkin_go_proto",
    proto = ":zipkin",
    visibility = ["//visibility:public"],
)
�[	OPENTELEMETRY_BUILD_CONTENT�-
load("@com_github_grpc_grpc//bazel:cc_grpc_library.bzl", "cc_grpc_library")
load("@com_github_grpc_grpc//bazel:python_rules.bzl", "py_proto_library", "py_grpc_library")
load("@com_google_protobuf//bazel:cc_proto_library.bzl", "cc_proto_library")
load("@com_google_protobuf//bazel:proto_library.bzl", "proto_library")
load("@io_bazel_rules_go//proto:def.bzl", "go_proto_library", "go_grpc_library")

package(default_visibility = ["//visibility:public"])

proto_library(
    name = "common_proto",
    srcs = [
        "opentelemetry/proto/common/v1/common.proto",
    ],
)

cc_proto_library(
    name = "common_proto_cc",
    deps = [":common_proto"],
)

py_proto_library(
    name = "common_proto_py",
    deps = [":common_proto"],
)

go_proto_library(
    name = "common_proto_go",
    importpath = "go.opentelemetry.io/proto/otlp/common/v1",
    protos = [":common_proto"],
)

proto_library(
    name = "logs_proto",
    srcs = [
        "opentelemetry/proto/logs/v1/logs.proto",
    ],
    deps = [
        ":common_proto",
        ":resource_proto",
    ],
)

cc_proto_library(
    name = "logs_proto_cc",
    deps = [":logs_proto"],
)

py_proto_library(
    name = "logs_proto_py",
    deps = [":logs_proto"],
)

go_proto_library(
    name = "logs_proto_go",
    importpath = "go.opentelemetry.io/proto/otlp/logs/v1",
    protos = [":logs_proto"],
    deps = [
        ":common_proto_go",
        ":resource_proto_go",
    ],
)

proto_library(
    name = "logs_service_proto",
    srcs = [
        "opentelemetry/proto/collector/logs/v1/logs_service.proto",
    ],
    deps = [
        ":logs_proto",
    ],
)

cc_proto_library(
    name = "logs_service_proto_cc",
    deps = [":logs_service_proto"],
)

cc_grpc_library(
    name = "logs_service_grpc_cc",
    srcs = [":logs_service_proto"],
    generate_mocks = True,
    grpc_only = True,
    deps = [":logs_service_proto_cc"],
)

py_proto_library(
    name = "logs_service_proto_py",
    deps = [":logs_service_proto"],
)

py_grpc_library(
    name = "logs_service_grpc_py",
    srcs = [":logs_service_proto"],
    deps = [":logs_service_proto_py"],
)

go_grpc_library(
    name = "logs_service_grpc_go",
    protos = [":logs_service_proto"],
    importpath = "go.opentelemetry.io/proto/otlp/logs/v1",
    embed = [
        ":logs_proto_go",
    ],
)

proto_library(
    name = "metrics_proto",
    srcs = [
        "opentelemetry/proto/metrics/v1/metrics.proto",
    ],
    deps = [
        ":common_proto",
        ":resource_proto",
    ],
)

cc_proto_library(
    name = "metrics_proto_cc",
    deps = [":metrics_proto"],
)

py_proto_library(
    name = "metrics_proto_py",
    deps = [":metrics_proto"],
)

go_proto_library(
    name = "metrics_proto_go",
    importpath = "go.opentelemetry.io/proto/otlp/metrics/v1",
    protos = [":metrics_proto"],
    deps = [
        ":common_proto_go",
        ":resource_proto_go",
    ],
)

proto_library(
    name = "metrics_service_proto",
    srcs = [
        "opentelemetry/proto/collector/metrics/v1/metrics_service.proto",
    ],
    deps = [
        ":metrics_proto",
    ],
)

cc_proto_library(
    name = "metrics_service_proto_cc",
    deps = [":metrics_service_proto"],
)

cc_grpc_library(
    name = "metrics_service_grpc_cc",
    srcs = [":metrics_service_proto"],
    generate_mocks = True,
    grpc_only = True,
    deps = [":metrics_service_proto_cc"],
)

py_proto_library(
    name = "metrics_service_proto_py",
    deps = [":metrics_service_proto"],
)

py_grpc_library(
    name = "metrics_service_grpc_py",
    srcs = [":metrics_service_proto"],
    deps = [":metrics_service_proto_py"],
)

go_grpc_library(
    name = "metrics_service_grpc_go",
    protos = [":metrics_service_proto"],
    importpath = "go.opentelemetry.io/proto/otlp/metrics/v1",
    embed = [
        ":metrics_proto_go",
    ],
)

proto_library(
    name = "resource_proto",
    srcs = [
        "opentelemetry/proto/resource/v1/resource.proto",
    ],
    deps = [
        ":common_proto",
    ],
)

cc_proto_library(
    name = "resource_proto_cc",
    deps = [":resource_proto"],
)

py_proto_library(
    name = "resource_proto_py",
    deps = [":resource_proto"],
)

go_proto_library(
    name = "resource_proto_go",
    importpath = "go.opentelemetry.io/proto/otlp/resource/v1",
    protos = [":resource_proto"],
    deps = [
        ":common_proto_go",
    ],
)

proto_library(
    name = "trace_proto",
    srcs = [
        "opentelemetry/proto/trace/v1/trace.proto",
    ],
    deps = [
        ":common_proto",
        ":resource_proto",
    ],
)

cc_proto_library(
    name = "trace_proto_cc",
    deps = [":trace_proto"],
)

py_proto_library(
    name = "trace_proto_py",
    deps = [":trace_proto"],
)

go_proto_library(
    name = "trace_proto_go",
    importpath = "go.opentelemetry.io/proto/otlp/trace/v1",
    protos = [":trace_proto"],
    deps = [
        ":common_proto_go",
        ":resource_proto_go",
    ],
)

proto_library(
    name = "trace_service_proto",
    srcs = [
        "opentelemetry/proto/collector/trace/v1/trace_service.proto",
    ],
    deps = [
        ":trace_proto",
    ],
)

cc_proto_library(
    name = "trace_service_proto_cc",
    deps = [":trace_service_proto"],
)

cc_grpc_library(
    name = "trace_service_grpc_cc",
    srcs = [":trace_service_proto"],
    generate_mocks = True,
    grpc_only = True,
    deps = [":trace_service_proto_cc"],
)

py_proto_library(
    name = "trace_service_proto_py",
    deps = [":trace_service_proto"],
)

py_grpc_library(
    name = "trace_service_grpc_py",
    srcs = [":trace_service_proto"],
    deps = [":trace_service_proto_py"],
)

go_grpc_library(
    name = "trace_service_grpc_go",
    protos = [":trace_service_proto"],
    importpath = "go.opentelemetry.io/proto/otlp/trace/v1",
    embed = [
        ":trace_proto_go",
    ],
)
j�-�-
load("@com_github_grpc_grpc//bazel:cc_grpc_library.bzl", "cc_grpc_library")
load("@com_github_grpc_grpc//bazel:python_rules.bzl", "py_proto_library", "py_grpc_library")
load("@com_google_protobuf//bazel:cc_proto_library.bzl", "cc_proto_library")
load("@com_google_protobuf//bazel:proto_library.bzl", "proto_library")
load("@io_bazel_rules_go//proto:def.bzl", "go_proto_library", "go_grpc_library")

package(default_visibility = ["//visibility:public"])

proto_library(
    name = "common_proto",
    srcs = [
        "opentelemetry/proto/common/v1/common.proto",
    ],
)

cc_proto_library(
    name = "common_proto_cc",
    deps = [":common_proto"],
)

py_proto_library(
    name = "common_proto_py",
    deps = [":common_proto"],
)

go_proto_library(
    name = "common_proto_go",
    importpath = "go.opentelemetry.io/proto/otlp/common/v1",
    protos = [":common_proto"],
)

proto_library(
    name = "logs_proto",
    srcs = [
        "opentelemetry/proto/logs/v1/logs.proto",
    ],
    deps = [
        ":common_proto",
        ":resource_proto",
    ],
)

cc_proto_library(
    name = "logs_proto_cc",
    deps = [":logs_proto"],
)

py_proto_library(
    name = "logs_proto_py",
    deps = [":logs_proto"],
)

go_proto_library(
    name = "logs_proto_go",
    importpath = "go.opentelemetry.io/proto/otlp/logs/v1",
    protos = [":logs_proto"],
    deps = [
        ":common_proto_go",
        ":resource_proto_go",
    ],
)

proto_library(
    name = "logs_service_proto",
    srcs = [
        "opentelemetry/proto/collector/logs/v1/logs_service.proto",
    ],
    deps = [
        ":logs_proto",
    ],
)

cc_proto_library(
    name = "logs_service_proto_cc",
    deps = [":logs_service_proto"],
)

cc_grpc_library(
    name = "logs_service_grpc_cc",
    srcs = [":logs_service_proto"],
    generate_mocks = True,
    grpc_only = True,
    deps = [":logs_service_proto_cc"],
)

py_proto_library(
    name = "logs_service_proto_py",
    deps = [":logs_service_proto"],
)

py_grpc_library(
    name = "logs_service_grpc_py",
    srcs = [":logs_service_proto"],
    deps = [":logs_service_proto_py"],
)

go_grpc_library(
    name = "logs_service_grpc_go",
    protos = [":logs_service_proto"],
    importpath = "go.opentelemetry.io/proto/otlp/logs/v1",
    embed = [
        ":logs_proto_go",
    ],
)

proto_library(
    name = "metrics_proto",
    srcs = [
        "opentelemetry/proto/metrics/v1/metrics.proto",
    ],
    deps = [
        ":common_proto",
        ":resource_proto",
    ],
)

cc_proto_library(
    name = "metrics_proto_cc",
    deps = [":metrics_proto"],
)

py_proto_library(
    name = "metrics_proto_py",
    deps = [":metrics_proto"],
)

go_proto_library(
    name = "metrics_proto_go",
    importpath = "go.opentelemetry.io/proto/otlp/metrics/v1",
    protos = [":metrics_proto"],
    deps = [
        ":common_proto_go",
        ":resource_proto_go",
    ],
)

proto_library(
    name = "metrics_service_proto",
    srcs = [
        "opentelemetry/proto/collector/metrics/v1/metrics_service.proto",
    ],
    deps = [
        ":metrics_proto",
    ],
)

cc_proto_library(
    name = "metrics_service_proto_cc",
    deps = [":metrics_service_proto"],
)

cc_grpc_library(
    name = "metrics_service_grpc_cc",
    srcs = [":metrics_service_proto"],
    generate_mocks = True,
    grpc_only = True,
    deps = [":metrics_service_proto_cc"],
)

py_proto_library(
    name = "metrics_service_proto_py",
    deps = [":metrics_service_proto"],
)

py_grpc_library(
    name = "metrics_service_grpc_py",
    srcs = [":metrics_service_proto"],
    deps = [":metrics_service_proto_py"],
)

go_grpc_library(
    name = "metrics_service_grpc_go",
    protos = [":metrics_service_proto"],
    importpath = "go.opentelemetry.io/proto/otlp/metrics/v1",
    embed = [
        ":metrics_proto_go",
    ],
)

proto_library(
    name = "resource_proto",
    srcs = [
        "opentelemetry/proto/resource/v1/resource.proto",
    ],
    deps = [
        ":common_proto",
    ],
)

cc_proto_library(
    name = "resource_proto_cc",
    deps = [":resource_proto"],
)

py_proto_library(
    name = "resource_proto_py",
    deps = [":resource_proto"],
)

go_proto_library(
    name = "resource_proto_go",
    importpath = "go.opentelemetry.io/proto/otlp/resource/v1",
    protos = [":resource_proto"],
    deps = [
        ":common_proto_go",
    ],
)

proto_library(
    name = "trace_proto",
    srcs = [
        "opentelemetry/proto/trace/v1/trace.proto",
    ],
    deps = [
        ":common_proto",
        ":resource_proto",
    ],
)

cc_proto_library(
    name = "trace_proto_cc",
    deps = [":trace_proto"],
)

py_proto_library(
    name = "trace_proto_py",
    deps = [":trace_proto"],
)

go_proto_library(
    name = "trace_proto_go",
    importpath = "go.opentelemetry.io/proto/otlp/trace/v1",
    protos = [":trace_proto"],
    deps = [
        ":common_proto_go",
        ":resource_proto_go",
    ],
)

proto_library(
    name = "trace_service_proto",
    srcs = [
        "opentelemetry/proto/collector/trace/v1/trace_service.proto",
    ],
    deps = [
        ":trace_proto",
    ],
)

cc_proto_library(
    name = "trace_service_proto_cc",
    deps = [":trace_service_proto"],
)

cc_grpc_library(
    name = "trace_service_grpc_cc",
    srcs = [":trace_service_proto"],
    generate_mocks = True,
    grpc_only = True,
    deps = [":trace_service_proto_cc"],
)

py_proto_library(
    name = "trace_service_proto_py",
    deps = [":trace_service_proto"],
)

py_grpc_library(
    name = "trace_service_grpc_py",
    srcs = [":trace_service_proto"],
    deps = [":trace_service_proto_py"],
)

go_grpc_library(
    name = "trace_service_grpc_go",
    protos = [":trace_service_proto"],
    importpath = "go.opentelemetry.io/proto/otlp/trace/v1",
    embed = [
        ":trace_proto_go",
    ],
)
.
,
	envoy_apibazelrepository_locations.bzl�
2
	envoy_apibazelrepository_locations_utils.bzl�load_repository_locations_spec*�
�
load_repository_locations_spec
repository_locations_spec (2S
load_repository_locations_spec1@@envoy_api//bazel:repository_locations_utils.bzl
		{merge_dicts*j
Z
merge_dicts	
dicts(2@
merge_dicts1@@envoy_api//bazel:repository_locations_utils.bzl
 