�
=
	envoy_api!bazel/cc_proto_descriptor_librarybuilddefs.bzl�cc_proto_descriptor_library"�
�
cc_proto_descriptor_library*
nameA unique name for this target. 
deps*
	ProtoInfo2[]"[
cc_proto_descriptor_library<@@envoy_api//bazel/cc_proto_descriptor_library:builddefs.bzl
�#�#,
*
nameA unique name for this target. 

deps*
	ProtoInfo2[]�!cc_proto_descriptor_library_copts"�
�
!cc_proto_descriptor_library_copts*
nameA unique name for this target. 
copts2[]"a
!cc_proto_descriptor_library_copts<@@envoy_api//bazel/cc_proto_descriptor_library:builddefs.bzl
�)�),
*
nameA unique name for this target. 

copts2[]�'cc_proto_descriptor_library_aspect_impl*�
�
'cc_proto_descriptor_library_aspect_impl
target (	
ctx (2g
'cc_proto_descriptor_library_aspect_impl<@@envoy_api//bazel/cc_proto_descriptor_library:builddefs.bzl
���&cc_proto_descriptor_library_copts_impl*�
�
&cc_proto_descriptor_library_copts_impl	
ctx (2f
&cc_proto_descriptor_library_copts_impl<@@envoy_api//bazel/cc_proto_descriptor_library:builddefs.bzl
���use_cpp_toolchain*v
f
use_cpp_toolchain2Q
use_cpp_toolchain<@@envoy_api//bazel/cc_proto_descriptor_library:builddefs.bzl
�!CcProtoDescriptorLibraryCoptsInfo6Provides copts for cc proto descriptor library targets2�
�
!CcProtoDescriptorLibraryCoptsInfo6Provides copts for cc proto descriptor library targets0
copts'copts for cc_proto_descriptor_library()"a
!CcProtoDescriptorLibraryCoptsInfo<@@envoy_api//bazel/cc_proto_descriptor_library:builddefs.bzl
�-�-2
0
copts'copts for cc_proto_descriptor_library()�CcProtoDescriptorWrappedCcInfoProvider for cc_info for protos2�
�
CcProtoDescriptorWrappedCcInfoProvider for cc_info for protos
cc_info(Undocumented)"^
CcProtoDescriptorWrappedCcInfo<@@envoy_api//bazel/cc_proto_descriptor_library:builddefs.bzl
�*�*

cc_info(Undocumented)�GeneratedSrcsInfo&Provides generated headers and sources2�
�
GeneratedSrcsInfo&Provides generated headers and sources
srcslist of srcs
hdrslist of hdrs"
includeslist of extra includes"Q
GeneratedSrcsInfo<@@envoy_api//bazel/cc_proto_descriptor_library:builddefs.bzl
��

srcslist of srcs

hdrslist of hdrs$
"
includeslist of extra includes�"cc_proto_descriptor_library_aspect:�
�
"cc_proto_descriptor_library_aspectdeps"*
nameA unique name for this target. *b
"cc_proto_descriptor_library_aspect<@@envoy_api//bazel/cc_proto_descriptor_library:builddefs.bzl
�,�,,
*
nameA unique name for this target. a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.�
//toolchains:utils.bzlr�
'
envoy_toolshed
toolchains	utils.bzl6
get_proto_compilerget_proto_compiler
0B8
use_proto_toolchainuse_proto_toolchain
FY
[�
//bazel/common:proto_info.bzlr^
(
protobufbazel/commonproto_info.bzl$
	ProtoInfo	ProtoInfo
1:
<y
//cc/common:cc_common.bzlrZ
$
rules_cc	cc/commoncc_common.bzl$
	cc_common	cc_common
-6
8o
//cc/common:cc_info.bzlrR
"
rules_cc	cc/commoncc_info.bzl
CcInfoCcInfo
	+	1
		3�
//tools/cpp:toolchain_utils.bzlru
-
bazel_tools	tools/cpptoolchain_utils.bzl6
find_cpp_toolchainfind_cpp_toolchain
6H
J`Public rules for using cc proto descriptor library with protos:
- cc_proto_descriptor_library()
��
(
	envoy_apibazelapi_build_system.bzl��api_go_test�This builds a set of tests that can be run with `bazel test`.<br><br>
To run all tests in the workspace, and print output on failure (the
equivalent of `go test ./...`), run<br>
```
bazel test --test_output=errors //...
```<br><br>
To run a Go benchmark test, run<br>
```
bazel run //path/to:test -- -test.bench=.
```<br><br>
You can run specific tests by passing the `--test_filter=pattern
<test_filter_>` argument to Bazel. You can pass arguments to tests by passing
`--test_arg=arg <test_arg_>` arguments to Bazel, and you can set environment
variables in the test environment by passing
`--test_env=VAR=value <test_env_>`. You can terminate test execution after the first
failure by passing the `--test_runner_fast_fast <test_runner_fail_fast_>` argument
to Bazel. This is equivalent to passing `--test_arg=-failfast <test_arg_>`.<br><br>
To write structured testlog information to Bazel's `XML_OUTPUT_FILE`, tests
ran with `bazel test` execute using a wrapper. This functionality can be
disabled by setting `GO_TEST_WRAP=0` in the test environment. Additionally,
the testbinary can be invoked with `-test.v` by setting
`GO_TEST_WRAP_TESTV=1` in the test environment; this will result in the
`XML_OUTPUT_FILE` containing more granular data.<br><br>
***Note:*** To interoperate cleanly with old targets generated by [Gazelle], `name`
should be `go_default_test` for internal tests and
`go_default_xtest` for external tests. Gazelle now generates
the name  based on the last component of the path. For example, a test
in `//foo/bar` is named `bar_test`, and uses internal and external
sources.
"��
�I
api_go_test�This builds a set of tests that can be run with `bazel test`.<br><br>
To run all tests in the workspace, and print output on failure (the
equivalent of `go test ./...`), run<br>
```
bazel test --test_output=errors //...
```<br><br>
To run a Go benchmark test, run<br>
```
bazel run //path/to:test -- -test.bench=.
```<br><br>
You can run specific tests by passing the `--test_filter=pattern
<test_filter_>` argument to Bazel. You can pass arguments to tests by passing
`--test_arg=arg <test_arg_>` arguments to Bazel, and you can set environment
variables in the test environment by passing
`--test_env=VAR=value <test_env_>`. You can terminate test execution after the first
failure by passing the `--test_runner_fast_fast <test_runner_fail_fast_>` argument
to Bazel. This is equivalent to passing `--test_arg=-failfast <test_arg_>`.<br><br>
To write structured testlog information to Bazel's `XML_OUTPUT_FILE`, tests
ran with `bazel test` execute using a wrapper. This functionality can be
disabled by setting `GO_TEST_WRAP=0` in the test environment. Additionally,
the testbinary can be invoked with `-test.v` by setting
`GO_TEST_WRAP_TESTV=1` in the test environment; this will result in the
`XML_OUTPUT_FILE` containing more granular data.<br><br>
***Note:*** To interoperate cleanly with old targets generated by [Gazelle], `name`
should be `go_default_test` for internal tests and
`go_default_xtest` for external tests. Gazelle now generates
the name  based on the last component of the path. For example, a test
in `//foo/bar` is named `bar_test`, and uses internal and external
sources.
*
nameA unique name for this target. �
cdeps�The list of other libraries that the c code depends on.
This can be anything that would be allowed in [cc_library deps]
Only valid if `cgo` = `True`.
2[]�
cgo�
If `True`, the package may contain [cgo] code, and `srcs` may contain
C, C++, Objective-C, and Objective-C++ files and non-Go assembly files.
When cgo is enabled, these files will be compiled with the C/C++ toolchain
and included in the package. Note that this attribute does not force cgo
to be enabled. Cgo is enabled for non-cross-compiling builds when a C/C++
toolchain is configured.
2False�
	clinkopts�List of flags to add to the C link command.
Subject to ["Make variable"] substitution and [Bourne shell tokenization].
Only valid if `cgo` = `True`.
2[]�
copts�List of flags to add to the C compilation command.
Subject to ["Make variable"] substitution and [Bourne shell tokenization].
Only valid if `cgo` = `True`.
2[]�
cppopts�List of flags to add to the C/C++ preprocessor command.
Subject to ["Make variable"] substitution and [Bourne shell tokenization].
Only valid if `cgo` = `True`.
2[]�
cxxopts�List of flags to add to the C++ compilation command.
Subject to ["Make variable"] substitution and [Bourne shell tokenization].
Only valid if `cgo` = `True`.
2[]�
data�List of files needed by this rule at run-time. This may include data files
needed or other programs that may be executed. The [bazel] package may be
used to locate run files; they may appear in different places depending on the
operating system and environment. See [data dependencies] for more
information on data files.
2[]�
deps�List of Go libraries this test imports directly.
These may be go_library rules or compatible rules with the [GoLibrary] provider.
*
	GoLibrary2[]�
embed�List of Go libraries whose sources should be compiled together with this
package's sources. Labels listed here must name `go_library`,
`go_proto_library`, or other compatible targets with the [GoLibrary] and
[GoSource] providers. Embedded libraries must have the same `importpath` as
the embedding library. At most one embedded library may have `cgo = True`,
and the embedding library may not also have `cgo = True`. See [Embedding]
for more information.
*
	GoLibrary2[]�
	embedsrcs�The list of files that may be embedded into the compiled package using
`//go:embed` directives. All files must be in the same logical directory
or a subdirectory as source files. All source files containing `//go:embed`
directives must be in the same logical directory. It's okay to mix static and
generated source files and static and generated embeddable files.
2[]�
env�Environment variables to set for the test execution.
The values (but not keys) are subject to
[location expansion](https://docs.bazel.build/versions/main/skylark/macros.html) but not full
[make variable expansion](https://docs.bazel.build/versions/main/be/make-variables.html).

2{}U
env_inherit@Environment variables to inherit from the external environment.
2[]�
	gc_goopts�List of flags to add to the Go compilation command when using the gc compiler.
Subject to ["Make variable"] substitution and [Bourne shell tokenization].
2[]�
gc_linkopts�List of flags to add to the Go link command when using the gc compiler.
Subject to ["Make variable"] substitution and [Bourne shell tokenization].
2[]�
goarch�Forces a binary to be cross-compiled for a specific architecture. It's usually
better to control this on the command line with `--platforms`.

This disables cgo by default, since a cross-compiling C/C++ toolchain is
rarely available. To force cgo, set `pure` = `off`.

See [Cross compilation] for more information.
2"auto"�
goos�Forces a binary to be cross-compiled for a specific operating system. It's
usually better to control this on the command line with `--platforms`.

This disables cgo by default, since a cross-compiling C/C++ toolchain is
rarely available. To force cgo, set `pure` = `off`.

See [Cross compilation] for more information.
2"auto"v
gotagsfEnables a list of build tags when evaluating [build constraints]. Useful for
conditional compilation.
2[]�

importpath�The import path of this test. Tests can't actually be imported, but this
may be used by [go_path] and other tools to report the location of source
files. This may be inferred from embedded libraries.
2""�
linkmode�Determines how the binary should be built and linked. This accepts some of
the same values as `go build -buildmode` and works the same way.
<br><br>
<ul>
<li>`normal`: Builds a normal executable with position-dependent code.</li>
<li>`pie`: Builds a position-independent executable.</li>
<li>`plugin`: Builds a shared library that can be loaded as a Go plugin. Only supported on platforms that support plugins.</li>
<li>`c-shared`: Builds a shared library that can be linked into a C program.</li>
<li>`c-archive`: Builds an archive that can be linked into a C program.</li>
</ul>
2"normal"�
msan�Controls whether code is instrumented for memory sanitization. May be one of
`on`, `off`, or `auto`. Not available when cgo is
disabled. In most cases, it's better to control this on the command line with
`--@io_bazel_rules_go//go/config:msan`. See [mode attributes], specifically
[msan].
2"auto"�
pure�Controls whether cgo source code and dependencies are compiled and linked,
similar to setting `CGO_ENABLED`. May be one of `on`, `off`,
or `auto`. If `auto`, pure mode is enabled when no C/C++
toolchain is configured or when cross-compiling. It's usually better to
control this on the command line with
`--@io_bazel_rules_go//go/config:pure`. See [mode attributes], specifically
[pure].
2"auto"�
race�Controls whether code is instrumented for race detection. May be one of
`on`, `off`, or `auto`. Not available when cgo is
disabled. In most cases, it's better to control this on the command line with
`--@io_bazel_rules_go//go/config:race`. See [mode attributes], specifically
[race].
2"auto"�
rundir�A directory to cd to before the test is run.
           This should be a path relative to the root directory of the
           repository in which the test is defined, which can be the main or an
           external repository.

           The default behaviour is to change to the relative path
           corresponding to the test's package, which replicates the normal
           behaviour of `go test` so it is easy to write compatible tests.

           Setting it to `.` makes the test behave the normal way for a bazel
           test, except that the working directory is always that of the test's
           repository, which is not necessarily the main repository.

           Note: If runfile symlinks are disabled (such as on Windows by
           default), the test will run in the working directory set by Bazel,
           which is the subdirectory of the runfiles directory corresponding to
           the main repository.
2""�
srcs�The list of Go source files that are compiled to create the package.
Only `.go` and `.s` files are permitted, unless the `cgo`
attribute is set, in which case,
`.c .cc .cpp .cxx .h .hh .hpp .hxx .inc .m .mm`
files are also permitted. Files may be filtered at build time
using Go [build constraints].
2[]�
static�Controls whether a binary is statically linked. May be one of `on`,
`off`, or `auto`. Not available on all platforms or in all
modes. It's usually better to control this on the command line with
`--@io_bazel_rules_go//go/config:static`. See [mode attributes],
specifically [static].
2"auto"{
x_defskMap of defines to add to the go link command.
See [Defines and stamping] for examples of how to use these.

2{}
��,
*
nameA unique name for this target. �
�
cdeps�The list of other libraries that the c code depends on.
This can be anything that would be allowed in [cc_library deps]
Only valid if `cgo` = `True`.
2[]�
�
cgo�
If `True`, the package may contain [cgo] code, and `srcs` may contain
C, C++, Objective-C, and Objective-C++ files and non-Go assembly files.
When cgo is enabled, these files will be compiled with the C/C++ toolchain
and included in the package. Note that this attribute does not force cgo
to be enabled. Cgo is enabled for non-cross-compiling builds when a C/C++
toolchain is configured.
2False�
�
	clinkopts�List of flags to add to the C link command.
Subject to ["Make variable"] substitution and [Bourne shell tokenization].
Only valid if `cgo` = `True`.
2[]�
�
copts�List of flags to add to the C compilation command.
Subject to ["Make variable"] substitution and [Bourne shell tokenization].
Only valid if `cgo` = `True`.
2[]�
�
cppopts�List of flags to add to the C/C++ preprocessor command.
Subject to ["Make variable"] substitution and [Bourne shell tokenization].
Only valid if `cgo` = `True`.
2[]�
�
cxxopts�List of flags to add to the C++ compilation command.
Subject to ["Make variable"] substitution and [Bourne shell tokenization].
Only valid if `cgo` = `True`.
2[]�
�
data�List of files needed by this rule at run-time. This may include data files
needed or other programs that may be executed. The [bazel] package may be
used to locate run files; they may appear in different places depending on the
operating system and environment. See [data dependencies] for more
information on data files.
2[]�
�
deps�List of Go libraries this test imports directly.
These may be go_library rules or compatible rules with the [GoLibrary] provider.
*
	GoLibrary2[]�
�
embed�List of Go libraries whose sources should be compiled together with this
package's sources. Labels listed here must name `go_library`,
`go_proto_library`, or other compatible targets with the [GoLibrary] and
[GoSource] providers. Embedded libraries must have the same `importpath` as
the embedding library. At most one embedded library may have `cgo = True`,
and the embedding library may not also have `cgo = True`. See [Embedding]
for more information.
*
	GoLibrary2[]�
�
	embedsrcs�The list of files that may be embedded into the compiled package using
`//go:embed` directives. All files must be in the same logical directory
or a subdirectory as source files. All source files containing `//go:embed`
directives must be in the same logical directory. It's okay to mix static and
generated source files and static and generated embeddable files.
2[]�
�
env�Environment variables to set for the test execution.
The values (but not keys) are subject to
[location expansion](https://docs.bazel.build/versions/main/skylark/macros.html) but not full
[make variable expansion](https://docs.bazel.build/versions/main/be/make-variables.html).

2{}W
U
env_inherit@Environment variables to inherit from the external environment.
2[]�
�
	gc_goopts�List of flags to add to the Go compilation command when using the gc compiler.
Subject to ["Make variable"] substitution and [Bourne shell tokenization].
2[]�
�
gc_linkopts�List of flags to add to the Go link command when using the gc compiler.
Subject to ["Make variable"] substitution and [Bourne shell tokenization].
2[]�
�
goarch�Forces a binary to be cross-compiled for a specific architecture. It's usually
better to control this on the command line with `--platforms`.

This disables cgo by default, since a cross-compiling C/C++ toolchain is
rarely available. To force cgo, set `pure` = `off`.

See [Cross compilation] for more information.
2"auto"�
�
goos�Forces a binary to be cross-compiled for a specific operating system. It's
usually better to control this on the command line with `--platforms`.

This disables cgo by default, since a cross-compiling C/C++ toolchain is
rarely available. To force cgo, set `pure` = `off`.

See [Cross compilation] for more information.
2"auto"x
v
gotagsfEnables a list of build tags when evaluating [build constraints]. Useful for
conditional compilation.
2[]�
�

importpath�The import path of this test. Tests can't actually be imported, but this
may be used by [go_path] and other tools to report the location of source
files. This may be inferred from embedded libraries.
2""�
�
linkmode�Determines how the binary should be built and linked. This accepts some of
the same values as `go build -buildmode` and works the same way.
<br><br>
<ul>
<li>`normal`: Builds a normal executable with position-dependent code.</li>
<li>`pie`: Builds a position-independent executable.</li>
<li>`plugin`: Builds a shared library that can be loaded as a Go plugin. Only supported on platforms that support plugins.</li>
<li>`c-shared`: Builds a shared library that can be linked into a C program.</li>
<li>`c-archive`: Builds an archive that can be linked into a C program.</li>
</ul>
2"normal"�
�
msan�Controls whether code is instrumented for memory sanitization. May be one of
`on`, `off`, or `auto`. Not available when cgo is
disabled. In most cases, it's better to control this on the command line with
`--@io_bazel_rules_go//go/config:msan`. See [mode attributes], specifically
[msan].
2"auto"�
�
pure�Controls whether cgo source code and dependencies are compiled and linked,
similar to setting `CGO_ENABLED`. May be one of `on`, `off`,
or `auto`. If `auto`, pure mode is enabled when no C/C++
toolchain is configured or when cross-compiling. It's usually better to
control this on the command line with
`--@io_bazel_rules_go//go/config:pure`. See [mode attributes], specifically
[pure].
2"auto"�
�
race�Controls whether code is instrumented for race detection. May be one of
`on`, `off`, or `auto`. Not available when cgo is
disabled. In most cases, it's better to control this on the command line with
`--@io_bazel_rules_go//go/config:race`. See [mode attributes], specifically
[race].
2"auto"�
�
rundir�A directory to cd to before the test is run.
           This should be a path relative to the root directory of the
           repository in which the test is defined, which can be the main or an
           external repository.

           The default behaviour is to change to the relative path
           corresponding to the test's package, which replicates the normal
           behaviour of `go test` so it is easy to write compatible tests.

           Setting it to `.` makes the test behave the normal way for a bazel
           test, except that the working directory is always that of the test's
           repository, which is not necessarily the main repository.

           Note: If runfile symlinks are disabled (such as on Windows by
           default), the test will run in the working directory set by Bazel,
           which is the subdirectory of the runfiles directory corresponding to
           the main repository.
2""�
�
srcs�The list of Go source files that are compiled to create the package.
Only `.go` and `.s` files are permitted, unless the `cgo`
attribute is set, in which case,
`.c .cc .cpp .cxx .h .hh .hpp .hxx .inc .m .mm`
files are also permitted. Files may be filtered at build time
using Go [build constraints].
2[]�
�
static�Controls whether a binary is statically linked. May be one of `on`,
`off`, or `auto`. Not available on all platforms or in all
modes. It's usually better to control this on the command line with
`--@io_bazel_rules_go//go/config:static`. See [mode attributes],
specifically [static].
2"auto"}
{
x_defskMap of defines to add to the go link command.
See [Defines and stamping] for examples of how to use these.

2{}�api_cc_py_proto_library*�
�
api_cc_py_proto_library

name ((

visibility["//visibility:private"](
srcs[](
deps[](

linkstatic0(
has_services0(
javaTrue(2B
api_cc_py_proto_library'@@envoy_api//bazel:api_build_system.bzl
BB"proto_library"cc_proto_descriptor_library"_py_proto_library"native.java_proto_library2proto_library2cc_proto_descriptor_library2_py_proto_library2native.java_proto_library�api_cc_test*�
]
api_cc_test

name (

kwargs(26
api_cc_test'@@envoy_api//bazel:api_build_system.bzl
��*cc_test2cc_test�api_proto_package*�
�
api_proto_package
name"pkg"(
srcs[](
deps[](
has_servicesFalse('

visibility["//visibility:public"](2<
api_proto_package'@@envoy_api//bazel:api_build_system.bzl
��"go_proto_library2api_cc_py_proto_library2go_proto_library�EnvoyProtoDepsInfo2�
k
EnvoyProtoDepsInfo
deps(Undocumented)"=
EnvoyProtoDepsInfo'@@envoy_api//bazel:api_build_system.bzl


deps(Undocumented)�
//bazel:external_proto_deps.bzlr�
+
	envoy_apibazelexternal_proto_deps.bzlP
EXTERNAL_PROTO_CC_BAZEL_DEP_MAPEXTERNAL_PROTO_CC_BAZEL_DEP_MAP
%P
EXTERNAL_PROTO_GO_BAZEL_DEP_MAPEXTERNAL_PROTO_GO_BAZEL_DEP_MAP
%
�
1//bazel/cc_proto_descriptor_library:builddefs.bzlr�
=
	envoy_api!bazel/cc_proto_descriptor_librarybuilddefs.bzlH
cc_proto_descriptor_librarycc_proto_descriptor_library
!
	�
//bazel:cc_grpc_library.bzlrd
"
grpcbazelcc_grpc_library.bzl0
cc_grpc_librarycc_grpc_library

+
:


<�
//bazel:python_rules.bzlrd

grpcbazelpython_rules.bzl3
py_proto_library_py_proto_library
'8
N�
//bazel:proto_library.bzlrb
$
protobufbazelproto_library.bzl,
proto_libraryproto_library
-:
<�
//bazel:pgv_proto_library.bzlr
3
protoc-gen-validatebazelpgv_proto_library.bzl:
pgv_cc_proto_librarypgv_cc_proto_library
<P
R]
//cc:defs.bzlrJ

rules_ccccdefs.bzl 
cc_testcc_test
!(
*[
//go:def.bzlrI

rules_gogodef.bzl 
go_testgo_test
 '
)s
//proto:def.bzlr^

rules_goprotodef.bzl2
go_proto_librarygo_proto_library
#3
5�
*
	envoy_apibazelenvoy_http_archive.bzl�envoy_http_archive*�
�
envoy_http_archive

name (
	locations (
location_nameNone(

kwargs(2?
envoy_http_archive)@@envoy_api//bazel:envoy_http_archive.bzl
*http_archive2http_archive�
 //tools/build_defs/repo:http.bzlrj
.
bazel_toolstools/build_defs/repohttp.bzl*
http_archivehttp_archive
7C
E�

"
	envoy_apibazelextensions.bzl�non_module_deps�
Extension for Envoy API dependencies not available in BCR.

This extension creates the following repositories:
- prometheus_metrics_model: Prometheus client model
- com_github_chrusty_protoc_gen_jsonschema: Proto to JSON schema compiler
- envoy_toolshed: Tooling and libraries for Envoy development

For WORKSPACE mode, call api_dependencies() directly from WORKSPACE.
This extension should only be used in MODULE.bazel files.
J�
�
non_module_deps�
Extension for Envoy API dependencies not available in BCR.

This extension creates the following repositories:
- prometheus_metrics_model: Prometheus client model
- com_github_chrusty_protoc_gen_jsonschema: Proto to JSON schema compiler
- envoy_toolshed: Tooling and libraries for Envoy development

For WORKSPACE mode, call api_dependencies() directly from WORKSPACE.
This extension should only be used in MODULE.bazel files.
"4
non_module_deps!@@envoy_api//bazel:extensions.bzl
##�
//bazel:repositories.bzlrh
$
	envoy_apibazelrepositories.bzl2
api_dependenciesapi_dependencies
-=
?�Non-BCR dependencies for Envoy Data Plane API.

This extension provides repositories that are not available in Bazel Central Registry (BCR).
�
%
	envoy_apibazelexternal_deps.bzl�load_repository_locations*�

load_repository_locations
repository_locations_spec (2A
load_repository_locations$@@envoy_api//bazel:external_deps.bzl
PP�
&//bazel:repository_locations_utils.bzlr�
2
	envoy_apibazelrepository_locations_utils.bzlN
load_repository_locations_specload_repository_locations_spec
;Y
[�	DEPENDENCY_ANNOTATIONSj�2�
cpe

extensions
implied_untracked_deps
project_desc
project_name
project_url
release_date
use_category
	version�	USE_CATEGORIESj�2�
api
build
controlplane
dataplane_core
dataplane_ext
observability_core
observability_ext
other
	test_only
docs

devtoolsN	 USE_CATEGORIES_WITH_CPE_OPTIONALj(2&
build
other
	test_only
api-
+
	envoy_apibazelexternal_proto_deps.bzl�p
$
	envoy_apibazelrepositories.bzlqapi_dependencies*[
K
api_dependencies27
api_dependencies#@@envoy_api//bazel:repositories.bzl
�external_http_archive*�
m
external_http_archive

name (

kwargs(2<
external_http_archive#@@envoy_api//bazel:repositories.bzl
*envoy_http_archive�
//bazel:envoy_http_archive.bzlrr
*
	envoy_apibazelenvoy_http_archive.bzl6
envoy_http_archiveenvoy_http_archive
3E
G�
//bazel:external_deps.bzlr{
%
	envoy_apibazelexternal_deps.bzlD
load_repository_locationsload_repository_locations
.G
I�
 //bazel:repository_locations.bzlr�
,
	envoy_apibazelrepository_locations.bzlD
REPOSITORY_LOCATIONS_SPECREPOSITORY_LOCATIONS_SPEC
5N
P�[	OPENTELEMETRY_BUILD_CONTENT�-
load("@com_github_grpc_grpc//bazel:cc_grpc_library.bzl", "cc_grpc_library")
load("@com_github_grpc_grpc//bazel:python_rules.bzl", "py_proto_library", "py_grpc_library")
load("@com_google_protobuf//bazel:cc_proto_library.bzl", "cc_proto_library")
load("@com_google_protobuf//bazel:proto_library.bzl", "proto_library")
load("@io_bazel_rules_go//proto:def.bzl", "go_proto_library", "go_grpc_library")

package(default_visibility = ["//visibility:public"])

proto_library(
    name = "common_proto",
    srcs = [
        "opentelemetry/proto/common/v1/common.proto",
    ],
)

cc_proto_library(
    name = "common_proto_cc",
    deps = [":common_proto"],
)

py_proto_library(
    name = "common_proto_py",
    deps = [":common_proto"],
)

go_proto_library(
    name = "common_proto_go",
    importpath = "go.opentelemetry.io/proto/otlp/common/v1",
    protos = [":common_proto"],
)

proto_library(
    name = "logs_proto",
    srcs = [
        "opentelemetry/proto/logs/v1/logs.proto",
    ],
    deps = [
        ":common_proto",
        ":resource_proto",
    ],
)

cc_proto_library(
    name = "logs_proto_cc",
    deps = [":logs_proto"],
)

py_proto_library(
    name = "logs_proto_py",
    deps = [":logs_proto"],
)

go_proto_library(
    name = "logs_proto_go",
    importpath = "go.opentelemetry.io/proto/otlp/logs/v1",
    protos = [":logs_proto"],
    deps = [
        ":common_proto_go",
        ":resource_proto_go",
    ],
)

proto_library(
    name = "logs_service_proto",
    srcs = [
        "opentelemetry/proto/collector/logs/v1/logs_service.proto",
    ],
    deps = [
        ":logs_proto",
    ],
)

cc_proto_library(
    name = "logs_service_proto_cc",
    deps = [":logs_service_proto"],
)

cc_grpc_library(
    name = "logs_service_grpc_cc",
    srcs = [":logs_service_proto"],
    generate_mocks = True,
    grpc_only = True,
    deps = [":logs_service_proto_cc"],
)

py_proto_library(
    name = "logs_service_proto_py",
    deps = [":logs_service_proto"],
)

py_grpc_library(
    name = "logs_service_grpc_py",
    srcs = [":logs_service_proto"],
    deps = [":logs_service_proto_py"],
)

go_grpc_library(
    name = "logs_service_grpc_go",
    protos = [":logs_service_proto"],
    importpath = "go.opentelemetry.io/proto/otlp/logs/v1",
    embed = [
        ":logs_proto_go",
    ],
)

proto_library(
    name = "metrics_proto",
    srcs = [
        "opentelemetry/proto/metrics/v1/metrics.proto",
    ],
    deps = [
        ":common_proto",
        ":resource_proto",
    ],
)

cc_proto_library(
    name = "metrics_proto_cc",
    deps = [":metrics_proto"],
)

py_proto_library(
    name = "metrics_proto_py",
    deps = [":metrics_proto"],
)

go_proto_library(
    name = "metrics_proto_go",
    importpath = "go.opentelemetry.io/proto/otlp/metrics/v1",
    protos = [":metrics_proto"],
    deps = [
        ":common_proto_go",
        ":resource_proto_go",
    ],
)

proto_library(
    name = "metrics_service_proto",
    srcs = [
        "opentelemetry/proto/collector/metrics/v1/metrics_service.proto",
    ],
    deps = [
        ":metrics_proto",
    ],
)

cc_proto_library(
    name = "metrics_service_proto_cc",
    deps = [":metrics_service_proto"],
)

cc_grpc_library(
    name = "metrics_service_grpc_cc",
    srcs = [":metrics_service_proto"],
    generate_mocks = True,
    grpc_only = True,
    deps = [":metrics_service_proto_cc"],
)

py_proto_library(
    name = "metrics_service_proto_py",
    deps = [":metrics_service_proto"],
)

py_grpc_library(
    name = "metrics_service_grpc_py",
    srcs = [":metrics_service_proto"],
    deps = [":metrics_service_proto_py"],
)

go_grpc_library(
    name = "metrics_service_grpc_go",
    protos = [":metrics_service_proto"],
    importpath = "go.opentelemetry.io/proto/otlp/metrics/v1",
    embed = [
        ":metrics_proto_go",
    ],
)

proto_library(
    name = "resource_proto",
    srcs = [
        "opentelemetry/proto/resource/v1/resource.proto",
    ],
    deps = [
        ":common_proto",
    ],
)

cc_proto_library(
    name = "resource_proto_cc",
    deps = [":resource_proto"],
)

py_proto_library(
    name = "resource_proto_py",
    deps = [":resource_proto"],
)

go_proto_library(
    name = "resource_proto_go",
    importpath = "go.opentelemetry.io/proto/otlp/resource/v1",
    protos = [":resource_proto"],
    deps = [
        ":common_proto_go",
    ],
)

proto_library(
    name = "trace_proto",
    srcs = [
        "opentelemetry/proto/trace/v1/trace.proto",
    ],
    deps = [
        ":common_proto",
        ":resource_proto",
    ],
)

cc_proto_library(
    name = "trace_proto_cc",
    deps = [":trace_proto"],
)

py_proto_library(
    name = "trace_proto_py",
    deps = [":trace_proto"],
)

go_proto_library(
    name = "trace_proto_go",
    importpath = "go.opentelemetry.io/proto/otlp/trace/v1",
    protos = [":trace_proto"],
    deps = [
        ":common_proto_go",
        ":resource_proto_go",
    ],
)

proto_library(
    name = "trace_service_proto",
    srcs = [
        "opentelemetry/proto/collector/trace/v1/trace_service.proto",
    ],
    deps = [
        ":trace_proto",
    ],
)

cc_proto_library(
    name = "trace_service_proto_cc",
    deps = [":trace_service_proto"],
)

cc_grpc_library(
    name = "trace_service_grpc_cc",
    srcs = [":trace_service_proto"],
    generate_mocks = True,
    grpc_only = True,
    deps = [":trace_service_proto_cc"],
)

py_proto_library(
    name = "trace_service_proto_py",
    deps = [":trace_service_proto"],
)

py_grpc_library(
    name = "trace_service_grpc_py",
    srcs = [":trace_service_proto"],
    deps = [":trace_service_proto_py"],
)

go_grpc_library(
    name = "trace_service_grpc_go",
    protos = [":trace_service_proto"],
    importpath = "go.opentelemetry.io/proto/otlp/trace/v1",
    embed = [
        ":trace_proto_go",
    ],
)
j�-�-
load("@com_github_grpc_grpc//bazel:cc_grpc_library.bzl", "cc_grpc_library")
load("@com_github_grpc_grpc//bazel:python_rules.bzl", "py_proto_library", "py_grpc_library")
load("@com_google_protobuf//bazel:cc_proto_library.bzl", "cc_proto_library")
load("@com_google_protobuf//bazel:proto_library.bzl", "proto_library")
load("@io_bazel_rules_go//proto:def.bzl", "go_proto_library", "go_grpc_library")

package(default_visibility = ["//visibility:public"])

proto_library(
    name = "common_proto",
    srcs = [
        "opentelemetry/proto/common/v1/common.proto",
    ],
)

cc_proto_library(
    name = "common_proto_cc",
    deps = [":common_proto"],
)

py_proto_library(
    name = "common_proto_py",
    deps = [":common_proto"],
)

go_proto_library(
    name = "common_proto_go",
    importpath = "go.opentelemetry.io/proto/otlp/common/v1",
    protos = [":common_proto"],
)

proto_library(
    name = "logs_proto",
    srcs = [
        "opentelemetry/proto/logs/v1/logs.proto",
    ],
    deps = [
        ":common_proto",
        ":resource_proto",
    ],
)

cc_proto_library(
    name = "logs_proto_cc",
    deps = [":logs_proto"],
)

py_proto_library(
    name = "logs_proto_py",
    deps = [":logs_proto"],
)

go_proto_library(
    name = "logs_proto_go",
    importpath = "go.opentelemetry.io/proto/otlp/logs/v1",
    protos = [":logs_proto"],
    deps = [
        ":common_proto_go",
        ":resource_proto_go",
    ],
)

proto_library(
    name = "logs_service_proto",
    srcs = [
        "opentelemetry/proto/collector/logs/v1/logs_service.proto",
    ],
    deps = [
        ":logs_proto",
    ],
)

cc_proto_library(
    name = "logs_service_proto_cc",
    deps = [":logs_service_proto"],
)

cc_grpc_library(
    name = "logs_service_grpc_cc",
    srcs = [":logs_service_proto"],
    generate_mocks = True,
    grpc_only = True,
    deps = [":logs_service_proto_cc"],
)

py_proto_library(
    name = "logs_service_proto_py",
    deps = [":logs_service_proto"],
)

py_grpc_library(
    name = "logs_service_grpc_py",
    srcs = [":logs_service_proto"],
    deps = [":logs_service_proto_py"],
)

go_grpc_library(
    name = "logs_service_grpc_go",
    protos = [":logs_service_proto"],
    importpath = "go.opentelemetry.io/proto/otlp/logs/v1",
    embed = [
        ":logs_proto_go",
    ],
)

proto_library(
    name = "metrics_proto",
    srcs = [
        "opentelemetry/proto/metrics/v1/metrics.proto",
    ],
    deps = [
        ":common_proto",
        ":resource_proto",
    ],
)

cc_proto_library(
    name = "metrics_proto_cc",
    deps = [":metrics_proto"],
)

py_proto_library(
    name = "metrics_proto_py",
    deps = [":metrics_proto"],
)

go_proto_library(
    name = "metrics_proto_go",
    importpath = "go.opentelemetry.io/proto/otlp/metrics/v1",
    protos = [":metrics_proto"],
    deps = [
        ":common_proto_go",
        ":resource_proto_go",
    ],
)

proto_library(
    name = "metrics_service_proto",
    srcs = [
        "opentelemetry/proto/collector/metrics/v1/metrics_service.proto",
    ],
    deps = [
        ":metrics_proto",
    ],
)

cc_proto_library(
    name = "metrics_service_proto_cc",
    deps = [":metrics_service_proto"],
)

cc_grpc_library(
    name = "metrics_service_grpc_cc",
    srcs = [":metrics_service_proto"],
    generate_mocks = True,
    grpc_only = True,
    deps = [":metrics_service_proto_cc"],
)

py_proto_library(
    name = "metrics_service_proto_py",
    deps = [":metrics_service_proto"],
)

py_grpc_library(
    name = "metrics_service_grpc_py",
    srcs = [":metrics_service_proto"],
    deps = [":metrics_service_proto_py"],
)

go_grpc_library(
    name = "metrics_service_grpc_go",
    protos = [":metrics_service_proto"],
    importpath = "go.opentelemetry.io/proto/otlp/metrics/v1",
    embed = [
        ":metrics_proto_go",
    ],
)

proto_library(
    name = "resource_proto",
    srcs = [
        "opentelemetry/proto/resource/v1/resource.proto",
    ],
    deps = [
        ":common_proto",
    ],
)

cc_proto_library(
    name = "resource_proto_cc",
    deps = [":resource_proto"],
)

py_proto_library(
    name = "resource_proto_py",
    deps = [":resource_proto"],
)

go_proto_library(
    name = "resource_proto_go",
    importpath = "go.opentelemetry.io/proto/otlp/resource/v1",
    protos = [":resource_proto"],
    deps = [
        ":common_proto_go",
    ],
)

proto_library(
    name = "trace_proto",
    srcs = [
        "opentelemetry/proto/trace/v1/trace.proto",
    ],
    deps = [
        ":common_proto",
        ":resource_proto",
    ],
)

cc_proto_library(
    name = "trace_proto_cc",
    deps = [":trace_proto"],
)

py_proto_library(
    name = "trace_proto_py",
    deps = [":trace_proto"],
)

go_proto_library(
    name = "trace_proto_go",
    importpath = "go.opentelemetry.io/proto/otlp/trace/v1",
    protos = [":trace_proto"],
    deps = [
        ":common_proto_go",
        ":resource_proto_go",
    ],
)

proto_library(
    name = "trace_service_proto",
    srcs = [
        "opentelemetry/proto/collector/trace/v1/trace_service.proto",
    ],
    deps = [
        ":trace_proto",
    ],
)

cc_proto_library(
    name = "trace_service_proto_cc",
    deps = [":trace_service_proto"],
)

cc_grpc_library(
    name = "trace_service_grpc_cc",
    srcs = [":trace_service_proto"],
    generate_mocks = True,
    grpc_only = True,
    deps = [":trace_service_proto_cc"],
)

py_proto_library(
    name = "trace_service_proto_py",
    deps = [":trace_service_proto"],
)

py_grpc_library(
    name = "trace_service_grpc_py",
    srcs = [":trace_service_proto"],
    deps = [":trace_service_proto_py"],
)

go_grpc_library(
    name = "trace_service_grpc_go",
    protos = [":trace_service_proto"],
    importpath = "go.opentelemetry.io/proto/otlp/trace/v1",
    embed = [
        ":trace_proto_go",
    ],
)
�	PROMETHEUSMETRICS_BUILD_CONTENT�
load("@envoy_api//bazel:api_build_system.bzl", "api_cc_py_proto_library")
load("@io_bazel_rules_go//proto:def.bzl", "go_proto_library")

api_cc_py_proto_library(
    name = "client_model",
    srcs = [
        "io/prometheus/client/metrics.proto",
    ],
    visibility = ["//visibility:public"],
)

go_proto_library(
    name = "client_model_go_proto",
    importpath = "github.com/prometheus/client_model/go",
    proto = ":client_model",
    visibility = ["//visibility:public"],
)
j��
load("@envoy_api//bazel:api_build_system.bzl", "api_cc_py_proto_library")
load("@io_bazel_rules_go//proto:def.bzl", "go_proto_library")

api_cc_py_proto_library(
    name = "client_model",
    srcs = [
        "io/prometheus/client/metrics.proto",
    ],
    visibility = ["//visibility:public"],
)

go_proto_library(
    name = "client_model_go_proto",
    importpath = "github.com/prometheus/client_model/go",
    proto = ":client_model",
    visibility = ["//visibility:public"],
)
�	ZIPKINAPI_BUILD_CONTENT�

load("@envoy_api//bazel:api_build_system.bzl", "api_cc_py_proto_library")
load("@io_bazel_rules_go//proto:def.bzl", "go_proto_library")

api_cc_py_proto_library(
    name = "zipkin",
    srcs = [
        "zipkin-jsonv2.proto",
        "zipkin.proto",
    ],
    visibility = ["//visibility:public"],
)

go_proto_library(
    name = "zipkin_go_proto",
    proto = ":zipkin",
    visibility = ["//visibility:public"],
)
j��

load("@envoy_api//bazel:api_build_system.bzl", "api_cc_py_proto_library")
load("@io_bazel_rules_go//proto:def.bzl", "go_proto_library")

api_cc_py_proto_library(
    name = "zipkin",
    srcs = [
        "zipkin-jsonv2.proto",
        "zipkin.proto",
    ],
    visibility = ["//visibility:public"],
)

go_proto_library(
    name = "zipkin_go_proto",
    proto = ":zipkin",
    visibility = ["//visibility:public"],
)
.
,
	envoy_apibazelrepository_locations.bzl�
2
	envoy_apibazelrepository_locations_utils.bzl�load_repository_locations_spec*�
�
load_repository_locations_spec
repository_locations_spec (2S
load_repository_locations_spec1@@envoy_api//bazel:repository_locations_utils.bzl
		{merge_dicts*j
Z
merge_dicts	
dicts(2@
merge_dicts1@@envoy_api//bazel:repository_locations_utils.bzl
 