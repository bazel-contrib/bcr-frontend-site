�
'
faiss	faiss/gpuivf_interleaved.bzl� generate_ivf_interleaved_sources:Generates the IVF-interleaved scan kernel specializations.*�
�
 generate_ivf_interleaved_sources5
name)prefix for the generated genrule targets. (D
template4label of the `.cu` template with SUB_* placeholders. (:Generates the IVF-interleaved scan kernel specializations."C
AA list of generated `.cu` source file names, suitable for `srcs`.2J
 generate_ivf_interleaved_sources&@@faiss//faiss/gpu:ivf_interleaved.bzl
--�Code generation for the faiss GPU IVF-interleaved scan kernels.

This mirrors the `generate_ivf_interleaved_code()` CMake function in
`faiss/gpu/CMakeLists.txt`. It instantiates
`impl/scan/IVFInterleavedScanKernelTemplate.cu` for the Cartesian product of
(codec, metric, thread configuration), replacing the SUB_* placeholders, and
returns the list of generated `.cu` source labels.
 