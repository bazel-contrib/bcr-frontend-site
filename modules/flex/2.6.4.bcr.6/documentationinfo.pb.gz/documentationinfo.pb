�

flexflex.bzl�flex�Runs GNU Flex on a scanner specification to produce lexer source.

This rule configures the `M4` environment variable automatically. The
interface follows the same pattern as `bazel_skylib`'s `run_binary`:
provide `srcs`, `outs`, and `args` with `$(execpath ...)` expansions for
input and output paths.

The m4 binary can be overridden globally via the `//:m4` label_flag,
or per-target via the `m4` attr.

Example:
    load("@flex//:flex.bzl", "flex")

    flex(
        name = "scanner",
        srcs = ["scanner.l"],
        outs = ["scanner.c"],
        args = ["-o", "$(execpath scanner.c)", "$(execpath scanner.l)"],
    )
"�
�
flex�Runs GNU Flex on a scanner specification to produce lexer source.

This rule configures the `M4` environment variable automatically. The
interface follows the same pattern as `bazel_skylib`'s `run_binary`:
provide `srcs`, `outs`, and `args` with `$(execpath ...)` expansions for
input and output paths.

The m4 binary can be overridden globally via the `//:m4` label_flag,
or per-target via the `m4` attr.

Example:
    load("@flex//:flex.bzl", "flex")

    flex(
        name = "scanner",
        srcs = ["scanner.l"],
        outs = ["scanner.c"],
        args = ["-o", "$(execpath scanner.c)", "$(execpath scanner.l)"],
    )
*
nameA unique name for this target. [
argsOArguments to pass to flex. Supports $(execpath ...) for input and output paths. *
flexThe flex binary to use.2//:flexQ
m4BThe m4 binary to use. Override globally with --@flex//:m4=<label>.2//:m4*
outsOutput files produced by flex. <
srcs0Source files (scanner specs) to provide to flex. "
flex@@flex//:flex.bzl
11,
*
nameA unique name for this target. ]
[
argsOArguments to pass to flex. Supports $(execpath ...) for input and output paths. ,
*
flexThe flex binary to use.2//:flexS
Q
m4BThe m4 binary to use. Override globally with --@flex//:m4=<label>.2//:m4,
*
outsOutput files produced by flex. >
<
srcs0Source files (scanner specs) to provide to flex. ;Rule for running GNU Flex with M4 configured automatically. 