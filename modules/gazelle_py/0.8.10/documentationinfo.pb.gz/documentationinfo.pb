�
.

gazelle_pycrates/import_extractoropt.bzl*�ModuleInfo request error: invalid argument: Traceback (most recent call last):
	File "external/gazelle_py/crates/import_extractor/opt.bzl", line 20, column 13, in <toplevel>
		with_cfg(rust_library, extra_providers = COMMON_PROVIDERS)
	File "external/with_cfg.bzl/with_cfg/private/with_cfg.bzl", line 107, column 35, in with_cfg
		executable = is_executable(rule_name)
	File "external/with_cfg.bzl/with_cfg/private/with_cfg.bzl", line 150, column 21, in is_executable
		return rule_name.endswith("_binary")
Error: 'NoneType' value has no field or method 'endswith' 