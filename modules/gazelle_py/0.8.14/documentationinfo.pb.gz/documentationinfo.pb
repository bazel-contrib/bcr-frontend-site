�
.

gazelle_pycrates/import_extractoropt.bzl*�ModuleInfo request error: invalid argument: Traceback (most recent call last):
	File "external/gazelle_py/crates/import_extractor/opt.bzl", line 19, column 46, in <toplevel>
		cgo_rust_library, _cgo_rust_library_internal = (
Error: too few values to unpack (got 0, want 2) 