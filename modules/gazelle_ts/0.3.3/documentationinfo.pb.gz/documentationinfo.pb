�
.

gazelle_tscrates/import_extractoropt.bzl*�ModuleInfo request error: invalid argument: Traceback (most recent call last):
	File "external/gazelle_ts/crates/import_extractor/opt.bzl", line 18, column 13, in <toplevel>
		with_cfg(rust_static_library)
	File "external/with_cfg.bzl/with_cfg/private/with_cfg.bzl", line 107, column 35, in with_cfg
		executable = is_executable(rule_name)
	File "external/with_cfg.bzl/with_cfg/private/with_cfg.bzl", line 150, column 21, in is_executable
		return rule_name.endswith("_binary")
Error: 'NoneType' value has no field or method 'endswith' 