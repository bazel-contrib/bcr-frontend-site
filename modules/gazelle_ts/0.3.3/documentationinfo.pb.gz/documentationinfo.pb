�
.

gazelle_tscrates/import_extractoropt.bzl*�ModuleInfo request error: invalid argument: Traceback (most recent call last):
	File "external/gazelle_ts/crates/import_extractor/opt.bzl", line 17, column 60, in <toplevel>
		opt_rust_static_library, _opt_rust_static_library_internal = (
Error: too few values to unpack (got 0, want 2) 