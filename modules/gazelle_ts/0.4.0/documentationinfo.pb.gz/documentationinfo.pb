�
.

gazelle_tscrates/import_extractoropt.bzl*�ModuleInfo request error: invalid argument: Traceback (most recent call last):
	File "external/gazelle_ts/crates/import_extractor/opt.bzl", line 18, column 13, in <toplevel>
		with_cfg(rust_static_library)
	File "external/with_cfg.bzl/with_cfg/private/with_cfg.bzl", line 107, column 35, in with_cfg
		executable = is_executable(rule_name)
	File "external/with_cfg.bzl/with_cfg/private/with_cfg.bzl", line 150, column 21, in is_executable
		return rule_name.endswith("_binary")
Error: 'NoneType' value has no field or method 'endswith'�


gazelle_tstsdefs.bzl{	ts_binary*l
\
	ts_binary

name (
dataNone(
_kwargs(2&
	ts_binary@@gazelle_ts//ts:defs.bzl
11�ts_bundler_config*x
h
ts_bundler_config

name (

srcs (
_kwargs(2.
ts_bundler_config@@gazelle_ts//ts:defs.bzl
44z
ts_library*j
Z

ts_library

name (

srcs (
_kwargs(2'

ts_library@@gazelle_ts//ts:defs.bzl
++qts_test*d
T
ts_test

name (

data (
_kwargs(2$
ts_test@@gazelle_ts//ts:defs.bzl
..�Stubs for the abstract rule kinds emitted by the gazelle_ts plugin.

`ts_library`, `ts_test`, `ts_binary`, and `ts_bundler_config` are
intentionally abstract: the plugin emits them with this load path, and
the consumer must override each with a project-specific macro via
`# gazelle:map_kind`. The wrappers typically forward to `ts_project`,
`js_test`/`vitest_test`/`jest_test`, or `js_binary` with project-specific
defaults baked in (transpiler, tsconfig, visibility, project-references
compile flags, entry_point handling, launcher).

`ts_binary` is the binary-flavored sibling of `ts_library`: hand-written
by the user (we never generate one), but its `data` attr is auto-managed
from the rule's `entry_point` / `srcs` imports. Same lifecycle as stock
`js_binary`, just under the gazelle_ts namespace so consumers can swap
implementations through map_kind without rewriting their gazelle config.

The gazelle_ts module deliberately does not take a transitive
`aspect_rules_ts` or `aspect_rules_js` dependency, so the macros can't
live here.

The fallbacks below collect matched files into a filegroup with a debug
print so the BUILD still loads and gazelle can run â but the files are
NOT typechecked or executed. To get a real compilation/test/binary unit,
add to your root BUILD:

    # gazelle:map_kind ts_library         <macro> <load_path>
    # gazelle:map_kind ts_test            <macro> <load_path>
    # gazelle:map_kind ts_binary          <macro> <load_path>
    # gazelle:map_kind ts_bundler_config  <macro> <load_path>

and re-run gazelle. See `examples/advanced/tools/ts.bzl` for one-line
wrappers.
 