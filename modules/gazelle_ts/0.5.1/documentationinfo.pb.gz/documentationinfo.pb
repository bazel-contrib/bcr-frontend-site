�
.

gazelle_tscrates/import_extractoropt.bzl*�ModuleInfo request error: invalid argument: Traceback (most recent call last):
	File "external/gazelle_ts/crates/import_extractor/opt.bzl", line 19, column 46, in <toplevel>
		cgo_rust_library, _cgo_rust_library_internal = (
Error: too few values to unpack (got 0, want 2)�
0

gazelle_tsts/testdata/advanced/toolsts.bzl�myorg_ts_binary�Thin wrapper over js_binary for TS entry points. A real consumer would set default NODE_OPTIONS, a wrapping launcher script, or

whatever house style the binaries should run with. The plugin
auto-manages `data` from the rule's entry_point/srcs imports.*�
�
myorg_ts_binary

name (
tsconfig_typesNone(

kwargs(�Thin wrapper over js_binary for TS entry points. A real consumer would set default NODE_OPTIONS, a wrapping launcher script, or

whatever house style the binaries should run with. The plugin
auto-manages `data` from the rule's entry_point/srcs imports.2B
myorg_ts_binary/@@gazelle_ts//ts/testdata/advanced/tools:ts.bzl
&&*
_js_binary2
_js_binary�myorg_ts_library{Project defaults baked in: shared tsconfig + project-references compile flags. The plugin doesn't emit these on ts_library.*�
�
myorg_ts_library

name (

srcs (
tsconfig_typesNone(

kwargs({Project defaults baked in: shared tsconfig + project-references compile flags. The plugin doesn't emit these on ts_library.2C
myorg_ts_library/@@gazelle_ts//ts/testdata/advanced/tools:ts.bzl
*_ts_project2_ts_project�myorg_ts_visual_library6Visual library typecheck target with project defaults.*�
�
myorg_ts_visual_library

name (

srcs (
deps[](
tsconfig_typesNone(

kwargs(6Visual library typecheck target with project defaults.2J
myorg_ts_visual_library/@@gazelle_ts//ts/testdata/advanced/tools:ts.bzl
--*_ts_project2_ts_project�vitest_test*�
�
vitest_test

name (

srcs (
deps[](
data[](
tsconfig_typesNone(

kwargs(2>
vitest_test/@@gazelle_ts//ts/testdata/advanced/tools:ts.bzl
>>i
//js:defs.bzlrV

aspect_rules_jsjsdefs.bzl%
	js_binary
_js_binary
'1
@k
//ts:defs.bzlrX

aspect_rules_tstsdefs.bzl'

ts_project_ts_project
'2
Bn
:vitest/package_json.bzlrP

npmvitest/package_json.bzl 
bin_vitest_bin
(3
<�Project-specific wrappers around stock rules_ts/rules_js.

Gazelle is told to emit these via `# gazelle:map_kind` directives in
//BUILD.bazel:

    # gazelle:map_kind ts_library  myorg_ts_library //tools:ts.bzl
    # gazelle:map_kind ts_test     vitest_test      //tools:ts.bzl
    # gazelle:map_kind ts_visual_library    myorg_ts_visual_library   //tools:ts.bzl
    # gazelle:map_kind ts_binary   myorg_ts_binary  //tools:ts.bzl

The plugin emits TypeScript abstract kinds with no compile flags or
entry_point â those defaults belong here.

Note: rules_js's `@npm//:vitest/package_json.bzl` re-exports the auto-
generated bin macros under a single `bin = struct(...)` symbol â so the
inner `vitest_test` isn't directly load()-able from there. We re-bind it
here so map_kind can target a single load path.
��
-

gazelle_tsts/testdata/basic/toolsts.bzl��ts_test�Identical to js_binary, but usable under `bazel test`.

All [common test attributes](https://bazel.build/reference/be/common-definitions#common-attributes-tests) are
supported including `args` as the list of arguments passed Node.js.

Bazel will set environment variables when a test target is run under `bazel test` and `bazel run`
that a test runner can use.

A runner can write arbitrary outputs files it wants Bazel to pickup and save with the test logs to
`TEST_UNDECLARED_OUTPUTS_DIR`. These get zipped up and saved along with the test logs.

JUnit XML reports can be written to `XML_OUTPUT_FILE` for Bazel to consume.

`TEST_TMPDIR` is an absolute path to a private writeable directory that the test runner can use for
creating temporary files.

LCOV coverage reports can be written to `COVERAGE_OUTPUT_FILE` when running under `bazel coverage`
or if the `--coverage` flag is set.

See the Bazel [Test encyclopedia](https://bazel.build/reference/test-encyclopedia) for details on
the contract between Bazel and a test runner."��
�S
ts_test�Identical to js_binary, but usable under `bazel test`.

All [common test attributes](https://bazel.build/reference/be/common-definitions#common-attributes-tests) are
supported including `args` as the list of arguments passed Node.js.

Bazel will set environment variables when a test target is run under `bazel test` and `bazel run`
that a test runner can use.

A runner can write arbitrary outputs files it wants Bazel to pickup and save with the test logs to
`TEST_UNDECLARED_OUTPUTS_DIR`. These get zipped up and saved along with the test logs.

JUnit XML reports can be written to `XML_OUTPUT_FILE` for Bazel to consume.

`TEST_TMPDIR` is an absolute path to a private writeable directory that the test runner can use for
creating temporary files.

LCOV coverage reports can be written to `COVERAGE_OUTPUT_FILE` when running under `bazel coverage`
or if the `--coverage` flag is set.

See the Bazel [Test encyclopedia](https://bazel.build/reference/test-encyclopedia) for details on
the contract between Bazel and a test runner.*
nameA unique name for this target. �
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/"))) + "$(rootpath //path/to/some:file)"],
)
```2""�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

NB: `data` files are copied to the Bazel output tree before being passed
as inputs to runfiles. See `copy_data_to_bin` docstring for more info.
2[]�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/bazel-contrib/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 �
env�Environment variables of the action.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_env` is set to True.

2{}�
env_inherit|Specifies additional environment variables to inherit from the external environment when the test is executed by bazel test.2[]�
expand_args�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `fixed_args`.

This comes at some analysis-time cost even for a set of args that does not have any expansions.2True�

expand_env�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `env`.

This comes at some analysis-time cost even for a set of envs that does not have any expansions.2Truei
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�

fixed_args�Fixed command line arguments to pass to the Node.js when this
binary target is executed.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_args` is set to True.

Unlike the built-in `args`, which are only passed to the target when it is
executed either by the `bazel run` command or as a test, `fixed_args` are baked
into the generated launcher script so are always passed even when the binary
target is run outside of Bazel directly from the launcher script.

`fixed_args` are passed before the ones specified in `args` and before ones
that are specified on the `bazel run` or `bazel test` command line.

See https://bazel.build/reference/be/common-definitions#common-attributes-binaries
for more info on the built-in `args` attribute.
2[]�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
include_npm_sources�When True, files in `npm_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in `data` targets are also included in the runfiles of the target.
2True�
include_sourcesjWhen True, `sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
include_transitive_sourcesuWhen True, `transitive_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
include_transitive_types�When True, `transitive_types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
include_types�When True, `types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.

NB: These are types from direct `data` dependencies only. You may also need to set `include_transitive_types` to True.2False�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.

Log levels: fatal, error, warn, info, debug2"error"�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
node_toolchain�The Node.js toolchain to use for this target.

See https://bazel-contrib.github.io/rules_nodejs/Toolchains.html

Typically this is left unset so that Bazel automatically selects the right Node.js toolchain
for the target platform. See https://bazel.build/extending/toolchains#toolchain-resolution
for more information.
2None�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2True
,
*
nameA unique name for this target. �
�
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/"))) + "$(rootpath //path/to/some:file)"],
)
```2""�
�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

NB: `data` files are copied to the Bazel output tree before being passed
as inputs to runfiles. See `copy_data_to_bin` docstring for more info.
2[]�
�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
�
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/bazel-contrib/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 �
�
env�Environment variables of the action.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_env` is set to True.

2{}�
�
env_inherit|Specifies additional environment variables to inherit from the external environment when the test is executed by bazel test.2[]�
�
expand_args�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `fixed_args`.

This comes at some analysis-time cost even for a set of args that does not have any expansions.2True�
�

expand_env�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `env`.

This comes at some analysis-time cost even for a set of envs that does not have any expansions.2Truek
i
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�
�

fixed_args�Fixed command line arguments to pass to the Node.js when this
binary target is executed.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_args` is set to True.

Unlike the built-in `args`, which are only passed to the target when it is
executed either by the `bazel run` command or as a test, `fixed_args` are baked
into the generated launcher script so are always passed even when the binary
target is run outside of Bazel directly from the launcher script.

`fixed_args` are passed before the ones specified in `args` and before ones
that are specified on the `bazel run` or `bazel test` command line.

See https://bazel.build/reference/be/common-definitions#common-attributes-binaries
for more info on the built-in `args` attribute.
2[]�
�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
�
include_npm_sources�When True, files in `npm_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in `data` targets are also included in the runfiles of the target.
2True�
�
include_sourcesjWhen True, `sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
�
include_transitive_sourcesuWhen True, `transitive_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
�
include_transitive_types�When True, `transitive_types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
�
include_types�When True, `types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.

NB: These are types from direct `data` dependencies only. You may also need to set `include_transitive_types` to True.2False�
�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.

Log levels: fatal, error, warn, info, debug2"error"�
�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
�
node_toolchain�The Node.js toolchain to use for this target.

See https://bazel-contrib.github.io/rules_nodejs/Toolchains.html

Typically this is left unset so that Bazel automatically selects the right Node.js toolchain
for the target platform. See https://bazel.build/extending/toolchains#toolchain-resolution
for more information.
2None�
�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2True�
ts_library*�
�

ts_library

name (

srcs (
tsconfig_typesNone(

kwargs(2:

ts_library,@@gazelle_ts//ts/testdata/basic/tools:ts.bzl


*
ts_project2
ts_project�ts_visual_library*�
�
ts_visual_library

name (

srcs (
deps[](
tsconfig_typesNone(

kwargs(2A
ts_visual_library,@@gazelle_ts//ts/testdata/basic/tools:ts.bzl
*
ts_project2
ts_projectd
//js:defs.bzlrQ

aspect_rules_jsjsdefs.bzl 
js_testjs_test
(/
1j
//ts:defs.bzlrW

aspect_rules_tstsdefs.bzl&

ts_project
ts_project
(2
4�Concrete macros for the abstract kinds emitted by gazelle_ts.

The plugin emits abstract TypeScript kinds that we map_kind here to
ts_project / js_test calls with the project's defaults baked in.
Ѱ
6

gazelle_ts ts/testdata/bundler-config/toolsts.bzl��ts_test�Identical to js_binary, but usable under `bazel test`.

All [common test attributes](https://bazel.build/reference/be/common-definitions#common-attributes-tests) are
supported including `args` as the list of arguments passed Node.js.

Bazel will set environment variables when a test target is run under `bazel test` and `bazel run`
that a test runner can use.

A runner can write arbitrary outputs files it wants Bazel to pickup and save with the test logs to
`TEST_UNDECLARED_OUTPUTS_DIR`. These get zipped up and saved along with the test logs.

JUnit XML reports can be written to `XML_OUTPUT_FILE` for Bazel to consume.

`TEST_TMPDIR` is an absolute path to a private writeable directory that the test runner can use for
creating temporary files.

LCOV coverage reports can be written to `COVERAGE_OUTPUT_FILE` when running under `bazel coverage`
or if the `--coverage` flag is set.

See the Bazel [Test encyclopedia](https://bazel.build/reference/test-encyclopedia) for details on
the contract between Bazel and a test runner."��
�S
ts_test�Identical to js_binary, but usable under `bazel test`.

All [common test attributes](https://bazel.build/reference/be/common-definitions#common-attributes-tests) are
supported including `args` as the list of arguments passed Node.js.

Bazel will set environment variables when a test target is run under `bazel test` and `bazel run`
that a test runner can use.

A runner can write arbitrary outputs files it wants Bazel to pickup and save with the test logs to
`TEST_UNDECLARED_OUTPUTS_DIR`. These get zipped up and saved along with the test logs.

JUnit XML reports can be written to `XML_OUTPUT_FILE` for Bazel to consume.

`TEST_TMPDIR` is an absolute path to a private writeable directory that the test runner can use for
creating temporary files.

LCOV coverage reports can be written to `COVERAGE_OUTPUT_FILE` when running under `bazel coverage`
or if the `--coverage` flag is set.

See the Bazel [Test encyclopedia](https://bazel.build/reference/test-encyclopedia) for details on
the contract between Bazel and a test runner.*
nameA unique name for this target. �
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/"))) + "$(rootpath //path/to/some:file)"],
)
```2""�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

NB: `data` files are copied to the Bazel output tree before being passed
as inputs to runfiles. See `copy_data_to_bin` docstring for more info.
2[]�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/bazel-contrib/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 �
env�Environment variables of the action.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_env` is set to True.

2{}�
env_inherit|Specifies additional environment variables to inherit from the external environment when the test is executed by bazel test.2[]�
expand_args�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `fixed_args`.

This comes at some analysis-time cost even for a set of args that does not have any expansions.2True�

expand_env�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `env`.

This comes at some analysis-time cost even for a set of envs that does not have any expansions.2Truei
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�

fixed_args�Fixed command line arguments to pass to the Node.js when this
binary target is executed.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_args` is set to True.

Unlike the built-in `args`, which are only passed to the target when it is
executed either by the `bazel run` command or as a test, `fixed_args` are baked
into the generated launcher script so are always passed even when the binary
target is run outside of Bazel directly from the launcher script.

`fixed_args` are passed before the ones specified in `args` and before ones
that are specified on the `bazel run` or `bazel test` command line.

See https://bazel.build/reference/be/common-definitions#common-attributes-binaries
for more info on the built-in `args` attribute.
2[]�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
include_npm_sources�When True, files in `npm_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in `data` targets are also included in the runfiles of the target.
2True�
include_sourcesjWhen True, `sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
include_transitive_sourcesuWhen True, `transitive_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
include_transitive_types�When True, `transitive_types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
include_types�When True, `types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.

NB: These are types from direct `data` dependencies only. You may also need to set `include_transitive_types` to True.2False�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.

Log levels: fatal, error, warn, info, debug2"error"�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
node_toolchain�The Node.js toolchain to use for this target.

See https://bazel-contrib.github.io/rules_nodejs/Toolchains.html

Typically this is left unset so that Bazel automatically selects the right Node.js toolchain
for the target platform. See https://bazel.build/extending/toolchains#toolchain-resolution
for more information.
2None�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2True
,
*
nameA unique name for this target. �
�
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/"))) + "$(rootpath //path/to/some:file)"],
)
```2""�
�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

NB: `data` files are copied to the Bazel output tree before being passed
as inputs to runfiles. See `copy_data_to_bin` docstring for more info.
2[]�
�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
�
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/bazel-contrib/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 �
�
env�Environment variables of the action.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_env` is set to True.

2{}�
�
env_inherit|Specifies additional environment variables to inherit from the external environment when the test is executed by bazel test.2[]�
�
expand_args�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `fixed_args`.

This comes at some analysis-time cost even for a set of args that does not have any expansions.2True�
�

expand_env�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `env`.

This comes at some analysis-time cost even for a set of envs that does not have any expansions.2Truek
i
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�
�

fixed_args�Fixed command line arguments to pass to the Node.js when this
binary target is executed.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_args` is set to True.

Unlike the built-in `args`, which are only passed to the target when it is
executed either by the `bazel run` command or as a test, `fixed_args` are baked
into the generated launcher script so are always passed even when the binary
target is run outside of Bazel directly from the launcher script.

`fixed_args` are passed before the ones specified in `args` and before ones
that are specified on the `bazel run` or `bazel test` command line.

See https://bazel.build/reference/be/common-definitions#common-attributes-binaries
for more info on the built-in `args` attribute.
2[]�
�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
�
include_npm_sources�When True, files in `npm_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in `data` targets are also included in the runfiles of the target.
2True�
�
include_sourcesjWhen True, `sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
�
include_transitive_sourcesuWhen True, `transitive_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
�
include_transitive_types�When True, `transitive_types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
�
include_types�When True, `types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.

NB: These are types from direct `data` dependencies only. You may also need to set `include_transitive_types` to True.2False�
�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.

Log levels: fatal, error, warn, info, debug2"error"�
�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
�
node_toolchain�The Node.js toolchain to use for this target.

See https://bazel-contrib.github.io/rules_nodejs/Toolchains.html

Typically this is left unset so that Bazel automatically selects the right Node.js toolchain
for the target platform. See https://bazel.build/extending/toolchains#toolchain-resolution
for more information.
2None�
�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2True�ts_bundler_config*�
�
ts_bundler_config

name (

srcs (

kwargs(2J
ts_bundler_config5@@gazelle_ts//ts/testdata/bundler-config/tools:ts.bzl
*_project2_project�
ts_library*�
�

ts_library

name (

srcs (
tsconfig_typesNone(

kwargs(2C

ts_library5@@gazelle_ts//ts/testdata/bundler-config/tools:ts.bzl
*_project2_project�ts_visual_library*�
�
ts_visual_library

name (

srcs (
deps[](
tsconfig_typesNone(

kwargs(2J
ts_visual_library5@@gazelle_ts//ts/testdata/bundler-config/tools:ts.bzl
*_project2_projectd
//js:defs.bzlrQ

aspect_rules_jsjsdefs.bzl 
js_testjs_test
(/
1j
//ts:defs.bzlrW

aspect_rules_tstsdefs.bzl&

ts_project
ts_project
(2
4�Concrete macros for the abstract kinds emitted by gazelle_ts.

The abstract TypeScript compile/check kinds forward to ts_project / js_test
with the project's defaults baked in.
��
1

gazelle_tsts/testdata/composite/toolsts.bzl��ts_test�Identical to js_binary, but usable under `bazel test`.

All [common test attributes](https://bazel.build/reference/be/common-definitions#common-attributes-tests) are
supported including `args` as the list of arguments passed Node.js.

Bazel will set environment variables when a test target is run under `bazel test` and `bazel run`
that a test runner can use.

A runner can write arbitrary outputs files it wants Bazel to pickup and save with the test logs to
`TEST_UNDECLARED_OUTPUTS_DIR`. These get zipped up and saved along with the test logs.

JUnit XML reports can be written to `XML_OUTPUT_FILE` for Bazel to consume.

`TEST_TMPDIR` is an absolute path to a private writeable directory that the test runner can use for
creating temporary files.

LCOV coverage reports can be written to `COVERAGE_OUTPUT_FILE` when running under `bazel coverage`
or if the `--coverage` flag is set.

See the Bazel [Test encyclopedia](https://bazel.build/reference/test-encyclopedia) for details on
the contract between Bazel and a test runner."��
�S
ts_test�Identical to js_binary, but usable under `bazel test`.

All [common test attributes](https://bazel.build/reference/be/common-definitions#common-attributes-tests) are
supported including `args` as the list of arguments passed Node.js.

Bazel will set environment variables when a test target is run under `bazel test` and `bazel run`
that a test runner can use.

A runner can write arbitrary outputs files it wants Bazel to pickup and save with the test logs to
`TEST_UNDECLARED_OUTPUTS_DIR`. These get zipped up and saved along with the test logs.

JUnit XML reports can be written to `XML_OUTPUT_FILE` for Bazel to consume.

`TEST_TMPDIR` is an absolute path to a private writeable directory that the test runner can use for
creating temporary files.

LCOV coverage reports can be written to `COVERAGE_OUTPUT_FILE` when running under `bazel coverage`
or if the `--coverage` flag is set.

See the Bazel [Test encyclopedia](https://bazel.build/reference/test-encyclopedia) for details on
the contract between Bazel and a test runner.*
nameA unique name for this target. �
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/"))) + "$(rootpath //path/to/some:file)"],
)
```2""�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

NB: `data` files are copied to the Bazel output tree before being passed
as inputs to runfiles. See `copy_data_to_bin` docstring for more info.
2[]�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/bazel-contrib/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 �
env�Environment variables of the action.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_env` is set to True.

2{}�
env_inherit|Specifies additional environment variables to inherit from the external environment when the test is executed by bazel test.2[]�
expand_args�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `fixed_args`.

This comes at some analysis-time cost even for a set of args that does not have any expansions.2True�

expand_env�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `env`.

This comes at some analysis-time cost even for a set of envs that does not have any expansions.2Truei
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�

fixed_args�Fixed command line arguments to pass to the Node.js when this
binary target is executed.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_args` is set to True.

Unlike the built-in `args`, which are only passed to the target when it is
executed either by the `bazel run` command or as a test, `fixed_args` are baked
into the generated launcher script so are always passed even when the binary
target is run outside of Bazel directly from the launcher script.

`fixed_args` are passed before the ones specified in `args` and before ones
that are specified on the `bazel run` or `bazel test` command line.

See https://bazel.build/reference/be/common-definitions#common-attributes-binaries
for more info on the built-in `args` attribute.
2[]�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
include_npm_sources�When True, files in `npm_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in `data` targets are also included in the runfiles of the target.
2True�
include_sourcesjWhen True, `sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
include_transitive_sourcesuWhen True, `transitive_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
include_transitive_types�When True, `transitive_types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
include_types�When True, `types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.

NB: These are types from direct `data` dependencies only. You may also need to set `include_transitive_types` to True.2False�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.

Log levels: fatal, error, warn, info, debug2"error"�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
node_toolchain�The Node.js toolchain to use for this target.

See https://bazel-contrib.github.io/rules_nodejs/Toolchains.html

Typically this is left unset so that Bazel automatically selects the right Node.js toolchain
for the target platform. See https://bazel.build/extending/toolchains#toolchain-resolution
for more information.
2None�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2True
,
*
nameA unique name for this target. �
�
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/"))) + "$(rootpath //path/to/some:file)"],
)
```2""�
�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

NB: `data` files are copied to the Bazel output tree before being passed
as inputs to runfiles. See `copy_data_to_bin` docstring for more info.
2[]�
�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
�
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/bazel-contrib/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 �
�
env�Environment variables of the action.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_env` is set to True.

2{}�
�
env_inherit|Specifies additional environment variables to inherit from the external environment when the test is executed by bazel test.2[]�
�
expand_args�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `fixed_args`.

This comes at some analysis-time cost even for a set of args that does not have any expansions.2True�
�

expand_env�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `env`.

This comes at some analysis-time cost even for a set of envs that does not have any expansions.2Truek
i
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�
�

fixed_args�Fixed command line arguments to pass to the Node.js when this
binary target is executed.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_args` is set to True.

Unlike the built-in `args`, which are only passed to the target when it is
executed either by the `bazel run` command or as a test, `fixed_args` are baked
into the generated launcher script so are always passed even when the binary
target is run outside of Bazel directly from the launcher script.

`fixed_args` are passed before the ones specified in `args` and before ones
that are specified on the `bazel run` or `bazel test` command line.

See https://bazel.build/reference/be/common-definitions#common-attributes-binaries
for more info on the built-in `args` attribute.
2[]�
�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
�
include_npm_sources�When True, files in `npm_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in `data` targets are also included in the runfiles of the target.
2True�
�
include_sourcesjWhen True, `sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
�
include_transitive_sourcesuWhen True, `transitive_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
�
include_transitive_types�When True, `transitive_types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
�
include_types�When True, `types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.

NB: These are types from direct `data` dependencies only. You may also need to set `include_transitive_types` to True.2False�
�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.

Log levels: fatal, error, warn, info, debug2"error"�
�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
�
node_toolchain�The Node.js toolchain to use for this target.

See https://bazel-contrib.github.io/rules_nodejs/Toolchains.html

Typically this is left unset so that Bazel automatically selects the right Node.js toolchain
for the target platform. See https://bazel.build/extending/toolchains#toolchain-resolution
for more information.
2None�
�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2True�
ts_library*�
�

ts_library

name (

srcs (
tsconfig_typesNone(

kwargs(2>

ts_library0@@gazelle_ts//ts/testdata/composite/tools:ts.bzl
*
ts_project2
ts_project�ts_visual_library*�
�
ts_visual_library

name (

srcs (
deps[](
tsconfig_typesNone(

kwargs(2E
ts_visual_library0@@gazelle_ts//ts/testdata/composite/tools:ts.bzl
*
ts_project2
ts_projectd
//js:defs.bzlrQ

aspect_rules_jsjsdefs.bzl 
js_testjs_test
(/
1j
//ts:defs.bzlrW

aspect_rules_tstsdefs.bzl&

ts_project
ts_project
(2
4=Concrete macros for the abstract kinds emitted by gazelle_ts.��
/

gazelle_tsts/testdata/graphql/toolsts.bzl��ts_test�Identical to js_binary, but usable under `bazel test`.

All [common test attributes](https://bazel.build/reference/be/common-definitions#common-attributes-tests) are
supported including `args` as the list of arguments passed Node.js.

Bazel will set environment variables when a test target is run under `bazel test` and `bazel run`
that a test runner can use.

A runner can write arbitrary outputs files it wants Bazel to pickup and save with the test logs to
`TEST_UNDECLARED_OUTPUTS_DIR`. These get zipped up and saved along with the test logs.

JUnit XML reports can be written to `XML_OUTPUT_FILE` for Bazel to consume.

`TEST_TMPDIR` is an absolute path to a private writeable directory that the test runner can use for
creating temporary files.

LCOV coverage reports can be written to `COVERAGE_OUTPUT_FILE` when running under `bazel coverage`
or if the `--coverage` flag is set.

See the Bazel [Test encyclopedia](https://bazel.build/reference/test-encyclopedia) for details on
the contract between Bazel and a test runner."��
�S
ts_test�Identical to js_binary, but usable under `bazel test`.

All [common test attributes](https://bazel.build/reference/be/common-definitions#common-attributes-tests) are
supported including `args` as the list of arguments passed Node.js.

Bazel will set environment variables when a test target is run under `bazel test` and `bazel run`
that a test runner can use.

A runner can write arbitrary outputs files it wants Bazel to pickup and save with the test logs to
`TEST_UNDECLARED_OUTPUTS_DIR`. These get zipped up and saved along with the test logs.

JUnit XML reports can be written to `XML_OUTPUT_FILE` for Bazel to consume.

`TEST_TMPDIR` is an absolute path to a private writeable directory that the test runner can use for
creating temporary files.

LCOV coverage reports can be written to `COVERAGE_OUTPUT_FILE` when running under `bazel coverage`
or if the `--coverage` flag is set.

See the Bazel [Test encyclopedia](https://bazel.build/reference/test-encyclopedia) for details on
the contract between Bazel and a test runner.*
nameA unique name for this target. �
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/"))) + "$(rootpath //path/to/some:file)"],
)
```2""�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

NB: `data` files are copied to the Bazel output tree before being passed
as inputs to runfiles. See `copy_data_to_bin` docstring for more info.
2[]�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/bazel-contrib/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 �
env�Environment variables of the action.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_env` is set to True.

2{}�
env_inherit|Specifies additional environment variables to inherit from the external environment when the test is executed by bazel test.2[]�
expand_args�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `fixed_args`.

This comes at some analysis-time cost even for a set of args that does not have any expansions.2True�

expand_env�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `env`.

This comes at some analysis-time cost even for a set of envs that does not have any expansions.2Truei
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�

fixed_args�Fixed command line arguments to pass to the Node.js when this
binary target is executed.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_args` is set to True.

Unlike the built-in `args`, which are only passed to the target when it is
executed either by the `bazel run` command or as a test, `fixed_args` are baked
into the generated launcher script so are always passed even when the binary
target is run outside of Bazel directly from the launcher script.

`fixed_args` are passed before the ones specified in `args` and before ones
that are specified on the `bazel run` or `bazel test` command line.

See https://bazel.build/reference/be/common-definitions#common-attributes-binaries
for more info on the built-in `args` attribute.
2[]�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
include_npm_sources�When True, files in `npm_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in `data` targets are also included in the runfiles of the target.
2True�
include_sourcesjWhen True, `sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
include_transitive_sourcesuWhen True, `transitive_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
include_transitive_types�When True, `transitive_types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
include_types�When True, `types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.

NB: These are types from direct `data` dependencies only. You may also need to set `include_transitive_types` to True.2False�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.

Log levels: fatal, error, warn, info, debug2"error"�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
node_toolchain�The Node.js toolchain to use for this target.

See https://bazel-contrib.github.io/rules_nodejs/Toolchains.html

Typically this is left unset so that Bazel automatically selects the right Node.js toolchain
for the target platform. See https://bazel.build/extending/toolchains#toolchain-resolution
for more information.
2None�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2True
,
*
nameA unique name for this target. �
�
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/"))) + "$(rootpath //path/to/some:file)"],
)
```2""�
�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

NB: `data` files are copied to the Bazel output tree before being passed
as inputs to runfiles. See `copy_data_to_bin` docstring for more info.
2[]�
�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
�
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/bazel-contrib/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 �
�
env�Environment variables of the action.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_env` is set to True.

2{}�
�
env_inherit|Specifies additional environment variables to inherit from the external environment when the test is executed by bazel test.2[]�
�
expand_args�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `fixed_args`.

This comes at some analysis-time cost even for a set of args that does not have any expansions.2True�
�

expand_env�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `env`.

This comes at some analysis-time cost even for a set of envs that does not have any expansions.2Truek
i
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�
�

fixed_args�Fixed command line arguments to pass to the Node.js when this
binary target is executed.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_args` is set to True.

Unlike the built-in `args`, which are only passed to the target when it is
executed either by the `bazel run` command or as a test, `fixed_args` are baked
into the generated launcher script so are always passed even when the binary
target is run outside of Bazel directly from the launcher script.

`fixed_args` are passed before the ones specified in `args` and before ones
that are specified on the `bazel run` or `bazel test` command line.

See https://bazel.build/reference/be/common-definitions#common-attributes-binaries
for more info on the built-in `args` attribute.
2[]�
�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
�
include_npm_sources�When True, files in `npm_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in `data` targets are also included in the runfiles of the target.
2True�
�
include_sourcesjWhen True, `sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
�
include_transitive_sourcesuWhen True, `transitive_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
�
include_transitive_types�When True, `transitive_types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
�
include_types�When True, `types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.

NB: These are types from direct `data` dependencies only. You may also need to set `include_transitive_types` to True.2False�
�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.

Log levels: fatal, error, warn, info, debug2"error"�
�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
�
node_toolchain�The Node.js toolchain to use for this target.

See https://bazel-contrib.github.io/rules_nodejs/Toolchains.html

Typically this is left unset so that Bazel automatically selects the right Node.js toolchain
for the target platform. See https://bazel.build/extending/toolchains#toolchain-resolution
for more information.
2None�
�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2True�
ts_library*�
�

ts_library

name (

srcs (
tsconfig_typesNone(

kwargs(2<

ts_library.@@gazelle_ts//ts/testdata/graphql/tools:ts.bzl
*
ts_project2
ts_project�ts_visual_library*�
�
ts_visual_library

name (

srcs (
deps[](
tsconfig_typesNone(

kwargs(2C
ts_visual_library.@@gazelle_ts//ts/testdata/graphql/tools:ts.bzl
*
ts_project2
ts_projectd
//js:defs.bzlrQ

aspect_rules_jsjsdefs.bzl 
js_testjs_test
(/
1j
//ts:defs.bzlrW

aspect_rules_tstsdefs.bzl&

ts_project
ts_project
(2
4=Concrete macros for the abstract kinds emitted by gazelle_ts.�
A

gazelle_ts)ts/testdata/upstream_nested_spec_map_kinddefs.bzl�my_ts_library*�
�
my_ts_library

name (

srcs (

kwargs(2Q
my_ts_library@@@gazelle_ts//ts/testdata/upstream_nested_spec_map_kind:defs.bzl
*native.filegroup2native.filegroup�
my_ts_test*�
�

my_ts_test

name (

srcs (
deps[](
data[](

kwargs(2N

my_ts_test@@@gazelle_ts//ts/testdata/upstream_nested_spec_map_kind:defs.bzl
*native.filegroup2native.filegroup�


gazelle_tstsdefs.bzl{	ts_binary*l
\
	ts_binary

name (
dataNone(
_kwargs(2&
	ts_binary@@gazelle_ts//ts:defs.bzl
66�ts_bundler_config*x
h
ts_bundler_config

name (

srcs (
_kwargs(2.
ts_bundler_config@@gazelle_ts//ts:defs.bzl
99z
ts_library*j
Z

ts_library

name (

srcs (
_kwargs(2'

ts_library@@gazelle_ts//ts:defs.bzl
--�ts_test*�
p
ts_test

name (

srcs (
deps[](
data[](
_kwargs(2$
ts_test@@gazelle_ts//ts:defs.bzl
00�ts_visual_library*�
v
ts_visual_library

name (

srcs (
deps[](
_kwargs(2.
ts_visual_library@@gazelle_ts//ts:defs.bzl
33�Stubs for the abstract rule kinds emitted by the gazelle_ts plugin.

`ts_library`, `ts_test`, `ts_visual_library`, `ts_binary`, and
`ts_bundler_config` are intentionally abstract: the plugin emits them with
this load path, and the consumer must override each with a project-specific
macro via `# gazelle:map_kind`. The wrappers typically forward to
`ts_project`, `js_test`/`vitest_test`/`jest_test`, Storybook-specific
compile/check targets, or `js_binary` with project-specific defaults baked in
(transpiler, tsconfig, visibility, project-references compile flags,
entry_point handling, launcher).

`ts_binary` is the binary-flavored sibling of `ts_library`: hand-written
by the user (we never generate one), but its `data` attr is auto-managed
from the rule's `entry_point` / `srcs` imports. Same lifecycle as stock
`js_binary`, just under the gazelle_ts namespace so consumers can swap
implementations through map_kind without rewriting their gazelle config.

The gazelle_ts module deliberately does not take a transitive
`aspect_rules_ts` or `aspect_rules_js` dependency, so the macros can't
live here.

The fallbacks below collect matched files into a filegroup with a debug
print so the BUILD still loads and gazelle can run â but the files are
NOT typechecked or executed. To get a real compilation/test/binary unit,
add to your root BUILD:

    # gazelle:map_kind ts_library         <macro> <load_path>
    # gazelle:map_kind ts_test            <macro> <load_path>
    # gazelle:map_kind ts_visual_library   <macro> <load_path>
    # gazelle:map_kind ts_binary          <macro> <load_path>
    # gazelle:map_kind ts_bundler_config  <macro> <load_path>

and re-run gazelle. See `examples/advanced/tools/ts.bzl` for one-line
wrappers.
 