�t
5
gloopgloop/tools/build_defs/cccc_embed_data.bzl�occ_embed_data�(
Add `load("//tools/build_defs/cc:cc_embed_data.bzl", "cc_embed_data")` to BUILD file.
`cc_embed_data()` encapsulates a collection of files, as-is, into an object file, so that their
contents are accessible from the program as constant byte arrays.

A *table of contents* is generated, containing the information needed to refer to those bytes.
This is an array of name-&gt;value pairs.  Each name is the name of a source data file. The
corresponding value is the address of that file's data and the length of that file's data.

The `cc_embed_data` rule works like a `cc_library` - it compiles the generated code, and it should
be placed in the deps attribute of dependent rules.

Either two or three output files are generated, based on the `outs` attribute.
* A `.h` file, containing the declarations for the table of contents, is always generated. This
  header can be included from rules that directly depend on the `cc_embed_data` rule.
* A `.cc` file, containing the data for the table of contents, is always generated and compiled.
* A `_data.o` file, containing the wrapped files, is optionally generated. If the `_data.o` file is
  not mentioned in `outs`, the wrapped files are instead encapuslated in the `.cc` file. (This is
  useful on platforms where the `_data.o` file cannot be generated directly.)

#### Notes

* *Either two or three output files must be listed.* It is an error to declare fewer than two or
  more than three files, or to declare files that do not match the pattern above.

* *The order of the files in the table of contents is the same as their order in the `srcs`
  attribute.*

* The tool that does the work is `//tools:filewrapper`. Please direct questions about it to
  the bazel team via <link>.

#### Examples
This example shows how one can encapsulate some graphics, JavaScript, and a stylesheet, to be
embedded in a program that needs them for its web console.

```
# from <path>

cc_embed_data(
    name = "this_package_resources",  # must be unique, see attribute documentation
    srcs = [
        "resources/console.css",
        "resources/overlib.js",
        "resources/sorttable.js",
        "resources/r10.png",
        "resources/dr10.png",
        "resources/g10.png",
        "resources/dg10.png",
        "resources/k10.png",
    ],
    outs = [
        "this_package_resources.cc",
        "this_package_resources.h",
        "this_package_resources_data.o",
    ],
    embedopts = ["--namespace=my_monitoring"],
    strip = "resources",  # remove the directory name
)
```
For backwards compatibility, it is still possible to place the rule into the srcs of a cc_library.
However, the recommended style is to reference it only in the deps, as shown here.

```
cc_library(
    name = "b3m",
    srcs = [
        ...
        "b3m.cc",
    ],
    deps = [
        ...
        ":this_package_resources",
    ],
)
```
The generated header file contains the declarations needed to access the encapsulated files.

```
/* The canonical definition is in "gloop/base/file_toc.h". */
struct FileToc {
  const char* name;             // the file's original name
  const char* data;             // beginning of the file
  size_t size;                  // length of the file
  unsigned char md5digest[16];  // MD5 digest of the file
};
namespace my_monitoring {
extern const struct FileToc* this_package_resources_create();  // name_create()
}  // my_monitoring namespace
```

For most purposes, you can obtain the definition of this structure simply by #including the `rule.h`
generated header file.  If you're writing a program that manipulates `FileToc` objects generically
and do not have access to a generated header, do not copy-and-paste the above declaration, but
instead `#include gloop/base/file_toc.h`. This will insulate you against breakage caused
by future changes in this structure.

The data in memory is always followed by a `NUL` character (ASCII 0), so if the original
file contains no embedded `NUL` characters, `data` can be treated as a C string.  The extra `NUL` is
not counted in the `size` or `md5digest` fields; `size` will be the length of the original file,
and `md5digest` will be its MD5 digest.

The `name_create()` procedure returns an array of table-of-contents entries. The
array is terminated with an entry in which all fields are set to `NULL`. The code needed
to use this is simple:

```
for (const FileToc* p = this_package_resources_create() ; p->name != nullptr ; ++p) {
  //  p->name       has the file name - "console.css".
  //  p->data       points to the start of the data.
  //  p->size       has the size of the data.
  //  p->md5digest  has the MD5 digest of the data.
}
```

The name will be used to generate an external symbol, so it must be globally unique. The compiler
might *not* warn you otherwise, leading to subtle and time-consuming bugs. This constraint may be
relaxed by passing the `--namespace=` argument in `embedopts`, which makes the generated code be in
the specified C++ namespace. In that case, the name must be unique only within that namespace.

`data`, `deps`, `deprecation`, `distribs`, and `licenses` attributes are not permitted.
"�G
�8
cc_embed_data�(
Add `load("//tools/build_defs/cc:cc_embed_data.bzl", "cc_embed_data")` to BUILD file.
`cc_embed_data()` encapsulates a collection of files, as-is, into an object file, so that their
contents are accessible from the program as constant byte arrays.

A *table of contents* is generated, containing the information needed to refer to those bytes.
This is an array of name-&gt;value pairs.  Each name is the name of a source data file. The
corresponding value is the address of that file's data and the length of that file's data.

The `cc_embed_data` rule works like a `cc_library` - it compiles the generated code, and it should
be placed in the deps attribute of dependent rules.

Either two or three output files are generated, based on the `outs` attribute.
* A `.h` file, containing the declarations for the table of contents, is always generated. This
  header can be included from rules that directly depend on the `cc_embed_data` rule.
* A `.cc` file, containing the data for the table of contents, is always generated and compiled.
* A `_data.o` file, containing the wrapped files, is optionally generated. If the `_data.o` file is
  not mentioned in `outs`, the wrapped files are instead encapuslated in the `.cc` file. (This is
  useful on platforms where the `_data.o` file cannot be generated directly.)

#### Notes

* *Either two or three output files must be listed.* It is an error to declare fewer than two or
  more than three files, or to declare files that do not match the pattern above.

* *The order of the files in the table of contents is the same as their order in the `srcs`
  attribute.*

* The tool that does the work is `//tools:filewrapper`. Please direct questions about it to
  the bazel team via <link>.

#### Examples
This example shows how one can encapsulate some graphics, JavaScript, and a stylesheet, to be
embedded in a program that needs them for its web console.

```
# from <path>

cc_embed_data(
    name = "this_package_resources",  # must be unique, see attribute documentation
    srcs = [
        "resources/console.css",
        "resources/overlib.js",
        "resources/sorttable.js",
        "resources/r10.png",
        "resources/dr10.png",
        "resources/g10.png",
        "resources/dg10.png",
        "resources/k10.png",
    ],
    outs = [
        "this_package_resources.cc",
        "this_package_resources.h",
        "this_package_resources_data.o",
    ],
    embedopts = ["--namespace=my_monitoring"],
    strip = "resources",  # remove the directory name
)
```
For backwards compatibility, it is still possible to place the rule into the srcs of a cc_library.
However, the recommended style is to reference it only in the deps, as shown here.

```
cc_library(
    name = "b3m",
    srcs = [
        ...
        "b3m.cc",
    ],
    deps = [
        ...
        ":this_package_resources",
    ],
)
```
The generated header file contains the declarations needed to access the encapsulated files.

```
/* The canonical definition is in "gloop/base/file_toc.h". */
struct FileToc {
  const char* name;             // the file's original name
  const char* data;             // beginning of the file
  size_t size;                  // length of the file
  unsigned char md5digest[16];  // MD5 digest of the file
};
namespace my_monitoring {
extern const struct FileToc* this_package_resources_create();  // name_create()
}  // my_monitoring namespace
```

For most purposes, you can obtain the definition of this structure simply by #including the `rule.h`
generated header file.  If you're writing a program that manipulates `FileToc` objects generically
and do not have access to a generated header, do not copy-and-paste the above declaration, but
instead `#include gloop/base/file_toc.h`. This will insulate you against breakage caused
by future changes in this structure.

The data in memory is always followed by a `NUL` character (ASCII 0), so if the original
file contains no embedded `NUL` characters, `data` can be treated as a C string.  The extra `NUL` is
not counted in the `size` or `md5digest` fields; `size` will be the length of the original file,
and `md5digest` will be its MD5 digest.

The `name_create()` procedure returns an array of table-of-contents entries. The
array is terminated with an entry in which all fields are set to `NULL`. The code needed
to use this is simple:

```
for (const FileToc* p = this_package_resources_create() ; p->name != nullptr ; ++p) {
  //  p->name       has the file name - "console.css".
  //  p->data       points to the start of the data.
  //  p->size       has the size of the data.
  //  p->md5digest  has the MD5 digest of the data.
}
```

The name will be used to generate an external symbol, so it must be globally unique. The compiler
might *not* warn you otherwise, leading to subtle and time-consuming bugs. This constraint may be
relaxed by passing the `--namespace=` argument in `embedopts`, which makes the generated code be in
the specified C++ namespace. In that case, the name must be unique only within that namespace.

`data`, `deps`, `deprecation`, `distribs`, and `licenses` attributes are not permitted.
*
nameA unique name for this target. .

alwayslink
See <link>.alwayslink
2Falsec
	embedoptsP
A list of options that will simply be passed through to `//tools:filewrapper`.
2[]�
flatten�
If non-zero, the leading path components are removed from each `srcs` file.

The `srcs` list may contain files that are pulled in from other parts of `google3`. `flatten = 1`
prevents the `//directory/path/at/the/beginning` from cluttering up the names in the table of
contents, preserving only the base name of the file. `flatten` overrides `strip`. This only affects
how the names are stored in the table of contents.
2False.

linkstatic
See <link>.linkstatic
2False�
outs�
A list of output files generated by this rule.

You can provide names for all three of the generated files or omit the `*.o`. They are recognized by their
suffixes: `.cc`;`.h`; and `_data.o`. The build system enforces that all output files go in the
same directory.
�
redact_filename�
If true, the `name` member of the FileToc structure will be empty. This is useful if the binary
is published externally, for example in an Android app, and the file name would leak information
about unreleased products or features.
2False�
srcs�"
The data files to be encapsulated.

These names also identify the files in the table of contents.  If the files are all in a
subdirectory, you can use the `strip` argument to remove the directory name.
2[]�
strip�
A leading directory name to be removed from the beginning of each `srcs` file.

It's likely that a package's to-be-wrapped files will be kept in a subdirectory.  The `strip`
option removes the directory name.  This only affects how the names are stored in the table of
contents.

The package of the label that declares the embed rule will be stripped automatically.

Example values: "`statstables/splits`", "`resources`", "`//mydata/resources/names_prefixes`".
2"""E
cc_embed_data4@@gloop//gloop/tools/build_defs/cc:cc_embed_data.bzl
��,
*
nameA unique name for this target. 0
.

alwayslink
See <link>.alwayslink
2Falsee
c
	embedoptsP
A list of options that will simply be passed through to `//tools:filewrapper`.
2[]�
�
flatten�
If non-zero, the leading path components are removed from each `srcs` file.

The `srcs` list may contain files that are pulled in from other parts of `google3`. `flatten = 1`
prevents the `//directory/path/at/the/beginning` from cluttering up the names in the table of
contents, preserving only the base name of the file. `flatten` overrides `strip`. This only affects
how the names are stored in the table of contents.
2False0
.

linkstatic
See <link>.linkstatic
2False�
�
outs�
A list of output files generated by this rule.

You can provide names for all three of the generated files or omit the `*.o`. They are recognized by their
suffixes: `.cc`;`.h`; and `_data.o`. The build system enforces that all output files go in the
same directory.
�
�
redact_filename�
If true, the `name` member of the FileToc structure will be empty. This is useful if the binary
is published externally, for example in an Android app, and the file name would leak information
about unreleased products or features.
2False�
�
srcs�"
The data files to be encapsulated.

These names also identify the files in the table of contents.  If the files are all in a
subdirectory, you can use the `strip` argument to remove the directory name.
2[]�
�
strip�
A leading directory name to be removed from the beginning of each `srcs` file.

It's likely that a package's to-be-wrapped files will be kept in a subdirectory.  The `strip`
option removes the directory name.  This only affects how the names are stored in the table of
contents.

The package of the label that declares the embed rule will be stripped automatically.

Example values: "`statstables/splits`", "`resources`", "`//mydata/resources/names_prefixes`".
2""a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.�
//cc:find_cc_toolchain.bzlr�
%
rules_ccccfind_cc_toolchain.bzl4
find_cc_toolchainfind_cc_toolchain
.?2
use_cc_toolchainuse_cc_toolchain
CS
Uy
//cc/common:cc_common.bzlrZ
$
rules_cc	cc/commoncc_common.bzl$
	cc_common	cc_common
-6
8o
//cc/common:cc_info.bzlrR
"
rules_cc	cc/commoncc_info.bzl
CcInfoCcInfo
+1
3*Starlark implementation of cc_embed_data.
�
8
gloop&gloop/tools/build_rules/text_to_binarydef.bzl�anticodex_tool$Converts text file into binary file.*�
�
anticodex_tool)
nameThe name of the build target. (5
src*A text formatted protocol buffer (<link>). (#
outThe name of output file. ((
outputThe format of output file. (@
proto1The name of the protocol message to output value.""(Q

proto_deps;proto targets to use to support the protobuf output format.None(C
output_to_bindir'output_to_bindir attribute for genrule.None(h
descriptor_setNA transitive_descriptor_set target. If this is
provided, don't set proto_deps.None(3
kwargs'Other args to be passed on to genrules.($Converts text file into binary file.2I
anticodex_tool7@@gloop//gloop/tools/build_rules/text_to_binary:def.bzl
``*rule2rule�

proto_dataJConverts a protocol buffer in text format into the standard binary format.*�	
�	

proto_data)
nameThe name of the build target. (5
src*A text formatted protocol buffer (<link>). (^

proto_nameLThe name of the message type in the .proto files that "src" file
represents. (�

proto_depspThe list of proto_library targets where "proto" is defined.
Transitive dependencies are pulled in automatically.None(�
out�(optional) The name of output file. If out is not set then name of
output file is name + ".binarypb" extension (or ".jspb", ".json").None(�

out_formatd(optional) The format of the output file.
Can be "binarypb", "jspb", or "json", default is binarypb.
"binarypb"(C
output_to_bindir'output_to_bindir attribute for genrule.None(h
descriptor_setNA transitive_descriptor_set target. If this is
provided, don't set proto_deps.None(w
include_test^(optional) If true a build_test will be created for the proto_data rule. The
default is false.False(;
	test_tags(Tag supplied by user for the build_test.[](9
kwargs-Other args to be passed on to anticodex_tool.(JConverts a protocol buffer in text format into the standard binary format.2E

proto_data7@@gloop//gloop/tools/build_rules/text_to_binary:def.bzl
''*anticodex_tool2anticodex_tool2
build_testy
//rules:build_test.bzlr]
%
bazel_skylibrulesbuild_test.bzl&

build_test
build_test
.8
:�
//bazel/common:proto_info.bzlr^
(
protobufbazel/commonproto_info.bzl$
	ProtoInfo	ProtoInfo
1:
<D
BUILD rules for converting text files into various binary formats.
 