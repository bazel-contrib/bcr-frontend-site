�
-
google_bazel_commontestingtest_defs.bzl�gen_android_local_tests�Generates `android_local_test` rules for each file in `srcs` ending in "Test.java".

All other files will be compiled in a supporting `android_library` that is
passed as a dep to each of the generated test rules.

The arguments to this macro match those of the `android_library` and
`android_local_test` rules. The arguments prefixed with `lib_` will be
passed to the generated supporting `android_library` and not the tests, and
vice versa for arguments prefixed with `test_`. For example, passing `deps =
[:a], lib_deps = [:b], test_deps = [:c]` will result in a `android_library`
that has `deps = [:a, :b]` and `android_local_test`s that have `deps =
[:a, :c]`.
*�	
�	
gen_android_local_tests

name (

srcs (

deps (�
prefix_path�(string) The prefix between the current package path and the source
file paths, which will be eliminated when determining test class names.None(
lib_depsNone(
	test_depsNone(
pluginsNone(
lib_pluginsNone(
test_pluginsNone(
	javacoptsNone(
lib_javacoptsNone(
test_javacoptsNone(
	jvm_flagsNone(

kwargs(�Generates `android_local_test` rules for each file in `srcs` ending in "Test.java".

All other files will be compiled in a supporting `android_library` that is
passed as a dep to each of the generated test rules.

The arguments to this macro match those of the `android_library` and
`android_local_test` rules. The arguments prefixed with `lib_` will be
passed to the generated supporting `android_library` and not the tests, and
vice versa for arguments prefixed with `test_`. For example, passing `deps =
[:a], lib_deps = [:b], test_deps = [:c]` will result in a `android_library`
that has `deps = [:a, :b]` and `android_local_test`s that have `deps =
[:a, :c]`.
2G
gen_android_local_tests,@@google_bazel_common//testing:test_defs.bzl
DD*_gen_java_tests�gen_java_tests�Generates `java_test` rules for each file in `srcs` ending in "Test.java".

All other files will be compiled in a supporting `java_library` that is passed
as a dep to each of the generated `java_test` rules.

The arguments to this macro match those of the `java_library` and `java_test`
rules. The arguments prefixed with `lib_` will be passed to the generated
supporting `java_library` and not the tests, and vice versa for arguments
prefixed with `test_`. For example, passing `deps = [:a], lib_deps = [:b],
test_deps = [:c]` will result in a `java_library` that has `deps = [:a, :b]`
and `java_test`s that have `deps = [:a, :c]`.
*�	
�
gen_java_tests

name (

srcs (

deps (�
prefix_path�(string) The prefix between the current package path and the source
file paths, which will be eliminated when determining test class names.None(
lib_depsNone(
	test_depsNone(
pluginsNone(
lib_pluginsNone(
test_pluginsNone(
	javacoptsNone(
lib_javacoptsNone(
test_javacoptsNone(
	jvm_flagsNone(

kwargs(�Generates `java_test` rules for each file in `srcs` ending in "Test.java".

All other files will be compiled in a supporting `java_library` that is passed
as a dep to each of the generated `java_test` rules.

The arguments to this macro match those of the `java_library` and `java_test`
rules. The arguments prefixed with `lib_` will be passed to the generated
supporting `java_library` and not the tests, and vice versa for arguments
prefixed with `test_`. For example, passing `deps = [:a], lib_deps = [:b],
test_deps = [:c]` will result in a `java_library` that has `deps = [:a, :b]`
and `java_test`s that have `deps = [:a, :c]`.
2>
gen_java_tests,@@google_bazel_common//testing:test_defs.bzl
*_gen_java_tests�
//java:defs.bzlr~


rules_javajavadefs.bzl*
java_libraryjava_library
%1$
	java_test	java_test
5>
@+Skylark macros to simplify declaring tests.�
/
google_bazel_commontools/jarjar
jarjar.bzl*�ModuleInfo request error: invalid argument: Traceback (most recent call last):
	File "external/google_bazel_common/tools/jarjar/jarjar.bzl", line 17, column 37, in <toplevel>
		load("@rules_java//java:defs.bzl", "java_common")
Error: file '@rules_java//java:defs.bzl' does not contain symbol 'java_common'�
1
google_bazel_commontools/javadocjavadoc.bzl*�ModuleInfo request error: invalid argument: Traceback (most recent call last):
	File "external/google_bazel_common/tools/javadoc/javadoc.bzl", line 18, column 49, in <toplevel>
		load("@rules_java//java:defs.bzl", "JavaInfo", "java_common")
Error: file '@rules_java//java:defs.bzl' does not contain symbol 'java_common'�.
0
google_bazel_commontools/mavenpom_file.bzl�pom_file�
Creates a Maven POM file for `targets`.

This rule scans the deps, runtime_deps, and exports of `targets` and their transitive exports,
checking each for tags of the form `maven_coordinates=<coords>`. These tags are used to build
the list of Maven dependencies for the generated POM.

Users should call this rule with a `template_file` that contains a `{generated_bzl_deps}`
placeholder. The rule will replace this with the appropriate XML for all dependencies.
Additional placeholders to replace can be passed via the `substitutions` argument.

The dependencies included will be sorted alphabetically by groupId, then by artifactId. The
`preferred_group_ids` can be used to specify groupIds (or groupId-prefixes) that should be
sorted ahead of other artifacts. Artifacts in the same group will be sorted alphabetically.

Args:
  name: the name of target. The generated POM file will use this name, with `.xml` appended
  targets: a list of build target(s) that represent this POM file
  template_file: a pom.xml file that will be used as a template for the generated POM
  substitutions: an optional mapping of placeholders to replacement values that will be applied
    to the `template_file` (e.g. `{'GROUP_ID': 'com.example.group'}`). `{pom_version}` is
    implicitly included in this mapping and can be configured by passing `bazel build
    --define=pom_version=<version>`.
  preferred_group_ids: an optional list of maven groupIds that will be used to sort the
    generated deps.
  excluded_artifacts: an optional list of maven artifacts in the format "groupId:artifactId"
    that should be excluded from the generated pom file.
"�
�
pom_file�
Creates a Maven POM file for `targets`.

This rule scans the deps, runtime_deps, and exports of `targets` and their transitive exports,
checking each for tags of the form `maven_coordinates=<coords>`. These tags are used to build
the list of Maven dependencies for the generated POM.

Users should call this rule with a `template_file` that contains a `{generated_bzl_deps}`
placeholder. The rule will replace this with the appropriate XML for all dependencies.
Additional placeholders to replace can be passed via the `substitutions` argument.

The dependencies included will be sorted alphabetically by groupId, then by artifactId. The
`preferred_group_ids` can be used to specify groupIds (or groupId-prefixes) that should be
sorted ahead of other artifacts. Artifacts in the same group will be sorted alphabetically.

Args:
  name: the name of target. The generated POM file will use this name, with `.xml` appended
  targets: a list of build target(s) that represent this POM file
  template_file: a pom.xml file that will be used as a template for the generated POM
  substitutions: an optional mapping of placeholders to replacement values that will be applied
    to the `template_file` (e.g. `{'GROUP_ID': 'com.example.group'}`). `{pom_version}` is
    implicitly included in this mapping and can be configured by passing `bazel build
    --define=pom_version=<version>`.
  preferred_group_ids: an optional list of maven groupIds that will be used to sort the
    generated deps.
  excluded_artifacts: an optional list of maven artifacts in the format "groupId:artifactId"
    that should be excluded from the generated pom file.
*
nameA unique name for this target. 
excluded_artifacts2[]
preferred_group_ids2[]
substitutions
2{}
targets 
template_file2None";
pom_file/@@google_bazel_common//tools/maven:pom_file.bzl
��,
*
nameA unique name for this target. 

excluded_artifacts2[]

preferred_group_ids2[]

substitutions
2{}

targets 

template_file2None�pom_file_tests%Tests for `pom_file` and `MavenInfo`.*�
z
pom_file_tests%Tests for `pom_file` and `MavenInfo`.2A
pom_file_tests/@@google_bazel_common//tools/maven:pom_file.bzl
��"_maven_info_test�	MavenInfo2�
�
	MavenInfo�
maven_artifacts�
The Maven coordinates for the artifacts that are exported by this target: i.e. the target
itself and its transitively exported targets.
�
maven_dependenciesj
The Maven coordinates of the direct dependencies, and the transitively exported targets, of
this target.
"<
	MavenInfo/@@google_bazel_common//tools/maven:pom_file.bzl
�
�
maven_artifacts�
The Maven coordinates for the artifacts that are exported by this target: i.e. the target
itself and its transitively exported targets.
�
�
maven_dependenciesj
The Maven coordinates of the direct dependencies, and the transitively exported targets, of
this target.
�
//lib:unittest.bzlrw
!
bazel_skyliblibunittest.bzl 
assertsasserts
*1"
unittestunittest
5=
?m
//java:defs.bzlrX


rules_javajavadefs.bzl*
java_libraryjava_library
%1
3�		DEP_BLOCKk<dependency>
  <groupId>{0}</groupId>
  <artifactId>{1}</artifactId>
  <version>{2}</version>
</dependency>jmk<dependency>
  <groupId>{0}</groupId>
  <artifactId>{1}</artifactId>
  <version>{2}</version>
</dependency>�	DEP_PKG_BLOCK�<dependency>
  <groupId>{0}</groupId>
  <artifactId>{1}</artifactId>
  <packaging>{2}</packaging>
  <version>{3}</version>
</dependency>j��<dependency>
  <groupId>{0}</groupId>
  <artifactId>{1}</artifactId>
  <packaging>{2}</packaging>
  <version>{3}</version>
</dependency>�	CLASSIFIER_DEP_BLOCK�<dependency>
  <groupId>{0}</groupId>
  <artifactId>{1}</artifactId>
  <version>{2}</version>
  <type>{3}</type>
  <classifier>{4}</classifier>
</dependency>j��<dependency>
  <groupId>{0}</groupId>
  <artifactId>{1}</artifactId>
  <version>{2}</version>
  <type>{3}</type>
  <classifier>{4}</classifier>
</dependency>:Skylark rules to make publishing Maven artifacts simpler.
 