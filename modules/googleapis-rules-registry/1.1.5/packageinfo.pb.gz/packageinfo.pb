�
/@@googleapis-rules-registry//private/extensionsf/home/sol/.bazel/execroot/_main/work/external/googleapis-rules-registry/private/extensions/BUILD.bazel 