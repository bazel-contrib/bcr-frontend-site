�
-

googleapisgoogle/mapspostprocessing.bzl�
maps_assembly_pkg�Target to build a post-processed ads-specific GAPIC assembly package.

Explodes a GAPIC assembly package, runs language-specific post-processing, and repackages.

This macro assumes srcs contains in a single input, namely a {{language}}_assembly_pkg target
produced by a gapic-generator build target.

There must be a corresponding postprocessing_{language}.sh script to invoke.
*�
�
maps_assembly_pkg/
name#defines the name of the main target (
srcsscollection containing exactly 1 build target, namely a
{{language}}_assembly_pkg target produced by gapic-generator (�
language�the programming language to post-process
(e.g., "java", "csharp", "php", etc.); there must be a matching
post-processin script of the form `postprocessing_{language}.sh
in this package (r

visibility\marco visibility setting;
(see https://docs.bazel.build/versions/master/skylark/macros.html)None(�Target to build a post-processed ads-specific GAPIC assembly package.

Explodes a GAPIC assembly package, runs language-specific post-processing, and repackages.

This macro assumes srcs contains in a single input, namely a {{language}}_assembly_pkg target
produced by a gapic-generator build target.

There must be a corresponding postprocessing_{language}.sh script to invoke.
2A
maps_assembly_pkg,@@googleapis//google/maps:postprocessing.bzl
2native.genruleA
Defines the postprocessing build rule for the Google Maps APIs.
�



googleapisload_json.bzl�
	load_jsonR�

�
	load_json.
name"A unique name for this repository. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 *
srca JSON file2//:example-file.jsonT
variable_name1symbol to define by the contents of the JSON file2"version_json"*)
	load_json@@googleapis//:load_json.bzl
0
.
name"A unique name for this repository. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 ,
*
srca JSON file2//:example-file.jsonV
T
variable_name1symbol to define by the contents of the JSON file2"version_json"-Helper to load configuration from JSON files.�&
"

googleapisrepository_rules.bzl�switched_rules_by_language�Switches rules in the generated imports.bzl between no-op and the actual implementation.

This defines which language-specific rules (or client type specific, like grpc or gapic) should
be enabled during the build. All non-enabled language-specific rules will default to no-op
implementations. Examples of the language-specific rules are: java_gapic_library
(Java-specific), go_proto_library (Go-specific), proto_library_with_info (gapic-specific) etc.
Note, proto_library rule is always enabled.

For example, to use this rule and enable Java and Go rules, add the following in the external
repository which imports com_google_googleapis repository and its corresponding dependencies:

    load("@com_google_googleapis//:repository_rules.bzl", "switched_rules_by_language")

    switched_rules_by_language(
        name = "com_google_googleapis_imports",
        grpc = True,
        gapic = True,
        go = True,
        java = True,
    )

Note, for build to work you should also import the language-specific transitive dependencies.
*�
�
switched_rules_by_languageP
nameDname of a target, is expected to be "com_google_googleapis_imports". (�
gapic�Enable GAPIC specific rules. The GAPIC rules are also language-specific, so
the actual enabled rules will be determined by the other language-specific arguments of
this rule. False by default.False(�
grpc�Enable gRPC specific rules. The gRPC rules are also language-specific, so
the actual enabled rules will be determined by the other language-specific arguments of
this rule. False by default.False(>
java-Enable Java specific rules. False by default.False(:
go+Enable Go specific rules. False by default.False(e
ccVEnable C++ specific rules. False by default. Partially implemented (no GAPIC
support).False(<
php,Enable PHP specific rules. False by default.False(C
nodejs0Enable Node.js specific rules. False by default.False(B
python/Enable Python-specific rules. False by default.False(>
ruby-Enable Ruby specific rules. False by default.False(>
csharp+Enable C# specific rules. False by default.False(�
go_test�A special temporary flag to disable only go_test targets. This is needed to
support rules_go version 0.24.0+, which made importmap duplicates an error instead of a
warning. More details: https://github.com/bazelbuild/rules_go/issues/1986.False(C
rules_override+Custom rule overrides (for advanced usage).{}(�Switches rules in the generated imports.bzl between no-op and the actual implementation.

This defines which language-specific rules (or client type specific, like grpc or gapic) should
be enabled during the build. All non-enabled language-specific rules will default to no-op
implementations. Examples of the language-specific rules are: java_gapic_library
(Java-specific), go_proto_library (Go-specific), proto_library_with_info (gapic-specific) etc.
Note, proto_library rule is always enabled.

For example, to use this rule and enable Java and Go rules, add the following in the external
repository which imports com_google_googleapis repository and its corresponding dependencies:

    load("@com_google_googleapis//:repository_rules.bzl", "switched_rules_by_language")

    switched_rules_by_language(
        name = "com_google_googleapis_imports",
        grpc = True,
        gapic = True,
        go = True,
        java = True,
    )

Note, for build to work you should also import the language-specific transitive dependencies.
2A
switched_rules_by_language#@@googleapis//:repository_rules.bzl
882switched_rules�switched_rulesR�
�
switched_rules.
name"A unique name for this repository. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 
rules *5
switched_rules#@@googleapis//:repository_rules.bzl
-!-!0
.
name"A unique name for this repository. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 

rules �Repository rules and macros which are expected to be called from WORKSPACE file of either
googleapis itself or any third_party repository which consumes googleapis as its dependency.
 