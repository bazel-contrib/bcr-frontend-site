�
"

googletestfake_fuchsia_sdk.bzl�	fake_fuchsia_sdkFUsed to create a fake @fuchsia_sdk repository with stub build targets.R�
�
fake_fuchsia_sdkFUsed to create a fake @fuchsia_sdk repository with stub build targets..
name"A unique name for this repository. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 *7
fake_fuchsia_sdk#@@googletest//:fake_fuchsia_sdk.bzl
##0
.
name"A unique name for this repository. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �fuchsia_sdkJq
P
fuchsia_sdk
create_fake"2
fuchsia_sdk#@@googletest//:fake_fuchsia_sdk.bzl
::

create_fake�Provides a fake @fuchsia_sdk implementation that's used when the real one isn't available.

GoogleTest can be used with the [Fuchsia](https://fuchsia.dev/) SDK. However,
because the Fuchsia SDK does not yet support bzlmod, GoogleTest's `MODULE.bazel`
file by default provides a "fake" Fuchsia SDK.

To override this and use the real Fuchsia SDK, you can add the following to your
project's `MODULE.bazel` file:

    fake_fuchsia_sdk_extension =
    use_extension("@com_google_googletest//:fake_fuchsia_sdk.bzl", "fuchsia_sdk")
    override_repo(fake_fuchsia_sdk_extension, "fuchsia_sdk")

NOTE: The `override_repo` built-in is only available in Bazel 8.0 and higher.

See https://github.com/google/googletest/issues/4472 for more details of why the
fake Fuchsia SDK is needed.
�
!

googletestgoogletest_deps.bzl�googletest_deps?Loads common dependencies needed to use the googletest library.*�
�
googletest_deps?Loads common dependencies needed to use the googletest library.25
googletest_deps"@@googletest//:googletest_deps.bzl
�
 //tools/build_defs/repo:http.bzlrj
.
bazel_toolstools/build_defs/repohttp.bzl*
http_archivehttp_archive
7C
EOLoad dependencies needed to use the googletest library as a 3rd-party consumer. 