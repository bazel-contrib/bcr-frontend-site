�
!
hdlf_texlive_packagesdefs.bzl�tex_package_filesJLinks the files of TeX packages into this package, under their bare names."�
�
tex_package_filesJLinks the files of TeX packages into this package, under their bare names.*
nameA unique name for this target. a
srcsSPackages of this module, such as `@hdlf_texlive_packages//pgf`, or any other files.2[]"7
tex_package_files"@@hdlf_texlive_packages//:defs.bzl
++,
*
nameA unique name for this target. c
a
srcsSPackages of this module, such as `@hdlf_texlive_packages//pgf`, or any other files.2[]�Puts TeX package files next to a LaTeX document.

pdflatex looks for a class or a style file in its working directory, by
its bare name. A LaTeX rule such as rules_latex_host's latex_document
copies each `data` file there under its path relative to the
document's package, so a file from this module, at
`external/hdlf_texlive_packages+/pgf/tikz.sty`, would land at a path that
starts with `..` and never be found.

tex_package_files links every file of the packages it is given into the
calling package, under its bare name, so that passing the target as
`data` puts each file where pdflatex looks:

    load("@hdlf_texlive_packages//:defs.bzl", "tex_package_files")

    tex_package_files(
        name = "tex_packages",
        srcs = [
            "@hdlf_texlive_packages//ieeetran",
            "@hdlf_texlive_packages//pgf",
        ],
    )

    latex_document(
        name = "paper",
        main = "paper.tex",
        data = [":tex_packages"],
    )

Two files with one bare name are an error: the build fails rather than
pick one.
 