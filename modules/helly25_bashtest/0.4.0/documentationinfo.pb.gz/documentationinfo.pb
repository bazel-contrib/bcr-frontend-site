�
*
helly25_bashtestbashtestbashtest.bzl�bashtest�Bashtest wrapper.

Specialized `sh_shell` rule to simplify `bashtest` usage. The rule provides
the `helly25_bashtest` environement variable that should
be used in test scripts to source the `bashtest.sh` script as follows:

* File: sh_test.sh

```sh
set -euo pipefail

# shellcheck disable=SC1090,SC1091,SC2154
source "${helly25_bashtest}"

test::my_test() {
  expect_ne "Hello" "World"
  # Your tests go here...
}

# More tests go here...

test_runner
```

* File: BUILD

```bzl
load("@helly25_bashtest//bashtest:bashtest.bzl", "bashtest")

bashtest(
    name = "sh_test",
    srcs = ["sh_test.sh"],
)
```
*�
�
bashtest8
name,Name of the test rule. Should end in `_test` (K
deps=Dependencies which will have bashtest_sh automatically added.[](H
env;Environmentname that automatically adds `helly25_bashtest`.{}(:
kwargs.All other attributes are passed through as is.(�Bashtest wrapper.

Specialized `sh_shell` rule to simplify `bashtest` usage. The rule provides
the `helly25_bashtest` environement variable that should
be used in test scripts to source the `bashtest.sh` script as follows:

* File: sh_test.sh

```sh
set -euo pipefail

# shellcheck disable=SC1090,SC1091,SC2154
source "${helly25_bashtest}"

test::my_test() {
  expect_ne "Hello" "World"
  # Your tests go here...
}

# More tests go here...

test_runner
```

* File: BUILD

```bzl
load("@helly25_bashtest//bashtest:bashtest.bzl", "bashtest")

bashtest(
    name = "sh_test",
    srcs = ["sh_test.sh"],
)
```
25
bashtest)@@helly25_bashtest//bashtest:bashtest.bzl
*sh_test2sh_testl
//shell:sh_test.bzlrS
!
rules_shellshellsh_test.bzl 
sh_testsh_test
*1
3"helly25_bashtest/bashtest:bashtest 