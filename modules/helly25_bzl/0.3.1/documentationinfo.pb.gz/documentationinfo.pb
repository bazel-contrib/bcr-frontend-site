�
)
helly25_bzlbzl/versionsversions.bzl�A starlark implementation of versioning functions that mostly follow semver.

SEE [README.md](https://github.com/helly25/bzl/blob/main/README.md).
 