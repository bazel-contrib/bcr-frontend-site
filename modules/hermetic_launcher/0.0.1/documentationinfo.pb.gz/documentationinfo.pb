�
M
hermetic_launcherlauncher/private/providersfinalizer_toolchain_info.bzl�FinalizerToolchainInfoQInformation about a finalizer toolchain that can be used to finalize a template.
2�
�
FinalizerToolchainInfoQInformation about a finalizer toolchain that can be used to finalize a template.
-
	finalizer The finalizer executable (File)."f
FinalizerToolchainInfoL@@hermetic_launcher//launcher/private/providers:finalizer_toolchain_info.bzl
""/
-
	finalizer The finalizer executable (File).�	DOCQInformation about a finalizer toolchain that can be used to finalize a template.
jSQInformation about a finalizer toolchain that can be used to finalize a template.
@Defines providers for a finalizer tool a specific exec platform.�
Q
hermetic_launcherlauncher/private/providers stub_template_toolchain_info.bzl�TemplateToolchainInfoEInformation about a template binary toolchain that can be finalized.
2�
�
TemplateToolchainInfoEInformation about a template binary toolchain that can be finalized.
/
template_exeThe template executable (File)."i
TemplateToolchainInfoP@@hermetic_launcher//launcher/private/providers:stub_template_toolchain_info.bzl
!!1
/
template_exeThe template executable (File).�	DOCEInformation about a template binary toolchain that can be finalized.
jGEInformation about a template binary toolchain that can be finalized.
EDefines providers for a stub template for a specific target platform.�C
@
hermetic_launcherlauncher/private/ruleslauncher_binary.bzl�Alauncher_binary�Creates a tiny, binary launcher that wraps another executable with its runfiles.

This rule generates a small native binary (10-68KB depending on platform) that:
- Resolves Bazel runfiles paths at runtime
- Executes the target program with embedded arguments
- Forwards additional runtime arguments
- Exports runfiles environment variables to child processes
- Works identically on Linux, macOS, and Windows

The launcher automatically detects runfiles using RUNFILES_DIR, RUNFILES_MANIFEST_FILE,
or by looking for a <binary>.runfiles/ directory adjacent to the executable.

**Example - Wrapping openssl to hash a file:**

```python
load("@hermetic_launcher//launcher:launcher_binary.bzl", "launcher_binary")

launcher_binary(
    name = "hash_file",
    entrypoint = "@openssl",
    embedded_args = [
        "dgst",
        "-sha256",
        "$(rlocationpath :file_to_hash.txt)",
    ],
    data = [":file_to_hash.txt"],
)
```

The launcher will:
1. Resolve the openssl binary location through runfiles
2. Resolve file_to_hash.txt location through runfiles (auto-detected from $(rlocationpath))
3. Execute: `openssl dgst -sha256 /resolved/path/to/file_to_hash.txt`
4. Export RUNFILES_DIR, RUNFILES_MANIFEST_FILE, and JAVA_RUNFILES to the child process

**Runtime argument forwarding:**

Additional arguments passed to the binary are forwarded to the entrypoint:

```bash
bazel run //:hash_file -- --some-extra-flag
# Executes: openssl dgst -sha256 /resolved/path/to/file.txt --some-extra-flag
```

**Automatic path transformation:**

By default, the entrypoint (index 0) and any argument matching `$(rlocationpath ...)`
are automatically transformed through runfiles. You can customize this with `transformed_args`.

**Cross-platform:**

The same BUILD file works on Linux, macOS, and Windows. The launcher handles platform-specific
path separators and runfiles resolution automatically.
"�2
� 
launcher_binary�Creates a tiny, binary launcher that wraps another executable with its runfiles.

This rule generates a small native binary (10-68KB depending on platform) that:
- Resolves Bazel runfiles paths at runtime
- Executes the target program with embedded arguments
- Forwards additional runtime arguments
- Exports runfiles environment variables to child processes
- Works identically on Linux, macOS, and Windows

The launcher automatically detects runfiles using RUNFILES_DIR, RUNFILES_MANIFEST_FILE,
or by looking for a <binary>.runfiles/ directory adjacent to the executable.

**Example - Wrapping openssl to hash a file:**

```python
load("@hermetic_launcher//launcher:launcher_binary.bzl", "launcher_binary")

launcher_binary(
    name = "hash_file",
    entrypoint = "@openssl",
    embedded_args = [
        "dgst",
        "-sha256",
        "$(rlocationpath :file_to_hash.txt)",
    ],
    data = [":file_to_hash.txt"],
)
```

The launcher will:
1. Resolve the openssl binary location through runfiles
2. Resolve file_to_hash.txt location through runfiles (auto-detected from $(rlocationpath))
3. Execute: `openssl dgst -sha256 /resolved/path/to/file_to_hash.txt`
4. Export RUNFILES_DIR, RUNFILES_MANIFEST_FILE, and JAVA_RUNFILES to the child process

**Runtime argument forwarding:**

Additional arguments passed to the binary are forwarded to the entrypoint:

```bash
bazel run //:hash_file -- --some-extra-flag
# Executes: openssl dgst -sha256 /resolved/path/to/file.txt --some-extra-flag
```

**Automatic path transformation:**

By default, the entrypoint (index 0) and any argument matching `$(rlocationpath ...)`
are automatically transformed through runfiles. You can customize this with `transformed_args`.

**Cross-platform:**

The same BUILD file works on Linux, macOS, and Windows. The launcher handles platform-specific
path separators and runfiles resolution automatically.
*
nameA unique name for this target. �
data�Runtime dependencies (data files, scripts, etc.) needed by the entrypoint.

These files and their transitive runfiles will be included in the binary's runfiles tree,
making them available at runtime. Use `$(rlocationpath)` to reference these files in
`embedded_args`.

Example:
```python
data = [
    ":config.yaml",
    "//data:test_fixtures",
    "@some_external//:data_files",
]
```
2[]�
embedded_args�Arguments to embed in the binary that will be passed to the entrypoint.

These arguments are baked into the binary at build time. They support Bazel location
expansion (e.g., `$(rlocationpath)`, `$(location)`, `$(execpath)`).

Arguments matching the pattern `$(rlocationpath ...)` are automatically detected and marked
for runtime path transformation unless you explicitly set `transformed_args`.

Example:
```python
embedded_args = [
    "--config",
    "$(rlocationpath :config.yaml)",  # Auto-detected for transformation
    "--mode=production",               # Literal string, not transformed
]
```
2[]�

entrypoint�The target executable to wrap. This is the actual program that will be executed.

The entrypoint's runfiles path will be automatically resolved at runtime through the Bazel
runfiles mechanism. This must be an executable target (e.g., a binary, a script, or another
launcher_binary).

Example: `entrypoint = "@python_3_11//:python"` or `entrypoint = "//tools:my_tool"`
 �
transformed_args�Explicit list of argument indices that need runtime runfiles path transformation.

Index 0 is the entrypoint, index 1 is the first embedded arg, index 2 is the second, etc.

**Default behavior (empty list):**
- Entrypoint (index 0) is always transformed
- Any argument matching `$(rlocationpath ...)` is transformed
- Other arguments are passed as literal strings

**Custom behavior:**
Set explicit indices to transform:
```python
transformed_args = [0, 2, 5]  # Transform entrypoint, 2nd arg, and 5th arg
```

**Disable all transformation:**
```python
transformed_args = [-1]  # Special value: no transformation at all
```

Use this when you want fine-grained control over which paths are resolved through runfiles.
2[]"R
launcher_binary?@@hermetic_launcher//launcher/private/rules:launcher_binary.bzl
<<,
*
nameA unique name for this target. �
�
data�Runtime dependencies (data files, scripts, etc.) needed by the entrypoint.

These files and their transitive runfiles will be included in the binary's runfiles tree,
making them available at runtime. Use `$(rlocationpath)` to reference these files in
`embedded_args`.

Example:
```python
data = [
    ":config.yaml",
    "//data:test_fixtures",
    "@some_external//:data_files",
]
```
2[]�
�
embedded_args�Arguments to embed in the binary that will be passed to the entrypoint.

These arguments are baked into the binary at build time. They support Bazel location
expansion (e.g., `$(rlocationpath)`, `$(location)`, `$(execpath)`).

Arguments matching the pattern `$(rlocationpath ...)` are automatically detected and marked
for runtime path transformation unless you explicitly set `transformed_args`.

Example:
```python
embedded_args = [
    "--config",
    "$(rlocationpath :config.yaml)",  # Auto-detected for transformation
    "--mode=production",               # Literal string, not transformed
]
```
2[]�
�

entrypoint�The target executable to wrap. This is the actual program that will be executed.

The entrypoint's runfiles path will be automatically resolved at runtime through the Bazel
runfiles mechanism. This must be an executable target (e.g., a binary, a script, or another
launcher_binary).

Example: `entrypoint = "@python_3_11//:python"` or `entrypoint = "//tools:my_tool"`
 �
�
transformed_args�Explicit list of argument indices that need runtime runfiles path transformation.

Index 0 is the entrypoint, index 1 is the first embedded arg, index 2 is the second, etc.

**Default behavior (empty list):**
- Entrypoint (index 0) is always transformed
- Any argument matching `$(rlocationpath ...)` is transformed
- Other arguments are passed as literal strings

**Custom behavior:**
Set explicit indices to transform:
```python
transformed_args = [0, 2, 5]  # Transform entrypoint, 2nd arg, and 5th arg
```

**Disable all transformation:**
```python
transformed_args = [-1]  # Special value: no transformation at all
```

Use this when you want fine-grained control over which paths are resolved through runfiles.
2[]�
 //launcher/private/rules:lib.bzlrh
4
hermetic_launcherlauncher/private/ruleslib.bzl"
launcherlauncher
=E
G6
4
hermetic_launcherlauncher/private/ruleslib.bzl�
5
hermetic_launcherlauncher/privateextensions.bzl�non_module_dependenciesJz
j
non_module_dependencies"O
non_module_dependencies4@@hermetic_launcher//launcher/private:extensions.bzl
G+G+�
 //tools/build_defs/repo:http.bzlrd
.
bazel_toolstools/build_defs/repohttp.bzl$
	http_file	http_file
7@
B�
C
hermetic_launcherlauncher/privatestub_finalizer_toolchain.bzl�stub_finalizer_toolchain�Defines an image builder toolchain.

The image build tool can natively target any platform,
so it only has exec platform constraints.

See https://bazel.build/extending/toolchains#defining-toolchains.
"�
�
stub_finalizer_toolchain�Defines an image builder toolchain.

The image build tool can natively target any platform,
so it only has exec platform constraints.

See https://bazel.build/extending/toolchains#defining-toolchains.
*
nameA unique name for this target. ,
	finalizerA finalizer executable.2None"^
stub_finalizer_toolchainB@@hermetic_launcher//launcher/private:stub_finalizer_toolchain.bzl
! ! ,
*
nameA unique name for this target. .
,
	finalizerA finalizer executable.2None�
9//launcher/private/providers:finalizer_toolchain_info.bzlr�
M
hermetic_launcherlauncher/private/providersfinalizer_toolchain_info.bzl>
FinalizerToolchainInfoFinalizerToolchainInfo
Vl
n�	DOC�Defines an image builder toolchain.

The image build tool can natively target any platform,
so it only has exec platform constraints.

See https://bazel.build/extending/toolchains#defining-toolchains.
j��Defines an image builder toolchain.

The image build tool can natively target any platform,
so it only has exec platform constraints.

See https://bazel.build/extending/toolchains#defining-toolchains.
b	TOOLCHAIN_TYPE%@@//launcher:finalizer_toolchain_typej'%@@//launcher:finalizer_toolchain_type4Implementation of the stub_finalizer_toolchain rule.�
B
hermetic_launcherlauncher/privatestub_template_toolchain.bzl�stub_template_toolchain�Defines an stub template toolchain.

The template can be finalized to create a stub that runs some other tool.

See https://bazel.build/extending/toolchains#defining-toolchains.
"�
�
stub_template_toolchain�Defines an stub template toolchain.

The template can be finalized to create a stub that runs some other tool.

See https://bazel.build/extending/toolchains#defining-toolchains.
*
nameA unique name for this target. @
template_exe(A template binary that can be finalized.2None"\
stub_template_toolchainA@@hermetic_launcher//launcher/private:stub_template_toolchain.bzl
  ,
*
nameA unique name for this target. B
@
template_exe(A template binary that can be finalized.2None�
=//launcher/private/providers:stub_template_toolchain_info.bzlr�
Q
hermetic_launcherlauncher/private/providers stub_template_toolchain_info.bzl<
TemplateToolchainInfoTemplateToolchainInfo
Zo
q`	TOOLCHAIN_TYPE$@@//launcher:template_toolchain_typej&$@@//launcher:template_toolchain_type�	DOC�Defines an stub template toolchain.

The template can be finalized to create a stub that runs some other tool.

See https://bazel.build/extending/toolchains#defining-toolchains.
j��Defines an stub template toolchain.

The template can be finalized to create a stub that runs some other tool.

See https://bazel.build/extending/toolchains#defining-toolchains.
3Implementation of the stub_template_toolchain rule.�C
2
hermetic_launcherlauncherlauncher_binary.bzl�Alauncher_binary�Creates a tiny, binary launcher that wraps another executable with its runfiles.

This rule generates a small native binary (10-68KB depending on platform) that:
- Resolves Bazel runfiles paths at runtime
- Executes the target program with embedded arguments
- Forwards additional runtime arguments
- Exports runfiles environment variables to child processes
- Works identically on Linux, macOS, and Windows

The launcher automatically detects runfiles using RUNFILES_DIR, RUNFILES_MANIFEST_FILE,
or by looking for a <binary>.runfiles/ directory adjacent to the executable.

**Example - Wrapping openssl to hash a file:**

```python
load("@hermetic_launcher//launcher:launcher_binary.bzl", "launcher_binary")

launcher_binary(
    name = "hash_file",
    entrypoint = "@openssl",
    embedded_args = [
        "dgst",
        "-sha256",
        "$(rlocationpath :file_to_hash.txt)",
    ],
    data = [":file_to_hash.txt"],
)
```

The launcher will:
1. Resolve the openssl binary location through runfiles
2. Resolve file_to_hash.txt location through runfiles (auto-detected from $(rlocationpath))
3. Execute: `openssl dgst -sha256 /resolved/path/to/file_to_hash.txt`
4. Export RUNFILES_DIR, RUNFILES_MANIFEST_FILE, and JAVA_RUNFILES to the child process

**Runtime argument forwarding:**

Additional arguments passed to the binary are forwarded to the entrypoint:

```bash
bazel run //:hash_file -- --some-extra-flag
# Executes: openssl dgst -sha256 /resolved/path/to/file.txt --some-extra-flag
```

**Automatic path transformation:**

By default, the entrypoint (index 0) and any argument matching `$(rlocationpath ...)`
are automatically transformed through runfiles. You can customize this with `transformed_args`.

**Cross-platform:**

The same BUILD file works on Linux, macOS, and Windows. The launcher handles platform-specific
path separators and runfiles resolution automatically.
"�2
� 
launcher_binary�Creates a tiny, binary launcher that wraps another executable with its runfiles.

This rule generates a small native binary (10-68KB depending on platform) that:
- Resolves Bazel runfiles paths at runtime
- Executes the target program with embedded arguments
- Forwards additional runtime arguments
- Exports runfiles environment variables to child processes
- Works identically on Linux, macOS, and Windows

The launcher automatically detects runfiles using RUNFILES_DIR, RUNFILES_MANIFEST_FILE,
or by looking for a <binary>.runfiles/ directory adjacent to the executable.

**Example - Wrapping openssl to hash a file:**

```python
load("@hermetic_launcher//launcher:launcher_binary.bzl", "launcher_binary")

launcher_binary(
    name = "hash_file",
    entrypoint = "@openssl",
    embedded_args = [
        "dgst",
        "-sha256",
        "$(rlocationpath :file_to_hash.txt)",
    ],
    data = [":file_to_hash.txt"],
)
```

The launcher will:
1. Resolve the openssl binary location through runfiles
2. Resolve file_to_hash.txt location through runfiles (auto-detected from $(rlocationpath))
3. Execute: `openssl dgst -sha256 /resolved/path/to/file_to_hash.txt`
4. Export RUNFILES_DIR, RUNFILES_MANIFEST_FILE, and JAVA_RUNFILES to the child process

**Runtime argument forwarding:**

Additional arguments passed to the binary are forwarded to the entrypoint:

```bash
bazel run //:hash_file -- --some-extra-flag
# Executes: openssl dgst -sha256 /resolved/path/to/file.txt --some-extra-flag
```

**Automatic path transformation:**

By default, the entrypoint (index 0) and any argument matching `$(rlocationpath ...)`
are automatically transformed through runfiles. You can customize this with `transformed_args`.

**Cross-platform:**

The same BUILD file works on Linux, macOS, and Windows. The launcher handles platform-specific
path separators and runfiles resolution automatically.
*
nameA unique name for this target. �
data�Runtime dependencies (data files, scripts, etc.) needed by the entrypoint.

These files and their transitive runfiles will be included in the binary's runfiles tree,
making them available at runtime. Use `$(rlocationpath)` to reference these files in
`embedded_args`.

Example:
```python
data = [
    ":config.yaml",
    "//data:test_fixtures",
    "@some_external//:data_files",
]
```
2[]�
embedded_args�Arguments to embed in the binary that will be passed to the entrypoint.

These arguments are baked into the binary at build time. They support Bazel location
expansion (e.g., `$(rlocationpath)`, `$(location)`, `$(execpath)`).

Arguments matching the pattern `$(rlocationpath ...)` are automatically detected and marked
for runtime path transformation unless you explicitly set `transformed_args`.

Example:
```python
embedded_args = [
    "--config",
    "$(rlocationpath :config.yaml)",  # Auto-detected for transformation
    "--mode=production",               # Literal string, not transformed
]
```
2[]�

entrypoint�The target executable to wrap. This is the actual program that will be executed.

The entrypoint's runfiles path will be automatically resolved at runtime through the Bazel
runfiles mechanism. This must be an executable target (e.g., a binary, a script, or another
launcher_binary).

Example: `entrypoint = "@python_3_11//:python"` or `entrypoint = "//tools:my_tool"`
 �
transformed_args�Explicit list of argument indices that need runtime runfiles path transformation.

Index 0 is the entrypoint, index 1 is the first embedded arg, index 2 is the second, etc.

**Default behavior (empty list):**
- Entrypoint (index 0) is always transformed
- Any argument matching `$(rlocationpath ...)` is transformed
- Other arguments are passed as literal strings

**Custom behavior:**
Set explicit indices to transform:
```python
transformed_args = [0, 2, 5]  # Transform entrypoint, 2nd arg, and 5th arg
```

**Disable all transformation:**
```python
transformed_args = [-1]  # Special value: no transformation at all
```

Use this when you want fine-grained control over which paths are resolved through runfiles.
2[]"D
launcher_binary1@@hermetic_launcher//launcher:launcher_binary.bzl
<<,
*
nameA unique name for this target. �
�
data�Runtime dependencies (data files, scripts, etc.) needed by the entrypoint.

These files and their transitive runfiles will be included in the binary's runfiles tree,
making them available at runtime. Use `$(rlocationpath)` to reference these files in
`embedded_args`.

Example:
```python
data = [
    ":config.yaml",
    "//data:test_fixtures",
    "@some_external//:data_files",
]
```
2[]�
�
embedded_args�Arguments to embed in the binary that will be passed to the entrypoint.

These arguments are baked into the binary at build time. They support Bazel location
expansion (e.g., `$(rlocationpath)`, `$(location)`, `$(execpath)`).

Arguments matching the pattern `$(rlocationpath ...)` are automatically detected and marked
for runtime path transformation unless you explicitly set `transformed_args`.

Example:
```python
embedded_args = [
    "--config",
    "$(rlocationpath :config.yaml)",  # Auto-detected for transformation
    "--mode=production",               # Literal string, not transformed
]
```
2[]�
�

entrypoint�The target executable to wrap. This is the actual program that will be executed.

The entrypoint's runfiles path will be automatically resolved at runtime through the Bazel
runfiles mechanism. This must be an executable target (e.g., a binary, a script, or another
launcher_binary).

Example: `entrypoint = "@python_3_11//:python"` or `entrypoint = "//tools:my_tool"`
 �
�
transformed_args�Explicit list of argument indices that need runtime runfiles path transformation.

Index 0 is the entrypoint, index 1 is the first embedded arg, index 2 is the second, etc.

**Default behavior (empty list):**
- Entrypoint (index 0) is always transformed
- Any argument matching `$(rlocationpath ...)` is transformed
- Other arguments are passed as literal strings

**Custom behavior:**
Set explicit indices to transform:
```python
transformed_args = [0, 2, 5]  # Transform entrypoint, 2nd arg, and 5th arg
```

**Disable all transformation:**
```python
transformed_args = [-1]  # Special value: no transformation at all
```

Use this when you want fine-grained control over which paths are resolved through runfiles.
2[]�
,//launcher/private/rules:launcher_binary.bzlr�
@
hermetic_launcherlauncher/private/ruleslauncher_binary.bzl1
launcher_binary_launcher_binary
HX
m�
&
hermetic_launcherlauncherlib.bzl�
 //launcher/private/rules:lib.bzlri
4
hermetic_launcherlauncher/private/ruleslib.bzl#
launcher	_launcher
<E
S 