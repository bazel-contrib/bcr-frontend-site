�A
2
hermetic_launcherlauncherlauncher_binary.bzl�Alauncher_binary�Creates a tiny, binary launcher that wraps another executable with its runfiles.

This rule generates a small native binary (10-68KB depending on platform) that:
- Resolves Bazel runfiles paths at runtime
- Executes the target program with embedded arguments
- Forwards additional runtime arguments
- Exports runfiles environment variables to child processes
- Works identically on Linux, macOS, and Windows

The launcher automatically detects runfiles using RUNFILES_DIR, RUNFILES_MANIFEST_FILE,
or by looking for a <binary>.runfiles/ directory adjacent to the executable.

**Example - Wrapping openssl to hash a file:**

```python
load("@hermetic_launcher//launcher:launcher_binary.bzl", "launcher_binary")

launcher_binary(
    name = "hash_file",
    entrypoint = "@openssl",
    embedded_args = [
        "dgst",
        "-sha256",
        "$(rlocationpath :file_to_hash.txt)",
    ],
    data = [":file_to_hash.txt"],
)
```

The launcher will:
1. Resolve the openssl binary location through runfiles
2. Resolve file_to_hash.txt location through runfiles (auto-detected from $(rlocationpath))
3. Execute: `openssl dgst -sha256 /resolved/path/to/file_to_hash.txt`
4. Export RUNFILES_DIR, RUNFILES_MANIFEST_FILE, and JAVA_RUNFILES to the child process

**Runtime argument forwarding:**

Additional arguments passed to the binary are forwarded to the entrypoint:

```bash
bazel run //:hash_file -- --some-extra-flag
# Executes: openssl dgst -sha256 /resolved/path/to/file.txt --some-extra-flag
```

**Automatic path transformation:**

By default, the entrypoint (index 0) and any argument matching `$(rlocationpath ...)`
are automatically transformed through runfiles. You can customize this with `transformed_args`.

**Cross-platform:**

The same BUILD file works on Linux, macOS, and Windows. The launcher handles platform-specific
path separators and runfiles resolution automatically."�2
� 
launcher_binary�Creates a tiny, binary launcher that wraps another executable with its runfiles.

This rule generates a small native binary (10-68KB depending on platform) that:
- Resolves Bazel runfiles paths at runtime
- Executes the target program with embedded arguments
- Forwards additional runtime arguments
- Exports runfiles environment variables to child processes
- Works identically on Linux, macOS, and Windows

The launcher automatically detects runfiles using RUNFILES_DIR, RUNFILES_MANIFEST_FILE,
or by looking for a <binary>.runfiles/ directory adjacent to the executable.

**Example - Wrapping openssl to hash a file:**

```python
load("@hermetic_launcher//launcher:launcher_binary.bzl", "launcher_binary")

launcher_binary(
    name = "hash_file",
    entrypoint = "@openssl",
    embedded_args = [
        "dgst",
        "-sha256",
        "$(rlocationpath :file_to_hash.txt)",
    ],
    data = [":file_to_hash.txt"],
)
```

The launcher will:
1. Resolve the openssl binary location through runfiles
2. Resolve file_to_hash.txt location through runfiles (auto-detected from $(rlocationpath))
3. Execute: `openssl dgst -sha256 /resolved/path/to/file_to_hash.txt`
4. Export RUNFILES_DIR, RUNFILES_MANIFEST_FILE, and JAVA_RUNFILES to the child process

**Runtime argument forwarding:**

Additional arguments passed to the binary are forwarded to the entrypoint:

```bash
bazel run //:hash_file -- --some-extra-flag
# Executes: openssl dgst -sha256 /resolved/path/to/file.txt --some-extra-flag
```

**Automatic path transformation:**

By default, the entrypoint (index 0) and any argument matching `$(rlocationpath ...)`
are automatically transformed through runfiles. You can customize this with `transformed_args`.

**Cross-platform:**

The same BUILD file works on Linux, macOS, and Windows. The launcher handles platform-specific
path separators and runfiles resolution automatically.*
nameA unique name for this target. �

entrypoint�The target executable to wrap. This is the actual program that will be executed.

The entrypoint's runfiles path will be automatically resolved at runtime through the Bazel
runfiles mechanism. This must be an executable target (e.g., a binary, a script, or another
launcher_binary).

Example: `entrypoint = "@python_3_11//:python"` or `entrypoint = "//tools:my_tool"` �
embedded_args�Arguments to embed in the binary that will be passed to the entrypoint.

These arguments are baked into the binary at build time. They support Bazel location
expansion (e.g., `$(rlocationpath)`, `$(location)`, `$(execpath)`).

Arguments matching the pattern `$(rlocationpath ...)` are automatically detected and marked
for runtime path transformation unless you explicitly set `transformed_args`.

Example:
```python
embedded_args = [
    "--config",
    "$(rlocationpath :config.yaml)",  # Auto-detected for transformation
    "--mode=production",               # Literal string, not transformed
]
```2[]�
transformed_args�Explicit list of argument indices that need runtime runfiles path transformation.

Index 0 is the entrypoint, index 1 is the first embedded arg, index 2 is the second, etc.

**Default behavior (empty list):**
- Entrypoint (index 0) is always transformed
- Any argument matching `$(rlocationpath ...)` is transformed
- Other arguments are passed as literal strings

**Custom behavior:**
Set explicit indices to transform:
```python
transformed_args = [0, 2, 5]  # Transform entrypoint, 2nd arg, and 5th arg
```

**Disable all transformation:**
```python
transformed_args = [-1]  # Special value: no transformation at all
```

Use this when you want fine-grained control over which paths are resolved through runfiles.2[]�
data�Runtime dependencies (data files, scripts, etc.) needed by the entrypoint.

These files and their transitive runfiles will be included in the binary's runfiles tree,
making them available at runtime. Use `$(rlocationpath)` to reference these files in
`embedded_args`.

Example:
```python
data = [
    ":config.yaml",
    "//data:test_fixtures",
    "@some_external//:data_files",
]
```2[]"Q
launcher_binary>@hermetic_launcher//launcher/private/rules:launcher_binary.bzl8,
*
nameA unique name for this target. �
�

entrypoint�The target executable to wrap. This is the actual program that will be executed.

The entrypoint's runfiles path will be automatically resolved at runtime through the Bazel
runfiles mechanism. This must be an executable target (e.g., a binary, a script, or another
launcher_binary).

Example: `entrypoint = "@python_3_11//:python"` or `entrypoint = "//tools:my_tool"` �
�
embedded_args�Arguments to embed in the binary that will be passed to the entrypoint.

These arguments are baked into the binary at build time. They support Bazel location
expansion (e.g., `$(rlocationpath)`, `$(location)`, `$(execpath)`).

Arguments matching the pattern `$(rlocationpath ...)` are automatically detected and marked
for runtime path transformation unless you explicitly set `transformed_args`.

Example:
```python
embedded_args = [
    "--config",
    "$(rlocationpath :config.yaml)",  # Auto-detected for transformation
    "--mode=production",               # Literal string, not transformed
]
```2[]�
�
transformed_args�Explicit list of argument indices that need runtime runfiles path transformation.

Index 0 is the entrypoint, index 1 is the first embedded arg, index 2 is the second, etc.

**Default behavior (empty list):**
- Entrypoint (index 0) is always transformed
- Any argument matching `$(rlocationpath ...)` is transformed
- Other arguments are passed as literal strings

**Custom behavior:**
Set explicit indices to transform:
```python
transformed_args = [0, 2, 5]  # Transform entrypoint, 2nd arg, and 5th arg
```

**Disable all transformation:**
```python
transformed_args = [-1]  # Special value: no transformation at all
```

Use this when you want fine-grained control over which paths are resolved through runfiles.2[]�
�
data�Runtime dependencies (data files, scripts, etc.) needed by the entrypoint.

These files and their transitive runfiles will be included in the binary's runfiles tree,
making them available at runtime. Use `$(rlocationpath)` to reference these files in
`embedded_args`.

Example:
```python
data = [
    ":config.yaml",
    "//data:test_fixtures",
    "@some_external//:data_files",
]
```2[]�
&
hermetic_launcherlauncherlib.bzl�launcher.append_embedded_arg*�
�
launcher.append_embedded_arg	
arg (
embedded_args (
transformed_args (2J
_append_embedded_arg2@hermetic_launcher//launcher/private/rules:lib.bzl
	
arg (

embedded_args (

transformed_args (�#launcher.append_raw_transformed_arg*�
�
#launcher.append_raw_transformed_arg	
arg (
embedded_args (
transformed_args (2Q
_append_raw_transformed_arg2@hermetic_launcher//launcher/private/rules:lib.bzl
	
arg (

embedded_args (

transformed_args (�launcher.append_runfile*�
�
launcher.append_runfile

file (
embedded_args (
transformed_args (2E
_append_runfile2@hermetic_launcher//launcher/private/rules:lib.bzl


file (

embedded_args (

transformed_args (�launcher.args_from_entrypoint*�
�
launcher.args_from_entrypoint
executable_file (2K
_args_from_entrypoint2@hermetic_launcher//launcher/private/rules:lib.bzl

executable_file (�launcher.compile_stub*�
�
launcher.compile_stub	
ctx (
embedded_args (
transformed_args (
output_file (
cfg"target"(
template_exec_groupNone(
template_fileNone(2C
_compile_stub2@hermetic_launcher//launcher/private/rules:lib.bzl
	
ctx (

embedded_args (

transformed_args (

output_file (

cfg"target"(

template_exec_groupNone(

template_fileNone(�launcher.entrypoint*�
�
launcher.entrypoint
executable_file (
transformed_argsNone(2A
_entrypoint2@hermetic_launcher//launcher/private/rules:lib.bzl

executable_file (

transformed_argsNone(�launcher.to_rlocation_path*|
o
launcher.to_rlocation_path
f (2H
_to_rlocation_path2@hermetic_launcher//launcher/private/rules:lib.bzl	

f ( 