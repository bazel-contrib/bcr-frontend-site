�5
jqjq.bzl�jq_rule-Most users should use the `jq` macro instead."�
�
jq_rule-Most users should use the `jq` macro instead.*
nameA unique name for this target. 

srcs 
data2[]
filter2""
filter_file2None
args2[]
expand_args2False
out2None8�
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.2-1"
jq_rule//jq:jq.bzl,
*
nameA unique name for this target. 


srcs 

data2[]

filter2""

filter_file2None

args2[]

expand_args2False

out2None8�
�
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.2-1�jq5Invoke jq with a filter on a set of json input files.*�
�
jq
nameName of the rule (.
srcs"List of input files. May be empty. (�
filter�Filter expression (https://stedolan.github.io/jq/manual/#Basicfilters).
Subject to stamp variable replacements, see [Stamping](./stamping.md).
When stamping is enabled, a variable named "STAMP" will be available in the filter.

Be careful to write the filter so that it handles unstamped builds, as in the example above.None(R
filter_file;File containing filter expression (alternative to `filter`)None(+
argsAdditional args to pass to jq[](S
outDName of the output json file; defaults to the rule name plus ".json"None(5
data'List of additional files. May be empty.[](U
expand_args=Run bazel's location and make variable expansion on the args.False(H
kwargs<Other common named parameters such as `tags` or `visibility`(5Invoke jq with a filter on a set of json input files.2
jq//jq:jq.bzl

nameName of the rule (0
.
srcs"List of input files. May be empty. (�
�
filter�Filter expression (https://stedolan.github.io/jq/manual/#Basicfilters).
Subject to stamp variable replacements, see [Stamping](./stamping.md).
When stamping is enabled, a variable named "STAMP" will be available in the filter.

Be careful to write the filter so that it handles unstamped builds, as in the example above.None(T
R
filter_file;File containing filter expression (alternative to `filter`)None(-
+
argsAdditional args to pass to jq[](U
S
outDName of the output json file; defaults to the rule name plus ".json"None(7
5
data'List of additional files. May be empty.[](W
U
expand_args=Run bazel's location and make variable expansion on the args.False(J
H
kwargs<Other common named parameters such as `tags` or `visibility`(�Load in your `BUILD` file with:

```starlark
load("@jq.bzl", "jq")
```

Examples
--------

Create a new file `bazel-out/.../no_srcs.json` containing some JSON data:

```starlark
jq(
    name = "no_srcs",
    srcs = [],
    filter = ".name = "Alice"",
)
```

Remove a field from `package.json`:

> The output path `bazel-out/.../package.json` matches the path of the source file,
> which means you must refer to the label `:no_dev_deps` to reference the output,
> since Bazel doesn't provide a label for an output file that collides with an input file.

```starlark
jq(
    name = "no_dev_deps",
    srcs = ["package.json"],
    out = "package.json",
    filter = "del(.devDependencies)",
)
```

Merge data from `bar.json` on top of `foo.json`, producing `foobar.json`:

```starlark
jq(
    name = "merged",
    srcs = ["foo.json", "bar.json"],
    filter = ".[0] * .[1]",
    args = ["--slurp"],
    out = "foobar.json",
)
```

Long filters can be split over several lines with comments:

```starlark
jq(
    name = "complex",
    srcs = ["a.json", "b.json"],
    filter = """
        .[0] as $a
        # Take select fields from b.json
        | (.[1] | {foo, bar, tags}) as $b
        # Merge b onto a
        | ($a * $b)
        # Combine 'tags' array from both
        | .tags = ($a.tags + $b.tags)
        # Add new field
        + {\"aspect_is_cool\": true}
    """,
    args = ["--slurp"],
)
```

Load filter from a file `filter.jq`, making it easier to edit complex filters:

```starlark
jq(
    name = "merged",
    srcs = ["foo.json", "bar.json"],
    filter_file = "filter.jq",
    args = ["--slurp"],
    out = "foobar.json",
)
```

Convert [genquery](https://bazel.build/reference/be/general#genquery) output to JSON.

```starlark
genquery(
    name = "deps",
    expression = "deps(//some:target)",
    scope = ["//some:target"],
)

jq(
    name = "deps_json",
    srcs = [":deps"],
    args = [
        "--raw-input",
        "--slurp",
    ],
    filter = "{ deps: split(\"\\n\") | map(select(. | length > 0)) }",
)
```

When Bazel is run with `--stamp`, replace some properties with version control info:

```starlark
jq(
    name = "stamped",
    srcs = ["package.json"],
    filter = "|".join([
        # Don't directly reference $STAMP as it's only set when stamping
        # This 'as' syntax results in $stamp being null in unstamped builds.
        "$ARGS.named.STAMP as $stamp",
        # Provide a default using the "alternative operator" in case $stamp is null.
        ".version = ($stamp[0].BUILD_EMBED_LABEL // "<unstamped>")",
    ]),
)
```

jq is exposed as a "Make variable", so you could use it directly from a `genrule` by referencing the toolchain.

```starlark
genrule(
    name = "case_genrule",
    srcs = ["a.json"],
    outs = ["genrule_output.json"],
    cmd = "$(JQ_BIN) '.' $(location a.json) > $@",
    toolchains = ["@jq_toolchains//:resolved_toolchain"],
)
``` 