�@
jqjq.bzl�jq_rule-Most users should use the `jq` macro instead."�
�
jq_rule-Most users should use the `jq` macro instead.*
nameA unique name for this target. 

srcs 
data2[]
filter2""
filter_file2None
args2[]
expand_args2False
out2None8�
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.2-1J1J0J-1"
jq_rule//jq:jq.bzl,
*
nameA unique name for this target. 


srcs 

data2[]

filter2""

filter_file2None

args2[]

expand_args2False

out2None8�
�
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.2-1J1J0J-1�jq5Invoke jq with a filter on a set of json input files.*�
�
jq
nameName of the rule (.
srcs"List of input files. May be empty. (�
filter�Filter expression (https://jqlang.org/manual/#basic-filters).
Subject to stamp variable replacements, see [Stamping](./stamping.md).
When stamping is enabled, a variable named "STAMP" will be available in the filter.

Be careful to write the filter so that it handles unstamped builds, as in the example above.None(R
filter_file;File containing filter expression (alternative to `filter`)None(+
argsAdditional args to pass to jq[](S
outDName of the output json file; defaults to the rule name plus ".json"None(5
data'List of additional files. May be empty.[](U
expand_args=Run bazel's location and make variable expansion on the args.False(H
kwargs<Other common named parameters such as `tags` or `visibility`(5Invoke jq with a filter on a set of json input files.2
jq//jq:jq.bzl

nameName of the rule (0
.
srcs"List of input files. May be empty. (�
�
filter�Filter expression (https://jqlang.org/manual/#basic-filters).
Subject to stamp variable replacements, see [Stamping](./stamping.md).
When stamping is enabled, a variable named "STAMP" will be available in the filter.

Be careful to write the filter so that it handles unstamped builds, as in the example above.None(T
R
filter_file;File containing filter expression (alternative to `filter`)None(-
+
argsAdditional args to pass to jq[](U
S
outDName of the output json file; defaults to the rule name plus ".json"None(7
5
data'List of additional files. May be empty.[](W
U
expand_args=Run bazel's location and make variable expansion on the args.False(J
H
kwargs<Other common named parameters such as `tags` or `visibility`(�
jq_test�Assert that the given json files have the same semantic content.

Uses jq to filter each file. The default value of `"."` as the filter
means to compare the whole file.

See the jq macro for more about the filter expressions as well as
setup notes for the `jq` toolchain.

Note that this macro is equivalent to calling bazel_lib's `diff_test` with the jq outputs.
*�
�
jq_test.
name"name of resulting diff_test target (
file1a json file (
file2another json file (/
filter1a jq filter to apply to file1"."(/
filter2a jq filter to apply to file2"."(B
kwargs6additional named arguments for the resulting diff_test(�Assert that the given json files have the same semantic content.

Uses jq to filter each file. The default value of `"."` as the filter
means to compare the whole file.

See the jq macro for more about the filter expressions as well as
setup notes for the `jq` toolchain.

Note that this macro is equivalent to calling bazel_lib's `diff_test` with the jq outputs.
2
jq_test//jq:jq.bzl0
.
name"name of resulting diff_test target (

file1a json file ( 

file2another json file (1
/
filter1a jq filter to apply to file1"."(1
/
filter2a jq filter to apply to file2"."(D
B
kwargs6additional named arguments for the resulting diff_test(�Load in your `BUILD` file with:

```starlark
load("@jq.bzl", "jq")
```

Examples
--------

Create a new file `bazel-out/.../no_srcs.json` containing some JSON data:

```starlark
jq(
    name = "no_srcs",
    srcs = [],
    filter = ".greeting = "Hello, " + $name",
    args = ["--arg" "name" "World"],
)
```

Remove a field from `package.json`:

> The output path `bazel-out/.../package.json` matches the path of the source file,
> which means you must refer to the label `:no_dev_deps` to reference the output,
> since Bazel doesn't provide a label for an output file that collides with an input file.

```starlark
jq(
    name = "no_dev_deps",
    srcs = ["package.json"],
    out = "package.json",
    filter = "del(.devDependencies)",
)
```

Merge data from `bar.json` on top of `foo.json`, producing `foobar.json`:

```starlark
jq(
    name = "merged",
    srcs = ["foo.json", "bar.json"],
    filter = ".[0] * .[1]",
    args = ["--slurp"],
    out = "foobar.json",
)
```

Long filters can be split over several lines with comments:

```starlark
jq(
    name = "complex",
    srcs = ["a.json", "b.json"],
    filter = """
        .[0] as $a
        # Take select fields from b.json
        | (.[1] | {foo, bar, tags}) as $b
        # Merge b onto a
        | ($a * $b)
        # Combine 'tags' array from both
        | .tags = ($a.tags + $b.tags)
        # Add new field
        + {\"aspect_is_cool\": true}
    """,
    args = ["--slurp"],
)
```

Load filter from a file `filter.jq`, making it easier to edit complex filters:

```starlark
jq(
    name = "merged",
    srcs = ["foo.json", "bar.json"],
    filter_file = "filter.jq",
    args = ["--slurp"],
    out = "foobar.json",
)
```

Convert [genquery](https://bazel.build/reference/be/general#genquery) output to JSON.

```starlark
genquery(
    name = "deps",
    expression = "deps(//some:target)",
    scope = ["//some:target"],
)

jq(
    name = "deps_json",
    srcs = [":deps"],
    args = [
        "--raw-input",
        "--slurp",
    ],
    filter = "{ deps: split(\"\\n\") | map(select(. | length > 0)) }",
)
```

When Bazel is run with `--stamp`, replace some properties with version control info:

```starlark
jq(
    name = "stamped",
    srcs = ["package.json"],
    filter = "|".join([
        # Don't directly reference $STAMP as it's only set when stamping
        # This 'as' syntax results in $stamp being null in unstamped builds.
        "$ARGS.named.STAMP as $stamp",
        # Provide a default using the "alternative operator" in case $stamp is null.
        ".version = ($stamp[0].BUILD_EMBED_LABEL // "<unstamped>")",
    ]),
)
```

jq is exposed as a "Make variable", so you could use it directly from a `genrule` by referencing the toolchain.

```starlark
genrule(
    name = "case_genrule",
    srcs = ["a.json"],
    outs = ["genrule_output.json"],
    cmd = "$(JQ_BIN) '.' $(location a.json) > $@",
    toolchains = ["@jq_toolchains//:resolved_toolchain"],
)
```�
jq/toolchainplatforms.bzl�jq_platform_repo,Fetch external tools needed for jq toolchainR�
�
jq_platform_repo,Fetch external tools needed for jq toolchain.
name"A unique name for this repository. �
repo_mapping�In `WORKSPACE` context only: a dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.

For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).

This attribute is _not_ supported in `MODULE.bazel` context (when invoking a repository rule inside a module extension's implementation function).

version J"1.7"n
platform J"darwin_amd64"J"darwin_arm64"J"linux_amd64"J"linux_arm64"J"linux_riscv64"J"windows_amd64"*0
jq_platform_repo//jq/toolchain:platforms.bzl0
.
name"A unique name for this repository. �
�
repo_mapping�In `WORKSPACE` context only: a dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.

For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).

This attribute is _not_ supported in `MODULE.bazel` context (when invoking a repository rule inside a module extension's implementation function).


version J"1.7"p
n
platform J"darwin_amd64"J"darwin_arm64"J"linux_amd64"J"linux_arm64"J"linux_riscv64"J"windows_amd64"@Definitions for downloading a binary for each supported platform�
jq/toolchaintoolchain.bzl�jq_toolchain"�
s
jq_toolchain*
nameA unique name for this target. 	
bin ",
jq_toolchain//jq/toolchain:toolchain.bzl,
*
nameA unique name for this target. 
	
bin �JqInfoProvide info for executing jq2�
l
JqInfoProvide info for executing jq
binExecutable jq binary"&
JqInfo//jq/toolchain:toolchain.bzl

binExecutable jq binary�jq_toolchains_repolCreates a repository with toolchain definitions for all known platforms
which can be registered or selected.R�
�
jq_toolchains_repolCreates a repository with toolchain definitions for all known platforms
which can be registered or selected..
name"A unique name for this repository. �
repo_mapping�In `WORKSPACE` context only: a dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.

For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).

This attribute is _not_ supported in `MODULE.bazel` context (when invoking a repository rule inside a module extension's implementation function).
A
user_repository_name#Base name for toolchains repository2""*2
jq_toolchains_repo//jq/toolchain:toolchain.bzl0
.
name"A unique name for this repository. �
�
repo_mapping�In `WORKSPACE` context only: a dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.

For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).

This attribute is _not_ supported in `MODULE.bazel` context (when invoking a repository rule inside a module extension's implementation function).
C
A
user_repository_name#Base name for toolchains repository2""�jq_host_alias_repo�Creates a repository with a shorter name meant for the host platform, which contains
a BUILD.bazel file that exports symlinks to the host platform's binariesR�
�
jq_host_alias_repo�Creates a repository with a shorter name meant for the host platform, which contains
a BUILD.bazel file that exports symlinks to the host platform's binaries.
name"A unique name for this repository. �
repo_mapping�In `WORKSPACE` context only: a dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.

For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).

This attribute is _not_ supported in `MODULE.bazel` context (when invoking a repository rule inside a module extension's implementation function).
*2
jq_host_alias_repo//jq/toolchain:toolchain.bzl0
.
name"A unique name for this repository. �
�
repo_mapping�In `WORKSPACE` context only: a dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.

For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).

This attribute is _not_ supported in `MODULE.bazel` context (when invoking a repository rule inside a module extension's implementation function).
<Provide access to a jq binary via Bazel's toolchains feature�
jq/toolchainversions.bzl�https://github.com/stedolan/jq/releases

The integrity hashes can be computed with
shasum -b -a 384 [downloaded file] | awk '{ print $1 }' | xxd -r -p | base64 