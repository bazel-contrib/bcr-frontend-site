�
,
jsonnettools/build_defspython_repo.bzl�python_headersR�
�
python_headers.
name"A unique name for this repository. 
path2	"python3"�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 *=
python_headers+@@jsonnet//tools/build_defs:python_repo.bzl
'!'!0
.
name"A unique name for this repository. 

path2	"python3"�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �	build_file_contents�package(default_visibility = ["//visibility:public"])

filegroup(
    name = "include",
    srcs = glob(["include/**"]),
)

cc_library(
    name = "headers",
    hdrs = [":include"],
    includes = ["include"]
)
j��package(default_visibility = ["//visibility:public"])

filegroup(
    name = "include",
    srcs = glob(["include/**"]),
)

cc_library(
    name = "headers",
    hdrs = [":include"],
    includes = ["include"]
)
 