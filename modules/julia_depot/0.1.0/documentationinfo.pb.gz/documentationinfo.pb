�)

julia_depotjulia	depot.bzl�julia_depotvInstantiates and precompiles a Julia project into the declared or ambient depot, failing loudly on a version mismatch.R�
�
julia_depotvInstantiates and precompiles a Julia project into the declared or ambient depot, failing loudly on a version mismatch..
name"A unique name for this repository. �
dir�The depot directory to instantiate into, overriding JULIA_DEPOT_PATH. {HOME} and {USER} expand from the fetch environment. Exported through env.sh with a trailing separator so Julia's bundled depots stay on the path.2""p
hook`Optional executable run before instantiate, with RULES_JULIA_DEPOT_BIN and JULIA_DEPOT_PATH set.2Nonej
hook_environTEnvironment variables the hook reads. Each is passed through and a change refetches.2[]�
julia�The Julia distribution to instantiate with, e.g. @julia_dist from julia.dist. Any target in the distribution's root package works; bin/julia and the version header are found beside it. Z
manifestJThe Manifest.toml that pins the environment. Its directory is the project. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 ^
timeoutKSeconds. A cold instantiate of a large environment is minutes, not seconds.23600*-
julia_depot@@julia_depot//julia:depot.bzl
��0
.
name"A unique name for this repository. �
�
dir�The depot directory to instantiate into, overriding JULIA_DEPOT_PATH. {HOME} and {USER} expand from the fetch environment. Exported through env.sh with a trailing separator so Julia's bundled depots stay on the path.2""r
p
hook`Optional executable run before instantiate, with RULES_JULIA_DEPOT_BIN and JULIA_DEPOT_PATH set.2Nonel
j
hook_environTEnvironment variables the hook reads. Each is passed through and a change refetches.2[]�
�
julia�The Julia distribution to instantiate with, e.g. @julia_dist from julia.dist. Any target in the distribution's root package works; bin/julia and the version header are found beside it. \
Z
manifestJThe Manifest.toml that pins the environment. Its directory is the project. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 `
^
timeoutKSeconds. A cold instantiate of a large environment is minutes, not seconds.23600r
//julia:dist.bzlr\

julia_depotjuliadist.bzl,
host_platformhost_platform
$'$4
$$6�A Julia environment pinned to a Manifest, as a repository rule.

THE CONTRACT. The declared input is Manifest.toml. Everything about the environment
follows from it: every registered package by git tree hash, every JLL artifact by tree
hash from its Artifacts.toml, and path entries that are the consumer's own source and
therefore srcs rather than depot content. A Manifest with no git-sourced entries
therefore determines the closure, which is what makes it legitimate to treat the depot
as a keyed side effect rather than a declared output. Check your manifest for
`repo-url` entries before relying on that.

A REPOSITORY RULE, not a genrule, for two reasons. Fetch time is where hitting the
network is legitimate, and a repository rule can be made to refetch when the Manifest
changes, which is what `_watch` below is for. A build-time genrule doing the same work
would need no-sandbox plus requires-network and would be lying to Bazel about its
inputs.

WHAT IT PRODUCES. `env.sh`, a shell fragment consumers source before running julia,
which always exports JULIA_DEPOT_PATH, and `stamp.txt`, the resolved facts (manifest
sha256, Julia version, host triplet, depot). Julia itself is not in env.sh: consumers
take it as a label from the distribution they passed as `julia` (`@julia_dist//:bin/julia`)
via $(location ...). The depot is the one path in env.sh, and it is per user by nature.

WHAT REFETCHES IT. The manifest, the hook and instantiate.sh, by content; the Julia
version, through the distribution's version header; the declared `dir`; and HOME,
JULIA_PKG_SERVER, every `hook_environ` variable and, when no `dir` is declared,
JULIA_DEPOT_PATH.

THE HOOK. Environments that resolve through a private registry or package server need
that registry in the depot BEFORE Pkg.instantiate, and fetch time is the only place
that can guarantee it. `hook` is an executable run first, with RULES_JULIA_DEPOT_BIN and
JULIA_DEPOT_PATH set, the latter to the same value env.sh exports; `hook_environ` names the variables it reads, so a change to any
of them refetches. The hook is the consumer's: this module knows nothing about any
particular registry.
�

julia_depotjuliadist.bzl�host_platformNMaps a host to the Julia build for it: (platform, arch_dir), or fails clearly.*�
�
host_platform&
os_namerepository_ctx.os.name. (#
archrepository_ctx.os.arch. (=
what%the rule or tag to name in the error."julia.dist"(NMaps a host to the Julia build for it: (platform, arch_dir), or fails clearly."U
SA tuple of the platform string (linux-x86_64) and the julialang-s3 directory (x64).2.
host_platform@@julia_depot//julia:dist.bzl
22�
julia_distRDownloads the official Julia distribution for the host platform, pinned by sha256.R�
�

julia_distRDownloads the official Julia distribution for the host platform, pinned by sha256..
name"A unique name for this repository. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 r
sha256bTarball sha256 by platform (linux-x86_64, linux-aarch64). Optional for versions this module knows.
2{}R
strip_prefix-Archive prefix template, expanded like `url`.2"julia-{version}"�
urlKTarball URL template; {version}, {minor}, {platform} and {arch_dir} expand.2c"https://julialang-s3.julialang.org/bin/linux/{arch_dir}/{minor}/julia-{version}-{platform}.tar.gz"*
versionJulia version, e.g. 1.12.7. *+

julia_dist@@julia_depot//julia:dist.bzl
��0
.
name"A unique name for this repository. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 t
r
sha256bTarball sha256 by platform (linux-x86_64, linux-aarch64). Optional for versions this module knows.
2{}T
R
strip_prefix-Archive prefix template, expanded like `url`.2"julia-{version}"�
�
urlKTarball URL template; {version}, {minor}, {platform} and {arch_dir} expand.2c"https://julialang-s3.julialang.org/bin/linux/{arch_dir}/{minor}/julia-{version}-{platform}.tar.gz",
*
versionJulia version, e.g. 1.12.7. <	DEFAULT_STRIP_PREFIXjulia-{version}jjulia-{version}�	DEFAULT_URLahttps://julialang-s3.julialang.org/bin/linux/{arch_dir}/{minor}/julia-{version}-{platform}.tar.gzjcahttps://julialang-s3.julialang.org/bin/linux/{arch_dir}/{minor}/julia-{version}-{platform}.tar.gz�An official Julia distribution for the host, pinned by sha256, as a repository rule.

THE HOST DECIDES THE BUILD. The platform is detected when the repository is fetched, not
when the extension is evaluated, so a host that cannot run Julia here only fails when a
Julia target is actually needed, and the extension's result in MODULE.bazel.lock stays the
same on every host.

    Linux x86_64    linux-x86_64     https://julialang-s3.julialang.org/bin/linux/x64/...
    Linux aarch64   linux-aarch64    https://julialang-s3.julialang.org/bin/linux/aarch64/...

Linux x86_64 is the supported platform. Linux aarch64 is mapped too, but untested and not
supported: it may work. macOS and Windows are refused, as is any other architecture: the
module's scripts need GNU tar, coreutils and a Linux layout, so a distribution that
downloaded would still fail later.

`url` and `strip_prefix` are templates, so one declaration serves every supported platform,
a mirror included: {version} (1.12.7), {minor} (1.12), {platform} (linux-x86_64) and
{arch_dir} (x64, the directory julialang-s3 files the build under).
�'
$
julia_depotjuliaextensions.bzl�juliaJ�
�	
julia�
dist�Fetch the official Julia distribution for the host, pinned by sha256. Linux x86_64 is supported; aarch64 is mapped but untested.-
name!Repository name, e.g. julia_dist. r
sha256bTarball sha256 by platform (linux-x86_64, linux-aarch64). Optional for versions this module knows.
2{}R
strip_prefix-Archive prefix template, expanded like `url`.2"julia-{version}"�
urleTarball URL template; {version}, {minor}, {platform} and {arch_dir} expand. Defaults to julialang-s3.2c"https://julialang-s3.julialang.org/bin/linux/{arch_dir}/{minor}/julia-{version}-{platform}.tar.gz"*
versionJulia version, e.g. 1.12.7. �
depotLInstantiate and precompile a Manifest-pinned project into the ambient depot.

name �
dirvDepot directory to instantiate into, overriding JULIA_DEPOT_PATH; {HOME} and {USER} expand from the fetch environment.2""]
hookMOptional executable run before instantiate (private registries, credentials).2NoneO
hook_environ9Environment variables the hook reads; a change refetches.2[]F
julia9The Julia distribution, e.g. @julia_dist from julia.dist. 
manifest 
timeout23600",
julia#@@julia_depot//julia:extensions.bzl
YY�	
�
dist�Fetch the official Julia distribution for the host, pinned by sha256. Linux x86_64 is supported; aarch64 is mapped but untested.-
name!Repository name, e.g. julia_dist. r
sha256bTarball sha256 by platform (linux-x86_64, linux-aarch64). Optional for versions this module knows.
2{}R
strip_prefix-Archive prefix template, expanded like `url`.2"julia-{version}"�
urleTarball URL template; {version}, {minor}, {platform} and {arch_dir} expand. Defaults to julialang-s3.2c"https://julialang-s3.julialang.org/bin/linux/{arch_dir}/{minor}/julia-{version}-{platform}.tar.gz"*
versionJulia version, e.g. 1.12.7. /
-
name!Repository name, e.g. julia_dist. t
r
sha256bTarball sha256 by platform (linux-x86_64, linux-aarch64). Optional for versions this module knows.
2{}T
R
strip_prefix-Archive prefix template, expanded like `url`.2"julia-{version}"�
�
urleTarball URL template; {version}, {minor}, {platform} and {arch_dir} expand. Defaults to julialang-s3.2c"https://julialang-s3.julialang.org/bin/linux/{arch_dir}/{minor}/julia-{version}-{platform}.tar.gz",
*
versionJulia version, e.g. 1.12.7. �
�
depotLInstantiate and precompile a Manifest-pinned project into the ambient depot.

name �
dirvDepot directory to instantiate into, overriding JULIA_DEPOT_PATH; {HOME} and {USER} expand from the fetch environment.2""]
hookMOptional executable run before instantiate (private registries, credentials).2NoneO
hook_environ9Environment variables the hook reads; a change refetches.2[]F
julia9The Julia distribution, e.g. @julia_dist from julia.dist. 
manifest 
timeout23600


name �
�
dirvDepot directory to instantiate into, overriding JULIA_DEPOT_PATH; {HOME} and {USER} expand from the fetch environment.2""_
]
hookMOptional executable run before instantiate (private registries, credentials).2NoneQ
O
hook_environ9Environment variables the hook reads; a change refetches.2[]H
F
julia9The Julia distribution, e.g. @julia_dist from julia.dist. 

manifest 

timeout23600p
//julia:depot.bzlrY

julia_depotjulia	depot.bzl(
julia_depotjulia_depot
(3
5�
//julia:dist.bzlr�

julia_depotjuliadist.bzl:
DEFAULT_STRIP_PREFIXDEFAULT_STRIP_PREFIX
';(
DEFAULT_URLDEFAULT_URL
?J&

julia_dist
julia_dist
NX
Z�
The `julia` module extension: a pinned Julia distribution and Manifest-pinned depots.

    julia = use_extension("@julia_depot//julia:extensions.bzl", "julia")
    julia.dist(name = "julia_dist", version = "1.12.7")
    julia.depot(
        name = "my_depot",
        manifest = "//julia:Manifest.toml",
        julia = "@julia_dist",
    )
    use_repo(julia, "julia_dist", "my_depot")

NAMING. A rule attribute that takes a repository is named after what it takes and is given
the repository itself: `julia = "@julia_dist"`, `depot = "@my_depot"`. Each repository's
default target, the one named after it, is what the rules need from it. The named targets
(`:dist`, `bin/julia`, `:env`, `env.sh`, `stamp.txt`) stay for genrules and scripts.

REPOSITORY NAMES ARE SHARED. The extension is evaluated once for the whole module graph,
so every module's `julia.dist` and `julia.depot` names land in one namespace, and two
modules declaring the same name is an error, even when the declarations are identical.
Nobody's declaration wins, because either way a module would silently build against a
Julia or a manifest it never asked for. The convention that keeps names apart: the root
module names its repositories freely, and a module that others depend on prefixes every
name it declares with its own module name (`reactant_server_julia`, not `julia_dist`).
�

julia_depotjulia	image.bzl�julia_compiled_layer�The precompile caches for an image's entry projects, as one layer.

The layers are unpacked into one tree with the image's layout and each entry project is
precompiled there, against the image's depot path rooted in that tree, for the image's
JULIA_CPU_TARGET. The caches land in the first depot's compiled/, which is all the layer holds,
and load unchanged in the image. Precompiling is also the first time the whole stack is loaded,
so a package that cannot load fails the build rather than a container.

The tar is normalised like every other layer, but it is not bit-for-bit reproducible: Julia
stamps each cache with a build id, and names each cache file with a hash over the paths of the
build, which live in a fresh temporary tree. The same packages get caches every time, with the
same modes, owners and mtimes; Bazel caches the action, so the digest is stable for as long as
the inputs are.
"�
�
julia_compiled_layer�The precompile caches for an image's entry projects, as one layer.

The layers are unpacked into one tree with the image's layout and each entry project is
precompiled there, against the image's depot path rooted in that tree, for the image's
JULIA_CPU_TARGET. The caches land in the first depot's compiled/, which is all the layer holds,
and load unchanged in the image. Precompiling is also the first time the whole stack is loaded,
so a package that cannot load fails the build rather than a container.

The tar is normalised like every other layer, but it is not bit-for-bit reproducible: Julia
stamps each cache with a build id, and names each cache file with a hash over the paths of the
build, which live in a fresh temporary tree. The same packages get caches every time, with the
same modes, owners and mtimes; Bazel caches the action, so the digest is stable for as long as
the inputs are.
*
nameA unique name for this target. �
env�Further variables for Julia, e.g. what a package reads in __init__ or to select an artifact. `{root}` in a value is the directory the layers are unpacked into, so a variable can name a file that only a build-time layer carries, such as a driver stub on LD_LIBRARY_PATH.
2{}N
	image_env(The julia_image_env the image runs with. *
JuliaImageEnvInfo~
juliaqThe Julia distribution, `@julia_dist` from julia.dist. Used when the layers carry no Julia at the image's prefix. �
layers�The image's layers, in oci_image order: at least the depot layer with packages, and every layer an entry project's files come from. l
projects\The entry projects, as absolute paths in the image: every project the image starts Julia in. o
sysimage]The sysimage the image starts Julia with, as a path in the image, when it is not Julia's own.2"""6
julia_compiled_layer@@julia_depot//julia:image.bzl
��,
*
nameA unique name for this target. �
�
env�Further variables for Julia, e.g. what a package reads in __init__ or to select an artifact. `{root}` in a value is the directory the layers are unpacked into, so a variable can name a file that only a build-time layer carries, such as a driver stub on LD_LIBRARY_PATH.
2{}P
N
	image_env(The julia_image_env the image runs with. *
JuliaImageEnvInfo�
~
juliaqThe Julia distribution, `@julia_dist` from julia.dist. Used when the layers carry no Julia at the image's prefix. �
�
layers�The image's layers, in oci_image order: at least the depot layer with packages, and every layer an entry project's files come from. n
l
projects\The entry projects, as absolute paths in the image: every project the image starts Julia in. q
o
sysimage]The sysimage the image starts Julia with, as a path in the image, when it is not Julia's own.2""�julia_depot_layer�A clean depot for the project at `prefix`, as one layer: image_depot.sh as a rule.

The project is instantiated from its Manifest into an empty depot, so the layer holds exactly its
closure. `contents = "artifacts"` ships artifacts/ only, for an image whose code is in a sysimage;
`"full"` ships packages/ too, for an image that loads from source, and is what
julia_compiled_layer needs. Fetches from the package server: set JULIA_PKG_SERVER with
--action_env to use a mirror.
"�
�
julia_depot_layer�A clean depot for the project at `prefix`, as one layer: image_depot.sh as a rule.

The project is instantiated from its Manifest into an empty depot, so the layer holds exactly its
closure. `contents = "artifacts"` ships artifacts/ only, for an image whose code is in a sysimage;
`"full"` ships packages/ too, for an image that loads from source, and is what
julia_compiled_layer needs. Fetches from the package server: set JULIA_PKG_SERVER with
--action_env to use a mirror.
*
nameA unique name for this target. O
contents4artifacts: artifacts/ only. full: packages/ as well.2"artifacts"�
depot�Optional julia.depot repository, e.g. `@my_depot`. Its registries and package-server credentials are used for the instantiate (never shipped). Without it the registry is fetched fresh.2Nonet
envgVariables for the instantiate, e.g. what a package's platform augmentation reads to select an artifact.
2{}C
julia6The Julia distribution, `@julia_dist` from julia.dist. a
manifestQThe Manifest.toml that pins it, staged beside the Project.toml wherever it lives. y
min_artifactscFail below this many artifact directories, a floor against a selection that silently came up empty.21k
overrides_buildPartifacts/Overrides.toml naming build-host directories; see docs/src/recipes.md.2Noney
overrides_image^The artifacts/Overrides.toml that ships, naming in-image paths. Required with overrides_build.2Noneh
prefixHWhere the image keeps the depot. Match julia_image_env's `depot_prefix`.2"/opt/julia-depot"*
projectThe project's Project.toml. �
srcsuFurther project files (LocalPreferences.toml, workspace members), staged at their paths relative to the Project.toml.2[]"3
julia_depot_layer@@julia_depot//julia:image.bzl
��,
*
nameA unique name for this target. Q
O
contents4artifacts: artifacts/ only. full: packages/ as well.2"artifacts"�
�
depot�Optional julia.depot repository, e.g. `@my_depot`. Its registries and package-server credentials are used for the instantiate (never shipped). Without it the registry is fetched fresh.2Nonev
t
envgVariables for the instantiate, e.g. what a package's platform augmentation reads to select an artifact.
2{}E
C
julia6The Julia distribution, `@julia_dist` from julia.dist. c
a
manifestQThe Manifest.toml that pins it, staged beside the Project.toml wherever it lives. {
y
min_artifactscFail below this many artifact directories, a floor against a selection that silently came up empty.21m
k
overrides_buildPartifacts/Overrides.toml naming build-host directories; see docs/src/recipes.md.2None{
y
overrides_image^The artifacts/Overrides.toml that ships, naming in-image paths. Required with overrides_build.2Nonej
h
prefixHWhere the image keeps the depot. Match julia_image_env's `depot_prefix`.2"/opt/julia-depot",
*
projectThe project's Project.toml. �
�
srcsuFurther project files (LocalPreferences.toml, workspace members), staged at their paths relative to the Project.toml.2[]�julia_dist_layer\The pinned Julia distribution at `prefix`, as one layer. Its own relative symlinks are kept."�
�
julia_dist_layer\The pinned Julia distribution at `prefix`, as one layer. Its own relative symlinks are kept.*
nameA unique name for this target. C
julia6The Julia distribution, `@julia_dist` from julia.dist. ^
prefixDWhere the image keeps Julia. Match julia_image_env's `julia_prefix`.2"/opt/julia""2
julia_dist_layer@@julia_depot//julia:image.bzl
��,
*
nameA unique name for this target. E
C
julia6The Julia distribution, `@julia_dist` from julia.dist. `
^
prefixDWhere the image keeps Julia. Match julia_image_env's `julia_prefix`.2"/opt/julia"�julia_image_env�The Julia layout of an image, and the environment file that describes it.

Writes `<name>.env`, one KEY=VALUE per line, which plugs into rules_oci as `oci_image(env =
":<name>")`. Provides JuliaImageEnvInfo, which julia_compiled_layer and julia_precompile_test
take as `image_env`, so the caches are compiled for, and checked against, this environment.
"�
�
julia_image_env�The Julia layout of an image, and the environment file that describes it.

Writes `<name>.env`, one KEY=VALUE per line, which plugs into rules_oci as `oci_image(env =
":<name>")`. Provides JuliaImageEnvInfo, which julia_compiled_layer and julia_precompile_test
take as `image_env`, so the caches are compiled for, and checked against, this environment.
*
nameA unique name for this target. �

cpu_target�JULIA_CPU_TARGET, and the targets the compiled layer compiles for. Default: the portable list for the target platform's CPU (PORTABLE_X86_64_CPU_TARGET or PORTABLE_AARCH64_CPU_TARGET).2""}
depot_prefixWWhere the image keeps the depot: a julia_depot_layer's prefix. Caches are written here.2"/opt/julia-depot"�
env�Further variables for the image, written to the same file. Not applied when caches are built; pass those to the compiled layer's own `env`.
2{}�
extra_depots�Further depots, after `depot_prefix`. List the application's root here when it holds packages of its own, so their caches are relocatable.2[]Y
julia_prefix9Where the image keeps Julia: a julia_dist_layer's prefix.2"/opt/julia"[
	load_pathHJULIA_LOAD_PATH entries. Unset when empty, which leaves Julia's default.2[].
offlineSet JULIA_PKG_OFFLINE=true.2True^
pathNSet PATH to <julia>/bin:$PATH, which rules_oci expands against the base image.2True1
project JULIA_PROJECT. Unset when empty.2"""1
julia_image_env@@julia_depot//julia:image.bzl
��,
*
nameA unique name for this target. �
�

cpu_target�JULIA_CPU_TARGET, and the targets the compiled layer compiles for. Default: the portable list for the target platform's CPU (PORTABLE_X86_64_CPU_TARGET or PORTABLE_AARCH64_CPU_TARGET).2""
}
depot_prefixWWhere the image keeps the depot: a julia_depot_layer's prefix. Caches are written here.2"/opt/julia-depot"�
�
env�Further variables for the image, written to the same file. Not applied when caches are built; pass those to the compiled layer's own `env`.
2{}�
�
extra_depots�Further depots, after `depot_prefix`. List the application's root here when it holds packages of its own, so their caches are relocatable.2[][
Y
julia_prefix9Where the image keeps Julia: a julia_dist_layer's prefix.2"/opt/julia"]
[
	load_pathHJULIA_LOAD_PATH entries. Unset when empty, which leaves Julia's default.2[]0
.
offlineSet JULIA_PKG_OFFLINE=true.2True`
^
pathNSet PATH to <julia>/bin:$PATH, which rules_oci expands against the base image.2True3
1
project JULIA_PROJECT. Unset when empty.2""�julia_precompile_test�A test that the image starts without precompiling, run against its layers, no container.

Unpacks the layers into one tree with the image's layout and, in each entry project, loads its
modules with Julia's loading debug output on. Fails when any cache is rejected or any package is
compiled, which is what a container would otherwise do at its first start. Runs the image's own
Julia when a julia_dist_layer is among the layers, and the distribution's otherwise.
"�
�
julia_precompile_test�A test that the image starts without precompiling, run against its layers, no container.

Unpacks the layers into one tree with the image's layout and, in each entry project, loads its
modules with Julia's loading debug output on. Fails when any cache is rejected or any package is
compiled, which is what a container would otherwise do at its first start. Runs the image's own
Julia when a julia_dist_layer is among the layers, and the distribution's otherwise.
*
nameA unique name for this target. �
env�Further variables for Julia, e.g. what a package reads in __init__ or to select an artifact. `{root}` in a value is the directory the layers are unpacked into, so a variable can name a file that only a build-time layer carries, such as a driver stub on LD_LIBRARY_PATH.
2{}N
	image_env(The julia_image_env the image runs with. *
JuliaImageEnvInfo~
juliaqThe Julia distribution, `@julia_dist` from julia.dist. Used when the layers carry no Julia at the image's prefix. �
layers�The image's layers, in oci_image order: at least the depot layer with packages, and every layer an entry project's files come from. �
modules~What to load in every entry project. Default: each project's direct dependencies, and the project itself when it is a package.2[]l
projects\The entry projects, as absolute paths in the image: every project the image starts Julia in. o
sysimage]The sysimage the image starts Julia with, as a path in the image, when it is not Julia's own.2"""7
julia_precompile_test@@julia_depot//julia:image.bzl
��,
*
nameA unique name for this target. �
�
env�Further variables for Julia, e.g. what a package reads in __init__ or to select an artifact. `{root}` in a value is the directory the layers are unpacked into, so a variable can name a file that only a build-time layer carries, such as a driver stub on LD_LIBRARY_PATH.
2{}P
N
	image_env(The julia_image_env the image runs with. *
JuliaImageEnvInfo�
~
juliaqThe Julia distribution, `@julia_dist` from julia.dist. Used when the layers carry no Julia at the image's prefix. �
�
layers�The image's layers, in oci_image order: at least the depot layer with packages, and every layer an entry project's files come from. �
�
modules~What to load in every entry project. Default: each project's direct dependencies, and the project itself when it is a package.2[]n
l
projects\The entry projects, as absolute paths in the image: every project the image starts Julia in. q
o
sysimage]The sysimage the image starts Julia with, as a path in the image, when it is not Julia's own.2""�julia_sysimage_layer�A PackageCompiler sysimage at `path`, as one layer: sysimage.sh as a rule.

The packages come from the depot `depot` names, which its julia.depot fetch already instantiated
for this manifest; a scratch depot in front takes anything the build writes. A sysimage does not
replace the depot layer: artifacts are resolved at startup, so ship a julia_depot_layer beside it,
and start Julia with `--sysimage <path>`.
"�
�

julia_sysimage_layer�A PackageCompiler sysimage at `path`, as one layer: sysimage.sh as a rule.

The packages come from the depot `depot` names, which its julia.depot fetch already instantiated
for this manifest; a scratch depot in front takes anything the build writes. A sysimage does not
replace the depot layer: artifacts are resolved at startup, so ship a julia_depot_layer beside it,
and start Julia with `--sysimage <path>`.
*
nameA unique name for this target. �

cpu_target�The sysimage's CPU targets. Default: the portable list for the target platform's CPU, which costs build time and runs on any host of that architecture.2""M
depot@The julia.depot repository over this manifest, e.g. `@my_depot`. %
envVariables for the build.
2{}C
julia6The Julia distribution, `@julia_dist` from julia.dist. a
manifestQThe Manifest.toml that pins it, staged beside the Project.toml wherever it lives. A
packages1Packages to bake, with everything they depend on. K
path#Where the image keeps the sysimage.2"/opt/julia-sysimage/sys.so"*
projectThe project's Project.toml. �
srcsuFurther project files (LocalPreferences.toml, workspace members), staged at their paths relative to the Project.toml.2[]"6
julia_sysimage_layer@@julia_depot//julia:image.bzl
��,
*
nameA unique name for this target. �
�

cpu_target�The sysimage's CPU targets. Default: the portable list for the target platform's CPU, which costs build time and runs on any host of that architecture.2""O
M
depot@The julia.depot repository over this manifest, e.g. `@my_depot`. '
%
envVariables for the build.
2{}E
C
julia6The Julia distribution, `@julia_dist` from julia.dist. c
a
manifestQThe Manifest.toml that pins it, staged beside the Project.toml wherever it lives. C
A
packages1Packages to bake, with everything they depend on. M
K
path#Where the image keeps the sysimage.2"/opt/julia-sysimage/sys.so",
*
projectThe project's Project.toml. �
�
srcsuFurther project files (LocalPreferences.toml, workspace members), staged at their paths relative to the Project.toml.2[]�julia_image_env_vars�The environment variables a Julia image needs, as a dict for oci_image's `env`.

The same variables `julia_image_env` writes, for a BUILD file that merges them with its own:

    env = julia_image_env_vars(project = "/opt/app") | {"MY_SETTING": "1"}
*�
�
julia_image_env_varsk
julia_prefixKwhere the image keeps the Julia distribution (a julia_dist_layer's prefix)."/opt/julia"(x
depot_prefixRwhere the image keeps the depot (a julia_depot_layer's prefix). Julia writes
here."/opt/julia-depot"(�
extra_depots�further depots, searched after `depot_prefix`, such as the application's root when
it holds packages of its own that the compiled layer caches.[](O
project<JULIA_PROJECT, the project Julia starts in. Unset when None.None(\
	load_pathGJULIA_LOAD_PATH entries. Unset when None, which leaves Julia's default.None(�

cpu_target�JULIA_CPU_TARGET. Must match the compiled layer's, which julia_image_env
guarantees by handing this value to it. A plain value, not chosen by platform, because
oci_image takes `env` only as a dict or a label: the x86_64 list by default, and
PORTABLE_AARCH64_CPU_TARGET passed explicitly for an aarch64 image.Y"generic;sandybridge,-xsaveopt,clone_all;haswell,-rdrnd,base(1);x86-64-v4,-rdrnd,base(1)"(]
offlineJJULIA_PKG_OFFLINE=true, so Pkg in the image never reaches for the network.True(�
path�prepend Julia's bin/ to the base image's PATH, as `<julia>/bin:$PATH`, which rules_oci
expands against the base image's own PATH.True(�The environment variables a Julia image needs, as a dict for oci_image's `env`.

The same variables `julia_image_env` writes, for a BUILD file that merges them with its own:

    env = julia_image_env_vars(project = "/opt/app") | {"MY_SETTING": "1"}
"#
!A dict of variable name to value.26
julia_image_env_vars@@julia_depot//julia:image.bzl
XX�JuliaImageEnvInfoYThe Julia layout of an image and the environment that describes it, from julia_image_env.2�
�
JuliaImageEnvInfoYThe Julia layout of an image and the environment that describes it, from julia_image_env.?
env8dict: every variable the image's environment file holds.V
julia_prefixFstring: where the image keeps the Julia distribution, e.g. /opt/julia.a

depot_pathSlist of strings: JULIA_DEPOT_PATH in search order. Caches are written to the first.N

cpu_target@string: JULIA_CPU_TARGET, which the compiled layer compiles for.F
project;string or None: JULIA_PROJECT, the project Julia starts in."3
JuliaImageEnvInfo@@julia_depot//julia:image.bzl
==A
?
env8dict: every variable the image's environment file holds.X
V
julia_prefixFstring: where the image keeps the Julia distribution, e.g. /opt/julia.c
a

depot_pathSlist of strings: JULIA_DEPOT_PATH in search order. Caches are written to the first.P
N

cpu_target@string: JULIA_CPU_TARGET, which the compiled layer compiles for.H
F
project;string or None: JULIA_PROJECT, the project Julia starts in.�	PORTABLE_AARCH64_CPU_TARGETegeneric;cortex-a57;thunderx2t99;carmel,clone_all;apple-m1,base(3);neoverse-512tvb,-rand,-fpac,base(3)jgegeneric;cortex-a57;thunderx2t99;carmel,clone_all;apple-m1,base(3);neoverse-512tvb,-rand,-fpac,base(3)�	PORTABLE_X86_64_CPU_TARGETWgeneric;sandybridge,-xsaveopt,clone_all;haswell,-rdrnd,base(1);x86-64-v4,-rdrnd,base(1)jYWgeneric;sandybridge,-xsaveopt,clone_all;haswell,-rdrnd,base(1);x86-64-v4,-rdrnd,base(1)�Image layers for a Julia application, and the environment and check that go with them.

    load(
        "@julia_depot//julia:image.bzl",
        "julia_compiled_layer",
        "julia_depot_layer",
        "julia_dist_layer",
        "julia_image_env",
        "julia_precompile_test",
    )

Each layer rule writes ONE deterministic tar, ready for rules_oci's `oci_image(tars = [...])`:
entries sorted, mtimes zeroed, owned by uid and gid 0, permissions normalised to 0755 or 0644.
This module does not depend on rules_oci and never will; the consumer wires the tars and the
environment file into its own `oci_image`. See docs/src/images.md for the whole recipe.

THE LAYOUT IS DECLARED ONCE, by `julia_image_env`: where Julia, the depot and any other depots
live in the image, their search order, the CPU targets the caches are compiled for, and the
active project. It writes the image's environment as a KEY=VALUE file, which `oci_image(env =
...)` takes as is, and carries the same facts to `julia_compiled_layer` and
`julia_precompile_test` through `JuliaImageEnvInfo`, so the caches are built for, and checked
against, exactly the environment the image runs with. `julia_image_env_vars` returns the same
variables as a dict, for a BUILD file that wants to merge them with its own.

The rules shell out to image_layers.sh, which wraps image_depot.sh and sysimage.sh; what those
scripts decide is not repeated here.
 