�#

julia_depotjuliacc.bzl�check_glibc/Fails unless `glibc` is a version such as 2.17.*�
�
check_glibc1
what%the rule or tag to name in the error. ( 
glibcthe version string. (/Fails unless `glibc` is a version such as 2.17.2*
check_glibc@@julia_depot//julia:cc.bzl
]]�julia_cciDownloads zig for the host, pinned by sha256, and wraps `zig cc` to link sysimages against a fixed glibc.R�
�
julia_cciDownloads zig for the host, pinned by sha256, and wraps `zig cc` to link sysimages against a fixed glibc..
name"A unique name for this repository. U
glibcBThe glibc version to link against: the oldest a sysimage loads on.2"2.17"�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 r
sha256bTarball sha256 by platform (linux-x86_64, linux-aarch64). Optional for versions this module knows.
2{}]
strip_prefix-Archive prefix template, expanded like `url`.2"zig-{arch}-linux-{version}"�
url2Tarball URL template; {version} and {arch} expand.2J"https://ziglang.org/download/{version}/zig-{arch}-linux-{version}.tar.xz"#
versionzig version.2"0.16.0"*'
julia_cc@@julia_depot//julia:cc.bzl
��0
.
name"A unique name for this repository. W
U
glibcBThe glibc version to link against: the oldest a sysimage loads on.2"2.17"�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 t
r
sha256bTarball sha256 by platform (linux-x86_64, linux-aarch64). Optional for versions this module knows.
2{}_
]
strip_prefix-Archive prefix template, expanded like `url`.2"zig-{arch}-linux-{version}"�
�
url2Tarball URL template; {version} and {arch} expand.2J"https://ziglang.org/download/{version}/zig-{arch}-linux-{version}.tar.xz"%
#
versionzig version.2"0.16.0"r
//julia:dist.bzlr\

julia_depotjuliadist.bzl,
host_platformhost_platform
'4
6�	DEFAULT_CC_URLHhttps://ziglang.org/download/{version}/zig-{arch}-linux-{version}.tar.xzjJHhttps://ziglang.org/download/{version}/zig-{arch}-linux-{version}.tar.xz(	DEFAULT_CC_VERSION0.16.0j0.16.0"	DEFAULT_CC_GLIBC2.17j2.17U	DEFAULT_CC_STRIP_PREFIXzig-{arch}-linux-{version}jzig-{arch}-linux-{version}�A pinned C compiler for linking sysimages: zig's `zig cc`, as a repository rule.

PackageCompiler links a sysimage with a C compiler. Left to itself it takes `JULIA_CC`, or else
the first of g++, clang++, gcc and clang on PATH, which makes the host's compiler and C library
an input that no cache key covers. This repository pins both. One zig tarball, fetched by
sha256, holds the compiler, the linker and the headers and stubs of every glibc version it
supports, so `zig cc -target <arch>-linux-gnu.<glibc>` links against the same C library on
every host.

    bin/cc   the compiler to give PackageCompiler (through sysimage.sh's
             JULIA_DEPOT_SYSIMAGE_CC); a wrapper that adds the target
    :cc      bin/cc and the zig distribution it runs, for an action's inputs; also the
             default target, named after the repository

The host decides the zig build, as it does the Julia build in dist.bzl: PackageCompiler builds
a sysimage for the Julia that runs it, so the compiler targets the same architecture.

The wrapper records the zig version, its sha256 and the target, so its digest changes with
any of them. An action that declares only bin/cc is therefore still keyed on the compiler.
It also needs the rest of :cc among its inputs, or a sandboxed action cannot find zig.

`glibc` is the oldest glibc a sysimage built with it loads on. The default, 2.17, is what the
official Julia builds target. A sysimage needs only the symbols libjulia already needs, so a
lower target costs nothing.
�M

julia_depotjulia	depot.bzl�,julia_depotuInstantiates and precompiles a Julia project into the declared or ambient depot, failing on a Julia version mismatch.R�+
�
julia_depotuInstantiates and precompiles a Julia project into the declared or ambient depot, failing on a Julia version mismatch..
name"A unique name for this repository. �
dir�The depot directory to instantiate into, overriding JULIA_DEPOT_PATH. {HOME} and {USER} expand from the fetch environment. Exported through env.sh with Julia's bundled depots behind it: a trailing separator, or on Julia 1.10 their paths.2""�
env�Variables for the hook and the instantiate, such as what a package's platform augmentation reads to select an artifact. The rule's own JULIA_DEPOT_* win.
2{}j
hookZOptional executable run before instantiate, with JULIA_DEPOT_BIN and JULIA_DEPOT_PATH set.2Nonej
hook_environTEnvironment variables the hook reads. Each is passed through and a change refetches.2[]�
julia�The Julia distribution to instantiate with, e.g. @julia_dist from julia.dist. Any target in the distribution's root package works: bin/julia and the version header are found beside it. �
manifestpThe Manifest.toml that pins the environment. Unless `project` is set, the Project.toml beside it is the project. �

precompile�Precompile the environment after instantiating it. False for a depot only images are built from, whose caches come from julia_compiled_layer.2True�
project�The Project.toml the Manifest locks, when the two are not in one directory, such as a production lock kept apart from a development tree. The project is then staged inside the repository, with the Manifest beside it as Manifest.toml, and instantiated there; path packages have no source there, so set `precompile = False` if it has any.2None�
project_srcs�Further files a resolve reads, at their paths relative to the project's directory: the Project.toml of each workspace member and path package. Watched, so an edit refetches; and staged by the rules that build from the depot. Required for every member and path package when `project` is set.2[]�
read_only_depots�Depots searched after `dir` and never written to, such as a host's shared depot: what they already hold is not installed into `dir`. Templates like `dir`; requires `dir`. A missing one is skipped. Their contents are not watched.2[]�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 T
timeoutASeconds. A cold instantiate of a large environment takes minutes.23600*-
julia_depot@@julia_depot//julia:depot.bzl
��0
.
name"A unique name for this repository. �
�
dir�The depot directory to instantiate into, overriding JULIA_DEPOT_PATH. {HOME} and {USER} expand from the fetch environment. Exported through env.sh with Julia's bundled depots behind it: a trailing separator, or on Julia 1.10 their paths.2""�
�
env�Variables for the hook and the instantiate, such as what a package's platform augmentation reads to select an artifact. The rule's own JULIA_DEPOT_* win.
2{}l
j
hookZOptional executable run before instantiate, with JULIA_DEPOT_BIN and JULIA_DEPOT_PATH set.2Nonel
j
hook_environTEnvironment variables the hook reads. Each is passed through and a change refetches.2[]�
�
julia�The Julia distribution to instantiate with, e.g. @julia_dist from julia.dist. Any target in the distribution's root package works: bin/julia and the version header are found beside it. �
�
manifestpThe Manifest.toml that pins the environment. Unless `project` is set, the Project.toml beside it is the project. �
�

precompile�Precompile the environment after instantiating it. False for a depot only images are built from, whose caches come from julia_compiled_layer.2True�
�
project�The Project.toml the Manifest locks, when the two are not in one directory, such as a production lock kept apart from a development tree. The project is then staged inside the repository, with the Manifest beside it as Manifest.toml, and instantiated there; path packages have no source there, so set `precompile = False` if it has any.2None�
�
project_srcs�Further files a resolve reads, at their paths relative to the project's directory: the Project.toml of each workspace member and path package. Watched, so an edit refetches; and staged by the rules that build from the depot. Required for every member and path package when `project` is set.2[]�
�
read_only_depots�Depots searched after `dir` and never written to, such as a host's shared depot: what they already hold is not installed into `dir`. Templates like `dir`; requires `dir`. A missing one is skipped. Their contents are not watched.2[]�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 V
T
timeoutASeconds. A cold instantiate of a large environment takes minutes.23600r
//julia:dist.bzlr\

julia_depotjuliadist.bzl,
host_platformhost_platform
:':4
::6�A Julia environment pinned to a Manifest, as a repository rule.

Contract: the declared input is the Manifest, and the environment follows from it. It pins
every registered package by git tree hash and every JLL artifact by the tree hash in its
Artifacts.toml. Path entries are the consumer's own source, so they are srcs, not depot
content. A Manifest with no git-sourced entries therefore determines the closure, which is
what allows the depot to be treated as a keyed side effect instead of a declared output.
Check your manifest for `repo-url` entries before relying on that.

The project is the Project.toml beside the Manifest, or `project` when the lock is kept apart.
`project_srcs` are the further files a resolve reads, each workspace member's and path
package's Project.toml. All of these are copied into the repository and watched, and the rules
that build from the depot stage the copies. With `project`, the environment is instantiated from
the copies, which hold no sources, so precompiling a path package is impossible and the fetch
says so; `precompile = False` skips precompiling. instantiate.sh also fails, naming it, when a
workspace member or path package is missing from the tree. `env` adds variables to the hook's and
the instantiate's environment.

A repository rule, because fetching may use the network and `_watch` below refetches when
the Manifest changes. A genrule doing this would need no-sandbox and requires-network, and
could not declare the depot as an output.

Outputs: `env.sh`, a shell fragment consumers source before running julia, which always
exports JULIA_DEPOT_PATH; and `stamp.txt`, the resolved facts (manifest sha256, Julia
version, host triplet, depot). Julia itself is not in env.sh: consumers take it as a label
from the distribution they passed as `julia` (`@julia_dist//:bin/julia`) via $(location
...). The depot path, the only thing in env.sh, is per user.

What refetches it: the manifest, the hook and instantiate.sh, by content; the Julia version,
through the distribution's version header; the declared `dir` and `read_only_depots`, and
whether each read-only depot exists; and HOME, JULIA_PKG_SERVER, every `hook_environ`
variable and, when no `dir` is declared, JULIA_DEPOT_PATH. The contents of a read-only depot
do not; see below.

Read-only depots: a host often has a shared depot, maintained by someone else, that already
holds most of what a Manifest needs. `read_only_depots` stacks such depots after `dir`, so
the path becomes `<dir>:<ro1>:<ro2>:...:` (on Julia 1.10 the bundled depots by name in place
of the trailing separator; see _bundled_depots). Julia reads packages, artifacts and compiled
caches from every entry and writes only to the first, and Pkg installs nothing that an entry
already has, so `dir` holds only what the shared depots lack. This rule never writes to or
creates them. A missing one stays on the path, where Julia ignores it, so a host without the
shared depot fetches into `dir` alone. Whether each exists is an input, so one appearing or
disappearing refetches. Its contents are not, since watching a depot's whole tree would cost
more than the fetch it guards; a shared depot that loses something `dir` relied on needs
`bazel fetch --force @<name>`. They require `dir`. Without it the depot is the ambient
JULIA_DEPOT_PATH, which can already list any number of depots, and appending to it would
make the first entry, the one written to, depend on the shell.

The hook: an environment that resolves through a private registry or package server needs
that registry in the depot before Pkg.instantiate, and only fetch time can guarantee that.
`hook` is an executable run first, with JULIA_DEPOT_BIN set and JULIA_DEPOT_PATH set to the
value env.sh exports. `hook_environ` names the variables it reads, so a change to any of them
refetches. The hook belongs to the consumer; this module knows no particular registry. With
read-only depots the path has several entries: a hook that writes must write to the first,
as Pkg does, and may find what it would add already present in a later one.
�
$
julia_depotjuliadepot_info.bzl�julia_depot_info"�
�
julia_depot_info*
nameA unique name for this target. 	
env 
julia 
manifest 
project 
project_dir2""
project_srcs2[]
stamp "7
julia_depot_info#@@julia_depot//julia:depot_info.bzl
22,
*
nameA unique name for this target. 
	
env 

julia 

manifest 

project 

project_dir2""

project_srcs2[]

stamp �JuliaDepotInfoLA julia.depot repository: the Julia and the project it was instantiated for.2�

�
JuliaDepotInfoLA julia.depot repository: the Julia and the project it was instantiated for.1
julia(depset of Files: the Julia distribution.!
	julia_binFile: its bin/julia.H

julia_dist:File: its julia_dist.txt, the tarball it was fetched from.<
project1File: the Project.toml the depot was fetched for.2
manifest&File: the Manifest it was fetched for.h
project_dirYstring: the short path of the directory the project lives in, which `srcs` must be under.�
project_srcs�list of struct(rel, file): the further files a resolve reads (workspace members' Project.toml), at their paths relative to the project.
envFile: env.sh.
stampFile: stamp.txt."5
JuliaDepotInfo#@@julia_depot//julia:depot_info.bzl
3
1
julia(depset of Files: the Julia distribution.#
!
	julia_binFile: its bin/julia.J
H

julia_dist:File: its julia_dist.txt, the tarball it was fetched from.>
<
project1File: the Project.toml the depot was fetched for.4
2
manifest&File: the Manifest it was fetched for.j
h
project_dirYstring: the short path of the directory the project lives in, which `srcs` must be under.�
�
project_srcs�list of struct(rel, file): the further files a resolve reads (workspace members' Project.toml), at their paths relative to the project.

envFile: env.sh.

stampFile: stamp.txt.�JuliaDepotInfo: what a julia.depot repository was fetched for, as its default target provides it.

A julia.depot repository is fetched for one Julia and one project. The rules that build from a
depot take only the depot and read both from here, so they cannot be given a Julia or a Manifest
the depot was not instantiated for. The repository keeps its own copies of the project's
Project.toml, its `project_srcs` and its Manifest, all watched, so an edit refetches and the
copies follow it.

julia_depot_info is internal: the depot repository's BUILD file is its only caller.
�

julia_depotjuliadist.bzl�host_platformZMaps a host to the Julia build for it: (platform, arch_dir). Fails on an unsupported host.*�
�
host_platform&
os_namerepository_ctx.os.name. (#
archrepository_ctx.os.arch. (=
what%the rule or tag to name in the error."julia.dist"(ZMaps a host to the Julia build for it: (platform, arch_dir). Fails on an unsupported host."U
SA tuple of the platform string (linux-x86_64) and the julialang-s3 directory (x64).2.
host_platform@@julia_depot//julia:dist.bzl
II�
julia_distRDownloads the official Julia distribution for the host platform, pinned by sha256.R�
�

julia_distRDownloads the official Julia distribution for the host platform, pinned by sha256..
name"A unique name for this repository. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 r
sha256bTarball sha256 by platform (linux-x86_64, linux-aarch64). Optional for versions this module knows.
2{}R
strip_prefix-Archive prefix template, expanded like `url`.2"julia-{version}"�
urlKTarball URL template; {version}, {minor}, {platform} and {arch_dir} expand.2c"https://julialang-s3.julialang.org/bin/linux/{arch_dir}/{minor}/julia-{version}-{platform}.tar.gz"*
versionJulia version, e.g. 1.12.7. *+

julia_dist@@julia_depot//julia:dist.bzl
��0
.
name"A unique name for this repository. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 t
r
sha256bTarball sha256 by platform (linux-x86_64, linux-aarch64). Optional for versions this module knows.
2{}T
R
strip_prefix-Archive prefix template, expanded like `url`.2"julia-{version}"�
�
urlKTarball URL template; {version}, {minor}, {platform} and {arch_dir} expand.2c"https://julialang-s3.julialang.org/bin/linux/{arch_dir}/{minor}/julia-{version}-{platform}.tar.gz",
*
versionJulia version, e.g. 1.12.7. <	DEFAULT_STRIP_PREFIXjulia-{version}jjulia-{version}�	DEFAULT_URLahttps://julialang-s3.julialang.org/bin/linux/{arch_dir}/{minor}/julia-{version}-{platform}.tar.gzjcahttps://julialang-s3.julialang.org/bin/linux/{arch_dir}/{minor}/julia-{version}-{platform}.tar.gz�An official Julia distribution for the host, pinned by sha256, as a repository rule.

The host decides the build. The platform is detected when the repository is fetched, not
when the extension is evaluated, so a host that cannot run Julia fails only when a Julia
target is needed, and the extension's result in MODULE.bazel.lock is the same on every host.

    Linux x86_64    linux-x86_64     https://julialang-s3.julialang.org/bin/linux/x64/...
    Linux aarch64   linux-aarch64    https://julialang-s3.julialang.org/bin/linux/aarch64/...

Linux x86_64 is supported. Linux aarch64 is mapped but untested and unsupported. macOS,
Windows and other architectures fail at fetch: the module's scripts need GNU tar, coreutils
and a Linux layout, so a downloaded distribution would fail later anyway.

`url` and `strip_prefix` are templates, so one declaration serves every supported platform,
a mirror included: {version} (1.12.7), {minor} (1.12), {platform} (linux-x86_64) and
{arch_dir} (x64, the directory julialang-s3 files the build under).
�S
$
julia_depotjuliaextensions.bzl�AjuliaJ�A
�
julia�
dist�Fetch the official Julia distribution for the host, pinned by sha256. Linux x86_64 is supported; aarch64 is mapped but untested.-
name!Repository name, e.g. julia_dist. r
sha256bTarball sha256 by platform (linux-x86_64, linux-aarch64). Optional for versions this module knows.
2{}R
strip_prefix-Archive prefix template, expanded like `url`.2"julia-{version}"�
urleTarball URL template; {version}, {minor}, {platform} and {arch_dir} expand. Defaults to julialang-s3.2c"https://julialang-s3.julialang.org/bin/linux/{arch_dir}/{minor}/julia-{version}-{platform}.tar.gz"*
versionJulia version, e.g. 1.12.7. �
depot`Instantiate and precompile a Manifest-pinned project into the declared (`dir`) or ambient depot.

name �
dirvDepot directory to instantiate into, overriding JULIA_DEPOT_PATH; {HOME} and {USER} expand from the fetch environment.2""n
envaVariables for the hook and the instantiate, such as what a package's platform augmentation reads.
2{}]
hookMOptional executable run before instantiate (private registries, credentials).2NoneO
hook_environ9Environment variables the hook reads; a change refetches.2[]F
julia9The Julia distribution, e.g. @julia_dist from julia.dist. {
manifestkThe Manifest that pins the environment. Unless `project` is set, the Project.toml beside it is the project. �

precompile�Precompile after instantiating. False for a depot only images are built from; required when `project` is set and the project has path packages.2True�
project�The Project.toml the Manifest locks, when the two are not in one directory. The project is then staged in the repository and instantiated there.2None�
project_srcs�Further files a resolve reads, at their paths relative to the project's directory: each workspace member's and path package's Project.toml. Required for all of them when `project` is set.2[]�
read_only_depots�Depots searched after `dir` and never written to, such as a host's shared depot, so `dir` holds only what they lack. Templates like `dir`; requires `dir`; a missing one is skipped, and their contents are not watched.2[]
timeout23600�
ccyFetch zig for the host, pinned by sha256, as the C compiler that links sysimages against a fixed glibc. See julia/cc.bzl.(
nameRepository name, e.g. my_cc. c
glibcPThe glibc version to link against: the oldest a sysimage built with it loads on.2"2.17"r
sha256bTarball sha256 by platform (linux-x86_64, linux-aarch64). Optional for versions this module knows.
2{}]
strip_prefix-Archive prefix template, expanded like `url`.2"zig-{arch}-linux-{version}"�
urlKTarball URL template; {version} and {arch} expand. Defaults to ziglang.org.2J"https://ziglang.org/download/{version}/zig-{arch}-linux-{version}.tar.xz"#
versionzig version.2"0.16.0"",
julia#@@julia_depot//julia:extensions.bzl
nn�	
�
dist�Fetch the official Julia distribution for the host, pinned by sha256. Linux x86_64 is supported; aarch64 is mapped but untested.-
name!Repository name, e.g. julia_dist. r
sha256bTarball sha256 by platform (linux-x86_64, linux-aarch64). Optional for versions this module knows.
2{}R
strip_prefix-Archive prefix template, expanded like `url`.2"julia-{version}"�
urleTarball URL template; {version}, {minor}, {platform} and {arch_dir} expand. Defaults to julialang-s3.2c"https://julialang-s3.julialang.org/bin/linux/{arch_dir}/{minor}/julia-{version}-{platform}.tar.gz"*
versionJulia version, e.g. 1.12.7. /
-
name!Repository name, e.g. julia_dist. t
r
sha256bTarball sha256 by platform (linux-x86_64, linux-aarch64). Optional for versions this module knows.
2{}T
R
strip_prefix-Archive prefix template, expanded like `url`.2"julia-{version}"�
�
urleTarball URL template; {version}, {minor}, {platform} and {arch_dir} expand. Defaults to julialang-s3.2c"https://julialang-s3.julialang.org/bin/linux/{arch_dir}/{minor}/julia-{version}-{platform}.tar.gz",
*
versionJulia version, e.g. 1.12.7. �
�
depot`Instantiate and precompile a Manifest-pinned project into the declared (`dir`) or ambient depot.

name �
dirvDepot directory to instantiate into, overriding JULIA_DEPOT_PATH; {HOME} and {USER} expand from the fetch environment.2""n
envaVariables for the hook and the instantiate, such as what a package's platform augmentation reads.
2{}]
hookMOptional executable run before instantiate (private registries, credentials).2NoneO
hook_environ9Environment variables the hook reads; a change refetches.2[]F
julia9The Julia distribution, e.g. @julia_dist from julia.dist. {
manifestkThe Manifest that pins the environment. Unless `project` is set, the Project.toml beside it is the project. �

precompile�Precompile after instantiating. False for a depot only images are built from; required when `project` is set and the project has path packages.2True�
project�The Project.toml the Manifest locks, when the two are not in one directory. The project is then staged in the repository and instantiated there.2None�
project_srcs�Further files a resolve reads, at their paths relative to the project's directory: each workspace member's and path package's Project.toml. Required for all of them when `project` is set.2[]�
read_only_depots�Depots searched after `dir` and never written to, such as a host's shared depot, so `dir` holds only what they lack. Templates like `dir`; requires `dir`; a missing one is skipped, and their contents are not watched.2[]
timeout23600


name �
�
dirvDepot directory to instantiate into, overriding JULIA_DEPOT_PATH; {HOME} and {USER} expand from the fetch environment.2""p
n
envaVariables for the hook and the instantiate, such as what a package's platform augmentation reads.
2{}_
]
hookMOptional executable run before instantiate (private registries, credentials).2NoneQ
O
hook_environ9Environment variables the hook reads; a change refetches.2[]H
F
julia9The Julia distribution, e.g. @julia_dist from julia.dist. }
{
manifestkThe Manifest that pins the environment. Unless `project` is set, the Project.toml beside it is the project. �
�

precompile�Precompile after instantiating. False for a depot only images are built from; required when `project` is set and the project has path packages.2True�
�
project�The Project.toml the Manifest locks, when the two are not in one directory. The project is then staged in the repository and instantiated there.2None�
�
project_srcs�Further files a resolve reads, at their paths relative to the project's directory: each workspace member's and path package's Project.toml. Required for all of them when `project` is set.2[]�
�
read_only_depots�Depots searched after `dir` and never written to, such as a host's shared depot, so `dir` holds only what they lack. Templates like `dir`; requires `dir`; a missing one is skipped, and their contents are not watched.2[]

timeout23600�	
�
ccyFetch zig for the host, pinned by sha256, as the C compiler that links sysimages against a fixed glibc. See julia/cc.bzl.(
nameRepository name, e.g. my_cc. c
glibcPThe glibc version to link against: the oldest a sysimage built with it loads on.2"2.17"r
sha256bTarball sha256 by platform (linux-x86_64, linux-aarch64). Optional for versions this module knows.
2{}]
strip_prefix-Archive prefix template, expanded like `url`.2"zig-{arch}-linux-{version}"�
urlKTarball URL template; {version} and {arch} expand. Defaults to ziglang.org.2J"https://ziglang.org/download/{version}/zig-{arch}-linux-{version}.tar.xz"#
versionzig version.2"0.16.0"*
(
nameRepository name, e.g. my_cc. e
c
glibcPThe glibc version to link against: the oldest a sysimage built with it loads on.2"2.17"t
r
sha256bTarball sha256 by platform (linux-x86_64, linux-aarch64). Optional for versions this module knows.
2{}_
]
strip_prefix-Archive prefix template, expanded like `url`.2"zig-{arch}-linux-{version}"�
�
urlKTarball URL template; {version} and {arch} expand. Defaults to ziglang.org.2J"https://ziglang.org/download/{version}/zig-{arch}-linux-{version}.tar.xz"%
#
versionzig version.2"0.16.0"�
//julia:cc.bzlr�

julia_depotjuliacc.bzl2
DEFAULT_CC_GLIBCDEFAULT_CC_GLIBC
%5@
DEFAULT_CC_STRIP_PREFIXDEFAULT_CC_STRIP_PREFIX
9P.
DEFAULT_CC_URLDEFAULT_CC_URL
Tb6
DEFAULT_CC_VERSIONDEFAULT_CC_VERSION
fx#
julia_ccjulia_cc
|�
�p
//julia:depot.bzlrY

julia_depotjulia	depot.bzl(
julia_depotjulia_depot
 ( 3
  5�
//julia:dist.bzlr�

julia_depotjuliadist.bzl:
DEFAULT_STRIP_PREFIXDEFAULT_STRIP_PREFIX
!'!;(
DEFAULT_URLDEFAULT_URL
!?!J&

julia_dist
julia_dist
!N!X
!!Z�The `julia` module extension: a pinned Julia distribution, Manifest-pinned depots, and a pinned C compiler for sysimages.

    julia = use_extension("@julia_depot//julia:extensions.bzl", "julia")
    julia.dist(name = "julia_dist", version = "1.12.7")
    julia.depot(
        name = "my_depot",
        manifest = "//julia:Manifest.toml",
        julia = "@julia_dist",
    )
    use_repo(julia, "julia_dist", "my_depot")

The module declares one compiler itself, `@julia_depot_cc`, which julia_sysimage_layer uses
unless told otherwise. `julia.cc` declares another, for a different zig or glibc:

    julia.cc(name = "my_cc", glibc = "2.28")

Naming: a rule attribute that takes a repository is named after what it takes and is given
the repository itself: `julia = "@julia_dist"`, `depot = "@my_depot"`, `cc = "@my_cc"`. The rules
use each repository's default target, the one named after it. The named targets (`:dist`,
`bin/julia`, `:env`, `env.sh`, `stamp.txt`, `:cc`, `bin/cc`) remain for genrules and scripts.

Repository names are shared: the extension is evaluated once for the whole module graph, so
every module's `julia.dist` and `julia.depot` names share one namespace. Two modules
declaring the same name is an error, even when the declarations are identical, because
letting either win would make the other module build against a Julia, a manifest or a
compiler it did not declare. To keep names apart, the root module names its repositories freely, and a
module that others depend on prefixes every name with its own module name (for example
`reactant_server_julia` for its `julia_dist`).
��

julia_depotjulia	image.bzl�julia_compiled_layer�The precompile caches for an image's entry projects, as one layer.

The layers are unpacked into one tree with the image's layout and each entry project is
precompiled there, against the image's depot path rooted in that tree, for the image's
JULIA_CPU_TARGET. The caches are written to the first depot's compiled/, which is all the layer
holds, and load unchanged in the image. Precompiling also loads the whole stack for the first
time, so a package that cannot load fails the build instead of a container.

The tar is normalised like every other layer but is not bit-for-bit reproducible: Julia stamps
each cache with a build id and names each cache file with a hash over the build's paths, which
are in a fresh temporary tree. The same packages get caches every time, with the same modes,
owners and mtimes. Bazel caches the action, so the digest is stable while the inputs are.
"�
�
julia_compiled_layer�The precompile caches for an image's entry projects, as one layer.

The layers are unpacked into one tree with the image's layout and each entry project is
precompiled there, against the image's depot path rooted in that tree, for the image's
JULIA_CPU_TARGET. The caches are written to the first depot's compiled/, which is all the layer
holds, and load unchanged in the image. Precompiling also loads the whole stack for the first
time, so a package that cannot load fails the build instead of a container.

The tar is normalised like every other layer but is not bit-for-bit reproducible: Julia stamps
each cache with a build id and names each cache file with a hash over the build's paths, which
are in a fresh temporary tree. The same packages get caches every time, with the same modes,
owners and mtimes. Bazel caches the action, so the digest is stable while the inputs are.
*
nameA unique name for this target. �
env�Further variables for Julia, e.g. what a package reads in __init__ or to select an artifact. `{root}` in a value is the directory the layers are unpacked into, so a variable can name a file that only a build-time layer carries, such as a driver stub on LD_LIBRARY_PATH.
2{}N
	image_env(The julia_image_env the image runs with. *
JuliaImageEnvInfo~
juliaqThe Julia distribution, `@julia_dist` from julia.dist. Used when the layers carry no Julia at the image's prefix. �
layers�The image's layers, in oci_image order: at least the depot layer with packages, and every layer an entry project's files come from. l
projects\The entry projects, as absolute paths in the image: every project the image starts Julia in. o
sysimage]The sysimage the image starts Julia with, as a path in the image, when it is not Julia's own.2"""6
julia_compiled_layer@@julia_depot//julia:image.bzl
��,
*
nameA unique name for this target. �
�
env�Further variables for Julia, e.g. what a package reads in __init__ or to select an artifact. `{root}` in a value is the directory the layers are unpacked into, so a variable can name a file that only a build-time layer carries, such as a driver stub on LD_LIBRARY_PATH.
2{}P
N
	image_env(The julia_image_env the image runs with. *
JuliaImageEnvInfo�
~
juliaqThe Julia distribution, `@julia_dist` from julia.dist. Used when the layers carry no Julia at the image's prefix. �
�
layers�The image's layers, in oci_image order: at least the depot layer with packages, and every layer an entry project's files come from. n
l
projects\The entry projects, as absolute paths in the image: every project the image starts Julia in. q
o
sysimage]The sysimage the image starts Julia with, as a path in the image, when it is not Julia's own.2""�julia_depot_layer�A clean depot for the project at `prefix`, as one layer: image_depot.sh as a rule.

The project is instantiated from its Manifest into an empty depot, so the layer holds exactly its
closure. What the depot already holds of it is copied in first, checked by tree hash, so the
instantiate downloads only the rest. `contents = "artifacts"` ships artifacts/ only, for an image whose code is in a sysimage;
`"full"` ships packages/ too, for an image that loads from source, and is what
julia_compiled_layer needs. Fetches from the package server: set JULIA_PKG_SERVER with
--action_env to use a mirror.
"�
�
julia_depot_layer�A clean depot for the project at `prefix`, as one layer: image_depot.sh as a rule.

The project is instantiated from its Manifest into an empty depot, so the layer holds exactly its
closure. What the depot already holds of it is copied in first, checked by tree hash, so the
instantiate downloads only the rest. `contents = "artifacts"` ships artifacts/ only, for an image whose code is in a sysimage;
`"full"` ships packages/ too, for an image that loads from source, and is what
julia_compiled_layer needs. Fetches from the package server: set JULIA_PKG_SERVER with
--action_env to use a mirror.
*
nameA unique name for this target. O
contents4artifacts: artifacts/ only. full: packages/ as well.2"artifacts"�
depotwThe julia.depot repository, e.g. `@my_depot`. It brings the Julia and the Project.toml and Manifest it was fetched for. *
JuliaDepotInfot
envgVariables for the instantiate, e.g. what a package's platform augmentation reads to select an artifact.
2{}�
fresh_registry�Fetch the registry into the clean depot instead of copying the depot's registries and package-server credentials, which are otherwise used for the instantiate (and never shipped). The depot's packages and artifacts are not copied either, so everything is downloaded.2Falsez
min_artifactsdFail below this many artifact directories, to catch a selection that came up empty without an error.21k
overrides_buildPartifacts/Overrides.toml naming build-host directories; see docs/src/recipes.md.2Noney
overrides_image^The artifacts/Overrides.toml that ships, naming in-image paths. Required with overrides_build.2Noneh
prefixHWhere the image keeps the depot. Match julia_image_env's `depot_prefix`.2"/opt/julia-depot"�
srcs�Further project files (the package's source, LocalPreferences.toml, workspace members), staged at their paths relative to the depot's Project.toml.2[]"3
julia_depot_layer@@julia_depot//julia:image.bzl
��,
*
nameA unique name for this target. Q
O
contents4artifacts: artifacts/ only. full: packages/ as well.2"artifacts"�
�
depotwThe julia.depot repository, e.g. `@my_depot`. It brings the Julia and the Project.toml and Manifest it was fetched for. *
JuliaDepotInfov
t
envgVariables for the instantiate, e.g. what a package's platform augmentation reads to select an artifact.
2{}�
�
fresh_registry�Fetch the registry into the clean depot instead of copying the depot's registries and package-server credentials, which are otherwise used for the instantiate (and never shipped). The depot's packages and artifacts are not copied either, so everything is downloaded.2False|
z
min_artifactsdFail below this many artifact directories, to catch a selection that came up empty without an error.21m
k
overrides_buildPartifacts/Overrides.toml naming build-host directories; see docs/src/recipes.md.2None{
y
overrides_image^The artifacts/Overrides.toml that ships, naming in-image paths. Required with overrides_build.2Nonej
h
prefixHWhere the image keeps the depot. Match julia_image_env's `depot_prefix`.2"/opt/julia-depot"�
�
srcs�Further project files (the package's source, LocalPreferences.toml, workspace members), staged at their paths relative to the depot's Project.toml.2[]�julia_dist_layer\The pinned Julia distribution at `prefix`, as one layer. Its own relative symlinks are kept."�
�
julia_dist_layer\The pinned Julia distribution at `prefix`, as one layer. Its own relative symlinks are kept.*
nameA unique name for this target. C
julia6The Julia distribution, `@julia_dist` from julia.dist. ^
prefixDWhere the image keeps Julia. Match julia_image_env's `julia_prefix`.2"/opt/julia""2
julia_dist_layer@@julia_depot//julia:image.bzl
��,
*
nameA unique name for this target. E
C
julia6The Julia distribution, `@julia_dist` from julia.dist. `
^
prefixDWhere the image keeps Julia. Match julia_image_env's `julia_prefix`.2"/opt/julia"�julia_image_env�The Julia layout of an image, and the environment file that describes it.

Writes `<name>.env`, one KEY=VALUE per line, which plugs into rules_oci as `oci_image(env =
":<name>")`. Provides JuliaImageEnvInfo, which julia_compiled_layer and julia_precompile_test
take as `image_env`, so the caches are compiled for, and checked against, this environment.
"�
�
julia_image_env�The Julia layout of an image, and the environment file that describes it.

Writes `<name>.env`, one KEY=VALUE per line, which plugs into rules_oci as `oci_image(env =
":<name>")`. Provides JuliaImageEnvInfo, which julia_compiled_layer and julia_precompile_test
take as `image_env`, so the caches are compiled for, and checked against, this environment.
*
nameA unique name for this target. �

cpu_target�JULIA_CPU_TARGET, and the targets the compiled layer compiles for. Default: the portable list for the target platform's CPU (PORTABLE_X86_64_CPU_TARGET or PORTABLE_AARCH64_CPU_TARGET).2""}
depot_prefixWWhere the image keeps the depot: a julia_depot_layer's prefix. Caches are written here.2"/opt/julia-depot"�
env�Further variables for the image, written to the same file. Not applied when caches are built; pass those to the compiled layer's own `env`.
2{}�
extra_depots�Further depots, after `depot_prefix`. List the application's root here when it holds packages of its own, so their caches are relocatable.2[]Y
julia_prefix9Where the image keeps Julia: a julia_dist_layer's prefix.2"/opt/julia"[
	load_pathHJULIA_LOAD_PATH entries. Unset when empty, which leaves Julia's default.2[].
offlineSet JULIA_PKG_OFFLINE=true.2True^
pathNSet PATH to <julia>/bin:$PATH, which rules_oci expands against the base image.2True1
project JULIA_PROJECT. Unset when empty.2"""1
julia_image_env@@julia_depot//julia:image.bzl
��,
*
nameA unique name for this target. �
�

cpu_target�JULIA_CPU_TARGET, and the targets the compiled layer compiles for. Default: the portable list for the target platform's CPU (PORTABLE_X86_64_CPU_TARGET or PORTABLE_AARCH64_CPU_TARGET).2""
}
depot_prefixWWhere the image keeps the depot: a julia_depot_layer's prefix. Caches are written here.2"/opt/julia-depot"�
�
env�Further variables for the image, written to the same file. Not applied when caches are built; pass those to the compiled layer's own `env`.
2{}�
�
extra_depots�Further depots, after `depot_prefix`. List the application's root here when it holds packages of its own, so their caches are relocatable.2[][
Y
julia_prefix9Where the image keeps Julia: a julia_dist_layer's prefix.2"/opt/julia"]
[
	load_pathHJULIA_LOAD_PATH entries. Unset when empty, which leaves Julia's default.2[]0
.
offlineSet JULIA_PKG_OFFLINE=true.2True`
^
pathNSet PATH to <julia>/bin:$PATH, which rules_oci expands against the base image.2True3
1
project JULIA_PROJECT. Unset when empty.2""�julia_precompile_test�Tests that the image starts without precompiling, using its layers and no container.

Unpacks the layers into one tree with the image's layout and, in each entry project, loads its
modules with Julia's loading debug output on. Fails when any cache is rejected or any package is
compiled, as a container would do at its first start. Runs the image's own Julia when a
julia_dist_layer is among the layers, and the distribution's otherwise.
"�
�
julia_precompile_test�Tests that the image starts without precompiling, using its layers and no container.

Unpacks the layers into one tree with the image's layout and, in each entry project, loads its
modules with Julia's loading debug output on. Fails when any cache is rejected or any package is
compiled, as a container would do at its first start. Runs the image's own Julia when a
julia_dist_layer is among the layers, and the distribution's otherwise.
*
nameA unique name for this target. �
env�Further variables for Julia, e.g. what a package reads in __init__ or to select an artifact. `{root}` in a value is the directory the layers are unpacked into, so a variable can name a file that only a build-time layer carries, such as a driver stub on LD_LIBRARY_PATH.
2{}N
	image_env(The julia_image_env the image runs with. *
JuliaImageEnvInfo~
juliaqThe Julia distribution, `@julia_dist` from julia.dist. Used when the layers carry no Julia at the image's prefix. �
layers�The image's layers, in oci_image order: at least the depot layer with packages, and every layer an entry project's files come from. �
modules~What to load in every entry project. Default: each project's direct dependencies, and the project itself when it is a package.2[]l
projects\The entry projects, as absolute paths in the image: every project the image starts Julia in. o
sysimage]The sysimage the image starts Julia with, as a path in the image, when it is not Julia's own.2"""7
julia_precompile_test@@julia_depot//julia:image.bzl
��,
*
nameA unique name for this target. �
�
env�Further variables for Julia, e.g. what a package reads in __init__ or to select an artifact. `{root}` in a value is the directory the layers are unpacked into, so a variable can name a file that only a build-time layer carries, such as a driver stub on LD_LIBRARY_PATH.
2{}P
N
	image_env(The julia_image_env the image runs with. *
JuliaImageEnvInfo�
~
juliaqThe Julia distribution, `@julia_dist` from julia.dist. Used when the layers carry no Julia at the image's prefix. �
�
layers�The image's layers, in oci_image order: at least the depot layer with packages, and every layer an entry project's files come from. �
�
modules~What to load in every entry project. Default: each project's direct dependencies, and the project itself when it is a package.2[]n
l
projects\The entry projects, as absolute paths in the image: every project the image starts Julia in. q
o
sysimage]The sysimage the image starts Julia with, as a path in the image, when it is not Julia's own.2""�%julia_sysimage�A PackageCompiler sysimage, `<name>.so`, to start Julia with: `julia --sysimage <file>`.
For an image, pass it to julia_sysimage_layer, which ships this build rather than repeating it.

The packages come from the depot `depot` names, which its julia.depot fetch already instantiated
for this manifest. That depot is only read: a scratch depot in front takes anything the build
writes, so the action runs sandboxed. A sysimage does not replace the depot: JLLs resolve their
artifacts at startup.

The sysimage is linked by `cc`, by default the module's pinned compiler, so the compiler and the
glibc it links against are inputs of the action. `system_cc = True` uses the host's compiler
instead; the action is then tagged no-remote-cache.

The `inputs` output group holds `<name>.inputs.json`: the sysimage's declared inputs by sha256,
the same on every build of the same inputs, since the sysimage itself is not reproducible. It is
written by its own action, so `--output_groups=inputs` builds it without the sysimage.
"�
�
julia_sysimage�A PackageCompiler sysimage, `<name>.so`, to start Julia with: `julia --sysimage <file>`.
For an image, pass it to julia_sysimage_layer, which ships this build rather than repeating it.

The packages come from the depot `depot` names, which its julia.depot fetch already instantiated
for this manifest. That depot is only read: a scratch depot in front takes anything the build
writes, so the action runs sandboxed. A sysimage does not replace the depot: JLLs resolve their
artifacts at startup.

The sysimage is linked by `cc`, by default the module's pinned compiler, so the compiler and the
glibc it links against are inputs of the action. `system_cc = True` uses the host's compiler
instead; the action is then tagged no-remote-cache.

The `inputs` output group holds `<name>.inputs.json`: the sysimage's declared inputs by sha256,
the same on every build of the same inputs, since the sysimage itself is not reproducible. It is
written by its own action, so `--output_groups=inputs` builds it without the sysimage.
*
nameA unique name for this target. �
cc�The C compiler that links the sysimage: a julia.cc repository such as `@my_cc`, or any executable target. Default: the module's own, zig targeting glibc 2.17.2!@@julia_depot_cc//:julia_depot_cc�

cpu_target�The sysimage's CPU targets. Default: the portable list for the target platform's CPU, which costs build time and runs on any host of that architecture.2""�
data�Further inputs of the build outside the project, such as a file a package reads while it is compiled. Name them in `env` with $(execpath ...).2[]�
depotwThe julia.depot repository, e.g. `@my_depot`. It brings the Julia and the Project.toml and Manifest it was fetched for. *
JuliaDepotInfo�
env�Variables for the build. $(execpath ...) and $(location ...) expand for `data`, and {execroot} to the absolute execution root, so `"{execroot}/$(execpath //:config.toml)"` is an absolute path to an input.
2{}A
packages1Packages to bake, with everything they depend on. �
srcs�Further project files (the package's source, LocalPreferences.toml, workspace members), staged at their paths relative to the depot's Project.toml.2[]�
	system_ccwLink with the host's compiler instead of `cc`. The result depends on the host, so the action is tagged no-remote-cache.2False"0
julia_sysimage@@julia_depot//julia:image.bzl
��,
*
nameA unique name for this target. �
�
cc�The C compiler that links the sysimage: a julia.cc repository such as `@my_cc`, or any executable target. Default: the module's own, zig targeting glibc 2.17.2!@@julia_depot_cc//:julia_depot_cc�
�

cpu_target�The sysimage's CPU targets. Default: the portable list for the target platform's CPU, which costs build time and runs on any host of that architecture.2""�
�
data�Further inputs of the build outside the project, such as a file a package reads while it is compiled. Name them in `env` with $(execpath ...).2[]�
�
depotwThe julia.depot repository, e.g. `@my_depot`. It brings the Julia and the Project.toml and Manifest it was fetched for. *
JuliaDepotInfo�
�
env�Variables for the build. $(execpath ...) and $(location ...) expand for `data`, and {execroot} to the absolute execution root, so `"{execroot}/$(execpath //:config.toml)"` is an absolute path to an input.
2{}C
A
packages1Packages to bake, with everything they depend on. �
�
srcs�Further project files (the package's source, LocalPreferences.toml, workspace members), staged at their paths relative to the depot's Project.toml.2[]�
�
	system_ccwLink with the host's compiler instead of `cc`. The result depends on the host, so the action is tagged no-remote-cache.2False�
julia_sysimage_layer�A julia_sysimage as one image layer: the sysimage at `path`, its inputs file beside it.

It ships the sysimage `sysimage` built, so a build that needs the file as well as the layer
compiles it once. Ship a julia_depot_layer beside it for the artifacts, and start Julia with
`--sysimage <path>`. The `inputs` output group holds the sysimage's inputs file.
"�
�
julia_sysimage_layer�A julia_sysimage as one image layer: the sysimage at `path`, its inputs file beside it.

It ships the sysimage `sysimage` built, so a build that needs the file as well as the layer
compiles it once. Ship a julia_depot_layer beside it for the artifacts, and start Julia with
`--sysimage <path>`. The `inputs` output group holds the sysimage's inputs file.
*
nameA unique name for this target. �
pathgWhere the image keeps the sysimage; the inputs file goes beside it as `<path without .so>.inputs.json`.2"/opt/julia-sysimage/sys.so"@
sysimageThe julia_sysimage to ship. *
JuliaSysimageInfo"6
julia_sysimage_layer@@julia_depot//julia:image.bzl
��,
*
nameA unique name for this target. �
�
pathgWhere the image keeps the sysimage; the inputs file goes beside it as `<path without .so>.inputs.json`.2"/opt/julia-sysimage/sys.so"B
@
sysimageThe julia_sysimage to ship. *
JuliaSysimageInfo�julia_image_env_vars�The environment variables a Julia image needs, as a dict for oci_image's `env`.

The same variables `julia_image_env` writes, for a BUILD file that merges them with its own:

    env = julia_image_env_vars(project = "/opt/app") | {"MY_SETTING": "1"}
*�
�
julia_image_env_varsk
julia_prefixKwhere the image keeps the Julia distribution (a julia_dist_layer's prefix)."/opt/julia"(x
depot_prefixRwhere the image keeps the depot (a julia_depot_layer's prefix). Julia writes
here."/opt/julia-depot"(�
extra_depots�further depots, searched after `depot_prefix`, such as the application's root when
it holds packages of its own that the compiled layer caches.[](O
project<JULIA_PROJECT, the project Julia starts in. Unset when None.None(\
	load_pathGJULIA_LOAD_PATH entries. Unset when None, which leaves Julia's default.None(�

cpu_target�JULIA_CPU_TARGET. Must match the compiled layer's; julia_image_env ensures this
by passing it the same value. Defaults to the x86_64 list; pass
PORTABLE_AARCH64_CPU_TARGET for an aarch64 image. This function cannot choose by
platform, because oci_image takes `env` only as a dict or a label.Y"generic;sandybridge,-xsaveopt,clone_all;haswell,-rdrnd,base(1);x86-64-v4,-rdrnd,base(1)"(]
offlineJJULIA_PKG_OFFLINE=true, so Pkg in the image never reaches for the network.True(�
path�prepend Julia's bin/ to the base image's PATH, as `<julia>/bin:$PATH`, which rules_oci
expands against the base image's own PATH.True(�The environment variables a Julia image needs, as a dict for oci_image's `env`.

The same variables `julia_image_env` writes, for a BUILD file that merges them with its own:

    env = julia_image_env_vars(project = "/opt/app") | {"MY_SETTING": "1"}
"#
!A dict of variable name to value.26
julia_image_env_vars@@julia_depot//julia:image.bzl
bb�JuliaDepotInfoLA julia.depot repository: the Julia and the project it was instantiated for.2�

�
JuliaDepotInfoLA julia.depot repository: the Julia and the project it was instantiated for.1
julia(depset of Files: the Julia distribution.!
	julia_binFile: its bin/julia.H

julia_dist:File: its julia_dist.txt, the tarball it was fetched from.<
project1File: the Project.toml the depot was fetched for.2
manifest&File: the Manifest it was fetched for.h
project_dirYstring: the short path of the directory the project lives in, which `srcs` must be under.�
project_srcs�list of struct(rel, file): the further files a resolve reads (workspace members' Project.toml), at their paths relative to the project.
envFile: env.sh.
stampFile: stamp.txt."0
JuliaDepotInfo@@julia_depot//julia:image.bzl
3
1
julia(depset of Files: the Julia distribution.#
!
	julia_binFile: its bin/julia.J
H

julia_dist:File: its julia_dist.txt, the tarball it was fetched from.>
<
project1File: the Project.toml the depot was fetched for.4
2
manifest&File: the Manifest it was fetched for.j
h
project_dirYstring: the short path of the directory the project lives in, which `srcs` must be under.�
�
project_srcs�list of struct(rel, file): the further files a resolve reads (workspace members' Project.toml), at their paths relative to the project.

envFile: env.sh.

stampFile: stamp.txt.�JuliaImageEnvInfoYThe Julia layout of an image and the environment that describes it, from julia_image_env.2�
�
JuliaImageEnvInfoYThe Julia layout of an image and the environment that describes it, from julia_image_env.?
env8dict: every variable the image's environment file holds.V
julia_prefixFstring: where the image keeps the Julia distribution, e.g. /opt/julia.a

depot_pathSlist of strings: JULIA_DEPOT_PATH in search order. Caches are written to the first.N

cpu_target@string: JULIA_CPU_TARGET, which the compiled layer compiles for.F
project;string or None: JULIA_PROJECT, the project Julia starts in."3
JuliaImageEnvInfo@@julia_depot//julia:image.bzl
HHA
?
env8dict: every variable the image's environment file holds.X
V
julia_prefixFstring: where the image keeps the Julia distribution, e.g. /opt/julia.c
a

depot_pathSlist of strings: JULIA_DEPOT_PATH in search order. Caches are written to the first.P
N

cpu_target@string: JULIA_CPU_TARGET, which the compiled layer compiles for.H
F
project;string or None: JULIA_PROJECT, the project Julia starts in.�JuliaSysimageInfo[A sysimage from julia_sysimage, for julia_sysimage_layer to ship without building it again.2�
�
JuliaSysimageInfo[A sysimage from julia_sysimage, for julia_sysimage_layer to ship without building it again.
sysimageFile: the sysimage. 
inputsFile: its inputs file.[
host_ccPbool: linked with the host's compiler (system_cc), so not to be cached remotely.{

cpu_targetmstring: the CPU targets it was compiled for, the JULIA_CPU_TARGET an image starting Julia with it should set."3
JuliaSysimageInfo@@julia_depot//julia:image.bzl
��!

sysimageFile: the sysimage."
 
inputsFile: its inputs file.]
[
host_ccPbool: linked with the host's compiler (system_cc), so not to be cached remotely.}
{

cpu_targetmstring: the CPU targets it was compiled for, the JULIA_CPU_TARGET an image starting Julia with it should set.�
//julia:depot_info.bzlre
$
julia_depotjuliadepot_info.bzl/
JuliaDepotInfo_JuliaDepotInfo
#,#;
##O�	PORTABLE_AARCH64_CPU_TARGETegeneric;cortex-a57;thunderx2t99;carmel,clone_all;apple-m1,base(3);neoverse-512tvb,-rand,-fpac,base(3)jgegeneric;cortex-a57;thunderx2t99;carmel,clone_all;apple-m1,base(3);neoverse-512tvb,-rand,-fpac,base(3)�	PORTABLE_X86_64_CPU_TARGETWgeneric;sandybridge,-xsaveopt,clone_all;haswell,-rdrnd,base(1);x86-64-v4,-rdrnd,base(1)jYWgeneric;sandybridge,-xsaveopt,clone_all;haswell,-rdrnd,base(1);x86-64-v4,-rdrnd,base(1)�Image layers for a Julia application, and the environment and check that go with them.

    load(
        "@julia_depot//julia:image.bzl",
        "julia_compiled_layer",
        "julia_depot_layer",
        "julia_dist_layer",
        "julia_image_env",
        "julia_precompile_test",
        "julia_sysimage",
        "julia_sysimage_layer",
    )

Each layer rule writes one deterministic tar for rules_oci's `oci_image(tars = [...])`: entries
sorted, mtimes zeroed, owned by uid and gid 0, permissions normalised to 0755 or 0644. This module
does not depend on rules_oci and will not; the consumer wires the tars and the environment file
into its own `oci_image`. See docs/src/images.md for the whole recipe.

`julia_image_env` declares the layout once: where Julia, the depot and any other depots live in
the image, their search order, the CPU targets the caches are compiled for, and the active
project. It writes the image's environment as a KEY=VALUE file, which `oci_image(env = ...)`
takes as is. It passes the same facts to `julia_compiled_layer` and `julia_precompile_test`
through `JuliaImageEnvInfo`, so the caches are built for, and checked against, the environment
the image runs with. `julia_image_env_vars` returns the same variables as a dict, for a BUILD
file that merges them with its own.

`julia_sysimage` is the one rule here that writes no layer: it builds the sysimage as a plain
file, for a build or a test that starts Julia with it directly. `julia_sysimage_layer` ships that
file in an image, so a build that needs both compiles the sysimage once.

The rules call image_layers.sh, which wraps image_depot.sh and sysimage.sh. All three scripts are
internal: the rules are the interface. What the scripts decide is documented there.
 