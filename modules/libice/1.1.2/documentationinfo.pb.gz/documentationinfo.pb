�.
"
libicelibice_config_checks.bzlt
//autoconf:checks.bzlrY
)
rules_cc_autoconfautoconf
checks.bzl
checkschecks
	2	8
		:�*	LIBICE_CONFIG_CHECKSj�*2�*
��{"code":"","define":"TCPCONN","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_TCPCONN","type":"define"}
��{"code":"","define":"UNIXCONN","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_UNIXCONN","type":"define"}
��{"code":"#include <sys/types.h>\n#include <sys/socket.h>\n#include <netinet/in.h>\nint main(void) {\n    if (sizeof(struct sockaddr_in6))\n        return 0;\n    return 1;\n}\n","code_must_fail":"#include <sys/types.h>\n#include <sys/socket.h>\n#include <netinet/in.h>\nint main(void) {\n    if (sizeof((struct sockaddr_in6)))\n        return 0;\n    return 1;\n}\n","define":"IPv6","language":"c","name":"ac_cv_type_struct_sockaddr_in6","type":"type"}
��{"code":"#include <sys/types.h>\n#include <sys/socket.h>\nint main(void) {\n    if (sizeof(socklen_t))\n        return 0;\n    return 1;\n}\n","code_must_fail":"#include <sys/types.h>\n#include <sys/socket.h>\nint main(void) {\n    if (sizeof((socklen_t)))\n        return 0;\n    return 1;\n}\n","define":"HAVE_SOCKLEN_T","language":"c","name":"ac_cv_type_socklen_t","type":"type"}
��{"code":"","define":"ICE_t","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_ICE_t","type":"define"}
��{"code":"","define":"TRANS_CLIENT","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_TRANS_CLIENT","type":"define"}
��{"code":"","define":"TRANS_SERVER","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_TRANS_SERVER","type":"define"}
��{"code":"#define asprintf innocuous_asprintf\n#include <limits.h>\n#undef asprintf\n#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\nint asprintf (void);\n#else\nchar asprintf (void);\n#endif\n#if defined __stub_asprintf || defined __stub___asprintf\nchoke me\n#endif\nint main(void) { return asprintf(); }\n","define":"HAVE_ASPRINTF","language":"c","name":"ac_cv_func_asprintf","type":"function"}
��{"code":"#define arc4random_buf innocuous_arc4random_buf\n#include <limits.h>\n#undef arc4random_buf\n#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\nint arc4random_buf (void);\n#else\nchar arc4random_buf (void);\n#endif\n#if defined __stub_arc4random_buf || defined __stub___arc4random_buf\nchoke me\n#endif\nint main(void) { return arc4random_buf(); }\n","define":"HAVE_ARC4RANDOM_BUF","language":"c","name":"ac_cv_func_arc4random_buf","type":"function"}
��{"code":"#define getentropy innocuous_getentropy\n#include <limits.h>\n#undef getentropy\n#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\nint getentropy (void);\n#else\nchar getentropy (void);\n#endif\n#if defined __stub_getentropy || defined __stub___getentropy\nchoke me\n#endif\nint main(void) { return getentropy(); }\n","define":"HAVE_GETENTROPY","language":"c","name":"ac_cv_func_getentropy","type":"function"}
��{"code":"#define strcasecmp innocuous_strcasecmp\n#include <limits.h>\n#undef strcasecmp\n#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\nint strcasecmp (void);\n#else\nchar strcasecmp (void);\n#endif\n#if defined __stub_strcasecmp || defined __stub___strcasecmp\nchoke me\n#endif\nint main(void) { return strcasecmp(); }\n","define":"HAVE_STRCASECMP","language":"c","name":"ac_cv_func_strcasecmp","type":"function"}
��{"code":"#define strlcpy innocuous_strlcpy\n#include <limits.h>\n#undef strlcpy\n#ifdef __cplusplus\nextern \"C\"\n#endif\n#if defined _MSC_VER\nint strlcpy (void);\n#else\nchar strlcpy (void);\n#endif\n#if defined __stub_strlcpy || defined __stub___strlcpy\nchoke me\n#endif\nint main(void) { return strlcpy(); }\n","define":"HAVE_STRLCPY","language":"c","name":"ac_cv_func_strlcpy","type":"function"}
��{"code":"","define":"PACKAGE_NAME","define_value":"\"libICE\"","define_value_fail":"\"libICE\"","language":"c","name":"ac_cv_define_PACKAGE_NAME","type":"define"}
��{"code":"","define":"PACKAGE_TARNAME","define_value":"\"libICE\"","define_value_fail":"\"libICE\"","language":"c","name":"ac_cv_define_PACKAGE_TARNAME","type":"define"}
��{"code":"","define":"PACKAGE_VERSION","define_value":"\"1.1.2\"","define_value_fail":"\"1.1.2\"","language":"c","name":"ac_cv_define_PACKAGE_VERSION","type":"define"}
��{"code":"","define":"PACKAGE_STRING","define_value":"\"libICE 1.1.2\"","define_value_fail":"\"libICE 1.1.2\"","language":"c","name":"ac_cv_define_PACKAGE_STRING","type":"define"}
��{"code":"","define":"PACKAGE_BUGREPORT","define_value":"\"https://gitlab.freedesktop.org/xorg/lib/libice/-/issues\"","define_value_fail":"\"https://gitlab.freedesktop.org/xorg/lib/libice/-/issues\"","language":"c","name":"ac_cv_define_PACKAGE_BUGREPORT","type":"define"}
��{"code":"","define":"PACKAGE_URL","define_value":"\"\"","define_value_fail":"\"\"","language":"c","name":"ac_cv_define_PACKAGE_URL","type":"define"}
��{"code":"","define":"PACKAGE_VERSION_MAJOR","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_PACKAGE_VERSION_MAJOR","type":"define"}
��{"code":"","define":"PACKAGE_VERSION_MINOR","define_value":"1","define_value_fail":"1","language":"c","name":"ac_cv_define_PACKAGE_VERSION_MINOR","type":"define"}
��{"code":"","define":"PACKAGE_VERSION_PATCHLEVEL","define_value":"2","define_value_fail":"2","language":"c","name":"ac_cv_define_PACKAGE_VERSION_PATCHLEVEL","type":"define"}�Autoconf-style checks used to generate libICE's config.h.

Mirrors the probes in upstream configure.ac (plus the XTRANS_CONNECTION_FLAGS
macro from xorg-macros), evaluated against Bazel's configured cc_toolchain.
Standard C header checks and the AC_USE_SYSTEM_EXTENSIONS feature macros come
from the macro targets listed in the autoconf_hdr deps.
 