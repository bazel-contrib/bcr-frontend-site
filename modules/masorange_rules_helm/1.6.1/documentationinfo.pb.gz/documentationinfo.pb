�
$
masorange_rules_helmgcsgcs.bzl�	
gcs_upload�Rule used to upload a single file to a Google Cloud Storage bucket

To load the rule use:
```starlark
load("//gcs:defs.bzl", "gcs_upload")
```

Example of use:

```starlark
load("//gcs:defs.bzl", "gcs_upload")

gcs_upload(
    name = "push",
    src = ":file",
    destination = "gs://my-bucket/file.zip"
)
```

This rule builds an executable. Use `run` instead of `build` to upload the file.
"�
�

gcs_upload�Rule used to upload a single file to a Google Cloud Storage bucket

To load the rule use:
```starlark
load("//gcs:defs.bzl", "gcs_upload")
```

Example of use:

```starlark
load("//gcs:defs.bzl", "gcs_upload")

gcs_upload(
    name = "push",
    src = ":file",
    destination = "gs://my-bucket/file.zip"
)
```

This rule builds an executable. Use `run` instead of `build` to upload the file.
*
nameA unique name for this target. O
destination<Google storage destination url. Example: gs://my-bucket/file  
srcSource file to upload "1

gcs_upload#@@masorange_rules_helm//gcs:gcs.bzl
;;,
*
nameA unique name for this target. Q
O
destination<Google storage destination url. Example: gs://my-bucket/file "
 
srcSource file to upload �
//gcs/private:gcs_upload.bzlrl
3
masorange_rules_helmgcs/privategcs_upload.bzl'

gcs_upload_gcs_upload
;F
V
Rules GCS.�
9
masorange_rules_helmgcs/privategcloud_toolchain.bzl�gcloud_toolchain"�
�
gcloud_toolchain*
nameA unique name for this target. 

gcloud_bin 
gcloud_files 

gsutil_bin "L
gcloud_toolchain8@@masorange_rules_helm//gcs/private:gcloud_toolchain.bzl
||,
*
nameA unique name for this target. 


gcloud_bin 

gcloud_files 


gsutil_bin �
GcloudInfo	Helm info2�
�

GcloudInfo	Helm info&

gcloud_binGcloud executable binary&

gsutil_binGsutil executable binary
gcloud_filesGcloud files"F

GcloudInfo8@@masorange_rules_helm//gcs/private:gcloud_toolchain.bzl
WW(
&

gcloud_binGcloud executable binary(
&

gsutil_binGsutil executable binary

gcloud_filesGcloud files�	gcloud_repoFetch external gcloud binariesR�	
�
gcloud_repoFetch external gcloud binaries.
name"A unique name for this repository. 
platform �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 	
sha 
version *G
gcloud_repo8@@masorange_rules_helm//gcs/private:gcloud_toolchain.bzl
��0
.
name"A unique name for this repository. 

platform �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 
	
sha 

version �
gcloud_toolchain_configurelCreates a repository with toolchain definitions for all known platforms
which can be registered or selected.R�	
�
gcloud_toolchain_configurelCreates a repository with toolchain definitions for all known platforms
which can be registered or selected..
name"A unique name for this repository. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 *V
gcloud_toolchain_configure8@@masorange_rules_helm//gcs/private:gcloud_toolchain.bzl
�-�-0
.
name"A unique name for this repository. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 .	GCLOUD_DEFAULT_VERSION502.0.0j	502.0.0�

3
masorange_rules_helmgcs/privategcs_upload.bzl�	
gcs_upload�Rule used to upload a single file to a Google Cloud Storage bucket

To load the rule use:
```starlark
load("//gcs:defs.bzl", "gcs_upload")
```

Example of use:

```starlark
load("//gcs:defs.bzl", "gcs_upload")

gcs_upload(
    name = "push",
    src = ":file",
    destination = "gs://my-bucket/file.zip"
)
```

This rule builds an executable. Use `run` instead of `build` to upload the file.
"�
�

gcs_upload�Rule used to upload a single file to a Google Cloud Storage bucket

To load the rule use:
```starlark
load("//gcs:defs.bzl", "gcs_upload")
```

Example of use:

```starlark
load("//gcs:defs.bzl", "gcs_upload")

gcs_upload(
    name = "push",
    src = ":file",
    destination = "gs://my-bucket/file.zip"
)
```

This rule builds an executable. Use `run` instead of `build` to upload the file.
*
nameA unique name for this target. O
destination<Google storage destination url. Example: gs://my-bucket/file  
srcSource file to upload "@

gcs_upload2@@masorange_rules_helm//gcs/private:gcs_upload.bzl
;;,
*
nameA unique name for this target. Q
O
destination<Google storage destination url. Example: gs://my-bucket/file "
 
srcSource file to upload �
%
masorange_rules_helmgcsdefs.bzl�	
gcs_upload�Rule used to upload a single file to a Google Cloud Storage bucket

To load the rule use:
```starlark
load("//gcs:defs.bzl", "gcs_upload")
```

Example of use:

```starlark
load("//gcs:defs.bzl", "gcs_upload")

gcs_upload(
    name = "push",
    src = ":file",
    destination = "gs://my-bucket/file.zip"
)
```

This rule builds an executable. Use `run` instead of `build` to upload the file.
"�
�

gcs_upload�Rule used to upload a single file to a Google Cloud Storage bucket

To load the rule use:
```starlark
load("//gcs:defs.bzl", "gcs_upload")
```

Example of use:

```starlark
load("//gcs:defs.bzl", "gcs_upload")

gcs_upload(
    name = "push",
    src = ":file",
    destination = "gs://my-bucket/file.zip"
)
```

This rule builds an executable. Use `run` instead of `build` to upload the file.
*
nameA unique name for this target. O
destination<Google storage destination url. Example: gs://my-bucket/file  
srcSource file to upload "2

gcs_upload$@@masorange_rules_helm//gcs:defs.bzl
;;,
*
nameA unique name for this target. Q
O
destination<Google storage destination url. Example: gs://my-bucket/file "
 
srcSource file to upload �
//gcs/private:gcs_upload.bzlrl
3
masorange_rules_helmgcs/privategcs_upload.bzl'

gcs_upload_gcs_upload
;F
V
Rules GCS.��
&
masorange_rules_helmhelmhelm.bzl�	helm_push�
Publish a helm chart produced by `helm_chart` rule to a remote registry.

To load the rule use:
```starlark
load("//helm:defs.bzl", "helm_push")
```

This rule builds an executable. Use `run` instead of `build` to publish the chart.
"�
�
	helm_push�
Publish a helm chart produced by `helm_chart` rule to a remote registry.

To load the rule use:
```starlark
load("//helm:defs.bzl", "helm_push")
```

This rule builds an executable. Use `run` instead of `build` to publish the chart.
*
nameA unique name for this target. �
chart�
The packaged chart archive to be published. It can be a reference to a `helm_chart` rule or a reference to a helm archived file *
	ChartInfo�
repository_configl
The repository config file. Used in conjunction with repository_name. It only works with oci repos by now.
2None�
repository_name�The name of the repository from the repository config file provided to this rule.
You must provide a repository_config in order to use this as the name of the repository. It only works with oci repos by now.
2""�
repository_url�
The remote url of the registry. Do not add the chart name to the url. If you provide `repository_config` and a `repository_name` attributes
this field will be omitted.
2"""2
	helm_push%@@masorange_rules_helm//helm:helm.bzl
��,
*
nameA unique name for this target. �
�
chart�
The packaged chart archive to be published. It can be a reference to a `helm_chart` rule or a reference to a helm archived file *
	ChartInfo�
�
repository_configl
The repository config file. Used in conjunction with repository_name. It only works with oci repos by now.
2None�
�
repository_name�The name of the repository from the repository config file provided to this rule.
You must provide a repository_config in order to use this as the name of the repository. It only works with oci repos by now.
2""�
�
repository_url�
The remote url of the registry. Do not add the chart name to the url. If you provide `repository_config` and a `repository_name` attributes
this field will be omitted.
2""�4helm_release�
  Installs or upgrades a helm release of a chart in to a cluster using helm binary.

  To load the rule use:
  ```starlark
  load("//helm:defs.bzl", "helm_release")
  ```

  This rule builds an executable. Use `run` instead of `build` to execute it.

  ```starklark
helm_release(
    name = "install",
    remote_chart = "oci://docker.pkg.dev/helm-charts/test_helm_chart",
    version = "0.7.5",
    namespace = "myapp",
    release_name = "helm-release-name",
    values = ["additional_values.yaml"],
)

helm_release(
    name = "install",
    chart = ":chart",
    namespace = "myapp",
    release_name = "helm-release-name",
    values = glob(["charts/myapp/values.yaml"]),
)
```

Example of use providing a kubernetes context config:
```starklark
helm_release(
    name = "chart_install",
    chart = ":chart",
    release_name = "release-name",
    values = glob(["charts/myapp/values.yaml"]),
    kubernetes_context = "mm-k8s-context",
)
```

Example of use decryptying sops secrets:
```starklark

sops_decrypt(
  name = "secret",
  srcs = ["secrets.yaml"],
)

helm_release(
    name = "chart_install",
    chart = ":chart",
    release_name = "release-name",
    values = glob(["charts/myapp/values.yaml"]) + [":secret"],
)
```

Example of use with k8s_namespace annotated with a GCP SA:
```starklark
k8s_namespace(
  name = "test-namespace",
  namespace_name = "test-namespace",
  kubernetes_sa = "test-kubernetes-sa",
  kubernetes_context = "mm-k8s-context",
)

helm_release(
    name = "chart_install",
    chart = ":chart",
    namespace_dep = ":test-namespace",
    release_name = "release-name",
    values = glob(["charts/myapp/values.yaml"]),
)
```

"�'
�
helm_release�
  Installs or upgrades a helm release of a chart in to a cluster using helm binary.

  To load the rule use:
  ```starlark
  load("//helm:defs.bzl", "helm_release")
  ```

  This rule builds an executable. Use `run` instead of `build` to execute it.

  ```starklark
helm_release(
    name = "install",
    remote_chart = "oci://docker.pkg.dev/helm-charts/test_helm_chart",
    version = "0.7.5",
    namespace = "myapp",
    release_name = "helm-release-name",
    values = ["additional_values.yaml"],
)

helm_release(
    name = "install",
    chart = ":chart",
    namespace = "myapp",
    release_name = "helm-release-name",
    values = glob(["charts/myapp/values.yaml"]),
)
```

Example of use providing a kubernetes context config:
```starklark
helm_release(
    name = "chart_install",
    chart = ":chart",
    release_name = "release-name",
    values = glob(["charts/myapp/values.yaml"]),
    kubernetes_context = "mm-k8s-context",
)
```

Example of use decryptying sops secrets:
```starklark

sops_decrypt(
  name = "secret",
  srcs = ["secrets.yaml"],
)

helm_release(
    name = "chart_install",
    chart = ":chart",
    release_name = "release-name",
    values = glob(["charts/myapp/values.yaml"]) + [":secret"],
)
```

Example of use with k8s_namespace annotated with a GCP SA:
```starklark
k8s_namespace(
  name = "test-namespace",
  namespace_name = "test-namespace",
  kubernetes_sa = "test-kubernetes-sa",
  kubernetes_context = "mm-k8s-context",
)

helm_release(
    name = "chart_install",
    chart = ":chart",
    namespace_dep = ":test-namespace",
    release_name = "release-name",
    values = glob(["charts/myapp/values.yaml"]),
)
```

*
nameA unique name for this target. �
chart�
The packaged chart archive to be published. It can be a reference to a `helm_chart` rule or a reference to a helm archived file. To specify a helm chart from a remote repository use `remote_chart` instead.2None�
create_namespacenA flag to indicate helm binary to create the kubernetes namespace if it is not already present in the cluster.2TrueE
kubernetes_context)The name of the kubeconfig context to use2""�
	namespaceoThe namespace literal where to install the helm release. Set to `""` to use namespace from current kube context2""�
namespace_dep�A reference to a `k8s_namespace` rule from where to extract the namespace to be used to install the release.Namespace where this release is installed to. Must be a label to a k8s_namespace rule. It takes precedence over namespace2NoneM
release_name9The name of the helm release to be installed or upgraded. �
remote_chartvHelm registry url of the chart to be installed. If `chart` attribute is also providedd, `remote_chart` has preference.2""�
set�
A dictionary of key value pairs consisting on yaml paths and values to be replaced in the chart via --set helm option before installing it:
"yaml.path": "value"

2{}]
valuesMA list of value files to be provided to helm install command through -f flag.2[];
values_yaml&[Deprecated] Use `values` attr instead2[]�
version}Chart version to be installed in a kubernetes cluster. This option will only be used if the `remote_chart` attribute is used.2""J
wait:Helm flag to wait for all resources to be created to exit.2True"5
helm_release%@@masorange_rules_helm//helm:helm.bzl
��,
*
nameA unique name for this target. �
�
chart�
The packaged chart archive to be published. It can be a reference to a `helm_chart` rule or a reference to a helm archived file. To specify a helm chart from a remote repository use `remote_chart` instead.2None�
�
create_namespacenA flag to indicate helm binary to create the kubernetes namespace if it is not already present in the cluster.2TrueG
E
kubernetes_context)The name of the kubeconfig context to use2""�
�
	namespaceoThe namespace literal where to install the helm release. Set to `""` to use namespace from current kube context2""�
�
namespace_dep�A reference to a `k8s_namespace` rule from where to extract the namespace to be used to install the release.Namespace where this release is installed to. Must be a label to a k8s_namespace rule. It takes precedence over namespace2NoneO
M
release_name9The name of the helm release to be installed or upgraded. �
�
remote_chartvHelm registry url of the chart to be installed. If `chart` attribute is also providedd, `remote_chart` has preference.2""�
�
set�
A dictionary of key value pairs consisting on yaml paths and values to be replaced in the chart via --set helm option before installing it:
"yaml.path": "value"

2{}_
]
valuesMA list of value files to be provided to helm install command through -f flag.2[]=
;
values_yaml&[Deprecated] Use `values` attr instead2[]�
�
version}Chart version to be installed in a kubernetes cluster. This option will only be used if the `remote_chart` attribute is used.2""L
J
wait:Helm flag to wait for all resources to be created to exit.2True�helm_uninstall�
Uninstall a helm release.

To load the rule use:
```starlark
load("//helm:defs.bzl", "helm_uninstall")
```

This rule builds an executable. Use `run` instead of `build` to be uninstall the helm release.
"�	
�
helm_uninstall�
Uninstall a helm release.

To load the rule use:
```starlark
load("//helm:defs.bzl", "helm_uninstall")
```

This rule builds an executable. Use `run` instead of `build` to be uninstall the helm release.
*
nameA unique name for this target. E
kubernetes_context)The name of the kubeconfig context to use2""E
	namespace2The namespace where the helm release is installed.2""�
namespace_depnA reference to a `k8s_namespace` rule from where to extract the namespace where the helm release is installed.2NoneM
release_name9The name of the helm release to be installed or upgraded. J
wait:Helm flag to wait for all resources to be created to exit.2True"7
helm_uninstall%@@masorange_rules_helm//helm:helm.bzl
BB,
*
nameA unique name for this target. G
E
kubernetes_context)The name of the kubeconfig context to use2""G
E
	namespace2The namespace where the helm release is installed.2""�
�
namespace_depnA reference to a `k8s_namespace` rule from where to extract the namespace where the helm release is installed.2NoneO
M
release_name9The name of the helm release to be installed or upgraded. L
J
wait:Helm flag to wait for all resources to be created to exit.2True�
helm_chart*�
Y

helm_chart

name (

kwargs(23

helm_chart%@@masorange_rules_helm//helm:helm.bzl
*_helm_chart*_helm_chart2_helm_chart2_helm_chart�		ChartInfo�
`helm_chart` expose ChartInfo providers to be able to access info about a packaged chart. The info available is:
- The name of the chart
- The version of the chart
- The ouput sources of the chart
- The output archive file targz
2�
�
	ChartInfo�
`helm_chart` expose ChartInfo providers to be able to access info about a packaged chart. The info available is:
- The name of the chart
- The version of the chart
- The ouput sources of the chart
- The output archive file targz
T
targzKThe output of helm_chart. This is the versioned packaged targz of the chartq

chart_namecThe name of the chart as is reflected in the Chart.yaml manifest and provided by the rule attribute6
chart_version%If provided, the version of the chartT

chart_srcsFThe sources of the chart before beign packaged into the archived targz"2
	ChartInfo%@@masorange_rules_helm//helm:helm.bzl
V
T
targzKThe output of helm_chart. This is the versioned packaged targz of the charts
q

chart_namecThe name of the chart as is reflected in the Chart.yaml manifest and provided by the rule attribute8
6
chart_version%If provided, the version of the chartV
T

chart_srcsFThe sources of the chart before beign packaged into the archived targz�*	helm_pull�
    Repository rule to download a `helm_chart` from a remote registry.

    To load the rule use:
    ```starlark
    load("//helm:defs.bzl", "helm_pull")
    ```

    It uses `helm` binary to download the chart, so `helm` has to be available in the PATH of the host machine where bazel is running.

    Default credentials on the host machine are used to authenticate against the remote registry.
    To use basic auth you must provide the basic credentials through env variables: `HELM_USER` and `HELM_PASSWORD`.

    OCI registries are supported.

    The downloaded chart is defined using the `helm_chart` rule and it's available as `:chart` target inside the repo name.

    ```starlark
    # With bzlmod, you typically will:
    # MODULE.bazel
    bazel_dep(name = "masorange_rules_helm", version = "1.3.1")

    helm = use_extension("@masmovil_bazel_rules//:extensions.bzl", "utils")

    helm.pull(
        name = "some_chart",
        chart_name = "chart_name",
        # do not add the chart name to the end of the url
        repo_url = "oci://docker.pkg.dev/helm-charts",
        version = "v1-stable",
    )
    use_repo(helm, "some_chart")
```

In non bzlmod workspaces:
```starlark
    # WORKSPACE
    load("//helm:defs.bzl", "helm_pull")

    helm_pull(
        name = "example_helm_chart",
        chart_name = "example",
        repo_url = "oci://docker.pkg.dev/project/helm-charts",
        version = "1.0.0",
    )
    ```

    It can be later referenced in a BUILD file in `helm_chart` dep:

```starlark
    helm_chart(
        ...
        deps = [
            "@example_helm_chart//:chart",
        ]
    )
    ```
R�
�
	helm_pull�
    Repository rule to download a `helm_chart` from a remote registry.

    To load the rule use:
    ```starlark
    load("//helm:defs.bzl", "helm_pull")
    ```

    It uses `helm` binary to download the chart, so `helm` has to be available in the PATH of the host machine where bazel is running.

    Default credentials on the host machine are used to authenticate against the remote registry.
    To use basic auth you must provide the basic credentials through env variables: `HELM_USER` and `HELM_PASSWORD`.

    OCI registries are supported.

    The downloaded chart is defined using the `helm_chart` rule and it's available as `:chart` target inside the repo name.

    ```starlark
    # With bzlmod, you typically will:
    # MODULE.bazel
    bazel_dep(name = "masorange_rules_helm", version = "1.3.1")

    helm = use_extension("@masmovil_bazel_rules//:extensions.bzl", "utils")

    helm.pull(
        name = "some_chart",
        chart_name = "chart_name",
        # do not add the chart name to the end of the url
        repo_url = "oci://docker.pkg.dev/helm-charts",
        version = "v1-stable",
    )
    use_repo(helm, "some_chart")
```

In non bzlmod workspaces:
```starlark
    # WORKSPACE
    load("//helm:defs.bzl", "helm_pull")

    helm_pull(
        name = "example_helm_chart",
        chart_name = "example",
        repo_url = "oci://docker.pkg.dev/project/helm-charts",
        version = "1.0.0",
    )
    ```

    It can be later referenced in a BUILD file in `helm_chart` dep:

```starlark
    helm_chart(
        ...
        deps = [
            "@example_helm_chart//:chart",
        ]
    )
    ```
.
name"A unique name for this repository. p

chart_name^The name of the helm_chart to download. It will be appendend at the end of the repository url. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
	repo_name�The name of the repository. This is only useful if you provide a `repository_config` file and you want the repo url to be located within the repo config.2""a
repo_urlQThe url where the chart is located. You have to omit the chart name from the url. 8
repository_configThe repository config file.2Nonej
versionYThe version of the chart to download. If no specified, the latest version will be pulled.2""*2
	helm_pull%@@masorange_rules_helm//helm:helm.bzl
��0
.
name"A unique name for this repository. r
p

chart_name^The name of the helm_chart to download. It will be appendend at the end of the repository url. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
�
	repo_name�The name of the repository. This is only useful if you provide a `repository_config` file and you want the repo url to be located within the repo config.2""c
a
repo_urlQThe url where the chart is located. You have to omit the chart name from the url. :
8
repository_configThe repository config file.2Nonel
j
versionYThe version of the chart to download. If no specified, the latest version will be pulled.2""�
//helm:defs.bzlr�
&
masorange_rules_helmhelmdefs.bzl&
	ChartInfo_chart_info
'

helm_chart_helm_chart
*
helm_lint_test
_helm_lint
%
	helm_pull
_helm_pull
%
	helm_push
_helm_push
		+
helm_release_helm_release


/
helm_uninstall_helm_uninstall

7Maintained as public export api for retro-compatibility�|
4
masorange_rules_helmhelm/privatechart_srcs.bzl�t
chart_srcs�Customize helm chart values and configuration.

This rule should not be used directly, users should use `helm_chart` macro instead. See [helm_chart](#helm_chart).
Despite, if you want to see the configuration arguments you can use to package a helm chart using `helm_chart` rule, check the arguments doc below for `chart_srcs` rule,
as `helm_chart` is just a wrapper around `chart_srcs` rule and all the arguments are propagated to `chart_srcs` rule.


This rule takes chart src files and write them to bazel output dir applying some modifications.
The rule is designed to be used with a packager to produce an archived file (`pkg_tar` is used).

```starlark
chart_srcs(
    name = "basic_chart",
    chart_name = "example",
    srcs = glob(["**"]),
)
```

You can customize the values of the chart overriding them via `values` rule attribute:

```starlark
chart_srcs(
    name = "basic_chart",
    chart_name = "example",
    srcs = glob(["**"]),
    values = {
        "override.value": "valueoverrided",
    }
)
```

Chart src files are not mandatory, you can specify all the chart configuration via rule attributes.
In this case the rule will take care of generating the chart files for you (Chart.yaml, values.yaml, template files, chart deps...).

```starlark
chart_srcs(
    name = "chart",
    chart_name = "example",
    version = "v1.0.0",
    app_version = "v2.3.4",
    api_version = "v2",
    description = "Helm chart description placed inside Chart.yaml",
    image = ":oci_image",
    values = {
        "yaml.path.to.value": "value",
    },
)
```

Stamp variables are supported in values attribute. To enable the use of stamp variables enable them via stamp attribute and --stamp flag in bazel.
You can customize stamped variables using bazel workspace status. See [the Bazel workspace status docs](https://docs.bazel.build/versions/master/user-manual.html#workspace_status)

All values with ${} format will be replaced by stamped variables (both volatile and stable are supported).

```starlark
chart_srcs(
    name = "chart",
    chart_name = "example",
    srcs = glob(["**"]),
    stamp = -1,
    values = {
        "stamped.value": "${STAMPED_VARIABLE}",
    },
)
```

For compatibility reasons, some attributes are still supported but marked as deprecated. Its use is discouraged.
"�b
�:

chart_srcs�Customize helm chart values and configuration.

This rule should not be used directly, users should use `helm_chart` macro instead. See [helm_chart](#helm_chart).
Despite, if you want to see the configuration arguments you can use to package a helm chart using `helm_chart` rule, check the arguments doc below for `chart_srcs` rule,
as `helm_chart` is just a wrapper around `chart_srcs` rule and all the arguments are propagated to `chart_srcs` rule.


This rule takes chart src files and write them to bazel output dir applying some modifications.
The rule is designed to be used with a packager to produce an archived file (`pkg_tar` is used).

```starlark
chart_srcs(
    name = "basic_chart",
    chart_name = "example",
    srcs = glob(["**"]),
)
```

You can customize the values of the chart overriding them via `values` rule attribute:

```starlark
chart_srcs(
    name = "basic_chart",
    chart_name = "example",
    srcs = glob(["**"]),
    values = {
        "override.value": "valueoverrided",
    }
)
```

Chart src files are not mandatory, you can specify all the chart configuration via rule attributes.
In this case the rule will take care of generating the chart files for you (Chart.yaml, values.yaml, template files, chart deps...).

```starlark
chart_srcs(
    name = "chart",
    chart_name = "example",
    version = "v1.0.0",
    app_version = "v2.3.4",
    api_version = "v2",
    description = "Helm chart description placed inside Chart.yaml",
    image = ":oci_image",
    values = {
        "yaml.path.to.value": "value",
    },
)
```

Stamp variables are supported in values attribute. To enable the use of stamp variables enable them via stamp attribute and --stamp flag in bazel.
You can customize stamped variables using bazel workspace status. See [the Bazel workspace status docs](https://docs.bazel.build/versions/master/user-manual.html#workspace_status)

All values with ${} format will be replaced by stamped variables (both volatile and stable are supported).

```starlark
chart_srcs(
    name = "chart",
    chart_name = "example",
    srcs = glob(["**"]),
    stamp = -1,
    values = {
        "stamped.value": "${STAMPED_VARIABLE}",
    },
)
```

For compatibility reasons, some attributes are still supported but marked as deprecated. Its use is discouraged.
*
nameA unique name for this target. A
additional_templates#[Deprecated] Use templates instead.2[]m
api_versionXHelm chart manifest apiVersion. The value is replaced in the output Chart.yaml manifest.2""z
app_versioneHelm chart appVersion. The value is replaced in the output Chart.yaml manifest in the appVersion key.2""�
app_version_manifest�Helm chart appVersion file. The value is replaced in the output Chart.yaml manifest in the appVersion key. The file can be a yaml file or a json file containing a single key named version.2None]

chart_deps<[Deprecated] Chart dependencies. Use deps attribute instead.*
	ChartInfo2[]\

chart_nameJName of the chart. It will be modified in the name field of the Chart.yaml �
deps�
A list of helm chart that this helm chart depends on. They will be placed inside the `charts` directory.
The dependencies will be traced inside the Chart.yaml manifest as well.
*
	ChartInfo2[]�
deps_conditions�
A dictionary containing the conditions that the dependencies of the chart should met to be rendered by helm.
The key has to be the name of the dependency chart. The value will be the condition that the values of the chart should have.
Check helm doc for more info https://helm.sh/docs/topics/charts/#the-chartyaml-file

2{}n
descriptionYHelm chart manifest description. The value is replaced in the output Chart.yaml manifest.2""�
force_repository_append�
A flag to specify if @ should be appended to the repository value in the chart values.yaml (in case `image` rule attribute is specified).
The rules will look for the specified repository value inside the values.yaml.
This is intended to meet image url with digest format: `gcr.io/container@sha256:a12e258c58ab92be22e403d08c8ef7eefd6119235eddca01309fe6b21101e100`.
If you have this already covered in your deployment templates, set this attr to false.
If the flag is set to true, the image rule attr is provided and no `values_repo_yaml_path` is set, the rule will look for the default path of the
repository value. .image.repository
2TrueQ
helm_chart_version5[Deprecated] Helm chart version. Use version instead.2""�
image�
Reference to image rule use to interpolate the image sha256 in the chart values.yaml.
If provided, the sha256 of the image will be placed in the output values.yaml of the chart in the yaml path provided by `values_tag_yaml_path` attribute.
Only oci_image rules are supported.2Nonei
image_digestQReference to oci_image digest file. Used internally by the macro (do not use it).2None`
image_repositoryF[Deprecated] You can use values attr dict to modify repository values.2""<
	image_tag)[Deprecated] Use image attribute instead.2""K
package_name5[Deprecated] Helm chart name. Use chart_name instead.2""�
path_to_chart�Attribute to specify the path to the root of the chart. This attribute is mandatory if neither Chart.yaml nor values.yaml are provided, and the chart srcs attr is not empty to determinate where in the path of the source files is located the root of the helm chart.2""0
srcs"A list of helm chart source files.2[]�
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.
2-1�
	templates�
A list of files that will be added to the chart. They will be added as addition to the chart templates refernced in the `srcs` attribute.
2[]�
values�
A dictionary of key values to be written in to the chart values.
keys: `yaml.path` or `.yaml.path`
values:  the value to be replaced inside the Chart values.yaml.
This attr supports use of stamped values. To provide a stamped value you have to use ${STAMP_VARIABLE_NAME} as value of the dict with
your stamped variable key. Make sure to enable stamping in your rule with the attribute `stamp`.

2{}�
values_repo_yaml_path{[Deprecated] Yaml path used to set the repo config provided by `image_repository` attribute (deprecated). .image.repository2""l
values_tag_yaml_pathDYaml path used to set the image sha256 inside the chart values.yaml.2".image.tag"G
version6Helm chart version to be placed in Chart.yaml manifest2""�
version_manifest�Helm chart version file to be used to set the chart version in Chart.yaml manifest. The file can be a yaml file or a josn file containing a single key named version.2None"A

chart_srcs3@@masorange_rules_helm//helm/private:chart_srcs.bzl
��,
*
nameA unique name for this target. C
A
additional_templates#[Deprecated] Use templates instead.2[]o
m
api_versionXHelm chart manifest apiVersion. The value is replaced in the output Chart.yaml manifest.2""|
z
app_versioneHelm chart appVersion. The value is replaced in the output Chart.yaml manifest in the appVersion key.2""�
�
app_version_manifest�Helm chart appVersion file. The value is replaced in the output Chart.yaml manifest in the appVersion key. The file can be a yaml file or a json file containing a single key named version.2None_
]

chart_deps<[Deprecated] Chart dependencies. Use deps attribute instead.*
	ChartInfo2[]^
\

chart_nameJName of the chart. It will be modified in the name field of the Chart.yaml �
�
deps�
A list of helm chart that this helm chart depends on. They will be placed inside the `charts` directory.
The dependencies will be traced inside the Chart.yaml manifest as well.
*
	ChartInfo2[]�
�
deps_conditions�
A dictionary containing the conditions that the dependencies of the chart should met to be rendered by helm.
The key has to be the name of the dependency chart. The value will be the condition that the values of the chart should have.
Check helm doc for more info https://helm.sh/docs/topics/charts/#the-chartyaml-file

2{}p
n
descriptionYHelm chart manifest description. The value is replaced in the output Chart.yaml manifest.2""�
�
force_repository_append�
A flag to specify if @ should be appended to the repository value in the chart values.yaml (in case `image` rule attribute is specified).
The rules will look for the specified repository value inside the values.yaml.
This is intended to meet image url with digest format: `gcr.io/container@sha256:a12e258c58ab92be22e403d08c8ef7eefd6119235eddca01309fe6b21101e100`.
If you have this already covered in your deployment templates, set this attr to false.
If the flag is set to true, the image rule attr is provided and no `values_repo_yaml_path` is set, the rule will look for the default path of the
repository value. .image.repository
2TrueS
Q
helm_chart_version5[Deprecated] Helm chart version. Use version instead.2""�
�
image�
Reference to image rule use to interpolate the image sha256 in the chart values.yaml.
If provided, the sha256 of the image will be placed in the output values.yaml of the chart in the yaml path provided by `values_tag_yaml_path` attribute.
Only oci_image rules are supported.2Nonek
i
image_digestQReference to oci_image digest file. Used internally by the macro (do not use it).2Noneb
`
image_repositoryF[Deprecated] You can use values attr dict to modify repository values.2"">
<
	image_tag)[Deprecated] Use image attribute instead.2""M
K
package_name5[Deprecated] Helm chart name. Use chart_name instead.2""�
�
path_to_chart�Attribute to specify the path to the root of the chart. This attribute is mandatory if neither Chart.yaml nor values.yaml are provided, and the chart srcs attr is not empty to determinate where in the path of the source files is located the root of the helm chart.2""2
0
srcs"A list of helm chart source files.2[]�
�
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.
2-1�
�
	templates�
A list of files that will be added to the chart. They will be added as addition to the chart templates refernced in the `srcs` attribute.
2[]�
�
values�
A dictionary of key values to be written in to the chart values.
keys: `yaml.path` or `.yaml.path`
values:  the value to be replaced inside the Chart values.yaml.
This attr supports use of stamped values. To provide a stamped value you have to use ${STAMP_VARIABLE_NAME} as value of the dict with
your stamped variable key. Make sure to enable stamping in your rule with the attribute `stamp`.

2{}�
�
values_repo_yaml_path{[Deprecated] Yaml path used to set the repo config provided by `image_repository` attribute (deprecated). .image.repository2""n
l
values_tag_yaml_pathDYaml path used to set the image sha256 inside the chart values.yaml.2".image.tag"I
G
version6Helm chart version to be placed in Chart.yaml manifest2""�
�
version_manifest�Helm chart version file to be used to set the chart version in Chart.yaml manifest. The file can be a yaml file or a josn file containing a single key named version.2None�
//lib:copy_file.bzlr�
&
aspect_bazel_liblibcopy_file.bzl:
COPY_FILE_TOOLCHAINSCOPY_FILE_TOOLCHAINS
/C2
copy_file_actioncopy_file_action
GW
Y�
//lib:stamping.bzlr�
%
aspect_bazel_liblibstamping.bzl(
STAMP_ATTRSSTAMP_ATTRS
.9(
maybe_stampmaybe_stamp
=H
Ja
//lib:dicts.bzlrL

bazel_skyliblib	dicts.bzl
dictsdicts
',
.a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.�
'//helm/private:helm_chart_providers.bzlrt
>
masorange_rules_helmhelm/privatehelm_chart_providers.bzl$
	ChartInfo	ChartInfo
GP
RD	DEFAULT_VALUES_REPO_YAML.image.repositoryj.image.repository&	DEFAULT_HELM_API_VERSIONv2jv2.	DEFAULT_HELM_CHART_VERSION1.0.0j1.0.0�
4
masorange_rules_helmhelm/privatehelm_chart.bzl��
helm_chart�!Bazel macro function to package a helm chart in to a targz archive file.

The macro is intended to be used as the public API for packaging a chart. It is a wrapper around `chart_srcs` rule. All the args are propagated to `chart_srcs` rule.
See [chart_srcs](#chart_srcs) arguments to see the available config.


To load the rule use:
```starlark
load("//helm:defs.bzl", "helm_chart")
```

It also defines a %name%_lint test target to be able to test that your chart is well-formed (using `helm lint`).

To make the output reproducible this macro does not use `helm package` to package the chart into a versioned chart archive file.
It uses `pkg_tar` bazel rule instead to create the archive file. Check this to find more info about it:
- https://github.com/masmovil/bazel-rules/issues/55
- https://github.com/helm/helm/issues/3612#issuecomment-525340295

This macro exports some providers to share info about charts between rules. Check [helm_chart providers](#providers).

The args are the same that the `chart_srcs` rule, check [chart_srcs](#chart_srcs).

```starlark
load("//helm:defs.bzl", "helm_chart")

helm_chart(
    name = "basic_chart",
    chart_name = "example",
    srcs = glob(["**"]),
)

helm_chart(
    name = "basic_chart",
    chart_name = "example",
    srcs = glob(["**"]),
    values = {
        "override.value": "valueoverrided",
    }
)

helm_chart(
    name = "chart",
    chart_name = "example",
    version = "v1.0.0",
    app_version = "v2.3.4",
    api_version = "v2",
    description = "Helm chart description placed inside Chart.yaml",
    image = ":oci_image",
    values = {
        "yaml.path.to.value": "value",
    },
)

# version file version.json
{
    "version": "v1.0.0",
}

# BULD.bazel
helm_chart(
    name = "chart",
    chart_name = "example",
    version_file = ":version.json",
    app_version = "v2.3.4",
    api_version = "v2",
    description = "Helm chart description placed inside Chart.yaml",
    image = ":oci_image",
    values = {
        "yaml.path.to.value": "value",
    },
)
```


Customize helm chart values and configuration.

This rule should not be used directly, users should use `helm_chart` macro instead. See [helm_chart](#helm_chart).
Despite, if you want to see the configuration arguments you can use to package a helm chart using `helm_chart` rule, check the arguments doc below for `chart_srcs` rule,
as `helm_chart` is just a wrapper around `chart_srcs` rule and all the arguments are propagated to `chart_srcs` rule.


This rule takes chart src files and write them to bazel output dir applying some modifications.
The rule is designed to be used with a packager to produce an archived file (`pkg_tar` is used).

```starlark
chart_srcs(
    name = "basic_chart",
    chart_name = "example",
    srcs = glob(["**"]),
)
```

You can customize the values of the chart overriding them via `values` rule attribute:

```starlark
chart_srcs(
    name = "basic_chart",
    chart_name = "example",
    srcs = glob(["**"]),
    values = {
        "override.value": "valueoverrided",
    }
)
```

Chart src files are not mandatory, you can specify all the chart configuration via rule attributes.
In this case the rule will take care of generating the chart files for you (Chart.yaml, values.yaml, template files, chart deps...).

```starlark
chart_srcs(
    name = "chart",
    chart_name = "example",
    version = "v1.0.0",
    app_version = "v2.3.4",
    api_version = "v2",
    description = "Helm chart description placed inside Chart.yaml",
    image = ":oci_image",
    values = {
        "yaml.path.to.value": "value",
    },
)
```

Stamp variables are supported in values attribute. To enable the use of stamp variables enable them via stamp attribute and --stamp flag in bazel.
You can customize stamped variables using bazel workspace status. See [the Bazel workspace status docs](https://docs.bazel.build/versions/master/user-manual.html#workspace_status)

All values with ${} format will be replaced by stamped variables (both volatile and stable are supported).

```starlark
chart_srcs(
    name = "chart",
    chart_name = "example",
    srcs = glob(["**"]),
    stamp = -1,
    values = {
        "stamped.value": "${STAMPED_VARIABLE}",
    },
)
```

For compatibility reasons, some attributes are still supported but marked as deprecated. Its use is discouraged.
"�r
�I

helm_chart�!Bazel macro function to package a helm chart in to a targz archive file.

The macro is intended to be used as the public API for packaging a chart. It is a wrapper around `chart_srcs` rule. All the args are propagated to `chart_srcs` rule.
See [chart_srcs](#chart_srcs) arguments to see the available config.


To load the rule use:
```starlark
load("//helm:defs.bzl", "helm_chart")
```

It also defines a %name%_lint test target to be able to test that your chart is well-formed (using `helm lint`).

To make the output reproducible this macro does not use `helm package` to package the chart into a versioned chart archive file.
It uses `pkg_tar` bazel rule instead to create the archive file. Check this to find more info about it:
- https://github.com/masmovil/bazel-rules/issues/55
- https://github.com/helm/helm/issues/3612#issuecomment-525340295

This macro exports some providers to share info about charts between rules. Check [helm_chart providers](#providers).

The args are the same that the `chart_srcs` rule, check [chart_srcs](#chart_srcs).

```starlark
load("//helm:defs.bzl", "helm_chart")

helm_chart(
    name = "basic_chart",
    chart_name = "example",
    srcs = glob(["**"]),
)

helm_chart(
    name = "basic_chart",
    chart_name = "example",
    srcs = glob(["**"]),
    values = {
        "override.value": "valueoverrided",
    }
)

helm_chart(
    name = "chart",
    chart_name = "example",
    version = "v1.0.0",
    app_version = "v2.3.4",
    api_version = "v2",
    description = "Helm chart description placed inside Chart.yaml",
    image = ":oci_image",
    values = {
        "yaml.path.to.value": "value",
    },
)

# version file version.json
{
    "version": "v1.0.0",
}

# BULD.bazel
helm_chart(
    name = "chart",
    chart_name = "example",
    version_file = ":version.json",
    app_version = "v2.3.4",
    api_version = "v2",
    description = "Helm chart description placed inside Chart.yaml",
    image = ":oci_image",
    values = {
        "yaml.path.to.value": "value",
    },
)
```


Customize helm chart values and configuration.

This rule should not be used directly, users should use `helm_chart` macro instead. See [helm_chart](#helm_chart).
Despite, if you want to see the configuration arguments you can use to package a helm chart using `helm_chart` rule, check the arguments doc below for `chart_srcs` rule,
as `helm_chart` is just a wrapper around `chart_srcs` rule and all the arguments are propagated to `chart_srcs` rule.


This rule takes chart src files and write them to bazel output dir applying some modifications.
The rule is designed to be used with a packager to produce an archived file (`pkg_tar` is used).

```starlark
chart_srcs(
    name = "basic_chart",
    chart_name = "example",
    srcs = glob(["**"]),
)
```

You can customize the values of the chart overriding them via `values` rule attribute:

```starlark
chart_srcs(
    name = "basic_chart",
    chart_name = "example",
    srcs = glob(["**"]),
    values = {
        "override.value": "valueoverrided",
    }
)
```

Chart src files are not mandatory, you can specify all the chart configuration via rule attributes.
In this case the rule will take care of generating the chart files for you (Chart.yaml, values.yaml, template files, chart deps...).

```starlark
chart_srcs(
    name = "chart",
    chart_name = "example",
    version = "v1.0.0",
    app_version = "v2.3.4",
    api_version = "v2",
    description = "Helm chart description placed inside Chart.yaml",
    image = ":oci_image",
    values = {
        "yaml.path.to.value": "value",
    },
)
```

Stamp variables are supported in values attribute. To enable the use of stamp variables enable them via stamp attribute and --stamp flag in bazel.
You can customize stamped variables using bazel workspace status. See [the Bazel workspace status docs](https://docs.bazel.build/versions/master/user-manual.html#workspace_status)

All values with ${} format will be replaced by stamped variables (both volatile and stable are supported).

```starlark
chart_srcs(
    name = "chart",
    chart_name = "example",
    srcs = glob(["**"]),
    stamp = -1,
    values = {
        "stamped.value": "${STAMPED_VARIABLE}",
    },
)
```

For compatibility reasons, some attributes are still supported but marked as deprecated. Its use is discouraged.
*
nameA unique name for this target. A
additional_templates#[Deprecated] Use templates instead.2[]m
api_versionXHelm chart manifest apiVersion. The value is replaced in the output Chart.yaml manifest.2""z
app_versioneHelm chart appVersion. The value is replaced in the output Chart.yaml manifest in the appVersion key.2""�
app_version_manifest�Helm chart appVersion file. The value is replaced in the output Chart.yaml manifest in the appVersion key. The file can be a yaml file or a json file containing a single key named version.2None]

chart_deps<[Deprecated] Chart dependencies. Use deps attribute instead.*
	ChartInfo2[]\

chart_nameJName of the chart. It will be modified in the name field of the Chart.yaml �
deps�
A list of helm chart that this helm chart depends on. They will be placed inside the `charts` directory.
The dependencies will be traced inside the Chart.yaml manifest as well.
*
	ChartInfo2[]�
deps_conditions�
A dictionary containing the conditions that the dependencies of the chart should met to be rendered by helm.
The key has to be the name of the dependency chart. The value will be the condition that the values of the chart should have.
Check helm doc for more info https://helm.sh/docs/topics/charts/#the-chartyaml-file

2{}n
descriptionYHelm chart manifest description. The value is replaced in the output Chart.yaml manifest.2""�
force_repository_append�
A flag to specify if @ should be appended to the repository value in the chart values.yaml (in case `image` rule attribute is specified).
The rules will look for the specified repository value inside the values.yaml.
This is intended to meet image url with digest format: `gcr.io/container@sha256:a12e258c58ab92be22e403d08c8ef7eefd6119235eddca01309fe6b21101e100`.
If you have this already covered in your deployment templates, set this attr to false.
If the flag is set to true, the image rule attr is provided and no `values_repo_yaml_path` is set, the rule will look for the default path of the
repository value. .image.repository
2TrueQ
helm_chart_version5[Deprecated] Helm chart version. Use version instead.2""�
image�
Reference to image rule use to interpolate the image sha256 in the chart values.yaml.
If provided, the sha256 of the image will be placed in the output values.yaml of the chart in the yaml path provided by `values_tag_yaml_path` attribute.
Only oci_image rules are supported.2Nonei
image_digestQReference to oci_image digest file. Used internally by the macro (do not use it).2None`
image_repositoryF[Deprecated] You can use values attr dict to modify repository values.2""<
	image_tag)[Deprecated] Use image attribute instead.2""K
package_name5[Deprecated] Helm chart name. Use chart_name instead.2""�
path_to_chart�Attribute to specify the path to the root of the chart. This attribute is mandatory if neither Chart.yaml nor values.yaml are provided, and the chart srcs attr is not empty to determinate where in the path of the source files is located the root of the helm chart.2""0
srcs"A list of helm chart source files.2[]�
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.
2-1�
	templates�
A list of files that will be added to the chart. They will be added as addition to the chart templates refernced in the `srcs` attribute.
2[]�
values�
A dictionary of key values to be written in to the chart values.
keys: `yaml.path` or `.yaml.path`
values:  the value to be replaced inside the Chart values.yaml.
This attr supports use of stamped values. To provide a stamped value you have to use ${STAMP_VARIABLE_NAME} as value of the dict with
your stamped variable key. Make sure to enable stamping in your rule with the attribute `stamp`.

2{}�
values_repo_yaml_path{[Deprecated] Yaml path used to set the repo config provided by `image_repository` attribute (deprecated). .image.repository2""l
values_tag_yaml_pathDYaml path used to set the image sha256 inside the chart values.yaml.2".image.tag"G
version6Helm chart version to be placed in Chart.yaml manifest2""�
version_manifest�Helm chart version file to be used to set the chart version in Chart.yaml manifest. The file can be a yaml file or a josn file containing a single key named version.2None
,
*
nameA unique name for this target. C
A
additional_templates#[Deprecated] Use templates instead.2[]o
m
api_versionXHelm chart manifest apiVersion. The value is replaced in the output Chart.yaml manifest.2""|
z
app_versioneHelm chart appVersion. The value is replaced in the output Chart.yaml manifest in the appVersion key.2""�
�
app_version_manifest�Helm chart appVersion file. The value is replaced in the output Chart.yaml manifest in the appVersion key. The file can be a yaml file or a json file containing a single key named version.2None_
]

chart_deps<[Deprecated] Chart dependencies. Use deps attribute instead.*
	ChartInfo2[]^
\

chart_nameJName of the chart. It will be modified in the name field of the Chart.yaml �
�
deps�
A list of helm chart that this helm chart depends on. They will be placed inside the `charts` directory.
The dependencies will be traced inside the Chart.yaml manifest as well.
*
	ChartInfo2[]�
�
deps_conditions�
A dictionary containing the conditions that the dependencies of the chart should met to be rendered by helm.
The key has to be the name of the dependency chart. The value will be the condition that the values of the chart should have.
Check helm doc for more info https://helm.sh/docs/topics/charts/#the-chartyaml-file

2{}p
n
descriptionYHelm chart manifest description. The value is replaced in the output Chart.yaml manifest.2""�
�
force_repository_append�
A flag to specify if @ should be appended to the repository value in the chart values.yaml (in case `image` rule attribute is specified).
The rules will look for the specified repository value inside the values.yaml.
This is intended to meet image url with digest format: `gcr.io/container@sha256:a12e258c58ab92be22e403d08c8ef7eefd6119235eddca01309fe6b21101e100`.
If you have this already covered in your deployment templates, set this attr to false.
If the flag is set to true, the image rule attr is provided and no `values_repo_yaml_path` is set, the rule will look for the default path of the
repository value. .image.repository
2TrueS
Q
helm_chart_version5[Deprecated] Helm chart version. Use version instead.2""�
�
image�
Reference to image rule use to interpolate the image sha256 in the chart values.yaml.
If provided, the sha256 of the image will be placed in the output values.yaml of the chart in the yaml path provided by `values_tag_yaml_path` attribute.
Only oci_image rules are supported.2Nonek
i
image_digestQReference to oci_image digest file. Used internally by the macro (do not use it).2Noneb
`
image_repositoryF[Deprecated] You can use values attr dict to modify repository values.2"">
<
	image_tag)[Deprecated] Use image attribute instead.2""M
K
package_name5[Deprecated] Helm chart name. Use chart_name instead.2""�
�
path_to_chart�Attribute to specify the path to the root of the chart. This attribute is mandatory if neither Chart.yaml nor values.yaml are provided, and the chart srcs attr is not empty to determinate where in the path of the source files is located the root of the helm chart.2""2
0
srcs"A list of helm chart source files.2[]�
�
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.
2-1�
�
	templates�
A list of files that will be added to the chart. They will be added as addition to the chart templates refernced in the `srcs` attribute.
2[]�
�
values�
A dictionary of key values to be written in to the chart values.
keys: `yaml.path` or `.yaml.path`
values:  the value to be replaced inside the Chart values.yaml.
This attr supports use of stamped values. To provide a stamped value you have to use ${STAMP_VARIABLE_NAME} as value of the dict with
your stamped variable key. Make sure to enable stamping in your rule with the attribute `stamp`.

2{}�
�
values_repo_yaml_path{[Deprecated] Yaml path used to set the repo config provided by `image_repository` attribute (deprecated). .image.repository2""n
l
values_tag_yaml_pathDYaml path used to set the image sha256 inside the chart values.yaml.2".image.tag"I
G
version6Helm chart version to be placed in Chart.yaml manifest2""�
�
version_manifest�Helm chart version file to be used to set the chart version in Chart.yaml manifest. The file can be a yaml file or a josn file containing a single key named version.2None�
//helm/private:chart_srcs.bzlrl
4
masorange_rules_helmhelm/privatechart_srcs.bzl&

chart_srcs
chart_srcs
=G
I�
'//helm/private:helm_chart_providers.bzlr�
>
masorange_rules_helmhelm/privatehelm_chart_providers.bzl:
helm_chart_providershelm_chart_providers
G[
]�
!//helm/private:helm_lint_test.bzlrx
8
masorange_rules_helmhelm/privatehelm_lint_test.bzl.
helm_lint_testhelm_lint_test
AO
Q�
//pkg:mappings.bzlr�

	rules_pkgpkgmappings.bzl,
pkg_filegrouppkg_filegroup
'4$
	pkg_files	pkg_files
8A*
strip_prefixstrip_prefix
EQ
S^
//pkg:tar.bzlrK

	rules_pkgpkgtar.bzl 
pkg_tarpkg_tar
")
+�
>
masorange_rules_helmhelm/privatehelm_chart_providers.bzl�helm_chart_providers"�
�
helm_chart_providers*
nameA unique name for this target. 
chart_bin_srcs 

chart_name 
chart_targz 
chart_version2"""U
helm_chart_providers=@@masorange_rules_helm//helm/private:helm_chart_providers.bzl
..,
*
nameA unique name for this target. 

chart_bin_srcs 


chart_name 

chart_targz 

chart_version2""�
	ChartInfo�
`helm_chart` expose ChartInfo providers to be able to access info about a packaged chart. The info available is:
- The name of the chart
- The version of the chart
- The ouput sources of the chart
- The output archive file targz
2�
�
	ChartInfo�
`helm_chart` expose ChartInfo providers to be able to access info about a packaged chart. The info available is:
- The name of the chart
- The version of the chart
- The ouput sources of the chart
- The output archive file targz
T
targzKThe output of helm_chart. This is the versioned packaged targz of the chartq

chart_namecThe name of the chart as is reflected in the Chart.yaml manifest and provided by the rule attribute6
chart_version%If provided, the version of the chartT

chart_srcsFThe sources of the chart before beign packaged into the archived targz"J
	ChartInfo=@@masorange_rules_helm//helm/private:helm_chart_providers.bzl
V
T
targzKThe output of helm_chart. This is the versioned packaged targz of the charts
q

chart_namecThe name of the chart as is reflected in the Chart.yaml manifest and provided by the rule attribute8
6
chart_version%If provided, the version of the chartV
T

chart_srcsFThe sources of the chart before beign packaged into the archived targz�
//lib/private:copy_to_bin.bzlr�
0
aspect_bazel_liblib/privatecopy_to_bin.bzlD
copy_files_to_bin_actionscopy_files_to_bin_actions
9R
Ta
//lib:dicts.bzlrL

bazel_skyliblib	dicts.bzl
dictsdicts
',
.a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.a
//lib:shell.bzlrL

bazel_skyliblib	shell.bzl
shellshell
',
.�,
3
masorange_rules_helmhelm/privatehelm_pull.bzl�*	helm_pull�
    Repository rule to download a `helm_chart` from a remote registry.

    To load the rule use:
    ```starlark
    load("//helm:defs.bzl", "helm_pull")
    ```

    It uses `helm` binary to download the chart, so `helm` has to be available in the PATH of the host machine where bazel is running.

    Default credentials on the host machine are used to authenticate against the remote registry.
    To use basic auth you must provide the basic credentials through env variables: `HELM_USER` and `HELM_PASSWORD`.

    OCI registries are supported.

    The downloaded chart is defined using the `helm_chart` rule and it's available as `:chart` target inside the repo name.

    ```starlark
    # With bzlmod, you typically will:
    # MODULE.bazel
    bazel_dep(name = "masorange_rules_helm", version = "1.3.1")

    helm = use_extension("@masmovil_bazel_rules//:extensions.bzl", "utils")

    helm.pull(
        name = "some_chart",
        chart_name = "chart_name",
        # do not add the chart name to the end of the url
        repo_url = "oci://docker.pkg.dev/helm-charts",
        version = "v1-stable",
    )
    use_repo(helm, "some_chart")
```

In non bzlmod workspaces:
```starlark
    # WORKSPACE
    load("//helm:defs.bzl", "helm_pull")

    helm_pull(
        name = "example_helm_chart",
        chart_name = "example",
        repo_url = "oci://docker.pkg.dev/project/helm-charts",
        version = "1.0.0",
    )
    ```

    It can be later referenced in a BUILD file in `helm_chart` dep:

```starlark
    helm_chart(
        ...
        deps = [
            "@example_helm_chart//:chart",
        ]
    )
    ```
R�
�
	helm_pull�
    Repository rule to download a `helm_chart` from a remote registry.

    To load the rule use:
    ```starlark
    load("//helm:defs.bzl", "helm_pull")
    ```

    It uses `helm` binary to download the chart, so `helm` has to be available in the PATH of the host machine where bazel is running.

    Default credentials on the host machine are used to authenticate against the remote registry.
    To use basic auth you must provide the basic credentials through env variables: `HELM_USER` and `HELM_PASSWORD`.

    OCI registries are supported.

    The downloaded chart is defined using the `helm_chart` rule and it's available as `:chart` target inside the repo name.

    ```starlark
    # With bzlmod, you typically will:
    # MODULE.bazel
    bazel_dep(name = "masorange_rules_helm", version = "1.3.1")

    helm = use_extension("@masmovil_bazel_rules//:extensions.bzl", "utils")

    helm.pull(
        name = "some_chart",
        chart_name = "chart_name",
        # do not add the chart name to the end of the url
        repo_url = "oci://docker.pkg.dev/helm-charts",
        version = "v1-stable",
    )
    use_repo(helm, "some_chart")
```

In non bzlmod workspaces:
```starlark
    # WORKSPACE
    load("//helm:defs.bzl", "helm_pull")

    helm_pull(
        name = "example_helm_chart",
        chart_name = "example",
        repo_url = "oci://docker.pkg.dev/project/helm-charts",
        version = "1.0.0",
    )
    ```

    It can be later referenced in a BUILD file in `helm_chart` dep:

```starlark
    helm_chart(
        ...
        deps = [
            "@example_helm_chart//:chart",
        ]
    )
    ```
.
name"A unique name for this repository. p

chart_name^The name of the helm_chart to download. It will be appendend at the end of the repository url. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
	repo_name�The name of the repository. This is only useful if you provide a `repository_config` file and you want the repo url to be located within the repo config.2""a
repo_urlQThe url where the chart is located. You have to omit the chart name from the url. 8
repository_configThe repository config file.2Nonej
versionYThe version of the chart to download. If no specified, the latest version will be pulled.2""*?
	helm_pull2@@masorange_rules_helm//helm/private:helm_pull.bzl
��0
.
name"A unique name for this repository. r
p

chart_name^The name of the helm_chart to download. It will be appendend at the end of the repository url. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
�
	repo_name�The name of the repository. This is only useful if you provide a `repository_config` file and you want the repo url to be located within the repo config.2""c
a
repo_urlQThe url where the chart is located. You have to omit the chart name from the url. :
8
repository_configThe repository config file.2Nonel
j
versionYThe version of the chart to download. If no specified, the latest version will be pulled.2""a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.�
3
masorange_rules_helmhelm/privatehelm_push.bzl�	helm_push�
Publish a helm chart produced by `helm_chart` rule to a remote registry.

To load the rule use:
```starlark
load("//helm:defs.bzl", "helm_push")
```

This rule builds an executable. Use `run` instead of `build` to publish the chart.
"�
�
	helm_push�
Publish a helm chart produced by `helm_chart` rule to a remote registry.

To load the rule use:
```starlark
load("//helm:defs.bzl", "helm_push")
```

This rule builds an executable. Use `run` instead of `build` to publish the chart.
*
nameA unique name for this target. �
chart�
The packaged chart archive to be published. It can be a reference to a `helm_chart` rule or a reference to a helm archived file *
	ChartInfo�
repository_configl
The repository config file. Used in conjunction with repository_name. It only works with oci repos by now.
2None�
repository_name�The name of the repository from the repository config file provided to this rule.
You must provide a repository_config in order to use this as the name of the repository. It only works with oci repos by now.
2""�
repository_url�
The remote url of the registry. Do not add the chart name to the url. If you provide `repository_config` and a `repository_name` attributes
this field will be omitted.
2"""?
	helm_push2@@masorange_rules_helm//helm/private:helm_push.bzl
��,
*
nameA unique name for this target. �
�
chart�
The packaged chart archive to be published. It can be a reference to a `helm_chart` rule or a reference to a helm archived file *
	ChartInfo�
�
repository_configl
The repository config file. Used in conjunction with repository_name. It only works with oci repos by now.
2None�
�
repository_name�The name of the repository from the repository config file provided to this rule.
You must provide a repository_config in order to use this as the name of the repository. It only works with oci repos by now.
2""�
�
repository_url�
The remote url of the registry. Do not add the chart name to the url. If you provide `repository_config` and a `repository_name` attributes
this field will be omitted.
2""�
'//helm/private:helm_chart_providers.bzlrt
>
masorange_rules_helmhelm/privatehelm_chart_providers.bzl$
	ChartInfo	ChartInfo
GP
R�6
6
masorange_rules_helmhelm/privatehelm_release.bzl�5helm_release�
  Installs or upgrades a helm release of a chart in to a cluster using helm binary.

  To load the rule use:
  ```starlark
  load("//helm:defs.bzl", "helm_release")
  ```

  This rule builds an executable. Use `run` instead of `build` to execute it.

  ```starklark
helm_release(
    name = "install",
    remote_chart = "oci://docker.pkg.dev/helm-charts/test_helm_chart",
    version = "0.7.5",
    namespace = "myapp",
    release_name = "helm-release-name",
    values = ["additional_values.yaml"],
)

helm_release(
    name = "install",
    chart = ":chart",
    namespace = "myapp",
    release_name = "helm-release-name",
    values = glob(["charts/myapp/values.yaml"]),
)
```

Example of use providing a kubernetes context config:
```starklark
helm_release(
    name = "chart_install",
    chart = ":chart",
    release_name = "release-name",
    values = glob(["charts/myapp/values.yaml"]),
    kubernetes_context = "mm-k8s-context",
)
```

Example of use decryptying sops secrets:
```starklark

sops_decrypt(
  name = "secret",
  srcs = ["secrets.yaml"],
)

helm_release(
    name = "chart_install",
    chart = ":chart",
    release_name = "release-name",
    values = glob(["charts/myapp/values.yaml"]) + [":secret"],
)
```

Example of use with k8s_namespace annotated with a GCP SA:
```starklark
k8s_namespace(
  name = "test-namespace",
  namespace_name = "test-namespace",
  kubernetes_sa = "test-kubernetes-sa",
  kubernetes_context = "mm-k8s-context",
)

helm_release(
    name = "chart_install",
    chart = ":chart",
    namespace_dep = ":test-namespace",
    release_name = "release-name",
    values = glob(["charts/myapp/values.yaml"]),
)
```

"�'
�
helm_release�
  Installs or upgrades a helm release of a chart in to a cluster using helm binary.

  To load the rule use:
  ```starlark
  load("//helm:defs.bzl", "helm_release")
  ```

  This rule builds an executable. Use `run` instead of `build` to execute it.

  ```starklark
helm_release(
    name = "install",
    remote_chart = "oci://docker.pkg.dev/helm-charts/test_helm_chart",
    version = "0.7.5",
    namespace = "myapp",
    release_name = "helm-release-name",
    values = ["additional_values.yaml"],
)

helm_release(
    name = "install",
    chart = ":chart",
    namespace = "myapp",
    release_name = "helm-release-name",
    values = glob(["charts/myapp/values.yaml"]),
)
```

Example of use providing a kubernetes context config:
```starklark
helm_release(
    name = "chart_install",
    chart = ":chart",
    release_name = "release-name",
    values = glob(["charts/myapp/values.yaml"]),
    kubernetes_context = "mm-k8s-context",
)
```

Example of use decryptying sops secrets:
```starklark

sops_decrypt(
  name = "secret",
  srcs = ["secrets.yaml"],
)

helm_release(
    name = "chart_install",
    chart = ":chart",
    release_name = "release-name",
    values = glob(["charts/myapp/values.yaml"]) + [":secret"],
)
```

Example of use with k8s_namespace annotated with a GCP SA:
```starklark
k8s_namespace(
  name = "test-namespace",
  namespace_name = "test-namespace",
  kubernetes_sa = "test-kubernetes-sa",
  kubernetes_context = "mm-k8s-context",
)

helm_release(
    name = "chart_install",
    chart = ":chart",
    namespace_dep = ":test-namespace",
    release_name = "release-name",
    values = glob(["charts/myapp/values.yaml"]),
)
```

*
nameA unique name for this target. �
chart�
The packaged chart archive to be published. It can be a reference to a `helm_chart` rule or a reference to a helm archived file. To specify a helm chart from a remote repository use `remote_chart` instead.2None�
create_namespacenA flag to indicate helm binary to create the kubernetes namespace if it is not already present in the cluster.2TrueE
kubernetes_context)The name of the kubeconfig context to use2""�
	namespaceoThe namespace literal where to install the helm release. Set to `""` to use namespace from current kube context2""�
namespace_dep�A reference to a `k8s_namespace` rule from where to extract the namespace to be used to install the release.Namespace where this release is installed to. Must be a label to a k8s_namespace rule. It takes precedence over namespace2NoneM
release_name9The name of the helm release to be installed or upgraded. �
remote_chartvHelm registry url of the chart to be installed. If `chart` attribute is also providedd, `remote_chart` has preference.2""�
set�
A dictionary of key value pairs consisting on yaml paths and values to be replaced in the chart via --set helm option before installing it:
"yaml.path": "value"

2{}]
valuesMA list of value files to be provided to helm install command through -f flag.2[];
values_yaml&[Deprecated] Use `values` attr instead2[]�
version}Chart version to be installed in a kubernetes cluster. This option will only be used if the `remote_chart` attribute is used.2""J
wait:Helm flag to wait for all resources to be created to exit.2True"E
helm_release5@@masorange_rules_helm//helm/private:helm_release.bzl
��,
*
nameA unique name for this target. �
�
chart�
The packaged chart archive to be published. It can be a reference to a `helm_chart` rule or a reference to a helm archived file. To specify a helm chart from a remote repository use `remote_chart` instead.2None�
�
create_namespacenA flag to indicate helm binary to create the kubernetes namespace if it is not already present in the cluster.2TrueG
E
kubernetes_context)The name of the kubeconfig context to use2""�
�
	namespaceoThe namespace literal where to install the helm release. Set to `""` to use namespace from current kube context2""�
�
namespace_dep�A reference to a `k8s_namespace` rule from where to extract the namespace to be used to install the release.Namespace where this release is installed to. Must be a label to a k8s_namespace rule. It takes precedence over namespace2NoneO
M
release_name9The name of the helm release to be installed or upgraded. �
�
remote_chartvHelm registry url of the chart to be installed. If `chart` attribute is also providedd, `remote_chart` has preference.2""�
�
set�
A dictionary of key value pairs consisting on yaml paths and values to be replaced in the chart via --set helm option before installing it:
"yaml.path": "value"

2{}_
]
valuesMA list of value files to be provided to helm install command through -f flag.2[]=
;
values_yaml&[Deprecated] Use `values` attr instead2[]�
�
version}Chart version to be installed in a kubernetes cluster. This option will only be used if the `remote_chart` attribute is used.2""L
J
wait:Helm flag to wait for all resources to be created to exit.2True}
//k8s:k8s.bzlrj
$
masorange_rules_helmk8sk8s.bzl4
NamespaceDataInfoNamespaceDataInfo
->
@�
8
masorange_rules_helmhelm/privatehelm_toolchain.bzl�helm_toolchain"�
�
helm_toolchain*
nameA unique name for this target. 	
bin "I
helm_toolchain7@@masorange_rules_helm//helm/private:helm_toolchain.bzl
xx,
*
nameA unique name for this target. 
	
bin �HelmToolchainInfoHelm toolchain2�
�
HelmToolchainInfoHelm toolchain
binHelm executable binary"L
HelmToolchainInfo7@@masorange_rules_helm//helm/private:helm_toolchain.bzl
UU

binHelm executable binary�		helm_repo.Fetch external tools needed for helm toolchainR�	
�
	helm_repo.Fetch external tools needed for helm toolchain.
name"A unique name for this repository. 
platform �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 	
sha 
version *D
	helm_repo7@@masorange_rules_helm//helm/private:helm_toolchain.bzl
��0
.
name"A unique name for this repository. 

platform �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 
	
sha 

version �
helm_toolchain_configurelCreates a repository with toolchain definitions for all known platforms
which can be registered or selected.R�	
�
helm_toolchain_configurelCreates a repository with toolchain definitions for all known platforms
which can be registered or selected..
name"A unique name for this repository. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 *S
helm_toolchain_configure7@@masorange_rules_helm//helm/private:helm_toolchain.bzl
�+�+0
.
name"A unique name for this repository. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 ,	HELM_DEFAULT_VERSIONv3.16.3j	v3.16.3�
8
masorange_rules_helmhelm/privatehelm_uninstall.bzl�helm_uninstall�
Uninstall a helm release.

To load the rule use:
```starlark
load("//helm:defs.bzl", "helm_uninstall")
```

This rule builds an executable. Use `run` instead of `build` to be uninstall the helm release.
"�

�
helm_uninstall�
Uninstall a helm release.

To load the rule use:
```starlark
load("//helm:defs.bzl", "helm_uninstall")
```

This rule builds an executable. Use `run` instead of `build` to be uninstall the helm release.
*
nameA unique name for this target. E
kubernetes_context)The name of the kubeconfig context to use2""E
	namespace2The namespace where the helm release is installed.2""�
namespace_depnA reference to a `k8s_namespace` rule from where to extract the namespace where the helm release is installed.2NoneM
release_name9The name of the helm release to be installed or upgraded. J
wait:Helm flag to wait for all resources to be created to exit.2True"I
helm_uninstall7@@masorange_rules_helm//helm/private:helm_uninstall.bzl
BB,
*
nameA unique name for this target. G
E
kubernetes_context)The name of the kubeconfig context to use2""G
E
	namespace2The namespace where the helm release is installed.2""�
�
namespace_depnA reference to a `k8s_namespace` rule from where to extract the namespace where the helm release is installed.2NoneO
M
release_name9The name of the helm release to be installed or upgraded. L
J
wait:Helm flag to wait for all resources to be created to exit.2True}
//k8s:k8s.bzlrj
$
masorange_rules_helmk8sk8s.bzl4
NamespaceDataInfoNamespaceDataInfo
->
@�
9
masorange_rules_helmhelm/tests/helm_chart
charts.bzlt
get_charts*d
T

get_charts2F

get_charts8@@masorange_rules_helm//helm/tests/helm_chart:charts.bzl
��
&
masorange_rules_helmhelmdefs.bzl�t
chart_srcs�Customize helm chart values and configuration.

This rule should not be used directly, users should use `helm_chart` macro instead. See [helm_chart](#helm_chart).
Despite, if you want to see the configuration arguments you can use to package a helm chart using `helm_chart` rule, check the arguments doc below for `chart_srcs` rule,
as `helm_chart` is just a wrapper around `chart_srcs` rule and all the arguments are propagated to `chart_srcs` rule.


This rule takes chart src files and write them to bazel output dir applying some modifications.
The rule is designed to be used with a packager to produce an archived file (`pkg_tar` is used).

```starlark
chart_srcs(
    name = "basic_chart",
    chart_name = "example",
    srcs = glob(["**"]),
)
```

You can customize the values of the chart overriding them via `values` rule attribute:

```starlark
chart_srcs(
    name = "basic_chart",
    chart_name = "example",
    srcs = glob(["**"]),
    values = {
        "override.value": "valueoverrided",
    }
)
```

Chart src files are not mandatory, you can specify all the chart configuration via rule attributes.
In this case the rule will take care of generating the chart files for you (Chart.yaml, values.yaml, template files, chart deps...).

```starlark
chart_srcs(
    name = "chart",
    chart_name = "example",
    version = "v1.0.0",
    app_version = "v2.3.4",
    api_version = "v2",
    description = "Helm chart description placed inside Chart.yaml",
    image = ":oci_image",
    values = {
        "yaml.path.to.value": "value",
    },
)
```

Stamp variables are supported in values attribute. To enable the use of stamp variables enable them via stamp attribute and --stamp flag in bazel.
You can customize stamped variables using bazel workspace status. See [the Bazel workspace status docs](https://docs.bazel.build/versions/master/user-manual.html#workspace_status)

All values with ${} format will be replaced by stamped variables (both volatile and stable are supported).

```starlark
chart_srcs(
    name = "chart",
    chart_name = "example",
    srcs = glob(["**"]),
    stamp = -1,
    values = {
        "stamped.value": "${STAMPED_VARIABLE}",
    },
)
```

For compatibility reasons, some attributes are still supported but marked as deprecated. Its use is discouraged.
"�b
�:

chart_srcs�Customize helm chart values and configuration.

This rule should not be used directly, users should use `helm_chart` macro instead. See [helm_chart](#helm_chart).
Despite, if you want to see the configuration arguments you can use to package a helm chart using `helm_chart` rule, check the arguments doc below for `chart_srcs` rule,
as `helm_chart` is just a wrapper around `chart_srcs` rule and all the arguments are propagated to `chart_srcs` rule.


This rule takes chart src files and write them to bazel output dir applying some modifications.
The rule is designed to be used with a packager to produce an archived file (`pkg_tar` is used).

```starlark
chart_srcs(
    name = "basic_chart",
    chart_name = "example",
    srcs = glob(["**"]),
)
```

You can customize the values of the chart overriding them via `values` rule attribute:

```starlark
chart_srcs(
    name = "basic_chart",
    chart_name = "example",
    srcs = glob(["**"]),
    values = {
        "override.value": "valueoverrided",
    }
)
```

Chart src files are not mandatory, you can specify all the chart configuration via rule attributes.
In this case the rule will take care of generating the chart files for you (Chart.yaml, values.yaml, template files, chart deps...).

```starlark
chart_srcs(
    name = "chart",
    chart_name = "example",
    version = "v1.0.0",
    app_version = "v2.3.4",
    api_version = "v2",
    description = "Helm chart description placed inside Chart.yaml",
    image = ":oci_image",
    values = {
        "yaml.path.to.value": "value",
    },
)
```

Stamp variables are supported in values attribute. To enable the use of stamp variables enable them via stamp attribute and --stamp flag in bazel.
You can customize stamped variables using bazel workspace status. See [the Bazel workspace status docs](https://docs.bazel.build/versions/master/user-manual.html#workspace_status)

All values with ${} format will be replaced by stamped variables (both volatile and stable are supported).

```starlark
chart_srcs(
    name = "chart",
    chart_name = "example",
    srcs = glob(["**"]),
    stamp = -1,
    values = {
        "stamped.value": "${STAMPED_VARIABLE}",
    },
)
```

For compatibility reasons, some attributes are still supported but marked as deprecated. Its use is discouraged.
*
nameA unique name for this target. A
additional_templates#[Deprecated] Use templates instead.2[]m
api_versionXHelm chart manifest apiVersion. The value is replaced in the output Chart.yaml manifest.2""z
app_versioneHelm chart appVersion. The value is replaced in the output Chart.yaml manifest in the appVersion key.2""�
app_version_manifest�Helm chart appVersion file. The value is replaced in the output Chart.yaml manifest in the appVersion key. The file can be a yaml file or a json file containing a single key named version.2None]

chart_deps<[Deprecated] Chart dependencies. Use deps attribute instead.*
	ChartInfo2[]\

chart_nameJName of the chart. It will be modified in the name field of the Chart.yaml �
deps�
A list of helm chart that this helm chart depends on. They will be placed inside the `charts` directory.
The dependencies will be traced inside the Chart.yaml manifest as well.
*
	ChartInfo2[]�
deps_conditions�
A dictionary containing the conditions that the dependencies of the chart should met to be rendered by helm.
The key has to be the name of the dependency chart. The value will be the condition that the values of the chart should have.
Check helm doc for more info https://helm.sh/docs/topics/charts/#the-chartyaml-file

2{}n
descriptionYHelm chart manifest description. The value is replaced in the output Chart.yaml manifest.2""�
force_repository_append�
A flag to specify if @ should be appended to the repository value in the chart values.yaml (in case `image` rule attribute is specified).
The rules will look for the specified repository value inside the values.yaml.
This is intended to meet image url with digest format: `gcr.io/container@sha256:a12e258c58ab92be22e403d08c8ef7eefd6119235eddca01309fe6b21101e100`.
If you have this already covered in your deployment templates, set this attr to false.
If the flag is set to true, the image rule attr is provided and no `values_repo_yaml_path` is set, the rule will look for the default path of the
repository value. .image.repository
2TrueQ
helm_chart_version5[Deprecated] Helm chart version. Use version instead.2""�
image�
Reference to image rule use to interpolate the image sha256 in the chart values.yaml.
If provided, the sha256 of the image will be placed in the output values.yaml of the chart in the yaml path provided by `values_tag_yaml_path` attribute.
Only oci_image rules are supported.2Nonei
image_digestQReference to oci_image digest file. Used internally by the macro (do not use it).2None`
image_repositoryF[Deprecated] You can use values attr dict to modify repository values.2""<
	image_tag)[Deprecated] Use image attribute instead.2""K
package_name5[Deprecated] Helm chart name. Use chart_name instead.2""�
path_to_chart�Attribute to specify the path to the root of the chart. This attribute is mandatory if neither Chart.yaml nor values.yaml are provided, and the chart srcs attr is not empty to determinate where in the path of the source files is located the root of the helm chart.2""0
srcs"A list of helm chart source files.2[]�
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.
2-1�
	templates�
A list of files that will be added to the chart. They will be added as addition to the chart templates refernced in the `srcs` attribute.
2[]�
values�
A dictionary of key values to be written in to the chart values.
keys: `yaml.path` or `.yaml.path`
values:  the value to be replaced inside the Chart values.yaml.
This attr supports use of stamped values. To provide a stamped value you have to use ${STAMP_VARIABLE_NAME} as value of the dict with
your stamped variable key. Make sure to enable stamping in your rule with the attribute `stamp`.

2{}�
values_repo_yaml_path{[Deprecated] Yaml path used to set the repo config provided by `image_repository` attribute (deprecated). .image.repository2""l
values_tag_yaml_pathDYaml path used to set the image sha256 inside the chart values.yaml.2".image.tag"G
version6Helm chart version to be placed in Chart.yaml manifest2""�
version_manifest�Helm chart version file to be used to set the chart version in Chart.yaml manifest. The file can be a yaml file or a josn file containing a single key named version.2None"3

chart_srcs%@@masorange_rules_helm//helm:defs.bzl
��,
*
nameA unique name for this target. C
A
additional_templates#[Deprecated] Use templates instead.2[]o
m
api_versionXHelm chart manifest apiVersion. The value is replaced in the output Chart.yaml manifest.2""|
z
app_versioneHelm chart appVersion. The value is replaced in the output Chart.yaml manifest in the appVersion key.2""�
�
app_version_manifest�Helm chart appVersion file. The value is replaced in the output Chart.yaml manifest in the appVersion key. The file can be a yaml file or a json file containing a single key named version.2None_
]

chart_deps<[Deprecated] Chart dependencies. Use deps attribute instead.*
	ChartInfo2[]^
\

chart_nameJName of the chart. It will be modified in the name field of the Chart.yaml �
�
deps�
A list of helm chart that this helm chart depends on. They will be placed inside the `charts` directory.
The dependencies will be traced inside the Chart.yaml manifest as well.
*
	ChartInfo2[]�
�
deps_conditions�
A dictionary containing the conditions that the dependencies of the chart should met to be rendered by helm.
The key has to be the name of the dependency chart. The value will be the condition that the values of the chart should have.
Check helm doc for more info https://helm.sh/docs/topics/charts/#the-chartyaml-file

2{}p
n
descriptionYHelm chart manifest description. The value is replaced in the output Chart.yaml manifest.2""�
�
force_repository_append�
A flag to specify if @ should be appended to the repository value in the chart values.yaml (in case `image` rule attribute is specified).
The rules will look for the specified repository value inside the values.yaml.
This is intended to meet image url with digest format: `gcr.io/container@sha256:a12e258c58ab92be22e403d08c8ef7eefd6119235eddca01309fe6b21101e100`.
If you have this already covered in your deployment templates, set this attr to false.
If the flag is set to true, the image rule attr is provided and no `values_repo_yaml_path` is set, the rule will look for the default path of the
repository value. .image.repository
2TrueS
Q
helm_chart_version5[Deprecated] Helm chart version. Use version instead.2""�
�
image�
Reference to image rule use to interpolate the image sha256 in the chart values.yaml.
If provided, the sha256 of the image will be placed in the output values.yaml of the chart in the yaml path provided by `values_tag_yaml_path` attribute.
Only oci_image rules are supported.2Nonek
i
image_digestQReference to oci_image digest file. Used internally by the macro (do not use it).2Noneb
`
image_repositoryF[Deprecated] You can use values attr dict to modify repository values.2"">
<
	image_tag)[Deprecated] Use image attribute instead.2""M
K
package_name5[Deprecated] Helm chart name. Use chart_name instead.2""�
�
path_to_chart�Attribute to specify the path to the root of the chart. This attribute is mandatory if neither Chart.yaml nor values.yaml are provided, and the chart srcs attr is not empty to determinate where in the path of the source files is located the root of the helm chart.2""2
0
srcs"A list of helm chart source files.2[]�
�
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.
2-1�
�
	templates�
A list of files that will be added to the chart. They will be added as addition to the chart templates refernced in the `srcs` attribute.
2[]�
�
values�
A dictionary of key values to be written in to the chart values.
keys: `yaml.path` or `.yaml.path`
values:  the value to be replaced inside the Chart values.yaml.
This attr supports use of stamped values. To provide a stamped value you have to use ${STAMP_VARIABLE_NAME} as value of the dict with
your stamped variable key. Make sure to enable stamping in your rule with the attribute `stamp`.

2{}�
�
values_repo_yaml_path{[Deprecated] Yaml path used to set the repo config provided by `image_repository` attribute (deprecated). .image.repository2""n
l
values_tag_yaml_pathDYaml path used to set the image sha256 inside the chart values.yaml.2".image.tag"I
G
version6Helm chart version to be placed in Chart.yaml manifest2""�
�
version_manifest�Helm chart version file to be used to set the chart version in Chart.yaml manifest. The file can be a yaml file or a josn file containing a single key named version.2None�helm_chart_providers"�
�
helm_chart_providers*
nameA unique name for this target. 
chart_bin_srcs 

chart_name 
chart_targz 
chart_version2"""=
helm_chart_providers%@@masorange_rules_helm//helm:defs.bzl
..,
*
nameA unique name for this target. 

chart_bin_srcs 


chart_name 

chart_targz 

chart_version2""�	helm_push�
Publish a helm chart produced by `helm_chart` rule to a remote registry.

To load the rule use:
```starlark
load("//helm:defs.bzl", "helm_push")
```

This rule builds an executable. Use `run` instead of `build` to publish the chart.
"�
�
	helm_push�
Publish a helm chart produced by `helm_chart` rule to a remote registry.

To load the rule use:
```starlark
load("//helm:defs.bzl", "helm_push")
```

This rule builds an executable. Use `run` instead of `build` to publish the chart.
*
nameA unique name for this target. �
chart�
The packaged chart archive to be published. It can be a reference to a `helm_chart` rule or a reference to a helm archived file *
	ChartInfo�
repository_configl
The repository config file. Used in conjunction with repository_name. It only works with oci repos by now.
2None�
repository_name�The name of the repository from the repository config file provided to this rule.
You must provide a repository_config in order to use this as the name of the repository. It only works with oci repos by now.
2""�
repository_url�
The remote url of the registry. Do not add the chart name to the url. If you provide `repository_config` and a `repository_name` attributes
this field will be omitted.
2"""2
	helm_push%@@masorange_rules_helm//helm:defs.bzl
��,
*
nameA unique name for this target. �
�
chart�
The packaged chart archive to be published. It can be a reference to a `helm_chart` rule or a reference to a helm archived file *
	ChartInfo�
�
repository_configl
The repository config file. Used in conjunction with repository_name. It only works with oci repos by now.
2None�
�
repository_name�The name of the repository from the repository config file provided to this rule.
You must provide a repository_config in order to use this as the name of the repository. It only works with oci repos by now.
2""�
�
repository_url�
The remote url of the registry. Do not add the chart name to the url. If you provide `repository_config` and a `repository_name` attributes
this field will be omitted.
2""�4helm_release�
  Installs or upgrades a helm release of a chart in to a cluster using helm binary.

  To load the rule use:
  ```starlark
  load("//helm:defs.bzl", "helm_release")
  ```

  This rule builds an executable. Use `run` instead of `build` to execute it.

  ```starklark
helm_release(
    name = "install",
    remote_chart = "oci://docker.pkg.dev/helm-charts/test_helm_chart",
    version = "0.7.5",
    namespace = "myapp",
    release_name = "helm-release-name",
    values = ["additional_values.yaml"],
)

helm_release(
    name = "install",
    chart = ":chart",
    namespace = "myapp",
    release_name = "helm-release-name",
    values = glob(["charts/myapp/values.yaml"]),
)
```

Example of use providing a kubernetes context config:
```starklark
helm_release(
    name = "chart_install",
    chart = ":chart",
    release_name = "release-name",
    values = glob(["charts/myapp/values.yaml"]),
    kubernetes_context = "mm-k8s-context",
)
```

Example of use decryptying sops secrets:
```starklark

sops_decrypt(
  name = "secret",
  srcs = ["secrets.yaml"],
)

helm_release(
    name = "chart_install",
    chart = ":chart",
    release_name = "release-name",
    values = glob(["charts/myapp/values.yaml"]) + [":secret"],
)
```

Example of use with k8s_namespace annotated with a GCP SA:
```starklark
k8s_namespace(
  name = "test-namespace",
  namespace_name = "test-namespace",
  kubernetes_sa = "test-kubernetes-sa",
  kubernetes_context = "mm-k8s-context",
)

helm_release(
    name = "chart_install",
    chart = ":chart",
    namespace_dep = ":test-namespace",
    release_name = "release-name",
    values = glob(["charts/myapp/values.yaml"]),
)
```

"�'
�
helm_release�
  Installs or upgrades a helm release of a chart in to a cluster using helm binary.

  To load the rule use:
  ```starlark
  load("//helm:defs.bzl", "helm_release")
  ```

  This rule builds an executable. Use `run` instead of `build` to execute it.

  ```starklark
helm_release(
    name = "install",
    remote_chart = "oci://docker.pkg.dev/helm-charts/test_helm_chart",
    version = "0.7.5",
    namespace = "myapp",
    release_name = "helm-release-name",
    values = ["additional_values.yaml"],
)

helm_release(
    name = "install",
    chart = ":chart",
    namespace = "myapp",
    release_name = "helm-release-name",
    values = glob(["charts/myapp/values.yaml"]),
)
```

Example of use providing a kubernetes context config:
```starklark
helm_release(
    name = "chart_install",
    chart = ":chart",
    release_name = "release-name",
    values = glob(["charts/myapp/values.yaml"]),
    kubernetes_context = "mm-k8s-context",
)
```

Example of use decryptying sops secrets:
```starklark

sops_decrypt(
  name = "secret",
  srcs = ["secrets.yaml"],
)

helm_release(
    name = "chart_install",
    chart = ":chart",
    release_name = "release-name",
    values = glob(["charts/myapp/values.yaml"]) + [":secret"],
)
```

Example of use with k8s_namespace annotated with a GCP SA:
```starklark
k8s_namespace(
  name = "test-namespace",
  namespace_name = "test-namespace",
  kubernetes_sa = "test-kubernetes-sa",
  kubernetes_context = "mm-k8s-context",
)

helm_release(
    name = "chart_install",
    chart = ":chart",
    namespace_dep = ":test-namespace",
    release_name = "release-name",
    values = glob(["charts/myapp/values.yaml"]),
)
```

*
nameA unique name for this target. �
chart�
The packaged chart archive to be published. It can be a reference to a `helm_chart` rule or a reference to a helm archived file. To specify a helm chart from a remote repository use `remote_chart` instead.2None�
create_namespacenA flag to indicate helm binary to create the kubernetes namespace if it is not already present in the cluster.2TrueE
kubernetes_context)The name of the kubeconfig context to use2""�
	namespaceoThe namespace literal where to install the helm release. Set to `""` to use namespace from current kube context2""�
namespace_dep�A reference to a `k8s_namespace` rule from where to extract the namespace to be used to install the release.Namespace where this release is installed to. Must be a label to a k8s_namespace rule. It takes precedence over namespace2NoneM
release_name9The name of the helm release to be installed or upgraded. �
remote_chartvHelm registry url of the chart to be installed. If `chart` attribute is also providedd, `remote_chart` has preference.2""�
set�
A dictionary of key value pairs consisting on yaml paths and values to be replaced in the chart via --set helm option before installing it:
"yaml.path": "value"

2{}]
valuesMA list of value files to be provided to helm install command through -f flag.2[];
values_yaml&[Deprecated] Use `values` attr instead2[]�
version}Chart version to be installed in a kubernetes cluster. This option will only be used if the `remote_chart` attribute is used.2""J
wait:Helm flag to wait for all resources to be created to exit.2True"5
helm_release%@@masorange_rules_helm//helm:defs.bzl
��,
*
nameA unique name for this target. �
�
chart�
The packaged chart archive to be published. It can be a reference to a `helm_chart` rule or a reference to a helm archived file. To specify a helm chart from a remote repository use `remote_chart` instead.2None�
�
create_namespacenA flag to indicate helm binary to create the kubernetes namespace if it is not already present in the cluster.2TrueG
E
kubernetes_context)The name of the kubeconfig context to use2""�
�
	namespaceoThe namespace literal where to install the helm release. Set to `""` to use namespace from current kube context2""�
�
namespace_dep�A reference to a `k8s_namespace` rule from where to extract the namespace to be used to install the release.Namespace where this release is installed to. Must be a label to a k8s_namespace rule. It takes precedence over namespace2NoneO
M
release_name9The name of the helm release to be installed or upgraded. �
�
remote_chartvHelm registry url of the chart to be installed. If `chart` attribute is also providedd, `remote_chart` has preference.2""�
�
set�
A dictionary of key value pairs consisting on yaml paths and values to be replaced in the chart via --set helm option before installing it:
"yaml.path": "value"

2{}_
]
valuesMA list of value files to be provided to helm install command through -f flag.2[]=
;
values_yaml&[Deprecated] Use `values` attr instead2[]�
�
version}Chart version to be installed in a kubernetes cluster. This option will only be used if the `remote_chart` attribute is used.2""L
J
wait:Helm flag to wait for all resources to be created to exit.2True�helm_uninstall�
Uninstall a helm release.

To load the rule use:
```starlark
load("//helm:defs.bzl", "helm_uninstall")
```

This rule builds an executable. Use `run` instead of `build` to be uninstall the helm release.
"�	
�
helm_uninstall�
Uninstall a helm release.

To load the rule use:
```starlark
load("//helm:defs.bzl", "helm_uninstall")
```

This rule builds an executable. Use `run` instead of `build` to be uninstall the helm release.
*
nameA unique name for this target. E
kubernetes_context)The name of the kubeconfig context to use2""E
	namespace2The namespace where the helm release is installed.2""�
namespace_depnA reference to a `k8s_namespace` rule from where to extract the namespace where the helm release is installed.2NoneM
release_name9The name of the helm release to be installed or upgraded. J
wait:Helm flag to wait for all resources to be created to exit.2True"7
helm_uninstall%@@masorange_rules_helm//helm:defs.bzl
BB,
*
nameA unique name for this target. G
E
kubernetes_context)The name of the kubeconfig context to use2""G
E
	namespace2The namespace where the helm release is installed.2""�
�
namespace_depnA reference to a `k8s_namespace` rule from where to extract the namespace where the helm release is installed.2NoneO
M
release_name9The name of the helm release to be installed or upgraded. L
J
wait:Helm flag to wait for all resources to be created to exit.2TrueƔ
helm_chart�!Bazel macro function to package a helm chart in to a targz archive file.

The macro is intended to be used as the public API for packaging a chart. It is a wrapper around `chart_srcs` rule. All the args are propagated to `chart_srcs` rule.
See [chart_srcs](#chart_srcs) arguments to see the available config.


To load the rule use:
```starlark
load("//helm:defs.bzl", "helm_chart")
```

It also defines a %name%_lint test target to be able to test that your chart is well-formed (using `helm lint`).

To make the output reproducible this macro does not use `helm package` to package the chart into a versioned chart archive file.
It uses `pkg_tar` bazel rule instead to create the archive file. Check this to find more info about it:
- https://github.com/masmovil/bazel-rules/issues/55
- https://github.com/helm/helm/issues/3612#issuecomment-525340295

This macro exports some providers to share info about charts between rules. Check [helm_chart providers](#providers).

The args are the same that the `chart_srcs` rule, check [chart_srcs](#chart_srcs).

```starlark
load("//helm:defs.bzl", "helm_chart")

helm_chart(
    name = "basic_chart",
    chart_name = "example",
    srcs = glob(["**"]),
)

helm_chart(
    name = "basic_chart",
    chart_name = "example",
    srcs = glob(["**"]),
    values = {
        "override.value": "valueoverrided",
    }
)

helm_chart(
    name = "chart",
    chart_name = "example",
    version = "v1.0.0",
    app_version = "v2.3.4",
    api_version = "v2",
    description = "Helm chart description placed inside Chart.yaml",
    image = ":oci_image",
    values = {
        "yaml.path.to.value": "value",
    },
)

# version file version.json
{
    "version": "v1.0.0",
}

# BULD.bazel
helm_chart(
    name = "chart",
    chart_name = "example",
    version_file = ":version.json",
    app_version = "v2.3.4",
    api_version = "v2",
    description = "Helm chart description placed inside Chart.yaml",
    image = ":oci_image",
    values = {
        "yaml.path.to.value": "value",
    },
)
```


Customize helm chart values and configuration.

This rule should not be used directly, users should use `helm_chart` macro instead. See [helm_chart](#helm_chart).
Despite, if you want to see the configuration arguments you can use to package a helm chart using `helm_chart` rule, check the arguments doc below for `chart_srcs` rule,
as `helm_chart` is just a wrapper around `chart_srcs` rule and all the arguments are propagated to `chart_srcs` rule.


This rule takes chart src files and write them to bazel output dir applying some modifications.
The rule is designed to be used with a packager to produce an archived file (`pkg_tar` is used).

```starlark
chart_srcs(
    name = "basic_chart",
    chart_name = "example",
    srcs = glob(["**"]),
)
```

You can customize the values of the chart overriding them via `values` rule attribute:

```starlark
chart_srcs(
    name = "basic_chart",
    chart_name = "example",
    srcs = glob(["**"]),
    values = {
        "override.value": "valueoverrided",
    }
)
```

Chart src files are not mandatory, you can specify all the chart configuration via rule attributes.
In this case the rule will take care of generating the chart files for you (Chart.yaml, values.yaml, template files, chart deps...).

```starlark
chart_srcs(
    name = "chart",
    chart_name = "example",
    version = "v1.0.0",
    app_version = "v2.3.4",
    api_version = "v2",
    description = "Helm chart description placed inside Chart.yaml",
    image = ":oci_image",
    values = {
        "yaml.path.to.value": "value",
    },
)
```

Stamp variables are supported in values attribute. To enable the use of stamp variables enable them via stamp attribute and --stamp flag in bazel.
You can customize stamped variables using bazel workspace status. See [the Bazel workspace status docs](https://docs.bazel.build/versions/master/user-manual.html#workspace_status)

All values with ${} format will be replaced by stamped variables (both volatile and stable are supported).

```starlark
chart_srcs(
    name = "chart",
    chart_name = "example",
    srcs = glob(["**"]),
    stamp = -1,
    values = {
        "stamped.value": "${STAMPED_VARIABLE}",
    },
)
```

For compatibility reasons, some attributes are still supported but marked as deprecated. Its use is discouraged.
"�r
�J

helm_chart�!Bazel macro function to package a helm chart in to a targz archive file.

The macro is intended to be used as the public API for packaging a chart. It is a wrapper around `chart_srcs` rule. All the args are propagated to `chart_srcs` rule.
See [chart_srcs](#chart_srcs) arguments to see the available config.


To load the rule use:
```starlark
load("//helm:defs.bzl", "helm_chart")
```

It also defines a %name%_lint test target to be able to test that your chart is well-formed (using `helm lint`).

To make the output reproducible this macro does not use `helm package` to package the chart into a versioned chart archive file.
It uses `pkg_tar` bazel rule instead to create the archive file. Check this to find more info about it:
- https://github.com/masmovil/bazel-rules/issues/55
- https://github.com/helm/helm/issues/3612#issuecomment-525340295

This macro exports some providers to share info about charts between rules. Check [helm_chart providers](#providers).

The args are the same that the `chart_srcs` rule, check [chart_srcs](#chart_srcs).

```starlark
load("//helm:defs.bzl", "helm_chart")

helm_chart(
    name = "basic_chart",
    chart_name = "example",
    srcs = glob(["**"]),
)

helm_chart(
    name = "basic_chart",
    chart_name = "example",
    srcs = glob(["**"]),
    values = {
        "override.value": "valueoverrided",
    }
)

helm_chart(
    name = "chart",
    chart_name = "example",
    version = "v1.0.0",
    app_version = "v2.3.4",
    api_version = "v2",
    description = "Helm chart description placed inside Chart.yaml",
    image = ":oci_image",
    values = {
        "yaml.path.to.value": "value",
    },
)

# version file version.json
{
    "version": "v1.0.0",
}

# BULD.bazel
helm_chart(
    name = "chart",
    chart_name = "example",
    version_file = ":version.json",
    app_version = "v2.3.4",
    api_version = "v2",
    description = "Helm chart description placed inside Chart.yaml",
    image = ":oci_image",
    values = {
        "yaml.path.to.value": "value",
    },
)
```


Customize helm chart values and configuration.

This rule should not be used directly, users should use `helm_chart` macro instead. See [helm_chart](#helm_chart).
Despite, if you want to see the configuration arguments you can use to package a helm chart using `helm_chart` rule, check the arguments doc below for `chart_srcs` rule,
as `helm_chart` is just a wrapper around `chart_srcs` rule and all the arguments are propagated to `chart_srcs` rule.


This rule takes chart src files and write them to bazel output dir applying some modifications.
The rule is designed to be used with a packager to produce an archived file (`pkg_tar` is used).

```starlark
chart_srcs(
    name = "basic_chart",
    chart_name = "example",
    srcs = glob(["**"]),
)
```

You can customize the values of the chart overriding them via `values` rule attribute:

```starlark
chart_srcs(
    name = "basic_chart",
    chart_name = "example",
    srcs = glob(["**"]),
    values = {
        "override.value": "valueoverrided",
    }
)
```

Chart src files are not mandatory, you can specify all the chart configuration via rule attributes.
In this case the rule will take care of generating the chart files for you (Chart.yaml, values.yaml, template files, chart deps...).

```starlark
chart_srcs(
    name = "chart",
    chart_name = "example",
    version = "v1.0.0",
    app_version = "v2.3.4",
    api_version = "v2",
    description = "Helm chart description placed inside Chart.yaml",
    image = ":oci_image",
    values = {
        "yaml.path.to.value": "value",
    },
)
```

Stamp variables are supported in values attribute. To enable the use of stamp variables enable them via stamp attribute and --stamp flag in bazel.
You can customize stamped variables using bazel workspace status. See [the Bazel workspace status docs](https://docs.bazel.build/versions/master/user-manual.html#workspace_status)

All values with ${} format will be replaced by stamped variables (both volatile and stable are supported).

```starlark
chart_srcs(
    name = "chart",
    chart_name = "example",
    srcs = glob(["**"]),
    stamp = -1,
    values = {
        "stamped.value": "${STAMPED_VARIABLE}",
    },
)
```

For compatibility reasons, some attributes are still supported but marked as deprecated. Its use is discouraged.
*
nameA unique name for this target. A
additional_templates#[Deprecated] Use templates instead.2[]m
api_versionXHelm chart manifest apiVersion. The value is replaced in the output Chart.yaml manifest.2""z
app_versioneHelm chart appVersion. The value is replaced in the output Chart.yaml manifest in the appVersion key.2""�
app_version_manifest�Helm chart appVersion file. The value is replaced in the output Chart.yaml manifest in the appVersion key. The file can be a yaml file or a json file containing a single key named version.2None]

chart_deps<[Deprecated] Chart dependencies. Use deps attribute instead.*
	ChartInfo2[]\

chart_nameJName of the chart. It will be modified in the name field of the Chart.yaml �
deps�
A list of helm chart that this helm chart depends on. They will be placed inside the `charts` directory.
The dependencies will be traced inside the Chart.yaml manifest as well.
*
	ChartInfo2[]�
deps_conditions�
A dictionary containing the conditions that the dependencies of the chart should met to be rendered by helm.
The key has to be the name of the dependency chart. The value will be the condition that the values of the chart should have.
Check helm doc for more info https://helm.sh/docs/topics/charts/#the-chartyaml-file

2{}n
descriptionYHelm chart manifest description. The value is replaced in the output Chart.yaml manifest.2""�
force_repository_append�
A flag to specify if @ should be appended to the repository value in the chart values.yaml (in case `image` rule attribute is specified).
The rules will look for the specified repository value inside the values.yaml.
This is intended to meet image url with digest format: `gcr.io/container@sha256:a12e258c58ab92be22e403d08c8ef7eefd6119235eddca01309fe6b21101e100`.
If you have this already covered in your deployment templates, set this attr to false.
If the flag is set to true, the image rule attr is provided and no `values_repo_yaml_path` is set, the rule will look for the default path of the
repository value. .image.repository
2TrueQ
helm_chart_version5[Deprecated] Helm chart version. Use version instead.2""�
image�
Reference to image rule use to interpolate the image sha256 in the chart values.yaml.
If provided, the sha256 of the image will be placed in the output values.yaml of the chart in the yaml path provided by `values_tag_yaml_path` attribute.
Only oci_image rules are supported.2Nonei
image_digestQReference to oci_image digest file. Used internally by the macro (do not use it).2None`
image_repositoryF[Deprecated] You can use values attr dict to modify repository values.2""<
	image_tag)[Deprecated] Use image attribute instead.2""K
package_name5[Deprecated] Helm chart name. Use chart_name instead.2""�
path_to_chart�Attribute to specify the path to the root of the chart. This attribute is mandatory if neither Chart.yaml nor values.yaml are provided, and the chart srcs attr is not empty to determinate where in the path of the source files is located the root of the helm chart.2""0
srcs"A list of helm chart source files.2[]�
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.
2-1�
	templates�
A list of files that will be added to the chart. They will be added as addition to the chart templates refernced in the `srcs` attribute.
2[]�
values�
A dictionary of key values to be written in to the chart values.
keys: `yaml.path` or `.yaml.path`
values:  the value to be replaced inside the Chart values.yaml.
This attr supports use of stamped values. To provide a stamped value you have to use ${STAMP_VARIABLE_NAME} as value of the dict with
your stamped variable key. Make sure to enable stamping in your rule with the attribute `stamp`.

2{}�
values_repo_yaml_path{[Deprecated] Yaml path used to set the repo config provided by `image_repository` attribute (deprecated). .image.repository2""l
values_tag_yaml_pathDYaml path used to set the image sha256 inside the chart values.yaml.2".image.tag"G
version6Helm chart version to be placed in Chart.yaml manifest2""�
version_manifest�Helm chart version file to be used to set the chart version in Chart.yaml manifest. The file can be a yaml file or a josn file containing a single key named version.2None"3

chart_srcs%@@masorange_rules_helm//helm:defs.bzl
,
*
nameA unique name for this target. C
A
additional_templates#[Deprecated] Use templates instead.2[]o
m
api_versionXHelm chart manifest apiVersion. The value is replaced in the output Chart.yaml manifest.2""|
z
app_versioneHelm chart appVersion. The value is replaced in the output Chart.yaml manifest in the appVersion key.2""�
�
app_version_manifest�Helm chart appVersion file. The value is replaced in the output Chart.yaml manifest in the appVersion key. The file can be a yaml file or a json file containing a single key named version.2None_
]

chart_deps<[Deprecated] Chart dependencies. Use deps attribute instead.*
	ChartInfo2[]^
\

chart_nameJName of the chart. It will be modified in the name field of the Chart.yaml �
�
deps�
A list of helm chart that this helm chart depends on. They will be placed inside the `charts` directory.
The dependencies will be traced inside the Chart.yaml manifest as well.
*
	ChartInfo2[]�
�
deps_conditions�
A dictionary containing the conditions that the dependencies of the chart should met to be rendered by helm.
The key has to be the name of the dependency chart. The value will be the condition that the values of the chart should have.
Check helm doc for more info https://helm.sh/docs/topics/charts/#the-chartyaml-file

2{}p
n
descriptionYHelm chart manifest description. The value is replaced in the output Chart.yaml manifest.2""�
�
force_repository_append�
A flag to specify if @ should be appended to the repository value in the chart values.yaml (in case `image` rule attribute is specified).
The rules will look for the specified repository value inside the values.yaml.
This is intended to meet image url with digest format: `gcr.io/container@sha256:a12e258c58ab92be22e403d08c8ef7eefd6119235eddca01309fe6b21101e100`.
If you have this already covered in your deployment templates, set this attr to false.
If the flag is set to true, the image rule attr is provided and no `values_repo_yaml_path` is set, the rule will look for the default path of the
repository value. .image.repository
2TrueS
Q
helm_chart_version5[Deprecated] Helm chart version. Use version instead.2""�
�
image�
Reference to image rule use to interpolate the image sha256 in the chart values.yaml.
If provided, the sha256 of the image will be placed in the output values.yaml of the chart in the yaml path provided by `values_tag_yaml_path` attribute.
Only oci_image rules are supported.2Nonek
i
image_digestQReference to oci_image digest file. Used internally by the macro (do not use it).2Noneb
`
image_repositoryF[Deprecated] You can use values attr dict to modify repository values.2"">
<
	image_tag)[Deprecated] Use image attribute instead.2""M
K
package_name5[Deprecated] Helm chart name. Use chart_name instead.2""�
�
path_to_chart�Attribute to specify the path to the root of the chart. This attribute is mandatory if neither Chart.yaml nor values.yaml are provided, and the chart srcs attr is not empty to determinate where in the path of the source files is located the root of the helm chart.2""2
0
srcs"A list of helm chart source files.2[]�
�
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.
2-1�
�
	templates�
A list of files that will be added to the chart. They will be added as addition to the chart templates refernced in the `srcs` attribute.
2[]�
�
values�
A dictionary of key values to be written in to the chart values.
keys: `yaml.path` or `.yaml.path`
values:  the value to be replaced inside the Chart values.yaml.
This attr supports use of stamped values. To provide a stamped value you have to use ${STAMP_VARIABLE_NAME} as value of the dict with
your stamped variable key. Make sure to enable stamping in your rule with the attribute `stamp`.

2{}�
�
values_repo_yaml_path{[Deprecated] Yaml path used to set the repo config provided by `image_repository` attribute (deprecated). .image.repository2""n
l
values_tag_yaml_pathDYaml path used to set the image sha256 inside the chart values.yaml.2".image.tag"I
G
version6Helm chart version to be placed in Chart.yaml manifest2""�
�
version_manifest�Helm chart version file to be used to set the chart version in Chart.yaml manifest. The file can be a yaml file or a josn file containing a single key named version.2None�		ChartInfo�
`helm_chart` expose ChartInfo providers to be able to access info about a packaged chart. The info available is:
- The name of the chart
- The version of the chart
- The ouput sources of the chart
- The output archive file targz
2�
�
	ChartInfo�
`helm_chart` expose ChartInfo providers to be able to access info about a packaged chart. The info available is:
- The name of the chart
- The version of the chart
- The ouput sources of the chart
- The output archive file targz
T
targzKThe output of helm_chart. This is the versioned packaged targz of the chartq

chart_namecThe name of the chart as is reflected in the Chart.yaml manifest and provided by the rule attribute6
chart_version%If provided, the version of the chartT

chart_srcsFThe sources of the chart before beign packaged into the archived targz"2
	ChartInfo%@@masorange_rules_helm//helm:defs.bzl
V
T
targzKThe output of helm_chart. This is the versioned packaged targz of the charts
q

chart_namecThe name of the chart as is reflected in the Chart.yaml manifest and provided by the rule attribute8
6
chart_version%If provided, the version of the chartV
T

chart_srcsFThe sources of the chart before beign packaged into the archived targz�*	helm_pull�
    Repository rule to download a `helm_chart` from a remote registry.

    To load the rule use:
    ```starlark
    load("//helm:defs.bzl", "helm_pull")
    ```

    It uses `helm` binary to download the chart, so `helm` has to be available in the PATH of the host machine where bazel is running.

    Default credentials on the host machine are used to authenticate against the remote registry.
    To use basic auth you must provide the basic credentials through env variables: `HELM_USER` and `HELM_PASSWORD`.

    OCI registries are supported.

    The downloaded chart is defined using the `helm_chart` rule and it's available as `:chart` target inside the repo name.

    ```starlark
    # With bzlmod, you typically will:
    # MODULE.bazel
    bazel_dep(name = "masorange_rules_helm", version = "1.3.1")

    helm = use_extension("@masmovil_bazel_rules//:extensions.bzl", "utils")

    helm.pull(
        name = "some_chart",
        chart_name = "chart_name",
        # do not add the chart name to the end of the url
        repo_url = "oci://docker.pkg.dev/helm-charts",
        version = "v1-stable",
    )
    use_repo(helm, "some_chart")
```

In non bzlmod workspaces:
```starlark
    # WORKSPACE
    load("//helm:defs.bzl", "helm_pull")

    helm_pull(
        name = "example_helm_chart",
        chart_name = "example",
        repo_url = "oci://docker.pkg.dev/project/helm-charts",
        version = "1.0.0",
    )
    ```

    It can be later referenced in a BUILD file in `helm_chart` dep:

```starlark
    helm_chart(
        ...
        deps = [
            "@example_helm_chart//:chart",
        ]
    )
    ```
R�
�
	helm_pull�
    Repository rule to download a `helm_chart` from a remote registry.

    To load the rule use:
    ```starlark
    load("//helm:defs.bzl", "helm_pull")
    ```

    It uses `helm` binary to download the chart, so `helm` has to be available in the PATH of the host machine where bazel is running.

    Default credentials on the host machine are used to authenticate against the remote registry.
    To use basic auth you must provide the basic credentials through env variables: `HELM_USER` and `HELM_PASSWORD`.

    OCI registries are supported.

    The downloaded chart is defined using the `helm_chart` rule and it's available as `:chart` target inside the repo name.

    ```starlark
    # With bzlmod, you typically will:
    # MODULE.bazel
    bazel_dep(name = "masorange_rules_helm", version = "1.3.1")

    helm = use_extension("@masmovil_bazel_rules//:extensions.bzl", "utils")

    helm.pull(
        name = "some_chart",
        chart_name = "chart_name",
        # do not add the chart name to the end of the url
        repo_url = "oci://docker.pkg.dev/helm-charts",
        version = "v1-stable",
    )
    use_repo(helm, "some_chart")
```

In non bzlmod workspaces:
```starlark
    # WORKSPACE
    load("//helm:defs.bzl", "helm_pull")

    helm_pull(
        name = "example_helm_chart",
        chart_name = "example",
        repo_url = "oci://docker.pkg.dev/project/helm-charts",
        version = "1.0.0",
    )
    ```

    It can be later referenced in a BUILD file in `helm_chart` dep:

```starlark
    helm_chart(
        ...
        deps = [
            "@example_helm_chart//:chart",
        ]
    )
    ```
.
name"A unique name for this repository. p

chart_name^The name of the helm_chart to download. It will be appendend at the end of the repository url. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
	repo_name�The name of the repository. This is only useful if you provide a `repository_config` file and you want the repo url to be located within the repo config.2""a
repo_urlQThe url where the chart is located. You have to omit the chart name from the url. 8
repository_configThe repository config file.2Nonej
versionYThe version of the chart to download. If no specified, the latest version will be pulled.2""*2
	helm_pull%@@masorange_rules_helm//helm:defs.bzl
��0
.
name"A unique name for this repository. r
p

chart_name^The name of the helm_chart to download. It will be appendend at the end of the repository url. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
�
	repo_name�The name of the repository. This is only useful if you provide a `repository_config` file and you want the repo url to be located within the repo config.2""c
a
repo_urlQThe url where the chart is located. You have to omit the chart name from the url. :
8
repository_configThe repository config file.2Nonel
j
versionYThe version of the chart to download. If no specified, the latest version will be pulled.2""�
//helm/private:chart_srcs.bzlrm
4
masorange_rules_helmhelm/privatechart_srcs.bzl'

chart_srcs_chart_srcs
<G
W�
//helm/private:helm_chart.bzlrm
4
masorange_rules_helmhelm/privatehelm_chart.bzl'

helm_chart_helm_chart
	<	G
		W�
'//helm/private:helm_chart_providers.bzlr�
>
masorange_rules_helmhelm/privatehelm_chart_providers.bzl&
	ChartInfo_chart_info

F
Q;
helm_chart_providers_helm_chart_providers

a
v


��
!//helm/private:helm_lint_test.bzlrt
8
masorange_rules_helmhelm/privatehelm_lint_test.bzl*
helm_lint_test
_helm_lint
@J
^�
//helm/private:helm_pull.bzlr�
3
masorange_rules_helmhelm/privatehelm_pull.bzl%
	helm_pull
_helm_pull
;E&

pull_attrs
_pull_attr
U_
o�
//helm/private:helm_push.bzlrj
3
masorange_rules_helmhelm/privatehelm_push.bzl%
	helm_push
_helm_push
;E
T�
//helm/private:helm_release.bzlrs
6
masorange_rules_helmhelm/privatehelm_release.bzl+
helm_release_helm_release
>K
]�
!//helm/private:helm_uninstall.bzlry
8
masorange_rules_helmhelm/privatehelm_uninstall.bzl/
helm_uninstall_helm_uninstall
@O
cuRules for manipulating helm charts. To load these rules:

```starlark
load("//helm:defs.bzl", "helm_chart", ...)
```
�
,
masorange_rules_helmhelpershelpers.bzl�get_make_value_or_default*�
{
get_make_value_or_default	
ctx (	
var (2H
get_make_value_or_default+@@masorange_rules_helm//helpers:helpers.bzl
�write_sh*�
�
write_sh	
ctx (
sh_filename (	
tpl (
substitutions{}(
is_executableTrue(27
write_sh+@@masorange_rules_helm//helpers:helpers.bzl
�'
$
masorange_rules_helmk8sk8s.bzl�$k8s_namespace�Create a kubernetes namespace in a kubernetes cluster with workload identity support. You can also configure GKE Workload Identity with it.

  To load the rule use:
  ```starlark
  load("//k8s:defs.bzl", "k8s_namespace")
  ```

  You can annotate the kubernetes namespace with a kubernetes service account, and bind the service account with
  gcp workload identity.

  This rule uses kubectl client to create and annotate the kubernetes namespace and gcloud sdk to create the bindings
  between the kubernetes service account and the gcp workload identity user.

  This rule builds an executable. Use `run` instead of `build` to be create the namespace.

  ```starlark
  load("//k8s:defs.bzl", "k8s_namespace")

  k8s_namespace(
      name = "namespace",
      namespace_name = "ft-sesame-${DEPLOY_BRANCH}",
      kubernetes_sa = "default",
      gcp_sa_project = "mm-odissey-dev",
      gcp_sa = "odissey-dev@mm-odissey-dev.iam.gserviceaccount.com",
      gcp_gke_project = "mm-k8s-dev-01",
      workload_identity_namespace = "mm-k8s-dev-01.svc.id.goog",
      kubernetes_context = "mm-k8s-context",
  )
  ```

You can use `k8s_namespace` in combination with `helm_release` trough `napesmace_dep` attribute.

Example of use with `helm_release`:

```starlark
  load("//k8s:defs.bzl", "k8s_namespace")

  k8s_namespace(
    name = "test-namespace",
    namespace_name = "test-namespace",
    kubernetes_sa = "test-kubernetes-sa",
    kubernetes_context = "mm-k8s-context",
  )
  helm_release(
      name = "chart_install",
      chart = ":chart",
      namespace_dep = ":test-namespace",
      tiller_namespace = "tiller-system",
      release_name = "release-name",
      values_yaml = glob(["charts/myapp/values.yaml"]),
      kubernetes_context = "mm-k8s-context",
  )
```
"�
�
k8s_namespace�Create a kubernetes namespace in a kubernetes cluster with workload identity support. You can also configure GKE Workload Identity with it.

  To load the rule use:
  ```starlark
  load("//k8s:defs.bzl", "k8s_namespace")
  ```

  You can annotate the kubernetes namespace with a kubernetes service account, and bind the service account with
  gcp workload identity.

  This rule uses kubectl client to create and annotate the kubernetes namespace and gcloud sdk to create the bindings
  between the kubernetes service account and the gcp workload identity user.

  This rule builds an executable. Use `run` instead of `build` to be create the namespace.

  ```starlark
  load("//k8s:defs.bzl", "k8s_namespace")

  k8s_namespace(
      name = "namespace",
      namespace_name = "ft-sesame-${DEPLOY_BRANCH}",
      kubernetes_sa = "default",
      gcp_sa_project = "mm-odissey-dev",
      gcp_sa = "odissey-dev@mm-odissey-dev.iam.gserviceaccount.com",
      gcp_gke_project = "mm-k8s-dev-01",
      workload_identity_namespace = "mm-k8s-dev-01.svc.id.goog",
      kubernetes_context = "mm-k8s-context",
  )
  ```

You can use `k8s_namespace` in combination with `helm_release` trough `napesmace_dep` attribute.

Example of use with `helm_release`:

```starlark
  load("//k8s:defs.bzl", "k8s_namespace")

  k8s_namespace(
    name = "test-namespace",
    namespace_name = "test-namespace",
    kubernetes_sa = "test-kubernetes-sa",
    kubernetes_context = "mm-k8s-context",
  )
  helm_release(
      name = "chart_install",
      chart = ":chart",
      namespace_dep = ":test-namespace",
      tiller_namespace = "tiller-system",
      release_name = "release-name",
      values_yaml = glob(["charts/myapp/values.yaml"]),
      kubernetes_context = "mm-k8s-context",
  )
```
*
nameA unique name for this target. 
gcp_gke_project2""5
gcp_sa%GCP Service Account in e-mail format.2""D
gcp_sa_project,CP project name where Service Account lives.2""
kubernetes_context2""V
kubernetes_sa?Kubernetes Service Account to associate with Workload Identity.2"":
namespace_name$Name of the namespace to be created. \
workload_identity_namespace7Workload Identity Namespace e.g clustername.svc.id.goog2"""4
k8s_namespace#@@masorange_rules_helm//k8s:k8s.bzl
��,
*
nameA unique name for this target. 

gcp_gke_project2""7
5
gcp_sa%GCP Service Account in e-mail format.2""F
D
gcp_sa_project,CP project name where Service Account lives.2""

kubernetes_context2""X
V
kubernetes_sa?Kubernetes Service Account to associate with Workload Identity.2""<
:
namespace_name$Name of the namespace to be created. ^
\
workload_identity_namespace7Workload Identity Namespace e.g clustername.svc.id.goog2""�NamespaceDataInfo2�
j
NamespaceDataInfo
	namespace(Undocumented)"8
NamespaceDataInfo#@@masorange_rules_helm//k8s:k8s.bzl


	namespace(Undocumented)�
//k8s/private:k8s_namespace.bzlr�
6
masorange_rules_helmk8s/privatek8s_namespace.bzl-
k8s_namespace_k8s_namespace
>L7
NamespaceDataInfo_namespace_data_info
`t
�"Rules for manipulate k8s resources�&
6
masorange_rules_helmk8s/privatek8s_namespace.bzl�$k8s_namespace�Create a kubernetes namespace in a kubernetes cluster with workload identity support. You can also configure GKE Workload Identity with it.

  To load the rule use:
  ```starlark
  load("//k8s:defs.bzl", "k8s_namespace")
  ```

  You can annotate the kubernetes namespace with a kubernetes service account, and bind the service account with
  gcp workload identity.

  This rule uses kubectl client to create and annotate the kubernetes namespace and gcloud sdk to create the bindings
  between the kubernetes service account and the gcp workload identity user.

  This rule builds an executable. Use `run` instead of `build` to be create the namespace.

  ```starlark
  load("//k8s:defs.bzl", "k8s_namespace")

  k8s_namespace(
      name = "namespace",
      namespace_name = "ft-sesame-${DEPLOY_BRANCH}",
      kubernetes_sa = "default",
      gcp_sa_project = "mm-odissey-dev",
      gcp_sa = "odissey-dev@mm-odissey-dev.iam.gserviceaccount.com",
      gcp_gke_project = "mm-k8s-dev-01",
      workload_identity_namespace = "mm-k8s-dev-01.svc.id.goog",
      kubernetes_context = "mm-k8s-context",
  )
  ```

You can use `k8s_namespace` in combination with `helm_release` trough `napesmace_dep` attribute.

Example of use with `helm_release`:

```starlark
  load("//k8s:defs.bzl", "k8s_namespace")

  k8s_namespace(
    name = "test-namespace",
    namespace_name = "test-namespace",
    kubernetes_sa = "test-kubernetes-sa",
    kubernetes_context = "mm-k8s-context",
  )
  helm_release(
      name = "chart_install",
      chart = ":chart",
      namespace_dep = ":test-namespace",
      tiller_namespace = "tiller-system",
      release_name = "release-name",
      values_yaml = glob(["charts/myapp/values.yaml"]),
      kubernetes_context = "mm-k8s-context",
  )
```
"�
�
k8s_namespace�Create a kubernetes namespace in a kubernetes cluster with workload identity support. You can also configure GKE Workload Identity with it.

  To load the rule use:
  ```starlark
  load("//k8s:defs.bzl", "k8s_namespace")
  ```

  You can annotate the kubernetes namespace with a kubernetes service account, and bind the service account with
  gcp workload identity.

  This rule uses kubectl client to create and annotate the kubernetes namespace and gcloud sdk to create the bindings
  between the kubernetes service account and the gcp workload identity user.

  This rule builds an executable. Use `run` instead of `build` to be create the namespace.

  ```starlark
  load("//k8s:defs.bzl", "k8s_namespace")

  k8s_namespace(
      name = "namespace",
      namespace_name = "ft-sesame-${DEPLOY_BRANCH}",
      kubernetes_sa = "default",
      gcp_sa_project = "mm-odissey-dev",
      gcp_sa = "odissey-dev@mm-odissey-dev.iam.gserviceaccount.com",
      gcp_gke_project = "mm-k8s-dev-01",
      workload_identity_namespace = "mm-k8s-dev-01.svc.id.goog",
      kubernetes_context = "mm-k8s-context",
  )
  ```

You can use `k8s_namespace` in combination with `helm_release` trough `napesmace_dep` attribute.

Example of use with `helm_release`:

```starlark
  load("//k8s:defs.bzl", "k8s_namespace")

  k8s_namespace(
    name = "test-namespace",
    namespace_name = "test-namespace",
    kubernetes_sa = "test-kubernetes-sa",
    kubernetes_context = "mm-k8s-context",
  )
  helm_release(
      name = "chart_install",
      chart = ":chart",
      namespace_dep = ":test-namespace",
      tiller_namespace = "tiller-system",
      release_name = "release-name",
      values_yaml = glob(["charts/myapp/values.yaml"]),
      kubernetes_context = "mm-k8s-context",
  )
```
*
nameA unique name for this target. 
gcp_gke_project2""5
gcp_sa%GCP Service Account in e-mail format.2""D
gcp_sa_project,CP project name where Service Account lives.2""
kubernetes_context2""V
kubernetes_sa?Kubernetes Service Account to associate with Workload Identity.2"":
namespace_name$Name of the namespace to be created. \
workload_identity_namespace7Workload Identity Namespace e.g clustername.svc.id.goog2"""F
k8s_namespace5@@masorange_rules_helm//k8s/private:k8s_namespace.bzl
��,
*
nameA unique name for this target. 

gcp_gke_project2""7
5
gcp_sa%GCP Service Account in e-mail format.2""F
D
gcp_sa_project,CP project name where Service Account lives.2""

kubernetes_context2""X
V
kubernetes_sa?Kubernetes Service Account to associate with Workload Identity.2""<
:
namespace_name$Name of the namespace to be created. ^
\
workload_identity_namespace7Workload Identity Namespace e.g clustername.svc.id.goog2""�NamespaceDataInfo2�
|
NamespaceDataInfo
	namespace(Undocumented)"J
NamespaceDataInfo5@@masorange_rules_helm//k8s/private:k8s_namespace.bzl


	namespace(Undocumented)�
:
masorange_rules_helmk8s/privatekubectl_toolchain.bzl�kubectl_toolchain"�
�
kubectl_toolchain*
nameA unique name for this target. 	
bin "N
kubectl_toolchain9@@masorange_rules_helm//k8s/private:kubectl_toolchain.bzl
YY,
*
nameA unique name for this target. 
	
bin �KubectlToolchainInfoKubectl toolchain2�
�
KubectlToolchainInfoKubectl toolchain 
binKubectl executable binary"Q
KubectlToolchainInfo9@@masorange_rules_helm//k8s/private:kubectl_toolchain.bzl
< < "
 
binKubectl executable binary�	kubectl_repoFetch kubectl binaryR�	
�
kubectl_repoFetch kubectl binary.
name"A unique name for this repository. 
platform �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 	
sha 
version *I
kubectl_repo9@@masorange_rules_helm//k8s/private:kubectl_toolchain.bzl
��0
.
name"A unique name for this repository. 

platform �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 
	
sha 

version �
kubectl_toolchain_configurelCreates a repository with toolchain definitions for all known platforms
which can be registered or selected.R�	
�
kubectl_toolchain_configurelCreates a repository with toolchain definitions for all known platforms
which can be registered or selected..
name"A unique name for this repository. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 *X
kubectl_toolchain_configure9@@masorange_rules_helm//k8s/private:kubectl_toolchain.bzl
�.�.0
.
name"A unique name for this repository. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 /	KUBECTL_DEFAULT_VERSIONv1.28.2j	v1.28.2�'
%
masorange_rules_helmk8sdefs.bzl�$k8s_namespace�Create a kubernetes namespace in a kubernetes cluster with workload identity support. You can also configure GKE Workload Identity with it.

  To load the rule use:
  ```starlark
  load("//k8s:defs.bzl", "k8s_namespace")
  ```

  You can annotate the kubernetes namespace with a kubernetes service account, and bind the service account with
  gcp workload identity.

  This rule uses kubectl client to create and annotate the kubernetes namespace and gcloud sdk to create the bindings
  between the kubernetes service account and the gcp workload identity user.

  This rule builds an executable. Use `run` instead of `build` to be create the namespace.

  ```starlark
  load("//k8s:defs.bzl", "k8s_namespace")

  k8s_namespace(
      name = "namespace",
      namespace_name = "ft-sesame-${DEPLOY_BRANCH}",
      kubernetes_sa = "default",
      gcp_sa_project = "mm-odissey-dev",
      gcp_sa = "odissey-dev@mm-odissey-dev.iam.gserviceaccount.com",
      gcp_gke_project = "mm-k8s-dev-01",
      workload_identity_namespace = "mm-k8s-dev-01.svc.id.goog",
      kubernetes_context = "mm-k8s-context",
  )
  ```

You can use `k8s_namespace` in combination with `helm_release` trough `napesmace_dep` attribute.

Example of use with `helm_release`:

```starlark
  load("//k8s:defs.bzl", "k8s_namespace")

  k8s_namespace(
    name = "test-namespace",
    namespace_name = "test-namespace",
    kubernetes_sa = "test-kubernetes-sa",
    kubernetes_context = "mm-k8s-context",
  )
  helm_release(
      name = "chart_install",
      chart = ":chart",
      namespace_dep = ":test-namespace",
      tiller_namespace = "tiller-system",
      release_name = "release-name",
      values_yaml = glob(["charts/myapp/values.yaml"]),
      kubernetes_context = "mm-k8s-context",
  )
```
"�
�
k8s_namespace�Create a kubernetes namespace in a kubernetes cluster with workload identity support. You can also configure GKE Workload Identity with it.

  To load the rule use:
  ```starlark
  load("//k8s:defs.bzl", "k8s_namespace")
  ```

  You can annotate the kubernetes namespace with a kubernetes service account, and bind the service account with
  gcp workload identity.

  This rule uses kubectl client to create and annotate the kubernetes namespace and gcloud sdk to create the bindings
  between the kubernetes service account and the gcp workload identity user.

  This rule builds an executable. Use `run` instead of `build` to be create the namespace.

  ```starlark
  load("//k8s:defs.bzl", "k8s_namespace")

  k8s_namespace(
      name = "namespace",
      namespace_name = "ft-sesame-${DEPLOY_BRANCH}",
      kubernetes_sa = "default",
      gcp_sa_project = "mm-odissey-dev",
      gcp_sa = "odissey-dev@mm-odissey-dev.iam.gserviceaccount.com",
      gcp_gke_project = "mm-k8s-dev-01",
      workload_identity_namespace = "mm-k8s-dev-01.svc.id.goog",
      kubernetes_context = "mm-k8s-context",
  )
  ```

You can use `k8s_namespace` in combination with `helm_release` trough `napesmace_dep` attribute.

Example of use with `helm_release`:

```starlark
  load("//k8s:defs.bzl", "k8s_namespace")

  k8s_namespace(
    name = "test-namespace",
    namespace_name = "test-namespace",
    kubernetes_sa = "test-kubernetes-sa",
    kubernetes_context = "mm-k8s-context",
  )
  helm_release(
      name = "chart_install",
      chart = ":chart",
      namespace_dep = ":test-namespace",
      tiller_namespace = "tiller-system",
      release_name = "release-name",
      values_yaml = glob(["charts/myapp/values.yaml"]),
      kubernetes_context = "mm-k8s-context",
  )
```
*
nameA unique name for this target. 
gcp_gke_project2""5
gcp_sa%GCP Service Account in e-mail format.2""D
gcp_sa_project,CP project name where Service Account lives.2""
kubernetes_context2""V
kubernetes_sa?Kubernetes Service Account to associate with Workload Identity.2"":
namespace_name$Name of the namespace to be created. \
workload_identity_namespace7Workload Identity Namespace e.g clustername.svc.id.goog2"""5
k8s_namespace$@@masorange_rules_helm//k8s:defs.bzl
��,
*
nameA unique name for this target. 

gcp_gke_project2""7
5
gcp_sa%GCP Service Account in e-mail format.2""F
D
gcp_sa_project,CP project name where Service Account lives.2""

kubernetes_context2""X
V
kubernetes_sa?Kubernetes Service Account to associate with Workload Identity.2""<
:
namespace_name$Name of the namespace to be created. ^
\
workload_identity_namespace7Workload Identity Namespace e.g clustername.svc.id.goog2""�NamespaceDataInfo2�
k
NamespaceDataInfo
	namespace(Undocumented)"9
NamespaceDataInfo$@@masorange_rules_helm//k8s:defs.bzl


	namespace(Undocumented)�
//k8s/private:k8s_namespace.bzlr�
6
masorange_rules_helmk8s/privatek8s_namespace.bzl-
k8s_namespace_k8s_namespace
>L7
NamespaceDataInfo_namespace_data_info
`t
�"Rules for manipulate k8s resources�
&
masorange_rules_helmsopssops.bzl�sops_decrypt*�
�
sops_decrypt

name (

srcs (
age_keys_file (
	sops_yaml":.sops.yaml"(2K
sops_decrypt;@@masorange_rules_helm//sops/private:sops_decrypt_macro.bzl
2sops_decrypt_rule�
%//sops/private:sops_decrypt_macro.bzlry
<
masorange_rules_helmsops/privatesops_decrypt_macro.bzl+
sops_decrypt_sops_decrypt
DQ
c!Rules for manipulate sops screts.�'
6
masorange_rules_helmsops/privatesops_decrypt.bzl�'sops_decrypt�Decrypt secrets using [sops](https://github.com/mozilla/sops)

To load the rule use:
```starlark
load("//sops:defs.bzl", "sops_decrypt")
```

You can decrypt as many secrets as you want using `sops_decrypt` rule. Use the rule attribute `src` to provide the encrypted secrets that you want to decrypt.
The rule also needs the sops config file with the keyring id in order to decrypt files (`.sops.yaml`). You can provide it using the `sops_yaml` rule attribute.
If no sops_yaml config is provided, the rule will try to locate a `.sops.yaml` file by default in the same directory where the target is placed.

Example of use:
```starlark
# explicit .sops.yaml config
load("//sops:defs.bzl", "sops_decrypt")

sops_decrypt(
    name = "decrypt_secret_files",
    srcs = [":secrets.yaml"]
    sops_yaml = ":.sops.yaml"
)
```

```starlark
# implicit .sops.yaml config
load("//sops:defs.bzl", "sops_decrypt")

sops_decrypt(
    name = "decrypt_secret_files",
    srcs = [":secrets.yaml"]
)
```

The outputs of the rule are the decrypted secrets that you can later provide to other rules, as for example to `helm_release`:

```starlark
sops_decrypt(
    name = "decrypt_secret_files",
    srcs = [":secrets.yaml"]
)

helm_release(
    name = "chart_install",
    chart = ":chart",
    namespace = "myapp",
    release_name = "release-name",
    values = glob(["charts/myapp/values.yaml"]) + [":decrypt_secret_files"],
)
```

You can also use [age](https://github.com/FiloSottile/age) key file to decrypt your secrets. To provide the key_file use the rule attribute `age_keys_file` to point
to the age keys file used to encrypt your secrets.

```starlark
sops_decrypt(
    name = "decrypt_secret_files",
    srcs = [":secrets.yaml"],
    age_keys_file = "sops/age_keys.txt"
)

helm_release(
    name = "chart_install",
    chart = ":chart",
    namespace = "myapp",
    release_name = "release-name",
    values = glob(["charts/myapp/values.yaml"]) + [":decrypt_secret_files"],
)
```

"�
�
sops_decrypt�Decrypt secrets using [sops](https://github.com/mozilla/sops)

To load the rule use:
```starlark
load("//sops:defs.bzl", "sops_decrypt")
```

You can decrypt as many secrets as you want using `sops_decrypt` rule. Use the rule attribute `src` to provide the encrypted secrets that you want to decrypt.
The rule also needs the sops config file with the keyring id in order to decrypt files (`.sops.yaml`). You can provide it using the `sops_yaml` rule attribute.
If no sops_yaml config is provided, the rule will try to locate a `.sops.yaml` file by default in the same directory where the target is placed.

Example of use:
```starlark
# explicit .sops.yaml config
load("//sops:defs.bzl", "sops_decrypt")

sops_decrypt(
    name = "decrypt_secret_files",
    srcs = [":secrets.yaml"]
    sops_yaml = ":.sops.yaml"
)
```

```starlark
# implicit .sops.yaml config
load("//sops:defs.bzl", "sops_decrypt")

sops_decrypt(
    name = "decrypt_secret_files",
    srcs = [":secrets.yaml"]
)
```

The outputs of the rule are the decrypted secrets that you can later provide to other rules, as for example to `helm_release`:

```starlark
sops_decrypt(
    name = "decrypt_secret_files",
    srcs = [":secrets.yaml"]
)

helm_release(
    name = "chart_install",
    chart = ":chart",
    namespace = "myapp",
    release_name = "release-name",
    values = glob(["charts/myapp/values.yaml"]) + [":decrypt_secret_files"],
)
```

You can also use [age](https://github.com/FiloSottile/age) key file to decrypt your secrets. To provide the key_file use the rule attribute `age_keys_file` to point
to the age keys file used to encrypt your secrets.

```starlark
sops_decrypt(
    name = "decrypt_secret_files",
    srcs = [":secrets.yaml"],
    age_keys_file = "sops/age_keys.txt"
)

helm_release(
    name = "chart_install",
    chart = ":chart",
    namespace = "myapp",
    release_name = "release-name",
    values = glob(["charts/myapp/values.yaml"]) + [":decrypt_secret_files"],
)
```

*
nameA unique name for this target. �
age_keys_file�Age file with age keys used to encrypt the secret. [Check official docs](https://github.com/getsops/sops?tab=readme-ov-file#encrypting-using-age) about how to use age with sops.2None�
	sops_yaml�The .sops.yaml configuration file. If no provided, the macro will usually try to locate the configuration file in the same dir where the BUILD file is located. 4
srcs(List of encrypted files to be decrypted. "E
sops_decrypt5@@masorange_rules_helm//sops/private:sops_decrypt.bzl
nn,
*
nameA unique name for this target. �
�
age_keys_file�Age file with age keys used to encrypt the secret. [Check official docs](https://github.com/getsops/sops?tab=readme-ov-file#encrypting-using-age) about how to use age with sops.2None�
�
	sops_yaml�The .sops.yaml configuration file. If no provided, the macro will usually try to locate the configuration file in the same dir where the BUILD file is located. 6
4
srcs(List of encrypted files to be decrypted. �
<
masorange_rules_helmsops/privatesops_decrypt_macro.bzl�sops_decrypt*�
�
sops_decrypt

name (

srcs (
age_keys_file (
	sops_yaml":.sops.yaml"(2K
sops_decrypt;@@masorange_rules_helm//sops/private:sops_decrypt_macro.bzl
2sops_decrypt_rulea
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.�
//sops/private:sops_decrypt.bzlrw
6
masorange_rules_helmsops/privatesops_decrypt.bzl/
sops_decryptsops_decrypt_rule
>O
a�
8
masorange_rules_helmsops/privatesops_toolchain.bzl�sops_toolchain"�
�
sops_toolchain*
nameA unique name for this target. 	
bin "I
sops_toolchain7@@masorange_rules_helm//sops/private:sops_toolchain.bzl
WW,
*
nameA unique name for this target. 
	
bin �SopsToolchainInfoSops toolchain2�
�
SopsToolchainInfoSops toolchain
binSops executable binary"L
SopsToolchainInfo7@@masorange_rules_helm//sops/private:sops_toolchain.bzl
44

binSops executable binary�		sops_repo.Fetch external tools needed for sops toolchainR�	
�
	sops_repo.Fetch external tools needed for sops toolchain.
name"A unique name for this repository. 
platform �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 	
sha 
version *D
	sops_repo7@@masorange_rules_helm//sops/private:sops_toolchain.bzl
��0
.
name"A unique name for this repository. 

platform �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 
	
sha 

version �
sops_toolchain_configurelCreates a repository with toolchain definitions for all known platforms
which can be registered or selected.R�	
�
sops_toolchain_configurelCreates a repository with toolchain definitions for all known platforms
which can be registered or selected..
name"A unique name for this repository. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 *S
sops_toolchain_configure7@@masorange_rules_helm//sops/private:sops_toolchain.bzl
�+�+0
.
name"A unique name for this repository. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 *	SOPS_DEFAULT_VERSIONv3.8.1jv3.8.1�
&
masorange_rules_helmsopsdefs.bzl�sops_decrypt*�
�
sops_decrypt

name (

srcs (
age_keys_file (
	sops_yaml":.sops.yaml"(2K
sops_decrypt;@@masorange_rules_helm//sops/private:sops_decrypt_macro.bzl
2sops_decrypt_rule�
%//sops/private:sops_decrypt_macro.bzlry
<
masorange_rules_helmsops/privatesops_decrypt_macro.bzl+
sops_decrypt_sops_decrypt
DQ
c!Rules for manipulate sops screts.�
"
masorange_rules_helm
config.bzl�masorange_rules_helm_configure*w
g
masorange_rules_helm_configure2E
masorange_rules_helm_configure#@@masorange_rules_helm//:config.bzl
�
//lib:repositories.bzlr�
)
aspect_bazel_liblibrepositories.bzlL
aspect_bazel_lib_dependenciesaspect_bazel_lib_dependencies
2OZ
$aspect_bazel_lib_register_toolchains$aspect_bazel_lib_register_toolchains
SwM
register_coreutils_toolchainsregister_coreutils_toolchains
{�
��
:workspace.bzlrm

bazel_skylibworkspace.bzl>
bazel_skylib_workspacebazel_skylib_workspace
(>
@�
:toolchains.bzlr�
&
masorange_rules_helmtoolchains.bzlb
(masorange_rules_helm_register_toolchains(masorange_rules_helm_register_toolchains
1Y
[t
	:deps.bzlre

	rules_pkgdeps.bzl>
rules_pkg_dependenciesrules_pkg_dependencies
 6
8�
&
masorange_rules_helmextensions.bzl�
toolchainsJ�
�

toolchains�
install
gcloud_name2"gcloud"
gcloud_version2	"502.0.0"
	helm_name2"helm"
helm_version2	"v3.16.3"
kubectl_name2	"kubectl"
kubectl_version2	"v1.28.2"
	sops_name2"sops"
sops_version2"v3.8.1""5

toolchains'@@masorange_rules_helm//:extensions.bzl
�
�
install
gcloud_name2"gcloud"
gcloud_version2	"502.0.0"
	helm_name2"helm"
helm_version2	"v3.16.3"
kubectl_name2	"kubectl"
kubectl_version2	"v1.28.2"
	sops_name2"sops"
sops_version2"v3.8.1"

gcloud_name2"gcloud"

gcloud_version2	"502.0.0"

	helm_name2"helm"

helm_version2	"v3.16.3"

kubectl_name2	"kubectl" 

kubectl_version2	"v1.28.2"

	sops_name2"sops"

sops_version2"v3.8.1"�utilsJ�
�
utils�
pull

name p

chart_name^The name of the helm_chart to download. It will be appendend at the end of the repository url. �
	repo_name�The name of the repository. This is only useful if you provide a `repository_config` file and you want the repo url to be located within the repo config.2""a
repo_urlQThe url where the chart is located. You have to omit the chart name from the url. 8
repository_configThe repository config file.2Nonej
versionYThe version of the chart to download. If no specified, the latest version will be pulled.2"""0
utils'@@masorange_rules_helm//:extensions.bzl
11�	
�
pull

name p

chart_name^The name of the helm_chart to download. It will be appendend at the end of the repository url. �
	repo_name�The name of the repository. This is only useful if you provide a `repository_config` file and you want the repo url to be located within the repo config.2""a
repo_urlQThe url where the chart is located. You have to omit the chart name from the url. 8
repository_configThe repository config file.2Nonej
versionYThe version of the chart to download. If no specified, the latest version will be pulled.2""


name r
p

chart_name^The name of the helm_chart to download. It will be appendend at the end of the repository url. �
�
	repo_name�The name of the repository. This is only useful if you provide a `repository_config` file and you want the repo url to be located within the repo config.2""c
a
repo_urlQThe url where the chart is located. You have to omit the chart name from the url. :
8
repository_configThe repository config file.2Nonel
j
versionYThe version of the chart to download. If no specified, the latest version will be pulled.2""a
//lib:dicts.bzlrL

bazel_skyliblib	dicts.bzl
dictsdicts
',
.�
:toolchains.bzlr�
&
masorange_rules_helmtoolchains.bzlF
register_gcloud_toolchainsregister_gcloud_toolchains
1KB
register_helm_toolchainsregister_helm_toolchains
OgI
register_kubectl_toolchainsregister_kubectl_toolchains
k�D
register_sops_toolchainsregister_sops_toolchains
��
��
"//gcs/private:gcloud_toolchain.bzlr�
9
masorange_rules_helmgcs/privategcloud_toolchain.bzl>
GCLOUD_DEFAULT_VERSIONGCLOUD_DEFAULT_VERSION
BX
Z�
//helm:defs.bzlr�
&
masorange_rules_helmhelmdefs.bzl$
	helm_pull	helm_pull
/8&

pull_attrs
pull_attrs
<F
H�
!//helm/private:helm_toolchain.bzlr�
8
masorange_rules_helmhelm/privatehelm_toolchain.bzl:
HELM_DEFAULT_VERSIONHELM_DEFAULT_VERSION
AU
W�
#//k8s/private:kubectl_toolchain.bzlr�
:
masorange_rules_helmk8s/privatekubectl_toolchain.bzl@
KUBECTL_DEFAULT_VERSIONKUBECTL_DEFAULT_VERSION
CZ
\�
!//sops/private:sops_toolchain.bzlr�
8
masorange_rules_helmsops/privatesops_toolchain.bzl:
SOPS_DEFAULT_VERSIONSOPS_DEFAULT_VERSION
AU
W�
(
masorange_rules_helmrepositories.bzl~http_archive*l
U
http_archive

kwargs(29
http_archive)@@masorange_rules_helm//:repositories.bzl
*maybeninternal_deps*[
K
internal_deps2:
internal_deps)@@masorange_rules_helm//:repositories.bzl
00�!masorange_rules_helm_repositories*�
s
!masorange_rules_helm_repositories2N
!masorange_rules_helm_repositories)@@masorange_rules_helm//:repositories.bzl
�
 //tools/build_defs/repo:http.bzlrk
.
bazel_toolstools/build_defs/repohttp.bzl+
http_archive_http_archive
6C
U�
!//tools/build_defs/repo:utils.bzlr]
/
bazel_toolstools/build_defs/repo	utils.bzl
maybemaybe
8=
?�
:toolchains.bzlr�
&
masorange_rules_helmtoolchains.bzlF
register_gcloud_toolchainsregister_gcloud_toolchains
1KB
register_helm_toolchainsregister_helm_toolchains
OgI
register_kubectl_toolchainsregister_kubectl_toolchains
k�D
register_sops_toolchainsregister_sops_toolchains
��
��
"//gcs/private:gcloud_toolchain.bzlr�
9
masorange_rules_helmgcs/privategcloud_toolchain.bzl>
GCLOUD_DEFAULT_VERSIONGCLOUD_DEFAULT_VERSION
BX
Z�
!//helm/private:helm_toolchain.bzlr�
8
masorange_rules_helmhelm/privatehelm_toolchain.bzl:
HELM_DEFAULT_VERSIONHELM_DEFAULT_VERSION
AU
W�
#//k8s/private:kubectl_toolchain.bzlr�
:
masorange_rules_helmk8s/privatekubectl_toolchain.bzl@
KUBECTL_DEFAULT_VERSIONKUBECTL_DEFAULT_VERSION
	C	Z
		\�
!//sops/private:sops_toolchain.bzlr�
8
masorange_rules_helmsops/privatesops_toolchain.bzl:
SOPS_DEFAULT_VERSIONSOPS_DEFAULT_VERSION

A
U


W�
&
masorange_rules_helmtoolchains.bzl�(masorange_rules_helm_register_toolchains*�

(masorange_rules_helm_register_toolchains2S
(masorange_rules_helm_register_toolchains'@@masorange_rules_helm//:toolchains.bzl
66�register_gcloud_toolchains*�
�
register_gcloud_toolchains

name (
version (
registerFalse(2E
register_gcloud_toolchains'@@masorange_rules_helm//:toolchains.bzl
2gcloud_toolchain_configure�register_helm_toolchains*�
�
register_helm_toolchains

name (
version (
registerFalse(2C
register_helm_toolchains'@@masorange_rules_helm//:toolchains.bzl
2helm_toolchain_configure�register_kubectl_toolchains*�
�
register_kubectl_toolchains

name (
version (
registerFalse(2F
register_kubectl_toolchains'@@masorange_rules_helm//:toolchains.bzl
**2kubectl_toolchain_configure�register_sops_toolchains*�
�
register_sops_toolchains

name (
version (
registerFalse(2C
register_sops_toolchains'@@masorange_rules_helm//:toolchains.bzl
2sops_toolchain_configure�
"//gcs/private:gcloud_toolchain.bzlr�
9
masorange_rules_helmgcs/privategcloud_toolchain.bzl>
GCLOUD_DEFAULT_VERSIONGCLOUD_DEFAULT_VERSION
BX0
GCLOUD_VERSIONSGCLOUD_VERSIONS
\k(
gcloud_repogcloud_repo
ozG
gcloud_toolchain_configuregcloud_toolchain_configure
~�
��
!//helm/private:helm_toolchain.bzlr�
8
masorange_rules_helmhelm/privatehelm_toolchain.bzl:
HELM_DEFAULT_VERSIONHELM_DEFAULT_VERSION
AU,
HELM_VERSIONSHELM_VERSIONS
Yf$
	helm_repo	helm_repo
jsC
helm_toolchain_configurehelm_toolchain_configure
w�
��
#//k8s/private:kubectl_toolchain.bzlr�
:
masorange_rules_helmk8s/privatekubectl_toolchain.bzl@
KUBECTL_DEFAULT_VERSIONKUBECTL_DEFAULT_VERSION
CZ2
KUBECTL_VERSIONSKUBECTL_VERSIONS
^n*
kubectl_repokubectl_repo
r~J
kubectl_toolchain_configurekubectl_toolchain_configure
��
��
!//sops/private:sops_toolchain.bzlr�
8
masorange_rules_helmsops/privatesops_toolchain.bzl:
SOPS_DEFAULT_VERSIONSOPS_DEFAULT_VERSION
AU,
SOPS_VERSIONSSOPS_VERSIONS
Yf$
	sops_repo	sops_repo
jsC
sops_toolchain_configuresops_toolchain_configure
w�
� 