�	

nvcbazelcss_header.bzl�
css_header�Used to generate `src/cov/cov-style.h` from `src/cov/cov-style.css`
(the upstream `Makemodule.am` does the same job with an inline `sed`
pipeline). Implemented as a real rule rather than a `genrule` so the
underlying process wrapper has a typed, named-argument CLI instead of
a free-form shell command.
"�
�

css_header�Used to generate `src/cov/cov-style.h` from `src/cov/cov-style.css`
(the upstream `Makemodule.am` does the same job with an inline `sed`
pipeline). Implemented as a real rule rather than a `genrule` so the
underlying process wrapper has a typed, named-argument CLI instead of
a free-form shell command.
*
nameA unique name for this target. =
out2Output header file (declared as a generated file). 
srcInput CSS file. 6
varname'Name of the C `const char[]` to define. ")

css_header@@nvc//bazel:css_header.bzl
,
*
nameA unique name for this target. ?
=
out2Output header file (declared as a generated file). 

srcInput CSS file. 8
6
varname'Name of the C `const char[]` to define. 6Custom rule that wraps `bazel/tools/css_to_header.sh`.�

nvcbazelllvm_utils.bzl�cc_stdcc17_transitioned_libraryxWrap `target` so its dependency closure is built with C++17.

A rule to transition a C++ library to build with stdc++17."�
�
cc_stdcc17_transitioned_libraryxWrap `target` so its dependency closure is built with C++17.

A rule to transition a C++ library to build with stdc++17.*
nameA unique name for this target. V
cxxoptsGFlags to inject into `--host_cxxopt` and `--cxxopt` command line flags. '
targetThe target to transition. "?
 _cc_stdcc17_transitioned_library@@nvc//bazel:llvm_utils.bzl
kk,
*
nameA unique name for this target. X
V
cxxoptsGFlags to inject into `--host_cxxopt` and `--cxxopt` command line flags. )
'
targetThe target to transition. [
//cc:defs.bzlrH

rules_ccccdefs.bzl
CcInfoCcInfo
!'
)�Configuration-transition wrappers for the LLVM dep closure.

LLVM 17+ source uses C++17-only features (`std::string_view`, etc.)
in its public headers, but several BCR cc toolchains still default
the `--cxxopt` to `-std=c++14`. Without a transition, anything that
pulls in `@llvm-project//llvm:*` fails to compile on those
toolchains.

We solve it the same way `rules_ghdl` does: wrap the LLVM-consuming
target in a config transition that forces
`--cxxopt=-std=c++17` (and the matching `/std:c++17` for MSVC /
clang-cl) on both the target and exec configurations.

Vendored from rules_rust, via the BCR `ghdl` module:
https://github.com/bazelbuild/rules_rust/blob/main/extensions/bindgen/private/llvm_utils.bzl
�;

nvcbazelnvc_compile.bzl�nvc_compile�Compile a `@rules_vhdl//vhdl:vhdl_library` target with `nvc -a`.

Output is a TreeArtifact containing the compiled `.NVC` units, with
the directory basename matching the VHDL `library` name so the nvc
runtime can locate it via `-L`.
"�
�	
nvc_compile�Compile a `@rules_vhdl//vhdl:vhdl_library` target with `nvc -a`.

Output is a TreeArtifact containing the compiled `.NVC` units, with
the directory basename matching the VHDL `library` name so the nvc
runtime can locate it via `-L`.
*
nameA unique name for this target. Y
	bootstrapCPass --bootstrap to the first analysis (required for STD.STANDARD).2FalseX
deps8Other nvc_compile targets whose units may be referenced.*
NvcLibraryInfo2[]�
libiA @rules_vhdl//vhdl:vhdl_library target carrying the sources, library name, VHDL standard, and dep graph. *

VhdlInfo7
nvc&The nvc binary to use for compilation.2//:nvc]
relaxedIPass --relaxed to nvc (loosen 1993 LRM checks; used by VITAL primitives).2False�
seed�Optional sibling nvc_compile whose compiled contents are copied into the work dir before this library's srcs are analysed. Lets a split library (e.g. std_base â std_full) extend an earlier build without re-running its analyses.*
NvcLibraryInfo2None�
standard}Override the VHDL standard from the `lib` (rules_vhdl) target. Useful when the same source files are reused across standards.2"""+
nvc_compile@@nvc//bazel:nvc_compile.bzl
tt,
*
nameA unique name for this target. [
Y
	bootstrapCPass --bootstrap to the first analysis (required for STD.STANDARD).2FalseZ
X
deps8Other nvc_compile targets whose units may be referenced.*
NvcLibraryInfo2[]�
�
libiA @rules_vhdl//vhdl:vhdl_library target carrying the sources, library name, VHDL standard, and dep graph. *

VhdlInfo9
7
nvc&The nvc binary to use for compilation.2//:nvc_
]
relaxedIPass --relaxed to nvc (loosen 1993 LRM checks; used by VITAL primitives).2False�
�
seed�Optional sibling nvc_compile whose compiled contents are copied into the work dir before this library's srcs are analysed. Lets a split library (e.g. std_base â std_full) extend an earlier build without re-running its analyses.*
NvcLibraryInfo2None�
�
standard}Override the VHDL standard from the `lib` (rules_vhdl) target. Useful when the same source files are reused across standards.2""�
vhdl_chain�Emit an ordered chain of `vhdl_library` + `nvc_compile` targets.

The bootstrap of NVC's shipped VHDL libraries (STD, IEEE, NVC,
SYNOPSYS, VITAL) is sensitive to source-file ordering: bodies must
follow declarations, IEEE.NUMERIC_STD uses IEEE.STD_LOGIC_1164, and
some bodies reference NVC.POLYFILL which is itself built later.

Buildifier will sort the `srcs` list of any single `vhdl_library`
call, so encoding the order as a flat list is unreliable. Instead,
`vhdl_chain` accepts a list of `(suffix, [srcs])` tuples — buildifier
leaves the tuple order intact — and emits one `vhdl_library` and one
`nvc_compile` per phase. Each compile is `seed=`-ed off the previous
phase, so units analysed earlier in the chain are visible to later
ones without redoing the work.

The final phase's compile is named `<name>` (the public handle that
other targets depend on); intermediate compiles are named
`<name>__<suffix>` to keep their internal status visible.
*�
�

vhdl_chainE
name9Final compile target name (e.g. `"std"`, `"ieee_decls"`). (I
library:VHDL library identifier (passed verbatim to vhdl_library). (@
standard0VHDL standard (`"1993"`, `"2008"`, or `"2019"`). (�
phases�Ordered list of `(suffix, srcs)` tuples. `srcs` is a list
of source files; `suffix` is appended to `name` for intermediate
compiles. The LAST entry's compile is named `name` directly. (K
	bootstrap5If True, the first phase passes `--bootstrap` to nvc.False(C
relaxed/If True, every phase passes `--relaxed` to nvc.False(s
depscOther `nvc_compile` targets visible from every phase (e.g.
`:std_base`). Defaults to an empty list.None(�
seed�Optional sibling `nvc_compile` (label string) whose compiled
contents are copied into the first phase's work dir, so the
chain extends an existing library rather than starting from
scratch. Used to chain `:std` (TEXTIO-body) on top of
`:std_base`, etc.None(B

visibility,Visibility of the final compile target only.None(�Emit an ordered chain of `vhdl_library` + `nvc_compile` targets.

The bootstrap of NVC's shipped VHDL libraries (STD, IEEE, NVC,
SYNOPSYS, VITAL) is sensitive to source-file ordering: bodies must
follow declarations, IEEE.NUMERIC_STD uses IEEE.STD_LOGIC_1164, and
some bodies reference NVC.POLYFILL which is itself built later.

Buildifier will sort the `srcs` list of any single `vhdl_library`
call, so encoding the order as a flat list is unreliable. Instead,
`vhdl_chain` accepts a list of `(suffix, [srcs])` tuples — buildifier
leaves the tuple order intact — and emits one `vhdl_library` and one
`nvc_compile` per phase. Each compile is `seed=`-ed off the previous
phase, so units analysed earlier in the chain are visible to later
ones without redoing the work.

The final phase's compile is named `<name>` (the public handle that
other targets depend on); intermediate compiles are named
`<name>__<suffix>` to keep their internal status visible.
"=
;The Bazel target name of the final compile (always `name`).2*

vhdl_chain@@nvc//bazel:nvc_compile.bzl
��"vhdl_library"nvc_compile�NvcLibraryInfo+Compiled NVC VHDL library output directory.2�
�
NvcLibraryInfo+Compiled NVC VHDL library output directory.8
lib_dir-TreeArtifact containing the compiled library.z
transitive_lib_dirscdepset[File]: every nvc_compile dir that must be in -L when consumers analyse against this library.".
NvcLibraryInfo@@nvc//bazel:nvc_compile.bzl
:
8
lib_dir-TreeArtifact containing the compiled library.|
z
transitive_lib_dirscdepset[File]: every nvc_compile dir that must be in -L when consumers analyse against this library.�
//vhdl:defs.bzlr|


rules_vhdlvhdldefs.bzl"
VhdlInfoVhdlInfo
%-*
vhdl_libraryvhdl_library
1=
?�
Starlark rule for compiling VHDL libraries with `nvc -a`.

Source declarations come from the standard `@rules_vhdl//vhdl:defs.bzl#vhdl_library`
rule, which only collects sources and metadata (library name, VHDL
standard, transitive dep graph). This module supplies the matching
backend: `nvc_compile` consumes a `VhdlInfo` provider and produces a
TreeArtifact of the compiled library, ready to be loaded by the nvc
simulator at runtime.

The split mirrors what `rules_ghdl` does for GHDL â a third-party
ruleset that owns the source layer, and a backend-specific rule that
runs the simulator's analyser.

Cyclic interleaving between sibling libraries (`lib/std/textio-body.vhd`
`use nvc.polyfill.all;` forces it to be compiled AFTER lib/nvc/NVC.POLYFILL,
even though every NVC.* unit transitively needs STD.STANDARD) is handled
through the `seed` attribute: an optional sibling `nvc_compile` target
whose contents are copied into the work directory before compilation
begins. That lets the upstream multi-phase bootstrap collapse into a
small number of Bazel targets per standard.

The actual `nvc -a` invocations run through `bazel/vhdl_compile.cc`,
called via `ctx.actions.run` with a named-argument CLI. The rule
itself just assembles the arguments â no inline shell command, no
`run_shell`.
 