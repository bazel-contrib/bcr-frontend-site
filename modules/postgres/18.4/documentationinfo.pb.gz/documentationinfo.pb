�
,
postgresprivatecurl_ssl_transition.bzl�pg_ssl_bundleORe-exports a `cc_library` with `@curl//:ssl_lib` forced to match `//:with_ssl`."�
�
pg_ssl_bundleORe-exports a `cc_library` with `@curl//:ssl_lib` forced to match `//:with_ssl`.*
nameA unique name for this target. q
targetYThe `cc_library` bundling libpq's SSL link inputs (openssl/boringssl + optionally @curl). *
CcInfo"<
pg_ssl_bundle+@@postgres//private:curl_ssl_transition.bzl
22,
*
nameA unique name for this target. s
q
targetYThe `cc_library` bundling libpq's SSL link inputs (openssl/boringssl + optionally @curl). *
CcInfoo
//cc/common:cc_info.bzlrR
"
rules_cc	cc/commoncc_info.bzl
CcInfoCcInfo
+1
3�
Incoming-edge transition that pins `@curl//:ssl_lib` to `//:with_ssl`.

`@curl//:curl` carries its own `ssl_lib` flag (defaulted to BoringSSL) that
selects which SSL library it links against. If postgres uses
`--//:with_ssl=openssl` but `--@curl//:ssl_lib` is left at its module
default, the final link will pull in both `@openssl` and `@boringssl` and
trip duplicate-symbol errors (macOS's `ld` rejects them outright; GNU ld
silently picks one).

The fix is to bundle every SSL-touching dep of libpq â `@openssl` /
`@boringssl` themselves and (when `--//:with_libcurl=True`) `@curl//:curl`
â into a single `cc_library`, then wrap that bundle with this transition.
Because every libpq target that needs SSL routes through the wrapped
bundle, there is exactly one path through the build graph that reaches
`@openssl` / `@boringssl`, and it is always in the transitioned config.

Wrapping just `@curl//:curl` instead doesn't work: `:ssl_backend` would
stay in the default config while `@curl//:curl` was transitioned, both
paths would reach `@openssl` at different configs, and Bazel's
`cc_shared_library` machinery would refuse to link the same `libssl`
built in two different configurations.

`--//:with_ssl=none` leaves `@curl//:ssl_lib` at its default since libcurl
isn't linked in that case.
 