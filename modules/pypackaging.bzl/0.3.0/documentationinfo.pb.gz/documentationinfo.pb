Ρ
pypackaging.bzl�pypackaging.markers.evaluate�Evaluates a parsed marker expression against an environment.

Semantics follow `packaging.markers.Marker.evaluate` (packaging 26.2):

- `python_version`, `python_full_version`, `implementation_version` and
  `platform_release` are compared as PEP 440 versions when `op + value` is a
  valid specifier (pre-releases always match). If it is not a valid
  specifier, the comparison falls back to the string table below; if the
  version being tested is not a valid version, the comparison is False,
  except for `===`, which compares the strings case-insensitively. A
  `python_full_version` ending in "+" gets "local" appended first.
- All other comparisons use upstream's string table: `==`, `!=`, `in` and
  `not in` as usual, `<` and `>` are always False, `<=` and `>=` mean
  equality, and `~=` and `===` fail ("Undefined comparison").
- `extra`, `extras` and `dependency_groups` values are normalized (PEP 685
  / PEP 735) on both sides.

There is no default environment: every variable the marker references must
be present, except `extra`, which defaults to "" (None is also treated as
""). Callers must supply `extras` / `dependency_groups` (as lists of
strings) when markers use them.

Non-standard extension (uv-compatible): `environment["extra"]` may be a
list or tuple of strings, the set of active extras (uv also uses this for
its conflict tokens). Each element is normalized. `extra == X` and
`X == extra` are True iff X is in the set; `!=` is True iff it is not. An
empty list therefore makes `==` False and `!=` True. Any other operator
(including `===`, which fails for a string `extra` too) fails.
*�
�
pypackaging.markers.evaluatef
markersWThe parsed marker tree (list), as returned by `parse`. An
empty list evaluates to True. (T
environmentAA dict mapping marker variable names (underscore form)
to values. (�Evaluates a parsed marker expression against an environment.

Semantics follow `packaging.markers.Marker.evaluate` (packaging 26.2):

- `python_version`, `python_full_version`, `implementation_version` and
  `platform_release` are compared as PEP 440 versions when `op + value` is a
  valid specifier (pre-releases always match). If it is not a valid
  specifier, the comparison falls back to the string table below; if the
  version being tested is not a valid version, the comparison is False,
  except for `===`, which compares the strings case-insensitively. A
  `python_full_version` ending in "+" gets "local" appended first.
- All other comparisons use upstream's string table: `==`, `!=`, `in` and
  `not in` as usual, `<` and `>` are always False, `<=` and `>=` mean
  equality, and `~=` and `===` fail ("Undefined comparison").
- `extra`, `extras` and `dependency_groups` values are normalized (PEP 685
  / PEP 735) on both sides.

There is no default environment: every variable the marker references must
be present, except `extra`, which defaults to "" (None is also treated as
""). Callers must supply `extras` / `dependency_groups` (as lists of
strings) when markers use them.

Non-standard extension (uv-compatible): `environment["extra"]` may be a
list or tuple of strings, the set of active extras (uv also uses this for
its conflict tokens). Each element is normalized. `extra == X` and
`X == extra` are True iff X is in the set; `!=` is True iff it is not. An
empty list therefore makes `==` False and `!=` True. Any other operator
(including `===`, which fails for a string `extra` too) fails.
"8
6True if the markers evaluate to true, False otherwise.2=
evaluate_markers)//pypackaging/private/markers:markers.bzlh
f
markersWThe parsed marker tree (list), as returned by `parse`. An
empty list evaluates to True. (V
T
environmentAA dict mapping marker variable names (underscore form)
to values. (�pypackaging.markers.parse�Parses a PEP 508 marker string into an AST-like structure.

The grammar, error conditions and value processing follow
`packaging.markers.Marker` (packaging 26.2): quoted strings are decoded like
Python string literals (`\N{...}` escapes are not supported), dotted
variable names are mapped to their underscore form, `python_implementation`
is an alias for `platform_python_implementation`, and the value compared
against `extra` is normalized (PEP 685) at every nesting level.

Unlike upstream, an empty or whitespace-only string is accepted and
returns `[]`, which `evaluate` treats as always true.

Invalid input fails with an upstream-style message that shows the marker
and a caret at the error position.
*�	
�	
pypackaging.markers.parse-

marker_strThe marker string to parse. (�Parses a PEP 508 marker string into an AST-like structure.

The grammar, error conditions and value processing follow
`packaging.markers.Marker` (packaging 26.2): quoted strings are decoded like
Python string literals (`\N{...}` escapes are not supported), dotted
variable names are mapped to their underscore form, `python_implementation`
is an alias for `platform_python_implementation`, and the value compared
against `extra` is normalized (PEP 685) at every nesting level.

Unlike upstream, an empty or whitespace-only string is accepted and
returns `[]`, which `evaluate` treats as always true.

Invalid input fails with an upstream-style message that shows the marker
and a caret at the error position.
"�
�A list representing the parsed marker tree. Each comparison is a tuple
`(lhs, op, rhs)` where `lhs`/`rhs` are `struct(type, value)` with
`type` either "variable" or "string" and `op` a string such as "==",
"in" or "not in"; boolean operators are the strings "and"/"or"; and
parenthesized groups are nested lists.29
parse_marker)//pypackaging/private/markers:markers.bzl/
-

marker_strThe marker string to parse. (�pypackaging.markers.to_string�Serializes a parsed marker tree like upstream `str(Marker)`.

Variables and `extra` values are emitted in their normalized form, string
values are double-quoted, and redundant outer parentheses around a group
are dropped.
*�
�
pypackaging.markers.to_string3
markers$A parsed marker tree (from `parse`). (�Serializes a parsed marker tree like upstream `str(Marker)`.

Variables and `extra` values are emitted in their normalized form, string
values are double-quoted, and redundant outer parentheses around a group
are dropped.
"6
4The normalized marker string ("" for an empty tree).2=
marker_to_string)//pypackaging/private/markers:markers.bzl5
3
markers$A parsed marker tree (from `parse`). (�pypackaging.requirements.parse�Parses a PEP 508 requirement (dependency specifier) string.

Accepts and rejects exactly what `packaging.requirements.Requirement`
(packaging 26.2) does, failing with an upstream-style message that shows
the input and a caret at the error position.

Differences from upstream's `Requirement` object:

- `name` is normalized (`utils.canonicalize_name`), and `extras` is a
  sorted, de-duplicated list of normalized extra names. The names as
  written are in `raw_name` and `raw_extras`.
- `specifier` is the result of `specifiers.parse_set` for name-based
  requirements (with no specifiers it has an empty `specs` list), but
  `None` for URL requirements.
- `marker` is the parsed marker tree (see `markers.parse`), or `None` when
  the requirement has no marker. `marker_str` is the marker text exactly as
  written (without surrounding whitespace), or `None`.
*�
�
pypackaging.requirements.parse/
req_str The requirement string to parse. (�Parses a PEP 508 requirement (dependency specifier) string.

Accepts and rejects exactly what `packaging.requirements.Requirement`
(packaging 26.2) does, failing with an upstream-style message that shows
the input and a caret at the error position.

Differences from upstream's `Requirement` object:

- `name` is normalized (`utils.canonicalize_name`), and `extras` is a
  sorted, de-duplicated list of normalized extra names. The names as
  written are in `raw_name` and `raw_extras`.
- `specifier` is the result of `specifiers.parse_set` for name-based
  requirements (with no specifiers it has an empty `specs` list), but
  `None` for URL requirements.
- `marker` is the parsed marker tree (see `markers.parse`), or `None` when
  the requirement has no marker. `marker_str` is the marker text exactly as
  written (without surrounding whitespace), or `None`.
"�
�A struct with fields:
name: The normalized project name.
raw_name: The project name as written.
url: The URL for `name @ url` requirements, else None.
extras: Sorted list of unique, normalized extras.
raw_extras: Sorted list of unique extras as written.
specifier: A specifier set struct, or None for URL requirements.
marker: The parsed marker tree, or None.
marker_str: The raw marker string, or None.
req_str: The input string with surrounding whitespace stripped.2I
_parse_requirement3//pypackaging/private/requirements:requirements.bzl1
/
req_str The requirement string to parse. (�"pypackaging.requirements.to_string�Serializes a parsed requirement like upstream `str(Requirement)`.

The project name and extras are emitted as originally written (extras
sorted and de-duplicated), specifiers are sorted and de-duplicated, and the
marker is normalized with `markers.to_string`.
*�
�
"pypackaging.requirements.to_string4
req)A requirement struct returned by `parse`. (�Serializes a parsed requirement like upstream `str(Requirement)`.

The project name and extras are emitted as originally written (extras
sorted and de-duplicated), specifiers are sorted and de-duplicated, and the
marker is normalized with `markers.to_string`.
"$
"The normalized requirement string.2M
_requirement_to_string3//pypackaging/private/requirements:requirements.bzl6
4
req)A requirement struct returned by `parse`. (�
pypackaging.specifiers.contains�Checks if a version satisfies a specifier.

This is upstream's `Specifier.contains`. Pre-releases are accepted unless
`prereleases` is False: there are no other candidates to prefer, so the
PEP 440 rule to exclude them doesn't apply. A `version` that is not a valid
PEP 440 version never matches, except that `===` compares it as a string.
*�
�
pypackaging.specifiers.contains!
specThe specifier struct. (V
versionGThe version to check: a string or a struct returned by
`version.parse`. (k
prereleasesTIf False, pre-release versions never match. None (the
default) and True accept them.None(�Checks if a version satisfies a specifier.

This is upstream's `Specifier.contains`. Pre-releases are accepted unless
`prereleases` is False: there are no other candidates to prefer, so the
PEP 440 rule to exclude them doesn't apply. A `version` that is not a valid
PEP 440 version never matches, except that `===` compares it as a string.
"?
=True if the version satisfies the specifier, False otherwise.2E
specifier_contains///pypackaging/private/specifiers:specifiers.bzl#
!
specThe specifier struct. (X
V
versionGThe version to check: a string or a struct returned by
`version.parse`. (m
k
prereleasesTIf False, pre-release versions never match. None (the
default) and True accept them.None(�pypackaging.specifiers.filter�Filters versions that satisfy a specifier.

This is upstream's `Specifier.filter`. With `prereleases = None`, whether
pre-releases are included comes from `prereleases(spec)`; if that is not
True, matching pre-releases are only returned when no matching final
release (or post-release) was found.
*�
�
pypackaging.specifiers.filter!
specThe specifier struct. (�
versions�A list of versions: strings or structs returned by
`version.parse`. Strings that are not valid PEP 440 versions only
match `===`. (}
prereleasesfTrue to include pre-releases, False to exclude them, or
None for the default behavior described above.None(�Filters versions that satisfy a specifier.

This is upstream's `Specifier.filter`. With `prereleases = None`, whether
pre-releases are included comes from `prereleases(spec)`; if that is not
True, matching pre-releases are only returned when no matching final
release (or post-release) was found.
"-
+The matching items of `versions`, in order.2C
specifier_filter///pypackaging/private/specifiers:specifiers.bzl#
!
specThe specifier struct. (�
�
versions�A list of versions: strings or structs returned by
`version.parse`. Strings that are not valid PEP 440 versions only
match `===`. (
}
prereleasesfTrue to include pre-releases, False to exclude them, or
None for the default behavior described above.None(�pypackaging.specifiers.parse!Parses a single specifier string.*�
�
pypackaging.specifiers.parse[
spec_strKThe specifier string to parse. Fails if it isn't a valid
PEP 440 specifier. (!Parses a single specifier string."�
�A struct representing the parsed specifier, with these fields:

* `operator`: one of `~=`, `==`, `!=`, `<=`, `>=`, `<`, `>`, `===`.
* `version`: the version string as written (e.g. `1.0`, `1.0.*`).
* `parsed_version`: the parsed version (see `version.parse`), without
  the `.*` suffix for wildcard specifiers. None for `===`.2B
parse_specifier///pypackaging/private/specifiers:specifiers.bzl]
[
spec_strKThe specifier string to parse. Fails if it isn't a valid
PEP 440 specifier. (� pypackaging.specifiers.parse_set�Parses a comma-separated set of specifiers.

Like `packaging.specifiers.SpecifierSet`, empty items are ignored, so
`">=1.0,"`, `">=1.0,,<2"` and `" "` are accepted.
*�
�
 pypackaging.specifiers.parse_set6
spec_set_str"The specifier set string to parse. (�Parses a comma-separated set of specifiers.

Like `packaging.specifiers.SpecifierSet`, empty items are ignored, so
`">=1.0,"`, `">=1.0,,<2"` and `" "` are accepted.
"W
UA struct with a `specs` field: the list of parsed specifiers (see
`parse`), in order.2F
parse_specifier_set///pypackaging/private/specifiers:specifiers.bzl8
6
spec_set_str"The specifier set string to parse. (�"pypackaging.specifiers.prereleases�Returns whether a specifier implies that pre-releases are allowed.

This is upstream's `Specifier.prereleases` for a specifier constructed
without an explicit `prereleases` argument: False for `!=` and for `==`
with a wildcard, None for `===` with a version that isn't valid PEP 440,
and otherwise whether the specifier's version is a pre-release.
*�
�
"pypackaging.specifiers.prereleases!
specThe specifier struct. (�Returns whether a specifier implies that pre-releases are allowed.

This is upstream's `Specifier.prereleases` for a specifier constructed
without an explicit `prereleases` argument: False for `!=` and for `==`
with a wildcard, None for `===` with a version that isn't valid PEP 440,
and otherwise whether the specifier's version is a pre-release.
"
True, False, or None.2H
specifier_prereleases///pypackaging/private/specifiers:specifiers.bzl#
!
specThe specifier struct. (�#pypackaging.specifiers.set_contains�Checks if a version satisfies all specifiers in the set.

This is upstream's `SpecifierSet.contains`. Pre-releases are accepted unless
`prereleases` is False. A `version` that is not a valid PEP 440 version
only matches if every specifier in the set is `===` and matches it as a
string. An empty set matches everything.
*�	
�
#pypackaging.specifiers.set_contains)
spec_setThe specifier set struct. (V
versionGThe version to check: a string or a struct returned by
`version.parse`. (k
prereleasesTIf False, pre-release versions never match. None (the
default) and True accept them.None(_
	installedJIf True, a pre-release version is accepted even if
`prereleases` is False.None(�Checks if a version satisfies all specifiers in the set.

This is upstream's `SpecifierSet.contains`. Pre-releases are accepted unless
`prereleases` is False. A `version` that is not a valid PEP 440 version
only matches if every specifier in the set is `===` and matches it as a
string. An empty set matches everything.
"@
>True if the version satisfies all specifiers, False otherwise.2I
specifier_set_contains///pypackaging/private/specifiers:specifiers.bzl+
)
spec_setThe specifier set struct. (X
V
versionGThe version to check: a string or a struct returned by
`version.parse`. (m
k
prereleasesTIf False, pre-release versions never match. None (the
default) and True accept them.None(a
_
	installedJIf True, a pre-release version is accepted even if
`prereleases` is False.None(�!pypackaging.specifiers.set_filter�Filters versions that satisfy all specifiers in the set.

This is upstream's `SpecifierSet.filter`. With `prereleases = None`,
pre-releases are included if `set_prereleases(spec_set)` is True;
otherwise matching pre-releases are only returned when no matching final
release (or post-release) was found, as PEP 440 recommends.
*�

�
!pypackaging.specifiers.set_filter)
spec_setThe specifier set struct. (�
versions�A list of versions: strings or structs returned by
`version.parse`. Strings that are not valid PEP 440 versions only
match if every specifier is `===` (or the set is empty), and are
never treated as pre-releases. (}
prereleasesfTrue to include pre-releases, False to exclude them, or
None for the default behavior described above.None(�Filters versions that satisfy all specifiers in the set.

This is upstream's `SpecifierSet.filter`. With `prereleases = None`,
pre-releases are included if `set_prereleases(spec_set)` is True;
otherwise matching pre-releases are only returned when no matching final
release (or post-release) was found, as PEP 440 recommends.
"-
+The matching items of `versions`, in order.2G
specifier_set_filter///pypackaging/private/specifiers:specifiers.bzl+
)
spec_setThe specifier set struct. (�
�
versions�A list of versions: strings or structs returned by
`version.parse`. Strings that are not valid PEP 440 versions only
match if every specifier is `===` (or the set is empty), and are
never treated as pre-releases. (
}
prereleasesfTrue to include pre-releases, False to exclude them, or
None for the default behavior described above.None(�&pypackaging.specifiers.set_prereleases�Returns whether a specifier set implies that pre-releases are allowed.

This is upstream's `SpecifierSet.prereleases` for a set constructed without
an explicit `prereleases` argument: True if any specifier implies
pre-releases (see `prereleases`), otherwise None.
*�
�
&pypackaging.specifiers.set_prereleases)
spec_setThe specifier set struct. (�Returns whether a specifier set implies that pre-releases are allowed.

This is upstream's `SpecifierSet.prereleases` for a set constructed without
an explicit `prereleases` argument: True if any specifier implies
pre-releases (see `prereleases`), otherwise None.
"
True or None.2L
specifier_set_prereleases///pypackaging/private/specifiers:specifiers.bzl+
)
spec_setThe specifier set struct. (�pypackaging.tags.get_supported�Return a list of supported tags, most preferred first.

A port of pip's `get_supported()` (`pip/_internal/utils/compatibility_tags.py`)
on top of packaging's `cpython_tags()`, `generic_tags()` and
`compatible_tags()`. Each requested platform is expanded into the
platforms it is compatible with, as pip does for `--platform`:

* `macosx*_X_Y_<arch>`: packaging's `mac_platforms((X, Y), arch)`. As in
  pip, a custom prefix such as `macosxcustom_` is kept.
* `ios*_X_Y_<multiarch>`: packaging's `ios_platforms()`, likewise.
* `android_N_<abi>`: packaging's `android_platforms()`.

Differences from pip, all because this runs at analysis time without a
host interpreter:

* `manylinux_X_Y_<arch>`, legacy `manylinux1/2010/2014_<arch>` and
  `musllinux_X_Y_<arch>` are fully expanded, as packaging does for the host
  platform in `_linux_platforms()`: every older glibc/musl version, the
  legacy aliases, an `armv8l` -> `armv7l` fallback, and finally
  `linux_<arch>` (after all other expanded platforms). pip only maps
  `manylinux2014` -> `manylinux2010`/`manylinux1` and `manylinux2010` ->
  `manylinux1`. As in packaging, nothing older than glibc 2.17 is emitted
  on architectures other than x86_64/i686, so `manylinux2010_aarch64`
  expands to just `linux_aarch64`.
* `platforms=None`, `[]`, or platforms that all expand to nothing (e.g.
  `macosx_9_0_x86_64`) mean `["any"]`, and `abis=None` means no
  interpreter-specific ABIs; pip uses the host's platforms and ABIs.
  `version` is required and `impl` defaults to `"cp"`.
* Every `"abi3"` and `"none"` entry in `abis` is ignored for CPython;
  packaging only removes the first occurrence of each.

Tags are lowercase, like packaging's `Tag`.
*�
�
pypackaging.tags.get_supported;
version(The Python version string (e.g., "311").None(1
	platformsA list of allowed platforms.None(C
impl3The interpreter implementation prefix (e.g., "cp").None(
abisA list of ABIs.None(�Return a list of supported tags, most preferred first.

A port of pip's `get_supported()` (`pip/_internal/utils/compatibility_tags.py`)
on top of packaging's `cpython_tags()`, `generic_tags()` and
`compatible_tags()`. Each requested platform is expanded into the
platforms it is compatible with, as pip does for `--platform`:

* `macosx*_X_Y_<arch>`: packaging's `mac_platforms((X, Y), arch)`. As in
  pip, a custom prefix such as `macosxcustom_` is kept.
* `ios*_X_Y_<multiarch>`: packaging's `ios_platforms()`, likewise.
* `android_N_<abi>`: packaging's `android_platforms()`.

Differences from pip, all because this runs at analysis time without a
host interpreter:

* `manylinux_X_Y_<arch>`, legacy `manylinux1/2010/2014_<arch>` and
  `musllinux_X_Y_<arch>` are fully expanded, as packaging does for the host
  platform in `_linux_platforms()`: every older glibc/musl version, the
  legacy aliases, an `armv8l` -> `armv7l` fallback, and finally
  `linux_<arch>` (after all other expanded platforms). pip only maps
  `manylinux2014` -> `manylinux2010`/`manylinux1` and `manylinux2010` ->
  `manylinux1`. As in packaging, nothing older than glibc 2.17 is emitted
  on architectures other than x86_64/i686, so `manylinux2010_aarch64`
  expands to just `linux_aarch64`.
* `platforms=None`, `[]`, or platforms that all expand to nothing (e.g.
  `macosx_9_0_x86_64`) mean `["any"]`, and `abis=None` means no
  interpreter-specific ABIs; pip uses the host's platforms and ABIs.
  `version` is required and `impl` defaults to `"cp"`.
* Every `"abi3"` and `"none"` entry in `abis` is ignored for CPython;
  packaging only removes the first occurrence of each.

Tags are lowercase, like packaging's `Tag`.
"&
$A list of compatibility tag strings.24
get_supported#//pypackaging/private/tags:tags.bzl=
;
version(The Python version string (e.g., "311").None(3
1
	platformsA list of allowed platforms.None(E
C
impl3The interpreter implementation prefix (e.g., "cp").None(!

abisA list of ABIs.None(�pypackaging.tags.parse_tag�Parses the provided tag into a list of Tag structs.

A compressed tag set such as `py2.py3-none-any` expands to one Tag per
combination. packaging returns a `frozenset`; this returns a list without
duplicates, in the order the components appear in the tag. Tag structs
have `interpreter`, `abi` and `platform` fields, are lowercased like
packaging's `Tag`, and compare equal by value.

Like packaging, empty components (e.g. `py3--any`) are not rejected; they
produce tags with empty fields that never match a supported tag.
*�
�
pypackaging.tags.parse_tag3
tag(The tag to parse (e.g., "py3-none-any"). (a
validate_orderFWhether to check if compressed tag set components are in sorted order.False(�Parses the provided tag into a list of Tag structs.

A compressed tag set such as `py2.py3-none-any` expands to one Tag per
combination. packaging returns a `frozenset`; this returns a list without
duplicates, in the order the components appear in the tag. Tag structs
have `interpreter`, `abi` and `platform` fields, are lowercased like
packaging's `Tag`, and compare equal by value.

Like packaging, empty components (e.g. `py3--any`) are not rejected; they
produce tags with empty fields that never match a supported tag.
"
A list of Tag structs.20
	parse_tag#//pypackaging/private/tags:tags.bzl5
3
tag(The tag to parse (e.g., "py3-none-any"). (c
a
validate_orderFWhether to check if compressed tag set components are in sorted order.False(�	pypackaging.tags.priority_map�Builds a `{tag string: rank}` map from an ordered list of supported tags.

Rank 0 is the most preferred tag. If a tag appears more than once, its
first (best) rank is kept. Build the map once and reuse it with
`select_compatible`, or look up `tag_str(tag)` directly, instead of
scanning the supported tag list for every candidate.
*�
�
pypackaging.tags.priority_map�
	supported�An ordered list of supported tags, most preferred first, as
returned by `get_supported`. Entries may be tag strings (which are
lowercased) or Tag structs. Compressed tag sets are not expanded. (�Builds a `{tag string: rank}` map from an ordered list of supported tags.

Rank 0 is the most preferred tag. If a tag appears more than once, its
first (best) rank is kept. Build the map once and reuse it with
`select_compatible`, or look up `tag_str(tag)` directly, instead of
scanning the supported tag list for every candidate.
"-
+A dict mapping each tag string to its rank.23
priority_map#//pypackaging/private/tags:tags.bzl�
�
	supported�An ordered list of supported tags, most preferred first, as
returned by `get_supported`. Entries may be tag strings (which are
lowercased) or Tag structs. Compressed tag sets are not expanded. (�"pypackaging.tags.select_compatible�Orders things by their best-matching supported tag.

A port of packaging's `create_compatible_tags_selector()`. Things with no
supported tag are dropped. The rest are sorted by the rank of their best
supported tag; ties keep their input order. To pick the best wheel, take
the first element of the result.
*�

�
"pypackaging.tags.select_compatible�
	supported�An ordered list of supported tags (most preferred first), or
a map returned by `priority_map`. Pass a precomputed map when
calling this repeatedly with the same supported tags. (�
tagged�A list of `(thing, tags)` tuples, where `tags` is a list of Tag
structs (e.g. `parse_wheel_filename(f).tags`) or tag strings.
Compressed tag strings such as `py2.py3-none-any` are expanded
with `parse_tag`. (�Orders things by their best-matching supported tag.

A port of packaging's `create_compatible_tags_selector()`. Things with no
supported tag are dropped. The rest are sorted by the rank of their best
supported tag; ties keep their input order. To pick the best wheel, take
the first element of the result.
"*
(The compatible things, best match first.28
select_compatible#//pypackaging/private/tags:tags.bzl�
�
	supported�An ordered list of supported tags (most preferred first), or
a map returned by `priority_map`. Pass a precomputed map when
calling this repeatedly with the same supported tags. (�
�
tagged�A list of `(thing, tags)` tuples, where `tags` is a list of Tag
structs (e.g. `parse_wheel_filename(f).tags`) or tag strings.
Compressed tag strings such as `py2.py3-none-any` are expanded
with `parse_tag`. (�pypackaging.tags.tag_strCReturns the `interpreter-abi-platform` string form of a Tag struct.*�
�
pypackaging.tags.tag_str4
tag)A Tag struct, as returned by `parse_tag`. (CReturns the `interpreter-abi-platform` string form of a Tag struct."&
$The tag string, e.g. "py3-none-any".2.
tag_str#//pypackaging/private/tags:tags.bzl6
4
tag)A Tag struct, as returned by `parse_tag`. (�#pypackaging.utils.canonicalize_name�Takes a valid Python package or extra name, and returns the normalized form of it.

Lowercases the name and replaces runs of `-`, `_` and `.` with a single `-`
(PEP 503). Starlark's `lower()` only lowercases ASCII letters, so unlike
packaging, non-ASCII letters are left unchanged. Valid distribution names
are ASCII-only, so this only matters when `validate` is False.
*�
�
#pypackaging.utils.canonicalize_name"
nameThe name to normalize. (�
validate�If True, `fail()` unless `name` is a valid distribution name
per the core metadata spec (ASCII letters and digits, with `.`,
`_` and `-` allowed except at the start and end), like packaging
raising `InvalidName`.False(�Takes a valid Python package or extra name, and returns the normalized form of it.

Lowercases the name and replaces runs of `-`, `_` and `.` with a single `-`
(PEP 503). Starlark's `lower()` only lowercases ASCII letters, so unlike
packaging, non-ASCII letters are left unchanged. Valid distribution names
are ASCII-only, so this only matters when `validate` is False.
"
The normalized name.2:
canonicalize_name%//pypackaging/private/utils:utils.bzl$
"
nameThe name to normalize. (�
�
validate�If True, `fail()` unless `name` is a valid distribution name
per the core metadata spec (ASCII letters and digits, with `.`,
`_` and `-` allowed except at the start and end), like packaging
raising `InvalidName`.False(�	&pypackaging.utils.canonicalize_version�Return a canonical form of a version as a string.

With `strip_trailing_zero = False`, the result is the normalized PEP 440
form, i.e. packaging's `str(Version(...))`.
*�
�
&pypackaging.utils.canonicalize_version�
version_input�The version to canonicalize (string or Version struct).
A string that isn't a valid PEP 440 version is returned unchanged,
like packaging. Leading and trailing whitespace is ignored. (n
strip_trailing_zeroOWhether to strip trailing zeros from the release
segment (e.g. "1.0.0" -> "1").True(�Return a canonical form of a version as a string.

With `strip_trailing_zero = False`, the result is the normalized PEP 440
form, i.e. packaging's `str(Version(...))`.
"#
!The canonicalized version string.2=
canonicalize_version%//pypackaging/private/utils:utils.bzl�
�
version_input�The version to canonicalize (string or Version struct).
A string that isn't a valid PEP 440 version is returned unchanged,
like packaging. Leading and trailing whitespace is ignored. (p
n
strip_trailing_zeroOWhether to strip trailing zeros from the release
segment (e.g. "1.0.0" -> "1").True(�$pypackaging.utils.is_normalized_name�Check if a name is already normalized.

A normalized name is lowercase ASCII letters and digits separated by
single `-`. packaging 26.2's regex also accepts `--` after a
one-character first segment (`a--b`, `a--b-c`); this function doesn't,
since `canonicalize_name` never produces it.
*�
�
$pypackaging.utils.is_normalized_name
nameThe name to check. (�Check if a name is already normalized.

A normalized name is lowercase ASCII letters and digits separated by
single `-`. packaging 26.2's regex also accepts `--` after a
one-character first segment (`a--b`, `a--b-c`); this function doesn't,
since `canonicalize_name` never produces it.
"&
$True if normalized, False otherwise.2;
is_normalized_name%//pypackaging/private/utils:utils.bzl 

nameThe name to check. (�&pypackaging.utils.parse_sdist_filename�Parses the filename of a sdist file.

The returned struct has these fields:

* `name`: the project name, normalized with `canonicalize_name`.
* `version`: the Version struct. Its `version_str` field is the version
  text exactly as it appears in the filename. For the normalized form, use
  `version.to_string(version)`.
*�
�
&pypackaging.utils.parse_sdist_filename&
filenameThe filename to parse. (�Parses the filename of a sdist file.

The returned struct has these fields:

* `name`: the project name, normalized with `canonicalize_name`.
* `version`: the Version struct. Its `version_str` field is the version
  text exactly as it appears in the filename. For the normalized form, use
  `version.to_string(version)`.
"'
%A struct containing name and version.2=
parse_sdist_filename%//pypackaging/private/utils:utils.bzl(
&
filenameThe filename to parse. (�&pypackaging.utils.parse_wheel_filename�Parses the filename of a wheel file.

The returned struct has these fields:

* `name`: the project name, normalized with `canonicalize_name`.
* `version`: the Version struct. Its `version_str` field is the version
  text exactly as it appears in the filename (e.g. `1.0.0.RC1`). For the
  normalized form (packaging's `str(version)`, e.g. `1.0.0rc1`), use
  `version.to_string(version)`.
* `build`: `()` or a `(number, suffix)` build tag tuple, e.g. `(1, "abc")`.
* `tags`: a list of Tag structs, as returned by `tags.parse_tag`.

Like packaging, the project name may contain non-ASCII characters. Any
non-ASCII character is accepted, where packaging only accepts Unicode
word characters.
*�	
�
&pypackaging.utils.parse_wheel_filename&
filenameThe filename to parse. (m
validate_orderRWhether to fail if compressed tag set components
aren't in sorted order (PEP 425).False(�Parses the filename of a wheel file.

The returned struct has these fields:

* `name`: the project name, normalized with `canonicalize_name`.
* `version`: the Version struct. Its `version_str` field is the version
  text exactly as it appears in the filename (e.g. `1.0.0.RC1`). For the
  normalized form (packaging's `str(version)`, e.g. `1.0.0rc1`), use
  `version.to_string(version)`.
* `build`: `()` or a `(number, suffix)` build tag tuple, e.g. `(1, "abc")`.
* `tags`: a list of Tag structs, as returned by `tags.parse_tag`.

Like packaging, the project name may contain non-ASCII characters. Any
non-ASCII character is accepted, where packaging only accepts Unicode
word characters.
"5
3A struct containing name, version, build, and tags.2=
parse_wheel_filename%//pypackaging/private/utils:utils.bzl(
&
filenameThe filename to parse. (o
m
validate_orderRWhether to fail if compressed tag set components
aren't in sorted order (PEP 425).False(�"pypackaging.version.get_public_key�Returns the sort key of a version without its local segment.

This is the `key` of upstream's `Version.public`: `1.0+abc` and `1.0`
have the same public key.
*�
�
"pypackaging.version.get_public_key.
v%A version struct returned by `parse`. (�Returns the sort key of a version without its local segment.

This is the `key` of upstream's `Version.public`: `1.0+abc` and `1.0`
have the same public key.
"@
>A sort key, comparable with the `key` field of other versions.2;
get_public_key)//pypackaging/private/version:version.bzl0
.
v%A version struct returned by `parse`. (�pypackaging.version.parsevParses a version string into a struct.

Leading and trailing whitespace is ignored, like `packaging.version.Version`.
*�
�
pypackaging.version.parseZ
version_strGThe version string to parse. Fails if it isn't a valid
PEP 440 version. (vParses a version string into a struct.

Leading and trailing whitespace is ignored, like `packaging.version.Version`.
"�
�A struct representing the parsed version, with these fields:

* `version_str`: the input string without surrounding whitespace.
* `epoch`: the epoch as an int.
* `release`: the release segment as a tuple of ints.
* `pre`: `("a" | "b" | "rc", int)` or None.
* `post`: `("post", int)` or None.
* `dev`: `("dev", int)` or None.
* `local`: the local segment as a tuple of lowercase strings and ints,
  or None.
* `key`: a sort key. Compare keys to compare versions.
* `is_prerelease`, `is_postrelease`, `is_devrelease`: bools.2:
parse_version)//pypackaging/private/version:version.bzl\
Z
version_strGThe version string to parse. Fails if it isn't a valid
PEP 440 version. (�pypackaging.version.to_string�Returns the normalized string form of a parsed version.

This is upstream's `str(Version)`, e.g. `1.0.0-RC1` becomes `1.0.0rc1` and
`v1!2.0-post3` becomes `1!2.0.post3`. Trailing zeros are kept.
*�
�
pypackaging.version.to_string.
v%A version struct returned by `parse`. (�Returns the normalized string form of a parsed version.

This is upstream's `str(Version)`, e.g. `1.0.0-RC1` becomes `1.0.0rc1` and
`v1!2.0-post3` becomes `1!2.0.post3`. Trailing zeros are kept.
" 
The normalized version string.2>
version_to_string)//pypackaging/private/version:version.bzl0
.
v%A version struct returned by `parse`. (�pypackaging.version.try_parseKLike `parse_version`, but returns None instead of failing on invalid input.*�
�
pypackaging.version.try_parse/
version_strThe version string to parse. (KLike `parse_version`, but returns None instead of failing on invalid input."d
bA struct representing the parsed version, or None if `version_str` is
not a valid PEP 440 version.2>
try_parse_version)//pypackaging/private/version:version.bzl1
/
version_strThe version string to parse. ('Python packaging utilities in Starlark. 