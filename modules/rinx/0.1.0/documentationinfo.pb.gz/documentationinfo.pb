�

rinxrulesdoctest.bzl�
rinx_doctest_tests0Defines the doctest test for one `rinx_library`.*�	
�	
rinx_doctest_tests,
name Name of the generated `py_test`. (�
lib�The `rinx_library` whose documents to test. Every document it
owns is tested; its `deps` are not, since each library carries the test
target for its own documents. (�
py_deps�`py_library` targets to put on the path, so documented code is
importable. This is rules_python's ordinary `deps`, surfaced — not a
third dependency mechanism of rinx's own. Note it is unrelated
to `rinx_library`'s `deps`, which is strictly about toctrees.None(�
global_setup�A `.py` file run before every group, Sphinx's
`doctest_global_setup`. A file label rather than a config field,
because sandboxes relocate paths (see ADR-001).None(=
global_cleanup#A `.py` file run after every group.None(�
sizesBazel test size; `small` (60s) by default. A doctest that needs
longer is usually a doctest that should not be one."small"(b
tagsRApplied to the generated test, e.g. `manual` to keep it out of
`bazel test //...`.None(H
kwargs<Passed to the generated `py_test` (`timeout`, `flaky`, …).(0Defines the doctest test for one `rinx_library`.2/
rinx_doctest_tests@@rinx//rules:doctest.bzl
22*py_test2py_testi
//python:defs.bzlrR
 
rules_pythonpythondefs.bzl 
py_testpy_test
0)00
002�rinx_doctest_tests macro.

Runs the doctest blocks of a `rinx_library`'s documents as one Bazel
test. See `docs/decisions/002-doctest-execution.md` for the full rationale; the
notes below are what you need before editing this file.

# Why one test per library, not per document

`rinx_library` is the unit of ownership everywhere else in this ruleset,
exactly like `cc_library`, and a macro cannot read its providers at loading
time. Testing per document therefore meant repeating the document list in the
BUILD file and connecting the two sides by a duplicated naming convention. Per
library, the macro just consumes the library's aggregate `doctest_plans` output
group and neither duplication exists.

Someone who wants finer granularity splits the library, which is the same thing
they would do for any other reason â `examples/BUILD.bazel` keeps the one
document with executable content in its own `doctest_docs` library for exactly
this reason.

Two consequences, both accepted: editing test code in one document re-runs that
library's other documents too, and a library's documents share one interpreter,
so process-global side effects (`sys.modules`, `os.chdir`, monkeypatching) can
leak between them. Per-*group* namespaces are unaffected. The second moves
*closer* to Sphinx, whose `make doctest` runs a whole project in one process.

# Why a macro over stock `py_test`, and why a test at all

Both argued in full in the ADR. In short: a custom `rule(test = True)` would have
to reimplement rules_python's bootstrap for no gain, and running the doctests in
a build action instead would execute them under `bazel build //...`, lose
`--test_timeout`, and make `--cache_test_results=no` a silent no-op.

Bazel already caches test results on the test's runfiles, so when the only data
runfiles are the library's `.doctests.json` plans â whose bytes ignore prose,
`:hide:` and trim options â a prose edit leaves the key unchanged and
`bazel test` reports `(cached)` without starting an interpreter. The firewall is
the extraction step, which stays a build action.

# Keeping Python out of the build

The Python toolchain is a dependency of these test targets only. It must never
become one of `rinx_library` or `rinx_site`:
`bazel build //examples:site` has to stay buildable with no Python toolchain
registered. `tests/test_doctest_isolation.sh` enforces that.
�

rinxrulesinventory.bzl�rinx_inventory�
Declares a Sphinx inventory (`objects.inv`) a rinx_site may link into.

List it in the site's `inventories`; the site's index action reads it, and a
reference no document of the site defines is then resolved against it.
"�
�
rinx_inventory�
Declares a Sphinx inventory (`objects.inv`) a rinx_site may link into.

List it in the site's `inventories`; the site's index action reads it, and a
reference no document of the site defines is then resolved against it.
*
nameA unique name for this target. �
base_url�Where the inventory's pages are published. An absolute URL (`https://docs.python.org/3/`), or a path relative to the consuming site's root (`../api/`) for a site deployed next to it â each page's link is then made relative to that page. �
inventory_name�The name documents pick this inventory out by, as in :external+python:ref:`tut` or :ref:`python:tut`. Defaults to the target's name.2""�
src�The objects.inv file: a vendored copy, an `http_file` pinned by `sha256`, or a filegroup over another rinx_site's `inventory` output group. "-
rinx_inventory@@rinx//rules:inventory.bzl
,
*
nameA unique name for this target. �
�
base_url�Where the inventory's pages are published. An absolute URL (`https://docs.python.org/3/`), or a path relative to the consuming site's root (`../api/`) for a site deployed next to it â each page's link is then made relative to that page. �
�
inventory_name�The name documents pick this inventory out by, as in :external+python:ref:`tut` or :ref:`python:tut`. Defaults to the target's name.2""�
�
src�The objects.inv file: a vendored copy, an `http_file` pinned by `sha256`, or a filegroup over another rinx_site's `inventory` output group. o
:providers.bzlr[

rinxproviders.bzl4
RinxInventoryInfoRinxInventoryInfo
 1
3�
rinx_inventory rule.

Declares another documentation site's `objects.inv` as a pinned input a
rinx_site links into â Sphinx's `intersphinx_mapping`, minus the
fetch. Sphinx downloads an inventory while building; a sandboxed action may
not, so the file is an ordinary label instead: vendored, fetched by the
module system with a checksum (`http_file` with `sha256`), or another
rinx_site's `inventory` output group. Updating the pin is then an
explicit change to the build rather than something that happens to it.
�R

rinxruleslibrary.bzl�Prinx_library�
Parses a set of reStructuredText files into AST files (Phase 1).

Diagrams are opt-in with `diagrams = True`; see that attribute. Note this rule
does *not* compile them itself. A `.. needuml::` is expanded
against the project's entity graph, which only exists once every document has
been indexed, so diagram compilation belongs to `rinx_site` â and a
plain `.. plantuml::` goes the same way, because two compile paths would mean
two hash populations and the compiled set could drift from the validated one.

Each .rst file becomes an independently cacheable .ast file. Declare
strict structural dependencies (i.e. targets included in a `.. toctree::`) in `deps`.
Standard cross-references/hyperlinks do not need to be declared in `deps` as they are
resolved late during the site rendering phase.

Sources can be rendered as Jinja templates before parsing with `jinja = True`
â what a Sphinx project gets from a `source-read` hook in its `conf.py`. The
templates an `{% include %}` names are declared in `parse_data` and must not
also appear in `srcs`.

Files read while parsing go in `parse_data` â the data behind
`.. csv-table:: :file:`, the templates a Jinja `{% include %}` reads, and the
sources `.. include::`/`.. literalinclude::` splice in. That is unrelated to `deps`: it declares bytes the parser reads, not
another library. A `.. toctree::` written *inside* an included fragment still
needs its documents in `deps`, because toctree validation runs on the merged
AST. Pictures
shown by `.. image::`/`.. figure::` go in `images`, which is unrelated to both:
those bytes are read by neither the parser nor another library â they are
copied into the site and, when a document asks to embed one, inlined into it.
"�B
�(
rinx_library�
Parses a set of reStructuredText files into AST files (Phase 1).

Diagrams are opt-in with `diagrams = True`; see that attribute. Note this rule
does *not* compile them itself. A `.. needuml::` is expanded
against the project's entity graph, which only exists once every document has
been indexed, so diagram compilation belongs to `rinx_site` â and a
plain `.. plantuml::` goes the same way, because two compile paths would mean
two hash populations and the compiled set could drift from the validated one.

Each .rst file becomes an independently cacheable .ast file. Declare
strict structural dependencies (i.e. targets included in a `.. toctree::`) in `deps`.
Standard cross-references/hyperlinks do not need to be declared in `deps` as they are
resolved late during the site rendering phase.

Sources can be rendered as Jinja templates before parsing with `jinja = True`
â what a Sphinx project gets from a `source-read` hook in its `conf.py`. The
templates an `{% include %}` names are declared in `parse_data` and must not
also appear in `srcs`.

Files read while parsing go in `parse_data` â the data behind
`.. csv-table:: :file:`, the templates a Jinja `{% include %}` reads, and the
sources `.. include::`/`.. literalinclude::` splice in. That is unrelated to `deps`: it declares bytes the parser reads, not
another library. A `.. toctree::` written *inside* an included fragment still
needs its documents in `deps`, because toctree validation runs on the merged
AST. Pictures
shown by `.. image::`/`.. figure::` go in `images`, which is unrelated to both:
those bytes are read by neither the parser nor another library â they are
copied into the site and, when a document asks to embed one, inlined into it.
*
nameA unique name for this target. �
default_domain�The Sphinx domain (e.g. "py", "c") that bare, unprefixed directives and roles in this library's docs resolve to. This is a property of the library's content, not of any site that assembles it.2"py"�
depsyOther rinx_library targets that are structurally included via `.. toctree::`. Not required for standard cross-references.*

RinxInfo2[]�
diagrams�Whether this library's documents may hold PlantUML diagrams â `.. plantuml::`/`.. uml::`, `.. entity-diagram::`/`.. needuml::`, `.. entity-arch::`/`.. needarch::` and the generated `.. entity-flow::`/`.. needflow::` and `.. entity-sequence::`/`.. needsequence::`. Off by default so a library that draws nothing pays nothing: the site creates diagram actions only for documents of libraries that set this. A diagram written in a library without it fails the parse, naming this attribute. To keep the cost narrow, put diagram documents in a library of their own.2False�
entity_schema�The project's entity meta-model: the types, attributes, sections, relations and roles this library's documents may use. Read at *parse* time, since it is what makes `.. req::` a directive rather than an unknown name, so editing it re-parses every document here. Every library in a site and the site itself must name the same file â a mismatch is reported as `entity.schema-mismatch` when the index is built. Omit it for a project that declares no entities, which then behaves exactly as before this feature existed.2None�
images�Image files this library's documents show via `.. image::`/`.. figure::`. Paths in the document resolve relative to the document itself, or to the source root with a leading `/`. Declaring the file here is what gets it bundled into the site's `_images/` directory and, for a `:loading: embed` image, into the build action that inlines it; an undeclared image fails the site's image validation.2[]�
jinja�Whether this library's `.rst` sources are rendered as Jinja templates before they are parsed â the transform a Sphinx project gets by connecting the `source-read` event in its `conf.py`. Off by default, because a document is free to contain `{{` and `{%` as text and most projects mean nothing by them. The templates an `{% include %}` reads are declared in `parse_data`, like every other file the parser reads, and must not also appear in `srcs`.2False�
jinja_context�Names a Jinja-rendered source may read, the way a Sphinx project's `html_context` binds them. Values only; a name bound by neither this nor a `{% set %}` is reported rather than silently rendered as the empty string. Meaningless without `jinja = True`.
2{}�

parse_data�Files this library's documents read *at parse time*: the data behind `.. csv-table::`'s `:file:` option, and the sources spliced in by `.. include::` and `.. literalinclude::`. Paths in the document resolve relative to the file the directive was written in (the document, or an including fragment), or to the source root with a leading `/`; declaring the file here is what puts it in the parse action's sandbox. An `.rst` included this way must NOT also appear in `srcs` â that would additionally publish it as a page of its own.2[]B
srcs4reStructuredText source files owned by this library.2[]")
rinx_library@@rinx//rules:library.bzl
��,
*
nameA unique name for this target. �
�
default_domain�The Sphinx domain (e.g. "py", "c") that bare, unprefixed directives and roles in this library's docs resolve to. This is a property of the library's content, not of any site that assembles it.2"py"�
�
depsyOther rinx_library targets that are structurally included via `.. toctree::`. Not required for standard cross-references.*

RinxInfo2[]�
�
diagrams�Whether this library's documents may hold PlantUML diagrams â `.. plantuml::`/`.. uml::`, `.. entity-diagram::`/`.. needuml::`, `.. entity-arch::`/`.. needarch::` and the generated `.. entity-flow::`/`.. needflow::` and `.. entity-sequence::`/`.. needsequence::`. Off by default so a library that draws nothing pays nothing: the site creates diagram actions only for documents of libraries that set this. A diagram written in a library without it fails the parse, naming this attribute. To keep the cost narrow, put diagram documents in a library of their own.2False�
�
entity_schema�The project's entity meta-model: the types, attributes, sections, relations and roles this library's documents may use. Read at *parse* time, since it is what makes `.. req::` a directive rather than an unknown name, so editing it re-parses every document here. Every library in a site and the site itself must name the same file â a mismatch is reported as `entity.schema-mismatch` when the index is built. Omit it for a project that declares no entities, which then behaves exactly as before this feature existed.2None�
�
images�Image files this library's documents show via `.. image::`/`.. figure::`. Paths in the document resolve relative to the document itself, or to the source root with a leading `/`. Declaring the file here is what gets it bundled into the site's `_images/` directory and, for a `:loading: embed` image, into the build action that inlines it; an undeclared image fails the site's image validation.2[]�
�
jinja�Whether this library's `.rst` sources are rendered as Jinja templates before they are parsed â the transform a Sphinx project gets by connecting the `source-read` event in its `conf.py`. Off by default, because a document is free to contain `{{` and `{%` as text and most projects mean nothing by them. The templates an `{% include %}` reads are declared in `parse_data`, like every other file the parser reads, and must not also appear in `srcs`.2False�
�
jinja_context�Names a Jinja-rendered source may read, the way a Sphinx project's `html_context` binds them. Values only; a name bound by neither this nor a `{% set %}` is reported rather than silently rendered as the empty string. Meaningless without `jinja = True`.
2{}�
�

parse_data�Files this library's documents read *at parse time*: the data behind `.. csv-table::`'s `:file:` option, and the sources spliced in by `.. include::` and `.. literalinclude::`. Paths in the document resolve relative to the file the directive was written in (the document, or an including fragment), or to the source root with a leading `/`; declaring the file here is what puts it in the parse action's sandbox. An `.rst` included this way must NOT also appear in `srcs` â that would additionally publish it as a page of its own.2[]D
B
srcs4reStructuredText source files owned by this library.2[]]
:providers.bzlrI

rinxproviders.bzl"
RinxInfoRinxInfo
 (
*�
rinx_library rule.

Parses every .rst source file (Phase 1) into a .ast JSON file using the
rinx worker binary and propagates them via RinxInfo.
�#

rinxrulessite.bzl�!	rinx_site�
Assembles a complete documentation site from rinx_library deps.

Performs Phase 2 (global index, one action) and Phase 3 (per-file HTML
render, one action per .ast file).  All actions are individually cacheable
by Bazel.
"�
�
	rinx_site�
Assembles a complete documentation site from rinx_library deps.

Performs Phase 2 (global index, one action) and Phase 3 (per-file HTML
render, one action per .ast file).  All actions are individually cacheable
by Bazel.
*
nameA unique name for this target. \
config.The rinx.toml configuration file for the site.2 //:templates/default_config.tomlQ
css1The CSS stylesheet to include in the site output.2//:assets/default.cssG
deps-rinx_library targets to include in this site.*

RinxInfo2[]�
entity_schema�The project's entity meta-model. Must be the same file every `rinx_library` in `deps` names, since the documents were parsed against it; a mismatch is reported as `entity.schema-mismatch` while the index is built. Read here by the index action, which derives back-links from the declared relations, and by each render action, which reads the labels and presentation.2None�
entity_templates�Per-type entity presentation templates, rendered with MiniJinja. A schema's `template = "name.html"` refers to a file by its basename; listing it here is what puts it in the render action's sandbox. Omit for the built-in rendering, which every type gets without configuring anything. A template a type names but that is absent here fails the build rather than silently falling back.2[]�
inventories�rinx_inventory targets: other sites' objects.inv files this site links into (Sphinx's intersphinx). A reference no document defines is resolved against them, in the order listed; `:external+name:` and a `name:` prefix pick one out. Read by the index action alone, so editing one re-runs the index and every render, as any index input does.*
RinxInventoryInfo2[]�
strict_links�If True, a broken cross-reference (:ref:, hyperlink, :term:, or domain-object role) fails the render action for that page instead of only printing a warning. Off by default so existing sites are unaffected.2False�
templateZThe HTML template file used for page rendering. Passed as --template to the render action.2//:templates/default.html"#
	rinx_site@@rinx//rules:site.bzl
��,
*
nameA unique name for this target. ^
\
config.The rinx.toml configuration file for the site.2 //:templates/default_config.tomlS
Q
css1The CSS stylesheet to include in the site output.2//:assets/default.cssI
G
deps-rinx_library targets to include in this site.*

RinxInfo2[]�
�
entity_schema�The project's entity meta-model. Must be the same file every `rinx_library` in `deps` names, since the documents were parsed against it; a mismatch is reported as `entity.schema-mismatch` while the index is built. Read here by the index action, which derives back-links from the declared relations, and by each render action, which reads the labels and presentation.2None�
�
entity_templates�Per-type entity presentation templates, rendered with MiniJinja. A schema's `template = "name.html"` refers to a file by its basename; listing it here is what puts it in the render action's sandbox. Omit for the built-in rendering, which every type gets without configuring anything. A template a type names but that is absent here fails the build rather than silently falling back.2[]�
�
inventories�rinx_inventory targets: other sites' objects.inv files this site links into (Sphinx's intersphinx). A reference no document defines is resolved against them, in the order listed; `:external+name:` and a `name:` prefix pick one out. Read by the index action alone, so editing one re-runs the index and every render, as any index input does.*
RinxInventoryInfo2[]�
�
strict_links�If True, a broken cross-reference (:ref:, hyperlink, :term:, or domain-object role) fails the render action for that page instead of only printing a warning. Off by default so existing sites are unaffected.2False�
�
templateZThe HTML template file used for page rendering. Passed as --template to the render action.2//:templates/default.html�
:providers.bzlr

rinxproviders.bzl"
RinxInfoRinxInfo
 (4
RinxInventoryInfoRinxInventoryInfo
,=
?�
rinx_site rule.

Collects all .ast files from its deps (Phase 2: index) then renders each
one to HTML (Phase 3: render) using the rinx worker binary.
��

rinxdefs.bzl�rinx_inventory�
Declares a Sphinx inventory (`objects.inv`) a rinx_site may link into.

List it in the site's `inventories`; the site's index action reads it, and a
reference no document of the site defines is then resolved against it.
"�
�
rinx_inventory�
Declares a Sphinx inventory (`objects.inv`) a rinx_site may link into.

List it in the site's `inventories`; the site's index action reads it, and a
reference no document of the site defines is then resolved against it.
*
nameA unique name for this target. �
base_url�Where the inventory's pages are published. An absolute URL (`https://docs.python.org/3/`), or a path relative to the consuming site's root (`../api/`) for a site deployed next to it â each page's link is then made relative to that page. �
inventory_name�The name documents pick this inventory out by, as in :external+python:ref:`tut` or :ref:`python:tut`. Defaults to the target's name.2""�
src�The objects.inv file: a vendored copy, an `http_file` pinned by `sha256`, or a filegroup over another rinx_site's `inventory` output group. "#
rinx_inventory@@rinx//:defs.bzl
,
*
nameA unique name for this target. �
�
base_url�Where the inventory's pages are published. An absolute URL (`https://docs.python.org/3/`), or a path relative to the consuming site's root (`../api/`) for a site deployed next to it â each page's link is then made relative to that page. �
�
inventory_name�The name documents pick this inventory out by, as in :external+python:ref:`tut` or :ref:`python:tut`. Defaults to the target's name.2""�
�
src�The objects.inv file: a vendored copy, an `http_file` pinned by `sha256`, or a filegroup over another rinx_site's `inventory` output group. �Prinx_library�
Parses a set of reStructuredText files into AST files (Phase 1).

Diagrams are opt-in with `diagrams = True`; see that attribute. Note this rule
does *not* compile them itself. A `.. needuml::` is expanded
against the project's entity graph, which only exists once every document has
been indexed, so diagram compilation belongs to `rinx_site` â and a
plain `.. plantuml::` goes the same way, because two compile paths would mean
two hash populations and the compiled set could drift from the validated one.

Each .rst file becomes an independently cacheable .ast file. Declare
strict structural dependencies (i.e. targets included in a `.. toctree::`) in `deps`.
Standard cross-references/hyperlinks do not need to be declared in `deps` as they are
resolved late during the site rendering phase.

Sources can be rendered as Jinja templates before parsing with `jinja = True`
â what a Sphinx project gets from a `source-read` hook in its `conf.py`. The
templates an `{% include %}` names are declared in `parse_data` and must not
also appear in `srcs`.

Files read while parsing go in `parse_data` â the data behind
`.. csv-table:: :file:`, the templates a Jinja `{% include %}` reads, and the
sources `.. include::`/`.. literalinclude::` splice in. That is unrelated to `deps`: it declares bytes the parser reads, not
another library. A `.. toctree::` written *inside* an included fragment still
needs its documents in `deps`, because toctree validation runs on the merged
AST. Pictures
shown by `.. image::`/`.. figure::` go in `images`, which is unrelated to both:
those bytes are read by neither the parser nor another library â they are
copied into the site and, when a document asks to embed one, inlined into it.
"�B
�(
rinx_library�
Parses a set of reStructuredText files into AST files (Phase 1).

Diagrams are opt-in with `diagrams = True`; see that attribute. Note this rule
does *not* compile them itself. A `.. needuml::` is expanded
against the project's entity graph, which only exists once every document has
been indexed, so diagram compilation belongs to `rinx_site` â and a
plain `.. plantuml::` goes the same way, because two compile paths would mean
two hash populations and the compiled set could drift from the validated one.

Each .rst file becomes an independently cacheable .ast file. Declare
strict structural dependencies (i.e. targets included in a `.. toctree::`) in `deps`.
Standard cross-references/hyperlinks do not need to be declared in `deps` as they are
resolved late during the site rendering phase.

Sources can be rendered as Jinja templates before parsing with `jinja = True`
â what a Sphinx project gets from a `source-read` hook in its `conf.py`. The
templates an `{% include %}` names are declared in `parse_data` and must not
also appear in `srcs`.

Files read while parsing go in `parse_data` â the data behind
`.. csv-table:: :file:`, the templates a Jinja `{% include %}` reads, and the
sources `.. include::`/`.. literalinclude::` splice in. That is unrelated to `deps`: it declares bytes the parser reads, not
another library. A `.. toctree::` written *inside* an included fragment still
needs its documents in `deps`, because toctree validation runs on the merged
AST. Pictures
shown by `.. image::`/`.. figure::` go in `images`, which is unrelated to both:
those bytes are read by neither the parser nor another library â they are
copied into the site and, when a document asks to embed one, inlined into it.
*
nameA unique name for this target. �
default_domain�The Sphinx domain (e.g. "py", "c") that bare, unprefixed directives and roles in this library's docs resolve to. This is a property of the library's content, not of any site that assembles it.2"py"�
depsyOther rinx_library targets that are structurally included via `.. toctree::`. Not required for standard cross-references.*

RinxInfo2[]�
diagrams�Whether this library's documents may hold PlantUML diagrams â `.. plantuml::`/`.. uml::`, `.. entity-diagram::`/`.. needuml::`, `.. entity-arch::`/`.. needarch::` and the generated `.. entity-flow::`/`.. needflow::` and `.. entity-sequence::`/`.. needsequence::`. Off by default so a library that draws nothing pays nothing: the site creates diagram actions only for documents of libraries that set this. A diagram written in a library without it fails the parse, naming this attribute. To keep the cost narrow, put diagram documents in a library of their own.2False�
entity_schema�The project's entity meta-model: the types, attributes, sections, relations and roles this library's documents may use. Read at *parse* time, since it is what makes `.. req::` a directive rather than an unknown name, so editing it re-parses every document here. Every library in a site and the site itself must name the same file â a mismatch is reported as `entity.schema-mismatch` when the index is built. Omit it for a project that declares no entities, which then behaves exactly as before this feature existed.2None�
images�Image files this library's documents show via `.. image::`/`.. figure::`. Paths in the document resolve relative to the document itself, or to the source root with a leading `/`. Declaring the file here is what gets it bundled into the site's `_images/` directory and, for a `:loading: embed` image, into the build action that inlines it; an undeclared image fails the site's image validation.2[]�
jinja�Whether this library's `.rst` sources are rendered as Jinja templates before they are parsed â the transform a Sphinx project gets by connecting the `source-read` event in its `conf.py`. Off by default, because a document is free to contain `{{` and `{%` as text and most projects mean nothing by them. The templates an `{% include %}` reads are declared in `parse_data`, like every other file the parser reads, and must not also appear in `srcs`.2False�
jinja_context�Names a Jinja-rendered source may read, the way a Sphinx project's `html_context` binds them. Values only; a name bound by neither this nor a `{% set %}` is reported rather than silently rendered as the empty string. Meaningless without `jinja = True`.
2{}�

parse_data�Files this library's documents read *at parse time*: the data behind `.. csv-table::`'s `:file:` option, and the sources spliced in by `.. include::` and `.. literalinclude::`. Paths in the document resolve relative to the file the directive was written in (the document, or an including fragment), or to the source root with a leading `/`; declaring the file here is what puts it in the parse action's sandbox. An `.rst` included this way must NOT also appear in `srcs` â that would additionally publish it as a page of its own.2[]B
srcs4reStructuredText source files owned by this library.2[]"!
rinx_library@@rinx//:defs.bzl
��,
*
nameA unique name for this target. �
�
default_domain�The Sphinx domain (e.g. "py", "c") that bare, unprefixed directives and roles in this library's docs resolve to. This is a property of the library's content, not of any site that assembles it.2"py"�
�
depsyOther rinx_library targets that are structurally included via `.. toctree::`. Not required for standard cross-references.*

RinxInfo2[]�
�
diagrams�Whether this library's documents may hold PlantUML diagrams â `.. plantuml::`/`.. uml::`, `.. entity-diagram::`/`.. needuml::`, `.. entity-arch::`/`.. needarch::` and the generated `.. entity-flow::`/`.. needflow::` and `.. entity-sequence::`/`.. needsequence::`. Off by default so a library that draws nothing pays nothing: the site creates diagram actions only for documents of libraries that set this. A diagram written in a library without it fails the parse, naming this attribute. To keep the cost narrow, put diagram documents in a library of their own.2False�
�
entity_schema�The project's entity meta-model: the types, attributes, sections, relations and roles this library's documents may use. Read at *parse* time, since it is what makes `.. req::` a directive rather than an unknown name, so editing it re-parses every document here. Every library in a site and the site itself must name the same file â a mismatch is reported as `entity.schema-mismatch` when the index is built. Omit it for a project that declares no entities, which then behaves exactly as before this feature existed.2None�
�
images�Image files this library's documents show via `.. image::`/`.. figure::`. Paths in the document resolve relative to the document itself, or to the source root with a leading `/`. Declaring the file here is what gets it bundled into the site's `_images/` directory and, for a `:loading: embed` image, into the build action that inlines it; an undeclared image fails the site's image validation.2[]�
�
jinja�Whether this library's `.rst` sources are rendered as Jinja templates before they are parsed â the transform a Sphinx project gets by connecting the `source-read` event in its `conf.py`. Off by default, because a document is free to contain `{{` and `{%` as text and most projects mean nothing by them. The templates an `{% include %}` reads are declared in `parse_data`, like every other file the parser reads, and must not also appear in `srcs`.2False�
�
jinja_context�Names a Jinja-rendered source may read, the way a Sphinx project's `html_context` binds them. Values only; a name bound by neither this nor a `{% set %}` is reported rather than silently rendered as the empty string. Meaningless without `jinja = True`.
2{}�
�

parse_data�Files this library's documents read *at parse time*: the data behind `.. csv-table::`'s `:file:` option, and the sources spliced in by `.. include::` and `.. literalinclude::`. Paths in the document resolve relative to the file the directive was written in (the document, or an including fragment), or to the source root with a leading `/`; declaring the file here is what puts it in the parse action's sandbox. An `.rst` included this way must NOT also appear in `srcs` â that would additionally publish it as a page of its own.2[]D
B
srcs4reStructuredText source files owned by this library.2[]�!	rinx_site�
Assembles a complete documentation site from rinx_library deps.

Performs Phase 2 (global index, one action) and Phase 3 (per-file HTML
render, one action per .ast file).  All actions are individually cacheable
by Bazel.
"�
�
	rinx_site�
Assembles a complete documentation site from rinx_library deps.

Performs Phase 2 (global index, one action) and Phase 3 (per-file HTML
render, one action per .ast file).  All actions are individually cacheable
by Bazel.
*
nameA unique name for this target. \
config.The rinx.toml configuration file for the site.2 //:templates/default_config.tomlQ
css1The CSS stylesheet to include in the site output.2//:assets/default.cssG
deps-rinx_library targets to include in this site.*

RinxInfo2[]�
entity_schema�The project's entity meta-model. Must be the same file every `rinx_library` in `deps` names, since the documents were parsed against it; a mismatch is reported as `entity.schema-mismatch` while the index is built. Read here by the index action, which derives back-links from the declared relations, and by each render action, which reads the labels and presentation.2None�
entity_templates�Per-type entity presentation templates, rendered with MiniJinja. A schema's `template = "name.html"` refers to a file by its basename; listing it here is what puts it in the render action's sandbox. Omit for the built-in rendering, which every type gets without configuring anything. A template a type names but that is absent here fails the build rather than silently falling back.2[]�
inventories�rinx_inventory targets: other sites' objects.inv files this site links into (Sphinx's intersphinx). A reference no document defines is resolved against them, in the order listed; `:external+name:` and a `name:` prefix pick one out. Read by the index action alone, so editing one re-runs the index and every render, as any index input does.*
RinxInventoryInfo2[]�
strict_links�If True, a broken cross-reference (:ref:, hyperlink, :term:, or domain-object role) fails the render action for that page instead of only printing a warning. Off by default so existing sites are unaffected.2False�
templateZThe HTML template file used for page rendering. Passed as --template to the render action.2//:templates/default.html"
	rinx_site@@rinx//:defs.bzl
��,
*
nameA unique name for this target. ^
\
config.The rinx.toml configuration file for the site.2 //:templates/default_config.tomlS
Q
css1The CSS stylesheet to include in the site output.2//:assets/default.cssI
G
deps-rinx_library targets to include in this site.*

RinxInfo2[]�
�
entity_schema�The project's entity meta-model. Must be the same file every `rinx_library` in `deps` names, since the documents were parsed against it; a mismatch is reported as `entity.schema-mismatch` while the index is built. Read here by the index action, which derives back-links from the declared relations, and by each render action, which reads the labels and presentation.2None�
�
entity_templates�Per-type entity presentation templates, rendered with MiniJinja. A schema's `template = "name.html"` refers to a file by its basename; listing it here is what puts it in the render action's sandbox. Omit for the built-in rendering, which every type gets without configuring anything. A template a type names but that is absent here fails the build rather than silently falling back.2[]�
�
inventories�rinx_inventory targets: other sites' objects.inv files this site links into (Sphinx's intersphinx). A reference no document defines is resolved against them, in the order listed; `:external+name:` and a `name:` prefix pick one out. Read by the index action alone, so editing one re-runs the index and every render, as any index input does.*
RinxInventoryInfo2[]�
�
strict_links�If True, a broken cross-reference (:ref:, hyperlink, :term:, or domain-object role) fails the render action for that page instead of only printing a warning. Off by default so existing sites are unaffected.2False�
�
templateZThe HTML template file used for page rendering. Passed as --template to the render action.2//:templates/default.html�
rinx_doctest_tests0Defines the doctest test for one `rinx_library`.*�	
�	
rinx_doctest_tests,
name Name of the generated `py_test`. (�
lib�The `rinx_library` whose documents to test. Every document it
owns is tested; its `deps` are not, since each library carries the test
target for its own documents. (�
py_deps�`py_library` targets to put on the path, so documented code is
importable. This is rules_python's ordinary `deps`, surfaced — not a
third dependency mechanism of rinx's own. Note it is unrelated
to `rinx_library`'s `deps`, which is strictly about toctrees.None(�
global_setup�A `.py` file run before every group, Sphinx's
`doctest_global_setup`. A file label rather than a config field,
because sandboxes relocate paths (see ADR-001).None(=
global_cleanup#A `.py` file run after every group.None(�
sizesBazel test size; `small` (60s) by default. A doctest that needs
longer is usually a doctest that should not be one."small"(b
tagsRApplied to the generated test, e.g. `manual` to keep it out of
`bazel test //...`.None(H
kwargs<Passed to the generated `py_test` (`timeout`, `flaky`, …).(0Defines the doctest test for one `rinx_library`.2/
rinx_doctest_tests@@rinx//rules:doctest.bzl
22*py_test2py_test|
//rules:doctest.bzlrc

rinxrulesdoctest.bzl7
rinx_doctest_tests_rinx_doctest_tests
"5
Mx
//rules:inventory.bzlr]

rinxrulesinventory.bzl/
rinx_inventory_rinx_inventory
$3
Gp
//rules:library.bzlrW

rinxruleslibrary.bzl+
rinx_library_rinx_library
"/
Ad
//rules:site.bzlrN

rinxrulessite.bzl%
	rinx_site
_rinx_site
)
8�
Public API for the rinx Bazel rules.

Load this file to access rinx_library, rinx_site and
rinx_inventory.

Example:
    load("@rinx//:defs.bzl", "rinx_library", "rinx_site")
�

rinxproviders.bzl�RinxInfo7Carries compiled .ast files from a rinx_library target.2�
�
RinxInfo7Carries compiled .ast files from a rinx_library target.4
	ast_files'A depset of compiled .ast File objects.�
diagram_ast_files�A depset of the .ast File objects whose library set `diagrams = True` â a subset of `ast_files`. The site creates diagram actions for exactly these documents, which is what keeps a library that draws nothing free of the diagram pipeline's cost.k
direct_doc_namesWA list of string names for documents directly explicitly exported by just this library.�
image_files�A depset of authored image File objects, declared via rinx_library's `images` attribute. These are files the author wrote and referenced with `.. image::`/`.. figure::`, as opposed to the diagrams the site rule compiles, which never pass through a library at all.�
embed_sidecars�A depset of per-document .embeds.json File objects, mapping each `:loading: embed` image to its data: URI. Consumed by the render action of the document it belongs to.""
RinxInfo@@rinx//:providers.bzl
6
4
	ast_files'A depset of compiled .ast File objects.�
�
diagram_ast_files�A depset of the .ast File objects whose library set `diagrams = True` â a subset of `ast_files`. The site creates diagram actions for exactly these documents, which is what keeps a library that draws nothing free of the diagram pipeline's cost.m
k
direct_doc_namesWA list of string names for documents directly explicitly exported by just this library.�
�
image_files�A depset of authored image File objects, declared via rinx_library's `images` attribute. These are files the author wrote and referenced with `.. image::`/`.. figure::`, as opposed to the diagrams the site rule compiles, which never pass through a library at all.�
�
embed_sidecars�A depset of per-document .embeds.json File objects, mapping each `:loading: embed` image to its data: URI. Consumed by the render action of the document it belongs to.�RinxInventoryInfo`Carries one Sphinx inventory (`objects.inv`) a rinx_site links into, declared by rinx_inventory.2�
�
RinxInventoryInfo`Carries one Sphinx inventory (`objects.inv`) a rinx_site links into, declared by rinx_inventory.�
name�The name a document writes to pick this inventory out (`python` in :external+python:ref:`tut`) â Sphinx's `intersphinx_mapping` key.�
base_url�Where the inventory's pages are published: an absolute URL, or a path relative to the consuming site's root for a sibling site deployed next to it.$
fileThe objects.inv File itself."+
RinxInventoryInfo@@rinx//:providers.bzl
�
�
name�The name a document writes to pick this inventory out (`python` in :external+python:ref:`tut`) â Sphinx's `intersphinx_mapping` key.�
�
base_url�Where the inventory's pages are published: an absolute URL, or a path relative to the consuming site's root for a sibling site deployed next to it.&
$
fileThe objects.inv File itself.�
RinxInfo provider.

Carries the depset of compiled .ast files produced by rinx_library
and consumed by rinx_site for indexing and rendering.
 