^
@@rules_android_ndk//E/home/sol/.bazel/execroot/_main/work/external/rules_android_ndk/BUILD 