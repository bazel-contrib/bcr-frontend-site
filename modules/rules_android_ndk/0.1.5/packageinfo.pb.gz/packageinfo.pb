�
@@rules_android_ndk//w/home/sol/.cache/bazel/_bazel_sol/dee7d2116cbeda440a9fb8e57dc802ae/execroot/_main/work/external/rules_android_ndk/BUILD 