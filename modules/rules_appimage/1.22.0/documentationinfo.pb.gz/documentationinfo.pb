�2
$
rules_appimageappimagedefs.bzl�appimageqPackage your binary into an AppImage.

Inspect intermediate build artifacts with `--output_groups=appimage_debug`"�
�
appimageqPackage your binary into an AppImage.

Inspect intermediate build artifacts with `--output_groups=appimage_debug`*
nameA unique name for this target. �
argv0_binaries�Additional executables to run instead of `binary`, keyed by the name the appimage is invoked as, e.g.
`{"my_tool": "//path/to:my_tool"}`.

The AppImage runtime exports the path the appimage was invoked with as `$ARGV0`. If its basename matches one of the
keys, the corresponding executable is run instead of `binary`. This makes it possible to ship several programs in one
appimage and select among them with symlinks, e.g. `ln -s my.appimage my_tool`.

The runfiles of these executables are merged into the runfiles tree of `binary`, so the working directory and
`RUNFILES_DIR` are the same whichever executable runs. The environment is that of `binary` combined with `env`;
the environment of the executables listed here is not applied.2{}e
binaryWThe executable that is packaged and run inside the appimage, e.g. `//path/to:my_binary` m

build_argsYExtra arguments passed to `mksquashfs` when building the appimage, e.g. `['-comp', 'xz']`2[]Q
dataCAny additional data that will be made available inside the appimage2[]{
envnRuntime environment variables. See https://bazel.build/reference/be/common-definitions#common-attributes-tests
2{}"2
appimage&@rules_appimage//appimage:appimage.bzl8,
*
nameA unique name for this target. �
�
argv0_binaries�Additional executables to run instead of `binary`, keyed by the name the appimage is invoked as, e.g.
`{"my_tool": "//path/to:my_tool"}`.

The AppImage runtime exports the path the appimage was invoked with as `$ARGV0`. If its basename matches one of the
keys, the corresponding executable is run instead of `binary`. This makes it possible to ship several programs in one
appimage and select among them with symlinks, e.g. `ln -s my.appimage my_tool`.

The runfiles of these executables are merged into the runfiles tree of `binary`, so the working directory and
`RUNFILES_DIR` are the same whichever executable runs. The environment is that of `binary` combined with `env`;
the environment of the executables listed here is not applied.2{}g
e
binaryWThe executable that is packaged and run inside the appimage, e.g. `//path/to:my_binary` o
m

build_argsYExtra arguments passed to `mksquashfs` when building the appimage, e.g. `['-comp', 'xz']`2[]S
Q
dataCAny additional data that will be made available inside the appimage2[]}
{
envnRuntime environment variables. See https://bazel.build/reference/be/common-definitions#common-attributes-tests
2{}�appimage_testvPackage your test target into an AppImage.

Inspect intermediate build artifacts with `--output_groups=appimage_debug`"�
�
appimage_testvPackage your test target into an AppImage.

Inspect intermediate build artifacts with `--output_groups=appimage_debug`*
nameA unique name for this target. �
argv0_binaries�Additional executables to run instead of `binary`, keyed by the name the appimage is invoked as, e.g.
`{"my_tool": "//path/to:my_tool"}`.

The AppImage runtime exports the path the appimage was invoked with as `$ARGV0`. If its basename matches one of the
keys, the corresponding executable is run instead of `binary`. This makes it possible to ship several programs in one
appimage and select among them with symlinks, e.g. `ln -s my.appimage my_tool`.

The runfiles of these executables are merged into the runfiles tree of `binary`, so the working directory and
`RUNFILES_DIR` are the same whichever executable runs. The environment is that of `binary` combined with `env`;
the environment of the executables listed here is not applied.2{}e
binaryWThe executable that is packaged and run inside the appimage, e.g. `//path/to:my_binary` m

build_argsYExtra arguments passed to `mksquashfs` when building the appimage, e.g. `['-comp', 'xz']`2[]Q
dataCAny additional data that will be made available inside the appimage2[]{
envnRuntime environment variables. See https://bazel.build/reference/be/common-definitions#common-attributes-tests
2{}"7
appimage_test&@rules_appimage//appimage:appimage.bzl08,
*
nameA unique name for this target. �
�
argv0_binaries�Additional executables to run instead of `binary`, keyed by the name the appimage is invoked as, e.g.
`{"my_tool": "//path/to:my_tool"}`.

The AppImage runtime exports the path the appimage was invoked with as `$ARGV0`. If its basename matches one of the
keys, the corresponding executable is run instead of `binary`. This makes it possible to ship several programs in one
appimage and select among them with symlinks, e.g. `ln -s my.appimage my_tool`.

The runfiles of these executables are merged into the runfiles tree of `binary`, so the working directory and
`RUNFILES_DIR` are the same whichever executable runs. The environment is that of `binary` combined with `env`;
the environment of the executables listed here is not applied.2{}g
e
binaryWThe executable that is packaged and run inside the appimage, e.g. `//path/to:my_binary` o
m

build_argsYExtra arguments passed to `mksquashfs` when building the appimage, e.g. `['-comp', 'xz']`2[]S
Q
dataCAny additional data that will be made available inside the appimage2[]}
{
envnRuntime environment variables. See https://bazel.build/reference/be/common-definitions#common-attributes-tests
2{}�appimage_toolchain�Declare an AppImage toolchain wrapping a platform-specific AppImage runtime binary.

A separate toolchain target should be registered for each supported CPU architecture, constrained to the matching platform, so that the `appimage()` rule automatically selects the correct runtime for the target platform."�
�
appimage_toolchain�Declare an AppImage toolchain wrapping a platform-specific AppImage runtime binary.

A separate toolchain target should be registered for each supported CPU architecture, constrained to the matching platform, so that the `appimage()` rule automatically selects the correct runtime for the target platform.*
nameA unique name for this target. 
appimage_runtime2None"=
appimage_toolchain'@rules_appimage//appimage:toolchain.bzl,
*
nameA unique name for this target. 

appimage_runtime2None 