��

rules_appleapple	apple.bzl�apple_dynamic_framework_import�This rule encapsulates an already-built dynamic framework. It is defined by a list of
files in exactly one `.framework` directory. `apple_dynamic_framework_import` targets
need to be added to library targets through the `deps` attribute.
### Examples

```python
apple_dynamic_framework_import(
    name = "my_dynamic_framework",
    framework_imports = glob(["my_dynamic_framework.framework/**"]),
)

objc_library(
    name = "foo_lib",
    ...,
    deps = [
        ":my_dynamic_framework",
    ],
)
```"�
�
apple_dynamic_framework_import�This rule encapsulates an already-built dynamic framework. It is defined by a list of
files in exactly one `.framework` directory. `apple_dynamic_framework_import` targets
need to be added to library targets through the `deps` attribute.
### Examples

```python
apple_dynamic_framework_import(
    name = "my_dynamic_framework",
    framework_imports = glob(["my_dynamic_framework.framework/**"]),
)

objc_library(
    name = "foo_lib",
    ...,
    deps = [
        ":my_dynamic_framework",
    ],
)
```*
nameA unique name for this target. �
framework_importstThe list of files under a .framework directory which are provided to Apple based targets that depend
on this target. �
depsiA list of targets that are dependencies of the target being built, which will be linked into that
target.*5
CcInfo+
CcInfo!@rules_cc//cc/private:cc_info.bzl*�
CcInfo
AppleFrameworkImportInfo+
CcInfo!@rules_cc//cc/private:cc_info.bzlF
AppleFrameworkImportInfo*@rules_apple//apple/internal:providers.bzl2[]n
dsym_importsXThe list of files under a .dSYM directory, that is the imported framework's dSYM bundle.2[]�
bundle_only�Avoid linking the dynamic framework, but still include it in the app. This is useful when you want
to manually dlopen the framework at runtime.2False"Y
apple_dynamic_framework_import7@rules_apple//apple/internal:apple_framework_import.bzl,
*
nameA unique name for this target. �
�
framework_importstThe list of files under a .framework directory which are provided to Apple based targets that depend
on this target. �
�
depsiA list of targets that are dependencies of the target being built, which will be linked into that
target.*5
CcInfo+
CcInfo!@rules_cc//cc/private:cc_info.bzl*�
CcInfo
AppleFrameworkImportInfo+
CcInfo!@rules_cc//cc/private:cc_info.bzlF
AppleFrameworkImportInfo*@rules_apple//apple/internal:providers.bzl2[]p
n
dsym_importsXThe list of files under a .dSYM directory, that is the imported framework's dSYM bundle.2[]�
�
bundle_only�Avoid linking the dynamic framework, but still include it in the app. This is useful when you want
to manually dlopen the framework at runtime.2False� apple_dynamic_xcframework_import�This rule encapsulates an already-built XCFramework. Defined by a list of files in a .xcframework
directory. apple_xcframework_import targets need to be added as dependencies to library targets
through the `deps` attribute.

### Example

```bzl
apple_dynamic_xcframework_import(
    name = "my_dynamic_xcframework",
    xcframework_imports = glob(["my_dynamic_framework.xcframework/**"]),
)

objc_library(
    name = "foo_lib",
    ...,
    deps = [
        ":my_dynamic_xcframework",
    ],
)
```"�
�
 apple_dynamic_xcframework_import�This rule encapsulates an already-built XCFramework. Defined by a list of files in a .xcframework
directory. apple_xcframework_import targets need to be added as dependencies to library targets
through the `deps` attribute.

### Example

```bzl
apple_dynamic_xcframework_import(
    name = "my_dynamic_xcframework",
    xcframework_imports = glob(["my_dynamic_framework.xcframework/**"]),
)

objc_library(
    name = "foo_lib",
    ...,
    deps = [
        ":my_dynamic_xcframework",
    ],
)
```*
nameA unique name for this target. �
xcframework_importsrList of files under a .xcframework directory which are provided to Apple based targets that depend
on this target. �
deps{List of targets that are dependencies of the target being built, which will provide headers and be
linked into that target.*5
CcInfo+
CcInfo!@rules_cc//cc/private:cc_info.bzl*�
CcInfo
AppleFrameworkImportInfo+
CcInfo!@rules_cc//cc/private:cc_info.bzlF
AppleFrameworkImportInfo*@rules_apple//apple/internal:providers.bzl2[]�
bundle_only�Avoid linking the dynamic framework, but still include it in the app. This is useful when you want
to manually dlopen the framework at runtime.2FalseS
library_identifiers6Unnecssary and ignored, will be removed in the future.
2{}"]
 apple_dynamic_xcframework_import9@rules_apple//apple/internal:apple_xcframework_import.bzl*�
AppleFrameworkImportInfo
CcInfo
AppleDynamicFrameworkInfoF
AppleFrameworkImportInfo*@rules_apple//apple/internal:providers.bzl+
CcInfo!@rules_cc//cc/private:cc_info.bzlG
AppleDynamicFrameworkInfo*@rules_apple//apple/internal:providers.bzl,
*
nameA unique name for this target. �
�
xcframework_importsrList of files under a .xcframework directory which are provided to Apple based targets that depend
on this target. �
�
deps{List of targets that are dependencies of the target being built, which will provide headers and be
linked into that target.*5
CcInfo+
CcInfo!@rules_cc//cc/private:cc_info.bzl*�
CcInfo
AppleFrameworkImportInfo+
CcInfo!@rules_cc//cc/private:cc_info.bzlF
AppleFrameworkImportInfo*@rules_apple//apple/internal:providers.bzl2[]�
�
bundle_only�Avoid linking the dynamic framework, but still include it in the app. This is useful when you want
to manually dlopen the framework at runtime.2FalseU
S
library_identifiers6Unnecssary and ignored, will be removed in the future.
2{}�/apple_static_framework_import�This rule encapsulates an already-built static framework. It is defined by a list of
files in exactly one `.framework` directory. `apple_static_framework_import` targets
need to be added to library targets through the `deps` attribute.
### Examples

```python
apple_static_framework_import(
    name = "my_static_framework",
    framework_imports = glob(["my_static_framework.framework/**"]),
)

objc_library(
    name = "foo_lib",
    ...,
    deps = [
        ":my_static_framework",
    ],
)
```"�+
�
apple_static_framework_import�This rule encapsulates an already-built static framework. It is defined by a list of
files in exactly one `.framework` directory. `apple_static_framework_import` targets
need to be added to library targets through the `deps` attribute.
### Examples

```python
apple_static_framework_import(
    name = "my_static_framework",
    framework_imports = glob(["my_static_framework.framework/**"]),
)

objc_library(
    name = "foo_lib",
    ...,
    deps = [
        ":my_static_framework",
    ],
)
```*
nameA unique name for this target. �
framework_importstThe list of files under a .framework directory which are provided to Apple based targets that depend
on this target. �

sdk_dylibs�Names of SDK .dylib libraries to link with. For instance, `libz` or `libarchive`. `libc++` is
included automatically if the binary has any C++ or Objective-C++ sources in its dependency tree.
When linking a binary, all libraries named in that binary's transitive dependency graph are used.2[]�
sdk_frameworks�Names of SDK frameworks to link with (e.g. `AddressBook`, `QuartzCore`). `UIKit` and `Foundation`
are always included when building for the iOS, tvOS, visionOS, and watchOS platforms. For macOS, only
`Foundation` is always included. When linking a top level binary, all SDK frameworks listed in that
binary's transitive dependency graph are linked.2[]�
weak_sdk_frameworks�Names of SDK frameworks to weakly link with. For instance, `MediaAccessibility`. In difference to
regularly linked SDK frameworks, symbols from weakly linked frameworks do not cause an error if they
are not present at runtime.2[]�
deps}A list of targets that are dependencies of the target being built, which will provide headers and be
linked into that target.*5
CcInfo+
CcInfo!@rules_cc//cc/private:cc_info.bzl*�
CcInfo
AppleFrameworkImportInfo+
CcInfo!@rules_cc//cc/private:cc_info.bzlF
AppleFrameworkImportInfo*@rules_apple//apple/internal:providers.bzl2[]�
data�List of files needed by this target at runtime.

Files and targets named in the `data` attribute will appear in the `*.runfiles`
area of this target, if it has one. This may include data files needed by a
binary or library, or other programs needed by it.2[]�

alwayslink�If true, any binary that depends (directly or indirectly) on this framework will link in all the
object files for the framework file, even if some contain no symbols referenced by the binary. This
is useful if your code isn't explicitly called by code in the binary; for example, if you rely on
runtime checks for protocol conformances added in extensions in the library but do not directly
reference any other symbols in the object file that adds that conformance.2False�
	has_swift�A boolean indicating if the target has Swift source code. This helps flag Apple frameworks that do
not include Swift interface or Swift module files.2False"X
apple_static_framework_import7@rules_apple//apple/internal:apple_framework_import.bzl,
*
nameA unique name for this target. �
�
framework_importstThe list of files under a .framework directory which are provided to Apple based targets that depend
on this target. �
�

sdk_dylibs�Names of SDK .dylib libraries to link with. For instance, `libz` or `libarchive`. `libc++` is
included automatically if the binary has any C++ or Objective-C++ sources in its dependency tree.
When linking a binary, all libraries named in that binary's transitive dependency graph are used.2[]�
�
sdk_frameworks�Names of SDK frameworks to link with (e.g. `AddressBook`, `QuartzCore`). `UIKit` and `Foundation`
are always included when building for the iOS, tvOS, visionOS, and watchOS platforms. For macOS, only
`Foundation` is always included. When linking a top level binary, all SDK frameworks listed in that
binary's transitive dependency graph are linked.2[]�
�
weak_sdk_frameworks�Names of SDK frameworks to weakly link with. For instance, `MediaAccessibility`. In difference to
regularly linked SDK frameworks, symbols from weakly linked frameworks do not cause an error if they
are not present at runtime.2[]�
�
deps}A list of targets that are dependencies of the target being built, which will provide headers and be
linked into that target.*5
CcInfo+
CcInfo!@rules_cc//cc/private:cc_info.bzl*�
CcInfo
AppleFrameworkImportInfo+
CcInfo!@rules_cc//cc/private:cc_info.bzlF
AppleFrameworkImportInfo*@rules_apple//apple/internal:providers.bzl2[]�
�
data�List of files needed by this target at runtime.

Files and targets named in the `data` attribute will appear in the `*.runfiles`
area of this target, if it has one. This may include data files needed by a
binary or library, or other programs needed by it.2[]�
�

alwayslink�If true, any binary that depends (directly or indirectly) on this framework will link in all the
object files for the framework file, even if some contain no symbols referenced by the binary. This
is useful if your code isn't explicitly called by code in the binary; for example, if you rely on
runtime checks for protocol conformances added in extensions in the library but do not directly
reference any other symbols in the object file that adds that conformance.2False�
�
	has_swift�A boolean indicating if the target has Swift source code. This helps flag Apple frameworks that do
not include Swift interface or Swift module files.2False�6apple_static_library�This rule produces single- or multi-architecture ("fat") static libraries targeting
Apple platforms.

The `lipo` tool is used to combine files of multiple architectures. One of
several flags may control which architectures are included in the output,
depending on the value of the `platform_type` attribute.

NOTE: In most situations, users should prefer the platform- and
product-type-specific rules, such as `apple_static_xcframework`. This
rule is being provided for the purpose of transitioning users from the built-in
implementation of `apple_static_library` in Bazel core so that it can be removed."�1
�
apple_static_library�This rule produces single- or multi-architecture ("fat") static libraries targeting
Apple platforms.

The `lipo` tool is used to combine files of multiple architectures. One of
several flags may control which architectures are included in the output,
depending on the value of the `platform_type` attribute.

NOTE: In most situations, users should prefer the platform- and
product-type-specific rules, such as `apple_static_xcframework`. This
rule is being provided for the purpose of transitioning users from the built-in
implementation of `apple_static_library` in Bazel core so that it can be removed.*
nameA unique name for this target. S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�

avoid_deps�A list of library targets on which this framework depends in order to compile, but the transitive
closure of which will not be linked into the framework's binary.*5
CcInfo+
CcInfo!@rules_cc//cc/private:cc_info.bzl2[]O
dataAFiles to be made available to the library archive upon execution.2[]�
deps�A list of dependencies targets that will be linked into this target's binary. Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle.*5
CcInfo+
CcInfo!@rules_cc//cc/private:cc_info.bzl2[]a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
platform_type�The target Apple platform for which to create a binary. This dictates which SDK
is used for compilation/linking and which flag is used to determine the
architectures to target. For example, if `ios` is specified, then the output
binaries/libraries will be created combining all architectures specified by
`--ios_multi_cpus`. Options are:

*   `ios`: architectures gathered from `--ios_multi_cpus`.
*   `macos`: architectures gathered from `--macos_cpus`.
*   `tvos`: architectures gathered from `--tvos_cpus`.
*   `visionos`: architectures gathered from `--visionos_cpus`.
*   `watchos`: architectures gathered from `--watchos_cpus`. �
sdk_frameworks�Names of SDK frameworks to link with (e.g., `AddressBook`, `QuartzCore`).
`UIKit` and `Foundation` are always included, even if this attribute is
provided and does not list them.

This attribute is discouraged; in general, targets should list system
framework dependencies in the library targets where that framework is used,
not in the top-level bundle.2[]�

sdk_dylibs�Names of SDK `.dylib` libraries to link with (e.g., `libz` or `libarchive`).
`libc++` is included automatically if the binary has any C++ or Objective-C++
sources in its dependency tree. When linking a binary, all libraries named in
that binary's transitive dependency graph are used.2[]�
weak_sdk_frameworks�Names of SDK frameworks to weakly link with (e.g., `MediaAccessibility`).
Unlike regularly linked SDK frameworks, symbols from weakly linked
frameworks do not cause the binary to fail to load if they are not present in
the version of the framework available at runtime.

This attribute is discouraged; in general, targets should list system
framework dependencies in the library targets where that framework is used,
not in the top-level bundle.2[]"D
apple_static_library,@rules_apple//apple:apple_static_library.bzl,
*
nameA unique name for this target. U
S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
�

avoid_deps�A list of library targets on which this framework depends in order to compile, but the transitive
closure of which will not be linked into the framework's binary.*5
CcInfo+
CcInfo!@rules_cc//cc/private:cc_info.bzl2[]Q
O
dataAFiles to be made available to the library archive upon execution.2[]�
�
deps�A list of dependencies targets that will be linked into this target's binary. Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle.*5
CcInfo+
CcInfo!@rules_cc//cc/private:cc_info.bzl2[]c
a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
platform_type�The target Apple platform for which to create a binary. This dictates which SDK
is used for compilation/linking and which flag is used to determine the
architectures to target. For example, if `ios` is specified, then the output
binaries/libraries will be created combining all architectures specified by
`--ios_multi_cpus`. Options are:

*   `ios`: architectures gathered from `--ios_multi_cpus`.
*   `macos`: architectures gathered from `--macos_cpus`.
*   `tvos`: architectures gathered from `--tvos_cpus`.
*   `visionos`: architectures gathered from `--visionos_cpus`.
*   `watchos`: architectures gathered from `--watchos_cpus`. �
�
sdk_frameworks�Names of SDK frameworks to link with (e.g., `AddressBook`, `QuartzCore`).
`UIKit` and `Foundation` are always included, even if this attribute is
provided and does not list them.

This attribute is discouraged; in general, targets should list system
framework dependencies in the library targets where that framework is used,
not in the top-level bundle.2[]�
�

sdk_dylibs�Names of SDK `.dylib` libraries to link with (e.g., `libz` or `libarchive`).
`libc++` is included automatically if the binary has any C++ or Objective-C++
sources in its dependency tree. When linking a binary, all libraries named in
that binary's transitive dependency graph are used.2[]�
�
weak_sdk_frameworks�Names of SDK frameworks to weakly link with (e.g., `MediaAccessibility`).
Unlike regularly linked SDK frameworks, symbols from weakly linked
frameworks do not cause the binary to fail to load if they are not present in
the version of the framework available at runtime.

This attribute is discouraged; in general, targets should list system
framework dependencies in the library targets where that framework is used,
not in the top-level bundle.2[]�Gapple_static_xcframeworkLGenerates an XCFramework with static libraries for third-party distribution."�G
�$
apple_static_xcframeworkLGenerates an XCFramework with static libraries for third-party distribution.*
nameA unique name for this target. �
	bundle_id�Optional bundle ID (reverse-DNS path followed by framework name) for each of the embedded frameworks.
If present, this value will be embedded in an Info.plist within each framework bundle, similar to
apple_xcframework (dynamic frameworks).2""�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�

avoid_deps�A list of library targets on which this framework depends in order to compile, but the transitive
closure of which will not be linked into the framework's binary, nor bundled into final XCFramework.2[]�
bundle_name�The desired name of the XCFramework bundle (without the extension) and the binaries for all embedded
static libraries. If this attribute is not set, then the name of the target will be used instead.2""�
deps�A list of files directly referencing libraries to be represented for each given platform split in
the XCFramework. These libraries will be embedded within each platform split. �
families_required�A list of device families supported by this extension, with platforms such as `ios` as keys. Valid
values are `iphone` and `ipad` for `ios`; at least one must be specified if a platform is defined.
Currently, this only affects processing of `ios` resources.2{}�

infoplists�A list of .plist files that will be merged to form the Info.plist for each of the embedded
frameworks. Only used if bundle_id is provided.2[]�
ios�A dictionary of strings indicating which platform variants should be built for the `ios` platform (
`device` or `simulator`) as keys, and arrays of strings listing which architectures should be
built for those platform variants (for example, `x86_64`, `arm64`) as their values.2{}�
macosxA list of strings indicating which architecture should be built for the macOS platform (for example, `x86_64`, `arm64`).2[]�
tvos�A dictionary of strings indicating which platform variants should be built for the tvOS platform (
`device` or `simulator`) as keys, and arrays of strings listing which architectures should be
built for those platform variants (for example, `x86_64`, `arm64`) as their values.2{}�
visionos�A dictionary of strings indicating which platform variants should be built for the visionOS platform
(`device` or `simulator`) as keys, and arrays of strings listing which architectures should be
built for those platform variants (for example, `arm64`) as their values.2{}�
minimum_deployment_os_versions�A dictionary of strings indicating the minimum deployment OS version supported by the target,
represented as a dotted version number (for example, "9.0") as values, with their respective
platforms such as `ios` as keys. This is different from `minimum_os_versions`, which is effective
at compile time. Ensure version specific APIs are guarded with `available` clauses.
2{}�
minimum_os_versions�A dictionary of strings indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "8.0") as values, with their respective platforms such as `ios`,
`tvos`, or `visionos` as keys:

    minimum_os_versions = {
        "ios": "13.0",
        "tvos": "15.0",
        "visionos": "1.0",
    }
 �
public_hdrs�A list of files directly referencing header files to be used as the publicly visible interface for
each of these embedded libraries. These header files will be embedded within each platform split,
typically in a subdirectory such as `Headers`.2[]�
umbrella_header�An optional single .h file to use as the umbrella header for this framework. Usually, this header
will have the same name as this target, so that clients can load the header using the #import
<MyFramework/MyFramework.h> format. If this attribute is not specified (the common use case), an
umbrella header will be generated under the same name as this target.2None�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-versioning.md#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2None"N
apple_static_xcframework2@rules_apple//apple/internal:xcframework_rules.bzl,
*
nameA unique name for this target. �
�
	bundle_id�Optional bundle ID (reverse-DNS path followed by framework name) for each of the embedded frameworks.
If present, this value will be embedded in an Info.plist within each framework bundle, similar to
apple_xcframework (dynamic frameworks).2""�
�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
�

avoid_deps�A list of library targets on which this framework depends in order to compile, but the transitive
closure of which will not be linked into the framework's binary, nor bundled into final XCFramework.2[]�
�
bundle_name�The desired name of the XCFramework bundle (without the extension) and the binaries for all embedded
static libraries. If this attribute is not set, then the name of the target will be used instead.2""�
�
deps�A list of files directly referencing libraries to be represented for each given platform split in
the XCFramework. These libraries will be embedded within each platform split. �
�
families_required�A list of device families supported by this extension, with platforms such as `ios` as keys. Valid
values are `iphone` and `ipad` for `ios`; at least one must be specified if a platform is defined.
Currently, this only affects processing of `ios` resources.2{}�
�

infoplists�A list of .plist files that will be merged to form the Info.plist for each of the embedded
frameworks. Only used if bundle_id is provided.2[]�
�
ios�A dictionary of strings indicating which platform variants should be built for the `ios` platform (
`device` or `simulator`) as keys, and arrays of strings listing which architectures should be
built for those platform variants (for example, `x86_64`, `arm64`) as their values.2{}�
�
macosxA list of strings indicating which architecture should be built for the macOS platform (for example, `x86_64`, `arm64`).2[]�
�
tvos�A dictionary of strings indicating which platform variants should be built for the tvOS platform (
`device` or `simulator`) as keys, and arrays of strings listing which architectures should be
built for those platform variants (for example, `x86_64`, `arm64`) as their values.2{}�
�
visionos�A dictionary of strings indicating which platform variants should be built for the visionOS platform
(`device` or `simulator`) as keys, and arrays of strings listing which architectures should be
built for those platform variants (for example, `arm64`) as their values.2{}�
�
minimum_deployment_os_versions�A dictionary of strings indicating the minimum deployment OS version supported by the target,
represented as a dotted version number (for example, "9.0") as values, with their respective
platforms such as `ios` as keys. This is different from `minimum_os_versions`, which is effective
at compile time. Ensure version specific APIs are guarded with `available` clauses.
2{}�
�
minimum_os_versions�A dictionary of strings indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "8.0") as values, with their respective platforms such as `ios`,
`tvos`, or `visionos` as keys:

    minimum_os_versions = {
        "ios": "13.0",
        "tvos": "15.0",
        "visionos": "1.0",
    }
 �
�
public_hdrs�A list of files directly referencing header files to be used as the publicly visible interface for
each of these embedded libraries. These header files will be embedded within each platform split,
typically in a subdirectory such as `Headers`.2[]�
�
umbrella_header�An optional single .h file to use as the umbrella header for this framework. Usually, this header
will have the same name as this target, so that clients can load the header using the #import
<MyFramework/MyFramework.h> format. If this attribute is not specified (the common use case), an
umbrella header will be generated under the same name as this target.2None�
�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-versioning.md#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2None�8apple_static_xcframework_import�This rule encapsulates an already-built XCFramework with static libraries. Defined by a list of
files in a .xcframework directory. apple_xcframework_import targets need to be added as dependencies
to library targets through the `deps` attribute.
### Examples

```slarlark
apple_static_xcframework_import(
    name = "my_static_xcframework",
    xcframework_imports = glob(["my_static_framework.xcframework/**"]),
)

objc_library(
    name = "foo_lib",
    ...,
    deps = [
        ":my_static_xcframework",
    ],
)
```"�4
�
apple_static_xcframework_import�This rule encapsulates an already-built XCFramework with static libraries. Defined by a list of
files in a .xcframework directory. apple_xcframework_import targets need to be added as dependencies
to library targets through the `deps` attribute.
### Examples

```slarlark
apple_static_xcframework_import(
    name = "my_static_xcframework",
    xcframework_imports = glob(["my_static_framework.xcframework/**"]),
)

objc_library(
    name = "foo_lib",
    ...,
    deps = [
        ":my_static_xcframework",
    ],
)
```*
nameA unique name for this target. �

alwayslink�If true, any binary that depends (directly or indirectly) on this XCFramework will link in all the
object files for the XCFramework bundle, even if some contain no symbols referenced by the binary.
This is useful if your code isn't explicitly called by code in the binary; for example, if you rely
on runtime checks for protocol conformances added in extensions in the library but do not directly
reference any other symbols in the object file that adds that conformance.2False�
deps{List of targets that are dependencies of the target being built, which will provide headers and be
linked into that target.*5
CcInfo+
CcInfo!@rules_cc//cc/private:cc_info.bzl*�
CcInfo
AppleFrameworkImportInfo+
CcInfo!@rules_cc//cc/private:cc_info.bzlF
AppleFrameworkImportInfo*@rules_apple//apple/internal:providers.bzl2[]�
data�List of files needed by this target at runtime.

Files and targets named in the `data` attribute will appear in the `*.runfiles`
area of this target, if it has one. This may include data files needed by a
binary or library, or other programs needed by it.2[]�
	has_swift�A boolean indicating if the target has Swift source code. This helps flag XCFrameworks that do not
include Swift interface files.2False�
includes�List of `#include/#import` search paths to add to this target and all depending
targets.

The paths are interpreted relative to the single platform directory inside the
XCFramework for the platform being built.

These flags are added for this rule and every rule that depends on it. (Note:
not the rules it depends upon!) Be very careful, since this may have
far-reaching effects.2[]a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]�

sdk_dylibs�Names of SDK .dylib libraries to link with. For instance, `libz` or `libarchive`. `libc++` is
included automatically if the binary has any C++ or Objective-C++ sources in its dependency tree.
When linking a binary, all libraries named in that binary's transitive dependency graph are used.2[]�
sdk_frameworks�Names of SDK frameworks to link with (e.g. `AddressBook`, `QuartzCore`). `UIKit` and `Foundation`
are always included when building for the iOS, tvOS, visionOS and watchOS platforms. For macOS, only
`Foundation` is always included. When linking a top level binary, all SDK frameworks listed in that
binary's transitive dependency graph are linked.2[]�
weak_sdk_frameworks�Names of SDK frameworks to weakly link with. For instance, `MediaAccessibility`. In difference to
regularly linked SDK frameworks, symbols from weakly linked frameworks do not cause an error if they
are not present at runtime.2[]�
xcframework_importsrList of files under a .xcframework directory which are provided to Apple based targets that depend
on this target. S
library_identifiers6Unnecssary and ignored, will be removed in the future.
2{}"\
apple_static_xcframework_import9@rules_apple//apple/internal:apple_xcframework_import.bzl,
*
nameA unique name for this target. �
�

alwayslink�If true, any binary that depends (directly or indirectly) on this XCFramework will link in all the
object files for the XCFramework bundle, even if some contain no symbols referenced by the binary.
This is useful if your code isn't explicitly called by code in the binary; for example, if you rely
on runtime checks for protocol conformances added in extensions in the library but do not directly
reference any other symbols in the object file that adds that conformance.2False�
�
deps{List of targets that are dependencies of the target being built, which will provide headers and be
linked into that target.*5
CcInfo+
CcInfo!@rules_cc//cc/private:cc_info.bzl*�
CcInfo
AppleFrameworkImportInfo+
CcInfo!@rules_cc//cc/private:cc_info.bzlF
AppleFrameworkImportInfo*@rules_apple//apple/internal:providers.bzl2[]�
�
data�List of files needed by this target at runtime.

Files and targets named in the `data` attribute will appear in the `*.runfiles`
area of this target, if it has one. This may include data files needed by a
binary or library, or other programs needed by it.2[]�
�
	has_swift�A boolean indicating if the target has Swift source code. This helps flag XCFrameworks that do not
include Swift interface files.2False�
�
includes�List of `#include/#import` search paths to add to this target and all depending
targets.

The paths are interpreted relative to the single platform directory inside the
XCFramework for the platform being built.

These flags are added for this rule and every rule that depends on it. (Note:
not the rules it depends upon!) Be very careful, since this may have
far-reaching effects.2[]c
a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]�
�

sdk_dylibs�Names of SDK .dylib libraries to link with. For instance, `libz` or `libarchive`. `libc++` is
included automatically if the binary has any C++ or Objective-C++ sources in its dependency tree.
When linking a binary, all libraries named in that binary's transitive dependency graph are used.2[]�
�
sdk_frameworks�Names of SDK frameworks to link with (e.g. `AddressBook`, `QuartzCore`). `UIKit` and `Foundation`
are always included when building for the iOS, tvOS, visionOS and watchOS platforms. For macOS, only
`Foundation` is always included. When linking a top level binary, all SDK frameworks listed in that
binary's transitive dependency graph are linked.2[]�
�
weak_sdk_frameworks�Names of SDK frameworks to weakly link with. For instance, `MediaAccessibility`. In difference to
regularly linked SDK frameworks, symbols from weakly linked frameworks do not cause an error if they
are not present at runtime.2[]�
�
xcframework_importsrList of files under a .xcframework directory which are provided to Apple based targets that depend
on this target. U
S
library_identifiers6Unnecssary and ignored, will be removed in the future.
2{}�apple_universal_binary�This rule produces a multi-architecture ("fat") binary targeting Apple platforms.
The `lipo` tool is used to combine built binaries of multiple architectures."�
�
apple_universal_binary�This rule produces a multi-architecture ("fat") binary targeting Apple platforms.
The `lipo` tool is used to combine built binaries of multiple architectures.*
nameA unique name for this target. �
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""�
platform_type�The target Apple platform for which to create a binary. This dictates which SDK
is used for compilation/linking and which flag is used to determine the
architectures to target. For example, if `ios` is specified, then the output
binaries/libraries will be created combining all architectures specified by
`--ios_multi_cpus`. Options are:

*   `ios`: architectures gathered from `--ios_multi_cpus`.
*   `macos`: architectures gathered from `--macos_cpus`.
*   `tvos`: architectures gathered from `--tvos_cpus`.
*   `watchos`: architectures gathered from `--watchos_cpus`. 5
binary'Target to generate a 'fat' binary from. �
forced_cpus�An optional list of target CPUs for which the universal binary should be built.

If this attribute is present, the value of the platform-specific CPU flag (`--ios_multi_cpus`,
`--macos_cpus`, `--tvos_cpus`, `--visionos_cpus`, or `--watchos_cpus`) will be ignored and the
binary will be built for all of the specified architectures instead.

This is primarily useful to force macOS tools to be built as universal binaries using
`forced_cpus = ["x86_64", "arm64"]`, without requiring the user to pass additional flags when
invoking Bazel.2[]"Q
apple_universal_binary7@rules_apple//apple/internal:apple_universal_binary.bzl,
*
nameA unique name for this target. �
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""�
�
platform_type�The target Apple platform for which to create a binary. This dictates which SDK
is used for compilation/linking and which flag is used to determine the
architectures to target. For example, if `ios` is specified, then the output
binaries/libraries will be created combining all architectures specified by
`--ios_multi_cpus`. Options are:

*   `ios`: architectures gathered from `--ios_multi_cpus`.
*   `macos`: architectures gathered from `--macos_cpus`.
*   `tvos`: architectures gathered from `--tvos_cpus`.
*   `watchos`: architectures gathered from `--watchos_cpus`. 7
5
binary'Target to generate a 'fat' binary from. �
�
forced_cpus�An optional list of target CPUs for which the universal binary should be built.

If this attribute is present, the value of the platform-specific CPU flag (`--ios_multi_cpus`,
`--macos_cpus`, `--tvos_cpus`, `--visionos_cpus`, or `--watchos_cpus`) will be ignored and the
binary will be built for all of the specified architectures instead.

This is primarily useful to force macOS tools to be built as universal binaries using
`forced_cpus = ["x86_64", "arm64"]`, without requiring the user to pass additional flags when
invoking Bazel.2[]�_apple_xcframework�Builds and bundles an XCFramework for third-party distribution.

Pass `--apple_generate_dsym` to include dSYM bundles in the XCFramework."�]
�/
apple_xcframework�Builds and bundles an XCFramework for third-party distribution.

Pass `--apple_generate_dsym` to include dSYM bundles in the XCFramework.*
nameA unique name for this target. �
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for each of the embedded frameworks. If
present, this value will be embedded in an Info.plist within each framework bundle. �
bundle_name�The desired name of the xcframework bundle (without the extension) and the bundles for all embedded
frameworks. If this attribute is not set, then the name of the target will be used instead.2""�
data�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within each of the embedded framework bundles.2[]�
extension_safe�If true, compiles and links this framework with `-application-extension`, restricting the binary to
use only extension-safe APIs.2False�
families_required�A list of device families supported by this extension, with platforms such as `ios` as keys. Valid
values are `iphone` and `ipad` for `ios`; at least one must be specified if a platform is defined.
Currently, this only affects processing of `ios` resources.2{}�

infoplists�A list of .plist files that will be merged to form the Info.plist for each of the embedded
frameworks. At least one file must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
ios�A dictionary of strings indicating which platform variants should be built for the iOS platform (
`device` or `simulator`) as keys, and arrays of strings listing which architectures should be
built for those platform variants (for example, `x86_64`, `arm64`) as their values.2{}�
macosxA list of strings indicating which architecture should be built for the macOS platform (for example, `x86_64`, `arm64`).2[]�
tvos�A dictionary of strings indicating which platform variants should be built for the tvOS platform (
`device` or `simulator`) as keys, and arrays of strings listing which architectures should be
built for those platform variants (for example, `x86_64`, `arm64`) as their values.2{}�
visionos�A dictionary of strings indicating which platform variants should be built for the visionOS platform
(`device` or `simulator`) as keys, and arrays of strings listing which architectures should be
built for those platform variants (for example, `arm64`) as their values.2{}�
minimum_deployment_os_versions�A dictionary of strings indicating the minimum deployment OS version supported by the target,
represented as a dotted version number (for example, "9.0") as values, with their respective
platforms such as `ios` as keys. This is different from `minimum_os_versions`, which is effective
at compile time. Ensure version specific APIs are guarded with `available` clauses.
2{}�
minimum_os_versions�A dictionary of strings indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "8.0") as values, with their respective platforms such as `ios`,
or `tvos` as keys:

    minimum_os_versions = {
        "ios": "13.0",
        "tvos": "15.0",
        "visionos": "1.0",
    }
 �
public_hdrs�A list of files directly referencing header files to be used as the publicly visible interface for
each of these embedded frameworks. These header files will be embedded within each bundle,
typically in a subdirectory such as `Headers`.2[]�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-versioning.md#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2None�
umbrella_header�An optional single .h file to use as the umbrella header for this framework. Usually, this header
will have the same name as this target, so that clients can load the header using the #import
<MyFramework/MyFramework.h> format. If this attribute is not specified (the common use case), an
umbrella header will be generated under the same name as this target.2None"G
apple_xcframework2@rules_apple//apple/internal:xcframework_rules.bzl,
*
nameA unique name for this target. �
�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]g
e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]c
a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]U
S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for each of the embedded frameworks. If
present, this value will be embedded in an Info.plist within each framework bundle. �
�
bundle_name�The desired name of the xcframework bundle (without the extension) and the bundles for all embedded
frameworks. If this attribute is not set, then the name of the target will be used instead.2""�
�
data�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within each of the embedded framework bundles.2[]�
�
extension_safe�If true, compiles and links this framework with `-application-extension`, restricting the binary to
use only extension-safe APIs.2False�
�
families_required�A list of device families supported by this extension, with platforms such as `ios` as keys. Valid
values are `iphone` and `ipad` for `ios`; at least one must be specified if a platform is defined.
Currently, this only affects processing of `ios` resources.2{}�
�

infoplists�A list of .plist files that will be merged to form the Info.plist for each of the embedded
frameworks. At least one file must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
�
ios�A dictionary of strings indicating which platform variants should be built for the iOS platform (
`device` or `simulator`) as keys, and arrays of strings listing which architectures should be
built for those platform variants (for example, `x86_64`, `arm64`) as their values.2{}�
�
macosxA list of strings indicating which architecture should be built for the macOS platform (for example, `x86_64`, `arm64`).2[]�
�
tvos�A dictionary of strings indicating which platform variants should be built for the tvOS platform (
`device` or `simulator`) as keys, and arrays of strings listing which architectures should be
built for those platform variants (for example, `x86_64`, `arm64`) as their values.2{}�
�
visionos�A dictionary of strings indicating which platform variants should be built for the visionOS platform
(`device` or `simulator`) as keys, and arrays of strings listing which architectures should be
built for those platform variants (for example, `arm64`) as their values.2{}�
�
minimum_deployment_os_versions�A dictionary of strings indicating the minimum deployment OS version supported by the target,
represented as a dotted version number (for example, "9.0") as values, with their respective
platforms such as `ios` as keys. This is different from `minimum_os_versions`, which is effective
at compile time. Ensure version specific APIs are guarded with `available` clauses.
2{}�
�
minimum_os_versions�A dictionary of strings indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "8.0") as values, with their respective platforms such as `ios`,
or `tvos` as keys:

    minimum_os_versions = {
        "ios": "13.0",
        "tvos": "15.0",
        "visionos": "1.0",
    }
 �
�
public_hdrs�A list of files directly referencing header files to be used as the publicly visible interface for
each of these embedded frameworks. These header files will be embedded within each bundle,
typically in a subdirectory such as `Headers`.2[]�
�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-versioning.md#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2None�
�
umbrella_header�An optional single .h file to use as the umbrella header for this framework. Usually, this header
will have the same name as this target, so that clients can load the header using the #import
<MyFramework/MyFramework.h> format. If this attribute is not specified (the common use case), an
umbrella header will be generated under the same name as this target.2None�local_provisioning_profile�	This rule declares a bazel target that you can pass to the
`provisioning_profile` attribute of rules that support it. It discovers a
provisioning profile for the given attributes either on the user's local
machine, or with the optional `fallback_profiles` passed to
`provisioning_profile_repository`.

This rule will automatically pick the newest
profile if there are multiple profiles matching the given criteria.

By default this rule will search for a `.mobileprovision` file with the same name
as the rule itself, you can pass `profile_name` to use a different name, you
can pass `team_id` if you'd like to disambiguate between 2 Apple developer accounts
that have the same profile name. You may also pass `.provisionprofile` to
`profile_extension` to search for a macOS provisioning profile instead.

## Example

```starlark
load("//apple:apple.bzl", "local_provisioning_profile")

local_provisioning_profile(
    name = "app_debug_profile",
    profile_name = "Development App",
    team_id = "abc123",
)

ios_application(
    name = "app",
    ...
    provisioning_profile = ":app_debug_profile",
)

local_provisioning_profile(
    name = "app_release_profile",
)

ios_application(
    name = "release_app",
    ...
    provisioning_profile = ":app_release_profile",
)
```"�
�
local_provisioning_profile�	This rule declares a bazel target that you can pass to the
`provisioning_profile` attribute of rules that support it. It discovers a
provisioning profile for the given attributes either on the user's local
machine, or with the optional `fallback_profiles` passed to
`provisioning_profile_repository`.

This rule will automatically pick the newest
profile if there are multiple profiles matching the given criteria.

By default this rule will search for a `.mobileprovision` file with the same name
as the rule itself, you can pass `profile_name` to use a different name, you
can pass `team_id` if you'd like to disambiguate between 2 Apple developer accounts
that have the same profile name. You may also pass `.provisionprofile` to
`profile_extension` to search for a macOS provisioning profile instead.

## Example

```starlark
load("//apple:apple.bzl", "local_provisioning_profile")

local_provisioning_profile(
    name = "app_debug_profile",
    profile_name = "Development App",
    team_id = "abc123",
)

ios_application(
    name = "app",
    ...
    provisioning_profile = ":app_debug_profile",
)

local_provisioning_profile(
    name = "app_release_profile",
)

ios_application(
    name = "release_app",
    ...
    provisioning_profile = ":app_release_profile",
)
```*
nameA unique name for this target. �
profile_extensionHThe extension for the provisioning profile which may differ by platform.2".mobileprovision"J".mobileprovision"J".provisionprofile"c
profile_nameMName of the profile to use, if it's not provided the name of the rule is used2""�
team_id�Team ID of the profile to find. This is useful for disambiguating between multiple profiles with the same name on different developer accounts.2"""Z
local_provisioning_profile<@rules_apple//apple/internal:local_provisioning_profiles.bzl,
*
nameA unique name for this target. �
�
profile_extensionHThe extension for the provisioning profile which may differ by platform.2".mobileprovision"J".mobileprovision"J".provisionprofile"e
c
profile_nameMName of the profile to use, if it's not provided the name of the rule is used2""�
�
team_id�Team ID of the profile to find. This is useful for disambiguating between multiple profiles with the same name on different developer accounts.2""�)provisioning_profile_repository_extensionlSee [`provisioning_profile_repository`](#provisioning_profile_repository) for more information and examples.J�
�
)provisioning_profile_repository_extensionlSee [`provisioning_profile_repository`](#provisioning_profile_repository) for more information and examples.$
setup
fallback_profiles2None"><@rules_apple//apple/internal:local_provisioning_profiles.bzlE
$
setup
fallback_profiles2None

fallback_profiles2None�provisioning_profile_repository�	This rule declares an external repository for discovering locally installed
provisioning profiles. This is consumed by `local_provisioning_profile`.
You can optionally set 'fallback_profiles' to point at a stable location of
profiles if a newer version of the desired profile does not exist on the local
machine. This is useful for checking in the current version of the profile, but
not having to update it every time a new device or certificate is added.

## Example

### In your `MODULE.bazel` file:

You only need this in the case you want to setup fallback profiles, otherwise
it can be ommitted when using bzlmod.

```bzl
provisioning_profile_repository = use_extension("@rules_apple//apple:apple.bzl", "provisioning_profile_repository_extension")
provisioning_profile_repository.setup(
    fallback_profiles = "//path/to/some:filegroup", # Profiles to use if one isn't found locally
)
```

### In your `BUILD` files (see `local_provisioning_profile` for more examples):

```starlark
load("//apple:apple.bzl", "local_provisioning_profile")

local_provisioning_profile(
    name = "app_debug_profile",
    profile_name = "Development App",
    team_id = "abc123",
)

ios_application(
    name = "app",
    ...
    provisioning_profile = ":app_debug_profile",
)
```R�
�
provisioning_profile_repository�	This rule declares an external repository for discovering locally installed
provisioning profiles. This is consumed by `local_provisioning_profile`.
You can optionally set 'fallback_profiles' to point at a stable location of
profiles if a newer version of the desired profile does not exist on the local
machine. This is useful for checking in the current version of the profile, but
not having to update it every time a new device or certificate is added.

## Example

### In your `MODULE.bazel` file:

You only need this in the case you want to setup fallback profiles, otherwise
it can be ommitted when using bzlmod.

```bzl
provisioning_profile_repository = use_extension("@rules_apple//apple:apple.bzl", "provisioning_profile_repository_extension")
provisioning_profile_repository.setup(
    fallback_profiles = "//path/to/some:filegroup", # Profiles to use if one isn't found locally
)
```

### In your `BUILD` files (see `local_provisioning_profile` for more examples):

```starlark
load("//apple:apple.bzl", "local_provisioning_profile")

local_provisioning_profile(
    name = "app_debug_profile",
    profile_name = "Development App",
    team_id = "abc123",
)

ios_application(
    name = "app",
    ...
    provisioning_profile = ":app_debug_profile",
)
```.
name"A unique name for this repository. 
fallback_profiles2None"HOME*_
provisioning_profile_repository<@rules_apple//apple/internal:local_provisioning_profiles.bzl0
.
name"A unique name for this repository. 

fallback_profiles2None*# Rules that apply to all Apple platforms.�,

rules_appleappledocc.bzl�+docc_archive�Builds a .doccarchive for the given dependency.
The target created by this rule can also be `run` to preview the generated documentation in Xcode.

NOTE: At this time Swift is the only supported language for this rule.

Example:

```starlark
load("@rules_apple//apple:docc.bzl", "docc_archive")

docc_archive(
    name = "Lib.doccarchive",
    dep = ":Lib",
    fallback_bundle_identifier = "com.example.lib",
    fallback_bundle_version = "1.0.0",
    fallback_display_name = "Lib",
)
```"�'
�
docc_archive�Builds a .doccarchive for the given dependency.
The target created by this rule can also be `run` to preview the generated documentation in Xcode.

NOTE: At this time Swift is the only supported language for this rule.

Example:

```starlark
load("@rules_apple//apple:docc.bzl", "docc_archive")

docc_archive(
    name = "Lib.doccarchive",
    dep = ":Lib",
    fallback_bundle_identifier = "com.example.lib",
    fallback_bundle_version = "1.0.0",
    fallback_display_name = "Lib",
)
```*
nameA unique name for this target. �
dep*E
DocCBundleInfo3
DocCBundleInfo!@rules_apple//apple:providers.bzl*Q
DocCSymbolGraphsInfo9
DocCSymbolGraphsInfo!@rules_apple//apple:providers.bzl2None�
default_code_listing_languagetA fallback default language for code listings if no value is provided in the documentation bundle's Info.plist file.2""�
diagnostic_level�Filters diagnostics above this level from output
This filter level is inclusive. If a level of `information` is specified, diagnostics with a severity up to and including `information` will be printed.
Must be one of "error", "warning", "information", or "hint"2""J"error"J	"warning"J"information"J"hint"�
emit_extension_block_symbols�Defines if the symbol graph information for `extension` blocks should be
emitted in addition to the default symbol graph information.

This value must be either `"0"` or `"1"`.When the value is `"1"`, the symbol
graph information for `extension` blocks will be emitted in addition to
the default symbol graph information. The default value is `"0"`.2"0"J"0"J"1"N
enable_inherited_docs,Inherit documentation for inherited symbols.2False�
fallback_bundle_identifiercA fallback bundle identifier if no value is provided in the documentation bundle's Info.plist file. 
fallback_bundle_version`A fallback bundle version if no value is provided in the documentation bundle's Info.plist file. {
fallback_display_name^A fallback display name if no value is provided in the documentation bundle's Info.plist file. �
hosting_base_path�The base path your documentation website will be hosted at. For example, to deploy your site to 'example.com/my_name/my_project/documentation' instead of 'example.com/documentation', pass '/my_name/my_project' as the base path.2""K
kinds<The kinds of entities to filter generated documentation for.2[]�
minimum_access_level�"
The minimum access level of the declarations that should be emitted in the symbol graphs.
This value must be either `fileprivate`, `internal`, `private`, or `public`. The default value is `public`.2"public"J"fileprivate"J
"internal"J	"private"J"public"&
transform_for_static_hosting2True"5
docc_archive%@rules_apple//apple/internal:docc.bzl8,
*
nameA unique name for this target. �
�
dep*E
DocCBundleInfo3
DocCBundleInfo!@rules_apple//apple:providers.bzl*Q
DocCSymbolGraphsInfo9
DocCSymbolGraphsInfo!@rules_apple//apple:providers.bzl2None�
�
default_code_listing_languagetA fallback default language for code listings if no value is provided in the documentation bundle's Info.plist file.2""�
�
diagnostic_level�Filters diagnostics above this level from output
This filter level is inclusive. If a level of `information` is specified, diagnostics with a severity up to and including `information` will be printed.
Must be one of "error", "warning", "information", or "hint"2""J"error"J	"warning"J"information"J"hint"�
�
emit_extension_block_symbols�Defines if the symbol graph information for `extension` blocks should be
emitted in addition to the default symbol graph information.

This value must be either `"0"` or `"1"`.When the value is `"1"`, the symbol
graph information for `extension` blocks will be emitted in addition to
the default symbol graph information. The default value is `"0"`.2"0"J"0"J"1"P
N
enable_inherited_docs,Inherit documentation for inherited symbols.2False�
�
fallback_bundle_identifiercA fallback bundle identifier if no value is provided in the documentation bundle's Info.plist file. �

fallback_bundle_version`A fallback bundle version if no value is provided in the documentation bundle's Info.plist file. }
{
fallback_display_name^A fallback display name if no value is provided in the documentation bundle's Info.plist file. �
�
hosting_base_path�The base path your documentation website will be hosted at. For example, to deploy your site to 'example.com/my_name/my_project/documentation' instead of 'example.com/documentation', pass '/my_name/my_project' as the base path.2""M
K
kinds<The kinds of entities to filter generated documentation for.2[]�
�
minimum_access_level�"
The minimum access level of the declarations that should be emitted in the symbol graphs.
This value must be either `fileprivate`, `internal`, `private`, or `public`. The default value is `public`.2"public"J"fileprivate"J
"internal"J	"private"J"public"(
&
transform_for_static_hosting2True.Defines rules for building Apple DocC targets.�
 
rules_appleapple
dtrace.bzl�dtrace_compile�Compiles
[dtrace files with probes](https://www.ibm.com/developerworks/aix/library/au-dtraceprobes.html)
to generate header files to use those probes in C languages. The header files
generated will have the same name as the source files but with a `.h`
extension. Headers will be generated in a label scoped workspace relative file
structure. For example with a directory structure of

```
  Workspace
  foo/
    bar.d
```
and a target named `dtrace_gen` the header path would be
`<GENFILES>/dtrace_gen/foo/bar.h`."�
�
dtrace_compile�Compiles
[dtrace files with probes](https://www.ibm.com/developerworks/aix/library/au-dtraceprobes.html)
to generate header files to use those probes in C languages. The header files
generated will have the same name as the source files but with a `.h`
extension. Headers will be generated in a label scoped workspace relative file
structure. For example with a directory structure of

```
  Workspace
  foo/
    bar.d
```
and a target named `dtrace_gen` the header path would be
`<GENFILES>/dtrace_gen/foo/bar.h`.*
nameA unique name for this target. '
dtracedtrace binary to use.2None5
srcs'dtrace(.d) source files to be compiled.2[]"0
dtrace_compile@rules_apple//apple:dtrace.bzl,
*
nameA unique name for this target. )
'
dtracedtrace binary to use.2None7
5
srcs'dtrace(.d) source files to be compiled.2[]&# Bazel rules for working with dtrace.�
$
rules_appleappleheader_map.bzl�
header_map�	Creates a binary `.hmap` file from the given headers suitable for passing to clang.

Headermaps can be used in `-I` and `-iquote` compile flags (as well as in `includes`) to tell clang where to find headers.
This can be used to allow headers to be imported at a consistent path regardless of the package structure being used.

For example, if you have a package structure like this:

    ```
    MyLib/
        headers/
            MyLib.h
        MyLib.c
        BUILD
    ```

And you want to import `MyLib.h` from `MyLib.c` using angle bracket imports: `#import <MyLib/MyLib.h>`
You can create a header map like this:

    ```bzl
    header_map(
        name = "MyLib.hmap",
        hdrs = ["headers/MyLib.h"],
    )
    ```

This generates a binary headermap that looks like:

    ```
    MyLib.h -> headers/MyLib.h
    MyLib/MyLib.h -> headers/MyLib.h
    ```

Then update `deps`, `copts` and `includes` to use the header map:

    ```bzl
    objc_library(
        name = "MyLib",
        module_name = "MyLib",
        srcs = ["MyLib.c"],
        hdrs = ["headers/MyLib.h"],
        deps = [":MyLib.hmap"],
        copts = ["-I.]
        includes = ["MyLib.hmap"]
    )
    ```"�
�

header_map�	Creates a binary `.hmap` file from the given headers suitable for passing to clang.

Headermaps can be used in `-I` and `-iquote` compile flags (as well as in `includes`) to tell clang where to find headers.
This can be used to allow headers to be imported at a consistent path regardless of the package structure being used.

For example, if you have a package structure like this:

    ```
    MyLib/
        headers/
            MyLib.h
        MyLib.c
        BUILD
    ```

And you want to import `MyLib.h` from `MyLib.c` using angle bracket imports: `#import <MyLib/MyLib.h>`
You can create a header map like this:

    ```bzl
    header_map(
        name = "MyLib.hmap",
        hdrs = ["headers/MyLib.h"],
    )
    ```

This generates a binary headermap that looks like:

    ```
    MyLib.h -> headers/MyLib.h
    MyLib/MyLib.h -> headers/MyLib.h
    ```

Then update `deps`, `copts` and `includes` to use the header map:

    ```bzl
    objc_library(
        name = "MyLib",
        module_name = "MyLib",
        srcs = ["MyLib.c"],
        hdrs = ["headers/MyLib.h"],
        deps = [":MyLib.hmap"],
        copts = ["-I.]
        includes = ["MyLib.hmap"]
    )
    ```*
nameA unique name for this target. =
module_name(The prefix to be used for header imports2""<
hdrs.The list of headers included in the header_map2[]�
deps^Targets whose direct headers should be added to the list of hdrs and rooted at the module_name*?
ObjcInfo3
ObjcInfo'@@_builtins//:common/objc/objc_info.bzl*5
CcInfo+
CcInfo!@rules_cc//cc/private:cc_info.bzl2[]"9

header_map+@rules_apple//apple/internal:header_map.bzl,
*
nameA unique name for this target. ?
=
module_name(The prefix to be used for header imports2"">
<
hdrs.The list of headers included in the header_map2[]�
�
deps^Targets whose direct headers should be added to the list of hdrs and rooted at the module_name*?
ObjcInfo3
ObjcInfo'@@_builtins//:common/objc/objc_info.bzl*5
CcInfo+
CcInfo!@rules_cc//cc/private:cc_info.bzl2[]Rules for creating header maps.��

rules_appleappleios.bzl��ios_application&Builds and bundles an iOS Application."��
�T
ios_application&Builds and bundles an iOS Application.*
nameA unique name for this target. �
	app_icons�Files that comprise the app icons for the application. Each file must have a containing directory
named `*..xcassets/*..appiconset` and there may be only one such
`..appiconset` directory in the list. In Xcode 26+ for iOS/macOS/watchOS, an `*.icon`
bundle can be provided along with the `*..xcassets` bundle to support 26 and
pre-26 Apple OS rendering.2[]�
primary_app_icon�An optional String to identify the name of the primary app icon when alternate app icons have been
provided for the app. This should match both the `*.icon` bundle in iOS/macOS/watchOS 26+ and the
`*..xcassets/.appiconset` bundle's AppIcon resource in previous versions of
iOS/macOS/watchOS.2""�
app_intents:List of dependencies implementing the AppIntents protocol.*;
	SwiftInfo.
	SwiftInfo!@rules_swift//swift:providers.bzl2[]�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonea
familiesQA list of device families supported by this rule. At least one must be specified. �

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. If not provided,
a default Info.plist will be used. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported.2H["@rules_apple//apple/internal/templates:default_application_infoplist"]�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
launch_images�Files that comprise the launch images for the application. Each file must have a containing
directory named `*.xcassets/*.launchimage` and there may be only one such `.launchimage` directory
in the list.2[]�
locales_to_include�A list of locales to include in the bundle. Only *.lproj directories that are matched will be copied as a part of the build.
This value takes precedence (and is preferred) over locales defined using `--define "apple.locales_to_include=..."`.2[]�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""
platform_type2"ios"�
settings_bundle�A resource bundle (e.g. `apple_bundle_import`) target that contains the files that make up the
application's settings bundle. These files will be copied into the root of the final application
bundle in a directory named `Settings.bundle`.*`
AppleResourceBundleInfoE
AppleResourceBundleInfo*@rules_apple//apple/internal:providers.bzl*?
ObjcInfo3
ObjcInfo'@@_builtins//:common/objc/objc_info.bzl2None�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID rule found within
`signed_capabilities`.2""�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
a base bundle ID rule found within `signed_capabilities`, then this string will be appended to the
end of the bundle ID following a "." separator.2"_"�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
entitlements�The entitlements file required for device builds of this target. If absent, the default entitlements
from the provisioning profile will be used.

The following variables are substituted in the entitlements file: `$(CFBundleIdentifier)` with the
bundle ID of the application and `$(AppIdentifierPrefix)` with the value of the
`ApplicationIdentifierPrefix` key from the target's provisioning profile.2None�
entitlements_validation�An `entitlements_validation_mode` to control the validation of the requested entitlements against
the provisioning profile to ensure they are supported.2"loose"J"error"J"warn"J"loose"J"skip"�
shared_capabilities�A list of shared `apple_capability_set` rules to represent the capabilities that a code sign aware
Apple bundle rule output should have. These can define the formal prefix for the target's
`bundle_id` and can further be merged with information provided by `entitlements`, if defined by any
capabilities found within the `apple_capability_set`.*d
AppleSharedCapabilityInfoG
AppleSharedCapabilityInfo*@rules_apple//apple/internal:providers.bzl2[]�
alternate_icons�Files that comprise the alternate app icons for the application. Each file must have a containing directory
named after the alternate icon identifier.2[]�
	app_clipsCA list of iOS app clips to include in the final application bundle.*�
AppleBundleInfo
IosAppClipBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlB
IosAppClipBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�

extensionsPA list of iOS application extensions to include in the final application bundle.*�
AppleBundleInfo
IosExtensionBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlD
IosExtensionBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�

frameworks�A list of framework targets (see
[`ios_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-ios.md#ios_framework))
that this target depends on.*�
AppleBundleInfo
IosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlD
IosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�
include_symbols_in_bundle�If true and --output_groups=+dsyms is specified, generates `$UUID.symbols`
files from all `{binary: .dSYM, ...}` pairs for the application and its
dependencies, then packages them under the `Symbols/` directory in the
final application bundle.2False�
launch_storyboard�The `.storyboard` or `.xib` file that should be used as the launch screen for the application. The
provided file will be compiled into the appropriate format (`.storyboardc` or `.nib`) and placed in
the root of the final bundle. The generated file will also be registered in the bundle's
Info.plist under the key `UILaunchStoryboardName`.2None�
sdk_frameworks�Names of SDK frameworks to link with (e.g., `AddressBook`, `QuartzCore`).
`UIKit` and `Foundation` are always included, even if this attribute is
provided and does not list them.

This attribute is discouraged; in general, targets should list system
framework dependencies in the library targets where that framework is used,
not in the top-level bundle.2[]�
watch_application�A `watchos_application` target that represents an Apple Watch application or a
`watchos_single_target_application` target that represents a single-target Apple Watch application
that should be embedded in the application bundle.*�
AppleBundleInfo
WatchosApplicationBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlJ
WatchosApplicationBundleInfo*@rules_apple//apple/internal:providers.bzl2None"=
ios_application*@rules_apple//apple/internal:ios_rules.bzl8,
*
nameA unique name for this target. �
�
	app_icons�Files that comprise the app icons for the application. Each file must have a containing directory
named `*..xcassets/*..appiconset` and there may be only one such
`..appiconset` directory in the list. In Xcode 26+ for iOS/macOS/watchOS, an `*.icon`
bundle can be provided along with the `*..xcassets` bundle to support 26 and
pre-26 Apple OS rendering.2[]�
�
primary_app_icon�An optional String to identify the name of the primary app icon when alternate app icons have been
provided for the app. This should match both the `*.icon` bundle in iOS/macOS/watchOS 26+ and the
`*..xcassets/.appiconset` bundle's AppIcon resource in previous versions of
iOS/macOS/watchOS.2""�
�
app_intents:List of dependencies implementing the AppIntents protocol.*;
	SwiftInfo.
	SwiftInfo!@rules_swift//swift:providers.bzl2[]�
�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]g
e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]c
a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]U
S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonec
a
familiesQA list of device families supported by this rule. At least one must be specified. �
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. If not provided,
a default Info.plist will be used. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported.2H["@rules_apple//apple/internal/templates:default_application_infoplist"]�
�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
�
launch_images�Files that comprise the launch images for the application. Each file must have a containing
directory named `*.xcassets/*.launchimage` and there may be only one such `.launchimage` directory
in the list.2[]�
�
locales_to_include�A list of locales to include in the bundle. Only *.lproj directories that are matched will be copied as a part of the build.
This value takes precedence (and is preferred) over locales defined using `--define "apple.locales_to_include=..."`.2[]�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""

platform_type2"ios"�
�
settings_bundle�A resource bundle (e.g. `apple_bundle_import`) target that contains the files that make up the
application's settings bundle. These files will be copied into the root of the final application
bundle in a directory named `Settings.bundle`.*`
AppleResourceBundleInfoE
AppleResourceBundleInfo*@rules_apple//apple/internal:providers.bzl*?
ObjcInfo3
ObjcInfo'@@_builtins//:common/objc/objc_info.bzl2None�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID rule found within
`signed_capabilities`.2""�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
a base bundle ID rule found within `signed_capabilities`, then this string will be appended to the
end of the bundle ID following a "." separator.2"_"�
�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
entitlements�The entitlements file required for device builds of this target. If absent, the default entitlements
from the provisioning profile will be used.

The following variables are substituted in the entitlements file: `$(CFBundleIdentifier)` with the
bundle ID of the application and `$(AppIdentifierPrefix)` with the value of the
`ApplicationIdentifierPrefix` key from the target's provisioning profile.2None�
�
entitlements_validation�An `entitlements_validation_mode` to control the validation of the requested entitlements against
the provisioning profile to ensure they are supported.2"loose"J"error"J"warn"J"loose"J"skip"�
�
shared_capabilities�A list of shared `apple_capability_set` rules to represent the capabilities that a code sign aware
Apple bundle rule output should have. These can define the formal prefix for the target's
`bundle_id` and can further be merged with information provided by `entitlements`, if defined by any
capabilities found within the `apple_capability_set`.*d
AppleSharedCapabilityInfoG
AppleSharedCapabilityInfo*@rules_apple//apple/internal:providers.bzl2[]�
�
alternate_icons�Files that comprise the alternate app icons for the application. Each file must have a containing directory
named after the alternate icon identifier.2[]�
�
	app_clipsCA list of iOS app clips to include in the final application bundle.*�
AppleBundleInfo
IosAppClipBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlB
IosAppClipBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�
�

extensionsPA list of iOS application extensions to include in the final application bundle.*�
AppleBundleInfo
IosExtensionBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlD
IosExtensionBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�
�

frameworks�A list of framework targets (see
[`ios_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-ios.md#ios_framework))
that this target depends on.*�
AppleBundleInfo
IosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlD
IosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�
�
include_symbols_in_bundle�If true and --output_groups=+dsyms is specified, generates `$UUID.symbols`
files from all `{binary: .dSYM, ...}` pairs for the application and its
dependencies, then packages them under the `Symbols/` directory in the
final application bundle.2False�
�
launch_storyboard�The `.storyboard` or `.xib` file that should be used as the launch screen for the application. The
provided file will be compiled into the appropriate format (`.storyboardc` or `.nib`) and placed in
the root of the final bundle. The generated file will also be registered in the bundle's
Info.plist under the key `UILaunchStoryboardName`.2None�
�
sdk_frameworks�Names of SDK frameworks to link with (e.g., `AddressBook`, `QuartzCore`).
`UIKit` and `Foundation` are always included, even if this attribute is
provided and does not list them.

This attribute is discouraged; in general, targets should list system
framework dependencies in the library targets where that framework is used,
not in the top-level bundle.2[]�
�
watch_application�A `watchos_application` target that represents an Apple Watch application or a
`watchos_single_target_application` target that represents a single-target Apple Watch application
that should be embedded in the application bundle.*�
AppleBundleInfo
WatchosApplicationBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlJ
WatchosApplicationBundleInfo*@rules_apple//apple/internal:providers.bzl2None��ios_app_clip#Builds and bundles an iOS App Clip."
�@
ios_app_clip#Builds and bundles an iOS App Clip.*
nameA unique name for this target. �
	app_icons�Files that comprise the app icons for the application. Each file must have a containing directory
named `*..xcassets/*..appiconset` and there may be only one such
`..appiconset` directory in the list. In Xcode 26+ for iOS/macOS/watchOS, an `*.icon`
bundle can be provided along with the `*..xcassets` bundle to support 26 and
pre-26 Apple OS rendering.2[]�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonea
familiesQA list of device families supported by this rule. At least one must be specified. �

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
locales_to_include�A list of locales to include in the bundle. Only *.lproj directories that are matched will be copied as a part of the build.
This value takes precedence (and is preferred) over locales defined using `--define "apple.locales_to_include=..."`.2[]�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""
platform_type2"ios"�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID rule found within
`signed_capabilities`.2""�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
a base bundle ID rule found within `signed_capabilities`, then this string will be appended to the
end of the bundle ID following a "." separator.2"bundle_name"�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
entitlements�The entitlements file required for device builds of this target. If absent, the default entitlements
from the provisioning profile will be used.

The following variables are substituted in the entitlements file: `$(CFBundleIdentifier)` with the
bundle ID of the application and `$(AppIdentifierPrefix)` with the value of the
`ApplicationIdentifierPrefix` key from the target's provisioning profile.2None�
entitlements_validation�An `entitlements_validation_mode` to control the validation of the requested entitlements against
the provisioning profile to ensure they are supported.2"loose"J"error"J"warn"J"loose"J"skip"�
shared_capabilities�A list of shared `apple_capability_set` rules to represent the capabilities that a code sign aware
Apple bundle rule output should have. These can define the formal prefix for the target's
`bundle_id` and can further be merged with information provided by `entitlements`, if defined by any
capabilities found within the `apple_capability_set`.*d
AppleSharedCapabilityInfoG
AppleSharedCapabilityInfo*@rules_apple//apple/internal:providers.bzl2[]�

frameworks�A list of framework targets (see
[`ios_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-ios.md#ios_framework))
that this target depends on.*�
AppleBundleInfo
IosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlD
IosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�
launch_storyboard�The `.storyboard` or `.xib` file that should be used as the launch screen for the app clip. The
provided file will be compiled into the appropriate format (`.storyboardc` or `.nib`) and placed in
the root of the final bundle. The generated file will also be registered in the bundle's
Info.plist under the key `UILaunchStoryboardName`.2None�

extensions�A list of ios_extension live activity extensions to include in the final app clip bundle.
It is only possible to embed live activity WidgetKit extensions.
Visit Apple developer documentation page for more info https://developer.apple.com/documentation/appclip/offering-live-activities-with-your-app-clip.*�
AppleBundleInfo
IosExtensionBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlD
IosExtensionBundleInfo*@rules_apple//apple/internal:providers.bzl2[]":
ios_app_clip*@rules_apple//apple/internal:ios_rules.bzl8,
*
nameA unique name for this target. �
�
	app_icons�Files that comprise the app icons for the application. Each file must have a containing directory
named `*..xcassets/*..appiconset` and there may be only one such
`..appiconset` directory in the list. In Xcode 26+ for iOS/macOS/watchOS, an `*.icon`
bundle can be provided along with the `*..xcassets` bundle to support 26 and
pre-26 Apple OS rendering.2[]�
�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]g
e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]c
a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]U
S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonec
a
familiesQA list of device families supported by this rule. At least one must be specified. �
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
�
locales_to_include�A list of locales to include in the bundle. Only *.lproj directories that are matched will be copied as a part of the build.
This value takes precedence (and is preferred) over locales defined using `--define "apple.locales_to_include=..."`.2[]�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""

platform_type2"ios"�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID rule found within
`signed_capabilities`.2""�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
a base bundle ID rule found within `signed_capabilities`, then this string will be appended to the
end of the bundle ID following a "." separator.2"bundle_name"�
�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
entitlements�The entitlements file required for device builds of this target. If absent, the default entitlements
from the provisioning profile will be used.

The following variables are substituted in the entitlements file: `$(CFBundleIdentifier)` with the
bundle ID of the application and `$(AppIdentifierPrefix)` with the value of the
`ApplicationIdentifierPrefix` key from the target's provisioning profile.2None�
�
entitlements_validation�An `entitlements_validation_mode` to control the validation of the requested entitlements against
the provisioning profile to ensure they are supported.2"loose"J"error"J"warn"J"loose"J"skip"�
�
shared_capabilities�A list of shared `apple_capability_set` rules to represent the capabilities that a code sign aware
Apple bundle rule output should have. These can define the formal prefix for the target's
`bundle_id` and can further be merged with information provided by `entitlements`, if defined by any
capabilities found within the `apple_capability_set`.*d
AppleSharedCapabilityInfoG
AppleSharedCapabilityInfo*@rules_apple//apple/internal:providers.bzl2[]�
�

frameworks�A list of framework targets (see
[`ios_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-ios.md#ios_framework))
that this target depends on.*�
AppleBundleInfo
IosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlD
IosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�
�
launch_storyboard�The `.storyboard` or `.xib` file that should be used as the launch screen for the app clip. The
provided file will be compiled into the appropriate format (`.storyboardc` or `.nib`) and placed in
the root of the final bundle. The generated file will also be registered in the bundle's
Info.plist under the key `UILaunchStoryboardName`.2None�
�

extensions�A list of ios_extension live activity extensions to include in the final app clip bundle.
It is only possible to embed live activity WidgetKit extensions.
Visit Apple developer documentation page for more info https://developer.apple.com/documentation/appclip/offering-live-activities-with-your-app-clip.*�
AppleBundleInfo
IosExtensionBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlD
IosExtensionBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�bios_dynamic_frameworkHBuilds and bundles an iOS dynamic framework that is consumable by Xcode."�a
�1
ios_dynamic_frameworkHBuilds and bundles an iOS dynamic framework that is consumable by Xcode.*
nameA unique name for this target. �
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nones
familiesQA list of device families supported by this rule. At least one must be specified.2["iphone", "ipad"]�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""
platform_type2"ios"�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2""�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2"bundle_name"�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
bundle_only�Avoid linking the dynamic framework, but still include it in the app. This is useful when you want
to manually dlopen the framework at runtime.2False�
extension_safe�If true, compiles and links this framework with `-application-extension`, restricting the binary to
use only extension-safe APIs.2False�

frameworks�A list of framework targets (see
[`ios_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-ios.md#ios_framework))
that this target depends on.*�
AppleBundleInfo
IosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlD
IosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]
hdrs2[]"C
ios_dynamic_framework*@rules_apple//apple/internal:ios_rules.bzl,
*
nameA unique name for this target. �
�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]g
e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]c
a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]U
S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Noneu
s
familiesQA list of device families supported by this rule. At least one must be specified.2["iphone", "ipad"]�
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""

platform_type2"ios"�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2""�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2"bundle_name"�
�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
�
bundle_only�Avoid linking the dynamic framework, but still include it in the app. This is useful when you want
to manually dlopen the framework at runtime.2False�
�
extension_safe�If true, compiles and links this framework with `-application-extension`, restricting the binary to
use only extension-safe APIs.2False�
�

frameworks�A list of framework targets (see
[`ios_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-ios.md#ios_framework))
that this target depends on.*�
AppleBundleInfo
IosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlD
IosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]

hdrs2[]܂ios_extension�Builds and bundles an iOS Application Extension.

Most iOS app extensions use a plug-in-based architecture where the executable's entry point
is provided by a system framework.
However, iOS 14 introduced Widget Extensions that use a traditional `main` entry point
(typically expressed through Swift's `@main` attribute)."��
�A
ios_extension�Builds and bundles an iOS Application Extension.

Most iOS app extensions use a plug-in-based architecture where the executable's entry point
is provided by a system framework.
However, iOS 14 introduced Widget Extensions that use a traditional `main` entry point
(typically expressed through Swift's `@main` attribute).*
nameA unique name for this target. �
	app_icons�Files that comprise the app icons for the application. Each file must have a containing directory
named `*..xcassets/*..appiconset` and there may be only one such
`..appiconset` directory in the list. In Xcode 26+ for iOS/macOS/watchOS, an `*.icon`
bundle can be provided along with the `*..xcassets` bundle to support 26 and
pre-26 Apple OS rendering.2[]�
app_intents:List of dependencies implementing the AppIntents protocol.*;
	SwiftInfo.
	SwiftInfo!@rules_swift//swift:providers.bzl2[]�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonea
familiesQA list of device families supported by this rule. At least one must be specified. k
extensionkit_extensionHIndicates if this target should be treated as an ExtensionKit extension.2False�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
locales_to_include�A list of locales to include in the bundle. Only *.lproj directories that are matched will be copied as a part of the build.
This value takes precedence (and is preferred) over locales defined using `--define "apple.locales_to_include=..."`.2[]�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""
platform_type2"ios"�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID rule found within
`signed_capabilities`.2""�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
a base bundle ID rule found within `signed_capabilities`, then this string will be appended to the
end of the bundle ID following a "." separator.2"bundle_name"�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
entitlements�The entitlements file required for device builds of this target. If absent, the default entitlements
from the provisioning profile will be used.

The following variables are substituted in the entitlements file: `$(CFBundleIdentifier)` with the
bundle ID of the application and `$(AppIdentifierPrefix)` with the value of the
`ApplicationIdentifierPrefix` key from the target's provisioning profile.2None�
entitlements_validation�An `entitlements_validation_mode` to control the validation of the requested entitlements against
the provisioning profile to ensure they are supported.2"loose"J"error"J"warn"J"loose"J"skip"�
shared_capabilities�A list of shared `apple_capability_set` rules to represent the capabilities that a code sign aware
Apple bundle rule output should have. These can define the formal prefix for the target's
`bundle_id` and can further be merged with information provided by `entitlements`, if defined by any
capabilities found within the `apple_capability_set`.*d
AppleSharedCapabilityInfoG
AppleSharedCapabilityInfo*@rules_apple//apple/internal:providers.bzl2[]�

frameworks�A list of framework targets (see
[`ios_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-ios.md#ios_framework))
that this target depends on.*�
AppleBundleInfo
IosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlD
IosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�
sdk_frameworks�Names of SDK frameworks to link with (e.g., `AddressBook`, `QuartzCore`).
`UIKit` and `Foundation` are always included, even if this attribute is
provided and does not list them.

This attribute is discouraged; in general, targets should list system
framework dependencies in the library targets where that framework is used,
not in the top-level bundle.2[]";
ios_extension*@rules_apple//apple/internal:ios_rules.bzl,
*
nameA unique name for this target. �
�
	app_icons�Files that comprise the app icons for the application. Each file must have a containing directory
named `*..xcassets/*..appiconset` and there may be only one such
`..appiconset` directory in the list. In Xcode 26+ for iOS/macOS/watchOS, an `*.icon`
bundle can be provided along with the `*..xcassets` bundle to support 26 and
pre-26 Apple OS rendering.2[]�
�
app_intents:List of dependencies implementing the AppIntents protocol.*;
	SwiftInfo.
	SwiftInfo!@rules_swift//swift:providers.bzl2[]�
�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]g
e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]c
a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]U
S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonec
a
familiesQA list of device families supported by this rule. At least one must be specified. m
k
extensionkit_extensionHIndicates if this target should be treated as an ExtensionKit extension.2False�
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
�
locales_to_include�A list of locales to include in the bundle. Only *.lproj directories that are matched will be copied as a part of the build.
This value takes precedence (and is preferred) over locales defined using `--define "apple.locales_to_include=..."`.2[]�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""

platform_type2"ios"�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID rule found within
`signed_capabilities`.2""�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
a base bundle ID rule found within `signed_capabilities`, then this string will be appended to the
end of the bundle ID following a "." separator.2"bundle_name"�
�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
entitlements�The entitlements file required for device builds of this target. If absent, the default entitlements
from the provisioning profile will be used.

The following variables are substituted in the entitlements file: `$(CFBundleIdentifier)` with the
bundle ID of the application and `$(AppIdentifierPrefix)` with the value of the
`ApplicationIdentifierPrefix` key from the target's provisioning profile.2None�
�
entitlements_validation�An `entitlements_validation_mode` to control the validation of the requested entitlements against
the provisioning profile to ensure they are supported.2"loose"J"error"J"warn"J"loose"J"skip"�
�
shared_capabilities�A list of shared `apple_capability_set` rules to represent the capabilities that a code sign aware
Apple bundle rule output should have. These can define the formal prefix for the target's
`bundle_id` and can further be merged with information provided by `entitlements`, if defined by any
capabilities found within the `apple_capability_set`.*d
AppleSharedCapabilityInfoG
AppleSharedCapabilityInfo*@rules_apple//apple/internal:providers.bzl2[]�
�

frameworks�A list of framework targets (see
[`ios_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-ios.md#ios_framework))
that this target depends on.*�
AppleBundleInfo
IosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlD
IosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�
�
sdk_frameworks�Names of SDK frameworks to link with (e.g., `AddressBook`, `QuartzCore`).
`UIKit` and `Foundation` are always included, even if this attribute is
provided and does not list them.

This attribute is discouraged; in general, targets should list system
framework dependencies in the library targets where that framework is used,
not in the top-level bundle.2[]�cios_framework�Builds and bundles an iOS Dynamic Framework.

To use this framework for your app and extensions, list it in the `frameworks` attributes
of those `ios_application` and/or `ios_extension` rules."�a
�1
ios_framework�Builds and bundles an iOS Dynamic Framework.

To use this framework for your app and extensions, list it in the `frameworks` attributes
of those `ios_application` and/or `ios_extension` rules.*
nameA unique name for this target. �
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonea
familiesQA list of device families supported by this rule. At least one must be specified. �

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""
platform_type2"ios"�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2""�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2"bundle_name"�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
bundle_only�Avoid linking the dynamic framework, but still include it in the app. This is useful when you want
to manually dlopen the framework at runtime.2False�

frameworks�A list of framework targets (see
[`ios_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-ios.md#ios_framework))
that this target depends on.*�
AppleBundleInfo
IosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlD
IosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�
extension_safe�If true, compiles and links this framework with `-application-extension`, restricting the binary to
use only extension-safe APIs.2False
hdrs2[]";
ios_framework*@rules_apple//apple/internal:ios_rules.bzl,
*
nameA unique name for this target. �
�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]g
e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]c
a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]U
S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonec
a
familiesQA list of device families supported by this rule. At least one must be specified. �
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""

platform_type2"ios"�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2""�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2"bundle_name"�
�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
�
bundle_only�Avoid linking the dynamic framework, but still include it in the app. This is useful when you want
to manually dlopen the framework at runtime.2False�
�

frameworks�A list of framework targets (see
[`ios_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-ios.md#ios_framework))
that this target depends on.*�
AppleBundleInfo
IosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlD
IosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�
�
extension_safe�If true, compiles and links this framework with `-application-extension`, restricting the binary to
use only extension-safe APIs.2False

hdrs2[]�^ios_imessage_application�Builds and bundles an iOS iMessage Application.

iOS iMessage applications do not have any dependencies, as it works mostly as a wrapper
for either an iOS iMessage extension or a Sticker Pack extension."�\
�/
ios_imessage_application�Builds and bundles an iOS iMessage Application.

iOS iMessage applications do not have any dependencies, as it works mostly as a wrapper
for either an iOS iMessage extension or a Sticker Pack extension.*
nameA unique name for this target. �
	app_icons�Files that comprise the app icons for the application. Each file must have a containing directory
named `*..xcassets/*..appiconset` and there may be only one such
`..appiconset` directory in the list. In Xcode 26+ for iOS/macOS/watchOS, an `*.icon`
bundle can be provided along with the `*..xcassets` bundle to support 26 and
pre-26 Apple OS rendering.2[]�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonea
familiesQA list of device families supported by this rule. At least one must be specified. �

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
locales_to_include�A list of locales to include in the bundle. Only *.lproj directories that are matched will be copied as a part of the build.
This value takes precedence (and is preferred) over locales defined using `--define "apple.locales_to_include=..."`.2[]�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""
platform_type2"ios"�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID rule found within
`signed_capabilities`.2""�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
a base bundle ID rule found within `signed_capabilities`, then this string will be appended to the
end of the bundle ID following a "." separator.2"_"�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
entitlements�The entitlements file required for device builds of this target. If absent, the default entitlements
from the provisioning profile will be used.

The following variables are substituted in the entitlements file: `$(CFBundleIdentifier)` with the
bundle ID of the application and `$(AppIdentifierPrefix)` with the value of the
`ApplicationIdentifierPrefix` key from the target's provisioning profile.2None�
entitlements_validation�An `entitlements_validation_mode` to control the validation of the requested entitlements against
the provisioning profile to ensure they are supported.2"loose"J"error"J"warn"J"loose"J"skip"�
shared_capabilities�A list of shared `apple_capability_set` rules to represent the capabilities that a code sign aware
Apple bundle rule output should have. These can define the formal prefix for the target's
`bundle_id` and can further be merged with information provided by `entitlements`, if defined by any
capabilities found within the `apple_capability_set`.*d
AppleSharedCapabilityInfoG
AppleSharedCapabilityInfo*@rules_apple//apple/internal:providers.bzl2[]�
	extensioniSingle label referencing either an ios_imessage_extension or ios_sticker_pack_extension target.
Required. *�
AppleBundleInfo
IosImessageExtensionBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlL
IosImessageExtensionBundleInfo*@rules_apple//apple/internal:providers.bzl*�
AppleBundleInfo
!IosStickerPackExtensionBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlF
!IosStickerPackExtensionBundleInfo!@rules_apple//apple:providers.bzl"F
ios_imessage_application*@rules_apple//apple/internal:ios_rules.bzl,
*
nameA unique name for this target. �
�
	app_icons�Files that comprise the app icons for the application. Each file must have a containing directory
named `*..xcassets/*..appiconset` and there may be only one such
`..appiconset` directory in the list. In Xcode 26+ for iOS/macOS/watchOS, an `*.icon`
bundle can be provided along with the `*..xcassets` bundle to support 26 and
pre-26 Apple OS rendering.2[]�
�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonec
a
familiesQA list of device families supported by this rule. At least one must be specified. �
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
�
locales_to_include�A list of locales to include in the bundle. Only *.lproj directories that are matched will be copied as a part of the build.
This value takes precedence (and is preferred) over locales defined using `--define "apple.locales_to_include=..."`.2[]�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""

platform_type2"ios"�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID rule found within
`signed_capabilities`.2""�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
a base bundle ID rule found within `signed_capabilities`, then this string will be appended to the
end of the bundle ID following a "." separator.2"_"�
�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
entitlements�The entitlements file required for device builds of this target. If absent, the default entitlements
from the provisioning profile will be used.

The following variables are substituted in the entitlements file: `$(CFBundleIdentifier)` with the
bundle ID of the application and `$(AppIdentifierPrefix)` with the value of the
`ApplicationIdentifierPrefix` key from the target's provisioning profile.2None�
�
entitlements_validation�An `entitlements_validation_mode` to control the validation of the requested entitlements against
the provisioning profile to ensure they are supported.2"loose"J"error"J"warn"J"loose"J"skip"�
�
shared_capabilities�A list of shared `apple_capability_set` rules to represent the capabilities that a code sign aware
Apple bundle rule output should have. These can define the formal prefix for the target's
`bundle_id` and can further be merged with information provided by `entitlements`, if defined by any
capabilities found within the `apple_capability_set`.*d
AppleSharedCapabilityInfoG
AppleSharedCapabilityInfo*@rules_apple//apple/internal:providers.bzl2[]�
�
	extensioniSingle label referencing either an ios_imessage_extension or ios_sticker_pack_extension target.
Required. *�
AppleBundleInfo
IosImessageExtensionBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlL
IosImessageExtensionBundleInfo*@rules_apple//apple/internal:providers.bzl*�
AppleBundleInfo
!IosStickerPackExtensionBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlF
!IosStickerPackExtensionBundleInfo!@rules_apple//apple:providers.bzl�Uios_sticker_pack_extension1Builds and bundles an iOS Sticker Pack Extension."�U
�*
ios_sticker_pack_extension1Builds and bundles an iOS Sticker Pack Extension.*
nameA unique name for this target. �
	app_icons�Files that comprise the app icons for the application. Each file must have a containing directory
named `*..xcstickers/*..stickersiconset` and there may be only one such
`..stickersiconset` directory in the list. In Xcode 26+ for iOS/macOS/watchOS, an `*.icon`
bundle can be provided along with the `*..xcstickers` bundle to support 26 and
pre-26 Apple OS rendering.2[]�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonea
familiesQA list of device families supported by this rule. At least one must be specified. �

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""
platform_type2"ios"�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID rule found within
`signed_capabilities`.2""�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
a base bundle ID rule found within `signed_capabilities`, then this string will be appended to the
end of the bundle ID following a "." separator.2"bundle_name"�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
entitlements�The entitlements file required for device builds of this target. If absent, the default entitlements
from the provisioning profile will be used.

The following variables are substituted in the entitlements file: `$(CFBundleIdentifier)` with the
bundle ID of the application and `$(AppIdentifierPrefix)` with the value of the
`ApplicationIdentifierPrefix` key from the target's provisioning profile.2None�
entitlements_validation�An `entitlements_validation_mode` to control the validation of the requested entitlements against
the provisioning profile to ensure they are supported.2"loose"J"error"J"warn"J"loose"J"skip"�
shared_capabilities�A list of shared `apple_capability_set` rules to represent the capabilities that a code sign aware
Apple bundle rule output should have. These can define the formal prefix for the target's
`bundle_id` and can further be merged with information provided by `entitlements`, if defined by any
capabilities found within the `apple_capability_set`.*d
AppleSharedCapabilityInfoG
AppleSharedCapabilityInfo*@rules_apple//apple/internal:providers.bzl2[]�
sticker_assets�List of sticker files to bundle. The collection of assets should be under a folder named
`*.*.xcstickers`. The icons go in a `*.stickersiconset` (instead of `*.appiconset`); and the files
for the stickers should all be in Sticker Pack directories, so `*.stickerpack/*.sticker` or
`*.stickerpack/*.stickersequence`.2[]"H
ios_sticker_pack_extension*@rules_apple//apple/internal:ios_rules.bzl,
*
nameA unique name for this target. �
�
	app_icons�Files that comprise the app icons for the application. Each file must have a containing directory
named `*..xcstickers/*..stickersiconset` and there may be only one such
`..stickersiconset` directory in the list. In Xcode 26+ for iOS/macOS/watchOS, an `*.icon`
bundle can be provided along with the `*..xcstickers` bundle to support 26 and
pre-26 Apple OS rendering.2[]�
�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonec
a
familiesQA list of device families supported by this rule. At least one must be specified. �
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""

platform_type2"ios"�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID rule found within
`signed_capabilities`.2""�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
a base bundle ID rule found within `signed_capabilities`, then this string will be appended to the
end of the bundle ID following a "." separator.2"bundle_name"�
�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
entitlements�The entitlements file required for device builds of this target. If absent, the default entitlements
from the provisioning profile will be used.

The following variables are substituted in the entitlements file: `$(CFBundleIdentifier)` with the
bundle ID of the application and `$(AppIdentifierPrefix)` with the value of the
`ApplicationIdentifierPrefix` key from the target's provisioning profile.2None�
�
entitlements_validation�An `entitlements_validation_mode` to control the validation of the requested entitlements against
the provisioning profile to ensure they are supported.2"loose"J"error"J"warn"J"loose"J"skip"�
�
shared_capabilities�A list of shared `apple_capability_set` rules to represent the capabilities that a code sign aware
Apple bundle rule output should have. These can define the formal prefix for the target's
`bundle_id` and can further be merged with information provided by `entitlements`, if defined by any
capabilities found within the `apple_capability_set`.*d
AppleSharedCapabilityInfoG
AppleSharedCapabilityInfo*@rules_apple//apple/internal:providers.bzl2[]�
�
sticker_assets�List of sticker files to bundle. The collection of assets should be under a folder named
`*.*.xcstickers`. The icons go in a `*.stickersiconset` (instead of `*.appiconset`); and the files
for the stickers should all be in Sticker Pack directories, so `*.stickerpack/*.sticker` or
`*.stickerpack/*.stickersequence`.2[]�tios_imessage_extension-Builds and bundles an iOS iMessage Extension."�t
�:
ios_imessage_extension-Builds and bundles an iOS iMessage Extension.*
nameA unique name for this target. �
	app_icons�Files that comprise the app icons for the application. Each file must have a containing directory
named `*..xcassets/*..appiconset` and there may be only one such
`..appiconset` directory in the list. In Xcode 26+ for iOS/macOS/watchOS, an `*.icon`
bundle can be provided along with the `*..xcassets` bundle to support 26 and
pre-26 Apple OS rendering.2[]�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonea
familiesQA list of device families supported by this rule. At least one must be specified. �

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
locales_to_include�A list of locales to include in the bundle. Only *.lproj directories that are matched will be copied as a part of the build.
This value takes precedence (and is preferred) over locales defined using `--define "apple.locales_to_include=..."`.2[]�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""
platform_type2"ios"�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID rule found within
`signed_capabilities`.2""�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
a base bundle ID rule found within `signed_capabilities`, then this string will be appended to the
end of the bundle ID following a "." separator.2"bundle_name"�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
entitlements�The entitlements file required for device builds of this target. If absent, the default entitlements
from the provisioning profile will be used.

The following variables are substituted in the entitlements file: `$(CFBundleIdentifier)` with the
bundle ID of the application and `$(AppIdentifierPrefix)` with the value of the
`ApplicationIdentifierPrefix` key from the target's provisioning profile.2None�
entitlements_validation�An `entitlements_validation_mode` to control the validation of the requested entitlements against
the provisioning profile to ensure they are supported.2"loose"J"error"J"warn"J"loose"J"skip"�
shared_capabilities�A list of shared `apple_capability_set` rules to represent the capabilities that a code sign aware
Apple bundle rule output should have. These can define the formal prefix for the target's
`bundle_id` and can further be merged with information provided by `entitlements`, if defined by any
capabilities found within the `apple_capability_set`.*d
AppleSharedCapabilityInfoG
AppleSharedCapabilityInfo*@rules_apple//apple/internal:providers.bzl2[]�

frameworks�A list of framework targets (see
[`ios_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-ios.md#ios_framework))
that this target depends on.*�
AppleBundleInfo
IosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlD
IosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]"D
ios_imessage_extension*@rules_apple//apple/internal:ios_rules.bzl,
*
nameA unique name for this target. �
�
	app_icons�Files that comprise the app icons for the application. Each file must have a containing directory
named `*..xcassets/*..appiconset` and there may be only one such
`..appiconset` directory in the list. In Xcode 26+ for iOS/macOS/watchOS, an `*.icon`
bundle can be provided along with the `*..xcassets` bundle to support 26 and
pre-26 Apple OS rendering.2[]�
�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]g
e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]c
a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]U
S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonec
a
familiesQA list of device families supported by this rule. At least one must be specified. �
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
�
locales_to_include�A list of locales to include in the bundle. Only *.lproj directories that are matched will be copied as a part of the build.
This value takes precedence (and is preferred) over locales defined using `--define "apple.locales_to_include=..."`.2[]�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""

platform_type2"ios"�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID rule found within
`signed_capabilities`.2""�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
a base bundle ID rule found within `signed_capabilities`, then this string will be appended to the
end of the bundle ID following a "." separator.2"bundle_name"�
�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
entitlements�The entitlements file required for device builds of this target. If absent, the default entitlements
from the provisioning profile will be used.

The following variables are substituted in the entitlements file: `$(CFBundleIdentifier)` with the
bundle ID of the application and `$(AppIdentifierPrefix)` with the value of the
`ApplicationIdentifierPrefix` key from the target's provisioning profile.2None�
�
entitlements_validation�An `entitlements_validation_mode` to control the validation of the requested entitlements against
the provisioning profile to ensure they are supported.2"loose"J"error"J"warn"J"loose"J"skip"�
�
shared_capabilities�A list of shared `apple_capability_set` rules to represent the capabilities that a code sign aware
Apple bundle rule output should have. These can define the formal prefix for the target's
`bundle_id` and can further be merged with information provided by `entitlements`, if defined by any
capabilities found within the `apple_capability_set`.*d
AppleSharedCapabilityInfoG
AppleSharedCapabilityInfo*@rules_apple//apple/internal:providers.bzl2[]�
�

frameworks�A list of framework targets (see
[`ios_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-ios.md#ios_framework))
that this target depends on.*�
AppleBundleInfo
IosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlD
IosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�dios_kernel_extension+Builds and bundles an iOS Kernel Extension."�d
�2
ios_kernel_extension+Builds and bundles an iOS Kernel Extension.*
nameA unique name for this target. �
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nones
familiesQA list of device families supported by this rule. At least one must be specified.2["iphone", "ipad"]�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""
platform_type2"ios"�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID rule found within
`signed_capabilities`.2""�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
a base bundle ID rule found within `signed_capabilities`, then this string will be appended to the
end of the bundle ID following a "." separator.2"_"�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
entitlements�The entitlements file required for device builds of this target. If absent, the default entitlements
from the provisioning profile will be used.

The following variables are substituted in the entitlements file: `$(CFBundleIdentifier)` with the
bundle ID of the application and `$(AppIdentifierPrefix)` with the value of the
`ApplicationIdentifierPrefix` key from the target's provisioning profile.2None�
entitlements_validation�An `entitlements_validation_mode` to control the validation of the requested entitlements against
the provisioning profile to ensure they are supported.2"loose"J"error"J"warn"J"loose"J"skip"�
shared_capabilities�A list of shared `apple_capability_set` rules to represent the capabilities that a code sign aware
Apple bundle rule output should have. These can define the formal prefix for the target's
`bundle_id` and can further be merged with information provided by `entitlements`, if defined by any
capabilities found within the `apple_capability_set`.*d
AppleSharedCapabilityInfoG
AppleSharedCapabilityInfo*@rules_apple//apple/internal:providers.bzl2[]"B
ios_kernel_extension*@rules_apple//apple/internal:ios_rules.bzl,
*
nameA unique name for this target. �
�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]g
e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]c
a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]U
S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Noneu
s
familiesQA list of device families supported by this rule. At least one must be specified.2["iphone", "ipad"]�
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""

platform_type2"ios"�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID rule found within
`signed_capabilities`.2""�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
a base bundle ID rule found within `signed_capabilities`, then this string will be appended to the
end of the bundle ID following a "." separator.2"_"�
�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
entitlements�The entitlements file required for device builds of this target. If absent, the default entitlements
from the provisioning profile will be used.

The following variables are substituted in the entitlements file: `$(CFBundleIdentifier)` with the
bundle ID of the application and `$(AppIdentifierPrefix)` with the value of the
`ApplicationIdentifierPrefix` key from the target's provisioning profile.2None�
�
entitlements_validation�An `entitlements_validation_mode` to control the validation of the requested entitlements against
the provisioning profile to ensure they are supported.2"loose"J"error"J"warn"J"loose"J"skip"�
�
shared_capabilities�A list of shared `apple_capability_set` rules to represent the capabilities that a code sign aware
Apple bundle rule output should have. These can define the formal prefix for the target's
`bundle_id` and can further be merged with information provided by `entitlements`, if defined by any
capabilities found within the `apple_capability_set`.*d
AppleSharedCapabilityInfoG
AppleSharedCapabilityInfo*@rules_apple//apple/internal:providers.bzl2[]�uios_static_framework�Builds and bundles an iOS static framework for third-party distribution.

A static framework is bundled like a dynamic framework except that the embedded
binary is a static library rather than a dynamic library. It is intended to
create distributable static SDKs or artifacts that can be easily imported into
other Xcode projects; it is specifically **not** intended to be used as a
dependency of other Bazel targets. For that use case, use the corresponding
`objc_library` targets directly.

Unlike other iOS bundles, the fat binary in an `ios_static_framework` may
simultaneously contain simulator and device architectures (that is, you can
build a single framework artifact that works for all architectures by specifying
`--ios_multi_cpus=i386,x86_64,armv7,arm64` when you build).

`ios_static_framework` supports Swift, but there are some constraints:

* `ios_static_framework` with Swift only works with Xcode 11 and above, since
  the required Swift functionality for module compatibility is available in
  Swift 5.1.
* `ios_static_framework` only supports a single direct `swift_library` target
  that does not depend transitively on any other `swift_library` targets. The
  Swift compiler expects a framework to contain a single Swift module, and each
  `swift_library` target is its own module by definition.
* `ios_static_framework` does not support mixed Objective-C and Swift public
  interfaces. This means that the `umbrella_header` and `hdrs` attributes are
  unavailable when using `swift_library` dependencies. You are allowed to depend
  on `objc_library` from the main `swift_library` dependency, but note that only
  the `swift_library`'s public interface will be available to users of the
  static framework.

When using Swift, the `ios_static_framework` bundles `swiftinterface` and
`swiftdocs` file for each of the required architectures. It also bundles an
umbrella header which is the header generated by the single `swift_library`
target. Finally, it also bundles a `module.modulemap` file pointing to the
umbrella header for Objetive-C module compatibility. This umbrella header and
modulemap can be skipped by disabling the `swift.no_generated_header` feature (
i.e. `--features=-swift.no_generated_header`)."�d
�:
ios_static_framework�Builds and bundles an iOS static framework for third-party distribution.

A static framework is bundled like a dynamic framework except that the embedded
binary is a static library rather than a dynamic library. It is intended to
create distributable static SDKs or artifacts that can be easily imported into
other Xcode projects; it is specifically **not** intended to be used as a
dependency of other Bazel targets. For that use case, use the corresponding
`objc_library` targets directly.

Unlike other iOS bundles, the fat binary in an `ios_static_framework` may
simultaneously contain simulator and device architectures (that is, you can
build a single framework artifact that works for all architectures by specifying
`--ios_multi_cpus=i386,x86_64,armv7,arm64` when you build).

`ios_static_framework` supports Swift, but there are some constraints:

* `ios_static_framework` with Swift only works with Xcode 11 and above, since
  the required Swift functionality for module compatibility is available in
  Swift 5.1.
* `ios_static_framework` only supports a single direct `swift_library` target
  that does not depend transitively on any other `swift_library` targets. The
  Swift compiler expects a framework to contain a single Swift module, and each
  `swift_library` target is its own module by definition.
* `ios_static_framework` does not support mixed Objective-C and Swift public
  interfaces. This means that the `umbrella_header` and `hdrs` attributes are
  unavailable when using `swift_library` dependencies. You are allowed to depend
  on `objc_library` from the main `swift_library` dependency, but note that only
  the `swift_library`'s public interface will be available to users of the
  static framework.

When using Swift, the `ios_static_framework` bundles `swiftinterface` and
`swiftdocs` file for each of the required architectures. It also bundles an
umbrella header which is the header generated by the single `swift_library`
target. Finally, it also bundles a `module.modulemap` file pointing to the
umbrella header for Objetive-C module compatibility. This umbrella header and
modulemap can be skipped by disabling the `swift.no_generated_header` feature (
i.e. `--features=-swift.no_generated_header`).*
nameA unique name for this target. �
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nones
familiesQA list of device families supported by this rule. At least one must be specified.2["iphone", "ipad"]�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""
platform_type2"ios"�

avoid_deps�A list of library targets on which this framework depends in order to compile, but the transitive
closure of which will not be linked into the framework's binary.2[]�
exclude_resources�Indicates whether resources should be excluded from the bundle. This can be used to avoid
unnecessarily bundling resources if the static framework is being distributed in a different
fashion, such as a Cocoapod.2False�
hdrs�A list of `.h` files that will be publicly exposed by this framework. These headers should have
framework-relative imports, and if non-empty, an umbrella header named `%{bundle_name}.h` will also
be generated that imports all of the headers listed here.2[]�
umbrella_header�An optional single .h file to use as the umbrella header for this framework. Usually, this header
will have the same name as this target, so that clients can load the header using the #import
<MyFramework/MyFramework.h> format. If this attribute is not specified (the common use case), an
umbrella header will be generated under the same name as this target.2None"B
ios_static_framework*@rules_apple//apple/internal:ios_rules.bzl,
*
nameA unique name for this target. �
�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]g
e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]c
a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]U
S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Noneu
s
familiesQA list of device families supported by this rule. At least one must be specified.2["iphone", "ipad"]�
�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""

platform_type2"ios"�
�

avoid_deps�A list of library targets on which this framework depends in order to compile, but the transitive
closure of which will not be linked into the framework's binary.2[]�
�
exclude_resources�Indicates whether resources should be excluded from the bundle. This can be used to avoid
unnecessarily bundling resources if the static framework is being distributed in a different
fashion, such as a Cocoapod.2False�
�
hdrs�A list of `.h` files that will be publicly exposed by this framework. These headers should have
framework-relative imports, and if non-empty, an umbrella header named `%{bundle_name}.h` will also
be generated that imports all of the headers listed here.2[]�
�
umbrella_header�An optional single .h file to use as the umbrella header for this framework. Usually, this header
will have the same name as this target, so that clients can load the header using the #import
<MyFramework/MyFramework.h> format. If this attribute is not specified (the common use case), an
umbrella header will be generated under the same name as this target.2None�6ios_test_runner�Rule to identify an iOS runner that runs tests for iOS.

The runner will create a new simulator according to the given arguments to run
tests.

Outputs:
  AppleTestRunnerInfo:
    test_runner_template: Template file that contains the specific mechanism
        with which the tests will be performed.
    execution_requirements: Dictionary that represents the specific hardware
        requirements for this test.
  Runfiles:
    files: The files needed during runtime for the test to be performed."�2
�
ios_test_runner�Rule to identify an iOS runner that runs tests for iOS.

The runner will create a new simulator according to the given arguments to run
tests.

Outputs:
  AppleTestRunnerInfo:
    test_runner_template: Template file that contains the specific mechanism
        with which the tests will be performed.
    execution_requirements: Dictionary that represents the specific hardware
        requirements for this test.
  Runfiles:
    files: The files needed during runtime for the test to be performed.*
nameA unique name for this target. �
create_simulator_action�
A binary that produces a UDID for a simulator that matches the given device type and OS version. The UDID will be used to run the tests on the correct simulator. The binary must print only the UDID to stdout. This is only invoked when the `$REUSE_GLOBAL_SIMULATOR` environment variable is set.

When executed, the binary will have the following environment variables available to it:

<ul>
<li>`SIMULATOR_DEVICE_TYPE`: The device type of the simulator to create. The supported types correspond to the output of `xcrun simctl list devicetypes`. E.g., iPhone 6, iPad Air. The value will either be the value of the `device_type` attribute, the `ios_simulator_device` build setting, or an empty string that should imply a default device.</li>
<li>`SIMULATOR_OS_VERSION`: The os version of the simulator to create. The supported os versions correspond to the output of `xcrun simctl list runtimes`. ' 'E.g., 11.2, 9.3. The value will either be the value of the `os_version` attribute, the `ios_simulator_version` build setting, or an empty string that should imply a default OS version for the selected simulator runtime.</li>
<li>`SIMULATOR_SDK_VERSION`: The SDK version of the simulator to create. The supported SDK builds correspond to the output of `xcrun simctl runtime match list`. E.g., 11.2, 9.3. The value will be derived from the `default_ios_sdk_version` for the current Xcode version.</li>
</ul>2None�
device_type�The device type of the iOS simulator to run test. The supported types correspond
to the output of `xcrun simctl list devicetypes`. E.g., iPhone 6, iPad Air.
By default, it is the latest supported iPhone type.'2""�
execution_requirements�Dictionary of strings to strings which specifies the execution requirements for
the runner. In most common cases, this should not be used.
2{"requires-darwin": ""}�

os_version�The os version of the iOS simulator to run test. The supported os versions
correspond to the output of `xcrun simctl list runtimes`. ' 'E.g., 11.2, 9.3.
By default, it is the latest supported version of the device type.'2""�
post_action�A binary to run following test execution. Runs after testing but before test result handling and coverage processing. Sets the `$TEST_EXIT_CODE` environment variable, in addition to any other variables available to the test runner.2None�
 post_action_determines_exit_code�When true, the exit code of the test run will be set to the exit code of the `post_action`. This is useful for tests that need to fail the test run based on their own criteria.2False�

pre_action�A binary to run prior to test execution. Runs after simulator creation. Sets any environment variables available to the test runner.2None�
test_environmenthOptional dictionary with the environment variables that are to be propagated
into the XCTest invocation.
2{}"Q
ios_test_runner>@rules_apple//apple/testing/default_runner:ios_test_runner.bzl,
*
nameA unique name for this target. �
�
create_simulator_action�
A binary that produces a UDID for a simulator that matches the given device type and OS version. The UDID will be used to run the tests on the correct simulator. The binary must print only the UDID to stdout. This is only invoked when the `$REUSE_GLOBAL_SIMULATOR` environment variable is set.

When executed, the binary will have the following environment variables available to it:

<ul>
<li>`SIMULATOR_DEVICE_TYPE`: The device type of the simulator to create. The supported types correspond to the output of `xcrun simctl list devicetypes`. E.g., iPhone 6, iPad Air. The value will either be the value of the `device_type` attribute, the `ios_simulator_device` build setting, or an empty string that should imply a default device.</li>
<li>`SIMULATOR_OS_VERSION`: The os version of the simulator to create. The supported os versions correspond to the output of `xcrun simctl list runtimes`. ' 'E.g., 11.2, 9.3. The value will either be the value of the `os_version` attribute, the `ios_simulator_version` build setting, or an empty string that should imply a default OS version for the selected simulator runtime.</li>
<li>`SIMULATOR_SDK_VERSION`: The SDK version of the simulator to create. The supported SDK builds correspond to the output of `xcrun simctl runtime match list`. E.g., 11.2, 9.3. The value will be derived from the `default_ios_sdk_version` for the current Xcode version.</li>
</ul>2None�
�
device_type�The device type of the iOS simulator to run test. The supported types correspond
to the output of `xcrun simctl list devicetypes`. E.g., iPhone 6, iPad Air.
By default, it is the latest supported iPhone type.'2""�
�
execution_requirements�Dictionary of strings to strings which specifies the execution requirements for
the runner. In most common cases, this should not be used.
2{"requires-darwin": ""}�
�

os_version�The os version of the iOS simulator to run test. The supported os versions
correspond to the output of `xcrun simctl list runtimes`. ' 'E.g., 11.2, 9.3.
By default, it is the latest supported version of the device type.'2""�
�
post_action�A binary to run following test execution. Runs after testing but before test result handling and coverage processing. Sets the `$TEST_EXIT_CODE` environment variable, in addition to any other variables available to the test runner.2None�
�
 post_action_determines_exit_code�When true, the exit code of the test run will be set to the exit code of the `post_action`. This is useful for tests that need to fail the test run based on their own criteria.2False�
�

pre_action�A binary to run prior to test execution. Runs after simulator creation. Sets any environment variables available to the test runner.2None�
�
test_environmenthOptional dictionary with the environment variables that are to be propagated
into the XCTest invocation.
2{}�wios_xctestrun_runner�	This rule creates a test runner for iOS tests that uses xctestrun files to run
hosted tests, and uses xctest directly to run logic tests.

You can use this rule directly if you need to override 'device_type' or
'os_version', otherwise you can use the predefined runners:

```
"@rules_apple//apple/testing/default_runner:ios_xctestrun_ordered_runner"
```

or:

```
"@rules_apple//apple/testing/default_runner:ios_xctestrun_random_runner"
```

Depending on if you want random test ordering or not. Set these as the `runner`
attribute on your `ios_unit_test` target:

```bzl
ios_unit_test(
    name = "Tests",
    minimum_os_version = "15.5",
    runner = "@rules_apple//apple/testing/default_runner:ios_xctestrun_random_runner",
    deps = [":TestsLib"],
)
```

If you would like this test runner to generate xcresult bundles for your tests,
pass `--test_env=CREATE_XCRESULT_BUNDLE=1`. It is preferable to use the
`create_xcresult_bundle` on the test runner itself instead of this parameter.

This rule automatically handles running x86_64 tests on arm64 hosts. The only
exception is that if you want to generate xcresult bundles or run tests in
random order, the test must have a test host. This is because of a limitation
in Xcode."�m
�;
ios_xctestrun_runner�	This rule creates a test runner for iOS tests that uses xctestrun files to run
hosted tests, and uses xctest directly to run logic tests.

You can use this rule directly if you need to override 'device_type' or
'os_version', otherwise you can use the predefined runners:

```
"@rules_apple//apple/testing/default_runner:ios_xctestrun_ordered_runner"
```

or:

```
"@rules_apple//apple/testing/default_runner:ios_xctestrun_random_runner"
```

Depending on if you want random test ordering or not. Set these as the `runner`
attribute on your `ios_unit_test` target:

```bzl
ios_unit_test(
    name = "Tests",
    minimum_os_version = "15.5",
    runner = "@rules_apple//apple/testing/default_runner:ios_xctestrun_random_runner",
    deps = [":TestsLib"],
)
```

If you would like this test runner to generate xcresult bundles for your tests,
pass `--test_env=CREATE_XCRESULT_BUNDLE=1`. It is preferable to use the
`create_xcresult_bundle` on the test runner itself instead of this parameter.

This rule automatically handles running x86_64 tests on arm64 hosts. The only
exception is that if you want to generate xcresult bundles or run tests in
random order, the test must have a test host. This is because of a limitation
in Xcode.*
nameA unique name for this target. �
attachment_lifetime�Attachment lifetime to set in the xctestrun file when running the test bundle - `"keepNever"` (default), `"keepAlways"`
or `"deleteOnSuccess"`. This affects presence of attachments in the XCResult output. This does not force using
`xcodebuild` or an XCTestRun file but the value will be used in that case.2"keepNever"�
clean_up_simulator_action�A binary that cleans up any simulators created by the `create_simulator_action`. Runs after the `post_action`, regardless of test success or failure.

When executed, the binary will have the following environment variables available to it:

<ul>
<li>`SIMULATOR_UDID`: The UDID of the simulator to clean up. This will be the same UDID produced by the `create_simulator_action` and used to run the tests.</li>
<li>`SIMULATOR_REUSE_SIMULATOR`: Whether to an existing simulator was reused or if a new one was created. The value will be set to "1" if the `reuse_simulator` attribute is true, and unset otherwise. Whether or not this variable is respected should be treated as an implementation detail of the simulator cleanup tool.</li>
</ul>2None�
command_line_args�CommandLineArguments to pass to xctestrun file when running the test bundle. This means it
will always use `xcodebuild test-without-building` to run the test bundle.2[]�
create_simulator_action�A binary that produces a UDID for a simulator that matches the given device type and OS version. Runs before the `pre_action`. The UDID will be used to run the tests on the correct simulator. The binary must print only the UDID to stdout.

When executed, the binary will have the following environment variables available to it:

<ul>
<li>`SIMULATOR_DEVICE_TYPE`: The device type of the simulator to create. The supported types correspond to the output of `xcrun simctl list devicetypes`. E.g., iPhone 6, iPad Air. The value will either be the value of the `device_type` attribute, or the `ios_simulator_device` build setting.</li>
<li>`SIMULATOR_OS_VERSION`: The OS version of the simulator to create. The supported OS versions correspond to the output of `xcrun simctl list runtimes`. E.g., 11.2, 9.3. The value will either be the value of the `os_version` attribute, or the `ios_simulator_version` build setting.</li>
<li>`SIMULATOR_REUSE_SIMULATOR`: Whether to reuse an existing simulator or create a new one. The value will be set to "1" if the `reuse_simulator` attribute is true, and unset otherwise. Whether or not this variable is respected should be treated as an implementation detail of the simulator creator tool.</li>
<li>`SIMULATOR_SDK_VERSION`: The SDK version of the simulator to create. The supported SDK builds correspond to the output of `xcrun simctl runtime match list`. E.g., 11.2, 9.3. The value will be derived from the `default_ios_sdk_version` for the current Xcode version.</li>
</ul>2None�
create_xcresult_bundle�Force the test runner to always create an XCResult bundle. This means it will
always use `xcodebuild test-without-building` to run the test bundle.2Falsey
destination_timeout]Use the specified timeout when searching for a destination device. The default is 30 seconds.20�
device_type�The device type of the iOS simulator to run test. The supported types correspond
to the output of `xcrun simctl list devicetypes`. E.g., iPhone X, iPad Air.
By default, it reads from the `ios_simulator_device` build setting or falls back to some device.2""�

os_version�The os version of the iOS simulator to run test. The supported os versions
correspond to the output of `xcrun simctl list runtimes`. E.g., 15.5.
By default, it reads the `ios_simulator_version` build setting and then falls back to the latest
supported version.2""�
post_action�A binary to run following test execution. Runs after testing but before test result handling and coverage processing. Sets the `$TEST_EXIT_CODE`, `$TEST_LOG_FILE`, and `$SIMULATOR_UDID` environment variables, the `$TEST_XCRESULT_BUNDLE_PATH` environment variable if the test run produces an XCResult bundle, and any other variables available to the test runner.2None�
 post_action_determines_exit_code�When true, the exit code of the test run will be set to the exit code of the `post_action`. This is useful for tests that need to fail the test run based on their own criteria.2False�

pre_action�A binary to run prior to test execution. Runs after simulator creation. Sets the `$SIMULATOR_UDID` environment variable, in addition to any other variables available to the test runner.2Nonef
randomSWhether to run the tests in random order to identify unintended state
dependencies.2False�
reuse_simulator�Toggle simulator reuse. The default behavior is to reuse an existing device of the same type and OS version. When disabled, a new simulator is created before testing starts and shutdown when the runner completes.2True�
screen_capture_format�Controls the `PreferredScreenCaptureFormat` written into the generated xctestrun file (added in Xcode 15). One of:

* `""` (default): do not set the key, use Xcode's platform default.
* `"screenshots"`: capture screenshots only.
* `"screenRecording"`: capture a full screen recording of each UI test run, attached to the resulting `.xcresult` bundle.

Setting a non-empty value forces the runner onto the `xcodebuild test-without-building` path (the direct `xctest` path does not read the xctestrun file and cannot capture the screen) and forces an `.xcresult` bundle to be produced (the capture is only observable there). This attribute is only meaningful for UI tests.

Screen captures are system attachments, so setting this attribute requires `attachment_lifetime` to be `"keepAlways"` or `"deleteOnSuccess"` — with the default `"keepNever"` the capture would be discarded before it reaches the `.xcresult`, so the runner fails with an error.2""J""J"screenshots"J"screenRecording"�
test_environmenthOptional dictionary with the environment variables that are to be propagated
into the XCTest invocation.
2{}�
xcodebuild_args�Arguments to pass to `xcodebuild` when running the test bundle. This means it
will always use `xcodebuild test-without-building` to run the test bundle.2[]"[
ios_xctestrun_runnerC@rules_apple//apple/testing/default_runner:ios_xctestrun_runner.bzl,
*
nameA unique name for this target. �
�
attachment_lifetime�Attachment lifetime to set in the xctestrun file when running the test bundle - `"keepNever"` (default), `"keepAlways"`
or `"deleteOnSuccess"`. This affects presence of attachments in the XCResult output. This does not force using
`xcodebuild` or an XCTestRun file but the value will be used in that case.2"keepNever"�
�
clean_up_simulator_action�A binary that cleans up any simulators created by the `create_simulator_action`. Runs after the `post_action`, regardless of test success or failure.

When executed, the binary will have the following environment variables available to it:

<ul>
<li>`SIMULATOR_UDID`: The UDID of the simulator to clean up. This will be the same UDID produced by the `create_simulator_action` and used to run the tests.</li>
<li>`SIMULATOR_REUSE_SIMULATOR`: Whether to an existing simulator was reused or if a new one was created. The value will be set to "1" if the `reuse_simulator` attribute is true, and unset otherwise. Whether or not this variable is respected should be treated as an implementation detail of the simulator cleanup tool.</li>
</ul>2None�
�
command_line_args�CommandLineArguments to pass to xctestrun file when running the test bundle. This means it
will always use `xcodebuild test-without-building` to run the test bundle.2[]�
�
create_simulator_action�A binary that produces a UDID for a simulator that matches the given device type and OS version. Runs before the `pre_action`. The UDID will be used to run the tests on the correct simulator. The binary must print only the UDID to stdout.

When executed, the binary will have the following environment variables available to it:

<ul>
<li>`SIMULATOR_DEVICE_TYPE`: The device type of the simulator to create. The supported types correspond to the output of `xcrun simctl list devicetypes`. E.g., iPhone 6, iPad Air. The value will either be the value of the `device_type` attribute, or the `ios_simulator_device` build setting.</li>
<li>`SIMULATOR_OS_VERSION`: The OS version of the simulator to create. The supported OS versions correspond to the output of `xcrun simctl list runtimes`. E.g., 11.2, 9.3. The value will either be the value of the `os_version` attribute, or the `ios_simulator_version` build setting.</li>
<li>`SIMULATOR_REUSE_SIMULATOR`: Whether to reuse an existing simulator or create a new one. The value will be set to "1" if the `reuse_simulator` attribute is true, and unset otherwise. Whether or not this variable is respected should be treated as an implementation detail of the simulator creator tool.</li>
<li>`SIMULATOR_SDK_VERSION`: The SDK version of the simulator to create. The supported SDK builds correspond to the output of `xcrun simctl runtime match list`. E.g., 11.2, 9.3. The value will be derived from the `default_ios_sdk_version` for the current Xcode version.</li>
</ul>2None�
�
create_xcresult_bundle�Force the test runner to always create an XCResult bundle. This means it will
always use `xcodebuild test-without-building` to run the test bundle.2False{
y
destination_timeout]Use the specified timeout when searching for a destination device. The default is 30 seconds.20�
�
device_type�The device type of the iOS simulator to run test. The supported types correspond
to the output of `xcrun simctl list devicetypes`. E.g., iPhone X, iPad Air.
By default, it reads from the `ios_simulator_device` build setting or falls back to some device.2""�
�

os_version�The os version of the iOS simulator to run test. The supported os versions
correspond to the output of `xcrun simctl list runtimes`. E.g., 15.5.
By default, it reads the `ios_simulator_version` build setting and then falls back to the latest
supported version.2""�
�
post_action�A binary to run following test execution. Runs after testing but before test result handling and coverage processing. Sets the `$TEST_EXIT_CODE`, `$TEST_LOG_FILE`, and `$SIMULATOR_UDID` environment variables, the `$TEST_XCRESULT_BUNDLE_PATH` environment variable if the test run produces an XCResult bundle, and any other variables available to the test runner.2None�
�
 post_action_determines_exit_code�When true, the exit code of the test run will be set to the exit code of the `post_action`. This is useful for tests that need to fail the test run based on their own criteria.2False�
�

pre_action�A binary to run prior to test execution. Runs after simulator creation. Sets the `$SIMULATOR_UDID` environment variable, in addition to any other variables available to the test runner.2Noneh
f
randomSWhether to run the tests in random order to identify unintended state
dependencies.2False�
�
reuse_simulator�Toggle simulator reuse. The default behavior is to reuse an existing device of the same type and OS version. When disabled, a new simulator is created before testing starts and shutdown when the runner completes.2True�
�
screen_capture_format�Controls the `PreferredScreenCaptureFormat` written into the generated xctestrun file (added in Xcode 15). One of:

* `""` (default): do not set the key, use Xcode's platform default.
* `"screenshots"`: capture screenshots only.
* `"screenRecording"`: capture a full screen recording of each UI test run, attached to the resulting `.xcresult` bundle.

Setting a non-empty value forces the runner onto the `xcodebuild test-without-building` path (the direct `xctest` path does not read the xctestrun file and cannot capture the screen) and forces an `.xcresult` bundle to be produced (the capture is only observable there). This attribute is only meaningful for UI tests.

Screen captures are system attachments, so setting this attribute requires `attachment_lifetime` to be `"keepAlways"` or `"deleteOnSuccess"` — with the default `"keepNever"` the capture would be discarded before it reaches the `.xcresult`, so the runner fails with an error.2""J""J"screenshots"J"screenRecording"�
�
test_environmenthOptional dictionary with the environment variables that are to be propagated
into the XCTest invocation.
2{}�
�
xcodebuild_args�Arguments to pass to `xcodebuild` when running the test bundle. This means it
will always use `xcodebuild test-without-building` to run the test bundle.2[]�
ios_build_test�Test rule to check that the given library targets (Swift, Objective-C, C++)
build for iOS.

Typical usage:

```starlark
ios_build_test(
    name = "my_build_test",
    minimum_os_version = "12.0",
    targets = [
        "//some/package:my_library",
    ],
)
```"�
�
ios_build_test�Test rule to check that the given library targets (Swift, Objective-C, C++)
build for iOS.

Typical usage:

```starlark
ios_build_test(
    name = "my_build_test",
    minimum_os_version = "12.0",
    targets = [
        "//some/package:my_library",
    ],
)
```*
nameA unique name for this target. �
minimum_os_version�A required string indicating the minimum OS version that will be used as the
deployment target when building the targets, represented as a dotted version
number (for example, `"9.0"`). ;
targets*The targets to check for successful build.2[]
platform_type2"ios""-
ios_build_test@rules_apple//apple:ios.bzl08,
*
nameA unique name for this target. �
�
minimum_os_version�A required string indicating the minimum OS version that will be used as the
deployment target when building the targets, represented as a dotted version
number (for example, `"9.0"`). =
;
targets*The targets to check for successful build.2[]

platform_type2"ios"�nios_unit_test�	Builds and bundles an iOS Unit `.xctest` test bundle. Runs the tests using the
provided test runner when invoked with `bazel test`.

`ios_unit_test` targets can work in two modes: as app or library
tests. If the `test_host` attribute is set to an `ios_application` target, the
tests will run within that application's context. If no `test_host` is provided,
the tests will run outside the context of an iOS application. Because of this,
certain functionalities might not be present (e.g. UI layout, NSUserDefaults).
You can find more information about app and library testing for Apple platforms
[here](https://developer.apple.com/library/content/documentation/DeveloperTools/Conceptual/testing_with_xcode/chapters/03-testing_basics.html).

The `provisioning_profile` attribute needs to be set to run the test on a real device.

To run the same test on multiple simulators/devices see
[ios_unit_test_suite](#ios_unit_test_suite).

The following is a list of the `ios_unit_test` specific attributes; for a list
of the attributes inherited by all test rules, please check the
[Bazel documentation](https://bazel.build/reference/be/common-definitions#common-attributes-tests).Z�e
�7
ios_unit_test�	Builds and bundles an iOS Unit `.xctest` test bundle. Runs the tests using the
provided test runner when invoked with `bazel test`.

`ios_unit_test` targets can work in two modes: as app or library
tests. If the `test_host` attribute is set to an `ios_application` target, the
tests will run within that application's context. If no `test_host` is provided,
the tests will run outside the context of an iOS application. Because of this,
certain functionalities might not be present (e.g. UI layout, NSUserDefaults).
You can find more information about app and library testing for Apple platforms
[here](https://developer.apple.com/library/content/documentation/DeveloperTools/Conceptual/testing_with_xcode/chapters/03-testing_basics.html).

The `provisioning_profile` attribute needs to be set to run the test on a real device.

To run the same test on multiple simulators/devices see
[ios_unit_test_suite](#ios_unit_test_suite).

The following is a list of the `ios_unit_test` specific attributes; for a list
of the attributes inherited by all test rules, please check the
[Bazel documentation](https://bazel.build/reference/be/common-definitions#common-attributes-tests).�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2""�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2"bundle_name"�
bundle_name�The desired name of the test bundle (without the extension). If this attribute is not set, then the
name of the target will be used instead.2""8�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]s
familiesQA list of device families supported by this rule. At least one must be specified.2["iphone", "ipad"]�

frameworks8A list of framework targets that this target depends on.*�
AppleBundleInfo
IosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlD
IosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. If not provided,
a default Info.plist will be used. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported.26["@rules_apple//apple/testing:DefaultTestBundlePlist"]a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.20J-1J0J1
runner2A single runner target to use for the test target.2?"@rules_apple//apple/testing/default_runner:ios_default_runner"
expect_failure2None@ 
transitive_configs2None8@
deprecation2None8@
tags2None8@
testonly2None8@
features2None@
compatible_with2None8@
restricted_to2None8@
package_metadata2None8@
aspect_hints2None@P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@
exec_properties
2None@"
exec_compatible_with2None8@(
exec_group_compatible_with2None8@Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@
size2None8@
timeout2None8@
flaky2None8@
shard_count2None@
local2None8@
args2None@q
collect_code_coveragePWhether to collect code coverage for this test if `--collect_code_coverage=yes`.2NoneL
data<Files to be made available to the test during its execution.2None�
env�Dictionary of environment variables that should be set during the test execution. The values of
the dictionary are subject to "Make" variable expansion.
2None^
env_inheritGList of environment variables to inherit from the external environment.2Noner
test_filter[Test filter string that will be passed into the test runner to select which tests will run.2None�
test_coverage_manifesteA file that will be used in lcov export calls to limit the scope of files instrumented with coverage.2None�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None
platform_type2Nonee
	test_host*P
AppleBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl2None�
test_host_is_bundle_loaderpWhether the 'test_host' should be used as the -bundle_loader to allow testing
the symbols from the test host app2None",
ios_unit_test@rules_apple//apple:ios.bzl�
�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �
�

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@U
S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2""�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2"bundle_name"�
�
bundle_name�The desired name of the test bundle (without the extension). If this attribute is not set, then the
name of the target will be used instead.2""8�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]u
s
familiesQA list of device families supported by this rule. At least one must be specified.2["iphone", "ipad"]�
�

frameworks8A list of framework targets that this target depends on.*�
AppleBundleInfo
IosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlD
IosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. If not provided,
a default Info.plist will be used. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported.26["@rules_apple//apple/testing:DefaultTestBundlePlist"]c
a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]�
�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.20J-1J0J1�

runner2A single runner target to use for the test target.2?"@rules_apple//apple/testing/default_runner:ios_default_runner"

expect_failure2None@"
 
transitive_configs2None8@

deprecation2None8@

tags2None8@

testonly2None8@

features2None@

compatible_with2None8@

restricted_to2None8@ 

package_metadata2None8@

aspect_hints2None@R
P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@

exec_properties
2None@$
"
exec_compatible_with2None8@*
(
exec_group_compatible_with2None8@\
Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@

size2None8@

timeout2None8@

flaky2None8@

shard_count2None@

local2None8@

args2None@s
q
collect_code_coveragePWhether to collect code coverage for this test if `--collect_code_coverage=yes`.2NoneN
L
data<Files to be made available to the test during its execution.2None�
�
env�Dictionary of environment variables that should be set during the test execution. The values of
the dictionary are subject to "Make" variable expansion.
2None`
^
env_inheritGList of environment variables to inherit from the external environment.2Nonet
r
test_filter[Test filter string that will be passed into the test runner to select which tests will run.2None�
�
test_coverage_manifesteA file that will be used in lcov export calls to limit the scope of files instrumented with coverage.2None�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None

platform_type2Noneg
e
	test_host*P
AppleBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl2None�
�
test_host_is_bundle_loaderpWhether the 'test_host' should be used as the -bundle_loader to allow testing
the symbols from the test host app2None�eios_ui_test�iOS UI Test rule.

Builds and bundles an iOS UI `.xctest` test bundle. Runs the tests using the
provided test runner when invoked with `bazel test`.

The `provisioning_profile` attribute needs to be set to run the test on a real device.

To run the same test on multiple simulators/devices see
[ios_ui_test_suite](#ios_ui_test_suite).

The following is a list of the `ios_ui_test` specific attributes; for a list
of the attributes inherited by all test rules, please check the
[Bazel documentation](https://bazel.build/reference/be/common-definitions#common-attributes-tests).Z�`
�2
ios_ui_test�iOS UI Test rule.

Builds and bundles an iOS UI `.xctest` test bundle. Runs the tests using the
provided test runner when invoked with `bazel test`.

The `provisioning_profile` attribute needs to be set to run the test on a real device.

To run the same test on multiple simulators/devices see
[ios_ui_test_suite](#ios_ui_test_suite).

The following is a list of the `ios_ui_test` specific attributes; for a list
of the attributes inherited by all test rules, please check the
[Bazel documentation](https://bazel.build/reference/be/common-definitions#common-attributes-tests).�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2""�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2"bundle_name"�
bundle_name�The desired name of the test bundle (without the extension). If this attribute is not set, then the
name of the target will be used instead.2""8�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]s
familiesQA list of device families supported by this rule. At least one must be specified.2["iphone", "ipad"]�

frameworks8A list of framework targets that this target depends on.*�
AppleBundleInfo
IosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlD
IosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. If not provided,
a default Info.plist will be used. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported.26["@rules_apple//apple/testing:DefaultTestBundlePlist"]a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.20J-1J0J1
runner2A single runner target to use for the test target.2?"@rules_apple//apple/testing/default_runner:ios_default_runner"
expect_failure2None@ 
transitive_configs2None8@
deprecation2None8@
tags2None8@
testonly2None8@
features2None@
compatible_with2None8@
restricted_to2None8@
package_metadata2None8@
aspect_hints2None@P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@
exec_properties
2None@"
exec_compatible_with2None8@(
exec_group_compatible_with2None8@Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@
size2None8@
timeout2None8@
flaky2None8@
shard_count2None@
local2None8@
args2None@q
collect_code_coveragePWhether to collect code coverage for this test if `--collect_code_coverage=yes`.2NoneL
data<Files to be made available to the test during its execution.2None�
env�Dictionary of environment variables that should be set during the test execution. The values of
the dictionary are subject to "Make" variable expansion.
2None^
env_inheritGList of environment variables to inherit from the external environment.2Noner
test_filter[Test filter string that will be passed into the test runner to select which tests will run.2None�
test_coverage_manifesteA file that will be used in lcov export calls to limit the scope of files instrumented with coverage.2None�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None
platform_type2Nonee
	test_host*P
AppleBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl2None�
test_host_is_bundle_loaderpWhether the 'test_host' should be used as the -bundle_loader to allow testing
the symbols from the test host app2None"*
ios_ui_test@rules_apple//apple:ios.bzl�
�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �
�

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@U
S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2""�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2"bundle_name"�
�
bundle_name�The desired name of the test bundle (without the extension). If this attribute is not set, then the
name of the target will be used instead.2""8�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]u
s
familiesQA list of device families supported by this rule. At least one must be specified.2["iphone", "ipad"]�
�

frameworks8A list of framework targets that this target depends on.*�
AppleBundleInfo
IosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlD
IosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. If not provided,
a default Info.plist will be used. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported.26["@rules_apple//apple/testing:DefaultTestBundlePlist"]c
a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]�
�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.20J-1J0J1�

runner2A single runner target to use for the test target.2?"@rules_apple//apple/testing/default_runner:ios_default_runner"

expect_failure2None@"
 
transitive_configs2None8@

deprecation2None8@

tags2None8@

testonly2None8@

features2None@

compatible_with2None8@

restricted_to2None8@ 

package_metadata2None8@

aspect_hints2None@R
P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@

exec_properties
2None@$
"
exec_compatible_with2None8@*
(
exec_group_compatible_with2None8@\
Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@

size2None8@

timeout2None8@

flaky2None8@

shard_count2None@

local2None8@

args2None@s
q
collect_code_coveragePWhether to collect code coverage for this test if `--collect_code_coverage=yes`.2NoneN
L
data<Files to be made available to the test during its execution.2None�
�
env�Dictionary of environment variables that should be set during the test execution. The values of
the dictionary are subject to "Make" variable expansion.
2None`
^
env_inheritGList of environment variables to inherit from the external environment.2Nonet
r
test_filter[Test filter string that will be passed into the test runner to select which tests will run.2None�
�
test_coverage_manifesteA file that will be used in lcov export calls to limit the scope of files instrumented with coverage.2None�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None

platform_type2Noneg
e
	test_host*P
AppleBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl2None�
�
test_host_is_bundle_loaderpWhether the 'test_host' should be used as the -bundle_loader to allow testing
the symbols from the test host app2None�`ios_unit_test_suite�Generates a [test_suite] containing an [ios_unit_test] for each of the given `runners`.

`ios_unit_test_suite` takes the same parameters as [ios_unit_test], except `runner` is replaced by `runners`.

[test_suite]: https://docs.bazel.build/versions/master/be/general.html#test_suite
[ios_unit_test]: #ios_unit_testZ�]
�0
ios_unit_test_suite�Generates a [test_suite] containing an [ios_unit_test] for each of the given `runners`.

`ios_unit_test_suite` takes the same parameters as [ios_unit_test], except `runner` is replaced by `runners`.

[test_suite]: https://docs.bazel.build/versions/master/be/general.html#test_suite
[ios_unit_test]: #ios_unit_test�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2""�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2"bundle_name"�
bundle_name�The desired name of the test bundle (without the extension). If this attribute is not set, then the
name of the target will be used instead.2""8�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]s
familiesQA list of device families supported by this rule. At least one must be specified.2["iphone", "ipad"]�

frameworks8A list of framework targets that this target depends on.*�
AppleBundleInfo
IosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlD
IosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. If not provided,
a default Info.plist will be used. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported.26["@rules_apple//apple/testing:DefaultTestBundlePlist"]a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.20J-1J0J1F
runners5A list of runner targets to use for the test targets. 8
expect_failure2None@ 
transitive_configs2None8@
deprecation2None8@
tags2None8@
testonly2None8@
features2None@
compatible_with2None8@
restricted_to2None8@
package_metadata2None8@
aspect_hints2None@P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@
exec_properties
2None@"
exec_compatible_with2None8@(
exec_group_compatible_with2None8@Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@
size2None8@
timeout2None8@
flaky2None8@
shard_count2None@
local2None8@
args2None@q
collect_code_coveragePWhether to collect code coverage for this test if `--collect_code_coverage=yes`.2NoneL
data<Files to be made available to the test during its execution.2None�
env�Dictionary of environment variables that should be set during the test execution. The values of
the dictionary are subject to "Make" variable expansion.
2None^
env_inheritGList of environment variables to inherit from the external environment.2Noner
test_filter[Test filter string that will be passed into the test runner to select which tests will run.2None�
test_coverage_manifesteA file that will be used in lcov export calls to limit the scope of files instrumented with coverage.2None�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None
platform_type2Nonee
	test_host*P
AppleBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl2None�
test_host_is_bundle_loaderpWhether the 'test_host' should be used as the -bundle_loader to allow testing
the symbols from the test host app2None"2
ios_unit_test_suite@rules_apple//apple:ios.bzl�
�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �
�

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@U
S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2""�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2"bundle_name"�
�
bundle_name�The desired name of the test bundle (without the extension). If this attribute is not set, then the
name of the target will be used instead.2""8�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]u
s
familiesQA list of device families supported by this rule. At least one must be specified.2["iphone", "ipad"]�
�

frameworks8A list of framework targets that this target depends on.*�
AppleBundleInfo
IosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlD
IosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. If not provided,
a default Info.plist will be used. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported.26["@rules_apple//apple/testing:DefaultTestBundlePlist"]c
a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]�
�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.20J-1J0J1H
F
runners5A list of runner targets to use for the test targets. 8

expect_failure2None@"
 
transitive_configs2None8@

deprecation2None8@

tags2None8@

testonly2None8@

features2None@

compatible_with2None8@

restricted_to2None8@ 

package_metadata2None8@

aspect_hints2None@R
P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@

exec_properties
2None@$
"
exec_compatible_with2None8@*
(
exec_group_compatible_with2None8@\
Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@

size2None8@

timeout2None8@

flaky2None8@

shard_count2None@

local2None8@

args2None@s
q
collect_code_coveragePWhether to collect code coverage for this test if `--collect_code_coverage=yes`.2NoneN
L
data<Files to be made available to the test during its execution.2None�
�
env�Dictionary of environment variables that should be set during the test execution. The values of
the dictionary are subject to "Make" variable expansion.
2None`
^
env_inheritGList of environment variables to inherit from the external environment.2Nonet
r
test_filter[Test filter string that will be passed into the test runner to select which tests will run.2None�
�
test_coverage_manifesteA file that will be used in lcov export calls to limit the scope of files instrumented with coverage.2None�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None

platform_type2Noneg
e
	test_host*P
AppleBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl2None�
�
test_host_is_bundle_loaderpWhether the 'test_host' should be used as the -bundle_loader to allow testing
the symbols from the test host app2None�`ios_ui_test_suite�Generates a [test_suite] containing an [ios_ui_test] for each of the given `runners`.

`ios_ui_test_suite` takes the same parameters as [ios_ui_test], except `runner` is replaced by `runners`.

[test_suite]: https://docs.bazel.build/versions/master/be/general.html#test_suite
[ios_ui_test]: #ios_ui_testZ�]
�/
ios_ui_test_suite�Generates a [test_suite] containing an [ios_ui_test] for each of the given `runners`.

`ios_ui_test_suite` takes the same parameters as [ios_ui_test], except `runner` is replaced by `runners`.

[test_suite]: https://docs.bazel.build/versions/master/be/general.html#test_suite
[ios_ui_test]: #ios_ui_test�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2""�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2"bundle_name"�
bundle_name�The desired name of the test bundle (without the extension). If this attribute is not set, then the
name of the target will be used instead.2""8�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]s
familiesQA list of device families supported by this rule. At least one must be specified.2["iphone", "ipad"]�

frameworks8A list of framework targets that this target depends on.*�
AppleBundleInfo
IosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlD
IosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. If not provided,
a default Info.plist will be used. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported.26["@rules_apple//apple/testing:DefaultTestBundlePlist"]a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.20J-1J0J1F
runners5A list of runner targets to use for the test targets. 8
expect_failure2None@ 
transitive_configs2None8@
deprecation2None8@
tags2None8@
testonly2None8@
features2None@
compatible_with2None8@
restricted_to2None8@
package_metadata2None8@
aspect_hints2None@P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@
exec_properties
2None@"
exec_compatible_with2None8@(
exec_group_compatible_with2None8@Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@
size2None8@
timeout2None8@
flaky2None8@
shard_count2None@
local2None8@
args2None@q
collect_code_coveragePWhether to collect code coverage for this test if `--collect_code_coverage=yes`.2NoneL
data<Files to be made available to the test during its execution.2None�
env�Dictionary of environment variables that should be set during the test execution. The values of
the dictionary are subject to "Make" variable expansion.
2None^
env_inheritGList of environment variables to inherit from the external environment.2Noner
test_filter[Test filter string that will be passed into the test runner to select which tests will run.2None�
test_coverage_manifesteA file that will be used in lcov export calls to limit the scope of files instrumented with coverage.2None�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None
platform_type2Nonee
	test_host*P
AppleBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl2None�
test_host_is_bundle_loaderpWhether the 'test_host' should be used as the -bundle_loader to allow testing
the symbols from the test host app2None"0
ios_ui_test_suite@rules_apple//apple:ios.bzl�
�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �
�

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@U
S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2""�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2"bundle_name"�
�
bundle_name�The desired name of the test bundle (without the extension). If this attribute is not set, then the
name of the target will be used instead.2""8�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]u
s
familiesQA list of device families supported by this rule. At least one must be specified.2["iphone", "ipad"]�
�

frameworks8A list of framework targets that this target depends on.*�
AppleBundleInfo
IosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlD
IosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. If not provided,
a default Info.plist will be used. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported.26["@rules_apple//apple/testing:DefaultTestBundlePlist"]c
a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]�
�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.20J-1J0J1H
F
runners5A list of runner targets to use for the test targets. 8

expect_failure2None@"
 
transitive_configs2None8@

deprecation2None8@

tags2None8@

testonly2None8@

features2None@

compatible_with2None8@

restricted_to2None8@ 

package_metadata2None8@

aspect_hints2None@R
P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@

exec_properties
2None@$
"
exec_compatible_with2None8@*
(
exec_group_compatible_with2None8@\
Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@

size2None8@

timeout2None8@

flaky2None8@

shard_count2None@

local2None8@

args2None@s
q
collect_code_coveragePWhether to collect code coverage for this test if `--collect_code_coverage=yes`.2NoneN
L
data<Files to be made available to the test during its execution.2None�
�
env�Dictionary of environment variables that should be set during the test execution. The values of
the dictionary are subject to "Make" variable expansion.
2None`
^
env_inheritGList of environment variables to inherit from the external environment.2Nonet
r
test_filter[Test filter string that will be passed into the test runner to select which tests will run.2None�
�
test_coverage_manifesteA file that will be used in lcov export calls to limit the scope of files instrumented with coverage.2None�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None

platform_type2Noneg
e
	test_host*P
AppleBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl2None�
�
test_host_is_bundle_loaderpWhether the 'test_host' should be used as the -bundle_loader to allow testing
the symbols from the test host app2None8# Bazel rules for creating iOS applications and bundles.�
 
rules_appleapple
linker.bzl�apple_order_file�Injects the provided `.order` files into Apple link lines, concatenating and deduplicating them before supplying the appropriate linker flags.
The rule short-circuits in non-optimized compilations because generating order files is intended for release/deployment builds where they improve runtime locality.

Example:

```starlark
apple_order_file(
    name = "app_order_file",
    deps = [
        "my_file.order",
        "my_second_order_file.order",
    ],
)

ios_application(
    name = "app",
    deps = [":app_order_file"],
)
```

Set `stats = True` if you want the linker to emit information about how it used the order file."�
�
apple_order_file�Injects the provided `.order` files into Apple link lines, concatenating and deduplicating them before supplying the appropriate linker flags.
The rule short-circuits in non-optimized compilations because generating order files is intended for release/deployment builds where they improve runtime locality.

Example:

```starlark
apple_order_file(
    name = "app_order_file",
    deps = [
        "my_file.order",
        "my_second_order_file.order",
    ],
)

ios_application(
    name = "app",
    deps = [":app_order_file"],
)
```

Set `stats = True` if you want the linker to emit information about how it used the order file.*
nameA unique name for this target. G
deps;The raw text order files to be used in the iOS application. Y
statsGIndicate whether to log stats about how the linker used the order file.2False"9

order_file+@rules_apple//apple/internal:order_file.bzl,
*
nameA unique name for this target. I
G
deps;The raw text order files to be used in the iOS application. [
Y
statsGIndicate whether to log stats about how the linker used the order file.2FalseRules related to Apple linker.��

rules_appleapple	macos.bzl�kmacos_quick_look_plugin-Builds and bundles a macOS Quick Look Plugin."�k
�5
macos_quick_look_plugin-Builds and bundles a macOS Quick Look Plugin.*
nameA unique name for this target. �
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Noneh
familiesQA list of device families supported by this rule. At least one must be specified.2["mac"]�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""
platform_type2"macos"�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID rule found within
`signed_capabilities`.2""�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
a base bundle ID rule found within `signed_capabilities`, then this string will be appended to the
end of the bundle ID following a "." separator.2"_"�
provisioning_profile�The provisioning profile (`.provisionprofile` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
entitlements�The entitlements file required for device builds of this target. If absent, the default entitlements
from the provisioning profile will be used.

The following variables are substituted in the entitlements file: `$(CFBundleIdentifier)` with the
bundle ID of the application and `$(AppIdentifierPrefix)` with the value of the
`ApplicationIdentifierPrefix` key from the target's provisioning profile.2None�
entitlements_validation�An `entitlements_validation_mode` to control the validation of the requested entitlements against
the provisioning profile to ensure they are supported.2"loose"J"error"J"warn"J"loose"J"skip"�
shared_capabilities�A list of shared `apple_capability_set` rules to represent the capabilities that a code sign aware
Apple bundle rule output should have. These can define the formal prefix for the target's
`bundle_id` and can further be merged with information provided by `entitlements`, if defined by any
capabilities found within the `apple_capability_set`.*d
AppleSharedCapabilityInfoG
AppleSharedCapabilityInfo*@rules_apple//apple/internal:providers.bzl2[]�
additional_contents�Files that should be copied into specific subdirectories of the Contents folder in the bundle. The
keys of this dictionary are labels pointing to single files, filegroups, or targets; the
corresponding value is the name of the subdirectory of Contents where they should be placed.

The relative directory structure of filegroup contents is preserved when they are copied into the
desired Contents subdirectory.	2{}"G
macos_quick_look_plugin,@rules_apple//apple/internal:macos_rules.bzl,
*
nameA unique name for this target. �
�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]g
e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]c
a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]U
S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonej
h
familiesQA list of device families supported by this rule. At least one must be specified.2["mac"]�
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""

platform_type2"macos"�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID rule found within
`signed_capabilities`.2""�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
a base bundle ID rule found within `signed_capabilities`, then this string will be appended to the
end of the bundle ID following a "." separator.2"_"�
�
provisioning_profile�The provisioning profile (`.provisionprofile` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
entitlements�The entitlements file required for device builds of this target. If absent, the default entitlements
from the provisioning profile will be used.

The following variables are substituted in the entitlements file: `$(CFBundleIdentifier)` with the
bundle ID of the application and `$(AppIdentifierPrefix)` with the value of the
`ApplicationIdentifierPrefix` key from the target's provisioning profile.2None�
�
entitlements_validation�An `entitlements_validation_mode` to control the validation of the requested entitlements against
the provisioning profile to ensure they are supported.2"loose"J"error"J"warn"J"loose"J"skip"�
�
shared_capabilities�A list of shared `apple_capability_set` rules to represent the capabilities that a code sign aware
Apple bundle rule output should have. These can define the formal prefix for the target's
`bundle_id` and can further be merged with information provided by `entitlements`, if defined by any
capabilities found within the `apple_capability_set`.*d
AppleSharedCapabilityInfoG
AppleSharedCapabilityInfo*@rules_apple//apple/internal:providers.bzl2[]�
�
additional_contents�Files that should be copied into specific subdirectories of the Contents folder in the bundle. The
keys of this dictionary are labels pointing to single files, filegroups, or targets; the
corresponding value is the name of the subdirectory of Contents where they should be placed.

The relative directory structure of filegroup contents is preserved when they are copied into the
desired Contents subdirectory.	2{}�kmacos_spotlight_importer.Builds and bundles a macOS Spotlight Importer."�k
�5
macos_spotlight_importer.Builds and bundles a macOS Spotlight Importer.*
nameA unique name for this target. �
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Noneh
familiesQA list of device families supported by this rule. At least one must be specified.2["mac"]�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""
platform_type2"macos"�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID rule found within
`signed_capabilities`.2""�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
a base bundle ID rule found within `signed_capabilities`, then this string will be appended to the
end of the bundle ID following a "." separator.2"_"�
provisioning_profile�The provisioning profile (`.provisionprofile` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
entitlements�The entitlements file required for device builds of this target. If absent, the default entitlements
from the provisioning profile will be used.

The following variables are substituted in the entitlements file: `$(CFBundleIdentifier)` with the
bundle ID of the application and `$(AppIdentifierPrefix)` with the value of the
`ApplicationIdentifierPrefix` key from the target's provisioning profile.2None�
entitlements_validation�An `entitlements_validation_mode` to control the validation of the requested entitlements against
the provisioning profile to ensure they are supported.2"loose"J"error"J"warn"J"loose"J"skip"�
shared_capabilities�A list of shared `apple_capability_set` rules to represent the capabilities that a code sign aware
Apple bundle rule output should have. These can define the formal prefix for the target's
`bundle_id` and can further be merged with information provided by `entitlements`, if defined by any
capabilities found within the `apple_capability_set`.*d
AppleSharedCapabilityInfoG
AppleSharedCapabilityInfo*@rules_apple//apple/internal:providers.bzl2[]�
additional_contents�Files that should be copied into specific subdirectories of the Contents folder in the bundle. The
keys of this dictionary are labels pointing to single files, filegroups, or targets; the
corresponding value is the name of the subdirectory of Contents where they should be placed.

The relative directory structure of filegroup contents is preserved when they are copied into the
desired Contents subdirectory.	2{}"H
macos_spotlight_importer,@rules_apple//apple/internal:macos_rules.bzl,
*
nameA unique name for this target. �
�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]g
e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]c
a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]U
S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonej
h
familiesQA list of device families supported by this rule. At least one must be specified.2["mac"]�
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""

platform_type2"macos"�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID rule found within
`signed_capabilities`.2""�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
a base bundle ID rule found within `signed_capabilities`, then this string will be appended to the
end of the bundle ID following a "." separator.2"_"�
�
provisioning_profile�The provisioning profile (`.provisionprofile` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
entitlements�The entitlements file required for device builds of this target. If absent, the default entitlements
from the provisioning profile will be used.

The following variables are substituted in the entitlements file: `$(CFBundleIdentifier)` with the
bundle ID of the application and `$(AppIdentifierPrefix)` with the value of the
`ApplicationIdentifierPrefix` key from the target's provisioning profile.2None�
�
entitlements_validation�An `entitlements_validation_mode` to control the validation of the requested entitlements against
the provisioning profile to ensure they are supported.2"loose"J"error"J"warn"J"loose"J"skip"�
�
shared_capabilities�A list of shared `apple_capability_set` rules to represent the capabilities that a code sign aware
Apple bundle rule output should have. These can define the formal prefix for the target's
`bundle_id` and can further be merged with information provided by `entitlements`, if defined by any
capabilities found within the `apple_capability_set`.*d
AppleSharedCapabilityInfoG
AppleSharedCapabilityInfo*@rules_apple//apple/internal:providers.bzl2[]�
�
additional_contents�Files that should be copied into specific subdirectories of the Contents folder in the bundle. The
keys of this dictionary are labels pointing to single files, filegroups, or targets; the
corresponding value is the name of the subdirectory of Contents where they should be placed.

The relative directory structure of filegroup contents is preserved when they are copied into the
desired Contents subdirectory.	2{}�kmacos_xpc_service'Builds and bundles a macOS XPC Service."�j
�5
macos_xpc_service'Builds and bundles a macOS XPC Service.*
nameA unique name for this target. �
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2None�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2Noneh
familiesQA list of device families supported by this rule. At least one must be specified.2["mac"]�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""
platform_type2"macos"�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID rule found within
`signed_capabilities`.2""�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
a base bundle ID rule found within `signed_capabilities`, then this string will be appended to the
end of the bundle ID following a "." separator.2"_"�
provisioning_profile�The provisioning profile (`.provisionprofile` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
entitlements�The entitlements file required for device builds of this target. If absent, the default entitlements
from the provisioning profile will be used.

The following variables are substituted in the entitlements file: `$(CFBundleIdentifier)` with the
bundle ID of the application and `$(AppIdentifierPrefix)` with the value of the
`ApplicationIdentifierPrefix` key from the target's provisioning profile.2None�
entitlements_validation�An `entitlements_validation_mode` to control the validation of the requested entitlements against
the provisioning profile to ensure they are supported.2"loose"J"error"J"warn"J"loose"J"skip"�
shared_capabilities�A list of shared `apple_capability_set` rules to represent the capabilities that a code sign aware
Apple bundle rule output should have. These can define the formal prefix for the target's
`bundle_id` and can further be merged with information provided by `entitlements`, if defined by any
capabilities found within the `apple_capability_set`.*d
AppleSharedCapabilityInfoG
AppleSharedCapabilityInfo*@rules_apple//apple/internal:providers.bzl2[]�
additional_contents�Files that should be copied into specific subdirectories of the Contents folder in the bundle. The
keys of this dictionary are labels pointing to single files, filegroups, or targets; the
corresponding value is the name of the subdirectory of Contents where they should be placed.

The relative directory structure of filegroup contents is preserved when they are copied into the
desired Contents subdirectory.	2{}"A
macos_xpc_service,@rules_apple//apple/internal:macos_rules.bzl,
*
nameA unique name for this target. �
�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]g
e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]c
a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]U
S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2None�
�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2Nonej
h
familiesQA list of device families supported by this rule. At least one must be specified.2["mac"]�
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""

platform_type2"macos"�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID rule found within
`signed_capabilities`.2""�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
a base bundle ID rule found within `signed_capabilities`, then this string will be appended to the
end of the bundle ID following a "." separator.2"_"�
�
provisioning_profile�The provisioning profile (`.provisionprofile` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
entitlements�The entitlements file required for device builds of this target. If absent, the default entitlements
from the provisioning profile will be used.

The following variables are substituted in the entitlements file: `$(CFBundleIdentifier)` with the
bundle ID of the application and `$(AppIdentifierPrefix)` with the value of the
`ApplicationIdentifierPrefix` key from the target's provisioning profile.2None�
�
entitlements_validation�An `entitlements_validation_mode` to control the validation of the requested entitlements against
the provisioning profile to ensure they are supported.2"loose"J"error"J"warn"J"loose"J"skip"�
�
shared_capabilities�A list of shared `apple_capability_set` rules to represent the capabilities that a code sign aware
Apple bundle rule output should have. These can define the formal prefix for the target's
`bundle_id` and can further be merged with information provided by `entitlements`, if defined by any
capabilities found within the `apple_capability_set`.*d
AppleSharedCapabilityInfoG
AppleSharedCapabilityInfo*@rules_apple//apple/internal:providers.bzl2[]�
�
additional_contents�Files that should be copied into specific subdirectories of the Contents folder in the bundle. The
keys of this dictionary are labels pointing to single files, filegroups, or targets; the
corresponding value is the name of the subdirectory of Contents where they should be placed.

The relative directory structure of filegroup contents is preserved when they are copied into the
desired Contents subdirectory.	2{}�
macos_build_test�Test rule to check that the given library targets (Swift, Objective-C, C++)
build for macOS.

Typical usage:

```starlark
macos_build_test(
    name = "my_build_test",
    minimum_os_version = "10.14",
    targets = [
        "//some/package:my_library",
    ],
)
```"�
�
macos_build_test�Test rule to check that the given library targets (Swift, Objective-C, C++)
build for macOS.

Typical usage:

```starlark
macos_build_test(
    name = "my_build_test",
    minimum_os_version = "10.14",
    targets = [
        "//some/package:my_library",
    ],
)
```*
nameA unique name for this target. �
minimum_os_version�A required string indicating the minimum OS version that will be used as the
deployment target when building the targets, represented as a dotted version
number (for example, `"9.0"`). ;
targets*The targets to check for successful build.2[]
platform_type2"macos""1
macos_build_test@rules_apple//apple:macos.bzl08,
*
nameA unique name for this target. �
�
minimum_os_version�A required string indicating the minimum OS version that will be used as the
deployment target when building the targets, represented as a dotted version
number (for example, `"9.0"`). =
;
targets*The targets to check for successful build.2[]

platform_type2"macos"��macos_applicationPackages a macOS application.Z��
�M
macos_applicationPackages a macOS application.�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@
expect_failure2None@ 
transitive_configs2None8@
deprecation2None8@
tags2None8@
testonly2None8@
features2None@
compatible_with2None8@
restricted_to2None8@
package_metadata2None8@
aspect_hints2None@P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@
exec_properties
2None@"
exec_compatible_with2None8@(
exec_group_compatible_with2None8@Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@
args2None@
output_licenses2None@�
	app_icons�Files that comprise the app icons for the application. Each file must have a containing directory
named `*..xcassets/*..appiconset` and there may be only one such
`..appiconset` directory in the list. In Xcode 26+ for iOS/macOS/watchOS, an `*.icon`
bundle can be provided along with the `*..xcassets` bundle to support 26 and
pre-26 Apple OS rendering.2None�
app_intents:List of dependencies implementing the AppIntents protocol.*;
	SwiftInfo.
	SwiftInfo!@rules_swift//swift:providers.bzl2None�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2Noneg
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2None�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2Nonec
linkoptsOA list of strings representing extra flags that should be passed to the linker.2NoneU
additional_linker_inputs1A list of input files to be passed to the linker.2None�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2NoneJ-1J0J1�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2None�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2None�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2None�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2None�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2None�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonee
familiesQA list of device families supported by this rule. At least one must be specified.2None�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. If not provided,
a default Info.plist will be used. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported.2None�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
locales_to_include�A list of locales to include in the bundle. Only *.lproj directories that are matched will be copied as a part of the build.
This value takes precedence (and is preferred) over locales defined using `--define "apple.locales_to_include=..."`.2None�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None
platform_type2None�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID rule found within
`signed_capabilities`.2None�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
a base bundle ID rule found within `signed_capabilities`, then this string will be appended to the
end of the bundle ID following a "." separator.2None�
provisioning_profile�The provisioning profile (`.provisionprofile` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
entitlements�The entitlements file required for device builds of this target. If absent, the default entitlements
from the provisioning profile will be used.

The following variables are substituted in the entitlements file: `$(CFBundleIdentifier)` with the
bundle ID of the application and `$(AppIdentifierPrefix)` with the value of the
`ApplicationIdentifierPrefix` key from the target's provisioning profile.2None�
entitlements_validation�An `entitlements_validation_mode` to control the validation of the requested entitlements against
the provisioning profile to ensure they are supported.2NoneJ"error"J"warn"J"loose"J"skip"�
shared_capabilities�A list of shared `apple_capability_set` rules to represent the capabilities that a code sign aware
Apple bundle rule output should have. These can define the formal prefix for the target's
`bundle_id` and can further be merged with information provided by `entitlements`, if defined by any
capabilities found within the `apple_capability_set`.*d
AppleSharedCapabilityInfoG
AppleSharedCapabilityInfo*@rules_apple//apple/internal:providers.bzl2None�
additional_contents�Files that should be copied into specific subdirectories of the Contents folder in the bundle. The
keys of this dictionary are labels pointing to single files, filegroups, or targets; the
corresponding value is the name of the subdirectory of Contents where they should be placed.

The relative directory structure of filegroup contents is preserved when they are copied into the
desired Contents subdirectory.	2None�

extensionsFA list of macOS extensions to include in the final application bundle.*�
AppleBundleInfo
MacosExtensionBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlF
MacosExtensionBundleInfo*@rules_apple//apple/internal:providers.bzl2None�

frameworks�A list of framework targets (see
[`macos_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-macos.md#macos_framework))
that this target depends on.*�
AppleBundleInfo
MacosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl=
MacosFrameworkBundleInfo!@rules_apple//apple:providers.bzl2None�
xpc_servicesHA list of macOS XPC Services to include in the final application bundle.*�
AppleBundleInfo
MacosXPCServiceBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlG
MacosXPCServiceBundleInfo*@rules_apple//apple/internal:providers.bzl2None�
include_symbols_in_bundle�If true and --output_groups=+dsyms is specified, generates `$UUID.symbols` files from all
`{binary: .dSYM, ...}` pairs for the application and its dependencies, then packages them under the
`Symbols/` directory in the final application bundle.2None"2
macos_application@rules_apple//apple:macos.bzl�
�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �
�

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@

expect_failure2None@"
 
transitive_configs2None8@

deprecation2None8@

tags2None8@

testonly2None8@

features2None@

compatible_with2None8@

restricted_to2None8@ 

package_metadata2None8@

aspect_hints2None@R
P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@

exec_properties
2None@$
"
exec_compatible_with2None8@*
(
exec_group_compatible_with2None8@\
Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@

args2None@

output_licenses2None@�
�
	app_icons�Files that comprise the app icons for the application. Each file must have a containing directory
named `*..xcassets/*..appiconset` and there may be only one such
`..appiconset` directory in the list. In Xcode 26+ for iOS/macOS/watchOS, an `*.icon`
bundle can be provided along with the `*..xcassets` bundle to support 26 and
pre-26 Apple OS rendering.2None�
�
app_intents:List of dependencies implementing the AppIntents protocol.*;
	SwiftInfo.
	SwiftInfo!@rules_swift//swift:providers.bzl2None�
�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2Nonei
g
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2None�
�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2Nonee
c
linkoptsOA list of strings representing extra flags that should be passed to the linker.2NoneW
U
additional_linker_inputs1A list of input files to be passed to the linker.2None�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2NoneJ-1J0J1�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2None�
�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2None�
�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2None�
�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2None�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2None�
�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Noneg
e
familiesQA list of device families supported by this rule. At least one must be specified.2None�
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. If not provided,
a default Info.plist will be used. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported.2None�
�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
�
locales_to_include�A list of locales to include in the bundle. Only *.lproj directories that are matched will be copied as a part of the build.
This value takes precedence (and is preferred) over locales defined using `--define "apple.locales_to_include=..."`.2None�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None

platform_type2None�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID rule found within
`signed_capabilities`.2None�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
a base bundle ID rule found within `signed_capabilities`, then this string will be appended to the
end of the bundle ID following a "." separator.2None�
�
provisioning_profile�The provisioning profile (`.provisionprofile` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
entitlements�The entitlements file required for device builds of this target. If absent, the default entitlements
from the provisioning profile will be used.

The following variables are substituted in the entitlements file: `$(CFBundleIdentifier)` with the
bundle ID of the application and `$(AppIdentifierPrefix)` with the value of the
`ApplicationIdentifierPrefix` key from the target's provisioning profile.2None�
�
entitlements_validation�An `entitlements_validation_mode` to control the validation of the requested entitlements against
the provisioning profile to ensure they are supported.2NoneJ"error"J"warn"J"loose"J"skip"�
�
shared_capabilities�A list of shared `apple_capability_set` rules to represent the capabilities that a code sign aware
Apple bundle rule output should have. These can define the formal prefix for the target's
`bundle_id` and can further be merged with information provided by `entitlements`, if defined by any
capabilities found within the `apple_capability_set`.*d
AppleSharedCapabilityInfoG
AppleSharedCapabilityInfo*@rules_apple//apple/internal:providers.bzl2None�
�
additional_contents�Files that should be copied into specific subdirectories of the Contents folder in the bundle. The
keys of this dictionary are labels pointing to single files, filegroups, or targets; the
corresponding value is the name of the subdirectory of Contents where they should be placed.

The relative directory structure of filegroup contents is preserved when they are copied into the
desired Contents subdirectory.	2None�
�

extensionsFA list of macOS extensions to include in the final application bundle.*�
AppleBundleInfo
MacosExtensionBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlF
MacosExtensionBundleInfo*@rules_apple//apple/internal:providers.bzl2None�
�

frameworks�A list of framework targets (see
[`macos_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-macos.md#macos_framework))
that this target depends on.*�
AppleBundleInfo
MacosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl=
MacosFrameworkBundleInfo!@rules_apple//apple:providers.bzl2None�
�
xpc_servicesHA list of macOS XPC Services to include in the final application bundle.*�
AppleBundleInfo
MacosXPCServiceBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlG
MacosXPCServiceBundleInfo*@rules_apple//apple/internal:providers.bzl2None�
�
include_symbols_in_bundle�If true and --output_groups=+dsyms is specified, generates `$UUID.symbols` files from all
`{binary: .dSYM, ...}` pairs for the application and its dependencies, then packages them under the
`Symbols/` directory in the final application bundle.2None��macos_bundle!Packages a macOS loadable bundle.Zʉ
�D
macos_bundle!Packages a macOS loadable bundle.�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@
expect_failure2None@ 
transitive_configs2None8@
deprecation2None8@
tags2None8@
testonly2None8@
features2None@
compatible_with2None8@
restricted_to2None8@
package_metadata2None8@
aspect_hints2None@P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@
exec_properties
2None@"
exec_compatible_with2None8@(
exec_group_compatible_with2None8@Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@�
	app_icons�Files that comprise the app icons for the application. Each file must have a containing directory
named `*..xcassets/*..appiconset` and there may be only one such
`..appiconset` directory in the list. In Xcode 26+ for iOS/macOS/watchOS, an `*.icon`
bundle can be provided along with the `*..xcassets` bundle to support 26 and
pre-26 Apple OS rendering.2None�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2Noneg
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2None�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2Nonec
linkoptsOA list of strings representing extra flags that should be passed to the linker.2NoneU
additional_linker_inputs1A list of input files to be passed to the linker.2None�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2NoneJ-1J0J1�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2None�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2None�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2None�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2None�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2None�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonee
familiesQA list of device families supported by this rule. At least one must be specified.2None�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None
platform_type2None�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID rule found within
`signed_capabilities`.2None�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
a base bundle ID rule found within `signed_capabilities`, then this string will be appended to the
end of the bundle ID following a "." separator.2None�
provisioning_profile�The provisioning profile (`.provisionprofile` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
entitlements�The entitlements file required for device builds of this target. If absent, the default entitlements
from the provisioning profile will be used.

The following variables are substituted in the entitlements file: `$(CFBundleIdentifier)` with the
bundle ID of the application and `$(AppIdentifierPrefix)` with the value of the
`ApplicationIdentifierPrefix` key from the target's provisioning profile.2None�
entitlements_validation�An `entitlements_validation_mode` to control the validation of the requested entitlements against
the provisioning profile to ensure they are supported.2NoneJ"error"J"warn"J"loose"J"skip"�
shared_capabilities�A list of shared `apple_capability_set` rules to represent the capabilities that a code sign aware
Apple bundle rule output should have. These can define the formal prefix for the target's
`bundle_id` and can further be merged with information provided by `entitlements`, if defined by any
capabilities found within the `apple_capability_set`.*d
AppleSharedCapabilityInfoG
AppleSharedCapabilityInfo*@rules_apple//apple/internal:providers.bzl2None�
additional_contents�Files that should be copied into specific subdirectories of the Contents folder in the bundle. The
keys of this dictionary are labels pointing to single files, filegroups, or targets; the
corresponding value is the name of the subdirectory of Contents where they should be placed.

The relative directory structure of filegroup contents is preserved when they are copied into the
desired Contents subdirectory.	2None�
bundle_extension�The extension, without a leading dot, that will be used to name the bundle. If this attribute is not
set, then the extension will be `.bundle`.2None�
bundle_loader�The target representing the executable that will be loading this bundle. Undefined symbols from the
bundle are checked against this execuable during linking as if it were one of the dynamic libraries
the bundle was linked with.*d
AppleExecutableBinaryInfoG
AppleExecutableBinaryInfo*@rules_apple//apple/internal:providers.bzl2None"-
macos_bundle@rules_apple//apple:macos.bzl�
�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �
�

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@

expect_failure2None@"
 
transitive_configs2None8@

deprecation2None8@

tags2None8@

testonly2None8@

features2None@

compatible_with2None8@

restricted_to2None8@ 

package_metadata2None8@

aspect_hints2None@R
P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@

exec_properties
2None@$
"
exec_compatible_with2None8@*
(
exec_group_compatible_with2None8@\
Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@�
�
	app_icons�Files that comprise the app icons for the application. Each file must have a containing directory
named `*..xcassets/*..appiconset` and there may be only one such
`..appiconset` directory in the list. In Xcode 26+ for iOS/macOS/watchOS, an `*.icon`
bundle can be provided along with the `*..xcassets` bundle to support 26 and
pre-26 Apple OS rendering.2None�
�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2Nonei
g
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2None�
�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2Nonee
c
linkoptsOA list of strings representing extra flags that should be passed to the linker.2NoneW
U
additional_linker_inputs1A list of input files to be passed to the linker.2None�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2NoneJ-1J0J1�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2None�
�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2None�
�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2None�
�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2None�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2None�
�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Noneg
e
familiesQA list of device families supported by this rule. At least one must be specified.2None�
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None

platform_type2None�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID rule found within
`signed_capabilities`.2None�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
a base bundle ID rule found within `signed_capabilities`, then this string will be appended to the
end of the bundle ID following a "." separator.2None�
�
provisioning_profile�The provisioning profile (`.provisionprofile` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
entitlements�The entitlements file required for device builds of this target. If absent, the default entitlements
from the provisioning profile will be used.

The following variables are substituted in the entitlements file: `$(CFBundleIdentifier)` with the
bundle ID of the application and `$(AppIdentifierPrefix)` with the value of the
`ApplicationIdentifierPrefix` key from the target's provisioning profile.2None�
�
entitlements_validation�An `entitlements_validation_mode` to control the validation of the requested entitlements against
the provisioning profile to ensure they are supported.2NoneJ"error"J"warn"J"loose"J"skip"�
�
shared_capabilities�A list of shared `apple_capability_set` rules to represent the capabilities that a code sign aware
Apple bundle rule output should have. These can define the formal prefix for the target's
`bundle_id` and can further be merged with information provided by `entitlements`, if defined by any
capabilities found within the `apple_capability_set`.*d
AppleSharedCapabilityInfoG
AppleSharedCapabilityInfo*@rules_apple//apple/internal:providers.bzl2None�
�
additional_contents�Files that should be copied into specific subdirectories of the Contents folder in the bundle. The
keys of this dictionary are labels pointing to single files, filegroups, or targets; the
corresponding value is the name of the subdirectory of Contents where they should be placed.

The relative directory structure of filegroup contents is preserved when they are copied into the
desired Contents subdirectory.	2None�
�
bundle_extension�The extension, without a leading dot, that will be used to name the bundle. If this attribute is not
set, then the extension will be `.bundle`.2None�
�
bundle_loader�The target representing the executable that will be loading this bundle. Undefined symbols from the
bundle are checked against this execuable during linking as if it were one of the dynamic libraries
the bundle was linked with.*d
AppleExecutableBinaryInfoG
AppleExecutableBinaryInfo*@rules_apple//apple/internal:providers.bzl2None�{macos_kernel_extension"Packages a macOS Kernel Extension.Z�{
�=
macos_kernel_extension"Packages a macOS Kernel Extension.�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@
expect_failure2None@ 
transitive_configs2None8@
deprecation2None8@
tags2None8@
testonly2None8@
features2None@
compatible_with2None8@
restricted_to2None8@
package_metadata2None8@
aspect_hints2None@P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@
exec_properties
2None@"
exec_compatible_with2None8@(
exec_group_compatible_with2None8@Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2Noneg
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2None�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2Nonec
linkoptsOA list of strings representing extra flags that should be passed to the linker.2NoneU
additional_linker_inputs1A list of input files to be passed to the linker.2None�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2NoneJ-1J0J1�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2None�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2None�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2None�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2None�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2None�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonee
familiesQA list of device families supported by this rule. At least one must be specified.2None�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None
platform_type2None�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID rule found within
`signed_capabilities`.2None�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
a base bundle ID rule found within `signed_capabilities`, then this string will be appended to the
end of the bundle ID following a "." separator.2None�
provisioning_profile�The provisioning profile (`.provisionprofile` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
entitlements�The entitlements file required for device builds of this target. If absent, the default entitlements
from the provisioning profile will be used.

The following variables are substituted in the entitlements file: `$(CFBundleIdentifier)` with the
bundle ID of the application and `$(AppIdentifierPrefix)` with the value of the
`ApplicationIdentifierPrefix` key from the target's provisioning profile.2None�
entitlements_validation�An `entitlements_validation_mode` to control the validation of the requested entitlements against
the provisioning profile to ensure they are supported.2NoneJ"error"J"warn"J"loose"J"skip"�
shared_capabilities�A list of shared `apple_capability_set` rules to represent the capabilities that a code sign aware
Apple bundle rule output should have. These can define the formal prefix for the target's
`bundle_id` and can further be merged with information provided by `entitlements`, if defined by any
capabilities found within the `apple_capability_set`.*d
AppleSharedCapabilityInfoG
AppleSharedCapabilityInfo*@rules_apple//apple/internal:providers.bzl2None�
additional_contents�Files that should be copied into specific subdirectories of the Contents folder in the bundle. The
keys of this dictionary are labels pointing to single files, filegroups, or targets; the
corresponding value is the name of the subdirectory of Contents where they should be placed.

The relative directory structure of filegroup contents is preserved when they are copied into the
desired Contents subdirectory.	2None"7
macos_kernel_extension@rules_apple//apple:macos.bzl�
�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �
�

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@

expect_failure2None@"
 
transitive_configs2None8@

deprecation2None8@

tags2None8@

testonly2None8@

features2None@

compatible_with2None8@

restricted_to2None8@ 

package_metadata2None8@

aspect_hints2None@R
P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@

exec_properties
2None@$
"
exec_compatible_with2None8@*
(
exec_group_compatible_with2None8@\
Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@�
�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2Nonei
g
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2None�
�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2Nonee
c
linkoptsOA list of strings representing extra flags that should be passed to the linker.2NoneW
U
additional_linker_inputs1A list of input files to be passed to the linker.2None�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2NoneJ-1J0J1�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2None�
�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2None�
�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2None�
�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2None�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2None�
�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Noneg
e
familiesQA list of device families supported by this rule. At least one must be specified.2None�
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None

platform_type2None�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID rule found within
`signed_capabilities`.2None�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
a base bundle ID rule found within `signed_capabilities`, then this string will be appended to the
end of the bundle ID following a "." separator.2None�
�
provisioning_profile�The provisioning profile (`.provisionprofile` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
entitlements�The entitlements file required for device builds of this target. If absent, the default entitlements
from the provisioning profile will be used.

The following variables are substituted in the entitlements file: `$(CFBundleIdentifier)` with the
bundle ID of the application and `$(AppIdentifierPrefix)` with the value of the
`ApplicationIdentifierPrefix` key from the target's provisioning profile.2None�
�
entitlements_validation�An `entitlements_validation_mode` to control the validation of the requested entitlements against
the provisioning profile to ensure they are supported.2NoneJ"error"J"warn"J"loose"J"skip"�
�
shared_capabilities�A list of shared `apple_capability_set` rules to represent the capabilities that a code sign aware
Apple bundle rule output should have. These can define the formal prefix for the target's
`bundle_id` and can further be merged with information provided by `entitlements`, if defined by any
capabilities found within the `apple_capability_set`.*d
AppleSharedCapabilityInfoG
AppleSharedCapabilityInfo*@rules_apple//apple/internal:providers.bzl2None�
�
additional_contents�Files that should be copied into specific subdirectories of the Contents folder in the bundle. The
keys of this dictionary are labels pointing to single files, filegroups, or targets; the
corresponding value is the name of the subdirectory of Contents where they should be placed.

The relative directory structure of filegroup contents is preserved when they are copied into the
desired Contents subdirectory.	2None�Xmacos_command_line_application(Builds a macOS command line application.Z�W
�,
macos_command_line_application(Builds a macOS command line application.�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@
expect_failure2None@ 
transitive_configs2None8@
deprecation2None8@
tags2None8@
testonly2None8@
features2None@
compatible_with2None8@
restricted_to2None8@
package_metadata2None8@
aspect_hints2None@P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@
exec_properties
2None@"
exec_compatible_with2None8@(
exec_group_compatible_with2None8@Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@
args2None@
output_licenses2None@�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2Noneg
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2None�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2Nonec
linkoptsOA list of strings representing extra flags that should be passed to the linker.2NoneU
additional_linker_inputs1A list of input files to be passed to the linker.2None�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2NoneJ-1J0J1�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2None�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None
platform_type2None�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2None�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2None�
provisioning_profile�The provisioning profile (`.provisionprofile` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�

infoplists�A list of .plist files that will be merged to form the Info.plist that represents the application
and is embedded into the binary. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported.2None�
launchdplists�A list of system wide and per-user daemon/agent configuration files, as specified by the launch
plist manual that can be found via `man launchd.plist`. These are XML files that can be loaded into
launchd with launchctl, and are required of command line applications that are intended to be used
as launch daemons and agents on macOS. All `launchd.plist`s referenced by this attribute will be
merged into a single plist and written directly into the `__TEXT`,`__launchd_plist` section of the
linked binary.2None�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2None"?
macos_command_line_application@rules_apple//apple:macos.bzl�
�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �
�

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@

expect_failure2None@"
 
transitive_configs2None8@

deprecation2None8@

tags2None8@

testonly2None8@

features2None@

compatible_with2None8@

restricted_to2None8@ 

package_metadata2None8@

aspect_hints2None@R
P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@

exec_properties
2None@$
"
exec_compatible_with2None8@*
(
exec_group_compatible_with2None8@\
Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@

args2None@

output_licenses2None@�
�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2Nonei
g
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2None�
�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2Nonee
c
linkoptsOA list of strings representing extra flags that should be passed to the linker.2NoneW
U
additional_linker_inputs1A list of input files to be passed to the linker.2None�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2NoneJ-1J0J1�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2None�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None

platform_type2None�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2None�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2None�
�
provisioning_profile�The provisioning profile (`.provisionprofile` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
�

infoplists�A list of .plist files that will be merged to form the Info.plist that represents the application
and is embedded into the binary. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported.2None�
�
launchdplists�A list of system wide and per-user daemon/agent configuration files, as specified by the launch
plist manual that can be found via `man launchd.plist`. These are XML files that can be loaded into
launchd with launchctl, and are required of command line applications that are intended to be used
as launch daemons and agents on macOS. All `launchd.plist`s referenced by this attribute will be
merged into a single plist and written directly into the `__TEXT`,`__launchd_plist` section of the
linked binary.2None�
�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2None�Nmacos_dylibBuilds a macOS dylib.Z�N
�'
macos_dylibBuilds a macOS dylib.�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@
expect_failure2None@ 
transitive_configs2None8@
deprecation2None8@
tags2None8@
testonly2None8@
features2None@
compatible_with2None8@
restricted_to2None8@
package_metadata2None8@
aspect_hints2None@P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@
exec_properties
2None@"
exec_compatible_with2None8@(
exec_group_compatible_with2None8@Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2Noneg
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2None�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2Nonec
linkoptsOA list of strings representing extra flags that should be passed to the linker.2NoneU
additional_linker_inputs1A list of input files to be passed to the linker.2None�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2NoneJ-1J0J1�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2None�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None
platform_type2None�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2None�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2None�
provisioning_profile�The provisioning profile (`.provisionprofile` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�

infoplists�A list of .plist files that will be merged to form the Info.plist that represents the application
and is embedded into the binary. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported.2None�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2None",
macos_dylib@rules_apple//apple:macos.bzl�
�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �
�

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@

expect_failure2None@"
 
transitive_configs2None8@

deprecation2None8@

tags2None8@

testonly2None8@

features2None@

compatible_with2None8@

restricted_to2None8@ 

package_metadata2None8@

aspect_hints2None@R
P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@

exec_properties
2None@$
"
exec_compatible_with2None8@*
(
exec_group_compatible_with2None8@\
Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@�
�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2Nonei
g
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2None�
�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2Nonee
c
linkoptsOA list of strings representing extra flags that should be passed to the linker.2NoneW
U
additional_linker_inputs1A list of input files to be passed to the linker.2None�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2NoneJ-1J0J1�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2None�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None

platform_type2None�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2None�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2None�
�
provisioning_profile�The provisioning profile (`.provisionprofile` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
�

infoplists�A list of .plist files that will be merged to form the Info.plist that represents the application
and is embedded into the binary. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported.2None�
�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonemacos_extension"Packages a macOS Extension Bundle.Z��
�F
macos_extension"Packages a macOS Extension Bundle.�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@
expect_failure2None@ 
transitive_configs2None8@
deprecation2None8@
tags2None8@
testonly2None8@
features2None@
compatible_with2None8@
restricted_to2None8@
package_metadata2None8@
aspect_hints2None@P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@
exec_properties
2None@"
exec_compatible_with2None8@(
exec_group_compatible_with2None8@Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@�
	app_icons�Files that comprise the app icons for the application. Each file must have a containing directory
named `*..xcassets/*..appiconset` and there may be only one such
`..appiconset` directory in the list. In Xcode 26+ for iOS/macOS/watchOS, an `*.icon`
bundle can be provided along with the `*..xcassets` bundle to support 26 and
pre-26 Apple OS rendering.2None�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2Noneg
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2None�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2Nonec
linkoptsOA list of strings representing extra flags that should be passed to the linker.2NoneU
additional_linker_inputs1A list of input files to be passed to the linker.2None�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2NoneJ-1J0J1�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2None�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2None�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2None�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2None�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2None�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonee
familiesQA list of device families supported by this rule. At least one must be specified.2Nonej
extensionkit_extensionHIndicates if this target should be treated as an ExtensionKit extension.2None�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
locales_to_include�A list of locales to include in the bundle. Only *.lproj directories that are matched will be copied as a part of the build.
This value takes precedence (and is preferred) over locales defined using `--define "apple.locales_to_include=..."`.2None�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None
platform_type2None�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID rule found within
`signed_capabilities`.2None�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
a base bundle ID rule found within `signed_capabilities`, then this string will be appended to the
end of the bundle ID following a "." separator.2None�
provisioning_profile�The provisioning profile (`.provisionprofile` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
entitlements�The entitlements file required for device builds of this target. If absent, the default entitlements
from the provisioning profile will be used.

The following variables are substituted in the entitlements file: `$(CFBundleIdentifier)` with the
bundle ID of the application and `$(AppIdentifierPrefix)` with the value of the
`ApplicationIdentifierPrefix` key from the target's provisioning profile.2None�
entitlements_validation�An `entitlements_validation_mode` to control the validation of the requested entitlements against
the provisioning profile to ensure they are supported.2NoneJ"error"J"warn"J"loose"J"skip"�
shared_capabilities�A list of shared `apple_capability_set` rules to represent the capabilities that a code sign aware
Apple bundle rule output should have. These can define the formal prefix for the target's
`bundle_id` and can further be merged with information provided by `entitlements`, if defined by any
capabilities found within the `apple_capability_set`.*d
AppleSharedCapabilityInfoG
AppleSharedCapabilityInfo*@rules_apple//apple/internal:providers.bzl2None�
additional_contents�Files that should be copied into specific subdirectories of the Contents folder in the bundle. The
keys of this dictionary are labels pointing to single files, filegroups, or targets; the
corresponding value is the name of the subdirectory of Contents where they should be placed.

The relative directory structure of filegroup contents is preserved when they are copied into the
desired Contents subdirectory.	2None�

frameworks�A list of framework targets (see
[`macos_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-macos.md#macos_framework))
that this target depends on.*�
AppleBundleInfo
MacosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl=
MacosFrameworkBundleInfo!@rules_apple//apple:providers.bzl2None"0
macos_extension@rules_apple//apple:macos.bzl�
�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �
�

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@

expect_failure2None@"
 
transitive_configs2None8@

deprecation2None8@

tags2None8@

testonly2None8@

features2None@

compatible_with2None8@

restricted_to2None8@ 

package_metadata2None8@

aspect_hints2None@R
P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@

exec_properties
2None@$
"
exec_compatible_with2None8@*
(
exec_group_compatible_with2None8@\
Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@�
�
	app_icons�Files that comprise the app icons for the application. Each file must have a containing directory
named `*..xcassets/*..appiconset` and there may be only one such
`..appiconset` directory in the list. In Xcode 26+ for iOS/macOS/watchOS, an `*.icon`
bundle can be provided along with the `*..xcassets` bundle to support 26 and
pre-26 Apple OS rendering.2None�
�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2Nonei
g
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2None�
�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2Nonee
c
linkoptsOA list of strings representing extra flags that should be passed to the linker.2NoneW
U
additional_linker_inputs1A list of input files to be passed to the linker.2None�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2NoneJ-1J0J1�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2None�
�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2None�
�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2None�
�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2None�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2None�
�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Noneg
e
familiesQA list of device families supported by this rule. At least one must be specified.2Nonel
j
extensionkit_extensionHIndicates if this target should be treated as an ExtensionKit extension.2None�
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
�
locales_to_include�A list of locales to include in the bundle. Only *.lproj directories that are matched will be copied as a part of the build.
This value takes precedence (and is preferred) over locales defined using `--define "apple.locales_to_include=..."`.2None�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None

platform_type2None�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID rule found within
`signed_capabilities`.2None�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
a base bundle ID rule found within `signed_capabilities`, then this string will be appended to the
end of the bundle ID following a "." separator.2None�
�
provisioning_profile�The provisioning profile (`.provisionprofile` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
entitlements�The entitlements file required for device builds of this target. If absent, the default entitlements
from the provisioning profile will be used.

The following variables are substituted in the entitlements file: `$(CFBundleIdentifier)` with the
bundle ID of the application and `$(AppIdentifierPrefix)` with the value of the
`ApplicationIdentifierPrefix` key from the target's provisioning profile.2None�
�
entitlements_validation�An `entitlements_validation_mode` to control the validation of the requested entitlements against
the provisioning profile to ensure they are supported.2NoneJ"error"J"warn"J"loose"J"skip"�
�
shared_capabilities�A list of shared `apple_capability_set` rules to represent the capabilities that a code sign aware
Apple bundle rule output should have. These can define the formal prefix for the target's
`bundle_id` and can further be merged with information provided by `entitlements`, if defined by any
capabilities found within the `apple_capability_set`.*d
AppleSharedCapabilityInfoG
AppleSharedCapabilityInfo*@rules_apple//apple/internal:providers.bzl2None�
�
additional_contents�Files that should be copied into specific subdirectories of the Contents folder in the bundle. The
keys of this dictionary are labels pointing to single files, filegroups, or targets; the
corresponding value is the name of the subdirectory of Contents where they should be placed.

The relative directory structure of filegroup contents is preserved when they are copied into the
desired Contents subdirectory.	2None�
�

frameworks�A list of framework targets (see
[`macos_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-macos.md#macos_framework))
that this target depends on.*�
AppleBundleInfo
MacosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl=
MacosFrameworkBundleInfo!@rules_apple//apple:providers.bzl2None�qmacos_frameworkPackages a macOS framework.Z�q
�8
macos_frameworkPackages a macOS framework.�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@
expect_failure2None@ 
transitive_configs2None8@
deprecation2None8@
tags2None8@
testonly2None8@
features2None@
compatible_with2None8@
restricted_to2None8@
package_metadata2None8@
aspect_hints2None@P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@
exec_properties
2None@"
exec_compatible_with2None8@(
exec_group_compatible_with2None8@Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2Noneg
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2None�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2Nonec
linkoptsOA list of strings representing extra flags that should be passed to the linker.2NoneU
additional_linker_inputs1A list of input files to be passed to the linker.2None�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2NoneJ-1J0J1�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2None�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2None�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2None�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2None�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2None�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonee
familiesQA list of device families supported by this rule. At least one must be specified.2None�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None
platform_type2None�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2None�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2None�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
bundle_only�Avoid linking the dynamic framework, but still include it in the app. This is useful when you want
to manually dlopen the framework at runtime.2None�
extension_safe�If true, compiles and links this framework with `-application-extension`, restricting the binary to
use only extension-safe APIs.2None�

frameworks�A list of framework targets (see
[`macos_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-macos.md#macos_framework))
that this target depends on.*�
AppleBundleInfo
MacosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl=
MacosFrameworkBundleInfo!@rules_apple//apple:providers.bzl2None
hdrs2None"0
macos_framework@rules_apple//apple:macos.bzl�
�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �
�

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@

expect_failure2None@"
 
transitive_configs2None8@

deprecation2None8@

tags2None8@

testonly2None8@

features2None@

compatible_with2None8@

restricted_to2None8@ 

package_metadata2None8@

aspect_hints2None@R
P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@

exec_properties
2None@$
"
exec_compatible_with2None8@*
(
exec_group_compatible_with2None8@\
Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@�
�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2Nonei
g
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2None�
�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2Nonee
c
linkoptsOA list of strings representing extra flags that should be passed to the linker.2NoneW
U
additional_linker_inputs1A list of input files to be passed to the linker.2None�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2NoneJ-1J0J1�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2None�
�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2None�
�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2None�
�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2None�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2None�
�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Noneg
e
familiesQA list of device families supported by this rule. At least one must be specified.2None�
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None

platform_type2None�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2None�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2None�
�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
�
bundle_only�Avoid linking the dynamic framework, but still include it in the app. This is useful when you want
to manually dlopen the framework at runtime.2None�
�
extension_safe�If true, compiles and links this framework with `-application-extension`, restricting the binary to
use only extension-safe APIs.2None�
�

frameworks�A list of framework targets (see
[`macos_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-macos.md#macos_framework))
that this target depends on.*�
AppleBundleInfo
MacosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl=
MacosFrameworkBundleInfo!@rules_apple//apple:providers.bzl2None

hdrs2None�cmacos_static_frameworkPackages a macOS framework.Z�c
�1
macos_static_frameworkPackages a macOS framework.�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@
expect_failure2None@ 
transitive_configs2None8@
deprecation2None8@
tags2None8@
testonly2None8@
features2None@
compatible_with2None8@
restricted_to2None8@
package_metadata2None8@
aspect_hints2None@P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@
exec_properties
2None@"
exec_compatible_with2None8@(
exec_group_compatible_with2None8@Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2Noneg
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2None�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2Nonec
linkoptsOA list of strings representing extra flags that should be passed to the linker.2NoneU
additional_linker_inputs1A list of input files to be passed to the linker.2None�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2NoneJ-1J0J1�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2None�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2None�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2None�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2None�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2None�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonee
familiesQA list of device families supported by this rule. At least one must be specified.2None�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None
platform_type2None�

avoid_deps�A list of library targets on which this framework depends in order to compile, but the transitive
closure of which will not be linked into the framework's binary.2None�
exclude_resources�Indicates whether resources should be excluded from the bundle. This can be used to avoid
unnecessarily bundling resources if the static framework is being distributed in a different
fashion, such as a Cocoapod.2None�
hdrs�A list of `.h` files that will be publicly exposed by this framework. These headers should have
framework-relative imports, and if non-empty, an umbrella header named `%{bundle_name}.h` will also
be generated that imports all of the headers listed here.2None�
umbrella_header�An optional single .h file to use as the umbrella header for this framework. Usually, this header
will have the same name as this target, so that clients can load the header using the #import
<MyFramework/MyFramework.h> format. If this attribute is not specified (the common use case), an
umbrella header will be generated under the same name as this target.2None"7
macos_static_framework@rules_apple//apple:macos.bzl�
�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �
�

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@

expect_failure2None@"
 
transitive_configs2None8@

deprecation2None8@

tags2None8@

testonly2None8@

features2None@

compatible_with2None8@

restricted_to2None8@ 

package_metadata2None8@

aspect_hints2None@R
P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@

exec_properties
2None@$
"
exec_compatible_with2None8@*
(
exec_group_compatible_with2None8@\
Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@�
�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2Nonei
g
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2None�
�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2Nonee
c
linkoptsOA list of strings representing extra flags that should be passed to the linker.2NoneW
U
additional_linker_inputs1A list of input files to be passed to the linker.2None�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2NoneJ-1J0J1�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2None�
�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2None�
�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2None�
�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2None�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2None�
�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Noneg
e
familiesQA list of device families supported by this rule. At least one must be specified.2None�
�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None

platform_type2None�
�

avoid_deps�A list of library targets on which this framework depends in order to compile, but the transitive
closure of which will not be linked into the framework's binary.2None�
�
exclude_resources�Indicates whether resources should be excluded from the bundle. This can be used to avoid
unnecessarily bundling resources if the static framework is being distributed in a different
fashion, such as a Cocoapod.2None�
�
hdrs�A list of `.h` files that will be publicly exposed by this framework. These headers should have
framework-relative imports, and if non-empty, an umbrella header named `%{bundle_name}.h` will also
be generated that imports all of the headers listed here.2None�
�
umbrella_header�An optional single .h file to use as the umbrella header for this framework. Usually, this header
will have the same name as this target, so that clients can load the header using the #import
<MyFramework/MyFramework.h> format. If this attribute is not specified (the common use case), an
umbrella header will be generated under the same name as this target.2None�qmacos_dynamic_frameworkPackages a macOS framework.Z�q
�8
macos_dynamic_frameworkPackages a macOS framework.�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@
expect_failure2None@ 
transitive_configs2None8@
deprecation2None8@
tags2None8@
testonly2None8@
features2None@
compatible_with2None8@
restricted_to2None8@
package_metadata2None8@
aspect_hints2None@P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@
exec_properties
2None@"
exec_compatible_with2None8@(
exec_group_compatible_with2None8@Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2Noneg
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2None�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2Nonec
linkoptsOA list of strings representing extra flags that should be passed to the linker.2NoneU
additional_linker_inputs1A list of input files to be passed to the linker.2None�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2NoneJ-1J0J1�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2None�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2None�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2None�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2None�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2None�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonee
familiesQA list of device families supported by this rule. At least one must be specified.2None�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None
platform_type2None�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2None�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2None�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
bundle_only�Avoid linking the dynamic framework, but still include it in the app. This is useful when you want
to manually dlopen the framework at runtime.2None�
extension_safe�If true, compiles and links this framework with `-application-extension`, restricting the binary to
use only extension-safe APIs.2None�

frameworks�A list of framework targets (see
[`macos_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-macos.md#macos_framework))
that this target depends on.*�
AppleBundleInfo
MacosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl=
MacosFrameworkBundleInfo!@rules_apple//apple:providers.bzl2None
hdrs2None"8
macos_dynamic_framework@rules_apple//apple:macos.bzl�
�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �
�

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@

expect_failure2None@"
 
transitive_configs2None8@

deprecation2None8@

tags2None8@

testonly2None8@

features2None@

compatible_with2None8@

restricted_to2None8@ 

package_metadata2None8@

aspect_hints2None@R
P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@

exec_properties
2None@$
"
exec_compatible_with2None8@*
(
exec_group_compatible_with2None8@\
Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@�
�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2Nonei
g
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2None�
�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2Nonee
c
linkoptsOA list of strings representing extra flags that should be passed to the linker.2NoneW
U
additional_linker_inputs1A list of input files to be passed to the linker.2None�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2NoneJ-1J0J1�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2None�
�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2None�
�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2None�
�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2None�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2None�
�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Noneg
e
familiesQA list of device families supported by this rule. At least one must be specified.2None�
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None

platform_type2None�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2None�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2None�
�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
�
bundle_only�Avoid linking the dynamic framework, but still include it in the app. This is useful when you want
to manually dlopen the framework at runtime.2None�
�
extension_safe�If true, compiles and links this framework with `-application-extension`, restricting the binary to
use only extension-safe APIs.2None�
�

frameworks�A list of framework targets (see
[`macos_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-macos.md#macos_framework))
that this target depends on.*�
AppleBundleInfo
MacosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl=
MacosFrameworkBundleInfo!@rules_apple//apple:providers.bzl2None

hdrs2None�nmacos_unit_test�Builds and bundles a macOS unit `.xctest` test bundle. Runs the tests using the
provided test runner when invoked with `bazel test`.

`macos_unit_test` targets can work in two modes: as app or library tests. If the
`test_host` attribute is set to an `macos_application` target, the tests will
run within that application's context. If no `test_host` is provided, the tests
will run outside the context of an macOS application. Because of this, certain
functionalities might not be present (e.g. UI layout, NSUserDefaults). You can
find more information about testing for Apple platforms
[here](https://developer.apple.com/library/content/documentation/DeveloperTools/Conceptual/testing_with_xcode/chapters/03-testing_basics.html).Z�h
�7
macos_unit_test�Builds and bundles a macOS unit `.xctest` test bundle. Runs the tests using the
provided test runner when invoked with `bazel test`.

`macos_unit_test` targets can work in two modes: as app or library tests. If the
`test_host` attribute is set to an `macos_application` target, the tests will
run within that application's context. If no `test_host` is provided, the tests
will run outside the context of an macOS application. Because of this, certain
functionalities might not be present (e.g. UI layout, NSUserDefaults). You can
find more information about testing for Apple platforms
[here](https://developer.apple.com/library/content/documentation/DeveloperTools/Conceptual/testing_with_xcode/chapters/03-testing_basics.html).�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2""�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2"bundle_name"�
bundle_name�The desired name of the test bundle (without the extension). If this attribute is not set, then the
name of the target will be used instead.2""8�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]h
familiesQA list of device families supported by this rule. At least one must be specified.2["mac"]�

frameworks8A list of framework targets that this target depends on.*�
AppleBundleInfo
MacosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl=
MacosFrameworkBundleInfo!@rules_apple//apple:providers.bzl2[]�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. If not provided,
a default Info.plist will be used. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported.26["@rules_apple//apple/testing:DefaultTestBundlePlist"]a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]�
provisioning_profile�The provisioning profile (`.provisionprofile` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.20J-1J0J1�
additional_contents�Files that should be copied into specific subdirectories of the Contents folder in the bundle. The
keys of this dictionary are labels pointing to single files, filegroups, or targets; the
corresponding value is the name of the subdirectory of Contents where they should be placed.

The relative directory structure of filegroup contents is preserved when they are copied into the
desired Contents subdirectory.	2{}�
runner2A single runner target to use for the test target.2A"@rules_apple//apple/testing/default_runner:macos_default_runner"
expect_failure2None@ 
transitive_configs2None8@
deprecation2None8@
tags2None8@
testonly2None8@
features2None@
compatible_with2None8@
restricted_to2None8@
package_metadata2None8@
aspect_hints2None@P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@
exec_properties
2None@"
exec_compatible_with2None8@(
exec_group_compatible_with2None8@Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@
size2None8@
timeout2None8@
flaky2None8@
shard_count2None@
local2None8@
args2None@q
collect_code_coveragePWhether to collect code coverage for this test if `--collect_code_coverage=yes`.2NoneL
data<Files to be made available to the test during its execution.2None�
env�Dictionary of environment variables that should be set during the test execution. The values of
the dictionary are subject to "Make" variable expansion.
2None^
env_inheritGList of environment variables to inherit from the external environment.2Noner
test_filter[Test filter string that will be passed into the test runner to select which tests will run.2None�
test_coverage_manifesteA file that will be used in lcov export calls to limit the scope of files instrumented with coverage.2None�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None
platform_type2Nonee
	test_host*P
AppleBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl2None�
test_host_is_bundle_loaderpWhether the 'test_host' should be used as the -bundle_loader to allow testing
the symbols from the test host app2None"0
macos_unit_test@rules_apple//apple:macos.bzl�
�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �
�

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@U
S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2""�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2"bundle_name"�
�
bundle_name�The desired name of the test bundle (without the extension). If this attribute is not set, then the
name of the target will be used instead.2""8�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]j
h
familiesQA list of device families supported by this rule. At least one must be specified.2["mac"]�
�

frameworks8A list of framework targets that this target depends on.*�
AppleBundleInfo
MacosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl=
MacosFrameworkBundleInfo!@rules_apple//apple:providers.bzl2[]�
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. If not provided,
a default Info.plist will be used. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported.26["@rules_apple//apple/testing:DefaultTestBundlePlist"]c
a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]�
�
provisioning_profile�The provisioning profile (`.provisionprofile` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.20J-1J0J1�
�
additional_contents�Files that should be copied into specific subdirectories of the Contents folder in the bundle. The
keys of this dictionary are labels pointing to single files, filegroups, or targets; the
corresponding value is the name of the subdirectory of Contents where they should be placed.

The relative directory structure of filegroup contents is preserved when they are copied into the
desired Contents subdirectory.	2{}�
�
runner2A single runner target to use for the test target.2A"@rules_apple//apple/testing/default_runner:macos_default_runner"

expect_failure2None@"
 
transitive_configs2None8@

deprecation2None8@

tags2None8@

testonly2None8@

features2None@

compatible_with2None8@

restricted_to2None8@ 

package_metadata2None8@

aspect_hints2None@R
P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@

exec_properties
2None@$
"
exec_compatible_with2None8@*
(
exec_group_compatible_with2None8@\
Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@

size2None8@

timeout2None8@

flaky2None8@

shard_count2None@

local2None8@

args2None@s
q
collect_code_coveragePWhether to collect code coverage for this test if `--collect_code_coverage=yes`.2NoneN
L
data<Files to be made available to the test during its execution.2None�
�
env�Dictionary of environment variables that should be set during the test execution. The values of
the dictionary are subject to "Make" variable expansion.
2None`
^
env_inheritGList of environment variables to inherit from the external environment.2Nonet
r
test_filter[Test filter string that will be passed into the test runner to select which tests will run.2None�
�
test_coverage_manifesteA file that will be used in lcov export calls to limit the scope of files instrumented with coverage.2None�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None

platform_type2Noneg
e
	test_host*P
AppleBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl2None�
�
test_host_is_bundle_loaderpWhether the 'test_host' should be used as the -bundle_loader to allow testing
the symbols from the test host app2None�fmacos_ui_test�Builds and bundles an iOS UI `.xctest` test bundle. Runs the tests using the
provided test runner when invoked with `bazel test`.

Note: macOS UI tests are not currently supported in the default test runner.Z�d
�2
macos_ui_test�Builds and bundles an iOS UI `.xctest` test bundle. Runs the tests using the
provided test runner when invoked with `bazel test`.

Note: macOS UI tests are not currently supported in the default test runner.�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2""�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2"bundle_name"�
bundle_name�The desired name of the test bundle (without the extension). If this attribute is not set, then the
name of the target will be used instead.2""8�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]h
familiesQA list of device families supported by this rule. At least one must be specified.2["mac"]�

frameworks8A list of framework targets that this target depends on.*�
AppleBundleInfo
MacosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl=
MacosFrameworkBundleInfo!@rules_apple//apple:providers.bzl2[]�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. If not provided,
a default Info.plist will be used. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported.26["@rules_apple//apple/testing:DefaultTestBundlePlist"]a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]�
provisioning_profile�The provisioning profile (`.provisionprofile` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.20J-1J0J1�
additional_contents�Files that should be copied into specific subdirectories of the Contents folder in the bundle. The
keys of this dictionary are labels pointing to single files, filegroups, or targets; the
corresponding value is the name of the subdirectory of Contents where they should be placed.

The relative directory structure of filegroup contents is preserved when they are copied into the
desired Contents subdirectory.	2{}�
runner2A single runner target to use for the test target.2A"@rules_apple//apple/testing/default_runner:macos_default_runner"
expect_failure2None@ 
transitive_configs2None8@
deprecation2None8@
tags2None8@
testonly2None8@
features2None@
compatible_with2None8@
restricted_to2None8@
package_metadata2None8@
aspect_hints2None@P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@
exec_properties
2None@"
exec_compatible_with2None8@(
exec_group_compatible_with2None8@Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@
size2None8@
timeout2None8@
flaky2None8@
shard_count2None@
local2None8@
args2None@q
collect_code_coveragePWhether to collect code coverage for this test if `--collect_code_coverage=yes`.2NoneL
data<Files to be made available to the test during its execution.2None�
env�Dictionary of environment variables that should be set during the test execution. The values of
the dictionary are subject to "Make" variable expansion.
2None^
env_inheritGList of environment variables to inherit from the external environment.2Noner
test_filter[Test filter string that will be passed into the test runner to select which tests will run.2None�
test_coverage_manifesteA file that will be used in lcov export calls to limit the scope of files instrumented with coverage.2None�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None
platform_type2Nonee
	test_host*P
AppleBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl2None�
test_host_is_bundle_loaderpWhether the 'test_host' should be used as the -bundle_loader to allow testing
the symbols from the test host app2None".
macos_ui_test@rules_apple//apple:macos.bzl�
�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �
�

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@U
S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2""�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2"bundle_name"�
�
bundle_name�The desired name of the test bundle (without the extension). If this attribute is not set, then the
name of the target will be used instead.2""8�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]j
h
familiesQA list of device families supported by this rule. At least one must be specified.2["mac"]�
�

frameworks8A list of framework targets that this target depends on.*�
AppleBundleInfo
MacosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl=
MacosFrameworkBundleInfo!@rules_apple//apple:providers.bzl2[]�
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. If not provided,
a default Info.plist will be used. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported.26["@rules_apple//apple/testing:DefaultTestBundlePlist"]c
a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]�
�
provisioning_profile�The provisioning profile (`.provisionprofile` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.20J-1J0J1�
�
additional_contents�Files that should be copied into specific subdirectories of the Contents folder in the bundle. The
keys of this dictionary are labels pointing to single files, filegroups, or targets; the
corresponding value is the name of the subdirectory of Contents where they should be placed.

The relative directory structure of filegroup contents is preserved when they are copied into the
desired Contents subdirectory.	2{}�
�
runner2A single runner target to use for the test target.2A"@rules_apple//apple/testing/default_runner:macos_default_runner"

expect_failure2None@"
 
transitive_configs2None8@

deprecation2None8@

tags2None8@

testonly2None8@

features2None@

compatible_with2None8@

restricted_to2None8@ 

package_metadata2None8@

aspect_hints2None@R
P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@

exec_properties
2None@$
"
exec_compatible_with2None8@*
(
exec_group_compatible_with2None8@\
Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@

size2None8@

timeout2None8@

flaky2None8@

shard_count2None@

local2None8@

args2None@s
q
collect_code_coveragePWhether to collect code coverage for this test if `--collect_code_coverage=yes`.2NoneN
L
data<Files to be made available to the test during its execution.2None�
�
env�Dictionary of environment variables that should be set during the test execution. The values of
the dictionary are subject to "Make" variable expansion.
2None`
^
env_inheritGList of environment variables to inherit from the external environment.2Nonet
r
test_filter[Test filter string that will be passed into the test runner to select which tests will run.2None�
�
test_coverage_manifesteA file that will be used in lcov export calls to limit the scope of files instrumented with coverage.2None�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None

platform_type2Noneg
e
	test_host*P
AppleBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl2None�
�
test_host_is_bundle_loaderpWhether the 'test_host' should be used as the -bundle_loader to allow testing
the symbols from the test host app2None:# Bazel rules for creating macOS applications and bundles.ӏ
#
rules_appleappleproviders.bzl�-apple_provider.make_apple_bundle_version_info@Creates a new instance of the `AppleBundleVersionInfo` provider.*�
�
-apple_provider.make_apple_bundle_version_infoG
version_file3Required. See the docs on `AppleBundleVersionInfo`. (@Creates a new instance of the `AppleBundleVersionInfo` provider."J
HA new `AppleBundleVersionInfo` provider based on the supplied arguments.2L
make_apple_bundle_version_info*@rules_apple//apple/internal:providers.bzlI
G
version_file3Required. See the docs on `AppleBundleVersionInfo`. (�*apple_provider.make_apple_test_runner_info;Creates a new instance of the AppleTestRunnerInfo provider.*�
�
*apple_provider.make_apple_test_runner_info�
kwargs�A set of keyword arguments expected to match the fields of `AppleTestRunnerInfo`.
See the documentation for `AppleTestRunnerInfo` for what these must be.(;Creates a new instance of the AppleTestRunnerInfo provider."G
EA new `AppleTestRunnerInfo` provider based on the supplied arguments.2I
make_apple_test_runner_info*@rules_apple//apple/internal:providers.bzl�
�
kwargs�A set of keyword arguments expected to match the fields of `AppleTestRunnerInfo`.
See the documentation for `AppleTestRunnerInfo` for what these must be.(�0apple_provider.merge_apple_framework_import_info4Merges multiple `AppleFrameworkImportInfo` into one.*�
�
0apple_provider.merge_apple_framework_import_infoT
apple_framework_import_infos0List of `AppleFrameworkImportInfo` to be merged. (4Merges multiple `AppleFrameworkImportInfo` into one."5
3Result of merging all the received framework infos.2O
!merge_apple_framework_import_info*@rules_apple//apple/internal:providers.bzlV
T
apple_framework_import_infos0List of `AppleFrameworkImportInfo` to be merged. (�AppleBaseBundleIdInfo5Provides the base bundle ID prefix for an Apple rule.2�
�
AppleBaseBundleIdInfo5Provides the base bundle ID prefix for an Apple rule.p
base_bundle_id^`String`. The bundle ID prefix, composed from an organization ID and an optional variant name."C
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl*Q
AppleBaseBundleIdInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzlr
p
base_bundle_id^`String`. The bundle ID prefix, composed from an organization ID and an optional variant name.�*AppleBundleInfo�This provider propagates general information about an Apple bundle that is not
specific to any particular bundle type. It is propagated by most bundling
rules (applications, extensions, frameworks, test bundles, and so forth).2�(
�
AppleBundleInfo�This provider propagates general information about an Apple bundle that is not
specific to any particular bundle type. It is propagated by most bundling
rules (applications, extensions, frameworks, test bundles, and so forth).>
archive3`File`. The archive that contains the built bundle.�
archive_root�`String`. The file system path (relative to the workspace root) where the signed
bundle was constructed (before archiving). Other rules **should not** depend on
this field; it is intended to support IDEs that want to read that path from the
provider to avoid performance issues from unzipping the output archive.�
binary�`File`. The binary (executable, dynamic library, etc.) that was bundled. The
physical file is identical to the one inside the bundle except that it is
always unsigned, so note that it is _not_ a path to the binary inside your
output bundle. The primary purpose of this field is to provide a way to access
the binary directly at analysis time; for example, for code coverage.3
bundle_extension`String`. The bundle extension.h
	bundle_id[`String`. The bundle identifier (i.e., `CFBundleIdentifier` in
`Info.plist`) of the bundle.G
bundle_name8`String`. The name of the bundle, without the extension.7
entitlements'`File`. Entitlements file used, if any.I
executable_name6`string`. The name of the executable that was bundled.�
extension_safe�`Boolean`. True if the target propagating this provider was
compiled and linked with -application-extension, restricting it to
extension-safe APIs only.V
	infoplistI`File`. The complete (binary-formatted) `Info.plist` file for the bundle.�
minimum_deployment_os_version�`string`. The minimum deployment OS version (as a dotted version
number like "9.0") that this bundle was built to support. This is different from
`minimum_os_version`, which is effective at compile time. Ensure version
specific APIs are guarded with `available` clauses.�
minimum_os_versiono`String`. The minimum OS version (as a dotted version
number like "9.0") that this bundle was built to support.Y
platform_typeH`String`. The platform type for the bundle (i.e. `ios` for iOS bundles).�
product_type�`String`. The dot-separated product type identifier associated
with the bundle (for example, `com.apple.product-type.application`).�

uses_swift�Boolean. True if Swift is used by the target propagating this
provider. This does not consider embedded bundles; for example, an
Objective-C application containing a Swift extension would have this field
set to true for the extension but false for the application."=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl*K
AppleBundleInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzl@
>
archive3`File`. The archive that contains the built bundle.�
�
archive_root�`String`. The file system path (relative to the workspace root) where the signed
bundle was constructed (before archiving). Other rules **should not** depend on
this field; it is intended to support IDEs that want to read that path from the
provider to avoid performance issues from unzipping the output archive.�
�
binary�`File`. The binary (executable, dynamic library, etc.) that was bundled. The
physical file is identical to the one inside the bundle except that it is
always unsigned, so note that it is _not_ a path to the binary inside your
output bundle. The primary purpose of this field is to provide a way to access
the binary directly at analysis time; for example, for code coverage.5
3
bundle_extension`String`. The bundle extension.j
h
	bundle_id[`String`. The bundle identifier (i.e., `CFBundleIdentifier` in
`Info.plist`) of the bundle.I
G
bundle_name8`String`. The name of the bundle, without the extension.9
7
entitlements'`File`. Entitlements file used, if any.K
I
executable_name6`string`. The name of the executable that was bundled.�
�
extension_safe�`Boolean`. True if the target propagating this provider was
compiled and linked with -application-extension, restricting it to
extension-safe APIs only.X
V
	infoplistI`File`. The complete (binary-formatted) `Info.plist` file for the bundle.�
�
minimum_deployment_os_version�`string`. The minimum deployment OS version (as a dotted version
number like "9.0") that this bundle was built to support. This is different from
`minimum_os_version`, which is effective at compile time. Ensure version
specific APIs are guarded with `available` clauses.�
�
minimum_os_versiono`String`. The minimum OS version (as a dotted version
number like "9.0") that this bundle was built to support.[
Y
platform_typeH`String`. The platform type for the bundle (i.e. `ios` for iOS bundles).�
�
product_type�`String`. The dot-separated product type identifier associated
with the bundle (for example, `com.apple.product-type.application`).�
�

uses_swift�Boolean. True if Swift is used by the target propagating this
provider. This does not consider embedded bundles; for example, an
Objective-C application containing a Swift extension would have this field
set to true for the extension but false for the application.�	AppleBinaryInfo�Provides information about an Apple binary target.

This provider propagates general information about an Apple binary that is not
specific to any particular binary type.2�
�
AppleBinaryInfo�Provides information about an Apple binary target.

This provider propagates general information about an Apple binary that is not
specific to any particular binary type.a
binaryW`File`. The binary (executable, dynamic library, etc.) file that the target represents.Y
	infoplistL`File`. The complete (binary-formatted) `Info.plist` embedded in the binary.�
product_type|`String`. The dot-separated product type identifier associated with the binary (for example,
`com.apple.product-type.tool`)."=
AppleBinaryInfo*@rules_apple//apple/internal:providers.bzl*K
AppleBinaryInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzlc
a
binaryW`File`. The binary (executable, dynamic library, etc.) file that the target represents.[
Y
	infoplistL`File`. The complete (binary-formatted) `Info.plist` embedded in the binary.�
�
product_type|`String`. The dot-separated product type identifier associated with the binary (for example,
`com.apple.product-type.tool`).�AppleBundleVersionInfo4Provides versioning information for an Apple bundle.2�
�
AppleBundleVersionInfo4Provides versioning information for an Apple bundle.�
version_file�Required. A `File` containing JSON-formatted text describing the version number information
propagated by the target.

It contains two keys:

*   `build_version`, which corresponds to `CFBundleVersion`.

*   `short_version_string`, which corresponds to `CFBundleShortVersionString`."D
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl*R
AppleBundleVersionInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzl�
�
version_file�Required. A `File` containing JSON-formatted text describing the version number information
propagated by the target.

It contains two keys:

*   `build_version`, which corresponds to `CFBundleVersion`.

*   `short_version_string`, which corresponds to `CFBundleShortVersionString`.�AppleCodesigningDossierInfo>Provides information around the use of a code signing dossier.2�
�
AppleCodesigningDossierInfo>Provides information around the use of a code signing dossier.�
dossier}A `File` reference to the code signing dossier zip that acts as a direct dependency of the given
target if one was generated."I
AppleCodesigningDossierInfo*@rules_apple//apple/internal:providers.bzl*W
AppleCodesigningDossierInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzl�
�
dossier}A `File` reference to the code signing dossier zip that acts as a direct dependency of the given
target if one was generated.�AppleDebugOutputsInfo�Holds debug outputs of an Apple binary rule.

This provider is DEPRECATED. Preferably use `AppleDsymBundleInfo` instead.

The only field is `output_map`, which is a dictionary of:
  `{ arch: { "dsym_binary": File, "linkmap": File }`

Where `arch` is any Apple architecture such as "arm64" or "armv7".2�
�
AppleDebugOutputsInfo�Holds debug outputs of an Apple binary rule.

This provider is DEPRECATED. Preferably use `AppleDsymBundleInfo` instead.

The only field is `output_map`, which is a dictionary of:
  `{ arch: { "dsym_binary": File, "linkmap": File }`

Where `arch` is any Apple architecture such as "arm64" or "armv7".
outputs_map"C
AppleDebugOutputsInfo*@rules_apple//apple/internal:providers.bzl*Q
AppleDebugOutputsInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzl

outputs_map�AppleDsymBundleInfo.Provides information for an Apple dSYM bundle.2�
�
AppleDsymBundleInfo.Provides information for an Apple dSYM bundle.�
direct_dsyms�`List` containing `File` references to each of the dSYM bundles that act as direct dependencies of
the given target if any were generated.�
transitive_dsyms�`depset` containing `File` references to each of the dSYM bundles that act as transitive
dependencies of the given target if any were generated."A
AppleDsymBundleInfo*@rules_apple//apple/internal:providers.bzl*O
AppleDsymBundleInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzl�
�
direct_dsyms�`List` containing `File` references to each of the dSYM bundles that act as direct dependencies of
the given target if any were generated.�
�
transitive_dsyms�`depset` containing `File` references to each of the dSYM bundles that act as transitive
dependencies of the given target if any were generated.�AppleDynamicFrameworkInfo6Contains information about an Apple dynamic framework.2�
�
AppleDynamicFrameworkInfo6Contains information about an Apple dynamic framework.n
framework_dirs\The framework path names used as link inputs in order to link against the
dynamic framework.u
framework_filesbThe full set of artifacts that should be included as inputs to link against the
dynamic framework.=
binary3The dylib binary artifact of the dynamic framework.j
cc_info_A `CcInfo` which contains information about the transitive dependencies linked
into the binary."G
AppleDynamicFrameworkInfo*@rules_apple//apple/internal:providers.bzl*U
AppleDynamicFrameworkInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzlp
n
framework_dirs\The framework path names used as link inputs in order to link against the
dynamic framework.w
u
framework_filesbThe full set of artifacts that should be included as inputs to link against the
dynamic framework.?
=
binary3The dylib binary artifact of the dynamic framework.l
j
cc_info_A `CcInfo` which contains information about the transitive dependencies linked
into the binary.�AppleExecutableBinaryInfovContains the executable binary output that was built using
`link_multi_arch_binary` with the `executable` binary type.2�
�
AppleExecutableBinaryInfovContains the executable binary output that was built using
`link_multi_arch_binary` with the `executable` binary type.L
binaryBThe executable binary artifact output by `link_multi_arch_binary`.j
cc_info_A `CcInfo` which contains information about the transitive dependencies linked
into the binary."G
AppleExecutableBinaryInfo*@rules_apple//apple/internal:providers.bzl*U
AppleExecutableBinaryInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzlN
L
binaryBThe executable binary artifact output by `link_multi_arch_binary`.l
j
cc_info_A `CcInfo` which contains information about the transitive dependencies linked
into the binary.�AppleExtraOutputsInfo�Provides information about extra outputs that should be produced from the build.

This provider propagates supplemental files that should be produced as outputs
even if the bundle they are associated with is not a direct output of the rule.
For example, an application that contains an extension will build both targets
but only the application will be a rule output. However, if dSYM bundles are
also being generated, we do want to produce the dSYMs for *both* application and
extension as outputs of the build, not just the dSYMs of the explicit target
being built (the application).2�	
�
AppleExtraOutputsInfo�Provides information about extra outputs that should be produced from the build.

This provider propagates supplemental files that should be produced as outputs
even if the bundle they are associated with is not a direct output of the rule.
For example, an application that contains an extension will build both targets
but only the application will be a rule output. However, if dSYM bundles are
also being generated, we do want to produce the dSYMs for *both* application and
extension as outputs of the build, not just the dSYMs of the explicit target
being built (the application).�
files�`depset` of `File`s. These files will be propagated from embedded bundles (such
as frameworks and extensions) to the top-level bundle (such as an application)
to ensure that they are explicitly produced as outputs of the build."C
AppleExtraOutputsInfo*@rules_apple//apple/internal:providers.bzl*Q
AppleExtraOutputsInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzl�
�
files�`depset` of `File`s. These files will be propagated from embedded bundles (such
as frameworks and extensions) to the top-level bundle (such as an application)
to ensure that they are explicitly produced as outputs of the build.�AppleFrameworkBundleInfo�Denotes a target is an Apple framework bundle.

This provider does not reference 3rd party or precompiled frameworks.
Propagated by Apple framework rules: `ios_framework`, and `tvos_framework`.2�
�
AppleFrameworkBundleInfo�Denotes a target is an Apple framework bundle.

This provider does not reference 3rd party or precompiled frameworks.
Propagated by Apple framework rules: `ios_framework`, and `tvos_framework`."F
AppleFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl*T
AppleFrameworkBundleInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzl�AppleFrameworkImportInfo�Provider that propagates information about 3rd party imported framework targets.

Propagated by framework and XCFramework import rules: `apple_dynamic_framework_import`,
`apple_dynamic_xcframework_import`, `apple_static_framework_import`, and
`apple_static_xcframework_import`2�
�
AppleFrameworkImportInfo�Provider that propagates information about 3rd party imported framework targets.

Propagated by framework and XCFramework import rules: `apple_dynamic_framework_import`,
`apple_dynamic_xcframework_import`, `apple_static_framework_import`, and
`apple_static_xcframework_import`�
framework_imports�`depset` of `File`s that represent framework imports that need to be bundled in the top level
application bundle under the Frameworks directory.�
dsym_imports�Depset of Files that represent dSYM imports that need to be processed to
provide .symbols files for packaging into the .ipa file if requested in the
build with --define=apple.package_symbols=(yes|true|1).i
build_archsZ`depset` of `String`s that represent binary architectures reported from the current build.s
debug_info_binaries\Depset of Files that represent framework binaries and dSYM binaries that
provide debug info."F
AppleFrameworkImportInfo*@rules_apple//apple/internal:providers.bzl*T
AppleFrameworkImportInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzl�
�
framework_imports�`depset` of `File`s that represent framework imports that need to be bundled in the top level
application bundle under the Frameworks directory.�
�
dsym_imports�Depset of Files that represent dSYM imports that need to be processed to
provide .symbols files for packaging into the .ipa file if requested in the
build with --define=apple.package_symbols=(yes|true|1).k
i
build_archsZ`depset` of `String`s that represent binary architectures reported from the current build.u
s
debug_info_binaries\Depset of Files that represent framework binaries and dSYM binaries that
provide debug info.�ApplePlatformInfo@Provides information for the currently selected Apple platforms.2�
�
ApplePlatformInfo@Provides information for the currently selected Apple platforms.R
target_archC`String` representing the selected target architecture or cpu type.^
target_build_configG'configuration' representing the selected target's build configuration.i
target_environmentS`String` representing the selected target environment (e.g. "device", "simulator").9
	target_os,`String` representing the selected Apple OS."?
ApplePlatformInfo*@rules_apple//apple/internal:providers.bzl*M
ApplePlatformInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzlT
R
target_archC`String` representing the selected target architecture or cpu type.`
^
target_build_configG'configuration' representing the selected target's build configuration.k
i
target_environmentS`String` representing the selected target environment (e.g. "device", "simulator").;
9
	target_os,`String` representing the selected Apple OS.�AppleResourceBundleInfo�Denotes that a target is an Apple resource bundle.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically an Apple resource bundle
(and not some other Apple bundle). Rule authors who wish to require that a
dependency is an Apple resource bundle should use this provider to describe that
requirement.2�
�
AppleResourceBundleInfo�Denotes that a target is an Apple resource bundle.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically an Apple resource bundle
(and not some other Apple bundle). Rule authors who wish to require that a
dependency is an Apple resource bundle should use this provider to describe that
requirement."E
AppleResourceBundleInfo*@rules_apple//apple/internal:providers.bzl*S
AppleResourceBundleInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzl�AppleResourceInfoNProvider that propagates buckets of resources that are differentiated by type.2�
�
AppleResourceInfoNProvider that propagates buckets of resources that are differentiated by type.D
alternate_icons1Alternate icons to be included in the App bundle.E
asset_catalogs3Resources that need to be embedded into Assets.car.

datamodelsDatamodel files.V
	frameworkIApple framework bundle from `ios_framework` and `tvos_framework` targets.�

infoplists�Plist files to be merged and processed. Plist files that should not be merged into the root Info.plist should be propagated in `plists`. Because of this, infoplists should only be bucketed with the `bucketize_typed` method.w
metalsmMetal Shading Language source files to be compiled into a single .metallib file
and bundled at the top level.V
mlmodelsJCore ML model files that should be processed and bundled at the top level.H
plists>Resource Plist files that should not be merged into Info.plist`
pngsXPNG images which are not bundled in an .xcassets folder or an .icon folder in Xcode 26+.>
	processed1Typed resources that have already been processed. 
storyboardsStoryboard files.&
stringsLocalization strings files.'
texture_atlasesTexture atlas files.?
unprocessed0Generic resources not mapped to the other types."
	xcstringsString catalog files.
xibsXIB Interface files..
owners$`depset` of (resource, owner) pairs.K
processed_origins6`depset` of (processed resource, resource list) pairs.3
unowned_resources`depset` of unowned resources."?
AppleResourceInfo*@rules_apple//apple/internal:providers.bzl*M
AppleResourceInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzlF
D
alternate_icons1Alternate icons to be included in the App bundle.G
E
asset_catalogs3Resources that need to be embedded into Assets.car. 


datamodelsDatamodel files.X
V
	frameworkIApple framework bundle from `ios_framework` and `tvos_framework` targets.�
�

infoplists�Plist files to be merged and processed. Plist files that should not be merged into the root Info.plist should be propagated in `plists`. Because of this, infoplists should only be bucketed with the `bucketize_typed` method.y
w
metalsmMetal Shading Language source files to be compiled into a single .metallib file
and bundled at the top level.X
V
mlmodelsJCore ML model files that should be processed and bundled at the top level.J
H
plists>Resource Plist files that should not be merged into Info.plistb
`
pngsXPNG images which are not bundled in an .xcassets folder or an .icon folder in Xcode 26+.@
>
	processed1Typed resources that have already been processed."
 
storyboardsStoryboard files.(
&
stringsLocalization strings files.)
'
texture_atlasesTexture atlas files.A
?
unprocessed0Generic resources not mapped to the other types.$
"
	xcstringsString catalog files.

xibsXIB Interface files.0
.
owners$`depset` of (resource, owner) pairs.M
K
processed_origins6`depset` of (processed resource, resource list) pairs.5
3
unowned_resources`depset` of unowned resources.�AppleSharedCapabilityInfo?Provides information on a mergeable set of shared capabilities.2�
�
AppleSharedCapabilityInfo?Provides information on a mergeable set of shared capabilities.p
base_bundle_id^`String`. The bundle ID prefix, composed from an organization ID and an optional variant name."G
AppleSharedCapabilityInfo*@rules_apple//apple/internal:providers.bzl*U
AppleSharedCapabilityInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzlr
p
base_bundle_id^`String`. The bundle ID prefix, composed from an organization ID and an optional variant name.� AppleStaticXcframeworkBundleInfo�Denotes that a target is a static library XCFramework.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically an XCFramework bundle
(and not some other Apple bundle). Rule authors who wish to require that a
dependency is an XCFramework should use this provider to describe that
requirement.2�
�
 AppleStaticXcframeworkBundleInfo�Denotes that a target is a static library XCFramework.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically an XCFramework bundle
(and not some other Apple bundle). Rule authors who wish to require that a
dependency is an XCFramework should use this provider to describe that
requirement."N
 AppleStaticXcframeworkBundleInfo*@rules_apple//apple/internal:providers.bzl*\
 AppleStaticXcframeworkBundleInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzl�AppleTestInfoDProvider that test targets propagate to be used for IDE integration.2�
�
AppleTestInfoDProvider that test targets propagate to be used for IDE integration.O
test_bundle@The artifact representing the XCTest bundle for the test target.k
	test_host^The artifact representing the test host for the test target, if the test requires a test host.";
AppleTestInfo*@rules_apple//apple/internal:providers.bzl*I
AppleTestInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzlQ
O
test_bundle@The artifact representing the XCTest bundle for the test target.m
k
	test_host^The artifact representing the test host for the test target, if the test requires a test host.�AppleTestRunnerInfo�Provider that runner targets must propagate.

In addition to the fields, all the runfiles that the runner target declares will be added to the
test rules runfiles.2�
�
AppleTestRunnerInfo�Provider that runner targets must propagate.

In addition to the fields, all the runfiles that the runner target declares will be added to the
test rules runfiles.o
execution_requirementsUOptional dictionary that represents the specific hardware requirements for this test.�
execution_environment�Optional dictionary with the environment variables that are to be set in the test action, and are
not propagated into the XCTest invocation. These values will _not_ be added into the %(test_env)s
substitution, but will be set in the test action.�
test_environment�Optional dictionary with the environment variables that are to be propagated into the XCTest
invocation. These values will be included in the %(test_env)s substitution and will _not_ be set in
the test action.�
test_runner_template�Required template file that contains the specific mechanism with which the tests will be run. The
*_ui_test and *_unit_test rules will substitute the following values:
    * %(test_host_path)s:   Path to the app being tested.
    * %(test_bundle_path)s: Path to the test bundle that contains the tests.
    * %(test_env)s:         Environment variables for the XCTest invocation (e.g FOO=BAR,BAZ=QUX).
    * %(test_type)s:        The test type, whether it is unit or UI."A
AppleTestRunnerInfo*@rules_apple//apple/internal:providers.bzl*O
AppleTestRunnerInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzlq
o
execution_requirementsUOptional dictionary that represents the specific hardware requirements for this test.�
�
execution_environment�Optional dictionary with the environment variables that are to be set in the test action, and are
not propagated into the XCTest invocation. These values will _not_ be added into the %(test_env)s
substitution, but will be set in the test action.�
�
test_environment�Optional dictionary with the environment variables that are to be propagated into the XCTest
invocation. These values will be included in the %(test_env)s substitution and will _not_ be set in
the test action.�
�
test_runner_template�Required template file that contains the specific mechanism with which the tests will be run. The
*_ui_test and *_unit_test rules will substitute the following values:
    * %(test_host_path)s:   Path to the app being tested.
    * %(test_bundle_path)s: Path to the test bundle that contains the tests.
    * %(test_env)s:         Environment variables for the XCTest invocation (e.g FOO=BAR,BAZ=QUX).
    * %(test_type)s:        The test type, whether it is unit or UI.�AppleXcframeworkBundleInfo�Denotes that a target is an XCFramework.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically an XCFramework bundle
(and not some other Apple bundle). Rule authors who wish to require that a
dependency is an XCFramework should use this provider to describe that
requirement.2�
�
AppleXcframeworkBundleInfo�Denotes that a target is an XCFramework.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically an XCFramework bundle
(and not some other Apple bundle). Rule authors who wish to require that a
dependency is an XCFramework should use this provider to describe that
requirement."H
AppleXcframeworkBundleInfo*@rules_apple//apple/internal:providers.bzl*V
AppleXcframeworkBundleInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzl�IosAppClipBundleInfo�Denotes that a target is an iOS app clip.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically an iOS app clip bundle (and
not some other Apple bundle). Rule authors who wish to require that a dependency
is an iOS app clip should use this provider to describe that requirement.2�
�
IosAppClipBundleInfo�Denotes that a target is an iOS app clip.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically an iOS app clip bundle (and
not some other Apple bundle). Rule authors who wish to require that a dependency
is an iOS app clip should use this provider to describe that requirement."B
IosAppClipBundleInfo*@rules_apple//apple/internal:providers.bzl*P
IosAppClipBundleInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzl�IosApplicationBundleInfo�Denotes that a target is an iOS application.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically an iOS application bundle
(and not some other Apple bundle). Rule authors who wish to require that a
dependency is an iOS application should use this provider to describe that
requirement.2�
�
IosApplicationBundleInfo�Denotes that a target is an iOS application.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically an iOS application bundle
(and not some other Apple bundle). Rule authors who wish to require that a
dependency is an iOS application should use this provider to describe that
requirement."F
IosApplicationBundleInfo*@rules_apple//apple/internal:providers.bzl*T
IosApplicationBundleInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzl�IosExtensionBundleInfo�Denotes that a target is an iOS application extension.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically an iOS application
extension bundle (and not some other Apple bundle). Rule authors who wish to
require that a dependency is an iOS application extension should use this
provider to describe that requirement.2�
�
IosExtensionBundleInfo�Denotes that a target is an iOS application extension.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically an iOS application
extension bundle (and not some other Apple bundle). Rule authors who wish to
require that a dependency is an iOS application extension should use this
provider to describe that requirement."D
IosExtensionBundleInfo*@rules_apple//apple/internal:providers.bzl*R
IosExtensionBundleInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzl�IosFrameworkBundleInfo�Denotes that a target is an iOS dynamic framework.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically an iOS dynamic framework
bundle (and not some other Apple bundle). Rule authors who wish to require that
a dependency is an iOS dynamic framework should use this provider to describe
that requirement.2�
�
IosFrameworkBundleInfo�Denotes that a target is an iOS dynamic framework.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically an iOS dynamic framework
bundle (and not some other Apple bundle). Rule authors who wish to require that
a dependency is an iOS dynamic framework should use this provider to describe
that requirement."D
IosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl*R
IosFrameworkBundleInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzl� IosImessageApplicationBundleInfo�Denotes that a target is an iOS iMessage application.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically an iOS iMessage application
bundle (and not some other Apple bundle). Rule authors who wish to require that
a dependency is an iOS iMessage application should use this provider to describe
that requirement.2�
�
 IosImessageApplicationBundleInfo�Denotes that a target is an iOS iMessage application.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically an iOS iMessage application
bundle (and not some other Apple bundle). Rule authors who wish to require that
a dependency is an iOS iMessage application should use this provider to describe
that requirement."N
 IosImessageApplicationBundleInfo*@rules_apple//apple/internal:providers.bzl*\
 IosImessageApplicationBundleInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzl�IosImessageExtensionBundleInfo�Denotes that a target is an iOS iMessage extension.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically an iOS iMessage extension
bundle (and not some other Apple bundle). Rule authors who wish to require that
a dependency is an iOS iMessage extension should use this provider to describe
that requirement.2�
�
IosImessageExtensionBundleInfo�Denotes that a target is an iOS iMessage extension.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically an iOS iMessage extension
bundle (and not some other Apple bundle). Rule authors who wish to require that
a dependency is an iOS iMessage extension should use this provider to describe
that requirement."L
IosImessageExtensionBundleInfo*@rules_apple//apple/internal:providers.bzl*Z
IosImessageExtensionBundleInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzl�IosKernelExtensionBundleInfo�Denotes that a target is an iOS kernel extension.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically an iOS kernel extension
bundle (and not some other Apple bundle). Rule authors who wish to require that
a dependency is an iOS kernel extension should use this provider to describe that
requirement.2�
�
IosKernelExtensionBundleInfo�Denotes that a target is an iOS kernel extension.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically an iOS kernel extension
bundle (and not some other Apple bundle). Rule authors who wish to require that
a dependency is an iOS kernel extension should use this provider to describe that
requirement."J
IosKernelExtensionBundleInfo*@rules_apple//apple/internal:providers.bzl*X
IosKernelExtensionBundleInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzl�IosStaticFrameworkBundleInfo�Denotes that a target is an iOS static framework.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically an iOS static framework
bundle (and not some other Apple bundle). Rule authors who wish to require that
a dependency is an iOS static framework should use this provider to describe
that requirement.2�
�
IosStaticFrameworkBundleInfo�Denotes that a target is an iOS static framework.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically an iOS static framework
bundle (and not some other Apple bundle). Rule authors who wish to require that
a dependency is an iOS static framework should use this provider to describe
that requirement."J
IosStaticFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl*X
IosStaticFrameworkBundleInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzl�IosXcTestBundleInfo�Denotes a target that is an iOS .xctest bundle.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically an iOS .xctest bundle (and
not some other Apple bundle). Rule authors who wish to require that a dependency
is an iOS .xctest bundle should use this provider to describe that requirement.2�
�
IosXcTestBundleInfo�Denotes a target that is an iOS .xctest bundle.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically an iOS .xctest bundle (and
not some other Apple bundle). Rule authors who wish to require that a dependency
is an iOS .xctest bundle should use this provider to describe that requirement."A
IosXcTestBundleInfo*@rules_apple//apple/internal:providers.bzl*O
IosXcTestBundleInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzl�MacosApplicationBundleInfo�Denotes that a target is a macOS application.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a macOS application bundle
(and not some other Apple bundle). Rule authors who wish to require that a
dependency is a macOS application should use this provider to describe that
requirement.2�
�
MacosApplicationBundleInfo�Denotes that a target is a macOS application.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a macOS application bundle
(and not some other Apple bundle). Rule authors who wish to require that a
dependency is a macOS application should use this provider to describe that
requirement."H
MacosApplicationBundleInfo*@rules_apple//apple/internal:providers.bzl*V
MacosApplicationBundleInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzl�MacosBundleBundleInfo�Denotes that a target is a macOS loadable bundle.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a macOS loadable bundle
(and not some other Apple bundle). Rule authors who wish to require that a
dependency is a macOS loadable bundle should use this provider to describe that
requirement.2�
�
MacosBundleBundleInfo�Denotes that a target is a macOS loadable bundle.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a macOS loadable bundle
(and not some other Apple bundle). Rule authors who wish to require that a
dependency is a macOS loadable bundle should use this provider to describe that
requirement."C
MacosBundleBundleInfo*@rules_apple//apple/internal:providers.bzl*Q
MacosBundleBundleInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzl�MacosExtensionBundleInfo�Denotes that a target is a macOS application extension.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a macOS application
extension bundle (and not some other Apple bundle). Rule authors who wish to
require that a dependency is a macOS application extension should use this
provider to describe that requirement.2�
�
MacosExtensionBundleInfo�Denotes that a target is a macOS application extension.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a macOS application
extension bundle (and not some other Apple bundle). Rule authors who wish to
require that a dependency is a macOS application extension should use this
provider to describe that requirement."F
MacosExtensionBundleInfo*@rules_apple//apple/internal:providers.bzl*T
MacosExtensionBundleInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzl�MacosKernelExtensionBundleInfo�Denotes that a target is a macOS kernel extension.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a macOS kernel extension
(and not some other Apple bundle). Rule authors who wish to require that a
dependency is a macOS kernel extension should use this provider to describe that
requirement.2�
�
MacosKernelExtensionBundleInfo�Denotes that a target is a macOS kernel extension.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a macOS kernel extension
(and not some other Apple bundle). Rule authors who wish to require that a
dependency is a macOS kernel extension should use this provider to describe that
requirement."L
MacosKernelExtensionBundleInfo*@rules_apple//apple/internal:providers.bzl*Z
MacosKernelExtensionBundleInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzl�MacosQuickLookPluginBundleInfo�Denotes that a target is a macOS Quick Look Generator bundle.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a macOS Quick Look generator
bundle (and not some other Apple bundle). Rule authors who wish to require that
a dependency is a macOS Quick Look generator should use this provider to describe
that requirement.2�
�
MacosQuickLookPluginBundleInfo�Denotes that a target is a macOS Quick Look Generator bundle.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a macOS Quick Look generator
bundle (and not some other Apple bundle). Rule authors who wish to require that
a dependency is a macOS Quick Look generator should use this provider to describe
that requirement."L
MacosQuickLookPluginBundleInfo*@rules_apple//apple/internal:providers.bzl*Z
MacosQuickLookPluginBundleInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzl� MacosSpotlightImporterBundleInfo�Denotes that a target is a macOS Spotlight Importer bundle.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a macOS Spotlight importer
(and not some other Apple bundle). Rule authors who wish to require that a
dependency is a macOS Spotlight importer should use this provider to describe that
requirement.2�
�
 MacosSpotlightImporterBundleInfo�Denotes that a target is a macOS Spotlight Importer bundle.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a macOS Spotlight importer
(and not some other Apple bundle). Rule authors who wish to require that a
dependency is a macOS Spotlight importer should use this provider to describe that
requirement."N
 MacosSpotlightImporterBundleInfo*@rules_apple//apple/internal:providers.bzl*\
 MacosSpotlightImporterBundleInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzl�MacosXPCServiceBundleInfo�Denotes that a target is a macOS XPC Service bundle.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a macOS XPC service
(and not some other Apple bundle). Rule authors who wish to require that a
dependency is a macOS XPC service should use this provider to describe that
requirement.2�
�
MacosXPCServiceBundleInfo�Denotes that a target is a macOS XPC Service bundle.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a macOS XPC service
(and not some other Apple bundle). Rule authors who wish to require that a
dependency is a macOS XPC service should use this provider to describe that
requirement."G
MacosXPCServiceBundleInfo*@rules_apple//apple/internal:providers.bzl*U
MacosXPCServiceBundleInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzl�MacosXcTestBundleInfo�Denotes a target that is a macOS .xctest bundle.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a macOS .xctest bundle
(and not some other Apple bundle). Rule authors who wish to require that a
dependency is a macOS .xctest bundle should use this provider to describe that
requirement.2�
�
MacosXcTestBundleInfo�Denotes a target that is a macOS .xctest bundle.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a macOS .xctest bundle
(and not some other Apple bundle). Rule authors who wish to require that a
dependency is a macOS .xctest bundle should use this provider to describe that
requirement."C
MacosXcTestBundleInfo*@rules_apple//apple/internal:providers.bzl*Q
MacosXcTestBundleInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzl�TvosApplicationBundleInfo�Denotes that a target is a tvOS application.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a tvOS application bundle
(and not some other Apple bundle). Rule authors who wish to require that a
dependency is a tvOS application should use this provider to describe that
requirement.2�
�
TvosApplicationBundleInfo�Denotes that a target is a tvOS application.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a tvOS application bundle
(and not some other Apple bundle). Rule authors who wish to require that a
dependency is a tvOS application should use this provider to describe that
requirement."G
TvosApplicationBundleInfo*@rules_apple//apple/internal:providers.bzl*U
TvosApplicationBundleInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzl�TvosExtensionBundleInfo�Denotes that a target is a tvOS application extension.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a tvOS application
extension bundle (and not some other Apple bundle). Rule authors who wish to
require that a dependency is a tvOS application extension should use this
provider to describe that requirement.2�
�
TvosExtensionBundleInfo�Denotes that a target is a tvOS application extension.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a tvOS application
extension bundle (and not some other Apple bundle). Rule authors who wish to
require that a dependency is a tvOS application extension should use this
provider to describe that requirement."E
TvosExtensionBundleInfo*@rules_apple//apple/internal:providers.bzl*S
TvosExtensionBundleInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzl�TvosFrameworkBundleInfo�Denotes that a target is a tvOS dynamic framework.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a tvOS dynamic framework
bundle (and not some other Apple bundle). Rule authors who wish to require that
a dependency is a tvOS dynamic framework should use this provider to describe
that requirement.2�
�
TvosFrameworkBundleInfo�Denotes that a target is a tvOS dynamic framework.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a tvOS dynamic framework
bundle (and not some other Apple bundle). Rule authors who wish to require that
a dependency is a tvOS dynamic framework should use this provider to describe
that requirement."E
TvosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl*S
TvosFrameworkBundleInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzl�TvosStaticFrameworkBundleInfo�Denotes that a target is a tvOS static framework.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a tvOS static framework
bundle (and not some other Apple bundle). Rule authors who wish to require that
a dependency is a tvOS static framework should use this provider to describe
that requirement.2�
�
TvosStaticFrameworkBundleInfo�Denotes that a target is a tvOS static framework.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a tvOS static framework
bundle (and not some other Apple bundle). Rule authors who wish to require that
a dependency is a tvOS static framework should use this provider to describe
that requirement."K
TvosStaticFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl*Y
TvosStaticFrameworkBundleInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzl�TvosXcTestBundleInfo�Denotes a target that is a tvOS .xctest bundle.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a tvOS .xctest bundle (and
not some other Apple bundle). Rule authors who wish to require that a dependency
is a tvOS .xctest bundle should use this provider to describe that requirement.2�
�
TvosXcTestBundleInfo�Denotes a target that is a tvOS .xctest bundle.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a tvOS .xctest bundle (and
not some other Apple bundle). Rule authors who wish to require that a dependency
is a tvOS .xctest bundle should use this provider to describe that requirement."B
TvosXcTestBundleInfo*@rules_apple//apple/internal:providers.bzl*P
TvosXcTestBundleInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzl�VisionosApplicationBundleInfo�Denotes that a target is a visionOS application.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a visionOS application
bundle (and not some other Apple bundle). Rule authors who wish to require that a
dependency is a visionOS application should use this provider to describe that
requirement.2�
�
VisionosApplicationBundleInfo�Denotes that a target is a visionOS application.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a visionOS application
bundle (and not some other Apple bundle). Rule authors who wish to require that a
dependency is a visionOS application should use this provider to describe that
requirement."K
VisionosApplicationBundleInfo*@rules_apple//apple/internal:providers.bzl*Y
VisionosApplicationBundleInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzl�VisionosFrameworkBundleInfo�Denotes that a target is visionOS dynamic framework.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a visionOS dynamic framework
bundle (and not some other Apple bundle). Rule authors who wish to require that
a dependency is a visionOS dynamic framework should use this provider to describe
that requirement.2�
�
VisionosFrameworkBundleInfo�Denotes that a target is visionOS dynamic framework.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a visionOS dynamic framework
bundle (and not some other Apple bundle). Rule authors who wish to require that
a dependency is a visionOS dynamic framework should use this provider to describe
that requirement."I
VisionosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl*W
VisionosFrameworkBundleInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzl�VisionosExtensionBundleInfo�Denotes that a target is a visionOS application.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a visionOS application
bundle (and not some other Apple bundle). Rule authors who wish to require that a
dependency is a visionOS application should use this provider to describe that
requirement.2�
�
VisionosExtensionBundleInfo�Denotes that a target is a visionOS application.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a visionOS application
bundle (and not some other Apple bundle). Rule authors who wish to require that a
dependency is a visionOS application should use this provider to describe that
requirement."K
VisionosApplicationBundleInfo*@rules_apple//apple/internal:providers.bzl*W
VisionosExtensionBundleInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzl�VisionosXcTestBundleInfo�Denotes a target that is a visionOS .xctest bundle.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a visionOS .xctest bundle
(and not some other Apple bundle). Rule authors who wish to require that a
dependency is a visionOS .xctest bundle  should use this provider to describe
that requirement.2�
�
VisionosXcTestBundleInfo�Denotes a target that is a visionOS .xctest bundle.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a visionOS .xctest bundle
(and not some other Apple bundle). Rule authors who wish to require that a
dependency is a visionOS .xctest bundle  should use this provider to describe
that requirement."F
VisionosXcTestBundleInfo*@rules_apple//apple/internal:providers.bzl*T
VisionosXcTestBundleInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzl�WatchosApplicationBundleInfo�Denotes that a target is a watchOS application.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a watchOS application
bundle (and not some other Apple bundle). Rule authors who wish to require that
a dependency is a watchOS application should use this provider to describe that
requirement.2�
�
WatchosApplicationBundleInfo�Denotes that a target is a watchOS application.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a watchOS application
bundle (and not some other Apple bundle). Rule authors who wish to require that
a dependency is a watchOS application should use this provider to describe that
requirement."J
WatchosApplicationBundleInfo*@rules_apple//apple/internal:providers.bzl*X
WatchosApplicationBundleInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzl�WatchosExtensionBundleInfo�Denotes that a target is a watchOS application extension.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a watchOS application
extension bundle (and not some other Apple bundle). Rule authors who wish to
require that a dependency is a watchOS application extension should use this
provider to describe that requirement.2�
�
WatchosExtensionBundleInfo�Denotes that a target is a watchOS application extension.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a watchOS application
extension bundle (and not some other Apple bundle). Rule authors who wish to
require that a dependency is a watchOS application extension should use this
provider to describe that requirement."H
WatchosExtensionBundleInfo*@rules_apple//apple/internal:providers.bzl*V
WatchosExtensionBundleInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzl�WatchosXcTestBundleInfo�Denotes a target that is a watchOS .xctest bundle.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a watchOS .xctest bundle (and
not some other Apple bundle). Rule authors who wish to require that a dependency
is a watchOS .xctest bundle should use this provider to describe that requirement.2�
�
WatchosXcTestBundleInfo�Denotes a target that is a watchOS .xctest bundle.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a watchOS .xctest bundle (and
not some other Apple bundle). Rule authors who wish to require that a dependency
is a watchOS .xctest bundle should use this provider to describe that requirement."E
WatchosXcTestBundleInfo*@rules_apple//apple/internal:providers.bzl*S
WatchosXcTestBundleInfo

kwargs(2,*@rules_apple//apple/internal:providers.bzl�AppleBinaryInfoplistInfoVProvides information about the Info.plist that was linked into an Apple binary
target.2�
�
AppleBinaryInfoplistInfoVProvides information about the Info.plist that was linked into an Apple binary
target.Y
	infoplistL`File`. The complete (binary-formatted) `Info.plist` embedded in the binary."=
AppleBinaryInfoplistInfo!@rules_apple//apple:providers.bzl[
Y
	infoplistL`File`. The complete (binary-formatted) `Info.plist` embedded in the binary.�AppleDeviceTestRunnerInfo9Provider that device-based runner targets must propagate.2�
�
AppleDeviceTestRunnerInfo9Provider that device-based runner targets must propagate.�
device_type�The device type of the iOS simulator to run test. The supported types correspond
to the output of `xcrun simctl list devicetypes`. E.g., iPhone X, iPad Air.�

os_version�The os version of the iOS simulator to run test. The supported os versions
correspond to the output of `xcrun simctl list runtimes`. E.g., 15.5.">
AppleDeviceTestRunnerInfo!@rules_apple//apple:providers.bzl�
�
device_type�The device type of the iOS simulator to run test. The supported types correspond
to the output of `xcrun simctl list devicetypes`. E.g., iPhone X, iPad Air.�
�

os_version�The os version of the iOS simulator to run test. The supported os versions
correspond to the output of `xcrun simctl list runtimes`. E.g., 15.5.�AppleProvisioningProfileInfo2Provides information about a provisioning profile.2�
�
AppleProvisioningProfileInfo2Provides information about a provisioning profile.9
provisioning_profile!`File`. The provisioning profile.a
profile_nameQstring. The profile name (e.g. "iOS Team Provisioning Profile: com.example.app").�
team_idw`string`. The Team ID the profile is associated with (e.g. "A12B3CDEFG"), or `None` if it's not
known at analysis time."A
AppleProvisioningProfileInfo!@rules_apple//apple:providers.bzl;
9
provisioning_profile!`File`. The provisioning profile.c
a
profile_nameQstring. The profile name (e.g. "iOS Team Provisioning Profile: com.example.app").�
�
team_idw`string`. The Team ID the profile is associated with (e.g. "A12B3CDEFG"), or `None` if it's not
known at analysis time.�!IosStickerPackExtensionBundleInfo�Denotes that a target is an iOS Sticker Pack extension.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically an iOS Sticker Pack extension
bundle (and not some other Apple bundle). Rule authors who wish to require that
a dependency is an iOS Sticker Pack extension should use this provider to describe
that requirement.2�
�
!IosStickerPackExtensionBundleInfo�Denotes that a target is an iOS Sticker Pack extension.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically an iOS Sticker Pack extension
bundle (and not some other Apple bundle). Rule authors who wish to require that
a dependency is an iOS Sticker Pack extension should use this provider to describe
that requirement."F
!IosStickerPackExtensionBundleInfo!@rules_apple//apple:providers.bzl�WatchosFrameworkBundleInfo�Denotes that a target is watchOS dynamic framework.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a watchOS dynamic framework
bundle (and not some other Apple bundle). Rule authors who wish to require that
a dependency is a watchOS dynamic framework should use this provider to describe
that requirement.2�
�
WatchosFrameworkBundleInfo�Denotes that a target is watchOS dynamic framework.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a watchOS dynamic framework
bundle (and not some other Apple bundle). Rule authors who wish to require that
a dependency is a watchOS dynamic framework should use this provider to describe
that requirement."?
WatchosFrameworkBundleInfo!@rules_apple//apple:providers.bzl� WatchosStaticFrameworkBundleInfo�Denotes that a target is an watchOS static framework.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a watchOS static framework
bundle (and not some other Apple bundle). Rule authors who wish to require that
a dependency is a watchOS static framework should use this provider to describe
that requirement.2�
�
 WatchosStaticFrameworkBundleInfo�Denotes that a target is an watchOS static framework.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically a watchOS static framework
bundle (and not some other Apple bundle). Rule authors who wish to require that
a dependency is a watchOS static framework should use this provider to describe
that requirement."E
 WatchosStaticFrameworkBundleInfo!@rules_apple//apple:providers.bzl�MacosFrameworkBundleInfo�Denotes that a target is an macOS dynamic framework.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically an macOS dynamic framework
bundle (and not some other Apple bundle). Rule authors who wish to require that
a dependency is an macOS dynamic framework should use this provider to describe
that requirement.2�
�
MacosFrameworkBundleInfo�Denotes that a target is an macOS dynamic framework.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically an macOS dynamic framework
bundle (and not some other Apple bundle). Rule authors who wish to require that
a dependency is an macOS dynamic framework should use this provider to describe
that requirement."=
MacosFrameworkBundleInfo!@rules_apple//apple:providers.bzl�MacosStaticFrameworkBundleInfo�Denotes that a target is an macOS static framework.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically an macOS static framework
bundle (and not some other Apple bundle). Rule authors who wish to require that
a dependency is an macOS static framework should use this provider to describe
that requirement.2�
�
MacosStaticFrameworkBundleInfo�Denotes that a target is an macOS static framework.

This provider does not contain any fields of its own at this time but is used as
a "marker" to indicate that a target is specifically an macOS static framework
bundle (and not some other Apple bundle). Rule authors who wish to require that
a dependency is an macOS static framework should use this provider to describe
that requirement."C
MacosStaticFrameworkBundleInfo!@rules_apple//apple:providers.bzl�DocCBundleInfo2Provides general information about a .docc bundle.2�
�
DocCBundleInfo2Provides general information about a .docc bundle.&
bundlethe path to the .docc bundleB
bundle_files2the file targets contained within the .docc bundle"3
DocCBundleInfo!@rules_apple//apple:providers.bzl(
&
bundlethe path to the .docc bundleD
B
bundle_files2the file targets contained within the .docc bundle�DocCSymbolGraphsInfo>Provides the symbol graphs required to archive a .docc bundle.2�
�
DocCSymbolGraphsInfo>Provides the symbol graphs required to archive a .docc bundle.9
symbol_graphs(the depset of paths to the symbol graphs"9
DocCSymbolGraphsInfo!@rules_apple//apple:providers.bzl;
9
symbol_graphs(the depset of paths to the symbol graphs�# Providers

Defines providers and related types used throughout the rules in this repository.

Most users will not need to use these providers to simply create and build Apple
targets, but if you want to write your own custom rules that interact with these
rules, then you will use these providers to communicate between them.

These providers are part of the public API of the bundling rules. Other rules that want to propagate
information to the bundling rules or that want to consume the bundling rules as their own inputs
should use these to handle the relevant information that they need.

Public initializers must be defined in apple:providers.bzl instead of apple/internal:providers.bzl.
These should build from the "raw initializer" where possible, but not export it, to allow for a safe
boundary with well-defined public APIs for broader usage.��
#
rules_appleappleresources.bzl�apple_bundle_import�This rule encapsulates an already-built bundle. It is defined by a list of files
in exactly one `.bundle` directory. `apple_bundle_import` targets need to be
added to library targets through the `data` attribute, or to other resource
targets (i.e. `apple_resource_bundle` and `apple_resource_group`) through the
`resources` attribute."�
�
apple_bundle_import�This rule encapsulates an already-built bundle. It is defined by a list of files
in exactly one `.bundle` directory. `apple_bundle_import` targets need to be
added to library targets through the `data` attribute, or to other resource
targets (i.e. `apple_resource_bundle` and `apple_resource_group`) through the
`resources` attribute.*
nameA unique name for this target. v
bundle_imports`The list of files under a `.bundle` directory to be propagated to the top-level bundling target. "Z
apple_bundle_importC@rules_apple//apple/internal/resource_rules:apple_bundle_import.bzl,
*
nameA unique name for this target. x
v
bundle_imports`The list of files under a `.bundle` directory to be propagated to the top-level bundling target. �apple_intent_library�This rule supports the integration of Intents `.intentdefinition` files into Apple rules.
It takes a single `.intentdefinition` file and creates a target that can be added as a dependency from `objc_library` or
`swift_library` targets. It accepts the regular `objc_library` attributes too.
This target generates a header named `<target_name>.h` that can be imported from within the package where this target
resides. For example, if this target's label is `//my/package:intent`, you can import the header as
`#import "my/package/intent.h"`."�
�	
apple_intent_library�This rule supports the integration of Intents `.intentdefinition` files into Apple rules.
It takes a single `.intentdefinition` file and creates a target that can be added as a dependency from `objc_library` or
`swift_library` targets. It accepts the regular `objc_library` attributes too.
This target generates a header named `<target_name>.h` that can be imported from within the package where this target
resides. For example, if this target's label is `//my/package:intent`, you can import the header as
`#import "my/package/intent.h"`.*
nameA unique name for this target. \
srcQLabel to a single `.intentdefinition` files from which to generate sources files. ^
language6Language of generated classes ("Objective-C", "Swift") J"Objective-C"J"Swift"D
class_prefix.Class prefix to use for the generated classes.2""I
swift_version2Version of Swift to use for the generated classes.2""�
class_visibilityPVisibility attribute for the generated classes ("public", "private", "project").2""J"public"J	"private"J	"project"R
header_name=Name of the public header file (only when using Objective-C).2"""\
apple_intent_libraryD@rules_apple//apple/internal/resource_rules:apple_intent_library.bzl,
*
nameA unique name for this target. ^
\
srcQLabel to a single `.intentdefinition` files from which to generate sources files. `
^
language6Language of generated classes ("Objective-C", "Swift") J"Objective-C"J"Swift"F
D
class_prefix.Class prefix to use for the generated classes.2""K
I
swift_version2Version of Swift to use for the generated classes.2""�
�
class_visibilityPVisibility attribute for the generated classes ("public", "private", "project").2""J"public"J	"private"J	"project"T
R
header_name=Name of the public header file (only when using Objective-C).2""�apple_metal_library<Compiles Metal shader language sources into a Metal library."�
�
apple_metal_library<Compiles Metal shader language sources into a Metal library.*
nameA unique name for this target. Y
coptsJA list of compiler options passed to the `metal` compiler for each source.2[]T
hdrsFA list of headers to make importable when compiling the metal library.2[]k
outNAn output `.metallib` filename. Defaults to `default.metallib` if unspecified.2"default.metallib"S
srcsGA list of `.metal` source files that will be compiled into the library. "Z
apple_metal_libraryC@rules_apple//apple/internal/resource_rules:apple_metal_library.bzl,
*
nameA unique name for this target. [
Y
coptsJA list of compiler options passed to the `metal` compiler for each source.2[]V
T
hdrsFA list of headers to make importable when compiling the metal library.2[]m
k
outNAn output `.metallib` filename. Defaults to `default.metallib` if unspecified.2"default.metallib"U
S
srcsGA list of `.metal` source files that will be compiled into the library. �4!apple_precompiled_resource_bundle�This rule encapsulates a target which is provided to dependers as a bundle. An
`apple_precompiled_resource_bundle`'s resources are put in a resource bundle in the top
level Apple bundle dependent. `apple_precompiled_resource_bundle` targets need to be added to
library targets through the `data` attribute."�1
�
!apple_precompiled_resource_bundle�This rule encapsulates a target which is provided to dependers as a bundle. An
`apple_precompiled_resource_bundle`'s resources are put in a resource bundle in the top
level Apple bundle dependent. `apple_precompiled_resource_bundle` targets need to be added to
library targets through the `data` attribute.*
nameA unique name for this target. �
	bundle_id�The bundle ID for this target. It will replace `$(PRODUCT_BUNDLE_IDENTIFIER)` found in the files
from defined in the `infoplists` paramter.2""�
bundle_name�The desired name of the bundle (without the `.bundle` extension). If this attribute is not set,
then the `name` of the target will be used instead.2""�

infoplists�A list of `.plist` files that will be merged to form the `Info.plist` that represents the extension.
At least one file must be specified.
Please see [Info.plist Handling](/doc/common_info.md#infoplist-handling") for what is supported.

Duplicate keys between infoplist files
will cause an error if and only if the values conflict.
Bazel will perform variable substitution on the Info.plist file for the following values (if they
are strings in the top-level dict of the plist):

${BUNDLE_NAME}: This target's name and bundle suffix (.bundle or .app) in the form name.suffix.
${PRODUCT_NAME}: This target's name.
${TARGET_NAME}: This target's name.
The key in ${} may be suffixed with :rfc1034identifier (for example
${PRODUCT_NAME::rfc1034identifier}) in which case Bazel will replicate Xcode's behavior and replace
non-RFC1034-compliant characters with -.2[]�
	resources�Files to include in the resource bundle. Files that are processable resources, like .xib,
.storyboard, .strings, .png, and others, will be processed by the Apple bundling rules that have
those files as dependencies. Other file types that are not processed will be copied verbatim. These
files are placed in the root of the resource bundle (e.g. `Payload/foo.app/bar.bundle/...`) in most
cases. However, if they appear to be localized (i.e. are contained in a directory called *.lproj),
they will be placed in a directory of the same name in the app bundle.

You can also add other `apple_precompiled_resource_bundle` and `apple_bundle_import` targets into `resources`,
and the resource bundle structures will be propagated into the final bundle.2[]�
#strip_structured_resources_prefixes�A list of prefixes to strip from the paths of structured resources. For each
structured resource, if the path starts with one of these prefixes, the first
matching prefix will be removed from the path when the resource is placed in
the bundle root. This is useful for removing intermediate directories from the
resource paths.

For example, if `structured_resources` contains `["intermediate/res/foo.png"]`,
and `strip_structured_resources_prefixes` contains `["intermediate"]`,
`res/foo.png` will end up inside the bundle.2[]�
structured_resources�Files to include in the final resource bundle. They are not processed or compiled in any way
besides the processing done by the rules that actually generate them. These files are placed in the
bundle root in the same structure passed to this argument, so `["res/foo.png"]` will end up in
`res/foo.png` inside the bundle.2[]"v
!apple_precompiled_resource_bundleQ@rules_apple//apple/internal/resource_rules:apple_precompiled_resource_bundle.bzl,
*
nameA unique name for this target. �
�
	bundle_id�The bundle ID for this target. It will replace `$(PRODUCT_BUNDLE_IDENTIFIER)` found in the files
from defined in the `infoplists` paramter.2""�
�
bundle_name�The desired name of the bundle (without the `.bundle` extension). If this attribute is not set,
then the `name` of the target will be used instead.2""�
�

infoplists�A list of `.plist` files that will be merged to form the `Info.plist` that represents the extension.
At least one file must be specified.
Please see [Info.plist Handling](/doc/common_info.md#infoplist-handling") for what is supported.

Duplicate keys between infoplist files
will cause an error if and only if the values conflict.
Bazel will perform variable substitution on the Info.plist file for the following values (if they
are strings in the top-level dict of the plist):

${BUNDLE_NAME}: This target's name and bundle suffix (.bundle or .app) in the form name.suffix.
${PRODUCT_NAME}: This target's name.
${TARGET_NAME}: This target's name.
The key in ${} may be suffixed with :rfc1034identifier (for example
${PRODUCT_NAME::rfc1034identifier}) in which case Bazel will replicate Xcode's behavior and replace
non-RFC1034-compliant characters with -.2[]�
�
	resources�Files to include in the resource bundle. Files that are processable resources, like .xib,
.storyboard, .strings, .png, and others, will be processed by the Apple bundling rules that have
those files as dependencies. Other file types that are not processed will be copied verbatim. These
files are placed in the root of the resource bundle (e.g. `Payload/foo.app/bar.bundle/...`) in most
cases. However, if they appear to be localized (i.e. are contained in a directory called *.lproj),
they will be placed in a directory of the same name in the app bundle.

You can also add other `apple_precompiled_resource_bundle` and `apple_bundle_import` targets into `resources`,
and the resource bundle structures will be propagated into the final bundle.2[]�
�
#strip_structured_resources_prefixes�A list of prefixes to strip from the paths of structured resources. For each
structured resource, if the path starts with one of these prefixes, the first
matching prefix will be removed from the path when the resource is placed in
the bundle root. This is useful for removing intermediate directories from the
resource paths.

For example, if `structured_resources` contains `["intermediate/res/foo.png"]`,
and `strip_structured_resources_prefixes` contains `["intermediate"]`,
`res/foo.png` will end up inside the bundle.2[]�
�
structured_resources�Files to include in the final resource bundle. They are not processed or compiled in any way
besides the processing done by the rules that actually generate them. These files are placed in the
bundle root in the same structure passed to this argument, so `["res/foo.png"]` will end up in
`res/foo.png` inside the bundle.2[]�3apple_resource_bundle�This rule encapsulates a target which is provided to dependers as a bundle. An
`apple_resource_bundle`'s resources are put in a resource bundle in the top
level Apple bundle dependent. apple_resource_bundle targets need to be added to
library targets through the `data` attribute."�1
�
apple_resource_bundle�This rule encapsulates a target which is provided to dependers as a bundle. An
`apple_resource_bundle`'s resources are put in a resource bundle in the top
level Apple bundle dependent. apple_resource_bundle targets need to be added to
library targets through the `data` attribute.*
nameA unique name for this target. �
	bundle_id�The bundle ID for this target. It will replace `$(PRODUCT_BUNDLE_IDENTIFIER)` found in the files
from defined in the `infoplists` paramter.2""�
bundle_name�The desired name of the bundle (without the `.bundle` extension). If this attribute is not set,
then the `name` of the target will be used instead.2""�

infoplists�A list of `.plist` files that will be merged to form the `Info.plist` that represents the extension.
At least one file must be specified.
Please see [Info.plist Handling](/doc/common_info.md#infoplist-handling") for what is supported.

Duplicate keys between infoplist files
will cause an error if and only if the values conflict.
Bazel will perform variable substitution on the Info.plist file for the following values (if they
are strings in the top-level dict of the plist):

${BUNDLE_NAME}: This target's name and bundle suffix (.bundle or .app) in the form name.suffix.
${PRODUCT_NAME}: This target's name.
${TARGET_NAME}: This target's name.
The key in ${} may be suffixed with :rfc1034identifier (for example
${PRODUCT_NAME::rfc1034identifier}) in which case Bazel will replicate Xcode's behavior and replace
non-RFC1034-compliant characters with -.2[]�
	resources�Files to include in the resource bundle. Files that are processable resources, like .xib,
.storyboard, .strings, .png, and others, will be processed by the Apple bundling rules that have
those files as dependencies. Other file types that are not processed will be copied verbatim. These
files are placed in the root of the resource bundle (e.g. `Payload/foo.app/bar.bundle/...`) in most
cases. However, if they appear to be localized (i.e. are contained in a directory called *.lproj),
they will be placed in a directory of the same name in the app bundle.

You can also add other `apple_resource_bundle` and `apple_bundle_import` targets into `resources`,
and the resource bundle structures will be propagated into the final bundle.2[]�
#strip_structured_resources_prefixes�A list of prefixes to strip from the paths of structured resources. For each
structured resource, if the path starts with one of these prefixes, the first
matching prefix will be removed from the path when the resource is placed in
the bundle root. This is useful for removing intermediate directories from the
resource paths.

For example, if `structured_resources` contains `["intermediate/res/foo.png"]`,
and `strip_structured_resources_prefixes` contains `["intermediate"]`,
`res/foo.png` will end up inside the bundle.2[]�
structured_resources�Files to include in the final resource bundle. They are not processed or compiled in any way
besides the processing done by the rules that actually generate them. These files are placed in the
bundle root in the same structure passed to this argument, so `["res/foo.png"]` will end up in
`res/foo.png` inside the bundle.2[]"^
apple_resource_bundleE@rules_apple//apple/internal/resource_rules:apple_resource_bundle.bzl,
*
nameA unique name for this target. �
�
	bundle_id�The bundle ID for this target. It will replace `$(PRODUCT_BUNDLE_IDENTIFIER)` found in the files
from defined in the `infoplists` paramter.2""�
�
bundle_name�The desired name of the bundle (without the `.bundle` extension). If this attribute is not set,
then the `name` of the target will be used instead.2""�
�

infoplists�A list of `.plist` files that will be merged to form the `Info.plist` that represents the extension.
At least one file must be specified.
Please see [Info.plist Handling](/doc/common_info.md#infoplist-handling") for what is supported.

Duplicate keys between infoplist files
will cause an error if and only if the values conflict.
Bazel will perform variable substitution on the Info.plist file for the following values (if they
are strings in the top-level dict of the plist):

${BUNDLE_NAME}: This target's name and bundle suffix (.bundle or .app) in the form name.suffix.
${PRODUCT_NAME}: This target's name.
${TARGET_NAME}: This target's name.
The key in ${} may be suffixed with :rfc1034identifier (for example
${PRODUCT_NAME::rfc1034identifier}) in which case Bazel will replicate Xcode's behavior and replace
non-RFC1034-compliant characters with -.2[]�
�
	resources�Files to include in the resource bundle. Files that are processable resources, like .xib,
.storyboard, .strings, .png, and others, will be processed by the Apple bundling rules that have
those files as dependencies. Other file types that are not processed will be copied verbatim. These
files are placed in the root of the resource bundle (e.g. `Payload/foo.app/bar.bundle/...`) in most
cases. However, if they appear to be localized (i.e. are contained in a directory called *.lproj),
they will be placed in a directory of the same name in the app bundle.

You can also add other `apple_resource_bundle` and `apple_bundle_import` targets into `resources`,
and the resource bundle structures will be propagated into the final bundle.2[]�
�
#strip_structured_resources_prefixes�A list of prefixes to strip from the paths of structured resources. For each
structured resource, if the path starts with one of these prefixes, the first
matching prefix will be removed from the path when the resource is placed in
the bundle root. This is useful for removing intermediate directories from the
resource paths.

For example, if `structured_resources` contains `["intermediate/res/foo.png"]`,
and `strip_structured_resources_prefixes` contains `["intermediate"]`,
`res/foo.png` will end up inside the bundle.2[]�
�
structured_resources�Files to include in the final resource bundle. They are not processed or compiled in any way
besides the processing done by the rules that actually generate them. These files are placed in the
bundle root in the same structure passed to this argument, so `["res/foo.png"]` will end up in
`res/foo.png` inside the bundle.2[]�"apple_resource_group�This rule encapsulates a target which provides resources to dependents. An
`apple_resource_group`'s `resources` and `structured_resources` are put in the
top-level Apple bundle target. `apple_resource_group` targets need to be added
to library targets through the `data` attribute, or to other
`apple_resource_bundle` or `apple_resource_group` targets through the
`resources` attribute."�
�
apple_resource_group�This rule encapsulates a target which provides resources to dependents. An
`apple_resource_group`'s `resources` and `structured_resources` are put in the
top-level Apple bundle target. `apple_resource_group` targets need to be added
to library targets through the `data` attribute, or to other
`apple_resource_bundle` or `apple_resource_group` targets through the
`resources` attribute.*
nameA unique name for this target. �
	resources�Files to include in the final bundle that depends on this target. Files that are processable
resources, like .xib, .storyboard, .strings, .png, and others, will be processed by the Apple
bundling rules that have those files as dependencies. Other file types that are not processed will
be copied verbatim. These files are placed in the root of the final bundle (e.g.
Payload/foo.app/...) in most cases. However, if they appear to be localized (i.e. are contained in a
directory called *.lproj), they will be placed in a directory of the same name in the app bundle.

You can also add apple_resource_bundle and apple_bundle_import targets into `resources`, and the
resource bundle structures will be propagated into the final bundle.2[]�
#strip_structured_resources_prefixes�A list of prefixes to strip from the paths of structured resources. For each
structured resource, if the path starts with one of these prefixes, the first
matching prefix will be removed from the path when the resource is placed in
the bundle root. This is useful for removing intermediate directories from the
resource paths.

For example, if `structured_resources` contains `["intermediate/res/foo.png"]`,
and `strip_structured_resources_prefixes` contains `["intermediate"]`,
`res/foo.png` will end up inside the bundle.2[]�
structured_resources�Files to include in the final application bundle. They are not processed or compiled in any way
besides the processing done by the rules that actually generate them. These files are placed in the
bundle root in the same structure passed to this argument, so `["res/foo.png"]` will end up in
`res/foo.png` inside the bundle.2[]"\
apple_resource_groupD@rules_apple//apple/internal/resource_rules:apple_resource_group.bzl,
*
nameA unique name for this target. �
�
	resources�Files to include in the final bundle that depends on this target. Files that are processable
resources, like .xib, .storyboard, .strings, .png, and others, will be processed by the Apple
bundling rules that have those files as dependencies. Other file types that are not processed will
be copied verbatim. These files are placed in the root of the final bundle (e.g.
Payload/foo.app/...) in most cases. However, if they appear to be localized (i.e. are contained in a
directory called *.lproj), they will be placed in a directory of the same name in the app bundle.

You can also add apple_resource_bundle and apple_bundle_import targets into `resources`, and the
resource bundle structures will be propagated into the final bundle.2[]�
�
#strip_structured_resources_prefixes�A list of prefixes to strip from the paths of structured resources. For each
structured resource, if the path starts with one of these prefixes, the first
matching prefix will be removed from the path when the resource is placed in
the bundle root. This is useful for removing intermediate directories from the
resource paths.

For example, if `structured_resources` contains `["intermediate/res/foo.png"]`,
and `strip_structured_resources_prefixes` contains `["intermediate"]`,
`res/foo.png` will end up inside the bundle.2[]�
�
structured_resources�Files to include in the final application bundle. They are not processed or compiled in any way
besides the processing done by the rules that actually generate them. These files are placed in the
bundle root in the same structure passed to this argument, so `["res/foo.png"]` will end up in
`res/foo.png` inside the bundle.2[]�apple_core_data_model�This rule takes one or more Core Data model definitions from .xcdatamodeld
bundles and generates Swift or Objective-C source files that can be added
as srcs of a swift_library target."�
�
apple_core_data_model�This rule takes one or more Core Data model definitions from .xcdatamodeld
bundles and generates Swift or Objective-C source files that can be added
as srcs of a swift_library target.*
nameA unique name for this target. 

srcs B
swift_version+Target Swift version for generated classes.2""�
outs�A dictionary where the key is the name of a data model and the value is a
list of source files expected to be generated from that data model. For
example, if srcs contains one data model called "Taxonomy.xcdatamodeld" with
a single entity called "Animal," you might provide this value:
```
outs = {
    "Taxonomy": [
        "taxonomy+CoreDataModel.swift",
        "Animal+CoreDataProperties.swift",
    ],
},
```
If one or more files are provided for a data model, the rule will return these
files individually as outputs. Otherwise, the rule will return the directory
containing the sources for the data model.2{}"^
apple_core_data_modelE@rules_apple//apple/internal/resource_rules:apple_core_data_model.bzl,
*
nameA unique name for this target. 


srcs D
B
swift_version+Target Swift version for generated classes.2""�
�
outs�A dictionary where the key is the name of a data model and the value is a
list of source files expected to be generated from that data model. For
example, if srcs contains one data model called "Taxonomy.xcdatamodeld" with
a single entity called "Animal," you might provide this value:
```
outs = {
    "Taxonomy": [
        "taxonomy+CoreDataModel.swift",
        "Animal+CoreDataProperties.swift",
    ],
},
```
If one or more files are provided for a data model, the rule will return these
files individually as outputs. Otherwise, the rule will return the directory
containing the sources for the data model.2{}�resources_common.bucketize�Separates the given resources into resource bucket types and returns an AppleResourceInfo.

This method wraps _bucketize_data and returns its tuple as an immutable Starlark structure to
help propagate the structure of the Apple bundle resources to the bundler.
*�
�	
resources_common.bucketize�
allowed_buckets�List of buckets allowed for bucketing. Files that do not fall into these
buckets will instead be placed into the "unprocessed" bucket. Defaults to `None` which
means all buckets are allowed.None(�
owner�An optional string that has a unique identifier to the target that should own the
resources. If an owner should be passed, it's usually equal to `str(ctx.label)`.None(�
parent_dir_param�Either a string/None or a struct used to calculate the value of
parent_dir for each resource. If it is a struct, it will be considered a partial
context, and will be invoked with partial.call().None(0
	resourcesList of resources to bucketize. (N
swift_module6The Swift module name to associate to these resources.None(�Separates the given resources into resource bucket types and returns an AppleResourceInfo.

This method wraps _bucketize_data and returns its tuple as an immutable Starlark structure to
help propagate the structure of the Apple bundle resources to the bundler.
"L
JAn AppleResourceInfo provider with resources bucketized according to type.28

_bucketize*@rules_apple//apple/internal:resources.bzl�
�
allowed_buckets�List of buckets allowed for bucketing. Files that do not fall into these
buckets will instead be placed into the "unprocessed" bucket. Defaults to `None` which
means all buckets are allowed.None(�
�
owner�An optional string that has a unique identifier to the target that should own the
resources. If an owner should be passed, it's usually equal to `str(ctx.label)`.None(�
�
parent_dir_param�Either a string/None or a struct used to calculate the value of
parent_dir for each resource. If it is a struct, it will be considered a partial
context, and will be invoked with partial.call().None(2
0
	resourcesList of resources to bucketize. (P
N
swift_module6The Swift module name to associate to these resources.None(� resources_common.bucketize_data�	Separates the given resources into resource bucket types.

This method takes a list of resources and constructs a tuple object for each, placing it inside
the correct bucket.

The parent_dir is calculated from the parent_dir_param object. This object can either be None
(the default), a string object, or a function object. If a function is provided, it should
accept only 1 parameter, which will be the File object representing the resource to bucket. This
mechanism gives us a simpler way to manage multiple use cases. For example, when used to
bucketize structured resources, the parent_dir_param can be a function that returns the relative
path to the owning package; or in an objc_library it can be None, signaling that these resources
should be placed in the root level.

If no bucket was detected based on the short path for a specific resource, it will be placed
into the "unprocessed" bucket. Resources in this bucket will not be processed and will be copied
as is. Once all resources have been placed in buckets, each of the lists will be minimized.

Finally, it will return a AppleResourceInfo provider with the resources bucketed per type.
*�
�
resources_common.bucketize_data�
allowed_buckets�List of buckets allowed for bucketing. Files that do not fall into these
buckets will instead be placed into the "unprocessed" bucket. Defaults to `None` which
means all buckets are allowed.None(�
owner�An optional string that has a unique identifier to the target that should own the
resources. If an owner should be passed, it's usually equal to `str(ctx.label)`.None(�
parent_dir_param�Either a string/None or a struct used to calculate the value of
parent_dir for each resource. If it is a struct, it will be considered a partial
context, and will be invoked with partial.call().None(0
	resourcesList of resources to bucketize. (N
swift_module6The Swift module name to associate to these resources.None(�	Separates the given resources into resource bucket types.

This method takes a list of resources and constructs a tuple object for each, placing it inside
the correct bucket.

The parent_dir is calculated from the parent_dir_param object. This object can either be None
(the default), a string object, or a function object. If a function is provided, it should
accept only 1 parameter, which will be the File object representing the resource to bucket. This
mechanism gives us a simpler way to manage multiple use cases. For example, when used to
bucketize structured resources, the parent_dir_param can be a function that returns the relative
path to the owning package; or in an objc_library it can be None, signaling that these resources
should be placed in the root level.

If no bucket was detected based on the short path for a specific resource, it will be placed
into the "unprocessed" bucket. Resources in this bucket will not be processed and will be copied
as is. Once all resources have been placed in buckets, each of the lists will be minimized.

Finally, it will return a AppleResourceInfo provider with the resources bucketed per type.
"�
�A tuple with a list of owners, a list of "unowned" resources, and a dictionary with
bucketized resources organized by resource type.2=
_bucketize_data*@rules_apple//apple/internal:resources.bzl�
�
allowed_buckets�List of buckets allowed for bucketing. Files that do not fall into these
buckets will instead be placed into the "unprocessed" bucket. Defaults to `None` which
means all buckets are allowed.None(�
�
owner�An optional string that has a unique identifier to the target that should own the
resources. If an owner should be passed, it's usually equal to `str(ctx.label)`.None(�
�
parent_dir_param�Either a string/None or a struct used to calculate the value of
parent_dir for each resource. If it is a struct, it will be considered a partial
context, and will be invoked with partial.call().None(2
0
	resourcesList of resources to bucketize. (P
N
swift_module6The Swift module name to associate to these resources.None(� resources_common.bucketize_typed�Collects and bucketizes a specific type of resource and returns an AppleResourceInfo.

Adds the given resources directly into a tuple under the field named in bucket_type. This avoids
the sorting mechanism that `bucketize` does, while grouping resources together using
parent_dir_param when available.
*�
�	
 resources_common.bucketize_typed�
	resources�List of resources to place in bucket_type or Dictionary of resources keyed by
target to place in bucket_type. This dictionary is supported by the
`resources.collect()` API. (T
bucket_typeAThe AppleResourceInfo field under which to collect the resources. (�
owner�An optional string that has a unique identifier to the target that should own the
resources. If an owner should be passed, it's usually equal to `str(ctx.label)`.None(�
parent_dir_param�Either a string/None or a struct used to calculate the value of
parent_dir for each resource. If it is a struct, it will be considered a partial
context, and will be invoked with partial.call().None(�Collects and bucketizes a specific type of resource and returns an AppleResourceInfo.

Adds the given resources directly into a tuple under the field named in bucket_type. This avoids
the sorting mechanism that `bucketize` does, while grouping resources together using
parent_dir_param when available.
"C
AAn AppleResourceInfo provider with resources in the given bucket.2>
_bucketize_typed*@rules_apple//apple/internal:resources.bzl�
�
	resources�List of resources to place in bucket_type or Dictionary of resources keyed by
target to place in bucket_type. This dictionary is supported by the
`resources.collect()` API. (V
T
bucket_typeAThe AppleResourceInfo field under which to collect the resources. (�
�
owner�An optional string that has a unique identifier to the target that should own the
resources. If an owner should be passed, it's usually equal to `str(ctx.label)`.None(�
�
parent_dir_param�Either a string/None or a struct used to calculate the value of
parent_dir for each resource. If it is a struct, it will be considered a partial
context, and will be invoked with partial.call().None(�%resources_common.bucketize_typed_data�Collects and bucketizes a specific type of resource.

Adds the given resources directly into a tuple under the field named in bucket_type. This avoids
the sorting mechanism that `bucketize` does, while grouping resources together using
parent_dir_param when available.
*�
�	
%resources_common.bucketize_typed_dataT
bucket_typeAThe AppleResourceInfo field under which to collect the resources. (�
owner�An optional string that has a unique identifier to the target that should own the
resources. If an owner should be passed, it's usually equal to `str(ctx.label)`.None(�
parent_dir_param�Either a string/None or a struct used to calculate the value of
parent_dir for each resource. If it is a struct, it will be considered a partial
context, and will be invoked with partial.call().None(�
	resources�List of resources to place in bucket_type or Dictionary of resources keyed by
target to place in bucket_type. This dictionary is supported by the
`resources.collect()` API. (�Collects and bucketizes a specific type of resource.

Adds the given resources directly into a tuple under the field named in bucket_type. This avoids
the sorting mechanism that `bucketize` does, while grouping resources together using
parent_dir_param when available.
"�
�A tuple with a list of owners, a list of "unowned" resources, and a dictionary with
bucketized resources that are all placed within a single bucket defined by bucket_type.2C
_bucketize_typed_data*@rules_apple//apple/internal:resources.bzlV
T
bucket_typeAThe AppleResourceInfo field under which to collect the resources. (�
�
owner�An optional string that has a unique identifier to the target that should own the
resources. If an owner should be passed, it's usually equal to `str(ctx.label)`.None(�
�
parent_dir_param�Either a string/None or a struct used to calculate the value of
parent_dir for each resource. If it is a struct, it will be considered a partial
context, and will be invoked with partial.call().None(�
�
	resources�List of resources to place in bucket_type or Dictionary of resources keyed by
target to place in bucket_type. This dictionary is supported by the
`resources.collect()` API. (�
+resources_common.bundle_relative_parent_dir�Returns the bundle relative path to the resource rooted at the bundle.

Looks for the first instance of a folder with the suffix specified by `extension`, and then
returns the directory path to the file within the bundle. For example, for a resource with path
my/package/Contents.bundle/directory/foo.txt and `extension` equal to `"bundle"`, it would
return Contents.bundle/directory.
*�
�
+resources_common.bundle_relative_parent_dirM
resource=The resource for which to calculate the bundle relative path. (L
	extension;The bundle extension to use when finding the relative path. (�Returns the bundle relative path to the resource rooted at the bundle.

Looks for the first instance of a folder with the suffix specified by `extension`, and then
returns the directory path to the file within the bundle. For example, for a resource with path
my/package/Contents.bundle/directory/foo.txt and `extension` equal to `"bundle"`, it would
return Contents.bundle/directory.
";
9The bundle relative path, rooted at the outermost bundle.2I
_bundle_relative_parent_dir*@rules_apple//apple/internal:resources.bzlO
M
resource=The resource for which to calculate the bundle relative path. (N
L
	extension;The bundle extension to use when finding the relative path. (�resources_common.collect�Collects all resource attributes present in the given attributes.

Iterates over the given res_attrs attributes collecting files to be processed as resources.
These are all placed into a list, and then returned.
*�	
�
resources_common.collect�
attr�The attributes object on the current context. Can be either a `ctx.attr/ctx.rule.attr`
-like struct that has targets/lists as its values, or a `ctx.split_attr`-like struct
with the dictionary fan-out corresponding to split key. (K
	res_attrs8List of attributes to iterate over collecting resources.[](Y
split_attr_keys@If defined, a list of 1:2+ transition keys to merge values from.[](�Collects all resource attributes present in the given attributes.

Iterates over the given res_attrs attributes collecting files to be processed as resources.
These are all placed into a list, and then returned.
"[
YA dictionary keyed by target from the rule attr with the list of all collected resources.26
_collect*@rules_apple//apple/internal:resources.bzl�
�
attr�The attributes object on the current context. Can be either a `ctx.attr/ctx.rule.attr`
-like struct that has targets/lists as its values, or a `ctx.split_attr`-like struct
with the dictionary fan-out corresponding to split key. (M
K
	res_attrs8List of attributes to iterate over collecting resources.[]([
Y
split_attr_keys@If defined, a list of 1:2+ transition keys to merge values from.[](�resources_common.deduplicate*�
�
resources_common.deduplicate
resources_provider (
avoid_providers (
field_handler (
default_ownerNone(2:
_deduplicate*@rules_apple//apple/internal:resources.bzl

resources_provider (

avoid_providers (

field_handler (

default_ownerNone(� resources_common.merge_providers5Merges multiple AppleResourceInfo providers into one.*�
�
 resources_common.merge_providers�
default_owner�The default owner to be used for resources which have a None value in the
`owners` dictionary. May be None, in which case no owner is marked.None(w
	providersfThe list of providers to merge. This method will fail unless there is at least 1
provider in the list. (�
validate_all_resources_owned�Whether to validate that all resources are owned. This is
useful for top-level rules to ensure that the resources in AppleResourceInfo that
they are propagating are fully owned. If default_owner is set, this attribute does
nothing, as by definition the resources will all have a default owner.False(5Merges multiple AppleResourceInfo providers into one."T
RA AppleResourceInfo provider with the results of the merge of the given providers.2>
_merge_providers*@rules_apple//apple/internal:resources.bzl�
�
default_owner�The default owner to be used for resources which have a None value in the
`owners` dictionary. May be None, in which case no owner is marked.None(y
w
	providersfThe list of providers to merge. This method will fail unless there is at least 1
provider in the list. (�
�
validate_all_resources_owned�Whether to validate that all resources are owned. This is
useful for top-level rules to ensure that the resources in AppleResourceInfo that
they are propagating are fully owned. If default_owner is set, this attribute does
nothing, as by definition the resources will all have a default owner.False(�resources_common.minimize�Minimizes the given list of tuples into the smallest subset possible.

Takes the list of tuples that represent one resource bucket, and minimizes it so that 2 tuples
with resources that should be placed under the same location are merged into 1 tuple.

For tuples to be merged, they need to have the same parent_dir and swift_module.
*�
�
resources_common.minimize-
bucketList of tuples to be minimized. (�Minimizes the given list of tuples into the smallest subset possible.

Takes the list of tuples that represent one resource bucket, and minimizes it so that 2 tuples
with resources that should be placed under the same location are merged into 1 tuple.

For tuples to be merged, they need to have the same parent_dir and swift_module.
"
A list of minimized tuples.27
	_minimize*@rules_apple//apple/internal:resources.bzl/
-
bucketList of tuples to be minimized. (�resources_common.nest_in_bundle�Nests resources in a AppleResourceInfo provider under a new parent bundle directory.

This method is mostly used by rules that create resource bundles in order to nest other resource
bundle targets within themselves. For instance, apple_resource_bundle supports nesting other
bundles through the resources attribute. In these use cases, the dependency bundles are added as
nested bundles into the dependent bundle.

This method prepends the parent_dir field in the buckets with the given
nesting_bundle_dir argument.
*�
�
resources_common.nest_in_bundleP
provider_to_nest8A AppleResourceInfo provider with the resources to nest. (W
nesting_bundle_dir=The new bundle directory under which to bundle the resources. (�Nests resources in a AppleResourceInfo provider under a new parent bundle directory.

This method is mostly used by rules that create resource bundles in order to nest other resource
bundle targets within themselves. For instance, apple_resource_bundle supports nesting other
bundles through the resources attribute. In these use cases, the dependency bundles are added as
nested bundles into the dependent bundle.

This method prepends the parent_dir field in the buckets with the given
nesting_bundle_dir argument.
"V
TA new AppleResourceInfo provider with the resources nested under nesting_bundle_dir.2=
_nest_in_bundle*@rules_apple//apple/internal:resources.bzlR
P
provider_to_nest8A AppleResourceInfo provider with the resources to nest. (Y
W
nesting_bundle_dir=The new bundle directory under which to bundle the resources. (�*resources_common.populated_resource_fieldsTReturns a list of field names of the provider's resource buckets that are non empty.*�
�
*resources_common.populated_resource_fields
provider (TReturns a list of field names of the provider's resource buckets that are non empty.2H
_populated_resource_fields*@rules_apple//apple/internal:resources.bzl

provider (�(resources_common.process_bucketized_data�Registers actions for select resource types, given bucketized groupings of data.

This method performs the same actions as bucketize_data, and further
iterates through a subset of resource types to register actions to process
them as necessary before returning an AppleResourceInfo. This
AppleResourceInfo has an additional field, called "processed", featuring the
expected outputs for each of the actions declared in this method.
*�
�
(resources_common.process_bucketized_data7
actions(The actions provider from `ctx.actions`. (8
mac_exec_group"The execution group for Mac tools. (R
apple_mac_toolchain_info2`struct` of tools from the shared Apple
toolchain. (]
bucketized_ownersBA list of tuples indicating the owner of each
bucketized resource.[](Q
bucketsBA dictionary with bucketized resources organized by resource
type. (<
	bundle_id+The bundle ID to configure for this target. (p
output_discriminatorPA string to differentiate between different target
intermediate files or `None`.None([
platform_prerequisites=Struct containing information on the platform
being targeted. (�
processing_owner�An optional string that has a unique identifier to the
target that should own the resources. If an owner should be passed,
it's usually equal to `str(ctx.label)`.None(Y
product_typeEThe product type identifier used to describe the current
bundle type. (n
resource_types_to_process"A list of bucket types to process.+["infoplists", "plists", "pngs", "strings"](9

rule_label'The label of the target being analyzed. (9
unowned_resourcesA list of "unowned" resources.[](�Registers actions for select resource types, given bucketized groupings of data.

This method performs the same actions as bucketize_data, and further
iterates through a subset of resource types to register actions to process
them as necessary before returning an AppleResourceInfo. This
AppleResourceInfo has an additional field, called "processed", featuring the
expected outputs for each of the actions declared in this method.
"L
JAn AppleResourceInfo provider with resources bucketized according to
type.2F
_process_bucketized_data*@rules_apple//apple/internal:resources.bzl9
7
actions(The actions provider from `ctx.actions`. (:
8
mac_exec_group"The execution group for Mac tools. (T
R
apple_mac_toolchain_info2`struct` of tools from the shared Apple
toolchain. (_
]
bucketized_ownersBA list of tuples indicating the owner of each
bucketized resource.[](S
Q
bucketsBA dictionary with bucketized resources organized by resource
type. (>
<
	bundle_id+The bundle ID to configure for this target. (r
p
output_discriminatorPA string to differentiate between different target
intermediate files or `None`.None(]
[
platform_prerequisites=Struct containing information on the platform
being targeted. (�
�
processing_owner�An optional string that has a unique identifier to the
target that should own the resources. If an owner should be passed,
it's usually equal to `str(ctx.label)`.None([
Y
product_typeEThe product type identifier used to describe the current
bundle type. (p
n
resource_types_to_process"A list of bucket types to process.+["infoplists", "plists", "pngs", "strings"](;
9

rule_label'The label of the target being analyzed. (;
9
unowned_resourcesA list of "unowned" resources.[](�.resources_common.runfiles_resources_parent_dir)Returns the parent directory of the file.*�
�
.resources_common.runfiles_resources_parent_dirN
resource>The resource for which to calculate the package relative path. ()Returns the parent directory of the file."D
BThe package relative path to the parent directory of the resource.2L
_runfiles_resources_parent_dir*@rules_apple//apple/internal:resources.bzlP
N
resource>The resource for which to calculate the package relative path. (�0resources_common.structured_resources_parent_dirIReturns the package relative path for the parent directory of a resource.*�
�
0resources_common.structured_resources_parent_dirO

parent_dir9Parent directory to prepend to the package relative path.None(N
resource>The resource for which to calculate the package relative path. (
strip_prefixesgA list of prefixes to strip from the package relative
path. The first prefix that matches will be used.[](IReturns the package relative path for the parent directory of a resource."D
BThe package relative path to the parent directory of the resource.2N
 _structured_resources_parent_dir*@rules_apple//apple/internal:resources.bzlQ
O

parent_dir9Parent directory to prepend to the package relative path.None(P
N
resource>The resource for which to calculate the package relative path. (�

strip_prefixesgA list of prefixes to strip from the package relative
path. The first prefix that matches will be used.[](�apple_core_ml_libraryNMacro to orchestrate an objc_library with generated sources for mlmodel files.*�
�
apple_core_ml_library

name (
mlmodel (

kwargs(NMacro to orchestrate an objc_library with generated sources for mlmodel files.2:
apple_core_ml_library!@rules_apple//apple:resources.bzl


name (

mlmodel (


kwargs(�swift_apple_core_ml_libraryNMacro to orchestrate a swift_library with generated sources for mlmodel files.*�
�
swift_apple_core_ml_library

name (
mlmodel (

kwargs(NMacro to orchestrate a swift_library with generated sources for mlmodel files.2@
swift_apple_core_ml_library!@rules_apple//apple:resources.bzl


name (

mlmodel (


kwargs(�objc_intent_libraryVMacro to orchestrate an objc_library with generated sources for intentdefiniton files.*�
�
objc_intent_library

name (	
src (
class_prefixNone(
testonlyFalse(

kwargs(VMacro to orchestrate an objc_library with generated sources for intentdefiniton files.28
objc_intent_library!@rules_apple//apple:resources.bzl


name (
	
src (

class_prefixNone(

testonlyFalse(


kwargs(�swift_intent_library�This macro supports the integration of Intents `.intentdefinition` files into Apple rules.

It takes a single `.intentdefinition` file and creates a target that can be added as a dependency from `objc_library` or
`swift_library` targets.

It accepts the regular `swift_library` attributes too.
*�

�
swift_intent_library)
nameA unique name for the target. (?
src4Reference to the `.intentdefiniton` file to process. (F
class_prefix.Class prefix to use for the generated classes.None(l
class_visibilityPVisibility attribute for the generated classes (`public`, `private`, `project`).None(K
swift_version2Version of Swift to use for the generated classes.None(Z
testonlyESet to True to enforce that this library is only used from test code.False(

kwargs(�This macro supports the integration of Intents `.intentdefinition` files into Apple rules.

It takes a single `.intentdefinition` file and creates a target that can be added as a dependency from `objc_library` or
`swift_library` targets.

It accepts the regular `swift_library` attributes too.
29
swift_intent_library!@rules_apple//apple:resources.bzl+
)
nameA unique name for the target. (A
?
src4Reference to the `.intentdefiniton` file to process. (H
F
class_prefix.Class prefix to use for the generated classes.None(n
l
class_visibilityPVisibility attribute for the generated classes (`public`, `private`, `project`).None(M
K
swift_version2Version of Swift to use for the generated classes.None(\
Z
testonlyESet to True to enforce that this library is only used from test code.False(


kwargs(8# Rules related to Apple resources and resource bundles.ݜ

rules_appleappletvos.bzl��tvos_application&Builds and bundles a tvOS Application."�
�H
tvos_application&Builds and bundles a tvOS Application.*
nameA unique name for this target. �
	app_icons�Files that comprise the app icons for the application. Each file must have a containing directory
named `*..xcassets/*..appiconset` and there may be only one such
`..appiconset` directory in the list. In Xcode 26+ for iOS/macOS/watchOS, an `*.icon`
bundle can be provided along with the `*..xcassets` bundle to support 26 and
pre-26 Apple OS rendering.2[]�
primary_app_icon�An optional String to identify the name of the primary app icon when alternate app icons have been
provided for the app. This should match both the `*.icon` bundle in iOS/macOS/watchOS 26+ and the
`*..xcassets/.appiconset` bundle's AppIcon resource in previous versions of
iOS/macOS/watchOS.2""�
app_intents:List of dependencies implementing the AppIntents protocol.*;
	SwiftInfo.
	SwiftInfo!@rules_swift//swift:providers.bzl2[]�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Noneg
familiesQA list of device families supported by this rule. At least one must be specified.2["tv"]�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. If not provided,
a default Info.plist will be used. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported.2H["@rules_apple//apple/internal/templates:default_application_infoplist"]�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
locales_to_include�A list of locales to include in the bundle. Only *.lproj directories that are matched will be copied as a part of the build.
This value takes precedence (and is preferred) over locales defined using `--define "apple.locales_to_include=..."`.2[]�
launch_images�Files that comprise the launch images for the application. Each file must have a containing
directory named `*.xcassets/*.launchimage` and there may be only one such `.launchimage` directory
in the list.2[]�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""
platform_type2"tvos"�
settings_bundle�A resource bundle (e.g. `apple_bundle_import`) target that contains the files that make up the
application's settings bundle. These files will be copied into the root of the final application
bundle in a directory named `Settings.bundle`.*`
AppleResourceBundleInfoE
AppleResourceBundleInfo*@rules_apple//apple/internal:providers.bzl*?
ObjcInfo3
ObjcInfo'@@_builtins//:common/objc/objc_info.bzl2None�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID rule found within
`signed_capabilities`.2""�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
a base bundle ID rule found within `signed_capabilities`, then this string will be appended to the
end of the bundle ID following a "." separator.2"_"�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
entitlements�The entitlements file required for device builds of this target. If absent, the default entitlements
from the provisioning profile will be used.

The following variables are substituted in the entitlements file: `$(CFBundleIdentifier)` with the
bundle ID of the application and `$(AppIdentifierPrefix)` with the value of the
`ApplicationIdentifierPrefix` key from the target's provisioning profile.2None�
entitlements_validation�An `entitlements_validation_mode` to control the validation of the requested entitlements against
the provisioning profile to ensure they are supported.2"loose"J"error"J"warn"J"loose"J"skip"�
shared_capabilities�A list of shared `apple_capability_set` rules to represent the capabilities that a code sign aware
Apple bundle rule output should have. These can define the formal prefix for the target's
`bundle_id` and can further be merged with information provided by `entitlements`, if defined by any
capabilities found within the `apple_capability_set`.*d
AppleSharedCapabilityInfoG
AppleSharedCapabilityInfo*@rules_apple//apple/internal:providers.bzl2[]�

frameworks�A list of framework targets (see
[`tvos_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-tvos.md#tvos_framework))
that this target depends on.*�
AppleBundleInfo
TvosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlE
TvosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�

extensionsEA list of tvOS extensions to include in the final application bundle.*�
AppleBundleInfo
TvosExtensionBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlE
TvosExtensionBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�
launch_storyboard�The `.storyboard` file that should be used as the launch screen for the application. The provided
file will be compiled into the appropriate format (`.storyboardc`) and placed in the root of the
final bundle. The generated file will also be registered in the bundle's Info.plist under the key
`UILaunchStoryboardName`.2None"?
tvos_application+@rules_apple//apple/internal:tvos_rules.bzl8,
*
nameA unique name for this target. �
�
	app_icons�Files that comprise the app icons for the application. Each file must have a containing directory
named `*..xcassets/*..appiconset` and there may be only one such
`..appiconset` directory in the list. In Xcode 26+ for iOS/macOS/watchOS, an `*.icon`
bundle can be provided along with the `*..xcassets` bundle to support 26 and
pre-26 Apple OS rendering.2[]�
�
primary_app_icon�An optional String to identify the name of the primary app icon when alternate app icons have been
provided for the app. This should match both the `*.icon` bundle in iOS/macOS/watchOS 26+ and the
`*..xcassets/.appiconset` bundle's AppIcon resource in previous versions of
iOS/macOS/watchOS.2""�
�
app_intents:List of dependencies implementing the AppIntents protocol.*;
	SwiftInfo.
	SwiftInfo!@rules_swift//swift:providers.bzl2[]�
�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]g
e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]c
a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]U
S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonei
g
familiesQA list of device families supported by this rule. At least one must be specified.2["tv"]�
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. If not provided,
a default Info.plist will be used. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported.2H["@rules_apple//apple/internal/templates:default_application_infoplist"]�
�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
�
locales_to_include�A list of locales to include in the bundle. Only *.lproj directories that are matched will be copied as a part of the build.
This value takes precedence (and is preferred) over locales defined using `--define "apple.locales_to_include=..."`.2[]�
�
launch_images�Files that comprise the launch images for the application. Each file must have a containing
directory named `*.xcassets/*.launchimage` and there may be only one such `.launchimage` directory
in the list.2[]�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""

platform_type2"tvos"�
�
settings_bundle�A resource bundle (e.g. `apple_bundle_import`) target that contains the files that make up the
application's settings bundle. These files will be copied into the root of the final application
bundle in a directory named `Settings.bundle`.*`
AppleResourceBundleInfoE
AppleResourceBundleInfo*@rules_apple//apple/internal:providers.bzl*?
ObjcInfo3
ObjcInfo'@@_builtins//:common/objc/objc_info.bzl2None�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID rule found within
`signed_capabilities`.2""�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
a base bundle ID rule found within `signed_capabilities`, then this string will be appended to the
end of the bundle ID following a "." separator.2"_"�
�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
entitlements�The entitlements file required for device builds of this target. If absent, the default entitlements
from the provisioning profile will be used.

The following variables are substituted in the entitlements file: `$(CFBundleIdentifier)` with the
bundle ID of the application and `$(AppIdentifierPrefix)` with the value of the
`ApplicationIdentifierPrefix` key from the target's provisioning profile.2None�
�
entitlements_validation�An `entitlements_validation_mode` to control the validation of the requested entitlements against
the provisioning profile to ensure they are supported.2"loose"J"error"J"warn"J"loose"J"skip"�
�
shared_capabilities�A list of shared `apple_capability_set` rules to represent the capabilities that a code sign aware
Apple bundle rule output should have. These can define the formal prefix for the target's
`bundle_id` and can further be merged with information provided by `entitlements`, if defined by any
capabilities found within the `apple_capability_set`.*d
AppleSharedCapabilityInfoG
AppleSharedCapabilityInfo*@rules_apple//apple/internal:providers.bzl2[]�
�

frameworks�A list of framework targets (see
[`tvos_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-tvos.md#tvos_framework))
that this target depends on.*�
AppleBundleInfo
TvosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlE
TvosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�
�

extensionsEA list of tvOS extensions to include in the final application bundle.*�
AppleBundleInfo
TvosExtensionBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlE
TvosExtensionBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�
�
launch_storyboard�The `.storyboard` file that should be used as the launch screen for the application. The provided
file will be compiled into the appropriate format (`.storyboardc`) and placed in the root of the
final bundle. The generated file will also be registered in the bundle's Info.plist under the key
`UILaunchStoryboardName`.2None�btvos_dynamic_frameworkHBuilds and bundles a tvOS dynamic framework that is consumable by Xcode."�a
�1
tvos_dynamic_frameworkHBuilds and bundles a tvOS dynamic framework that is consumable by Xcode.*
nameA unique name for this target. �
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Noneg
familiesQA list of device families supported by this rule. At least one must be specified.2["tv"]�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""
platform_type2"tvos"�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2""�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2"bundle_name"�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
bundle_only�Avoid linking the dynamic framework, but still include it in the app. This is useful when you want
to manually dlopen the framework at runtime.2False�
extension_safe�If true, compiles and links this framework with `-application-extension`, restricting the binary to
use only extension-safe APIs.2False�

frameworks�A list of framework targets (see
[`tvos_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-tvos.md#tvos_framework))
that this target depends on.*�
AppleBundleInfo
TvosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlE
TvosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]
hdrs2[]"E
tvos_dynamic_framework+@rules_apple//apple/internal:tvos_rules.bzl,
*
nameA unique name for this target. �
�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]g
e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]c
a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]U
S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonei
g
familiesQA list of device families supported by this rule. At least one must be specified.2["tv"]�
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""

platform_type2"tvos"�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2""�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2"bundle_name"�
�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
�
bundle_only�Avoid linking the dynamic framework, but still include it in the app. This is useful when you want
to manually dlopen the framework at runtime.2False�
�
extension_safe�If true, compiles and links this framework with `-application-extension`, restricting the binary to
use only extension-safe APIs.2False�
�

frameworks�A list of framework targets (see
[`tvos_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-tvos.md#tvos_framework))
that this target depends on.*�
AppleBundleInfo
TvosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlE
TvosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]

hdrs2[]�ttvos_extension$Builds and bundles a tvOS Extension."�t
�:
tvos_extension$Builds and bundles a tvOS Extension.*
nameA unique name for this target. �
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Noneg
familiesQA list of device families supported by this rule. At least one must be specified.2["tv"]k
extensionkit_extensionHIndicates if this target should be treated as an ExtensionKit extension.2False�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
locales_to_include�A list of locales to include in the bundle. Only *.lproj directories that are matched will be copied as a part of the build.
This value takes precedence (and is preferred) over locales defined using `--define "apple.locales_to_include=..."`.2[]�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""
platform_type2"tvos"�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID rule found within
`signed_capabilities`.2""�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
a base bundle ID rule found within `signed_capabilities`, then this string will be appended to the
end of the bundle ID following a "." separator.2"bundle_name"�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
entitlements�The entitlements file required for device builds of this target. If absent, the default entitlements
from the provisioning profile will be used.

The following variables are substituted in the entitlements file: `$(CFBundleIdentifier)` with the
bundle ID of the application and `$(AppIdentifierPrefix)` with the value of the
`ApplicationIdentifierPrefix` key from the target's provisioning profile.2None�
entitlements_validation�An `entitlements_validation_mode` to control the validation of the requested entitlements against
the provisioning profile to ensure they are supported.2"loose"J"error"J"warn"J"loose"J"skip"�
shared_capabilities�A list of shared `apple_capability_set` rules to represent the capabilities that a code sign aware
Apple bundle rule output should have. These can define the formal prefix for the target's
`bundle_id` and can further be merged with information provided by `entitlements`, if defined by any
capabilities found within the `apple_capability_set`.*d
AppleSharedCapabilityInfoG
AppleSharedCapabilityInfo*@rules_apple//apple/internal:providers.bzl2[]�

frameworks�A list of framework targets (see
[`tvos_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-tvos.md#tvos_framework))
that this target depends on.*�
AppleBundleInfo
TvosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlE
TvosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�
legacy_entry_point�If `True`, the extension uses the legacy tvOS extension entry point (`_TVExtensionMain`) used
by extensions prior to tvOS 13. If `False` (the default), the extension uses the modern
NSExtension entry point (`_NSExtensionMain`).2False"=
tvos_extension+@rules_apple//apple/internal:tvos_rules.bzl,
*
nameA unique name for this target. �
�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]g
e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]c
a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]U
S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonei
g
familiesQA list of device families supported by this rule. At least one must be specified.2["tv"]m
k
extensionkit_extensionHIndicates if this target should be treated as an ExtensionKit extension.2False�
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
�
locales_to_include�A list of locales to include in the bundle. Only *.lproj directories that are matched will be copied as a part of the build.
This value takes precedence (and is preferred) over locales defined using `--define "apple.locales_to_include=..."`.2[]�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""

platform_type2"tvos"�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID rule found within
`signed_capabilities`.2""�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
a base bundle ID rule found within `signed_capabilities`, then this string will be appended to the
end of the bundle ID following a "." separator.2"bundle_name"�
�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
entitlements�The entitlements file required for device builds of this target. If absent, the default entitlements
from the provisioning profile will be used.

The following variables are substituted in the entitlements file: `$(CFBundleIdentifier)` with the
bundle ID of the application and `$(AppIdentifierPrefix)` with the value of the
`ApplicationIdentifierPrefix` key from the target's provisioning profile.2None�
�
entitlements_validation�An `entitlements_validation_mode` to control the validation of the requested entitlements against
the provisioning profile to ensure they are supported.2"loose"J"error"J"warn"J"loose"J"skip"�
�
shared_capabilities�A list of shared `apple_capability_set` rules to represent the capabilities that a code sign aware
Apple bundle rule output should have. These can define the formal prefix for the target's
`bundle_id` and can further be merged with information provided by `entitlements`, if defined by any
capabilities found within the `apple_capability_set`.*d
AppleSharedCapabilityInfoG
AppleSharedCapabilityInfo*@rules_apple//apple/internal:providers.bzl2[]�
�

frameworks�A list of framework targets (see
[`tvos_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-tvos.md#tvos_framework))
that this target depends on.*�
AppleBundleInfo
TvosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlE
TvosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�
�
legacy_entry_point�If `True`, the extension uses the legacy tvOS extension entry point (`_TVExtensionMain`) used
by extensions prior to tvOS 13. If `False` (the default), the extension uses the modern
NSExtension entry point (`_NSExtensionMain`).2False�ctvos_framework�Builds and bundles a tvOS Dynamic Framework.

To use this framework for your app and extensions, list it in the frameworks attributes of those tvos_application and/or tvos_extension rules."�b
�1
tvos_framework�Builds and bundles a tvOS Dynamic Framework.

To use this framework for your app and extensions, list it in the frameworks attributes of those tvos_application and/or tvos_extension rules.*
nameA unique name for this target. �
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Noneg
familiesQA list of device families supported by this rule. At least one must be specified.2["tv"]�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""
platform_type2"tvos"�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2""�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2"bundle_name"�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
bundle_only�Avoid linking the dynamic framework, but still include it in the app. This is useful when you want
to manually dlopen the framework at runtime.2False�
extension_safe�If true, compiles and links this framework with `-application-extension`, restricting the binary to
use only extension-safe APIs.2False�

frameworks�A list of framework targets (see
[`tvos_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-tvos.md#tvos_framework))
that this target depends on.*�
AppleBundleInfo
TvosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlE
TvosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]
hdrs2[]"=
tvos_framework+@rules_apple//apple/internal:tvos_rules.bzl,
*
nameA unique name for this target. �
�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]g
e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]c
a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]U
S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonei
g
familiesQA list of device families supported by this rule. At least one must be specified.2["tv"]�
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""

platform_type2"tvos"�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2""�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2"bundle_name"�
�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
�
bundle_only�Avoid linking the dynamic framework, but still include it in the app. This is useful when you want
to manually dlopen the framework at runtime.2False�
�
extension_safe�If true, compiles and links this framework with `-application-extension`, restricting the binary to
use only extension-safe APIs.2False�
�

frameworks�A list of framework targets (see
[`tvos_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-tvos.md#tvos_framework))
that this target depends on.*�
AppleBundleInfo
TvosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlE
TvosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]

hdrs2[]�utvos_static_framework�Builds and bundles an tvOS static framework for third-party distribution.

A static framework is bundled like a dynamic framework except that the embedded
binary is a static library rather than a dynamic library. It is intended to
create distributable static SDKs or artifacts that can be easily imported into
other Xcode projects; it is specifically **not** intended to be used as a
dependency of other Bazel targets. For that use case, use the corresponding
`objc_library` targets directly.

Unlike other tvOS bundles, the fat binary in an `tvos_static_framework` may
simultaneously contain simulator and device architectures (that is, you can
build a single framework artifact that works for all architectures by specifying
`--tvos_cpus=x86_64,arm64` when you build).

`tvos_static_framework` supports Swift, but there are some constraints:

* `tvos_static_framework` with Swift only works with Xcode 11 and above, since
  the required Swift functionality for module compatibility is available in
  Swift 5.1.
* `tvos_static_framework` only supports a single direct `swift_library` target
  that does not depend transitively on any other `swift_library` targets. The
  Swift compiler expects a framework to contain a single Swift module, and each
  `swift_library` target is its own module by definition.
* `tvos_static_framework` does not support mixed Objective-C and Swift public
  interfaces. This means that the `umbrella_header` and `hdrs` attributes are
  unavailable when using `swift_library` dependencies. You are allowed to depend
  on `objc_library` from the main `swift_library` dependency, but note that only
  the `swift_library`'s public interface will be available to users of the
  static framework.

When using Swift, the `tvos_static_framework` bundles `swiftinterface` and
`swiftdocs` file for each of the required architectures. It also bundles an
umbrella header which is the header generated by the single `swift_library`
target. Finally, it also bundles a `module.modulemap` file pointing to the
umbrella header for Objetive-C module compatibility. This umbrella header and
modulemap can be skipped by disabling the `swift.no_generated_header` feature (
i.e. `--features=-swift.no_generated_header`)."�c
�:
tvos_static_framework�Builds and bundles an tvOS static framework for third-party distribution.

A static framework is bundled like a dynamic framework except that the embedded
binary is a static library rather than a dynamic library. It is intended to
create distributable static SDKs or artifacts that can be easily imported into
other Xcode projects; it is specifically **not** intended to be used as a
dependency of other Bazel targets. For that use case, use the corresponding
`objc_library` targets directly.

Unlike other tvOS bundles, the fat binary in an `tvos_static_framework` may
simultaneously contain simulator and device architectures (that is, you can
build a single framework artifact that works for all architectures by specifying
`--tvos_cpus=x86_64,arm64` when you build).

`tvos_static_framework` supports Swift, but there are some constraints:

* `tvos_static_framework` with Swift only works with Xcode 11 and above, since
  the required Swift functionality for module compatibility is available in
  Swift 5.1.
* `tvos_static_framework` only supports a single direct `swift_library` target
  that does not depend transitively on any other `swift_library` targets. The
  Swift compiler expects a framework to contain a single Swift module, and each
  `swift_library` target is its own module by definition.
* `tvos_static_framework` does not support mixed Objective-C and Swift public
  interfaces. This means that the `umbrella_header` and `hdrs` attributes are
  unavailable when using `swift_library` dependencies. You are allowed to depend
  on `objc_library` from the main `swift_library` dependency, but note that only
  the `swift_library`'s public interface will be available to users of the
  static framework.

When using Swift, the `tvos_static_framework` bundles `swiftinterface` and
`swiftdocs` file for each of the required architectures. It also bundles an
umbrella header which is the header generated by the single `swift_library`
target. Finally, it also bundles a `module.modulemap` file pointing to the
umbrella header for Objetive-C module compatibility. This umbrella header and
modulemap can be skipped by disabling the `swift.no_generated_header` feature (
i.e. `--features=-swift.no_generated_header`).*
nameA unique name for this target. �
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Noneg
familiesQA list of device families supported by this rule. At least one must be specified.2["tv"]�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""
platform_type2"tvos"�

avoid_deps�A list of library targets on which this framework depends in order to compile, but the transitive
closure of which will not be linked into the framework's binary.2[]�
exclude_resources�Indicates whether resources should be excluded from the bundle. This can be used to avoid
unnecessarily bundling resources if the static framework is being distributed in a different
fashion, such as a Cocoapod.2False�
hdrs�A list of `.h` files that will be publicly exposed by this framework. These headers should have
framework-relative imports, and if non-empty, an umbrella header named `%{bundle_name}.h` will also
be generated that imports all of the headers listed here.2[]�
umbrella_header�An optional single .h file to use as the umbrella header for this framework. Usually, this header
will have the same name as this target, so that clients can load the header using the #import
<MyFramework/MyFramework.h> format. If this attribute is not specified (the common use case), an
umbrella header will be generated under the same name as this target.2None"D
tvos_static_framework+@rules_apple//apple/internal:tvos_rules.bzl,
*
nameA unique name for this target. �
�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]g
e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]c
a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]U
S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonei
g
familiesQA list of device families supported by this rule. At least one must be specified.2["tv"]�
�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""

platform_type2"tvos"�
�

avoid_deps�A list of library targets on which this framework depends in order to compile, but the transitive
closure of which will not be linked into the framework's binary.2[]�
�
exclude_resources�Indicates whether resources should be excluded from the bundle. This can be used to avoid
unnecessarily bundling resources if the static framework is being distributed in a different
fashion, such as a Cocoapod.2False�
�
hdrs�A list of `.h` files that will be publicly exposed by this framework. These headers should have
framework-relative imports, and if non-empty, an umbrella header named `%{bundle_name}.h` will also
be generated that imports all of the headers listed here.2[]�
�
umbrella_header�An optional single .h file to use as the umbrella header for this framework. Usually, this header
will have the same name as this target, so that clients can load the header using the #import
<MyFramework/MyFramework.h> format. If this attribute is not specified (the common use case), an
umbrella header will be generated under the same name as this target.2None�
tvos_build_test�Test rule to check that the given library targets (Swift, Objective-C, C++)
build for tvOS.

Typical usage:

```starlark
tvos_build_test(
    name = "my_build_test",
    minimum_os_version = "12.0",
    targets = [
        "//some/package:my_library",
    ],
)
```"�
�
tvos_build_test�Test rule to check that the given library targets (Swift, Objective-C, C++)
build for tvOS.

Typical usage:

```starlark
tvos_build_test(
    name = "my_build_test",
    minimum_os_version = "12.0",
    targets = [
        "//some/package:my_library",
    ],
)
```*
nameA unique name for this target. �
minimum_os_version�A required string indicating the minimum OS version that will be used as the
deployment target when building the targets, represented as a dotted version
number (for example, `"9.0"`). ;
targets*The targets to check for successful build.2[]
platform_type2"tvos""/
tvos_build_test@rules_apple//apple:tvos.bzl08,
*
nameA unique name for this target. �
�
minimum_os_version�A required string indicating the minimum OS version that will be used as the
deployment target when building the targets, represented as a dotted version
number (for example, `"9.0"`). =
;
targets*The targets to check for successful build.2[]

platform_type2"tvos"�ltvos_unit_test�Builds and bundles a tvOS Unit `.xctest` test bundle. Runs the tests using the
provided test runner when invoked with `bazel test`.

Note: tvOS unit tests are not currently supported in the default test runner.

`tvos_unit_test` targets can work in two modes: as app or library tests. If the
`test_host` attribute is set to an `tvos_application` target, the tests will run
within that application's context. If no `test_host` is provided, the tests will
run outside the context of a tvOS application. Because of this, certain
functionalities might not be present (e.g. UI layout, NSUserDefaults). You can
find more information about app and library testing for Apple platforms
[here](https://developer.apple.com/library/content/documentation/DeveloperTools/Conceptual/testing_with_xcode/chapters/03-testing_basics.html).

The following is a list of the `tvos_unit_test` specific attributes; for a list
of the attributes inherited by all test rules, please check the
[Bazel documentation](https://bazel.build/reference/be/common-definitions#common-attributes-tests).Z�d
�6
tvos_unit_test�Builds and bundles a tvOS Unit `.xctest` test bundle. Runs the tests using the
provided test runner when invoked with `bazel test`.

Note: tvOS unit tests are not currently supported in the default test runner.

`tvos_unit_test` targets can work in two modes: as app or library tests. If the
`test_host` attribute is set to an `tvos_application` target, the tests will run
within that application's context. If no `test_host` is provided, the tests will
run outside the context of a tvOS application. Because of this, certain
functionalities might not be present (e.g. UI layout, NSUserDefaults). You can
find more information about app and library testing for Apple platforms
[here](https://developer.apple.com/library/content/documentation/DeveloperTools/Conceptual/testing_with_xcode/chapters/03-testing_basics.html).

The following is a list of the `tvos_unit_test` specific attributes; for a list
of the attributes inherited by all test rules, please check the
[Bazel documentation](https://bazel.build/reference/be/common-definitions#common-attributes-tests).�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2""�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2"bundle_name"�
bundle_name�The desired name of the test bundle (without the extension). If this attribute is not set, then the
name of the target will be used instead.2""8�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]g
familiesQA list of device families supported by this rule. At least one must be specified.2["tv"]�

frameworks8A list of framework targets that this target depends on.*�
AppleBundleInfo
TvosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlE
TvosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. If not provided,
a default Info.plist will be used. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported.26["@rules_apple//apple/testing:DefaultTestBundlePlist"]a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.20J-1J0J1�
runner2A single runner target to use for the test target.2@"@rules_apple//apple/testing/default_runner:tvos_default_runner"
expect_failure2None@ 
transitive_configs2None8@
deprecation2None8@
tags2None8@
testonly2None8@
features2None@
compatible_with2None8@
restricted_to2None8@
package_metadata2None8@
aspect_hints2None@P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@
exec_properties
2None@"
exec_compatible_with2None8@(
exec_group_compatible_with2None8@Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@
size2None8@
timeout2None8@
flaky2None8@
shard_count2None@
local2None8@
args2None@q
collect_code_coveragePWhether to collect code coverage for this test if `--collect_code_coverage=yes`.2NoneL
data<Files to be made available to the test during its execution.2None�
env�Dictionary of environment variables that should be set during the test execution. The values of
the dictionary are subject to "Make" variable expansion.
2None^
env_inheritGList of environment variables to inherit from the external environment.2Noner
test_filter[Test filter string that will be passed into the test runner to select which tests will run.2None�
test_coverage_manifesteA file that will be used in lcov export calls to limit the scope of files instrumented with coverage.2None�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None
platform_type2Nonee
	test_host*P
AppleBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl2None�
test_host_is_bundle_loaderpWhether the 'test_host' should be used as the -bundle_loader to allow testing
the symbols from the test host app2None".
tvos_unit_test@rules_apple//apple:tvos.bzl�
�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �
�

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@U
S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2""�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2"bundle_name"�
�
bundle_name�The desired name of the test bundle (without the extension). If this attribute is not set, then the
name of the target will be used instead.2""8�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]i
g
familiesQA list of device families supported by this rule. At least one must be specified.2["tv"]�
�

frameworks8A list of framework targets that this target depends on.*�
AppleBundleInfo
TvosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlE
TvosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. If not provided,
a default Info.plist will be used. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported.26["@rules_apple//apple/testing:DefaultTestBundlePlist"]c
a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]�
�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.20J-1J0J1�
�
runner2A single runner target to use for the test target.2@"@rules_apple//apple/testing/default_runner:tvos_default_runner"

expect_failure2None@"
 
transitive_configs2None8@

deprecation2None8@

tags2None8@

testonly2None8@

features2None@

compatible_with2None8@

restricted_to2None8@ 

package_metadata2None8@

aspect_hints2None@R
P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@

exec_properties
2None@$
"
exec_compatible_with2None8@*
(
exec_group_compatible_with2None8@\
Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@

size2None8@

timeout2None8@

flaky2None8@

shard_count2None@

local2None8@

args2None@s
q
collect_code_coveragePWhether to collect code coverage for this test if `--collect_code_coverage=yes`.2NoneN
L
data<Files to be made available to the test during its execution.2None�
�
env�Dictionary of environment variables that should be set during the test execution. The values of
the dictionary are subject to "Make" variable expansion.
2None`
^
env_inheritGList of environment variables to inherit from the external environment.2Nonet
r
test_filter[Test filter string that will be passed into the test runner to select which tests will run.2None�
�
test_coverage_manifesteA file that will be used in lcov export calls to limit the scope of files instrumented with coverage.2None�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None

platform_type2Noneg
e
	test_host*P
AppleBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl2None�
�
test_host_is_bundle_loaderpWhether the 'test_host' should be used as the -bundle_loader to allow testing
the symbols from the test host app2None�ctvos_ui_test�Builds and bundles a tvOS UI `.xctest` test bundle. Runs the tests using the
provided test runner when invoked with `bazel test`.

Note: tvOS UI tests are not currently supported in the default test runner.

The following is a list of the `tvos_ui_test` specific attributes; for a list of
the attributes inherited by all test rules, please check the
[Bazel documentation](https://bazel.build/reference/be/common-definitions#common-attributes-tests).Z�_
�1
tvos_ui_test�Builds and bundles a tvOS UI `.xctest` test bundle. Runs the tests using the
provided test runner when invoked with `bazel test`.

Note: tvOS UI tests are not currently supported in the default test runner.

The following is a list of the `tvos_ui_test` specific attributes; for a list of
the attributes inherited by all test rules, please check the
[Bazel documentation](https://bazel.build/reference/be/common-definitions#common-attributes-tests).�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2""�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2"bundle_name"�
bundle_name�The desired name of the test bundle (without the extension). If this attribute is not set, then the
name of the target will be used instead.2""8�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]g
familiesQA list of device families supported by this rule. At least one must be specified.2["tv"]�

frameworks8A list of framework targets that this target depends on.*�
AppleBundleInfo
TvosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlE
TvosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. If not provided,
a default Info.plist will be used. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported.26["@rules_apple//apple/testing:DefaultTestBundlePlist"]a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.20J-1J0J1�
runner2A single runner target to use for the test target.2@"@rules_apple//apple/testing/default_runner:tvos_default_runner"
expect_failure2None@ 
transitive_configs2None8@
deprecation2None8@
tags2None8@
testonly2None8@
features2None@
compatible_with2None8@
restricted_to2None8@
package_metadata2None8@
aspect_hints2None@P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@
exec_properties
2None@"
exec_compatible_with2None8@(
exec_group_compatible_with2None8@Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@
size2None8@
timeout2None8@
flaky2None8@
shard_count2None@
local2None8@
args2None@q
collect_code_coveragePWhether to collect code coverage for this test if `--collect_code_coverage=yes`.2NoneL
data<Files to be made available to the test during its execution.2None�
env�Dictionary of environment variables that should be set during the test execution. The values of
the dictionary are subject to "Make" variable expansion.
2None^
env_inheritGList of environment variables to inherit from the external environment.2Noner
test_filter[Test filter string that will be passed into the test runner to select which tests will run.2None�
test_coverage_manifesteA file that will be used in lcov export calls to limit the scope of files instrumented with coverage.2None�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None
platform_type2Nonee
	test_host*P
AppleBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl2None�
test_host_is_bundle_loaderpWhether the 'test_host' should be used as the -bundle_loader to allow testing
the symbols from the test host app2None",
tvos_ui_test@rules_apple//apple:tvos.bzl�
�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �
�

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@U
S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2""�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2"bundle_name"�
�
bundle_name�The desired name of the test bundle (without the extension). If this attribute is not set, then the
name of the target will be used instead.2""8�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]i
g
familiesQA list of device families supported by this rule. At least one must be specified.2["tv"]�
�

frameworks8A list of framework targets that this target depends on.*�
AppleBundleInfo
TvosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlE
TvosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. If not provided,
a default Info.plist will be used. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported.26["@rules_apple//apple/testing:DefaultTestBundlePlist"]c
a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]�
�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.20J-1J0J1�
�
runner2A single runner target to use for the test target.2@"@rules_apple//apple/testing/default_runner:tvos_default_runner"

expect_failure2None@"
 
transitive_configs2None8@

deprecation2None8@

tags2None8@

testonly2None8@

features2None@

compatible_with2None8@

restricted_to2None8@ 

package_metadata2None8@

aspect_hints2None@R
P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@

exec_properties
2None@$
"
exec_compatible_with2None8@*
(
exec_group_compatible_with2None8@\
Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@

size2None8@

timeout2None8@

flaky2None8@

shard_count2None@

local2None8@

args2None@s
q
collect_code_coveragePWhether to collect code coverage for this test if `--collect_code_coverage=yes`.2NoneN
L
data<Files to be made available to the test during its execution.2None�
�
env�Dictionary of environment variables that should be set during the test execution. The values of
the dictionary are subject to "Make" variable expansion.
2None`
^
env_inheritGList of environment variables to inherit from the external environment.2Nonet
r
test_filter[Test filter string that will be passed into the test runner to select which tests will run.2None�
�
test_coverage_manifesteA file that will be used in lcov export calls to limit the scope of files instrumented with coverage.2None�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None

platform_type2Noneg
e
	test_host*P
AppleBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl2None�
�
test_host_is_bundle_loaderpWhether the 'test_host' should be used as the -bundle_loader to allow testing
the symbols from the test host app2None9# Bazel rules for creating tvOS applications and bundles.�5
$
rules_appleappleversioning.bzl�5apple_bundle_version�Produces a target that contains versioning information for an Apple bundle.

This rule allows version numbers to be hard-coded into the BUILD file or
extracted from the build label passed into Bazel using the `--embed_label`
command line flag.

Targets created by this rule do not generate outputs themselves, but instead
should be used in the `version` attribute of an Apple application or extension
bundle target to set the version keys in that bundle's Info.plist file.

### Examples

```python
# A version scheme that uses hard-coded versions checked into your
# BUILD files.
apple_bundle_version(
    name = "simple",
    build_version = "1.0.134",
    short_version_string = "1.0",
)

ios_application(
    name = "foo_app",
    ...,
    version = ":simple",
)

# A version scheme that parses version information out of the build
# label and uses a fallback for developers' builds. For example, the
# following command
#
#    bazel build //myapp:myapp --embed_label=MyApp_1.2_build_345
#
# would yield the Info.plist values:
#
#    CFBundleVersion = "1.2.345"
#    CFBundleShortVersionString = "1.2"
#
# and the development builds using the command:
#
#    bazel build //myapp:myapp
#
# would yield the values:
#
#    CFBundleVersion = "99.99.99"
#    CFBundleShortVersionString = "99.99"
#
apple_bundle_version(
    name = "build_label_version",
    build_label_pattern = "MyApp_{version}_build_{build}",
    build_version = "{version}.{build}",
    capture_groups = {
        "version": "\\d+\\.\\d+",
        "build": "\\d+",
    },
    short_version_string = "{version}",
    fallback_build_label = "MyApp_99.99_build_99",
)

ios_application(
    name = "bar_app",
    ...,
    version = ":build_label_version",
)
```

Provides:
  AppleBundleVersionInfo: Contains a reference to the JSON file that holds the
      version information for a bundle."�&
�
apple_bundle_version�Produces a target that contains versioning information for an Apple bundle.

This rule allows version numbers to be hard-coded into the BUILD file or
extracted from the build label passed into Bazel using the `--embed_label`
command line flag.

Targets created by this rule do not generate outputs themselves, but instead
should be used in the `version` attribute of an Apple application or extension
bundle target to set the version keys in that bundle's Info.plist file.

### Examples

```python
# A version scheme that uses hard-coded versions checked into your
# BUILD files.
apple_bundle_version(
    name = "simple",
    build_version = "1.0.134",
    short_version_string = "1.0",
)

ios_application(
    name = "foo_app",
    ...,
    version = ":simple",
)

# A version scheme that parses version information out of the build
# label and uses a fallback for developers' builds. For example, the
# following command
#
#    bazel build //myapp:myapp --embed_label=MyApp_1.2_build_345
#
# would yield the Info.plist values:
#
#    CFBundleVersion = "1.2.345"
#    CFBundleShortVersionString = "1.2"
#
# and the development builds using the command:
#
#    bazel build //myapp:myapp
#
# would yield the values:
#
#    CFBundleVersion = "99.99.99"
#    CFBundleShortVersionString = "99.99"
#
apple_bundle_version(
    name = "build_label_version",
    build_label_pattern = "MyApp_{version}_build_{build}",
    build_version = "{version}.{build}",
    capture_groups = {
        "version": "\\d+\\.\\d+",
        "build": "\\d+",
    },
    short_version_string = "{version}",
    fallback_build_label = "MyApp_99.99_build_99",
)

ios_application(
    name = "bar_app",
    ...,
    version = ":build_label_version",
)
```

Provides:
  AppleBundleVersionInfo: Contains a reference to the JSON file that holds the
      version information for a bundle.*
nameA unique name for this target. �
build_label_pattern�A pattern that should contain placeholders inside curly braces (e.g.,
`"foo_{version}_bar"`) that is used to parse the build label that is generated
in the build info file with the `--embed_label` option passed to Bazel. Each of
the placeholders is expected to match one of the keys in the `capture_groups`
attribute.2""�
build_version�A string that will be used as the value for the `CFBundleVersion` key in a
depending bundle's Info.plist. If this string contains placeholders, then they
will be replaced by strings captured out of `build_label_pattern`. �
capture_groups�A dictionary where each key is the name of a placeholder found in
`build_label_pattern` and the corresponding value is the regular expression that
should match that placeholder. If this attribute is provided, then
`build_label_pattern` must also be provided.
2{}�
fallback_build_label�A build label to use when the no `--embed_label` was provided on the build. Used
to provide a version that will be used during development.2""�
short_version_string�A string that will be used as the value for the `CFBundleShortVersionString` key
in a depending bundle's Info.plist. If this string contains placeholders, then
they will be replaced by strings captured out of `build_label_pattern`. This
attribute is optional; if it is omitted, then the value of `build_version` will
be used for this key as well.2""":
apple_bundle_version"@rules_apple//apple:versioning.bzl,
*
nameA unique name for this target. �
�
build_label_pattern�A pattern that should contain placeholders inside curly braces (e.g.,
`"foo_{version}_bar"`) that is used to parse the build label that is generated
in the build info file with the `--embed_label` option passed to Bazel. Each of
the placeholders is expected to match one of the keys in the `capture_groups`
attribute.2""�
�
build_version�A string that will be used as the value for the `CFBundleVersion` key in a
depending bundle's Info.plist. If this string contains placeholders, then they
will be replaced by strings captured out of `build_label_pattern`. �
�
capture_groups�A dictionary where each key is the name of a placeholder found in
`build_label_pattern` and the corresponding value is the regular expression that
should match that placeholder. If this attribute is provided, then
`build_label_pattern` must also be provided.
2{}�
�
fallback_build_label�A build label to use when the no `--embed_label` was provided on the build. Used
to provide a version that will be used during development.2""�
�
short_version_string�A string that will be used as the value for the `CFBundleShortVersionString` key
in a depending bundle's Info.plist. If this string contains placeholders, then
they will be replaced by strings captured out of `build_label_pattern`. This
attribute is optional; if it is omitted, then the value of `build_version` will
be used for this key as well.2""+# Rules related to Apple bundle versioning.�
"
rules_appleapplevisionos.bzl��visionos_application*Builds and bundles a visionOS Application."��
�C
visionos_application*Builds and bundles a visionOS Application.*
nameA unique name for this target. �
	app_icons�Files that comprise the app icons for the application. Each file must have a containing directory
named `*..xcassets/*..solidimagestack` and there may be only one such
`..solidimagestack` directory in the list. In Xcode 26+ for iOS/macOS/watchOS, an `*.icon`
bundle can be provided along with the `*..xcassets` bundle to support 26 and
pre-26 Apple OS rendering.2[]�
primary_app_icon�An optional String to identify the name of the primary app icon when alternate app icons have been
provided for the app. This should match both the `*.icon` bundle in iOS/macOS/watchOS 26+ and the
`*..xcassets/.appiconset` bundle's AppIcon resource in previous versions of
iOS/macOS/watchOS.2""�
app_intents:List of dependencies implementing the AppIntents protocol.*;
	SwiftInfo.
	SwiftInfo!@rules_swift//swift:providers.bzl2[]�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonek
familiesQA list of device families supported by this rule. At least one must be specified.2
["vision"]�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. If not provided,
a default Info.plist will be used. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported.2H["@rules_apple//apple/internal/templates:default_application_infoplist"]�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
locales_to_include�A list of locales to include in the bundle. Only *.lproj directories that are matched will be copied as a part of the build.
This value takes precedence (and is preferred) over locales defined using `--define "apple.locales_to_include=..."`.2[]�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""
platform_type2
"visionos"�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID rule found within
`signed_capabilities`.2""�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
a base bundle ID rule found within `signed_capabilities`, then this string will be appended to the
end of the bundle ID following a "." separator.2"bundle_name"�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
entitlements�The entitlements file required for device builds of this target. If absent, the default entitlements
from the provisioning profile will be used.

The following variables are substituted in the entitlements file: `$(CFBundleIdentifier)` with the
bundle ID of the application and `$(AppIdentifierPrefix)` with the value of the
`ApplicationIdentifierPrefix` key from the target's provisioning profile.2None�
entitlements_validation�An `entitlements_validation_mode` to control the validation of the requested entitlements against
the provisioning profile to ensure they are supported.2"loose"J"error"J"warn"J"loose"J"skip"�
shared_capabilities�A list of shared `apple_capability_set` rules to represent the capabilities that a code sign aware
Apple bundle rule output should have. These can define the formal prefix for the target's
`bundle_id` and can further be merged with information provided by `entitlements`, if defined by any
capabilities found within the `apple_capability_set`.*d
AppleSharedCapabilityInfoG
AppleSharedCapabilityInfo*@rules_apple//apple/internal:providers.bzl2[]�

frameworks�A list of framework targets (see
[`visionos_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-visionos.md#visionos_framework))
that this target depends on.*�
AppleBundleInfo
VisionosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlI
VisionosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�

extensionsIA list of visionOS extensions to include in the final application bundle.*�
AppleBundleInfo
VisionosExtensionBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlI
VisionosExtensionBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�
launch_storyboard�The `.storyboard` file that should be used as the launch screen for the application. The provided
file will be compiled into the appropriate format (`.storyboardc`) and placed in the root of the
final bundle. The generated file will also be registered in the bundle's Info.plist under the key
`UILaunchStoryboardName`.2None"G
visionos_application/@rules_apple//apple/internal:visionos_rules.bzl8,
*
nameA unique name for this target. �
�
	app_icons�Files that comprise the app icons for the application. Each file must have a containing directory
named `*..xcassets/*..solidimagestack` and there may be only one such
`..solidimagestack` directory in the list. In Xcode 26+ for iOS/macOS/watchOS, an `*.icon`
bundle can be provided along with the `*..xcassets` bundle to support 26 and
pre-26 Apple OS rendering.2[]�
�
primary_app_icon�An optional String to identify the name of the primary app icon when alternate app icons have been
provided for the app. This should match both the `*.icon` bundle in iOS/macOS/watchOS 26+ and the
`*..xcassets/.appiconset` bundle's AppIcon resource in previous versions of
iOS/macOS/watchOS.2""�
�
app_intents:List of dependencies implementing the AppIntents protocol.*;
	SwiftInfo.
	SwiftInfo!@rules_swift//swift:providers.bzl2[]�
�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]g
e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]c
a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]U
S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonem
k
familiesQA list of device families supported by this rule. At least one must be specified.2
["vision"]�
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. If not provided,
a default Info.plist will be used. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported.2H["@rules_apple//apple/internal/templates:default_application_infoplist"]�
�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
�
locales_to_include�A list of locales to include in the bundle. Only *.lproj directories that are matched will be copied as a part of the build.
This value takes precedence (and is preferred) over locales defined using `--define "apple.locales_to_include=..."`.2[]�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""

platform_type2
"visionos"�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID rule found within
`signed_capabilities`.2""�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
a base bundle ID rule found within `signed_capabilities`, then this string will be appended to the
end of the bundle ID following a "." separator.2"bundle_name"�
�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
entitlements�The entitlements file required for device builds of this target. If absent, the default entitlements
from the provisioning profile will be used.

The following variables are substituted in the entitlements file: `$(CFBundleIdentifier)` with the
bundle ID of the application and `$(AppIdentifierPrefix)` with the value of the
`ApplicationIdentifierPrefix` key from the target's provisioning profile.2None�
�
entitlements_validation�An `entitlements_validation_mode` to control the validation of the requested entitlements against
the provisioning profile to ensure they are supported.2"loose"J"error"J"warn"J"loose"J"skip"�
�
shared_capabilities�A list of shared `apple_capability_set` rules to represent the capabilities that a code sign aware
Apple bundle rule output should have. These can define the formal prefix for the target's
`bundle_id` and can further be merged with information provided by `entitlements`, if defined by any
capabilities found within the `apple_capability_set`.*d
AppleSharedCapabilityInfoG
AppleSharedCapabilityInfo*@rules_apple//apple/internal:providers.bzl2[]�
�

frameworks�A list of framework targets (see
[`visionos_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-visionos.md#visionos_framework))
that this target depends on.*�
AppleBundleInfo
VisionosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlI
VisionosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�
�

extensionsIA list of visionOS extensions to include in the final application bundle.*�
AppleBundleInfo
VisionosExtensionBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlI
VisionosExtensionBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�
�
launch_storyboard�The `.storyboard` file that should be used as the launch screen for the application. The provided
file will be compiled into the appropriate format (`.storyboardc`) and placed in the root of the
final bundle. The generated file will also be registered in the bundle's Info.plist under the key
`UILaunchStoryboardName`.2None�bvisionos_dynamic_frameworkLBuilds and bundles a visionos dynamic framework that is consumable by Xcode."�a
�1
visionos_dynamic_frameworkLBuilds and bundles a visionos dynamic framework that is consumable by Xcode.*
nameA unique name for this target. �
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonek
familiesQA list of device families supported by this rule. At least one must be specified.2
["vision"]�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""
platform_type2
"visionos"�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2""�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2"bundle_name"�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
bundle_only�Avoid linking the dynamic framework, but still include it in the app. This is useful when you want
to manually dlopen the framework at runtime.2False�
extension_safe�If true, compiles and links this framework with `-application-extension`, restricting the binary to
use only extension-safe APIs.2False�

frameworks�A list of framework targets (see
[`visionos_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-visionos.md#visionos_framework))
that this target depends on.*�
AppleBundleInfo
VisionosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlI
VisionosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]
hdrs2[]"M
visionos_dynamic_framework/@rules_apple//apple/internal:visionos_rules.bzl,
*
nameA unique name for this target. �
�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]g
e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]c
a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]U
S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonem
k
familiesQA list of device families supported by this rule. At least one must be specified.2
["vision"]�
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""

platform_type2
"visionos"�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2""�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2"bundle_name"�
�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
�
bundle_only�Avoid linking the dynamic framework, but still include it in the app. This is useful when you want
to manually dlopen the framework at runtime.2False�
�
extension_safe�If true, compiles and links this framework with `-application-extension`, restricting the binary to
use only extension-safe APIs.2False�
�

frameworks�A list of framework targets (see
[`visionos_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-visionos.md#visionos_framework))
that this target depends on.*�
AppleBundleInfo
VisionosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlI
VisionosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]

hdrs2[]�dvisionos_framework�Builds and bundles a visionos Dynamic Framework.

To use this framework for your app and extensions, list it in the frameworks attributes of those visionos_application and/or visionos_extension rules."�b
�2
visionos_framework�Builds and bundles a visionos Dynamic Framework.

To use this framework for your app and extensions, list it in the frameworks attributes of those visionos_application and/or visionos_extension rules.*
nameA unique name for this target. �
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonek
familiesQA list of device families supported by this rule. At least one must be specified.2
["vision"]�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""
platform_type2
"visionos"�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2""�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2"bundle_name"�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
bundle_only�Avoid linking the dynamic framework, but still include it in the app. This is useful when you want
to manually dlopen the framework at runtime.2False�
extension_safe�If true, compiles and links this framework with `-application-extension`, restricting the binary to
use only extension-safe APIs.2False�

frameworks�A list of framework targets (see
[`visionos_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-visionos.md#visionos_framework))
that this target depends on.*�
AppleBundleInfo
VisionosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlI
VisionosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]
hdrs2[]"E
visionos_framework/@rules_apple//apple/internal:visionos_rules.bzl,
*
nameA unique name for this target. �
�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]g
e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]c
a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]U
S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonem
k
familiesQA list of device families supported by this rule. At least one must be specified.2
["vision"]�
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""

platform_type2
"visionos"�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2""�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2"bundle_name"�
�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
�
bundle_only�Avoid linking the dynamic framework, but still include it in the app. This is useful when you want
to manually dlopen the framework at runtime.2False�
�
extension_safe�If true, compiles and links this framework with `-application-extension`, restricting the binary to
use only extension-safe APIs.2False�
�

frameworks�A list of framework targets (see
[`visionos_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-visionos.md#visionos_framework))
that this target depends on.*�
AppleBundleInfo
VisionosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlI
VisionosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]

hdrs2[]�vvisionos_static_framework�Builds and bundles an visionos static framework for third-party distribution.

A static framework is bundled like a dynamic framework except that the embedded
binary is a static library rather than a dynamic library. It is intended to
create distributable static SDKs or artifacts that can be easily imported into
other Xcode projects; it is specifically **not** intended to be used as a
dependency of other Bazel targets. For that use case, use the corresponding
`objc_library` targets directly.

Unlike other visionos bundles, the fat binary in an `visionos_static_framework` may
simultaneously contain simulator and device architectures (that is, you can
build a single framework artifact that works for all architectures by specifying
`--visionos_cpus=sim_arm64,arm64` when you build).

`visionos_static_framework` supports Swift, but there are some constraints:

* `visionos_static_framework` with Swift only works with Xcode 11 and above, since
  the required Swift functionality for module compatibility is available in
  Swift 5.1.
* `visionos_static_framework` only supports a single direct `swift_library` target
  that does not depend transitively on any other `swift_library` targets. The
  Swift compiler expects a framework to contain a single Swift module, and each
  `swift_library` target is its own module by definition.
* `visionos_static_framework` does not support mixed Objective-C and Swift public
  interfaces. This means that the `umbrella_header` and `hdrs` attributes are
  unavailable when using `swift_library` dependencies. You are allowed to depend
  on `objc_library` from the main `swift_library` dependency, but note that only
  the `swift_library`'s public interface will be available to users of the
  static framework.

When using Swift, the `visionos_static_framework` bundles `swiftinterface` and
`swiftdocs` file for each of the required architectures. It also bundles an
umbrella header which is the header generated by the single `swift_library`
target. Finally, it also bundles a `module.modulemap` file pointing to the
umbrella header for Objetive-C module compatibility. This umbrella header and
modulemap can be skipped by disabling the `swift.no_generated_header` feature (
i.e. `--features=-swift.no_generated_header`)."�d
�;
visionos_static_framework�Builds and bundles an visionos static framework for third-party distribution.

A static framework is bundled like a dynamic framework except that the embedded
binary is a static library rather than a dynamic library. It is intended to
create distributable static SDKs or artifacts that can be easily imported into
other Xcode projects; it is specifically **not** intended to be used as a
dependency of other Bazel targets. For that use case, use the corresponding
`objc_library` targets directly.

Unlike other visionos bundles, the fat binary in an `visionos_static_framework` may
simultaneously contain simulator and device architectures (that is, you can
build a single framework artifact that works for all architectures by specifying
`--visionos_cpus=sim_arm64,arm64` when you build).

`visionos_static_framework` supports Swift, but there are some constraints:

* `visionos_static_framework` with Swift only works with Xcode 11 and above, since
  the required Swift functionality for module compatibility is available in
  Swift 5.1.
* `visionos_static_framework` only supports a single direct `swift_library` target
  that does not depend transitively on any other `swift_library` targets. The
  Swift compiler expects a framework to contain a single Swift module, and each
  `swift_library` target is its own module by definition.
* `visionos_static_framework` does not support mixed Objective-C and Swift public
  interfaces. This means that the `umbrella_header` and `hdrs` attributes are
  unavailable when using `swift_library` dependencies. You are allowed to depend
  on `objc_library` from the main `swift_library` dependency, but note that only
  the `swift_library`'s public interface will be available to users of the
  static framework.

When using Swift, the `visionos_static_framework` bundles `swiftinterface` and
`swiftdocs` file for each of the required architectures. It also bundles an
umbrella header which is the header generated by the single `swift_library`
target. Finally, it also bundles a `module.modulemap` file pointing to the
umbrella header for Objetive-C module compatibility. This umbrella header and
modulemap can be skipped by disabling the `swift.no_generated_header` feature (
i.e. `--features=-swift.no_generated_header`).*
nameA unique name for this target. �
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonek
familiesQA list of device families supported by this rule. At least one must be specified.2
["vision"]�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""
platform_type2
"visionos"�

avoid_deps�A list of library targets on which this framework depends in order to compile, but the transitive
closure of which will not be linked into the framework's binary.2[]�
exclude_resources�Indicates whether resources should be excluded from the bundle. This can be used to avoid
unnecessarily bundling resources if the static framework is being distributed in a different
fashion, such as a Cocoapod.2False�
hdrs�A list of `.h` files that will be publicly exposed by this framework. These headers should have
framework-relative imports, and if non-empty, an umbrella header named `%{bundle_name}.h` will also
be generated that imports all of the headers listed here.2[]�
umbrella_header�An optional single .h file to use as the umbrella header for this framework. Usually, this header
will have the same name as this target, so that clients can load the header using the #import
<MyFramework/MyFramework.h> format. If this attribute is not specified (the common use case), an
umbrella header will be generated under the same name as this target.2None"L
visionos_static_framework/@rules_apple//apple/internal:visionos_rules.bzl,
*
nameA unique name for this target. �
�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]g
e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]c
a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]U
S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonem
k
familiesQA list of device families supported by this rule. At least one must be specified.2
["vision"]�
�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""

platform_type2
"visionos"�
�

avoid_deps�A list of library targets on which this framework depends in order to compile, but the transitive
closure of which will not be linked into the framework's binary.2[]�
�
exclude_resources�Indicates whether resources should be excluded from the bundle. This can be used to avoid
unnecessarily bundling resources if the static framework is being distributed in a different
fashion, such as a Cocoapod.2False�
�
hdrs�A list of `.h` files that will be publicly exposed by this framework. These headers should have
framework-relative imports, and if non-empty, an umbrella header named `%{bundle_name}.h` will also
be generated that imports all of the headers listed here.2[]�
�
umbrella_header�An optional single .h file to use as the umbrella header for this framework. Usually, this header
will have the same name as this target, so that clients can load the header using the #import
<MyFramework/MyFramework.h> format. If this attribute is not specified (the common use case), an
umbrella header will be generated under the same name as this target.2None�
visionos_build_test�Test rule to check that the given library targets (Swift, Objective-C, C++)
build for visionOS.

Typical usage:

```starlark
visionos_build_test(
    name = "my_build_test",
    minimum_os_version = "1.0",
    targets = [
        "//some/package:my_library",
    ],
)
```"�
�
visionos_build_test�Test rule to check that the given library targets (Swift, Objective-C, C++)
build for visionOS.

Typical usage:

```starlark
visionos_build_test(
    name = "my_build_test",
    minimum_os_version = "1.0",
    targets = [
        "//some/package:my_library",
    ],
)
```*
nameA unique name for this target. �
minimum_os_version�A required string indicating the minimum OS version that will be used as the
deployment target when building the targets, represented as a dotted version
number (for example, `"9.0"`). ;
targets*The targets to check for successful build.2[]
platform_type2
"visionos""7
visionos_build_test @rules_apple//apple:visionos.bzl08,
*
nameA unique name for this target. �
�
minimum_os_version�A required string indicating the minimum OS version that will be used as the
deployment target when building the targets, represented as a dotted version
number (for example, `"9.0"`). =
;
targets*The targets to check for successful build.2[]

platform_type2
"visionos"�mvisionos_unit_test�Builds and bundles a visionOS Unit `.xctest` test bundle. Runs the tests using the
provided test runner when invoked with `bazel test`.

Note: visionOS unit tests are not currently supported in the default test runner.

`visionos_unit_test` targets can work in two modes: as app or library tests. If the
`test_host` attribute is set to an `visionos_application` target, the tests will run
within that application's context. If no `test_host` is provided, the tests will
run outside the context of a visionOS application. Because of this, certain
functionalities might not be present (e.g. UI layout, NSUserDefaults). You can
find more information about app and library testing for Apple platforms
[here](https://developer.apple.com/library/content/documentation/DeveloperTools/Conceptual/testing_with_xcode/chapters/03-testing_basics.html).

The following is a list of the `visionos_unit_test` specific attributes; for a list
of the attributes inherited by all test rules, please check the
[Bazel documentation](https://bazel.build/reference/be/common-definitions#common-attributes-tests).Z�d
�6
visionos_unit_test�Builds and bundles a visionOS Unit `.xctest` test bundle. Runs the tests using the
provided test runner when invoked with `bazel test`.

Note: visionOS unit tests are not currently supported in the default test runner.

`visionos_unit_test` targets can work in two modes: as app or library tests. If the
`test_host` attribute is set to an `visionos_application` target, the tests will run
within that application's context. If no `test_host` is provided, the tests will
run outside the context of a visionOS application. Because of this, certain
functionalities might not be present (e.g. UI layout, NSUserDefaults). You can
find more information about app and library testing for Apple platforms
[here](https://developer.apple.com/library/content/documentation/DeveloperTools/Conceptual/testing_with_xcode/chapters/03-testing_basics.html).

The following is a list of the `visionos_unit_test` specific attributes; for a list
of the attributes inherited by all test rules, please check the
[Bazel documentation](https://bazel.build/reference/be/common-definitions#common-attributes-tests).�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2""�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2"bundle_name"�
bundle_name�The desired name of the test bundle (without the extension). If this attribute is not set, then the
name of the target will be used instead.2""8�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]k
familiesQA list of device families supported by this rule. At least one must be specified.2
["vision"]�

frameworks8A list of framework targets that this target depends on.*�
AppleBundleInfo
VisionosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlI
VisionosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. If not provided,
a default Info.plist will be used. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported.26["@rules_apple//apple/testing:DefaultTestBundlePlist"]a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.20J-1J0J1�
runner2A single runner target to use for the test target.2D"@rules_apple//apple/testing/default_runner:visionos_default_runner"
expect_failure2None@ 
transitive_configs2None8@
deprecation2None8@
tags2None8@
testonly2None8@
features2None@
compatible_with2None8@
restricted_to2None8@
package_metadata2None8@
aspect_hints2None@P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@
exec_properties
2None@"
exec_compatible_with2None8@(
exec_group_compatible_with2None8@Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@
size2None8@
timeout2None8@
flaky2None8@
shard_count2None@
local2None8@
args2None@q
collect_code_coveragePWhether to collect code coverage for this test if `--collect_code_coverage=yes`.2NoneL
data<Files to be made available to the test during its execution.2None�
env�Dictionary of environment variables that should be set during the test execution. The values of
the dictionary are subject to "Make" variable expansion.
2None^
env_inheritGList of environment variables to inherit from the external environment.2Noner
test_filter[Test filter string that will be passed into the test runner to select which tests will run.2None�
test_coverage_manifesteA file that will be used in lcov export calls to limit the scope of files instrumented with coverage.2None�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None
platform_type2Nonee
	test_host*P
AppleBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl2None�
test_host_is_bundle_loaderpWhether the 'test_host' should be used as the -bundle_loader to allow testing
the symbols from the test host app2None"6
visionos_unit_test @rules_apple//apple:visionos.bzl�
�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �
�

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@U
S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2""�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2"bundle_name"�
�
bundle_name�The desired name of the test bundle (without the extension). If this attribute is not set, then the
name of the target will be used instead.2""8�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]m
k
familiesQA list of device families supported by this rule. At least one must be specified.2
["vision"]�
�

frameworks8A list of framework targets that this target depends on.*�
AppleBundleInfo
VisionosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlI
VisionosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. If not provided,
a default Info.plist will be used. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported.26["@rules_apple//apple/testing:DefaultTestBundlePlist"]c
a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]�
�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.20J-1J0J1�
�
runner2A single runner target to use for the test target.2D"@rules_apple//apple/testing/default_runner:visionos_default_runner"

expect_failure2None@"
 
transitive_configs2None8@

deprecation2None8@

tags2None8@

testonly2None8@

features2None@

compatible_with2None8@

restricted_to2None8@ 

package_metadata2None8@

aspect_hints2None@R
P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@

exec_properties
2None@$
"
exec_compatible_with2None8@*
(
exec_group_compatible_with2None8@\
Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@

size2None8@

timeout2None8@

flaky2None8@

shard_count2None@

local2None8@

args2None@s
q
collect_code_coveragePWhether to collect code coverage for this test if `--collect_code_coverage=yes`.2NoneN
L
data<Files to be made available to the test during its execution.2None�
�
env�Dictionary of environment variables that should be set during the test execution. The values of
the dictionary are subject to "Make" variable expansion.
2None`
^
env_inheritGList of environment variables to inherit from the external environment.2Nonet
r
test_filter[Test filter string that will be passed into the test runner to select which tests will run.2None�
�
test_coverage_manifesteA file that will be used in lcov export calls to limit the scope of files instrumented with coverage.2None�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None

platform_type2Noneg
e
	test_host*P
AppleBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl2None�
�
test_host_is_bundle_loaderpWhether the 'test_host' should be used as the -bundle_loader to allow testing
the symbols from the test host app2None�cvisionos_ui_test�Builds and bundles a visionOS UI `.xctest` test bundle. Runs the tests using the
provided test runner when invoked with `bazel test`.

Note: visionOS UI tests are not currently supported in the default test runner.

The following is a list of the `visionos_ui_test` specific attributes; for a list of
the attributes inherited by all test rules, please check the
[Bazel documentation](https://bazel.build/reference/be/common-definitions#common-attributes-tests).Z�`
�1
visionos_ui_test�Builds and bundles a visionOS UI `.xctest` test bundle. Runs the tests using the
provided test runner when invoked with `bazel test`.

Note: visionOS UI tests are not currently supported in the default test runner.

The following is a list of the `visionos_ui_test` specific attributes; for a list of
the attributes inherited by all test rules, please check the
[Bazel documentation](https://bazel.build/reference/be/common-definitions#common-attributes-tests).�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2""�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2"bundle_name"�
bundle_name�The desired name of the test bundle (without the extension). If this attribute is not set, then the
name of the target will be used instead.2""8�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]k
familiesQA list of device families supported by this rule. At least one must be specified.2
["vision"]�

frameworks8A list of framework targets that this target depends on.*�
AppleBundleInfo
VisionosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlI
VisionosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. If not provided,
a default Info.plist will be used. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported.26["@rules_apple//apple/testing:DefaultTestBundlePlist"]a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.20J-1J0J1�
runner2A single runner target to use for the test target.2D"@rules_apple//apple/testing/default_runner:visionos_default_runner"
expect_failure2None@ 
transitive_configs2None8@
deprecation2None8@
tags2None8@
testonly2None8@
features2None@
compatible_with2None8@
restricted_to2None8@
package_metadata2None8@
aspect_hints2None@P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@
exec_properties
2None@"
exec_compatible_with2None8@(
exec_group_compatible_with2None8@Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@
size2None8@
timeout2None8@
flaky2None8@
shard_count2None@
local2None8@
args2None@q
collect_code_coveragePWhether to collect code coverage for this test if `--collect_code_coverage=yes`.2NoneL
data<Files to be made available to the test during its execution.2None�
env�Dictionary of environment variables that should be set during the test execution. The values of
the dictionary are subject to "Make" variable expansion.
2None^
env_inheritGList of environment variables to inherit from the external environment.2Noner
test_filter[Test filter string that will be passed into the test runner to select which tests will run.2None�
test_coverage_manifesteA file that will be used in lcov export calls to limit the scope of files instrumented with coverage.2None�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None
platform_type2Nonee
	test_host*P
AppleBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl2None�
test_host_is_bundle_loaderpWhether the 'test_host' should be used as the -bundle_loader to allow testing
the symbols from the test host app2None"4
visionos_ui_test @rules_apple//apple:visionos.bzl�
�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �
�

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@U
S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2""�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2"bundle_name"�
�
bundle_name�The desired name of the test bundle (without the extension). If this attribute is not set, then the
name of the target will be used instead.2""8�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]m
k
familiesQA list of device families supported by this rule. At least one must be specified.2
["vision"]�
�

frameworks8A list of framework targets that this target depends on.*�
AppleBundleInfo
VisionosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlI
VisionosFrameworkBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. If not provided,
a default Info.plist will be used. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported.26["@rules_apple//apple/testing:DefaultTestBundlePlist"]c
a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]�
�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.20J-1J0J1�
�
runner2A single runner target to use for the test target.2D"@rules_apple//apple/testing/default_runner:visionos_default_runner"

expect_failure2None@"
 
transitive_configs2None8@

deprecation2None8@

tags2None8@

testonly2None8@

features2None@

compatible_with2None8@

restricted_to2None8@ 

package_metadata2None8@

aspect_hints2None@R
P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@

exec_properties
2None@$
"
exec_compatible_with2None8@*
(
exec_group_compatible_with2None8@\
Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@

size2None8@

timeout2None8@

flaky2None8@

shard_count2None@

local2None8@

args2None@s
q
collect_code_coveragePWhether to collect code coverage for this test if `--collect_code_coverage=yes`.2NoneN
L
data<Files to be made available to the test during its execution.2None�
�
env�Dictionary of environment variables that should be set during the test execution. The values of
the dictionary are subject to "Make" variable expansion.
2None`
^
env_inheritGList of environment variables to inherit from the external environment.2Nonet
r
test_filter[Test filter string that will be passed into the test runner to select which tests will run.2None�
�
test_coverage_manifesteA file that will be used in lcov export calls to limit the scope of files instrumented with coverage.2None�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None

platform_type2Noneg
e
	test_host*P
AppleBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl2None�
�
test_host_is_bundle_loaderpWhether the 'test_host' should be used as the -bundle_loader to allow testing
the symbols from the test host app2None=# Bazel rules for creating visionOS applications and bundles.��
!
rules_appleapplewatchos.bzl��watchos_application)Builds and bundles a watchOS Application."�
�G
watchos_application)Builds and bundles a watchOS Application.*
nameA unique name for this target. �
	app_icons�Files that comprise the app icons for the application. Each file must have a containing directory
named `*..xcassets/*..appiconset` and there may be only one such
`..appiconset` directory in the list. In Xcode 26+ for iOS/macOS/watchOS, an `*.icon`
bundle can be provided along with the `*..xcassets` bundle to support 26 and
pre-26 Apple OS rendering.2[]�
app_intents:List of dependencies implementing the AppIntents protocol.*;
	SwiftInfo.
	SwiftInfo!@rules_swift//swift:providers.bzl2[]�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonej
familiesQA list of device families supported by this rule. At least one must be specified.2	["watch"]�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. If not provided,
a default Info.plist will be used. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported.2H["@rules_apple//apple/internal/templates:default_application_infoplist"]�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
locales_to_include�A list of locales to include in the bundle. Only *.lproj directories that are matched will be copied as a part of the build.
This value takes precedence (and is preferred) over locales defined using `--define "apple.locales_to_include=..."`.2[]�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""
platform_type2	"watchos"�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID rule found within
`signed_capabilities`.2""�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
a base bundle ID rule found within `signed_capabilities`, then this string will be appended to the
end of the bundle ID following a "." separator.2"watchkitapp"�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
entitlements�The entitlements file required for device builds of this target. If absent, the default entitlements
from the provisioning profile will be used.

The following variables are substituted in the entitlements file: `$(CFBundleIdentifier)` with the
bundle ID of the application and `$(AppIdentifierPrefix)` with the value of the
`ApplicationIdentifierPrefix` key from the target's provisioning profile.2None�
entitlements_validation�An `entitlements_validation_mode` to control the validation of the requested entitlements against
the provisioning profile to ensure they are supported.2"loose"J"error"J"warn"J"loose"J"skip"�
shared_capabilities�A list of shared `apple_capability_set` rules to represent the capabilities that a code sign aware
Apple bundle rule output should have. These can define the formal prefix for the target's
`bundle_id` and can further be merged with information provided by `entitlements`, if defined by any
capabilities found within the `apple_capability_set`.*d
AppleSharedCapabilityInfoG
AppleSharedCapabilityInfo*@rules_apple//apple/internal:providers.bzl2[]�
	extension�The watchOS 2 `watchos_extension` that is required to be bundled within a watchOS 2 application.

It is considered an error if the watchOS 2 application extension is assigned to a single target
watchOS application, which is constructed if the `watchos_application` target is assigned `deps`.

This attribute will not support additional types of `watchos_extension`s in the future.

This attribute is deprecated, please use `extensions` instead.*�
AppleBundleInfo
WatchosExtensionBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlH
WatchosExtensionBundleInfo*@rules_apple//apple/internal:providers.bzl2None�

extensions�In case of single-target watchOS app, a list of watchOS application extensions to include in the final watch app bundle.

In case of an extension-based watchOS app, a list with a single element,
the watchOS 2 `watchos_extension` that is required to be bundled within a watchOS 2 app.*�
AppleBundleInfo
WatchosExtensionBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlH
WatchosExtensionBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�
storyboards�A list of `.storyboard` files, often localizable. These files are compiled and placed in the root of
the final application bundle, unless a file's immediate containing directory is named `*.lproj`, in
which case it will be placed under a directory with the same name in the bundle.2[]�

frameworks�A list of framework targets (see
[`watchos_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-watchos.md#watchos_framework))
that this target depends on.*�
AppleBundleInfo
WatchosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl?
WatchosFrameworkBundleInfo!@rules_apple//apple:providers.bzl2[]"E
watchos_application.@rules_apple//apple/internal:watchos_rules.bzl8,
*
nameA unique name for this target. �
�
	app_icons�Files that comprise the app icons for the application. Each file must have a containing directory
named `*..xcassets/*..appiconset` and there may be only one such
`..appiconset` directory in the list. In Xcode 26+ for iOS/macOS/watchOS, an `*.icon`
bundle can be provided along with the `*..xcassets` bundle to support 26 and
pre-26 Apple OS rendering.2[]�
�
app_intents:List of dependencies implementing the AppIntents protocol.*;
	SwiftInfo.
	SwiftInfo!@rules_swift//swift:providers.bzl2[]�
�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]g
e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]c
a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]U
S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonel
j
familiesQA list of device families supported by this rule. At least one must be specified.2	["watch"]�
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. If not provided,
a default Info.plist will be used. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported.2H["@rules_apple//apple/internal/templates:default_application_infoplist"]�
�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
�
locales_to_include�A list of locales to include in the bundle. Only *.lproj directories that are matched will be copied as a part of the build.
This value takes precedence (and is preferred) over locales defined using `--define "apple.locales_to_include=..."`.2[]�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""

platform_type2	"watchos"�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID rule found within
`signed_capabilities`.2""�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
a base bundle ID rule found within `signed_capabilities`, then this string will be appended to the
end of the bundle ID following a "." separator.2"watchkitapp"�
�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
entitlements�The entitlements file required for device builds of this target. If absent, the default entitlements
from the provisioning profile will be used.

The following variables are substituted in the entitlements file: `$(CFBundleIdentifier)` with the
bundle ID of the application and `$(AppIdentifierPrefix)` with the value of the
`ApplicationIdentifierPrefix` key from the target's provisioning profile.2None�
�
entitlements_validation�An `entitlements_validation_mode` to control the validation of the requested entitlements against
the provisioning profile to ensure they are supported.2"loose"J"error"J"warn"J"loose"J"skip"�
�
shared_capabilities�A list of shared `apple_capability_set` rules to represent the capabilities that a code sign aware
Apple bundle rule output should have. These can define the formal prefix for the target's
`bundle_id` and can further be merged with information provided by `entitlements`, if defined by any
capabilities found within the `apple_capability_set`.*d
AppleSharedCapabilityInfoG
AppleSharedCapabilityInfo*@rules_apple//apple/internal:providers.bzl2[]�
�
	extension�The watchOS 2 `watchos_extension` that is required to be bundled within a watchOS 2 application.

It is considered an error if the watchOS 2 application extension is assigned to a single target
watchOS application, which is constructed if the `watchos_application` target is assigned `deps`.

This attribute will not support additional types of `watchos_extension`s in the future.

This attribute is deprecated, please use `extensions` instead.*�
AppleBundleInfo
WatchosExtensionBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlH
WatchosExtensionBundleInfo*@rules_apple//apple/internal:providers.bzl2None�
�

extensions�In case of single-target watchOS app, a list of watchOS application extensions to include in the final watch app bundle.

In case of an extension-based watchOS app, a list with a single element,
the watchOS 2 `watchos_extension` that is required to be bundled within a watchOS 2 app.*�
AppleBundleInfo
WatchosExtensionBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlH
WatchosExtensionBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�
�
storyboards�A list of `.storyboard` files, often localizable. These files are compiled and placed in the root of
the final application bundle, unless a file's immediate containing directory is named `*.lproj`, in
which case it will be placed under a directory with the same name in the bundle.2[]�
�

frameworks�A list of framework targets (see
[`watchos_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-watchos.md#watchos_framework))
that this target depends on.*�
AppleBundleInfo
WatchosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl?
WatchosFrameworkBundleInfo!@rules_apple//apple:providers.bzl2[]�bwatchos_dynamic_frameworkKBuilds and bundles a watchOS dynamic framework that is consumable by Xcode."�a
�1
watchos_dynamic_frameworkKBuilds and bundles a watchOS dynamic framework that is consumable by Xcode.*
nameA unique name for this target. �
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonej
familiesQA list of device families supported by this rule. At least one must be specified.2	["watch"]�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""
platform_type2	"watchos"�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2""�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2"bundle_name"�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
bundle_only�Avoid linking the dynamic framework, but still include it in the app. This is useful when you want
to manually dlopen the framework at runtime.2False�
extension_safe�If true, compiles and links this framework with `-application-extension`, restricting the binary to
use only extension-safe APIs.2False�

frameworks�A list of framework targets (see
[`watchos_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-watchos.md#watchos_framework))
that this target depends on.*�
AppleBundleInfo
WatchosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl?
WatchosFrameworkBundleInfo!@rules_apple//apple:providers.bzl2[]
hdrs2[]"K
watchos_dynamic_framework.@rules_apple//apple/internal:watchos_rules.bzl,
*
nameA unique name for this target. �
�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]g
e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]c
a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]U
S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonel
j
familiesQA list of device families supported by this rule. At least one must be specified.2	["watch"]�
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""

platform_type2	"watchos"�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2""�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2"bundle_name"�
�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
�
bundle_only�Avoid linking the dynamic framework, but still include it in the app. This is useful when you want
to manually dlopen the framework at runtime.2False�
�
extension_safe�If true, compiles and links this framework with `-application-extension`, restricting the binary to
use only extension-safe APIs.2False�
�

frameworks�A list of framework targets (see
[`watchos_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-watchos.md#watchos_framework))
that this target depends on.*�
AppleBundleInfo
WatchosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl?
WatchosFrameworkBundleInfo!@rules_apple//apple:providers.bzl2[]

hdrs2[]�cwatchos_framework�Builds and bundles a watchOS Dynamic Framework.

To use this framework for your extensions, list it in the `frameworks` attributes of
those `watchos_extension` rules."�b
�1
watchos_framework�Builds and bundles a watchOS Dynamic Framework.

To use this framework for your extensions, list it in the `frameworks` attributes of
those `watchos_extension` rules.*
nameA unique name for this target. �
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonej
familiesQA list of device families supported by this rule. At least one must be specified.2	["watch"]�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""
platform_type2	"watchos"�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2""�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2"bundle_name"�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
bundle_only�Avoid linking the dynamic framework, but still include it in the app. This is useful when you want
to manually dlopen the framework at runtime.2False�
extension_safe�If true, compiles and links this framework with `-application-extension`, restricting the binary to
use only extension-safe APIs.2False�

frameworks�A list of framework targets (see
[`watchos_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-watchos.md#watchos_framework))
that this target depends on.*�
AppleBundleInfo
WatchosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl?
WatchosFrameworkBundleInfo!@rules_apple//apple:providers.bzl2[]
hdrs2[]"C
watchos_framework.@rules_apple//apple/internal:watchos_rules.bzl,
*
nameA unique name for this target. �
�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]g
e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]c
a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]U
S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonel
j
familiesQA list of device families supported by this rule. At least one must be specified.2	["watch"]�
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""

platform_type2	"watchos"�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2""�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2"bundle_name"�
�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
�
bundle_only�Avoid linking the dynamic framework, but still include it in the app. This is useful when you want
to manually dlopen the framework at runtime.2False�
�
extension_safe�If true, compiles and links this framework with `-application-extension`, restricting the binary to
use only extension-safe APIs.2False�
�

frameworks�A list of framework targets (see
[`watchos_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-watchos.md#watchos_framework))
that this target depends on.*�
AppleBundleInfo
WatchosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl?
WatchosFrameworkBundleInfo!@rules_apple//apple:providers.bzl2[]

hdrs2[]�{watchos_extension'Builds and bundles a watchOS Extension."�z
�=
watchos_extension'Builds and bundles a watchOS Extension.*
nameA unique name for this target. �
app_intents:List of dependencies implementing the AppIntents protocol.*;
	SwiftInfo.
	SwiftInfo!@rules_swift//swift:providers.bzl2[]�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonej
familiesQA list of device families supported by this rule. At least one must be specified.2	["watch"]�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
locales_to_include�A list of locales to include in the bundle. Only *.lproj directories that are matched will be copied as a part of the build.
This value takes precedence (and is preferred) over locales defined using `--define "apple.locales_to_include=..."`.2[]�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""
platform_type2	"watchos"�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID rule found within
`signed_capabilities`.2""�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
a base bundle ID rule found within `signed_capabilities`, then this string will be appended to the
end of the bundle ID following a "." separator.2"watchkitapp.watchkitextension"�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
entitlements�The entitlements file required for device builds of this target. If absent, the default entitlements
from the provisioning profile will be used.

The following variables are substituted in the entitlements file: `$(CFBundleIdentifier)` with the
bundle ID of the application and `$(AppIdentifierPrefix)` with the value of the
`ApplicationIdentifierPrefix` key from the target's provisioning profile.2None�
entitlements_validation�An `entitlements_validation_mode` to control the validation of the requested entitlements against
the provisioning profile to ensure they are supported.2"loose"J"error"J"warn"J"loose"J"skip"�
shared_capabilities�A list of shared `apple_capability_set` rules to represent the capabilities that a code sign aware
Apple bundle rule output should have. These can define the formal prefix for the target's
`bundle_id` and can further be merged with information provided by `entitlements`, if defined by any
capabilities found within the `apple_capability_set`.*d
AppleSharedCapabilityInfoG
AppleSharedCapabilityInfo*@rules_apple//apple/internal:providers.bzl2[]�
application_extension�If `True`, this extension is an App Extension instead of a WatchKit Extension.
It links the extension with the application extension point (`_NSExtensionMain`)
instead of the WatchKit extension point (`_WKExtensionMain`), and has the
`app_extension` `product_type` instead of `watch2_extension`.2False�

extensionsXA list of watchOS application extensions to include in the final watch extension bundle.*�
AppleBundleInfo
WatchosExtensionBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlH
WatchosExtensionBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�

frameworks�A list of framework targets (see
[`watchos_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-watchos.md#watchos_framework))
that this target depends on.*�
AppleBundleInfo
WatchosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl?
WatchosFrameworkBundleInfo!@rules_apple//apple:providers.bzl2[]"C
watchos_extension.@rules_apple//apple/internal:watchos_rules.bzl,
*
nameA unique name for this target. �
�
app_intents:List of dependencies implementing the AppIntents protocol.*;
	SwiftInfo.
	SwiftInfo!@rules_swift//swift:providers.bzl2[]�
�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]g
e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]c
a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]U
S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonel
j
familiesQA list of device families supported by this rule. At least one must be specified.2	["watch"]�
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. At least one file
must be specified. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported. �
�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
�
locales_to_include�A list of locales to include in the bundle. Only *.lproj directories that are matched will be copied as a part of the build.
This value takes precedence (and is preferred) over locales defined using `--define "apple.locales_to_include=..."`.2[]�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""

platform_type2	"watchos"�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID rule found within
`signed_capabilities`.2""�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
a base bundle ID rule found within `signed_capabilities`, then this string will be appended to the
end of the bundle ID following a "." separator.2"watchkitapp.watchkitextension"�
�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
entitlements�The entitlements file required for device builds of this target. If absent, the default entitlements
from the provisioning profile will be used.

The following variables are substituted in the entitlements file: `$(CFBundleIdentifier)` with the
bundle ID of the application and `$(AppIdentifierPrefix)` with the value of the
`ApplicationIdentifierPrefix` key from the target's provisioning profile.2None�
�
entitlements_validation�An `entitlements_validation_mode` to control the validation of the requested entitlements against
the provisioning profile to ensure they are supported.2"loose"J"error"J"warn"J"loose"J"skip"�
�
shared_capabilities�A list of shared `apple_capability_set` rules to represent the capabilities that a code sign aware
Apple bundle rule output should have. These can define the formal prefix for the target's
`bundle_id` and can further be merged with information provided by `entitlements`, if defined by any
capabilities found within the `apple_capability_set`.*d
AppleSharedCapabilityInfoG
AppleSharedCapabilityInfo*@rules_apple//apple/internal:providers.bzl2[]�
�
application_extension�If `True`, this extension is an App Extension instead of a WatchKit Extension.
It links the extension with the application extension point (`_NSExtensionMain`)
instead of the WatchKit extension point (`_WKExtensionMain`), and has the
`app_extension` `product_type` instead of `watch2_extension`.2False�
�

extensionsXA list of watchOS application extensions to include in the final watch extension bundle.*�
AppleBundleInfo
WatchosExtensionBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlH
WatchosExtensionBundleInfo*@rules_apple//apple/internal:providers.bzl2[]�
�

frameworks�A list of framework targets (see
[`watchos_framework`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-watchos.md#watchos_framework))
that this target depends on.*�
AppleBundleInfo
WatchosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl?
WatchosFrameworkBundleInfo!@rules_apple//apple:providers.bzl2[]�Swatchos_static_framework.Builds and bundles a watchOS Static Framework."�S
�)
watchos_static_framework.Builds and bundles a watchOS Static Framework.*
nameA unique name for this target. �
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonej
familiesQA list of device families supported by this rule. At least one must be specified.2	["watch"]�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""
platform_type2	"watchos"�

avoid_deps�A list of library targets on which this framework depends in order to compile, but the transitive
closure of which will not be linked into the framework's binary.2[]�
exclude_resources�Indicates whether resources should be excluded from the bundle. This can be used to avoid
unnecessarily bundling resources if the static framework is being distributed in a different
fashion, such as a Cocoapod.2False�
hdrs�A list of `.h` files that will be publicly exposed by this framework. These headers should have
framework-relative imports, and if non-empty, an umbrella header named `%{bundle_name}.h` will also
be generated that imports all of the headers listed here.2[]�
umbrella_header�An optional single .h file to use as the umbrella header for this framework. Usually, this header
will have the same name as this target, so that clients can load the header using the #import
<MyFramework/MyFramework.h> format. If this attribute is not specified (the common use case), an
umbrella header will be generated under the same name as this target.2None"J
watchos_static_framework.@rules_apple//apple/internal:watchos_rules.bzl,
*
nameA unique name for this target. �
�
codesign_inputstA list of dependencies targets that provide inputs that will be used by
`codesign` (referenced with `codesignopts`).2[]g
e
codesignoptsOA list of strings representing extra flags that should be passed to `codesign`.2[]�
�
exported_symbols_lists�A list of targets containing exported symbols lists files for the linker to control symbol
resolution.

Each file is expected to have a list of global symbol names that will remain as global symbols in
the compiled binary owned by this framework. All other global symbols will be treated as if they
were marked as `__private_extern__` (aka `visibility=hidden`) and will not be global in the output
file.

See the man page documentation for `ld(1)` on macOS for more details.2[]c
a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]U
S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.2-1J-1J0J1�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]�
�
bundle_name�The desired name of the bundle (without the extension). If this attribute is not set, then the name
of the target will be used instead.2""�
�
executable_name�The desired name of the executable, if the bundle has an executable. If this attribute is not set,
then the name of the `bundle_name` attribute will be used if it is set; if not, then the name of
the target will be used instead.2""�
�
strings�A list of `.strings` files, often localizable. These files are converted to binary plists (if they
are not already) and placed in the root of the final bundle, unless a file's immediate containing
directory is named `*.lproj`, in which case it will be placed under a directory with the same name
in the bundle.2[]�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
�
version�An `apple_bundle_version` target that represents the version for this target. See
[`apple_bundle_version`](https://github.com/bazelbuild/rules_apple/blob/main/doc/rules-general.md?cl=head#apple_bundle_version).*^
AppleBundleVersionInfoD
AppleBundleVersionInfo*@rules_apple//apple/internal:providers.bzl2Nonel
j
familiesQA list of device families supported by this rule. At least one must be specified.2	["watch"]�
�
ipa_post_processor�A tool that edits this target's archive after it is assembled but before it is signed. The tool is
invoked with a single command-line argument that denotes the path to a directory containing the
unzipped contents of the archive; this target's bundle will be the directory's only contents.

Any changes made by the tool must be made in this directory, and the tool's execution must be
hermetic given these inputs to ensure that the result can be safely cached.2None�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2""

platform_type2	"watchos"�
�

avoid_deps�A list of library targets on which this framework depends in order to compile, but the transitive
closure of which will not be linked into the framework's binary.2[]�
�
exclude_resources�Indicates whether resources should be excluded from the bundle. This can be used to avoid
unnecessarily bundling resources if the static framework is being distributed in a different
fashion, such as a Cocoapod.2False�
�
hdrs�A list of `.h` files that will be publicly exposed by this framework. These headers should have
framework-relative imports, and if non-empty, an umbrella header named `%{bundle_name}.h` will also
be generated that imports all of the headers listed here.2[]�
�
umbrella_header�An optional single .h file to use as the umbrella header for this framework. Usually, this header
will have the same name as this target, so that clients can load the header using the #import
<MyFramework/MyFramework.h> format. If this attribute is not specified (the common use case), an
umbrella header will be generated under the same name as this target.2None�
watchos_build_test�Test rule to check that the given library targets (Swift, Objective-C, C++)
build for watchOS.

Typical usage:

```starlark
watchos_build_test(
    name = "my_build_test",
    minimum_os_version = "6.0",
    targets = [
        "//some/package:my_library",
    ],
)
```"�
�
watchos_build_test�Test rule to check that the given library targets (Swift, Objective-C, C++)
build for watchOS.

Typical usage:

```starlark
watchos_build_test(
    name = "my_build_test",
    minimum_os_version = "6.0",
    targets = [
        "//some/package:my_library",
    ],
)
```*
nameA unique name for this target. �
minimum_os_version�A required string indicating the minimum OS version that will be used as the
deployment target when building the targets, represented as a dotted version
number (for example, `"9.0"`). ;
targets*The targets to check for successful build.2[]
platform_type2	"watchos""5
watchos_build_test@rules_apple//apple:watchos.bzl08,
*
nameA unique name for this target. �
�
minimum_os_version�A required string indicating the minimum OS version that will be used as the
deployment target when building the targets, represented as a dotted version
number (for example, `"9.0"`). =
;
targets*The targets to check for successful build.2[]

platform_type2	"watchos"�\watchos_unit_testwatchOS Unit Test rule.Z�\
�.
watchos_unit_testwatchOS Unit Test rule.�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2""�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2"bundle_name"�
bundle_name�The desired name of the test bundle (without the extension). If this attribute is not set, then the
name of the target will be used instead.2""8�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]j
familiesQA list of device families supported by this rule. At least one must be specified.2	["watch"]�

frameworks8A list of framework targets that this target depends on.*�
AppleBundleInfo
WatchosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl?
WatchosFrameworkBundleInfo!@rules_apple//apple:providers.bzl2[]�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. If not provided,
a default Info.plist will be used. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported.26["@rules_apple//apple/testing:DefaultTestBundlePlist"]a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.20J-1J0J1�
runner2A single runner target to use for the test target.2C"@rules_apple//apple/testing/default_runner:watchos_default_runner"
expect_failure2None@ 
transitive_configs2None8@
deprecation2None8@
tags2None8@
testonly2None8@
features2None@
compatible_with2None8@
restricted_to2None8@
package_metadata2None8@
aspect_hints2None@P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@
exec_properties
2None@"
exec_compatible_with2None8@(
exec_group_compatible_with2None8@Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@
size2None8@
timeout2None8@
flaky2None8@
shard_count2None@
local2None8@
args2None@q
collect_code_coveragePWhether to collect code coverage for this test if `--collect_code_coverage=yes`.2NoneL
data<Files to be made available to the test during its execution.2None�
env�Dictionary of environment variables that should be set during the test execution. The values of
the dictionary are subject to "Make" variable expansion.
2None^
env_inheritGList of environment variables to inherit from the external environment.2Noner
test_filter[Test filter string that will be passed into the test runner to select which tests will run.2None�
test_coverage_manifesteA file that will be used in lcov export calls to limit the scope of files instrumented with coverage.2None�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None
platform_type2Nonee
	test_host*P
AppleBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl2None�
test_host_is_bundle_loaderpWhether the 'test_host' should be used as the -bundle_loader to allow testing
the symbols from the test host app2None"4
watchos_unit_test@rules_apple//apple:watchos.bzl�
�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �
�

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@U
S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2""�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2"bundle_name"�
�
bundle_name�The desired name of the test bundle (without the extension). If this attribute is not set, then the
name of the target will be used instead.2""8�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]l
j
familiesQA list of device families supported by this rule. At least one must be specified.2	["watch"]�
�

frameworks8A list of framework targets that this target depends on.*�
AppleBundleInfo
WatchosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl?
WatchosFrameworkBundleInfo!@rules_apple//apple:providers.bzl2[]�
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. If not provided,
a default Info.plist will be used. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported.26["@rules_apple//apple/testing:DefaultTestBundlePlist"]c
a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]�
�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.20J-1J0J1�
�
runner2A single runner target to use for the test target.2C"@rules_apple//apple/testing/default_runner:watchos_default_runner"

expect_failure2None@"
 
transitive_configs2None8@

deprecation2None8@

tags2None8@

testonly2None8@

features2None@

compatible_with2None8@

restricted_to2None8@ 

package_metadata2None8@

aspect_hints2None@R
P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@

exec_properties
2None@$
"
exec_compatible_with2None8@*
(
exec_group_compatible_with2None8@\
Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@

size2None8@

timeout2None8@

flaky2None8@

shard_count2None@

local2None8@

args2None@s
q
collect_code_coveragePWhether to collect code coverage for this test if `--collect_code_coverage=yes`.2NoneN
L
data<Files to be made available to the test during its execution.2None�
�
env�Dictionary of environment variables that should be set during the test execution. The values of
the dictionary are subject to "Make" variable expansion.
2None`
^
env_inheritGList of environment variables to inherit from the external environment.2Nonet
r
test_filter[Test filter string that will be passed into the test runner to select which tests will run.2None�
�
test_coverage_manifesteA file that will be used in lcov export calls to limit the scope of files instrumented with coverage.2None�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None

platform_type2Noneg
e
	test_host*P
AppleBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl2None�
�
test_host_is_bundle_loaderpWhether the 'test_host' should be used as the -bundle_loader to allow testing
the symbols from the test host app2None�\watchos_ui_testwatchOS UI Test rule.Z�\
�.
watchos_ui_testwatchOS UI Test rule.�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2""�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2"bundle_name"�
bundle_name�The desired name of the test bundle (without the extension). If this attribute is not set, then the
name of the target will be used instead.2""8�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]j
familiesQA list of device families supported by this rule. At least one must be specified.2	["watch"]�

frameworks8A list of framework targets that this target depends on.*�
AppleBundleInfo
WatchosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl?
WatchosFrameworkBundleInfo!@rules_apple//apple:providers.bzl2[]�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. If not provided,
a default Info.plist will be used. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported.26["@rules_apple//apple/testing:DefaultTestBundlePlist"]a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.20J-1J0J1�
runner2A single runner target to use for the test target.2C"@rules_apple//apple/testing/default_runner:watchos_default_runner"
expect_failure2None@ 
transitive_configs2None8@
deprecation2None8@
tags2None8@
testonly2None8@
features2None@
compatible_with2None8@
restricted_to2None8@
package_metadata2None8@
aspect_hints2None@P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@
exec_properties
2None@"
exec_compatible_with2None8@(
exec_group_compatible_with2None8@Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@
size2None8@
timeout2None8@
flaky2None8@
shard_count2None@
local2None8@
args2None@q
collect_code_coveragePWhether to collect code coverage for this test if `--collect_code_coverage=yes`.2NoneL
data<Files to be made available to the test during its execution.2None�
env�Dictionary of environment variables that should be set during the test execution. The values of
the dictionary are subject to "Make" variable expansion.
2None^
env_inheritGList of environment variables to inherit from the external environment.2Noner
test_filter[Test filter string that will be passed into the test runner to select which tests will run.2None�
test_coverage_manifesteA file that will be used in lcov export calls to limit the scope of files instrumented with coverage.2None�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None
platform_type2Nonee
	test_host*P
AppleBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl2None�
test_host_is_bundle_loaderpWhether the 'test_host' should be used as the -bundle_loader to allow testing
the symbols from the test host app2None"2
watchos_ui_test@rules_apple//apple:watchos.bzl�
�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �
�

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@U
S
additional_linker_inputs1A list of input files to be passed to the linker.2[]�
�
base_bundle_iddThe base bundle ID rule to dictate the form that a given bundle rule's bundle ID prefix should take.*\
AppleBaseBundleIdInfoC
AppleBaseBundleIdInfo*@rules_apple//apple/internal:providers.bzl2None�
�
	bundle_id�The bundle ID (reverse-DNS path followed by app name) for this target. Only use this attribute if
the bundle ID is not intended to be composed through an assigned base bundle ID referenced by
`base_bundle_id`.2""�
�
bundle_id_suffix�A string to act as the suffix of the composed bundle ID. If this target's bundle ID is composed from
the base bundle ID rule referenced by `base_bundle_id`, then this string will be appended to the end
of the bundle ID following a "." separator.2"bundle_name"�
�
bundle_name�The desired name of the test bundle (without the extension). If this attribute is not set, then the
name of the target will be used instead.2""8�
�
deps�A list of dependent targets that will be linked into this target's binary(s). Any resources, such as
asset catalogs, that are referenced by those targets will also be transitively included in the final
bundle(s).2[]l
j
familiesQA list of device families supported by this rule. At least one must be specified.2	["watch"]�
�

frameworks8A list of framework targets that this target depends on.*�
AppleBundleInfo
WatchosFrameworkBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl?
WatchosFrameworkBundleInfo!@rules_apple//apple:providers.bzl2[]�
�

infoplists�A list of .plist files that will be merged to form the Info.plist for this target. If not provided,
a default Info.plist will be used. Please see
[Info.plist Handling](https://github.com/bazelbuild/rules_apple/blob/main/doc/common_info.md#infoplist-handling)
for what is supported.26["@rules_apple//apple/testing:DefaultTestBundlePlist"]c
a
linkoptsOA list of strings representing extra flags that should be passed to the linker.2[]�
�
provisioning_profile�The provisioning profile (`.mobileprovision` file) to use when creating the bundle. This value is
optional for simulator builds as the simulator doesn't fully enforce entitlements, but is
required for device builds.2None�
�
	resources�A list of resources or files bundled with the bundle. The resources will be stored in the
appropriate resources location within the bundle.2[]�
�
stamp�Enable link stamping. Whether to encode build information into the binary. Possible values:

*   `stamp = 1`: Stamp the build information into the binary. Stamped binaries are only rebuilt
    when their dependencies change. Use this if there are tests that depend on the build
    information.
*   `stamp = 0`: Always replace build information by constant values. This gives good build
    result caching.
*   `stamp = -1`: Embedding of build information is controlled by the `--[no]stamp` flag.20J-1J0J1�
�
runner2A single runner target to use for the test target.2C"@rules_apple//apple/testing/default_runner:watchos_default_runner"

expect_failure2None@"
 
transitive_configs2None8@

deprecation2None8@

tags2None8@

testonly2None8@

features2None@

compatible_with2None8@

restricted_to2None8@ 

package_metadata2None8@

aspect_hints2None@R
P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@

exec_properties
2None@$
"
exec_compatible_with2None8@*
(
exec_group_compatible_with2None8@\
Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@

size2None8@

timeout2None8@

flaky2None8@

shard_count2None@

local2None8@

args2None@s
q
collect_code_coveragePWhether to collect code coverage for this test if `--collect_code_coverage=yes`.2NoneN
L
data<Files to be made available to the test during its execution.2None�
�
env�Dictionary of environment variables that should be set during the test execution. The values of
the dictionary are subject to "Make" variable expansion.
2None`
^
env_inheritGList of environment variables to inherit from the external environment.2Nonet
r
test_filter[Test filter string that will be passed into the test runner to select which tests will run.2None�
�
test_coverage_manifesteA file that will be used in lcov export calls to limit the scope of files instrumented with coverage.2None�
�
minimum_os_version�A required string indicating the minimum OS version supported by the target, represented as a
dotted version number (for example, "9.0"). �
�
minimum_deployment_os_version�A required string indicating the minimum deployment OS version supported by the target, represented
as a dotted version number (for example, "9.0"). This is different from `minimum_os_version`, which
is effective at compile time. Ensure version specific APIs are guarded with `available` clauses.2None

platform_type2Noneg
e
	test_host*P
AppleBundleInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzl2None�
�
test_host_is_bundle_loaderpWhether the 'test_host' should be used as the -bundle_loader to allow testing
the symbols from the test host app2None<# Bazel rules for creating watchOS applications and bundles.�
#
rules_appleapplexcarchive.bzl�	xcarchive�Re-packages an Apple bundle into a .xcarchive.

This rule uses the providers from the bundle target to construct the required
metadata for the .xcarchive.

Example:

````starlark
load("//apple:xcarchive.bzl", "xcarchive")

ios_application(
    name = "App",
    bundle_id = "com.example.my.app",
    ...
)

xcarchive(
    name = "App.xcarchive",
    bundle = ":App",
)
````"�

�
	xcarchive�Re-packages an Apple bundle into a .xcarchive.

This rule uses the providers from the bundle target to construct the required
metadata for the .xcarchive.

Example:

````starlark
load("//apple:xcarchive.bzl", "xcarchive")

ios_application(
    name = "App",
    bundle_id = "com.example.my.app",
    ...
)

xcarchive(
    name = "App.xcarchive",
    bundle = ":App",
)
````*
nameA unique name for this target. �
bundle`The label to a target to re-package into a .xcarchive. For example, an
`ios_application` target.*�
AppleBundleInfo
AppleDsymBundleInfo
AppleDebugInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlA
AppleDsymBundleInfo*@rules_apple//apple/internal:providers.bzlM
AppleDebugInfo;@rules_apple//apple/internal/providers:apple_debug_info.bzl2None"7
	xcarchive*@rules_apple//apple/internal:xcarchive.bzl,
*
nameA unique name for this target. �
�
bundle`The label to a target to re-package into a .xcarchive. For example, an
`ios_application` target.*�
AppleBundleInfo
AppleDsymBundleInfo
AppleDebugInfo=
AppleBundleInfo*@rules_apple//apple/internal:providers.bzlA
AppleDsymBundleInfo*@rules_apple//apple/internal:providers.bzlM
AppleDebugInfo;@rules_apple//apple/internal/providers:apple_debug_info.bzl2None"Rules for creating Xcode archives.�
#
rules_appleapplexctrunner.bzl�	xctrunner�Packages one or more .xctest bundles into a XCTRunner.app. Retains same
platform and architectures as the given `tests` bundles.

Example:

````starlark
load("//apple:xctrunner.bzl", "xctrunner")

ios_ui_test(
    name = "HelloWorldSwiftUITests",
    minimum_os_version = "15.0",
    runner = "@rules_apple//apple/testing/default_runner:ios_xctestrun_ordered_runner",
    test_host = ":HelloWorldSwift",
    deps = [":UITests"],
)

xctrunner(
    name = "HelloWorldSwiftXCTRunner",
    tests = [":HelloWorldSwiftUITests"],
    testonly = True,
)
````"�
�
	xctrunner�Packages one or more .xctest bundles into a XCTRunner.app. Retains same
platform and architectures as the given `tests` bundles.

Example:

````starlark
load("//apple:xctrunner.bzl", "xctrunner")

ios_ui_test(
    name = "HelloWorldSwiftUITests",
    minimum_os_version = "15.0",
    runner = "@rules_apple//apple/testing/default_runner:ios_xctestrun_ordered_runner",
    test_host = ":HelloWorldSwift",
    deps = [":UITests"],
)

xctrunner(
    name = "HelloWorldSwiftXCTRunner",
    tests = [":HelloWorldSwiftUITests"],
    testonly = True,
)
````*
nameA unique name for this target. 8
tests+List of test targets and suites to include. =
verbose)Print logs from xctrunnertool to console.2False"7
	xctrunner*@rules_apple//apple/internal:xctrunner.bzl,
*
nameA unique name for this target. :
8
tests+List of test targets and suites to include. ?
=
verbose)Print logs from xctrunnertool to console.2False�Rule for creating a XCTRunner.app with one or more .xctest bundles. Retains same
platform and architectures as the given `tests` bundles. 