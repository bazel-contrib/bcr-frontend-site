�
auto_dotnetdefs.bzl�dotnet_generated_props�Generate a .props file to sync IDE with Bazel-generated sources.

This creates a .props file containing `<Compile Include="...">` elements for
Bazel-generated source files. The .props file can be imported into a .csproj
to enable IDE features (IntelliSense, Go to Definition) for generated code.

Usage in BUILD.bazel:
```
load("@rules_dotnet//dotnet:defs.bzl", "dotnet_generated_props")

proto_csharp_library(
    name = "my_protos",
    protos = ["//proto:services"],
)

dotnet_generated_props(
    name = "sync_ide",
    generated_srcs = [":my_protos"],
    out = "MyProject.Generated.props",
)
```

Usage in .csproj:
```xml
<Project Sdk="Microsoft.NET.Sdk">
  <Import Project="MyProject.Generated.props"
          Condition="Exists('MyProject.Generated.props')" />
</Project>
```

To update the .props file:
```bash
bazel run //:sync_ide
```
*�
�
dotnet_generated_propsM
nameATarget name. Use this with `bazel run` to update the .props file. (E
generated_srcs/List of labels to Bazel-generated source files. (P
outAOutput filename (default: "{name}.props" in the current package).None(]
suggested_update_target:Override the update target shown in the generated comment.None(=
kwargs1Additional arguments passed to write_source_file.(�Generate a .props file to sync IDE with Bazel-generated sources.

This creates a .props file containing `<Compile Include="...">` elements for
Bazel-generated source files. The .props file can be imported into a .csproj
to enable IDE features (IntelliSense, Go to Definition) for generated code.

Usage in BUILD.bazel:
```
load("@rules_dotnet//dotnet:defs.bzl", "dotnet_generated_props")

proto_csharp_library(
    name = "my_protos",
    protos = ["//proto:services"],
)

dotnet_generated_props(
    name = "sync_ide",
    generated_srcs = [":my_protos"],
    out = "MyProject.Generated.props",
)
```

Usage in .csproj:
```xml
<Project Sdk="Microsoft.NET.Sdk">
  <Import Project="MyProject.Generated.props"
          Condition="Exists('MyProject.Generated.props')" />
</Project>
```

To update the .props file:
```bash
bazel run //:sync_ide
```
"�
�Creates two targets:
- {name}_content: The generated .props content
- {name}: The write_source_file target to sync the checked-in file2C
dotnet_generated_props)//auto_dotnet/private:generated_props.bzlO
M
nameATarget name. Use this with `bazel run` to update the .props file. (G
E
generated_srcs/List of labels to Bazel-generated source files. (R
P
outAOutput filename (default: "{name}.props" in the current package).None(_
]
suggested_update_target:Override the update target shown in the generated comment.None(?
=
kwargs1Additional arguments passed to write_source_file.(�dotnet_generated_props_test�Test that a .props file is up-to-date with generated sources.

This is the test-only version that fails if the .props file needs updating.
Use in CI to ensure generated files are committed.
*�
�
dotnet_generated_props_test
nameTarget name. (E
generated_srcs/List of labels to Bazel-generated source files. ($
outThe .props file to check. (=
kwargs1Additional arguments passed to write_source_file.(�Test that a .props file is up-to-date with generated sources.

This is the test-only version that fails if the .props file needs updating.
Use in CI to ensure generated files are committed.
2H
dotnet_generated_props_test)//auto_dotnet/private:generated_props.bzl

nameTarget name. (G
E
generated_srcs/List of labels to Bazel-generated source files. (&
$
outThe .props file to check. (?
=
kwargs1Additional arguments passed to write_source_file.(aPublic API surface is re-exported here.

Users should not load files under "/auto_dotnet/private"�M
auto_dotnetextensions.bzl�Mauto_dotnet�Extension for automatic .NET project scanning and Bazel target generation.

This extension scans .csproj and .fsproj files in your workspace and generates
Bazel targets using rules_dotnet. Use alongside @rules_dotnet for toolchain
registration and build rules.J�J
�
auto_dotnet�Extension for automatic .NET project scanning and Bazel target generation.

This extension scans .csproj and .fsproj files in your workspace and generates
Bazel targets using rules_dotnet. Use alongside @rules_dotnet for toolchain
registration and build rules.�
	toolchain�Declare a .NET toolchain version.

These declarations are used by scan_projects to validate that registered
toolchains cover all discovered target frameworks. The actual toolchain
registration should be done via rules_dotnet's extension.8
name$Base name for generated repositories2"dotnet"/
dotnet_versionVersion of the .Net SDK2""�
scan_projects�
Enable automatic scanning of .csproj and .fsproj files.

When enabled, the extension will:
1. Scan the workspace for .csproj and .fsproj files
2. Parse each file to extract properties, sources, and dependencies
3. Generate a @dotnet_projects repository with .bzl files for each project
4. Validate that registered toolchains cover all discovered target frameworks

Usage in MODULE.bazel:
    dotnet = use_extension("@rules_dotnet//dotnet:extensions.bzl", "dotnet")
    dotnet.toolchain(dotnet_version = "10.0.100")
    use_repo(dotnet, "dotnet_toolchains")
    register_toolchains("@dotnet_toolchains//:all")

    auto_dotnet = use_extension("@rules_auto_dotnet//auto_dotnet:extensions.bzl", "auto_dotnet")
    auto_dotnet.toolchain(dotnet_version = "10.0.100")
    auto_dotnet.scan_projects()
    use_repo(auto_dotnet, "dotnet_projects")

Usage in BUILD files:
    load("@dotnet_projects//path/to:MyProject.csproj.bzl", "auto_dotnet_targets")
    auto_dotnet_targets(name = "MyProject")

File Change Detection:
    Changes to existing .csproj/.fsproj files are automatically detected.
    New files in existing project directories are also detected.

    However, new project files in entirely new directories require manual sync:
        bazel sync --only=@dotnet_projects

Requirements:
    Bazel 7.1 or later is required for the scan_projects feature.�
exclude_patterns}Glob patterns for paths to exclude from scanning.

Default patterns exclude bin/, obj/, .git/, .jj/, and bazel-* directories.2[]�
nuget_repo_nameiName of the NuGet repository to generate.

Packages can be referenced as @{nuget_repo_name}//PackageName.2"dotnet_projects.nuget"�
fail_on_missing_toolchain�If true, fail when a project targets a TFM not covered by registered toolchains.

Set to false to only emit warnings instead of failing.2True�
toolchain_diagnostics�Severity for toolchain coverage diagnostics.

Allowed values: "off", "warn", "strict".
- off: do not emit toolchain diagnostics
- warn: emit warnings and continue (default)
- strict: fail after collecting diagnostics2"warn"�
parser_diagnostics�Severity for project parsing diagnostics.

Allowed values: "off", "warn", "strict".
- off: ignore parse diagnostics
- warn: emit warnings and continue (default)
- strict: fail after collecting diagnostics2"warn"�
paket_diagnostics�Severity for Paket diagnostics.

Allowed values: "off", "warn", "strict".
- off: ignore Paket diagnostics
- warn: emit warnings and continue (default)
- strict: fail after collecting diagnostics2"warn"�
(paket_references_strict_mode_diagnostics�Severity for enforcing `references: strict!` in paket.dependencies.

Allowed values: "off", "warn", "strict".
- off: do not enforce strict! adoption
- warn: emit warning and continue
- strict: fail after collecting diagnostics (default)2"strict"�
 internals_visibility_diagnostics�Severity for InternalsVisibleTo diagnostics.

Allowed values: "off", "warn", "strict".
- off: ignore internals visibility diagnostics
- warn: emit warnings and continue (default)
- strict: fail after collecting diagnostics2"warn"m
emit_diagnostics_reportJIf true, generate DIAGNOSTICS.md and diagnostics.json in @dotnet_projects.2True"//auto_dotnet:extensions.bzl�
�
	toolchain�Declare a .NET toolchain version.

These declarations are used by scan_projects to validate that registered
toolchains cover all discovered target frameworks. The actual toolchain
registration should be done via rules_dotnet's extension.8
name$Base name for generated repositories2"dotnet"/
dotnet_versionVersion of the .Net SDK2"":
8
name$Base name for generated repositories2"dotnet"1
/
dotnet_versionVersion of the .Net SDK2""�(
�
scan_projects�
Enable automatic scanning of .csproj and .fsproj files.

When enabled, the extension will:
1. Scan the workspace for .csproj and .fsproj files
2. Parse each file to extract properties, sources, and dependencies
3. Generate a @dotnet_projects repository with .bzl files for each project
4. Validate that registered toolchains cover all discovered target frameworks

Usage in MODULE.bazel:
    dotnet = use_extension("@rules_dotnet//dotnet:extensions.bzl", "dotnet")
    dotnet.toolchain(dotnet_version = "10.0.100")
    use_repo(dotnet, "dotnet_toolchains")
    register_toolchains("@dotnet_toolchains//:all")

    auto_dotnet = use_extension("@rules_auto_dotnet//auto_dotnet:extensions.bzl", "auto_dotnet")
    auto_dotnet.toolchain(dotnet_version = "10.0.100")
    auto_dotnet.scan_projects()
    use_repo(auto_dotnet, "dotnet_projects")

Usage in BUILD files:
    load("@dotnet_projects//path/to:MyProject.csproj.bzl", "auto_dotnet_targets")
    auto_dotnet_targets(name = "MyProject")

File Change Detection:
    Changes to existing .csproj/.fsproj files are automatically detected.
    New files in existing project directories are also detected.

    However, new project files in entirely new directories require manual sync:
        bazel sync --only=@dotnet_projects

Requirements:
    Bazel 7.1 or later is required for the scan_projects feature.�
exclude_patterns}Glob patterns for paths to exclude from scanning.

Default patterns exclude bin/, obj/, .git/, .jj/, and bazel-* directories.2[]�
nuget_repo_nameiName of the NuGet repository to generate.

Packages can be referenced as @{nuget_repo_name}//PackageName.2"dotnet_projects.nuget"�
fail_on_missing_toolchain�If true, fail when a project targets a TFM not covered by registered toolchains.

Set to false to only emit warnings instead of failing.2True�
toolchain_diagnostics�Severity for toolchain coverage diagnostics.

Allowed values: "off", "warn", "strict".
- off: do not emit toolchain diagnostics
- warn: emit warnings and continue (default)
- strict: fail after collecting diagnostics2"warn"�
parser_diagnostics�Severity for project parsing diagnostics.

Allowed values: "off", "warn", "strict".
- off: ignore parse diagnostics
- warn: emit warnings and continue (default)
- strict: fail after collecting diagnostics2"warn"�
paket_diagnostics�Severity for Paket diagnostics.

Allowed values: "off", "warn", "strict".
- off: ignore Paket diagnostics
- warn: emit warnings and continue (default)
- strict: fail after collecting diagnostics2"warn"�
(paket_references_strict_mode_diagnostics�Severity for enforcing `references: strict!` in paket.dependencies.

Allowed values: "off", "warn", "strict".
- off: do not enforce strict! adoption
- warn: emit warning and continue
- strict: fail after collecting diagnostics (default)2"strict"�
 internals_visibility_diagnostics�Severity for InternalsVisibleTo diagnostics.

Allowed values: "off", "warn", "strict".
- off: ignore internals visibility diagnostics
- warn: emit warnings and continue (default)
- strict: fail after collecting diagnostics2"warn"m
emit_diagnostics_reportJIf true, generate DIAGNOSTICS.md and diagnostics.json in @dotnet_projects.2True�
�
exclude_patterns}Glob patterns for paths to exclude from scanning.

Default patterns exclude bin/, obj/, .git/, .jj/, and bazel-* directories.2[]�
�
nuget_repo_nameiName of the NuGet repository to generate.

Packages can be referenced as @{nuget_repo_name}//PackageName.2"dotnet_projects.nuget"�
�
fail_on_missing_toolchain�If true, fail when a project targets a TFM not covered by registered toolchains.

Set to false to only emit warnings instead of failing.2True�
�
toolchain_diagnostics�Severity for toolchain coverage diagnostics.

Allowed values: "off", "warn", "strict".
- off: do not emit toolchain diagnostics
- warn: emit warnings and continue (default)
- strict: fail after collecting diagnostics2"warn"�
�
parser_diagnostics�Severity for project parsing diagnostics.

Allowed values: "off", "warn", "strict".
- off: ignore parse diagnostics
- warn: emit warnings and continue (default)
- strict: fail after collecting diagnostics2"warn"�
�
paket_diagnostics�Severity for Paket diagnostics.

Allowed values: "off", "warn", "strict".
- off: ignore Paket diagnostics
- warn: emit warnings and continue (default)
- strict: fail after collecting diagnostics2"warn"�
�
(paket_references_strict_mode_diagnostics�Severity for enforcing `references: strict!` in paket.dependencies.

Allowed values: "off", "warn", "strict".
- off: do not enforce strict! adoption
- warn: emit warning and continue
- strict: fail after collecting diagnostics (default)2"strict"�
�
 internals_visibility_diagnostics�Severity for InternalsVisibleTo diagnostics.

Allowed values: "off", "warn", "strict".
- off: ignore internals visibility diagnostics
- warn: emit warnings and continue (default)
- strict: fail after collecting diagnostics2"warn"o
m
emit_diagnostics_reportJIf true, generate DIAGNOSTICS.md and diagnostics.json in @dotnet_projects.2TrueExtensions for bzlmod 