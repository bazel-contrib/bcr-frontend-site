�

repo.bzl�bittorrent_file�Downloads a single file from a torrent.

The file is available as `@<name>//:file`, and is exported under its own
file name.

Example, in `MODULE.bazel`:

```starlark
bittorrent_file = use_repo_rule("@rules_bittorrent//:repo.bzl", "bittorrent_file")

bittorrent_file(
    name = "my_file",
    uri = "magnet:?xt=urn:btih:...",
    integrity = "...",
)
```R�
�
bittorrent_file�Downloads a single file from a torrent.

The file is available as `@<name>//:file`, and is exported under its own
file name.

Example, in `MODULE.bazel`:

```starlark
bittorrent_file = use_repo_rule("@rules_bittorrent//:repo.bzl", "bittorrent_file")

bittorrent_file(
    name = "my_file",
    uri = "magnet:?xt=urn:btih:...",
    integrity = "...",
)
```.
name"A unique name for this repository. T
timeout?The timeout in seconds for the download, over all its attempts.2200000�
attempt_timeout�How long, in seconds, one run of rain may take.

rain sometimes never exits after it has downloaded the whole file
(https://github.com/filmil/bazel_rules_bt/issues/49). So rain runs for at
most this long at a time, and after each run the file is checked against
`integrity`:

* a matching file ends the fetch, whether or not rain exited;
* if rain exited, or the file did not change over a whole run (rain is
  done or stuck), the fetch fails, and a file that differs from
  `integrity` is reported with both hashes;
* otherwise rain runs again and resumes where it stopped.

`timeout` bounds the sum of the runs' limits; the checks between runs come
on top. A fetch that runs out of `timeout` keeps rain's resume file, so the
next fetch resumes.2120�
	integrity�The expected hash of the downloaded file, in Subresource Integrity form: `sha256-` followed by the base64 of the SHA-256 digest (`sha384-` and `sha512-` also work).

The fetch fails if the file rain downloads does not have this hash, and the error shows both values. To get the value for a new file, set any well-formed wrong value, for example `sha256-AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=`, and copy the hash the error reports. ;
quiet*Whether to omit printing download progress2TrueB
file4The name of the file to use for the downloaded file.2""5
uri*The torrent URI to download the file from. *
bittorrent_file//:repo.bzl0
.
name"A unique name for this repository. V
T
timeout?The timeout in seconds for the download, over all its attempts.2200000�
�
attempt_timeout�How long, in seconds, one run of rain may take.

rain sometimes never exits after it has downloaded the whole file
(https://github.com/filmil/bazel_rules_bt/issues/49). So rain runs for at
most this long at a time, and after each run the file is checked against
`integrity`:

* a matching file ends the fetch, whether or not rain exited;
* if rain exited, or the file did not change over a whole run (rain is
  done or stuck), the fetch fails, and a file that differs from
  `integrity` is reported with both hashes;
* otherwise rain runs again and resumes where it stopped.

`timeout` bounds the sum of the runs' limits; the checks between runs come
on top. A fetch that runs out of `timeout` keeps rain's resume file, so the
next fetch resumes.2120�
�
	integrity�The expected hash of the downloaded file, in Subresource Integrity form: `sha256-` followed by the base64 of the SHA-256 digest (`sha384-` and `sha512-` also work).

The fetch fails if the file rain downloads does not have this hash, and the error shows both values. To get the value for a new file, set any well-formed wrong value, for example `sha256-AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=`, and copy the hash the error reports. =
;
quiet*Whether to omit printing download progress2TrueD
B
file4The name of the file to use for the downloaded file.2""7
5
uri*The torrent URI to download the file from. �&bittorrent_archive�Downloads an archive from a torrent, and extracts it.

The repository gets a `BUILD.bazel` file with `build_file_content` as its
content. `{name}` in that content is replaced by the downloaded file name.

Example, in `MODULE.bazel`:

```starlark
bittorrent_archive = use_repo_rule("@rules_bittorrent//:repo.bzl", "bittorrent_archive")

bittorrent_archive(
    name = "my_archive",
    uri = "magnet:?xt=urn:btih:...",
    integrity = "...",
    strip_prefix = "my_archive-1.0",
    build_file_content = """
filegroup(
    name = "files",
    srcs = glob(["**"]),
    visibility = ["//visibility:public"],
)
""",
)
```R�!
�
bittorrent_archive�Downloads an archive from a torrent, and extracts it.

The repository gets a `BUILD.bazel` file with `build_file_content` as its
content. `{name}` in that content is replaced by the downloaded file name.

Example, in `MODULE.bazel`:

```starlark
bittorrent_archive = use_repo_rule("@rules_bittorrent//:repo.bzl", "bittorrent_archive")

bittorrent_archive(
    name = "my_archive",
    uri = "magnet:?xt=urn:btih:...",
    integrity = "...",
    strip_prefix = "my_archive-1.0",
    build_file_content = """
filegroup(
    name = "files",
    srcs = glob(["**"]),
    visibility = ["//visibility:public"],
)
""",
)
```.
name"A unique name for this repository. T
timeout?The timeout in seconds for the download, over all its attempts.2200000�
attempt_timeout�How long, in seconds, one run of rain may take.

rain sometimes never exits after it has downloaded the whole file
(https://github.com/filmil/bazel_rules_bt/issues/49). So rain runs for at
most this long at a time, and after each run the file is checked against
`integrity`:

* a matching file ends the fetch, whether or not rain exited;
* if rain exited, or the file did not change over a whole run (rain is
  done or stuck), the fetch fails, and a file that differs from
  `integrity` is reported with both hashes;
* otherwise rain runs again and resumes where it stopped.

`timeout` bounds the sum of the runs' limits; the checks between runs come
on top. A fetch that runs out of `timeout` keeps rain's resume file, so the
next fetch resumes.2120�
	integrity�The expected hash of the downloaded file, in Subresource Integrity form: `sha256-` followed by the base64 of the SHA-256 digest (`sha384-` and `sha512-` also work).

The fetch fails if the file rain downloads does not have this hash, and the error shows both values. To get the value for a new file, set any well-formed wrong value, for example `sha256-AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=`, and copy the hash the error reports. ;
quiet*Whether to omit printing download progress2TrueB
file4The name of the file to use for the downloaded file.2""5
uri*The torrent URI to download the file from. L
build_file_content2The content of the build file to place in the repo M
strip_prefix7The prefix (directory) within the archive to strip away2""l
extractYWhether to extract the downloaded torrent (torrent with multiple files may not need this)2True*!
bittorrent_archive//:repo.bzl0
.
name"A unique name for this repository. V
T
timeout?The timeout in seconds for the download, over all its attempts.2200000�
�
attempt_timeout�How long, in seconds, one run of rain may take.

rain sometimes never exits after it has downloaded the whole file
(https://github.com/filmil/bazel_rules_bt/issues/49). So rain runs for at
most this long at a time, and after each run the file is checked against
`integrity`:

* a matching file ends the fetch, whether or not rain exited;
* if rain exited, or the file did not change over a whole run (rain is
  done or stuck), the fetch fails, and a file that differs from
  `integrity` is reported with both hashes;
* otherwise rain runs again and resumes where it stopped.

`timeout` bounds the sum of the runs' limits; the checks between runs come
on top. A fetch that runs out of `timeout` keeps rain's resume file, so the
next fetch resumes.2120�
�
	integrity�The expected hash of the downloaded file, in Subresource Integrity form: `sha256-` followed by the base64 of the SHA-256 digest (`sha384-` and `sha512-` also work).

The fetch fails if the file rain downloads does not have this hash, and the error shows both values. To get the value for a new file, set any well-formed wrong value, for example `sha256-AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=`, and copy the hash the error reports. =
;
quiet*Whether to omit printing download progress2TrueD
B
file4The name of the file to use for the downloaded file.2""7
5
uri*The torrent URI to download the file from. N
L
build_file_content2The content of the build file to place in the repo O
M
strip_prefix7The prefix (directory) within the archive to strip away2""n
l
extractYWhether to extract the downloaded torrent (torrent with multiple files may not need this)2True�bt_file�Downloads a single file from a torrent.

The file is available as `@<name>//:file`, and is exported under its own
file name.

Example, in `MODULE.bazel`:

```starlark
bittorrent_file = use_repo_rule("@rules_bittorrent//:repo.bzl", "bittorrent_file")

bittorrent_file(
    name = "my_file",
    uri = "magnet:?xt=urn:btih:...",
    integrity = "...",
)
```R�
�
bt_file�Downloads a single file from a torrent.

The file is available as `@<name>//:file`, and is exported under its own
file name.

Example, in `MODULE.bazel`:

```starlark
bittorrent_file = use_repo_rule("@rules_bittorrent//:repo.bzl", "bittorrent_file")

bittorrent_file(
    name = "my_file",
    uri = "magnet:?xt=urn:btih:...",
    integrity = "...",
)
```.
name"A unique name for this repository. T
timeout?The timeout in seconds for the download, over all its attempts.2200000�
attempt_timeout�How long, in seconds, one run of rain may take.

rain sometimes never exits after it has downloaded the whole file
(https://github.com/filmil/bazel_rules_bt/issues/49). So rain runs for at
most this long at a time, and after each run the file is checked against
`integrity`:

* a matching file ends the fetch, whether or not rain exited;
* if rain exited, or the file did not change over a whole run (rain is
  done or stuck), the fetch fails, and a file that differs from
  `integrity` is reported with both hashes;
* otherwise rain runs again and resumes where it stopped.

`timeout` bounds the sum of the runs' limits; the checks between runs come
on top. A fetch that runs out of `timeout` keeps rain's resume file, so the
next fetch resumes.2120�
	integrity�The expected hash of the downloaded file, in Subresource Integrity form: `sha256-` followed by the base64 of the SHA-256 digest (`sha384-` and `sha512-` also work).

The fetch fails if the file rain downloads does not have this hash, and the error shows both values. To get the value for a new file, set any well-formed wrong value, for example `sha256-AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=`, and copy the hash the error reports. ;
quiet*Whether to omit printing download progress2TrueB
file4The name of the file to use for the downloaded file.2""5
uri*The torrent URI to download the file from. *
bittorrent_file//:repo.bzl0
.
name"A unique name for this repository. V
T
timeout?The timeout in seconds for the download, over all its attempts.2200000�
�
attempt_timeout�How long, in seconds, one run of rain may take.

rain sometimes never exits after it has downloaded the whole file
(https://github.com/filmil/bazel_rules_bt/issues/49). So rain runs for at
most this long at a time, and after each run the file is checked against
`integrity`:

* a matching file ends the fetch, whether or not rain exited;
* if rain exited, or the file did not change over a whole run (rain is
  done or stuck), the fetch fails, and a file that differs from
  `integrity` is reported with both hashes;
* otherwise rain runs again and resumes where it stopped.

`timeout` bounds the sum of the runs' limits; the checks between runs come
on top. A fetch that runs out of `timeout` keeps rain's resume file, so the
next fetch resumes.2120�
�
	integrity�The expected hash of the downloaded file, in Subresource Integrity form: `sha256-` followed by the base64 of the SHA-256 digest (`sha384-` and `sha512-` also work).

The fetch fails if the file rain downloads does not have this hash, and the error shows both values. To get the value for a new file, set any well-formed wrong value, for example `sha256-AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=`, and copy the hash the error reports. =
;
quiet*Whether to omit printing download progress2TrueD
B
file4The name of the file to use for the downloaded file.2""7
5
uri*The torrent URI to download the file from. �&
bt_archive�Downloads an archive from a torrent, and extracts it.

The repository gets a `BUILD.bazel` file with `build_file_content` as its
content. `{name}` in that content is replaced by the downloaded file name.

Example, in `MODULE.bazel`:

```starlark
bittorrent_archive = use_repo_rule("@rules_bittorrent//:repo.bzl", "bittorrent_archive")

bittorrent_archive(
    name = "my_archive",
    uri = "magnet:?xt=urn:btih:...",
    integrity = "...",
    strip_prefix = "my_archive-1.0",
    build_file_content = """
filegroup(
    name = "files",
    srcs = glob(["**"]),
    visibility = ["//visibility:public"],
)
""",
)
```R�!
�

bt_archive�Downloads an archive from a torrent, and extracts it.

The repository gets a `BUILD.bazel` file with `build_file_content` as its
content. `{name}` in that content is replaced by the downloaded file name.

Example, in `MODULE.bazel`:

```starlark
bittorrent_archive = use_repo_rule("@rules_bittorrent//:repo.bzl", "bittorrent_archive")

bittorrent_archive(
    name = "my_archive",
    uri = "magnet:?xt=urn:btih:...",
    integrity = "...",
    strip_prefix = "my_archive-1.0",
    build_file_content = """
filegroup(
    name = "files",
    srcs = glob(["**"]),
    visibility = ["//visibility:public"],
)
""",
)
```.
name"A unique name for this repository. T
timeout?The timeout in seconds for the download, over all its attempts.2200000�
attempt_timeout�How long, in seconds, one run of rain may take.

rain sometimes never exits after it has downloaded the whole file
(https://github.com/filmil/bazel_rules_bt/issues/49). So rain runs for at
most this long at a time, and after each run the file is checked against
`integrity`:

* a matching file ends the fetch, whether or not rain exited;
* if rain exited, or the file did not change over a whole run (rain is
  done or stuck), the fetch fails, and a file that differs from
  `integrity` is reported with both hashes;
* otherwise rain runs again and resumes where it stopped.

`timeout` bounds the sum of the runs' limits; the checks between runs come
on top. A fetch that runs out of `timeout` keeps rain's resume file, so the
next fetch resumes.2120�
	integrity�The expected hash of the downloaded file, in Subresource Integrity form: `sha256-` followed by the base64 of the SHA-256 digest (`sha384-` and `sha512-` also work).

The fetch fails if the file rain downloads does not have this hash, and the error shows both values. To get the value for a new file, set any well-formed wrong value, for example `sha256-AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=`, and copy the hash the error reports. ;
quiet*Whether to omit printing download progress2TrueB
file4The name of the file to use for the downloaded file.2""5
uri*The torrent URI to download the file from. L
build_file_content2The content of the build file to place in the repo M
strip_prefix7The prefix (directory) within the archive to strip away2""l
extractYWhether to extract the downloaded torrent (torrent with multiple files may not need this)2True*!
bittorrent_archive//:repo.bzl0
.
name"A unique name for this repository. V
T
timeout?The timeout in seconds for the download, over all its attempts.2200000�
�
attempt_timeout�How long, in seconds, one run of rain may take.

rain sometimes never exits after it has downloaded the whole file
(https://github.com/filmil/bazel_rules_bt/issues/49). So rain runs for at
most this long at a time, and after each run the file is checked against
`integrity`:

* a matching file ends the fetch, whether or not rain exited;
* if rain exited, or the file did not change over a whole run (rain is
  done or stuck), the fetch fails, and a file that differs from
  `integrity` is reported with both hashes;
* otherwise rain runs again and resumes where it stopped.

`timeout` bounds the sum of the runs' limits; the checks between runs come
on top. A fetch that runs out of `timeout` keeps rain's resume file, so the
next fetch resumes.2120�
�
	integrity�The expected hash of the downloaded file, in Subresource Integrity form: `sha256-` followed by the base64 of the SHA-256 digest (`sha384-` and `sha512-` also work).

The fetch fails if the file rain downloads does not have this hash, and the error shows both values. To get the value for a new file, set any well-formed wrong value, for example `sha256-AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=`, and copy the hash the error reports. =
;
quiet*Whether to omit printing download progress2TrueD
B
file4The name of the file to use for the downloaded file.2""7
5
uri*The torrent URI to download the file from. N
L
build_file_content2The content of the build file to place in the repo O
M
strip_prefix7The prefix (directory) within the archive to strip away2""n
l
extractYWhether to extract the downloaded torrent (torrent with multiple files may not need this)2True�
testsaliases_test.bzl�aliases_test�Fails the load of the calling package when an alias names another rule.

The check runs while the package loads, so a broken alias fails
`bazel test //...` before any test runs. The test itself only passes.

Example:

```starlark
load(":aliases_test.bzl", "aliases_test")

aliases_test(name = "aliases_test")
```
*�
�
aliases_test(
nameThe name of the test target. (B
kwargs6Passed to the test rule, for example `size` or `tags`.(�Fails the load of the calling package when an alias names another rule.

The check runs while the package loads, so a broken alias fails
`bazel test //...` before any test runs. The test itself only passes.

Example:

```starlark
load(":aliases_test.bzl", "aliases_test")

aliases_test(name = "aliases_test")
```
2(
aliases_test//tests:aliases_test.bzl*
(
nameThe name of the test target. (D
B
kwargs6Passed to the test rule, for example `size` or `tags`.(<Checks that the old rule names still name the renamed rules. 