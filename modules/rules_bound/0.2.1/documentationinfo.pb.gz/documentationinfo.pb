�/
(
rules_boundbound/private
binary.bzl�+bound_binary�Turns an executable and what it needs into one self-contained executable.

The output runs without a runfiles tree: copy it anywhere, run it from any
directory, use it as a tool. When it runs, bound extracts the bundle (once,
into the user's cache, with `bundle = "shared"`) and starts the program.

If `binary` provides a BoundInfo, the bundle is laid out as it says (an
interpreter with the application in its site-packages, for example).
Otherwise it holds the program and its runfiles tree, and the program starts
with RUNFILES_DIR pointing at it, so runfiles libraries find every file
where they expect it.

```starlark
load("@rules_bound//bound:defs.bzl", "bound_binary")

bound_binary(
    name = "report",
    binary = ":report_bin",          # any executable: py_binary, sh_binary, cc_binary, ...
    data = ["templates/report.html"],
    bound_args = ["--template", "$(rlocationpath templates/report.html)"],
    bound_env = {"MODE": "production"},
)
```
"�#
�
bound_binary�Turns an executable and what it needs into one self-contained executable.

The output runs without a runfiles tree: copy it anywhere, run it from any
directory, use it as a tool. When it runs, bound extracts the bundle (once,
into the user's cache, with `bundle = "shared"`) and starts the program.

If `binary` provides a BoundInfo, the bundle is laid out as it says (an
interpreter with the application in its site-packages, for example).
Otherwise it holds the program and its runfiles tree, and the program starts
with RUNFILES_DIR pointing at it, so runfiles libraries find every file
where they expect it.

```starlark
load("@rules_bound//bound:defs.bzl", "bound_binary")

bound_binary(
    name = "report",
    binary = ":report_bin",          # any executable: py_binary, sh_binary, cc_binary, ...
    data = ["templates/report.html"],
    bound_args = ["--template", "$(rlocationpath templates/report.html)"],
    bound_env = {"MODE": "production"},
)
```
*
nameA unique name for this target. s
binaryeThe program: a target with a BoundInfo, or any executable target, whose runfiles are bundled with it. �

bound_args�Arguments bound into the executable, placed before the arguments given at run time unless `@args` marks their place. A whole-argument `$(location X)`, `$(rootpath X)`, `$(execpath X)` or `$(rlocationpath X)` becomes the absolute path of the bundled file at run time. Other values use bound's syntax: `@args`, `@bundle:PATH`, and `@@TEXT` for a literal leading `@`.2[]\
	bound_envIEnvironment variables set for the program, with values like `bound_args`.
2{}k
bound_env_appendSList variables with entries put after the caller's value, like `bound_env_prepend`. �
bound_env_prepend�List variables, such as PATH, with entries put before the caller's value (joined with the platform's separator, `:` or `;`), with values like `bound_args`. Needs bound 0.2.0 or later. �
bundle�"shared": the bundle is extracted once, into the user's cache, read-only (as runfiles are), and reused by every run. "private": a new copy for every run, removed afterwards.2"shared"�
cwd�"inherit": the program runs in the caller's working directory. "bundle": in the bundle directory. "@bundle:DIR": in the bundled directory DIR (needs bound 0.2.0 or later).2	"inherit"_
dataQMore files to bundle, in the runfiles tree (for a BoundInfo, its `runfiles_dir`).2[]�
runfiles_env�When the bundle has a runfiles tree, point RUNFILES_DIR and JAVA_RUNFILES at it and remove RUNFILES_MANIFEST_FILE and RUNFILES_MANIFEST_ONLY, whatever the caller's environment holds.2TrueP
	unset_env=Environment variables removed from what the program inherits.2[]"7
bound_binary'@@rules_bound//bound/private:binary.bzl
44,
*
nameA unique name for this target. u
s
binaryeThe program: a target with a BoundInfo, or any executable target, whose runfiles are bundled with it. �
�

bound_args�Arguments bound into the executable, placed before the arguments given at run time unless `@args` marks their place. A whole-argument `$(location X)`, `$(rootpath X)`, `$(execpath X)` or `$(rlocationpath X)` becomes the absolute path of the bundled file at run time. Other values use bound's syntax: `@args`, `@bundle:PATH`, and `@@TEXT` for a literal leading `@`.2[]^
\
	bound_envIEnvironment variables set for the program, with values like `bound_args`.
2{}m
k
bound_env_appendSList variables with entries put after the caller's value, like `bound_env_prepend`. �
�
bound_env_prepend�List variables, such as PATH, with entries put before the caller's value (joined with the platform's separator, `:` or `;`), with values like `bound_args`. Needs bound 0.2.0 or later. �
�
bundle�"shared": the bundle is extracted once, into the user's cache, read-only (as runfiles are), and reused by every run. "private": a new copy for every run, removed afterwards.2"shared"�
�
cwd�"inherit": the program runs in the caller's working directory. "bundle": in the bundle directory. "@bundle:DIR": in the bundled directory DIR (needs bound 0.2.0 or later).2	"inherit"a
_
dataQMore files to bundle, in the runfiles tree (for a BoundInfo, its `runfiles_dir`).2[]�
�
runfiles_env�When the bundle has a runfiles tree, point RUNFILES_DIR and JAVA_RUNFILES at it and remove RUNFILES_MANIFEST_FILE and RUNFILES_MANIFEST_ONLY, whatever the caller's environment holds.2TrueR
P
	unset_env=Environment variables removed from what the program inherits.2[]�
//bound/private:context.bzlr�
)
rules_boundbound/privatecontext.bzl.
TOOLCHAIN_TYPETOOLCHAIN_TYPE
2@,
bound_contextbound_context
DQ
S�
//bound/private:layout.bzlr�
(
rules_boundbound/private
layout.bzl(
bundle_pathbundle_path
1<
rawraw
@C 
runfilerunfile
GN
PAbound_binary: an executable and what it needs, as one executable.�#
)
rules_boundbound/privatecontext.bzl�bound_context�The bound helpers for a rule implementation.

The rule must declare the bound toolchain: `toolchains =
[BOUND_TOOLCHAIN_TYPE]`.
*�
�
bound_context
ctxthe rule context. (�The bound helpers for a rule implementation.

The rule must declare the bound toolchain: `toolchains =
[BOUND_TOOLCHAIN_TYPE]`.
"�
�A struct with:

* `bind(executable, layout = [], runfiles = None, output = None,
  args = [], env = {}, unset = [], env_prepend = {}, env_append = {},
  bundle = "shared", cwd = "inherit", runfiles_env = None,
  mnemonic = "Bound")`: registers the action that
  writes a bound executable and returns a struct with `executable` (the
  File), `program` (the program's path in the bundle) and
  `runfiles_dir` (the runfiles tree's path in the bundle, or None).

  * `executable`: what to bind. A Target: its BoundInfo if it has one,
    otherwise the program and its runfiles, laid out as Bazel does. A
    File: that program alone. A BoundInfo: any layout.
  * `layout`: more layout entries (`bound_layout`).
  * `runfiles`: more runfiles, for the runfiles tree.
  * `output`: the File to write; by default the rule's name, with
    `.exe` for Windows.
  * `args`: arguments after those of the BoundInfo, before those given
    at run time unless `RUNTIME_ARGS` marks their place. Strings are
    literal; `bundle_path(path)` becomes the absolute path of `path` in
    the extracted bundle, and a File or `runfile(rlocationpath)` that
    of a file in the runfiles tree; `raw(text)` is bound's own syntax.
  * `env`: variables to set, with values like `args`; they override
    those of the BoundInfo.
  * `unset`: variables to remove from the inherited environment.
  * `env_prepend`, `env_append`: list variables such as `PATH`, each
    a name and a list of entries (values like `args`, but not
    `RUNTIME_ARGS`) put before or after the caller's value, joined
    with the platform's separator. The BoundInfo's entries of a name
    sit inside the caller's (its prepend entries after the caller's,
    its append entries before). A name the caller binds any other way
    replaces the BoundInfo's binding of it, and one party cannot bind
    a name two ways; names compare case-insensitively. Needs bound
    0.2.0 or later.
  * `bundle`: "shared" (extracted once into the user's cache,
    read-only) or "private" (extracted for every run).
  * `cwd`: "inherit" (the caller's directory), "bundle", or
    `bundle_path(DIR)`: a directory in the bundle, which the layout
    must hold (needs bound 0.2.0 or later).
  * `runfiles_env`: set RUNFILES_DIR and JAVA_RUNFILES to the bundled
    runfiles tree and remove RUNFILES_MANIFEST_FILE and
    RUNFILES_MANIFEST_ONLY. By default, when the layout has a runfiles
    tree.
* `toolchain`: the resolved bound toolchain (`bound`, `launcher`,
  `exe_suffix`).
* `layout`, `runtime_args`, `bundle_path`, `runfile`, `raw`,
  `rlocation`: as exported by defs.bzl (`bound_layout`,
  `RUNTIME_ARGS`, ...).29
bound_context(@@rules_bound//bound/private:context.bzl
���bound_info_of(The BoundInfo to bind for an executable.*�
�
bound_info_of�

executablera Target (its BoundInfo if it has one, otherwise its
runfiles layout), a File (the program alone), or a BoundInfo. (A
runfiles-more runfiles for the runfiles tree, or None.None((The BoundInfo to bind for an executable."
A BoundInfo.29
bound_info_of(@@rules_bound//bound/private:context.bzl
���
//bound/private:layout.bzlr�
(
rules_boundbound/private
layout.bzl$
	BoundInfo	BoundInfo
*
RUNTIME_ARGSRUNTIME_ARGS
*
bound_layoutbound_layout
(
bundle_pathbundle_path
(
check_listscheck_lists
(
check_namescheck_names

rawraw
	,
relative_linkrelative_link
$
	rlocation	rlocation
4
rlocation_of_pathrlocation_of_path
 
runfilerunfile
8
runfiles_bound_inforunfiles_bound_info

	�The ctx adaptor: builds bound executables from a rule implementation.

`bind` turns a BoundInfo (a layout and an invocation) into one action that
runs `bound build`. The layout becomes an `--include-list` file of
`DEST=SOURCE` lines, written by functions that `Args.map_each` calls when the
action runs, so that depsets are never flattened during analysis.
�~
(
rules_boundbound/private
layout.bzl�bound_layout.directory:A directory, empty unless other entries place files in it.*�
�
bound_layout.directory/
path#the directory's path in the bundle. (:A directory, empty unless other entries place files in it."
A layout entry.25

_directory'@@rules_bound//bound/private:layout.bzl
���bound_layout.file?Places one file at `path`, or a tree artifact's files under it.*�
�
bound_layout.file#
paththe path in the bundle. (z
filena File: a file, a tree artifact, or a symlink declared with
`ctx.actions.declare_symlink` (bundled as a link). (?Places one file at `path`, or a tree artifact's files under it."
A layout entry.20
_file'@@rules_bound//bound/private:layout.bzl
���bound_layout.files�Places files by their runfiles paths, optionally relative to roots.

Each file goes to `dest/` followed by its runfiles path (such as
`_main/pkg/a.py` or `pip_six/site-packages/six.py`), from which the
longest of the `strip_prefix` directories that contains it is removed.
Tree artifacts are expanded: each file in them is placed by its own
path. Files declared with `ctx.actions.declare_symlink` are bundled as
links, with their targets.
*�	
�	
bound_layout.files'
filesa depset or list of Files. (=
dest/the directory in the bundle; `""` for the root.""(�
strip_prefix�None to keep the whole runfiles path, or a string or a
list or depset of strings: runfiles paths of directories, such as the
import paths of a PyInfo. A depset is flattened here, so it should be
small. `""` matches every file.None(�
	unmatched�for a file under none of `strip_prefix`: `"error"` (the
build fails), `"skip"` (it is left out) or `"keep"` (it is placed by
its whole runfiles path)."error"(q
exclude^runfiles paths of files and directories to leave out, as a
string, a list or a (small) depset.None(�Places files by their runfiles paths, optionally relative to roots.

Each file goes to `dest/` followed by its runfiles path (such as
`_main/pkg/a.py` or `pip_six/site-packages/six.py`), from which the
longest of the `strip_prefix` directories that contains it is removed.
Tree artifacts are expanded: each file in them is placed by its own
path. Files declared with `ctx.actions.declare_symlink` are bundled as
links, with their targets.
"
A layout entry.21
_files'@@rules_bound//bound/private:layout.bzl
���bound_layout.runfiles�A Bazel runfiles tree at `dest`, as runfiles libraries expect it.

Files go to their runfiles paths, with the runfiles' symlinks, root
symlinks and empty files, and `_repo_mapping` if given.
*�
�
bound_layout.runfilesB
dest6the tree's path in the bundle, such as `app.runfiles`. ("
runfilesa runfiles object. (u
repo_mapping]the repository mapping manifest (a File, from
`files_to_run.repo_mapping_manifest`), or None.None(�A Bazel runfiles tree at `dest`, as runfiles libraries expect it.

Files go to their runfiles paths, with the runfiles' symlinks, root
symlinks and empty files, and `_repo_mapping` if given.
"
A layout entry.24
	_runfiles'@@rules_bound//bound/private:layout.bzl
���bound_layout.symlink�A symbolic link at `path` to `target`, another path in the bundle.

The link is relative (computed from the two paths), so it works wherever
the bundle is extracted. What it points to must be in the bundle. Links
are not supported in bundles for Windows.
*�
�
bound_layout.symlink*
paththe link's path in the bundle. (7
target)the path in the bundle that it points to. (�A symbolic link at `path` to `target`, another path in the bundle.

The link is relative (computed from the two paths), so it works wherever
the bundle is extracted. What it points to must be in the bundle. Links
are not supported in bundles for Windows.
"
A layout entry.23
_symlink'@@rules_bound//bound/private:layout.bzl
���bound_layout.symlinksCMany symbolic links, like `symlink`, computed when the action runs.*�
�
bound_layout.symlinks�
links�a depset or list of `(path, target)` tuples of paths in the
bundle, both under `dest`. A depset lets rules collect the links of
their dependencies without flattening them, as rules_js does for the
links of a node_modules tree. (f
destXthe directory in the bundle that `path` and `target` are
relative to; `""` for the root.""(CMany symbolic links, like `symlink`, computed when the action runs."
A layout entry.24
	_symlinks'@@rules_bound//bound/private:layout.bzl
���bundle_path7A path in the bundle, as an argument or variable value.*�
�
bundle_pathE
path9a `/`-separated path in the bundle, such as `python/lib`. (7A path in the bundle, as an argument or variable value."�
�A value for `args`, `env`, `env_prepend` and `env_append`, replaced at
run time by the absolute path of `path` in the extracted bundle, or the
`cwd` of `bind`: the bundled directory `path`. Something must be
bundled there.26
bundle_path'@@rules_bound//bound/private:layout.bzl
�check_listsIChecks list variables: name -> non-empty list of values, no RUNTIME_ARGS.*�
�
check_lists4
what(where the lists come from, for messages. (
liststhe dict to check. (IChecks list variables: name -> non-empty list of values, no RUNTIME_ARGS.""
 The dict, with its lists copied.26
check_lists'@@rules_bound//bound/private:layout.bzl
���check_names|Fails if two of `groups` (lists of variable names) share a name.

Names compare case-insensitively, as bound compares them.
*�
�
check_names4
what(where the names come from, for messages. (1
groups#lists of names, each bound one way. (|Fails if two of `groups` (lists of variable names) share a name.

Names compare case-insensitively, as bound compares them.
26
check_names'@@rules_bound//bound/private:layout.bzl
���raw<An argument or value in bound's own syntax, passed as it is.*�
�
rawq
argumentaa string that may use bound's directives (`@args`,
`@bundle:PATH`, `@@TEXT`); see bound's README. (<An argument or value in bound's own syntax, passed as it is."
A value for `args` or `env`.2.
raw'@@rules_bound//bound/private:layout.bzl
..�relative_link<The target text of a link at `path` that points to `target`.*�
�
relative_link*
paththe link's path in the bundle. (=
target/the path in the bundle that the link points to. (<The target text of a link at `path` that points to `target`."D
B`target` relative to the link's directory, such as `../store/pkg`.28
relative_link'@@rules_bound//bound/private:layout.bzl
���	rlocation�The runfiles path of a file, such as `_main/pkg/data.txt`.

For a file in a tree artifact expanded by `Args.add_all`, the path
includes its path in the tree.
*�
�
	rlocation
filea File. (�The runfiles path of a file, such as `_main/pkg/data.txt`.

For a file in a tree artifact expanded by `Args.add_all`, the path
includes its path in the tree.
"{
yThe path of the file under the runfiles root. Its first component is
the file's repository: `rlocation(f).split("/")[0]`.24
	rlocation'@@rules_bound//bound/private:layout.bzl
JJ�rlocation_of_path�The runfiles path for a File's short_path (or an empty file's name).

Main repository files live in `_main`, external ones in their
repository's directory (their short paths start with `../`).
*�
�
rlocation_of_path&

short_patha File's short_path. (�The runfiles path for a File's short_path (or an empty file's name).

Main repository files live in `_main`, external ones in their
repository's directory (their short paths start with `../`).
"A
?The path under the runfiles root, such as `_main/pkg/data.txt`.2<
rlocation_of_path'@@rules_bound//bound/private:layout.bzl
::�runfileFA path in the bundled runfiles tree, as an argument or variable value.*�
�
runfilee
rlocationpathPthe runfiles path, such as `_main/pkg/data.txt` (what
`$(rlocationpath)` gives). (FA path in the bundled runfiles tree, as an argument or variable value."�
�A value for `args` or `env`, replaced at run time by the absolute path
of that file in the extracted bundle. The layout needs a runfiles tree
(a BoundInfo `runfiles_dir`).22
runfile'@@rules_bound//bound/private:layout.bzl
  �runfiles_bound_info�The BoundInfo of Bazel's own layout: a program and its runfiles.

The program is placed at its own name and its runfiles tree next to it,
at `<name>.runfiles`, where runfiles libraries look (with, for Bazel's
Windows launchers, the script they run from next to them). This is what
`bind` uses for an executable without a BoundInfo.
*�
�
runfiles_bound_infod

executableRa Target (with its runfiles and repository mapping) or a
File (the program alone). (>
runfiles*more runfiles to add to the tree, or None.None(�The BoundInfo of Bazel's own layout: a program and its runfiles.

The program is placed at its own name and its runfiles tree next to it,
at `<name>.runfiles`, where runfiles libraries look (with, for Bazel's
Windows launchers, the script they run from next to them). This is what
`bind` uses for an executable without a BoundInfo.
"
A BoundInfo.2>
runfiles_bound_info'@@rules_bound//bound/private:layout.bzl
���	BoundInfo�How to bind a program: what its bundle contains, where, and how it starts.

A rule returns BoundInfo to decide how bound lays out its programs: an
interpreter with the application in its site-packages, a node_modules tree,
a JDK and its jars, instead of Bazel's runfiles tree. `bound_binary` uses the
BoundInfo of its `binary` when it has one, and `bound_context(ctx).bind()`
accepts one as its `executable`. Returning BoundInfo needs no toolchain and
registers no action: rules pay nothing unless something binds them.
2�
�
	BoundInfo�How to bind a program: what its bundle contains, where, and how it starts.

A rule returns BoundInfo to decide how bound lays out its programs: an
interpreter with the application in its site-packages, a node_modules tree,
a JDK and its jars, instead of Bazel's runfiles tree. `bound_binary` uses the
BoundInfo of its `binary` when it has one, and `bound_context(ctx).bind()`
accepts one as its `executable`. Returning BoundInfo needs no toolchain and
registers no action: rules pay nothing unless something binds them.
Z
layoutPA list of entries made with `bound_layout`: what the bundle contains, and where.8
program-The path in the bundle of the program to run.�
args�Arguments that start the program, such as an interpreter's options and the module to run. Strings are literal; `bundle_path()`, `runfile()`, `raw()` and `RUNTIME_ARGS` as for `bind`. The arguments given to `bind` (and `bound_args`) follow them.;
env4A dict of variables to set, with values like `args`.F
unset=A list of variables to remove from what the program inherits.�
env_prepend�A dict of list variables, such as `PATH`, to lists of entries put before the caller's value (joined with the platform's separator), with values like `args` except `RUNTIME_ARGS`. Needs bound 0.2.0 or later.l

env_append^A dict of list variables to lists of entries put after the caller's value, like `env_prepend`.�
runfiles_dir�The path in the bundle of a runfiles tree (a `bound_layout.runfiles` entry), or None. With one, `runfile()` values, File values and `bound_binary`'s `data` go there, and RUNFILES_DIR points to it (unless `runfiles_env = False`)."4
	BoundInfo'@@rules_bound//bound/private:layout.bzl
�&�&\
Z
layoutPA list of entries made with `bound_layout`: what the bundle contains, and where.:
8
program-The path in the bundle of the program to run.�
�
args�Arguments that start the program, such as an interpreter's options and the module to run. Strings are literal; `bundle_path()`, `runfile()`, `raw()` and `RUNTIME_ARGS` as for `bind`. The arguments given to `bind` (and `bound_args`) follow them.=
;
env4A dict of variables to set, with values like `args`.H
F
unset=A list of variables to remove from what the program inherits.�
�
env_prepend�A dict of list variables, such as `PATH`, to lists of entries put before the caller's value (joined with the platform's separator), with values like `args` except `RUNTIME_ARGS`. Needs bound 0.2.0 or later.n
l

env_append^A dict of list variables to lists of entries put after the caller's value, like `env_prepend`.�
�
runfiles_dir�The path in the bundle of a runfiles tree (a `bound_layout.runfiles` entry), or None. With one, `runfile()` values, File values and `bound_binary`'s `data` go there, and RUNFILES_DIR points to it (unless `runfiles_env = False`).�	RUNTIME_ARGS�Layouts: what a bound bundle contains, where, and how its program starts.

A layout is a list of entries, each placing files at paths in the bundle.
The entries hold depsets and Files as they are; nothing is flattened while
rules are analyzed. Paths are computed when the action runs, by functions
of the entries that `bind` passes to `Args.map_each`.

Everything here is data, with no ctx: a rule can build a layout and return
it in a BoundInfo without declaring the bound toolchain. Only `bind`
(context.bzl) turns layouts into actions.
z�
RUNTIME_ARGS
�Layouts: what a bound bundle contains, where, and how its program starts.

A layout is a list of entries, each placing files at paths in the bundle.
The entries hold depsets and Files as they are; nothing is flattened while
rules are analyzed. Paths are computed when the action runs, by functions
of the entries that `bind` passes to `Args.map_each`.

Everything here is data, with no ctx: a rule can build a layout and return
it in a BoundInfo without declaring the bound toolchain. Only `bind`
(context.bzl) turns layouts into actions.
"3

bound_kind
"RUNTIME_ARGS.bound_kind*'@@rules_bound//bound/private:layout.bzl�bound_layout�Layouts: what a bound bundle contains, where, and how its program starts.

A layout is a list of entries, each placing files at paths in the bundle.
The entries hold depsets and Files as they are; nothing is flattened while
rules are analyzed. Paths are computed when the action runs, by functions
of the entries that `bind` passes to `Args.map_each`.

Everything here is data, with no ctx: a rule can build a layout and return
it in a BoundInfo without declaring the bound toolchain. Only `bind`
(context.bzl) turns layouts into actions.
z�
bound_layout
���Layouts: what a bound bundle contains, where, and how its program starts.

A layout is a list of entries, each placing files at paths in the bundle.
The entries hold depsets and Files as they are; nothing is flattened while
rules are analyzed. Paths are computed when the action runs, by functions
of the entries that `bind` passes to `Args.map_each`.

Everything here is data, with no ctx: a rule can build a layout and return
it in a BoundInfo without declaring the bound toolchain. Only `bind`
(context.bzl) turns layouts into actions.
"3
files
��_files"bound_layout.files"0
file
��_file"bound_layout.file"9
symlink
��_symlink"bound_layout.symlink"<
symlinks
��	_symlinks"bound_layout.symlinks"?
	directory
��
_directory"bound_layout.directory"<
runfiles
��	_runfiles"bound_layout.runfiles*'@@rules_bound//bound/private:layout.bzl�Layouts: what a bound bundle contains, where, and how its program starts.

A layout is a list of entries, each placing files at paths in the bundle.
The entries hold depsets and Files as they are; nothing is flattened while
rules are analyzed. Paths are computed when the action runs, by functions
of the entries that `bind` passes to `Args.map_each`.

Everything here is data, with no ctx: a rule can build a layout and return
it in a BoundInfo without declaring the bound toolchain. Only `bind`
(context.bzl) turns layouts into actions.
�
+
rules_boundbound/privateplatforms.bzl�constraints-The @platforms constraints of a platform key.*�
�
constraints#
platforma key of PLATFORMS. (-The @platforms constraints of a platform key."+
)A list of constraint labels (as strings).29
constraints*@@rules_bound//bound/private:platforms.bzl
$The platforms bound is released for.�$
.
rules_boundbound/privaterepositories.bzl�	bound_local=bound binaries from a local directory, for the host platform.R�	
�
bound_local=bound binaries from a local directory, for the host platform..
name"A unique name for this repository. 
pathAn absolute path. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 *<
bound_local-@@rules_bound//bound/private:repositories.bzl
..0
.
name"A unique name for this repository. 

pathAn absolute path. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
bound_release-The released bound binaries for one platform.R�	
�
bound_release-The released bound binaries for one platform..
name"A unique name for this repository. 
platform �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 
sha256 
url_templates 
version *>
bound_release-@@rules_bound//bound/private:repositories.bzl
  0
.
name"A unique name for this repository. 

platform �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 

sha256 

url_templates 

version �bound_toolchainsEDeclares a toolchain for every pair of execution and target platform.R�
�
bound_toolchainsEDeclares a toolchain for every pair of execution and target platform..
name"A unique name for this repository. K
constraints6platform -> its constraint labels, separated by spaces
2{}
host_constraints_bzl B

local_repo.a bound_local repository, for a host toolchain2""C
releases1platform -> repository with its released binaries
2{}�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 
toolchain_bzl 
toolchain_type *A
bound_toolchains-@@rules_bound//bound/private:repositories.bzl
o#o#0
.
name"A unique name for this repository. M
K
constraints6platform -> its constraint labels, separated by spaces
2{}

host_constraints_bzl D
B

local_repo.a bound_local repository, for a host toolchain2""E
C
releases1platform -> repository with its released binaries
2{}�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 

toolchain_bzl 

toolchain_type �
//bound/private:platforms.bzlra
+
rules_boundbound/privateplatforms.bzl$
	PLATFORMS	PLATFORMS
4=
?DRepository rules that provide bound binaries and declare toolchains.�
*
rules_boundbound/privateversions.bzl#	DEFAULT_VERSION0.2.1j0.2.1�	URL_TEMPLATEchttps://github.com/bound-rs/bound/releases/download/v{version}/bound-{version}-{platform}.{archive}jechttps://github.com/bound-rs/bound/releases/download/v{version}/bound-{version}-{platform}.{archive}�Released versions of bound and the checksums of their archives.

To add a release, run `scripts/checksums.sh VERSION` and paste its output
here. Until a version is listed, use `bound.toolchain(version, sha256s = ...)`
or `bound.local(path)` (see extensions.bzl).
��

rules_boundbounddefs.bzl�+bound_binary�Turns an executable and what it needs into one self-contained executable.

The output runs without a runfiles tree: copy it anywhere, run it from any
directory, use it as a tool. When it runs, bound extracts the bundle (once,
into the user's cache, with `bundle = "shared"`) and starts the program.

If `binary` provides a BoundInfo, the bundle is laid out as it says (an
interpreter with the application in its site-packages, for example).
Otherwise it holds the program and its runfiles tree, and the program starts
with RUNFILES_DIR pointing at it, so runfiles libraries find every file
where they expect it.

```starlark
load("@rules_bound//bound:defs.bzl", "bound_binary")

bound_binary(
    name = "report",
    binary = ":report_bin",          # any executable: py_binary, sh_binary, cc_binary, ...
    data = ["templates/report.html"],
    bound_args = ["--template", "$(rlocationpath templates/report.html)"],
    bound_env = {"MODE": "production"},
)
```
"�#
�
bound_binary�Turns an executable and what it needs into one self-contained executable.

The output runs without a runfiles tree: copy it anywhere, run it from any
directory, use it as a tool. When it runs, bound extracts the bundle (once,
into the user's cache, with `bundle = "shared"`) and starts the program.

If `binary` provides a BoundInfo, the bundle is laid out as it says (an
interpreter with the application in its site-packages, for example).
Otherwise it holds the program and its runfiles tree, and the program starts
with RUNFILES_DIR pointing at it, so runfiles libraries find every file
where they expect it.

```starlark
load("@rules_bound//bound:defs.bzl", "bound_binary")

bound_binary(
    name = "report",
    binary = ":report_bin",          # any executable: py_binary, sh_binary, cc_binary, ...
    data = ["templates/report.html"],
    bound_args = ["--template", "$(rlocationpath templates/report.html)"],
    bound_env = {"MODE": "production"},
)
```
*
nameA unique name for this target. s
binaryeThe program: a target with a BoundInfo, or any executable target, whose runfiles are bundled with it. �

bound_args�Arguments bound into the executable, placed before the arguments given at run time unless `@args` marks their place. A whole-argument `$(location X)`, `$(rootpath X)`, `$(execpath X)` or `$(rlocationpath X)` becomes the absolute path of the bundled file at run time. Other values use bound's syntax: `@args`, `@bundle:PATH`, and `@@TEXT` for a literal leading `@`.2[]\
	bound_envIEnvironment variables set for the program, with values like `bound_args`.
2{}k
bound_env_appendSList variables with entries put after the caller's value, like `bound_env_prepend`. �
bound_env_prepend�List variables, such as PATH, with entries put before the caller's value (joined with the platform's separator, `:` or `;`), with values like `bound_args`. Needs bound 0.2.0 or later. �
bundle�"shared": the bundle is extracted once, into the user's cache, read-only (as runfiles are), and reused by every run. "private": a new copy for every run, removed afterwards.2"shared"�
cwd�"inherit": the program runs in the caller's working directory. "bundle": in the bundle directory. "@bundle:DIR": in the bundled directory DIR (needs bound 0.2.0 or later).2	"inherit"_
dataQMore files to bundle, in the runfiles tree (for a BoundInfo, its `runfiles_dir`).2[]�
runfiles_env�When the bundle has a runfiles tree, point RUNFILES_DIR and JAVA_RUNFILES at it and remove RUNFILES_MANIFEST_FILE and RUNFILES_MANIFEST_ONLY, whatever the caller's environment holds.2TrueP
	unset_env=Environment variables removed from what the program inherits.2[]"-
bound_binary@@rules_bound//bound:defs.bzl
44,
*
nameA unique name for this target. u
s
binaryeThe program: a target with a BoundInfo, or any executable target, whose runfiles are bundled with it. �
�

bound_args�Arguments bound into the executable, placed before the arguments given at run time unless `@args` marks their place. A whole-argument `$(location X)`, `$(rootpath X)`, `$(execpath X)` or `$(rlocationpath X)` becomes the absolute path of the bundled file at run time. Other values use bound's syntax: `@args`, `@bundle:PATH`, and `@@TEXT` for a literal leading `@`.2[]^
\
	bound_envIEnvironment variables set for the program, with values like `bound_args`.
2{}m
k
bound_env_appendSList variables with entries put after the caller's value, like `bound_env_prepend`. �
�
bound_env_prepend�List variables, such as PATH, with entries put before the caller's value (joined with the platform's separator, `:` or `;`), with values like `bound_args`. Needs bound 0.2.0 or later. �
�
bundle�"shared": the bundle is extracted once, into the user's cache, read-only (as runfiles are), and reused by every run. "private": a new copy for every run, removed afterwards.2"shared"�
�
cwd�"inherit": the program runs in the caller's working directory. "bundle": in the bundle directory. "@bundle:DIR": in the bundled directory DIR (needs bound 0.2.0 or later).2	"inherit"a
_
dataQMore files to bundle, in the runfiles tree (for a BoundInfo, its `runfiles_dir`).2[]�
�
runfiles_env�When the bundle has a runfiles tree, point RUNFILES_DIR and JAVA_RUNFILES at it and remove RUNFILES_MANIFEST_FILE and RUNFILES_MANIFEST_ONLY, whatever the caller's environment holds.2TrueR
P
	unset_env=Environment variables removed from what the program inherits.2[]�bound_context�The bound helpers for a rule implementation.

The rule must declare the bound toolchain: `toolchains =
[BOUND_TOOLCHAIN_TYPE]`.
*�
�
bound_context
ctxthe rule context. (�The bound helpers for a rule implementation.

The rule must declare the bound toolchain: `toolchains =
[BOUND_TOOLCHAIN_TYPE]`.
"�
�A struct with:

* `bind(executable, layout = [], runfiles = None, output = None,
  args = [], env = {}, unset = [], env_prepend = {}, env_append = {},
  bundle = "shared", cwd = "inherit", runfiles_env = None,
  mnemonic = "Bound")`: registers the action that
  writes a bound executable and returns a struct with `executable` (the
  File), `program` (the program's path in the bundle) and
  `runfiles_dir` (the runfiles tree's path in the bundle, or None).

  * `executable`: what to bind. A Target: its BoundInfo if it has one,
    otherwise the program and its runfiles, laid out as Bazel does. A
    File: that program alone. A BoundInfo: any layout.
  * `layout`: more layout entries (`bound_layout`).
  * `runfiles`: more runfiles, for the runfiles tree.
  * `output`: the File to write; by default the rule's name, with
    `.exe` for Windows.
  * `args`: arguments after those of the BoundInfo, before those given
    at run time unless `RUNTIME_ARGS` marks their place. Strings are
    literal; `bundle_path(path)` becomes the absolute path of `path` in
    the extracted bundle, and a File or `runfile(rlocationpath)` that
    of a file in the runfiles tree; `raw(text)` is bound's own syntax.
  * `env`: variables to set, with values like `args`; they override
    those of the BoundInfo.
  * `unset`: variables to remove from the inherited environment.
  * `env_prepend`, `env_append`: list variables such as `PATH`, each
    a name and a list of entries (values like `args`, but not
    `RUNTIME_ARGS`) put before or after the caller's value, joined
    with the platform's separator. The BoundInfo's entries of a name
    sit inside the caller's (its prepend entries after the caller's,
    its append entries before). A name the caller binds any other way
    replaces the BoundInfo's binding of it, and one party cannot bind
    a name two ways; names compare case-insensitively. Needs bound
    0.2.0 or later.
  * `bundle`: "shared" (extracted once into the user's cache,
    read-only) or "private" (extracted for every run).
  * `cwd`: "inherit" (the caller's directory), "bundle", or
    `bundle_path(DIR)`: a directory in the bundle, which the layout
    must hold (needs bound 0.2.0 or later).
  * `runfiles_env`: set RUNFILES_DIR and JAVA_RUNFILES to the bundled
    runfiles tree and remove RUNFILES_MANIFEST_FILE and
    RUNFILES_MANIFEST_ONLY. By default, when the layout has a runfiles
    tree.
* `toolchain`: the resolved bound toolchain (`bound`, `launcher`,
  `exe_suffix`).
* `layout`, `runtime_args`, `bundle_path`, `runfile`, `raw`,
  `rlocation`: as exported by defs.bzl (`bound_layout`,
  `RUNTIME_ARGS`, ...).29
bound_context(@@rules_bound//bound/private:context.bzl
���bundle_path7A path in the bundle, as an argument or variable value.*�
�
bundle_pathE
path9a `/`-separated path in the bundle, such as `python/lib`. (7A path in the bundle, as an argument or variable value."�
�A value for `args`, `env`, `env_prepend` and `env_append`, replaced at
run time by the absolute path of `path` in the extracted bundle, or the
`cwd` of `bind`: the bundled directory `path`. Something must be
bundled there.26
bundle_path'@@rules_bound//bound/private:layout.bzl
�raw<An argument or value in bound's own syntax, passed as it is.*�
�
rawq
argumentaa string that may use bound's directives (`@args`,
`@bundle:PATH`, `@@TEXT`); see bound's README. (<An argument or value in bound's own syntax, passed as it is."
A value for `args` or `env`.2.
raw'@@rules_bound//bound/private:layout.bzl
..�	rlocation�The runfiles path of a file, such as `_main/pkg/data.txt`.

For a file in a tree artifact expanded by `Args.add_all`, the path
includes its path in the tree.
*�
�
	rlocation
filea File. (�The runfiles path of a file, such as `_main/pkg/data.txt`.

For a file in a tree artifact expanded by `Args.add_all`, the path
includes its path in the tree.
"{
yThe path of the file under the runfiles root. Its first component is
the file's repository: `rlocation(f).split("/")[0]`.24
	rlocation'@@rules_bound//bound/private:layout.bzl
JJ�runfileFA path in the bundled runfiles tree, as an argument or variable value.*�
�
runfilee
rlocationpathPthe runfiles path, such as `_main/pkg/data.txt` (what
`$(rlocationpath)` gives). (FA path in the bundled runfiles tree, as an argument or variable value."�
�A value for `args` or `env`, replaced at run time by the absolute path
of that file in the extracted bundle. The layout needs a runfiles tree
(a BoundInfo `runfiles_dir`).22
runfile'@@rules_bound//bound/private:layout.bzl
  �runfiles_bound_info�The BoundInfo of Bazel's own layout: a program and its runfiles.

The program is placed at its own name and its runfiles tree next to it,
at `<name>.runfiles`, where runfiles libraries look (with, for Bazel's
Windows launchers, the script they run from next to them). This is what
`bind` uses for an executable without a BoundInfo.
*�
�
runfiles_bound_infod

executableRa Target (with its runfiles and repository mapping) or a
File (the program alone). (>
runfiles*more runfiles to add to the tree, or None.None(�The BoundInfo of Bazel's own layout: a program and its runfiles.

The program is placed at its own name and its runfiles tree next to it,
at `<name>.runfiles`, where runfiles libraries look (with, for Bazel's
Windows launchers, the script they run from next to them). This is what
`bind` uses for an executable without a BoundInfo.
"
A BoundInfo.2>
runfiles_bound_info'@@rules_bound//bound/private:layout.bzl
���	BoundInfo�How to bind a program: what its bundle contains, where, and how it starts.

A rule returns BoundInfo to decide how bound lays out its programs: an
interpreter with the application in its site-packages, a node_modules tree,
a JDK and its jars, instead of Bazel's runfiles tree. `bound_binary` uses the
BoundInfo of its `binary` when it has one, and `bound_context(ctx).bind()`
accepts one as its `executable`. Returning BoundInfo needs no toolchain and
registers no action: rules pay nothing unless something binds them.
2�
�
	BoundInfo�How to bind a program: what its bundle contains, where, and how it starts.

A rule returns BoundInfo to decide how bound lays out its programs: an
interpreter with the application in its site-packages, a node_modules tree,
a JDK and its jars, instead of Bazel's runfiles tree. `bound_binary` uses the
BoundInfo of its `binary` when it has one, and `bound_context(ctx).bind()`
accepts one as its `executable`. Returning BoundInfo needs no toolchain and
registers no action: rules pay nothing unless something binds them.
Z
layoutPA list of entries made with `bound_layout`: what the bundle contains, and where.8
program-The path in the bundle of the program to run.�
args�Arguments that start the program, such as an interpreter's options and the module to run. Strings are literal; `bundle_path()`, `runfile()`, `raw()` and `RUNTIME_ARGS` as for `bind`. The arguments given to `bind` (and `bound_args`) follow them.;
env4A dict of variables to set, with values like `args`.F
unset=A list of variables to remove from what the program inherits.�
env_prepend�A dict of list variables, such as `PATH`, to lists of entries put before the caller's value (joined with the platform's separator), with values like `args` except `RUNTIME_ARGS`. Needs bound 0.2.0 or later.l

env_append^A dict of list variables to lists of entries put after the caller's value, like `env_prepend`.�
runfiles_dir�The path in the bundle of a runfiles tree (a `bound_layout.runfiles` entry), or None. With one, `runfile()` values, File values and `bound_binary`'s `data` go there, and RUNFILES_DIR points to it (unless `runfiles_env = False`)."*
	BoundInfo@@rules_bound//bound:defs.bzl
�&�&\
Z
layoutPA list of entries made with `bound_layout`: what the bundle contains, and where.:
8
program-The path in the bundle of the program to run.�
�
args�Arguments that start the program, such as an interpreter's options and the module to run. Strings are literal; `bundle_path()`, `runfile()`, `raw()` and `RUNTIME_ARGS` as for `bind`. The arguments given to `bind` (and `bound_args`) follow them.=
;
env4A dict of variables to set, with values like `args`.H
F
unset=A list of variables to remove from what the program inherits.�
�
env_prepend�A dict of list variables, such as `PATH`, to lists of entries put before the caller's value (joined with the platform's separator), with values like `args` except `RUNTIME_ARGS`. Needs bound 0.2.0 or later.n
l

env_append^A dict of list variables to lists of entries put after the caller's value, like `env_prepend`.�
�
runfiles_dir�The path in the bundle of a runfiles tree (a `bound_layout.runfiles` entry), or None. With one, `runfile()` values, File values and `bound_binary`'s `data` go there, and RUNFILES_DIR points to it (unless `runfiles_env = False`).�
//bound/private:binary.bzlre
(
rules_boundbound/private
binary.bzl+
bound_binary_bound_binary
0=
O�
//bound/private:context.bzlr�
)
rules_boundbound/privatecontext.bzl/
TOOLCHAIN_TYPE_TOOLCHAIN_TYPE
1@-
bound_context_bound_context
Uc
v�
//bound/private:layout.bzlr�
(
rules_boundbound/private
layout.bzl%
	BoundInfo
_BoundInfo
+
RUNTIME_ARGS_RUNTIME_ARGS
+
bound_layout_bound_layout
)
bundle_path_bundle_path

raw_raw
	%
	rlocation
_rlocation
!
runfile_runfile
9
runfiles_bound_info_runfiles_bound_info
  
!�Public API of rules_bound.

For BUILD files:

* `bound_binary`: an executable target as one self-contained executable.

For rules (see the README):

* `BoundInfo`: how a program is laid out in a bundle and started. Rules
  return it to lay out their programs the way their language expects.
* `bound_layout`: the entries of a layout (`files`, `file`, `symlink`,
  `symlinks`, `directory`, `runfiles`).
* `bound_context(ctx)`: builds bound executables in a rule (the ctx
  adaptor); such rules declare `toolchains = [BOUND_TOOLCHAIN_TYPE]`.
* `runfiles_bound_info(executable)`: the BoundInfo of Bazel's own layout, a
  program and its runfiles tree.
* Values for arguments and variables: `RUNTIME_ARGS`, `bundle_path`,
  `runfile`, `raw`; and `rlocation(file)`, a file's runfiles path.
�
$
rules_boundboundextensions.bzl�bound=Provides the bound toolchains (see the module documentation).J�
�
bound=Provides the bound toolchains (see the module documentation).�
	toolchain Use a released version of bound.�
sha256s�SHA-256 of each platform's archive (keys such as linux_x86_64, macos_aarch64, windows_x86_64), for versions rules_bound does not know. Platforms left out get no toolchain.
2{}�
url_templatesRWhere to download archives from; {version}, {platform} and {archive} are replaced.2g["https://github.com/bound-rs/bound/releases/download/v{version}/bound-{version}-{platform}.{archive}"]*
versionThe version, such as 0.2.1. �
localTUse `bound` and `bound-launcher` from a local directory, for the host platform only.f
pathZThe directory: absolute, or relative to the root module (such as ../bound/target/release). ",
bound#@@rules_bound//bound:extensions.bzl
nn�
�
	toolchain Use a released version of bound.�
sha256s�SHA-256 of each platform's archive (keys such as linux_x86_64, macos_aarch64, windows_x86_64), for versions rules_bound does not know. Platforms left out get no toolchain.
2{}�
url_templatesRWhere to download archives from; {version}, {platform} and {archive} are replaced.2g["https://github.com/bound-rs/bound/releases/download/v{version}/bound-{version}-{platform}.{archive}"]*
versionThe version, such as 0.2.1. �
�
sha256s�SHA-256 of each platform's archive (keys such as linux_x86_64, macos_aarch64, windows_x86_64), for versions rules_bound does not know. Platforms left out get no toolchain.
2{}�
�
url_templatesRWhere to download archives from; {version}, {platform} and {archive} are replaced.2g["https://github.com/bound-rs/bound/releases/download/v{version}/bound-{version}-{platform}.{archive}"],
*
versionThe version, such as 0.2.1. �
�
localTUse `bound` and `bound-launcher` from a local directory, for the host platform only.f
pathZThe directory: absolute, or relative to the root module (such as ../bound/target/release). h
f
pathZThe directory: absolute, or relative to the root module (such as ../bound/target/release). �
//bound/private:platforms.bzlr�
+
rules_boundbound/privateplatforms.bzl$
	PLATFORMS	PLATFORMS
4=(
constraintsconstraints
AL
N�
 //bound/private:repositories.bzlr�
.
rules_boundbound/privaterepositories.bzl(
bound_localbound_local
7B,
bound_releasebound_release
FS2
bound_toolchainsbound_toolchains
Wg
i�
//bound/private:versions.bzlr�
*
rules_boundbound/privateversions.bzl0
DEFAULT_VERSIONDEFAULT_VERSION
3B*
URL_TEMPLATEURL_TEMPLATE
FR"
VERSIONSVERSIONS
V^
`�The `bound` module extension: which bound binaries the toolchains use.

rules_bound registers `@bound_toolchains//:all`, which this extension
fills. The root module chooses:

```starlark
bound = use_extension("@rules_bound//bound:extensions.bzl", "bound")

# A released version (checksums built into rules_bound, or given here):
bound.toolchain(version = "0.2.1")

# Or binaries built locally, for the host platform only, e.g. from a bound
# checkout (a path relative to the root module, or absolute):
bound.local(path = "../bound/target/release")
```

A released version provides a toolchain for every pair of supported
execution and target platforms, so builds can produce executables for
other platforms. Without either tag, the default version is used; if
rules_bound knows no release yet, no toolchain is declared and you need
one of the tags, or a toolchain of your own (see toolchain.bzl).
�
#
rules_boundboundtoolchain.bzl�bound_toolchainBThe `bound` command line and the launcher for one target platform."�
�
bound_toolchainBThe `bound` command line and the launcher for one target platform.*
nameA unique name for this target. @
bound3The `bound` executable, for the execution platform. l
launcher\The `bound-launcher` executable, for the target platform (`bound-launcher.exe` for Windows). "5
bound_toolchain"@@rules_bound//bound:toolchain.bzl
%%,
*
nameA unique name for this target. B
@
bound3The `bound` executable, for the execution platform. n
l
launcher\The `bound-launcher` executable, for the target platform (`bound-launcher.exe` for Windows). �The bound toolchain.

A bound toolchain pairs the `bound` command line, which runs on the
execution platform, with a `bound-launcher`, the start of every executable
bound writes, for the target platform. The module extension in
extensions.bzl declares toolchains for released binaries; declare your own
with `bound_toolchain` and `toolchain()` to use others:

```starlark
load("@rules_bound//bound:toolchain.bzl", "bound_toolchain")

bound_toolchain(
    name = "my_bound",
    bound = "//tools:bound",
    launcher = "//tools:bound-launcher",
)

toolchain(
    name = "my_bound_toolchain",
    exec_compatible_with = ["@platforms//os:linux", "@platforms//cpu:x86_64"],
    target_compatible_with = ["@platforms//os:linux", "@platforms//cpu:x86_64"],
    toolchain = ":my_bound",
    toolchain_type = "@rules_bound//bound:toolchain_type",
)
```
 