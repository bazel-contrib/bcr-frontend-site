�
1
rules_browsersbrowsers/chromiumchromium.bzl�define_chrome_repositories*|
l
define_chrome_repositories2N
define_chrome_repositories0@@rules_browsers//browsers/chromium:chromium.bzl
�
#//browsers/private:browser_repo.bzlrp
4
rules_browsersbrowsers/privatebrowser_repo.bzl*
browser_repobrowser_repo
=I
K�
5
rules_browsersbrowsers/chromiumchromedriver.bzl� define_chromedriver_repositories*�
|
 define_chromedriver_repositories2X
 define_chromedriver_repositories4@@rules_browsers//browsers/chromium:chromedriver.bzl
�
#//browsers/private:browser_repo.bzlrp
4
rules_browsersbrowsers/privatebrowser_repo.bzl*
browser_repobrowser_repo
=I
K�
/
rules_browsersbrowsers/firefoxfirefox.bzl�define_firefox_repositories*|
l
define_firefox_repositories2M
define_firefox_repositories.@@rules_browsers//browsers/firefox:firefox.bzl
�
#//browsers/private:browser_repo.bzlrp
4
rules_browsersbrowsers/privatebrowser_repo.bzl*
browser_repobrowser_repo
=I
K�
8
rules_browsersbrowsers/privatebrowser_artifact.bzl�browser_artifact�
Rule that is used in combination with the `browser_repo` rule. It captures a set
of files which are needed for dealing with a browser. Additionally, specific files
for the browser can be denoted with an unique name so that web tests can access browser
files in a platform-agnostic way, regardless of which browser repository is selected.

The specified browser files are exposed as runfiles of the target defined through this
rule. The unique names with their associated files are captured within a metadata file
that is exposed through a `WebTestInfo` provider. Web tests will be able to deal with
this metadata file to resolve browser files in a platform-agnostic way.

More details on this can be found in the `browser_repo` rule.
"�
�	
browser_artifact�
Rule that is used in combination with the `browser_repo` rule. It captures a set
of files which are needed for dealing with a browser. Additionally, specific files
for the browser can be denoted with an unique name so that web tests can access browser
files in a platform-agnostic way, regardless of which browser repository is selected.

The specified browser files are exposed as runfiles of the target defined through this
rule. The unique names with their associated files are captured within a metadata file
that is exposed through a `WebTestInfo` provider. Web tests will be able to deal with
this metadata file to resolve browser files in a platform-agnostic way.

More details on this can be found in the `browser_repo` rule.
*
nameA unique name for this target. <
files/List of files which are needed for the browser. �
named_files�
Dictionary that maps files to unique identifiers. This is useful
if browser archives are different on different platforms and the web
tests would not want to care about archive-specific paths. e.g. targets
expect a `CHROMIUM` key to point to the Chromium browser binary.
	 "K
browser_artifact7@@rules_browsers//browsers/private:browser_artifact.bzl
%%,
*
nameA unique name for this target. >
<
files/List of files which are needed for the browser. �
�
named_files�
Dictionary that maps files to unique identifiers. This is useful
if browser archives are different on different platforms and the web
tests would not want to care about archive-specific paths. e.g. targets
expect a `CHROMIUM` key to point to the Chromium browser binary.
	 �NamedFilesInfoBProvider exposing the named files of an extracted browser archive.2�
�
NamedFilesInfoBProvider exposing the named files of an extracted browser archive.B
value9Dictionary of keys and their corresponding manifest paths"I
NamedFilesInfo7@@rules_browsers//browsers/private:browser_artifact.bzl
D
B
value9Dictionary of keys and their corresponding manifest paths�
5
rules_browsersbrowsers/privatebrowser_group.bzl�browser_group7Groups multiple `browser_artifact` into a single target"�
�
browser_group7Groups multiple `browser_artifact` into a single target*
nameA unique name for this target. 

deps "E
browser_group4@@rules_browsers//browsers/private:browser_group.bzl
,
*
nameA unique name for this target. 


deps �
'//browsers/private:browser_artifact.bzlrx
8
rules_browsersbrowsers/privatebrowser_artifact.bzl.
NamedFilesInfoNamedFilesInfo
AO
Q�7
4
rules_browsersbrowsers/privatebrowser_repo.bzl�6browser_repo�
Rule that can be used to download and unpack a browser archive in a dedicated Bazel
repository. Additionally, files within the archive can be denoted with an unique name
so that web tests can access browser files in a platform-agnostic way, regardless of
which `browser_repo` repository is added as dependency.

As an example for the concept of denoting archive files with an unique name, consider a case
where a web test decides conditionally based on the current exec platform which
`browser_repo` repository is used (e.g. mac, windows or linux). The archives are different
for each platform. The test usually would need to determine the current platform, and know how
each archive is structured in order to access the browser binary within the repository. By
defining named files though, the web test could just pull a named file called `BINARY` that
always resolves to the browser binary in a platform-agnostic way.

Note #1: This rule exists as an alternative to the `platform_http_file` concept
from `rules_webtesting` because the `platform_http_file` rule does not extract the archive
directly, but relies on later build actions to perform the unpacking. This results in less
efficient caching because build actions are invalidated more frequently (e.g. `bazel clean).
We also noticed that the extraction within RBE containers is rather unstable, and extracting
the archives as part of a Bazel repository mitigates this (as extractions happens on the host).

Note #2: Additionally `rules_webtesting` defines a single repository for all platforms,
where only an archive for the current host platform is pulled. This breaks cross-compilation
because the wrong platform archive would be used for web tests that run in the exec platform.
R�(
�
browser_repo�
Rule that can be used to download and unpack a browser archive in a dedicated Bazel
repository. Additionally, files within the archive can be denoted with an unique name
so that web tests can access browser files in a platform-agnostic way, regardless of
which `browser_repo` repository is added as dependency.

As an example for the concept of denoting archive files with an unique name, consider a case
where a web test decides conditionally based on the current exec platform which
`browser_repo` repository is used (e.g. mac, windows or linux). The archives are different
for each platform. The test usually would need to determine the current platform, and know how
each archive is structured in order to access the browser binary within the repository. By
defining named files though, the web test could just pull a named file called `BINARY` that
always resolves to the browser binary in a platform-agnostic way.

Note #1: This rule exists as an alternative to the `platform_http_file` concept
from `rules_webtesting` because the `platform_http_file` rule does not extract the archive
directly, but relies on later build actions to perform the unpacking. This results in less
efficient caching because build actions are invalidated more frequently (e.g. `bazel clean).
We also noticed that the extraction within RBE containers is rather unstable, and extracting
the archives as part of a Bazel repository mitigates this (as extractions happens on the host).

Note #2: Additionally `rules_webtesting` defines a single repository for all platforms,
where only an archive for the current host platform is pulled. This breaks cross-compilation
because the wrong platform archive would be used for web tests that run in the exec platform.
.
name"A unique name for this repository. �
exclude_patterns�Patterns of files which should be excluded from the browser runfiles.

This is useful for example when files with spaces are shipped as part of the
archives of browsers. Runfiles with spaces cause issues within Bazel and if
these files are not strictly needed, they should be omitted.
2[]�
exports_files�Patterns of files which should be added to exports_files.

This is useful for example when files with spaces are shipped as part of the
archives of browsers. Instead of individual files, the top-level source directory
can be depended on which resolves the runfiles with spaces issue. NB: source
directories are not compatible with remote execution so a target that uses sources
directory inputs should be tagged "local".
2[]�
named_files�
Dictionary that maps files to unique identifiers. This is useful
if browser archives are different on different platforms and the web
tests would not want to care about archive-specific paths. e.g. targets
expect a `CHROMIUM` key to point to the Chromium browser binary.

 �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 .
sha256 SHA256 checksum for the archive. Z
urlsNURLs used for downloading the archive. Multiple URLs can be serve as fallback. *C
browser_repo3@@rules_browsers//browsers/private:browser_repo.bzl
QQ0
.
name"A unique name for this repository. �
�
exclude_patterns�Patterns of files which should be excluded from the browser runfiles.

This is useful for example when files with spaces are shipped as part of the
archives of browsers. Runfiles with spaces cause issues within Bazel and if
these files are not strictly needed, they should be omitted.
2[]�
�
exports_files�Patterns of files which should be added to exports_files.

This is useful for example when files with spaces are shipped as part of the
archives of browsers. Instead of individual files, the top-level source directory
can be depended on which resolves the runfiles with spaces issue. NB: source
directories are not compatible with remote execution so a target that uses sources
directory inputs should be tagged "local".
2[]�
�
named_files�
Dictionary that maps files to unique identifiers. This is useful
if browser archives are different on different platforms and the web
tests would not want to care about archive-specific paths. e.g. targets
expect a `CHROMIUM` key to point to the Chromium browser binary.

 �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 0
.
sha256 SHA256 checksum for the archive. \
Z
urlsNURLs used for downloading the archive. Multiple URLs can be serve as fallback. *Implementation of the `browser_repo` rule.�	
?
rules_browsersbrowsers/privatebrowser_toolchain_alias.bzl�browser_toolchain_alias�
Exposes a toolchain alias exposing the template variables for all named files
included in the browser metadata dependencies. The values of the template variables
will follow the semantics of Bazel location rootpaths.

The variables can be consumed within Bazel make variable expansion.
"�
�
browser_toolchain_alias�
Exposes a toolchain alias exposing the template variables for all named files
included in the browser metadata dependencies. The values of the template variables
will follow the semantics of Bazel location rootpaths.

The variables can be consumed within Bazel make variable expansion.
*
nameA unique name for this target. b
deps7Metadata targets that provides the browser named files. *
NamedFilesInfo
DefaultInfo"Y
browser_toolchain_alias>@@rules_browsers//browsers/private:browser_toolchain_alias.bzl
,
*
nameA unique name for this target. d
b
deps7Metadata targets that provides the browser named files. *
NamedFilesInfo
DefaultInfo�
'//browsers/private:browser_artifact.bzlrx
8
rules_browsersbrowsers/privatebrowser_artifact.bzl.
NamedFilesInfoNamedFilesInfo
AO
Q�
*
rules_browsersbrowsersextensions.bzl�browsersJ�
f
browsers
chrome
chromedriver	
firefox"5
browsers)@@rules_browsers//browsers:extensions.bzl



chrome

chromedriver
	
firefox�
$//browsers/chromium:chromedriver.bzlr�
5
rules_browsersbrowsers/chromiumchromedriver.bzlR
 define_chromedriver_repositories define_chromedriver_repositories
>^
`�
 //browsers/chromium:chromium.bzlr�
1
rules_browsersbrowsers/chromiumchromium.bzlF
define_chrome_repositoriesdefine_chrome_repositories
:T
V�
//browsers/firefox:firefox.bzlr�
/
rules_browsersbrowsers/firefoxfirefox.bzlH
define_firefox_repositoriesdefine_firefox_repositories
8S
U3Extension that allows loading browser repositories.�
,
rules_browsersbrowsersrepositories.bzl�rules_browsers_repositoriesLoad pinned browser versions.*�
�
rules_browsers_repositoriesLoad pinned browser versions.2J
rules_browsers_repositories+@@rules_browsers//browsers:repositories.bzl
�
$//browsers/chromium:chromedriver.bzlr�
5
rules_browsersbrowsers/chromiumchromedriver.bzlR
 define_chromedriver_repositories define_chromedriver_repositories
>^
`�
 //browsers/chromium:chromium.bzlr�
1
rules_browsersbrowsers/chromiumchromium.bzlF
define_chrome_repositoriesdefine_chrome_repositories
:T
V�
//browsers/firefox:firefox.bzlr�
/
rules_browsersbrowsers/firefoxfirefox.bzlH
define_firefox_repositoriesdefine_firefox_repositories
8S
UPinned browser versions.�
,
rules_browsersprotractor_test	index.bzl�protractor_test*�
�
protractor_test

name (
server (

deps (
extra_config{}(
data[](
enable_perf_loggingFalse(

kwargs(2>
protractor_test+@@rules_browsers//protractor_test:index.bzl
*server_test2
write_file2server_testy
//rules:write_file.bzlr]
%
bazel_skylibruleswrite_file.bzl&

write_file
write_file
.8
:�
:protractor/package_json.bzlrb
1
npm_rules_browsersprotractor/package_json.bzl
bin
protractor
;E
N
//server_test:index.bzlrb
(
rules_browsersserver_test	index.bzl(
server_testserver_test
1<
>ɫ
(
rules_browsersserver_test	index.bzl��server_test�Identical to js_binary, but usable under `bazel test`.

All [common test attributes](https://bazel.build/reference/be/common-definitions#common-attributes-tests) are
supported including `args` as the list of arguments passed Node.js.

Bazel will set environment variables when a test target is run under `bazel test` and `bazel run`
that a test runner can use.

A runner can write arbitrary outputs files it wants Bazel to pickup and save with the test logs to
`TEST_UNDECLARED_OUTPUTS_DIR`. These get zipped up and saved along with the test logs.

JUnit XML reports can be written to `XML_OUTPUT_FILE` for Bazel to consume.

`TEST_TMPDIR` is an absolute path to a private writeable directory that the test runner can use for
creating temporary files.

LCOV coverage reports can be written to `COVERAGE_OUTPUT_FILE` when running under `bazel coverage`
or if the `--coverage` flag is set.

See the Bazel [Test encyclopedia](https://bazel.build/reference/test-encyclopedia) for details on
the contract between Bazel and a test runner."��
�S
server_test�Identical to js_binary, but usable under `bazel test`.

All [common test attributes](https://bazel.build/reference/be/common-definitions#common-attributes-tests) are
supported including `args` as the list of arguments passed Node.js.

Bazel will set environment variables when a test target is run under `bazel test` and `bazel run`
that a test runner can use.

A runner can write arbitrary outputs files it wants Bazel to pickup and save with the test logs to
`TEST_UNDECLARED_OUTPUTS_DIR`. These get zipped up and saved along with the test logs.

JUnit XML reports can be written to `XML_OUTPUT_FILE` for Bazel to consume.

`TEST_TMPDIR` is an absolute path to a private writeable directory that the test runner can use for
creating temporary files.

LCOV coverage reports can be written to `COVERAGE_OUTPUT_FILE` when running under `bazel coverage`
or if the `--coverage` flag is set.

See the Bazel [Test encyclopedia](https://bazel.build/reference/test-encyclopedia) for details on
the contract between Bazel and a test runner.*
nameA unique name for this target. �
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/"))) + "$(rootpath //path/to/some:file)"],
)
```2""�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

NB: `data` files are copied to the Bazel output tree before being passed
as inputs to runfiles. See `copy_data_to_bin` docstring for more info.
2[]�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/bazel-contrib/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 �
env�Environment variables of the action.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_env` is set to True.

2{}�
env_inherit|Specifies additional environment variables to inherit from the external environment when the test is executed by bazel test.2[]�
expand_args�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `fixed_args`.

This comes at some analysis-time cost even for a set of args that does not have any expansions.2True�

expand_env�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `env`.

This comes at some analysis-time cost even for a set of envs that does not have any expansions.2Truei
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�

fixed_args�Fixed command line arguments to pass to the Node.js when this
binary target is executed.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_args` is set to True.

Unlike the built-in `args`, which are only passed to the target when it is
executed either by the `bazel run` command or as a test, `fixed_args` are baked
into the generated launcher script so are always passed even when the binary
target is run outside of Bazel directly from the launcher script.

`fixed_args` are passed before the ones specified in `args` and before ones
that are specified on the `bazel run` or `bazel test` command line.

See https://bazel.build/reference/be/common-definitions#common-attributes-binaries
for more info on the built-in `args` attribute.
2[]�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
include_npm_sources�When True, files in `npm_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in `data` targets are also included in the runfiles of the target.
2True�
include_sourcesjWhen True, `sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
include_transitive_sourcesuWhen True, `transitive_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
include_transitive_types�When True, `transitive_types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
include_types�When True, `types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.

NB: These are types from direct `data` dependencies only. You may also need to set `include_transitive_types` to True.2False�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.

Log levels: fatal, error, warn, info, debug2"error"�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
node_toolchain�The Node.js toolchain to use for this target.

See https://bazel-contrib.github.io/rules_nodejs/Toolchains.html

Typically this is left unset so that Bazel automatically selects the right Node.js toolchain
for the target platform. See https://bazel.build/extending/toolchains#toolchain-resolution
for more information.
2None�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2True
		,
*
nameA unique name for this target. �
�
chdir�Working directory to run the binary or test in, relative to the workspace.

By default, `js_binary` runs in the root of the output tree.

To run in the directory containing the `js_binary` use

    chdir = package_name()

(or if you're in a macro, use `native.package_name()`)

WARNING: this will affect other paths passed to the program, either as arguments or in configuration files,
which are workspace-relative.

You may need `../../` segments to re-relativize such paths to the new working directory.
In a `BUILD` file you could do something like this to point to the output path:

```python
js_binary(
    ...
    chdir = package_name(),
    # ../.. segments to re-relative paths from the chdir back to workspace;
    # add an additional 3 segments to account for running js_binary running
    # in the root of the output tree
    args = ["/".join([".."] * len(package_name().split("/"))) + "$(rootpath //path/to/some:file)"],
)
```2""�
�
copy_data_to_bin�When True, `data` files and the `entry_point` file are copied to the Bazel output tree before being passed
as inputs to runfiles.

Defaults to True so that a `js_binary` with the default value is compatible with `js_run_binary` with
`use_execroot_entry_point` set to True, the default there.

Setting this to False is more optimal in terms of inputs, but there is a yet unresolved issue of ESM imports
skirting the node fs patches and escaping the sandbox: https://github.com/aspect-build/rules_js/issues/362.
This is hit in some popular test runners such as mocha, which use native `import()` statements
(https://github.com/aspect-build/rules_js/pull/353). When set to False, a program such as mocha that uses ESM
imports may escape the execroot by following symlinks into the source tree. When set to True, such a program
would escape the sandbox but will end up in the output tree where `node_modules` and other inputs required
will be available.
2True�
�
data�Runtime dependencies of the program.

The transitive closure of the `data` dependencies will be available in
the .runfiles folder for this binary/test.

NB: `data` files are copied to the Bazel output tree before being passed
as inputs to runfiles. See `copy_data_to_bin` docstring for more info.
2[]�
�
enable_runfiles�Whether runfiles are enabled in the current build configuration.

Typical usage of this rule is via a macro which automatically sets this
attribute based on a `config_setting` rule.
 �
�
entry_point�The main script which is evaluated by node.js.

This is the module referenced by the `require.main` property in the runtime.

This must be a target that provides a single file or a `DirectoryPathInfo`
from `@aspect_bazel_lib//lib::directory_path.bzl`.

See https://github.com/bazel-contrib/bazel-lib/blob/main/docs/directory_path.md
for more info on creating a target that provides a `DirectoryPathInfo`.
 �
�
env�Environment variables of the action.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_env` is set to True.

2{}�
�
env_inherit|Specifies additional environment variables to inherit from the external environment when the test is executed by bazel test.2[]�
�
expand_args�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `fixed_args`.

This comes at some analysis-time cost even for a set of args that does not have any expansions.2True�
�

expand_env�Enables [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution for `env`.

This comes at some analysis-time cost even for a set of envs that does not have any expansions.2Truek
i
expected_exit_codeNThe expected exit code.

Can be used to write tests that are expected to fail.20�
�

fixed_args�Fixed command line arguments to pass to the Node.js when this
binary target is executed.

Subject to [$(location)](https://bazel.build/reference/be/make-variables#predefined_label_variables)
and ["Make variable"](https://bazel.build/reference/be/make-variables) substitution if `expand_args` is set to True.

Unlike the built-in `args`, which are only passed to the target when it is
executed either by the `bazel run` command or as a test, `fixed_args` are baked
into the generated launcher script so are always passed even when the binary
target is run outside of Bazel directly from the launcher script.

`fixed_args` are passed before the ones specified in `args` and before ones
that are specified on the `bazel run` or `bazel test` command line.

See https://bazel.build/reference/be/common-definitions#common-attributes-binaries
for more info on the built-in `args` attribute.
2[]�
�
include_npm�When True, npm is included in the runfiles of the target.

An npm binary is also added on the PATH so tools can spawn npm processes. This is a bash script
on Linux and MacOS and a batch script on Windows.

A minimum of rules_nodejs version 5.7.0 is required which contains the Node.js toolchain changes
to use npm.
2False�
�
include_npm_sources�When True, files in `npm_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

`transitive_files` from `NpmPackageStoreInfo` providers in `data` targets are also included in the runfiles of the target.
2True�
�
include_sourcesjWhen True, `sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
�
include_transitive_sourcesuWhen True, `transitive_sources` from `JsInfo` providers in `data` targets are included in the runfiles of the target.2True�
�
include_transitive_types�When True, `transitive_types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.2False�
�
include_types�When True, `types` from `JsInfo` providers in `data` targets are included in the runfiles of the target.

Defaults to False since types are generally not needed at runtime and introducing them could slow down developer round trip
time due to having to generate typings on source file changes.

NB: These are types from direct `data` dependencies only. You may also need to set `include_transitive_types` to True.2False�
�
	log_level�Set the logging level.

Log from are written to stderr. They will be supressed on success when running as the tool
of a js_run_binary when silent_on_success is True. In that case, they will be shown
only on a build failure along with the stdout & stderr of the node tool being run.

Log levels: fatal, error, warn, info, debug2"error"�
�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
�
node_options�Options to pass to the node invocation on the command line.

https://nodejs.org/api/cli.html

These options are passed directly to the node invocation on the command line.
Options passed here will take precendence over options passed via
the NODE_OPTIONS environment variable. Options passed here are not added
to the NODE_OPTIONS environment variable so will not be automatically
picked up by child processes that inherit that enviroment variable.
2[]�
�
node_toolchain�The Node.js toolchain to use for this target.

See https://bazel-contrib.github.io/rules_nodejs/Toolchains.html

Typically this is left unset so that Bazel automatically selects the right Node.js toolchain
for the target platform. See https://bazel.build/extending/toolchains#toolchain-resolution
for more information.
2None�
�
patch_node_fs�Patch the to Node.js `fs` API (https://nodejs.org/api/fs.html) for this node program
to prevent the program from following symlinks out of the execroot, runfiles and the sandbox.

When enabled, `js_binary` patches the Node.js sync and async `fs` API functions `lstat`,
`readlink`, `realpath`, `readdir` and `opendir` so that the node program being
run cannot resolve symlinks out of the execroot and the runfiles tree. When in the sandbox,
these patches prevent the program being run from resolving symlinks out of the sandbox.

When disabled, node programs can leave the execroot, runfiles and sandbox by following symlinks
which can lead to non-hermetic behavior.2True�
�
preserve_symlinks_main�When True, the --preserve-symlinks-main flag is passed to node.

This prevents node from following an ESM entry script out of runfiles and the sandbox. This can happen for `.mjs`
ESM entry points where the fs node patches, which guard the runfiles and sandbox, are not applied.
See https://github.com/aspect-build/rules_js/issues/362 for more information. Once #362 is resolved,
the default for this attribute can be set to False.

This flag was added in Node.js v10.2.0 (released 2018-05-23). If your node toolchain is configured to use a
Node.js version older than this you'll need to set this attribute to False.

See https://nodejs.org/api/cli.html#--preserve-symlinks-main for more information.
2Trued
//js:defs.bzlrQ

aspect_rules_jsjsdefs.bzl 
js_testjs_test
(/
1�
Runs a given test together with the specified server. The server executable is expected
to support a `PORT` environment variable. The chosen available port is then set as environment
variable so that the test environment can connect to the server. Use `TEST_SERVER_PORT`.
�
 
rules_browserswtr	index.bzl�wtr_test*�
�
wtr_test

name (

deps (
firefoxTrue(
chromiumTrue(

kwargs(2+
wtr_test@@rules_browsers//wtr:index.bzl
::*_base_wtr_test*_base_wtr_test*_base_wtr_test2native.test_suite�
":@web/test-runner/package_json.bzlra
7
npm_rules_browsers!@web/test-runner/package_json.bzl
binwtr
AD
M 