�#

	rules_bsxbsx.bzl�bsx"�
�
bsx*
nameA unique name for this target. X
cmdKCommand script to execute after extraction (mutually exclusive with 'main')2""�
data�Files or targets to include in the archive. Keys are file labels, values are destination paths within the archive. Each label must resolve to exactly one file.	2{}�
	exec_main�Replace the wrapper process with the script (exec) instead of running it as a child. Use this when the script must keep the wrapper's process identity â most importantly when it has to be PID 1, as an init that ends in switch_root does, since switch_root refuses to run anywhere else. The trade-off: the wrapper is gone once the script starts, so the extraction directory is never cleaned up. Set BSX_EXTRACT_DIR to control where it lands, or leave it if the filesystem is throwaway (an initramfs, a container).2False\
mainLMain script file to execute after extraction (mutually exclusive with 'cmd')2Noneg
tarballsUTarballs to merge into the self-extracting archive (later ones override earlier ones)2[]"
bsx@@rules_bsx//:bsx.bzl
��,
*
nameA unique name for this target. Z
X
cmdKCommand script to execute after extraction (mutually exclusive with 'main')2""�
�
data�Files or targets to include in the archive. Keys are file labels, values are destination paths within the archive. Each label must resolve to exactly one file.	2{}�
�
	exec_main�Replace the wrapper process with the script (exec) instead of running it as a child. Use this when the script must keep the wrapper's process identity â most importantly when it has to be PID 1, as an init that ends in switch_root does, since switch_root refuses to run anywhere else. The trade-off: the wrapper is gone once the script starts, so the extraction directory is never cleaned up. Set BSX_EXTRACT_DIR to control where it lands, or leave it if the filesystem is throwaway (an initramfs, a container).2False^
\
mainLMain script file to execute after extraction (mutually exclusive with 'cmd')2Nonei
g
tarballsUTarballs to merge into the self-extracting archive (later ones override earlier ones)2[]�bsx_sign"�
�
bsx_sign*
nameA unique name for this target. !
bsxThe bsx target to sign �
deterministic�Sign ML-DSA deterministically (-pkeyopt deterministic:1) instead of using the hedged default. ML-DSA normally mixes fresh randomness into every signature, so signing the same bytes twice yields two different .sig files; deterministic signing makes the signature a pure function of key and message, which is what you want if the signature is checked in, cached, or compared between builds. The hedged default is the more conservative choice against fault and side-channel attacks on the signing host. Ignored for other key types: RSA-PSS is hedged and has no such option, while Ed25519 and Ed448 are deterministic by specification.2False�
output_name�Filename for the signed output (defaults to the bsx target's filename). Overridden by an explicit output path passed as the first argument at run time.2""�
signing_key_cmd�Shell command that outputs the signing private key (PEM) to stdout. Runs at 'bazel run' time, so it can be interactive (e.g., 1Password). "!
bsx_sign@@rules_bsx//:bsx.bzl
��,
*
nameA unique name for this target. #
!
bsxThe bsx target to sign �
�
deterministic�Sign ML-DSA deterministically (-pkeyopt deterministic:1) instead of using the hedged default. ML-DSA normally mixes fresh randomness into every signature, so signing the same bytes twice yields two different .sig files; deterministic signing makes the signature a pure function of key and message, which is what you want if the signature is checked in, cached, or compared between builds. The hedged default is the more conservative choice against fault and side-channel attacks on the signing host. Ignored for other key types: RSA-PSS is hedged and has no such option, while Ed25519 and Ed448 are deterministic by specification.2False�
�
output_name�Filename for the signed output (defaults to the bsx target's filename). Overridden by an explicit output path passed as the first argument at run time.2""�
�
signing_key_cmd�Shell command that outputs the signing private key (PEM) to stdout. Runs at 'bazel run' time, so it can be interactive (e.g., 1Password). fBSX rules for building self-extracting binaries with integrity verification and cryptographic signing. 