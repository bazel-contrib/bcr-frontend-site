�
+
rules_cc_autoconfautoconfautoconf.bzl�autoconf�Run autoconf-like checks and produce results.

This rule resolves the `autoconf_toolchain` (when registered) to skip redundant
checker actions. If a check's cache variable name already has a result in the
toolchain or in transitive `deps`, the existing result file is reused.

Use `autoconf_cache` instead for targets that feed into `autoconf_toolchain`
to avoid a dependency cycle.

Example:

```python
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")

autoconf(
    name = "config",
    checks = [
        checks.AC_CHECK_HEADER("stdio.h"),
        checks.AC_CHECK_HEADER("stdlib.h"),
        checks.AC_CHECK_FUNC("printf"),
    ],
)
```

The results can then be used by `autoconf_hdr` or `autoconf_srcs` to generate
headers or wrapped source files.
*�
�
autoconf*
nameA unique name for this target. (�
build_settings�List of `checks.AC_BUILD_SETTING(...)` entries
associating Bazel build setting targets (any rule providing
`BuildSettingInfo`) with autoconf-style defines and substitutions.None(h
checksVList of JSON-encoded checks from `checks`
(e.g., `checks.AC_CHECK_HEADER('stdio.h')`).None(a
depsQAdditional `autoconf`, `autoconf_cache`, or `autoconf_package_info`
dependencies.None(�
kwargs�Standard Bazel attributes (e.g. `visibility`, `tags`) and the
rule's other attributes: `cc_deps` (libraries the checks compile
against and link, as configure's CPPFLAGS and LIBS carry them),
`default_deps`, `copts`, `conlyopts`, `cxxopts`.(�Run autoconf-like checks and produce results.

This rule resolves the `autoconf_toolchain` (when registered) to skip redundant
checker actions. If a check's cache variable name already has a result in the
toolchain or in transitive `deps`, the existing result file is reused.

Use `autoconf_cache` instead for targets that feed into `autoconf_toolchain`
to avoid a dependency cycle.

Example:

```python
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")

autoconf(
    name = "config",
    checks = [
        checks.AC_CHECK_HEADER("stdio.h"),
        checks.AC_CHECK_HEADER("stdlib.h"),
        checks.AC_CHECK_FUNC("printf"),
    ],
)
```

The results can then be used by `autoconf_hdr` or `autoconf_srcs` to generate
headers or wrapped source files.
26
autoconf*@@rules_cc_autoconf//autoconf:autoconf.bzl
		*_autoconf_rule2_autoconf_rule�
'//autoconf/private:autoconf_library.bzlr�
;
rules_cc_autoconfautoconf/privateautoconf_library.bzl>
to_build_settings_dictto_build_settings_dict
(
autoconf_autoconf_rule


# autoconf�
<
rules_cc_autoconfautoconf/macros/AC_C_INLINE
inline.bzl�ac_c_inline�Detect the C inline keyword variant supported by the compiler.

Implements the GNU autoconf AC_C_INLINE fallback chain. Tries the bare
`inline` keyword first (C99/C11), then `__inline__` (GCC/Clang), then
`__inline` (MSVC). If none compile, defines `inline` to empty.

The `deps` attribute lists standard `autoconf` targets that run the individual
keyword compile checks. The `keywords` attribute maps each keyword to the cache
variable name used as the lookup key in the deps' results.

Returns a CcAutoconfInfo provider with the `inline` define result,
compatible with the standard `autoconf` rule for use as a dependency.
"�	
�
ac_c_inline�Detect the C inline keyword variant supported by the compiler.

Implements the GNU autoconf AC_C_INLINE fallback chain. Tries the bare
`inline` keyword first (C99/C11), then `__inline__` (GCC/Clang), then
`__inline` (MSVC). If none compile, defines `inline` to empty.

The `deps` attribute lists standard `autoconf` targets that run the individual
keyword compile checks. The `keywords` attribute maps each keyword to the cache
variable name used as the lookup key in the deps' results.

Returns a CcAutoconfInfo provider with the `inline` define result,
compatible with the standard `autoconf` rule for use as a dependency.
*
nameA unique name for this target. ]
deps=autoconf targets providing the keyword compile check results.*
CcAutoconfInfo2[]v
keywordsfOrdered mapping of keyword -> cache variable name. Processed in insertion order as the fallback chain.
 "J
ac_c_inline;@@rules_cc_autoconf//autoconf/macros/AC_C_INLINE:inline.bzl
PP,
*
nameA unique name for this target. _
]
deps=autoconf targets providing the keyword compile check results.*
CcAutoconfInfo2[]x
v
keywordsfOrdered mapping of keyword -> cache variable name. Processed in insertion order as the fallback chain.
 q
:features.bzlr^

bazel_featuresfeatures.bzl.
bazel_featuresbazel_features
)7
9�
//autoconf:cc_autoconf_info.bzlrs
3
rules_cc_autoconfautoconfcc_autoconf_info.bzl.
CcAutoconfInfoCcAutoconfInfo
<J
L�
&//autoconf/private:autoconf_config.bzlr�
:
rules_cc_autoconfautoconf/privateautoconf_config.bzl*
collect_depscollect_deps
COF
collect_transitive_resultscollect_transitive_results
Sm
o�Custom rule for AC_C_INLINE keyword detection.

Implements the GNU autoconf AC_C_INLINE fallback chain:
  1. inline      â C99/C11 keyword (no #define needed if it works)
  2. __inline__  â GCC/Clang extension
  3. __inline    â MSVC extension
  4. (none)      â #define inline to empty

Wrapped in #ifndef __cplusplus because C++ always supports inline.

This cannot be expressed with the core `autoconf` rule because the fallback
chain requires multiple compile checks that resolve to a single define, and
the core rule rejects duplicate defines for the same name.

The individual keyword compile checks are standard `autoconf` targets listed
in `deps`. The `keywords` dict maps each keyword to the cache variable name
used as the key lookup into the deps' results. The resolver picks the first
successful keyword.
�
@
rules_cc_autoconfautoconf/macros/AC_C_RESTRICTrestrict.bzl�	ac_c_restrict�Detect the C restrict keyword variant supported by the compiler.

Implements the GNU autoconf AC_C_RESTRICT fallback chain with autoconf's own
test program: `__restrict__`, then `__restrict`, then `_Restrict`, then
`restrict` (no define when the bare keyword is what works). If none compile,
defines `restrict` to empty, as happens with cl.exe.

Returns a CcAutoconfInfo provider with the `restrict` define result,
compatible with the standard `autoconf` rule for use as a dependency.
"�
�
ac_c_restrict�Detect the C restrict keyword variant supported by the compiler.

Implements the GNU autoconf AC_C_RESTRICT fallback chain with autoconf's own
test program: `__restrict__`, then `__restrict`, then `_Restrict`, then
`restrict` (no define when the bare keyword is what works). If none compile,
defines `restrict` to empty, as happens with cl.exe.

Returns a CcAutoconfInfo provider with the `restrict` define result,
compatible with the standard `autoconf` rule for use as a dependency.
*
nameA unique name for this target. "P
ac_c_restrict?@@rules_cc_autoconf//autoconf/macros/AC_C_RESTRICT:restrict.bzl
��,
*
nameA unique name for this target. q
:features.bzlr^

bazel_featuresfeatures.bzl.
bazel_featuresbazel_features
)7
9�
//cc:find_cc_toolchain.bzlri
%
rules_ccccfind_cc_toolchain.bzl2
use_cc_toolchainuse_cc_toolchain
.>
@�
//autoconf:cc_autoconf_info.bzlrs
3
rules_cc_autoconfautoconfcc_autoconf_info.bzl.
CcAutoconfInfoCcAutoconfInfo
<J
L�
&//autoconf/private:autoconf_config.bzlr�
:
rules_cc_autoconfautoconf/privateautoconf_config.bzl8
AUTOCONF_EXEC_GROUPAUTOCONF_EXEC_GROUP
6
create_config_dictcreate_config_dict
<
get_cc_toolchain_infoget_cc_toolchain_info
D
get_environment_variablesget_environment_variables
4
write_config_jsonwrite_config_json
  
!�
(//autoconf/private:ctx_actions_write.bzlrj
<
rules_cc_autoconfautoconf/privatectx_actions_write.bzl
writewrite
"E"J
""L�Custom rule for AC_C_RESTRICT keyword detection.

Implements the GNU autoconf AC_C_RESTRICT fallback chain (autoconf 2.72,
lib/autoconf/c.m4), keywords tried in this order:
  1. __restrict__  â first, "to avoid problems with glibc and non-GCC"
  2. __restrict
  3. _Restrict
  4. restrict      â last, "because C++ lacks it"; no #define when it wins
  5. (none)        â #define restrict to empty
Every keyword is tried on a pointer parameter, an array parameter
(`int bar (int [kw]);`, "Catch GCC bug 14050") and a local pointer, exactly
as autoconf's test program does; cl.exe rejects the array form for all four,
which is why GNU configure defines `restrict` to nothing on MSVC.

This cannot be expressed with the core `autoconf` rule because the fallback
chain requires multiple compile checks that resolve to a single define, and
the core rule rejects duplicate defines for the same name.

The rule uses the standard checker binary for the individual compile checks
and a dedicated resolver tool to combine the results.
�]
:
rules_cc_autoconfautoconf/privateautoconf_config.bzl�cc_deps_args�Add the cc_deps flags to a checker command line.

`--cc-flag` carries the compile flags, `--link-library` the archives (as
Files, so path mapping rewrites them) and then the link flags.
*�
�
cc_deps_args+
argsThe checker action's arguments. (&
cc_depsFrom `collect_cc_deps`. (�Add the cc_deps flags to a checker command line.

`--cc-flag` carries the compile flags, `--link-library` the archives (as
Files, so path mapping rewrites them) and then the link flags.
2I
cc_deps_args9@@rules_cc_autoconf//autoconf/private:autoconf_config.bzl
���
collect_cc_deps�What the checks see of the target's `cc_deps`: configure's CPPFLAGS and LIBS.

Nothing here goes into the config file: the paths are action inputs that
path mapping (`--experimental_output_paths=strip`) rewrites on the command
line, so they reach the checker as `Args` (see `cc_deps_args`).
*�
�
collect_cc_deps?
cc_deps0The `cc_deps` attribute (targets with `CcInfo`). (D
compiler_type/The toolchain's compiler, for the flag dialect. (F
bin_dir7`ctx.bin_dir.path`, under which generated headers live. (�What the checks see of the target's `cc_deps`: configure's CPPFLAGS and LIBS.

Nothing here goes into the config file: the paths are action inputs that
path mapping (`--experimental_output_paths=strip`) rewrites on the command
line, so they reach the checker as `Args` (see `cc_deps_args`).
"�
�struct: `flags` (defines and source-tree include directories, plain
strings), `mapped_includes` (include directories under the output
tree, each with a header in it that stands witness to the mapped
prefix), `libraries` (File: the deps' archives), `link_flags`
(their user link flags), `inputs` (depset[File]: headers and
archives), and `key` (every flag, for the checks' content key).2L
collect_cc_deps9@@rules_cc_autoconf//autoconf/private:autoconf_config.bzl
���collect_defaultsRThe defaults a target reads: its `default_deps` and the defaults its `deps` carry.*�
�
collect_defaultsO
default_deps;The `default_deps` attribute (`autoconf_defaults` targets). ('
	dep_infosThe transitive `deps`. (RThe defaults a target reads: its `default_deps` and the defaults its `deps` carry."s
qdepset[CcAutoconfDefaultsInfo]: What this target reads and, as an
`autoconf` target, passes on to its dependents.2M
collect_defaults9@@rules_cc_autoconf//autoconf/private:autoconf_config.bzl
||�collect_deps+Collect `CcAutoconfInfo` from dependencies.*�
�
collect_deps
depsA list of `Target` (+Collect `CcAutoconfInfo` from dependencies."'
%depset: A depset of `CcAutoconfInfo`.2I
collect_deps9@@rules_cc_autoconf//autoconf/private:autoconf_config.bzl
���
 collect_transitive_content_cache�Collect transitive `content_cache` without conflict detection.

For action deduplication only. Unlike `collect_transitive_results`,
this does NOT validate define/subst uniqueness — the sole caller is
`autoconf_toolchain`'s `cache_deps` path, which intentionally tolerates
overlap so a broad sweep of cache providers (e.g., every gnulib m4
module) can be passed without analysis-time conflicts. Last-write-wins
is safe because the content key already encodes the full check
implementation, so any two files mapped to the same key are
interchangeable.
*�
�
 collect_transitive_content_cache,
	dep_infosA list of `CcAutoconfInfo`. (�Collect transitive `content_cache` without conflict detection.

For action deduplication only. Unlike `collect_transitive_results`,
this does NOT validate define/subst uniqueness — the sole caller is
`autoconf_toolchain`'s `cache_deps` path, which intentionally tolerates
overlap so a broad sweep of cache providers (e.g., every gnulib m4
module) can be passed without analysis-time conflicts. Last-write-wins
is safe because the content key already encodes the full check
implementation, so any two files mapped to the same key are
interchangeable.
";
9dict[str, File]: Mapping of content keys to result files.2]
 collect_transitive_content_cache9@@rules_cc_autoconf//autoconf/private:autoconf_config.bzl
���collect_transitive_results*Collect transitive cache variable results.*�
�
collect_transitive_results,
	dep_infosA list of `CcAutoconfInfo`. (*Collect transitive cache variable results."�
�dict: A mapping with keys "cache", "content_cache", "define", "subst"
(each dict[str, File]) and "unquoted_defines" (list[str]).
Defaults are not results: `collect_defaults` gathers them.2W
collect_transitive_results9@@rules_cc_autoconf//autoconf/private:autoconf_config.bzl
���constant_check_result�Return the result-file content for a check that needs no execution.

`AC_DEFINE` / `AC_SUBST` / `M4_VARIABLE` style checks with a literal value
and no `condition`/`requires` never touch a compiler: `check_define`
simply echoes the value back.  (It also ignores `code`, so the placeholder
program `M4_VARIABLE` carries does not disqualify it.)  For those the
result can be written at analysis time instead of spawning a
`CcAutoconfCheck` action.  The content produced here
mirrors `checker.cc` exactly (`{success, type, value}` with 4-space
indent, sorted keys, trailing newline) so downstream consumers cannot
tell the two apart.
*�
�
constant_check_resultF
check9Decoded check dict (as passed in the `checks` attribute). (�Return the result-file content for a check that needs no execution.

`AC_DEFINE` / `AC_SUBST` / `M4_VARIABLE` style checks with a literal value
and no `condition`/`requires` never touch a compiler: `check_define`
simply echoes the value back.  (It also ignores `code`, so the placeholder
program `M4_VARIABLE` carries does not disqualify it.)  For those the
result can be written at analysis time instead of spawning a
`CcAutoconfCheck` action.  The content produced here
mirrors `checker.cc` exactly (`{success, type, value}` with 4-space
indent, sorted keys, trailing newline) so downstream consumers cannot
tell the two apart.
"V
TThe file content as a string, or `None` when the check must run
through the checker.2R
constant_check_result9@@rules_cc_autoconf//autoconf/private:autoconf_config.bzl
88�create_config_dict3Create a config dictionary for the autoconf runner.*�
�
create_config_dict:
toolchain_info$Struct from get_cc_toolchain_info(). (3Create a config dictionary for the autoconf runner."0
.A dictionary representing the autoconf config.2O
create_config_dict9@@rules_cc_autoconf//autoconf/private:autoconf_config.bzl
���encode_result�Encode a value as a flat result JSON string.

Returns the content for a result file that can be referenced from
``CcAutoconfInfo``.  Using this function insulates callers from the
internal result-file schema.
*�
�
encode_result�
value�The result value.  Strings are JSON-encoded (quoted in the
output); numbers and booleans are stored as their JSON
representation.  Use ``None`` for a valueless define
(``#define FOO`` with no value). (�
success�Whether the check succeeded.  Defaults to ``True``.
A result with ``success=False`` is rendered as
``/* #undef FOO */`` in the generated header.True(�Encode a value as a flat result JSON string.

Returns the content for a result file that can be referenced from
``CcAutoconfInfo``.  Using this function insulates callers from the
internal result-file schema.
"3
1A JSON string suitable for ``ctx.actions.write``.2J
encode_result9@@rules_cc_autoconf//autoconf/private:autoconf_config.bzl
�get_autoconf_toolchain_cache�Get the content-based cache from the autoconf toolchain.

Returns the content cache of the toolchain's ``cache_deps``.  Used by the
``autoconf`` rule for content-based action deduplication.
*�
�
get_autoconf_toolchain_cacheG
ctx<The rule context (must declare the autoconf toolchain type). (�Get the content-based cache from the autoconf toolchain.

Returns the content cache of the toolchain's ``cache_deps``.  Used by the
``autoconf`` rule for content-based action deduplication.
"e
cdict[str, File]: Mapping of content keys to result files.
Empty dict if no toolchain is configured.2Y
get_autoconf_toolchain_cache9@@rules_cc_autoconf//autoconf/private:autoconf_config.bzl
ii�get_cc_toolchain_info8Get cc_toolchain information for autoconf configuration.*�
�
get_cc_toolchain_info
ctxThe rule context. (8Get cc_toolchain information for autoconf configuration."�
�A struct containing:
- cc_toolchain: The cc_toolchain
- feature_configuration: The feature configuration
- c_compiler_path: Path to C compiler
- cpp_compiler_path: Path to C++ compiler
- linker_path: Path to linker
- c_flags: List of C compiler flags
- cpp_flags: List of C++ compiler flags
- c_link_flags: List of C linker flags
- cpp_link_flags: List of C++ linker flags
- compiler_type: The compiler type2R
get_cc_toolchain_info9@@rules_cc_autoconf//autoconf/private:autoconf_config.bzl
���get_environment_variables6Get environment variables for running autoconf checks.*�
�
get_environment_variables
ctxThe rule context. (:
toolchain_info$Struct from get_cc_toolchain_info(). (6Get environment variables for running autoconf checks."(
&A dictionary of environment variables.2V
get_environment_variables9@@rules_cc_autoconf//autoconf/private:autoconf_config.bzl
���merge_defaults�Flatten defaults into one set of results.

Two defaults of one name must agree: the gnulib pattern has exactly one
`_H_DEFAULTS` macro assign each variable, so a disagreement is a port bug,
not something to resolve by order.
*�
�
merge_defaults?
default_infos*Usually `collect_defaults(...).to_list()`. (�Flatten defaults into one set of results.

Two defaults of one name must agree: the gnulib pattern has exactly one
`_H_DEFAULTS` macro assign each variable, so a disagreement is a port bug,
not something to resolve by order.
"a
_struct: `cache`, `define`, `subst` dicts (name to result file) and the
`unquoted_defines` list.2K
merge_defaults9@@rules_cc_autoconf//autoconf/private:autoconf_config.bzl
���merge_resultsAWhat a consumer reads: the defaults beneath the ordinary results.*�
�
merge_results:
dep_results'`collect_transitive_results` of `deps`. (6
defaults&`merge_defaults` of the defaults read. (AWhat a consumer reads: the defaults beneath the ordinary results."K
Istruct: `cache`, `define`, `subst` dicts and the `unquoted_defines` list.2J
merge_results9@@rules_cc_autoconf//autoconf/private:autoconf_config.bzl
���write_config_json)Write a config dictionary to a JSON file.*�
�
write_config_json
ctxThe rule context. (C
config_dict0The config dictionary from create_config_dict(). ()Write a config dictionary to a JSON file."+
)A File representing the config JSON file.2N
write_config_json9@@rules_cc_autoconf//autoconf/private:autoconf_config.bzl
��w
//cc:action_names.bzlr\
 
rules_ccccaction_names.bzl*
ACTION_NAMESACTION_NAMES
)5
7y
//cc/common:cc_common.bzlrZ
$
rules_cc	cc/commoncc_common.bzl$
	cc_common	cc_common
-6
8o
//cc/common:cc_info.bzlrR
"
rules_cc	cc/commoncc_info.bzl
CcInfoCcInfo
+1
3�
(//autoconf/private:ctx_actions_write.bzlrj
<
rules_cc_autoconfautoconf/privatectx_actions_write.bzl
writewrite
	E	J
		L�
 //autoconf/private:providers.bzlr�
4
rules_cc_autoconfautoconf/privateproviders.bzl>
CcAutoconfDefaultsInfoCcAutoconfDefaultsInfo

=
S.
CcAutoconfInfoCcAutoconfInfo

W
e


g-	AUTOCONF_EXEC_GROUPautoconfj
autoconf8# autoconf_config

Common utilities for autoconf rules.
�z
;
rules_cc_autoconfautoconf/privateautoconf_library.bzl�-autoconf�Run autoconf-like checks and produce results.

This rule resolves the ``autoconf_toolchain`` (when registered) to skip redundant
checker actions.  If a check's cache variable name already has a result in the
toolchain or in transitive ``deps``, the existing result file is reused.

Use ``autoconf_cache`` instead for targets that feed into ``autoconf_toolchain``
to avoid a dependency cycle.

Example:

```python
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")

autoconf(
    name = "config",
    checks = [
        checks.AC_CHECK_HEADER("stdio.h"),
        checks.AC_CHECK_HEADER("stdlib.h"),
        checks.AC_CHECK_FUNC("printf"),
    ],
)
```

The results can then be used by `autoconf_hdr` or `autoconf_srcs` to generate headers
or wrapped source files.
"�&
�
autoconf�Run autoconf-like checks and produce results.

This rule resolves the ``autoconf_toolchain`` (when registered) to skip redundant
checker actions.  If a check's cache variable name already has a result in the
toolchain or in transitive ``deps``, the existing result file is reused.

Use ``autoconf_cache`` instead for targets that feed into ``autoconf_toolchain``
to avoid a dependency cycle.

Example:

```python
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")

autoconf(
    name = "config",
    checks = [
        checks.AC_CHECK_HEADER("stdio.h"),
        checks.AC_CHECK_HEADER("stdlib.h"),
        checks.AC_CHECK_FUNC("printf"),
    ],
)
```

The results can then be used by `autoconf_hdr` or `autoconf_srcs` to generate headers
or wrapped source files.
*
nameA unique name for this target. �
build_settings�Mapping of Bazel build setting targets (any rule providing `BuildSettingInfo`) to JSON metadata produced by `checks.AC_BUILD_SETTING`.	*
BuildSettingInfo2{}�
cc_deps�Libraries the checks compile against and link, as configure's CPPFLAGS and LIBS carry a project's dependencies: every check sees their include directories and defines, and every link probe links their archives after its own object.  Their flags are part of each check's identity, so a check never shares a result between targets with different `cc_deps`.  Prefer `cc_deps = ["@gmp//:gmp"]` with a real `AC_CHECK_LIB` over a static `AC_DEFINE`.*
CcInfo2[]d
checksTList of JSON-encoded checks from checks (e.g., `checks.AC_CHECK_HEADER('stdio.h')`).2[]�
	conlyopts�Flags for the C compiles of this target's checks only, after `copts` (as on a cc_library).  Not transitive: flags for every check of a build, the gnulib ports included, are `--copt`.2[]�
copts�Flags for every compile of this target's checks, after the toolchain's and `--copt` / `--cxxopt` and before a check's own `copts` (the order of a cc_library's), so they win over the command line where the last flag counts.  Not transitive.2[]~
cxxoptsmFlags for the C++ compiles of this target's checks only, after `copts` (as on a cc_library).  Not transitive.2[]�
default_deps�`autoconf_defaults` targets.  Their values stand where no result of the name comes through `deps`; a result overrides a default silently, and two defaults of one name must agree.  The defaults a `deps` entry carries are read as well, and dependents of this target read all of them in turn.  This is gnulib's `*_H_DEFAULTS` pattern (`HAVE_X=1`, `REPLACE_X=0` before the probes may reassign them): list a header's `:defaults` here where the m4 `AC_REQUIRE`s `gl_<HEADER>_H_DEFAULTS`.*
CcAutoconfDefaultsInfo2[]s
depsSAdditional `autoconf`, `autoconf_library`, or `autoconf_package_info` dependencies.*
CcAutoconfInfo2[]"F
autoconf:@@rules_cc_autoconf//autoconf/private:autoconf_library.bzl
��,
*
nameA unique name for this target. �
�
build_settings�Mapping of Bazel build setting targets (any rule providing `BuildSettingInfo`) to JSON metadata produced by `checks.AC_BUILD_SETTING`.	*
BuildSettingInfo2{}�
�
cc_deps�Libraries the checks compile against and link, as configure's CPPFLAGS and LIBS carry a project's dependencies: every check sees their include directories and defines, and every link probe links their archives after its own object.  Their flags are part of each check's identity, so a check never shares a result between targets with different `cc_deps`.  Prefer `cc_deps = ["@gmp//:gmp"]` with a real `AC_CHECK_LIB` over a static `AC_DEFINE`.*
CcInfo2[]f
d
checksTList of JSON-encoded checks from checks (e.g., `checks.AC_CHECK_HEADER('stdio.h')`).2[]�
�
	conlyopts�Flags for the C compiles of this target's checks only, after `copts` (as on a cc_library).  Not transitive: flags for every check of a build, the gnulib ports included, are `--copt`.2[]�
�
copts�Flags for every compile of this target's checks, after the toolchain's and `--copt` / `--cxxopt` and before a check's own `copts` (the order of a cc_library's), so they win over the command line where the last flag counts.  Not transitive.2[]�
~
cxxoptsmFlags for the C++ compiles of this target's checks only, after `copts` (as on a cc_library).  Not transitive.2[]�
�
default_deps�`autoconf_defaults` targets.  Their values stand where no result of the name comes through `deps`; a result overrides a default silently, and two defaults of one name must agree.  The defaults a `deps` entry carries are read as well, and dependents of this target read all of them in turn.  This is gnulib's `*_H_DEFAULTS` pattern (`HAVE_X=1`, `REPLACE_X=0` before the probes may reassign them): list a header's `:defaults` here where the m4 `AC_REQUIRE`s `gl_<HEADER>_H_DEFAULTS`.*
CcAutoconfDefaultsInfo2[]u
s
depsSAdditional `autoconf`, `autoconf_library`, or `autoconf_package_info` dependencies.*
CcAutoconfInfo2[]�(autoconf_cache�Run autoconf-like checks without resolving the autoconf toolchain.

Identical to ``autoconf`` except that it does **not** resolve the
``autoconf_toolchain``.  Use this rule for targets that are listed as
``cache_deps`` of an ``autoconf_toolchain`` -- using the regular ``autoconf``
rule in that position would create a dependency cycle.

Dep-level caching still applies: if a check's cache variable name already
has a result in transitive ``deps``, the action is skipped.
"�$
�
autoconf_cache�Run autoconf-like checks without resolving the autoconf toolchain.

Identical to ``autoconf`` except that it does **not** resolve the
``autoconf_toolchain``.  Use this rule for targets that are listed as
``cache_deps`` of an ``autoconf_toolchain`` -- using the regular ``autoconf``
rule in that position would create a dependency cycle.

Dep-level caching still applies: if a check's cache variable name already
has a result in transitive ``deps``, the action is skipped.
*
nameA unique name for this target. �
build_settings�Mapping of Bazel build setting targets (any rule providing `BuildSettingInfo`) to JSON metadata produced by `checks.AC_BUILD_SETTING`.	*
BuildSettingInfo2{}�
cc_deps�Libraries the checks compile against and link, as configure's CPPFLAGS and LIBS carry a project's dependencies: every check sees their include directories and defines, and every link probe links their archives after its own object.  Their flags are part of each check's identity, so a check never shares a result between targets with different `cc_deps`.  Prefer `cc_deps = ["@gmp//:gmp"]` with a real `AC_CHECK_LIB` over a static `AC_DEFINE`.*
CcInfo2[]d
checksTList of JSON-encoded checks from checks (e.g., `checks.AC_CHECK_HEADER('stdio.h')`).2[]�
	conlyopts�Flags for the C compiles of this target's checks only, after `copts` (as on a cc_library).  Not transitive: flags for every check of a build, the gnulib ports included, are `--copt`.2[]�
copts�Flags for every compile of this target's checks, after the toolchain's and `--copt` / `--cxxopt` and before a check's own `copts` (the order of a cc_library's), so they win over the command line where the last flag counts.  Not transitive.2[]~
cxxoptsmFlags for the C++ compiles of this target's checks only, after `copts` (as on a cc_library).  Not transitive.2[]�
default_deps�`autoconf_defaults` targets.  Their values stand where no result of the name comes through `deps`; a result overrides a default silently, and two defaults of one name must agree.  The defaults a `deps` entry carries are read as well, and dependents of this target read all of them in turn.  This is gnulib's `*_H_DEFAULTS` pattern (`HAVE_X=1`, `REPLACE_X=0` before the probes may reassign them): list a header's `:defaults` here where the m4 `AC_REQUIRE`s `gl_<HEADER>_H_DEFAULTS`.*
CcAutoconfDefaultsInfo2[]s
depsSAdditional `autoconf`, `autoconf_library`, or `autoconf_package_info` dependencies.*
CcAutoconfInfo2[]"L
autoconf_cache:@@rules_cc_autoconf//autoconf/private:autoconf_library.bzl
��,
*
nameA unique name for this target. �
�
build_settings�Mapping of Bazel build setting targets (any rule providing `BuildSettingInfo`) to JSON metadata produced by `checks.AC_BUILD_SETTING`.	*
BuildSettingInfo2{}�
�
cc_deps�Libraries the checks compile against and link, as configure's CPPFLAGS and LIBS carry a project's dependencies: every check sees their include directories and defines, and every link probe links their archives after its own object.  Their flags are part of each check's identity, so a check never shares a result between targets with different `cc_deps`.  Prefer `cc_deps = ["@gmp//:gmp"]` with a real `AC_CHECK_LIB` over a static `AC_DEFINE`.*
CcInfo2[]f
d
checksTList of JSON-encoded checks from checks (e.g., `checks.AC_CHECK_HEADER('stdio.h')`).2[]�
�
	conlyopts�Flags for the C compiles of this target's checks only, after `copts` (as on a cc_library).  Not transitive: flags for every check of a build, the gnulib ports included, are `--copt`.2[]�
�
copts�Flags for every compile of this target's checks, after the toolchain's and `--copt` / `--cxxopt` and before a check's own `copts` (the order of a cc_library's), so they win over the command line where the last flag counts.  Not transitive.2[]�
~
cxxoptsmFlags for the C++ compiles of this target's checks only, after `copts` (as on a cc_library).  Not transitive.2[]�
�
default_deps�`autoconf_defaults` targets.  Their values stand where no result of the name comes through `deps`; a result overrides a default silently, and two defaults of one name must agree.  The defaults a `deps` entry carries are read as well, and dependents of this target read all of them in turn.  This is gnulib's `*_H_DEFAULTS` pattern (`HAVE_X=1`, `REPLACE_X=0` before the probes may reassign them): list a header's `:defaults` here where the m4 `AC_REQUIRE`s `gl_<HEADER>_H_DEFAULTS`.*
CcAutoconfDefaultsInfo2[]u
s
depsSAdditional `autoconf`, `autoconf_library`, or `autoconf_package_info` dependencies.*
CcAutoconfInfo2[]�autoconf_impl_common>Shared implementation for autoconf and autoconf_library rules.*�
�
autoconf_impl_common%
ctxThe rule's context object. (C
resolve_toolchain*Whether or not to use the toolchain cache. (>Shared implementation for autoconf and autoconf_library rules."
The target providers.2R
autoconf_impl_common:@@rules_cc_autoconf//autoconf/private:autoconf_library.bzl
���to_build_settings_dict�Convert a list of `checks.AC_BUILD_SETTING(...)` structs to the dict the rule attribute requires.

The `build_settings` attribute on `autoconf` / `autoconf_cache` is typed
`attr.label_keyed_string_dict` -- the only pre-Bazel-9 attribute type that
carries `(Label, str)` pairs natively. Users author build settings as a
list of `checks.AC_BUILD_SETTING(target=..., name=..., define=...)` calls
(so each entry's keyword-argument signature is self-documenting); the
public `autoconf` / `autoconf_cache` macros call this helper to fold that
list into the `{label_str: metadata_json}` shape the rule attribute
accepts.

Once Bazel 9 is the minimum supported version, switch the attribute to
`string_keyed_label_dict` (key = metadata JSON, value = build-setting
target), have `AC_BUILD_SETTING` return a one-key dict the user composes
with `|`, and delete this helper together with the wrapping macros.
*�	
�	
to_build_settings_dictl
entries]List of structs produced by `checks.AC_BUILD_SETTING(...)`,
or `None` / empty for no entries. (�Convert a list of `checks.AC_BUILD_SETTING(...)` structs to the dict the rule attribute requires.

The `build_settings` attribute on `autoconf` / `autoconf_cache` is typed
`attr.label_keyed_string_dict` -- the only pre-Bazel-9 attribute type that
carries `(Label, str)` pairs natively. Users author build settings as a
list of `checks.AC_BUILD_SETTING(target=..., name=..., define=...)` calls
(so each entry's keyword-argument signature is self-documenting); the
public `autoconf` / `autoconf_cache` macros call this helper to fold that
list into the `{label_str: metadata_json}` shape the rule attribute
accepts.

Once Bazel 9 is the minimum supported version, switch the attribute to
`string_keyed_label_dict` (key = metadata JSON, value = build-setting
target), have `AC_BUILD_SETTING` return a one-key dict the user composes
with `|`, and delete this helper together with the wrapping macros.
"�
�A `dict[str, str]` mapping build-setting label strings to JSON
metadata blobs, suitable for the rule's `build_settings` attribute.2T
to_build_settings_dict:@@rules_cc_autoconf//autoconf/private:autoconf_library.bzl
��q
:features.bzlr^

bazel_featuresfeatures.bzl.
bazel_featuresbazel_features
)7
9�
//rules:common_settings.bzlrn
*
bazel_skylibrulescommon_settings.bzl2
BuildSettingInfoBuildSettingInfo
3C
E�
//cc:find_cc_toolchain.bzlri
%
rules_ccccfind_cc_toolchain.bzl2
use_cc_toolchainuse_cc_toolchain
.>
@o
//cc/common:cc_info.bzlrR
"
rules_cc	cc/commoncc_info.bzl
CcInfoCcInfo
+1
3�
&//autoconf/private:autoconf_config.bzlr�
:
rules_cc_autoconfautoconf/privateautoconf_config.bzl8
AUTOCONF_EXEC_GROUPAUTOCONF_EXEC_GROUP
		*
cc_deps_argscc_deps_args


0
collect_cc_depscollect_cc_deps
2
collect_defaultscollect_defaults
*
collect_depscollect_deps
F
collect_transitive_resultscollect_transitive_results
 <
constant_check_resultconstant_check_result
6
create_config_dictcreate_config_dict
,
encode_resultencode_result
J
get_autoconf_toolchain_cacheget_autoconf_toolchain_cache
"<
get_cc_toolchain_infoget_cc_toolchain_info
D
get_environment_variablesget_environment_variables
.
merge_defaultsmerge_defaults
4
write_config_jsonwrite_config_json

�
&//autoconf/private:condition_utils.bzlr�
:
rules_cc_autoconfautoconf/privatecondition_utils.bzl>
extract_condition_varsextract_condition_vars
CY2
strip_macro_argsstrip_macro_args
]m
o�
(//autoconf/private:ctx_actions_write.bzlrj
<
rules_cc_autoconfautoconf/privatectx_actions_write.bzl
writewrite
EJ
L�
 //autoconf/private:providers.bzlr�
4
rules_cc_autoconfautoconf/privateproviders.bzl>
CcAutoconfDefaultsInfoCcAutoconfDefaultsInfo
=S.
CcAutoconfInfoCcAutoconfInfo
We
gautoconf implementation�*
5
rules_cc_autoconfautoconf/privatecheck_info.bzl�
make_check�Encode a check dict as JSON.

Single entry point for all factory functions. Currently a thin wrapper
around json.encode(); exists so that future global transformations or
legacy conversions can be applied in one place.
*�
�

make_checkL
check?Dict with check fields (e.g. {"type": "compile", "name": ...}). (�Encode a check dict as JSON.

Single entry point for all factory functions. Currently a thin wrapper
around json.encode(); exists so that future global transformations or
legacy conversions can be applied in one place.
"E
CA JSON-encoded string suitable for the autoconf rule's checks attr.2B

make_check4@@rules_cc_autoconf//autoconf/private:check_info.bzl
@@�"AutoconfCheckInfo�Structured autoconf check definition with typed, documented fields. Used by the validation aspect to parse check JSON at analysis time.2� 
�
AutoconfCheckInfo�Structured autoconf check definition with typed, documented fields. Used by the validation aspect to parse check JSON at analysis time.�
code|(str | list[str]): C/C++ program to compile or link for this check, or a list of programs tried in order until one succeeds.�
code_must_fail�str: Optional second probe whose compile must FAIL for the check to succeed. Used by AC_CHECK_TYPE to distinguish a type from a variable.d
compile_definesQlist[str]: Preprocessor define names from previous checks to add before includes.R
	conditionEstr: Boolean expression that selects between if_true/if_false values.V
coptsMlist[str]: Extra compiler flags for this check (e.g. ['-msse2', '-std=c11'])._
defineU(str | bool): Define name to set in config.h, or True to use the cache variable name.Q
define_valueA(str | int | None): Value for the define when the check succeeds.S
define_value_fail>(str | int | None): Value for the define when the check fails.S
errorJstr: Stop the build with this message when the check fails (AC_MSG_ERROR).>
flag6str: Compiler flag to test (for compiler-flag checks).Q
if_falseE(str | int | None): Value to use when a condition evaluates to false.O
if_trueD(str | int | None): Value to use when a condition evaluates to true.V

input_depsH(list[str]) Dependency variable names (wiring only, not run conditions).8
language,(str) Language for the check ('c' or 'cpp').K
	libraries>list[str]: Library names to search in order (for search_libs).G
library<str: Single library name to link against (for AC_CHECK_LIB).T
linkoptsHlist[str]: Extra linker flags for this check (e.g. ['-Wl,--as-needed']).?
name7str: Cache variable name (e.g. 'ac_cv_header_stdio_h').O
requiresC(list[str]): Requirements that must be truthy for the check to run.y
substp(str | bool | None): Substitution variable name for `@VAR@` replacement, or True to use the cache variable name.O
typeGstr: Check type (compile, link, function, type, sizeof, alignof, etc.).S
unquoteHbool: If true, emit the define with unquoted (AC_DEFINE_UNQUOTED) style."I
AutoconfCheckInfo4@@rules_cc_autoconf//autoconf/private:check_info.bzl
�2�2�
�
code|(str | list[str]): C/C++ program to compile or link for this check, or a list of programs tried in order until one succeeds.�
�
code_must_fail�str: Optional second probe whose compile must FAIL for the check to succeed. Used by AC_CHECK_TYPE to distinguish a type from a variable.f
d
compile_definesQlist[str]: Preprocessor define names from previous checks to add before includes.T
R
	conditionEstr: Boolean expression that selects between if_true/if_false values.X
V
coptsMlist[str]: Extra compiler flags for this check (e.g. ['-msse2', '-std=c11']).a
_
defineU(str | bool): Define name to set in config.h, or True to use the cache variable name.S
Q
define_valueA(str | int | None): Value for the define when the check succeeds.U
S
define_value_fail>(str | int | None): Value for the define when the check fails.U
S
errorJstr: Stop the build with this message when the check fails (AC_MSG_ERROR).@
>
flag6str: Compiler flag to test (for compiler-flag checks).S
Q
if_falseE(str | int | None): Value to use when a condition evaluates to false.Q
O
if_trueD(str | int | None): Value to use when a condition evaluates to true.X
V

input_depsH(list[str]) Dependency variable names (wiring only, not run conditions).:
8
language,(str) Language for the check ('c' or 'cpp').M
K
	libraries>list[str]: Library names to search in order (for search_libs).I
G
library<str: Single library name to link against (for AC_CHECK_LIB).V
T
linkoptsHlist[str]: Extra linker flags for this check (e.g. ['-Wl,--as-needed']).A
?
name7str: Cache variable name (e.g. 'ac_cv_header_stdio_h').Q
O
requiresC(list[str]): Requirements that must be truthy for the check to run.{
y
substp(str | bool | None): Substitution variable name for `@VAR@` replacement, or True to use the cache variable name.Q
O
typeGstr: Check type (compile, link, function, type, sizeof, alignof, etc.).U
S
unquoteHbool: If true, emit the define with unquoted (AC_DEFINE_UNQUOTED) style.�Schema for autoconf check definitions.

Provides `make_check()` for JSON encoding (used by factory functions at
loading time) and `AutoconfCheck` provider for structured analysis-time
validation (used only by the validation aspect).
�
:
rules_cc_autoconfautoconf/privatecondition_utils.bzl�extract_condition_vars�Extract all variable names from a condition expression.

Handles compound expressions with ``||``, ``&&``, ``!``, ``()``, and
comparison operators (``==``, ``!=``, ``<``, ``>``, ``<=``, ``>=``).
*�
�
extract_condition_varsM
exprAA condition expression string, e.g. ``"HAVE_X==0 || REPLACE_X"``. (�Extract all variable names from a condition expression.

Handles compound expressions with ``||``, ``&&``, ``!``, ``()``, and
comparison operators (``==``, ``!=``, ``<``, ``>``, ``<=``, ``>=``).
"I
GA list of unique variable name strings, in the order they first appear.2S
extract_condition_vars9@@rules_cc_autoconf//autoconf/private:condition_utils.bzl
%%�strip_macro_args�Return the bare identifier from a possibly function-like define name.

`AC_DEFINE("FOO(a, b)", ...)` writes `#define FOO(a, b) ...` in the
generated header, but the C symbol identity — and what the cache
variable / duplicate-detection registry key on — is just `FOO`.
*�
�
strip_macro_argsx
namelA define name, optionally including a function-like macro
argument list (e.g. ``"FOO"`` or ``"FOO(a, b)"``). (�Return the bare identifier from a possibly function-like define name.

`AC_DEFINE("FOO(a, b)", ...)` writes `#define FOO(a, b) ...` in the
generated header, but the C symbol identity — and what the cache
variable / duplicate-detection registry key on — is just `FOO`.
"?
=The bare identifier with any ``(...)`` argument list removed.2M
strip_macro_args9@@rules_cc_autoconf//autoconf/private:condition_utils.bzl
		�Utilities for extracting variable names from condition expressions.

Shared by autoconf_library.bzl and autoconf_srcs.bzl so that the Starlark-side
dependency graph wiring matches what the C++ condition evaluator expects.
�
<
rules_cc_autoconfautoconf/privatectx_actions_write.bzl�write*�
y
write
actions (
output (
content (2D
write;@@rules_cc_autoconf//autoconf/private:ctx_actions_write.bzl
q
:features.bzlr^

bazel_featuresfeatures.bzl.
bazel_featuresbazel_features
)7
9Wrappers for writing files�"
4
rules_cc_autoconfautoconf/privateproviders.bzl�CcAutoconfDefaultsInfo�Default values for autoconf results, produced by `autoconf_defaults`.

Defaults are not check results: nothing probes for them, and they never take
part in duplicate detection.  A target reads them through `default_deps`,
beneath every ordinary result, so a probe of the same name overrides a default
silently.  This is gnulib's `*_H_DEFAULTS` pattern (`HAVE_X=1`, `REPLACE_X=0`
before the probes may reassign them).  Only `default_deps` accepts this
provider; `deps` does not.
2�
�
CcAutoconfDefaultsInfo�Default values for autoconf results, produced by `autoconf_defaults`.

Defaults are not check results: nothing probes for them, and they never take
part in duplicate detection.  A target reads them through `default_deps`,
beneath every ordinary result, so a probe of the same name overrides a default
silently.  This is gnulib's `*_H_DEFAULTS` pattern (`HAVE_X=1`, `REPLACE_X=0`
before the probes may reassign them).  Only `default_deps` accepts this
provider; `deps` does not.
l
cache_results[dict[str, File]: Cache variable name to result file, for `requires`/`condition` resolution.{
contentpdict[str, str]: Result file path to its content. Two defaults of one name must agree, which this is compared on.>
define_results,dict[str, File]: Define name to result file./
owner&Label: The `autoconf_defaults` target.<
subst_results+dict[str, File]: Subst name to result file.>
unquoted_defines*list[str]: Define names rendered unquoted."M
CcAutoconfDefaultsInfo3@@rules_cc_autoconf//autoconf/private:providers.bzl
8B8Bn
l
cache_results[dict[str, File]: Cache variable name to result file, for `requires`/`condition` resolution.}
{
contentpdict[str, str]: Result file path to its content. Two defaults of one name must agree, which this is compared on.@
>
define_results,dict[str, File]: Define name to result file.1
/
owner&Label: The `autoconf_defaults` target.>
<
subst_results+dict[str, File]: Subst name to result file.@
>
unquoted_defines*list[str]: Define names rendered unquoted.�CcAutoconfInfo9A provider containing autoconf configuration and results.2�
�
CcAutoconfInfo9A provider containing autoconf configuration and results.�
cache_resultsqdict[str, File]: A map of cache variable names to flat result JSON files. Used for requires/condition resolution.�
content_cachewdict[str, File]: A map of content-based keys to result files. Used for action deduplication across deps and toolchains.�
defaults�depset[CcAutoconfDefaultsInfo]: The defaults this target reads and passes on: its `default_deps` and the defaults of its `deps`. Kept apart from the results above; a consumer reads them only where no ordinary result of the name exists.y
define_resultsgdict[str, File]: A map of define names to flat result JSON files produced by `CcAutoconfCheck` actions.H
deps@depset[CcAutoconfInfo]: Dependencies of the current info target.6
owner-Label: The label of the owner of the results.w
subst_resultsfdict[str, File]: A map of subst names to flat result JSON files produced by `CcAutoconfCheck` actions.b
unquoted_definesNlist[str]: Define names that should be rendered unquoted (AC_DEFINE_UNQUOTED)."E
CcAutoconfInfo3@@rules_cc_autoconf//autoconf/private:providers.bzl
11�
�
cache_resultsqdict[str, File]: A map of cache variable names to flat result JSON files. Used for requires/condition resolution.�
�
content_cachewdict[str, File]: A map of content-based keys to result files. Used for action deduplication across deps and toolchains.�
�
defaults�depset[CcAutoconfDefaultsInfo]: The defaults this target reads and passes on: its `default_deps` and the defaults of its `deps`. Kept apart from the results above; a consumer reads them only where no ordinary result of the name exists.{
y
define_resultsgdict[str, File]: A map of define names to flat result JSON files produced by `CcAutoconfCheck` actions.J
H
deps@depset[CcAutoconfInfo]: Dependencies of the current info target.8
6
owner-Label: The label of the owner of the results.y
w
subst_resultsfdict[str, File]: A map of subst names to flat result JSON files produced by `CcAutoconfCheck` actions.d
b
unquoted_definesNlist[str]: Define names that should be rendered unquoted (AC_DEFINE_UNQUOTED).# providers�
:
rules_cc_autoconfautoconf/privatevalidate_checks.bzl�validate_checks_aspect:�
�
validate_checks_aspectdeps"*
nameA unique name for this target. *S
validate_checks_aspect9@@rules_cc_autoconf//autoconf/private:validate_checks.bzl
  ,
*
nameA unique name for this target. �
!//autoconf/private:check_info.bzlr{
5
rules_cc_autoconfautoconf/privatecheck_info.bzl4
AutoconfCheckInfoAutoconfCheckInfo
>O
QFAspect that validates check JSON at analysis time using AutoconfCheck.�
D
rules_cc_autoconf$autoconf/tests/core/auto_exec_groups	tests.bzl�auto_exec_groups_test"�
�
auto_exec_groups_test*
nameA unique name for this target. 
expected_checks21
target_under_test "\
auto_exec_groups_testC@@rules_cc_autoconf//autoconf/tests/core/auto_exec_groups:tests.bzl
��,
*
nameA unique name for this target. 

expected_checks21

target_under_test �
//lib:unittest.bzlr
!
bazel_skyliblibunittest.bzl*
analysistestanalysistest
*6 
assertsasserts
:A
CERegression tests for compiler probes with automatic execution groups.�
G
rules_cc_autoconf"autoconf/tests/core/build_settingstransition.bzl�transitioned_file�Wraps a target with a configuration transition that overrides the build_settings-test flags to non-default values, then re-exports its single output file under this rule's name."�
�
transitioned_file�Wraps a target with a configuration transition that overrides the build_settings-test flags to non-default values, then re-exports its single output file under this rule's name.*
nameA unique name for this target. M
actual?Target whose default output is re-emitted after the transition. "[
transitioned_fileF@@rules_cc_autoconf//autoconf/tests/core/build_settings:transition.bzl
  ,
*
nameA unique name for this target. O
M
actual?Target whose default output is re-emitted after the transition. �Transition wrapper that overrides the build_settings flags for testing.

Used to verify that values flowing through `checks.AC_BUILD_SETTING` actually
re-render the produced header when the underlying build setting changes
configuration -- not just when the user passes a different flag at the
command line.
�
H
rules_cc_autoconfautoconf/tests/core/cachingcaching_test_suite.bzl�content_dedup_same_file_test"�
�
content_dedup_same_file_test*
nameA unique name for this target. 
target_under_test "g
content_dedup_same_file_testG@@rules_cc_autoconf//autoconf/tests/core/caching:caching_test_suite.bzl
��,
*
nameA unique name for this target. 

target_under_test �"content_dep_dedup_reuses_file_test"�
�
"content_dep_dedup_reuses_file_test*
nameA unique name for this target. 
target_under_test "m
"content_dep_dedup_reuses_file_testG@@rules_cc_autoconf//autoconf/tests/core/caching:caching_test_suite.bzl
��,
*
nameA unique name for this target. 

target_under_test �%content_diff_val_different_files_test"�
�
%content_diff_val_different_files_test*
nameA unique name for this target. 
target_under_test "p
%content_diff_val_different_files_testG@@rules_cc_autoconf//autoconf/tests/core/caching:caching_test_suite.bzl
��,
*
nameA unique name for this target. 

target_under_test �sibling_conflict_test"�
�
sibling_conflict_test*
nameA unique name for this target. 
target_under_test "`
sibling_conflict_testG@@rules_cc_autoconf//autoconf/tests/core/caching:caching_test_suite.bzl
��,
*
nameA unique name for this target. 

target_under_test �!tc_content_dedup_reuses_file_test"�
�
!tc_content_dedup_reuses_file_test*
nameA unique name for this target. 
target_under_test "l
!tc_content_dedup_reuses_file_testG@@rules_cc_autoconf//autoconf/tests/core/caching:caching_test_suite.bzl
��,
*
nameA unique name for this target. 

target_under_test �caching_test_suite0Test suite for autoconf dep-level check caching.*�
�
caching_test_suite'
nameThe name of the test suite. ()
kwargsAdditional keyword arguments.(0Test suite for autoconf dep-level check caching.2]
caching_test_suiteG@@rules_cc_autoconf//autoconf/tests/core/caching:caching_test_suite.bzl
��"autoconf"autoconf_hdr"autoconf_cache"autoconf_toolchain"_autoconf_with_toolchain"_autoconf_hdr_with_toolchain"sibling_conflict_test"content_dedup_same_file_test"%content_diff_val_different_files_test""content_dep_dedup_reuses_file_test"!tc_content_dedup_reuses_file_test*native.test_suite2native.test_suite�
//lib:unittest.bzlr
!
bazel_skyliblibunittest.bzl*
analysistestanalysistest
	*	6 
assertsasserts
	:	A
		Cy
//rules:build_test.bzlr]
%
bazel_skylibrulesbuild_test.bzl&

build_test
build_test

.
8


:y
//rules:write_file.bzlr]
%
bazel_skylibruleswrite_file.bzl&

write_file
write_file
.8
:|
//autoconf:autoconf.bzlr_
+
rules_cc_autoconfautoconfautoconf.bzl"
autoconfautoconf
4<
>�
//autoconf:autoconf_hdr.bzlrk
/
rules_cc_autoconfautoconfautoconf_hdr.bzl*
autoconf_hdrautoconf_hdr
8D
F�
!//autoconf:autoconf_toolchain.bzlr�
5
rules_cc_autoconfautoconfautoconf_toolchain.bzl.
autoconf_cacheautoconf_cache
>L6
autoconf_toolchainautoconf_toolchain
Pb
dt
//autoconf:checks.bzlrY
)
rules_cc_autoconfautoconf
checks.bzl
checkschecks
28
:�
 //autoconf/private:providers.bzlrt
4
rules_cc_autoconfautoconf/privateproviders.bzl.
CcAutoconfInfoCcAutoconfInfo
=K
M�
//autoconf/tests:diff_test.bzlrh
2
rules_cc_autoconfautoconf/testsdiff_test.bzl$
	diff_test	diff_test
;D
F�caching_test_suite

Test suite for verifying autoconf dep-level check caching.

When an autoconf target lists a check whose cache variable name already exists
in its deps, the check action is skipped and the dep's result file is reused.
�)
\
rules_cc_autoconf%autoconf/tests/core/condition_parsing condition_parsing_test_suite.bzl�and_test"�
�
and_test*
nameA unique name for this target. "g
and_test[@@rules_cc_autoconf//autoconf/tests/core/condition_parsing:condition_parsing_test_suite.bzl
��,
*
nameA unique name for this target. �
dedup_test"�
�

dedup_test*
nameA unique name for this target. "i

dedup_test[@@rules_cc_autoconf//autoconf/tests/core/condition_parsing:condition_parsing_test_suite.bzl
��,
*
nameA unique name for this target. �double_negation_test"�
�
double_negation_test*
nameA unique name for this target. "s
double_negation_test[@@rules_cc_autoconf//autoconf/tests/core/condition_parsing:condition_parsing_test_suite.bzl
��,
*
nameA unique name for this target. �equality_test"�
�
equality_test*
nameA unique name for this target. "l
equality_test[@@rules_cc_autoconf//autoconf/tests/core/condition_parsing:condition_parsing_test_suite.bzl
��,
*
nameA unique name for this target. �gnulib_getmntent_test"�
�
gnulib_getmntent_test*
nameA unique name for this target. "t
gnulib_getmntent_test[@@rules_cc_autoconf//autoconf/tests/core/condition_parsing:condition_parsing_test_suite.bzl
��,
*
nameA unique name for this target. �inequality_test"�
�
inequality_test*
nameA unique name for this target. "n
inequality_test[@@rules_cc_autoconf//autoconf/tests/core/condition_parsing:condition_parsing_test_suite.bzl
��,
*
nameA unique name for this target. �multi_and_test"�
�
multi_and_test*
nameA unique name for this target. "m
multi_and_test[@@rules_cc_autoconf//autoconf/tests/core/condition_parsing:condition_parsing_test_suite.bzl
��,
*
nameA unique name for this target. �multi_or_test"�
�
multi_or_test*
nameA unique name for this target. "l
multi_or_test[@@rules_cc_autoconf//autoconf/tests/core/condition_parsing:condition_parsing_test_suite.bzl
��,
*
nameA unique name for this target. �negation_test"�
�
negation_test*
nameA unique name for this target. "l
negation_test[@@rules_cc_autoconf//autoconf/tests/core/condition_parsing:condition_parsing_test_suite.bzl
��,
*
nameA unique name for this target. �nested_test"�
�
nested_test*
nameA unique name for this target. "j
nested_test[@@rules_cc_autoconf//autoconf/tests/core/condition_parsing:condition_parsing_test_suite.bzl
��,
*
nameA unique name for this target. �numeric_rhs_filtered_test"�
�
numeric_rhs_filtered_test*
nameA unique name for this target. "x
numeric_rhs_filtered_test[@@rules_cc_autoconf//autoconf/tests/core/condition_parsing:condition_parsing_test_suite.bzl
��,
*
nameA unique name for this target. �or_test"�
�
or_test*
nameA unique name for this target. "f
or_test[@@rules_cc_autoconf//autoconf/tests/core/condition_parsing:condition_parsing_test_suite.bzl
��,
*
nameA unique name for this target. �relational_test"�
�
relational_test*
nameA unique name for this target. "n
relational_test[@@rules_cc_autoconf//autoconf/tests/core/condition_parsing:condition_parsing_test_suite.bzl
��,
*
nameA unique name for this target. �simple_var_test"�
�
simple_var_test*
nameA unique name for this target. "n
simple_var_test[@@rules_cc_autoconf//autoconf/tests/core/condition_parsing:condition_parsing_test_suite.bzl
��,
*
nameA unique name for this target. �single_equals_test"�
�
single_equals_test*
nameA unique name for this target. "q
single_equals_test[@@rules_cc_autoconf//autoconf/tests/core/condition_parsing:condition_parsing_test_suite.bzl
��,
*
nameA unique name for this target. �condition_parsing_test_suite&Test suite for extract_condition_vars.*�
�
condition_parsing_test_suite#
nameName of the test suite. (>
kwargs2Additional keyword arguments passed to test_suite.(&Test suite for extract_condition_vars.2{
condition_parsing_test_suite[@@rules_cc_autoconf//autoconf/tests/core/condition_parsing:condition_parsing_test_suite.bzl
��"simple_var_test"negation_test"double_negation_test"equality_test"inequality_test"single_equals_test"or_test"and_test"nested_test"numeric_rhs_filtered_test"relational_test"
dedup_test"multi_or_test"multi_and_test"gnulib_getmntent_test*native.test_suite2simple_var_test2negation_test2double_negation_test2equality_test2inequality_test2single_equals_test2or_test2and_test2nested_test2numeric_rhs_filtered_test2relational_test2
dedup_test2multi_or_test2multi_and_test2gnulib_getmntent_test2native.test_suite�
//lib:unittest.bzlrw
!
bazel_skyliblibunittest.bzl 
assertsasserts
*1"
unittestunittest
5=
?�
&//autoconf/private:condition_utils.bzlr�
:
rules_cc_autoconfautoconf/privatecondition_utils.bzl>
extract_condition_varsextract_condition_vars
CY
[8Tests for extract_condition_vars in condition_utils.bzl.�
Z
rules_cc_autoconf$autoconf/tests/core/constant_resultsconstant_results_test_suite.bzl�constant_results_test_suite&Instantiate the constant-result tests.*�
�
constant_results_test_suite/
name#Name of the resulting `test_suite`. (&Instantiate the constant-result tests.2x
constant_results_test_suiteY@@rules_cc_autoconf//autoconf/tests/core/constant_results:constant_results_test_suite.bzl
qq"autoconf"_constants_skip_checker_test"_requires_use_checker_test"_result_file2autoconf2autoconf2_constants_skip_checker_test2_requires_use_checker_test2native.test_suite�
//lib:unittest.bzlr
!
bazel_skyliblibunittest.bzl*
analysistestanalysistest
*6 
assertsasserts
:A
C|
//autoconf:autoconf.bzlr_
+
rules_cc_autoconfautoconfautoconf.bzl"
autoconfautoconf
4<
>t
//autoconf:checks.bzlrY
)
rules_cc_autoconfautoconf
checks.bzl
checkschecks
28
:�
 //autoconf/private:providers.bzlrt
4
rules_cc_autoconfautoconf/privateproviders.bzl.
CcAutoconfInfoCcAutoconfInfo
=K
M�
//autoconf/tests:diff_test.bzlrh
2
rules_cc_autoconfautoconf/testsdiff_test.bzl$
	diff_test	diff_test
;D
F�constant_results_test_suite

Literal `AC_DEFINE` / `AC_SUBST` / `M4_VARIABLE` checks with no `condition`
or `requires` are written at analysis time instead of running the checker.
These tests pin three properties of that fast path:

1. No `CcAutoconfCheck` action is registered for such checks, while an
   otherwise identical check that carries `requires` still runs the checker.
2. The `autoconf_checks` output group still carries a `<name>.check.json`
   spec for every check resolved by the target, whichever path it took.
3. The written result file matches the one the checker produces for the same
   value, so nothing downstream can tell the paths apart.
�	
P
rules_cc_autoconf#autoconf/tests/core/global_linkoptslinkopt_transition.bzl�autoconf_with_flagsgWraps an autoconf target with a configuration transition that appends extra --copt and --linkopt flags."�
�
autoconf_with_flagsgWraps an autoconf target with a configuration transition that appends extra --copt and --linkopt flags.*
nameA unique name for this target. <
actualThe autoconf target to wrap. *
CcAutoconfInfo7
extra_copts"Additional --copt flags to inject.2[]=
extra_linkopts%Additional --linkopt flags to inject.2[]"f
autoconf_with_flagsO@@rules_cc_autoconf//autoconf/tests/core/global_linkopts:linkopt_transition.bzl
,
*
nameA unique name for this target. >
<
actualThe autoconf target to wrap. *
CcAutoconfInfo9
7
extra_copts"Additional --copt flags to inject.2[]?
=
extra_linkopts%Additional --linkopt flags to inject.2[]�
 //autoconf/private:providers.bzlrt
4
rules_cc_autoconfautoconf/privateproviders.bzl.
CcAutoconfInfoCcAutoconfInfo
=K
MITransition rule to inject extra --copt and --linkopt flags into a target.�
R
rules_cc_autoconf(autoconf/tests/core/has_feature_overridecopt_transition.bzl�	autoconf_with_copts�Wraps an autoconf target with a configuration transition that appends extra copts. This allows testing autoconf checks under non-standard compiler flags (e.g. flags containing shell metacharacters) without affecting the rest of the build."�
�
autoconf_with_copts�Wraps an autoconf target with a configuration transition that appends extra copts. This allows testing autoconf checks under non-standard compiler flags (e.g. flags containing shell metacharacters) without affecting the rest of the build.*
nameA unique name for this target. s
actualSThe autoconf target to wrap. The transition applies to this target's configuration. *
CcAutoconfInfo[
extra_coptsFAdditional --copt flags to inject into the transitioned configuration.2[]"h
autoconf_with_coptsQ@@rules_cc_autoconf//autoconf/tests/core/has_feature_override:copt_transition.bzl
,
*
nameA unique name for this target. u
s
actualSThe autoconf target to wrap. The transition applies to this target's configuration. *
CcAutoconfInfo]
[
extra_coptsFAdditional --copt flags to inject into the transitioned configuration.2[]�
 //autoconf/private:providers.bzlrt
4
rules_cc_autoconfautoconf/privateproviders.bzl.
CcAutoconfInfoCcAutoconfInfo
=K
METransition rule to inject extra --copt flags into an autoconf target.�
3
rules_cc_autoconfautoconf/tests/gnu
cc_env.bzl�autotools_cc_binary�Run a Python program with the autotools environment and the C++ toolchain.

Like `autotools_binary`, plus `CONVERT_CC_ENV`: the rlocationpath of a JSON
description of the current C++ toolchain (compiler, flags, environment), with
the toolchain's files in the runfiles."�
�
autotools_cc_binary�Run a Python program with the autotools environment and the C++ toolchain.

Like `autotools_binary`, plus `CONVERT_CC_ENV`: the rlocationpath of a JSON
description of the current C++ toolchain (compiler, flags, environment), with
the toolchain's files in the runfiles.*
nameA unique name for this target. $
runnerPython program to run. "I
autotools_cc_binary2@@rules_cc_autoconf//autoconf/tests/gnu:cc_env.bzl
__,
*
nameA unique name for this target. &
$
runnerPython program to run. �cc_env_dictLThe compiler, flags and environment of the C++ toolchain, as JSON-able data.*�
�
cc_env_dictD
ctx9a rule context with the `AUTOCONF_EXEC_GROUP` exec group. (3
toolchain_info`get_cc_toolchain_info(ctx)`. (LThe compiler, flags and environment of the C++ toolchain, as JSON-able data."�
�dict: keys `c_compiler`, `c_flags`, `c_link_flags`, `compiler_type`,
`cpp_compiler`, `cpp_flags`, `cpp_link_flags`, `env`, `linker`.2A
cc_env_dict2@@rules_cc_autoconf//autoconf/tests/gnu:cc_env.bzl
**�tool_rlocationpath�Convert an execroot-relative tool path into an rlocationpath.

Absolute paths (host toolchains such as `/usr/bin/gcc`) are returned as is.
*�
�
tool_rlocationpath:
path.the tool path as the C++ toolchain reports it. (+
workspace_name`ctx.workspace_name`. (�Convert an execroot-relative tool path into an rlocationpath.

Absolute paths (host toolchains such as `/usr/bin/gcc`) are returned as is.
".
,str: an rlocationpath, or the absolute path.2H
tool_rlocationpath2@@rules_cc_autoconf//autoconf/tests/gnu:cc_env.bzl
�
//cc:find_cc_toolchain.bzlri
%
rules_ccccfind_cc_toolchain.bzl2
use_cc_toolchainuse_cc_toolchain

.
>


@�
&//autoconf/private:autoconf_config.bzlr�
:
rules_cc_autoconfautoconf/privateautoconf_config.bzl8
AUTOCONF_EXEC_GROUPAUTOCONF_EXEC_GROUP
6
create_config_dictcreate_config_dict
<
get_cc_toolchain_infoget_cc_toolchain_info
D
get_environment_variablesget_environment_variables

�
"//autoconf/tests/gnu:toolchain.bzlr�
6
rules_cc_autoconfautoconf/tests/gnutoolchain.bzl4
SH_TOOLCHAIN_TYPESH_TOOLCHAIN_TYPE
?P.
TOOLCHAIN_TYPETOOLCHAIN_TYPE
Tb4
autotools_runtimeautotools_runtime
fw-
rlocationpathrlocationpath
{�(

shell_path
shell_path
��
��The C++ toolchain as a JSON description, for tools that run GNU configure.

`cc_env_dict` is what `gnu_autoconf_conformance_test` serializes as
`<name>.cc_env.json`; `autotools_cc_binary` makes the same description (and
the toolchain's files) available to a `bazel run` program through the
`CONVERT_CC_ENV` environment variable, so `//tools/convert`'s `check` can
drive `./configure` with the compiler the rules' probes use.
�8
8
rules_cc_autoconfautoconf/tests/gnuconformance.bzl�+gnu_autoconf_conformance_test�Wrapper adding the `gnu_autoconf_test` tag.

The oracle runs on every platform.  On Windows it runs under the
rules_shell bash with MSVC driven through gnulib's `compile` wrapper.


Check that Bazel reproduces GNU autoconf's output for a `configure.ac`.

GNU `aclocal`, `autoconf` and `configure` run with the pinned autotools
toolchain and with the compiler, flags and environment of the current C++
toolchain, exactly as the `autoconf` rule computes them.  The resulting
`config.h` and `subst.h` must match `bazel_config_h` / `bazel_subst_h` byte
for byte, except for variables listed in `known_divergences`.

Everything needed to review a result is left in the undeclared outputs
directory: `gnu/` (the configure work tree with config.h, subst.h and
config.log), `bazel/` (the Bazel headers), `*.diff` when they differ, the
configure environment, tool versions and the host toolchain fingerprint.
The staged m4 files and aux scripts (pinned inputs) and `autom4te.cache`
are removed after configure runs.
"�#
�
gnu_autoconf_conformance_test�Wrapper adding the `gnu_autoconf_test` tag.

The oracle runs on every platform.  On Windows it runs under the
rules_shell bash with MSVC driven through gnulib's `compile` wrapper.


Check that Bazel reproduces GNU autoconf's output for a `configure.ac`.

GNU `aclocal`, `autoconf` and `configure` run with the pinned autotools
toolchain and with the compiler, flags and environment of the current C++
toolchain, exactly as the `autoconf` rule computes them.  The resulting
`config.h` and `subst.h` must match `bazel_config_h` / `bazel_subst_h` byte
for byte, except for variables listed in `known_divergences`.

Everything needed to review a result is left in the undeclared outputs
directory: `gnu/` (the configure work tree with config.h, subst.h and
config.log), `bazel/` (the Bazel headers), `*.diff` when they differ, the
configure environment, tool versions and the host toolchain fingerprint.
The staged m4 files and aux scripts (pinned inputs) and `autom4te.cache`
are removed after configure runs.
*
nameA unique name for this target. |
autoconf_targetOThe `autoconf` target under test; its cache results feed the divergence report.*
CcAutoconfInfo2None[
	aux_filesHAuxiliary files (e.g. `config.rpath`) copied to the work directory root.2[][
bazel_config_hABazel-generated `config.h` (from `autoconf_hdr`, mode `defines`).2NoneZ
bazel_subst_hABazel-generated subst header (from `autoconf_hdr`, mode `subst`).2Noner
	build_auxB`config.guess` / `config.sub` and friends, from the pinned gnulib.2[Label("@@gnulib//:build-aux")]>
config_h_in+Template for AC_DEFINE (`#undef` patterns). 2
configure_acThe `configure.ac` under test. �
configure_args�Extra arguments for `./configure`. The default keeps configure in the same
language mode Bazel compiles in: autoconf 2.72+ `AC_PROG_CC` would otherwise
probe for C23 support and append `-std=gnu23` to `CC`, which changes results
such as `HAVE_C_BOOL` and gnulib's `NEXT_ASSERT_H` relative to the Bazel
toolchain's default standard. Likewise the C11 probe is told the default
mode already suffices: cl.exe is not C11 by default and configure would
append `-std:c11`, which enables `<threads.h>` and C11 math declarations
that the Bazel checks, running without that flag, do not see.2.["ac_cv_prog_cc_c23=no", "ac_cv_prog_cc_c11="]u
known_divergencesZVariable name -> reason, for intentional differences from upstream m4. Masked in the diff.
2{}Q
m4_files?Candidate m4 files; `aclocal` selects the ones actually needed.2[]?

subst_h_in)Template for AC_SUBST (`@FOO@` patterns).2None`
verify_variablesCRequire the templates to contain every variable configure produced.2False"Y
_gnu_autoconf_conformance_test7@@rules_cc_autoconf//autoconf/tests/gnu:conformance.bzl
��,
*
nameA unique name for this target. ~
|
autoconf_targetOThe `autoconf` target under test; its cache results feed the divergence report.*
CcAutoconfInfo2None]
[
	aux_filesHAuxiliary files (e.g. `config.rpath`) copied to the work directory root.2[]]
[
bazel_config_hABazel-generated `config.h` (from `autoconf_hdr`, mode `defines`).2None\
Z
bazel_subst_hABazel-generated subst header (from `autoconf_hdr`, mode `subst`).2Nonet
r
	build_auxB`config.guess` / `config.sub` and friends, from the pinned gnulib.2[Label("@@gnulib//:build-aux")]@
>
config_h_in+Template for AC_DEFINE (`#undef` patterns). 4
2
configure_acThe `configure.ac` under test. �
�
configure_args�Extra arguments for `./configure`. The default keeps configure in the same
language mode Bazel compiles in: autoconf 2.72+ `AC_PROG_CC` would otherwise
probe for C23 support and append `-std=gnu23` to `CC`, which changes results
such as `HAVE_C_BOOL` and gnulib's `NEXT_ASSERT_H` relative to the Bazel
toolchain's default standard. Likewise the C11 probe is told the default
mode already suffices: cl.exe is not C11 by default and configure would
append `-std:c11`, which enables `<threads.h>` and C11 math declarations
that the Bazel checks, running without that flag, do not see.2.["ac_cv_prog_cc_c23=no", "ac_cv_prog_cc_c11="]w
u
known_divergencesZVariable name -> reason, for intentional differences from upstream m4. Masked in the diff.
2{}S
Q
m4_files?Candidate m4 files; `aclocal` selects the ones actually needed.2[]A
?

subst_h_in)Template for AC_SUBST (`@FOO@` patterns).2Noneb
`
verify_variablesCRequire the templates to contain every variable configure produced.2False�
//cc:find_cc_toolchain.bzlri
%
rules_ccccfind_cc_toolchain.bzl2
use_cc_toolchainuse_cc_toolchain

.
>


@�
&//autoconf/private:autoconf_config.bzlr�
:
rules_cc_autoconfautoconf/privateautoconf_config.bzl8
AUTOCONF_EXEC_GROUPAUTOCONF_EXEC_GROUP
F
collect_transitive_resultscollect_transitive_results
 <
get_cc_toolchain_infoget_cc_toolchain_info

�
 //autoconf/private:providers.bzlrt
4
rules_cc_autoconfautoconf/privateproviders.bzl.
CcAutoconfInfoCcAutoconfInfo
=K
M�
//autoconf/tests/gnu:cc_env.bzlrm
3
rules_cc_autoconfautoconf/tests/gnu
cc_env.bzl(
cc_env_dictcc_env_dict
<G
I�
"//autoconf/tests/gnu:toolchain.bzlr�
6
rules_cc_autoconfautoconf/tests/gnutoolchain.bzl4
SH_TOOLCHAIN_TYPESH_TOOLCHAIN_TYPE
?P.
TOOLCHAIN_TYPETOOLCHAIN_TYPE
Tb4
autotools_runtimeautotools_runtime
fw-
rlocationpathrlocationpath
{�(

shell_path
shell_path
��
��gnu_autoconf_conformance_test

Runs GNU `aclocal`, `autoconf` and `configure` on a `configure.ac` with the
same compiler and flags the `autoconf` rule uses, then compares the rendered
`config.h` / `subst.h` against the Bazel-generated files.  Both sides of
every comparison, the diff, config.log, tool output and the environment are
written to the test's undeclared outputs directory.
�
1
rules_cc_autoconfautoconf/tests/gnudeps.bzl�
autoconf_repository7Fetches and installs GNU autoconf without a build step.R�	
�
autoconf_repository7Fetches and installs GNU autoconf without a build step..
name"A unique name for this repository. 
	integrity 
release_year �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 
version *G
autoconf_repository0@@rules_cc_autoconf//autoconf/tests/gnu:deps.bzl
k&k&0
.
name"A unique name for this repository. 

	integrity 

release_year �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 

version �
automake_repositoryCFetches and installs GNU automake's `aclocal` without a build step.R�

�
automake_repositoryCFetches and installs GNU automake's `aclocal` without a build step..
name"A unique name for this repository. 
api_version 
	integrity 
release_year �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 
version *G
automake_repository0@@rules_cc_autoconf//autoconf/tests/gnu:deps.bzl
�&�&0
.
name"A unique name for this repository. 

api_version 

	integrity 

release_year �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 

version �	autotoolsDPinned GNU autoconf and automake sources for the conformance oracle.J�
�
	autotoolsDPinned GNU autoconf and automake sources for the conformance oracle."=
	autotools0@@rules_cc_autoconf//autoconf/tests/gnu:deps.bzl
��'	AUTOMAKE_RELEASE_YEAR2025j2025&	AUTOMAKE_VERSION1.18.1j1.18.1'	AUTOCONF_RELEASE_YEAR2026j2026"	AUTOCONF_VERSION2.73j2.73&	AUTOMAKE_API_VERSION1.18j1.18�Pinned GNU autotools used as the conformance oracle.

Neither autoconf nor automake compiles anything.  Their `make install` is a
`sed` over a handful of `*.in` templates, so the whole install happens at
fetch time inside a repository rule and no build action is required.

Every location the tools would normally have baked in at install time is
overridable through their own environment variables (`autom4te_perllibdir`,
`AC_MACRODIR`, `AUTOM4TE_CFG`, `AUTOM4TE`, `trailer_m4`, `M4`,
`AUTOMAKE_UNINSTALLED`, `AUTOMAKE_LIBDIR`) or command line options
(`--automake-acdir`, `--system-acdir`).  The tester sets all of them from
runfiles, so the templates below are filled with sentinel paths that fail
loudly if anything ever falls back to them.
�
=
rules_cc_autoconfautoconf/tests/gnuhost_fingerprint.bzl�
host_cc_fingerprint@Writes the host compiler and SDK versions to `fingerprint.json`.R�	
�
host_cc_fingerprint@Writes the host compiler and SDK versions to `fingerprint.json`..
name"A unique name for this repository. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 "CC"BAZEL_CC"DEVELOPER_DIR"SDKROOT*S
host_cc_fingerprint<@@rules_cc_autoconf//autoconf/tests/gnu:host_fingerprint.bzl
C&C&0
.
name"A unique name for this repository. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �Record the host C/C++ toolchain identity as a build input.

`local_config_cc` does not change when Xcode or GCC is upgraded, so results
cached from an older compiler survive the upgrade and failures surface only on
fresh machines.  This repository rule writes the compiler and SDK versions to
`fingerprint.json`; anything that depends on that file is re-run when they
change.  It is best effort and never fails: on a machine where nothing can be
detected the file simply records that.
�'
6
rules_cc_autoconfautoconf/tests/gnutoolchain.bzl�autotools_binaryFRun a Python program with the autotools environment (for `bazel run`)."�
�
autotools_binaryFRun a Python program with the autotools environment (for `bazel run`).*
nameA unique name for this target. E
runner7Python program to run inside the autotools environment. K
tool=Tool name passed as `AUTOTOOLS_TOOL` (used by `run_tool.py`).2"""I
autotools_binary5@@rules_cc_autoconf//autoconf/tests/gnu:toolchain.bzl
��,
*
nameA unique name for this target. G
E
runner7Python program to run inside the autotools environment. M
K
tool=Tool name passed as `AUTOTOOLS_TOOL` (used by `run_tool.py`).2""�autotools_test1Run a Python test with the autotools environment."�
�
autotools_test1Run a Python test with the autotools environment.*
nameA unique name for this target. E
runner7Python program to run inside the autotools environment. K
tool=Tool name passed as `AUTOTOOLS_TOOL` (used by `run_tool.py`).2"""G
autotools_test5@@rules_cc_autoconf//autoconf/tests/gnu:toolchain.bzl
��,
*
nameA unique name for this target. G
E
runner7Python program to run inside the autotools environment. M
K
tool=Tool name passed as `AUTOTOOLS_TOOL` (used by `run_tool.py`).2""�autotools_toolchainABundle the pinned autoconf and automake sources with perl and m4."�
�
autotools_toolchainABundle the pinned autoconf and automake sources with perl and m4.*
nameA unique name for this target. /
aclocal automake's `bin/aclocal` script. 1
autoconf!autoconf's `bin/autoconf` script. E
autoconf_files/All autoconf runtime files (`bin/*`, `lib/**`). 
autoconf_version 
automake_api_version C
automake_files-All automake runtime files needed by aclocal. 
automake_version 
m4GNU m4 executable. "L
autotools_toolchain5@@rules_cc_autoconf//autoconf/tests/gnu:toolchain.bzl
OO,
*
nameA unique name for this target. 1
/
aclocal automake's `bin/aclocal` script. 3
1
autoconf!autoconf's `bin/autoconf` script. G
E
autoconf_files/All autoconf runtime files (`bin/*`, `lib/**`). 

autoconf_version 

automake_api_version E
C
automake_files-All automake runtime files needed by aclocal. 

automake_version 

m4GNU m4 executable. �autotools_runtime�Resolve the autotools toolchain into test environment and runfiles.

The returned environment is consumed by `autoconf/tests/gnu/autotools.py`.
*�
�
autotools_runtime9
ctx.a rule context that declared `TOOLCHAIN_TYPE`. (�Resolve the autotools toolchain into test environment and runfiles.

The returned environment is consumed by `autoconf/tests/gnu/autotools.py`.
"<
:struct: `env` (dict[str, str]) and `files` (depset[File]).2J
autotools_runtime5@@rules_cc_autoconf//autoconf/tests/gnu:toolchain.bzl
rr�rlocationpath%Compute the runfiles path for a file.*�
�
rlocationpath
file	the file. (+
workspace_name`ctx.workspace_name`. (%Compute the runfiles path for a file."
str: the rlocationpath.2F
rlocationpath5@@rules_cc_autoconf//autoconf/tests/gnu:toolchain.bzl
##�
shell_pathEThe host POSIX shell from rules_shell, or None if none is registered.*�
�

shell_pathG
ctx<a rule context that declared `SH_TOOLCHAIN_TYPE` (optional). (EThe host POSIX shell from rules_shell, or None if none is registered.""
 str | None: absolute shell path.2C

shell_path5@@rules_cc_autoconf//autoconf/tests/gnu:toolchain.bzl
�AutotoolsInfo?GNU autotools runtime: interpreters, scripts and support files.2�
�
AutotoolsInfo?GNU autotools runtime: interpreters, scripts and support files.6
aclocal+File: automake's `bin/aclocal` perl script.8
autoconf,File: autoconf's `bin/autoconf` perl script.1
autoconf_versionstr: pinned autoconf version.G
automake_api_version/str: pinned automake API version (e.g. `1.18`).1
automake_versionstr: pinned automake version.5
files,depset[File]: every file needed at run time.
m4File: GNU m4 executable.
perlFile: perl interpreter."F
AutotoolsInfo5@@rules_cc_autoconf//autoconf/tests/gnu:toolchain.bzl
8
6
aclocal+File: automake's `bin/aclocal` perl script.:
8
autoconf,File: autoconf's `bin/autoconf` perl script.3
1
autoconf_versionstr: pinned autoconf version.I
G
automake_api_version/str: pinned automake API version (e.g. `1.18`).3
1
automake_versionstr: pinned automake version.7
5
files,depset[File]: every file needed at run time. 

m4File: GNU m4 executable.!

perlFile: perl interpreter.]	PERL_TOOLCHAIN_TYPE @rules_perl//perl:toolchain_typej" @rules_perl//perl:toolchain_type_	SH_TOOLCHAIN_TYPE"@rules_shell//shell:toolchain_typej$"@rules_shell//shell:toolchain_typeb	TOOLCHAIN_TYPE%@@//autoconf/tests/gnu:toolchain_typej'%@@//autoconf/tests/gnu:toolchain_typeGToolchain exposing the pinned GNU autotools, perl and m4 to test rules.�*
4
rules_cc_autoconfautoconfautoconf_defaults.bzl�'autoconf_defaults�Default values for autoconf results.

A default is not a check: nothing is probed, no toolchain is resolved, and the
values are written at analysis time.  A target reads defaults through
`default_deps`, beneath every ordinary result, so a probe of the same name
overrides the default silently where a second probe would be a duplicate
error.  `deps` rejects defaults targets; they only enter through `default_deps`.

This is how gnulib's `*_H_DEFAULTS` macros work: `gl_UNISTD_H_DEFAULTS` sets
`HAVE_DUP3=1`, `REPLACE_DUP2=0` and so on, and the probes that run later
reassign only what they find wanting.  Port such a macro as one
`autoconf_defaults` target and list it in the `default_deps` of every target
whose m4 `AC_REQUIRE`s it:

```python
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:autoconf_defaults.bzl", "autoconf_defaults")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")

# gl_UNISTD_H_DEFAULTS
autoconf_defaults(
    name = "defaults",
    substs = {
        "HAVE_DUP3": "1",
        "REPLACE_DUP2": "0",
    },
)

# gl_FUNC_DUP2: AC_REQUIRE([gl_UNISTD_H_DEFAULTS]), then may set REPLACE_DUP2=1
autoconf(
    name = "dup2",
    checks = [
        checks.AC_SUBST("REPLACE_DUP2", 1, condition = "!gl_cv_func_dup2_works"),
    ],
    default_deps = [":defaults"],
)
```

Defaults compose: `deps` lists other `autoconf_defaults` targets whose values
this one carries along (gnulib's `_H_REQUIRE_DEFAULTS` on top of
`_H_DEFAULTS`), and an `autoconf` target passes the defaults it reads on to
its dependents.  Two defaults of one name must agree.
"�
�
autoconf_defaults�Default values for autoconf results.

A default is not a check: nothing is probed, no toolchain is resolved, and the
values are written at analysis time.  A target reads defaults through
`default_deps`, beneath every ordinary result, so a probe of the same name
overrides the default silently where a second probe would be a duplicate
error.  `deps` rejects defaults targets; they only enter through `default_deps`.

This is how gnulib's `*_H_DEFAULTS` macros work: `gl_UNISTD_H_DEFAULTS` sets
`HAVE_DUP3=1`, `REPLACE_DUP2=0` and so on, and the probes that run later
reassign only what they find wanting.  Port such a macro as one
`autoconf_defaults` target and list it in the `default_deps` of every target
whose m4 `AC_REQUIRE`s it:

```python
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:autoconf_defaults.bzl", "autoconf_defaults")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")

# gl_UNISTD_H_DEFAULTS
autoconf_defaults(
    name = "defaults",
    substs = {
        "HAVE_DUP3": "1",
        "REPLACE_DUP2": "0",
    },
)

# gl_FUNC_DUP2: AC_REQUIRE([gl_UNISTD_H_DEFAULTS]), then may set REPLACE_DUP2=1
autoconf(
    name = "dup2",
    checks = [
        checks.AC_SUBST("REPLACE_DUP2", 1, condition = "!gl_cv_func_dup2_works"),
    ],
    default_deps = [":defaults"],
)
```

Defaults compose: `deps` lists other `autoconf_defaults` targets whose values
this one carries along (gnulib's `_H_REQUIRE_DEFAULTS` on top of
`_H_DEFAULTS`), and an `autoconf` target passes the defaults it reads on to
its dependents.  Two defaults of one name must agree.
*
nameA unique name for this target. �
defines�Default `AC_DEFINE` values: define name to value.  Decimal integers are stored as numbers, as `checks.AC_DEFINE("X", 1)` stores them; anything else as text.
2{}q
depsIOther `autoconf_defaults` targets whose values this target carries along.*
CcAutoconfDefaultsInfo2[]�
substs�Default `AC_SUBST` values: variable name to value (`{"HAVE_DUP3": "1"}`), stored under the cache name `ac_cv_subst_<NAME>` as `checks.AC_SUBST` does.  Decimal integers are stored as numbers; anything else as text.
2{}�
	variables�Default shell variables that are neither defines nor substitutions (`checks.M4_VARIABLE`): name to value, read by `requires` and `condition` expressions and by `cc_gnulib_conditional_hdrs` conditions, e.g. `{"GL_GENERATE_ICONV_H": "false"}`.
2{}"H
autoconf_defaults3@@rules_cc_autoconf//autoconf:autoconf_defaults.bzl
[[,
*
nameA unique name for this target. �
�
defines�Default `AC_DEFINE` values: define name to value.  Decimal integers are stored as numbers, as `checks.AC_DEFINE("X", 1)` stores them; anything else as text.
2{}s
q
depsIOther `autoconf_defaults` targets whose values this target carries along.*
CcAutoconfDefaultsInfo2[]�
�
substs�Default `AC_SUBST` values: variable name to value (`{"HAVE_DUP3": "1"}`), stored under the cache name `ac_cv_subst_<NAME>` as `checks.AC_SUBST` does.  Decimal integers are stored as numbers; anything else as text.
2{}�
�
	variables�Default shell variables that are neither defines nor substitutions (`checks.M4_VARIABLE`): name to value, read by `requires` and `condition` expressions and by `cc_gnulib_conditional_hdrs` conditions, e.g. `{"GL_GENERATE_ICONV_H": "false"}`.
2{}�
(//autoconf/private:ctx_actions_write.bzlrj
<
rules_cc_autoconfautoconf/privatectx_actions_write.bzl
writewrite
EJ
L�
 //autoconf/private:providers.bzlr�
4
rules_cc_autoconfautoconf/privateproviders.bzl>
CcAutoconfDefaultsInfoCcAutoconfDefaultsInfo
=S
U# autoconf_defaults�<
/
rules_cc_autoconfautoconfautoconf_hdr.bzl�4autoconf_hdr�	Generate configuration headers from results provided by `autoconf` targets.

This rule takes check results from `autoconf` targets (via `deps`) and generates a header file.
The template file (if provided) is used to format the output header.

Example:

```python
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:autoconf_hdr.bzl", "autoconf_hdr")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")

autoconf(
    name = "config_checks",
    checks = [
        checks.AC_CHECK_HEADER("stdio.h"),
        checks.AC_CHECK_HEADER("stdlib.h"),
        checks.AC_CHECK_FUNC("printf"),
    ],
)

autoconf_hdr(
    name = "config",
    out = "config.h",
    deps = [":config_checks"],
    template = "config.h.in",
)
```

Valid `mode` values:
- `"defines"` (default): Only process defines (AC_DEFINE, AC_CHECK_*, etc.), not substitution variables (AC_SUBST). This is for config.h files.
- `"subst"`: Only process substitution variables (AC_SUBST), not defines. This is for subst.h files.
- `"all"`: Process both defines and substitution variables.

This allows you to run checks once and generate multiple header files from the same results.
"�+
�
autoconf_hdr�	Generate configuration headers from results provided by `autoconf` targets.

This rule takes check results from `autoconf` targets (via `deps`) and generates a header file.
The template file (if provided) is used to format the output header.

Example:

```python
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:autoconf_hdr.bzl", "autoconf_hdr")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")

autoconf(
    name = "config_checks",
    checks = [
        checks.AC_CHECK_HEADER("stdio.h"),
        checks.AC_CHECK_HEADER("stdlib.h"),
        checks.AC_CHECK_FUNC("printf"),
    ],
)

autoconf_hdr(
    name = "config",
    out = "config.h",
    deps = [":config_checks"],
    template = "config.h.in",
)
```

Valid `mode` values:
- `"defines"` (default): Only process defines (AC_DEFINE, AC_CHECK_*, etc.), not substitution variables (AC_SUBST). This is for config.h files.
- `"subst"`: Only process substitution variables (AC_SUBST), not defines. This is for subst.h files.
- `"all"`: Process both defines and substitution variables.

This allows you to run checks once and generate multiple header files from the same results.
*
nameA unique name for this target. �
default_deps�`autoconf_defaults` targets whose values stand where no result of the name comes through `deps`
(a result overrides a default silently; two defaults of one name must agree).  The defaults the
`deps` carry are read as well.
*
CcAutoconfDefaultsInfo2[]�
defaults�Deprecated and ignored: defaults come through `deps` and `default_deps`; the autoconf toolchain
no longer carries any.  Accepted so existing BUILD files keep loading.2False�
deps�List of `autoconf` targets which provide check results. Results from all deps will be merged together, and duplicate define names will produce an error. If not provided, an empty results file will be created.*
CcAutoconfInfo2[]�
inlines�A mapping of strings to files for replace within the content of the given `template` attribute.

The exact string in the template is replaced with the content of the associated file.
Any `@VAR@` style placeholders in the inline file content will be replaced with their
corresponding define values (package info, check results, etc.) after insertion.	2{}]
modeHProcessing mode that determines what should be replaced within the file.2	"defines"9
out.The output config file (typically `config.h`). �
substitutions�A mapping of exact strings to replacement values.

Each entry performs an exact text replacement in the template - the key
string is replaced with the value string. No special patterns or wrappers
are added.

Example:
```python
autoconf_hdr(
    name = "config",
    out = "config.h",
    template = "config.h.in",
    substitutions = {
        "@MY_VERSION@": "1.2.3",
        "@BUILD_TYPE@": "release",
        "PLACEHOLDER_TEXT": "actual_value",
    },
    deps = [":checks"],
)
```

This would replace the exact string `@MY_VERSION@` with `1.2.3`,
`@BUILD_TYPE@` with `release`, and `PLACEHOLDER_TEXT` with `actual_value`.
2{}�
template�Template file (`config.h.in`) to use as base for generating the header file. The template is used to format the output header, but does not generate any checks. ">
autoconf_hdr.@@rules_cc_autoconf//autoconf:autoconf_hdr.bzl
zz,
*
nameA unique name for this target. �
�
default_deps�`autoconf_defaults` targets whose values stand where no result of the name comes through `deps`
(a result overrides a default silently; two defaults of one name must agree).  The defaults the
`deps` carry are read as well.
*
CcAutoconfDefaultsInfo2[]�
�
defaults�Deprecated and ignored: defaults come through `deps` and `default_deps`; the autoconf toolchain
no longer carries any.  Accepted so existing BUILD files keep loading.2False�
�
deps�List of `autoconf` targets which provide check results. Results from all deps will be merged together, and duplicate define names will produce an error. If not provided, an empty results file will be created.*
CcAutoconfInfo2[]�
�
inlines�A mapping of strings to files for replace within the content of the given `template` attribute.

The exact string in the template is replaced with the content of the associated file.
Any `@VAR@` style placeholders in the inline file content will be replaced with their
corresponding define values (package info, check results, etc.) after insertion.	2{}_
]
modeHProcessing mode that determines what should be replaced within the file.2	"defines";
9
out.The output config file (typically `config.h`). �
�
substitutions�A mapping of exact strings to replacement values.

Each entry performs an exact text replacement in the template - the key
string is replaced with the value string. No special patterns or wrappers
are added.

Example:
```python
autoconf_hdr(
    name = "config",
    out = "config.h",
    template = "config.h.in",
    substitutions = {
        "@MY_VERSION@": "1.2.3",
        "@BUILD_TYPE@": "release",
        "PLACEHOLDER_TEXT": "actual_value",
    },
    deps = [":checks"],
)
```

This would replace the exact string `@MY_VERSION@` with `1.2.3`,
`@BUILD_TYPE@` with `release`, and `PLACEHOLDER_TEXT` with `actual_value`.
2{}�
�
template�Template file (`config.h.in`) to use as base for generating the header file. The template is used to format the output header, but does not generate any checks. q
:features.bzlr^

bazel_featuresfeatures.bzl.
bazel_featuresbazel_features
)7
9�
&//autoconf/private:autoconf_config.bzlr�
:
rules_cc_autoconfautoconf/privateautoconf_config.bzl2
collect_defaultscollect_defaults
*
collect_depscollect_deps
F
collect_transitive_resultscollect_transitive_results
 .
merge_defaultsmerge_defaults
		,
merge_resultsmerge_results



�
(//autoconf/private:ctx_actions_write.bzlrj
<
rules_cc_autoconfautoconf/privatectx_actions_write.bzl
writewrite
EJ
L�
 //autoconf/private:providers.bzlr�
4
rules_cc_autoconfautoconf/privateproviders.bzl>
CcAutoconfDefaultsInfoCcAutoconfDefaultsInfo
=S.
CcAutoconfInfoCcAutoconfInfo
We
g# autoconf_hdr�*
4
rules_cc_autoconfautoconfautoconf_linkopts.bzl�autoconf_linkopts�Resolve AC_SEARCH_LIBS / AC_SUBST results into linker flags.

Reads subst result JSON files from autoconf deps and produces a
linker response file. Returns CcInfo with the flags, so consumers
can simply add this target to their deps list.

On GCC/Clang the flags are delivered via a @response-file. On
MSVC/clang-cl a .c file with #pragma comment(lib, ...) directives
is compiled instead, since MSVC's link.exe does not support nested
response files.

Variables not found in the deps are silently ignored (they may
be provided by a different module or not needed on this platform).
"�
�
autoconf_linkopts�Resolve AC_SEARCH_LIBS / AC_SUBST results into linker flags.

Reads subst result JSON files from autoconf deps and produces a
linker response file. Returns CcInfo with the flags, so consumers
can simply add this target to their deps list.

On GCC/Clang the flags are delivered via a @response-file. On
MSVC/clang-cl a .c file with #pragma comment(lib, ...) directives
is compiled instead, since MSVC's link.exe does not support nested
response files.

Variables not found in the deps are silently ignored (they may
be provided by a different module or not needed on this platform).
*
nameA unique name for this target. �
default_deps�`autoconf_defaults` targets whose values stand where no result of the name comes through `deps`
(a result overrides a default silently; two defaults of one name must agree).  The defaults the
`deps` carry are read as well.
*
CcAutoconfDefaultsInfo2[]�
defaults�Deprecated and ignored: defaults come through `deps` and `default_deps`; the autoconf toolchain
no longer carries any.  Accepted so existing BUILD files keep loading.2FalseO
deps1List of autoconf targets providing check results. *
CcAutoconfInfo�
vars�List of AC_SUBST variable names to resolve (e.g., ["LIBPTHREAD", "FDATASYNC_LIB"]).
Each variable is looked up in the subst results from deps. Non-empty values
(like "-lpthread") are added to linkopts; empty values are skipped.
 "H
autoconf_linkopts3@@rules_cc_autoconf//autoconf:autoconf_linkopts.bzl
��,
*
nameA unique name for this target. �
�
default_deps�`autoconf_defaults` targets whose values stand where no result of the name comes through `deps`
(a result overrides a default silently; two defaults of one name must agree).  The defaults the
`deps` carry are read as well.
*
CcAutoconfDefaultsInfo2[]�
�
defaults�Deprecated and ignored: defaults come through `deps` and `default_deps`; the autoconf toolchain
no longer carries any.  Accepted so existing BUILD files keep loading.2FalseQ
O
deps1List of autoconf targets providing check results. *
CcAutoconfInfo�
�
vars�List of AC_SUBST variable names to resolve (e.g., ["LIBPTHREAD", "FDATASYNC_LIB"]).
Each variable is looked up in the subst results from deps. Non-empty values
(like "-lpthread") are added to linkopts; empty values are skipped.
 q
:features.bzlr^

bazel_featuresfeatures.bzl.
bazel_featuresbazel_features
+)+7
++9�
//cc:find_cc_toolchain.bzlr�
%
rules_ccccfind_cc_toolchain.bzl6
find_cpp_toolchainfind_cpp_toolchain
,.,@2
use_cc_toolchainuse_cc_toolchain
,D,T
,,Vy
//cc/common:cc_common.bzlrZ
$
rules_cc	cc/commoncc_common.bzl$
	cc_common	cc_common
---6
--8o
//cc/common:cc_info.bzlrR
"
rules_cc	cc/commoncc_info.bzl
CcInfoCcInfo
.+.1
..3�
&//autoconf/private:autoconf_config.bzlr�
:
rules_cc_autoconfautoconf/privateautoconf_config.bzl2
collect_defaultscollect_defaults
11*
collect_depscollect_deps
22F
collect_transitive_resultscollect_transitive_results
33 .
merge_defaultsmerge_defaults
44,
merge_resultsmerge_results
55
/6�
 //autoconf/private:providers.bzlr�
4
rules_cc_autoconfautoconf/privateproviders.bzl>
CcAutoconfDefaultsInfoCcAutoconfDefaultsInfo
7=7S.
CcAutoconfInfoCcAutoconfInfo
7W7e
77g�	# autoconf_linkopts

Resolve AC_SEARCH_LIBS / AC_SUBST results into linker flags at build time.

This rule reads the JSON result files from autoconf subst variables and
produces a linker response file containing only the non-empty flags. The
response file is returned via CcInfo so that cc_binary/cc_library targets
can depend on it to get the correct platform-specific linkopts.

On GCC/Clang the flags are passed via a @response-file in user_link_flags.
On MSVC/clang-cl (where nested @file is unsupported), a .c file with
#pragma comment(lib, ...) directives is compiled and the resulting object
is linked in, achieving the same effect through MSVC's native mechanism.

Example:

```python
load("@rules_cc_autoconf//autoconf:autoconf_linkopts.bzl", "autoconf_linkopts")

autoconf_linkopts(
    name = "linkopts",
    vars = [
        "LIBPTHREAD",
        "FDATASYNC_LIB",
        "CLOCK_TIME_LIB",
    ],
    deps = [":autoconf"],
)

cc_binary(
    name = "my_binary",
    srcs = ["main.c"],
    deps = [":gnulib", ":linkopts"],
)
```

On modern Linux (glibc 2.34+) where pthread/rt functions are in libc,
AC_SEARCH_LIBS produces empty values and no extra -l flags are added.
On older systems, the appropriate flags (-lpthread, -lrt) are added
automatically.
�
8
rules_cc_autoconfautoconfautoconf_package_info.bzl�autoconf_package_info�A rule providing package metadata, equivalent to GNU autoconf's `AC_INIT`.

It emits the `PACKAGE_NAME`, `PACKAGE_VERSION`, `PACKAGE_STRING`, `PACKAGE_TARNAME`,
`PACKAGE_BUGREPORT`, and `PACKAGE_URL` defines, either from explicit attributes or
by parsing a `MODULE.bazel` file.

This rule is most useful when paired with the `autoconf` rule.

Example:

```python
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:autoconf_package_info.bzl", "autoconf_package_info")

autoconf_package_info(
    name = "package",
    module_bazel = "//:MODULE.bazel",
)

autoconf(
    name = "config_h",
    out = "config.h",
    checks = [
        # ...
    ],
    deps = [
        ":package",
    ],
)
```
"�
�
autoconf_package_info�A rule providing package metadata, equivalent to GNU autoconf's `AC_INIT`.

It emits the `PACKAGE_NAME`, `PACKAGE_VERSION`, `PACKAGE_STRING`, `PACKAGE_TARNAME`,
`PACKAGE_BUGREPORT`, and `PACKAGE_URL` defines, either from explicit attributes or
by parsing a `MODULE.bazel` file.

This rule is most useful when paired with the `autoconf` rule.

Example:

```python
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:autoconf_package_info.bzl", "autoconf_package_info")

autoconf_package_info(
    name = "package",
    module_bazel = "//:MODULE.bazel",
)

autoconf(
    name = "config_h",
    out = "config.h",
    checks = [
        # ...
    ],
    deps = [
        ":package",
    ],
)
```
*
nameA unique name for this target. a
aliasesPAdditional variables to define that are mirrored by the provided value variable.
2{}�
module_bazeluA `MODULE.bazel` file to parse module information from. Mutually exclusive with `package_name` and `package_version`.2Nonei
package_bugreportNThe package bug report email/URL. Used to populate `PACKAGE_BUGREPORT` define.2""{
package_nameeThe package name. Must be provided together with `package_version` if `module_bazel` is not provided.2""J
package_tarname1Exactly tarname, possibly generated from package.2""V
package_urlAThe package home page URL. Used to populate `PACKAGE_URL` define.2""~
package_versioneThe package version. Must be provided together with `package_name` if `module_bazel` is not provided.2""l
strip_bcr_versionNWhether or not to strip `.bcr.*` suffixes from `module_bazel` parsed versions.2False"P
autoconf_package_info7@@rules_cc_autoconf//autoconf:autoconf_package_info.bzl
��,
*
nameA unique name for this target. c
a
aliasesPAdditional variables to define that are mirrored by the provided value variable.
2{}�
�
module_bazeluA `MODULE.bazel` file to parse module information from. Mutually exclusive with `package_name` and `package_version`.2Nonek
i
package_bugreportNThe package bug report email/URL. Used to populate `PACKAGE_BUGREPORT` define.2""}
{
package_nameeThe package name. Must be provided together with `package_version` if `module_bazel` is not provided.2""L
J
package_tarname1Exactly tarname, possibly generated from package.2""X
V
package_urlAThe package home page URL. Used to populate `PACKAGE_URL` define.2""�
~
package_versioneThe package version. Must be provided together with `package_name` if `module_bazel` is not provided.2""n
l
strip_bcr_versionNWhether or not to strip `.bcr.*` suffixes from `module_bazel` parsed versions.2Falseq
:features.bzlr^

bazel_featuresfeatures.bzl.
bazel_featuresbazel_features
)7
9�
//autoconf:cc_autoconf_info.bzlr�
3
rules_cc_autoconfautoconfcc_autoconf_info.bzl.
CcAutoconfInfoCcAutoconfInfo
,
encode_resultencode_result

�
(//autoconf/private:ctx_actions_write.bzlrj
<
rules_cc_autoconfautoconf/privatectx_actions_write.bzl
writewrite
	E	J
		L# autoconf_package_info�=
0
rules_cc_autoconfautoconfautoconf_srcs.bzl�1autoconf_srcs�
Generate wrapper sources that are conditionally enabled by autoconf results.

Typical use case:

```python
load("@rules_cc_autoconf//autoconf:autoconf_srcs.bzl", "autoconf_srcs")
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")
load("@rules_cc//cc:cc_library.bzl", "cc_library")

autoconf(
    name = "config",
    out = "config.h",
    checks = [
        # Feature is present on this platform/toolchain.
        checks.AC_CHECK_HEADER("foo.h", define = "HAVE_FOO"),
    ],
)

autoconf_srcs(
    name = "foo_srcs",
    deps = [":config"],
    srcs = {
        "uses_foo.c": "HAVE_FOO",
    },
)

cc_library(
    name = "foo",
    srcs = [":foo_srcs"],
    hdrs = [":config.h"],
)
```

In this setup `autoconf_srcs` reads the results from `:config` (or multiple targets via `deps`) and generates a
wrapped copy of `uses_foo.c` whose contents are effectively:

```cc
#define HAVE_FOO 1      // when the check for HAVE_FOO succeeds
/* or: #undef HAVE_FOO  // when the check fails */
#ifdef HAVE_FOO
/* original uses_foo.c contents ... */
#endif
```

This is useful when you have platform-specific or optional sources that should
only be compiled when a particular autoconf check passes, without having to
manually maintain `#ifdef` guards in every source file.
"�'
�
autoconf_srcs�
Generate wrapper sources that are conditionally enabled by autoconf results.

Typical use case:

```python
load("@rules_cc_autoconf//autoconf:autoconf_srcs.bzl", "autoconf_srcs")
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")
load("@rules_cc//cc:cc_library.bzl", "cc_library")

autoconf(
    name = "config",
    out = "config.h",
    checks = [
        # Feature is present on this platform/toolchain.
        checks.AC_CHECK_HEADER("foo.h", define = "HAVE_FOO"),
    ],
)

autoconf_srcs(
    name = "foo_srcs",
    deps = [":config"],
    srcs = {
        "uses_foo.c": "HAVE_FOO",
    },
)

cc_library(
    name = "foo",
    srcs = [":foo_srcs"],
    hdrs = [":config.h"],
)
```

In this setup `autoconf_srcs` reads the results from `:config` (or multiple targets via `deps`) and generates a
wrapped copy of `uses_foo.c` whose contents are effectively:

```cc
#define HAVE_FOO 1      // when the check for HAVE_FOO succeeds
/* or: #undef HAVE_FOO  // when the check fails */
#ifdef HAVE_FOO
/* original uses_foo.c contents ... */
#endif
```

This is useful when you have platform-specific or optional sources that should
only be compiled when a particular autoconf check passes, without having to
manually maintain `#ifdef` guards in every source file.
*
nameA unique name for this target. �
default_deps�`autoconf_defaults` targets whose values stand where no result of the name comes through `deps`
(a result overrides a default silently; two defaults of one name must agree).  The defaults the
`deps` carry are read as well.
*
CcAutoconfDefaultsInfo2[]�
defaults�Deprecated and ignored: defaults come through `deps` and `default_deps`; the autoconf toolchain
no longer carries any.  Accepted so existing BUILD files keep loading.2False�
deps�List of `autoconf` targets which provide defines. Results from all deps will be merged together, and duplicate define names will produce an error. *
CcAutoconfInfo�
naming�How to name generated sources: `package_relative` keeps the original package-relative path, `ac_suffix`
inserts `.ac.` before the final suffix (e.g. `foo.cc -> foo.ac.cc`), and `per_target` prefixes outputs
with `{ctx.label.name}` to namespace them per rule.  Under `wrap = "include"` the output always carries the
`.ac` infix as well (`foo.c -> foo.ac.c`, `per_target`: `{ctx.label.name}/foo.ac.c`): a wrapper named like
a root-level source would resolve its own `#include "foo.c"` to itself.
2"package_relative"L
srcs@A mapping of source file to define required to compile the file.	 �
wrap�How a generated file stands for its source.  `copy` (the default) carries a copy of the source's contents.  `include` carries only `#include "<path of the source>"`, so the source's own quoted includes (`#include "sibling.h"`) still resolve in its directory and `__FILE__` and diagnostics name the source; the sources must then reach the compiler, which they do when the consumer lists this target in `deps` as well as `srcs` (the target provides them as headers of a `CcInfo`).2"copy""@
autoconf_srcs/@@rules_cc_autoconf//autoconf:autoconf_srcs.bzl
��,
*
nameA unique name for this target. �
�
default_deps�`autoconf_defaults` targets whose values stand where no result of the name comes through `deps`
(a result overrides a default silently; two defaults of one name must agree).  The defaults the
`deps` carry are read as well.
*
CcAutoconfDefaultsInfo2[]�
�
defaults�Deprecated and ignored: defaults come through `deps` and `default_deps`; the autoconf toolchain
no longer carries any.  Accepted so existing BUILD files keep loading.2False�
�
deps�List of `autoconf` targets which provide defines. Results from all deps will be merged together, and duplicate define names will produce an error. *
CcAutoconfInfo�
�
naming�How to name generated sources: `package_relative` keeps the original package-relative path, `ac_suffix`
inserts `.ac.` before the final suffix (e.g. `foo.cc -> foo.ac.cc`), and `per_target` prefixes outputs
with `{ctx.label.name}` to namespace them per rule.  Under `wrap = "include"` the output always carries the
`.ac` infix as well (`foo.c -> foo.ac.c`, `per_target`: `{ctx.label.name}/foo.ac.c`): a wrapper named like
a root-level source would resolve its own `#include "foo.c"` to itself.
2"package_relative"N
L
srcs@A mapping of source file to define required to compile the file.	 �
�
wrap�How a generated file stands for its source.  `copy` (the default) carries a copy of the source's contents.  `include` carries only `#include "<path of the source>"`, so the source's own quoted includes (`#include "sibling.h"`) still resolve in its directory and `__FILE__` and diagnostics name the source; the sources must then reach the compiler, which they do when the consumer lists this target in `deps` as well as `srcs` (the target provides them as headers of a `CcInfo`).2"copy"q
:features.bzlr^

bazel_featuresfeatures.bzl.
bazel_featuresbazel_features
)7
9a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.�
//cc:find_cc_toolchain.bzlri
%
rules_ccccfind_cc_toolchain.bzl2
use_cc_toolchainuse_cc_toolchain
.>
@y
//cc/common:cc_common.bzlrZ
$
rules_cc	cc/commoncc_common.bzl$
	cc_common	cc_common
-6
8o
//cc/common:cc_info.bzlrR
"
rules_cc	cc/commoncc_info.bzl
CcInfoCcInfo
+1
3�
&//autoconf/private:autoconf_config.bzlr�
:
rules_cc_autoconfautoconf/privateautoconf_config.bzl2
collect_defaultscollect_defaults


*
collect_depscollect_deps
F
collect_transitive_resultscollect_transitive_results
 .
merge_defaultsmerge_defaults
,
merge_resultsmerge_results

�
&//autoconf/private:condition_utils.bzlr�
:
rules_cc_autoconfautoconf/privatecondition_utils.bzl>
extract_condition_varsextract_condition_vars
CY
[�
 //autoconf/private:providers.bzlr�
4
rules_cc_autoconfautoconf/privateproviders.bzl>
CcAutoconfDefaultsInfoCcAutoconfDefaultsInfo
=S.
CcAutoconfInfoCcAutoconfInfo
We
g# autoconf_srcs�O
5
rules_cc_autoconfautoconfautoconf_toolchain.bzl�<autoconf_toolchain�Define an autoconf toolchain that shares check results across targets.

The toolchain carries one thing: the **content cache** of its `cache_deps`.
When an `autoconf` target lists a check whose implementation already has a
result there, the checker action is skipped and the existing result file is
reused.  Nothing else crosses the toolchain boundary: not the results as
defines or substs, and not defaults.  Defaults are `autoconf_defaults`
targets that a target reads through its own `default_deps` (see
`autoconf_defaults`); the toolchain neither carries nor injects any.

Targets listed in `cache_deps` must use `autoconf_cache` (not `autoconf`)
to avoid a dependency cycle.

Example:

```python
load("@rules_cc_autoconf//autoconf:defs.bzl", "autoconf_cache", "autoconf_toolchain")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")

autoconf_cache(
    name = "common_checks",
    checks = [
        checks.AC_CHECK_HEADER("stdio.h"),
        checks.AC_CHECK_FUNC("strerror"),
    ],
)

autoconf_toolchain(
    name = "my_toolchain_impl",
    cache_deps = [":common_checks"],
)

toolchain(
    name = "my_toolchain",
    toolchain = ":my_toolchain_impl",
    toolchain_type = "@rules_cc_autoconf//autoconf:toolchain_type",
)
```

## Caching behavior

### Content-key deduplication

Every check is fingerprinted by a **content key** derived from its
implementation fields: `type`, `code`, `language`, `define_value`,
`includes`, `libraries`, `requires`, `condition`, `compile_defines`,
and similar. Consumer metadata (`name`, `define`, `subst`, `unquote`)
is **excluded**, so two checks with different consumer names but
identical implementations share one content key and produce a single
checker action and result file.

When a new check is processed, its content key is looked up in order:

1. Transitive deps' `content_cache`
2. Toolchain content cache (`cache_deps`)
3. Current target's local `content_cache`

If a hit is found at any level the existing result file is reused and
no new checker action is declared. Identical checks within the same
target are idempotent (silently skipped on second occurrence).

### Conflict detection

Three layers, from strictest to most relaxed:

- **Within one target** -- duplicate `define` or `subst` symbol names
  in the same `checks` list always fail, even if the content keys
  match. This prevents accidental duplication in a single target.
- **Local vs dependencies / deps vs deps** -- the same symbol
  appearing with a **different result file** is an error, **unless**
  both files share the same content key (a benign duplicate from
  identical implementations).
- **Cache variable names** (`cache_results`) have no cross-dep
  conflict detection; content-based dedup is the identity signal.

`cache_deps` on the toolchain itself is intentionally exempt from
define/subst conflict detection: it contributes only to the content
cache and is meant to absorb broad sweeps of cache providers (e.g.,
every gnulib m4 module) that legitimately publish overlapping symbols
from different files. Per-target `deps` still enforce conflicts.

### Resolving conflicts

The typical fix for *"Define 'X' is defined both locally and in
dependencies with different result files"*:

- Remove the local check and depend on the target that already
  provides it.
- Or factor the shared check into its own `autoconf` /
  `autoconf_cache` target and depend on it from both consumers.
"�!
�
autoconf_toolchain�Define an autoconf toolchain that shares check results across targets.

The toolchain carries one thing: the **content cache** of its `cache_deps`.
When an `autoconf` target lists a check whose implementation already has a
result there, the checker action is skipped and the existing result file is
reused.  Nothing else crosses the toolchain boundary: not the results as
defines or substs, and not defaults.  Defaults are `autoconf_defaults`
targets that a target reads through its own `default_deps` (see
`autoconf_defaults`); the toolchain neither carries nor injects any.

Targets listed in `cache_deps` must use `autoconf_cache` (not `autoconf`)
to avoid a dependency cycle.

Example:

```python
load("@rules_cc_autoconf//autoconf:defs.bzl", "autoconf_cache", "autoconf_toolchain")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")

autoconf_cache(
    name = "common_checks",
    checks = [
        checks.AC_CHECK_HEADER("stdio.h"),
        checks.AC_CHECK_FUNC("strerror"),
    ],
)

autoconf_toolchain(
    name = "my_toolchain_impl",
    cache_deps = [":common_checks"],
)

toolchain(
    name = "my_toolchain",
    toolchain = ":my_toolchain_impl",
    toolchain_type = "@rules_cc_autoconf//autoconf:toolchain_type",
)
```

## Caching behavior

### Content-key deduplication

Every check is fingerprinted by a **content key** derived from its
implementation fields: `type`, `code`, `language`, `define_value`,
`includes`, `libraries`, `requires`, `condition`, `compile_defines`,
and similar. Consumer metadata (`name`, `define`, `subst`, `unquote`)
is **excluded**, so two checks with different consumer names but
identical implementations share one content key and produce a single
checker action and result file.

When a new check is processed, its content key is looked up in order:

1. Transitive deps' `content_cache`
2. Toolchain content cache (`cache_deps`)
3. Current target's local `content_cache`

If a hit is found at any level the existing result file is reused and
no new checker action is declared. Identical checks within the same
target are idempotent (silently skipped on second occurrence).

### Conflict detection

Three layers, from strictest to most relaxed:

- **Within one target** -- duplicate `define` or `subst` symbol names
  in the same `checks` list always fail, even if the content keys
  match. This prevents accidental duplication in a single target.
- **Local vs dependencies / deps vs deps** -- the same symbol
  appearing with a **different result file** is an error, **unless**
  both files share the same content key (a benign duplicate from
  identical implementations).
- **Cache variable names** (`cache_results`) have no cross-dep
  conflict detection; content-based dedup is the identity signal.

`cache_deps` on the toolchain itself is intentionally exempt from
define/subst conflict detection: it contributes only to the content
cache and is meant to absorb broad sweeps of cache providers (e.g.,
every gnulib m4 module) that legitimately publish overlapping symbols
from different files. Per-target `deps` still enforce conflicts.

### Resolving conflicts

The typical fix for *"Define 'X' is defined both locally and in
dependencies with different result files"*:

- Remove the local check and depend on the target that already
  provides it.
- Or factor the shared check into its own `autoconf` /
  `autoconf_cache` target and depend on it from both consumers.
*
nameA unique name for this target. �

cache_deps�Targets whose check results are available for action deduplication in `autoconf` targets. Only the content cache is exposed downstream; define/subst conflicts among these targets are NOT detected, so a broad sweep of cache providers with overlapping symbols (e.g., every gnulib m4 module) can be passed safely.*
CcAutoconfInfo2[]"J
autoconf_toolchain4@@rules_cc_autoconf//autoconf:autoconf_toolchain.bzl
!!,
*
nameA unique name for this target. �
�

cache_deps�Targets whose check results are available for action deduplication in `autoconf` targets. Only the content cache is exposed downstream; define/subst conflicts among these targets are NOT detected, so a broad sweep of cache providers with overlapping symbols (e.g., every gnulib m4 module) can be passed safely.*
CcAutoconfInfo2[]�autoconf_cache�Run autoconf-like checks without resolving the autoconf toolchain.

Identical to `autoconf` except that it does **not** resolve the
`autoconf_toolchain`. Use this rule for targets that are listed as
`cache_deps` of an `autoconf_toolchain` -- using the regular `autoconf`
rule in that position would create a dependency cycle.

Dep-level caching still applies: if a check's cache variable name already
has a result in transitive `deps`, the action is skipped.
*�
�
autoconf_cache*
nameA unique name for this target. (�
build_settings�List of `checks.AC_BUILD_SETTING(...)` entries
associating Bazel build setting targets (any rule providing
`BuildSettingInfo`) with autoconf-style defines and substitutions.None(h
checksVList of JSON-encoded checks from `checks`
(e.g., `checks.AC_CHECK_HEADER('stdio.h')`).None(a
depsQAdditional `autoconf`, `autoconf_cache`, or `autoconf_package_info`
dependencies.None(B
kwargs6Standard Bazel attributes (e.g. `visibility`, `tags`).(�Run autoconf-like checks without resolving the autoconf toolchain.

Identical to `autoconf` except that it does **not** resolve the
`autoconf_toolchain`. Use this rule for targets that are listed as
`cache_deps` of an `autoconf_toolchain` -- using the regular `autoconf`
rule in that position would create a dependency cycle.

Dep-level caching still applies: if a check's cache variable name already
has a result in transitive `deps`, the action is skipped.
2F
autoconf_cache4@@rules_cc_autoconf//autoconf:autoconf_toolchain.bzl
��*_autoconf_cache_rule2_autoconf_cache_rule�
&//autoconf/private:autoconf_config.bzlr�
:
rules_cc_autoconfautoconf/privateautoconf_config.bzl*
collect_depscollect_deps
R
 collect_transitive_content_cache collect_transitive_content_cache
		&

�
'//autoconf/private:autoconf_library.bzlr�
;
rules_cc_autoconfautoconf/privateautoconf_library.bzl>
to_build_settings_dictto_build_settings_dict
DZ4
autoconf_cache_autoconf_cache_rule
]q
��
 //autoconf/private:providers.bzlrt
4
rules_cc_autoconfautoconf/privateproviders.bzl.
CcAutoconfInfoCcAutoconfInfo
=K
MXautoconf_toolchain

Provides default autoconf checks that can be overridden by targets.
�3
3
rules_cc_autoconfautoconfcc_autoconf_info.bzl�encode_result�Encode a value as a flat result JSON string.

Returns the content for a result file that can be referenced from
``CcAutoconfInfo``.  Using this function insulates callers from the
internal result-file schema.
*�
�
encode_result�
value�The result value.  Strings are JSON-encoded (quoted in the
output); numbers and booleans are stored as their JSON
representation.  Use ``None`` for a valueless define
(``#define FOO`` with no value). (�
success�Whether the check succeeded.  Defaults to ``True``.
A result with ``success=False`` is rendered as
``/* #undef FOO */`` in the generated header.True(�Encode a value as a flat result JSON string.

Returns the content for a result file that can be referenced from
``CcAutoconfInfo``.  Using this function insulates callers from the
internal result-file schema.
"3
1A JSON string suitable for ``ctx.actions.write``.2J
encode_result9@@rules_cc_autoconf//autoconf/private:autoconf_config.bzl
�CcAutoconfDefaultsInfo�Default values for autoconf results, produced by `autoconf_defaults`.

Defaults are not check results: nothing probes for them, and they never take
part in duplicate detection.  A target reads them through `default_deps`,
beneath every ordinary result, so a probe of the same name overrides a default
silently.  This is gnulib's `*_H_DEFAULTS` pattern (`HAVE_X=1`, `REPLACE_X=0`
before the probes may reassign them).  Only `default_deps` accepts this
provider; `deps` does not.
2�
�
CcAutoconfDefaultsInfo�Default values for autoconf results, produced by `autoconf_defaults`.

Defaults are not check results: nothing probes for them, and they never take
part in duplicate detection.  A target reads them through `default_deps`,
beneath every ordinary result, so a probe of the same name overrides a default
silently.  This is gnulib's `*_H_DEFAULTS` pattern (`HAVE_X=1`, `REPLACE_X=0`
before the probes may reassign them).  Only `default_deps` accepts this
provider; `deps` does not.
l
cache_results[dict[str, File]: Cache variable name to result file, for `requires`/`condition` resolution.{
contentpdict[str, str]: Result file path to its content. Two defaults of one name must agree, which this is compared on.>
define_results,dict[str, File]: Define name to result file./
owner&Label: The `autoconf_defaults` target.<
subst_results+dict[str, File]: Subst name to result file.>
unquoted_defines*list[str]: Define names rendered unquoted."L
CcAutoconfDefaultsInfo2@@rules_cc_autoconf//autoconf:cc_autoconf_info.bzl
8B8Bn
l
cache_results[dict[str, File]: Cache variable name to result file, for `requires`/`condition` resolution.}
{
contentpdict[str, str]: Result file path to its content. Two defaults of one name must agree, which this is compared on.@
>
define_results,dict[str, File]: Define name to result file.1
/
owner&Label: The `autoconf_defaults` target.>
<
subst_results+dict[str, File]: Subst name to result file.@
>
unquoted_defines*list[str]: Define names rendered unquoted.�CcAutoconfInfo9A provider containing autoconf configuration and results.2�
�
CcAutoconfInfo9A provider containing autoconf configuration and results.�
cache_resultsqdict[str, File]: A map of cache variable names to flat result JSON files. Used for requires/condition resolution.�
content_cachewdict[str, File]: A map of content-based keys to result files. Used for action deduplication across deps and toolchains.�
defaults�depset[CcAutoconfDefaultsInfo]: The defaults this target reads and passes on: its `default_deps` and the defaults of its `deps`. Kept apart from the results above; a consumer reads them only where no ordinary result of the name exists.y
define_resultsgdict[str, File]: A map of define names to flat result JSON files produced by `CcAutoconfCheck` actions.H
deps@depset[CcAutoconfInfo]: Dependencies of the current info target.6
owner-Label: The label of the owner of the results.w
subst_resultsfdict[str, File]: A map of subst names to flat result JSON files produced by `CcAutoconfCheck` actions.b
unquoted_definesNlist[str]: Define names that should be rendered unquoted (AC_DEFINE_UNQUOTED)."D
CcAutoconfInfo2@@rules_cc_autoconf//autoconf:cc_autoconf_info.bzl
11�
�
cache_resultsqdict[str, File]: A map of cache variable names to flat result JSON files. Used for requires/condition resolution.�
�
content_cachewdict[str, File]: A map of content-based keys to result files. Used for action deduplication across deps and toolchains.�
�
defaults�depset[CcAutoconfDefaultsInfo]: The defaults this target reads and passes on: its `default_deps` and the defaults of its `deps`. Kept apart from the results above; a consumer reads them only where no ordinary result of the name exists.{
y
define_resultsgdict[str, File]: A map of define names to flat result JSON files produced by `CcAutoconfCheck` actions.J
H
deps@depset[CcAutoconfInfo]: Dependencies of the current info target.8
6
owner-Label: The label of the owner of the results.y
w
subst_resultsfdict[str, File]: A map of subst names to flat result JSON files produced by `CcAutoconfCheck` actions.d
b
unquoted_definesNlist[str]: Define names that should be rendered unquoted (AC_DEFINE_UNQUOTED).�
&//autoconf/private:autoconf_config.bzlry
:
rules_cc_autoconfautoconf/privateautoconf_config.bzl-
encode_result_encode_result

�
 //autoconf/private:providers.bzlr�
4
rules_cc_autoconfautoconf/privateproviders.bzl?
CcAutoconfDefaultsInfo_CcAutoconfDefaultsInfo
/
CcAutoconfInfo_CcAutoconfInfo

�# CcAutoconfInfo

Public API for external rules that produce autoconf-compatible check results.

The ``CcAutoconfInfo`` provider constructor accepts defaults for every field
except ``owner``, so callers only need to supply the fields they care about
(``CcAutoconfDefaultsInfo``, what ``autoconf_defaults`` produces and
``default_deps`` accepts, is exported alongside it):

```python
load("@rules_cc_autoconf//autoconf:cc_autoconf_info.bzl",
     "CcAutoconfInfo", "encode_result")

def _my_rule_impl(ctx):
    result = ctx.actions.declare_file("{}/MY_DEFINE.result.json".format(ctx.label.name))
    ctx.actions.write(output = result, content = encode_result("hello"))
    return [CcAutoconfInfo(owner = ctx.label, define_results = {"MY_DEFINE": result})]
```
��
)
rules_cc_autoconfautoconf
checks.bzl�checks.AC_BUILD_SETTING�Associate a Bazel build setting target with an autoconf define/subst.

Reads the value of `target` (any rule providing `BuildSettingInfo`) at
analysis time and renders it as a pre-computed check result -- the same
shape `AC_DEFINE` / `AC_SUBST` produce -- so it flows through
`autoconf_hdr` / `autoconf_srcs` like any other check. No compilation is
performed.

The returned value is consumed by the `autoconf` (and `autoconf_cache`)
macro's `build_settings` parameter, which collects a list of these and
forwards them to the underlying rule.

Example:
```python
load("@bazel_skylib//rules:common_settings.bzl", "string_flag")
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")

string_flag(name = "package_name", build_setting_default = "myproj")

autoconf(
    name = "config",
    build_settings = [
        checks.AC_BUILD_SETTING(
            target = ":package_name",
            name = "ac_cv_package_name",
            define = "PACKAGE_NAME",
            subst = True,
        ),
    ],
)
```
*�
�
checks.AC_BUILD_SETTINGp
targetbLabel of a target providing `BuildSettingInfo` (e.g. a
`string_flag`, `bool_flag`, or `int_flag`). (>
name2Cache variable name (e.g. `"ac_cv_package_name"`). (�
definewDefine name to set in the generated header, or `True` to
reuse `name`. At least one of `define` or `subst` is required.None(�
subst�Substitution variable name for `@VAR@` replacement, or `True`
to reuse `define`/`name`. At least one of `define` or `subst`
is required.None(n
unquoteZIf True, emit the define with AC_DEFINE_UNQUOTED-style
(trailing space) instead of `/**/`.False(�Associate a Bazel build setting target with an autoconf define/subst.

Reads the value of `target` (any rule providing `BuildSettingInfo`) at
analysis time and renders it as a pre-computed check result -- the same
shape `AC_DEFINE` / `AC_SUBST` produce -- so it flows through
`autoconf_hdr` / `autoconf_srcs` like any other check. No compilation is
performed.

The returned value is consumed by the `autoconf` (and `autoconf_cache`)
macro's `build_settings` parameter, which collects a list of these and
forwards them to the underlying rule.

Example:
```python
load("@bazel_skylib//rules:common_settings.bzl", "string_flag")
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")

string_flag(name = "package_name", build_setting_default = "myproj")

autoconf(
    name = "config",
    build_settings = [
        checks.AC_BUILD_SETTING(
            target = ":package_name",
            name = "ac_cv_package_name",
            define = "PACKAGE_NAME",
            subst = True,
        ),
    ],
)
```
"\
ZA struct consumed by the `autoconf` / `autoconf_cache` macro's
`build_settings` parameter.2=
_ac_build_setting(@@rules_cc_autoconf//autoconf:checks.bzl
���checks.AC_CHECK_ALIGNOF�Check the alignment of a type.

Original m4 example:
```m4
AC_CHECK_ALIGNOF([int])
AC_CHECK_ALIGNOF([double], [[#include <stddef.h>]])
```

Example:
```python
macros.AC_CHECK_ALIGNOF("int")
macros.AC_CHECK_ALIGNOF("double", includes = ["stddef.h"])
```

Cross-Compile Warning:
    This macro is NOT cross-compile friendly. It requires compiling and
    running code to determine the alignment, which doesn't work when cross-compiling.
*�
�
checks.AC_CHECK_ALIGNOF!
	type_nameName of the type (C
define1Custom define name (defaults to `ALIGNOF_<TYPE>`)None(�
includes�Optional list of header names to include (e.g. `["stddef.h"]`). Without it the
probe compiles with autoconf's default includes (`AC_INCLUDES_DEFAULT`), as the macro does.None(?
language,Language to use for check (`"c"` or `"cpp"`)"c"(�
copts�Optional list of extra compiler flags for this check
(e.g., `["-std=c11"]`). Appended after the autoconf toolchain's
own copts so they take precedence on last-wins conflicts.None(�
requires�List of requirements that must be met before this check runs.
Can be simple define names (e.g., `"HAVE_FOO"`) or value-based
requirements (e.g., `"REPLACE_FSTAT=1"` to require specific value)None(]
substLIf True, mark as a substitution variable (for @VAR@ replacement in subst.h).None(�Check the alignment of a type.

Original m4 example:
```m4
AC_CHECK_ALIGNOF([int])
AC_CHECK_ALIGNOF([double], [[#include <stddef.h>]])
```

Example:
```python
macros.AC_CHECK_ALIGNOF("int")
macros.AC_CHECK_ALIGNOF("double", includes = ["stddef.h"])
```

Cross-Compile Warning:
    This macro is NOT cross-compile friendly. It requires compiling and
    running code to determine the alignment, which doesn't work when cross-compiling.
"=
;A JSON-encoded check string for use with the autoconf rule.2=
_ac_check_alignof(@@rules_cc_autoconf//autoconf:checks.bzl
���
!checks.AC_CHECK_CXX_COMPILER_FLAG�Check if the C++ compiler supports a specific flag.

Original m4 example:
```m4
AC_CHECK_CXX_COMPILER_FLAG([-std=c++17], [CXXFLAGS="$CXXFLAGS -std=c++17"])
```

Example:
```python
macros.AC_CHECK_CXX_COMPILER_FLAG("-std=c++17")
macros.AC_CHECK_CXX_COMPILER_FLAG("-Wall")
```
*�
�
!checks.AC_CHECK_CXX_COMPILER_FLAGC
flag7Compiler flag to test (e.g., `"-Wall"`, `"-std=c++17"`) (E
define3Custom define name (defaults to `HAVE_FLAG_<FLAG>`)None(A
language,Language to use for check (`"c"` or `"cpp"`)"cpp"(�
requires�List of requirements that must be met before this check runs.
Can be simple define names (e.g., `"HAVE_FOO"`) or value-based
requirements (e.g., `"REPLACE_FSTAT=1"` to require specific value)None(]
substLIf True, mark as a substitution variable (for @VAR@ replacement in subst.h).None(�Check if the C++ compiler supports a specific flag.

Original m4 example:
```m4
AC_CHECK_CXX_COMPILER_FLAG([-std=c++17], [CXXFLAGS="$CXXFLAGS -std=c++17"])
```

Example:
```python
macros.AC_CHECK_CXX_COMPILER_FLAG("-std=c++17")
macros.AC_CHECK_CXX_COMPILER_FLAG("-Wall")
```
"=
;A JSON-encoded check string for use with the autoconf rule.2G
_ac_check_cxx_compiler_flag(@@rules_cc_autoconf//autoconf:checks.bzl
���	checks.AC_CHECK_C_COMPILER_FLAG�Check if the C compiler supports a specific flag.

Original m4 example:
```m4
AC_CHECK_C_COMPILER_FLAG([-Wall], [CFLAGS="$CFLAGS -Wall"])
```

Example:
```python
macros.AC_CHECK_C_COMPILER_FLAG("-Wall")
macros.AC_CHECK_C_COMPILER_FLAG("-std=c99")
```
*�
�
checks.AC_CHECK_C_COMPILER_FLAGA
flag5Compiler flag to test (e.g., `"-Wall"`, `"-std=c99"`) (E
define3Custom define name (defaults to `HAVE_FLAG_<FLAG>`)None(?
language,Language to use for check (`"c"` or `"cpp"`)"c"(�
requires�List of requirements that must be met before this check runs.
Can be simple define names (e.g., `"HAVE_FOO"`) or value-based
requirements (e.g., `"REPLACE_FSTAT=1"` to require specific value)None(]
substLIf True, mark as a substitution variable (for @VAR@ replacement in subst.h).None(�Check if the C compiler supports a specific flag.

Original m4 example:
```m4
AC_CHECK_C_COMPILER_FLAG([-Wall], [CFLAGS="$CFLAGS -Wall"])
```

Example:
```python
macros.AC_CHECK_C_COMPILER_FLAG("-Wall")
macros.AC_CHECK_C_COMPILER_FLAG("-std=c99")
```
"=
;A JSON-encoded check string for use with the autoconf rule.2E
_ac_check_c_compiler_flag(@@rules_cc_autoconf//autoconf:checks.bzl
���checks.AC_CHECK_DECL�Check if a symbol is declared.

Original m4 example:
```m4
AC_CHECK_DECL([NULL], [AC_DEFINE([HAVE_DECL_NULL], [1])], [], [[#include <stddef.h>]])
AC_CHECK_DECL([stdout], [AC_DEFINE([HAVE_DECL_STDOUT], [1])], [], [[#include <stdio.h>]])
```

Example:
```python
# Cache variable only (no define, no subst)
macros.AC_CHECK_DECL("NULL", includes = ["stddef.h"])
# -> Creates cache variable: "ac_cv_have_decl_NULL"

# Cache variable + define (explicit name)
macros.AC_CHECK_DECL("stdout", includes = ["stdio.h"], define = "HAVE_DECL_STDOUT")
# -> Creates cache variable: "ac_cv_have_decl_stdout"
# -> Creates define: "HAVE_DECL_STDOUT" in config.h
```

Note:
    This is different from `AC_CHECK_SYMBOL` - it checks if something is
    declared (not just `#defined`).

    When no includes are specified, the standard default includes
    are used (AC_INCLUDES_DEFAULT from GNU Autoconf).

    Use header names like `"stdlib.h"` (not `"#include <stdlib.h>"`).
*�
�
checks.AC_CHECK_DECL)
symbolName of the symbol to check (j
nameZCache variable name (defaults to `ac_cv_have_decl_<SYMBOL>` following autoconf convention)None(�
define�Define behavior:
- `None` (default): No define is created, only cache variable
- `True`: Create define using the cache variable name (`name`)
- `"HAVE_FOO"`: Create define with explicit name `HAVE_FOO` (implies `define=True`)None(�
includes�Optional list of header names to include (e.g. `["stdlib.h"]`).
If not specified and `headers` is not specified, uses AC_INCLUDES_DEFAULT.None(�
compile_defines�Optional list of preprocessor define names from previous checks
to add before includes (e.g., `["_GNU_SOURCE", "_DARWIN_C_SOURCE"]`).
Each string must match the define name of a previous check. The values
from those checks will be used automatically.None(�
copts�Optional list of extra compiler flags for this check
(e.g., `["-std=c11"]`). Appended after the autoconf toolchain's
own copts so they take precedence on last-wins conflicts.None(?
language,Language to use for check (`"c"` or `"cpp"`)"c"(�
requires�Requirements that must be met for this check to run.
Can be define names (e.g., `"HAVE_FOO"`), negated (e.g., `"!HAVE_FOO"`),
or value-based (e.g., `"REPLACE_FSTAT==1"`, `"REPLACE_FSTAT!=0"`).None(]
if_trueJValue to use when check succeeds (currently not used for this check type).None([
if_falseGValue to use when check fails (currently not used for this check type).None(�
subst�Subst behavior:
- `None` (default): No subst is created, only cache variable
- `True`: Create subst using the cache variable name (`name`)
- `"HAVE_FOO"`: Create subst with explicit name `HAVE_FOO` (implies `subst=True`)None(�Check if a symbol is declared.

Original m4 example:
```m4
AC_CHECK_DECL([NULL], [AC_DEFINE([HAVE_DECL_NULL], [1])], [], [[#include <stddef.h>]])
AC_CHECK_DECL([stdout], [AC_DEFINE([HAVE_DECL_STDOUT], [1])], [], [[#include <stdio.h>]])
```

Example:
```python
# Cache variable only (no define, no subst)
macros.AC_CHECK_DECL("NULL", includes = ["stddef.h"])
# -> Creates cache variable: "ac_cv_have_decl_NULL"

# Cache variable + define (explicit name)
macros.AC_CHECK_DECL("stdout", includes = ["stdio.h"], define = "HAVE_DECL_STDOUT")
# -> Creates cache variable: "ac_cv_have_decl_stdout"
# -> Creates define: "HAVE_DECL_STDOUT" in config.h
```

Note:
    This is different from `AC_CHECK_SYMBOL` - it checks if something is
    declared (not just `#defined`).

    When no includes are specified, the standard default includes
    are used (AC_INCLUDES_DEFAULT from GNU Autoconf).

    Use header names like `"stdlib.h"` (not `"#include <stdlib.h>"`).
"=
;A JSON-encoded check string for use with the autoconf rule.2:
_ac_check_decl(@@rules_cc_autoconf//autoconf:checks.bzl
���0checks.AC_CHECK_FUNC�Check for a function.

Original m4 example:
```m4
AC_CHECK_FUNC([malloc])
AC_CHECK_FUNC([mmap], [AC_DEFINE([HAVE_MMAP_FEATURE], [1])])
```

The default `code` is a list of two programs, tried in order. The first
is GNU autoconf's (`utils.AC_LANG_FUNC_LINK_TRY`): declare the function
with a dummy prototype, call it, and link against the default
libraries. The second runs only if that fails and only under
`_MSC_VER`: it includes `AC_INCLUDES_DEFAULT` and takes the function's
address, because the UCRT implements the printf and scanf families as
header-inline functions with no linker symbol. GNU autoconf itself
reports those absent on MSVC; this check reports them present, which
is what a `HAVE_<FUNCTION>` consumer needs. Results on every other
compiler are exactly GNU's. Passing `code` replaces the list: a check
that wants GNU's literal answer on MSVC passes
`code = utils.AC_LANG_FUNC_LINK_TRY(function)` alone. gnulib ports
verified against GNU autoconf do so for the printf family, because
gnulib documents that answer as MSVC 14's state and builds its
replacement logic on it:

- https://learn.microsoft.com/en-us/cpp/porting/visual-cpp-change-history-2003-2015#stdioh-and-conioh
- https://github.com/coreutils/gnulib/blob/1039a5f2cee3cda1c11f64a5eb3a15b2e87cd2f0/doc/posix-functions/snprintf.texi#L15-L16
- https://github.com/coreutils/gnulib/blob/1039a5f2cee3cda1c11f64a5eb3a15b2e87cd2f0/m4/snprintf.m4#L45-L62

Example:
```python
# Cache variable only (no define, no subst)
macros.AC_CHECK_FUNC("malloc")
# -> Creates cache variable: "ac_cv_func_malloc"

# Cache variable + define (explicit name)
macros.AC_CHECK_FUNC("mmap", define = "HAVE_MMAP")
# -> Creates cache variable: "ac_cv_func_mmap"
# -> Creates define: "HAVE_MMAP" in config.h

# Cache variable + define (using cache var name)
macros.AC_CHECK_FUNC("mmap", define = True)
# -> Creates cache variable: "ac_cv_func_mmap"
# -> Creates define: "ac_cv_func_mmap" in config.h

# Cache variable + subst
macros.AC_CHECK_FUNC("_Exit", subst = True)
# -> Creates cache variable: "ac_cv_func__Exit"
# -> Creates subst: "ac_cv_func__Exit" in subst.h
```
*�
�
checks.AC_CHECK_FUNC7
function'Name of the function (e.g., `"printf"`) (g
nameWCache variable name (defaults to `ac_cv_func_<FUNCTION>` following autoconf convention)None(�
define�Define behavior:
- `None` (default): No define is created, only cache variable
- `True`: Create define using the cache variable name (`name`)
- `"HAVE_FOO"`: Create define with explicit name `HAVE_FOO` (implies `define=True`)None(�
code�Custom program to compile and link, or a list of programs tried
in order until one links (optional). Replaces the default list
described above.None(?
language,Language to use for check (`"c"` or `"cpp"`)"c"(�
compile_defines�Optional list of preprocessor define names from previous checks
to add before includes (e.g., `["_GNU_SOURCE", "_DARWIN_C_SOURCE"]`).
Each string must match the define name of a previous check. The values
from those checks will be used automatically.None(�
copts�Optional list of extra compiler flags for this check
(e.g., `["-std=c11"]`). Appended after the autoconf toolchain's
own copts so they take precedence on last-wins conflicts.None(�
linkoptsuOptional list of extra linker flags for this check
(e.g., `["-pthread"]`). Appended after the toolchain's link
flags.None(�
requires�Requirements that must be met for this check to run.
Can be define names (e.g., `"HAVE_FOO"`), negated (e.g., `"!HAVE_FOO"`),
or value-based (e.g., `"REPLACE_FSTAT==1"`, `"REPLACE_FSTAT!=0"`).None(�
subst�Subst behavior:
- `None` (default): No subst is created, only cache variable
- `True`: Create subst using the cache variable name (`name`)
- `"HAVE_FOO"`: Create subst with explicit name `HAVE_FOO` (implies `subst=True`)None(�Check for a function.

Original m4 example:
```m4
AC_CHECK_FUNC([malloc])
AC_CHECK_FUNC([mmap], [AC_DEFINE([HAVE_MMAP_FEATURE], [1])])
```

The default `code` is a list of two programs, tried in order. The first
is GNU autoconf's (`utils.AC_LANG_FUNC_LINK_TRY`): declare the function
with a dummy prototype, call it, and link against the default
libraries. The second runs only if that fails and only under
`_MSC_VER`: it includes `AC_INCLUDES_DEFAULT` and takes the function's
address, because the UCRT implements the printf and scanf families as
header-inline functions with no linker symbol. GNU autoconf itself
reports those absent on MSVC; this check reports them present, which
is what a `HAVE_<FUNCTION>` consumer needs. Results on every other
compiler are exactly GNU's. Passing `code` replaces the list: a check
that wants GNU's literal answer on MSVC passes
`code = utils.AC_LANG_FUNC_LINK_TRY(function)` alone. gnulib ports
verified against GNU autoconf do so for the printf family, because
gnulib documents that answer as MSVC 14's state and builds its
replacement logic on it:

- https://learn.microsoft.com/en-us/cpp/porting/visual-cpp-change-history-2003-2015#stdioh-and-conioh
- https://github.com/coreutils/gnulib/blob/1039a5f2cee3cda1c11f64a5eb3a15b2e87cd2f0/doc/posix-functions/snprintf.texi#L15-L16
- https://github.com/coreutils/gnulib/blob/1039a5f2cee3cda1c11f64a5eb3a15b2e87cd2f0/m4/snprintf.m4#L45-L62

Example:
```python
# Cache variable only (no define, no subst)
macros.AC_CHECK_FUNC("malloc")
# -> Creates cache variable: "ac_cv_func_malloc"

# Cache variable + define (explicit name)
macros.AC_CHECK_FUNC("mmap", define = "HAVE_MMAP")
# -> Creates cache variable: "ac_cv_func_mmap"
# -> Creates define: "HAVE_MMAP" in config.h

# Cache variable + define (using cache var name)
macros.AC_CHECK_FUNC("mmap", define = True)
# -> Creates cache variable: "ac_cv_func_mmap"
# -> Creates define: "ac_cv_func_mmap" in config.h

# Cache variable + subst
macros.AC_CHECK_FUNC("_Exit", subst = True)
# -> Creates cache variable: "ac_cv_func__Exit"
# -> Creates subst: "ac_cv_func__Exit" in subst.h
```
"=
;A JSON-encoded check string for use with the autoconf rule.2:
_ac_check_func(@@rules_cc_autoconf//autoconf:checks.bzl
���checks.AC_CHECK_HEADER�Check for a header file.

Original m4 example:
```m4
AC_CHECK_HEADER([stdio.h])
AC_CHECK_HEADER([pthread.h], [AC_CHECK_FUNC([pthread_create])])
```

Example:
```python
# Cache variable only (no define, no subst)
macros.AC_CHECK_HEADER("stdio.h")
# -> Creates cache variable: "ac_cv_header_stdio_h"

# Cache variable + define (explicit name)
macros.AC_CHECK_HEADER("pthread.h", define = "HAVE_PTHREAD_H")
# -> Creates cache variable: "ac_cv_header_pthread_h"
# -> Creates define: "HAVE_PTHREAD_H" in config.h

# Cache variable + define (using cache var name)
macros.AC_CHECK_HEADER("pthread.h", define = True)
# -> Creates cache variable: "ac_cv_header_pthread_h"
# -> Creates define: "ac_cv_header_pthread_h" in config.h
```
*�
�
checks.AC_CHECK_HEADER9
header+Name of the header file (e.g., `"stdio.h"`) (g
nameWCache variable name (defaults to `ac_cv_header_<HEADER>` following autoconf convention)None(�
define�Define behavior:
- `None` (default): No define is created, only cache variable
- `True`: Create define using the cache variable name (`name`)
- `"HAVE_FOO"`: Create define with explicit name `HAVE_FOO` (implies `define=True`)None(8
includes$Optional list of headers to include.None(?
language,Language to use for check (`"c"` or `"cpp"`)"c"(�
compile_defines�Optional list of preprocessor define names from previous checks
to add before includes (e.g., `["_GNU_SOURCE", "_DARWIN_C_SOURCE"]`).
Each string must match the define name of a previous check. The values
from those checks will be used automatically.None(�
copts�Optional list of extra compiler flags for this check
(e.g., `["-std=c11", "-D_POSIX_C_SOURCE=200809L"]`). Appended after
the autoconf toolchain's own copts so they take precedence on
last-wins conflicts.None(�
requires�Requirements that must be met for this check to run.
Can be define names (e.g., `"HAVE_FOO"`), negated (e.g., `"!HAVE_FOO"`),
or value-based (e.g., `"REPLACE_FSTAT==1"`, `"REPLACE_FSTAT!=0"`).None(�
subst�Subst behavior:
- `None` (default): No subst is created, only cache variable
- `True`: Create subst using the cache variable name (`name`)
- `"HAVE_FOO"`: Create subst with explicit name `HAVE_FOO` (implies `subst=True`)None(�Check for a header file.

Original m4 example:
```m4
AC_CHECK_HEADER([stdio.h])
AC_CHECK_HEADER([pthread.h], [AC_CHECK_FUNC([pthread_create])])
```

Example:
```python
# Cache variable only (no define, no subst)
macros.AC_CHECK_HEADER("stdio.h")
# -> Creates cache variable: "ac_cv_header_stdio_h"

# Cache variable + define (explicit name)
macros.AC_CHECK_HEADER("pthread.h", define = "HAVE_PTHREAD_H")
# -> Creates cache variable: "ac_cv_header_pthread_h"
# -> Creates define: "HAVE_PTHREAD_H" in config.h

# Cache variable + define (using cache var name)
macros.AC_CHECK_HEADER("pthread.h", define = True)
# -> Creates cache variable: "ac_cv_header_pthread_h"
# -> Creates define: "ac_cv_header_pthread_h" in config.h
```
"=
;A JSON-encoded check string for use with the autoconf rule.2<
_ac_check_header(@@rules_cc_autoconf//autoconf:checks.bzl
���checks.AC_CHECK_LIB�Check for a function in a library.

Original m4 example:
```m4
AC_CHECK_LIB([m], [cos])
AC_CHECK_LIB([pthread], [pthread_create])
```

Example:
```python
macros.AC_CHECK_LIB("m", "cos")
macros.AC_CHECK_LIB("pthread", "pthread_create")
```

Note:
    This checks if the specified function is available in the given library.
    It attempts to link against `-l<library>` to verify the library provides
    the function.

    GNU Autoconf treats `function = "main"` specially. The generated program
    supplies its own `main`, so this form tests whether the complete link
    command accepts `-l<library>`; it does not require the library to export
    a symbol named `main`.
*�
�
checks.AC_CHECK_LIBN
library?Library name without the `-l` prefix (e.g., `"m"`, `"pthread"`) (]
functionMFunction name to check for in the library (e.g., `"cos"`, `"pthread_create"`) (X
nameHThe name of the cache variable. Defaults to `ac_cv_lib_library_function`None(F
define4Custom define name (defaults to `HAVE_LIB<LIBRARY>`)None(:
code*Custom code to compile and link (optional)None(?
language,Language to use for check (`"c"` or `"cpp"`)"c"(�
copts�Optional list of extra compiler flags for this check
(e.g., `["-std=c11"]`). Appended after the autoconf toolchain's
own copts so they take precedence on last-wins conflicts.None(�
linkopts�Optional list of extra linker flags for this check
(e.g., `["-pthread"]`). Appended after the toolchain's link
flags AND after the `-l<library>` argument.None(�
requires�Requirements that must be met for this check to run.
Can be define names (e.g., `"HAVE_FOO"`), negated (e.g., `"!HAVE_FOO"`),
or value-based (e.g., `"REPLACE_FSTAT==1"`, `"REPLACE_FSTAT!=0"`).None(]
if_trueJValue to use when check succeeds (currently not used for this check type).None([
if_falseGValue to use when check fails (currently not used for this check type).None(]
substLIf True, mark as a substitution variable (for @VAR@ replacement in subst.h).None(�Check for a function in a library.

Original m4 example:
```m4
AC_CHECK_LIB([m], [cos])
AC_CHECK_LIB([pthread], [pthread_create])
```

Example:
```python
macros.AC_CHECK_LIB("m", "cos")
macros.AC_CHECK_LIB("pthread", "pthread_create")
```

Note:
    This checks if the specified function is available in the given library.
    It attempts to link against `-l<library>` to verify the library provides
    the function.

    GNU Autoconf treats `function = "main"` specially. The generated program
    supplies its own `main`, so this form tests whether the complete link
    command accepts `-l<library>`; it does not require the library to export
    a symbol named `main`.
"=
;A JSON-encoded check string for use with the autoconf rule.29
_ac_check_lib(@@rules_cc_autoconf//autoconf:checks.bzl
���checks.AC_CHECK_MEMBER�Check if a struct or union has a member.

Original m4 example:
```m4
AC_CHECK_MEMBER([struct stat.st_rdev], [AC_DEFINE([HAVE_STRUCT_STAT_ST_RDEV], [1])], [], [[#include <sys/stat.h>]])
AC_CHECK_MEMBER([struct tm.tm_zone], [AC_DEFINE([HAVE_STRUCT_TM_TM_ZONE], [1])], [], [[#include <time.h>]])
```

Example:
```python
macros.AC_CHECK_MEMBER("struct stat.st_rdev", includes = ["sys/stat.h"])
macros.AC_CHECK_MEMBER("struct tm.tm_zone", includes = ["time.h"])
```
*�
�
checks.AC_CHECK_MEMBERO
aggregate_member7Struct or union name with (e.g., `struct stat.st_rdev`) (o
name_Cache variable name (defaults to `ac_cv_member_aggregate_member` following autoconf convention)None(N
define<Custom define name (defaults to `HAVE_<AGGREGATE>_<MEMBER>`)None(T
includes@Optional list of header names to include (e.g. `["sys/stat.h"]`)None(?
language,Language to use for check (`"c"` or `"cpp"`)"c"(�
compile_defines�Optional list of preprocessor define names from previous checks
to add before includes (e.g., `["_GNU_SOURCE", "_DARWIN_C_SOURCE"]`).
Each string must match the define name of a previous check. The values
from those checks will be used automatically.None(�
copts�Optional list of extra compiler flags for this check
(e.g., `["-std=c11"]`). Appended after the autoconf toolchain's
own copts so they take precedence on last-wins conflicts.None(�
requires�Requirements that must be met for this check to run.
Can be define names (e.g., `"HAVE_FOO"`), negated (e.g., `"!HAVE_FOO"`),
or value-based (e.g., `"REPLACE_FSTAT==1"`, `"REPLACE_FSTAT!=0"`).None(]
if_trueJValue to use when check succeeds (currently not used for this check type).None([
if_falseGValue to use when check fails (currently not used for this check type).None(�
subst�If True, automatically create a substitution variable with the same name
that will be set to "1" if the check succeeds, "0" if it fails.None(�Check if a struct or union has a member.

Original m4 example:
```m4
AC_CHECK_MEMBER([struct stat.st_rdev], [AC_DEFINE([HAVE_STRUCT_STAT_ST_RDEV], [1])], [], [[#include <sys/stat.h>]])
AC_CHECK_MEMBER([struct tm.tm_zone], [AC_DEFINE([HAVE_STRUCT_TM_TM_ZONE], [1])], [], [[#include <time.h>]])
```

Example:
```python
macros.AC_CHECK_MEMBER("struct stat.st_rdev", includes = ["sys/stat.h"])
macros.AC_CHECK_MEMBER("struct tm.tm_zone", includes = ["time.h"])
```
"=
;A JSON-encoded check string for use with the autoconf rule.2<
_ac_check_member(@@rules_cc_autoconf//autoconf:checks.bzl
���checks.AC_CHECK_SIZEOF�Check the size of a type.

Original m4 example:
```m4
AC_CHECK_SIZEOF([int])
AC_CHECK_SIZEOF([size_t], [], [[#include <stddef.h>]])
```

Example:
```python
# Cache variable only (no define, no subst)
macros.AC_CHECK_SIZEOF("int")
# -> Creates cache variable: "ac_cv_sizeof_int"

# Cache variable + define (explicit name)
macros.AC_CHECK_SIZEOF("size_t", includes = ["#include <stddef.h>"], define = "SIZEOF_SIZE_T")
# -> Creates cache variable: "ac_cv_sizeof_size_t"
# -> Creates define: "SIZEOF_SIZE_T" in config.h
```

Cross-Compile Warning:
    This macro is NOT cross-compile friendly. It requires compiling and
    running code to determine the size, which doesn't work when cross-compiling.
*�
�
checks.AC_CHECK_SIZEOFB
	type_name1Name of the type (e.g., `int`, `size_t`, `void*`) (e
nameUCache variable name (defaults to `ac_cv_sizeof_<TYPE>` following autoconf convention)None(�
define�Define behavior:
- `None` (default): No define is created, only cache variable
- `True`: Create define using the cache variable name (`name`)
- `"SIZEOF_FOO"`: Create define with explicit name `SIZEOF_FOO` (implies `define=True`)None(�
includes�Optional list of header names to include (e.g. `["stddef.h"]`). Without it the
probe compiles with autoconf's default includes (`AC_INCLUDES_DEFAULT`), as the macro does.None(?
language,Language to use for check (`"c"` or `"cpp"`)"c"(�
copts�Optional list of extra compiler flags for this check
(e.g., `["-std=c11"]`). Appended after the autoconf toolchain's
own copts so they take precedence on last-wins conflicts.None(�
requires�Requirements that must be met for this check to run.
Can be define names (e.g., `"HAVE_FOO"`), negated (e.g., `"!HAVE_FOO"`),
or value-based (e.g., `"REPLACE_FSTAT==1"`, `"REPLACE_FSTAT!=0"`).None(]
if_trueJValue to use when check succeeds (currently not used for this check type).None([
if_falseGValue to use when check fails (currently not used for this check type).None(�
subst�Subst behavior:
- `None` (default): No subst is created, only cache variable
- `True`: Create subst using the cache variable name (`name`)
- `"SIZEOF_FOO"`: Create subst with explicit name `SIZEOF_FOO` (implies `subst=True`)None(�Check the size of a type.

Original m4 example:
```m4
AC_CHECK_SIZEOF([int])
AC_CHECK_SIZEOF([size_t], [], [[#include <stddef.h>]])
```

Example:
```python
# Cache variable only (no define, no subst)
macros.AC_CHECK_SIZEOF("int")
# -> Creates cache variable: "ac_cv_sizeof_int"

# Cache variable + define (explicit name)
macros.AC_CHECK_SIZEOF("size_t", includes = ["#include <stddef.h>"], define = "SIZEOF_SIZE_T")
# -> Creates cache variable: "ac_cv_sizeof_size_t"
# -> Creates define: "SIZEOF_SIZE_T" in config.h
```

Cross-Compile Warning:
    This macro is NOT cross-compile friendly. It requires compiling and
    running code to determine the size, which doesn't work when cross-compiling.
"=
;A JSON-encoded check string for use with the autoconf rule.2<
_ac_check_sizeof(@@rules_cc_autoconf//autoconf:checks.bzl
�
�
�checks.AC_CHECK_TYPE�Check for a type.

Original m4 example:
```m4
AC_CHECK_TYPE([size_t])
AC_CHECK_TYPE([pthread_t], [], [], [[#include <pthread.h>]])
```

Example:
```python
# Cache variable only (no define, no subst)
macros.AC_CHECK_TYPE("size_t")
# -> Creates cache variable: "ac_cv_type_size_t"

# Cache variable + define (explicit name)
macros.AC_CHECK_TYPE("pthread_t", includes = ["#include <pthread.h>"], define = "HAVE_PTHREAD_T")
# -> Creates cache variable: "ac_cv_type_pthread_t"
# -> Creates define: "HAVE_PTHREAD_T" in config.h
```
*�
�
checks.AC_CHECK_TYPE2
	type_name!Name of the type (e.g., `size_t`) (c
nameSCache variable name (defaults to `ac_cv_type_<TYPE>` following autoconf convention)None(�
define�Define behavior:
- `None` (default): No define is created, only cache variable
- `True`: Create define using the cache variable name (`name`)
- `"HAVE_FOO"`: Create define with explicit name `HAVE_FOO` (implies `define=True`)None(�
includesrOptional list of headers to include (e.g. `["#include <pthread.h>"]`).
If not specified, uses AC_INCLUDES_DEFAULT.None(?
language,Language to use for check (`"c"` or `"cpp"`)"c"(�
compile_defines�Optional list of preprocessor define names from previous checks
to add before includes (e.g., `["_GNU_SOURCE", "_DARWIN_C_SOURCE"]`).
Each string must match the define name of a previous check. The values
from those checks will be used automatically.None(�
copts�Optional list of extra compiler flags for this check
(e.g., `["-std=c11"]`). Appended after the autoconf toolchain's
own copts so they take precedence on last-wins conflicts.None(�
requires�Requirements that must be met for this check to run.
Can be define names (e.g., `"HAVE_FOO"`), negated (e.g., `"!HAVE_FOO"`),
or value-based (e.g., `"REPLACE_FSTAT==1"`, `"REPLACE_FSTAT!=0"`).None(]
if_trueJValue to use when check succeeds (currently not used for this check type).None([
if_falseGValue to use when check fails (currently not used for this check type).None(�
subst�Subst behavior:
- `None` (default): No subst is created, only cache variable
- `True`: Create subst using the cache variable name (`name`)
- `"HAVE_FOO"`: Create subst with explicit name `HAVE_FOO` (implies `subst=True`)None(�Check for a type.

Original m4 example:
```m4
AC_CHECK_TYPE([size_t])
AC_CHECK_TYPE([pthread_t], [], [], [[#include <pthread.h>]])
```

Example:
```python
# Cache variable only (no define, no subst)
macros.AC_CHECK_TYPE("size_t")
# -> Creates cache variable: "ac_cv_type_size_t"

# Cache variable + define (explicit name)
macros.AC_CHECK_TYPE("pthread_t", includes = ["#include <pthread.h>"], define = "HAVE_PTHREAD_T")
# -> Creates cache variable: "ac_cv_type_pthread_t"
# -> Creates define: "HAVE_PTHREAD_T" in config.h
```
"=
;A JSON-encoded check string for use with the autoconf rule.2:
_ac_check_type(@@rules_cc_autoconf//autoconf:checks.bzl
���checks.AC_COMPUTE_INT�Compute an integer value at compile time.

Original m4 example:
```m4
AC_COMPUTE_INT([SIZEOF_INT], [sizeof(int)])
AC_COMPUTE_INT([MAX_VALUE], [1 << 16])
```

Example:
```python
macros.AC_COMPUTE_INT("SIZEOF_INT", "sizeof(int)")
macros.AC_COMPUTE_INT("MAX_VALUE", "1 << 16")
```

Cross-Compile Warning:
    This macro is NOT cross-compile friendly. It requires compiling and
    running code to compute the value, which doesn't work when cross-compiling.
*�
�

checks.AC_COMPUTE_INTF
define8Define name for the result (first arg to match autoconf) (H

expression6C expression that evaluates to an integer (second arg) (R
includes>Optional list of header names to include (e.g. `["stdlib.h"]`)None(?
language,Language to use for check (`"c"` or `"cpp"`)"c"(�
copts�Optional list of extra compiler flags for this check
(e.g., `["-std=c11"]`). Appended after the autoconf toolchain's
own copts for every probe in the binary-search loop.None(�
requires�List of requirements that must be met before this check runs.
Can be simple define names (e.g., `"HAVE_FOO"`) or value-based
requirements (e.g., `"REPLACE_FSTAT=1"` to require specific value)None(]
substLIf True, mark as a substitution variable (for @VAR@ replacement in subst.h).None(�Compute an integer value at compile time.

Original m4 example:
```m4
AC_COMPUTE_INT([SIZEOF_INT], [sizeof(int)])
AC_COMPUTE_INT([MAX_VALUE], [1 << 16])
```

Example:
```python
macros.AC_COMPUTE_INT("SIZEOF_INT", "sizeof(int)")
macros.AC_COMPUTE_INT("MAX_VALUE", "1 << 16")
```

Cross-Compile Warning:
    This macro is NOT cross-compile friendly. It requires compiling and
    running code to compute the value, which doesn't work when cross-compiling.
"=
;A JSON-encoded check string for use with the autoconf rule.2;
_ac_compute_int(@@rules_cc_autoconf//autoconf:checks.bzl
���checks.AC_C_RESTRICT�Check if the compiler supports restrict keyword.

Original m4 example:
```m4
AC_C_RESTRICT
```

Example:
```python
checks.AC_C_RESTRICT()
```

Note:
    If restrict is not supported, the define is set to empty string.
*�
�
checks.AC_C_RESTRICT<
define$Define name (defaults to `restrict`)
"restrict"(?
language,Language to use for check (`"c"` or `"cpp"`)"c"(�
requires�List of requirements that must be met before this check runs.
Can be simple define names (e.g., `"HAVE_FOO"`) or value-based
requirements (e.g., `"REPLACE_FSTAT=1"` to require specific value)None(]
substLIf True, mark as a substitution variable (for @VAR@ replacement in subst.h).None(�Check if the compiler supports restrict keyword.

Original m4 example:
```m4
AC_C_RESTRICT
```

Example:
```python
checks.AC_C_RESTRICT()
```

Note:
    If restrict is not supported, the define is set to empty string.
"=
;A JSON-encoded check string for use with the autoconf rule.2:
_ac_c_restrict(@@rules_cc_autoconf//autoconf:checks.bzl
���checks.AC_DEFINE�
Define a configuration macro.

Original m4 example:
```m4
AC_DEFINE([CUSTOM_VALUE], [42])
AC_DEFINE([ENABLE_FEATURE], [1])
AC_DEFINE([PROJECT_NAME], ["MyProject"])
AC_DEFINE([EMPTY_VALUE], [])
```

Conditional example (m4):
```m4
if test $gl_cv_foo = yes; then
  AC_DEFINE([FOO_WORKS], [1])
fi
```

Example:
```python
# Simple (always define)
macros.AC_DEFINE("CUSTOM_VALUE", "42")

# Conditional (define based on another check's result)
macros.AC_DEFINE(
    "FOO_WORKS",
    condition = "HAVE_FOO",
    if_true = "1",      # Value when HAVE_FOO is true
    if_false = None,    # Don't define when HAVE_FOO is false
)
```

Note:
    This is equivalent to GNU Autoconf's AC_DEFINE macro. When used without
    `condition`, it creates a define that will always be set. When used with
    `condition`, the define is set based on the condition's result.

    **Condition Resolution**: If `condition` references a cache variable (e.g.,
    `condition="ac_cv_header_foo_h"`), it's evaluated as a truthy check:
    - Condition is `true` if the check succeeded AND the value is truthy (non-empty, non-zero)
    - Condition is `false` if the check failed OR the value is falsy (empty, "0")
    - If condition includes a comparison (e.g., `condition="ac_cv_header_foo_h==1"`),
      it performs value comparison instead.
*�
�
checks.AC_DEFINE2
define$Define name (e.g., `"CUSTOM_VALUE"`) (P
valueBValue to assign when no condition is specified (defaults to `"1"`)1(�
requires�Requirements that must be met for this check to run.
Can be define names (e.g., `"HAVE_FOO"`), negated (e.g., `"!HAVE_FOO"`),
or value-based (e.g., `"REPLACE_FSTAT==1"`, `"REPLACE_FSTAT!=0"`).None(�
	condition|Selects which value to use: `if_true` when condition is true,
`if_false` when false. Does not affect whether the check runs.None(D
if_true4Value when condition is true (requires `condition`).1(�
if_falseqValue when condition is false (requires `condition`).
Use `None` to not define the macro when condition is false.0(]
substLIf True, mark as a substitution variable (for @VAR@ replacement in subst.h).None(�
Define a configuration macro.

Original m4 example:
```m4
AC_DEFINE([CUSTOM_VALUE], [42])
AC_DEFINE([ENABLE_FEATURE], [1])
AC_DEFINE([PROJECT_NAME], ["MyProject"])
AC_DEFINE([EMPTY_VALUE], [])
```

Conditional example (m4):
```m4
if test $gl_cv_foo = yes; then
  AC_DEFINE([FOO_WORKS], [1])
fi
```

Example:
```python
# Simple (always define)
macros.AC_DEFINE("CUSTOM_VALUE", "42")

# Conditional (define based on another check's result)
macros.AC_DEFINE(
    "FOO_WORKS",
    condition = "HAVE_FOO",
    if_true = "1",      # Value when HAVE_FOO is true
    if_false = None,    # Don't define when HAVE_FOO is false
)
```

Note:
    This is equivalent to GNU Autoconf's AC_DEFINE macro. When used without
    `condition`, it creates a define that will always be set. When used with
    `condition`, the define is set based on the condition's result.

    **Condition Resolution**: If `condition` references a cache variable (e.g.,
    `condition="ac_cv_header_foo_h"`), it's evaluated as a truthy check:
    - Condition is `true` if the check succeeded AND the value is truthy (non-empty, non-zero)
    - Condition is `false` if the check failed OR the value is falsy (empty, "0")
    - If condition includes a comparison (e.g., `condition="ac_cv_header_foo_h==1"`),
      it performs value comparison instead.
"=
;A JSON-encoded check string for use with the autoconf rule.26

_ac_define(@@rules_cc_autoconf//autoconf:checks.bzl
���checks.AC_DEFINE_UNQUOTED�Define a configuration macro without quoting (AC_DEFINE_UNQUOTED).

Original m4 example:
```m4
AC_DEFINE_UNQUOTED([ICONV_CONST], [$iconv_arg1])
AC_DEFINE_UNQUOTED([VERSION], ["$PACKAGE_VERSION"])
```

This is similar to AC_DEFINE, but with one key difference:
- AC_DEFINE with empty value generates: `#define NAME /**/`
- AC_DEFINE_UNQUOTED with empty value generates: `#define NAME ` (trailing space)

Example:
```python
# Simple (always define)
macros.AC_DEFINE_UNQUOTED("ICONV_CONST", "")

# Conditional (define based on another check's result)
macros.AC_DEFINE_UNQUOTED(
    "ICONV_CONST",
    condition = "_gl_cv_iconv_nonconst",
    if_true = "",      # Empty value - will generate "#define ICONV_CONST " (trailing space)
    if_false = "const",  # Non-empty value
)
```

Note:
    This is equivalent to GNU Autoconf's AC_DEFINE_UNQUOTED macro. The main
    difference from AC_DEFINE is how empty values are rendered in config.h:
    AC_DEFINE uses `/**/` while AC_DEFINE_UNQUOTED uses a trailing space.
*�
�
checks.AC_DEFINE_UNQUOTED1
define#Define name (e.g., `"ICONV_CONST"`) (P
valueBValue to assign when no condition is specified (defaults to `"1"`)1(�
requires�Requirements that must be met for this check to run.
Can be define names (e.g., `"HAVE_FOO"`), negated (e.g., `"!HAVE_FOO"`),
or value-based (e.g., `"REPLACE_FSTAT==1"`, `"REPLACE_FSTAT!=0"`).None(�
	condition|Selects which value to use: `if_true` when condition is true,
`if_false` when false. Does not affect whether the check runs.None(G
if_true4Value when condition is true (requires `condition`).None(�
if_falseqValue when condition is false (requires `condition`).
Use `None` to not define the macro when condition is false.None(]
substLIf True, mark as a substitution variable (for @VAR@ replacement in subst.h).None(�Define a configuration macro without quoting (AC_DEFINE_UNQUOTED).

Original m4 example:
```m4
AC_DEFINE_UNQUOTED([ICONV_CONST], [$iconv_arg1])
AC_DEFINE_UNQUOTED([VERSION], ["$PACKAGE_VERSION"])
```

This is similar to AC_DEFINE, but with one key difference:
- AC_DEFINE with empty value generates: `#define NAME /**/`
- AC_DEFINE_UNQUOTED with empty value generates: `#define NAME ` (trailing space)

Example:
```python
# Simple (always define)
macros.AC_DEFINE_UNQUOTED("ICONV_CONST", "")

# Conditional (define based on another check's result)
macros.AC_DEFINE_UNQUOTED(
    "ICONV_CONST",
    condition = "_gl_cv_iconv_nonconst",
    if_true = "",      # Empty value - will generate "#define ICONV_CONST " (trailing space)
    if_false = "const",  # Non-empty value
)
```

Note:
    This is equivalent to GNU Autoconf's AC_DEFINE_UNQUOTED macro. The main
    difference from AC_DEFINE is how empty values are rendered in config.h:
    AC_DEFINE uses `/**/` while AC_DEFINE_UNQUOTED uses a trailing space.
"=
;A JSON-encoded check string for use with the autoconf rule.2?
_ac_define_unquoted(@@rules_cc_autoconf//autoconf:checks.bzl
���checks.AC_FAIL�A check that always fails, producing /* #undef NAME */ in config.h.

This is useful for platform-specific checks (like WORDS_BIGENDIAN) where
the value is only defined on some platforms but should result in an
explicit #undef on others.

Original m4 example:
```m4
dnl AC_C_BIGENDIAN sets WORDS_BIGENDIAN=1 on big-endian platforms.
dnl On little-endian platforms it is left undefined.
```

Example:
```python
# In a select() for the default (little-endian) case:
checks.AC_FAIL("WORDS_BIGENDIAN")
# -> Produces /* #undef WORDS_BIGENDIAN */ in config.h
```
*�
�
checks.AC_FAILO
defineADefine name to produce an #undef for (e.g., `"WORDS_BIGENDIAN"`). (H
name8Cache variable name (defaults to `ac_cv_fail_<DEFINE>`).None(]
substLIf True, mark as a substitution variable (for @VAR@ replacement in subst.h).None(�A check that always fails, producing /* #undef NAME */ in config.h.

This is useful for platform-specific checks (like WORDS_BIGENDIAN) where
the value is only defined on some platforms but should result in an
explicit #undef on others.

Original m4 example:
```m4
dnl AC_C_BIGENDIAN sets WORDS_BIGENDIAN=1 on big-endian platforms.
dnl On little-endian platforms it is left undefined.
```

Example:
```python
# In a select() for the default (little-endian) case:
checks.AC_FAIL("WORDS_BIGENDIAN")
# -> Produces /* #undef WORDS_BIGENDIAN */ in config.h
```
"=
;A JSON-encoded check string for use with the autoconf rule.24
_ac_fail(@@rules_cc_autoconf//autoconf:checks.bzl
���checks.AC_LANG_STANDARD�
Check the language standard the compiler is running in.

The probe compares `__STDC_VERSION__` (C) or `__cplusplus` -- `_MSVC_LANG`
on MSVC, whose `__cplusplus` stays at 199711L -- with the value of
`standard`, under the flags every check sees: the toolchain's, `--copt` /
`--conlyopt` / `--cxxopt`, and the target's own `copts` / `conlyopts` /
`cxxopts`.  It is
the test behind `AC_PROG_CC_C99`, `AC_PROG_CC_STDC` and
`AX_CXX_COMPILE_STDCXX`'s mandatory mode, as one check: configure
switches the compiler into the mode it needs and stops when it cannot;
a Bazel build takes its standard from the root module, so the check
reports, or stops the build, instead.

Original m4 example:
```m4
AC_PROG_CC_C99
AX_CXX_COMPILE_STDCXX([17], [noext], [mandatory])
```

Example:
```python
# Stop the build unless the C compiler is in C11 mode or later.
checks.AC_LANG_STANDARD("c11", error = True)
# Record whether the C++ compiler is in C++17 mode or later.
checks.AC_LANG_STANDARD("c++17", define = "HAVE_CXX17")
# Exactly C99 (the GNU dialect reports the same value).
checks.AC_LANG_STANDARD("c99", compare = "==", error = "C99 required")
```

Note:
    This is a rules_cc_autoconf extension.  Dialects compare equal to
    the standard they extend (`gnu11` is `c11`), and the standard is the
    build's: a `-std` of the target's own `conlyopts` / `cxxopts` is seen,
    a dependency's is not.
*�
�
checks.AC_LANG_STANDARDU
standardE`c89` .. `c23` or `c++98` .. `c++26`, with or without a `gnu` prefix. (�
name~Cache variable name. Defaults to `ac_cv_std_<standard>` plus a suffix
for comparisons other than `>=` (`ac_cv_std_c99_exact`).None(q
compare^How the compiler's standard must relate to `standard`: `>=` (default),
`==`, `<=`, `>` or `<`.">="(?
define-Define name to set when the comparison holds.None(�
error�Stop the build when the comparison does not hold: `True` for a message
naming the flags to add (GNU and MSVC spellings), or a message of your own.None(F
copts5Optional list of extra compiler flags for this check.None(H
requires4Requirements that must be met for this check to run.None(�
Check the language standard the compiler is running in.

The probe compares `__STDC_VERSION__` (C) or `__cplusplus` -- `_MSVC_LANG`
on MSVC, whose `__cplusplus` stays at 199711L -- with the value of
`standard`, under the flags every check sees: the toolchain's, `--copt` /
`--conlyopt` / `--cxxopt`, and the target's own `copts` / `conlyopts` /
`cxxopts`.  It is
the test behind `AC_PROG_CC_C99`, `AC_PROG_CC_STDC` and
`AX_CXX_COMPILE_STDCXX`'s mandatory mode, as one check: configure
switches the compiler into the mode it needs and stops when it cannot;
a Bazel build takes its standard from the root module, so the check
reports, or stops the build, instead.

Original m4 example:
```m4
AC_PROG_CC_C99
AX_CXX_COMPILE_STDCXX([17], [noext], [mandatory])
```

Example:
```python
# Stop the build unless the C compiler is in C11 mode or later.
checks.AC_LANG_STANDARD("c11", error = True)
# Record whether the C++ compiler is in C++17 mode or later.
checks.AC_LANG_STANDARD("c++17", define = "HAVE_CXX17")
# Exactly C99 (the GNU dialect reports the same value).
checks.AC_LANG_STANDARD("c99", compare = "==", error = "C99 required")
```

Note:
    This is a rules_cc_autoconf extension.  Dialects compare equal to
    the standard they extend (`gnu11` is `c11`), and the standard is the
    build's: a `-std` of the target's own `conlyopts` / `cxxopts` is seen,
    a dependency's is not.
"=
;A JSON-encoded check string for use with the autoconf rule.2=
_ac_lang_standard(@@rules_cc_autoconf//autoconf:checks.bzl
���checks.AC_PROG_CC�Check that a C compiler is available.

Original m4 example:
```m4
AC_PROG_CC
AC_PROG_CC([gcc clang])
```

Example:
```python
macros.AC_PROG_CC()
```

Note:
    This is mostly a no-op in Bazel since the toolchain must be configured,
    but returns a check that will verify the compiler works.
*�
�
checks.AC_PROG_CC�
requires�List of requirements that must be met before this check runs.
Can be simple define names (e.g., `"HAVE_FOO"`) or value-based
requirements (e.g., `"REPLACE_FSTAT=1"` to require specific value)None(�Check that a C compiler is available.

Original m4 example:
```m4
AC_PROG_CC
AC_PROG_CC([gcc clang])
```

Example:
```python
macros.AC_PROG_CC()
```

Note:
    This is mostly a no-op in Bazel since the toolchain must be configured,
    but returns a check that will verify the compiler works.
"=
;A JSON-encoded check string for use with the autoconf rule.27
_ac_prog_cc(@@rules_cc_autoconf//autoconf:checks.bzl
�	�	�checks.AC_PROG_CC_C_O�Check if the compiler supports -c and -o flags simultaneously.

Original m4 example:
```m4
AC_PROG_CC_C_O
```

Example:
```python
macros.AC_PROG_CC_C_O()
```

Note:
    If the compiler does NOT support both flags together, the define is set.
*�
�
checks.AC_PROG_CC_C_OR
define0Define name (defaults to `"NO_MINUS_C_MINUS_O"`)"NO_MINUS_C_MINUS_O"(?
language,Language to use for check (`"c"` or `"cpp"`)"c"(�
requires�List of requirements that must be met before this check runs.
Can be simple define names (e.g., `"HAVE_FOO"`) or value-based
requirements (e.g., `"REPLACE_FSTAT=1"` to require specific value)None(]
substLIf True, mark as a substitution variable (for @VAR@ replacement in subst.h).None(�Check if the compiler supports -c and -o flags simultaneously.

Original m4 example:
```m4
AC_PROG_CC_C_O
```

Example:
```python
macros.AC_PROG_CC_C_O()
```

Note:
    If the compiler does NOT support both flags together, the define is set.
"=
;A JSON-encoded check string for use with the autoconf rule.2;
_ac_prog_cc_c_o(@@rules_cc_autoconf//autoconf:checks.bzl
���checks.AC_PROG_CXX�Check that a C++ compiler is available.

Original m4 example:
```m4
AC_PROG_CXX
AC_PROG_CXX([g++ clang++])
```

Example:
```python
macros.AC_PROG_CXX()
```

Note:
    This is mostly a no-op in Bazel since the toolchain must be configured,
    but returns a check that will verify the compiler works.
*�
�
checks.AC_PROG_CXX�
requires�List of requirements that must be met before this check runs.
Can be simple define names (e.g., `"HAVE_FOO"`) or value-based
requirements (e.g., `"REPLACE_FSTAT=1"` to require specific value)None(�Check that a C++ compiler is available.

Original m4 example:
```m4
AC_PROG_CXX
AC_PROG_CXX([g++ clang++])
```

Example:
```python
macros.AC_PROG_CXX()
```

Note:
    This is mostly a no-op in Bazel since the toolchain must be configured,
    but returns a check that will verify the compiler works.
"=
;A JSON-encoded check string for use with the autoconf rule.28
_ac_prog_cxx(@@rules_cc_autoconf//autoconf:checks.bzl
�
�
�checks.AC_SEARCH_LIBS�Search for a function in libc, then in a list of libraries.

Mirrors GNU autoconf's AC_SEARCH_LIBS. The checker tries linking the
function without any extra library first, then with each library in order.

For `function = "main"`, the generated program supplies its own `main`.
Consequently, a working linker succeeds on the initial no-library attempt
and no candidate library is selected, matching GNU Autoconf.

When `subst` is specified, a substitution variable is produced with the
library flag value: `""` if the function is in libc or not found,
`"-l<lib>"` if found in a library.

Original m4 example:
```m4
AC_SEARCH_LIBS([clock_gettime], [rt posix4])
```

Example:
```python
checks.AC_SEARCH_LIBS("clock_gettime", ["rt", "posix4"],
                      subst = "CLOCK_TIME_LIB")
```
*�
�
checks.AC_SEARCH_LIBSC
function3Function name to search for (e.g., "clock_gettime") (c
	librariesRList of library names (without -l prefix) to try in order
(e.g., ["rt", "posix4"]) (K
name;Cache variable name. Defaults to "ac_cv_search_<function>".None(;
code+Custom code to compile and link (optional).None(<
language)Language to use for check ("c" or "cpp")."c"(�
copts~Optional list of extra compiler flags for this check
(e.g., `["-std=c11"]`). Applied to every link attempt in the
search loop.None(�
linkopts�Optional list of extra linker flags for this check
(e.g., `["-pthread"]`). Applied to every link attempt; appended
after the optional `-l<library>` argument.None(H
requires4Requirements that must be met for this check to run.None(H
subst7Substitution variable name for the library flag result.None(�Search for a function in libc, then in a list of libraries.

Mirrors GNU autoconf's AC_SEARCH_LIBS. The checker tries linking the
function without any extra library first, then with each library in order.

For `function = "main"`, the generated program supplies its own `main`.
Consequently, a working linker succeeds on the initial no-library attempt
and no candidate library is selected, matching GNU Autoconf.

When `subst` is specified, a substitution variable is produced with the
library flag value: `""` if the function is in libc or not found,
`"-l<lib>"` if found in a library.

Original m4 example:
```m4
AC_SEARCH_LIBS([clock_gettime], [rt posix4])
```

Example:
```python
checks.AC_SEARCH_LIBS("clock_gettime", ["rt", "posix4"],
                      subst = "CLOCK_TIME_LIB")
```
"=
;A JSON-encoded check string for use with the autoconf rule.2;
_ac_search_libs(@@rules_cc_autoconf//autoconf:checks.bzl
���checks.AC_SUBST�Substitute a variable value (equivalent to AC_SUBST in GNU Autoconf).

Original m4 example:
```m4
HAVE_DECL_WCSDUP=1;   AC_SUBST([HAVE_DECL_WCSDUP])
HAVE_DECL_WCWIDTH=1;  AC_SUBST([HAVE_DECL_WCWIDTH])
```

Conditional example (m4):
```m4
if test $gl_cv_sys_struct_lconv_ok = no; then
  REPLACE_STRUCT_LCONV=1
else
  REPLACE_STRUCT_LCONV=0
fi
AC_SUBST([REPLACE_STRUCT_LCONV])
```

Example:
```python
# Simple (always set)
macros.AC_SUBST("HAVE_DECL_WCSDUP", "1")

# Conditional (set based on another check's result)
macros.AC_SUBST(
    "REPLACE_STRUCT_LCONV",
    condition = "HAVE_STRUCT_LCONV_OK",
    if_true = "0",    # Value when condition is true
    if_false = "1",   # Value when condition is false
)
```

Note:
    **Condition Resolution**: If `condition` references a cache variable (e.g.,
    `condition="ac_cv_header_foo_h"`), it's evaluated as a truthy check:
    - Condition is `true` if the check succeeded AND the value is truthy (non-empty, non-zero)
    - Condition is `false` if the check failed OR the value is falsy (empty, "0")
    - If condition includes a comparison (e.g., `condition="ac_cv_header_foo_h==1"`),
      it performs value comparison instead.

    In GNU Autoconf, `AC_SUBST` is used to substitute shell variables into
    Makefiles and template files (replacing `@VAR@` patterns). When used
    without `condition`, it always sets the variable. When used with
    `condition`, the value depends on the condition's result.
*�
�
checks.AC_SUBST6
variable&Variable name (e.g., `"LIBRARY_PATH"`) (P
valueBValue to assign when no condition is specified (defaults to `"1"`)1(�
requires�Requirements that must be met for this check to run.
Can be define names (e.g., `"HAVE_FOO"`), negated (e.g., `"!HAVE_FOO"`),
or value-based (e.g., `"REPLACE_FSTAT==1"`, `"REPLACE_FSTAT!=0"`).None(�
	condition|Selects which value to use: `if_true` when condition is true,
`if_false` when false. Does not affect whether the check runs.None(D
if_true4Value when condition is true (requires `condition`).1(F
if_false5Value when condition is false (requires `condition`).0(�Substitute a variable value (equivalent to AC_SUBST in GNU Autoconf).

Original m4 example:
```m4
HAVE_DECL_WCSDUP=1;   AC_SUBST([HAVE_DECL_WCSDUP])
HAVE_DECL_WCWIDTH=1;  AC_SUBST([HAVE_DECL_WCWIDTH])
```

Conditional example (m4):
```m4
if test $gl_cv_sys_struct_lconv_ok = no; then
  REPLACE_STRUCT_LCONV=1
else
  REPLACE_STRUCT_LCONV=0
fi
AC_SUBST([REPLACE_STRUCT_LCONV])
```

Example:
```python
# Simple (always set)
macros.AC_SUBST("HAVE_DECL_WCSDUP", "1")

# Conditional (set based on another check's result)
macros.AC_SUBST(
    "REPLACE_STRUCT_LCONV",
    condition = "HAVE_STRUCT_LCONV_OK",
    if_true = "0",    # Value when condition is true
    if_false = "1",   # Value when condition is false
)
```

Note:
    **Condition Resolution**: If `condition` references a cache variable (e.g.,
    `condition="ac_cv_header_foo_h"`), it's evaluated as a truthy check:
    - Condition is `true` if the check succeeded AND the value is truthy (non-empty, non-zero)
    - Condition is `false` if the check failed OR the value is falsy (empty, "0")
    - If condition includes a comparison (e.g., `condition="ac_cv_header_foo_h==1"`),
      it performs value comparison instead.

    In GNU Autoconf, `AC_SUBST` is used to substitute shell variables into
    Makefiles and template files (replacing `@VAR@` patterns). When used
    without `condition`, it always sets the variable. When used with
    `condition`, the value depends on the condition's result.
"=
;A JSON-encoded check string for use with the autoconf rule.25
	_ac_subst(@@rules_cc_autoconf//autoconf:checks.bzl
���!checks.AC_TRY_COMPILE�	Try to compile custom code.

Original m4 example:
```m4
AC_TRY_COMPILE([#include <stdio.h>], [printf("test");], [AC_DEFINE([HAVE_PRINTF], [1])])
```

Example:
```python
load("//autoconf:checks.bzl", "utils")
macros.AC_TRY_COMPILE(
    code = "#include <stdio.h>\nint main() { printf(\"test\"); return 0; }",
    define = "HAVE_PRINTF",
)
macros.AC_TRY_COMPILE(file = ":test.c", define = "CUSTOM_CHECK")
macros.AC_TRY_COMPILE(
    includes = ["pthread.h"],
    code = "int x = PTHREAD_CREATE_DETACHED; (void)x;",
    define = "HAVE_PTHREAD_CREATE_DETACHED",
)
macros.AC_TRY_COMPILE(
    code = utils.AC_LANG_PROGRAM(["#include <stdio.h>"], "printf("test");"),
    define = "HAVE_PRINTF",
)
```

Note:
    This is a rules_cc_autoconf extension. While GNU Autoconf has an
    obsolete AC_TRY_COMPILE macro (replaced by AC_COMPILE_IFELSE), this
    version adds support for file-based checks which is useful in Bazel.

    When `includes` is provided along with `code`, the code is treated as
    the body of main() and the includes are prepended. For the AC_LANG_PROGRAM
    pattern (prologue + body), use `utils.AC_LANG_PROGRAM(prologue, body)` and
    pass the result as `code`.
*�
�
checks.AC_TRY_COMPILE�
code�Code to compile. If `includes` is also provided, this is treated as
the body of main(). Otherwise, it should be complete C code. For
AC_LANG_PROGRAM-style tests, use code = utils.AC_LANG_PROGRAM(prologue, body).
May be a list of programs (or bodies, with `includes`): they are
tried in order and the check succeeds when one compiles.None($
nameCache variable name.None(<
define*Define name to set if compilation succeedsNone(y
includeseOptional list of headers to include. When provided, `code` is
treated as the body of main() function.None(?
language,Language to use for check (`"c"` or `"cpp"`)"c"(�
compile_defines�Optional list of preprocessor define names from previous checks
to add before includes (e.g., `["_GNU_SOURCE", "_DARWIN_C_SOURCE"]`).
Each string must match the define name of a previous check. The values
from those checks will be used automatically.None(g
coptsVOptional list of extra compiler flags for this check
(e.g., `["-msse2", "-std=c11"]`).None(�
requires�Requirements that must be met for this check to run.
Can be define names (e.g., `"HAVE_FOO"`), negated (e.g., `"!HAVE_FOO"`),
or value-based (e.g., `"REPLACE_FSTAT==1"`, `"REPLACE_FSTAT!=0"`).None(]
if_trueJValue to use when check succeeds (currently not used for this check type).None([
if_falseGValue to use when check fails (currently not used for this check type).None(�
subst�If True, automatically create a substitution variable with the same name
that will be set to "1" if the check succeeds, "0" if it fails.None(�
error�Stop the build with this message when the check fails: `AC_MSG_ERROR` in the
branch configure runs when the test does not pass, e.g. a mandatory language standard.None(�	Try to compile custom code.

Original m4 example:
```m4
AC_TRY_COMPILE([#include <stdio.h>], [printf("test");], [AC_DEFINE([HAVE_PRINTF], [1])])
```

Example:
```python
load("//autoconf:checks.bzl", "utils")
macros.AC_TRY_COMPILE(
    code = "#include <stdio.h>\nint main() { printf(\"test\"); return 0; }",
    define = "HAVE_PRINTF",
)
macros.AC_TRY_COMPILE(file = ":test.c", define = "CUSTOM_CHECK")
macros.AC_TRY_COMPILE(
    includes = ["pthread.h"],
    code = "int x = PTHREAD_CREATE_DETACHED; (void)x;",
    define = "HAVE_PTHREAD_CREATE_DETACHED",
)
macros.AC_TRY_COMPILE(
    code = utils.AC_LANG_PROGRAM(["#include <stdio.h>"], "printf("test");"),
    define = "HAVE_PRINTF",
)
```

Note:
    This is a rules_cc_autoconf extension. While GNU Autoconf has an
    obsolete AC_TRY_COMPILE macro (replaced by AC_COMPILE_IFELSE), this
    version adds support for file-based checks which is useful in Bazel.

    When `includes` is provided along with `code`, the code is treated as
    the body of main() and the includes are prepended. For the AC_LANG_PROGRAM
    pattern (prologue + body), use `utils.AC_LANG_PROGRAM(prologue, body)` and
    pass the result as `code`.
"=
;A JSON-encoded check string for use with the autoconf rule.2;
_ac_try_compile(@@rules_cc_autoconf//autoconf:checks.bzl
���$checks.AC_TRY_LINK�
Try to compile and link custom code.

This function mirrors GNU Autoconf's `AC_LINK_IFELSE` macro, which uses
`AC_LANG_PROGRAM` to construct test programs. In Bazel, use `code` (optionally
with `includes`). For the AC_LANG_PROGRAM pattern, pass
code = utils.AC_LANG_PROGRAM(prologue, body).

Comparison with GNU Autoconf:

**GNU Autoconf:**
```m4
AC_LINK_IFELSE(
    [AC_LANG_PROGRAM(
        [[#include <stdio.h>]],     # Prologue (includes/declarations)
        [[printf("test");]]         # Body (code inside main())
    )],
    [AC_DEFINE([HAVE_PRINTF], [1])],
    []
)
```

**Bazel (AC_LANG_PROGRAM pattern):**
```python
load("//autoconf:checks.bzl", "utils")
checks.AC_TRY_LINK(
    code = utils.AC_LANG_PROGRAM(["#include <stdio.h>"], "printf("test");"),
    define = "HAVE_PRINTF",
)
```

**Bazel (includes pattern - backward compat):**
```python
checks.AC_TRY_LINK(
    includes = ["stdio.h"],
    code = "printf("test");",     # Treated as body of main()
    define = "HAVE_PRINTF",
)
```

**Bazel (raw code pattern):**
```python
checks.AC_TRY_LINK(
    code = "#include <stdio.h>\nint main() { printf(\"test\"); return 0; }",
    define = "HAVE_PRINTF",
)
```

Note:
    This is similar to AC_TRY_COMPILE but also links the code, which is necessary
    to verify that functions are available at link time (not just declared).
*�
�
checks.AC_TRY_LINK�
code�Code to compile and link. If `includes` is also provided, this is
treated as the body of main(). Otherwise, it should be complete C code.
For AC_LANG_PROGRAM-style tests use code = utils.AC_LANG_PROGRAM(prologue, body).
May be a list of programs (or bodies, with `includes`): they are
tried in order and the check succeeds when one links.None($
nameCache variable name.None(H
define6Define name to set if compilation and linking succeedsNone(�
includes~Optional list of headers to include (backward compatibility).
When provided, `code` is treated as the body of main() function.None(?
language,Language to use for check (`"c"` or `"cpp"`)"c"(�
compile_defines�Optional list of preprocessor define names from previous checks
to add before includes (e.g., `["_GNU_SOURCE", "_DARWIN_C_SOURCE"]`).
Each string must match the define name of a previous check. The values
from those checks will be used automatically.None(g
coptsVOptional list of extra compiler flags for this check
(e.g., `["-msse2", "-std=c11"]`).None(r
linkopts^Optional list of extra linker flags for this check
(e.g., `["-lpthread", "-Wl,--as-needed"]`).None(�
requires�Requirements that must be met for this check to run.
Can be define names (e.g., `"HAVE_FOO"`), negated (e.g., `"!HAVE_FOO"`),
or value-based (e.g., `"REPLACE_FSTAT==1"`, `"REPLACE_FSTAT!=0"`).None(Z
if_trueJValue to use when check succeeds (currently not used for this check type).1(X
if_falseGValue to use when check fails (currently not used for this check type).0(]
substLIf True, mark as a substitution variable (for @VAR@ replacement in subst.h).None(�
error�Stop the build with this message when the check fails: `AC_MSG_ERROR` in the
branch configure runs when the test does not pass, e.g. a mandatory language standard.None(�
Try to compile and link custom code.

This function mirrors GNU Autoconf's `AC_LINK_IFELSE` macro, which uses
`AC_LANG_PROGRAM` to construct test programs. In Bazel, use `code` (optionally
with `includes`). For the AC_LANG_PROGRAM pattern, pass
code = utils.AC_LANG_PROGRAM(prologue, body).

Comparison with GNU Autoconf:

**GNU Autoconf:**
```m4
AC_LINK_IFELSE(
    [AC_LANG_PROGRAM(
        [[#include <stdio.h>]],     # Prologue (includes/declarations)
        [[printf("test");]]         # Body (code inside main())
    )],
    [AC_DEFINE([HAVE_PRINTF], [1])],
    []
)
```

**Bazel (AC_LANG_PROGRAM pattern):**
```python
load("//autoconf:checks.bzl", "utils")
checks.AC_TRY_LINK(
    code = utils.AC_LANG_PROGRAM(["#include <stdio.h>"], "printf("test");"),
    define = "HAVE_PRINTF",
)
```

**Bazel (includes pattern - backward compat):**
```python
checks.AC_TRY_LINK(
    includes = ["stdio.h"],
    code = "printf("test");",     # Treated as body of main()
    define = "HAVE_PRINTF",
)
```

**Bazel (raw code pattern):**
```python
checks.AC_TRY_LINK(
    code = "#include <stdio.h>\nint main() { printf(\"test\"); return 0; }",
    define = "HAVE_PRINTF",
)
```

Note:
    This is similar to AC_TRY_COMPILE but also links the code, which is necessary
    to verify that functions are available at link time (not just declared).
"=
;A JSON-encoded check string for use with the autoconf rule.28
_ac_try_link(@@rules_cc_autoconf//autoconf:checks.bzl
���checks.AX_CXX_COMPILE_STDCXX�AX_CXX_COMPILE_STDCXX from the autoconf archive: is the C++ compiler in C++<version> mode?

Defines `HAVE_CXX<version>` when it is (or a later one), and in mandatory
mode stops the build when it is not.  The macro itself would add
`-std=c++<version>` or `-std=gnu++<version>` to CXX; a Bazel build's
standard comes from the root module (`--cxxopt`) or the toolchain, so
only the test remains.

Original m4 example:
```m4
AX_CXX_COMPILE_STDCXX([17], [noext], [mandatory])
```

Example:
```python
checks.AX_CXX_COMPILE_STDCXX("17", "noext", mandatory = True)
```
*�
�
checks.AX_CXX_COMPILE_STDCXX4
version%`11`, `14`, `17`, `20`, `23` or `26`. (�
ext�`ext` or `noext`, as in the macro.  Accepted for fidelity; both dialects
report the same `__cplusplus`, so it does not change the test."ext"(
	mandatoryjStop the build when the compiler is not in that mode (the macro's
`mandatory`); `False` is its `optional`.True(�AX_CXX_COMPILE_STDCXX from the autoconf archive: is the C++ compiler in C++<version> mode?

Defines `HAVE_CXX<version>` when it is (or a later one), and in mandatory
mode stops the build when it is not.  The macro itself would add
`-std=c++<version>` or `-std=gnu++<version>` to CXX; a Bazel build's
standard comes from the root module (`--cxxopt`) or the toolchain, so
only the test remains.

Original m4 example:
```m4
AX_CXX_COMPILE_STDCXX([17], [noext], [mandatory])
```

Example:
```python
checks.AX_CXX_COMPILE_STDCXX("17", "noext", mandatory = True)
```
"=
;A JSON-encoded check string for use with the autoconf rule.2B
_ax_cxx_compile_stdcxx(@@rules_cc_autoconf//autoconf:checks.bzl
���checks.M4_VARIABLE�Define a configuration M4 variable.

Original m4 example:
```m4
REPLACE_FOO=1
```

Conditional example (m4):
```m4
if test $HAVE_FOO = yes; then
  REPLACE_FOO=0
else
  REPLACE_FOO=1
fi
```

Example:
```python
# Simple (always set)
macros.M4_VARIABLE("REPLACE_FOO", "1")

# Conditional (set based on another check's result)
macros.M4_VARIABLE(
    "REPLACE_FOO",
    condition = "HAVE_FOO",
    if_true = "0",    # Value when HAVE_FOO is true
    if_false = "1",   # Value when HAVE_FOO is false
)
```

Note:
    This is similar to `AC_SUBST` but is useful for tracking the difference
    between actual `AC_DEFINE` values and M4 shell variables used in macros.
    Unlike `AC_SUBST`, this does not set `subst=true` by default.
*�
�
checks.M4_VARIABLE1
define#Define name (e.g., `"REPLACE_FOO"`) (P
valueBValue to assign when no condition is specified (defaults to `"1"`)1(�
requires�List of requirements that must be met before this check runs.
Can be simple define names (e.g., `"HAVE_FOO"`) or value-based
requirements (e.g., `"REPLACE_FSTAT=1"` to require specific value)None(�
	condition|Selects which value to use: `if_true` when condition is true,
`if_false` when false. Does not affect whether the check runs.None(G
if_true4Value when condition is true (requires `condition`).None(I
if_false5Value when condition is false (requires `condition`).None(�Define a configuration M4 variable.

Original m4 example:
```m4
REPLACE_FOO=1
```

Conditional example (m4):
```m4
if test $HAVE_FOO = yes; then
  REPLACE_FOO=0
else
  REPLACE_FOO=1
fi
```

Example:
```python
# Simple (always set)
macros.M4_VARIABLE("REPLACE_FOO", "1")

# Conditional (set based on another check's result)
macros.M4_VARIABLE(
    "REPLACE_FOO",
    condition = "HAVE_FOO",
    if_true = "0",    # Value when HAVE_FOO is true
    if_false = "1",   # Value when HAVE_FOO is false
)
```

Note:
    This is similar to `AC_SUBST` but is useful for tracking the difference
    between actual `AC_DEFINE` values and M4 shell variables used in macros.
    Unlike `AC_SUBST`, this does not set `subst=true` by default.
"7
5A JSON-encoded check string for use with the m4 rule.28
_m4_variable(@@rules_cc_autoconf//autoconf:checks.bzl
���macros.AC_CHECK_DECLS�Check multiple declarations, creating HAVE_DECL_<SYMBOL> defines (AC_CHECK_DECLS).

GNU Autoconf's AC_CHECK_DECLS(symbol, ...) checks whether each symbol is
declared (e.g. in a header). This macro runs AC_CHECK_DECL for each symbol
and sets define names HAVE_DECL_<SYMBOL> following autoconf conventions.

Upstream:
https://www.gnu.org/savannah-checkouts/gnu/autoconf/manual/autoconf-2.72/autoconf.html#index-AC_005fCHECK_002dDECL

M4 example (configure.ac):
  AC_CHECK_DECLS([NULL, stdout, stderr], [], [], [[#include <stdio.h>]])
  AC_CHECK_DECL([NULL], [AC_DEFINE([HAVE_DECL_NULL], [1])], [], [[#include <stddef.h>]])

Bazel example (use `#include <foo>` in includes):
  load("//autoconf:checks.bzl", "macros")
  macros.AC_CHECK_DECLS(["NULL", "stdout", "stderr"], includes = ["#include <stdio.h>"])
  # Defines: HAVE_DECL_NULL, HAVE_DECL_STDOUT, HAVE_DECL_STDERR
*�
�
macros.AC_CHECK_DECLS-
symbolsList of symbol names to check. (V
includesBOptional list of include directives (e.g. ["#include <stdio.h>"]).None(^
compile_definesCOptional list of preprocessor define names (applies to all checks).None(A
language.Language to use for checks (`"c"` or `"cpp"`)."c"(J
requires6Requirements that must be met (applies to all checks).None(L
if_true9Value to use when check succeeds (applies to all checks).None(J
if_false6Value to use when check fails (applies to all checks).None(8
subst'Subst behavior (applies to all checks).None(�Check multiple declarations, creating HAVE_DECL_<SYMBOL> defines (AC_CHECK_DECLS).

GNU Autoconf's AC_CHECK_DECLS(symbol, ...) checks whether each symbol is
declared (e.g. in a header). This macro runs AC_CHECK_DECL for each symbol
and sets define names HAVE_DECL_<SYMBOL> following autoconf conventions.

Upstream:
https://www.gnu.org/savannah-checkouts/gnu/autoconf/manual/autoconf-2.72/autoconf.html#index-AC_005fCHECK_002dDECL

M4 example (configure.ac):
  AC_CHECK_DECLS([NULL, stdout, stderr], [], [], [[#include <stdio.h>]])
  AC_CHECK_DECL([NULL], [AC_DEFINE([HAVE_DECL_NULL], [1])], [], [[#include <stddef.h>]])

Bazel example (use `#include <foo>` in includes):
  load("//autoconf:checks.bzl", "macros")
  macros.AC_CHECK_DECLS(["NULL", "stdout", "stderr"], includes = ["#include <stdio.h>"])
  # Defines: HAVE_DECL_NULL, HAVE_DECL_STDOUT, HAVE_DECL_STDERR
"%
#List of JSON-encoded check strings.2;
_ac_check_decls(@@rules_cc_autoconf//autoconf:checks.bzl
���macros.AC_CHECK_FUNCS�Check multiple functions, creating HAVE_<FUNCTION> defines (AC_CHECK_FUNCS).

GNU Autoconf's AC_CHECK_FUNCS(function, ...) checks whether each function
is available (linkable). This macro runs AC_CHECK_FUNC for each function
and sets HAVE_<FUNCTION> following autoconf conventions.

Upstream:
https://www.gnu.org/savannah-checkouts/gnu/autoconf/manual/autoconf-2.72/autoconf.html#index-AC_005fCHECK_002dFUNC

M4 example (configure.ac):
  AC_CHECK_FUNCS([malloc, free, printf])

Bazel example:
  load("//autoconf:checks.bzl", "macros")
  macros.AC_CHECK_FUNCS(["malloc", "free", "printf"])
  # Defines: HAVE_MALLOC, HAVE_FREE, HAVE_PRINTF
*�	
�	
macros.AC_CHECK_FUNCS1
	functions List of function names to check. (�
codeuCustom program, or list of programs tried in order, to compile
and link (applies to all checks); see `AC_CHECK_FUNC`.None(A
language.Language to use for checks (`"c"` or `"cpp"`)."c"(^
compile_definesCOptional list of preprocessor define names (applies to all checks).None(J
requires6Requirements that must be met (applies to all checks).None(8
subst'Subst behavior (applies to all checks).None(�Check multiple functions, creating HAVE_<FUNCTION> defines (AC_CHECK_FUNCS).

GNU Autoconf's AC_CHECK_FUNCS(function, ...) checks whether each function
is available (linkable). This macro runs AC_CHECK_FUNC for each function
and sets HAVE_<FUNCTION> following autoconf conventions.

Upstream:
https://www.gnu.org/savannah-checkouts/gnu/autoconf/manual/autoconf-2.72/autoconf.html#index-AC_005fCHECK_002dFUNC

M4 example (configure.ac):
  AC_CHECK_FUNCS([malloc, free, printf])

Bazel example:
  load("//autoconf:checks.bzl", "macros")
  macros.AC_CHECK_FUNCS(["malloc", "free", "printf"])
  # Defines: HAVE_MALLOC, HAVE_FREE, HAVE_PRINTF
"%
#List of JSON-encoded check strings.2;
_ac_check_funcs(@@rules_cc_autoconf//autoconf:checks.bzl
���macros.AC_CHECK_HEADERS�Check multiple headers, creating HAVE_<HEADER> defines (AC_CHECK_HEADERS).

GNU Autoconf's AC_CHECK_HEADERS(header, ...) checks whether each header can
be compiled. This macro runs AC_CHECK_HEADER for each header and sets
HAVE_<HEADER_UPPER> (e.g. HAVE_STDIO_H) following autoconf conventions.
Header names are turned into include directives as #include <header>.

Upstream:
https://www.gnu.org/savannah-checkouts/gnu/autoconf/manual/autoconf-2.72/autoconf.html#index-AC_005fCHECK_002dHEADERS

Original m4 example:
```m4
AC_CHECK_HEADERS([stdio.h, stdlib.h, string.h])
```

Example:
```python
load("//autoconf:checks.bzl", "macros")
macros.AC_CHECK_HEADERS(["stdio.h", "stdlib.h", "string.h"])
# Defines: HAVE_STDIO_H, HAVE_STDLIB_H, HAVE_STRING_H
```
*�

�	
macros.AC_CHECK_HEADERSA
headers2List of header names to check (e.g. "sys/stat.h"). (A
language.Language to use for checks (`"c"` or `"cpp"`)."c"(V
includesBOptional list of include directives (e.g. ["#include <stdio.h>"]).None(^
compile_definesCOptional list of preprocessor define names (applies to all checks).None(J
requires6Requirements that must be met (applies to all checks).None(�Check multiple headers, creating HAVE_<HEADER> defines (AC_CHECK_HEADERS).

GNU Autoconf's AC_CHECK_HEADERS(header, ...) checks whether each header can
be compiled. This macro runs AC_CHECK_HEADER for each header and sets
HAVE_<HEADER_UPPER> (e.g. HAVE_STDIO_H) following autoconf conventions.
Header names are turned into include directives as #include <header>.

Upstream:
https://www.gnu.org/savannah-checkouts/gnu/autoconf/manual/autoconf-2.72/autoconf.html#index-AC_005fCHECK_002dHEADERS

Original m4 example:
```m4
AC_CHECK_HEADERS([stdio.h, stdlib.h, string.h])
```

Example:
```python
load("//autoconf:checks.bzl", "macros")
macros.AC_CHECK_HEADERS(["stdio.h", "stdlib.h", "string.h"])
# Defines: HAVE_STDIO_H, HAVE_STDLIB_H, HAVE_STRING_H
```
"%
#List of JSON-encoded check strings.2=
_ac_check_headers(@@rules_cc_autoconf//autoconf:checks.bzl
���macros.AC_CHECK_MEMBERS�Check multiple structure members, creating HAVE_<AGG>_<MEMBER> defines (AC_CHECK_MEMBERS).

GNU Autoconf's AC_CHECK_MEMBER(aggregate.member, ...) checks whether a
structure member exists. This macro runs AC_CHECK_MEMBER for each
"aggregate.member" and sets HAVE_<AGGREGATE>_<MEMBER> (e.g.
HAVE_STRUCT_STAT_ST_RDEV). Use includes with `#include <foo>` for headers
that declare the aggregate.

Upstream:
https://www.gnu.org/savannah-checkouts/gnu/autoconf/manual/autoconf-2.72/autoconf.html#index-AC_005fCHECK_002dMEMBER

M4 example (configure.ac):
  AC_CHECK_MEMBERS([struct stat.st_rdev, struct tm.tm_zone], [], [], [[#include <sys/stat.h>]])
  AC_CHECK_MEMBER([struct stat.st_rdev], [], [], [[#include <sys/stat.h>]])

Bazel example (use `#include <foo>` in includes):
  load("//autoconf:checks.bzl", "macros")
  macros.AC_CHECK_MEMBERS(
      ["struct stat.st_rdev", "struct tm.tm_zone"],
      includes = ["#include <sys/stat.h>", "#include <time.h>"],
  )
*�
�
macros.AC_CHECK_MEMBERSM
aggregate_members4List of member specs (e.g. ["struct stat.st_rdev"]). (Y
includesEOptional list of include directives (e.g. ["#include <sys/stat.h>"]).None(A
language.Language to use for checks (`"c"` or `"cpp"`)."c"(^
compile_definesCOptional list of preprocessor define names (applies to all checks).None(J
requires6Requirements that must be met (applies to all checks).None(L
if_true9Value to use when check succeeds (applies to all checks).None(J
if_false6Value to use when check fails (applies to all checks).None(8
subst'Subst behavior (applies to all checks).None(�Check multiple structure members, creating HAVE_<AGG>_<MEMBER> defines (AC_CHECK_MEMBERS).

GNU Autoconf's AC_CHECK_MEMBER(aggregate.member, ...) checks whether a
structure member exists. This macro runs AC_CHECK_MEMBER for each
"aggregate.member" and sets HAVE_<AGGREGATE>_<MEMBER> (e.g.
HAVE_STRUCT_STAT_ST_RDEV). Use includes with `#include <foo>` for headers
that declare the aggregate.

Upstream:
https://www.gnu.org/savannah-checkouts/gnu/autoconf/manual/autoconf-2.72/autoconf.html#index-AC_005fCHECK_002dMEMBER

M4 example (configure.ac):
  AC_CHECK_MEMBERS([struct stat.st_rdev, struct tm.tm_zone], [], [], [[#include <sys/stat.h>]])
  AC_CHECK_MEMBER([struct stat.st_rdev], [], [], [[#include <sys/stat.h>]])

Bazel example (use `#include <foo>` in includes):
  load("//autoconf:checks.bzl", "macros")
  macros.AC_CHECK_MEMBERS(
      ["struct stat.st_rdev", "struct tm.tm_zone"],
      includes = ["#include <sys/stat.h>", "#include <time.h>"],
  )
"%
#List of JSON-encoded check strings.2=
_ac_check_members(@@rules_cc_autoconf//autoconf:checks.bzl
���macros.AC_CHECK_TYPES�Check multiple types, creating HAVE_<TYPE> defines (AC_CHECK_TYPES).

GNU Autoconf's AC_CHECK_TYPE(type, ...) checks whether each type is defined.
This macro runs AC_CHECK_TYPE for each type and sets HAVE_<TYPE> (e.g.
HAVE_SIZE_T) following autoconf conventions. Use includes with
`#include <foo>` for the headers that declare the types.

Upstream:
https://www.gnu.org/savannah-checkouts/gnu/autoconf/manual/autoconf-2.72/autoconf.html#index-AC_005fCHECK_002dTYPE

M4 example (configure.ac):
  AC_CHECK_TYPES([size_t, pthread_t, pid_t], [], [], [[#include <stddef.h>]])
  AC_CHECK_TYPE([pthread_t], [], [], [[#include <pthread.h>]])

Bazel example (use `#include <foo>` in includes):
  load("//autoconf:checks.bzl", "macros")
  macros.AC_CHECK_TYPES(["size_t", "pthread_t", "pid_t"], includes = ["#include <stddef.h>", "#include <pthread.h>"])
  # Defines: HAVE_SIZE_T, HAVE_PTHREAD_T, HAVE_PID_T
*�
�
macros.AC_CHECK_TYPES)
typesList of type names to check. (W
includesCOptional list of include directives (e.g. ["#include <stddef.h>"]).None(A
language.Language to use for checks (`"c"` or `"cpp"`)."c"(^
compile_definesCOptional list of preprocessor define names (applies to all checks).None(J
requires6Requirements that must be met (applies to all checks).None(L
if_true9Value to use when check succeeds (applies to all checks).None(J
if_false6Value to use when check fails (applies to all checks).None(8
subst'Subst behavior (applies to all checks).None(�Check multiple types, creating HAVE_<TYPE> defines (AC_CHECK_TYPES).

GNU Autoconf's AC_CHECK_TYPE(type, ...) checks whether each type is defined.
This macro runs AC_CHECK_TYPE for each type and sets HAVE_<TYPE> (e.g.
HAVE_SIZE_T) following autoconf conventions. Use includes with
`#include <foo>` for the headers that declare the types.

Upstream:
https://www.gnu.org/savannah-checkouts/gnu/autoconf/manual/autoconf-2.72/autoconf.html#index-AC_005fCHECK_002dTYPE

M4 example (configure.ac):
  AC_CHECK_TYPES([size_t, pthread_t, pid_t], [], [], [[#include <stddef.h>]])
  AC_CHECK_TYPE([pthread_t], [], [], [[#include <pthread.h>]])

Bazel example (use `#include <foo>` in includes):
  load("//autoconf:checks.bzl", "macros")
  macros.AC_CHECK_TYPES(["size_t", "pthread_t", "pid_t"], includes = ["#include <stddef.h>", "#include <pthread.h>"])
  # Defines: HAVE_SIZE_T, HAVE_PTHREAD_T, HAVE_PID_T
"%
#List of JSON-encoded check strings.2;
_ac_check_types(@@rules_cc_autoconf//autoconf:checks.bzl
���utils.AC_LANG_FUNC_LINK_TRY�Return GNU autoconf's `AC_LANG_FUNC_LINK_TRY(C)` program for `function`.

The first program of `AC_CHECK_FUNC`'s default `code` list. Pass it alone
as `code` to get GNU's literal answer on every compiler; see
`AC_CHECK_FUNC` for when that matters.
*�
�
utils.AC_LANG_FUNC_LINK_TRY9
function)Name of the function (e.g., `"snprintf"`) (�Return GNU autoconf's `AC_LANG_FUNC_LINK_TRY(C)` program for `function`.

The first program of `AC_CHECK_FUNC`'s default `code` list. Pass it alone
as `code` to get GNU's literal answer on every compiler; see
`AC_CHECK_FUNC` for when that matters.
"
C source for the link probe.2B
_ac_lang_func_link_try(@@rules_cc_autoconf//autoconf:checks.bzl
���utils.AC_LANG_PROGRAM�Build program code from prologue and main body (AC_LANG_PROGRAM).

GNU Autoconf's AC_LANG_PROGRAM(prologue, body) expands to a complete test
program: prologue (includes/declarations) followed by main() containing body.
Use the result as the `code` argument to AC_TRY_COMPILE or AC_TRY_LINK.

Upstream:
https://www.gnu.org/savannah-checkouts/gnu/autoconf/manual/autoconf-2.72/autoconf.html#index-AC_005fLANG_005fPROGRAM

M4 example (configure.ac):
  AC_TRY_COMPILE([AC_LANG_PROGRAM([[#include <stdio.h>]], [printf("test");])], ...)
  AC_TRY_LINK([AC_LANG_PROGRAM([[#include <langinfo.h>]], [char* cs = nl_langinfo(CODESET); return !cs;])], ...)

Bazel example (use `#include <foo>` in the prologue list):
  load("//autoconf:checks.bzl", "utils", "checks")
  checks.AC_TRY_COMPILE(
      code = utils.AC_LANG_PROGRAM(["#include <stdio.h>"], "printf("test");"),
      define = "HAVE_PRINTF",
  )
  checks.AC_TRY_LINK(
      code = utils.AC_LANG_PROGRAM(
          ["#include <langinfo.h>"],
          "char* cs = nl_langinfo(CODESET); return !cs;",
      ),
      define = "HAVE_LANGINFO_CODESET",
  )
*�
�
utils.AC_LANG_PROGRAM[
prologueKList of strings (include directives or declarations), joined with newlines. (W
bodyKCode inside main() — a string, or a list of strings joined with newlines. (�Build program code from prologue and main body (AC_LANG_PROGRAM).

GNU Autoconf's AC_LANG_PROGRAM(prologue, body) expands to a complete test
program: prologue (includes/declarations) followed by main() containing body.
Use the result as the `code` argument to AC_TRY_COMPILE or AC_TRY_LINK.

Upstream:
https://www.gnu.org/savannah-checkouts/gnu/autoconf/manual/autoconf-2.72/autoconf.html#index-AC_005fLANG_005fPROGRAM

M4 example (configure.ac):
  AC_TRY_COMPILE([AC_LANG_PROGRAM([[#include <stdio.h>]], [printf("test");])], ...)
  AC_TRY_LINK([AC_LANG_PROGRAM([[#include <langinfo.h>]], [char* cs = nl_langinfo(CODESET); return !cs;])], ...)

Bazel example (use `#include <foo>` in the prologue list):
  load("//autoconf:checks.bzl", "utils", "checks")
  checks.AC_TRY_COMPILE(
      code = utils.AC_LANG_PROGRAM(["#include <stdio.h>"], "printf("test");"),
      define = "HAVE_PRINTF",
  )
  checks.AC_TRY_LINK(
      code = utils.AC_LANG_PROGRAM(
          ["#include <langinfo.h>"],
          "char* cs = nl_langinfo(CODESET); return !cs;",
      ),
      define = "HAVE_LANGINFO_CODESET",
  )
"N
LA string suitable for the `code` parameter of AC_TRY_COMPILE or AC_TRY_LINK.2<
_ac_lang_program(@@rules_cc_autoconf//autoconf:checks.bzl
���Cchecks�# checks

This module provides Bazel macros that mirror GNU Autoconf's behavior.

## Cache Variables, Defines, and Subst Values

Checks (AC_CHECK_FUNC, AC_CHECK_HEADER, etc.) create cache variables by default, following
autoconf's naming convention:
- AC_CHECK_HEADER("foo.h") -> cache variable "ac_cv_header_foo_h"
- AC_CHECK_FUNC("foo") -> cache variable "ac_cv_func_foo"
- AC_CHECK_DECL("foo") -> cache variable "ac_cv_have_decl_foo"

Defines and subst values are created explicitly using AC_DEFINE and AC_SUBST.

## Condition Resolution

When AC_DEFINE or AC_SUBST use a `condition` parameter that references a cache variable
(e.g., `condition="ac_cv_header_foo_h"`), the condition is evaluated as a **truthy check**:

- Condition is `true` if:
  - The cache variable exists (check was run)
  - The check succeeded (success = true)
  - The value is truthy (non-empty string, not "0")

- Condition is `false` if:
  - The cache variable doesn't exist (check wasn't run)
  - The check failed (success = false)
  - The value is falsy (empty string or "0")

If the condition includes a comparison operator (e.g., `condition="ac_cv_header_foo_h==1"`),
it performs value comparison instead of truthy check. A define that produced no
value (`/* #undef X */` in config.h) compares as `0`, as it would in `#if X == 0`;
a substitution whose value is the empty string does not.

Example:
```python
# Check creates cache variable
macros.AC_CHECK_HEADER("alloca.h")
# -> Creates cache variable: "ac_cv_header_alloca_h" with value "1" (if header exists)

# Define with truthy condition
macros.AC_DEFINE(
    "HAVE_ALLOCA_H",
    condition="ac_cv_header_alloca_h",  # Truthy: true if check succeeded and value is truthy
    if_true="1",
    if_false=None,  # Don't define if condition is false
)

# Subst with truthy condition
macros.AC_SUBST(
    "HAVE_ALLOCA_H",
    condition="ac_cv_header_alloca_h",  # Truthy check
    if_true="1",
    if_false="0",  # Always set subst value
)
```

## Default Includes

Default includes used by AC_CHECK_DECL, AC_CHECK_TYPE, etc. when no includes are specified.

GNU Autoconf's AC_INCLUDES_DEFAULT uses #ifdef HAVE_* guards, but that relies on
AC_CHECK_HEADERS_ONCE being called earlier to define those macros. In Bazel, each
compile test runs independently without access to results from other checks, so we
use unconditional includes instead. This matches what would happen on a modern
POSIX system where all the standard headers exist.

See: https://www.gnu.org/savannah-checkouts/gnu/autoconf/manual/autoconf-2.72/autoconf.html#Default-Includes

## Header / includes parameter

Checks that need to include headers (AC_CHECK_DECL, AC_CHECK_TYPE, AC_CHECK_SIZEOF,
AC_CHECK_MEMBER, etc.) take an **`includes`** parameter. **AC_CHECK_FUNC** does not
take includes (standard Autoconf link test only); use **GL_CHECK_FUNCS_ANDROID** (or
other GL_CHECK_FUNCS* in gnulib/macros.bzl) when includes are needed. Both of these forms are
supported:

Use **include directives** as strings, e.g. `"#include <stdlib.h>"` or
`"#include <sys/stat.h>"`, matching Autoconf/gnulib (e.g.
`gl_CHECK_FUNCS_ANDROID([faccessat], [[#include <unistd.h>]])`). The list is
joined with newlines to form the prologue of the test program.

The parameter `headers` is a deprecated alias for `includes`; prefer `includes`.
z�)
checks
���# checks

This module provides Bazel macros that mirror GNU Autoconf's behavior.

## Cache Variables, Defines, and Subst Values

Checks (AC_CHECK_FUNC, AC_CHECK_HEADER, etc.) create cache variables by default, following
autoconf's naming convention:
- AC_CHECK_HEADER("foo.h") -> cache variable "ac_cv_header_foo_h"
- AC_CHECK_FUNC("foo") -> cache variable "ac_cv_func_foo"
- AC_CHECK_DECL("foo") -> cache variable "ac_cv_have_decl_foo"

Defines and subst values are created explicitly using AC_DEFINE and AC_SUBST.

## Condition Resolution

When AC_DEFINE or AC_SUBST use a `condition` parameter that references a cache variable
(e.g., `condition="ac_cv_header_foo_h"`), the condition is evaluated as a **truthy check**:

- Condition is `true` if:
  - The cache variable exists (check was run)
  - The check succeeded (success = true)
  - The value is truthy (non-empty string, not "0")

- Condition is `false` if:
  - The cache variable doesn't exist (check wasn't run)
  - The check failed (success = false)
  - The value is falsy (empty string or "0")

If the condition includes a comparison operator (e.g., `condition="ac_cv_header_foo_h==1"`),
it performs value comparison instead of truthy check. A define that produced no
value (`/* #undef X */` in config.h) compares as `0`, as it would in `#if X == 0`;
a substitution whose value is the empty string does not.

Example:
```python
# Check creates cache variable
macros.AC_CHECK_HEADER("alloca.h")
# -> Creates cache variable: "ac_cv_header_alloca_h" with value "1" (if header exists)

# Define with truthy condition
macros.AC_DEFINE(
    "HAVE_ALLOCA_H",
    condition="ac_cv_header_alloca_h",  # Truthy: true if check succeeded and value is truthy
    if_true="1",
    if_false=None,  # Don't define if condition is false
)

# Subst with truthy condition
macros.AC_SUBST(
    "HAVE_ALLOCA_H",
    condition="ac_cv_header_alloca_h",  # Truthy check
    if_true="1",
    if_false="0",  # Always set subst value
)
```

## Default Includes

Default includes used by AC_CHECK_DECL, AC_CHECK_TYPE, etc. when no includes are specified.

GNU Autoconf's AC_INCLUDES_DEFAULT uses #ifdef HAVE_* guards, but that relies on
AC_CHECK_HEADERS_ONCE being called earlier to define those macros. In Bazel, each
compile test runs independently without access to results from other checks, so we
use unconditional includes instead. This matches what would happen on a modern
POSIX system where all the standard headers exist.

See: https://www.gnu.org/savannah-checkouts/gnu/autoconf/manual/autoconf-2.72/autoconf.html#Default-Includes

## Header / includes parameter

Checks that need to include headers (AC_CHECK_DECL, AC_CHECK_TYPE, AC_CHECK_SIZEOF,
AC_CHECK_MEMBER, etc.) take an **`includes`** parameter. **AC_CHECK_FUNC** does not
take includes (standard Autoconf link test only); use **GL_CHECK_FUNCS_ANDROID** (or
other GL_CHECK_FUNCS* in gnulib/macros.bzl) when includes are needed. Both of these forms are
supported:

Use **include directives** as strings, e.g. `"#include <stdlib.h>"` or
`"#include <sys/stat.h>"`, matching Autoconf/gnulib (e.g.
`gl_CHECK_FUNCS_ANDROID([faccessat], [[#include <unistd.h>]])`). The list is
joined with newlines to form the prologue of the test program.

The parameter `headers` is a deprecated alias for `includes`; prefer `includes`.
"N
AC_BUILD_SETTING
��_ac_build_setting"checks.AC_BUILD_SETTING"E
AC_C_RESTRICT
��_ac_c_restrict"checks.AC_C_RESTRICT"N
AC_CHECK_ALIGNOF
��_ac_check_alignof"checks.AC_CHECK_ALIGNOF"f
AC_CHECK_C_COMPILER_FLAG
��_ac_check_c_compiler_flag"checks.AC_CHECK_C_COMPILER_FLAG"l
AC_CHECK_CXX_COMPILER_FLAG
��_ac_check_cxx_compiler_flag"!checks.AC_CHECK_CXX_COMPILER_FLAG"E
AC_CHECK_DECL
��_ac_check_decl"checks.AC_CHECK_DECL"E
AC_CHECK_FUNC
��_ac_check_func"checks.AC_CHECK_FUNC"K
AC_CHECK_HEADER
��_ac_check_header"checks.AC_CHECK_HEADER"B
AC_CHECK_LIB
��_ac_check_lib"checks.AC_CHECK_LIB"K
AC_CHECK_MEMBER
��_ac_check_member"checks.AC_CHECK_MEMBER"K
AC_CHECK_SIZEOF
��_ac_check_sizeof"checks.AC_CHECK_SIZEOF"E
AC_CHECK_TYPE
��_ac_check_type"checks.AC_CHECK_TYPE"H
AC_COMPUTE_INT
��_ac_compute_int"checks.AC_COMPUTE_INT"9
	AC_DEFINE
��
_ac_define"checks.AC_DEFINE"T
AC_DEFINE_UNQUOTED
��_ac_define_unquoted"checks.AC_DEFINE_UNQUOTED"3
AC_FAIL
��_ac_fail"checks.AC_FAIL"N
AC_LANG_STANDARD
��_ac_lang_standard"checks.AC_LANG_STANDARD"<

AC_PROG_CC
��_ac_prog_cc"checks.AC_PROG_CC"H
AC_PROG_CC_C_O
��_ac_prog_cc_c_o"checks.AC_PROG_CC_C_O"?
AC_PROG_CXX
��_ac_prog_cxx"checks.AC_PROG_CXX"H
AC_SEARCH_LIBS
��_ac_search_libs"checks.AC_SEARCH_LIBS"6
AC_SUBST
��	_ac_subst"checks.AC_SUBST"H
AC_TRY_COMPILE
��_ac_try_compile"checks.AC_TRY_COMPILE"?
AC_TRY_LINK
��_ac_try_link"checks.AC_TRY_LINK"]
AX_CXX_COMPILE_STDCXX
��_ax_cxx_compile_stdcxx"checks.AX_CXX_COMPILE_STDCXX"?
M4_VARIABLE
��_m4_variable"checks.M4_VARIABLE*(@@rules_cc_autoconf//autoconf:checks.bzl�7macros�# checks

This module provides Bazel macros that mirror GNU Autoconf's behavior.

## Cache Variables, Defines, and Subst Values

Checks (AC_CHECK_FUNC, AC_CHECK_HEADER, etc.) create cache variables by default, following
autoconf's naming convention:
- AC_CHECK_HEADER("foo.h") -> cache variable "ac_cv_header_foo_h"
- AC_CHECK_FUNC("foo") -> cache variable "ac_cv_func_foo"
- AC_CHECK_DECL("foo") -> cache variable "ac_cv_have_decl_foo"

Defines and subst values are created explicitly using AC_DEFINE and AC_SUBST.

## Condition Resolution

When AC_DEFINE or AC_SUBST use a `condition` parameter that references a cache variable
(e.g., `condition="ac_cv_header_foo_h"`), the condition is evaluated as a **truthy check**:

- Condition is `true` if:
  - The cache variable exists (check was run)
  - The check succeeded (success = true)
  - The value is truthy (non-empty string, not "0")

- Condition is `false` if:
  - The cache variable doesn't exist (check wasn't run)
  - The check failed (success = false)
  - The value is falsy (empty string or "0")

If the condition includes a comparison operator (e.g., `condition="ac_cv_header_foo_h==1"`),
it performs value comparison instead of truthy check. A define that produced no
value (`/* #undef X */` in config.h) compares as `0`, as it would in `#if X == 0`;
a substitution whose value is the empty string does not.

Example:
```python
# Check creates cache variable
macros.AC_CHECK_HEADER("alloca.h")
# -> Creates cache variable: "ac_cv_header_alloca_h" with value "1" (if header exists)

# Define with truthy condition
macros.AC_DEFINE(
    "HAVE_ALLOCA_H",
    condition="ac_cv_header_alloca_h",  # Truthy: true if check succeeded and value is truthy
    if_true="1",
    if_false=None,  # Don't define if condition is false
)

# Subst with truthy condition
macros.AC_SUBST(
    "HAVE_ALLOCA_H",
    condition="ac_cv_header_alloca_h",  # Truthy check
    if_true="1",
    if_false="0",  # Always set subst value
)
```

## Default Includes

Default includes used by AC_CHECK_DECL, AC_CHECK_TYPE, etc. when no includes are specified.

GNU Autoconf's AC_INCLUDES_DEFAULT uses #ifdef HAVE_* guards, but that relies on
AC_CHECK_HEADERS_ONCE being called earlier to define those macros. In Bazel, each
compile test runs independently without access to results from other checks, so we
use unconditional includes instead. This matches what would happen on a modern
POSIX system where all the standard headers exist.

See: https://www.gnu.org/savannah-checkouts/gnu/autoconf/manual/autoconf-2.72/autoconf.html#Default-Includes

## Header / includes parameter

Checks that need to include headers (AC_CHECK_DECL, AC_CHECK_TYPE, AC_CHECK_SIZEOF,
AC_CHECK_MEMBER, etc.) take an **`includes`** parameter. **AC_CHECK_FUNC** does not
take includes (standard Autoconf link test only); use **GL_CHECK_FUNCS_ANDROID** (or
other GL_CHECK_FUNCS* in gnulib/macros.bzl) when includes are needed. Both of these forms are
supported:

Use **include directives** as strings, e.g. `"#include <stdlib.h>"` or
`"#include <sys/stat.h>"`, matching Autoconf/gnulib (e.g.
`gl_CHECK_FUNCS_ANDROID([faccessat], [[#include <unistd.h>]])`). The list is
joined with newlines to form the prologue of the test program.

The parameter `headers` is a deprecated alias for `includes`; prefer `includes`.
z�
macros
���# checks

This module provides Bazel macros that mirror GNU Autoconf's behavior.

## Cache Variables, Defines, and Subst Values

Checks (AC_CHECK_FUNC, AC_CHECK_HEADER, etc.) create cache variables by default, following
autoconf's naming convention:
- AC_CHECK_HEADER("foo.h") -> cache variable "ac_cv_header_foo_h"
- AC_CHECK_FUNC("foo") -> cache variable "ac_cv_func_foo"
- AC_CHECK_DECL("foo") -> cache variable "ac_cv_have_decl_foo"

Defines and subst values are created explicitly using AC_DEFINE and AC_SUBST.

## Condition Resolution

When AC_DEFINE or AC_SUBST use a `condition` parameter that references a cache variable
(e.g., `condition="ac_cv_header_foo_h"`), the condition is evaluated as a **truthy check**:

- Condition is `true` if:
  - The cache variable exists (check was run)
  - The check succeeded (success = true)
  - The value is truthy (non-empty string, not "0")

- Condition is `false` if:
  - The cache variable doesn't exist (check wasn't run)
  - The check failed (success = false)
  - The value is falsy (empty string or "0")

If the condition includes a comparison operator (e.g., `condition="ac_cv_header_foo_h==1"`),
it performs value comparison instead of truthy check. A define that produced no
value (`/* #undef X */` in config.h) compares as `0`, as it would in `#if X == 0`;
a substitution whose value is the empty string does not.

Example:
```python
# Check creates cache variable
macros.AC_CHECK_HEADER("alloca.h")
# -> Creates cache variable: "ac_cv_header_alloca_h" with value "1" (if header exists)

# Define with truthy condition
macros.AC_DEFINE(
    "HAVE_ALLOCA_H",
    condition="ac_cv_header_alloca_h",  # Truthy: true if check succeeded and value is truthy
    if_true="1",
    if_false=None,  # Don't define if condition is false
)

# Subst with truthy condition
macros.AC_SUBST(
    "HAVE_ALLOCA_H",
    condition="ac_cv_header_alloca_h",  # Truthy check
    if_true="1",
    if_false="0",  # Always set subst value
)
```

## Default Includes

Default includes used by AC_CHECK_DECL, AC_CHECK_TYPE, etc. when no includes are specified.

GNU Autoconf's AC_INCLUDES_DEFAULT uses #ifdef HAVE_* guards, but that relies on
AC_CHECK_HEADERS_ONCE being called earlier to define those macros. In Bazel, each
compile test runs independently without access to results from other checks, so we
use unconditional includes instead. This matches what would happen on a modern
POSIX system where all the standard headers exist.

See: https://www.gnu.org/savannah-checkouts/gnu/autoconf/manual/autoconf-2.72/autoconf.html#Default-Includes

## Header / includes parameter

Checks that need to include headers (AC_CHECK_DECL, AC_CHECK_TYPE, AC_CHECK_SIZEOF,
AC_CHECK_MEMBER, etc.) take an **`includes`** parameter. **AC_CHECK_FUNC** does not
take includes (standard Autoconf link test only); use **GL_CHECK_FUNCS_ANDROID** (or
other GL_CHECK_FUNCS* in gnulib/macros.bzl) when includes are needed. Both of these forms are
supported:

Use **include directives** as strings, e.g. `"#include <stdlib.h>"` or
`"#include <sys/stat.h>"`, matching Autoconf/gnulib (e.g.
`gl_CHECK_FUNCS_ANDROID([faccessat], [[#include <unistd.h>]])`). The list is
joined with newlines to form the prologue of the test program.

The parameter `headers` is a deprecated alias for `includes`; prefer `includes`.
"H
AC_CHECK_DECLS
��_ac_check_decls"macros.AC_CHECK_DECLS"N
AC_CHECK_HEADERS
��_ac_check_headers"macros.AC_CHECK_HEADERS"H
AC_CHECK_FUNCS
��_ac_check_funcs"macros.AC_CHECK_FUNCS"H
AC_CHECK_TYPES
��_ac_check_types"macros.AC_CHECK_TYPES"N
AC_CHECK_MEMBERS
��_ac_check_members"macros.AC_CHECK_MEMBERS*(@@rules_cc_autoconf//autoconf:checks.bzl�6utils�# checks

This module provides Bazel macros that mirror GNU Autoconf's behavior.

## Cache Variables, Defines, and Subst Values

Checks (AC_CHECK_FUNC, AC_CHECK_HEADER, etc.) create cache variables by default, following
autoconf's naming convention:
- AC_CHECK_HEADER("foo.h") -> cache variable "ac_cv_header_foo_h"
- AC_CHECK_FUNC("foo") -> cache variable "ac_cv_func_foo"
- AC_CHECK_DECL("foo") -> cache variable "ac_cv_have_decl_foo"

Defines and subst values are created explicitly using AC_DEFINE and AC_SUBST.

## Condition Resolution

When AC_DEFINE or AC_SUBST use a `condition` parameter that references a cache variable
(e.g., `condition="ac_cv_header_foo_h"`), the condition is evaluated as a **truthy check**:

- Condition is `true` if:
  - The cache variable exists (check was run)
  - The check succeeded (success = true)
  - The value is truthy (non-empty string, not "0")

- Condition is `false` if:
  - The cache variable doesn't exist (check wasn't run)
  - The check failed (success = false)
  - The value is falsy (empty string or "0")

If the condition includes a comparison operator (e.g., `condition="ac_cv_header_foo_h==1"`),
it performs value comparison instead of truthy check. A define that produced no
value (`/* #undef X */` in config.h) compares as `0`, as it would in `#if X == 0`;
a substitution whose value is the empty string does not.

Example:
```python
# Check creates cache variable
macros.AC_CHECK_HEADER("alloca.h")
# -> Creates cache variable: "ac_cv_header_alloca_h" with value "1" (if header exists)

# Define with truthy condition
macros.AC_DEFINE(
    "HAVE_ALLOCA_H",
    condition="ac_cv_header_alloca_h",  # Truthy: true if check succeeded and value is truthy
    if_true="1",
    if_false=None,  # Don't define if condition is false
)

# Subst with truthy condition
macros.AC_SUBST(
    "HAVE_ALLOCA_H",
    condition="ac_cv_header_alloca_h",  # Truthy check
    if_true="1",
    if_false="0",  # Always set subst value
)
```

## Default Includes

Default includes used by AC_CHECK_DECL, AC_CHECK_TYPE, etc. when no includes are specified.

GNU Autoconf's AC_INCLUDES_DEFAULT uses #ifdef HAVE_* guards, but that relies on
AC_CHECK_HEADERS_ONCE being called earlier to define those macros. In Bazel, each
compile test runs independently without access to results from other checks, so we
use unconditional includes instead. This matches what would happen on a modern
POSIX system where all the standard headers exist.

See: https://www.gnu.org/savannah-checkouts/gnu/autoconf/manual/autoconf-2.72/autoconf.html#Default-Includes

## Header / includes parameter

Checks that need to include headers (AC_CHECK_DECL, AC_CHECK_TYPE, AC_CHECK_SIZEOF,
AC_CHECK_MEMBER, etc.) take an **`includes`** parameter. **AC_CHECK_FUNC** does not
take includes (standard Autoconf link test only); use **GL_CHECK_FUNCS_ANDROID** (or
other GL_CHECK_FUNCS* in gnulib/macros.bzl) when includes are needed. Both of these forms are
supported:

Use **include directives** as strings, e.g. `"#include <stdlib.h>"` or
`"#include <sys/stat.h>"`, matching Autoconf/gnulib (e.g.
`gl_CHECK_FUNCS_ANDROID([faccessat], [[#include <unistd.h>]])`). The list is
joined with newlines to form the prologue of the test program.

The parameter `headers` is a deprecated alias for `includes`; prefer `includes`.
z�
utils
���# checks

This module provides Bazel macros that mirror GNU Autoconf's behavior.

## Cache Variables, Defines, and Subst Values

Checks (AC_CHECK_FUNC, AC_CHECK_HEADER, etc.) create cache variables by default, following
autoconf's naming convention:
- AC_CHECK_HEADER("foo.h") -> cache variable "ac_cv_header_foo_h"
- AC_CHECK_FUNC("foo") -> cache variable "ac_cv_func_foo"
- AC_CHECK_DECL("foo") -> cache variable "ac_cv_have_decl_foo"

Defines and subst values are created explicitly using AC_DEFINE and AC_SUBST.

## Condition Resolution

When AC_DEFINE or AC_SUBST use a `condition` parameter that references a cache variable
(e.g., `condition="ac_cv_header_foo_h"`), the condition is evaluated as a **truthy check**:

- Condition is `true` if:
  - The cache variable exists (check was run)
  - The check succeeded (success = true)
  - The value is truthy (non-empty string, not "0")

- Condition is `false` if:
  - The cache variable doesn't exist (check wasn't run)
  - The check failed (success = false)
  - The value is falsy (empty string or "0")

If the condition includes a comparison operator (e.g., `condition="ac_cv_header_foo_h==1"`),
it performs value comparison instead of truthy check. A define that produced no
value (`/* #undef X */` in config.h) compares as `0`, as it would in `#if X == 0`;
a substitution whose value is the empty string does not.

Example:
```python
# Check creates cache variable
macros.AC_CHECK_HEADER("alloca.h")
# -> Creates cache variable: "ac_cv_header_alloca_h" with value "1" (if header exists)

# Define with truthy condition
macros.AC_DEFINE(
    "HAVE_ALLOCA_H",
    condition="ac_cv_header_alloca_h",  # Truthy: true if check succeeded and value is truthy
    if_true="1",
    if_false=None,  # Don't define if condition is false
)

# Subst with truthy condition
macros.AC_SUBST(
    "HAVE_ALLOCA_H",
    condition="ac_cv_header_alloca_h",  # Truthy check
    if_true="1",
    if_false="0",  # Always set subst value
)
```

## Default Includes

Default includes used by AC_CHECK_DECL, AC_CHECK_TYPE, etc. when no includes are specified.

GNU Autoconf's AC_INCLUDES_DEFAULT uses #ifdef HAVE_* guards, but that relies on
AC_CHECK_HEADERS_ONCE being called earlier to define those macros. In Bazel, each
compile test runs independently without access to results from other checks, so we
use unconditional includes instead. This matches what would happen on a modern
POSIX system where all the standard headers exist.

See: https://www.gnu.org/savannah-checkouts/gnu/autoconf/manual/autoconf-2.72/autoconf.html#Default-Includes

## Header / includes parameter

Checks that need to include headers (AC_CHECK_DECL, AC_CHECK_TYPE, AC_CHECK_SIZEOF,
AC_CHECK_MEMBER, etc.) take an **`includes`** parameter. **AC_CHECK_FUNC** does not
take includes (standard Autoconf link test only); use **GL_CHECK_FUNCS_ANDROID** (or
other GL_CHECK_FUNCS* in gnulib/macros.bzl) when includes are needed. Both of these forms are
supported:

Use **include directives** as strings, e.g. `"#include <stdlib.h>"` or
`"#include <sys/stat.h>"`, matching Autoconf/gnulib (e.g.
`gl_CHECK_FUNCS_ANDROID([faccessat], [[#include <unistd.h>]])`). The list is
joined with newlines to form the prologue of the test program.

The parameter `headers` is a deprecated alias for `includes`; prefer `includes`.
"J
AC_LANG_PROGRAM
��_ac_lang_program"utils.AC_LANG_PROGRAM"\
AC_LANG_FUNC_LINK_TRY
��_ac_lang_func_link_try"utils.AC_LANG_FUNC_LINK_TRY"V
AC_INCLUDES_DEFAULT
��_AC_INCLUDES_DEFAULT"utils.AC_INCLUDES_DEFAULT*(@@rules_cc_autoconf//autoconf:checks.bzl�
!//autoconf/private:check_info.bzlrm
5
rules_cc_autoconfautoconf/privatecheck_info.bzl&

make_check
make_check
V>VH
VVJ�
&//autoconf/private:condition_utils.bzlr~
:
rules_cc_autoconfautoconf/privatecondition_utils.bzl2
strip_macro_argsstrip_macro_args
WCWS
WWU�# checks

This module provides Bazel macros that mirror GNU Autoconf's behavior.

## Cache Variables, Defines, and Subst Values

Checks (AC_CHECK_FUNC, AC_CHECK_HEADER, etc.) create cache variables by default, following
autoconf's naming convention:
- AC_CHECK_HEADER("foo.h") -> cache variable "ac_cv_header_foo_h"
- AC_CHECK_FUNC("foo") -> cache variable "ac_cv_func_foo"
- AC_CHECK_DECL("foo") -> cache variable "ac_cv_have_decl_foo"

Defines and subst values are created explicitly using AC_DEFINE and AC_SUBST.

## Condition Resolution

When AC_DEFINE or AC_SUBST use a `condition` parameter that references a cache variable
(e.g., `condition="ac_cv_header_foo_h"`), the condition is evaluated as a **truthy check**:

- Condition is `true` if:
  - The cache variable exists (check was run)
  - The check succeeded (success = true)
  - The value is truthy (non-empty string, not "0")

- Condition is `false` if:
  - The cache variable doesn't exist (check wasn't run)
  - The check failed (success = false)
  - The value is falsy (empty string or "0")

If the condition includes a comparison operator (e.g., `condition="ac_cv_header_foo_h==1"`),
it performs value comparison instead of truthy check. A define that produced no
value (`/* #undef X */` in config.h) compares as `0`, as it would in `#if X == 0`;
a substitution whose value is the empty string does not.

Example:
```python
# Check creates cache variable
macros.AC_CHECK_HEADER("alloca.h")
# -> Creates cache variable: "ac_cv_header_alloca_h" with value "1" (if header exists)

# Define with truthy condition
macros.AC_DEFINE(
    "HAVE_ALLOCA_H",
    condition="ac_cv_header_alloca_h",  # Truthy: true if check succeeded and value is truthy
    if_true="1",
    if_false=None,  # Don't define if condition is false
)

# Subst with truthy condition
macros.AC_SUBST(
    "HAVE_ALLOCA_H",
    condition="ac_cv_header_alloca_h",  # Truthy check
    if_true="1",
    if_false="0",  # Always set subst value
)
```

## Default Includes

Default includes used by AC_CHECK_DECL, AC_CHECK_TYPE, etc. when no includes are specified.

GNU Autoconf's AC_INCLUDES_DEFAULT uses #ifdef HAVE_* guards, but that relies on
AC_CHECK_HEADERS_ONCE being called earlier to define those macros. In Bazel, each
compile test runs independently without access to results from other checks, so we
use unconditional includes instead. This matches what would happen on a modern
POSIX system where all the standard headers exist.

See: https://www.gnu.org/savannah-checkouts/gnu/autoconf/manual/autoconf-2.72/autoconf.html#Default-Includes

## Header / includes parameter

Checks that need to include headers (AC_CHECK_DECL, AC_CHECK_TYPE, AC_CHECK_SIZEOF,
AC_CHECK_MEMBER, etc.) take an **`includes`** parameter. **AC_CHECK_FUNC** does not
take includes (standard Autoconf link test only); use **GL_CHECK_FUNCS_ANDROID** (or
other GL_CHECK_FUNCS* in gnulib/macros.bzl) when includes are needed. Both of these forms are
supported:

Use **include directives** as strings, e.g. `"#include <stdlib.h>"` or
`"#include <sys/stat.h>"`, matching Autoconf/gnulib (e.g.
`gl_CHECK_FUNCS_ANDROID([faccessat], [[#include <unistd.h>]])`). The list is
joined with newlines to form the prologue of the test program.

The parameter `headers` is a deprecated alias for `includes`; prefer `includes`.
��
'
rules_cc_autoconfautoconfdefs.bzl�'autoconf_defaults�Default values for autoconf results.

A default is not a check: nothing is probed, no toolchain is resolved, and the
values are written at analysis time.  A target reads defaults through
`default_deps`, beneath every ordinary result, so a probe of the same name
overrides the default silently where a second probe would be a duplicate
error.  `deps` rejects defaults targets; they only enter through `default_deps`.

This is how gnulib's `*_H_DEFAULTS` macros work: `gl_UNISTD_H_DEFAULTS` sets
`HAVE_DUP3=1`, `REPLACE_DUP2=0` and so on, and the probes that run later
reassign only what they find wanting.  Port such a macro as one
`autoconf_defaults` target and list it in the `default_deps` of every target
whose m4 `AC_REQUIRE`s it:

```python
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:autoconf_defaults.bzl", "autoconf_defaults")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")

# gl_UNISTD_H_DEFAULTS
autoconf_defaults(
    name = "defaults",
    substs = {
        "HAVE_DUP3": "1",
        "REPLACE_DUP2": "0",
    },
)

# gl_FUNC_DUP2: AC_REQUIRE([gl_UNISTD_H_DEFAULTS]), then may set REPLACE_DUP2=1
autoconf(
    name = "dup2",
    checks = [
        checks.AC_SUBST("REPLACE_DUP2", 1, condition = "!gl_cv_func_dup2_works"),
    ],
    default_deps = [":defaults"],
)
```

Defaults compose: `deps` lists other `autoconf_defaults` targets whose values
this one carries along (gnulib's `_H_REQUIRE_DEFAULTS` on top of
`_H_DEFAULTS`), and an `autoconf` target passes the defaults it reads on to
its dependents.  Two defaults of one name must agree.
"�
�
autoconf_defaults�Default values for autoconf results.

A default is not a check: nothing is probed, no toolchain is resolved, and the
values are written at analysis time.  A target reads defaults through
`default_deps`, beneath every ordinary result, so a probe of the same name
overrides the default silently where a second probe would be a duplicate
error.  `deps` rejects defaults targets; they only enter through `default_deps`.

This is how gnulib's `*_H_DEFAULTS` macros work: `gl_UNISTD_H_DEFAULTS` sets
`HAVE_DUP3=1`, `REPLACE_DUP2=0` and so on, and the probes that run later
reassign only what they find wanting.  Port such a macro as one
`autoconf_defaults` target and list it in the `default_deps` of every target
whose m4 `AC_REQUIRE`s it:

```python
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:autoconf_defaults.bzl", "autoconf_defaults")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")

# gl_UNISTD_H_DEFAULTS
autoconf_defaults(
    name = "defaults",
    substs = {
        "HAVE_DUP3": "1",
        "REPLACE_DUP2": "0",
    },
)

# gl_FUNC_DUP2: AC_REQUIRE([gl_UNISTD_H_DEFAULTS]), then may set REPLACE_DUP2=1
autoconf(
    name = "dup2",
    checks = [
        checks.AC_SUBST("REPLACE_DUP2", 1, condition = "!gl_cv_func_dup2_works"),
    ],
    default_deps = [":defaults"],
)
```

Defaults compose: `deps` lists other `autoconf_defaults` targets whose values
this one carries along (gnulib's `_H_REQUIRE_DEFAULTS` on top of
`_H_DEFAULTS`), and an `autoconf` target passes the defaults it reads on to
its dependents.  Two defaults of one name must agree.
*
nameA unique name for this target. �
defines�Default `AC_DEFINE` values: define name to value.  Decimal integers are stored as numbers, as `checks.AC_DEFINE("X", 1)` stores them; anything else as text.
2{}q
depsIOther `autoconf_defaults` targets whose values this target carries along.*
CcAutoconfDefaultsInfo2[]�
substs�Default `AC_SUBST` values: variable name to value (`{"HAVE_DUP3": "1"}`), stored under the cache name `ac_cv_subst_<NAME>` as `checks.AC_SUBST` does.  Decimal integers are stored as numbers; anything else as text.
2{}�
	variables�Default shell variables that are neither defines nor substitutions (`checks.M4_VARIABLE`): name to value, read by `requires` and `condition` expressions and by `cc_gnulib_conditional_hdrs` conditions, e.g. `{"GL_GENERATE_ICONV_H": "false"}`.
2{}";
autoconf_defaults&@@rules_cc_autoconf//autoconf:defs.bzl
[[,
*
nameA unique name for this target. �
�
defines�Default `AC_DEFINE` values: define name to value.  Decimal integers are stored as numbers, as `checks.AC_DEFINE("X", 1)` stores them; anything else as text.
2{}s
q
depsIOther `autoconf_defaults` targets whose values this target carries along.*
CcAutoconfDefaultsInfo2[]�
�
substs�Default `AC_SUBST` values: variable name to value (`{"HAVE_DUP3": "1"}`), stored under the cache name `ac_cv_subst_<NAME>` as `checks.AC_SUBST` does.  Decimal integers are stored as numbers; anything else as text.
2{}�
�
	variables�Default shell variables that are neither defines nor substitutions (`checks.M4_VARIABLE`): name to value, read by `requires` and `condition` expressions and by `cc_gnulib_conditional_hdrs` conditions, e.g. `{"GL_GENERATE_ICONV_H": "false"}`.
2{}�4autoconf_hdr�	Generate configuration headers from results provided by `autoconf` targets.

This rule takes check results from `autoconf` targets (via `deps`) and generates a header file.
The template file (if provided) is used to format the output header.

Example:

```python
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:autoconf_hdr.bzl", "autoconf_hdr")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")

autoconf(
    name = "config_checks",
    checks = [
        checks.AC_CHECK_HEADER("stdio.h"),
        checks.AC_CHECK_HEADER("stdlib.h"),
        checks.AC_CHECK_FUNC("printf"),
    ],
)

autoconf_hdr(
    name = "config",
    out = "config.h",
    deps = [":config_checks"],
    template = "config.h.in",
)
```

Valid `mode` values:
- `"defines"` (default): Only process defines (AC_DEFINE, AC_CHECK_*, etc.), not substitution variables (AC_SUBST). This is for config.h files.
- `"subst"`: Only process substitution variables (AC_SUBST), not defines. This is for subst.h files.
- `"all"`: Process both defines and substitution variables.

This allows you to run checks once and generate multiple header files from the same results.
"�+
�
autoconf_hdr�	Generate configuration headers from results provided by `autoconf` targets.

This rule takes check results from `autoconf` targets (via `deps`) and generates a header file.
The template file (if provided) is used to format the output header.

Example:

```python
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:autoconf_hdr.bzl", "autoconf_hdr")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")

autoconf(
    name = "config_checks",
    checks = [
        checks.AC_CHECK_HEADER("stdio.h"),
        checks.AC_CHECK_HEADER("stdlib.h"),
        checks.AC_CHECK_FUNC("printf"),
    ],
)

autoconf_hdr(
    name = "config",
    out = "config.h",
    deps = [":config_checks"],
    template = "config.h.in",
)
```

Valid `mode` values:
- `"defines"` (default): Only process defines (AC_DEFINE, AC_CHECK_*, etc.), not substitution variables (AC_SUBST). This is for config.h files.
- `"subst"`: Only process substitution variables (AC_SUBST), not defines. This is for subst.h files.
- `"all"`: Process both defines and substitution variables.

This allows you to run checks once and generate multiple header files from the same results.
*
nameA unique name for this target. �
default_deps�`autoconf_defaults` targets whose values stand where no result of the name comes through `deps`
(a result overrides a default silently; two defaults of one name must agree).  The defaults the
`deps` carry are read as well.
*
CcAutoconfDefaultsInfo2[]�
defaults�Deprecated and ignored: defaults come through `deps` and `default_deps`; the autoconf toolchain
no longer carries any.  Accepted so existing BUILD files keep loading.2False�
deps�List of `autoconf` targets which provide check results. Results from all deps will be merged together, and duplicate define names will produce an error. If not provided, an empty results file will be created.*
CcAutoconfInfo2[]�
inlines�A mapping of strings to files for replace within the content of the given `template` attribute.

The exact string in the template is replaced with the content of the associated file.
Any `@VAR@` style placeholders in the inline file content will be replaced with their
corresponding define values (package info, check results, etc.) after insertion.	2{}]
modeHProcessing mode that determines what should be replaced within the file.2	"defines"9
out.The output config file (typically `config.h`). �
substitutions�A mapping of exact strings to replacement values.

Each entry performs an exact text replacement in the template - the key
string is replaced with the value string. No special patterns or wrappers
are added.

Example:
```python
autoconf_hdr(
    name = "config",
    out = "config.h",
    template = "config.h.in",
    substitutions = {
        "@MY_VERSION@": "1.2.3",
        "@BUILD_TYPE@": "release",
        "PLACEHOLDER_TEXT": "actual_value",
    },
    deps = [":checks"],
)
```

This would replace the exact string `@MY_VERSION@` with `1.2.3`,
`@BUILD_TYPE@` with `release`, and `PLACEHOLDER_TEXT` with `actual_value`.
2{}�
template�Template file (`config.h.in`) to use as base for generating the header file. The template is used to format the output header, but does not generate any checks. "6
autoconf_hdr&@@rules_cc_autoconf//autoconf:defs.bzl
zz,
*
nameA unique name for this target. �
�
default_deps�`autoconf_defaults` targets whose values stand where no result of the name comes through `deps`
(a result overrides a default silently; two defaults of one name must agree).  The defaults the
`deps` carry are read as well.
*
CcAutoconfDefaultsInfo2[]�
�
defaults�Deprecated and ignored: defaults come through `deps` and `default_deps`; the autoconf toolchain
no longer carries any.  Accepted so existing BUILD files keep loading.2False�
�
deps�List of `autoconf` targets which provide check results. Results from all deps will be merged together, and duplicate define names will produce an error. If not provided, an empty results file will be created.*
CcAutoconfInfo2[]�
�
inlines�A mapping of strings to files for replace within the content of the given `template` attribute.

The exact string in the template is replaced with the content of the associated file.
Any `@VAR@` style placeholders in the inline file content will be replaced with their
corresponding define values (package info, check results, etc.) after insertion.	2{}_
]
modeHProcessing mode that determines what should be replaced within the file.2	"defines";
9
out.The output config file (typically `config.h`). �
�
substitutions�A mapping of exact strings to replacement values.

Each entry performs an exact text replacement in the template - the key
string is replaced with the value string. No special patterns or wrappers
are added.

Example:
```python
autoconf_hdr(
    name = "config",
    out = "config.h",
    template = "config.h.in",
    substitutions = {
        "@MY_VERSION@": "1.2.3",
        "@BUILD_TYPE@": "release",
        "PLACEHOLDER_TEXT": "actual_value",
    },
    deps = [":checks"],
)
```

This would replace the exact string `@MY_VERSION@` with `1.2.3`,
`@BUILD_TYPE@` with `release`, and `PLACEHOLDER_TEXT` with `actual_value`.
2{}�
�
template�Template file (`config.h.in`) to use as base for generating the header file. The template is used to format the output header, but does not generate any checks. �autoconf_linkopts�Resolve AC_SEARCH_LIBS / AC_SUBST results into linker flags.

Reads subst result JSON files from autoconf deps and produces a
linker response file. Returns CcInfo with the flags, so consumers
can simply add this target to their deps list.

On GCC/Clang the flags are delivered via a @response-file. On
MSVC/clang-cl a .c file with #pragma comment(lib, ...) directives
is compiled instead, since MSVC's link.exe does not support nested
response files.

Variables not found in the deps are silently ignored (they may
be provided by a different module or not needed on this platform).
"�
�
autoconf_linkopts�Resolve AC_SEARCH_LIBS / AC_SUBST results into linker flags.

Reads subst result JSON files from autoconf deps and produces a
linker response file. Returns CcInfo with the flags, so consumers
can simply add this target to their deps list.

On GCC/Clang the flags are delivered via a @response-file. On
MSVC/clang-cl a .c file with #pragma comment(lib, ...) directives
is compiled instead, since MSVC's link.exe does not support nested
response files.

Variables not found in the deps are silently ignored (they may
be provided by a different module or not needed on this platform).
*
nameA unique name for this target. �
default_deps�`autoconf_defaults` targets whose values stand where no result of the name comes through `deps`
(a result overrides a default silently; two defaults of one name must agree).  The defaults the
`deps` carry are read as well.
*
CcAutoconfDefaultsInfo2[]�
defaults�Deprecated and ignored: defaults come through `deps` and `default_deps`; the autoconf toolchain
no longer carries any.  Accepted so existing BUILD files keep loading.2FalseO
deps1List of autoconf targets providing check results. *
CcAutoconfInfo�
vars�List of AC_SUBST variable names to resolve (e.g., ["LIBPTHREAD", "FDATASYNC_LIB"]).
Each variable is looked up in the subst results from deps. Non-empty values
(like "-lpthread") are added to linkopts; empty values are skipped.
 ";
autoconf_linkopts&@@rules_cc_autoconf//autoconf:defs.bzl
��,
*
nameA unique name for this target. �
�
default_deps�`autoconf_defaults` targets whose values stand where no result of the name comes through `deps`
(a result overrides a default silently; two defaults of one name must agree).  The defaults the
`deps` carry are read as well.
*
CcAutoconfDefaultsInfo2[]�
�
defaults�Deprecated and ignored: defaults come through `deps` and `default_deps`; the autoconf toolchain
no longer carries any.  Accepted so existing BUILD files keep loading.2FalseQ
O
deps1List of autoconf targets providing check results. *
CcAutoconfInfo�
�
vars�List of AC_SUBST variable names to resolve (e.g., ["LIBPTHREAD", "FDATASYNC_LIB"]).
Each variable is looked up in the subst results from deps. Non-empty values
(like "-lpthread") are added to linkopts; empty values are skipped.
 �autoconf_package_info�A rule providing package metadata, equivalent to GNU autoconf's `AC_INIT`.

It emits the `PACKAGE_NAME`, `PACKAGE_VERSION`, `PACKAGE_STRING`, `PACKAGE_TARNAME`,
`PACKAGE_BUGREPORT`, and `PACKAGE_URL` defines, either from explicit attributes or
by parsing a `MODULE.bazel` file.

This rule is most useful when paired with the `autoconf` rule.

Example:

```python
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:autoconf_package_info.bzl", "autoconf_package_info")

autoconf_package_info(
    name = "package",
    module_bazel = "//:MODULE.bazel",
)

autoconf(
    name = "config_h",
    out = "config.h",
    checks = [
        # ...
    ],
    deps = [
        ":package",
    ],
)
```
"�
�
autoconf_package_info�A rule providing package metadata, equivalent to GNU autoconf's `AC_INIT`.

It emits the `PACKAGE_NAME`, `PACKAGE_VERSION`, `PACKAGE_STRING`, `PACKAGE_TARNAME`,
`PACKAGE_BUGREPORT`, and `PACKAGE_URL` defines, either from explicit attributes or
by parsing a `MODULE.bazel` file.

This rule is most useful when paired with the `autoconf` rule.

Example:

```python
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:autoconf_package_info.bzl", "autoconf_package_info")

autoconf_package_info(
    name = "package",
    module_bazel = "//:MODULE.bazel",
)

autoconf(
    name = "config_h",
    out = "config.h",
    checks = [
        # ...
    ],
    deps = [
        ":package",
    ],
)
```
*
nameA unique name for this target. a
aliasesPAdditional variables to define that are mirrored by the provided value variable.
2{}�
module_bazeluA `MODULE.bazel` file to parse module information from. Mutually exclusive with `package_name` and `package_version`.2Nonei
package_bugreportNThe package bug report email/URL. Used to populate `PACKAGE_BUGREPORT` define.2""{
package_nameeThe package name. Must be provided together with `package_version` if `module_bazel` is not provided.2""J
package_tarname1Exactly tarname, possibly generated from package.2""V
package_urlAThe package home page URL. Used to populate `PACKAGE_URL` define.2""~
package_versioneThe package version. Must be provided together with `package_name` if `module_bazel` is not provided.2""l
strip_bcr_versionNWhether or not to strip `.bcr.*` suffixes from `module_bazel` parsed versions.2False"?
autoconf_package_info&@@rules_cc_autoconf//autoconf:defs.bzl
��,
*
nameA unique name for this target. c
a
aliasesPAdditional variables to define that are mirrored by the provided value variable.
2{}�
�
module_bazeluA `MODULE.bazel` file to parse module information from. Mutually exclusive with `package_name` and `package_version`.2Nonek
i
package_bugreportNThe package bug report email/URL. Used to populate `PACKAGE_BUGREPORT` define.2""}
{
package_nameeThe package name. Must be provided together with `package_version` if `module_bazel` is not provided.2""L
J
package_tarname1Exactly tarname, possibly generated from package.2""X
V
package_urlAThe package home page URL. Used to populate `PACKAGE_URL` define.2""�
~
package_versioneThe package version. Must be provided together with `package_name` if `module_bazel` is not provided.2""n
l
strip_bcr_versionNWhether or not to strip `.bcr.*` suffixes from `module_bazel` parsed versions.2False�1autoconf_srcs�
Generate wrapper sources that are conditionally enabled by autoconf results.

Typical use case:

```python
load("@rules_cc_autoconf//autoconf:autoconf_srcs.bzl", "autoconf_srcs")
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")
load("@rules_cc//cc:cc_library.bzl", "cc_library")

autoconf(
    name = "config",
    out = "config.h",
    checks = [
        # Feature is present on this platform/toolchain.
        checks.AC_CHECK_HEADER("foo.h", define = "HAVE_FOO"),
    ],
)

autoconf_srcs(
    name = "foo_srcs",
    deps = [":config"],
    srcs = {
        "uses_foo.c": "HAVE_FOO",
    },
)

cc_library(
    name = "foo",
    srcs = [":foo_srcs"],
    hdrs = [":config.h"],
)
```

In this setup `autoconf_srcs` reads the results from `:config` (or multiple targets via `deps`) and generates a
wrapped copy of `uses_foo.c` whose contents are effectively:

```cc
#define HAVE_FOO 1      // when the check for HAVE_FOO succeeds
/* or: #undef HAVE_FOO  // when the check fails */
#ifdef HAVE_FOO
/* original uses_foo.c contents ... */
#endif
```

This is useful when you have platform-specific or optional sources that should
only be compiled when a particular autoconf check passes, without having to
manually maintain `#ifdef` guards in every source file.
"�'
�
autoconf_srcs�
Generate wrapper sources that are conditionally enabled by autoconf results.

Typical use case:

```python
load("@rules_cc_autoconf//autoconf:autoconf_srcs.bzl", "autoconf_srcs")
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")
load("@rules_cc//cc:cc_library.bzl", "cc_library")

autoconf(
    name = "config",
    out = "config.h",
    checks = [
        # Feature is present on this platform/toolchain.
        checks.AC_CHECK_HEADER("foo.h", define = "HAVE_FOO"),
    ],
)

autoconf_srcs(
    name = "foo_srcs",
    deps = [":config"],
    srcs = {
        "uses_foo.c": "HAVE_FOO",
    },
)

cc_library(
    name = "foo",
    srcs = [":foo_srcs"],
    hdrs = [":config.h"],
)
```

In this setup `autoconf_srcs` reads the results from `:config` (or multiple targets via `deps`) and generates a
wrapped copy of `uses_foo.c` whose contents are effectively:

```cc
#define HAVE_FOO 1      // when the check for HAVE_FOO succeeds
/* or: #undef HAVE_FOO  // when the check fails */
#ifdef HAVE_FOO
/* original uses_foo.c contents ... */
#endif
```

This is useful when you have platform-specific or optional sources that should
only be compiled when a particular autoconf check passes, without having to
manually maintain `#ifdef` guards in every source file.
*
nameA unique name for this target. �
default_deps�`autoconf_defaults` targets whose values stand where no result of the name comes through `deps`
(a result overrides a default silently; two defaults of one name must agree).  The defaults the
`deps` carry are read as well.
*
CcAutoconfDefaultsInfo2[]�
defaults�Deprecated and ignored: defaults come through `deps` and `default_deps`; the autoconf toolchain
no longer carries any.  Accepted so existing BUILD files keep loading.2False�
deps�List of `autoconf` targets which provide defines. Results from all deps will be merged together, and duplicate define names will produce an error. *
CcAutoconfInfo�
naming�How to name generated sources: `package_relative` keeps the original package-relative path, `ac_suffix`
inserts `.ac.` before the final suffix (e.g. `foo.cc -> foo.ac.cc`), and `per_target` prefixes outputs
with `{ctx.label.name}` to namespace them per rule.  Under `wrap = "include"` the output always carries the
`.ac` infix as well (`foo.c -> foo.ac.c`, `per_target`: `{ctx.label.name}/foo.ac.c`): a wrapper named like
a root-level source would resolve its own `#include "foo.c"` to itself.
2"package_relative"L
srcs@A mapping of source file to define required to compile the file.	 �
wrap�How a generated file stands for its source.  `copy` (the default) carries a copy of the source's contents.  `include` carries only `#include "<path of the source>"`, so the source's own quoted includes (`#include "sibling.h"`) still resolve in its directory and `__FILE__` and diagnostics name the source; the sources must then reach the compiler, which they do when the consumer lists this target in `deps` as well as `srcs` (the target provides them as headers of a `CcInfo`).2"copy""7
autoconf_srcs&@@rules_cc_autoconf//autoconf:defs.bzl
��,
*
nameA unique name for this target. �
�
default_deps�`autoconf_defaults` targets whose values stand where no result of the name comes through `deps`
(a result overrides a default silently; two defaults of one name must agree).  The defaults the
`deps` carry are read as well.
*
CcAutoconfDefaultsInfo2[]�
�
defaults�Deprecated and ignored: defaults come through `deps` and `default_deps`; the autoconf toolchain
no longer carries any.  Accepted so existing BUILD files keep loading.2False�
�
deps�List of `autoconf` targets which provide defines. Results from all deps will be merged together, and duplicate define names will produce an error. *
CcAutoconfInfo�
�
naming�How to name generated sources: `package_relative` keeps the original package-relative path, `ac_suffix`
inserts `.ac.` before the final suffix (e.g. `foo.cc -> foo.ac.cc`), and `per_target` prefixes outputs
with `{ctx.label.name}` to namespace them per rule.  Under `wrap = "include"` the output always carries the
`.ac` infix as well (`foo.c -> foo.ac.c`, `per_target`: `{ctx.label.name}/foo.ac.c`): a wrapper named like
a root-level source would resolve its own `#include "foo.c"` to itself.
2"package_relative"N
L
srcs@A mapping of source file to define required to compile the file.	 �
�
wrap�How a generated file stands for its source.  `copy` (the default) carries a copy of the source's contents.  `include` carries only `#include "<path of the source>"`, so the source's own quoted includes (`#include "sibling.h"`) still resolve in its directory and `__FILE__` and diagnostics name the source; the sources must then reach the compiler, which they do when the consumer lists this target in `deps` as well as `srcs` (the target provides them as headers of a `CcInfo`).2"copy"�<autoconf_toolchain�Define an autoconf toolchain that shares check results across targets.

The toolchain carries one thing: the **content cache** of its `cache_deps`.
When an `autoconf` target lists a check whose implementation already has a
result there, the checker action is skipped and the existing result file is
reused.  Nothing else crosses the toolchain boundary: not the results as
defines or substs, and not defaults.  Defaults are `autoconf_defaults`
targets that a target reads through its own `default_deps` (see
`autoconf_defaults`); the toolchain neither carries nor injects any.

Targets listed in `cache_deps` must use `autoconf_cache` (not `autoconf`)
to avoid a dependency cycle.

Example:

```python
load("@rules_cc_autoconf//autoconf:defs.bzl", "autoconf_cache", "autoconf_toolchain")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")

autoconf_cache(
    name = "common_checks",
    checks = [
        checks.AC_CHECK_HEADER("stdio.h"),
        checks.AC_CHECK_FUNC("strerror"),
    ],
)

autoconf_toolchain(
    name = "my_toolchain_impl",
    cache_deps = [":common_checks"],
)

toolchain(
    name = "my_toolchain",
    toolchain = ":my_toolchain_impl",
    toolchain_type = "@rules_cc_autoconf//autoconf:toolchain_type",
)
```

## Caching behavior

### Content-key deduplication

Every check is fingerprinted by a **content key** derived from its
implementation fields: `type`, `code`, `language`, `define_value`,
`includes`, `libraries`, `requires`, `condition`, `compile_defines`,
and similar. Consumer metadata (`name`, `define`, `subst`, `unquote`)
is **excluded**, so two checks with different consumer names but
identical implementations share one content key and produce a single
checker action and result file.

When a new check is processed, its content key is looked up in order:

1. Transitive deps' `content_cache`
2. Toolchain content cache (`cache_deps`)
3. Current target's local `content_cache`

If a hit is found at any level the existing result file is reused and
no new checker action is declared. Identical checks within the same
target are idempotent (silently skipped on second occurrence).

### Conflict detection

Three layers, from strictest to most relaxed:

- **Within one target** -- duplicate `define` or `subst` symbol names
  in the same `checks` list always fail, even if the content keys
  match. This prevents accidental duplication in a single target.
- **Local vs dependencies / deps vs deps** -- the same symbol
  appearing with a **different result file** is an error, **unless**
  both files share the same content key (a benign duplicate from
  identical implementations).
- **Cache variable names** (`cache_results`) have no cross-dep
  conflict detection; content-based dedup is the identity signal.

`cache_deps` on the toolchain itself is intentionally exempt from
define/subst conflict detection: it contributes only to the content
cache and is meant to absorb broad sweeps of cache providers (e.g.,
every gnulib m4 module) that legitimately publish overlapping symbols
from different files. Per-target `deps` still enforce conflicts.

### Resolving conflicts

The typical fix for *"Define 'X' is defined both locally and in
dependencies with different result files"*:

- Remove the local check and depend on the target that already
  provides it.
- Or factor the shared check into its own `autoconf` /
  `autoconf_cache` target and depend on it from both consumers.
"�!
�
autoconf_toolchain�Define an autoconf toolchain that shares check results across targets.

The toolchain carries one thing: the **content cache** of its `cache_deps`.
When an `autoconf` target lists a check whose implementation already has a
result there, the checker action is skipped and the existing result file is
reused.  Nothing else crosses the toolchain boundary: not the results as
defines or substs, and not defaults.  Defaults are `autoconf_defaults`
targets that a target reads through its own `default_deps` (see
`autoconf_defaults`); the toolchain neither carries nor injects any.

Targets listed in `cache_deps` must use `autoconf_cache` (not `autoconf`)
to avoid a dependency cycle.

Example:

```python
load("@rules_cc_autoconf//autoconf:defs.bzl", "autoconf_cache", "autoconf_toolchain")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")

autoconf_cache(
    name = "common_checks",
    checks = [
        checks.AC_CHECK_HEADER("stdio.h"),
        checks.AC_CHECK_FUNC("strerror"),
    ],
)

autoconf_toolchain(
    name = "my_toolchain_impl",
    cache_deps = [":common_checks"],
)

toolchain(
    name = "my_toolchain",
    toolchain = ":my_toolchain_impl",
    toolchain_type = "@rules_cc_autoconf//autoconf:toolchain_type",
)
```

## Caching behavior

### Content-key deduplication

Every check is fingerprinted by a **content key** derived from its
implementation fields: `type`, `code`, `language`, `define_value`,
`includes`, `libraries`, `requires`, `condition`, `compile_defines`,
and similar. Consumer metadata (`name`, `define`, `subst`, `unquote`)
is **excluded**, so two checks with different consumer names but
identical implementations share one content key and produce a single
checker action and result file.

When a new check is processed, its content key is looked up in order:

1. Transitive deps' `content_cache`
2. Toolchain content cache (`cache_deps`)
3. Current target's local `content_cache`

If a hit is found at any level the existing result file is reused and
no new checker action is declared. Identical checks within the same
target are idempotent (silently skipped on second occurrence).

### Conflict detection

Three layers, from strictest to most relaxed:

- **Within one target** -- duplicate `define` or `subst` symbol names
  in the same `checks` list always fail, even if the content keys
  match. This prevents accidental duplication in a single target.
- **Local vs dependencies / deps vs deps** -- the same symbol
  appearing with a **different result file** is an error, **unless**
  both files share the same content key (a benign duplicate from
  identical implementations).
- **Cache variable names** (`cache_results`) have no cross-dep
  conflict detection; content-based dedup is the identity signal.

`cache_deps` on the toolchain itself is intentionally exempt from
define/subst conflict detection: it contributes only to the content
cache and is meant to absorb broad sweeps of cache providers (e.g.,
every gnulib m4 module) that legitimately publish overlapping symbols
from different files. Per-target `deps` still enforce conflicts.

### Resolving conflicts

The typical fix for *"Define 'X' is defined both locally and in
dependencies with different result files"*:

- Remove the local check and depend on the target that already
  provides it.
- Or factor the shared check into its own `autoconf` /
  `autoconf_cache` target and depend on it from both consumers.
*
nameA unique name for this target. �

cache_deps�Targets whose check results are available for action deduplication in `autoconf` targets. Only the content cache is exposed downstream; define/subst conflicts among these targets are NOT detected, so a broad sweep of cache providers with overlapping symbols (e.g., every gnulib m4 module) can be passed safely.*
CcAutoconfInfo2[]"<
autoconf_toolchain&@@rules_cc_autoconf//autoconf:defs.bzl
!!,
*
nameA unique name for this target. �
�

cache_deps�Targets whose check results are available for action deduplication in `autoconf` targets. Only the content cache is exposed downstream; define/subst conflicts among these targets are NOT detected, so a broad sweep of cache providers with overlapping symbols (e.g., every gnulib m4 module) can be passed safely.*
CcAutoconfInfo2[]�autoconf�Run autoconf-like checks and produce results.

This rule resolves the `autoconf_toolchain` (when registered) to skip redundant
checker actions. If a check's cache variable name already has a result in the
toolchain or in transitive `deps`, the existing result file is reused.

Use `autoconf_cache` instead for targets that feed into `autoconf_toolchain`
to avoid a dependency cycle.

Example:

```python
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")

autoconf(
    name = "config",
    checks = [
        checks.AC_CHECK_HEADER("stdio.h"),
        checks.AC_CHECK_HEADER("stdlib.h"),
        checks.AC_CHECK_FUNC("printf"),
    ],
)
```

The results can then be used by `autoconf_hdr` or `autoconf_srcs` to generate
headers or wrapped source files.
*�
�
autoconf*
nameA unique name for this target. (�
build_settings�List of `checks.AC_BUILD_SETTING(...)` entries
associating Bazel build setting targets (any rule providing
`BuildSettingInfo`) with autoconf-style defines and substitutions.None(h
checksVList of JSON-encoded checks from `checks`
(e.g., `checks.AC_CHECK_HEADER('stdio.h')`).None(a
depsQAdditional `autoconf`, `autoconf_cache`, or `autoconf_package_info`
dependencies.None(�
kwargs�Standard Bazel attributes (e.g. `visibility`, `tags`) and the
rule's other attributes: `cc_deps` (libraries the checks compile
against and link, as configure's CPPFLAGS and LIBS carry them),
`default_deps`, `copts`, `conlyopts`, `cxxopts`.(�Run autoconf-like checks and produce results.

This rule resolves the `autoconf_toolchain` (when registered) to skip redundant
checker actions. If a check's cache variable name already has a result in the
toolchain or in transitive `deps`, the existing result file is reused.

Use `autoconf_cache` instead for targets that feed into `autoconf_toolchain`
to avoid a dependency cycle.

Example:

```python
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")

autoconf(
    name = "config",
    checks = [
        checks.AC_CHECK_HEADER("stdio.h"),
        checks.AC_CHECK_HEADER("stdlib.h"),
        checks.AC_CHECK_FUNC("printf"),
    ],
)
```

The results can then be used by `autoconf_hdr` or `autoconf_srcs` to generate
headers or wrapped source files.
26
autoconf*@@rules_cc_autoconf//autoconf:autoconf.bzl
		*_autoconf_rule2_autoconf_rule}
//autoconf:autoconf.bzlr`
+
rules_cc_autoconfautoconfautoconf.bzl#
autoconf	_autoconf

�
 //autoconf:autoconf_defaults.bzlr{
4
rules_cc_autoconfautoconfautoconf_defaults.bzl5
autoconf_defaults_autoconf_defaults



�
//autoconf:autoconf_hdr.bzlrl
/
rules_cc_autoconfautoconfautoconf_hdr.bzl+
autoconf_hdr_autoconf_hdr

�
 //autoconf:autoconf_linkopts.bzlr{
4
rules_cc_autoconfautoconfautoconf_linkopts.bzl5
autoconf_linkopts_autoconf_linkopts

�
$//autoconf:autoconf_package_info.bzlr�
8
rules_cc_autoconfautoconfautoconf_package_info.bzl=
autoconf_package_info_autoconf_package_info

�
//autoconf:autoconf_srcs.bzlro
0
rules_cc_autoconfautoconfautoconf_srcs.bzl-
autoconf_srcs_autoconf_srcs

�
!//autoconf:autoconf_toolchain.bzlr~
5
rules_cc_autoconfautoconfautoconf_toolchain.bzl7
autoconf_toolchain_autoconf_toolchain

�
//autoconf:checks.bzlr{
)
rules_cc_autoconfautoconf
checks.bzl
checks_checks
""
macros_macros
##
 $# rules_cc_autoconf
�
/
rules_cc_autoconfautoconfpackage_info.bzl�package_info�A rule providing package metadata, equivalent to GNU autoconf's `AC_INIT`.

It emits the `PACKAGE_NAME`, `PACKAGE_VERSION`, `PACKAGE_STRING`, `PACKAGE_TARNAME`,
`PACKAGE_BUGREPORT`, and `PACKAGE_URL` defines, either from explicit attributes or
by parsing a `MODULE.bazel` file.

This rule is most useful when paired with the `autoconf` rule.

Example:

```python
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:autoconf_package_info.bzl", "autoconf_package_info")

autoconf_package_info(
    name = "package",
    module_bazel = "//:MODULE.bazel",
)

autoconf(
    name = "config_h",
    out = "config.h",
    checks = [
        # ...
    ],
    deps = [
        ":package",
    ],
)
```
"�
�
package_info�A rule providing package metadata, equivalent to GNU autoconf's `AC_INIT`.

It emits the `PACKAGE_NAME`, `PACKAGE_VERSION`, `PACKAGE_STRING`, `PACKAGE_TARNAME`,
`PACKAGE_BUGREPORT`, and `PACKAGE_URL` defines, either from explicit attributes or
by parsing a `MODULE.bazel` file.

This rule is most useful when paired with the `autoconf` rule.

Example:

```python
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:autoconf_package_info.bzl", "autoconf_package_info")

autoconf_package_info(
    name = "package",
    module_bazel = "//:MODULE.bazel",
)

autoconf(
    name = "config_h",
    out = "config.h",
    checks = [
        # ...
    ],
    deps = [
        ":package",
    ],
)
```
*
nameA unique name for this target. a
aliasesPAdditional variables to define that are mirrored by the provided value variable.
2{}�
module_bazeluA `MODULE.bazel` file to parse module information from. Mutually exclusive with `package_name` and `package_version`.2Nonei
package_bugreportNThe package bug report email/URL. Used to populate `PACKAGE_BUGREPORT` define.2""{
package_nameeThe package name. Must be provided together with `package_version` if `module_bazel` is not provided.2""J
package_tarname1Exactly tarname, possibly generated from package.2""V
package_urlAThe package home page URL. Used to populate `PACKAGE_URL` define.2""~
package_versioneThe package version. Must be provided together with `package_name` if `module_bazel` is not provided.2""l
strip_bcr_versionNWhether or not to strip `.bcr.*` suffixes from `module_bazel` parsed versions.2False">
package_info.@@rules_cc_autoconf//autoconf:package_info.bzl
��,
*
nameA unique name for this target. c
a
aliasesPAdditional variables to define that are mirrored by the provided value variable.
2{}�
�
module_bazeluA `MODULE.bazel` file to parse module information from. Mutually exclusive with `package_name` and `package_version`.2Nonek
i
package_bugreportNThe package bug report email/URL. Used to populate `PACKAGE_BUGREPORT` define.2""}
{
package_nameeThe package name. Must be provided together with `package_version` if `module_bazel` is not provided.2""L
J
package_tarname1Exactly tarname, possibly generated from package.2""X
V
package_urlAThe package home page URL. Used to populate `PACKAGE_URL` define.2""�
~
package_versioneThe package version. Must be provided together with `package_name` if `module_bazel` is not provided.2""n
l
strip_bcr_versionNWhether or not to strip `.bcr.*` suffixes from `module_bazel` parsed versions.2False�
$//autoconf:autoconf_package_info.bzlr�
8
rules_cc_autoconfautoconfautoconf_package_info.bzl=
autoconf_package_info_autoconf_package_info
@V
q�# package_info

Deprecated: `package_info` has been renamed to `autoconf_package_info`. Load it from
`@rules_cc_autoconf//autoconf:autoconf_package_info.bzl` instead. This file remains as a
compatibility alias and will be removed in a future release.
�
5
rules_cc_autoconfgnulib/m4/inttypesinttypes.bzl�long_long_condition�gl_INTTYPES_CHECK_LONG_LONG_INT_CONDITION(NAME, COND, EXPR, FALLBACK).

Compiles upstream's probe and substitutes NAME with 1 or 0.
*�
�
long_long_conditionD
name8the AC_SUBST variable, also used for the cache variable. (D
cond8preprocessor condition selecting `expr` over `fallback`. (4
expr(the expression tested when `cond` holds. (0
fallback the expression tested otherwise. (�gl_INTTYPES_CHECK_LONG_LONG_INT_CONDITION(NAME, COND, EXPR, FALLBACK).

Compiles upstream's probe and substitutes NAME with 1 or 0.
"7
5list: two checks (an AC_TRY_COMPILE and an AC_SUBST).2K
long_long_condition4@@rules_cc_autoconf//gnulib/m4/inttypes:inttypes.bzl
t
//autoconf:checks.bzlrY
)
rules_cc_autoconfautoconf
checks.bzl
checkschecks
28
:Helpers for the inttypes port.�

6
rules_cc_autoconfgnulib/privateresult_lookup.bzl�find_result_file�Look up a check result name across cache/define/subst namespaces.

Returns the result `File`, or fails with a clear error if not found or
ambiguous. When the same result is exposed under multiple buckets that
refer to the same underlying file (same path), the lookup succeeds; only
distinct paths trigger the ambiguity error.
*�
�
find_result_fileQ
nameEThe result name to look up (e.g. `"HAVE_FOO"` or
`"ac_cv_func_foo"`). (8
	all_cache'Mapping of cache name -> result `File`. (:

all_define(Mapping of define name -> result `File`. (8
	all_subst'Mapping of subst name -> result `File`. (6
label)The rule's label, used in error messages. (�Look up a check result name across cache/define/subst namespaces.

Returns the result `File`, or fails with a clear error if not found or
ambiguous. When the same result is exposed under multiple buckets that
refer to the same underlying file (same path), the lookup succeeds; only
distinct paths trigger the ambiguity error.
"
The matched result `File`.2I
find_result_file5@@rules_cc_autoconf//gnulib/private:result_lookup.bzl
�Shared helper for looking up an autoconf check result by name across the
cache / define / subst buckets exposed by `CcAutoconfInfo`.�
+
rules_cc_autoconfgnulib/testsdeps.bzl�gnulib+rules_cc_autoconf gnulib test dependencies.J{
k
gnulib+rules_cc_autoconf gnulib test dependencies."4
gnulib*@@rules_cc_autoconf//gnulib/tests:deps.bzl
00�
 //tools/build_defs/repo:http.bzlrj
.
bazel_toolstools/build_defs/repohttp.bzl*
http_archivehttp_archive
7C
EGnulib test deps�
A
rules_cc_autoconfgnulib/testsgnu_gnulib_diff_test_suite.bzl�gnu_gnulib_diff_test_suite�Complete test suite for a gnulib module.

This creates:
1. `{name}_gnu_conformance`: runs GNU aclocal/autoconf/configure with the
   Bazel C++ toolchain's compiler and flags and requires the
   Bazel-generated headers to match byte for byte. The GNU and Bazel
   headers, config.log, tool output and environment are left in the
   test's undeclared outputs directory for review. There are no
   checked-in expected outputs; GNU autoconf produces them on the machine
   running the test.
2. `{name}_compile`: the Bazel-generated headers compile with `test_c`.
3. `{name}`: a test suite of the above.
*�
�
gnu_gnulib_diff_test_suite>
name2Name of the test suite (typically "{module}_test") (D
configure_ac0The configure.ac file specific to this m4 module (D
m4_files4ALL m4 files needed to run autoconf (including deps) (;
config_h_in(Template for AC_DEFINE (#undef patterns) (8

subst_h_in&Template for AC_SUBST (@FOO@ patterns) (H
bazel_autoconf_target+The autoconf target from //gnulib/m4/{name} (:
test_c,C file to compile with the generated headers (V
	aux_filesCAuxiliary files (e.g., config.rpath) to copy to work directory root[](�
known_divergences�Variable name -> reason for intentional
differences between the Bazel port and upstream m4. Masked in the
GNU comparison and always reported in the test log.{}(1
sizeTest size (default: "medium")"medium"(
tags	Test tags[]( 
kwargsAdditional arguments(�Complete test suite for a gnulib module.

This creates:
1. `{name}_gnu_conformance`: runs GNU aclocal/autoconf/configure with the
   Bazel C++ toolchain's compiler and flags and requires the
   Bazel-generated headers to match byte for byte. The GNU and Bazel
   headers, config.log, tool output and environment are left in the
   test's undeclared outputs directory for review. There are no
   checked-in expected outputs; GNU autoconf produces them on the machine
   running the test.
2. `{name}_compile`: the Bazel-generated headers compile with `test_c`.
3. `{name}`: a test suite of the above.
2^
gnu_gnulib_diff_test_suite@@@rules_cc_autoconf//gnulib/tests:gnu_gnulib_diff_test_suite.bzl
"autoconf_hdr*native.test_suite2autoconf_hdr2autoconf_hdr2gnu_autoconf_conformance_test2cc_test2native.test_suitec
//cc:cc_test.bzlrM

rules_cccccc_test.bzl 
cc_testcc_test
$+
-�
//autoconf:autoconf_hdr.bzlrk
/
rules_cc_autoconfautoconfautoconf_hdr.bzl*
autoconf_hdrautoconf_hdr
8D
F�
$//autoconf/tests/gnu:conformance.bzlr�
8
rules_cc_autoconfautoconf/tests/gnuconformance.bzlL
gnu_autoconf_conformance_testgnu_autoconf_conformance_test
	A	^
		`�Macros for testing gnulib m4 ports against GNU autoconf.

This module provides:
- gnu_gnulib_diff_test_suite: Complete test suite for a gnulib module
�R
1
rules_cc_autoconfgnulibconditional_hdrs.bzl�Gcc_gnulib_conditional_hdrs�Gate gnulib replacement headers on per-header autoconf conditions, mirroring
upstream gnulib's ``GL_GENERATE_*_H`` / ``rm -f $@`` pattern.

For each truthy entry in ``hdrs`` the file is written into the rule's
TreeArtifact output directory under its slot name (see ``preserve_paths``
below); for each falsy entry no file is written, so consumer ``#include``s
of that basename fall through the rest of the include search path to
whatever comes next (typically the system header).

The rule returns ``CcInfo`` exposing the TreeArtifact directory as a
single include root â drop the rule into a ``cc_library``'s ``deps`` and
consumers can ``#include`` directly:

```python
load("@rules_cc_autoconf//gnulib:conditional_hdrs.bzl", "cc_gnulib_conditional_hdrs")

cc_gnulib_conditional_hdrs(
    name = "gnu_replacements",
    hdrs = {
        ":alloca_h_processed":       "GL_GENERATE_ALLOCA_H",
        ":obstack_h_processed":      "GL_GENERATE_OBSTACK_H",
        ":getopt_cdefs_h_processed": "GL_GENERATE_GETOPT_CDEFS_H",
    },
    deps = [":autoconf"],
)

cc_library(
    name = "consumer",
    srcs = ["uses_alloca.c"],
    deps = [":gnu_replacements"],
)
```

The falsy branch emits no file, true to upstream's ``rm -f $@``: any
``#include_next`` chain a ``.in.h`` template needs is baked into the header
by the upstream ``autoconf_hdr`` substitution, so this rule never emits
``#include_next`` itself and has no MSVC gap.

Headers in subdirectories (``selinux/context.h``) are gated through
``strip_include_prefix``: declare them under one directory and strip it, as
``cc_library`` does.

```python
cc_gnulib_conditional_hdrs(
    name = "gnu_replacements",
    hdrs = {
        ":_gnulib_cond/selinux/context.h": "GL_GENERATE_SELINUX_CONTEXT_H",
    },
    strip_include_prefix = "_gnulib_cond",
    deps = [":autoconf"],
)
```

Limitations:

  - *Header-name collisions.* The TreeArtifact directory is added to the
    include path.  Any consumer with a same-named header in an earlier
    include dir will shadow the replacement.
  - *TreeArtifact semantics.* Bazel cannot statically know which slot
    names will be present (truthy is a configure-time decision).  This
    is intentional and matches upstream behavior.
  - *``preserve_paths`` shadowing on non-sandboxed builds (Windows).* With
    the deprecated ``preserve_paths = True`` the TreeArtifact contents path
    equals the upstream ``autoconf_hdr`` ``out`` path verbatim, and on a
    non-sandboxed build a ``cc_library(includes = ["."])`` elsewhere in the
    graph may resolve an ``#include`` to the un-gated intermediate.
    ``strip_include_prefix`` is immune: the stripped directory never
    coincides with the slot.
"�2
�#
cc_gnulib_conditional_hdrs�Gate gnulib replacement headers on per-header autoconf conditions, mirroring
upstream gnulib's ``GL_GENERATE_*_H`` / ``rm -f $@`` pattern.

For each truthy entry in ``hdrs`` the file is written into the rule's
TreeArtifact output directory under its slot name (see ``preserve_paths``
below); for each falsy entry no file is written, so consumer ``#include``s
of that basename fall through the rest of the include search path to
whatever comes next (typically the system header).

The rule returns ``CcInfo`` exposing the TreeArtifact directory as a
single include root â drop the rule into a ``cc_library``'s ``deps`` and
consumers can ``#include`` directly:

```python
load("@rules_cc_autoconf//gnulib:conditional_hdrs.bzl", "cc_gnulib_conditional_hdrs")

cc_gnulib_conditional_hdrs(
    name = "gnu_replacements",
    hdrs = {
        ":alloca_h_processed":       "GL_GENERATE_ALLOCA_H",
        ":obstack_h_processed":      "GL_GENERATE_OBSTACK_H",
        ":getopt_cdefs_h_processed": "GL_GENERATE_GETOPT_CDEFS_H",
    },
    deps = [":autoconf"],
)

cc_library(
    name = "consumer",
    srcs = ["uses_alloca.c"],
    deps = [":gnu_replacements"],
)
```

The falsy branch emits no file, true to upstream's ``rm -f $@``: any
``#include_next`` chain a ``.in.h`` template needs is baked into the header
by the upstream ``autoconf_hdr`` substitution, so this rule never emits
``#include_next`` itself and has no MSVC gap.

Headers in subdirectories (``selinux/context.h``) are gated through
``strip_include_prefix``: declare them under one directory and strip it, as
``cc_library`` does.

```python
cc_gnulib_conditional_hdrs(
    name = "gnu_replacements",
    hdrs = {
        ":_gnulib_cond/selinux/context.h": "GL_GENERATE_SELINUX_CONTEXT_H",
    },
    strip_include_prefix = "_gnulib_cond",
    deps = [":autoconf"],
)
```

Limitations:

  - *Header-name collisions.* The TreeArtifact directory is added to the
    include path.  Any consumer with a same-named header in an earlier
    include dir will shadow the replacement.
  - *TreeArtifact semantics.* Bazel cannot statically know which slot
    names will be present (truthy is a configure-time decision).  This
    is intentional and matches upstream behavior.
  - *``preserve_paths`` shadowing on non-sandboxed builds (Windows).* With
    the deprecated ``preserve_paths = True`` the TreeArtifact contents path
    equals the upstream ``autoconf_hdr`` ``out`` path verbatim, and on a
    non-sandboxed build a ``cc_library(includes = ["."])`` elsewhere in the
    graph may resolve an ``#include`` to the un-gated intermediate.
    ``strip_include_prefix`` is immune: the stripped directory never
    coincides with the slot.
*
nameA unique name for this target. �
default_deps�`autoconf_defaults` targets whose values stand where no result of the name comes through `deps`
(a result overrides a default silently; two defaults of one name must agree).  The defaults the
`deps` carry are read as well.
*
CcAutoconfDefaultsInfo2[]�
defaults�Deprecated and ignored: defaults come through `deps` and `default_deps`; the autoconf toolchain
no longer carries any.  Accepted so existing BUILD files keep loading.2False�
deps�Autoconf targets providing check results.  The condition expressions in
``hdrs`` are resolved against the merged results from all deps. *
CcAutoconfInfo�
hdrs�Mapping of header file label to a condition expression (same syntax as
``autoconf_srcs``: single var, ``!var``, ``HAVE_X==1``, ``A && !B``â¦).
When the condition holds the header is written into the TreeArtifact at
its slot name; when it does not hold nothing is written for that header
and consumer ``#include``s fall through the include search path.	 O
outBThe name of the output directory. If unset, `{name}` will be used.2""�
preserve_paths�Deprecated: use ``strip_include_prefix``.  If ``True``, each header is placed
at its path relative to the rule's package (``_gnulib/foo.h``), so consumers
``#include <_gnulib/foo.h>``; headers from other packages use their basename.
Mutually exclusive with ``strip_include_prefix``.2False�
strip_include_prefix�A directory of this package to strip from each header's package-relative
path to get its slot, as ``cc_library`` does: with ``_gnulib_cond`` the
header ``_gnulib_cond/selinux/context.h`` is included as
``<selinux/context.h>``.  Every header in ``hdrs`` must be under it.  Unset,
each header is placed at its basename.2"""N
cc_gnulib_conditional_hdrs0@@rules_cc_autoconf//gnulib:conditional_hdrs.bzl
�"�",
*
nameA unique name for this target. �
�
default_deps�`autoconf_defaults` targets whose values stand where no result of the name comes through `deps`
(a result overrides a default silently; two defaults of one name must agree).  The defaults the
`deps` carry are read as well.
*
CcAutoconfDefaultsInfo2[]�
�
defaults�Deprecated and ignored: defaults come through `deps` and `default_deps`; the autoconf toolchain
no longer carries any.  Accepted so existing BUILD files keep loading.2False�
�
deps�Autoconf targets providing check results.  The condition expressions in
``hdrs`` are resolved against the merged results from all deps. *
CcAutoconfInfo�
�
hdrs�Mapping of header file label to a condition expression (same syntax as
``autoconf_srcs``: single var, ``!var``, ``HAVE_X==1``, ``A && !B``â¦).
When the condition holds the header is written into the TreeArtifact at
its slot name; when it does not hold nothing is written for that header
and consumer ``#include``s fall through the include search path.	 Q
O
outBThe name of the output directory. If unset, `{name}` will be used.2""�
�
preserve_paths�Deprecated: use ``strip_include_prefix``.  If ``True``, each header is placed
at its path relative to the rule's package (``_gnulib/foo.h``), so consumers
``#include <_gnulib/foo.h>``; headers from other packages use their basename.
Mutually exclusive with ``strip_include_prefix``.2False�
�
strip_include_prefix�A directory of this package to strip from each header's package-relative
path to get its slot, as ``cc_library`` does: with ``_gnulib_cond`` the
header ``_gnulib_cond/selinux/context.h`` is included as
``<selinux/context.h>``.  Every header in ``hdrs`` must be under it.  Unset,
each header is placed at its basename.2""q
:features.bzlr^

bazel_featuresfeatures.bzl.
bazel_featuresbazel_features
)7
9y
//cc/common:cc_common.bzlrZ
$
rules_cc	cc/commoncc_common.bzl$
	cc_common	cc_common
-6
8o
//cc/common:cc_info.bzlrR
"
rules_cc	cc/commoncc_info.bzl
CcInfoCcInfo
+1
3�
&//autoconf/private:autoconf_config.bzlr�
:
rules_cc_autoconfautoconf/privateautoconf_config.bzl2
collect_defaultscollect_defaults


*
collect_depscollect_deps
F
collect_transitive_resultscollect_transitive_results
 .
merge_defaultsmerge_defaults
,
merge_resultsmerge_results

�
&//autoconf/private:condition_utils.bzlr�
:
rules_cc_autoconfautoconf/privatecondition_utils.bzl>
extract_condition_varsextract_condition_vars
CY
[�
 //autoconf/private:providers.bzlr�
4
rules_cc_autoconfautoconf/privateproviders.bzl>
CcAutoconfDefaultsInfoCcAutoconfDefaultsInfo
=S.
CcAutoconfInfoCcAutoconfInfo
We
g�
"//gnulib/private:result_lookup.bzlrz
6
rules_cc_autoconfgnulib/privateresult_lookup.bzl2
find_result_filefind_result_file
?O
Q# cc_gnulib_conditional_hdrs��
'
rules_cc_autoconfgnulib
macros.bzl�
checks.GL_NEXT_HEADER�Resolve NEXT_*_H for a header, inlining system header content when #include_next is unavailable.

On GCC/Clang: the checker returns `<header>` (normal angle-bracket include).
On MSVC: the checker runs the preprocessor to find the system header,
reads its content, and returns it prefixed with a newline so that the
template line `# @INCLUDE_NEXT@ @NEXT_*@` becomes a null directive
followed by the inlined system header content.
*�
�
checks.GL_NEXT_HEADER-
headerHeader name (e.g., "stddef.h"). (u
nameeOverride for the substitution variable name. Defaults to
NEXT_<HEADER_UPPER> (e.g., "NEXT_STDDEF_H").None(Z
requiresFOptional conditions that must hold before resolving the
system header.None(�Resolve NEXT_*_H for a header, inlining system header content when #include_next is unavailable.

On GCC/Clang: the checker returns `<header>` (normal angle-bracket include).
On MSVC: the checker runs the preprocessor to find the system header,
reads its content, and returns it prefixed with a newline so that the
template line `# @INCLUDE_NEXT@ @NEXT_*@` becomes a null directive
followed by the inlined system header content.
"=
;A JSON-encoded check string for use with the autoconf rule.29
_gl_next_header&@@rules_cc_autoconf//gnulib:macros.bzl
qq�macros.AC_LIB_HAVE_LINKFLAGS�Emulate AC_LIB_HAVE_LINKFLAGS from lib-link.m4 (link test + HAVE_LIB_* / LIB_* / LTLIB_*).

Gnulib's AC_LIB_HAVE_LINKFLAGS(name, dependencies, includes, testcode) finds library
flags via AC_LIB_LINKFLAGS_BODY, runs AC_LINK_IFELSE, and on success sets HAVE_LIB<NAME>=yes,
AC_SUBSTs LIB<NAME>, LTLIB<NAME>, LIB<NAME>_PREFIX, and #defines HAVE_LIB<NAME>. In Bazel we
run a single AC_TRY_LINK with the given includes and test_code; the target's deps must
provide the library. On success we AC_DEFINE HAVE_LIB_<NAME> and AC_SUBST the variables
with the values you pass.

Upstream:
<https://github.com/coreutils/gnulib/blob/a8482ceecf8f51571e773475a0efa9af7bb616e2/m4/lib-link.m4#L13-L19>

Original m4 example:
```m4
AC_LIB_HAVE_LINKFLAGS([intl], [], [[#include <libintl.h>]], [gettext(""); return 0;])
```

Example:
```python
load("@rules_cc_autoconf//gnulib:macros.bzl", gl_macros = "macros")
checks = gl_macros.AC_LIB_HAVE_LINKFLAGS(
    lib_name = "intl",
    includes = ["#include <libintl.h>"],
    test_code = "gettext(""); return 0;",
    lib_value = "-lintl",
)
```

For a single symbol, prefer `checks.AC_CHECK_LIB`.
*�
�
macros.AC_LIB_HAVE_LINKFLAGS4
lib_name$Library name (e.g. "intl", "iconv"). (]
includesMList of include directives for the link test (e.g. ["#include <libintl.h>"]). (R
	test_codeABody of main() for the link test (e.g. "gettext(""); return 0;"). (K
	lib_value8Value for LIB_<NAME> when link succeeds (e.g. "-lintl").""(?
ltlib_value*Value for LTLIB_<NAME> when link succeeds.""(I
lib_prefix_value/Value for LIB_<NAME>_PREFIX when link succeeds.""(�Emulate AC_LIB_HAVE_LINKFLAGS from lib-link.m4 (link test + HAVE_LIB_* / LIB_* / LTLIB_*).

Gnulib's AC_LIB_HAVE_LINKFLAGS(name, dependencies, includes, testcode) finds library
flags via AC_LIB_LINKFLAGS_BODY, runs AC_LINK_IFELSE, and on success sets HAVE_LIB<NAME>=yes,
AC_SUBSTs LIB<NAME>, LTLIB<NAME>, LIB<NAME>_PREFIX, and #defines HAVE_LIB<NAME>. In Bazel we
run a single AC_TRY_LINK with the given includes and test_code; the target's deps must
provide the library. On success we AC_DEFINE HAVE_LIB_<NAME> and AC_SUBST the variables
with the values you pass.

Upstream:
<https://github.com/coreutils/gnulib/blob/a8482ceecf8f51571e773475a0efa9af7bb616e2/m4/lib-link.m4#L13-L19>

Original m4 example:
```m4
AC_LIB_HAVE_LINKFLAGS([intl], [], [[#include <libintl.h>]], [gettext(""); return 0;])
```

Example:
```python
load("@rules_cc_autoconf//gnulib:macros.bzl", gl_macros = "macros")
checks = gl_macros.AC_LIB_HAVE_LINKFLAGS(
    lib_name = "intl",
    includes = ["#include <libintl.h>"],
    test_code = "gettext(""); return 0;",
    lib_value = "-lintl",
)
```

For a single symbol, prefer `checks.AC_CHECK_LIB`.
"C
AList of JSON-encoded check strings (one link check + four subst).2@
_ac_lib_have_linkflags&@@rules_cc_autoconf//gnulib:macros.bzl
���macros.GL_CHECK_FUNCS_ANDROID�
gl_CHECK_FUNCS_ANDROID / gl_CHECK_FUNCS_MACOS / gl_CHECK_FUNCS_ANDROID_MACOS.

For each function: AC_CHECK_FUNC, AC_DEFINE(HAVE_<FUNCTION>) when it links, and
AC_SUBST(HAVE_<FUNCTION>, 1 or 0) always.  That is what the upstream macros do on
every system but two: on Android they also check the declaration with `includes`
(a function may be in libc but undeclared for the target API level), and on macOS
they consult the deployment target ("future").  Neither applies to the platforms
the rules target, so the three macros are one here: `includes` is accepted for
parity with the m4 and not used, and the MACOS variants are this function.

Upstream:
<https://github.com/coreutils/gnulib/blob/a8482ceecf8f51571e773475a0efa9af7bb616e2/m4/gnulib-common.m4#L1630-L1665>

Original m4 example:
```m4
gl_CHECK_FUNCS_ANDROID([faccessat], [[#include <unistd.h>]])
gl_CHECK_FUNCS_ANDROID([dup3])
```

Example (use `#include <foo>` in the includes list)::
```python
load("@rules_cc_autoconf//gnulib:macros.bzl", gl_macros = "macros")
checks = gl_macros.GL_CHECK_FUNCS_ANDROID(
    ["faccessat", "dup3"],
    includes = ["#include <unistd.h>"],
)
```

Implementation:
For each function, this creates: AC_CHECK_FUNC; AC_DEFINE(HAVE_<FUNCTION>) when
present; AC_SUBST(HAVE_<FUNCTION>, "1"/"0").
*�
�
macros.GL_CHECK_FUNCS_ANDROIDd
	functionsSList of function names to check (e.g., ["dup3", "printf"]) or single function name. (`
includesLIgnored for now (only used in Android case; accepted for API compatibility).None(Q
codeAOptional custom code to compile (applies to all function checks).None(�
requires�Requirements that must be met for this check to run.
Can be define names (e.g., `"HAVE_FOO"`), negated (e.g., `"!HAVE_FOO"`),
or value-based (e.g., `"REPLACE_FSTAT==1"`, `"REPLACE_FSTAT!=0"`).None(�
gl_CHECK_FUNCS_ANDROID / gl_CHECK_FUNCS_MACOS / gl_CHECK_FUNCS_ANDROID_MACOS.

For each function: AC_CHECK_FUNC, AC_DEFINE(HAVE_<FUNCTION>) when it links, and
AC_SUBST(HAVE_<FUNCTION>, 1 or 0) always.  That is what the upstream macros do on
every system but two: on Android they also check the declaration with `includes`
(a function may be in libc but undeclared for the target API level), and on macOS
they consult the deployment target ("future").  Neither applies to the platforms
the rules target, so the three macros are one here: `includes` is accepted for
parity with the m4 and not used, and the MACOS variants are this function.

Upstream:
<https://github.com/coreutils/gnulib/blob/a8482ceecf8f51571e773475a0efa9af7bb616e2/m4/gnulib-common.m4#L1630-L1665>

Original m4 example:
```m4
gl_CHECK_FUNCS_ANDROID([faccessat], [[#include <unistd.h>]])
gl_CHECK_FUNCS_ANDROID([dup3])
```

Example (use `#include <foo>` in the includes list)::
```python
load("@rules_cc_autoconf//gnulib:macros.bzl", gl_macros = "macros")
checks = gl_macros.GL_CHECK_FUNCS_ANDROID(
    ["faccessat", "dup3"],
    includes = ["#include <unistd.h>"],
)
```

Implementation:
For each function, this creates: AC_CHECK_FUNC; AC_DEFINE(HAVE_<FUNCTION>) when
present; AC_SUBST(HAVE_<FUNCTION>, "1"/"0").
"V
TList of JSON-encoded check strings that can be added to an autoconf target's checks.2>
_check_funcs_android&@@rules_cc_autoconf//gnulib:macros.bzl
!!�#macros.GL_CHECK_FUNCS_ANDROID_MACOS�
gl_CHECK_FUNCS_ANDROID / gl_CHECK_FUNCS_MACOS / gl_CHECK_FUNCS_ANDROID_MACOS.

For each function: AC_CHECK_FUNC, AC_DEFINE(HAVE_<FUNCTION>) when it links, and
AC_SUBST(HAVE_<FUNCTION>, 1 or 0) always.  That is what the upstream macros do on
every system but two: on Android they also check the declaration with `includes`
(a function may be in libc but undeclared for the target API level), and on macOS
they consult the deployment target ("future").  Neither applies to the platforms
the rules target, so the three macros are one here: `includes` is accepted for
parity with the m4 and not used, and the MACOS variants are this function.

Upstream:
<https://github.com/coreutils/gnulib/blob/a8482ceecf8f51571e773475a0efa9af7bb616e2/m4/gnulib-common.m4#L1630-L1665>

Original m4 example:
```m4
gl_CHECK_FUNCS_ANDROID([faccessat], [[#include <unistd.h>]])
gl_CHECK_FUNCS_ANDROID([dup3])
```

Example (use `#include <foo>` in the includes list)::
```python
load("@rules_cc_autoconf//gnulib:macros.bzl", gl_macros = "macros")
checks = gl_macros.GL_CHECK_FUNCS_ANDROID(
    ["faccessat", "dup3"],
    includes = ["#include <unistd.h>"],
)
```

Implementation:
For each function, this creates: AC_CHECK_FUNC; AC_DEFINE(HAVE_<FUNCTION>) when
present; AC_SUBST(HAVE_<FUNCTION>, "1"/"0").
*�
�
#macros.GL_CHECK_FUNCS_ANDROID_MACOSd
	functionsSList of function names to check (e.g., ["dup3", "printf"]) or single function name. (`
includesLIgnored for now (only used in Android case; accepted for API compatibility).None(Q
codeAOptional custom code to compile (applies to all function checks).None(�
requires�Requirements that must be met for this check to run.
Can be define names (e.g., `"HAVE_FOO"`), negated (e.g., `"!HAVE_FOO"`),
or value-based (e.g., `"REPLACE_FSTAT==1"`, `"REPLACE_FSTAT!=0"`).None(�
gl_CHECK_FUNCS_ANDROID / gl_CHECK_FUNCS_MACOS / gl_CHECK_FUNCS_ANDROID_MACOS.

For each function: AC_CHECK_FUNC, AC_DEFINE(HAVE_<FUNCTION>) when it links, and
AC_SUBST(HAVE_<FUNCTION>, 1 or 0) always.  That is what the upstream macros do on
every system but two: on Android they also check the declaration with `includes`
(a function may be in libc but undeclared for the target API level), and on macOS
they consult the deployment target ("future").  Neither applies to the platforms
the rules target, so the three macros are one here: `includes` is accepted for
parity with the m4 and not used, and the MACOS variants are this function.

Upstream:
<https://github.com/coreutils/gnulib/blob/a8482ceecf8f51571e773475a0efa9af7bb616e2/m4/gnulib-common.m4#L1630-L1665>

Original m4 example:
```m4
gl_CHECK_FUNCS_ANDROID([faccessat], [[#include <unistd.h>]])
gl_CHECK_FUNCS_ANDROID([dup3])
```

Example (use `#include <foo>` in the includes list)::
```python
load("@rules_cc_autoconf//gnulib:macros.bzl", gl_macros = "macros")
checks = gl_macros.GL_CHECK_FUNCS_ANDROID(
    ["faccessat", "dup3"],
    includes = ["#include <unistd.h>"],
)
```

Implementation:
For each function, this creates: AC_CHECK_FUNC; AC_DEFINE(HAVE_<FUNCTION>) when
present; AC_SUBST(HAVE_<FUNCTION>, "1"/"0").
"V
TList of JSON-encoded check strings that can be added to an autoconf target's checks.2>
_check_funcs_android&@@rules_cc_autoconf//gnulib:macros.bzl
!!�macros.GL_CHECK_FUNCS_MACOS�
gl_CHECK_FUNCS_ANDROID / gl_CHECK_FUNCS_MACOS / gl_CHECK_FUNCS_ANDROID_MACOS.

For each function: AC_CHECK_FUNC, AC_DEFINE(HAVE_<FUNCTION>) when it links, and
AC_SUBST(HAVE_<FUNCTION>, 1 or 0) always.  That is what the upstream macros do on
every system but two: on Android they also check the declaration with `includes`
(a function may be in libc but undeclared for the target API level), and on macOS
they consult the deployment target ("future").  Neither applies to the platforms
the rules target, so the three macros are one here: `includes` is accepted for
parity with the m4 and not used, and the MACOS variants are this function.

Upstream:
<https://github.com/coreutils/gnulib/blob/a8482ceecf8f51571e773475a0efa9af7bb616e2/m4/gnulib-common.m4#L1630-L1665>

Original m4 example:
```m4
gl_CHECK_FUNCS_ANDROID([faccessat], [[#include <unistd.h>]])
gl_CHECK_FUNCS_ANDROID([dup3])
```

Example (use `#include <foo>` in the includes list)::
```python
load("@rules_cc_autoconf//gnulib:macros.bzl", gl_macros = "macros")
checks = gl_macros.GL_CHECK_FUNCS_ANDROID(
    ["faccessat", "dup3"],
    includes = ["#include <unistd.h>"],
)
```

Implementation:
For each function, this creates: AC_CHECK_FUNC; AC_DEFINE(HAVE_<FUNCTION>) when
present; AC_SUBST(HAVE_<FUNCTION>, "1"/"0").
*�
�
macros.GL_CHECK_FUNCS_MACOSd
	functionsSList of function names to check (e.g., ["dup3", "printf"]) or single function name. (`
includesLIgnored for now (only used in Android case; accepted for API compatibility).None(Q
codeAOptional custom code to compile (applies to all function checks).None(�
requires�Requirements that must be met for this check to run.
Can be define names (e.g., `"HAVE_FOO"`), negated (e.g., `"!HAVE_FOO"`),
or value-based (e.g., `"REPLACE_FSTAT==1"`, `"REPLACE_FSTAT!=0"`).None(�
gl_CHECK_FUNCS_ANDROID / gl_CHECK_FUNCS_MACOS / gl_CHECK_FUNCS_ANDROID_MACOS.

For each function: AC_CHECK_FUNC, AC_DEFINE(HAVE_<FUNCTION>) when it links, and
AC_SUBST(HAVE_<FUNCTION>, 1 or 0) always.  That is what the upstream macros do on
every system but two: on Android they also check the declaration with `includes`
(a function may be in libc but undeclared for the target API level), and on macOS
they consult the deployment target ("future").  Neither applies to the platforms
the rules target, so the three macros are one here: `includes` is accepted for
parity with the m4 and not used, and the MACOS variants are this function.

Upstream:
<https://github.com/coreutils/gnulib/blob/a8482ceecf8f51571e773475a0efa9af7bb616e2/m4/gnulib-common.m4#L1630-L1665>

Original m4 example:
```m4
gl_CHECK_FUNCS_ANDROID([faccessat], [[#include <unistd.h>]])
gl_CHECK_FUNCS_ANDROID([dup3])
```

Example (use `#include <foo>` in the includes list)::
```python
load("@rules_cc_autoconf//gnulib:macros.bzl", gl_macros = "macros")
checks = gl_macros.GL_CHECK_FUNCS_ANDROID(
    ["faccessat", "dup3"],
    includes = ["#include <unistd.h>"],
)
```

Implementation:
For each function, this creates: AC_CHECK_FUNC; AC_DEFINE(HAVE_<FUNCTION>) when
present; AC_SUBST(HAVE_<FUNCTION>, "1"/"0").
"V
TList of JSON-encoded check strings that can be added to an autoconf target's checks.2>
_check_funcs_android&@@rules_cc_autoconf//gnulib:macros.bzl
!!�macros.GL_CHECK_NEXT_HEADERS�Set NEXT_* variables for headers (gl_CHECK_NEXT_HEADERS).

Gnulib's gl_CHECK_NEXT_HEADERS runs AC_CHECK_HEADERS_ONCE for the headers, then
for each header sets NEXT_<HEADER> and NEXT_AS_FIRST_DIRECTIVE_<HEADER>.

The behavior matches autoconf:
- Checks if header exists via AC_CHECK_HEADER (creates cache variable)
- ALWAYS sets NEXT_<HEADER> = "<header>" (regardless of whether header exists)

For conditional behavior (e.g., NEXT_* should be empty when some check fails),
use the `condition` parameter. This ensures the substitution always runs (so
@NEXT_*@ placeholders are always replaced) but the value is conditional:
header value when condition is true, empty string when false.

Upstream:
<https://github.com/coreutils/gnulib/blob/a8482ceecf8f51571e773475a0efa9af7bb616e2/m4/include_next.m4#L133-L158>
*�

�

macros.GL_CHECK_NEXT_HEADERSQ
headersBHeader name (e.g., "assert.h" or "sys/stat.h") or list of headers. (G
value6Override value for NEXT_* vars. None means "<header>".None(�
	condition�When provided, makes the value conditional. If condition is
true, uses the header value; if false, uses empty string. Supports
define names (e.g., `"!HAVE_FOO"`), cache variables, or comparisons.None(�Set NEXT_* variables for headers (gl_CHECK_NEXT_HEADERS).

Gnulib's gl_CHECK_NEXT_HEADERS runs AC_CHECK_HEADERS_ONCE for the headers, then
for each header sets NEXT_<HEADER> and NEXT_AS_FIRST_DIRECTIVE_<HEADER>.

The behavior matches autoconf:
- Checks if header exists via AC_CHECK_HEADER (creates cache variable)
- ALWAYS sets NEXT_<HEADER> = "<header>" (regardless of whether header exists)

For conditional behavior (e.g., NEXT_* should be empty when some check fails),
use the `condition` parameter. This ensures the substitution always runs (so
@NEXT_*@ placeholders are always replaced) but the value is conditional:
header value when condition is true, empty string when false.

Upstream:
<https://github.com/coreutils/gnulib/blob/a8482ceecf8f51571e773475a0efa9af7bb616e2/m4/include_next.m4#L133-L158>
"N
LList of JSON-encoded check strings (header check + two AC_SUBST per header).2=
_check_next_headers&@@rules_cc_autoconf//gnulib:macros.bzl
���
macros.GL_NEXT_HEADERS�Set NEXT_* variables for headers without existence check (gl_NEXT_HEADERS).

Gnulib's gl_NEXT_HEADERS sets NEXT_* and NEXT_AS_FIRST_DIRECTIVE_* for each
header without running AC_CHECK_HEADERS_ONCE. Use for standard headers (e.g.
C89) that can be assumed to exist.

Upstream:
<https://github.com/coreutils/gnulib/blob/a8482ceecf8f51571e773475a0efa9af7bb616e2/m4/include_next.m4#L163-L168>
*�
�
macros.GL_NEXT_HEADERSQ
headersBHeader name (e.g., "stddef.h" or "sys/stat.h") or list of headers. (W
valueFOverride value for NEXT_* vars. None means "<header>", "" means empty.None(�
	condition�When provided, makes the value conditional. If condition is
true, uses the header value; if false, uses empty string. Supports
define names (e.g., `"!HAVE_FOO"`), cache variables, or comparisons.None(�Set NEXT_* variables for headers without existence check (gl_NEXT_HEADERS).

Gnulib's gl_NEXT_HEADERS sets NEXT_* and NEXT_AS_FIRST_DIRECTIVE_* for each
header without running AC_CHECK_HEADERS_ONCE. Use for standard headers (e.g.
C89) that can be assumed to exist.

Upstream:
<https://github.com/coreutils/gnulib/blob/a8482ceecf8f51571e773475a0efa9af7bb616e2/m4/include_next.m4#L163-L168>
"F
DList of JSON-encoded check strings (two AC_SUBST checks per header).27
_next_headers&@@rules_cc_autoconf//gnulib:macros.bzl
���checks�# gnulib macros

Common gnulib macro patterns as Bazel wrappers.

These macros encapsulate common patterns from gnulib's m4 files, making it
easier to port modules while maintaining consistency with gnulib behavior.
z�
checks
���# gnulib macros

Common gnulib macro patterns as Bazel wrappers.

These macros encapsulate common patterns from gnulib's m4 files, making it
easier to port modules while maintaining consistency with gnulib behavior.
"H
GL_NEXT_HEADER
��_gl_next_header"checks.GL_NEXT_HEADER*&@@rules_cc_autoconf//gnulib:macros.bzl�macros�# gnulib macros

Common gnulib macro patterns as Bazel wrappers.

These macros encapsulate common patterns from gnulib's m4 files, making it
easier to port modules while maintaining consistency with gnulib behavior.
z�
macros
���# gnulib macros

Common gnulib macro patterns as Bazel wrappers.

These macros encapsulate common patterns from gnulib's m4 files, making it
easier to port modules while maintaining consistency with gnulib behavior.
"]
GL_CHECK_FUNCS_ANDROID
��_check_funcs_android"macros.GL_CHECK_FUNCS_ANDROID"Y
GL_CHECK_FUNCS_MACOS
��_check_funcs_android"macros.GL_CHECK_FUNCS_MACOS"i
GL_CHECK_FUNCS_ANDROID_MACOS
��_check_funcs_android"#macros.GL_CHECK_FUNCS_ANDROID_MACOS"Z
GL_CHECK_NEXT_HEADERS
��_check_next_headers"macros.GL_CHECK_NEXT_HEADERS"H
GL_NEXT_HEADERS
��_next_headers"macros.GL_NEXT_HEADERS"]
AC_LIB_HAVE_LINKFLAGS
��_ac_lib_have_linkflags"macros.AC_LIB_HAVE_LINKFLAGS*&@@rules_cc_autoconf//gnulib:macros.bzl}
//autoconf:checks.bzlrb
)
rules_cc_autoconfautoconf
checks.bzl'
checksautoconf_checks
	1	@
		L�
!//autoconf/private:check_info.bzlrm
5
rules_cc_autoconfautoconf/privatecheck_info.bzl&

make_check
make_check
>H
J�# gnulib macros

Common gnulib macro patterns as Bazel wrappers.

These macros encapsulate common patterns from gnulib's m4 files, making it
easier to port modules while maintaining consistency with gnulib behavior.
�
/
rules_cc_autoconftools/cxxoptscxxopts.bzl�cxxopts6Returns a select statement for C++17 compiler options.*�
�
cxxopts6Returns a select statement for C++17 compiler options."I
GA select statement suitable for use in cc_library or cc_binary cxxopts.29
cxxopts.@@rules_cc_autoconf//tools/cxxopts:cxxopts.bzl
�linkopts2Returns a select statement for C++17 link options.*�
�
linkopts2Returns a select statement for C++17 link options."J
HA select statement suitable for use in cc_library or cc_binary linkopts.2:
linkopts.@@rules_cc_autoconf//tools/cxxopts:cxxopts.bzl
(C++ compiler options for autoconf tools.�

9
rules_cc_autoconftools/queryresult_query_aspect.bzl�ResultQueryInfo3Transitive collection of autoconf result DAG nodes.2�
�
ResultQueryInfo3Transitive collection of autoconf result DAG nodes.i

node_jsons[depset[string]: JSON-encoded node descriptors for every CcAutoconfInfo target in the graph.]
result_filesMdepset[File]: All result files in the transitive closure (so they get built)."K
ResultQueryInfo8@@rules_cc_autoconf//tools/query:result_query_aspect.bzl
		k
i

node_jsons[depset[string]: JSON-encoded node descriptors for every CcAutoconfInfo target in the graph._
]
result_filesMdepset[File]: All result files in the transitive closure (so they get built).�result_query_aspect:�
�
result_query_aspectdeps"*
nameA unique name for this target. *O
result_query_aspect8@@rules_cc_autoconf//tools/query:result_query_aspect.bzl
QQ,
*
nameA unique name for this target. �
(//autoconf/private:ctx_actions_write.bzlrj
<
rules_cc_autoconfautoconf/privatectx_actions_write.bzl
writewrite
EJ
L�
 //autoconf/private:providers.bzlrt
4
rules_cc_autoconfautoconf/privateproviders.bzl.
CcAutoconfInfoCcAutoconfInfo
=K
M.Aspect for collecting the autoconf result DAG.\
 
rules_cc_autoconfversion.bzl	VERSION0.29.0j0.29.0rules_cc_autoconf version 