�
+
rules_cc_autoconfautoconfautoconf.bzl�autoconf�Run autoconf-like checks and produce results.

This rule runs compilation checks against the configured cc_toolchain and produces
a JSON results file containing the check outcomes. Unlike `autoconf_hdr`, this rule
does not generate any header files - it only performs checks.

Example:

```python
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")

autoconf(
    name = "config",
    checks = [
        checks.AC_CHECK_HEADER("stdio.h"),
        checks.AC_CHECK_HEADER("stdlib.h"),
        checks.AC_CHECK_FUNC("printf"),
    ],
)
```

The results can then be used by `autoconf_hdr` or `autoconf_srcs` to generate headers
or wrapped source files.
"�	
�
autoconf�Run autoconf-like checks and produce results.

This rule runs compilation checks against the configured cc_toolchain and produces
a JSON results file containing the check outcomes. Unlike `autoconf_hdr`, this rule
does not generate any header files - it only performs checks.

Example:

```python
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")

autoconf(
    name = "config",
    checks = [
        checks.AC_CHECK_HEADER("stdio.h"),
        checks.AC_CHECK_HEADER("stdlib.h"),
        checks.AC_CHECK_FUNC("printf"),
    ],
)
```

The results can then be used by `autoconf_hdr` or `autoconf_srcs` to generate headers
or wrapped source files.
*
nameA unique name for this target. d
checksTList of JSON-encoded checks from checks (e.g., `checks.AC_CHECK_HEADER('stdio.h')`).2[]U
deps5Additional `autoconf` or `package_info` dependencies.*
CcAutoconfInfo2[]"6
autoconf*@@rules_cc_autoconf//autoconf:autoconf.bzl
��,
*
nameA unique name for this target. f
d
checksTList of JSON-encoded checks from checks (e.g., `checks.AC_CHECK_HEADER('stdio.h')`).2[]W
U
deps5Additional `autoconf` or `package_info` dependencies.*
CcAutoconfInfo2[]�
//cc:find_cc_toolchain.bzlri
%
rules_ccccfind_cc_toolchain.bzl2
use_cc_toolchainuse_cc_toolchain
.>
@�
&//autoconf/private:autoconf_config.bzlr�
:
rules_cc_autoconfautoconf/privateautoconf_config.bzl*
collect_depscollect_deps
F
collect_transitive_resultscollect_transitive_results
 6
create_config_dictcreate_config_dict
<
get_cc_toolchain_infoget_cc_toolchain_info
		D
get_environment_variablesget_environment_variables


4
write_config_jsonwrite_config_json

�
 //autoconf/private:providers.bzlrt
4
rules_cc_autoconfautoconf/privateproviders.bzl.
CcAutoconfInfoCcAutoconfInfo
=K
M
# autoconf�
@
rules_cc_autoconfautoconf/macros/AC_C_RESTRICTrestrict.bzl�ac_c_restrict�Detect the C restrict keyword variant supported by the compiler.

Implements the GNU autoconf AC_C_RESTRICT fallback chain. Tries the bare
`restrict` keyword first (C99), then `__restrict__` (GCC/Clang), then
`__restrict` (MSVC). If none compile, defines `restrict` to empty.

Returns a CcAutoconfInfo provider with the `restrict` define result,
compatible with the standard `autoconf` rule for use as a dependency.
"�
�
ac_c_restrict�Detect the C restrict keyword variant supported by the compiler.

Implements the GNU autoconf AC_C_RESTRICT fallback chain. Tries the bare
`restrict` keyword first (C99), then `__restrict__` (GCC/Clang), then
`__restrict` (MSVC). If none compile, defines `restrict` to empty.

Returns a CcAutoconfInfo provider with the `restrict` define result,
compatible with the standard `autoconf` rule for use as a dependency.
*
nameA unique name for this target. "P
ac_c_restrict?@@rules_cc_autoconf//autoconf/macros/AC_C_RESTRICT:restrict.bzl
��,
*
nameA unique name for this target. �
//cc:find_cc_toolchain.bzlri
%
rules_ccccfind_cc_toolchain.bzl2
use_cc_toolchainuse_cc_toolchain
.>
@�
&//autoconf/private:autoconf_config.bzlr�
:
rules_cc_autoconfautoconf/privateautoconf_config.bzl6
create_config_dictcreate_config_dict
<
get_cc_toolchain_infoget_cc_toolchain_info
D
get_environment_variablesget_environment_variables
4
write_config_jsonwrite_config_json

�
 //autoconf/private:providers.bzlrt
4
rules_cc_autoconfautoconf/privateproviders.bzl.
CcAutoconfInfoCcAutoconfInfo
=K
M�Custom rule for AC_C_RESTRICT keyword detection.

Implements the GNU autoconf AC_C_RESTRICT fallback chain:
  1. restrict      â C99 keyword (no #define needed if it works)
  2. __restrict__  â GCC/Clang extension
  3. __restrict    â MSVC extension
  4. (none)        â #define restrict to empty

This cannot be expressed with the core `autoconf` rule because the fallback
chain requires multiple compile checks that resolve to a single define, and
the core rule rejects duplicate defines for the same name.

The rule uses the standard checker binary for the individual compile checks
and a dedicated resolver tool to combine the results.
�-
:
rules_cc_autoconfautoconf/privateautoconf_config.bzl�collect_deps+Collect `CcAutoconfInfo` from dependencies.*�
�
collect_deps
depsA list of `Target` (+Collect `CcAutoconfInfo` from dependencies."'
%depset: A depset of `CcAutoconfInfo`.2I
collect_deps9@@rules_cc_autoconf//autoconf/private:autoconf_config.bzl
���collect_transitive_results*Collect transitive cache variable results.*�
�
collect_transitive_results,
	dep_infosA list of `CcAutoconfInfo`. (*Collect transitive cache variable results."?
=dict: A mapping of cache variable name to check result files.2W
collect_transitive_results9@@rules_cc_autoconf//autoconf/private:autoconf_config.bzl
���create_config_dict3Create a config dictionary for the autoconf runner.*�
�
create_config_dict:
toolchain_info$Struct from get_cc_toolchain_info(). (3Create a config dictionary for the autoconf runner."0
.A dictionary representing the autoconf config.2O
create_config_dict9@@rules_cc_autoconf//autoconf/private:autoconf_config.bzl
���filter_defaults9Filter toolchain defaults based on include/exclude lists.*�
�
filter_defaultse
defaults_by_labelLMapping of Label -> struct(cache=..., define=..., subst=...) from toolchain. (�
include_labels�If non-empty, only include defaults from these labels.
An error is raised if a label is specified but not found in the toolchain. (
exclude_labelsiIf non-empty, exclude defaults from these labels.
Labels not found in the toolchain are silently ignored. (9Filter toolchain defaults based on include/exclude lists."x
vstruct: A struct with `cache`, `define`, and `subst` fields, each containing
a merged dict[str, File] after filtering.2L
filter_defaults9@@rules_cc_autoconf//autoconf/private:autoconf_config.bzl
>>�get_autoconf_toolchain_defaults<Get default checks from the autoconf toolchain if available.*�
�
get_autoconf_toolchain_defaults
ctxThe rule context. (<Get default checks from the autoconf toolchain if available."�
�struct: A struct with `cache`, `define`, and `subst` fields, each containing
a dict[str, File] mapping variable names to result files.
Returns struct(cache={}, define={}, subst={}) if no toolchain is configured.2\
get_autoconf_toolchain_defaults9@@rules_cc_autoconf//autoconf/private:autoconf_config.bzl
�(get_autoconf_toolchain_defaults_by_labelJGet default checks from the autoconf toolchain, organized by source label.*�
�
(get_autoconf_toolchain_defaults_by_label
ctxThe rule context. (JGet default checks from the autoconf toolchain, organized by source label."�
�dict: A mapping of source labels to structs with `cache`, `define`, and `subst` fields,
each containing a dict[str, File]. Returns empty dict if no toolchain is configured.2e
(get_autoconf_toolchain_defaults_by_label9@@rules_cc_autoconf//autoconf/private:autoconf_config.bzl
((�get_cc_toolchain_info8Get cc_toolchain information for autoconf configuration.*�
�
get_cc_toolchain_info
ctxThe rule context. (8Get cc_toolchain information for autoconf configuration."�
�A struct containing:
- cc_toolchain: The cc_toolchain
- feature_configuration: The feature configuration
- c_compiler_path: Path to C compiler
- cpp_compiler_path: Path to C++ compiler
- linker_path: Path to linker
- c_flags: List of C compiler flags
- cpp_flags: List of C++ compiler flags
- c_link_flags: List of C linker flags
- cpp_link_flags: List of C++ linker flags
- compiler_type: The compiler type2R
get_cc_toolchain_info9@@rules_cc_autoconf//autoconf/private:autoconf_config.bzl
���get_environment_variables6Get environment variables for running autoconf checks.*�
�
get_environment_variables
ctxThe rule context. (:
toolchain_info$Struct from get_cc_toolchain_info(). (6Get environment variables for running autoconf checks."(
&A dictionary of environment variables.2V
get_environment_variables9@@rules_cc_autoconf//autoconf/private:autoconf_config.bzl
���merge_with_defaults�Merge check results with toolchain defaults.

Results from actual targets take precedence over defaults - any variable
present in both will use the result value, not the default.
*�
�
merge_with_defaultsF
defaults6Default checks from toolchain (variable name -> File). (B
results3Check results from targets (variable name -> File). (�Merge check results with toolchain defaults.

Results from actual targets take precedence over defaults - any variable
present in both will use the result value, not the default.
"8
6dict: Merged results with targets overriding defaults.2P
merge_with_defaults9@@rules_cc_autoconf//autoconf/private:autoconf_config.bzl
tt�write_config_json)Write a config dictionary to a JSON file.*�
�
write_config_json
ctxThe rule context. (C
config_dict0The config dictionary from create_config_dict(). ()Write a config dictionary to a JSON file."+
)A File representing the config JSON file.2N
write_config_json9@@rules_cc_autoconf//autoconf/private:autoconf_config.bzl
��w
//cc:action_names.bzlr\
 
rules_ccccaction_names.bzl*
ACTION_NAMESACTION_NAMES
)5
7�
//cc:find_cc_toolchain.bzlrm
%
rules_ccccfind_cc_toolchain.bzl6
find_cpp_toolchainfind_cpp_toolchain
.@
By
//cc/common:cc_common.bzlrZ
$
rules_cc	cc/commoncc_common.bzl$
	cc_common	cc_common
-6
8�
 //autoconf/private:providers.bzlrt
4
rules_cc_autoconfautoconf/privateproviders.bzl.
CcAutoconfInfoCcAutoconfInfo
	=	K
		M8# autoconf_config

Common utilities for autoconf rules.
�
4
rules_cc_autoconfautoconf/privateproviders.bzl�CcAutoconfInfo9A provider containing autoconf configuration and results.2�
�
CcAutoconfInfo9A provider containing autoconf configuration and results.�
cache_results�dict[str, File]: A map of cache names to JSON files containing the defines produced by `CcAutoconfCheck` actions. Each define name must be unique.�
define_results�dict[str, File]: A map of define names to JSON files containing the defines produced by `CcAutoconfCheck` actions. Each define name must be unique.H
deps@depset[CcAutoconfInfo]: Dependencies of the current info target.6
owner-Label: The label of the owner of the results.�
subst_results�dict[str, File]: A map of subst names to JSON files containing the defines produced by `CcAutoconfCheck` actions. Each define name must be unique."E
CcAutoconfInfo3@@rules_cc_autoconf//autoconf/private:providers.bzl
�
�
cache_results�dict[str, File]: A map of cache names to JSON files containing the defines produced by `CcAutoconfCheck` actions. Each define name must be unique.�
�
define_results�dict[str, File]: A map of define names to JSON files containing the defines produced by `CcAutoconfCheck` actions. Each define name must be unique.J
H
deps@depset[CcAutoconfInfo]: Dependencies of the current info target.8
6
owner-Label: The label of the owner of the results.�
�
subst_results�dict[str, File]: A map of subst names to JSON files containing the defines produced by `CcAutoconfCheck` actions. Each define name must be unique.# providersL
J
rules_cc_autoconfautoconf/tests/core/defaultsdefaults_test_suite.bzl�@
/
rules_cc_autoconfautoconfautoconf_hdr.bzl�;autoconf_hdr�	Generate configuration headers from results provided by `autoconf` targets.

This rule takes check results from `autoconf` targets (via `deps`) and generates a header file.
The template file (if provided) is used to format the output header.

Example:

```python
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:autoconf_hdr.bzl", "autoconf_hdr")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")

autoconf(
    name = "config_checks",
    checks = [
        checks.AC_CHECK_HEADER("stdio.h"),
        checks.AC_CHECK_HEADER("stdlib.h"),
        checks.AC_CHECK_FUNC("printf"),
    ],
)

autoconf_hdr(
    name = "config",
    out = "config.h",
    deps = [":config_checks"],
    template = "config.h.in",
)
```

Valid `mode` values:
- `"defines"` (default): Only process defines (AC_DEFINE, AC_CHECK_*, etc.), not substitution variables (AC_SUBST). This is for config.h files.
- `"subst"`: Only process substitution variables (AC_SUBST), not defines. This is for subst.h files.
- `"all"`: Process both defines and substitution variables.
```

This allows you to run checks once and generate multiple header files from the same results.
"�1
�
autoconf_hdr�	Generate configuration headers from results provided by `autoconf` targets.

This rule takes check results from `autoconf` targets (via `deps`) and generates a header file.
The template file (if provided) is used to format the output header.

Example:

```python
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:autoconf_hdr.bzl", "autoconf_hdr")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")

autoconf(
    name = "config_checks",
    checks = [
        checks.AC_CHECK_HEADER("stdio.h"),
        checks.AC_CHECK_HEADER("stdlib.h"),
        checks.AC_CHECK_FUNC("printf"),
    ],
)

autoconf_hdr(
    name = "config",
    out = "config.h",
    deps = [":config_checks"],
    template = "config.h.in",
)
```

Valid `mode` values:
- `"defines"` (default): Only process defines (AC_DEFINE, AC_CHECK_*, etc.), not substitution variables (AC_SUBST). This is for config.h files.
- `"subst"`: Only process substitution variables (AC_SUBST), not defines. This is for subst.h files.
- `"all"`: Process both defines and substitution variables.
```

This allows you to run checks once and generate multiple header files from the same results.
*
nameA unique name for this target. �
defaults�Whether to include toolchain defaults.

When False (the default), no toolchain defaults are included and only
the explicit deps provide check results. When True, defaults from the
autoconf toolchain are included, subject to filtering by defaults_include
or defaults_exclude.2False�
defaults_exclude�Labels to exclude from toolchain defaults.

Only effective when defaults=True. If specified, defaults from these
labels are excluded. Labels not found in the toolchain are silently
ignored. Mutually exclusive with defaults_include.*
CcAutoconfInfo2[]�
defaults_include�Labels to include from toolchain defaults.

Only effective when defaults=True. If specified, only defaults from
these labels are included. An error is raised if a specified label
is not found in the toolchain. Mutually exclusive with defaults_exclude.*
CcAutoconfInfo2[]�
deps�List of `autoconf` targets which provide check results. Results from all deps will be merged together, and duplicate define names will produce an error. If not provided, an empty results file will be created.*
CcAutoconfInfo2[]�
inlines�A mapping of strings to files for replace within the content of the given `template` attribute.

The exact string in the template is replaced with the content of the associated file.
Any `@VAR@` style placeholders in the inline file content will be replaced with their
corresponding define values (package info, check results, etc.) after insertion.	2{}]
modeHProcessing mode that determines what should be replaced within the file.2	"defines"9
out.The output config file (typically `config.h`). �
substitutions�A mapping of exact strings to replacement values.

Each entry performs an exact text replacement in the template - the key
string is replaced with the value string. No special patterns or wrappers
are added.

Example:
```python
autoconf_hdr(
    name = "config",
    out = "config.h",
    template = "config.h.in",
    substitutions = {
        "@MY_VERSION@": "1.2.3",
        "@BUILD_TYPE@": "release",
        "PLACEHOLDER_TEXT": "actual_value",
    },
    deps = [":checks"],
)
```

This would replace the exact string `@MY_VERSION@` with `1.2.3`,
`@BUILD_TYPE@` with `release`, and `PLACEHOLDER_TEXT` with `actual_value`.
2{}�
template�Template file (`config.h.in`) to use as base for generating the header file. The template is used to format the output header, but does not generate any checks. ">
autoconf_hdr.@@rules_cc_autoconf//autoconf:autoconf_hdr.bzl
kk,
*
nameA unique name for this target. �
�
defaults�Whether to include toolchain defaults.

When False (the default), no toolchain defaults are included and only
the explicit deps provide check results. When True, defaults from the
autoconf toolchain are included, subject to filtering by defaults_include
or defaults_exclude.2False�
�
defaults_exclude�Labels to exclude from toolchain defaults.

Only effective when defaults=True. If specified, defaults from these
labels are excluded. Labels not found in the toolchain are silently
ignored. Mutually exclusive with defaults_include.*
CcAutoconfInfo2[]�
�
defaults_include�Labels to include from toolchain defaults.

Only effective when defaults=True. If specified, only defaults from
these labels are included. An error is raised if a specified label
is not found in the toolchain. Mutually exclusive with defaults_exclude.*
CcAutoconfInfo2[]�
�
deps�List of `autoconf` targets which provide check results. Results from all deps will be merged together, and duplicate define names will produce an error. If not provided, an empty results file will be created.*
CcAutoconfInfo2[]�
�
inlines�A mapping of strings to files for replace within the content of the given `template` attribute.

The exact string in the template is replaced with the content of the associated file.
Any `@VAR@` style placeholders in the inline file content will be replaced with their
corresponding define values (package info, check results, etc.) after insertion.	2{}_
]
modeHProcessing mode that determines what should be replaced within the file.2	"defines";
9
out.The output config file (typically `config.h`). �
�
substitutions�A mapping of exact strings to replacement values.

Each entry performs an exact text replacement in the template - the key
string is replaced with the value string. No special patterns or wrappers
are added.

Example:
```python
autoconf_hdr(
    name = "config",
    out = "config.h",
    template = "config.h.in",
    substitutions = {
        "@MY_VERSION@": "1.2.3",
        "@BUILD_TYPE@": "release",
        "PLACEHOLDER_TEXT": "actual_value",
    },
    deps = [":checks"],
)
```

This would replace the exact string `@MY_VERSION@` with `1.2.3`,
`@BUILD_TYPE@` with `release`, and `PLACEHOLDER_TEXT` with `actual_value`.
2{}�
�
template�Template file (`config.h.in`) to use as base for generating the header file. The template is used to format the output header, but does not generate any checks. �
&//autoconf/private:autoconf_config.bzlr�
:
rules_cc_autoconfautoconf/privateautoconf_config.bzl*
collect_depscollect_deps
F
collect_transitive_resultscollect_transitive_results
 0
filter_defaultsfilter_defaults
P
get_autoconf_toolchain_defaultsget_autoconf_toolchain_defaults
%b
(get_autoconf_toolchain_defaults_by_label(get_autoconf_toolchain_defaults_by_label
		.

�
 //autoconf/private:providers.bzlrt
4
rules_cc_autoconfautoconf/privateproviders.bzl.
CcAutoconfInfoCcAutoconfInfo
=K
M# autoconf_hdr�4
0
rules_cc_autoconfautoconfautoconf_srcs.bzl�,autoconf_srcs�
Generate wrapper sources that are conditionally enabled by autoconf results.

Typical use case:

```python
load("@rules_cc_autoconf//autoconf:autoconf_srcs.bzl", "autoconf_srcs")
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")
load("@rules_cc//cc:cc_library.bzl", "cc_library")

autoconf(
    name = "config",
    out = "config.h",
    checks = [
        # Feature is present on this platform/toolchain.
        checks.AC_CHECK_HEADER("foo.h", define = "HAVE_FOO"),
    ],
)

autoconf_srcs(
    name = "foo_srcs",
    deps = [":config"],
    srcs = {
        "uses_foo.c": "HAVE_FOO",
    },
)

cc_library(
    name = "foo",
    srcs = [":foo_srcs"],
    hdrs = [":config.h"],
)
```

In this setup `autoconf_srcs` reads the results from `:config` (or multiple targets via `deps`) and generates a
wrapped copy of `uses_foo.c` whose contents are effectively:

```cc
#define HAVE_FOO 1      // when the check for HAVE_FOO succeeds
/* or: #undef HAVE_FOO  // when the check fails */
#ifdef HAVE_FOO
/* original uses_foo.c contents ... */
#endif
```

This is useful when you have platform-specific or optional sources that should
only be compiled when a particular autoconf check passes, without having to
manually maintain `#ifdef` guards in every source file.
"�"
�
autoconf_srcs�
Generate wrapper sources that are conditionally enabled by autoconf results.

Typical use case:

```python
load("@rules_cc_autoconf//autoconf:autoconf_srcs.bzl", "autoconf_srcs")
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")
load("@rules_cc//cc:cc_library.bzl", "cc_library")

autoconf(
    name = "config",
    out = "config.h",
    checks = [
        # Feature is present on this platform/toolchain.
        checks.AC_CHECK_HEADER("foo.h", define = "HAVE_FOO"),
    ],
)

autoconf_srcs(
    name = "foo_srcs",
    deps = [":config"],
    srcs = {
        "uses_foo.c": "HAVE_FOO",
    },
)

cc_library(
    name = "foo",
    srcs = [":foo_srcs"],
    hdrs = [":config.h"],
)
```

In this setup `autoconf_srcs` reads the results from `:config` (or multiple targets via `deps`) and generates a
wrapped copy of `uses_foo.c` whose contents are effectively:

```cc
#define HAVE_FOO 1      // when the check for HAVE_FOO succeeds
/* or: #undef HAVE_FOO  // when the check fails */
#ifdef HAVE_FOO
/* original uses_foo.c contents ... */
#endif
```

This is useful when you have platform-specific or optional sources that should
only be compiled when a particular autoconf check passes, without having to
manually maintain `#ifdef` guards in every source file.
*
nameA unique name for this target. �
defaults�Whether to include toolchain defaults.

When False (the default), no toolchain defaults are included and only
the explicit deps provide check results. When True, defaults from the
autoconf toolchain are included, subject to filtering by defaults_include
or defaults_exclude.2False�
defaults_exclude�Labels to exclude from toolchain defaults.

Only effective when defaults=True. If specified, defaults from these
labels are excluded. Labels not found in the toolchain are silently
ignored. Mutually exclusive with defaults_include.*
CcAutoconfInfo2[]�
defaults_include�Labels to include from toolchain defaults.

Only effective when defaults=True. If specified, only defaults from
these labels are included. An error is raised if a specified label
is not found in the toolchain. Mutually exclusive with defaults_exclude.*
CcAutoconfInfo2[]�
deps�List of `autoconf` targets which provide defines. Results from all deps will be merged together, and duplicate define names will produce an error. *
CcAutoconfInfo�
naming�How to name generated sources: `package_relative` keeps the original package-relative path, `ac_suffix`
inserts `.ac.` before the final suffix (e.g. `foo.cc -> foo.ac.cc`), and `per_target` prefixes outputs
with `{ctx.label.name}` to namespace them per rule.
2"package_relative"L
srcs@A mapping of source file to define required to compile the file.	 "@
autoconf_srcs/@@rules_cc_autoconf//autoconf:autoconf_srcs.bzl
��,
*
nameA unique name for this target. �
�
defaults�Whether to include toolchain defaults.

When False (the default), no toolchain defaults are included and only
the explicit deps provide check results. When True, defaults from the
autoconf toolchain are included, subject to filtering by defaults_include
or defaults_exclude.2False�
�
defaults_exclude�Labels to exclude from toolchain defaults.

Only effective when defaults=True. If specified, defaults from these
labels are excluded. Labels not found in the toolchain are silently
ignored. Mutually exclusive with defaults_include.*
CcAutoconfInfo2[]�
�
defaults_include�Labels to include from toolchain defaults.

Only effective when defaults=True. If specified, only defaults from
these labels are included. An error is raised if a specified label
is not found in the toolchain. Mutually exclusive with defaults_exclude.*
CcAutoconfInfo2[]�
�
deps�List of `autoconf` targets which provide defines. Results from all deps will be merged together, and duplicate define names will produce an error. *
CcAutoconfInfo�
�
naming�How to name generated sources: `package_relative` keeps the original package-relative path, `ac_suffix`
inserts `.ac.` before the final suffix (e.g. `foo.cc -> foo.ac.cc`), and `per_target` prefixes outputs
with `{ctx.label.name}` to namespace them per rule.
2"package_relative"N
L
srcs@A mapping of source file to define required to compile the file.	 a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.�
//cc:find_cc_toolchain.bzlri
%
rules_ccccfind_cc_toolchain.bzl2
use_cc_toolchainuse_cc_toolchain
.>
@�
&//autoconf/private:autoconf_config.bzlr�
:
rules_cc_autoconfautoconf/privateautoconf_config.bzl*
collect_depscollect_deps
F
collect_transitive_resultscollect_transitive_results
 0
filter_defaultsfilter_defaults
		P
get_autoconf_toolchain_defaultsget_autoconf_toolchain_defaults


%b
(get_autoconf_toolchain_defaults_by_label(get_autoconf_toolchain_defaults_by_label
.
�
 //autoconf/private:providers.bzlrt
4
rules_cc_autoconfautoconf/privateproviders.bzl.
CcAutoconfInfoCcAutoconfInfo
=K
M# autoconf_srcs�"
5
rules_cc_autoconfautoconfautoconf_toolchain.bzl�autoconf_toolchain�Define default autoconf checks that can be overridden by targets.

The toolchain collects results from `autoconf` target dependencies and provides them
as defaults. When `autoconf_hdr` or `autoconf_srcs` rules process checks, toolchain
defaults are considered first but any checks from the actual targets will override
the defaults (no error on conflict).

**Duplicate Detection**: The toolchain disallows duplicate variables across
different defaults targets. If the same variable (cache, define, or subst) is
defined in multiple defaults targets with different result files, the toolchain
construction will fail with a clear error message indicating which targets conflict.
Duplicate variables must point to the same result file (same check result).

Example:

```python
load("@rules_cc_autoconf//autoconf:defs.bzl", "autoconf", "autoconf_toolchain")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")

# Define default checks
autoconf(
    name = "gnulib_defaults",
    checks = [
        checks.AC_SUBST("GNULIB_VFPRINTF_POSIX", "0"),
        checks.AC_SUBST("REPLACE_POSIX_SPAWN", "0"),
        # ... many more defaults
    ],
)

# Create toolchain with defaults
autoconf_toolchain(
    name = "gnulib_toolchain_impl",
    deps = [":gnulib_defaults"],
)

toolchain(
    name = "gnulib_toolchain",
    toolchain = ":gnulib_toolchain_impl",
    toolchain_type = "@rules_cc_autoconf//autoconf:toolchain_type",
)
```

Then in consuming targets:

```python
autoconf_hdr(
    name = "config",
    out = "config.h",
    template = "config.h.in",
    deps = [":my_checks"],  # These will override any defaults from the toolchain
)
```
"�
�
autoconf_toolchain�Define default autoconf checks that can be overridden by targets.

The toolchain collects results from `autoconf` target dependencies and provides them
as defaults. When `autoconf_hdr` or `autoconf_srcs` rules process checks, toolchain
defaults are considered first but any checks from the actual targets will override
the defaults (no error on conflict).

**Duplicate Detection**: The toolchain disallows duplicate variables across
different defaults targets. If the same variable (cache, define, or subst) is
defined in multiple defaults targets with different result files, the toolchain
construction will fail with a clear error message indicating which targets conflict.
Duplicate variables must point to the same result file (same check result).

Example:

```python
load("@rules_cc_autoconf//autoconf:defs.bzl", "autoconf", "autoconf_toolchain")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")

# Define default checks
autoconf(
    name = "gnulib_defaults",
    checks = [
        checks.AC_SUBST("GNULIB_VFPRINTF_POSIX", "0"),
        checks.AC_SUBST("REPLACE_POSIX_SPAWN", "0"),
        # ... many more defaults
    ],
)

# Create toolchain with defaults
autoconf_toolchain(
    name = "gnulib_toolchain_impl",
    deps = [":gnulib_defaults"],
)

toolchain(
    name = "gnulib_toolchain",
    toolchain = ":gnulib_toolchain_impl",
    toolchain_type = "@rules_cc_autoconf//autoconf:toolchain_type",
)
```

Then in consuming targets:

```python
autoconf_hdr(
    name = "config",
    out = "config.h",
    template = "config.h.in",
    deps = [":my_checks"],  # These will override any defaults from the toolchain
)
```
*
nameA unique name for this target. �
depsuList of `autoconf` targets providing default checks. These defaults can be overridden by targets using the toolchain.*
CcAutoconfInfo2[]"J
autoconf_toolchain4@@rules_cc_autoconf//autoconf:autoconf_toolchain.bzl
33,
*
nameA unique name for this target. �
�
depsuList of `autoconf` targets providing default checks. These defaults can be overridden by targets using the toolchain.*
CcAutoconfInfo2[]�
&//autoconf/private:autoconf_config.bzlr�
:
rules_cc_autoconfautoconf/privateautoconf_config.bzl*
collect_depscollect_deps
COF
collect_transitive_resultscollect_transitive_results
Sm
o�
 //autoconf/private:providers.bzlrt
4
rules_cc_autoconfautoconf/privateproviders.bzl.
CcAutoconfInfoCcAutoconfInfo
=K
MXautoconf_toolchain

Provides default autoconf checks that can be overridden by targets.
�
3
rules_cc_autoconfautoconfcc_autoconf_info.bzl�CcAutoconfInfo9A provider containing autoconf configuration and results.2�
�
CcAutoconfInfo9A provider containing autoconf configuration and results.�
cache_results�dict[str, File]: A map of cache names to JSON files containing the defines produced by `CcAutoconfCheck` actions. Each define name must be unique.�
define_results�dict[str, File]: A map of define names to JSON files containing the defines produced by `CcAutoconfCheck` actions. Each define name must be unique.H
deps@depset[CcAutoconfInfo]: Dependencies of the current info target.6
owner-Label: The label of the owner of the results.�
subst_results�dict[str, File]: A map of subst names to JSON files containing the defines produced by `CcAutoconfCheck` actions. Each define name must be unique."D
CcAutoconfInfo2@@rules_cc_autoconf//autoconf:cc_autoconf_info.bzl
�
�
cache_results�dict[str, File]: A map of cache names to JSON files containing the defines produced by `CcAutoconfCheck` actions. Each define name must be unique.�
�
define_results�dict[str, File]: A map of define names to JSON files containing the defines produced by `CcAutoconfCheck` actions. Each define name must be unique.J
H
deps@depset[CcAutoconfInfo]: Dependencies of the current info target.8
6
owner-Label: The label of the owner of the results.�
�
subst_results�dict[str, File]: A map of subst names to JSON files containing the defines produced by `CcAutoconfCheck` actions. Each define name must be unique.�
 //autoconf/private:providers.bzlru
4
rules_cc_autoconfautoconf/privateproviders.bzl/
CcAutoconfInfo_CcAutoconfInfo

# CcAutoconfInfo�
)
rules_cc_autoconfautoconf
checks.bzl�# checks

This module provides Bazel macros that mirror GNU Autoconf's behavior.

## Cache Variables, Defines, and Subst Values

Checks (AC_CHECK_FUNC, AC_CHECK_HEADER, etc.) create cache variables by default, following
autoconf's naming convention:
- AC_CHECK_HEADER("foo.h") â cache variable "ac_cv_header_foo_h"
- AC_CHECK_FUNC("foo") â cache variable "ac_cv_func_foo"
- AC_CHECK_DECL("foo") â cache variable "ac_cv_have_decl_foo"

Defines and subst values are created explicitly using AC_DEFINE and AC_SUBST.

## Condition Resolution

When AC_DEFINE or AC_SUBST use a `condition` parameter that references a cache variable
(e.g., `condition="ac_cv_header_foo_h"`), the condition is evaluated as a **truthy check**:

- Condition is `true` if:
  - The cache variable exists (check was run)
  - The check succeeded (success = true)
  - The value is truthy (non-empty string, not "0")

- Condition is `false` if:
  - The cache variable doesn't exist (check wasn't run)
  - The check failed (success = false)
  - The value is falsy (empty string or "0")

If the condition includes a comparison operator (e.g., `condition="ac_cv_header_foo_h==1"`),
it performs value comparison instead of truthy check.

Example:
```python
# Check creates cache variable
macros.AC_CHECK_HEADER("alloca.h")
# â Creates cache variable: "ac_cv_header_alloca_h" with value "1" (if header exists)

# Define with truthy condition
macros.AC_DEFINE(
    "HAVE_ALLOCA_H",
    condition="ac_cv_header_alloca_h",  # Truthy: true if check succeeded and value is truthy
    if_true="1",
    if_false=None,  # Don't define if condition is false
)

# Subst with truthy condition
macros.AC_SUBST(
    "HAVE_ALLOCA_H",
    condition="ac_cv_header_alloca_h",  # Truthy check
    if_true="1",
    if_false="0",  # Always set subst value
)
```

## Default Includes

Default includes used by AC_CHECK_DECL, AC_CHECK_TYPE, etc. when no includes are specified.

GNU Autoconf's AC_INCLUDES_DEFAULT uses #ifdef HAVE_* guards, but that relies on
AC_CHECK_HEADERS_ONCE being called earlier to define those macros. In Bazel, each
compile test runs independently without access to results from other checks, so we
use unconditional includes instead. This matches what would happen on a modern
POSIX system where all the standard headers exist.

See: https://www.gnu.org/savannah-checkouts/gnu/autoconf/manual/autoconf-2.72/autoconf.html#Default-Includes

## Header / includes parameter

Checks that need to include headers (AC_CHECK_DECL, AC_CHECK_TYPE, AC_CHECK_SIZEOF,
AC_CHECK_MEMBER, etc.) take an **`includes`** parameter. **AC_CHECK_FUNC** does not
take includes (standard Autoconf link test only); use **GL_CHECK_FUNCS_ANDROID** (or
other GL_CHECK_FUNCS* in gnulib/macros.bzl) when includes are needed. Both of these forms are
supported:

Use **include directives** as strings, e.g. `"#include <stdlib.h>"` or
`"#include <sys/stat.h>"`, matching Autoconf/gnulib (e.g.
`gl_CHECK_FUNCS_ANDROID([faccessat], [[#include <unistd.h>]])`). The list is
joined with newlines to form the prologue of the test program.

The parameter `headers` is a deprecated alias for `includes`; prefer `includes`.
�
'
rules_cc_autoconfautoconfdefs.bzl�autoconf�Run autoconf-like checks and produce results.

This rule runs compilation checks against the configured cc_toolchain and produces
a JSON results file containing the check outcomes. Unlike `autoconf_hdr`, this rule
does not generate any header files - it only performs checks.

Example:

```python
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")

autoconf(
    name = "config",
    checks = [
        checks.AC_CHECK_HEADER("stdio.h"),
        checks.AC_CHECK_HEADER("stdlib.h"),
        checks.AC_CHECK_FUNC("printf"),
    ],
)
```

The results can then be used by `autoconf_hdr` or `autoconf_srcs` to generate headers
or wrapped source files.
"�	
�
autoconf�Run autoconf-like checks and produce results.

This rule runs compilation checks against the configured cc_toolchain and produces
a JSON results file containing the check outcomes. Unlike `autoconf_hdr`, this rule
does not generate any header files - it only performs checks.

Example:

```python
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")

autoconf(
    name = "config",
    checks = [
        checks.AC_CHECK_HEADER("stdio.h"),
        checks.AC_CHECK_HEADER("stdlib.h"),
        checks.AC_CHECK_FUNC("printf"),
    ],
)
```

The results can then be used by `autoconf_hdr` or `autoconf_srcs` to generate headers
or wrapped source files.
*
nameA unique name for this target. d
checksTList of JSON-encoded checks from checks (e.g., `checks.AC_CHECK_HEADER('stdio.h')`).2[]U
deps5Additional `autoconf` or `package_info` dependencies.*
CcAutoconfInfo2[]"2
autoconf&@@rules_cc_autoconf//autoconf:defs.bzl
��,
*
nameA unique name for this target. f
d
checksTList of JSON-encoded checks from checks (e.g., `checks.AC_CHECK_HEADER('stdio.h')`).2[]W
U
deps5Additional `autoconf` or `package_info` dependencies.*
CcAutoconfInfo2[]�;autoconf_hdr�	Generate configuration headers from results provided by `autoconf` targets.

This rule takes check results from `autoconf` targets (via `deps`) and generates a header file.
The template file (if provided) is used to format the output header.

Example:

```python
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:autoconf_hdr.bzl", "autoconf_hdr")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")

autoconf(
    name = "config_checks",
    checks = [
        checks.AC_CHECK_HEADER("stdio.h"),
        checks.AC_CHECK_HEADER("stdlib.h"),
        checks.AC_CHECK_FUNC("printf"),
    ],
)

autoconf_hdr(
    name = "config",
    out = "config.h",
    deps = [":config_checks"],
    template = "config.h.in",
)
```

Valid `mode` values:
- `"defines"` (default): Only process defines (AC_DEFINE, AC_CHECK_*, etc.), not substitution variables (AC_SUBST). This is for config.h files.
- `"subst"`: Only process substitution variables (AC_SUBST), not defines. This is for subst.h files.
- `"all"`: Process both defines and substitution variables.
```

This allows you to run checks once and generate multiple header files from the same results.
"�1
�
autoconf_hdr�	Generate configuration headers from results provided by `autoconf` targets.

This rule takes check results from `autoconf` targets (via `deps`) and generates a header file.
The template file (if provided) is used to format the output header.

Example:

```python
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:autoconf_hdr.bzl", "autoconf_hdr")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")

autoconf(
    name = "config_checks",
    checks = [
        checks.AC_CHECK_HEADER("stdio.h"),
        checks.AC_CHECK_HEADER("stdlib.h"),
        checks.AC_CHECK_FUNC("printf"),
    ],
)

autoconf_hdr(
    name = "config",
    out = "config.h",
    deps = [":config_checks"],
    template = "config.h.in",
)
```

Valid `mode` values:
- `"defines"` (default): Only process defines (AC_DEFINE, AC_CHECK_*, etc.), not substitution variables (AC_SUBST). This is for config.h files.
- `"subst"`: Only process substitution variables (AC_SUBST), not defines. This is for subst.h files.
- `"all"`: Process both defines and substitution variables.
```

This allows you to run checks once and generate multiple header files from the same results.
*
nameA unique name for this target. �
defaults�Whether to include toolchain defaults.

When False (the default), no toolchain defaults are included and only
the explicit deps provide check results. When True, defaults from the
autoconf toolchain are included, subject to filtering by defaults_include
or defaults_exclude.2False�
defaults_exclude�Labels to exclude from toolchain defaults.

Only effective when defaults=True. If specified, defaults from these
labels are excluded. Labels not found in the toolchain are silently
ignored. Mutually exclusive with defaults_include.*
CcAutoconfInfo2[]�
defaults_include�Labels to include from toolchain defaults.

Only effective when defaults=True. If specified, only defaults from
these labels are included. An error is raised if a specified label
is not found in the toolchain. Mutually exclusive with defaults_exclude.*
CcAutoconfInfo2[]�
deps�List of `autoconf` targets which provide check results. Results from all deps will be merged together, and duplicate define names will produce an error. If not provided, an empty results file will be created.*
CcAutoconfInfo2[]�
inlines�A mapping of strings to files for replace within the content of the given `template` attribute.

The exact string in the template is replaced with the content of the associated file.
Any `@VAR@` style placeholders in the inline file content will be replaced with their
corresponding define values (package info, check results, etc.) after insertion.	2{}]
modeHProcessing mode that determines what should be replaced within the file.2	"defines"9
out.The output config file (typically `config.h`). �
substitutions�A mapping of exact strings to replacement values.

Each entry performs an exact text replacement in the template - the key
string is replaced with the value string. No special patterns or wrappers
are added.

Example:
```python
autoconf_hdr(
    name = "config",
    out = "config.h",
    template = "config.h.in",
    substitutions = {
        "@MY_VERSION@": "1.2.3",
        "@BUILD_TYPE@": "release",
        "PLACEHOLDER_TEXT": "actual_value",
    },
    deps = [":checks"],
)
```

This would replace the exact string `@MY_VERSION@` with `1.2.3`,
`@BUILD_TYPE@` with `release`, and `PLACEHOLDER_TEXT` with `actual_value`.
2{}�
template�Template file (`config.h.in`) to use as base for generating the header file. The template is used to format the output header, but does not generate any checks. "6
autoconf_hdr&@@rules_cc_autoconf//autoconf:defs.bzl
kk,
*
nameA unique name for this target. �
�
defaults�Whether to include toolchain defaults.

When False (the default), no toolchain defaults are included and only
the explicit deps provide check results. When True, defaults from the
autoconf toolchain are included, subject to filtering by defaults_include
or defaults_exclude.2False�
�
defaults_exclude�Labels to exclude from toolchain defaults.

Only effective when defaults=True. If specified, defaults from these
labels are excluded. Labels not found in the toolchain are silently
ignored. Mutually exclusive with defaults_include.*
CcAutoconfInfo2[]�
�
defaults_include�Labels to include from toolchain defaults.

Only effective when defaults=True. If specified, only defaults from
these labels are included. An error is raised if a specified label
is not found in the toolchain. Mutually exclusive with defaults_exclude.*
CcAutoconfInfo2[]�
�
deps�List of `autoconf` targets which provide check results. Results from all deps will be merged together, and duplicate define names will produce an error. If not provided, an empty results file will be created.*
CcAutoconfInfo2[]�
�
inlines�A mapping of strings to files for replace within the content of the given `template` attribute.

The exact string in the template is replaced with the content of the associated file.
Any `@VAR@` style placeholders in the inline file content will be replaced with their
corresponding define values (package info, check results, etc.) after insertion.	2{}_
]
modeHProcessing mode that determines what should be replaced within the file.2	"defines";
9
out.The output config file (typically `config.h`). �
�
substitutions�A mapping of exact strings to replacement values.

Each entry performs an exact text replacement in the template - the key
string is replaced with the value string. No special patterns or wrappers
are added.

Example:
```python
autoconf_hdr(
    name = "config",
    out = "config.h",
    template = "config.h.in",
    substitutions = {
        "@MY_VERSION@": "1.2.3",
        "@BUILD_TYPE@": "release",
        "PLACEHOLDER_TEXT": "actual_value",
    },
    deps = [":checks"],
)
```

This would replace the exact string `@MY_VERSION@` with `1.2.3`,
`@BUILD_TYPE@` with `release`, and `PLACEHOLDER_TEXT` with `actual_value`.
2{}�
�
template�Template file (`config.h.in`) to use as base for generating the header file. The template is used to format the output header, but does not generate any checks. �,autoconf_srcs�
Generate wrapper sources that are conditionally enabled by autoconf results.

Typical use case:

```python
load("@rules_cc_autoconf//autoconf:autoconf_srcs.bzl", "autoconf_srcs")
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")
load("@rules_cc//cc:cc_library.bzl", "cc_library")

autoconf(
    name = "config",
    out = "config.h",
    checks = [
        # Feature is present on this platform/toolchain.
        checks.AC_CHECK_HEADER("foo.h", define = "HAVE_FOO"),
    ],
)

autoconf_srcs(
    name = "foo_srcs",
    deps = [":config"],
    srcs = {
        "uses_foo.c": "HAVE_FOO",
    },
)

cc_library(
    name = "foo",
    srcs = [":foo_srcs"],
    hdrs = [":config.h"],
)
```

In this setup `autoconf_srcs` reads the results from `:config` (or multiple targets via `deps`) and generates a
wrapped copy of `uses_foo.c` whose contents are effectively:

```cc
#define HAVE_FOO 1      // when the check for HAVE_FOO succeeds
/* or: #undef HAVE_FOO  // when the check fails */
#ifdef HAVE_FOO
/* original uses_foo.c contents ... */
#endif
```

This is useful when you have platform-specific or optional sources that should
only be compiled when a particular autoconf check passes, without having to
manually maintain `#ifdef` guards in every source file.
"�"
�
autoconf_srcs�
Generate wrapper sources that are conditionally enabled by autoconf results.

Typical use case:

```python
load("@rules_cc_autoconf//autoconf:autoconf_srcs.bzl", "autoconf_srcs")
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")
load("@rules_cc//cc:cc_library.bzl", "cc_library")

autoconf(
    name = "config",
    out = "config.h",
    checks = [
        # Feature is present on this platform/toolchain.
        checks.AC_CHECK_HEADER("foo.h", define = "HAVE_FOO"),
    ],
)

autoconf_srcs(
    name = "foo_srcs",
    deps = [":config"],
    srcs = {
        "uses_foo.c": "HAVE_FOO",
    },
)

cc_library(
    name = "foo",
    srcs = [":foo_srcs"],
    hdrs = [":config.h"],
)
```

In this setup `autoconf_srcs` reads the results from `:config` (or multiple targets via `deps`) and generates a
wrapped copy of `uses_foo.c` whose contents are effectively:

```cc
#define HAVE_FOO 1      // when the check for HAVE_FOO succeeds
/* or: #undef HAVE_FOO  // when the check fails */
#ifdef HAVE_FOO
/* original uses_foo.c contents ... */
#endif
```

This is useful when you have platform-specific or optional sources that should
only be compiled when a particular autoconf check passes, without having to
manually maintain `#ifdef` guards in every source file.
*
nameA unique name for this target. �
defaults�Whether to include toolchain defaults.

When False (the default), no toolchain defaults are included and only
the explicit deps provide check results. When True, defaults from the
autoconf toolchain are included, subject to filtering by defaults_include
or defaults_exclude.2False�
defaults_exclude�Labels to exclude from toolchain defaults.

Only effective when defaults=True. If specified, defaults from these
labels are excluded. Labels not found in the toolchain are silently
ignored. Mutually exclusive with defaults_include.*
CcAutoconfInfo2[]�
defaults_include�Labels to include from toolchain defaults.

Only effective when defaults=True. If specified, only defaults from
these labels are included. An error is raised if a specified label
is not found in the toolchain. Mutually exclusive with defaults_exclude.*
CcAutoconfInfo2[]�
deps�List of `autoconf` targets which provide defines. Results from all deps will be merged together, and duplicate define names will produce an error. *
CcAutoconfInfo�
naming�How to name generated sources: `package_relative` keeps the original package-relative path, `ac_suffix`
inserts `.ac.` before the final suffix (e.g. `foo.cc -> foo.ac.cc`), and `per_target` prefixes outputs
with `{ctx.label.name}` to namespace them per rule.
2"package_relative"L
srcs@A mapping of source file to define required to compile the file.	 "7
autoconf_srcs&@@rules_cc_autoconf//autoconf:defs.bzl
��,
*
nameA unique name for this target. �
�
defaults�Whether to include toolchain defaults.

When False (the default), no toolchain defaults are included and only
the explicit deps provide check results. When True, defaults from the
autoconf toolchain are included, subject to filtering by defaults_include
or defaults_exclude.2False�
�
defaults_exclude�Labels to exclude from toolchain defaults.

Only effective when defaults=True. If specified, defaults from these
labels are excluded. Labels not found in the toolchain are silently
ignored. Mutually exclusive with defaults_include.*
CcAutoconfInfo2[]�
�
defaults_include�Labels to include from toolchain defaults.

Only effective when defaults=True. If specified, only defaults from
these labels are included. An error is raised if a specified label
is not found in the toolchain. Mutually exclusive with defaults_exclude.*
CcAutoconfInfo2[]�
�
deps�List of `autoconf` targets which provide defines. Results from all deps will be merged together, and duplicate define names will produce an error. *
CcAutoconfInfo�
�
naming�How to name generated sources: `package_relative` keeps the original package-relative path, `ac_suffix`
inserts `.ac.` before the final suffix (e.g. `foo.cc -> foo.ac.cc`), and `per_target` prefixes outputs
with `{ctx.label.name}` to namespace them per rule.
2"package_relative"N
L
srcs@A mapping of source file to define required to compile the file.	 �package_info�A rule for parsing module info from `MODULE.bazel` files.

This rule is most useful when paired with the `autoconf` rule.

Example:

```python
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:package_info.bzl", "package_info")

package_info(
    name = "package_info",
    module_bazel = "//:MODULE.bazel",
)

autoconf(
    name = "config_h",
    out = "config.h",
    checks = [
        # ...
    ],
    deps = [
        ":package_info",
    ],
)
```
"�
�

package_info�A rule for parsing module info from `MODULE.bazel` files.

This rule is most useful when paired with the `autoconf` rule.

Example:

```python
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:package_info.bzl", "package_info")

package_info(
    name = "package_info",
    module_bazel = "//:MODULE.bazel",
)

autoconf(
    name = "config_h",
    out = "config.h",
    checks = [
        # ...
    ],
    deps = [
        ":package_info",
    ],
)
```
*
nameA unique name for this target. �
module_bazeluA `MODULE.bazel` file to parse module information from. Mutually exclusive with `package_name` and `package_version`.2Nonei
package_bugreportNThe package bug report email/URL. Used to populate `PACKAGE_BUGREPORT` define.2""{
package_nameeThe package name. Must be provided together with `package_version` if `module_bazel` is not provided.2""J
package_tarname1Exactly tarname, possibly generated from package.2""V
package_urlAThe package home page URL. Used to populate `PACKAGE_URL` define.2""~
package_versioneThe package version. Must be provided together with `package_name` if `module_bazel` is not provided.2"""6
package_info&@@rules_cc_autoconf//autoconf:defs.bzl
}},
*
nameA unique name for this target. �
�
module_bazeluA `MODULE.bazel` file to parse module information from. Mutually exclusive with `package_name` and `package_version`.2Nonek
i
package_bugreportNThe package bug report email/URL. Used to populate `PACKAGE_BUGREPORT` define.2""}
{
package_nameeThe package name. Must be provided together with `package_version` if `module_bazel` is not provided.2""L
J
package_tarname1Exactly tarname, possibly generated from package.2""X
V
package_urlAThe package home page URL. Used to populate `PACKAGE_URL` define.2""�
~
package_versioneThe package version. Must be provided together with `package_name` if `module_bazel` is not provided.2""}
//autoconf:autoconf.bzlr`
+
rules_cc_autoconfautoconfautoconf.bzl#
autoconf	_autoconf

�
//autoconf:autoconf_hdr.bzlrl
/
rules_cc_autoconfautoconfautoconf_hdr.bzl+
autoconf_hdr_autoconf_hdr



�
//autoconf:autoconf_srcs.bzlro
0
rules_cc_autoconfautoconfautoconf_srcs.bzl-
autoconf_srcs_autoconf_srcs

�
//autoconf:checks.bzlr{
)
rules_cc_autoconfautoconf
checks.bzl
checks_checks

macros_macros

�
//autoconf:package_info.bzlrl
/
rules_cc_autoconfautoconfpackage_info.bzl+
package_info_package_info

# rules_cc_autoconf
�
/
rules_cc_autoconfautoconfpackage_info.bzl�package_info�A rule for parsing module info from `MODULE.bazel` files.

This rule is most useful when paired with the `autoconf` rule.

Example:

```python
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:package_info.bzl", "package_info")

package_info(
    name = "package_info",
    module_bazel = "//:MODULE.bazel",
)

autoconf(
    name = "config_h",
    out = "config.h",
    checks = [
        # ...
    ],
    deps = [
        ":package_info",
    ],
)
```
"�
�

package_info�A rule for parsing module info from `MODULE.bazel` files.

This rule is most useful when paired with the `autoconf` rule.

Example:

```python
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:package_info.bzl", "package_info")

package_info(
    name = "package_info",
    module_bazel = "//:MODULE.bazel",
)

autoconf(
    name = "config_h",
    out = "config.h",
    checks = [
        # ...
    ],
    deps = [
        ":package_info",
    ],
)
```
*
nameA unique name for this target. �
module_bazeluA `MODULE.bazel` file to parse module information from. Mutually exclusive with `package_name` and `package_version`.2Nonei
package_bugreportNThe package bug report email/URL. Used to populate `PACKAGE_BUGREPORT` define.2""{
package_nameeThe package name. Must be provided together with `package_version` if `module_bazel` is not provided.2""J
package_tarname1Exactly tarname, possibly generated from package.2""V
package_urlAThe package home page URL. Used to populate `PACKAGE_URL` define.2""~
package_versioneThe package version. Must be provided together with `package_name` if `module_bazel` is not provided.2""">
package_info.@@rules_cc_autoconf//autoconf:package_info.bzl
}},
*
nameA unique name for this target. �
�
module_bazeluA `MODULE.bazel` file to parse module information from. Mutually exclusive with `package_name` and `package_version`.2Nonek
i
package_bugreportNThe package bug report email/URL. Used to populate `PACKAGE_BUGREPORT` define.2""}
{
package_nameeThe package name. Must be provided together with `package_version` if `module_bazel` is not provided.2""L
J
package_tarname1Exactly tarname, possibly generated from package.2""X
V
package_urlAThe package home page URL. Used to populate `PACKAGE_URL` define.2""�
~
package_versioneThe package version. Must be provided together with `package_name` if `module_bazel` is not provided.2""�
 //autoconf/private:providers.bzlrt
4
rules_cc_autoconfautoconf/privateproviders.bzl.
CcAutoconfInfoCcAutoconfInfo
=K
M# package_info�
+
rules_cc_autoconfgnulib/testsdeps.bzl�gnulib+rules_cc_autoconf gnulib test dependencies.J{
k
gnulib+rules_cc_autoconf gnulib test dependencies."4
gnulib*@@rules_cc_autoconf//gnulib/tests:deps.bzl
$$�
 //tools/build_defs/repo:http.bzlrj
.
bazel_toolstools/build_defs/repohttp.bzl*
http_archivehttp_archive
7C
EGnulib test deps�
A
rules_cc_autoconfgnulib/testsgnu_gnulib_diff_test_suite.bzl�gnu_gnulib_diff_test_suite�Complete test suite for a gnulib module.

This creates:
1. gnu_autoconf test - Runs GNU autoconf and compares with golden
2. bazel_config_diff - Compares Bazel-generated config.h with golden
3. bazel_gnulib_diff - Compares Bazel-generated gnulib_*.h with golden
4. compile test - Verifies golden headers compile
5. Test suite combining all above

Golden files can be specified as either:
- A simple Label (same golden for all platforms)
- A dict with platform keys: {"linux": "golden_linux.h.in", "macos": "golden_macos.h.in", ...}

Valid platform keys:
- "linux": Only runs on Linux
- "macos": Only runs on macOS
- "windows": Only runs on Windows
- "unix": Runs on all non-Windows platforms (Linux, macOS, BSD, etc.)

When using dict golden files, a single test target is created per test type; the
golden file is chosen via select(). If only linux and/or macos are specified
(no windows), target_compatible_with is set so the test does not run on Windows.
*�
�
gnu_gnulib_diff_test_suite>
name2Name of the test suite (typically "{module}_test") (D
configure_ac0The configure.ac file specific to this m4 module (D
m4_files4ALL m4 files needed to run autoconf (including deps) (;
config_h_in(Template for AC_DEFINE (#undef patterns) (8

subst_h_in&Template for AC_SUBST (@FOO@ patterns) ([
golden_config_hDExpected config.h output.
Can be a Label or dict with platform keys. (\
golden_subst_hFExpected gnulib_*.h output.
Can be a Label or dict with platform keys. (H
bazel_autoconf_target+The autoconf target from //gnulib/m4/{name} (3
test_c%C file to compile with golden headers (V
	aux_filesCAuxiliary files (e.g., config.rpath) to copy to work directory root[](1
sizeTest size (default: "medium")"medium"(
tags	Test tags[]( 
kwargsAdditional arguments(�Complete test suite for a gnulib module.

This creates:
1. gnu_autoconf test - Runs GNU autoconf and compares with golden
2. bazel_config_diff - Compares Bazel-generated config.h with golden
3. bazel_gnulib_diff - Compares Bazel-generated gnulib_*.h with golden
4. compile test - Verifies golden headers compile
5. Test suite combining all above

Golden files can be specified as either:
- A simple Label (same golden for all platforms)
- A dict with platform keys: {"linux": "golden_linux.h.in", "macos": "golden_macos.h.in", ...}

Valid platform keys:
- "linux": Only runs on Linux
- "macos": Only runs on macOS
- "windows": Only runs on Windows
- "unix": Runs on all non-Windows platforms (Linux, macOS, BSD, etc.)

When using dict golden files, a single test target is created per test type; the
golden file is chosen via select(). If only linux and/or macos are specified
(no windows), target_compatible_with is set so the test does not run on Windows.
2^
gnu_gnulib_diff_test_suite@@@rules_cc_autoconf//gnulib/tests:gnu_gnulib_diff_test_suite.bzl
"autoconf_hdr*native.test_suite2gnu_autoconf_configure_test2autoconf_hdr2autoconf_hdr2cc_test2native.test_suitec
//cc:cc_test.bzlrM

rules_cccccc_test.bzl 
cc_testcc_test
$+
-�
//autoconf:autoconf_hdr.bzlrk
/
rules_cc_autoconfautoconfautoconf_hdr.bzl*
autoconf_hdrautoconf_hdr
	8	D
		F�
//autoconf/tests:diff_test.bzlrh
2
rules_cc_autoconfautoconf/testsdiff_test.bzl$
	diff_test	diff_test

;
D


F�
0//autoconf/tests:gnu_autoconf_configure_test.bzlr�
D
rules_cc_autoconfautoconf/testsgnu_autoconf_configure_test.bzlH
gnu_autoconf_configure_testgnu_autoconf_configure_test
Mh
j�Macros for testing gnulib m4 files against golden outputs.

This module provides:
- gnu_gnulib_diff_test: Single test comparing GNU autoconf output with golden files
- gnu_gnulib_diff_test_suite: Complete test suite for a gnulib module
�
'
rules_cc_autoconfgnulib
macros.bzl}
//autoconf:checks.bzlrb
)
rules_cc_autoconfautoconf
checks.bzl'
checksautoconf_checks
1@
L�# gnulib macros

Common gnulib macro patterns as Bazel wrappers.

These macros encapsulate common patterns from gnulib's m4 files, making it
easier to port modules while maintaining consistency with gnulib behavior.
�
/
rules_cc_autoconftools/cxxoptscxxopts.bzl�cxxopts6Returns a select statement for C++17 compiler options.*�
�
cxxopts6Returns a select statement for C++17 compiler options."I
GA select statement suitable for use in cc_library or cc_binary cxxopts.29
cxxopts.@@rules_cc_autoconf//tools/cxxopts:cxxopts.bzl
�linkopts2Returns a select statement for C++17 link options.*�
�
linkopts2Returns a select statement for C++17 link options."J
HA select statement suitable for use in cc_library or cc_binary linkopts.2:
linkopts.@@rules_cc_autoconf//tools/cxxopts:cxxopts.bzl
(C++ compiler options for autoconf tools.�	
9
rules_cc_autoconftools/queryresult_query_aspect.bzl�ResultQueryInfo3Transitive collection of autoconf result DAG nodes.2�
�
ResultQueryInfo3Transitive collection of autoconf result DAG nodes.i

node_jsons[depset[string]: JSON-encoded node descriptors for every CcAutoconfInfo target in the graph.]
result_filesMdepset[File]: All result files in the transitive closure (so they get built)."K
ResultQueryInfo8@@rules_cc_autoconf//tools/query:result_query_aspect.bzl
k
i

node_jsons[depset[string]: JSON-encoded node descriptors for every CcAutoconfInfo target in the graph._
]
result_filesMdepset[File]: All result files in the transitive closure (so they get built).�result_query_aspect:�
�
result_query_aspectdeps"*
nameA unique name for this target. *O
result_query_aspect8@@rules_cc_autoconf//tools/query:result_query_aspect.bzl
II,
*
nameA unique name for this target. �
 //autoconf/private:providers.bzlrt
4
rules_cc_autoconfautoconf/privateproviders.bzl.
CcAutoconfInfoCcAutoconfInfo
=K
M.Aspect for collecting the autoconf result DAG.Z
 
rules_cc_autoconfversion.bzl	VERSION0.5.5j0.5.5rules_cc_autoconf version 