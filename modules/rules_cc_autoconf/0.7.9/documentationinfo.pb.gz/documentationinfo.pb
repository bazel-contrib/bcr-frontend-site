�
+
rules_cc_autoconfautoconfautoconf.bzl�autoconf�Run autoconf-like checks and produce results.

This rule resolves the ``autoconf_toolchain`` (when registered) to skip redundant
checker actions.  If a check's cache variable name already has a result in the
toolchain or in transitive ``deps``, the existing result file is reused.

Use ``autoconf_library`` instead for targets that feed into ``autoconf_toolchain``
to avoid a dependency cycle.

Example:

```python
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")

autoconf(
    name = "config",
    checks = [
        checks.AC_CHECK_HEADER("stdio.h"),
        checks.AC_CHECK_HEADER("stdlib.h"),
        checks.AC_CHECK_FUNC("printf"),
    ],
)
```

The results can then be used by `autoconf_hdr` or `autoconf_srcs` to generate headers
or wrapped source files.
"�

�
autoconf�Run autoconf-like checks and produce results.

This rule resolves the ``autoconf_toolchain`` (when registered) to skip redundant
checker actions.  If a check's cache variable name already has a result in the
toolchain or in transitive ``deps``, the existing result file is reused.

Use ``autoconf_library`` instead for targets that feed into ``autoconf_toolchain``
to avoid a dependency cycle.

Example:

```python
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")

autoconf(
    name = "config",
    checks = [
        checks.AC_CHECK_HEADER("stdio.h"),
        checks.AC_CHECK_HEADER("stdlib.h"),
        checks.AC_CHECK_FUNC("printf"),
    ],
)
```

The results can then be used by `autoconf_hdr` or `autoconf_srcs` to generate headers
or wrapped source files.
*
nameA unique name for this target. d
checksTList of JSON-encoded checks from checks (e.g., `checks.AC_CHECK_HEADER('stdio.h')`).2[]j
depsJAdditional `autoconf`, `autoconf_library`, or `package_info` dependencies.*
CcAutoconfInfo2[]"6
autoconf*@@rules_cc_autoconf//autoconf:autoconf.bzl
��,
*
nameA unique name for this target. f
d
checksTList of JSON-encoded checks from checks (e.g., `checks.AC_CHECK_HEADER('stdio.h')`).2[]l
j
depsJAdditional `autoconf`, `autoconf_library`, or `package_info` dependencies.*
CcAutoconfInfo2[]�
'//autoconf/private:autoconf_library.bzlrp
;
rules_cc_autoconfautoconf/privateautoconf_library.bzl#
autoconf	_autoconf


# autoconf�
@
rules_cc_autoconfautoconf/macros/AC_C_RESTRICTrestrict.bzl�ac_c_restrict�Detect the C restrict keyword variant supported by the compiler.

Implements the GNU autoconf AC_C_RESTRICT fallback chain. Tries the bare
`restrict` keyword first (C99), then `__restrict__` (GCC/Clang), then
`__restrict` (MSVC). If none compile, defines `restrict` to empty.

Returns a CcAutoconfInfo provider with the `restrict` define result,
compatible with the standard `autoconf` rule for use as a dependency.
"�
�
ac_c_restrict�Detect the C restrict keyword variant supported by the compiler.

Implements the GNU autoconf AC_C_RESTRICT fallback chain. Tries the bare
`restrict` keyword first (C99), then `__restrict__` (GCC/Clang), then
`__restrict` (MSVC). If none compile, defines `restrict` to empty.

Returns a CcAutoconfInfo provider with the `restrict` define result,
compatible with the standard `autoconf` rule for use as a dependency.
*
nameA unique name for this target. "P
ac_c_restrict?@@rules_cc_autoconf//autoconf/macros/AC_C_RESTRICT:restrict.bzl
��,
*
nameA unique name for this target. �
//cc:find_cc_toolchain.bzlri
%
rules_ccccfind_cc_toolchain.bzl2
use_cc_toolchainuse_cc_toolchain
.>
@�
//autoconf:cc_autoconf_info.bzlrs
3
rules_cc_autoconfautoconfcc_autoconf_info.bzl.
CcAutoconfInfoCcAutoconfInfo
<J
L�
&//autoconf/private:autoconf_config.bzlr�
:
rules_cc_autoconfautoconf/privateautoconf_config.bzl6
create_config_dictcreate_config_dict
<
get_cc_toolchain_infoget_cc_toolchain_info
D
get_environment_variablesget_environment_variables
4
write_config_jsonwrite_config_json

�Custom rule for AC_C_RESTRICT keyword detection.

Implements the GNU autoconf AC_C_RESTRICT fallback chain:
  1. restrict      â C99 keyword (no #define needed if it works)
  2. __restrict__  â GCC/Clang extension
  3. __restrict    â MSVC extension
  4. (none)        â #define restrict to empty

This cannot be expressed with the core `autoconf` rule because the fallback
chain requires multiple compile checks that resolve to a single define, and
the core rule rejects duplicate defines for the same name.

The rule uses the standard checker binary for the individual compile checks
and a dedicated resolver tool to combine the results.
�>
:
rules_cc_autoconfautoconf/privateautoconf_config.bzl�collect_deps+Collect `CcAutoconfInfo` from dependencies.*�
�
collect_deps
depsA list of `Target` (+Collect `CcAutoconfInfo` from dependencies."'
%depset: A depset of `CcAutoconfInfo`.2I
collect_deps9@@rules_cc_autoconf//autoconf/private:autoconf_config.bzl
���collect_transitive_results*Collect transitive cache variable results.*�
�
collect_transitive_results,
	dep_infosA list of `CcAutoconfInfo`. (*Collect transitive cache variable results."�
�dict: A mapping with keys "cache", "content_cache", "define", "subst"
(each dict[str, File]) and "unquoted_defines" (list[str]).2W
collect_transitive_results9@@rules_cc_autoconf//autoconf/private:autoconf_config.bzl
���create_config_dict3Create a config dictionary for the autoconf runner.*�
�
create_config_dict:
toolchain_info$Struct from get_cc_toolchain_info(). (3Create a config dictionary for the autoconf runner."0
.A dictionary representing the autoconf config.2O
create_config_dict9@@rules_cc_autoconf//autoconf/private:autoconf_config.bzl
���encode_result�Encode a value as a flat result JSON string.

Returns the content for a result file that can be referenced from
``CcAutoconfInfo``.  Using this function insulates callers from the
internal result-file schema.
*�
�
encode_result�
value�The result value.  Strings are JSON-encoded (quoted in the
output); numbers and booleans are stored as their JSON
representation.  Use ``None`` for a valueless define
(``#define FOO`` with no value). (�
success�Whether the check succeeded.  Defaults to ``True``.
A result with ``success=False`` is rendered as
``/* #undef FOO */`` in the generated header.True(�Encode a value as a flat result JSON string.

Returns the content for a result file that can be referenced from
``CcAutoconfInfo``.  Using this function insulates callers from the
internal result-file schema.
"3
1A JSON string suitable for ``ctx.actions.write``.2J
encode_result9@@rules_cc_autoconf//autoconf/private:autoconf_config.bzl
�filter_defaults9Filter toolchain defaults based on include/exclude lists.*�
�
filter_defaultse
defaults_by_labelLMapping of Label -> struct(cache=..., define=..., subst=...) from toolchain. (�
include_labels�If non-empty, only include defaults from these labels.
An error is raised if a label is specified but not found in the toolchain. (
exclude_labelsiIf non-empty, exclude defaults from these labels.
Labels not found in the toolchain are silently ignored. (9Filter toolchain defaults based on include/exclude lists."x
vstruct: A struct with `cache`, `define`, and `subst` fields, each containing
a merged dict[str, File] after filtering.2L
filter_defaults9@@rules_cc_autoconf//autoconf/private:autoconf_config.bzl
nn�get_autoconf_toolchain_cache�Get the content-based cache from the autoconf toolchain.

Returns the unified content cache from both ``cache_deps`` and ``defaults``
on the toolchain.  Used by the ``autoconf`` rule for content-based action
deduplication.
*�
�
get_autoconf_toolchain_cacheG
ctx<The rule context (must declare the autoconf toolchain type). (�Get the content-based cache from the autoconf toolchain.

Returns the unified content cache from both ``cache_deps`` and ``defaults``
on the toolchain.  Used by the ``autoconf`` rule for content-based action
deduplication.
"e
cdict[str, File]: Mapping of content keys to result files.
Empty dict if no toolchain is configured.2Y
get_autoconf_toolchain_cache9@@rules_cc_autoconf//autoconf/private:autoconf_config.bzl
%%�get_autoconf_toolchain_defaults�Get default checks from the autoconf toolchain if available.

Returns only the ``defaults`` portion of the toolchain (not ``cache_deps``).
Used by ``autoconf_hdr`` for rendering baseline values.
*�
�
get_autoconf_toolchain_defaults
ctxThe rule context. (�Get default checks from the autoconf toolchain if available.

Returns only the ``defaults`` portion of the toolchain (not ``cache_deps``).
Used by ``autoconf_hdr`` for rendering baseline values.
"�
�struct: A struct with `cache`, `define`, and `subst` fields, each containing
a dict[str, File] mapping variable names to result files.
Returns struct(cache={}, define={}, subst={}) if no toolchain is configured.2\
get_autoconf_toolchain_defaults9@@rules_cc_autoconf//autoconf/private:autoconf_config.bzl
99�(get_autoconf_toolchain_defaults_by_labelJGet default checks from the autoconf toolchain, organized by source label.*�
�
(get_autoconf_toolchain_defaults_by_label
ctxThe rule context. (JGet default checks from the autoconf toolchain, organized by source label."�
�dict: A mapping of source labels to structs with `cache`, `define`, and `subst` fields,
each containing a dict[str, File]. Returns empty dict if no toolchain is configured.2e
(get_autoconf_toolchain_defaults_by_label9@@rules_cc_autoconf//autoconf/private:autoconf_config.bzl
XX�get_cc_toolchain_info8Get cc_toolchain information for autoconf configuration.*�
�
get_cc_toolchain_info
ctxThe rule context. (8Get cc_toolchain information for autoconf configuration."�
�A struct containing:
- cc_toolchain: The cc_toolchain
- feature_configuration: The feature configuration
- c_compiler_path: Path to C compiler
- cpp_compiler_path: Path to C++ compiler
- linker_path: Path to linker
- c_flags: List of C compiler flags
- cpp_flags: List of C++ compiler flags
- c_link_flags: List of C linker flags
- cpp_link_flags: List of C++ linker flags
- compiler_type: The compiler type2R
get_cc_toolchain_info9@@rules_cc_autoconf//autoconf/private:autoconf_config.bzl
���get_environment_variables6Get environment variables for running autoconf checks.*�
�
get_environment_variables
ctxThe rule context. (:
toolchain_info$Struct from get_cc_toolchain_info(). (6Get environment variables for running autoconf checks."(
&A dictionary of environment variables.2V
get_environment_variables9@@rules_cc_autoconf//autoconf/private:autoconf_config.bzl
���merge_with_defaults�Merge check results with toolchain defaults.

Results from actual targets take precedence over defaults - any variable
present in both will use the result value, not the default.
*�
�
merge_with_defaultsF
defaults6Default checks from toolchain (variable name -> File). (B
results3Check results from targets (variable name -> File). (�Merge check results with toolchain defaults.

Results from actual targets take precedence over defaults - any variable
present in both will use the result value, not the default.
"8
6dict: Merged results with targets overriding defaults.2P
merge_with_defaults9@@rules_cc_autoconf//autoconf/private:autoconf_config.bzl
���write_config_json)Write a config dictionary to a JSON file.*�
�
write_config_json
ctxThe rule context. (C
config_dict0The config dictionary from create_config_dict(). ()Write a config dictionary to a JSON file."+
)A File representing the config JSON file.2N
write_config_json9@@rules_cc_autoconf//autoconf/private:autoconf_config.bzl
��w
//cc:action_names.bzlr\
 
rules_ccccaction_names.bzl*
ACTION_NAMESACTION_NAMES
)5
7�
//cc:find_cc_toolchain.bzlrm
%
rules_ccccfind_cc_toolchain.bzl6
find_cpp_toolchainfind_cpp_toolchain
.@
By
//cc/common:cc_common.bzlrZ
$
rules_cc	cc/commoncc_common.bzl$
	cc_common	cc_common
-6
8�
 //autoconf/private:providers.bzlrt
4
rules_cc_autoconfautoconf/privateproviders.bzl.
CcAutoconfInfoCcAutoconfInfo
	=	K
		M8# autoconf_config

Common utilities for autoconf rules.
�
4
rules_cc_autoconfautoconf/privateproviders.bzl�CcAutoconfInfo9A provider containing autoconf configuration and results.2�
�
CcAutoconfInfo9A provider containing autoconf configuration and results.�
cache_resultsqdict[str, File]: A map of cache variable names to flat result JSON files. Used for requires/condition resolution.�
content_cachewdict[str, File]: A map of content-based keys to result files. Used for action deduplication across deps and toolchains.y
define_resultsgdict[str, File]: A map of define names to flat result JSON files produced by `CcAutoconfCheck` actions.H
deps@depset[CcAutoconfInfo]: Dependencies of the current info target.6
owner-Label: The label of the owner of the results.w
subst_resultsfdict[str, File]: A map of subst names to flat result JSON files produced by `CcAutoconfCheck` actions.b
unquoted_definesNlist[str]: Define names that should be rendered unquoted (AC_DEFINE_UNQUOTED)."E
CcAutoconfInfo3@@rules_cc_autoconf//autoconf/private:providers.bzl
11�
�
cache_resultsqdict[str, File]: A map of cache variable names to flat result JSON files. Used for requires/condition resolution.�
�
content_cachewdict[str, File]: A map of content-based keys to result files. Used for action deduplication across deps and toolchains.{
y
define_resultsgdict[str, File]: A map of define names to flat result JSON files produced by `CcAutoconfCheck` actions.J
H
deps@depset[CcAutoconfInfo]: Dependencies of the current info target.8
6
owner-Label: The label of the owner of the results.y
w
subst_resultsfdict[str, File]: A map of subst names to flat result JSON files produced by `CcAutoconfCheck` actions.d
b
unquoted_definesNlist[str]: Define names that should be rendered unquoted (AC_DEFINE_UNQUOTED).# providers�
J
rules_cc_autoconfautoconf/tests/core/defaultsdefaults_test_suite.bzl�defaults_test_suite3Test suite for autoconf_hdr defaults functionality.*�
�
defaults_test_suite'
nameThe name of the test suite. ()
kwargsAdditional keyword arguments.(3Test suite for autoconf_hdr defaults functionality.2`
defaults_test_suiteI@@rules_cc_autoconf//autoconf/tests/core/defaults:defaults_test_suite.bzl
77"package_info"autoconf_cache"autoconf"autoconf_toolchain"autoconf_hdr"_autoconf_hdr_with_toolchain*native.test_suite2native.test_suitey
//rules:write_file.bzlr]
%
bazel_skylibruleswrite_file.bzl&

write_file
write_file
.8
:|
//autoconf:autoconf.bzlr_
+
rules_cc_autoconfautoconfautoconf.bzl"
autoconfautoconf
4<
>�
//autoconf:autoconf_hdr.bzlrk
/
rules_cc_autoconfautoconfautoconf_hdr.bzl*
autoconf_hdrautoconf_hdr
8D
F�
!//autoconf:autoconf_toolchain.bzlr�
5
rules_cc_autoconfautoconfautoconf_toolchain.bzl.
autoconf_cacheautoconf_cache
	>	L6
autoconf_toolchainautoconf_toolchain
	P	b
		dt
//autoconf:checks.bzlrY
)
rules_cc_autoconfautoconf
checks.bzl
checkschecks

2
8


:�
//autoconf:package_info.bzlrk
/
rules_cc_autoconfautoconfpackage_info.bzl*
package_infopackage_info
8D
F�
//autoconf/tests:diff_test.bzlrh
2
rules_cc_autoconfautoconf/testsdiff_test.bzl$
	diff_test	diff_test
;D
FSdefaults_test_suite

Test suite for verifying autoconf_hdr defaults functionality.
�@
/
rules_cc_autoconfautoconfautoconf_hdr.bzl�;autoconf_hdr�	Generate configuration headers from results provided by `autoconf` targets.

This rule takes check results from `autoconf` targets (via `deps`) and generates a header file.
The template file (if provided) is used to format the output header.

Example:

```python
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:autoconf_hdr.bzl", "autoconf_hdr")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")

autoconf(
    name = "config_checks",
    checks = [
        checks.AC_CHECK_HEADER("stdio.h"),
        checks.AC_CHECK_HEADER("stdlib.h"),
        checks.AC_CHECK_FUNC("printf"),
    ],
)

autoconf_hdr(
    name = "config",
    out = "config.h",
    deps = [":config_checks"],
    template = "config.h.in",
)
```

Valid `mode` values:
- `"defines"` (default): Only process defines (AC_DEFINE, AC_CHECK_*, etc.), not substitution variables (AC_SUBST). This is for config.h files.
- `"subst"`: Only process substitution variables (AC_SUBST), not defines. This is for subst.h files.
- `"all"`: Process both defines and substitution variables.

This allows you to run checks once and generate multiple header files from the same results.
"�1
�
autoconf_hdr�	Generate configuration headers from results provided by `autoconf` targets.

This rule takes check results from `autoconf` targets (via `deps`) and generates a header file.
The template file (if provided) is used to format the output header.

Example:

```python
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:autoconf_hdr.bzl", "autoconf_hdr")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")

autoconf(
    name = "config_checks",
    checks = [
        checks.AC_CHECK_HEADER("stdio.h"),
        checks.AC_CHECK_HEADER("stdlib.h"),
        checks.AC_CHECK_FUNC("printf"),
    ],
)

autoconf_hdr(
    name = "config",
    out = "config.h",
    deps = [":config_checks"],
    template = "config.h.in",
)
```

Valid `mode` values:
- `"defines"` (default): Only process defines (AC_DEFINE, AC_CHECK_*, etc.), not substitution variables (AC_SUBST). This is for config.h files.
- `"subst"`: Only process substitution variables (AC_SUBST), not defines. This is for subst.h files.
- `"all"`: Process both defines and substitution variables.

This allows you to run checks once and generate multiple header files from the same results.
*
nameA unique name for this target. �
defaults�Whether to include toolchain defaults.

When False (the default), no toolchain defaults are included and only
the explicit deps provide check results. When True, defaults from the
autoconf toolchain are included, subject to filtering by defaults_include
or defaults_exclude.2False�
defaults_exclude�Labels to exclude from toolchain defaults.

Only effective when defaults=True. If specified, defaults from these
labels are excluded. Labels not found in the toolchain are silently
ignored. Mutually exclusive with defaults_include.*
CcAutoconfInfo2[]�
defaults_include�Labels to include from toolchain defaults.

Only effective when defaults=True. If specified, only defaults from
these labels are included. An error is raised if a specified label
is not found in the toolchain. Mutually exclusive with defaults_exclude.*
CcAutoconfInfo2[]�
deps�List of `autoconf` targets which provide check results. Results from all deps will be merged together, and duplicate define names will produce an error. If not provided, an empty results file will be created.*
CcAutoconfInfo2[]�
inlines�A mapping of strings to files for replace within the content of the given `template` attribute.

The exact string in the template is replaced with the content of the associated file.
Any `@VAR@` style placeholders in the inline file content will be replaced with their
corresponding define values (package info, check results, etc.) after insertion.	2{}]
modeHProcessing mode that determines what should be replaced within the file.2	"defines"9
out.The output config file (typically `config.h`). �
substitutions�A mapping of exact strings to replacement values.

Each entry performs an exact text replacement in the template - the key
string is replaced with the value string. No special patterns or wrappers
are added.

Example:
```python
autoconf_hdr(
    name = "config",
    out = "config.h",
    template = "config.h.in",
    substitutions = {
        "@MY_VERSION@": "1.2.3",
        "@BUILD_TYPE@": "release",
        "PLACEHOLDER_TEXT": "actual_value",
    },
    deps = [":checks"],
)
```

This would replace the exact string `@MY_VERSION@` with `1.2.3`,
`@BUILD_TYPE@` with `release`, and `PLACEHOLDER_TEXT` with `actual_value`.
2{}�
template�Template file (`config.h.in`) to use as base for generating the header file. The template is used to format the output header, but does not generate any checks. ">
autoconf_hdr.@@rules_cc_autoconf//autoconf:autoconf_hdr.bzl
zz,
*
nameA unique name for this target. �
�
defaults�Whether to include toolchain defaults.

When False (the default), no toolchain defaults are included and only
the explicit deps provide check results. When True, defaults from the
autoconf toolchain are included, subject to filtering by defaults_include
or defaults_exclude.2False�
�
defaults_exclude�Labels to exclude from toolchain defaults.

Only effective when defaults=True. If specified, defaults from these
labels are excluded. Labels not found in the toolchain are silently
ignored. Mutually exclusive with defaults_include.*
CcAutoconfInfo2[]�
�
defaults_include�Labels to include from toolchain defaults.

Only effective when defaults=True. If specified, only defaults from
these labels are included. An error is raised if a specified label
is not found in the toolchain. Mutually exclusive with defaults_exclude.*
CcAutoconfInfo2[]�
�
deps�List of `autoconf` targets which provide check results. Results from all deps will be merged together, and duplicate define names will produce an error. If not provided, an empty results file will be created.*
CcAutoconfInfo2[]�
�
inlines�A mapping of strings to files for replace within the content of the given `template` attribute.

The exact string in the template is replaced with the content of the associated file.
Any `@VAR@` style placeholders in the inline file content will be replaced with their
corresponding define values (package info, check results, etc.) after insertion.	2{}_
]
modeHProcessing mode that determines what should be replaced within the file.2	"defines";
9
out.The output config file (typically `config.h`). �
�
substitutions�A mapping of exact strings to replacement values.

Each entry performs an exact text replacement in the template - the key
string is replaced with the value string. No special patterns or wrappers
are added.

Example:
```python
autoconf_hdr(
    name = "config",
    out = "config.h",
    template = "config.h.in",
    substitutions = {
        "@MY_VERSION@": "1.2.3",
        "@BUILD_TYPE@": "release",
        "PLACEHOLDER_TEXT": "actual_value",
    },
    deps = [":checks"],
)
```

This would replace the exact string `@MY_VERSION@` with `1.2.3`,
`@BUILD_TYPE@` with `release`, and `PLACEHOLDER_TEXT` with `actual_value`.
2{}�
�
template�Template file (`config.h.in`) to use as base for generating the header file. The template is used to format the output header, but does not generate any checks. �
&//autoconf/private:autoconf_config.bzlr�
:
rules_cc_autoconfautoconf/privateautoconf_config.bzl*
collect_depscollect_deps
F
collect_transitive_resultscollect_transitive_results
 0
filter_defaultsfilter_defaults
P
get_autoconf_toolchain_defaultsget_autoconf_toolchain_defaults
%b
(get_autoconf_toolchain_defaults_by_label(get_autoconf_toolchain_defaults_by_label
		.

�
 //autoconf/private:providers.bzlrt
4
rules_cc_autoconfautoconf/privateproviders.bzl.
CcAutoconfInfoCcAutoconfInfo
=K
M# autoconf_hdr�5
0
rules_cc_autoconfautoconfautoconf_srcs.bzl�,autoconf_srcs�
Generate wrapper sources that are conditionally enabled by autoconf results.

Typical use case:

```python
load("@rules_cc_autoconf//autoconf:autoconf_srcs.bzl", "autoconf_srcs")
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")
load("@rules_cc//cc:cc_library.bzl", "cc_library")

autoconf(
    name = "config",
    out = "config.h",
    checks = [
        # Feature is present on this platform/toolchain.
        checks.AC_CHECK_HEADER("foo.h", define = "HAVE_FOO"),
    ],
)

autoconf_srcs(
    name = "foo_srcs",
    deps = [":config"],
    srcs = {
        "uses_foo.c": "HAVE_FOO",
    },
)

cc_library(
    name = "foo",
    srcs = [":foo_srcs"],
    hdrs = [":config.h"],
)
```

In this setup `autoconf_srcs` reads the results from `:config` (or multiple targets via `deps`) and generates a
wrapped copy of `uses_foo.c` whose contents are effectively:

```cc
#define HAVE_FOO 1      // when the check for HAVE_FOO succeeds
/* or: #undef HAVE_FOO  // when the check fails */
#ifdef HAVE_FOO
/* original uses_foo.c contents ... */
#endif
```

This is useful when you have platform-specific or optional sources that should
only be compiled when a particular autoconf check passes, without having to
manually maintain `#ifdef` guards in every source file.
"�"
�
autoconf_srcs�
Generate wrapper sources that are conditionally enabled by autoconf results.

Typical use case:

```python
load("@rules_cc_autoconf//autoconf:autoconf_srcs.bzl", "autoconf_srcs")
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")
load("@rules_cc//cc:cc_library.bzl", "cc_library")

autoconf(
    name = "config",
    out = "config.h",
    checks = [
        # Feature is present on this platform/toolchain.
        checks.AC_CHECK_HEADER("foo.h", define = "HAVE_FOO"),
    ],
)

autoconf_srcs(
    name = "foo_srcs",
    deps = [":config"],
    srcs = {
        "uses_foo.c": "HAVE_FOO",
    },
)

cc_library(
    name = "foo",
    srcs = [":foo_srcs"],
    hdrs = [":config.h"],
)
```

In this setup `autoconf_srcs` reads the results from `:config` (or multiple targets via `deps`) and generates a
wrapped copy of `uses_foo.c` whose contents are effectively:

```cc
#define HAVE_FOO 1      // when the check for HAVE_FOO succeeds
/* or: #undef HAVE_FOO  // when the check fails */
#ifdef HAVE_FOO
/* original uses_foo.c contents ... */
#endif
```

This is useful when you have platform-specific or optional sources that should
only be compiled when a particular autoconf check passes, without having to
manually maintain `#ifdef` guards in every source file.
*
nameA unique name for this target. �
defaults�Whether to include toolchain defaults.

When False (the default), no toolchain defaults are included and only
the explicit deps provide check results. When True, defaults from the
autoconf toolchain are included, subject to filtering by defaults_include
or defaults_exclude.2False�
defaults_exclude�Labels to exclude from toolchain defaults.

Only effective when defaults=True. If specified, defaults from these
labels are excluded. Labels not found in the toolchain are silently
ignored. Mutually exclusive with defaults_include.*
CcAutoconfInfo2[]�
defaults_include�Labels to include from toolchain defaults.

Only effective when defaults=True. If specified, only defaults from
these labels are included. An error is raised if a specified label
is not found in the toolchain. Mutually exclusive with defaults_exclude.*
CcAutoconfInfo2[]�
deps�List of `autoconf` targets which provide defines. Results from all deps will be merged together, and duplicate define names will produce an error. *
CcAutoconfInfo�
naming�How to name generated sources: `package_relative` keeps the original package-relative path, `ac_suffix`
inserts `.ac.` before the final suffix (e.g. `foo.cc -> foo.ac.cc`), and `per_target` prefixes outputs
with `{ctx.label.name}` to namespace them per rule.
2"package_relative"L
srcs@A mapping of source file to define required to compile the file.	 "@
autoconf_srcs/@@rules_cc_autoconf//autoconf:autoconf_srcs.bzl
��,
*
nameA unique name for this target. �
�
defaults�Whether to include toolchain defaults.

When False (the default), no toolchain defaults are included and only
the explicit deps provide check results. When True, defaults from the
autoconf toolchain are included, subject to filtering by defaults_include
or defaults_exclude.2False�
�
defaults_exclude�Labels to exclude from toolchain defaults.

Only effective when defaults=True. If specified, defaults from these
labels are excluded. Labels not found in the toolchain are silently
ignored. Mutually exclusive with defaults_include.*
CcAutoconfInfo2[]�
�
defaults_include�Labels to include from toolchain defaults.

Only effective when defaults=True. If specified, only defaults from
these labels are included. An error is raised if a specified label
is not found in the toolchain. Mutually exclusive with defaults_exclude.*
CcAutoconfInfo2[]�
�
deps�List of `autoconf` targets which provide defines. Results from all deps will be merged together, and duplicate define names will produce an error. *
CcAutoconfInfo�
�
naming�How to name generated sources: `package_relative` keeps the original package-relative path, `ac_suffix`
inserts `.ac.` before the final suffix (e.g. `foo.cc -> foo.ac.cc`), and `per_target` prefixes outputs
with `{ctx.label.name}` to namespace them per rule.
2"package_relative"N
L
srcs@A mapping of source file to define required to compile the file.	 a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.�
//cc:find_cc_toolchain.bzlri
%
rules_ccccfind_cc_toolchain.bzl2
use_cc_toolchainuse_cc_toolchain
.>
@�
&//autoconf/private:autoconf_config.bzlr�
:
rules_cc_autoconfautoconf/privateautoconf_config.bzl*
collect_depscollect_deps
F
collect_transitive_resultscollect_transitive_results
 0
filter_defaultsfilter_defaults
		P
get_autoconf_toolchain_defaultsget_autoconf_toolchain_defaults


%b
(get_autoconf_toolchain_defaults_by_label(get_autoconf_toolchain_defaults_by_label
.
�
&//autoconf/private:condition_utils.bzlr�
:
rules_cc_autoconfautoconf/privatecondition_utils.bzl>
extract_condition_varsextract_condition_vars
CY
[�
 //autoconf/private:providers.bzlrt
4
rules_cc_autoconfautoconf/privateproviders.bzl.
CcAutoconfInfoCcAutoconfInfo
=K
M# autoconf_srcs�M
5
rules_cc_autoconfautoconfautoconf_toolchain.bzl�autoconf_cache�Run autoconf-like checks without resolving the autoconf toolchain.

Identical to ``autoconf`` except that it does **not** resolve the
``autoconf_toolchain``.  Use this rule for targets that are listed as
``cache_deps`` or ``defaults`` of an ``autoconf_toolchain`` -- using the
regular ``autoconf`` rule in that position would create a dependency cycle.

Dep-level caching still applies: if a check's cache variable name already
has a result in transitive ``deps``, the action is skipped.
"�
�
autoconf_cache�Run autoconf-like checks without resolving the autoconf toolchain.

Identical to ``autoconf`` except that it does **not** resolve the
``autoconf_toolchain``.  Use this rule for targets that are listed as
``cache_deps`` or ``defaults`` of an ``autoconf_toolchain`` -- using the
regular ``autoconf`` rule in that position would create a dependency cycle.

Dep-level caching still applies: if a check's cache variable name already
has a result in transitive ``deps``, the action is skipped.
*
nameA unique name for this target. d
checksTList of JSON-encoded checks from checks (e.g., `checks.AC_CHECK_HEADER('stdio.h')`).2[]j
depsJAdditional `autoconf`, `autoconf_library`, or `package_info` dependencies.*
CcAutoconfInfo2[]"F
autoconf_cache4@@rules_cc_autoconf//autoconf:autoconf_toolchain.bzl
��,
*
nameA unique name for this target. f
d
checksTList of JSON-encoded checks from checks (e.g., `checks.AC_CHECK_HEADER('stdio.h')`).2[]l
j
depsJAdditional `autoconf`, `autoconf_library`, or `package_info` dependencies.*
CcAutoconfInfo2[]�9autoconf_toolchain�Define an autoconf toolchain providing cached check results and rendering defaults.

The toolchain has two separate concepts:

- **cache_deps**: Check results available for action deduplication. When an
  `autoconf` target lists a check whose cache variable name already has a result
  in `cache_deps`, the checker action is skipped and the existing result file is
  reused.
- **defaults**: Baseline values for `autoconf_hdr` rendering. When
  `autoconf_hdr` has `defaults = True`, these values are merged into the
  generated header.

Both `cache_deps` and `defaults` contribute to the unified cache used by the
`autoconf` rule for action deduplication. Only `defaults` contributes to the
`defaults_by_label` map used by `autoconf_hdr` for include/exclude filtering.

Targets listed in `cache_deps` and `defaults` must use `autoconf_library`
(not `autoconf`) to avoid a dependency cycle.

Example:

```python
load("@rules_cc_autoconf//autoconf:defs.bzl", "autoconf_cache", "autoconf_toolchain")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")

autoconf_cache(
    name = "gnulib_defaults",
    checks = [
        checks.AC_SUBST("GNULIB_VFPRINTF_POSIX", "0"),
        checks.AC_SUBST("REPLACE_POSIX_SPAWN", "0"),
    ],
)

autoconf_toolchain(
    name = "gnulib_toolchain_impl",
    defaults = [":gnulib_defaults"],
)

toolchain(
    name = "gnulib_toolchain",
    toolchain = ":gnulib_toolchain_impl",
    toolchain_type = "@rules_cc_autoconf//autoconf:toolchain_type",
)
```

## Caching behavior

### Content-key deduplication

Every check is fingerprinted by a **content key** derived from its
implementation fields: `type`, `code`, `language`, `define_value`,
`includes`, `libraries`, `requires`, `condition`, `compile_defines`,
and similar. Consumer metadata (`name`, `define`, `subst`, `unquote`)
is **excluded**, so two checks with different consumer names but
identical implementations share one content key and produce a single
checker action and result file.

When a new check is processed, its content key is looked up in order:

1. Transitive deps' `content_cache`
2. Toolchain unified cache (`cache_deps` + `defaults`)
3. Current target's local `content_cache`

If a hit is found at any level the existing result file is reused and
no new checker action is declared. Identical checks within the same
target are idempotent (silently skipped on second occurrence).

### Conflict detection

Three layers, from strictest to most relaxed:

- **Within one target** -- duplicate `define` or `subst` symbol names
  in the same `checks` list always fail, even if the content keys
  match. This prevents accidental duplication in a single target.
- **Local vs dependencies / deps vs deps** -- the same symbol
  appearing with a **different result file** is an error, **unless**
  both files share the same content key (a benign duplicate from
  identical implementations).
- **Cache variable names** (`cache_results`) have no cross-dep
  conflict detection; content-based dedup is the identity signal.

### Resolving conflicts

The typical fix for *"Define 'X' is defined both locally and in
dependencies with different result files"*:

- Remove the local check and depend on the target that already
  provides it.
- Or factor the shared check into its own `autoconf` /
  `autoconf_cache` target and depend on it from both consumers.
"�
�
autoconf_toolchain�Define an autoconf toolchain providing cached check results and rendering defaults.

The toolchain has two separate concepts:

- **cache_deps**: Check results available for action deduplication. When an
  `autoconf` target lists a check whose cache variable name already has a result
  in `cache_deps`, the checker action is skipped and the existing result file is
  reused.
- **defaults**: Baseline values for `autoconf_hdr` rendering. When
  `autoconf_hdr` has `defaults = True`, these values are merged into the
  generated header.

Both `cache_deps` and `defaults` contribute to the unified cache used by the
`autoconf` rule for action deduplication. Only `defaults` contributes to the
`defaults_by_label` map used by `autoconf_hdr` for include/exclude filtering.

Targets listed in `cache_deps` and `defaults` must use `autoconf_library`
(not `autoconf`) to avoid a dependency cycle.

Example:

```python
load("@rules_cc_autoconf//autoconf:defs.bzl", "autoconf_cache", "autoconf_toolchain")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")

autoconf_cache(
    name = "gnulib_defaults",
    checks = [
        checks.AC_SUBST("GNULIB_VFPRINTF_POSIX", "0"),
        checks.AC_SUBST("REPLACE_POSIX_SPAWN", "0"),
    ],
)

autoconf_toolchain(
    name = "gnulib_toolchain_impl",
    defaults = [":gnulib_defaults"],
)

toolchain(
    name = "gnulib_toolchain",
    toolchain = ":gnulib_toolchain_impl",
    toolchain_type = "@rules_cc_autoconf//autoconf:toolchain_type",
)
```

## Caching behavior

### Content-key deduplication

Every check is fingerprinted by a **content key** derived from its
implementation fields: `type`, `code`, `language`, `define_value`,
`includes`, `libraries`, `requires`, `condition`, `compile_defines`,
and similar. Consumer metadata (`name`, `define`, `subst`, `unquote`)
is **excluded**, so two checks with different consumer names but
identical implementations share one content key and produce a single
checker action and result file.

When a new check is processed, its content key is looked up in order:

1. Transitive deps' `content_cache`
2. Toolchain unified cache (`cache_deps` + `defaults`)
3. Current target's local `content_cache`

If a hit is found at any level the existing result file is reused and
no new checker action is declared. Identical checks within the same
target are idempotent (silently skipped on second occurrence).

### Conflict detection

Three layers, from strictest to most relaxed:

- **Within one target** -- duplicate `define` or `subst` symbol names
  in the same `checks` list always fail, even if the content keys
  match. This prevents accidental duplication in a single target.
- **Local vs dependencies / deps vs deps** -- the same symbol
  appearing with a **different result file** is an error, **unless**
  both files share the same content key (a benign duplicate from
  identical implementations).
- **Cache variable names** (`cache_results`) have no cross-dep
  conflict detection; content-based dedup is the identity signal.

### Resolving conflicts

The typical fix for *"Define 'X' is defined both locally and in
dependencies with different result files"*:

- Remove the local check and depend on the target that already
  provides it.
- Or factor the shared check into its own `autoconf` /
  `autoconf_cache` target and depend on it from both consumers.
*
nameA unique name for this target. 

cache_depsYTargets whose check results are available for action deduplication in `autoconf` targets.*
CcAutoconfInfo2[]o
defaultsKTargets whose results provide baseline values for `autoconf_hdr` rendering.*
CcAutoconfInfo2[]"J
autoconf_toolchain4@@rules_cc_autoconf//autoconf:autoconf_toolchain.bzl
55,
*
nameA unique name for this target. �


cache_depsYTargets whose check results are available for action deduplication in `autoconf` targets.*
CcAutoconfInfo2[]q
o
defaultsKTargets whose results provide baseline values for `autoconf_hdr` rendering.*
CcAutoconfInfo2[]�
//cc:find_cc_toolchain.bzlri
%
rules_ccccfind_cc_toolchain.bzl2
use_cc_toolchainuse_cc_toolchain
.>
@�
&//autoconf/private:autoconf_config.bzlr�
:
rules_cc_autoconfautoconf/privateautoconf_config.bzl*
collect_depscollect_deps
COF
collect_transitive_resultscollect_transitive_results
Sm
o�
'//autoconf/private:autoconf_library.bzlr�
;
rules_cc_autoconfautoconf/privateautoconf_library.bzl*
COMMON_ATTRSCOMMON_ATTRS
DP:
autoconf_impl_commonautoconf_impl_common
Th
j�
 //autoconf/private:providers.bzlrt
4
rules_cc_autoconfautoconf/privateproviders.bzl.
CcAutoconfInfoCcAutoconfInfo
	=	K
		MXautoconf_toolchain

Provides default autoconf checks that can be overridden by targets.
�
3
rules_cc_autoconfautoconfcc_autoconf_info.bzl�encode_result�Encode a value as a flat result JSON string.

Returns the content for a result file that can be referenced from
``CcAutoconfInfo``.  Using this function insulates callers from the
internal result-file schema.
*�
�
encode_result�
value�The result value.  Strings are JSON-encoded (quoted in the
output); numbers and booleans are stored as their JSON
representation.  Use ``None`` for a valueless define
(``#define FOO`` with no value). (�
success�Whether the check succeeded.  Defaults to ``True``.
A result with ``success=False`` is rendered as
``/* #undef FOO */`` in the generated header.True(�Encode a value as a flat result JSON string.

Returns the content for a result file that can be referenced from
``CcAutoconfInfo``.  Using this function insulates callers from the
internal result-file schema.
"3
1A JSON string suitable for ``ctx.actions.write``.2J
encode_result9@@rules_cc_autoconf//autoconf/private:autoconf_config.bzl
�CcAutoconfInfo9A provider containing autoconf configuration and results.2�
�
CcAutoconfInfo9A provider containing autoconf configuration and results.�
cache_resultsqdict[str, File]: A map of cache variable names to flat result JSON files. Used for requires/condition resolution.�
content_cachewdict[str, File]: A map of content-based keys to result files. Used for action deduplication across deps and toolchains.y
define_resultsgdict[str, File]: A map of define names to flat result JSON files produced by `CcAutoconfCheck` actions.H
deps@depset[CcAutoconfInfo]: Dependencies of the current info target.6
owner-Label: The label of the owner of the results.w
subst_resultsfdict[str, File]: A map of subst names to flat result JSON files produced by `CcAutoconfCheck` actions.b
unquoted_definesNlist[str]: Define names that should be rendered unquoted (AC_DEFINE_UNQUOTED)."D
CcAutoconfInfo2@@rules_cc_autoconf//autoconf:cc_autoconf_info.bzl
11�
�
cache_resultsqdict[str, File]: A map of cache variable names to flat result JSON files. Used for requires/condition resolution.�
�
content_cachewdict[str, File]: A map of content-based keys to result files. Used for action deduplication across deps and toolchains.{
y
define_resultsgdict[str, File]: A map of define names to flat result JSON files produced by `CcAutoconfCheck` actions.J
H
deps@depset[CcAutoconfInfo]: Dependencies of the current info target.8
6
owner-Label: The label of the owner of the results.y
w
subst_resultsfdict[str, File]: A map of subst names to flat result JSON files produced by `CcAutoconfCheck` actions.d
b
unquoted_definesNlist[str]: Define names that should be rendered unquoted (AC_DEFINE_UNQUOTED).�
&//autoconf/private:autoconf_config.bzlry
:
rules_cc_autoconfautoconf/privateautoconf_config.bzl-
encode_result_encode_result

�
 //autoconf/private:providers.bzlru
4
rules_cc_autoconfautoconf/privateproviders.bzl/
CcAutoconfInfo_CcAutoconfInfo

�# CcAutoconfInfo

Public API for external rules that produce autoconf-compatible check results.

The ``CcAutoconfInfo`` provider constructor accepts defaults for every field
except ``owner``, so callers only need to supply the fields they care about:

```python
load("@rules_cc_autoconf//autoconf:cc_autoconf_info.bzl",
     "CcAutoconfInfo", "encode_result")

def _my_rule_impl(ctx):
    result = ctx.actions.declare_file("{}/MY_DEFINE.result.json".format(ctx.label.name))
    ctx.actions.write(output = result, content = encode_result("hello"))
    return [CcAutoconfInfo(owner = ctx.label, define_results = {"MY_DEFINE": result})]
```
�
)
rules_cc_autoconfautoconf
checks.bzl�
!//autoconf/private:check_info.bzlrm
5
rules_cc_autoconfautoconf/privatecheck_info.bzl&

make_check
make_check
T>TH
TTJ�# checks

This module provides Bazel macros that mirror GNU Autoconf's behavior.

## Cache Variables, Defines, and Subst Values

Checks (AC_CHECK_FUNC, AC_CHECK_HEADER, etc.) create cache variables by default, following
autoconf's naming convention:
- AC_CHECK_HEADER("foo.h") -> cache variable "ac_cv_header_foo_h"
- AC_CHECK_FUNC("foo") -> cache variable "ac_cv_func_foo"
- AC_CHECK_DECL("foo") -> cache variable "ac_cv_have_decl_foo"

Defines and subst values are created explicitly using AC_DEFINE and AC_SUBST.

## Condition Resolution

When AC_DEFINE or AC_SUBST use a `condition` parameter that references a cache variable
(e.g., `condition="ac_cv_header_foo_h"`), the condition is evaluated as a **truthy check**:

- Condition is `true` if:
  - The cache variable exists (check was run)
  - The check succeeded (success = true)
  - The value is truthy (non-empty string, not "0")

- Condition is `false` if:
  - The cache variable doesn't exist (check wasn't run)
  - The check failed (success = false)
  - The value is falsy (empty string or "0")

If the condition includes a comparison operator (e.g., `condition="ac_cv_header_foo_h==1"`),
it performs value comparison instead of truthy check.

Example:
```python
# Check creates cache variable
macros.AC_CHECK_HEADER("alloca.h")
# -> Creates cache variable: "ac_cv_header_alloca_h" with value "1" (if header exists)

# Define with truthy condition
macros.AC_DEFINE(
    "HAVE_ALLOCA_H",
    condition="ac_cv_header_alloca_h",  # Truthy: true if check succeeded and value is truthy
    if_true="1",
    if_false=None,  # Don't define if condition is false
)

# Subst with truthy condition
macros.AC_SUBST(
    "HAVE_ALLOCA_H",
    condition="ac_cv_header_alloca_h",  # Truthy check
    if_true="1",
    if_false="0",  # Always set subst value
)
```

## Default Includes

Default includes used by AC_CHECK_DECL, AC_CHECK_TYPE, etc. when no includes are specified.

GNU Autoconf's AC_INCLUDES_DEFAULT uses #ifdef HAVE_* guards, but that relies on
AC_CHECK_HEADERS_ONCE being called earlier to define those macros. In Bazel, each
compile test runs independently without access to results from other checks, so we
use unconditional includes instead. This matches what would happen on a modern
POSIX system where all the standard headers exist.

See: https://www.gnu.org/savannah-checkouts/gnu/autoconf/manual/autoconf-2.72/autoconf.html#Default-Includes

## Header / includes parameter

Checks that need to include headers (AC_CHECK_DECL, AC_CHECK_TYPE, AC_CHECK_SIZEOF,
AC_CHECK_MEMBER, etc.) take an **`includes`** parameter. **AC_CHECK_FUNC** does not
take includes (standard Autoconf link test only); use **GL_CHECK_FUNCS_ANDROID** (or
other GL_CHECK_FUNCS* in gnulib/macros.bzl) when includes are needed. Both of these forms are
supported:

Use **include directives** as strings, e.g. `"#include <stdlib.h>"` or
`"#include <sys/stat.h>"`, matching Autoconf/gnulib (e.g.
`gl_CHECK_FUNCS_ANDROID([faccessat], [[#include <unistd.h>]])`). The list is
joined with newlines to form the prologue of the test program.

The parameter `headers` is a deprecated alias for `includes`; prefer `includes`.
��
'
rules_cc_autoconfautoconfdefs.bzl�autoconf�Run autoconf-like checks and produce results.

This rule resolves the ``autoconf_toolchain`` (when registered) to skip redundant
checker actions.  If a check's cache variable name already has a result in the
toolchain or in transitive ``deps``, the existing result file is reused.

Use ``autoconf_library`` instead for targets that feed into ``autoconf_toolchain``
to avoid a dependency cycle.

Example:

```python
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")

autoconf(
    name = "config",
    checks = [
        checks.AC_CHECK_HEADER("stdio.h"),
        checks.AC_CHECK_HEADER("stdlib.h"),
        checks.AC_CHECK_FUNC("printf"),
    ],
)
```

The results can then be used by `autoconf_hdr` or `autoconf_srcs` to generate headers
or wrapped source files.
"�

�
autoconf�Run autoconf-like checks and produce results.

This rule resolves the ``autoconf_toolchain`` (when registered) to skip redundant
checker actions.  If a check's cache variable name already has a result in the
toolchain or in transitive ``deps``, the existing result file is reused.

Use ``autoconf_library`` instead for targets that feed into ``autoconf_toolchain``
to avoid a dependency cycle.

Example:

```python
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")

autoconf(
    name = "config",
    checks = [
        checks.AC_CHECK_HEADER("stdio.h"),
        checks.AC_CHECK_HEADER("stdlib.h"),
        checks.AC_CHECK_FUNC("printf"),
    ],
)
```

The results can then be used by `autoconf_hdr` or `autoconf_srcs` to generate headers
or wrapped source files.
*
nameA unique name for this target. d
checksTList of JSON-encoded checks from checks (e.g., `checks.AC_CHECK_HEADER('stdio.h')`).2[]j
depsJAdditional `autoconf`, `autoconf_library`, or `package_info` dependencies.*
CcAutoconfInfo2[]"2
autoconf&@@rules_cc_autoconf//autoconf:defs.bzl
��,
*
nameA unique name for this target. f
d
checksTList of JSON-encoded checks from checks (e.g., `checks.AC_CHECK_HEADER('stdio.h')`).2[]l
j
depsJAdditional `autoconf`, `autoconf_library`, or `package_info` dependencies.*
CcAutoconfInfo2[]�;autoconf_hdr�	Generate configuration headers from results provided by `autoconf` targets.

This rule takes check results from `autoconf` targets (via `deps`) and generates a header file.
The template file (if provided) is used to format the output header.

Example:

```python
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:autoconf_hdr.bzl", "autoconf_hdr")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")

autoconf(
    name = "config_checks",
    checks = [
        checks.AC_CHECK_HEADER("stdio.h"),
        checks.AC_CHECK_HEADER("stdlib.h"),
        checks.AC_CHECK_FUNC("printf"),
    ],
)

autoconf_hdr(
    name = "config",
    out = "config.h",
    deps = [":config_checks"],
    template = "config.h.in",
)
```

Valid `mode` values:
- `"defines"` (default): Only process defines (AC_DEFINE, AC_CHECK_*, etc.), not substitution variables (AC_SUBST). This is for config.h files.
- `"subst"`: Only process substitution variables (AC_SUBST), not defines. This is for subst.h files.
- `"all"`: Process both defines and substitution variables.

This allows you to run checks once and generate multiple header files from the same results.
"�1
�
autoconf_hdr�	Generate configuration headers from results provided by `autoconf` targets.

This rule takes check results from `autoconf` targets (via `deps`) and generates a header file.
The template file (if provided) is used to format the output header.

Example:

```python
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:autoconf_hdr.bzl", "autoconf_hdr")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")

autoconf(
    name = "config_checks",
    checks = [
        checks.AC_CHECK_HEADER("stdio.h"),
        checks.AC_CHECK_HEADER("stdlib.h"),
        checks.AC_CHECK_FUNC("printf"),
    ],
)

autoconf_hdr(
    name = "config",
    out = "config.h",
    deps = [":config_checks"],
    template = "config.h.in",
)
```

Valid `mode` values:
- `"defines"` (default): Only process defines (AC_DEFINE, AC_CHECK_*, etc.), not substitution variables (AC_SUBST). This is for config.h files.
- `"subst"`: Only process substitution variables (AC_SUBST), not defines. This is for subst.h files.
- `"all"`: Process both defines and substitution variables.

This allows you to run checks once and generate multiple header files from the same results.
*
nameA unique name for this target. �
defaults�Whether to include toolchain defaults.

When False (the default), no toolchain defaults are included and only
the explicit deps provide check results. When True, defaults from the
autoconf toolchain are included, subject to filtering by defaults_include
or defaults_exclude.2False�
defaults_exclude�Labels to exclude from toolchain defaults.

Only effective when defaults=True. If specified, defaults from these
labels are excluded. Labels not found in the toolchain are silently
ignored. Mutually exclusive with defaults_include.*
CcAutoconfInfo2[]�
defaults_include�Labels to include from toolchain defaults.

Only effective when defaults=True. If specified, only defaults from
these labels are included. An error is raised if a specified label
is not found in the toolchain. Mutually exclusive with defaults_exclude.*
CcAutoconfInfo2[]�
deps�List of `autoconf` targets which provide check results. Results from all deps will be merged together, and duplicate define names will produce an error. If not provided, an empty results file will be created.*
CcAutoconfInfo2[]�
inlines�A mapping of strings to files for replace within the content of the given `template` attribute.

The exact string in the template is replaced with the content of the associated file.
Any `@VAR@` style placeholders in the inline file content will be replaced with their
corresponding define values (package info, check results, etc.) after insertion.	2{}]
modeHProcessing mode that determines what should be replaced within the file.2	"defines"9
out.The output config file (typically `config.h`). �
substitutions�A mapping of exact strings to replacement values.

Each entry performs an exact text replacement in the template - the key
string is replaced with the value string. No special patterns or wrappers
are added.

Example:
```python
autoconf_hdr(
    name = "config",
    out = "config.h",
    template = "config.h.in",
    substitutions = {
        "@MY_VERSION@": "1.2.3",
        "@BUILD_TYPE@": "release",
        "PLACEHOLDER_TEXT": "actual_value",
    },
    deps = [":checks"],
)
```

This would replace the exact string `@MY_VERSION@` with `1.2.3`,
`@BUILD_TYPE@` with `release`, and `PLACEHOLDER_TEXT` with `actual_value`.
2{}�
template�Template file (`config.h.in`) to use as base for generating the header file. The template is used to format the output header, but does not generate any checks. "6
autoconf_hdr&@@rules_cc_autoconf//autoconf:defs.bzl
zz,
*
nameA unique name for this target. �
�
defaults�Whether to include toolchain defaults.

When False (the default), no toolchain defaults are included and only
the explicit deps provide check results. When True, defaults from the
autoconf toolchain are included, subject to filtering by defaults_include
or defaults_exclude.2False�
�
defaults_exclude�Labels to exclude from toolchain defaults.

Only effective when defaults=True. If specified, defaults from these
labels are excluded. Labels not found in the toolchain are silently
ignored. Mutually exclusive with defaults_include.*
CcAutoconfInfo2[]�
�
defaults_include�Labels to include from toolchain defaults.

Only effective when defaults=True. If specified, only defaults from
these labels are included. An error is raised if a specified label
is not found in the toolchain. Mutually exclusive with defaults_exclude.*
CcAutoconfInfo2[]�
�
deps�List of `autoconf` targets which provide check results. Results from all deps will be merged together, and duplicate define names will produce an error. If not provided, an empty results file will be created.*
CcAutoconfInfo2[]�
�
inlines�A mapping of strings to files for replace within the content of the given `template` attribute.

The exact string in the template is replaced with the content of the associated file.
Any `@VAR@` style placeholders in the inline file content will be replaced with their
corresponding define values (package info, check results, etc.) after insertion.	2{}_
]
modeHProcessing mode that determines what should be replaced within the file.2	"defines";
9
out.The output config file (typically `config.h`). �
�
substitutions�A mapping of exact strings to replacement values.

Each entry performs an exact text replacement in the template - the key
string is replaced with the value string. No special patterns or wrappers
are added.

Example:
```python
autoconf_hdr(
    name = "config",
    out = "config.h",
    template = "config.h.in",
    substitutions = {
        "@MY_VERSION@": "1.2.3",
        "@BUILD_TYPE@": "release",
        "PLACEHOLDER_TEXT": "actual_value",
    },
    deps = [":checks"],
)
```

This would replace the exact string `@MY_VERSION@` with `1.2.3`,
`@BUILD_TYPE@` with `release`, and `PLACEHOLDER_TEXT` with `actual_value`.
2{}�
�
template�Template file (`config.h.in`) to use as base for generating the header file. The template is used to format the output header, but does not generate any checks. �autoconf_linkopts�Resolve AC_SEARCH_LIBS / AC_SUBST results into linker flags.

Reads subst result JSON files from autoconf deps and produces a
linker response file. Returns CcInfo with the flags, so consumers
can simply add this target to their deps list.

On GCC/Clang the flags are delivered via a @response-file. On
MSVC/clang-cl a .c file with #pragma comment(lib, ...) directives
is compiled instead, since MSVC's link.exe does not support nested
response files.

Variables not found in the deps are silently ignored (they may
be provided by a different module or not needed on this platform).
"�
�
autoconf_linkopts�Resolve AC_SEARCH_LIBS / AC_SUBST results into linker flags.

Reads subst result JSON files from autoconf deps and produces a
linker response file. Returns CcInfo with the flags, so consumers
can simply add this target to their deps list.

On GCC/Clang the flags are delivered via a @response-file. On
MSVC/clang-cl a .c file with #pragma comment(lib, ...) directives
is compiled instead, since MSVC's link.exe does not support nested
response files.

Variables not found in the deps are silently ignored (they may
be provided by a different module or not needed on this platform).
*
nameA unique name for this target. ;
defaults&Whether to include toolchain defaults.2FalseO
deps1List of autoconf targets providing check results. *
CcAutoconfInfo�
vars�List of AC_SUBST variable names to resolve (e.g., ["LIBPTHREAD", "FDATASYNC_LIB"]).
Each variable is looked up in the subst results from deps. Non-empty values
(like "-lpthread") are added to linkopts; empty values are skipped.
 ";
autoconf_linkopts&@@rules_cc_autoconf//autoconf:defs.bzl
��,
*
nameA unique name for this target. =
;
defaults&Whether to include toolchain defaults.2FalseQ
O
deps1List of autoconf targets providing check results. *
CcAutoconfInfo�
�
vars�List of AC_SUBST variable names to resolve (e.g., ["LIBPTHREAD", "FDATASYNC_LIB"]).
Each variable is looked up in the subst results from deps. Non-empty values
(like "-lpthread") are added to linkopts; empty values are skipped.
 �,autoconf_srcs�
Generate wrapper sources that are conditionally enabled by autoconf results.

Typical use case:

```python
load("@rules_cc_autoconf//autoconf:autoconf_srcs.bzl", "autoconf_srcs")
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")
load("@rules_cc//cc:cc_library.bzl", "cc_library")

autoconf(
    name = "config",
    out = "config.h",
    checks = [
        # Feature is present on this platform/toolchain.
        checks.AC_CHECK_HEADER("foo.h", define = "HAVE_FOO"),
    ],
)

autoconf_srcs(
    name = "foo_srcs",
    deps = [":config"],
    srcs = {
        "uses_foo.c": "HAVE_FOO",
    },
)

cc_library(
    name = "foo",
    srcs = [":foo_srcs"],
    hdrs = [":config.h"],
)
```

In this setup `autoconf_srcs` reads the results from `:config` (or multiple targets via `deps`) and generates a
wrapped copy of `uses_foo.c` whose contents are effectively:

```cc
#define HAVE_FOO 1      // when the check for HAVE_FOO succeeds
/* or: #undef HAVE_FOO  // when the check fails */
#ifdef HAVE_FOO
/* original uses_foo.c contents ... */
#endif
```

This is useful when you have platform-specific or optional sources that should
only be compiled when a particular autoconf check passes, without having to
manually maintain `#ifdef` guards in every source file.
"�"
�
autoconf_srcs�
Generate wrapper sources that are conditionally enabled by autoconf results.

Typical use case:

```python
load("@rules_cc_autoconf//autoconf:autoconf_srcs.bzl", "autoconf_srcs")
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:checks.bzl", "checks")
load("@rules_cc//cc:cc_library.bzl", "cc_library")

autoconf(
    name = "config",
    out = "config.h",
    checks = [
        # Feature is present on this platform/toolchain.
        checks.AC_CHECK_HEADER("foo.h", define = "HAVE_FOO"),
    ],
)

autoconf_srcs(
    name = "foo_srcs",
    deps = [":config"],
    srcs = {
        "uses_foo.c": "HAVE_FOO",
    },
)

cc_library(
    name = "foo",
    srcs = [":foo_srcs"],
    hdrs = [":config.h"],
)
```

In this setup `autoconf_srcs` reads the results from `:config` (or multiple targets via `deps`) and generates a
wrapped copy of `uses_foo.c` whose contents are effectively:

```cc
#define HAVE_FOO 1      // when the check for HAVE_FOO succeeds
/* or: #undef HAVE_FOO  // when the check fails */
#ifdef HAVE_FOO
/* original uses_foo.c contents ... */
#endif
```

This is useful when you have platform-specific or optional sources that should
only be compiled when a particular autoconf check passes, without having to
manually maintain `#ifdef` guards in every source file.
*
nameA unique name for this target. �
defaults�Whether to include toolchain defaults.

When False (the default), no toolchain defaults are included and only
the explicit deps provide check results. When True, defaults from the
autoconf toolchain are included, subject to filtering by defaults_include
or defaults_exclude.2False�
defaults_exclude�Labels to exclude from toolchain defaults.

Only effective when defaults=True. If specified, defaults from these
labels are excluded. Labels not found in the toolchain are silently
ignored. Mutually exclusive with defaults_include.*
CcAutoconfInfo2[]�
defaults_include�Labels to include from toolchain defaults.

Only effective when defaults=True. If specified, only defaults from
these labels are included. An error is raised if a specified label
is not found in the toolchain. Mutually exclusive with defaults_exclude.*
CcAutoconfInfo2[]�
deps�List of `autoconf` targets which provide defines. Results from all deps will be merged together, and duplicate define names will produce an error. *
CcAutoconfInfo�
naming�How to name generated sources: `package_relative` keeps the original package-relative path, `ac_suffix`
inserts `.ac.` before the final suffix (e.g. `foo.cc -> foo.ac.cc`), and `per_target` prefixes outputs
with `{ctx.label.name}` to namespace them per rule.
2"package_relative"L
srcs@A mapping of source file to define required to compile the file.	 "7
autoconf_srcs&@@rules_cc_autoconf//autoconf:defs.bzl
��,
*
nameA unique name for this target. �
�
defaults�Whether to include toolchain defaults.

When False (the default), no toolchain defaults are included and only
the explicit deps provide check results. When True, defaults from the
autoconf toolchain are included, subject to filtering by defaults_include
or defaults_exclude.2False�
�
defaults_exclude�Labels to exclude from toolchain defaults.

Only effective when defaults=True. If specified, defaults from these
labels are excluded. Labels not found in the toolchain are silently
ignored. Mutually exclusive with defaults_include.*
CcAutoconfInfo2[]�
�
defaults_include�Labels to include from toolchain defaults.

Only effective when defaults=True. If specified, only defaults from
these labels are included. An error is raised if a specified label
is not found in the toolchain. Mutually exclusive with defaults_exclude.*
CcAutoconfInfo2[]�
�
deps�List of `autoconf` targets which provide defines. Results from all deps will be merged together, and duplicate define names will produce an error. *
CcAutoconfInfo�
�
naming�How to name generated sources: `package_relative` keeps the original package-relative path, `ac_suffix`
inserts `.ac.` before the final suffix (e.g. `foo.cc -> foo.ac.cc`), and `per_target` prefixes outputs
with `{ctx.label.name}` to namespace them per rule.
2"package_relative"N
L
srcs@A mapping of source file to define required to compile the file.	 �package_info�A rule for parsing module info from `MODULE.bazel` files.

This rule is most useful when paired with the `autoconf` rule.

Example:

```python
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:package_info.bzl", "package_info")

package_info(
    name = "package_info",
    module_bazel = "//:MODULE.bazel",
)

autoconf(
    name = "config_h",
    out = "config.h",
    checks = [
        # ...
    ],
    deps = [
        ":package_info",
    ],
)
```
"�
�
package_info�A rule for parsing module info from `MODULE.bazel` files.

This rule is most useful when paired with the `autoconf` rule.

Example:

```python
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:package_info.bzl", "package_info")

package_info(
    name = "package_info",
    module_bazel = "//:MODULE.bazel",
)

autoconf(
    name = "config_h",
    out = "config.h",
    checks = [
        # ...
    ],
    deps = [
        ":package_info",
    ],
)
```
*
nameA unique name for this target. a
aliasesPAdditional variables to define that are mirrored by the provided value variable.
2{}�
module_bazeluA `MODULE.bazel` file to parse module information from. Mutually exclusive with `package_name` and `package_version`.2Nonei
package_bugreportNThe package bug report email/URL. Used to populate `PACKAGE_BUGREPORT` define.2""{
package_nameeThe package name. Must be provided together with `package_version` if `module_bazel` is not provided.2""J
package_tarname1Exactly tarname, possibly generated from package.2""V
package_urlAThe package home page URL. Used to populate `PACKAGE_URL` define.2""~
package_versioneThe package version. Must be provided together with `package_name` if `module_bazel` is not provided.2""l
strip_bcr_versionNWhether or not to strip `.bcr.*` suffixes from `module_bazel` parsed versions.2False"6
package_info&@@rules_cc_autoconf//autoconf:defs.bzl
��,
*
nameA unique name for this target. c
a
aliasesPAdditional variables to define that are mirrored by the provided value variable.
2{}�
�
module_bazeluA `MODULE.bazel` file to parse module information from. Mutually exclusive with `package_name` and `package_version`.2Nonek
i
package_bugreportNThe package bug report email/URL. Used to populate `PACKAGE_BUGREPORT` define.2""}
{
package_nameeThe package name. Must be provided together with `package_version` if `module_bazel` is not provided.2""L
J
package_tarname1Exactly tarname, possibly generated from package.2""X
V
package_urlAThe package home page URL. Used to populate `PACKAGE_URL` define.2""�
~
package_versioneThe package version. Must be provided together with `package_name` if `module_bazel` is not provided.2""n
l
strip_bcr_versionNWhether or not to strip `.bcr.*` suffixes from `module_bazel` parsed versions.2False}
//autoconf:autoconf.bzlr`
+
rules_cc_autoconfautoconfautoconf.bzl#
autoconf	_autoconf

�
//autoconf:autoconf_hdr.bzlrl
/
rules_cc_autoconfautoconfautoconf_hdr.bzl+
autoconf_hdr_autoconf_hdr



�
 //autoconf:autoconf_linkopts.bzlr{
4
rules_cc_autoconfautoconfautoconf_linkopts.bzl5
autoconf_linkopts_autoconf_linkopts

�
//autoconf:autoconf_srcs.bzlro
0
rules_cc_autoconfautoconfautoconf_srcs.bzl-
autoconf_srcs_autoconf_srcs

�
//autoconf:checks.bzlr{
)
rules_cc_autoconfautoconf
checks.bzl
checks_checks

macros_macros

�
//autoconf:package_info.bzlrl
/
rules_cc_autoconfautoconfpackage_info.bzl+
package_info_package_info

# rules_cc_autoconf
�
/
rules_cc_autoconfautoconfpackage_info.bzl�package_info�A rule for parsing module info from `MODULE.bazel` files.

This rule is most useful when paired with the `autoconf` rule.

Example:

```python
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:package_info.bzl", "package_info")

package_info(
    name = "package_info",
    module_bazel = "//:MODULE.bazel",
)

autoconf(
    name = "config_h",
    out = "config.h",
    checks = [
        # ...
    ],
    deps = [
        ":package_info",
    ],
)
```
"�
�
package_info�A rule for parsing module info from `MODULE.bazel` files.

This rule is most useful when paired with the `autoconf` rule.

Example:

```python
load("@rules_cc_autoconf//autoconf:autoconf.bzl", "autoconf")
load("@rules_cc_autoconf//autoconf:package_info.bzl", "package_info")

package_info(
    name = "package_info",
    module_bazel = "//:MODULE.bazel",
)

autoconf(
    name = "config_h",
    out = "config.h",
    checks = [
        # ...
    ],
    deps = [
        ":package_info",
    ],
)
```
*
nameA unique name for this target. a
aliasesPAdditional variables to define that are mirrored by the provided value variable.
2{}�
module_bazeluA `MODULE.bazel` file to parse module information from. Mutually exclusive with `package_name` and `package_version`.2Nonei
package_bugreportNThe package bug report email/URL. Used to populate `PACKAGE_BUGREPORT` define.2""{
package_nameeThe package name. Must be provided together with `package_version` if `module_bazel` is not provided.2""J
package_tarname1Exactly tarname, possibly generated from package.2""V
package_urlAThe package home page URL. Used to populate `PACKAGE_URL` define.2""~
package_versioneThe package version. Must be provided together with `package_name` if `module_bazel` is not provided.2""l
strip_bcr_versionNWhether or not to strip `.bcr.*` suffixes from `module_bazel` parsed versions.2False">
package_info.@@rules_cc_autoconf//autoconf:package_info.bzl
��,
*
nameA unique name for this target. c
a
aliasesPAdditional variables to define that are mirrored by the provided value variable.
2{}�
�
module_bazeluA `MODULE.bazel` file to parse module information from. Mutually exclusive with `package_name` and `package_version`.2Nonek
i
package_bugreportNThe package bug report email/URL. Used to populate `PACKAGE_BUGREPORT` define.2""}
{
package_nameeThe package name. Must be provided together with `package_version` if `module_bazel` is not provided.2""L
J
package_tarname1Exactly tarname, possibly generated from package.2""X
V
package_urlAThe package home page URL. Used to populate `PACKAGE_URL` define.2""�
~
package_versioneThe package version. Must be provided together with `package_name` if `module_bazel` is not provided.2""n
l
strip_bcr_versionNWhether or not to strip `.bcr.*` suffixes from `module_bazel` parsed versions.2False�
//autoconf:cc_autoconf_info.bzlr�
3
rules_cc_autoconfautoconfcc_autoconf_info.bzl.
CcAutoconfInfoCcAutoconfInfo
,
encode_resultencode_result

# package_info�
+
rules_cc_autoconfgnulib/testsdeps.bzl�gnulib+rules_cc_autoconf gnulib test dependencies.J{
k
gnulib+rules_cc_autoconf gnulib test dependencies."4
gnulib*@@rules_cc_autoconf//gnulib/tests:deps.bzl
$$�
 //tools/build_defs/repo:http.bzlrj
.
bazel_toolstools/build_defs/repohttp.bzl*
http_archivehttp_archive
7C
EGnulib test deps� 
A
rules_cc_autoconfgnulib/testsgnu_gnulib_diff_test_suite.bzl�gnu_gnulib_diff_test_suite�Complete test suite for a gnulib module.

This creates:
1. gnu_autoconf test - Runs GNU autoconf and compares with golden
2. bazel_config_diff - Compares Bazel-generated config.h with golden
3. bazel_gnulib_diff - Compares Bazel-generated gnulib_*.h with golden
4. compile test - Verifies golden headers compile
5. Test suite combining all above

Golden files can be specified as either:
- A simple Label (same golden for all platforms)
- A dict with platform keys: {"linux": "golden_linux.h.in", "macos": "golden_macos.h.in", ...}

Valid platform keys:
- "linux": Only runs on Linux
- "macos": Only runs on macOS
- "windows": Only runs on Windows
- "unix": Runs on all non-Windows platforms (Linux, macOS, BSD, etc.)

When using dict golden files, a single test target is created per test type; the
golden file is chosen via select(). If only linux and/or macos are specified
(no windows), target_compatible_with is set so the test does not run on Windows.
*�
�
gnu_gnulib_diff_test_suite>
name2Name of the test suite (typically "{module}_test") (D
configure_ac0The configure.ac file specific to this m4 module (D
m4_files4ALL m4 files needed to run autoconf (including deps) (;
config_h_in(Template for AC_DEFINE (#undef patterns) (8

subst_h_in&Template for AC_SUBST (@FOO@ patterns) ([
golden_config_hDExpected config.h output.
Can be a Label or dict with platform keys. (\
golden_subst_hFExpected gnulib_*.h output.
Can be a Label or dict with platform keys. (H
bazel_autoconf_target+The autoconf target from //gnulib/m4/{name} (3
test_c%C file to compile with golden headers (V
	aux_filesCAuxiliary files (e.g., config.rpath) to copy to work directory root[](1
sizeTest size (default: "medium")"medium"(
tags	Test tags[](�
skip_subst_diff_on_windows�Skip the subst_diff test on Windows.
Set to True for modules whose NEXT_*_H values contain inlined
MSVC system header content that is SDK-version-specific and
cannot be captured in a stable golden file.False( 
kwargsAdditional arguments(�Complete test suite for a gnulib module.

This creates:
1. gnu_autoconf test - Runs GNU autoconf and compares with golden
2. bazel_config_diff - Compares Bazel-generated config.h with golden
3. bazel_gnulib_diff - Compares Bazel-generated gnulib_*.h with golden
4. compile test - Verifies golden headers compile
5. Test suite combining all above

Golden files can be specified as either:
- A simple Label (same golden for all platforms)
- A dict with platform keys: {"linux": "golden_linux.h.in", "macos": "golden_macos.h.in", ...}

Valid platform keys:
- "linux": Only runs on Linux
- "macos": Only runs on macOS
- "windows": Only runs on Windows
- "unix": Runs on all non-Windows platforms (Linux, macOS, BSD, etc.)

When using dict golden files, a single test target is created per test type; the
golden file is chosen via select(). If only linux and/or macos are specified
(no windows), target_compatible_with is set so the test does not run on Windows.
2^
gnu_gnulib_diff_test_suite@@@rules_cc_autoconf//gnulib/tests:gnu_gnulib_diff_test_suite.bzl
"autoconf_hdr*native.test_suite2gnu_autoconf_configure_test2autoconf_hdr2autoconf_hdr2cc_test2native.test_suitec
//cc:cc_test.bzlrM

rules_cccccc_test.bzl 
cc_testcc_test
$+
-�
//autoconf:autoconf_hdr.bzlrk
/
rules_cc_autoconfautoconfautoconf_hdr.bzl*
autoconf_hdrautoconf_hdr
	8	D
		F�
//autoconf/tests:diff_test.bzlrh
2
rules_cc_autoconfautoconf/testsdiff_test.bzl$
	diff_test	diff_test

;
D


F�
0//autoconf/tests:gnu_autoconf_configure_test.bzlr�
D
rules_cc_autoconfautoconf/testsgnu_autoconf_configure_test.bzlH
gnu_autoconf_configure_testgnu_autoconf_configure_test
Mh
j�Macros for testing gnulib m4 files against golden outputs.

This module provides:
- gnu_gnulib_diff_test: Single test comparing GNU autoconf output with golden files
- gnu_gnulib_diff_test_suite: Complete test suite for a gnulib module
�
'
rules_cc_autoconfgnulib
macros.bzl}
//autoconf:checks.bzlrb
)
rules_cc_autoconfautoconf
checks.bzl'
checksautoconf_checks
	1	@
		L�
!//autoconf/private:check_info.bzlrm
5
rules_cc_autoconfautoconf/privatecheck_info.bzl&

make_check
make_check
>H
J�# gnulib macros

Common gnulib macro patterns as Bazel wrappers.

These macros encapsulate common patterns from gnulib's m4 files, making it
easier to port modules while maintaining consistency with gnulib behavior.
�
/
rules_cc_autoconftools/cxxoptscxxopts.bzl�cxxopts6Returns a select statement for C++17 compiler options.*�
�
cxxopts6Returns a select statement for C++17 compiler options."I
GA select statement suitable for use in cc_library or cc_binary cxxopts.29
cxxopts.@@rules_cc_autoconf//tools/cxxopts:cxxopts.bzl
�linkopts2Returns a select statement for C++17 link options.*�
�
linkopts2Returns a select statement for C++17 link options."J
HA select statement suitable for use in cc_library or cc_binary linkopts.2:
linkopts.@@rules_cc_autoconf//tools/cxxopts:cxxopts.bzl
(C++ compiler options for autoconf tools.�	
9
rules_cc_autoconftools/queryresult_query_aspect.bzl�ResultQueryInfo3Transitive collection of autoconf result DAG nodes.2�
�
ResultQueryInfo3Transitive collection of autoconf result DAG nodes.i

node_jsons[depset[string]: JSON-encoded node descriptors for every CcAutoconfInfo target in the graph.]
result_filesMdepset[File]: All result files in the transitive closure (so they get built)."K
ResultQueryInfo8@@rules_cc_autoconf//tools/query:result_query_aspect.bzl
k
i

node_jsons[depset[string]: JSON-encoded node descriptors for every CcAutoconfInfo target in the graph._
]
result_filesMdepset[File]: All result files in the transitive closure (so they get built).�result_query_aspect:�
�
result_query_aspectdeps"*
nameA unique name for this target. *O
result_query_aspect8@@rules_cc_autoconf//tools/query:result_query_aspect.bzl
II,
*
nameA unique name for this target. �
 //autoconf/private:providers.bzlrt
4
rules_cc_autoconfautoconf/privateproviders.bzl.
CcAutoconfInfoCcAutoconfInfo
=K
M.Aspect for collecting the autoconf result DAG.Z
 
rules_cc_autoconfversion.bzl	VERSION0.8.0j0.8.0rules_cc_autoconf version 