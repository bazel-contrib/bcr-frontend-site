�
5
rules_cc_hdrs_mapcc_hdrs_map/actionscompile.bzl�prepare_for_compilation�Materialize information from hdrs map.

This function creates a epheremal directory, that contains all of the
patterns specified within hdrs_map providers, thus making them all
available under singular, temporary include statment.
*�
�
prepare_for_compilation
sctxsubrule context (i
input_hdrs_mapSlist of HdrsMapInfo which should be used for materialization of compilation context (>
input_public_hdrs%direct headers provided to the action (?
input_private_hdrs%direct headers provided to the action (7

input_deps%dependencies specified for the action (A
input_includes+include statements specified for the action (�Materialize information from hdrs map.

This function creates a epheremal directory, that contains all of the
patterns specified within hdrs_map providers, thus making them all
available under singular, temporary include statment.
2O
prepare_for_compilation4@@rules_cc_hdrs_map//cc_hdrs_map/actions:compile.bzl


�
//cc:find_cc_toolchain.bzlr�
%
rules_ccccfind_cc_toolchain.bzl4
find_cc_toolchainfind_cc_toolchain
2
use_cc_toolchainuse_cc_toolchain

�
$//cc_hdrs_map/providers:hdrs_map.bzlr�
8
rules_cc_hdrs_mapcc_hdrs_map/providershdrs_map.bzl(
HdrsMapInfoHdrsMapInfo
ALB
materialize_hdrs_mappingmaterialize_hdrs_mapping
PhO
merge_hdrs_maps_info_from_depsmerge_hdrs_maps_info_from_deps
l�
�SThis module contains logic responsible for HdrsMap handling and compilation phase. �
7
rules_cc_hdrs_mapcc_hdrs_map/actionscopy_file.bzl�	copy_fileaCopy file from a to b.

This function will copy file from given source to specified destination.
*�
�
	copy_file
ctx_actions (@
src5(File) source file that should be copied. Must exist. (W
dstL(File) destination file that should be created. Must be declared beforehand. (aCopy file from a to b.

This function will copy file from given source to specified destination.
2C
	copy_file6@@rules_cc_hdrs_map//cc_hdrs_map/actions:copy_file.bzl
_This module exposes the copy_file action. Done to avoid dependency towards skylib (or others). �
2
rules_cc_hdrs_mapcc_hdrs_map/actionsdefs.bzl�
!//cc_hdrs_map/actions:compile.bzlrh
5
rules_cc_hdrs_mapcc_hdrs_map/actionscompile.bzl!
compile_compile
=E
R�
)//cc_hdrs_map/actions:link_to_archive.bzlr�
=
rules_cc_hdrs_mapcc_hdrs_map/actionslink_to_archive.bzl1
link_to_archive_link_to_archive
EU
j�
(//cc_hdrs_map/actions:link_to_binary.bzlr}
<
rules_cc_hdrs_mapcc_hdrs_map/actionslink_to_binary.bzl/
link_to_binary_link_to_binary
DS
g�
$//cc_hdrs_map/actions:link_to_so.bzlrq
8
rules_cc_hdrs_mapcc_hdrs_map/actionslink_to_so.bzl'

link_to_so_link_to_so
@K
[_This module defines the CC compilation phase actions which are exposed publicalyl as subrules. �
=
rules_cc_hdrs_mapcc_hdrs_map/actionslink_to_archive.bzl�
//cc:action_names.bzlr�
 
rules_ccccaction_names.bzlX
#CPP_LINK_STATIC_LIBRARY_ACTION_NAME#CPP_LINK_STATIC_LIBRARY_ACTION_NAME
)L
N�
//cc:find_cc_toolchain.bzlr�
%
rules_ccccfind_cc_toolchain.bzl4
find_cc_toolchainfind_cc_toolchain
2
use_cc_toolchainuse_cc_toolchain

C" This module contains logic responsible for linking into .a file. �
<
rules_cc_hdrs_mapcc_hdrs_map/actionslink_to_binary.bzl�
//cc:find_cc_toolchain.bzlr�
%
rules_ccccfind_cc_toolchain.bzl4
find_cc_toolchainfind_cc_toolchain
2
use_cc_toolchainuse_cc_toolchain

JThis module contains logic responsible for creation of executable binary. �
8
rules_cc_hdrs_mapcc_hdrs_map/actionslink_to_so.bzl�
//cc:find_cc_toolchain.bzlr�
%
rules_ccccfind_cc_toolchain.bzl4
find_cc_toolchainfind_cc_toolchain
2
use_cc_toolchainuse_cc_toolchain

BThis module contains logic responsible for linking into .so file. �
3
rules_cc_hdrs_mapcc_hdrs_map/private	attrs.bzl�get_cc_archive_attrsTo be described.*�
t
get_cc_archive_attrsTo be described.2J
get_cc_archive_attrs2@@rules_cc_hdrs_map//cc_hdrs_map/private:attrs.bzl
���get_cc_bin_attrsTo be described*}
k
get_cc_bin_attrsTo be described2F
get_cc_bin_attrs2@@rules_cc_hdrs_map//cc_hdrs_map/private:attrs.bzl
���get_cc_hdrs_attrsTo be described.*�
n
get_cc_hdrs_attrsTo be described.2G
get_cc_hdrs_attrs2@@rules_cc_hdrs_map//cc_hdrs_map/private:attrs.bzl
���get_cc_so_attrsTo be described.*|
j
get_cc_so_attrsTo be described.2E
get_cc_so_attrs2@@rules_cc_hdrs_map//cc_hdrs_map/private:attrs.bzl
��JContains common configuration-related entities used by cc_hdrs_map rules. �o
8
rules_cc_hdrs_mapcc_hdrs_map/privatecc_archive.bzl�j
cc_archive�Produce an archive file.

The intended major difference between this rule and rules_cc's `cc_static_library`,
is that this rule does not intend to pull-in all static dependencies.
"�i
�5

cc_archive�Produce an archive file.

The intended major difference between this rule and rules_cc's `cc_static_library`,
is that this rule does not intend to pull-in all static dependencies.
*
nameA unique name for this target. �
additional_linker_inputs�
Pass these files to the C++ linker command.

For example, compiled Windows .res files can be provided here to be embedded in the binary target.
2[]�
	conlyoptsy
Add these options to the C compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
copts�
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.
Each string in this attribute is added in the given order to COPTS before compiling the binary target. The flags take effect only for compiling this target, not its dependencies, so be careful about header files included elsewhere. All paths should be relative to the workspace, not to the current package.

If the package declares the feature no_copts_tokenization, Bourne shell tokenization applies only to strings that consist of a single "Make" variable.
2[]�
cxxopts{
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line to this target, as well as to every rule that depends on it. Be very careful, since this may have far-reaching effects. When in doubt, add define values to local_defines instead.
2[]8
deps*The list of dependencies of current target2[]�
dynamic_deps�
These are other cc_shared_library dependencies the current target depends on.

The cc_shared_library implementation will use the list of dynamic_deps (transitively, i.e. also the dynamic_deps of the current target's dynamic_deps) to decide which cc_libraries in the transitive deps should not be linked in because they are already provided by a different cc_shared_library. 
2[]�
hdrs_map�
Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory. 
 �
include_prefix�
The prefix to add to the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at is the value of this attribute prepended to their repository-relative path.

The prefix in the strip_include_prefix attribute is removed before this prefix is added.
2""�
includes�
List of include dirs to be added to the compile line.
Subject to "Make variable" substitution. Each string is prepended with -isystem and added to COPTS. Unlike COPTS, these flags are added for this rule and every rule that depends on it. (Note: not the rules it depends upon!) Be very careful, since this may have far-reaching effects. When in doubt, add "-I" flags to COPTS instead.

Headers must be added to srcs or hdrs, otherwise they will not be available to dependent rules when compilation is sandboxed (the default).
2[]�
link_extra_lib�
Control linking of extra libraries.

By default, C++ binaries are linked against //tools/cpp:link_extra_lib, which by default depends on the label flag //tools/cpp:link_extra_libs. Without setting the flag, this library is empty by default. Setting the label flag allows linking optional dependencies, such as overrides for weak symbols, interceptors for shared library functions, or special runtime libraries (for malloc replacements, prefer malloc or --custom_malloc). Setting this attribute to None disables this behaviour. 
2&@bazel_tools//tools/cpp:link_extra_lib�
linkopts�
Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.
2[]5

linkstaticLink the binary in static mode.2True�
local_defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line for this target, but not to its dependents.
2[]�
malloc�
Override the default dependency on malloc.

By default, C++ binaries are linked against //tools/cpp:malloc, which is an empty library so the binary ends up using libc malloc. This label must refer to a cc_library. If compilation is for a non-C++ rule, this option has no effect. The value of this attribute is ignored if linkshared=True is specified. 
2@bazel_tools//tools/cpp:malloc�
nocopts�
Remove matching options from the C++ compilation command. Subject to "Make" variable substitution. The value of this attribute is interpreted as a regular expression. Any preexisting COPTS that match this regular expression (including values explicitly specified in the rule's copts attribute) will be removed from COPTS for purposes of compiling this rule. This attribute should not be needed or used outside of third_party. The values are not preprocessed in any way other than the "Make" variable substitution. 
2""�
private_hdrsl
List of headers that CANNOT be included by dependent rules.
Notice: the cutoff happens during compilation.
2[]�
public_hdrsv
List of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.
2[]
reexport_deps
2[]%
srcsThe list of source files. �
strip_include_prefix�
The prefix to strip from the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at their path with this prefix cut off.

If it's a relative path, it's taken as a package-relative one. If it's an absolute one, it's understood as a repository-relative path.

The prefix in the include_prefix attribute is added after this prefix is stripped.
2"""E

cc_archive7@@rules_cc_hdrs_map//cc_hdrs_map/private:cc_archive.bzl
&&,
*
nameA unique name for this target. �
�
additional_linker_inputs�
Pass these files to the C++ linker command.

For example, compiled Windows .res files can be provided here to be embedded in the binary target.
2[]�
�
	conlyoptsy
Add these options to the C compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
�
copts�
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.
Each string in this attribute is added in the given order to COPTS before compiling the binary target. The flags take effect only for compiling this target, not its dependencies, so be careful about header files included elsewhere. All paths should be relative to the workspace, not to the current package.

If the package declares the feature no_copts_tokenization, Bourne shell tokenization applies only to strings that consist of a single "Make" variable.
2[]�
�
cxxopts{
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
�
defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line to this target, as well as to every rule that depends on it. Be very careful, since this may have far-reaching effects. When in doubt, add define values to local_defines instead.
2[]:
8
deps*The list of dependencies of current target2[]�
�
dynamic_deps�
These are other cc_shared_library dependencies the current target depends on.

The cc_shared_library implementation will use the list of dynamic_deps (transitively, i.e. also the dynamic_deps of the current target's dynamic_deps) to decide which cc_libraries in the transitive deps should not be linked in because they are already provided by a different cc_shared_library. 
2[]�
�
hdrs_map�
Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory. 
 �
�
include_prefix�
The prefix to add to the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at is the value of this attribute prepended to their repository-relative path.

The prefix in the strip_include_prefix attribute is removed before this prefix is added.
2""�
�
includes�
List of include dirs to be added to the compile line.
Subject to "Make variable" substitution. Each string is prepended with -isystem and added to COPTS. Unlike COPTS, these flags are added for this rule and every rule that depends on it. (Note: not the rules it depends upon!) Be very careful, since this may have far-reaching effects. When in doubt, add "-I" flags to COPTS instead.

Headers must be added to srcs or hdrs, otherwise they will not be available to dependent rules when compilation is sandboxed (the default).
2[]�
�
link_extra_lib�
Control linking of extra libraries.

By default, C++ binaries are linked against //tools/cpp:link_extra_lib, which by default depends on the label flag //tools/cpp:link_extra_libs. Without setting the flag, this library is empty by default. Setting the label flag allows linking optional dependencies, such as overrides for weak symbols, interceptors for shared library functions, or special runtime libraries (for malloc replacements, prefer malloc or --custom_malloc). Setting this attribute to None disables this behaviour. 
2&@bazel_tools//tools/cpp:link_extra_lib�
�
linkopts�
Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.
2[]7
5

linkstaticLink the binary in static mode.2True�
�
local_defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line for this target, but not to its dependents.
2[]�
�
malloc�
Override the default dependency on malloc.

By default, C++ binaries are linked against //tools/cpp:malloc, which is an empty library so the binary ends up using libc malloc. This label must refer to a cc_library. If compilation is for a non-C++ rule, this option has no effect. The value of this attribute is ignored if linkshared=True is specified. 
2@bazel_tools//tools/cpp:malloc�
�
nocopts�
Remove matching options from the C++ compilation command. Subject to "Make" variable substitution. The value of this attribute is interpreted as a regular expression. Any preexisting COPTS that match this regular expression (including values explicitly specified in the rule's copts attribute) will be removed from COPTS for purposes of compiling this rule. This attribute should not be needed or used outside of third_party. The values are not preprocessed in any way other than the "Make" variable substitution. 
2""�
�
private_hdrsl
List of headers that CANNOT be included by dependent rules.
Notice: the cutoff happens during compilation.
2[]�
�
public_hdrsv
List of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.
2[]

reexport_deps
2[]'
%
srcsThe list of source files. �
�
strip_include_prefix�
The prefix to strip from the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at their path with this prefix cut off.

If it's a relative path, it's taken as a package-relative one. If it's an absolute one, it's understood as a repository-relative path.

The prefix in the include_prefix attribute is added after this prefix is stripped.
2""�
//cc_hdrs_map/actions:defs.bzlrd
2
rules_cc_hdrs_mapcc_hdrs_map/actionsdefs.bzl 
actionsactions
;B
D�
//cc_hdrs_map/private:attrs.bzlr
3
rules_cc_hdrs_mapcc_hdrs_map/private	attrs.bzl:
get_cc_archive_attrsget_cc_archive_attrs
<P
R�
$//cc_hdrs_map/providers:hdrs_map.bzlrr
8
rules_cc_hdrs_mapcc_hdrs_map/providershdrs_map.bzl(
HdrsMapInfoHdrsMapInfo
AL
N4This module contains definition of cc_archive rule. �r
4
rules_cc_hdrs_mapcc_hdrs_map/private
cc_bin.bzl�occ_bin�Produce exectuable binary.

It is intended for this rule, to differ from rules_cc's `cc_binary` in the following
fashion: it aims to automatically gather all of its dynamic dependencies and make them
available during binary execution.
"�m
�7
cc_bin�Produce exectuable binary.

It is intended for this rule, to differ from rules_cc's `cc_binary` in the following
fashion: it aims to automatically gather all of its dynamic dependencies and make them
available during binary execution.
*
nameA unique name for this target. �
additional_linker_inputs�
Pass these files to the C++ linker command.

For example, compiled Windows .res files can be provided here to be embedded in the binary target.
2[]�
	conlyoptsy
Add these options to the C compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
copts�
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.
Each string in this attribute is added in the given order to COPTS before compiling the binary target. The flags take effect only for compiling this target, not its dependencies, so be careful about header files included elsewhere. All paths should be relative to the workspace, not to the current package.

If the package declares the feature no_copts_tokenization, Bourne shell tokenization applies only to strings that consist of a single "Make" variable.
2[]�
cxxopts{
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
data�
The list of files needed by this library at runtime. See general comments about data at Typical attributes defined by most build rules.

If a data is the name of a generated file, then this cc_library rule automatically depends on the generating rule.

If a data is a rule name, then this cc_library rule automatically depends on that rule, and that rule's outs are automatically added to this cc_library's data files. 
2[]�
defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line to this target, as well as to every rule that depends on it. Be very careful, since this may have far-reaching effects. When in doubt, add define values to local_defines instead.
2[]8
deps*The list of dependencies of current target2[]�
dynamic_deps�
These are other cc_shared_library dependencies the current target depends on.

The cc_shared_library implementation will use the list of dynamic_deps (transitively, i.e. also the dynamic_deps of the current target's dynamic_deps) to decide which cc_libraries in the transitive deps should not be linked in because they are already provided by a different cc_shared_library. 
2[]�
hdrs_map�
Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory. 
 �
includes�
List of include dirs to be added to the compile line.
Subject to "Make variable" substitution. Each string is prepended with -isystem and added to COPTS. Unlike COPTS, these flags are added for this rule and every rule that depends on it. (Note: not the rules it depends upon!) Be very careful, since this may have far-reaching effects. When in doubt, add "-I" flags to COPTS instead.

Headers must be added to srcs or hdrs, otherwise they will not be available to dependent rules when compilation is sandboxed (the default).
2[]�
link_extra_lib�
Control linking of extra libraries.

By default, C++ binaries are linked against //tools/cpp:link_extra_lib, which by default depends on the label flag //tools/cpp:link_extra_libs. Without setting the flag, this library is empty by default. Setting the label flag allows linking optional dependencies, such as overrides for weak symbols, interceptors for shared library functions, or special runtime libraries (for malloc replacements, prefer malloc or --custom_malloc). Setting this attribute to None disables this behaviour. 
2&@bazel_tools//tools/cpp:link_extra_lib�
linkopts�
Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.
2[]5

linkstaticLink the binary in static mode.2True�
local_defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line for this target, but not to its dependents.
2[]�
malloc�
Override the default dependency on malloc.

By default, C++ binaries are linked against //tools/cpp:malloc, which is an empty library so the binary ends up using libc malloc. This label must refer to a cc_library. If compilation is for a non-C++ rule, this option has no effect. The value of this attribute is ignored if linkshared=True is specified. 
2@bazel_tools//tools/cpp:malloc�
nocopts�
Remove matching options from the C++ compilation command. Subject to "Make" variable substitution. The value of this attribute is interpreted as a regular expression. Any preexisting COPTS that match this regular expression (including values explicitly specified in the rule's copts attribute) will be removed from COPTS for purposes of compiling this rule. This attribute should not be needed or used outside of third_party. The values are not preprocessed in any way other than the "Make" variable substitution. 
2""�
private_hdrsl
List of headers that CANNOT be included by dependent rules.
Notice: the cutoff happens during compilation.
2[]�
public_hdrsv
List of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.
2[]
reexport_deps
2[]%
srcsThe list of source files. �
stamp�
Whether to encode build information into the binary. Possible values:

  * stamp = 1: Always stamp the build information into the binary, even in --nostamp builds. This setting should be avoided, since it potentially kills remote caching for the binary and any downstream actions that depend on it.

  * stamp = 0: Always replace build information by constant values. This gives good build result caching.

  * stamp = -1: Embedding of build information is controlled by the --[no]stamp flag.

Stamped binaries are not rebuilt unless their dependencies change.
2-1"=
cc_bin3@@rules_cc_hdrs_map//cc_hdrs_map/private:cc_bin.bzl
,
*
nameA unique name for this target. �
�
additional_linker_inputs�
Pass these files to the C++ linker command.

For example, compiled Windows .res files can be provided here to be embedded in the binary target.
2[]�
�
	conlyoptsy
Add these options to the C compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
�
copts�
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.
Each string in this attribute is added in the given order to COPTS before compiling the binary target. The flags take effect only for compiling this target, not its dependencies, so be careful about header files included elsewhere. All paths should be relative to the workspace, not to the current package.

If the package declares the feature no_copts_tokenization, Bourne shell tokenization applies only to strings that consist of a single "Make" variable.
2[]�
�
cxxopts{
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
�
data�
The list of files needed by this library at runtime. See general comments about data at Typical attributes defined by most build rules.

If a data is the name of a generated file, then this cc_library rule automatically depends on the generating rule.

If a data is a rule name, then this cc_library rule automatically depends on that rule, and that rule's outs are automatically added to this cc_library's data files. 
2[]�
�
defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line to this target, as well as to every rule that depends on it. Be very careful, since this may have far-reaching effects. When in doubt, add define values to local_defines instead.
2[]:
8
deps*The list of dependencies of current target2[]�
�
dynamic_deps�
These are other cc_shared_library dependencies the current target depends on.

The cc_shared_library implementation will use the list of dynamic_deps (transitively, i.e. also the dynamic_deps of the current target's dynamic_deps) to decide which cc_libraries in the transitive deps should not be linked in because they are already provided by a different cc_shared_library. 
2[]�
�
hdrs_map�
Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory. 
 �
�
includes�
List of include dirs to be added to the compile line.
Subject to "Make variable" substitution. Each string is prepended with -isystem and added to COPTS. Unlike COPTS, these flags are added for this rule and every rule that depends on it. (Note: not the rules it depends upon!) Be very careful, since this may have far-reaching effects. When in doubt, add "-I" flags to COPTS instead.

Headers must be added to srcs or hdrs, otherwise they will not be available to dependent rules when compilation is sandboxed (the default).
2[]�
�
link_extra_lib�
Control linking of extra libraries.

By default, C++ binaries are linked against //tools/cpp:link_extra_lib, which by default depends on the label flag //tools/cpp:link_extra_libs. Without setting the flag, this library is empty by default. Setting the label flag allows linking optional dependencies, such as overrides for weak symbols, interceptors for shared library functions, or special runtime libraries (for malloc replacements, prefer malloc or --custom_malloc). Setting this attribute to None disables this behaviour. 
2&@bazel_tools//tools/cpp:link_extra_lib�
�
linkopts�
Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.
2[]7
5

linkstaticLink the binary in static mode.2True�
�
local_defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line for this target, but not to its dependents.
2[]�
�
malloc�
Override the default dependency on malloc.

By default, C++ binaries are linked against //tools/cpp:malloc, which is an empty library so the binary ends up using libc malloc. This label must refer to a cc_library. If compilation is for a non-C++ rule, this option has no effect. The value of this attribute is ignored if linkshared=True is specified. 
2@bazel_tools//tools/cpp:malloc�
�
nocopts�
Remove matching options from the C++ compilation command. Subject to "Make" variable substitution. The value of this attribute is interpreted as a regular expression. Any preexisting COPTS that match this regular expression (including values explicitly specified in the rule's copts attribute) will be removed from COPTS for purposes of compiling this rule. This attribute should not be needed or used outside of third_party. The values are not preprocessed in any way other than the "Make" variable substitution. 
2""�
�
private_hdrsl
List of headers that CANNOT be included by dependent rules.
Notice: the cutoff happens during compilation.
2[]�
�
public_hdrsv
List of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.
2[]

reexport_deps
2[]'
%
srcsThe list of source files. �
�
stamp�
Whether to encode build information into the binary. Possible values:

  * stamp = 1: Always stamp the build information into the binary, even in --nostamp builds. This setting should be avoided, since it potentially kills remote caching for the binary and any downstream actions that depend on it.

  * stamp = 0: Always replace build information by constant values. This gives good build result caching.

  * stamp = -1: Embedding of build information is controlled by the --[no]stamp flag.

Stamped binaries are not rebuilt unless their dependencies change.
2-1�
//cc_hdrs_map/actions:defs.bzlrd
2
rules_cc_hdrs_mapcc_hdrs_map/actionsdefs.bzl 
actionsactions
;B
D�
//cc_hdrs_map/private:attrs.bzlrw
3
rules_cc_hdrs_mapcc_hdrs_map/private	attrs.bzl2
get_cc_bin_attrsget_cc_bin_attrs
<L
N8This module contains the implementation of cc_bin rule. �
5
rules_cc_hdrs_mapcc_hdrs_map/privatecc_hdrs.bzl�cc_hdrs�Define header files properties.

This rule groups headers into a singular target and allows
to attach 'include_path' modifications information to them,
so that wherever the header files are being used, they can
be used with their intended include paths.
"�
�	
cc_hdrs�Define header files properties.

This rule groups headers into a singular target and allows
to attach 'include_path' modifications information to them,
so that wherever the header files are being used, they can
be used with their intended include paths.
*
nameA unique name for this target. 8
deps*The list of dependencies of current target2[]�
hdrs_map�
Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory. 
 �
private_hdrsl
List of headers that CANNOT be included by dependent rules.
Notice: the cutoff happens during compilation.
2[]�
public_hdrsv
List of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.
2[]"?
cc_hdrs4@@rules_cc_hdrs_map//cc_hdrs_map/private:cc_hdrs.bzl
,,,
*
nameA unique name for this target. :
8
deps*The list of dependencies of current target2[]�
�
hdrs_map�
Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory. 
 �
�
private_hdrsl
List of headers that CANNOT be included by dependent rules.
Notice: the cutoff happens during compilation.
2[]�
�
public_hdrsv
List of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.
2[]�
//cc_hdrs_map/actions:defs.bzlrd
2
rules_cc_hdrs_mapcc_hdrs_map/actionsdefs.bzl 
actionsactions
;B
D�
//cc_hdrs_map/private:attrs.bzlry
3
rules_cc_hdrs_mapcc_hdrs_map/private	attrs.bzl4
get_cc_hdrs_attrsget_cc_hdrs_attrs
<M
O�
$//cc_hdrs_map/providers:hdrs_map.bzlr�
8
rules_cc_hdrs_mapcc_hdrs_map/providershdrs_map.bzl(
HdrsMapInfoHdrsMapInfo
ALN
merge_hdrs_maps_info_from_depsmerge_hdrs_maps_info_from_deps
Pn
p5This module contains implementation of cc_hdrs rule. �v
3
rules_cc_hdrs_mapcc_hdrs_map/private	cc_so.bzl�qcc_so�Produce shared object library.

The intended difference between this rule and the rules_cc's cc_shared_library is
to unify handling of dependencies that are equipped with CcInfo and CcSharedLibraryInfo
(use singular attribute of deps to track them both).
"�o
�8
cc_so�Produce shared object library.

The intended difference between this rule and the rules_cc's cc_shared_library is
to unify handling of dependencies that are equipped with CcInfo and CcSharedLibraryInfo
(use singular attribute of deps to track them both).
*
nameA unique name for this target. �
additional_linker_inputs�
Pass these files to the C++ linker command.

For example, compiled Windows .res files can be provided here to be embedded in the binary target.
2[]�

alwayslink�
If 1, any binary that depends (directly or indirectly) on this C++ library will link in all the object files for the files listed in srcs, even if some contain no symbols referenced by the binary. This is useful if your code isn't explicitly called by code in the binary, e.g., if your code registers to receive some callback provided by some service.
2True�
	conlyoptsy
Add these options to the C compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
copts�
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.
Each string in this attribute is added in the given order to COPTS before compiling the binary target. The flags take effect only for compiling this target, not its dependencies, so be careful about header files included elsewhere. All paths should be relative to the workspace, not to the current package.

If the package declares the feature no_copts_tokenization, Bourne shell tokenization applies only to strings that consist of a single "Make" variable.
2[]�
cxxopts{
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line to this target, as well as to every rule that depends on it. Be very careful, since this may have far-reaching effects. When in doubt, add define values to local_defines instead.
2[]8
deps*The list of dependencies of current target2[]�
dynamic_deps�
These are other cc_shared_library dependencies the current target depends on.

The cc_shared_library implementation will use the list of dynamic_deps (transitively, i.e. also the dynamic_deps of the current target's dynamic_deps) to decide which cc_libraries in the transitive deps should not be linked in because they are already provided by a different cc_shared_library. 
2[]�
hdrs_map�
Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory. 
 �
include_prefix�
The prefix to add to the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at is the value of this attribute prepended to their repository-relative path.

The prefix in the strip_include_prefix attribute is removed before this prefix is added.
2""�
includes�
List of include dirs to be added to the compile line.
Subject to "Make variable" substitution. Each string is prepended with -isystem and added to COPTS. Unlike COPTS, these flags are added for this rule and every rule that depends on it. (Note: not the rules it depends upon!) Be very careful, since this may have far-reaching effects. When in doubt, add "-I" flags to COPTS instead.

Headers must be added to srcs or hdrs, otherwise they will not be available to dependent rules when compilation is sandboxed (the default).
2[]�
link_extra_lib�
Control linking of extra libraries.

By default, C++ binaries are linked against //tools/cpp:link_extra_lib, which by default depends on the label flag //tools/cpp:link_extra_libs. Without setting the flag, this library is empty by default. Setting the label flag allows linking optional dependencies, such as overrides for weak symbols, interceptors for shared library functions, or special runtime libraries (for malloc replacements, prefer malloc or --custom_malloc). Setting this attribute to None disables this behaviour. 
2&@bazel_tools//tools/cpp:link_extra_lib�
linkopts�
Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.
2[]5

linkstaticLink the binary in static mode.2True�
local_defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line for this target, but not to its dependents.
2[]�
malloc�
Override the default dependency on malloc.

By default, C++ binaries are linked against //tools/cpp:malloc, which is an empty library so the binary ends up using libc malloc. This label must refer to a cc_library. If compilation is for a non-C++ rule, this option has no effect. The value of this attribute is ignored if linkshared=True is specified. 
2@bazel_tools//tools/cpp:malloc�
nocopts�
Remove matching options from the C++ compilation command. Subject to "Make" variable substitution. The value of this attribute is interpreted as a regular expression. Any preexisting COPTS that match this regular expression (including values explicitly specified in the rule's copts attribute) will be removed from COPTS for purposes of compiling this rule. This attribute should not be needed or used outside of third_party. The values are not preprocessed in any way other than the "Make" variable substitution. 
2""�
private_hdrsl
List of headers that CANNOT be included by dependent rules.
Notice: the cutoff happens during compilation.
2[]�
public_hdrsv
List of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.
2[]
reexport_deps
2[]%
srcsThe list of source files. �
strip_include_prefix�
The prefix to strip from the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at their path with this prefix cut off.

If it's a relative path, it's taken as a package-relative one. If it's an absolute one, it's understood as a repository-relative path.

The prefix in the include_prefix attribute is added after this prefix is stripped.
2""";
cc_so2@@rules_cc_hdrs_map//cc_hdrs_map/private:cc_so.bzl
**,
*
nameA unique name for this target. �
�
additional_linker_inputs�
Pass these files to the C++ linker command.

For example, compiled Windows .res files can be provided here to be embedded in the binary target.
2[]�
�

alwayslink�
If 1, any binary that depends (directly or indirectly) on this C++ library will link in all the object files for the files listed in srcs, even if some contain no symbols referenced by the binary. This is useful if your code isn't explicitly called by code in the binary, e.g., if your code registers to receive some callback provided by some service.
2True�
�
	conlyoptsy
Add these options to the C compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
�
copts�
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.
Each string in this attribute is added in the given order to COPTS before compiling the binary target. The flags take effect only for compiling this target, not its dependencies, so be careful about header files included elsewhere. All paths should be relative to the workspace, not to the current package.

If the package declares the feature no_copts_tokenization, Bourne shell tokenization applies only to strings that consist of a single "Make" variable.
2[]�
�
cxxopts{
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
�
defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line to this target, as well as to every rule that depends on it. Be very careful, since this may have far-reaching effects. When in doubt, add define values to local_defines instead.
2[]:
8
deps*The list of dependencies of current target2[]�
�
dynamic_deps�
These are other cc_shared_library dependencies the current target depends on.

The cc_shared_library implementation will use the list of dynamic_deps (transitively, i.e. also the dynamic_deps of the current target's dynamic_deps) to decide which cc_libraries in the transitive deps should not be linked in because they are already provided by a different cc_shared_library. 
2[]�
�
hdrs_map�
Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory. 
 �
�
include_prefix�
The prefix to add to the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at is the value of this attribute prepended to their repository-relative path.

The prefix in the strip_include_prefix attribute is removed before this prefix is added.
2""�
�
includes�
List of include dirs to be added to the compile line.
Subject to "Make variable" substitution. Each string is prepended with -isystem and added to COPTS. Unlike COPTS, these flags are added for this rule and every rule that depends on it. (Note: not the rules it depends upon!) Be very careful, since this may have far-reaching effects. When in doubt, add "-I" flags to COPTS instead.

Headers must be added to srcs or hdrs, otherwise they will not be available to dependent rules when compilation is sandboxed (the default).
2[]�
�
link_extra_lib�
Control linking of extra libraries.

By default, C++ binaries are linked against //tools/cpp:link_extra_lib, which by default depends on the label flag //tools/cpp:link_extra_libs. Without setting the flag, this library is empty by default. Setting the label flag allows linking optional dependencies, such as overrides for weak symbols, interceptors for shared library functions, or special runtime libraries (for malloc replacements, prefer malloc or --custom_malloc). Setting this attribute to None disables this behaviour. 
2&@bazel_tools//tools/cpp:link_extra_lib�
�
linkopts�
Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.
2[]7
5

linkstaticLink the binary in static mode.2True�
�
local_defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line for this target, but not to its dependents.
2[]�
�
malloc�
Override the default dependency on malloc.

By default, C++ binaries are linked against //tools/cpp:malloc, which is an empty library so the binary ends up using libc malloc. This label must refer to a cc_library. If compilation is for a non-C++ rule, this option has no effect. The value of this attribute is ignored if linkshared=True is specified. 
2@bazel_tools//tools/cpp:malloc�
�
nocopts�
Remove matching options from the C++ compilation command. Subject to "Make" variable substitution. The value of this attribute is interpreted as a regular expression. Any preexisting COPTS that match this regular expression (including values explicitly specified in the rule's copts attribute) will be removed from COPTS for purposes of compiling this rule. This attribute should not be needed or used outside of third_party. The values are not preprocessed in any way other than the "Make" variable substitution. 
2""�
�
private_hdrsl
List of headers that CANNOT be included by dependent rules.
Notice: the cutoff happens during compilation.
2[]�
�
public_hdrsv
List of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.
2[]

reexport_deps
2[]'
%
srcsThe list of source files. �
�
strip_include_prefix�
The prefix to strip from the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at their path with this prefix cut off.

If it's a relative path, it's taken as a package-relative one. If it's an absolute one, it's understood as a repository-relative path.

The prefix in the include_prefix attribute is added after this prefix is stripped.
2""�
//cc_hdrs_map/actions:defs.bzlrd
2
rules_cc_hdrs_mapcc_hdrs_map/actionsdefs.bzl 
actionsactions
;B
D�
//cc_hdrs_map/private:attrs.bzlru
3
rules_cc_hdrs_mapcc_hdrs_map/private	attrs.bzl0
get_cc_so_attrsget_cc_so_attrs
<K
M�
$//cc_hdrs_map/providers:hdrs_map.bzlrr
8
rules_cc_hdrs_mapcc_hdrs_map/providershdrs_map.bzl(
HdrsMapInfoHdrsMapInfo
AL
N;This module contains the implementation of the cc_so rule. �$
8
rules_cc_hdrs_mapcc_hdrs_map/providershdrs_map.bzl�	
glob_match�Check if given path matches the simple glob expression.

Supported special characters:
`*` Will match zero or more characters, until it hits '/'
`?` Will match exactly one character of any kind, except for '/'
`<expr>/**` Will match anything after '<expr>/'
`**/<expr>` Will match greedily until it hits /<expr> (otherwise it
    will not be considered a match)
`<expr>**<expr>` just as '*`

This implementation is a clusterfuck, yet I hardly see
any room to improve it in starlark.
*�
�

glob_match'
patternglob expression to match (>
text2the path against which we are matching the pattern (�Check if given path matches the simple glob expression.

Supported special characters:
`*` Will match zero or more characters, until it hits '/'
`?` Will match exactly one character of any kind, except for '/'
`<expr>/**` Will match anything after '<expr>/'
`**/<expr>` Will match greedily until it hits /<expr> (otherwise it
    will not be considered a match)
`<expr>**<expr>` just as '*`

This implementation is a clusterfuck, yet I hardly see
any room to improve it in starlark.
"1
/Boolean: indicating if text matches the pattern2E

glob_match7@@rules_cc_hdrs_map//cc_hdrs_map/providers:hdrs_map.bzl
�materialize_hdrs_mapping�Materialize the expected file hierarchy.

Creates the header file hierarchy accordingly to specifications
in passed-in hdrs_map under 'vhm' directory.
*�
�
materialize_hdrs_mapping6
invoker_label!label of rule invoking the method ( 
actionsbazel ctx.actions (<
hdrs_map,HdrsMapInfo representing the headers mapping (K
hdrs?list of all header files that should be matched against the map (�Materialize the expected file hierarchy.

Creates the header file hierarchy accordingly to specifications
in passed-in hdrs_map under 'vhm' directory.
"�
�(materialized_include_path, materialized_hdrs_files): tuple of include_path to
the created header files dir and list of paths to all header files created.2S
materialize_hdrs_mapping7@@rules_cc_hdrs_map//cc_hdrs_map/providers:hdrs_map.bzl
���merge_hdrs_map)Merge two HdrsMapInfo hdrs_maps together.*�
�
merge_hdrs_map2
hdr_maps_onefirst HdrsMapInfo to be merged (3
hdr_maps_twosecond HdrsMapInfo to be merged ()Merge two HdrsMapInfo hdrs_maps together."!
Dict: merged together hdrs_maps2I
merge_hdrs_map7@@rules_cc_hdrs_map//cc_hdrs_map/providers:hdrs_map.bzl
���merge_hdrs_maps_info_from_deps�Aggregate any HdrsMapInfo from the dependencies.

Merges all HdrsMapInfos from the dependencies of a bazel target into
a singular description of mappings that exists.
*�
�
merge_hdrs_maps_info_from_deps4
deps(list of dependencies of the Bazel target (2
hdrs_map"map of headers of the Bazel target (�Aggregate any HdrsMapInfo from the dependencies.

Merges all HdrsMapInfos from the dependencies of a bazel target into
a singular description of mappings that exists.
"�
�(public_hdrs, private_hdrs, hdrs_map, hdr_maps_deps): tuple
containing list of public headers, private headers, merged hdrs_map and other dependencies.2Y
merge_hdrs_maps_info_from_deps7@@rules_cc_hdrs_map//cc_hdrs_map/providers:hdrs_map.bzl
���HdrsMapInfoTRepresents grouping of CC header files, alongsdie with their intended include paths.2�
�
HdrsMapInfoTRepresents grouping of CC header files, alongsdie with their intended include paths.M
public_hdrs>Headers which should be exposed after the compilation is done.L
private_hdrs<Headers that should not be propagated after the compilation.�
hdrs_map�(string_list_dict) which represents mapping between pattern and its intended include paths (i.e. "**/foo.hpp": ["bar/{filename}"])c
deps[CcInfo-aware dependencies that need to be propagated, for this provider to compile and link"F
HdrsMapInfo7@@rules_cc_hdrs_map//cc_hdrs_map/providers:hdrs_map.bzl
O
M
public_hdrs>Headers which should be exposed after the compilation is done.N
L
private_hdrs<Headers that should not be propagated after the compilation.�
�
hdrs_map�(string_list_dict) which represents mapping between pattern and its intended include paths (i.e. "**/foo.hpp": ["bar/{filename}"])e
c
deps[CcInfo-aware dependencies that need to be propagated, for this provider to compile and link�
#//cc_hdrs_map/actions:copy_file.bzlrm
7
rules_cc_hdrs_mapcc_hdrs_map/actionscopy_file.bzl$
	copy_file	copy_file

DModule describing HdrsMapInfo provider and common operations on it. Ŋ
*
rules_cc_hdrs_mapcc_hdrs_mapdefs.bzl�j
cc_archive�Produce an archive file.

The intended major difference between this rule and rules_cc's `cc_static_library`,
is that this rule does not intend to pull-in all static dependencies.
"�h
�5

cc_archive�Produce an archive file.

The intended major difference between this rule and rules_cc's `cc_static_library`,
is that this rule does not intend to pull-in all static dependencies.
*
nameA unique name for this target. �
additional_linker_inputs�
Pass these files to the C++ linker command.

For example, compiled Windows .res files can be provided here to be embedded in the binary target.
2[]�
	conlyoptsy
Add these options to the C compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
copts�
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.
Each string in this attribute is added in the given order to COPTS before compiling the binary target. The flags take effect only for compiling this target, not its dependencies, so be careful about header files included elsewhere. All paths should be relative to the workspace, not to the current package.

If the package declares the feature no_copts_tokenization, Bourne shell tokenization applies only to strings that consist of a single "Make" variable.
2[]�
cxxopts{
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line to this target, as well as to every rule that depends on it. Be very careful, since this may have far-reaching effects. When in doubt, add define values to local_defines instead.
2[]8
deps*The list of dependencies of current target2[]�
dynamic_deps�
These are other cc_shared_library dependencies the current target depends on.

The cc_shared_library implementation will use the list of dynamic_deps (transitively, i.e. also the dynamic_deps of the current target's dynamic_deps) to decide which cc_libraries in the transitive deps should not be linked in because they are already provided by a different cc_shared_library. 
2[]�
hdrs_map�
Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory. 
 �
include_prefix�
The prefix to add to the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at is the value of this attribute prepended to their repository-relative path.

The prefix in the strip_include_prefix attribute is removed before this prefix is added.
2""�
includes�
List of include dirs to be added to the compile line.
Subject to "Make variable" substitution. Each string is prepended with -isystem and added to COPTS. Unlike COPTS, these flags are added for this rule and every rule that depends on it. (Note: not the rules it depends upon!) Be very careful, since this may have far-reaching effects. When in doubt, add "-I" flags to COPTS instead.

Headers must be added to srcs or hdrs, otherwise they will not be available to dependent rules when compilation is sandboxed (the default).
2[]�
link_extra_lib�
Control linking of extra libraries.

By default, C++ binaries are linked against //tools/cpp:link_extra_lib, which by default depends on the label flag //tools/cpp:link_extra_libs. Without setting the flag, this library is empty by default. Setting the label flag allows linking optional dependencies, such as overrides for weak symbols, interceptors for shared library functions, or special runtime libraries (for malloc replacements, prefer malloc or --custom_malloc). Setting this attribute to None disables this behaviour. 
2&@bazel_tools//tools/cpp:link_extra_lib�
linkopts�
Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.
2[]5

linkstaticLink the binary in static mode.2True�
local_defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line for this target, but not to its dependents.
2[]�
malloc�
Override the default dependency on malloc.

By default, C++ binaries are linked against //tools/cpp:malloc, which is an empty library so the binary ends up using libc malloc. This label must refer to a cc_library. If compilation is for a non-C++ rule, this option has no effect. The value of this attribute is ignored if linkshared=True is specified. 
2@bazel_tools//tools/cpp:malloc�
nocopts�
Remove matching options from the C++ compilation command. Subject to "Make" variable substitution. The value of this attribute is interpreted as a regular expression. Any preexisting COPTS that match this regular expression (including values explicitly specified in the rule's copts attribute) will be removed from COPTS for purposes of compiling this rule. This attribute should not be needed or used outside of third_party. The values are not preprocessed in any way other than the "Make" variable substitution. 
2""�
private_hdrsl
List of headers that CANNOT be included by dependent rules.
Notice: the cutoff happens during compilation.
2[]�
public_hdrsv
List of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.
2[]
reexport_deps
2[]%
srcsThe list of source files. �
strip_include_prefix�
The prefix to strip from the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at their path with this prefix cut off.

If it's a relative path, it's taken as a package-relative one. If it's an absolute one, it's understood as a repository-relative path.

The prefix in the include_prefix attribute is added after this prefix is stripped.
2"""7

cc_archive)@@rules_cc_hdrs_map//cc_hdrs_map:defs.bzl
&&,
*
nameA unique name for this target. �
�
additional_linker_inputs�
Pass these files to the C++ linker command.

For example, compiled Windows .res files can be provided here to be embedded in the binary target.
2[]�
�
	conlyoptsy
Add these options to the C compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
�
copts�
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.
Each string in this attribute is added in the given order to COPTS before compiling the binary target. The flags take effect only for compiling this target, not its dependencies, so be careful about header files included elsewhere. All paths should be relative to the workspace, not to the current package.

If the package declares the feature no_copts_tokenization, Bourne shell tokenization applies only to strings that consist of a single "Make" variable.
2[]�
�
cxxopts{
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
�
defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line to this target, as well as to every rule that depends on it. Be very careful, since this may have far-reaching effects. When in doubt, add define values to local_defines instead.
2[]:
8
deps*The list of dependencies of current target2[]�
�
dynamic_deps�
These are other cc_shared_library dependencies the current target depends on.

The cc_shared_library implementation will use the list of dynamic_deps (transitively, i.e. also the dynamic_deps of the current target's dynamic_deps) to decide which cc_libraries in the transitive deps should not be linked in because they are already provided by a different cc_shared_library. 
2[]�
�
hdrs_map�
Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory. 
 �
�
include_prefix�
The prefix to add to the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at is the value of this attribute prepended to their repository-relative path.

The prefix in the strip_include_prefix attribute is removed before this prefix is added.
2""�
�
includes�
List of include dirs to be added to the compile line.
Subject to "Make variable" substitution. Each string is prepended with -isystem and added to COPTS. Unlike COPTS, these flags are added for this rule and every rule that depends on it. (Note: not the rules it depends upon!) Be very careful, since this may have far-reaching effects. When in doubt, add "-I" flags to COPTS instead.

Headers must be added to srcs or hdrs, otherwise they will not be available to dependent rules when compilation is sandboxed (the default).
2[]�
�
link_extra_lib�
Control linking of extra libraries.

By default, C++ binaries are linked against //tools/cpp:link_extra_lib, which by default depends on the label flag //tools/cpp:link_extra_libs. Without setting the flag, this library is empty by default. Setting the label flag allows linking optional dependencies, such as overrides for weak symbols, interceptors for shared library functions, or special runtime libraries (for malloc replacements, prefer malloc or --custom_malloc). Setting this attribute to None disables this behaviour. 
2&@bazel_tools//tools/cpp:link_extra_lib�
�
linkopts�
Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.
2[]7
5

linkstaticLink the binary in static mode.2True�
�
local_defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line for this target, but not to its dependents.
2[]�
�
malloc�
Override the default dependency on malloc.

By default, C++ binaries are linked against //tools/cpp:malloc, which is an empty library so the binary ends up using libc malloc. This label must refer to a cc_library. If compilation is for a non-C++ rule, this option has no effect. The value of this attribute is ignored if linkshared=True is specified. 
2@bazel_tools//tools/cpp:malloc�
�
nocopts�
Remove matching options from the C++ compilation command. Subject to "Make" variable substitution. The value of this attribute is interpreted as a regular expression. Any preexisting COPTS that match this regular expression (including values explicitly specified in the rule's copts attribute) will be removed from COPTS for purposes of compiling this rule. This attribute should not be needed or used outside of third_party. The values are not preprocessed in any way other than the "Make" variable substitution. 
2""�
�
private_hdrsl
List of headers that CANNOT be included by dependent rules.
Notice: the cutoff happens during compilation.
2[]�
�
public_hdrsv
List of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.
2[]

reexport_deps
2[]'
%
srcsThe list of source files. �
�
strip_include_prefix�
The prefix to strip from the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at their path with this prefix cut off.

If it's a relative path, it's taken as a package-relative one. If it's an absolute one, it's understood as a repository-relative path.

The prefix in the include_prefix attribute is added after this prefix is stripped.
2""�occ_bin�Produce exectuable binary.

It is intended for this rule, to differ from rules_cc's `cc_binary` in the following
fashion: it aims to automatically gather all of its dynamic dependencies and make them
available during binary execution.
"�m
�7
cc_bin�Produce exectuable binary.

It is intended for this rule, to differ from rules_cc's `cc_binary` in the following
fashion: it aims to automatically gather all of its dynamic dependencies and make them
available during binary execution.
*
nameA unique name for this target. �
additional_linker_inputs�
Pass these files to the C++ linker command.

For example, compiled Windows .res files can be provided here to be embedded in the binary target.
2[]�
	conlyoptsy
Add these options to the C compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
copts�
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.
Each string in this attribute is added in the given order to COPTS before compiling the binary target. The flags take effect only for compiling this target, not its dependencies, so be careful about header files included elsewhere. All paths should be relative to the workspace, not to the current package.

If the package declares the feature no_copts_tokenization, Bourne shell tokenization applies only to strings that consist of a single "Make" variable.
2[]�
cxxopts{
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
data�
The list of files needed by this library at runtime. See general comments about data at Typical attributes defined by most build rules.

If a data is the name of a generated file, then this cc_library rule automatically depends on the generating rule.

If a data is a rule name, then this cc_library rule automatically depends on that rule, and that rule's outs are automatically added to this cc_library's data files. 
2[]�
defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line to this target, as well as to every rule that depends on it. Be very careful, since this may have far-reaching effects. When in doubt, add define values to local_defines instead.
2[]8
deps*The list of dependencies of current target2[]�
dynamic_deps�
These are other cc_shared_library dependencies the current target depends on.

The cc_shared_library implementation will use the list of dynamic_deps (transitively, i.e. also the dynamic_deps of the current target's dynamic_deps) to decide which cc_libraries in the transitive deps should not be linked in because they are already provided by a different cc_shared_library. 
2[]�
hdrs_map�
Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory. 
 �
includes�
List of include dirs to be added to the compile line.
Subject to "Make variable" substitution. Each string is prepended with -isystem and added to COPTS. Unlike COPTS, these flags are added for this rule and every rule that depends on it. (Note: not the rules it depends upon!) Be very careful, since this may have far-reaching effects. When in doubt, add "-I" flags to COPTS instead.

Headers must be added to srcs or hdrs, otherwise they will not be available to dependent rules when compilation is sandboxed (the default).
2[]�
link_extra_lib�
Control linking of extra libraries.

By default, C++ binaries are linked against //tools/cpp:link_extra_lib, which by default depends on the label flag //tools/cpp:link_extra_libs. Without setting the flag, this library is empty by default. Setting the label flag allows linking optional dependencies, such as overrides for weak symbols, interceptors for shared library functions, or special runtime libraries (for malloc replacements, prefer malloc or --custom_malloc). Setting this attribute to None disables this behaviour. 
2&@bazel_tools//tools/cpp:link_extra_lib�
linkopts�
Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.
2[]5

linkstaticLink the binary in static mode.2True�
local_defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line for this target, but not to its dependents.
2[]�
malloc�
Override the default dependency on malloc.

By default, C++ binaries are linked against //tools/cpp:malloc, which is an empty library so the binary ends up using libc malloc. This label must refer to a cc_library. If compilation is for a non-C++ rule, this option has no effect. The value of this attribute is ignored if linkshared=True is specified. 
2@bazel_tools//tools/cpp:malloc�
nocopts�
Remove matching options from the C++ compilation command. Subject to "Make" variable substitution. The value of this attribute is interpreted as a regular expression. Any preexisting COPTS that match this regular expression (including values explicitly specified in the rule's copts attribute) will be removed from COPTS for purposes of compiling this rule. This attribute should not be needed or used outside of third_party. The values are not preprocessed in any way other than the "Make" variable substitution. 
2""�
private_hdrsl
List of headers that CANNOT be included by dependent rules.
Notice: the cutoff happens during compilation.
2[]�
public_hdrsv
List of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.
2[]
reexport_deps
2[]%
srcsThe list of source files. �
stamp�
Whether to encode build information into the binary. Possible values:

  * stamp = 1: Always stamp the build information into the binary, even in --nostamp builds. This setting should be avoided, since it potentially kills remote caching for the binary and any downstream actions that depend on it.

  * stamp = 0: Always replace build information by constant values. This gives good build result caching.

  * stamp = -1: Embedding of build information is controlled by the --[no]stamp flag.

Stamped binaries are not rebuilt unless their dependencies change.
2-1"3
cc_bin)@@rules_cc_hdrs_map//cc_hdrs_map:defs.bzl
,
*
nameA unique name for this target. �
�
additional_linker_inputs�
Pass these files to the C++ linker command.

For example, compiled Windows .res files can be provided here to be embedded in the binary target.
2[]�
�
	conlyoptsy
Add these options to the C compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
�
copts�
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.
Each string in this attribute is added in the given order to COPTS before compiling the binary target. The flags take effect only for compiling this target, not its dependencies, so be careful about header files included elsewhere. All paths should be relative to the workspace, not to the current package.

If the package declares the feature no_copts_tokenization, Bourne shell tokenization applies only to strings that consist of a single "Make" variable.
2[]�
�
cxxopts{
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
�
data�
The list of files needed by this library at runtime. See general comments about data at Typical attributes defined by most build rules.

If a data is the name of a generated file, then this cc_library rule automatically depends on the generating rule.

If a data is a rule name, then this cc_library rule automatically depends on that rule, and that rule's outs are automatically added to this cc_library's data files. 
2[]�
�
defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line to this target, as well as to every rule that depends on it. Be very careful, since this may have far-reaching effects. When in doubt, add define values to local_defines instead.
2[]:
8
deps*The list of dependencies of current target2[]�
�
dynamic_deps�
These are other cc_shared_library dependencies the current target depends on.

The cc_shared_library implementation will use the list of dynamic_deps (transitively, i.e. also the dynamic_deps of the current target's dynamic_deps) to decide which cc_libraries in the transitive deps should not be linked in because they are already provided by a different cc_shared_library. 
2[]�
�
hdrs_map�
Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory. 
 �
�
includes�
List of include dirs to be added to the compile line.
Subject to "Make variable" substitution. Each string is prepended with -isystem and added to COPTS. Unlike COPTS, these flags are added for this rule and every rule that depends on it. (Note: not the rules it depends upon!) Be very careful, since this may have far-reaching effects. When in doubt, add "-I" flags to COPTS instead.

Headers must be added to srcs or hdrs, otherwise they will not be available to dependent rules when compilation is sandboxed (the default).
2[]�
�
link_extra_lib�
Control linking of extra libraries.

By default, C++ binaries are linked against //tools/cpp:link_extra_lib, which by default depends on the label flag //tools/cpp:link_extra_libs. Without setting the flag, this library is empty by default. Setting the label flag allows linking optional dependencies, such as overrides for weak symbols, interceptors for shared library functions, or special runtime libraries (for malloc replacements, prefer malloc or --custom_malloc). Setting this attribute to None disables this behaviour. 
2&@bazel_tools//tools/cpp:link_extra_lib�
�
linkopts�
Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.
2[]7
5

linkstaticLink the binary in static mode.2True�
�
local_defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line for this target, but not to its dependents.
2[]�
�
malloc�
Override the default dependency on malloc.

By default, C++ binaries are linked against //tools/cpp:malloc, which is an empty library so the binary ends up using libc malloc. This label must refer to a cc_library. If compilation is for a non-C++ rule, this option has no effect. The value of this attribute is ignored if linkshared=True is specified. 
2@bazel_tools//tools/cpp:malloc�
�
nocopts�
Remove matching options from the C++ compilation command. Subject to "Make" variable substitution. The value of this attribute is interpreted as a regular expression. Any preexisting COPTS that match this regular expression (including values explicitly specified in the rule's copts attribute) will be removed from COPTS for purposes of compiling this rule. This attribute should not be needed or used outside of third_party. The values are not preprocessed in any way other than the "Make" variable substitution. 
2""�
�
private_hdrsl
List of headers that CANNOT be included by dependent rules.
Notice: the cutoff happens during compilation.
2[]�
�
public_hdrsv
List of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.
2[]

reexport_deps
2[]'
%
srcsThe list of source files. �
�
stamp�
Whether to encode build information into the binary. Possible values:

  * stamp = 1: Always stamp the build information into the binary, even in --nostamp builds. This setting should be avoided, since it potentially kills remote caching for the binary and any downstream actions that depend on it.

  * stamp = 0: Always replace build information by constant values. This gives good build result caching.

  * stamp = -1: Embedding of build information is controlled by the --[no]stamp flag.

Stamped binaries are not rebuilt unless their dependencies change.
2-1�cc_hdrs�Define header files properties.

This rule groups headers into a singular target and allows
to attach 'include_path' modifications information to them,
so that wherever the header files are being used, they can
be used with their intended include paths.
"�
�	
cc_hdrs�Define header files properties.

This rule groups headers into a singular target and allows
to attach 'include_path' modifications information to them,
so that wherever the header files are being used, they can
be used with their intended include paths.
*
nameA unique name for this target. 8
deps*The list of dependencies of current target2[]�
hdrs_map�
Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory. 
 �
private_hdrsl
List of headers that CANNOT be included by dependent rules.
Notice: the cutoff happens during compilation.
2[]�
public_hdrsv
List of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.
2[]"4
cc_hdrs)@@rules_cc_hdrs_map//cc_hdrs_map:defs.bzl
,,,
*
nameA unique name for this target. :
8
deps*The list of dependencies of current target2[]�
�
hdrs_map�
Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory. 
 �
�
private_hdrsl
List of headers that CANNOT be included by dependent rules.
Notice: the cutoff happens during compilation.
2[]�
�
public_hdrsv
List of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.
2[]�qcc_so�Produce shared object library.

The intended difference between this rule and the rules_cc's cc_shared_library is
to unify handling of dependencies that are equipped with CcInfo and CcSharedLibraryInfo
(use singular attribute of deps to track them both).
"�o
�8
cc_so�Produce shared object library.

The intended difference between this rule and the rules_cc's cc_shared_library is
to unify handling of dependencies that are equipped with CcInfo and CcSharedLibraryInfo
(use singular attribute of deps to track them both).
*
nameA unique name for this target. �
additional_linker_inputs�
Pass these files to the C++ linker command.

For example, compiled Windows .res files can be provided here to be embedded in the binary target.
2[]�

alwayslink�
If 1, any binary that depends (directly or indirectly) on this C++ library will link in all the object files for the files listed in srcs, even if some contain no symbols referenced by the binary. This is useful if your code isn't explicitly called by code in the binary, e.g., if your code registers to receive some callback provided by some service.
2True�
	conlyoptsy
Add these options to the C compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
copts�
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.
Each string in this attribute is added in the given order to COPTS before compiling the binary target. The flags take effect only for compiling this target, not its dependencies, so be careful about header files included elsewhere. All paths should be relative to the workspace, not to the current package.

If the package declares the feature no_copts_tokenization, Bourne shell tokenization applies only to strings that consist of a single "Make" variable.
2[]�
cxxopts{
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line to this target, as well as to every rule that depends on it. Be very careful, since this may have far-reaching effects. When in doubt, add define values to local_defines instead.
2[]8
deps*The list of dependencies of current target2[]�
dynamic_deps�
These are other cc_shared_library dependencies the current target depends on.

The cc_shared_library implementation will use the list of dynamic_deps (transitively, i.e. also the dynamic_deps of the current target's dynamic_deps) to decide which cc_libraries in the transitive deps should not be linked in because they are already provided by a different cc_shared_library. 
2[]�
hdrs_map�
Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory. 
 �
include_prefix�
The prefix to add to the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at is the value of this attribute prepended to their repository-relative path.

The prefix in the strip_include_prefix attribute is removed before this prefix is added.
2""�
includes�
List of include dirs to be added to the compile line.
Subject to "Make variable" substitution. Each string is prepended with -isystem and added to COPTS. Unlike COPTS, these flags are added for this rule and every rule that depends on it. (Note: not the rules it depends upon!) Be very careful, since this may have far-reaching effects. When in doubt, add "-I" flags to COPTS instead.

Headers must be added to srcs or hdrs, otherwise they will not be available to dependent rules when compilation is sandboxed (the default).
2[]�
link_extra_lib�
Control linking of extra libraries.

By default, C++ binaries are linked against //tools/cpp:link_extra_lib, which by default depends on the label flag //tools/cpp:link_extra_libs. Without setting the flag, this library is empty by default. Setting the label flag allows linking optional dependencies, such as overrides for weak symbols, interceptors for shared library functions, or special runtime libraries (for malloc replacements, prefer malloc or --custom_malloc). Setting this attribute to None disables this behaviour. 
2&@bazel_tools//tools/cpp:link_extra_lib�
linkopts�
Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.
2[]5

linkstaticLink the binary in static mode.2True�
local_defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line for this target, but not to its dependents.
2[]�
malloc�
Override the default dependency on malloc.

By default, C++ binaries are linked against //tools/cpp:malloc, which is an empty library so the binary ends up using libc malloc. This label must refer to a cc_library. If compilation is for a non-C++ rule, this option has no effect. The value of this attribute is ignored if linkshared=True is specified. 
2@bazel_tools//tools/cpp:malloc�
nocopts�
Remove matching options from the C++ compilation command. Subject to "Make" variable substitution. The value of this attribute is interpreted as a regular expression. Any preexisting COPTS that match this regular expression (including values explicitly specified in the rule's copts attribute) will be removed from COPTS for purposes of compiling this rule. This attribute should not be needed or used outside of third_party. The values are not preprocessed in any way other than the "Make" variable substitution. 
2""�
private_hdrsl
List of headers that CANNOT be included by dependent rules.
Notice: the cutoff happens during compilation.
2[]�
public_hdrsv
List of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.
2[]
reexport_deps
2[]%
srcsThe list of source files. �
strip_include_prefix�
The prefix to strip from the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at their path with this prefix cut off.

If it's a relative path, it's taken as a package-relative one. If it's an absolute one, it's understood as a repository-relative path.

The prefix in the include_prefix attribute is added after this prefix is stripped.
2"""2
cc_so)@@rules_cc_hdrs_map//cc_hdrs_map:defs.bzl
**,
*
nameA unique name for this target. �
�
additional_linker_inputs�
Pass these files to the C++ linker command.

For example, compiled Windows .res files can be provided here to be embedded in the binary target.
2[]�
�

alwayslink�
If 1, any binary that depends (directly or indirectly) on this C++ library will link in all the object files for the files listed in srcs, even if some contain no symbols referenced by the binary. This is useful if your code isn't explicitly called by code in the binary, e.g., if your code registers to receive some callback provided by some service.
2True�
�
	conlyoptsy
Add these options to the C compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
�
copts�
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.
Each string in this attribute is added in the given order to COPTS before compiling the binary target. The flags take effect only for compiling this target, not its dependencies, so be careful about header files included elsewhere. All paths should be relative to the workspace, not to the current package.

If the package declares the feature no_copts_tokenization, Bourne shell tokenization applies only to strings that consist of a single "Make" variable.
2[]�
�
cxxopts{
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
�
defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line to this target, as well as to every rule that depends on it. Be very careful, since this may have far-reaching effects. When in doubt, add define values to local_defines instead.
2[]:
8
deps*The list of dependencies of current target2[]�
�
dynamic_deps�
These are other cc_shared_library dependencies the current target depends on.

The cc_shared_library implementation will use the list of dynamic_deps (transitively, i.e. also the dynamic_deps of the current target's dynamic_deps) to decide which cc_libraries in the transitive deps should not be linked in because they are already provided by a different cc_shared_library. 
2[]�
�
hdrs_map�
Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory. 
 �
�
include_prefix�
The prefix to add to the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at is the value of this attribute prepended to their repository-relative path.

The prefix in the strip_include_prefix attribute is removed before this prefix is added.
2""�
�
includes�
List of include dirs to be added to the compile line.
Subject to "Make variable" substitution. Each string is prepended with -isystem and added to COPTS. Unlike COPTS, these flags are added for this rule and every rule that depends on it. (Note: not the rules it depends upon!) Be very careful, since this may have far-reaching effects. When in doubt, add "-I" flags to COPTS instead.

Headers must be added to srcs or hdrs, otherwise they will not be available to dependent rules when compilation is sandboxed (the default).
2[]�
�
link_extra_lib�
Control linking of extra libraries.

By default, C++ binaries are linked against //tools/cpp:link_extra_lib, which by default depends on the label flag //tools/cpp:link_extra_libs. Without setting the flag, this library is empty by default. Setting the label flag allows linking optional dependencies, such as overrides for weak symbols, interceptors for shared library functions, or special runtime libraries (for malloc replacements, prefer malloc or --custom_malloc). Setting this attribute to None disables this behaviour. 
2&@bazel_tools//tools/cpp:link_extra_lib�
�
linkopts�
Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.
2[]7
5

linkstaticLink the binary in static mode.2True�
�
local_defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line for this target, but not to its dependents.
2[]�
�
malloc�
Override the default dependency on malloc.

By default, C++ binaries are linked against //tools/cpp:malloc, which is an empty library so the binary ends up using libc malloc. This label must refer to a cc_library. If compilation is for a non-C++ rule, this option has no effect. The value of this attribute is ignored if linkshared=True is specified. 
2@bazel_tools//tools/cpp:malloc�
�
nocopts�
Remove matching options from the C++ compilation command. Subject to "Make" variable substitution. The value of this attribute is interpreted as a regular expression. Any preexisting COPTS that match this regular expression (including values explicitly specified in the rule's copts attribute) will be removed from COPTS for purposes of compiling this rule. This attribute should not be needed or used outside of third_party. The values are not preprocessed in any way other than the "Make" variable substitution. 
2""�
�
private_hdrsl
List of headers that CANNOT be included by dependent rules.
Notice: the cutoff happens during compilation.
2[]�
�
public_hdrsv
List of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.
2[]

reexport_deps
2[]'
%
srcsThe list of source files. �
�
strip_include_prefix�
The prefix to strip from the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at their path with this prefix cut off.

If it's a relative path, it's taken as a package-relative one. If it's an absolute one, it's understood as a repository-relative path.

The prefix in the include_prefix attribute is added after this prefix is stripped.
2""�HdrsMapInfoTRepresents grouping of CC header files, alongsdie with their intended include paths.2�
�
HdrsMapInfoTRepresents grouping of CC header files, alongsdie with their intended include paths.M
public_hdrs>Headers which should be exposed after the compilation is done.L
private_hdrs<Headers that should not be propagated after the compilation.�
hdrs_map�(string_list_dict) which represents mapping between pattern and its intended include paths (i.e. "**/foo.hpp": ["bar/{filename}"])c
deps[CcInfo-aware dependencies that need to be propagated, for this provider to compile and link"8
HdrsMapInfo)@@rules_cc_hdrs_map//cc_hdrs_map:defs.bzl
O
M
public_hdrs>Headers which should be exposed after the compilation is done.N
L
private_hdrs<Headers that should not be propagated after the compilation.�
�
hdrs_map�(string_list_dict) which represents mapping between pattern and its intended include paths (i.e. "**/foo.hpp": ["bar/{filename}"])e
c
deps[CcInfo-aware dependencies that need to be propagated, for this provider to compile and link�
//cc_hdrs_map/actions:defs.bzlre
2
rules_cc_hdrs_mapcc_hdrs_map/actionsdefs.bzl!
actions_actions
I:IB
IIO�
$//cc_hdrs_map/private:cc_archive.bzlrq
8
rules_cc_hdrs_mapcc_hdrs_map/privatecc_archive.bzl'

cc_archive_cc_archive
J@JK
JJ[�
 //cc_hdrs_map/private:cc_bin.bzlre
4
rules_cc_hdrs_mapcc_hdrs_map/private
cc_bin.bzl
cc_bin_cc_bin
K<KC
KKO�
!//cc_hdrs_map/private:cc_hdrs.bzlrh
5
rules_cc_hdrs_mapcc_hdrs_map/privatecc_hdrs.bzl!
cc_hdrs_cc_hdrs
L=LE
LLR�
//cc_hdrs_map/private:cc_so.bzlrb
3
rules_cc_hdrs_mapcc_hdrs_map/private	cc_so.bzl
cc_so_cc_so
M;MA
MML�
$//cc_hdrs_map/providers:hdrs_map.bzlrs
8
rules_cc_hdrs_mapcc_hdrs_map/providershdrs_map.bzl)
HdrsMapInfo_HdrsMapInfo
N@NL
NN]�rules_cc_hdrs_map
---
[![ci](https://github.com/AleksanderGondek/rules_cc_hdrs_map/actions/workflows/ci.yaml/badge.svg)](https://github.com/AleksanderGondek/rules_cc_hdrs_map/actions/workflows/ci.yaml)

This project extends Bazel `CC` build capabilities with headers map implementation (allowing for easy support for most bizzare include path schemes).

In addition, it exposes CC compilation and linking functions in form of Bazel [subrules](https://docs.google.com/document/d/1RbNC88QieKvBEwir7iV5zZU08AaMlOzxhVkPnmKDedQ).

See [examples](/examples) for how to use `rules_cc_hdrs_map` (and why).

## Shortest possible example

```
$ cat foo.hpp
const std::string GREETINGS = "Hello";

$ cat foo.cpp
#include "bar/foo.h"
...

$ cat BUILD.bazel
load("@rules_cc_hdrs_map//cc_hdrs_map:defs.bzl", "cc_bin")

cc_bin(
    name = "foo",
    srcs = [
        "foo.hpp",
        "foo.cpp",
    ],
    hdrs_map = {
        "**/foo.hpp": ["bar/{filename}"],
    }
)

```

## Table of contents
1. [What issue is being addressed?](#what-issue-is-being-addressed)
2. [How the issue is being addressed?](#what-issue-is-being-addressed)
3. [What issue is being addressed?](#how-the-issue-is-being-addressed)
4. Rules
    1. [cc_archive](#cc_archive)
    2. [cc_bin](#cc_bin)
    3. [cc_hdrs](#cc_hdrs)
    4. [cc_so](#cc_so)
5. [HdrsMapInfo provider](#hdrsmapinfo)

## What issue is being addressed?

Creation of arbitrary include paths from existing sources.

_Scenario_: we want to build a C/CPP codebase with Bazel. 

One of its key characteristics is that most of the include statements do not reflect the code structure in the project - for example, header file located under path âname/a.hppâ is never included as âname/a.hppâ, instead an arbitrary list of aliases is used in the code (âx/y/z/a.hppâ, âb.hppâ etc.).  There is no overarching convention that could be used to generalize those statements into another file file hierarchy - in other words, every header file is a special case of its own.

Unfortunately we are forbidden from modifying the code itself and the directory structure (hello from enterprise word). 

As Bazel `rules_cc` have the expectation of header files being included in a way that resembles the file structure in the WORKSPACE (and one can only provide single âinclude prefixâ per library), we need to prepare the âexpected file structureâ before passing them into the `rules_cc`.

In the most naive approach, said âexpected file structureâ is being prepared for each compilable target (copying over files), passing on the already created structure to targets that depend on it. Very quickly conflicts occur and change of a single header file may cascade into rebuilding hundreds of targets.

There has to be a better way!

## How the issue is being addressed? 

The concept of header map is introduced - it is a dictionary, containing mapping between simple glob paths and their desired include paths. For example: â**/a.hppâ: âx/y/z/a.hppâ expresses the intent to import any header file with name âa.hppâ, present during compilation , as âx/y/z/a.hppâ. 

Said header map is propagated across all compatible C/C++ rules (meaning those from this WORKSPACE) and is being merged with all other header maps present. 

No action is being performed up until the moment of compilation - header mappings, resulting from the header map dictionary, are created only for the purposes of compilation and are _NOT_ part of any rule output. This ensures the impact for the Bazel cache is minimal and the compatibility with original `rules_cc`.
�
4
rules_cc_hdrs_mapcc_hdrs_mapworkspace_deps.bzl�cc_hdrs_map_workspace_deps%Load all dependencies of cc_hdrs_map.*�
�
cc_hdrs_map_workspace_deps%Load all dependencies of cc_hdrs_map.2Q
cc_hdrs_map_workspace_deps3@@rules_cc_hdrs_map//cc_hdrs_map:workspace_deps.bzl
�
 //tools/build_defs/repo:http.bzlrj
.
bazel_toolstools/build_defs/repohttp.bzl*
http_archivehttp_archive
7C
E�
!//tools/build_defs/repo:utils.bzlr]
/
bazel_toolstools/build_defs/repo	utils.bzl
maybemaybe
8=
?IThis module exposes a way to load rule dependencies in non-bzlmod usage.  