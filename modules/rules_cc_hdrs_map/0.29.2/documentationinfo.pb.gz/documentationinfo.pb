�
7
rules_cc_hdrs_mapcc_hdrs_map/actionscc_helper.bzla
//cc:defs.bzlrN

rules_ccccdefs.bzl$
	cc_common	cc_common
!*
,
//cc/common:cc_helper.bzlr`
$
rules_cc	cc/commoncc_helper.bzl*
	cc_helperrules_cc_helper
,;
J�
$//cc_hdrs_map/providers:hdrs_map.bzlr�
8
rules_cc_hdrs_mapcc_hdrs_map/providershdrs_map.bzlB
materialize_hdrs_mappingmaterialize_hdrs_mapping
AY*
new_hdrs_mapnew_hdrs_map
]i
k�
)//cc_hdrs_map/providers:hdrs_map_info.bzlr�
=
rules_cc_hdrs_mapcc_hdrs_map/providershdrs_map_info.bzl(
HdrsMapInfoHdrsMapInfo
FQH
quotient_map_hdrs_map_infosquotient_map_hdrs_map_infos
Up
rw	CC_HEADER_EXTENSIONSj]2[
.h
.hh
.hpp
.ipp
.hxx
.h++
.inc
.inl
.tlh
.tli
.H
.tccv	CC_SOURCE_EXTENSIONSj\2Z
.c
.cc
.cpp
.cxx
.c++
.C
.cu
.cl
.s
.S
.asm
.i
.iigThis module serves chiefly as a vehicle for exposing 'privaete' cc_helper methods to current rule set. �
5
rules_cc_hdrs_mapcc_hdrs_map/actionscompile.bzl�
//cc:defs.bzlrn

rules_ccccdefs.bzl
CcInfoCcInfo
!'$
	cc_common	cc_common
+4
6�
//cc:find_cc_toolchain.bzlr�
%
rules_ccccfind_cc_toolchain.bzl4
find_cc_toolchainfind_cc_toolchain
2
use_cc_toolchainuse_cc_toolchain

�
#//cc_hdrs_map/actions:cc_helper.bzlrm
7
rules_cc_hdrs_mapcc_hdrs_map/actionscc_helper.bzl$
	cc_helper	cc_helper
	@	I
		KSThis module contains logic responsible for HdrsMap handling and compilation phase. �
7
rules_cc_hdrs_mapcc_hdrs_map/actionscopy_file.bzl�	copy_fileaCopy file from a to b.

This function will copy file from given source to specified destination.
*�
�
	copy_file
ctx_actions (@
src5(File) source file that should be copied. Must exist. (W
dstL(File) destination file that should be created. Must be declared beforehand. (aCopy file from a to b.

This function will copy file from given source to specified destination.
2C
	copy_file6@@rules_cc_hdrs_map//cc_hdrs_map/actions:copy_file.bzl
_This module exposes the copy_file action. Done to avoid dependency towards skylib (or others). �	
2
rules_cc_hdrs_mapcc_hdrs_map/actionsdefs.bzla
//cc:defs.bzlrN

rules_ccccdefs.bzl$
	cc_common	cc_common
!*
,�
//cc:find_cc_toolchain.bzlrk
%
rules_ccccfind_cc_toolchain.bzl4
find_cc_toolchainfind_cc_toolchain
.?
A�
#//cc_hdrs_map/actions:cc_helper.bzlrn
7
rules_cc_hdrs_mapcc_hdrs_map/actionscc_helper.bzl%
	cc_helper
_cc_helper
?I
X�
!//cc_hdrs_map/actions:compile.bzlrh
5
rules_cc_hdrs_mapcc_hdrs_map/actionscompile.bzl!
compile_compile
=E
R�
)//cc_hdrs_map/actions:link_to_archive.bzlr�
=
rules_cc_hdrs_mapcc_hdrs_map/actionslink_to_archive.bzl1
link_to_archive_link_to_archive
EU
j�
(//cc_hdrs_map/actions:link_to_binary.bzlr}
<
rules_cc_hdrs_mapcc_hdrs_map/actionslink_to_binary.bzl/
link_to_binary_link_to_binary
DS
g�
$//cc_hdrs_map/actions:link_to_so.bzlrq
8
rules_cc_hdrs_mapcc_hdrs_map/actionslink_to_so.bzl'

link_to_so_link_to_so
	@	K
		[_This module defines the CC compilation phase actions which are exposed publicalyl as subrules. �
=
rules_cc_hdrs_mapcc_hdrs_map/actionslink_to_archive.bzl�
//cc:action_names.bzlr�
 
rules_ccccaction_names.bzlX
#CPP_LINK_STATIC_LIBRARY_ACTION_NAME#CPP_LINK_STATIC_LIBRARY_ACTION_NAME
)L
N�
//cc:defs.bzlrn

rules_ccccdefs.bzl
CcInfoCcInfo
!'$
	cc_common	cc_common
+4
6�
//cc:find_cc_toolchain.bzlr�
%
rules_ccccfind_cc_toolchain.bzl4
find_cc_toolchainfind_cc_toolchain
2
use_cc_toolchainuse_cc_toolchain

	�
#//cc_hdrs_map/actions:cc_helper.bzlrm
7
rules_cc_hdrs_mapcc_hdrs_map/actionscc_helper.bzl$
	cc_helper	cc_helper

@
I


KC" This module contains logic responsible for linking into .a file. �
<
rules_cc_hdrs_mapcc_hdrs_map/actionslink_to_binary.bzl�
//cc:defs.bzlrn

rules_ccccdefs.bzl
CcInfoCcInfo
!'$
	cc_common	cc_common
+4
6�
//cc:find_cc_toolchain.bzlr�
%
rules_ccccfind_cc_toolchain.bzl4
find_cc_toolchainfind_cc_toolchain
2
use_cc_toolchainuse_cc_toolchain

�
#//cc_hdrs_map/actions:cc_helper.bzlrm
7
rules_cc_hdrs_mapcc_hdrs_map/actionscc_helper.bzl$
	cc_helper	cc_helper
	@	I
		K�
<//cc_hdrs_map/providers:cascading_cc_shared_library_info.bzlr�
P
rules_cc_hdrs_mapcc_hdrs_map/providers$cascading_cc_shared_library_info.bzlJ
CascadingCcSharedLibraryInfoCascadingCcSharedLibraryInfo

Y
u


wJThis module contains logic responsible for creation of executable binary. �

8
rules_cc_hdrs_mapcc_hdrs_map/actionslink_to_so.bzla
//cc:defs.bzlrN

rules_ccccdefs.bzl$
	cc_common	cc_common
!*
,�
//cc:find_cc_toolchain.bzlr�
%
rules_ccccfind_cc_toolchain.bzl4
find_cc_toolchainfind_cc_toolchain
2
use_cc_toolchainuse_cc_toolchain

o
//cc/common:cc_info.bzlrR
"
rules_cc	cc/commoncc_info.bzl
CcInfoCcInfo
	+	1
		3�
&//cc/common:cc_shared_library_info.bzlr{
1
rules_cc	cc/commoncc_shared_library_info.bzl8
CcSharedLibraryInfoCcSharedLibraryInfo

:
M


O�
#//cc_hdrs_map/actions:cc_helper.bzlrm
7
rules_cc_hdrs_mapcc_hdrs_map/actionscc_helper.bzl$
	cc_helper	cc_helper
@I
K�
<//cc_hdrs_map/providers:cascading_cc_shared_library_info.bzlr�
P
rules_cc_hdrs_mapcc_hdrs_map/providers$cascading_cc_shared_library_info.bzlJ
CascadingCcSharedLibraryInfoCascadingCcSharedLibraryInfo
Yu
w�
2//cc_hdrs_map/providers:cc_shared_library_info.bzlr�
F
rules_cc_hdrs_mapcc_hdrs_map/providerscc_shared_library_info.bzlL
merge_cc_shared_library_infosmerge_cc_shared_library_infos
Ol
nBThis module contains logic responsible for linking into .so file. �
3
rules_cc_hdrs_mapcc_hdrs_map/private	attrs.bzl�get_cc_archive_attrsTo be described.*�
t
get_cc_archive_attrsTo be described.2J
get_cc_archive_attrs2@@rules_cc_hdrs_map//cc_hdrs_map/private:attrs.bzl
���get_cc_bin_attrsTo be described*}
k
get_cc_bin_attrsTo be described2F
get_cc_bin_attrs2@@rules_cc_hdrs_map//cc_hdrs_map/private:attrs.bzl
���get_cc_hdrs_attrsTo be described.*�
n
get_cc_hdrs_attrsTo be described.2G
get_cc_hdrs_attrs2@@rules_cc_hdrs_map//cc_hdrs_map/private:attrs.bzl
���get_cc_so_attrsTo be described.*|
j
get_cc_so_attrsTo be described.2E
get_cc_so_attrs2@@rules_cc_hdrs_map//cc_hdrs_map/private:attrs.bzl
���get_cc_so_import_attrsTo be described.*�
x
get_cc_so_import_attrsTo be described.2L
get_cc_so_import_attrs2@@rules_cc_hdrs_map//cc_hdrs_map/private:attrs.bzl
���
#//cc_hdrs_map/actions:cc_helper.bzlr�
7
rules_cc_hdrs_mapcc_hdrs_map/actionscc_helper.bzl:
CC_HEADER_EXTENSIONSCC_HEADER_EXTENSIONS
@T:
CC_SOURCE_EXTENSIONSCC_SOURCE_EXTENSIONS
Xl$
	cc_helper	cc_helper
py
{�
$//cc_hdrs_map/providers:hdrs_map.bzlrt
8
rules_cc_hdrs_mapcc_hdrs_map/providershdrs_map.bzl*
new_hdrs_mapnew_hdrs_map
AM
OJContains common configuration-related entities used by cc_hdrs_map rules. ��
8
rules_cc_hdrs_mapcc_hdrs_map/privatecc_archive.bzl��
cc_archive�Produce an archive file.

The intended major difference between this rule and rules_cc's `cc_static_library`,
is that this rule does not intend to pull-in all static dependencies.
"Ћ
�F

cc_archive�Produce an archive file.

The intended major difference between this rule and rules_cc's `cc_static_library`,
is that this rule does not intend to pull-in all static dependencies.
*
nameA unique name for this target. �
additional_compiler_inputs�
Any additional files you might want to pass to the compiler command line, such as sanitizer ignorelists, for example.
Files specified here can then be used in copts with the $(location) function. 
2[]�
additional_linker_inputs�
Any additional files that you may want to pass to the linker, for example, linker scripts.
You have to separately pass any linker flags that the linker needs in order to be aware of this file.
You can do so via the linkopts attribute.
2[]�
archive_lib_name�
Specify the name of the created .a file (that is decoupled from the rule instance name).
Note, that the 'cc_archive' is opinionated and will remove any leading 'lib' prefix and any '.a' in the name
(meaning 'libTest.a.x64.a' will become 'Test.x64' and will produce 'libTest.x64.a')
2""�
	conlyoptsy
Add these options to the C compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
copts�
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.
Each string in this attribute is added in the given order to COPTS before compiling the binary target. The flags take effect only for compiling this target, not its dependencies, so be careful about header files included elsewhere. All paths should be relative to the workspace, not to the current package.

If the package declares the feature no_copts_tokenization, Bourne shell tokenization applies only to strings that consist of a single "Make" variable.
2[]�
cxxopts{
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
data�
The list of files needed by this target at runtime. See general comments about data at Typical attributes defined by most build rules.
2[]�
defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line to this target, as well as to every rule that depends on it. Be very careful, since this may have far-reaching effects. When in doubt, add define values to local_defines instead.
2[]8
deps*The list of dependencies of current target2[]�
dynamic_deps�
In contrast to `rules_cc`, the dynamic_deps of `rules_cc_hdrs_map` are simply translated into deps parameter,
and the providers (CcInfo vs CcSharedInfo) are used to steer the behavior further.
2[]�
hdrsv
List of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.
2[]�
hdrs_map�
Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory. 
 �
implementation_deps�
The list of other libraries that the library target depends on. Unlike with deps, the headers and include paths of these libraries (and all their transitive deps) are only used for compilation of this library, and not libraries that depend on it. Libraries specified with implementation_deps are still linked in binary targets that depend on this library.
2[]�
implementation_hdrsl
List of headers that CANNOT be included by dependent rules.
Notice: the cutoff happens during compilation.
2[]�
include_prefix�
The prefix to add to the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at is the value of this attribute prepended to their repository-relative path.

The prefix in the strip_include_prefix attribute is removed before this prefix is added.
2""�
includes�
List of include dirs to be added to the compile line.
Subject to "Make variable" substitution. Each string is prepended with -isystem and added to COPTS. Unlike COPTS, these flags are added for this rule and every rule that depends on it. (Note: not the rules it depends upon!) Be very careful, since this may have far-reaching effects. When in doubt, add "-I" flags to COPTS instead.

Headers must be added to srcs or hdrs, otherwise they will not be available to dependent rules when compilation is sandboxed (the default).
2[]�
linkopts�
Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.
2[]�

linksharedz
Create a shared library. To enable this attribute, include linkshared=True in your rule. By default this option is off. 
2False�
	linkstamp�
Simultaneously compiles and links the specified C++ source file into the final binary. This trickery is required to introduce timestamp information into binaries; if we compiled the source file to an object file in the usual way, the timestamp would be incorrect. A linkstamp compilation may not include any particular set of compiler flags and so should not depend on any particular header, compiler option, or other build variable. This option should only be needed in the base package.
2None�

linkstatic�
If enabled and this is a binary or test, this option tells the build tool to link in .a's instead of .so's for user libraries whenever possible. System libraries such as libc (but not the C/C++ runtime libraries, see below) are still linked dynamically, as are libraries for which there is no static library. So the resulting executable will still be dynamically linked, hence only mostly static.
The linkstatic attribute has a different meaning if used on a cc_library() rule. For a C++ library, linkstatic=True indicates that only static linking is allowed, so no .so will be produced. linkstatic=False does not prevent static libraries from being created. The attribute is meant to control the creation of dynamic libraries. 
2False�
local_defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line for this target, but not to its dependents.
2[]�
module_interfaces�
The list of files that are regarded as C++20 Modules Interface.

C++ Standard has no restriction about module interface file extension
* Clang use cppm
* GCC can use any source file extension
* MSVC use ixx

The use is guarded by the flag --experimental_cpp_modules.
2[]�
nocopts�
Remove matching options from the C++ compilation command. Subject to "Make" variable substitution. The value of this attribute is interpreted as a regular expression. Any preexisting COPTS that match this regular expression (including values explicitly specified in the rule's copts attribute) will be removed from COPTS for purposes of compiling this rule. This attribute should not be needed or used outside of third_party. The values are not preprocessed in any way other than the "Make" variable substitution. 
2""
reexport_deps2[]%
srcsThe list of source files. �
strip_include_prefix�
The prefix to strip from the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at their path with this prefix cut off.

If it's a relative path, it's taken as a package-relative one. If it's an absolute one, it's understood as a repository-relative path.

The prefix in the include_prefix attribute is added after this prefix is stripped.
2""�
textual_hdrs�
The list of header files published by this library to be textually included by sources in dependent rules.

This is the location for declaring header files that cannot be compiled on their own; that is, they always need to be textually included by other source files to build valid code.
2[]�
win_def_file�
The Windows DEF file to be passed to linker.

This attribute should only be used when Windows is the target platform. It can be used to export symbols during linking a shared library.
2None"E

cc_archive7@@rules_cc_hdrs_map//cc_hdrs_map/private:cc_archive.bzl
//,
*
nameA unique name for this target. �
�
additional_compiler_inputs�
Any additional files you might want to pass to the compiler command line, such as sanitizer ignorelists, for example.
Files specified here can then be used in copts with the $(location) function. 
2[]�
�
additional_linker_inputs�
Any additional files that you may want to pass to the linker, for example, linker scripts.
You have to separately pass any linker flags that the linker needs in order to be aware of this file.
You can do so via the linkopts attribute.
2[]�
�
archive_lib_name�
Specify the name of the created .a file (that is decoupled from the rule instance name).
Note, that the 'cc_archive' is opinionated and will remove any leading 'lib' prefix and any '.a' in the name
(meaning 'libTest.a.x64.a' will become 'Test.x64' and will produce 'libTest.x64.a')
2""�
�
	conlyoptsy
Add these options to the C compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
�
copts�
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.
Each string in this attribute is added in the given order to COPTS before compiling the binary target. The flags take effect only for compiling this target, not its dependencies, so be careful about header files included elsewhere. All paths should be relative to the workspace, not to the current package.

If the package declares the feature no_copts_tokenization, Bourne shell tokenization applies only to strings that consist of a single "Make" variable.
2[]�
�
cxxopts{
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
�
data�
The list of files needed by this target at runtime. See general comments about data at Typical attributes defined by most build rules.
2[]�
�
defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line to this target, as well as to every rule that depends on it. Be very careful, since this may have far-reaching effects. When in doubt, add define values to local_defines instead.
2[]:
8
deps*The list of dependencies of current target2[]�
�
dynamic_deps�
In contrast to `rules_cc`, the dynamic_deps of `rules_cc_hdrs_map` are simply translated into deps parameter,
and the providers (CcInfo vs CcSharedInfo) are used to steer the behavior further.
2[]�
�
hdrsv
List of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.
2[]�
�
hdrs_map�
Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory. 
 �
�
implementation_deps�
The list of other libraries that the library target depends on. Unlike with deps, the headers and include paths of these libraries (and all their transitive deps) are only used for compilation of this library, and not libraries that depend on it. Libraries specified with implementation_deps are still linked in binary targets that depend on this library.
2[]�
�
implementation_hdrsl
List of headers that CANNOT be included by dependent rules.
Notice: the cutoff happens during compilation.
2[]�
�
include_prefix�
The prefix to add to the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at is the value of this attribute prepended to their repository-relative path.

The prefix in the strip_include_prefix attribute is removed before this prefix is added.
2""�
�
includes�
List of include dirs to be added to the compile line.
Subject to "Make variable" substitution. Each string is prepended with -isystem and added to COPTS. Unlike COPTS, these flags are added for this rule and every rule that depends on it. (Note: not the rules it depends upon!) Be very careful, since this may have far-reaching effects. When in doubt, add "-I" flags to COPTS instead.

Headers must be added to srcs or hdrs, otherwise they will not be available to dependent rules when compilation is sandboxed (the default).
2[]�
�
linkopts�
Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.
2[]�
�

linksharedz
Create a shared library. To enable this attribute, include linkshared=True in your rule. By default this option is off. 
2False�
�
	linkstamp�
Simultaneously compiles and links the specified C++ source file into the final binary. This trickery is required to introduce timestamp information into binaries; if we compiled the source file to an object file in the usual way, the timestamp would be incorrect. A linkstamp compilation may not include any particular set of compiler flags and so should not depend on any particular header, compiler option, or other build variable. This option should only be needed in the base package.
2None�
�

linkstatic�
If enabled and this is a binary or test, this option tells the build tool to link in .a's instead of .so's for user libraries whenever possible. System libraries such as libc (but not the C/C++ runtime libraries, see below) are still linked dynamically, as are libraries for which there is no static library. So the resulting executable will still be dynamically linked, hence only mostly static.
The linkstatic attribute has a different meaning if used on a cc_library() rule. For a C++ library, linkstatic=True indicates that only static linking is allowed, so no .so will be produced. linkstatic=False does not prevent static libraries from being created. The attribute is meant to control the creation of dynamic libraries. 
2False�
�
local_defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line for this target, but not to its dependents.
2[]�
�
module_interfaces�
The list of files that are regarded as C++20 Modules Interface.

C++ Standard has no restriction about module interface file extension
* Clang use cppm
* GCC can use any source file extension
* MSVC use ixx

The use is guarded by the flag --experimental_cpp_modules.
2[]�
�
nocopts�
Remove matching options from the C++ compilation command. Subject to "Make" variable substitution. The value of this attribute is interpreted as a regular expression. Any preexisting COPTS that match this regular expression (including values explicitly specified in the rule's copts attribute) will be removed from COPTS for purposes of compiling this rule. This attribute should not be needed or used outside of third_party. The values are not preprocessed in any way other than the "Make" variable substitution. 
2""

reexport_deps2[]'
%
srcsThe list of source files. �
�
strip_include_prefix�
The prefix to strip from the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at their path with this prefix cut off.

If it's a relative path, it's taken as a package-relative one. If it's an absolute one, it's understood as a repository-relative path.

The prefix in the include_prefix attribute is added after this prefix is stripped.
2""�
�
textual_hdrs�
The list of header files published by this library to be textually included by sources in dependent rules.

This is the location for declaring header files that cannot be compiled on their own; that is, they always need to be textually included by other source files to build valid code.
2[]�
�
win_def_file�
The Windows DEF file to be passed to linker.

This attribute should only be used when Windows is the target platform. It can be used to export symbols during linking a shared library.
2None[
//cc:defs.bzlrH

rules_ccccdefs.bzl
CcInfoCcInfo
!'
)�
//cc_hdrs_map/actions:defs.bzlrd
2
rules_cc_hdrs_mapcc_hdrs_map/actionsdefs.bzl 
actionsactions
;B
D�
//cc_hdrs_map/private:attrs.bzlr
3
rules_cc_hdrs_mapcc_hdrs_map/private	attrs.bzl:
get_cc_archive_attrsget_cc_archive_attrs
<P
R�
 //cc_hdrs_map/private:common.bzlr�
4
rules_cc_hdrs_mapcc_hdrs_map/private
common.bzlB
prepare_default_runfilesprepare_default_runfiles
=U
W�
)//cc_hdrs_map/providers:hdrs_map_info.bzlrw
=
rules_cc_hdrs_mapcc_hdrs_map/providershdrs_map_info.bzl(
HdrsMapInfoHdrsMapInfo
FQ
S4This module contains definition of cc_archive rule. ��
4
rules_cc_hdrs_mapcc_hdrs_map/private
cc_bin.bzl�cc_bin�Produce exectuable binary.

It is intended for this rule, to differ from rules_cc's `cc_binary` in the following
fashion: it aims to automatically gather all of its dynamic dependencies and make them
available during binary execution.
"�}
�?
cc_bin�Produce exectuable binary.

It is intended for this rule, to differ from rules_cc's `cc_binary` in the following
fashion: it aims to automatically gather all of its dynamic dependencies and make them
available during binary execution.
*
nameA unique name for this target. �
additional_compiler_inputs�
Any additional files you might want to pass to the compiler command line, such as sanitizer ignorelists, for example.
Files specified here can then be used in copts with the $(location) function. 
2[]�
additional_linker_inputs�
Any additional files that you may want to pass to the linker, for example, linker scripts.
You have to separately pass any linker flags that the linker needs in order to be aware of this file.
You can do so via the linkopts attribute.
2[]�
	conlyoptsy
Add these options to the C compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
copts�
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.
Each string in this attribute is added in the given order to COPTS before compiling the binary target. The flags take effect only for compiling this target, not its dependencies, so be careful about header files included elsewhere. All paths should be relative to the workspace, not to the current package.

If the package declares the feature no_copts_tokenization, Bourne shell tokenization applies only to strings that consist of a single "Make" variable.
2[]�
cxxopts{
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
data�
The list of files needed by this target at runtime. See general comments about data at Typical attributes defined by most build rules.
2[]�
defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line to this target, as well as to every rule that depends on it. Be very careful, since this may have far-reaching effects. When in doubt, add define values to local_defines instead.
2[]8
deps*The list of dependencies of current target2[]�
dynamic_deps�
In contrast to `rules_cc`, the dynamic_deps of `rules_cc_hdrs_map` are simply translated into deps parameter,
and the providers (CcInfo vs CcSharedInfo) are used to steer the behavior further.
2[]�
hdrsv
List of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.
2[]�
hdrs_map�
Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory. 
 �
includes�
List of include dirs to be added to the compile line.
Subject to "Make variable" substitution. Each string is prepended with -isystem and added to COPTS. Unlike COPTS, these flags are added for this rule and every rule that depends on it. (Note: not the rules it depends upon!) Be very careful, since this may have far-reaching effects. When in doubt, add "-I" flags to COPTS instead.

Headers must be added to srcs or hdrs, otherwise they will not be available to dependent rules when compilation is sandboxed (the default).
2[]�
link_extra_lib�
Control linking of extra libraries.

By default, C++ binaries are linked against //tools/cpp:link_extra_lib, which by default depends on the label flag //tools/cpp:link_extra_libs. Without setting the flag, this library is empty by default. Setting the label flag allows linking optional dependencies, such as overrides for weak symbols, interceptors for shared library functions, or special runtime libraries (for malloc replacements, prefer malloc or --custom_malloc). Setting this attribute to None disables this behaviour. 
2None�
linkopts�
Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.
2[]�

linksharedz
Create a shared library. To enable this attribute, include linkshared=True in your rule. By default this option is off. 
2False�

linkstatic�
If enabled and this is a binary or test, this option tells the build tool to link in .a's instead of .so's for user libraries whenever possible. System libraries such as libc (but not the C/C++ runtime libraries, see below) are still linked dynamically, as are libraries for which there is no static library. So the resulting executable will still be dynamically linked, hence only mostly static.
The linkstatic attribute has a different meaning if used on a cc_library() rule. For a C++ library, linkstatic=True indicates that only static linking is allowed, so no .so will be produced. linkstatic=False does not prevent static libraries from being created. The attribute is meant to control the creation of dynamic libraries. 
2False�
local_defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line for this target, but not to its dependents.
2[]�
malloc�
Override the default dependency on malloc.

By default, C++ binaries are linked against //tools/cpp:malloc, which is an empty library so the binary ends up using libc malloc. This label must refer to a cc_library. If compilation is for a non-C++ rule, this option has no effect. The value of this attribute is ignored if linkshared=True is specified. 
2None�
module_interfaces�
The list of files that are regarded as C++20 Modules Interface.

C++ Standard has no restriction about module interface file extension
* Clang use cppm
* GCC can use any source file extension
* MSVC use ixx

The use is guarded by the flag --experimental_cpp_modules.
2[]�
nocopts�
Remove matching options from the C++ compilation command. Subject to "Make" variable substitution. The value of this attribute is interpreted as a regular expression. Any preexisting COPTS that match this regular expression (including values explicitly specified in the rule's copts attribute) will be removed from COPTS for purposes of compiling this rule. This attribute should not be needed or used outside of third_party. The values are not preprocessed in any way other than the "Make" variable substitution. 
2""
reexport_deps2[]%
srcsThe list of source files. �
stamp�
Whether to encode build information into the binary. Possible values:

  * stamp = 1: Always stamp the build information into the binary, even in --nostamp builds. This setting should be avoided, since it potentially kills remote caching for the binary and any downstream actions that depend on it.

  * stamp = 0: Always replace build information by constant values. This gives good build result caching.

  * stamp = -1: Embedding of build information is controlled by the --[no]stamp flag.

Stamped binaries are not rebuilt unless their dependencies change.
2-1�
win_def_file�
The Windows DEF file to be passed to linker.

This attribute should only be used when Windows is the target platform. It can be used to export symbols during linking a shared library.
2None"=
cc_bin3@@rules_cc_hdrs_map//cc_hdrs_map/private:cc_bin.bzl
,
*
nameA unique name for this target. �
�
additional_compiler_inputs�
Any additional files you might want to pass to the compiler command line, such as sanitizer ignorelists, for example.
Files specified here can then be used in copts with the $(location) function. 
2[]�
�
additional_linker_inputs�
Any additional files that you may want to pass to the linker, for example, linker scripts.
You have to separately pass any linker flags that the linker needs in order to be aware of this file.
You can do so via the linkopts attribute.
2[]�
�
	conlyoptsy
Add these options to the C compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
�
copts�
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.
Each string in this attribute is added in the given order to COPTS before compiling the binary target. The flags take effect only for compiling this target, not its dependencies, so be careful about header files included elsewhere. All paths should be relative to the workspace, not to the current package.

If the package declares the feature no_copts_tokenization, Bourne shell tokenization applies only to strings that consist of a single "Make" variable.
2[]�
�
cxxopts{
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
�
data�
The list of files needed by this target at runtime. See general comments about data at Typical attributes defined by most build rules.
2[]�
�
defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line to this target, as well as to every rule that depends on it. Be very careful, since this may have far-reaching effects. When in doubt, add define values to local_defines instead.
2[]:
8
deps*The list of dependencies of current target2[]�
�
dynamic_deps�
In contrast to `rules_cc`, the dynamic_deps of `rules_cc_hdrs_map` are simply translated into deps parameter,
and the providers (CcInfo vs CcSharedInfo) are used to steer the behavior further.
2[]�
�
hdrsv
List of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.
2[]�
�
hdrs_map�
Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory. 
 �
�
includes�
List of include dirs to be added to the compile line.
Subject to "Make variable" substitution. Each string is prepended with -isystem and added to COPTS. Unlike COPTS, these flags are added for this rule and every rule that depends on it. (Note: not the rules it depends upon!) Be very careful, since this may have far-reaching effects. When in doubt, add "-I" flags to COPTS instead.

Headers must be added to srcs or hdrs, otherwise they will not be available to dependent rules when compilation is sandboxed (the default).
2[]�
�
link_extra_lib�
Control linking of extra libraries.

By default, C++ binaries are linked against //tools/cpp:link_extra_lib, which by default depends on the label flag //tools/cpp:link_extra_libs. Without setting the flag, this library is empty by default. Setting the label flag allows linking optional dependencies, such as overrides for weak symbols, interceptors for shared library functions, or special runtime libraries (for malloc replacements, prefer malloc or --custom_malloc). Setting this attribute to None disables this behaviour. 
2None�
�
linkopts�
Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.
2[]�
�

linksharedz
Create a shared library. To enable this attribute, include linkshared=True in your rule. By default this option is off. 
2False�
�

linkstatic�
If enabled and this is a binary or test, this option tells the build tool to link in .a's instead of .so's for user libraries whenever possible. System libraries such as libc (but not the C/C++ runtime libraries, see below) are still linked dynamically, as are libraries for which there is no static library. So the resulting executable will still be dynamically linked, hence only mostly static.
The linkstatic attribute has a different meaning if used on a cc_library() rule. For a C++ library, linkstatic=True indicates that only static linking is allowed, so no .so will be produced. linkstatic=False does not prevent static libraries from being created. The attribute is meant to control the creation of dynamic libraries. 
2False�
�
local_defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line for this target, but not to its dependents.
2[]�
�
malloc�
Override the default dependency on malloc.

By default, C++ binaries are linked against //tools/cpp:malloc, which is an empty library so the binary ends up using libc malloc. This label must refer to a cc_library. If compilation is for a non-C++ rule, this option has no effect. The value of this attribute is ignored if linkshared=True is specified. 
2None�
�
module_interfaces�
The list of files that are regarded as C++20 Modules Interface.

C++ Standard has no restriction about module interface file extension
* Clang use cppm
* GCC can use any source file extension
* MSVC use ixx

The use is guarded by the flag --experimental_cpp_modules.
2[]�
�
nocopts�
Remove matching options from the C++ compilation command. Subject to "Make" variable substitution. The value of this attribute is interpreted as a regular expression. Any preexisting COPTS that match this regular expression (including values explicitly specified in the rule's copts attribute) will be removed from COPTS for purposes of compiling this rule. This attribute should not be needed or used outside of third_party. The values are not preprocessed in any way other than the "Make" variable substitution. 
2""

reexport_deps2[]'
%
srcsThe list of source files. �
�
stamp�
Whether to encode build information into the binary. Possible values:

  * stamp = 1: Always stamp the build information into the binary, even in --nostamp builds. This setting should be avoided, since it potentially kills remote caching for the binary and any downstream actions that depend on it.

  * stamp = 0: Always replace build information by constant values. This gives good build result caching.

  * stamp = -1: Embedding of build information is controlled by the --[no]stamp flag.

Stamped binaries are not rebuilt unless their dependencies change.
2-1�
�
win_def_file�
The Windows DEF file to be passed to linker.

This attribute should only be used when Windows is the target platform. It can be used to export symbols during linking a shared library.
2None�
//cc_hdrs_map/actions:defs.bzlrd
2
rules_cc_hdrs_mapcc_hdrs_map/actionsdefs.bzl 
actionsactions
;B
D�
//cc_hdrs_map/private:attrs.bzlrw
3
rules_cc_hdrs_mapcc_hdrs_map/private	attrs.bzl2
get_cc_bin_attrsget_cc_bin_attrs
<L
N�
 //cc_hdrs_map/private:common.bzlr�
4
rules_cc_hdrs_mapcc_hdrs_map/private
common.bzlB
prepare_default_runfilesprepare_default_runfiles
=U
W8This module contains the implementation of cc_bin rule. �$
5
rules_cc_hdrs_mapcc_hdrs_map/privatecc_hdrs.bzl�cc_hdrs�Define header files properties.

This rule groups headers into a singular target and allows
to attach 'include_path' modifications information to them,
so that wherever the header files are being used, they can
be used with their intended include paths.
"�
�
cc_hdrs�Define header files properties.

This rule groups headers into a singular target and allows
to attach 'include_path' modifications information to them,
so that wherever the header files are being used, they can
be used with their intended include paths.
*
nameA unique name for this target. �
data�
The list of files needed by this target at runtime. See general comments about data at Typical attributes defined by most build rules.
2[]8
deps*The list of dependencies of current target2[]�
hdrsv
List of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.
2[]�
hdrs_map�
Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory. 
 �
implementation_hdrsl
List of headers that CANNOT be included by dependent rules.
Notice: the cutoff happens during compilation.
2[]�
module_interfaces�
The list of files that are regarded as C++20 Modules Interface.

C++ Standard has no restriction about module interface file extension
* Clang use cppm
* GCC can use any source file extension
* MSVC use ixx

The use is guarded by the flag --experimental_cpp_modules.
2[]�
win_def_file�
The Windows DEF file to be passed to linker.

This attribute should only be used when Windows is the target platform. It can be used to export symbols during linking a shared library.
2None"?
cc_hdrs4@@rules_cc_hdrs_map//cc_hdrs_map/private:cc_hdrs.bzl
66,
*
nameA unique name for this target. �
�
data�
The list of files needed by this target at runtime. See general comments about data at Typical attributes defined by most build rules.
2[]:
8
deps*The list of dependencies of current target2[]�
�
hdrsv
List of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.
2[]�
�
hdrs_map�
Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory. 
 �
�
implementation_hdrsl
List of headers that CANNOT be included by dependent rules.
Notice: the cutoff happens during compilation.
2[]�
�
module_interfaces�
The list of files that are regarded as C++20 Modules Interface.

C++ Standard has no restriction about module interface file extension
* Clang use cppm
* GCC can use any source file extension
* MSVC use ixx

The use is guarded by the flag --experimental_cpp_modules.
2[]�
�
win_def_file�
The Windows DEF file to be passed to linker.

This attribute should only be used when Windows is the target platform. It can be used to export symbols during linking a shared library.
2None�
//cc_hdrs_map/actions:defs.bzlrd
2
rules_cc_hdrs_mapcc_hdrs_map/actionsdefs.bzl 
actionsactions
;B
D�
//cc_hdrs_map/private:attrs.bzlry
3
rules_cc_hdrs_mapcc_hdrs_map/private	attrs.bzl4
get_cc_hdrs_attrsget_cc_hdrs_attrs
<M
O�
 //cc_hdrs_map/private:common.bzlr�
4
rules_cc_hdrs_mapcc_hdrs_map/private
common.bzlB
prepare_default_runfilesprepare_default_runfiles
=U
W�
$//cc_hdrs_map/providers:hdrs_map.bzlrt
8
rules_cc_hdrs_mapcc_hdrs_map/providershdrs_map.bzl*
new_hdrs_mapnew_hdrs_map
AM
O�
)//cc_hdrs_map/providers:hdrs_map_info.bzlr�
=
rules_cc_hdrs_mapcc_hdrs_map/providershdrs_map_info.bzl(
HdrsMapInfoHdrsMapInfo
FQH
quotient_map_hdrs_map_infosquotient_map_hdrs_map_infos
Up
r5This module contains implementation of cc_hdrs rule. ��
3
rules_cc_hdrs_mapcc_hdrs_map/private	cc_so.bzl��cc_so�Produce shared object library.

The intended difference between this rule and the rules_cc's cc_shared_library is to:
 1) remove 'cc_library' out of the equation (no more targets that produce either archive or sol)
 2) unify handling of dependencies that are equipped with CcInfo and CcSharedLibraryInfo
    (use singular attribute of deps to track them both).
"��
�Y
cc_so�Produce shared object library.

The intended difference between this rule and the rules_cc's cc_shared_library is to:
 1) remove 'cc_library' out of the equation (no more targets that produce either archive or sol)
 2) unify handling of dependencies that are equipped with CcInfo and CcSharedLibraryInfo
    (use singular attribute of deps to track them both).
*
nameA unique name for this target. �
additional_compiler_inputs�
Any additional files you might want to pass to the compiler command line, such as sanitizer ignorelists, for example.
Files specified here can then be used in copts with the $(location) function. 
2[]�
additional_linker_inputs�
Any additional files that you may want to pass to the linker, for example, linker scripts.
You have to separately pass any linker flags that the linker needs in order to be aware of this file.
You can do so via the linkopts attribute.
2[]�

alwayslink�
If 1, any binary that depends (directly or indirectly) on this C++ precompiled library will link in all the object files archived in the static library, even if some contain no symbols referenced by the binary. This is useful if your code isn't explicitly called by code in the binary, e.g., if your code registers to receive some callback provided by some service. 
2False�
	conlyoptsy
Add these options to the C compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
copts�
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.
Each string in this attribute is added in the given order to COPTS before compiling the binary target. The flags take effect only for compiling this target, not its dependencies, so be careful about header files included elsewhere. All paths should be relative to the workspace, not to the current package.

If the package declares the feature no_copts_tokenization, Bourne shell tokenization applies only to strings that consist of a single "Make" variable.
2[]�
cxxopts{
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
data�
The list of files needed by this target at runtime. See general comments about data at Typical attributes defined by most build rules.
2[]�
defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line to this target, as well as to every rule that depends on it. Be very careful, since this may have far-reaching effects. When in doubt, add define values to local_defines instead.
2[]8
deps*The list of dependencies of current target2[]�
dynamic_deps�
In contrast to `rules_cc`, the dynamic_deps of `rules_cc_hdrs_map` are simply translated into deps parameter,
and the providers (CcInfo vs CcSharedInfo) are used to steer the behavior further.
2[]�
exports_filter�
This attribute contains a list of targets that are claimed to be exported by the current shared library.

Any target deps is already understood to be exported by the shared library. This attribute should be used to list any targets that are exported by the shared library but are transitive dependencies of deps.

Note that this attribute is not actually adding a dependency edge to those targets, the dependency edge should instead be created by deps.The entries in this attribute are just strings. Keep in mind that when placing a target in this attribute, this is considered a claim that the shared library exports the symbols from that target. The cc_shared_library logic doesn't actually handle telling the linker which symbols should be exported.

The following syntax is allowed:

//foo:__pkg__ to account for any target in foo/BUILD

//foo:__subpackages__ to account for any target in foo/BUILD or any other package below foo/ like foo/bar/BUILD
2[]�
hdrsv
List of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.
2[]�
hdrs_map�
Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory. 
 �
implementation_deps�
The list of other libraries that the library target depends on. Unlike with deps, the headers and include paths of these libraries (and all their transitive deps) are only used for compilation of this library, and not libraries that depend on it. Libraries specified with implementation_deps are still linked in binary targets that depend on this library.
2[]�
implementation_hdrsl
List of headers that CANNOT be included by dependent rules.
Notice: the cutoff happens during compilation.
2[]�
include_prefix�
The prefix to add to the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at is the value of this attribute prepended to their repository-relative path.

The prefix in the strip_include_prefix attribute is removed before this prefix is added.
2""�
includes�
List of include dirs to be added to the compile line.
Subject to "Make variable" substitution. Each string is prepended with -isystem and added to COPTS. Unlike COPTS, these flags are added for this rule and every rule that depends on it. (Note: not the rules it depends upon!) Be very careful, since this may have far-reaching effects. When in doubt, add "-I" flags to COPTS instead.

Headers must be added to srcs or hdrs, otherwise they will not be available to dependent rules when compilation is sandboxed (the default).
2[]�
link_extra_lib�
Control linking of extra libraries.

By default, C++ binaries are linked against //tools/cpp:link_extra_lib, which by default depends on the label flag //tools/cpp:link_extra_libs. Without setting the flag, this library is empty by default. Setting the label flag allows linking optional dependencies, such as overrides for weak symbols, interceptors for shared library functions, or special runtime libraries (for malloc replacements, prefer malloc or --custom_malloc). Setting this attribute to None disables this behaviour. 
2None�
linkopts�
Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.
2[]�

linksharedz
Create a shared library. To enable this attribute, include linkshared=True in your rule. By default this option is off. 
2False�
	linkstamp�
Simultaneously compiles and links the specified C++ source file into the final binary. This trickery is required to introduce timestamp information into binaries; if we compiled the source file to an object file in the usual way, the timestamp would be incorrect. A linkstamp compilation may not include any particular set of compiler flags and so should not depend on any particular header, compiler option, or other build variable. This option should only be needed in the base package.
2None�

linkstatic�
If enabled and this is a binary or test, this option tells the build tool to link in .a's instead of .so's for user libraries whenever possible. System libraries such as libc (but not the C/C++ runtime libraries, see below) are still linked dynamically, as are libraries for which there is no static library. So the resulting executable will still be dynamically linked, hence only mostly static.
The linkstatic attribute has a different meaning if used on a cc_library() rule. For a C++ library, linkstatic=True indicates that only static linking is allowed, so no .so will be produced. linkstatic=False does not prevent static libraries from being created. The attribute is meant to control the creation of dynamic libraries. 
2False�
local_defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line for this target, but not to its dependents.
2[]�
malloc�
Override the default dependency on malloc.

By default, C++ binaries are linked against //tools/cpp:malloc, which is an empty library so the binary ends up using libc malloc. This label must refer to a cc_library. If compilation is for a non-C++ rule, this option has no effect. The value of this attribute is ignored if linkshared=True is specified. 
2None�
module_interfaces�
The list of files that are regarded as C++20 Modules Interface.

C++ Standard has no restriction about module interface file extension
* Clang use cppm
* GCC can use any source file extension
* MSVC use ixx

The use is guarded by the flag --experimental_cpp_modules.
2[]�
nocopts�
Remove matching options from the C++ compilation command. Subject to "Make" variable substitution. The value of this attribute is interpreted as a regular expression. Any preexisting COPTS that match this regular expression (including values explicitly specified in the rule's copts attribute) will be removed from COPTS for purposes of compiling this rule. This attribute should not be needed or used outside of third_party. The values are not preprocessed in any way other than the "Make" variable substitution. 
2""$
roots(Not yet implemented)2[]�
shared_lib_name�
Specify the name of the created SOL file (that is decoupled from the rule instance name).
Note, that the 'cc_so' is opinionated and will remove any leading 'lib' prefix and any '.so' in the name
(meaning 'libTest.so.x64.so' will become 'Test.x64' and will produce 'libTest.x64.so')
2""%
srcsThe list of source files. �
strip_include_prefix�
The prefix to strip from the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at their path with this prefix cut off.

If it's a relative path, it's taken as a package-relative one. If it's an absolute one, it's understood as a repository-relative path.

The prefix in the include_prefix attribute is added after this prefix is stripped.
2""�
textual_hdrs�
The list of header files published by this library to be textually included by sources in dependent rules.

This is the location for declaring header files that cannot be compiled on their own; that is, they always need to be textually included by other source files to build valid code.
2[]�
win_def_file�
The Windows DEF file to be passed to linker.

This attribute should only be used when Windows is the target platform. It can be used to export symbols during linking a shared library.
2None";
cc_so2@@rules_cc_hdrs_map//cc_hdrs_map/private:cc_so.bzl
11,
*
nameA unique name for this target. �
�
additional_compiler_inputs�
Any additional files you might want to pass to the compiler command line, such as sanitizer ignorelists, for example.
Files specified here can then be used in copts with the $(location) function. 
2[]�
�
additional_linker_inputs�
Any additional files that you may want to pass to the linker, for example, linker scripts.
You have to separately pass any linker flags that the linker needs in order to be aware of this file.
You can do so via the linkopts attribute.
2[]�
�

alwayslink�
If 1, any binary that depends (directly or indirectly) on this C++ precompiled library will link in all the object files archived in the static library, even if some contain no symbols referenced by the binary. This is useful if your code isn't explicitly called by code in the binary, e.g., if your code registers to receive some callback provided by some service. 
2False�
�
	conlyoptsy
Add these options to the C compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
�
copts�
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.
Each string in this attribute is added in the given order to COPTS before compiling the binary target. The flags take effect only for compiling this target, not its dependencies, so be careful about header files included elsewhere. All paths should be relative to the workspace, not to the current package.

If the package declares the feature no_copts_tokenization, Bourne shell tokenization applies only to strings that consist of a single "Make" variable.
2[]�
�
cxxopts{
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
�
data�
The list of files needed by this target at runtime. See general comments about data at Typical attributes defined by most build rules.
2[]�
�
defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line to this target, as well as to every rule that depends on it. Be very careful, since this may have far-reaching effects. When in doubt, add define values to local_defines instead.
2[]:
8
deps*The list of dependencies of current target2[]�
�
dynamic_deps�
In contrast to `rules_cc`, the dynamic_deps of `rules_cc_hdrs_map` are simply translated into deps parameter,
and the providers (CcInfo vs CcSharedInfo) are used to steer the behavior further.
2[]�
�
exports_filter�
This attribute contains a list of targets that are claimed to be exported by the current shared library.

Any target deps is already understood to be exported by the shared library. This attribute should be used to list any targets that are exported by the shared library but are transitive dependencies of deps.

Note that this attribute is not actually adding a dependency edge to those targets, the dependency edge should instead be created by deps.The entries in this attribute are just strings. Keep in mind that when placing a target in this attribute, this is considered a claim that the shared library exports the symbols from that target. The cc_shared_library logic doesn't actually handle telling the linker which symbols should be exported.

The following syntax is allowed:

//foo:__pkg__ to account for any target in foo/BUILD

//foo:__subpackages__ to account for any target in foo/BUILD or any other package below foo/ like foo/bar/BUILD
2[]�
�
hdrsv
List of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.
2[]�
�
hdrs_map�
Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory. 
 �
�
implementation_deps�
The list of other libraries that the library target depends on. Unlike with deps, the headers and include paths of these libraries (and all their transitive deps) are only used for compilation of this library, and not libraries that depend on it. Libraries specified with implementation_deps are still linked in binary targets that depend on this library.
2[]�
�
implementation_hdrsl
List of headers that CANNOT be included by dependent rules.
Notice: the cutoff happens during compilation.
2[]�
�
include_prefix�
The prefix to add to the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at is the value of this attribute prepended to their repository-relative path.

The prefix in the strip_include_prefix attribute is removed before this prefix is added.
2""�
�
includes�
List of include dirs to be added to the compile line.
Subject to "Make variable" substitution. Each string is prepended with -isystem and added to COPTS. Unlike COPTS, these flags are added for this rule and every rule that depends on it. (Note: not the rules it depends upon!) Be very careful, since this may have far-reaching effects. When in doubt, add "-I" flags to COPTS instead.

Headers must be added to srcs or hdrs, otherwise they will not be available to dependent rules when compilation is sandboxed (the default).
2[]�
�
link_extra_lib�
Control linking of extra libraries.

By default, C++ binaries are linked against //tools/cpp:link_extra_lib, which by default depends on the label flag //tools/cpp:link_extra_libs. Without setting the flag, this library is empty by default. Setting the label flag allows linking optional dependencies, such as overrides for weak symbols, interceptors for shared library functions, or special runtime libraries (for malloc replacements, prefer malloc or --custom_malloc). Setting this attribute to None disables this behaviour. 
2None�
�
linkopts�
Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.
2[]�
�

linksharedz
Create a shared library. To enable this attribute, include linkshared=True in your rule. By default this option is off. 
2False�
�
	linkstamp�
Simultaneously compiles and links the specified C++ source file into the final binary. This trickery is required to introduce timestamp information into binaries; if we compiled the source file to an object file in the usual way, the timestamp would be incorrect. A linkstamp compilation may not include any particular set of compiler flags and so should not depend on any particular header, compiler option, or other build variable. This option should only be needed in the base package.
2None�
�

linkstatic�
If enabled and this is a binary or test, this option tells the build tool to link in .a's instead of .so's for user libraries whenever possible. System libraries such as libc (but not the C/C++ runtime libraries, see below) are still linked dynamically, as are libraries for which there is no static library. So the resulting executable will still be dynamically linked, hence only mostly static.
The linkstatic attribute has a different meaning if used on a cc_library() rule. For a C++ library, linkstatic=True indicates that only static linking is allowed, so no .so will be produced. linkstatic=False does not prevent static libraries from being created. The attribute is meant to control the creation of dynamic libraries. 
2False�
�
local_defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line for this target, but not to its dependents.
2[]�
�
malloc�
Override the default dependency on malloc.

By default, C++ binaries are linked against //tools/cpp:malloc, which is an empty library so the binary ends up using libc malloc. This label must refer to a cc_library. If compilation is for a non-C++ rule, this option has no effect. The value of this attribute is ignored if linkshared=True is specified. 
2None�
�
module_interfaces�
The list of files that are regarded as C++20 Modules Interface.

C++ Standard has no restriction about module interface file extension
* Clang use cppm
* GCC can use any source file extension
* MSVC use ixx

The use is guarded by the flag --experimental_cpp_modules.
2[]�
�
nocopts�
Remove matching options from the C++ compilation command. Subject to "Make" variable substitution. The value of this attribute is interpreted as a regular expression. Any preexisting COPTS that match this regular expression (including values explicitly specified in the rule's copts attribute) will be removed from COPTS for purposes of compiling this rule. This attribute should not be needed or used outside of third_party. The values are not preprocessed in any way other than the "Make" variable substitution. 
2""&
$
roots(Not yet implemented)2[]�
�
shared_lib_name�
Specify the name of the created SOL file (that is decoupled from the rule instance name).
Note, that the 'cc_so' is opinionated and will remove any leading 'lib' prefix and any '.so' in the name
(meaning 'libTest.so.x64.so' will become 'Test.x64' and will produce 'libTest.x64.so')
2""'
%
srcsThe list of source files. �
�
strip_include_prefix�
The prefix to strip from the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at their path with this prefix cut off.

If it's a relative path, it's taken as a package-relative one. If it's an absolute one, it's understood as a repository-relative path.

The prefix in the include_prefix attribute is added after this prefix is stripped.
2""�
�
textual_hdrs�
The list of header files published by this library to be textually included by sources in dependent rules.

This is the location for declaring header files that cannot be compiled on their own; that is, they always need to be textually included by other source files to build valid code.
2[]�
�
win_def_file�
The Windows DEF file to be passed to linker.

This attribute should only be used when Windows is the target platform. It can be used to export symbols during linking a shared library.
2None�
&//cc/common:cc_shared_library_info.bzlr{
1
rules_cc	cc/commoncc_shared_library_info.bzl8
CcSharedLibraryInfoCcSharedLibraryInfo
:M
O�
//cc_hdrs_map/actions:defs.bzlrd
2
rules_cc_hdrs_mapcc_hdrs_map/actionsdefs.bzl 
actionsactions
;B
D�
//cc_hdrs_map/private:attrs.bzlru
3
rules_cc_hdrs_mapcc_hdrs_map/private	attrs.bzl0
get_cc_so_attrsget_cc_so_attrs
<K
M�
 //cc_hdrs_map/private:common.bzlr�
4
rules_cc_hdrs_mapcc_hdrs_map/private
common.bzlB
prepare_default_runfilesprepare_default_runfiles
=U
W�
<//cc_hdrs_map/providers:cascading_cc_shared_library_info.bzlr�
P
rules_cc_hdrs_mapcc_hdrs_map/providers$cascading_cc_shared_library_info.bzlJ
CascadingCcSharedLibraryInfoCascadingCcSharedLibraryInfo
Yu
w�
)//cc_hdrs_map/providers:hdrs_map_info.bzlrw
=
rules_cc_hdrs_mapcc_hdrs_map/providershdrs_map_info.bzl(
HdrsMapInfoHdrsMapInfo
FQ
S;This module contains the implementation of the cc_so rule. �G
:
rules_cc_hdrs_mapcc_hdrs_map/privatecc_so_import.bzl�7cc_so_import�Import precompiled C/C++ shared object library.

The intended difference between this rule and the rules_cc's cc_import is to directly
provide CcSharedLibrary info to force linking and early deps cutoff.
"�6
�
cc_so_import�Import precompiled C/C++ shared object library.

The intended difference between this rule and the rules_cc's cc_import is to directly
provide CcSharedLibrary info to force linking and early deps cutoff.
*
nameA unique name for this target. �
additional_linker_inputs�
Any additional files that you may want to pass to the linker, for example, linker scripts.
You have to separately pass any linker flags that the linker needs in order to be aware of this file.
You can do so via the linkopts attribute.
2[]v
cascadeb
Please DO NOT USE. This makes the SOL being propagated upwards to every dependee of this target.
2False�
data�
The list of files needed by this target at runtime. See general comments about data at Typical attributes defined by most build rules.
2[]8
deps*The list of dependencies of current target2[]�
dynamic_deps�
In contrast to `rules_cc`, the dynamic_deps of `rules_cc_hdrs_map` are simply translated into deps parameter,
and the providers (CcInfo vs CcSharedInfo) are used to steer the behavior further.
2[]�
hdrsv
List of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.
2[]�
hdrs_map�
Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory. 
 �
implementation_deps�
The list of other libraries that the library target depends on. Unlike with deps, the headers and include paths of these libraries (and all their transitive deps) are only used for compilation of this library, and not libraries that depend on it. Libraries specified with implementation_deps are still linked in binary targets that depend on this library.
2[]�
include_prefix�
The prefix to add to the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at is the value of this attribute prepended to their repository-relative path.

The prefix in the strip_include_prefix attribute is removed before this prefix is added.
2""�
linkopts�
Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.
2[]�
shared_libraryv
A single precompiled shared library. This ruleset will ensure it will be available to depending cc_hdrs_map targets.
 �
strip_include_prefix�
The prefix to strip from the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at their path with this prefix cut off.

If it's a relative path, it's taken as a package-relative one. If it's an absolute one, it's understood as a repository-relative path.

The prefix in the include_prefix attribute is added after this prefix is stripped.
2"""I
cc_so_import9@@rules_cc_hdrs_map//cc_hdrs_map/private:cc_so_import.bzl
oo,
*
nameA unique name for this target. �
�
additional_linker_inputs�
Any additional files that you may want to pass to the linker, for example, linker scripts.
You have to separately pass any linker flags that the linker needs in order to be aware of this file.
You can do so via the linkopts attribute.
2[]x
v
cascadeb
Please DO NOT USE. This makes the SOL being propagated upwards to every dependee of this target.
2False�
�
data�
The list of files needed by this target at runtime. See general comments about data at Typical attributes defined by most build rules.
2[]:
8
deps*The list of dependencies of current target2[]�
�
dynamic_deps�
In contrast to `rules_cc`, the dynamic_deps of `rules_cc_hdrs_map` are simply translated into deps parameter,
and the providers (CcInfo vs CcSharedInfo) are used to steer the behavior further.
2[]�
�
hdrsv
List of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.
2[]�
�
hdrs_map�
Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory. 
 �
�
implementation_deps�
The list of other libraries that the library target depends on. Unlike with deps, the headers and include paths of these libraries (and all their transitive deps) are only used for compilation of this library, and not libraries that depend on it. Libraries specified with implementation_deps are still linked in binary targets that depend on this library.
2[]�
�
include_prefix�
The prefix to add to the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at is the value of this attribute prepended to their repository-relative path.

The prefix in the strip_include_prefix attribute is removed before this prefix is added.
2""�
�
linkopts�
Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.
2[]�
�
shared_libraryv
A single precompiled shared library. This ruleset will ensure it will be available to depending cc_hdrs_map targets.
 �
�
strip_include_prefix�
The prefix to strip from the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at their path with this prefix cut off.

If it's a relative path, it's taken as a package-relative one. If it's an absolute one, it's understood as a repository-relative path.

The prefix in the include_prefix attribute is added after this prefix is stripped.
2""a
//cc:defs.bzlrN

rules_ccccdefs.bzl$
	cc_common	cc_common
!*
,�
//cc:find_cc_toolchain.bzlr�
%
rules_ccccfind_cc_toolchain.bzl4
find_cc_toolchainfind_cc_toolchain
2
use_cc_toolchainuse_cc_toolchain

�
&//cc/common:cc_shared_library_info.bzlr{
1
rules_cc	cc/commoncc_shared_library_info.bzl8
CcSharedLibraryInfoCcSharedLibraryInfo
	:	M
		O�
//cc_hdrs_map/actions:defs.bzlrd
2
rules_cc_hdrs_mapcc_hdrs_map/actionsdefs.bzl 
actionsactions

;
B


D�
//cc_hdrs_map/private:attrs.bzlr�
3
rules_cc_hdrs_mapcc_hdrs_map/private	attrs.bzl>
get_cc_so_import_attrsget_cc_so_import_attrs
<R
T�
 //cc_hdrs_map/private:common.bzlr�
4
rules_cc_hdrs_mapcc_hdrs_map/private
common.bzlB
prepare_default_runfilesprepare_default_runfiles
=U
W�
<//cc_hdrs_map/providers:cascading_cc_shared_library_info.bzlr�
P
rules_cc_hdrs_mapcc_hdrs_map/providers$cascading_cc_shared_library_info.bzlJ
CascadingCcSharedLibraryInfoCascadingCcSharedLibraryInfo
Yu
w�
2//cc_hdrs_map/providers:cc_shared_library_info.bzlr�
F
rules_cc_hdrs_mapcc_hdrs_map/providerscc_shared_library_info.bzlL
merge_cc_shared_library_infosmerge_cc_shared_library_infos
Ol
n�
$//cc_hdrs_map/providers:hdrs_map.bzlrt
8
rules_cc_hdrs_mapcc_hdrs_map/providershdrs_map.bzl*
new_hdrs_mapnew_hdrs_map
AM
O�
)//cc_hdrs_map/providers:hdrs_map_info.bzlr�
=
rules_cc_hdrs_mapcc_hdrs_map/providershdrs_map_info.bzl(
HdrsMapInfoHdrsMapInfo
FQH
quotient_map_hdrs_map_infosquotient_map_hdrs_map_infos
Up
rBThis module contains the implementation of the cc_so_import rule. �
4
rules_cc_hdrs_mapcc_hdrs_map/private
common.bzl�prepare_default_runfiles?The default list of runfiles, gathered from the data attribute.*�
�
prepare_default_runfiles
ctx_runfiles_fun (
	attr_data (
	attr_deps (
files[](?The default list of runfiles, gathered from the data attribute.2O
prepare_default_runfiles3@@rules_cc_hdrs_map//cc_hdrs_map/private:common.bzl
44[
//cc:defs.bzlrH

rules_ccccdefs.bzl
CcInfoCcInfo
!'
)>Contains common logic shared between rules implementation(s). �
P
rules_cc_hdrs_mapcc_hdrs_map/providers$cascading_cc_shared_library_info.bzl�CascadingCcSharedLibraryInfoXRepresents CcSharedLibrary that should cascade and be link in every transitive dependee.2�
�
CascadingCcSharedLibraryInfoXRepresents CcSharedLibrary that should cascade and be link in every transitive dependee.h
cc_shared_library_infosM[] of CcSharedLibraryInfo providers that describes what needs to be cascaded."o
CascadingCcSharedLibraryInfoO@@rules_cc_hdrs_map//cc_hdrs_map/providers:cascading_cc_shared_library_info.bzl
((j
h
cc_shared_library_infosM[] of CcSharedLibraryInfo providers that describes what needs to be cascaded.�
&//cc/common:cc_shared_library_info.bzlr{
1
rules_cc	cc/commoncc_shared_library_info.bzl8
CcSharedLibraryInfoCcSharedLibraryInfo
:M
OWThis module contains function that help with dealing with CcSharedLibraryInfo provider.�
F
rules_cc_hdrs_mapcc_hdrs_map/providerscc_shared_library_info.bzl�merge_cc_shared_library_infos?Merge CcSharedLibraryInfos from targets into singualr provider.*�
�
merge_cc_shared_library_infos~
targetsmlist of Bazel targets that should be merged. They must
contain either CcInfo or CcSharedLibraryInfo provider.[](Q
dynamic_deps9sequence of Depsets representing additional dynamic deps.None(I
exports6cc_libraries that are linked statically and exported".None(S
linker_input;the resultign linker inptu artifact for the shared library.None(s
link_once_static_libsRall libraries linked statically into this library that should
only be linked once.None(?Merge CcSharedLibraryInfos from targets into singualr provider."
CcSharedLibraryInfo provider.2f
merge_cc_shared_library_infosE@@rules_cc_hdrs_map//cc_hdrs_map/providers:cc_shared_library_info.bzl
??�
$quotient_map_cc_shared_library_infos�Transform list of Bazel targets into CcSharedLibrayInfo attribue groups.

For given list of Bazel targets, attributes relating to CcSharedLibraryInfo
(dynamic_deps, exports, linker_inputs, link_once_static_libs) will be extracted
from said targets and the output will contain groups of that values.
*�
�
$quotient_map_cc_shared_library_infos~
targetsmlist of Bazel targets that should be mapped. They must
contain either CcInfo or CcSharedLibraryInfo provider.[](Q
dynamic_deps9sequence of Depsets representing additional dynamic deps.None(I
exports6cc_libraries that are linked statically and exported".None(S
linker_input;the resultign linker inptu artifact for the shared library.None(s
link_once_static_libsRall libraries linked statically into this library that should
only be linked once.None(�Transform list of Bazel targets into CcSharedLibrayInfo attribue groups.

For given list of Bazel targets, attributes relating to CcSharedLibraryInfo
(dynamic_deps, exports, linker_inputs, link_once_static_libs) will be extracted
from said targets and the output will contain groups of that values.
"?
=(dynamic_deps, exports, linker_inptuts, link_once_static_lib)2m
$quotient_map_cc_shared_library_infosE@@rules_cc_hdrs_map//cc_hdrs_map/providers:cc_shared_library_info.bzl
o
//cc/common:cc_info.bzlrR
"
rules_cc	cc/commoncc_info.bzl
CcInfoCcInfo
+1
3�
&//cc/common:cc_shared_library_info.bzlr{
1
rules_cc	cc/commoncc_shared_library_info.bzl8
CcSharedLibraryInfoCcSharedLibraryInfo
:M
OWThis module contains function that help with dealing with CcSharedLibraryInfo provider.�

8
rules_cc_hdrs_mapcc_hdrs_map/providershdrs_map.bzl�materialize_hdrs_mapping�Materialize the expected file hierarchy.

Creates the header file hierarchy accordingly to specifications
in passed-in hdrs_map under 'vhm' directory.
*�
�
materialize_hdrs_mapping6
invoker_label!label of rule invoking the method ( 
actionsbazel ctx.actions (<
hdrs_map,HdrsMapInfo representing the headers mapping (K
hdrs?list of all header files that should be matched against the map (�Materialize the expected file hierarchy.

Creates the header file hierarchy accordingly to specifications
in passed-in hdrs_map under 'vhm' directory.
"�
�(materialized_include_path, materialized_hdrs_files): tuple of include_path to
the created header files dir and list of paths to all header files created.2S
materialize_hdrs_mapping7@@rules_cc_hdrs_map//cc_hdrs_map/providers:hdrs_map.bzl
���new_hdrs_map&Create new instance of HdrsMap struct.*�
�
new_hdrs_map
	from_dict{}(
_globNone(
	_non_globNone(&Create new instance of HdrsMap struct.2G
new_hdrs_map7@@rules_cc_hdrs_map//cc_hdrs_map/providers:hdrs_map.bzl
??�
#//cc_hdrs_map/actions:copy_file.bzlrm
7
rules_cc_hdrs_mapcc_hdrs_map/actionscopy_file.bzl$
	copy_file	copy_file

>Module describing HdrsMap struct and common operations on it. �
=
rules_cc_hdrs_mapcc_hdrs_map/providershdrs_map_info.bzl�merge_hdrs_map_infos?Merge all HdrsMapInfo providers from targets into singular one.*�
�
merge_hdrs_map_infos
targets[](3
hdrs#additional header files to include,None(L
implementation_hdrs-additional implementation headers to include,None(F
hdrs_map2initial hdrs_map to use as a foundation for merge,None(<
hdrs_map_deps#additional dependencies to include,None(g
pin_down_non_globsIwheather the final hdrs_map should have its
non_glob dependencies pinned.True(?Merge all HdrsMapInfo providers from targets into singular one."N
LHdrsMapInfo provider that represents merge of all HdrsMapInfos from targets.2T
merge_hdrs_map_infos<@@rules_cc_hdrs_map//cc_hdrs_map/providers:hdrs_map_info.bzl
aa�quotient_map_hdrs_map_infos7Take all HdrsMapInfo key-values and group them by keys.*�
�
quotient_map_hdrs_map_infos
targets[](3
hdrs#additional header files to include,None(L
implementation_hdrs-additional implementation headers to include,None(F
hdrs_map2initial hdrs_map to use as a foundation for merge,None(;
hdrs_map_deps"additional dependencies to includeNone(D
traverse_deps+wheather to gather HdrsMapInfos transitvelyTrue(7Take all HdrsMapInfo key-values and group them by keys."=
;(hdrs, implementation_hdrs, hdrs_map, hdr_maps_deps): tuple2[
quotient_map_hdrs_map_infos<@@rules_cc_hdrs_map//cc_hdrs_map/providers:hdrs_map_info.bzl
55�HdrsMapInfoTRepresents grouping of CC header files, alongsdie with their intended include paths.2�
�
HdrsMapInfoTRepresents grouping of CC header files, alongsdie with their intended include paths.F
hdrs>Headers which should be exposed after the compilation is done.S
implementation_hdrs<Headers that should not be propagated after the compilation.L
hdrs_map@(hdrs_map struct) object describing desired header file mappingsw
depsoCcInfo/CcSharedLibraryInfo-aware dependencies that need to be propagated, for this provider to compile and link"K
HdrsMapInfo<@@rules_cc_hdrs_map//cc_hdrs_map/providers:hdrs_map_info.bzl
H
F
hdrs>Headers which should be exposed after the compilation is done.U
S
implementation_hdrs<Headers that should not be propagated after the compilation.N
L
hdrs_map@(hdrs_map struct) object describing desired header file mappingsy
w
depsoCcInfo/CcSharedLibraryInfo-aware dependencies that need to be propagated, for this provider to compile and link�
$//cc_hdrs_map/providers:hdrs_map.bzlrt
8
rules_cc_hdrs_mapcc_hdrs_map/providershdrs_map.bzl*
new_hdrs_mapnew_hdrs_map

DModule describing HdrsMapInfo provider and common operations on it. �
6
rules_cc_hdrs_mapcc_hdrs_map/providers
helper.bzl�
2//cc_hdrs_map/providers:cc_shared_library_info.bzlr�
F
rules_cc_hdrs_mapcc_hdrs_map/providerscc_shared_library_info.bzlM
merge_cc_shared_library_infos_merge_cc_shared_library_infos
Nl]
$quotient_map_cc_shared_library_infos%_quotient_map_cc_shared_library_infos
��
��
$//cc_hdrs_map/providers:hdrs_map.bzlr�
8
rules_cc_hdrs_mapcc_hdrs_map/providershdrs_map.bzlC
materialize_hdrs_mapping_materialize_hdrs_mapping
@Y,
new_hdrs_map_new_hdrs_map
x�
��
)//cc_hdrs_map/providers:hdrs_map_info.bzlr�
=
rules_cc_hdrs_mapcc_hdrs_map/providershdrs_map_info.bzl;
merge_hdrs_map_infos_merge_hdrs_map_infos
EZJ
quotient_map_hdrs_map_infos_quotient_map_hdrs_map_infos
u�
�UThis module exposes the common operatiosn done towards providers as a helper struct. ��
*
rules_cc_hdrs_mapcc_hdrs_mapdefs.bzl��
cc_archive�Produce an archive file.

The intended major difference between this rule and rules_cc's `cc_static_library`,
is that this rule does not intend to pull-in all static dependencies.
"
�F

cc_archive�Produce an archive file.

The intended major difference between this rule and rules_cc's `cc_static_library`,
is that this rule does not intend to pull-in all static dependencies.
*
nameA unique name for this target. �
additional_compiler_inputs�
Any additional files you might want to pass to the compiler command line, such as sanitizer ignorelists, for example.
Files specified here can then be used in copts with the $(location) function. 
2[]�
additional_linker_inputs�
Any additional files that you may want to pass to the linker, for example, linker scripts.
You have to separately pass any linker flags that the linker needs in order to be aware of this file.
You can do so via the linkopts attribute.
2[]�
archive_lib_name�
Specify the name of the created .a file (that is decoupled from the rule instance name).
Note, that the 'cc_archive' is opinionated and will remove any leading 'lib' prefix and any '.a' in the name
(meaning 'libTest.a.x64.a' will become 'Test.x64' and will produce 'libTest.x64.a')
2""�
	conlyoptsy
Add these options to the C compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
copts�
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.
Each string in this attribute is added in the given order to COPTS before compiling the binary target. The flags take effect only for compiling this target, not its dependencies, so be careful about header files included elsewhere. All paths should be relative to the workspace, not to the current package.

If the package declares the feature no_copts_tokenization, Bourne shell tokenization applies only to strings that consist of a single "Make" variable.
2[]�
cxxopts{
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
data�
The list of files needed by this target at runtime. See general comments about data at Typical attributes defined by most build rules.
2[]�
defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line to this target, as well as to every rule that depends on it. Be very careful, since this may have far-reaching effects. When in doubt, add define values to local_defines instead.
2[]8
deps*The list of dependencies of current target2[]�
dynamic_deps�
In contrast to `rules_cc`, the dynamic_deps of `rules_cc_hdrs_map` are simply translated into deps parameter,
and the providers (CcInfo vs CcSharedInfo) are used to steer the behavior further.
2[]�
hdrsv
List of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.
2[]�
hdrs_map�
Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory. 
 �
implementation_deps�
The list of other libraries that the library target depends on. Unlike with deps, the headers and include paths of these libraries (and all their transitive deps) are only used for compilation of this library, and not libraries that depend on it. Libraries specified with implementation_deps are still linked in binary targets that depend on this library.
2[]�
implementation_hdrsl
List of headers that CANNOT be included by dependent rules.
Notice: the cutoff happens during compilation.
2[]�
include_prefix�
The prefix to add to the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at is the value of this attribute prepended to their repository-relative path.

The prefix in the strip_include_prefix attribute is removed before this prefix is added.
2""�
includes�
List of include dirs to be added to the compile line.
Subject to "Make variable" substitution. Each string is prepended with -isystem and added to COPTS. Unlike COPTS, these flags are added for this rule and every rule that depends on it. (Note: not the rules it depends upon!) Be very careful, since this may have far-reaching effects. When in doubt, add "-I" flags to COPTS instead.

Headers must be added to srcs or hdrs, otherwise they will not be available to dependent rules when compilation is sandboxed (the default).
2[]�
linkopts�
Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.
2[]�

linksharedz
Create a shared library. To enable this attribute, include linkshared=True in your rule. By default this option is off. 
2False�
	linkstamp�
Simultaneously compiles and links the specified C++ source file into the final binary. This trickery is required to introduce timestamp information into binaries; if we compiled the source file to an object file in the usual way, the timestamp would be incorrect. A linkstamp compilation may not include any particular set of compiler flags and so should not depend on any particular header, compiler option, or other build variable. This option should only be needed in the base package.
2None�

linkstatic�
If enabled and this is a binary or test, this option tells the build tool to link in .a's instead of .so's for user libraries whenever possible. System libraries such as libc (but not the C/C++ runtime libraries, see below) are still linked dynamically, as are libraries for which there is no static library. So the resulting executable will still be dynamically linked, hence only mostly static.
The linkstatic attribute has a different meaning if used on a cc_library() rule. For a C++ library, linkstatic=True indicates that only static linking is allowed, so no .so will be produced. linkstatic=False does not prevent static libraries from being created. The attribute is meant to control the creation of dynamic libraries. 
2False�
local_defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line for this target, but not to its dependents.
2[]�
module_interfaces�
The list of files that are regarded as C++20 Modules Interface.

C++ Standard has no restriction about module interface file extension
* Clang use cppm
* GCC can use any source file extension
* MSVC use ixx

The use is guarded by the flag --experimental_cpp_modules.
2[]�
nocopts�
Remove matching options from the C++ compilation command. Subject to "Make" variable substitution. The value of this attribute is interpreted as a regular expression. Any preexisting COPTS that match this regular expression (including values explicitly specified in the rule's copts attribute) will be removed from COPTS for purposes of compiling this rule. This attribute should not be needed or used outside of third_party. The values are not preprocessed in any way other than the "Make" variable substitution. 
2""
reexport_deps2[]%
srcsThe list of source files. �
strip_include_prefix�
The prefix to strip from the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at their path with this prefix cut off.

If it's a relative path, it's taken as a package-relative one. If it's an absolute one, it's understood as a repository-relative path.

The prefix in the include_prefix attribute is added after this prefix is stripped.
2""�
textual_hdrs�
The list of header files published by this library to be textually included by sources in dependent rules.

This is the location for declaring header files that cannot be compiled on their own; that is, they always need to be textually included by other source files to build valid code.
2[]�
win_def_file�
The Windows DEF file to be passed to linker.

This attribute should only be used when Windows is the target platform. It can be used to export symbols during linking a shared library.
2None"7

cc_archive)@@rules_cc_hdrs_map//cc_hdrs_map:defs.bzl
//,
*
nameA unique name for this target. �
�
additional_compiler_inputs�
Any additional files you might want to pass to the compiler command line, such as sanitizer ignorelists, for example.
Files specified here can then be used in copts with the $(location) function. 
2[]�
�
additional_linker_inputs�
Any additional files that you may want to pass to the linker, for example, linker scripts.
You have to separately pass any linker flags that the linker needs in order to be aware of this file.
You can do so via the linkopts attribute.
2[]�
�
archive_lib_name�
Specify the name of the created .a file (that is decoupled from the rule instance name).
Note, that the 'cc_archive' is opinionated and will remove any leading 'lib' prefix and any '.a' in the name
(meaning 'libTest.a.x64.a' will become 'Test.x64' and will produce 'libTest.x64.a')
2""�
�
	conlyoptsy
Add these options to the C compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
�
copts�
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.
Each string in this attribute is added in the given order to COPTS before compiling the binary target. The flags take effect only for compiling this target, not its dependencies, so be careful about header files included elsewhere. All paths should be relative to the workspace, not to the current package.

If the package declares the feature no_copts_tokenization, Bourne shell tokenization applies only to strings that consist of a single "Make" variable.
2[]�
�
cxxopts{
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
�
data�
The list of files needed by this target at runtime. See general comments about data at Typical attributes defined by most build rules.
2[]�
�
defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line to this target, as well as to every rule that depends on it. Be very careful, since this may have far-reaching effects. When in doubt, add define values to local_defines instead.
2[]:
8
deps*The list of dependencies of current target2[]�
�
dynamic_deps�
In contrast to `rules_cc`, the dynamic_deps of `rules_cc_hdrs_map` are simply translated into deps parameter,
and the providers (CcInfo vs CcSharedInfo) are used to steer the behavior further.
2[]�
�
hdrsv
List of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.
2[]�
�
hdrs_map�
Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory. 
 �
�
implementation_deps�
The list of other libraries that the library target depends on. Unlike with deps, the headers and include paths of these libraries (and all their transitive deps) are only used for compilation of this library, and not libraries that depend on it. Libraries specified with implementation_deps are still linked in binary targets that depend on this library.
2[]�
�
implementation_hdrsl
List of headers that CANNOT be included by dependent rules.
Notice: the cutoff happens during compilation.
2[]�
�
include_prefix�
The prefix to add to the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at is the value of this attribute prepended to their repository-relative path.

The prefix in the strip_include_prefix attribute is removed before this prefix is added.
2""�
�
includes�
List of include dirs to be added to the compile line.
Subject to "Make variable" substitution. Each string is prepended with -isystem and added to COPTS. Unlike COPTS, these flags are added for this rule and every rule that depends on it. (Note: not the rules it depends upon!) Be very careful, since this may have far-reaching effects. When in doubt, add "-I" flags to COPTS instead.

Headers must be added to srcs or hdrs, otherwise they will not be available to dependent rules when compilation is sandboxed (the default).
2[]�
�
linkopts�
Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.
2[]�
�

linksharedz
Create a shared library. To enable this attribute, include linkshared=True in your rule. By default this option is off. 
2False�
�
	linkstamp�
Simultaneously compiles and links the specified C++ source file into the final binary. This trickery is required to introduce timestamp information into binaries; if we compiled the source file to an object file in the usual way, the timestamp would be incorrect. A linkstamp compilation may not include any particular set of compiler flags and so should not depend on any particular header, compiler option, or other build variable. This option should only be needed in the base package.
2None�
�

linkstatic�
If enabled and this is a binary or test, this option tells the build tool to link in .a's instead of .so's for user libraries whenever possible. System libraries such as libc (but not the C/C++ runtime libraries, see below) are still linked dynamically, as are libraries for which there is no static library. So the resulting executable will still be dynamically linked, hence only mostly static.
The linkstatic attribute has a different meaning if used on a cc_library() rule. For a C++ library, linkstatic=True indicates that only static linking is allowed, so no .so will be produced. linkstatic=False does not prevent static libraries from being created. The attribute is meant to control the creation of dynamic libraries. 
2False�
�
local_defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line for this target, but not to its dependents.
2[]�
�
module_interfaces�
The list of files that are regarded as C++20 Modules Interface.

C++ Standard has no restriction about module interface file extension
* Clang use cppm
* GCC can use any source file extension
* MSVC use ixx

The use is guarded by the flag --experimental_cpp_modules.
2[]�
�
nocopts�
Remove matching options from the C++ compilation command. Subject to "Make" variable substitution. The value of this attribute is interpreted as a regular expression. Any preexisting COPTS that match this regular expression (including values explicitly specified in the rule's copts attribute) will be removed from COPTS for purposes of compiling this rule. This attribute should not be needed or used outside of third_party. The values are not preprocessed in any way other than the "Make" variable substitution. 
2""

reexport_deps2[]'
%
srcsThe list of source files. �
�
strip_include_prefix�
The prefix to strip from the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at their path with this prefix cut off.

If it's a relative path, it's taken as a package-relative one. If it's an absolute one, it's understood as a repository-relative path.

The prefix in the include_prefix attribute is added after this prefix is stripped.
2""�
�
textual_hdrs�
The list of header files published by this library to be textually included by sources in dependent rules.

This is the location for declaring header files that cannot be compiled on their own; that is, they always need to be textually included by other source files to build valid code.
2[]�
�
win_def_file�
The Windows DEF file to be passed to linker.

This attribute should only be used when Windows is the target platform. It can be used to export symbols during linking a shared library.
2None�cc_bin�Produce exectuable binary.

It is intended for this rule, to differ from rules_cc's `cc_binary` in the following
fashion: it aims to automatically gather all of its dynamic dependencies and make them
available during binary execution.
"�}
�?
cc_bin�Produce exectuable binary.

It is intended for this rule, to differ from rules_cc's `cc_binary` in the following
fashion: it aims to automatically gather all of its dynamic dependencies and make them
available during binary execution.
*
nameA unique name for this target. �
additional_compiler_inputs�
Any additional files you might want to pass to the compiler command line, such as sanitizer ignorelists, for example.
Files specified here can then be used in copts with the $(location) function. 
2[]�
additional_linker_inputs�
Any additional files that you may want to pass to the linker, for example, linker scripts.
You have to separately pass any linker flags that the linker needs in order to be aware of this file.
You can do so via the linkopts attribute.
2[]�
	conlyoptsy
Add these options to the C compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
copts�
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.
Each string in this attribute is added in the given order to COPTS before compiling the binary target. The flags take effect only for compiling this target, not its dependencies, so be careful about header files included elsewhere. All paths should be relative to the workspace, not to the current package.

If the package declares the feature no_copts_tokenization, Bourne shell tokenization applies only to strings that consist of a single "Make" variable.
2[]�
cxxopts{
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
data�
The list of files needed by this target at runtime. See general comments about data at Typical attributes defined by most build rules.
2[]�
defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line to this target, as well as to every rule that depends on it. Be very careful, since this may have far-reaching effects. When in doubt, add define values to local_defines instead.
2[]8
deps*The list of dependencies of current target2[]�
dynamic_deps�
In contrast to `rules_cc`, the dynamic_deps of `rules_cc_hdrs_map` are simply translated into deps parameter,
and the providers (CcInfo vs CcSharedInfo) are used to steer the behavior further.
2[]�
hdrsv
List of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.
2[]�
hdrs_map�
Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory. 
 �
includes�
List of include dirs to be added to the compile line.
Subject to "Make variable" substitution. Each string is prepended with -isystem and added to COPTS. Unlike COPTS, these flags are added for this rule and every rule that depends on it. (Note: not the rules it depends upon!) Be very careful, since this may have far-reaching effects. When in doubt, add "-I" flags to COPTS instead.

Headers must be added to srcs or hdrs, otherwise they will not be available to dependent rules when compilation is sandboxed (the default).
2[]�
link_extra_lib�
Control linking of extra libraries.

By default, C++ binaries are linked against //tools/cpp:link_extra_lib, which by default depends on the label flag //tools/cpp:link_extra_libs. Without setting the flag, this library is empty by default. Setting the label flag allows linking optional dependencies, such as overrides for weak symbols, interceptors for shared library functions, or special runtime libraries (for malloc replacements, prefer malloc or --custom_malloc). Setting this attribute to None disables this behaviour. 
2None�
linkopts�
Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.
2[]�

linksharedz
Create a shared library. To enable this attribute, include linkshared=True in your rule. By default this option is off. 
2False�

linkstatic�
If enabled and this is a binary or test, this option tells the build tool to link in .a's instead of .so's for user libraries whenever possible. System libraries such as libc (but not the C/C++ runtime libraries, see below) are still linked dynamically, as are libraries for which there is no static library. So the resulting executable will still be dynamically linked, hence only mostly static.
The linkstatic attribute has a different meaning if used on a cc_library() rule. For a C++ library, linkstatic=True indicates that only static linking is allowed, so no .so will be produced. linkstatic=False does not prevent static libraries from being created. The attribute is meant to control the creation of dynamic libraries. 
2False�
local_defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line for this target, but not to its dependents.
2[]�
malloc�
Override the default dependency on malloc.

By default, C++ binaries are linked against //tools/cpp:malloc, which is an empty library so the binary ends up using libc malloc. This label must refer to a cc_library. If compilation is for a non-C++ rule, this option has no effect. The value of this attribute is ignored if linkshared=True is specified. 
2None�
module_interfaces�
The list of files that are regarded as C++20 Modules Interface.

C++ Standard has no restriction about module interface file extension
* Clang use cppm
* GCC can use any source file extension
* MSVC use ixx

The use is guarded by the flag --experimental_cpp_modules.
2[]�
nocopts�
Remove matching options from the C++ compilation command. Subject to "Make" variable substitution. The value of this attribute is interpreted as a regular expression. Any preexisting COPTS that match this regular expression (including values explicitly specified in the rule's copts attribute) will be removed from COPTS for purposes of compiling this rule. This attribute should not be needed or used outside of third_party. The values are not preprocessed in any way other than the "Make" variable substitution. 
2""
reexport_deps2[]%
srcsThe list of source files. �
stamp�
Whether to encode build information into the binary. Possible values:

  * stamp = 1: Always stamp the build information into the binary, even in --nostamp builds. This setting should be avoided, since it potentially kills remote caching for the binary and any downstream actions that depend on it.

  * stamp = 0: Always replace build information by constant values. This gives good build result caching.

  * stamp = -1: Embedding of build information is controlled by the --[no]stamp flag.

Stamped binaries are not rebuilt unless their dependencies change.
2-1�
win_def_file�
The Windows DEF file to be passed to linker.

This attribute should only be used when Windows is the target platform. It can be used to export symbols during linking a shared library.
2None"3
cc_bin)@@rules_cc_hdrs_map//cc_hdrs_map:defs.bzl
,
*
nameA unique name for this target. �
�
additional_compiler_inputs�
Any additional files you might want to pass to the compiler command line, such as sanitizer ignorelists, for example.
Files specified here can then be used in copts with the $(location) function. 
2[]�
�
additional_linker_inputs�
Any additional files that you may want to pass to the linker, for example, linker scripts.
You have to separately pass any linker flags that the linker needs in order to be aware of this file.
You can do so via the linkopts attribute.
2[]�
�
	conlyoptsy
Add these options to the C compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
�
copts�
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.
Each string in this attribute is added in the given order to COPTS before compiling the binary target. The flags take effect only for compiling this target, not its dependencies, so be careful about header files included elsewhere. All paths should be relative to the workspace, not to the current package.

If the package declares the feature no_copts_tokenization, Bourne shell tokenization applies only to strings that consist of a single "Make" variable.
2[]�
�
cxxopts{
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
�
data�
The list of files needed by this target at runtime. See general comments about data at Typical attributes defined by most build rules.
2[]�
�
defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line to this target, as well as to every rule that depends on it. Be very careful, since this may have far-reaching effects. When in doubt, add define values to local_defines instead.
2[]:
8
deps*The list of dependencies of current target2[]�
�
dynamic_deps�
In contrast to `rules_cc`, the dynamic_deps of `rules_cc_hdrs_map` are simply translated into deps parameter,
and the providers (CcInfo vs CcSharedInfo) are used to steer the behavior further.
2[]�
�
hdrsv
List of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.
2[]�
�
hdrs_map�
Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory. 
 �
�
includes�
List of include dirs to be added to the compile line.
Subject to "Make variable" substitution. Each string is prepended with -isystem and added to COPTS. Unlike COPTS, these flags are added for this rule and every rule that depends on it. (Note: not the rules it depends upon!) Be very careful, since this may have far-reaching effects. When in doubt, add "-I" flags to COPTS instead.

Headers must be added to srcs or hdrs, otherwise they will not be available to dependent rules when compilation is sandboxed (the default).
2[]�
�
link_extra_lib�
Control linking of extra libraries.

By default, C++ binaries are linked against //tools/cpp:link_extra_lib, which by default depends on the label flag //tools/cpp:link_extra_libs. Without setting the flag, this library is empty by default. Setting the label flag allows linking optional dependencies, such as overrides for weak symbols, interceptors for shared library functions, or special runtime libraries (for malloc replacements, prefer malloc or --custom_malloc). Setting this attribute to None disables this behaviour. 
2None�
�
linkopts�
Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.
2[]�
�

linksharedz
Create a shared library. To enable this attribute, include linkshared=True in your rule. By default this option is off. 
2False�
�

linkstatic�
If enabled and this is a binary or test, this option tells the build tool to link in .a's instead of .so's for user libraries whenever possible. System libraries such as libc (but not the C/C++ runtime libraries, see below) are still linked dynamically, as are libraries for which there is no static library. So the resulting executable will still be dynamically linked, hence only mostly static.
The linkstatic attribute has a different meaning if used on a cc_library() rule. For a C++ library, linkstatic=True indicates that only static linking is allowed, so no .so will be produced. linkstatic=False does not prevent static libraries from being created. The attribute is meant to control the creation of dynamic libraries. 
2False�
�
local_defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line for this target, but not to its dependents.
2[]�
�
malloc�
Override the default dependency on malloc.

By default, C++ binaries are linked against //tools/cpp:malloc, which is an empty library so the binary ends up using libc malloc. This label must refer to a cc_library. If compilation is for a non-C++ rule, this option has no effect. The value of this attribute is ignored if linkshared=True is specified. 
2None�
�
module_interfaces�
The list of files that are regarded as C++20 Modules Interface.

C++ Standard has no restriction about module interface file extension
* Clang use cppm
* GCC can use any source file extension
* MSVC use ixx

The use is guarded by the flag --experimental_cpp_modules.
2[]�
�
nocopts�
Remove matching options from the C++ compilation command. Subject to "Make" variable substitution. The value of this attribute is interpreted as a regular expression. Any preexisting COPTS that match this regular expression (including values explicitly specified in the rule's copts attribute) will be removed from COPTS for purposes of compiling this rule. This attribute should not be needed or used outside of third_party. The values are not preprocessed in any way other than the "Make" variable substitution. 
2""

reexport_deps2[]'
%
srcsThe list of source files. �
�
stamp�
Whether to encode build information into the binary. Possible values:

  * stamp = 1: Always stamp the build information into the binary, even in --nostamp builds. This setting should be avoided, since it potentially kills remote caching for the binary and any downstream actions that depend on it.

  * stamp = 0: Always replace build information by constant values. This gives good build result caching.

  * stamp = -1: Embedding of build information is controlled by the --[no]stamp flag.

Stamped binaries are not rebuilt unless their dependencies change.
2-1�
�
win_def_file�
The Windows DEF file to be passed to linker.

This attribute should only be used when Windows is the target platform. It can be used to export symbols during linking a shared library.
2None�cc_hdrs�Define header files properties.

This rule groups headers into a singular target and allows
to attach 'include_path' modifications information to them,
so that wherever the header files are being used, they can
be used with their intended include paths.
"�
�
cc_hdrs�Define header files properties.

This rule groups headers into a singular target and allows
to attach 'include_path' modifications information to them,
so that wherever the header files are being used, they can
be used with their intended include paths.
*
nameA unique name for this target. �
data�
The list of files needed by this target at runtime. See general comments about data at Typical attributes defined by most build rules.
2[]8
deps*The list of dependencies of current target2[]�
hdrsv
List of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.
2[]�
hdrs_map�
Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory. 
 �
implementation_hdrsl
List of headers that CANNOT be included by dependent rules.
Notice: the cutoff happens during compilation.
2[]�
module_interfaces�
The list of files that are regarded as C++20 Modules Interface.

C++ Standard has no restriction about module interface file extension
* Clang use cppm
* GCC can use any source file extension
* MSVC use ixx

The use is guarded by the flag --experimental_cpp_modules.
2[]�
win_def_file�
The Windows DEF file to be passed to linker.

This attribute should only be used when Windows is the target platform. It can be used to export symbols during linking a shared library.
2None"4
cc_hdrs)@@rules_cc_hdrs_map//cc_hdrs_map:defs.bzl
66,
*
nameA unique name for this target. �
�
data�
The list of files needed by this target at runtime. See general comments about data at Typical attributes defined by most build rules.
2[]:
8
deps*The list of dependencies of current target2[]�
�
hdrsv
List of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.
2[]�
�
hdrs_map�
Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory. 
 �
�
implementation_hdrsl
List of headers that CANNOT be included by dependent rules.
Notice: the cutoff happens during compilation.
2[]�
�
module_interfaces�
The list of files that are regarded as C++20 Modules Interface.

C++ Standard has no restriction about module interface file extension
* Clang use cppm
* GCC can use any source file extension
* MSVC use ixx

The use is guarded by the flag --experimental_cpp_modules.
2[]�
�
win_def_file�
The Windows DEF file to be passed to linker.

This attribute should only be used when Windows is the target platform. It can be used to export symbols during linking a shared library.
2None��cc_so�Produce shared object library.

The intended difference between this rule and the rules_cc's cc_shared_library is to:
 1) remove 'cc_library' out of the equation (no more targets that produce either archive or sol)
 2) unify handling of dependencies that are equipped with CcInfo and CcSharedLibraryInfo
    (use singular attribute of deps to track them both).
"��
�Y
cc_so�Produce shared object library.

The intended difference between this rule and the rules_cc's cc_shared_library is to:
 1) remove 'cc_library' out of the equation (no more targets that produce either archive or sol)
 2) unify handling of dependencies that are equipped with CcInfo and CcSharedLibraryInfo
    (use singular attribute of deps to track them both).
*
nameA unique name for this target. �
additional_compiler_inputs�
Any additional files you might want to pass to the compiler command line, such as sanitizer ignorelists, for example.
Files specified here can then be used in copts with the $(location) function. 
2[]�
additional_linker_inputs�
Any additional files that you may want to pass to the linker, for example, linker scripts.
You have to separately pass any linker flags that the linker needs in order to be aware of this file.
You can do so via the linkopts attribute.
2[]�

alwayslink�
If 1, any binary that depends (directly or indirectly) on this C++ precompiled library will link in all the object files archived in the static library, even if some contain no symbols referenced by the binary. This is useful if your code isn't explicitly called by code in the binary, e.g., if your code registers to receive some callback provided by some service. 
2False�
	conlyoptsy
Add these options to the C compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
copts�
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.
Each string in this attribute is added in the given order to COPTS before compiling the binary target. The flags take effect only for compiling this target, not its dependencies, so be careful about header files included elsewhere. All paths should be relative to the workspace, not to the current package.

If the package declares the feature no_copts_tokenization, Bourne shell tokenization applies only to strings that consist of a single "Make" variable.
2[]�
cxxopts{
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
data�
The list of files needed by this target at runtime. See general comments about data at Typical attributes defined by most build rules.
2[]�
defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line to this target, as well as to every rule that depends on it. Be very careful, since this may have far-reaching effects. When in doubt, add define values to local_defines instead.
2[]8
deps*The list of dependencies of current target2[]�
dynamic_deps�
In contrast to `rules_cc`, the dynamic_deps of `rules_cc_hdrs_map` are simply translated into deps parameter,
and the providers (CcInfo vs CcSharedInfo) are used to steer the behavior further.
2[]�
exports_filter�
This attribute contains a list of targets that are claimed to be exported by the current shared library.

Any target deps is already understood to be exported by the shared library. This attribute should be used to list any targets that are exported by the shared library but are transitive dependencies of deps.

Note that this attribute is not actually adding a dependency edge to those targets, the dependency edge should instead be created by deps.The entries in this attribute are just strings. Keep in mind that when placing a target in this attribute, this is considered a claim that the shared library exports the symbols from that target. The cc_shared_library logic doesn't actually handle telling the linker which symbols should be exported.

The following syntax is allowed:

//foo:__pkg__ to account for any target in foo/BUILD

//foo:__subpackages__ to account for any target in foo/BUILD or any other package below foo/ like foo/bar/BUILD
2[]�
hdrsv
List of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.
2[]�
hdrs_map�
Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory. 
 �
implementation_deps�
The list of other libraries that the library target depends on. Unlike with deps, the headers and include paths of these libraries (and all their transitive deps) are only used for compilation of this library, and not libraries that depend on it. Libraries specified with implementation_deps are still linked in binary targets that depend on this library.
2[]�
implementation_hdrsl
List of headers that CANNOT be included by dependent rules.
Notice: the cutoff happens during compilation.
2[]�
include_prefix�
The prefix to add to the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at is the value of this attribute prepended to their repository-relative path.

The prefix in the strip_include_prefix attribute is removed before this prefix is added.
2""�
includes�
List of include dirs to be added to the compile line.
Subject to "Make variable" substitution. Each string is prepended with -isystem and added to COPTS. Unlike COPTS, these flags are added for this rule and every rule that depends on it. (Note: not the rules it depends upon!) Be very careful, since this may have far-reaching effects. When in doubt, add "-I" flags to COPTS instead.

Headers must be added to srcs or hdrs, otherwise they will not be available to dependent rules when compilation is sandboxed (the default).
2[]�
link_extra_lib�
Control linking of extra libraries.

By default, C++ binaries are linked against //tools/cpp:link_extra_lib, which by default depends on the label flag //tools/cpp:link_extra_libs. Without setting the flag, this library is empty by default. Setting the label flag allows linking optional dependencies, such as overrides for weak symbols, interceptors for shared library functions, or special runtime libraries (for malloc replacements, prefer malloc or --custom_malloc). Setting this attribute to None disables this behaviour. 
2None�
linkopts�
Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.
2[]�

linksharedz
Create a shared library. To enable this attribute, include linkshared=True in your rule. By default this option is off. 
2False�
	linkstamp�
Simultaneously compiles and links the specified C++ source file into the final binary. This trickery is required to introduce timestamp information into binaries; if we compiled the source file to an object file in the usual way, the timestamp would be incorrect. A linkstamp compilation may not include any particular set of compiler flags and so should not depend on any particular header, compiler option, or other build variable. This option should only be needed in the base package.
2None�

linkstatic�
If enabled and this is a binary or test, this option tells the build tool to link in .a's instead of .so's for user libraries whenever possible. System libraries such as libc (but not the C/C++ runtime libraries, see below) are still linked dynamically, as are libraries for which there is no static library. So the resulting executable will still be dynamically linked, hence only mostly static.
The linkstatic attribute has a different meaning if used on a cc_library() rule. For a C++ library, linkstatic=True indicates that only static linking is allowed, so no .so will be produced. linkstatic=False does not prevent static libraries from being created. The attribute is meant to control the creation of dynamic libraries. 
2False�
local_defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line for this target, but not to its dependents.
2[]�
malloc�
Override the default dependency on malloc.

By default, C++ binaries are linked against //tools/cpp:malloc, which is an empty library so the binary ends up using libc malloc. This label must refer to a cc_library. If compilation is for a non-C++ rule, this option has no effect. The value of this attribute is ignored if linkshared=True is specified. 
2None�
module_interfaces�
The list of files that are regarded as C++20 Modules Interface.

C++ Standard has no restriction about module interface file extension
* Clang use cppm
* GCC can use any source file extension
* MSVC use ixx

The use is guarded by the flag --experimental_cpp_modules.
2[]�
nocopts�
Remove matching options from the C++ compilation command. Subject to "Make" variable substitution. The value of this attribute is interpreted as a regular expression. Any preexisting COPTS that match this regular expression (including values explicitly specified in the rule's copts attribute) will be removed from COPTS for purposes of compiling this rule. This attribute should not be needed or used outside of third_party. The values are not preprocessed in any way other than the "Make" variable substitution. 
2""$
roots(Not yet implemented)2[]�
shared_lib_name�
Specify the name of the created SOL file (that is decoupled from the rule instance name).
Note, that the 'cc_so' is opinionated and will remove any leading 'lib' prefix and any '.so' in the name
(meaning 'libTest.so.x64.so' will become 'Test.x64' and will produce 'libTest.x64.so')
2""%
srcsThe list of source files. �
strip_include_prefix�
The prefix to strip from the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at their path with this prefix cut off.

If it's a relative path, it's taken as a package-relative one. If it's an absolute one, it's understood as a repository-relative path.

The prefix in the include_prefix attribute is added after this prefix is stripped.
2""�
textual_hdrs�
The list of header files published by this library to be textually included by sources in dependent rules.

This is the location for declaring header files that cannot be compiled on their own; that is, they always need to be textually included by other source files to build valid code.
2[]�
win_def_file�
The Windows DEF file to be passed to linker.

This attribute should only be used when Windows is the target platform. It can be used to export symbols during linking a shared library.
2None"2
cc_so)@@rules_cc_hdrs_map//cc_hdrs_map:defs.bzl
11,
*
nameA unique name for this target. �
�
additional_compiler_inputs�
Any additional files you might want to pass to the compiler command line, such as sanitizer ignorelists, for example.
Files specified here can then be used in copts with the $(location) function. 
2[]�
�
additional_linker_inputs�
Any additional files that you may want to pass to the linker, for example, linker scripts.
You have to separately pass any linker flags that the linker needs in order to be aware of this file.
You can do so via the linkopts attribute.
2[]�
�

alwayslink�
If 1, any binary that depends (directly or indirectly) on this C++ precompiled library will link in all the object files archived in the static library, even if some contain no symbols referenced by the binary. This is useful if your code isn't explicitly called by code in the binary, e.g., if your code registers to receive some callback provided by some service. 
2False�
�
	conlyoptsy
Add these options to the C compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
�
copts�
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.
Each string in this attribute is added in the given order to COPTS before compiling the binary target. The flags take effect only for compiling this target, not its dependencies, so be careful about header files included elsewhere. All paths should be relative to the workspace, not to the current package.

If the package declares the feature no_copts_tokenization, Bourne shell tokenization applies only to strings that consist of a single "Make" variable.
2[]�
�
cxxopts{
Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization. 
2[]�
�
data�
The list of files needed by this target at runtime. See general comments about data at Typical attributes defined by most build rules.
2[]�
�
defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line to this target, as well as to every rule that depends on it. Be very careful, since this may have far-reaching effects. When in doubt, add define values to local_defines instead.
2[]:
8
deps*The list of dependencies of current target2[]�
�
dynamic_deps�
In contrast to `rules_cc`, the dynamic_deps of `rules_cc_hdrs_map` are simply translated into deps parameter,
and the providers (CcInfo vs CcSharedInfo) are used to steer the behavior further.
2[]�
�
exports_filter�
This attribute contains a list of targets that are claimed to be exported by the current shared library.

Any target deps is already understood to be exported by the shared library. This attribute should be used to list any targets that are exported by the shared library but are transitive dependencies of deps.

Note that this attribute is not actually adding a dependency edge to those targets, the dependency edge should instead be created by deps.The entries in this attribute are just strings. Keep in mind that when placing a target in this attribute, this is considered a claim that the shared library exports the symbols from that target. The cc_shared_library logic doesn't actually handle telling the linker which symbols should be exported.

The following syntax is allowed:

//foo:__pkg__ to account for any target in foo/BUILD

//foo:__subpackages__ to account for any target in foo/BUILD or any other package below foo/ like foo/bar/BUILD
2[]�
�
hdrsv
List of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.
2[]�
�
hdrs_map�
Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory. 
 �
�
implementation_deps�
The list of other libraries that the library target depends on. Unlike with deps, the headers and include paths of these libraries (and all their transitive deps) are only used for compilation of this library, and not libraries that depend on it. Libraries specified with implementation_deps are still linked in binary targets that depend on this library.
2[]�
�
implementation_hdrsl
List of headers that CANNOT be included by dependent rules.
Notice: the cutoff happens during compilation.
2[]�
�
include_prefix�
The prefix to add to the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at is the value of this attribute prepended to their repository-relative path.

The prefix in the strip_include_prefix attribute is removed before this prefix is added.
2""�
�
includes�
List of include dirs to be added to the compile line.
Subject to "Make variable" substitution. Each string is prepended with -isystem and added to COPTS. Unlike COPTS, these flags are added for this rule and every rule that depends on it. (Note: not the rules it depends upon!) Be very careful, since this may have far-reaching effects. When in doubt, add "-I" flags to COPTS instead.

Headers must be added to srcs or hdrs, otherwise they will not be available to dependent rules when compilation is sandboxed (the default).
2[]�
�
link_extra_lib�
Control linking of extra libraries.

By default, C++ binaries are linked against //tools/cpp:link_extra_lib, which by default depends on the label flag //tools/cpp:link_extra_libs. Without setting the flag, this library is empty by default. Setting the label flag allows linking optional dependencies, such as overrides for weak symbols, interceptors for shared library functions, or special runtime libraries (for malloc replacements, prefer malloc or --custom_malloc). Setting this attribute to None disables this behaviour. 
2None�
�
linkopts�
Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.
2[]�
�

linksharedz
Create a shared library. To enable this attribute, include linkshared=True in your rule. By default this option is off. 
2False�
�
	linkstamp�
Simultaneously compiles and links the specified C++ source file into the final binary. This trickery is required to introduce timestamp information into binaries; if we compiled the source file to an object file in the usual way, the timestamp would be incorrect. A linkstamp compilation may not include any particular set of compiler flags and so should not depend on any particular header, compiler option, or other build variable. This option should only be needed in the base package.
2None�
�

linkstatic�
If enabled and this is a binary or test, this option tells the build tool to link in .a's instead of .so's for user libraries whenever possible. System libraries such as libc (but not the C/C++ runtime libraries, see below) are still linked dynamically, as are libraries for which there is no static library. So the resulting executable will still be dynamically linked, hence only mostly static.
The linkstatic attribute has a different meaning if used on a cc_library() rule. For a C++ library, linkstatic=True indicates that only static linking is allowed, so no .so will be produced. linkstatic=False does not prevent static libraries from being created. The attribute is meant to control the creation of dynamic libraries. 
2False�
�
local_defines�
List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line for this target, but not to its dependents.
2[]�
�
malloc�
Override the default dependency on malloc.

By default, C++ binaries are linked against //tools/cpp:malloc, which is an empty library so the binary ends up using libc malloc. This label must refer to a cc_library. If compilation is for a non-C++ rule, this option has no effect. The value of this attribute is ignored if linkshared=True is specified. 
2None�
�
module_interfaces�
The list of files that are regarded as C++20 Modules Interface.

C++ Standard has no restriction about module interface file extension
* Clang use cppm
* GCC can use any source file extension
* MSVC use ixx

The use is guarded by the flag --experimental_cpp_modules.
2[]�
�
nocopts�
Remove matching options from the C++ compilation command. Subject to "Make" variable substitution. The value of this attribute is interpreted as a regular expression. Any preexisting COPTS that match this regular expression (including values explicitly specified in the rule's copts attribute) will be removed from COPTS for purposes of compiling this rule. This attribute should not be needed or used outside of third_party. The values are not preprocessed in any way other than the "Make" variable substitution. 
2""&
$
roots(Not yet implemented)2[]�
�
shared_lib_name�
Specify the name of the created SOL file (that is decoupled from the rule instance name).
Note, that the 'cc_so' is opinionated and will remove any leading 'lib' prefix and any '.so' in the name
(meaning 'libTest.so.x64.so' will become 'Test.x64' and will produce 'libTest.x64.so')
2""'
%
srcsThe list of source files. �
�
strip_include_prefix�
The prefix to strip from the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at their path with this prefix cut off.

If it's a relative path, it's taken as a package-relative one. If it's an absolute one, it's understood as a repository-relative path.

The prefix in the include_prefix attribute is added after this prefix is stripped.
2""�
�
textual_hdrs�
The list of header files published by this library to be textually included by sources in dependent rules.

This is the location for declaring header files that cannot be compiled on their own; that is, they always need to be textually included by other source files to build valid code.
2[]�
�
win_def_file�
The Windows DEF file to be passed to linker.

This attribute should only be used when Windows is the target platform. It can be used to export symbols during linking a shared library.
2None�7cc_so_import�Import precompiled C/C++ shared object library.

The intended difference between this rule and the rules_cc's cc_import is to directly
provide CcSharedLibrary info to force linking and early deps cutoff.
"�6
�
cc_so_import�Import precompiled C/C++ shared object library.

The intended difference between this rule and the rules_cc's cc_import is to directly
provide CcSharedLibrary info to force linking and early deps cutoff.
*
nameA unique name for this target. �
additional_linker_inputs�
Any additional files that you may want to pass to the linker, for example, linker scripts.
You have to separately pass any linker flags that the linker needs in order to be aware of this file.
You can do so via the linkopts attribute.
2[]v
cascadeb
Please DO NOT USE. This makes the SOL being propagated upwards to every dependee of this target.
2False�
data�
The list of files needed by this target at runtime. See general comments about data at Typical attributes defined by most build rules.
2[]8
deps*The list of dependencies of current target2[]�
dynamic_deps�
In contrast to `rules_cc`, the dynamic_deps of `rules_cc_hdrs_map` are simply translated into deps parameter,
and the providers (CcInfo vs CcSharedInfo) are used to steer the behavior further.
2[]�
hdrsv
List of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.
2[]�
hdrs_map�
Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory. 
 �
implementation_deps�
The list of other libraries that the library target depends on. Unlike with deps, the headers and include paths of these libraries (and all their transitive deps) are only used for compilation of this library, and not libraries that depend on it. Libraries specified with implementation_deps are still linked in binary targets that depend on this library.
2[]�
include_prefix�
The prefix to add to the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at is the value of this attribute prepended to their repository-relative path.

The prefix in the strip_include_prefix attribute is removed before this prefix is added.
2""�
linkopts�
Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.
2[]�
shared_libraryv
A single precompiled shared library. This ruleset will ensure it will be available to depending cc_hdrs_map targets.
 �
strip_include_prefix�
The prefix to strip from the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at their path with this prefix cut off.

If it's a relative path, it's taken as a package-relative one. If it's an absolute one, it's understood as a repository-relative path.

The prefix in the include_prefix attribute is added after this prefix is stripped.
2"""9
cc_so_import)@@rules_cc_hdrs_map//cc_hdrs_map:defs.bzl
oo,
*
nameA unique name for this target. �
�
additional_linker_inputs�
Any additional files that you may want to pass to the linker, for example, linker scripts.
You have to separately pass any linker flags that the linker needs in order to be aware of this file.
You can do so via the linkopts attribute.
2[]x
v
cascadeb
Please DO NOT USE. This makes the SOL being propagated upwards to every dependee of this target.
2False�
�
data�
The list of files needed by this target at runtime. See general comments about data at Typical attributes defined by most build rules.
2[]:
8
deps*The list of dependencies of current target2[]�
�
dynamic_deps�
In contrast to `rules_cc`, the dynamic_deps of `rules_cc_hdrs_map` are simply translated into deps parameter,
and the providers (CcInfo vs CcSharedInfo) are used to steer the behavior further.
2[]�
�
hdrsv
List of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.
2[]�
�
hdrs_map�
Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory. 
 �
�
implementation_deps�
The list of other libraries that the library target depends on. Unlike with deps, the headers and include paths of these libraries (and all their transitive deps) are only used for compilation of this library, and not libraries that depend on it. Libraries specified with implementation_deps are still linked in binary targets that depend on this library.
2[]�
�
include_prefix�
The prefix to add to the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at is the value of this attribute prepended to their repository-relative path.

The prefix in the strip_include_prefix attribute is removed before this prefix is added.
2""�
�
linkopts�
Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.
2[]�
�
shared_libraryv
A single precompiled shared library. This ruleset will ensure it will be available to depending cc_hdrs_map targets.
 �
�
strip_include_prefix�
The prefix to strip from the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at their path with this prefix cut off.

If it's a relative path, it's taken as a package-relative one. If it's an absolute one, it's understood as a repository-relative path.

The prefix in the include_prefix attribute is added after this prefix is stripped.
2""�CascadingCcSharedLibraryInfoXRepresents CcSharedLibrary that should cascade and be link in every transitive dependee.2�
�
CascadingCcSharedLibraryInfoXRepresents CcSharedLibrary that should cascade and be link in every transitive dependee.h
cc_shared_library_infosM[] of CcSharedLibraryInfo providers that describes what needs to be cascaded."I
CascadingCcSharedLibraryInfo)@@rules_cc_hdrs_map//cc_hdrs_map:defs.bzl
((j
h
cc_shared_library_infosM[] of CcSharedLibraryInfo providers that describes what needs to be cascaded.�HdrsMapInfoTRepresents grouping of CC header files, alongsdie with their intended include paths.2�
�
HdrsMapInfoTRepresents grouping of CC header files, alongsdie with their intended include paths.F
hdrs>Headers which should be exposed after the compilation is done.S
implementation_hdrs<Headers that should not be propagated after the compilation.L
hdrs_map@(hdrs_map struct) object describing desired header file mappingsw
depsoCcInfo/CcSharedLibraryInfo-aware dependencies that need to be propagated, for this provider to compile and link"8
HdrsMapInfo)@@rules_cc_hdrs_map//cc_hdrs_map:defs.bzl
H
F
hdrs>Headers which should be exposed after the compilation is done.U
S
implementation_hdrs<Headers that should not be propagated after the compilation.N
L
hdrs_map@(hdrs_map struct) object describing desired header file mappingsy
w
depsoCcInfo/CcSharedLibraryInfo-aware dependencies that need to be propagated, for this provider to compile and link�
//cc_hdrs_map/actions:defs.bzlre
2
rules_cc_hdrs_mapcc_hdrs_map/actionsdefs.bzl!
actions_actions
I:IB
IIO�
$//cc_hdrs_map/private:cc_archive.bzlrq
8
rules_cc_hdrs_mapcc_hdrs_map/privatecc_archive.bzl'

cc_archive_cc_archive
J@JK
JJ[�
 //cc_hdrs_map/private:cc_bin.bzlre
4
rules_cc_hdrs_mapcc_hdrs_map/private
cc_bin.bzl
cc_bin_cc_bin
K<KC
KKO�
!//cc_hdrs_map/private:cc_hdrs.bzlrh
5
rules_cc_hdrs_mapcc_hdrs_map/privatecc_hdrs.bzl!
cc_hdrs_cc_hdrs
L=LE
LLR�
//cc_hdrs_map/private:cc_so.bzlrb
3
rules_cc_hdrs_mapcc_hdrs_map/private	cc_so.bzl
cc_so_cc_so
M;MA
MML�
&//cc_hdrs_map/private:cc_so_import.bzlrw
:
rules_cc_hdrs_mapcc_hdrs_map/privatecc_so_import.bzl+
cc_so_import_cc_so_import
NBNO
NNa�
<//cc_hdrs_map/providers:cascading_cc_shared_library_info.bzlr�
P
rules_cc_hdrs_mapcc_hdrs_map/providers$cascading_cc_shared_library_info.bzlK
CascadingCcSharedLibraryInfo_CascadingCcSharedLibraryInfo
OXOu
OO��
)//cc_hdrs_map/providers:hdrs_map_info.bzlrx
=
rules_cc_hdrs_mapcc_hdrs_map/providershdrs_map_info.bzl)
HdrsMapInfo_HdrsMapInfo
PEPQ
PPb�
"//cc_hdrs_map/providers:helper.bzlr{
6
rules_cc_hdrs_mapcc_hdrs_map/providers
helper.bzl3
providers_helper_providers_helper
Q>QO
QQe�rules_cc_hdrs_map
---
[![ci](https://github.com/AleksanderGondek/rules_cc_hdrs_map/actions/workflows/ci.yaml/badge.svg)](https://github.com/AleksanderGondek/rules_cc_hdrs_map/actions/workflows/ci.yaml)

This project extends Bazel `CC` build capabilities with headers map implementation (allowing for easy support for most bizzare include path schemes).

In addition, it exposes CC compilation and linking functions in form of Bazel [subrules](https://docs.google.com/document/d/1RbNC88QieKvBEwir7iV5zZU08AaMlOzxhVkPnmKDedQ).

See [examples](/examples) for how to use `rules_cc_hdrs_map` (and why).

## Shortest possible example

```
$ cat foo.hpp
const std::string GREETINGS = "Hello";

$ cat foo.cpp
#include "bar/foo.h"
...

$ cat BUILD.bazel
load("@rules_cc_hdrs_map//cc_hdrs_map:defs.bzl", "cc_bin")

cc_bin(
    name = "foo",
    srcs = [
        "foo.cpp",
        "foo.hpp",
    ],
    hdrs_map = {
        "**/foo.hpp": ["bar/{filename}"],
    }
)

```

## Table of contents
1. [What issue is being addressed?](#what-issue-is-being-addressed)
2. [How the issue is being addressed?](#what-issue-is-being-addressed)
3. [What issue is being addressed?](#how-the-issue-is-being-addressed)
4. Rules
    1. [cc_archive](#cc_archive)
    2. [cc_bin](#cc_bin)
    3. [cc_hdrs](#cc_hdrs)
    4. [cc_so](#cc_so)
5. [HdrsMapInfo provider](#hdrsmapinfo)

## What issue is being addressed?

Creation of arbitrary include paths from existing sources.

_Scenario_: we want to build a C/CPP codebase with Bazel. 

One of its key characteristics is that most of the include statements do not reflect the code structure in the project - for example, header file located under path âname/a.hppâ is never included as âname/a.hppâ, instead an arbitrary list of aliases is used in the code (âx/y/z/a.hppâ, âb.hppâ etc.).  There is no overarching convention that could be used to generalize those statements into another file file hierarchy - in other words, every header file is a special case of its own.

Unfortunately we are forbidden from modifying the code itself and the directory structure (hello from enterprise word). 

As Bazel `rules_cc` have the expectation of header files being included in a way that resembles the file structure in the WORKSPACE (and one can only provide single âinclude prefixâ per library), we need to prepare the âexpected file structureâ before passing them into the `rules_cc`.

In the most naive approach, said âexpected file structureâ is being prepared for each compilable target (copying over files), passing on the already created structure to targets that depend on it. Very quickly conflicts occur and change of a single header file may cascade into rebuilding hundreds of targets.

There has to be a better way!

## How the issue is being addressed? 

The concept of header map is introduced - it is a dictionary, containing mapping between simple glob paths and their desired include paths. For example: â**/a.hppâ: âx/y/z/a.hppâ expresses the intent to import any header file with name âa.hppâ, present during compilation , as âx/y/z/a.hppâ. 

Said header map is propagated across all compatible C/C++ rules (meaning those from this WORKSPACE) and is being merged with all other header maps present. 

No action is being performed up until the moment of compilation - header mappings, resulting from the header map dictionary, are created only for the purposes of compilation and are _NOT_ part of any rule output. This ensures the impact for the Bazel cache is minimal and the compatibility with original `rules_cc`.
�
4
rules_cc_hdrs_mapcc_hdrs_mapworkspace_deps.bzl�cc_hdrs_map_workspace_deps%Load all dependencies of cc_hdrs_map.*�
�
cc_hdrs_map_workspace_deps%Load all dependencies of cc_hdrs_map.2Q
cc_hdrs_map_workspace_deps3@@rules_cc_hdrs_map//cc_hdrs_map:workspace_deps.bzl
�
 //tools/build_defs/repo:http.bzlrj
.
bazel_toolstools/build_defs/repohttp.bzl*
http_archivehttp_archive
7C
E�
!//tools/build_defs/repo:utils.bzlr]
/
bazel_toolstools/build_defs/repo	utils.bzl
maybemaybe
8=
?IThis module exposes a way to load rule dependencies in non-bzlmod usage. �
(
rules_cc_hdrs_maputilsstardocs.bzl�stardoc_with_diff_test�Creates a stardoc target and update_docs target which writes the generated doc to the source tree and tests that it's up to date.

This is helpful for minimizing boilerplate in repos with lots of stardoc targets.
*�
�
stardoc_with_diff_test�
name�the name of the stardoc file to be written to the current source directory (.md will be appended to the name). Call bazel run on this target to update the file. (]
bzl_library_targetCthe label of the `bzl_library` target to generate documentation for (d
kwargsXadditional attributes passed to the stardoc() rule, such as for overriding the templates(�Creates a stardoc target and update_docs target which writes the generated doc to the source tree and tests that it's up to date.

This is helpful for minimizing boilerplate in repos with lots of stardoc targets.
2A
stardoc_with_diff_test'@@rules_cc_hdrs_map//utils:stardocs.bzl
*_stardoc2_stardoc�
//lib:write_source_files.bzlrp
(
	bazel_liblibwrite_source_files.bzl6
write_source_fileswrite_source_files
1C
Em
//stardoc:stardoc.bzlrR

stardocstardocstardoc.bzl!
stardoc_stardoc
'/
<�
Utility macros for generating markdown documentation.

The logic was previously present in the {aspect-}bazel-lib but was
removed (https://github.com/bazel-contrib/bazel-lib/issues/1185).

The current implementation is heavily inspired by said logic
(https://github.com/bazel-contrib/bazel-lib/blob/cbdd3a88650b8708c89c6871c07a5fcf01a89bc0/lib/private/docs.bzl)
but was modified to not use `native.` functionality.
 