�%
$cc_hdrs_map/actionscc_helper.bzl�(cc_helper.expand_make_variables_in_copts*�
�
(cc_helper.expand_make_variables_in_copts	
ctx (
cc_info (
action_kwargs (

opts (2F
_expand_make_variables_in_copts#//cc_hdrs_map/actions:cc_helper.bzl
	
ctx (

cc_info (

action_kwargs (


opts (�*cc_helper.expand_make_variables_in_defines*�
�
*cc_helper.expand_make_variables_in_defines	
ctx (
cc_info (
action_kwargs (
defines (
localFalse(2H
!_expand_make_variables_in_defines#//cc_hdrs_map/actions:cc_helper.bzl
	
ctx (

cc_info (

action_kwargs (

defines (

localFalse(�+cc_helper.expand_make_variables_in_linkopts*�
�
+cc_helper.expand_make_variables_in_linkopts	
ctx (
cc_info (
action_kwargs (

opts (2I
"_expand_make_variables_in_linkopts#//cc_hdrs_map/actions:cc_helper.bzl
	
ctx (

cc_info (

action_kwargs (


opts (mcc_helper.extensions.cc_header*I
G
cc_helper.extensions.cc_header2%#//cc_hdrs_map/actions:cc_helper.bzlmcc_helper.extensions.cc_source*I
G
cc_helper.extensions.cc_source2%#//cc_hdrs_map/actions:cc_helper.bzl�cc_helper.extract_headers*r
a
cc_helper.extract_headers
files (27
_extract_headers#//cc_hdrs_map/actions:cc_helper.bzl

files (�cc_helper.extract_sources*r
a
cc_helper.extract_sources
files (27
_extract_sources#//cc_hdrs_map/actions:cc_helper.bzl

files (�$cc_helper.get_cc_flags_make_variable*�
�
$cc_helper.get_cc_flags_make_variable
cc_toolchain (
feature_configuration (2B
_get_cc_flags_make_variable#//cc_hdrs_map/actions:cc_helper.bzl

cc_toolchain (

feature_configuration (�!cc_helper.get_compilation_defines*�
�
!cc_helper.get_compilation_defines	
ctx (
defines[](
deps[](.
&additional_make_variable_substitutions{}(
additional_targets[](2?
_get_compilation_defines#//cc_hdrs_map/actions:cc_helper.bzl
	
ctx (

defines[](

deps[](0
.
&additional_make_variable_substitutions{}(

additional_targets[](�cc_helper.get_compilation_opts*�
�
cc_helper.get_compilation_opts	
ctx (

opts (
feature_configuration (.
&additional_make_variable_substitutions{}(
additional_inputs[](2<
_get_compilation_opts#//cc_hdrs_map/actions:cc_helper.bzl
	
ctx (


opts (

feature_configuration (0
.
&additional_make_variable_substitutions{}(

additional_inputs[](�cc_helper.get_linking_opts*�
�
cc_helper.get_linking_opts	
ctx (

opts (.
&additional_make_variable_substitutions{}(
additional_inputs[](28
_get_linking_opts#//cc_hdrs_map/actions:cc_helper.bzl
	
ctx (


opts (0
.
&additional_make_variable_substitutions{}(

additional_inputs[](�/cc_helper.get_local_defines_for_runfiles_lookup*�
�
/cc_helper.get_local_defines_for_runfiles_lookup	
ctx (
all_deps (2M
&_get_local_defines_for_runfiles_lookup#//cc_hdrs_map/actions:cc_helper.bzl
	
ctx (

all_deps (�-cc_helper.get_toolchain_global_make_variables*�
�
-cc_helper.get_toolchain_global_make_variables
cc_toolchain (2K
$_get_toolchain_global_make_variables#//cc_hdrs_map/actions:cc_helper.bzl

cc_toolchain (�
!cc_helper.prepare_for_compilation�Materialize information from hdrs map.

This function creates a epheremal directory, that contains all of the
patterns specified within hdrs_map providers, thus making them all
available under singular, temporary include statment.
*�
�
!cc_helper.prepare_for_compilation
sctxsubrule context (i
input_hdrs_mapSlist of HdrsMapInfo which should be used for materialization of compilation context (7

input_hdrs%direct headers provided to the action (F
input_implementation_hdrs%direct headers provided to the action (7

input_deps%dependencies specified for the action (A
input_includes+include statements specified for the action (�Materialize information from hdrs map.

This function creates a epheremal directory, that contains all of the
patterns specified within hdrs_map providers, thus making them all
available under singular, temporary include statment.
2?
_prepare_for_compilation#//cc_hdrs_map/actions:cc_helper.bzl

sctxsubrule context (k
i
input_hdrs_mapSlist of HdrsMapInfo which should be used for materialization of compilation context (9
7

input_hdrs%direct headers provided to the action (H
F
input_implementation_hdrs%direct headers provided to the action (9
7

input_deps%dependencies specified for the action (C
A
input_includes+include statements specified for the action (eThis module serves chiefly as a vehicle for exposing 'private' cc_helper methods to current rule set.x
"cc_hdrs_map/actionscompile.bzlRThis module contains logic responsible for HdrsMap handling and compilation phase.�
$cc_hdrs_map/actionscopy_file.bzl�	copy_fileaCopy file from a to b.

This function will copy file from given source to specified destination.
*�
�
	copy_file
ctx_actions (@
src5(File) source file that should be copied. Must exist. (W
dstL(File) destination file that should be created. Must be declared beforehand. (aCopy file from a to b.

This function will copy file from given source to specified destination.
20
	copy_file#//cc_hdrs_map/actions:copy_file.bzl

ctx_actions (B
@
src5(File) source file that should be copied. Must exist. (Y
W
dstL(File) destination file that should be created. Must be declared beforehand. (^This module exposes the copy_file action. Done to avoid dependency towards skylib (or others).�
cc_hdrs_map/actionsdefs.bzl�actions.compile_kwargs*z
W
actions.compile_kwargs	
ctx (

rule_attrs (2 //cc_hdrs_map/actions:defs.bzl
	
ctx (


rule_attrs (�actions.link_to_archive_kwargs*�
_
actions.link_to_archive_kwargs	
ctx (

rule_attrs (2 //cc_hdrs_map/actions:defs.bzl
	
ctx (


rule_attrs (�actions.link_to_binary_kwargs*�
^
actions.link_to_binary_kwargs	
ctx (

rule_attrs (2 //cc_hdrs_map/actions:defs.bzl
	
ctx (


rule_attrs (�actions.link_to_so_kwargs*}
Z
actions.link_to_so_kwargs	
ctx (

rule_attrs (2 //cc_hdrs_map/actions:defs.bzl
	
ctx (


rule_attrs (�
actions.prepare_for_compilation�Materialize information from hdrs map.

This function creates a epheremal directory, that contains all of the
patterns specified within hdrs_map providers, thus making them all
available under singular, temporary include statment.
*�
�
actions.prepare_for_compilation
sctxsubrule context (i
input_hdrs_mapSlist of HdrsMapInfo which should be used for materialization of compilation context (7

input_hdrs%direct headers provided to the action (F
input_implementation_hdrs%direct headers provided to the action (7

input_deps%dependencies specified for the action (A
input_includes+include statements specified for the action (�Materialize information from hdrs map.

This function creates a epheremal directory, that contains all of the
patterns specified within hdrs_map providers, thus making them all
available under singular, temporary include statment.
2?
_prepare_for_compilation#//cc_hdrs_map/actions:cc_helper.bzl

sctxsubrule context (k
i
input_hdrs_mapSlist of HdrsMapInfo which should be used for materialization of compilation context (9
7

input_hdrs%direct headers provided to the action (H
F
input_implementation_hdrs%direct headers provided to the action (9
7

input_deps%dependencies specified for the action (C
A
input_includes+include statements specified for the action (^This module defines the CC compilation phase actions which are exposed publicalyl as subrules.p
*cc_hdrs_map/actionslink_to_archive.bzlB" This module contains logic responsible for linking into .a file.v
)cc_hdrs_map/actionslink_to_binary.bzlIThis module contains logic responsible for creation of executable binary.j
%cc_hdrs_map/actionslink_to_so.bzlAThis module contains logic responsible for linking into .so file.��
cc_hdrs_mapdefs.bzl��
cc_archive�Produce an archive file.

The intended major difference between this rule and rules_cc's `cc_static_library`,
is that this rule does not intend to pull-in all static dependencies."̋
�F

cc_archive�Produce an archive file.

The intended major difference between this rule and rules_cc's `cc_static_library`,
is that this rule does not intend to pull-in all static dependencies.*
nameA unique name for this target. �
archive_lib_name�Specify the name of the created .a file (that is decoupled from the rule instance name).
Note, that the 'cc_archive' is opinionated and will remove any leading 'lib' prefix and any '.a' in the name
(meaning 'libTest.a.x64.a' will become 'Test.x64' and will produce 'libTest.x64.a')2""
reexport_deps2[]�
data�The list of files needed by this target at runtime. See general comments about data at Typical attributes defined by most build rules.2[]8
deps*The list of dependencies of current target2[]%
srcsThe list of source files. �
hdrstList of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.2[]�
implementation_hdrsjList of headers that CANNOT be included by dependent rules.
Notice: the cutoff happens during compilation.2[]�
hdrs_map�Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory.2{}�
module_interfaces�The list of files that are regarded as C++20 Modules Interface.

C++ Standard has no restriction about module interface file extension
* Clang use cppm
* GCC can use any source file extension
* MSVC use ixx

The use is guarded by the flag --experimental_cpp_modules.2[]�
win_def_file�The Windows DEF file to be passed to linker.

This attribute should only be used when Windows is the target platform. It can be used to export symbols during linking a shared library.2None�
additional_compiler_inputs�Any additional files you might want to pass to the compiler command line, such as sanitizer ignorelists, for example.
Files specified here can then be used in copts with the $(location) function.2[]�
additional_linker_inputs�Any additional files that you may want to pass to the linker, for example, linker scripts.
You have to separately pass any linker flags that the linker needs in order to be aware of this file.
You can do so via the linkopts attribute.2[]�
	conlyoptsvAdd these options to the C compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.2[]�
copts�Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.
Each string in this attribute is added in the given order to COPTS before compiling the binary target. The flags take effect only for compiling this target, not its dependencies, so be careful about header files included elsewhere. All paths should be relative to the workspace, not to the current package.

If the package declares the feature no_copts_tokenization, Bourne shell tokenization applies only to strings that consist of a single "Make" variable.2[]�
cxxoptsxAdd these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.2[]�
defines�List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line to this target, as well as to every rule that depends on it. Be very careful, since this may have far-reaching effects. When in doubt, add define values to local_defines instead.2[]�
dynamic_deps�In contrast to `rules_cc`, the dynamic_deps of `rules_cc_hdrs_map` are simply translated into deps parameter,
and the providers (CcInfo vs CcSharedInfo) are used to steer the behavior further.2[]�
implementation_deps�The list of other libraries that the library target depends on. Unlike with deps, the headers and include paths of these libraries (and all their transitive deps) are only used for compilation of this library, and not libraries that depend on it. Libraries specified with implementation_deps are still linked in binary targets that depend on this library.2[]�
includes�List of include dirs to be added to the compile line.
Subject to "Make variable" substitution. Each string is prepended with -isystem and added to COPTS. Unlike COPTS, these flags are added for this rule and every rule that depends on it. (Note: not the rules it depends upon!) Be very careful, since this may have far-reaching effects. When in doubt, add "-I" flags to COPTS instead.

Headers must be added to srcs or hdrs, otherwise they will not be available to dependent rules when compilation is sandboxed (the default).2[]�
linkopts�Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.2[]�

linksharedwCreate a shared library. To enable this attribute, include linkshared=True in your rule. By default this option is off.2False�
	linkstamp�Simultaneously compiles and links the specified C++ source file into the final binary. This trickery is required to introduce timestamp information into binaries; if we compiled the source file to an object file in the usual way, the timestamp would be incorrect. A linkstamp compilation may not include any particular set of compiler flags and so should not depend on any particular header, compiler option, or other build variable. This option should only be needed in the base package.2None�

linkstatic�If enabled and this is a binary or test, this option tells the build tool to link in .a's instead of .so's for user libraries whenever possible. System libraries such as libc (but not the C/C++ runtime libraries, see below) are still linked dynamically, as are libraries for which there is no static library. So the resulting executable will still be dynamically linked, hence only mostly static.
The linkstatic attribute has a different meaning if used on a cc_library() rule. For a C++ library, linkstatic=True indicates that only static linking is allowed, so no .so will be produced. linkstatic=False does not prevent static libraries from being created. The attribute is meant to control the creation of dynamic libraries.2False�
local_defines�List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line for this target, but not to its dependents.2[]�
nocopts�Remove matching options from the C++ compilation command. Subject to "Make" variable substitution. The value of this attribute is interpreted as a regular expression. Any preexisting COPTS that match this regular expression (including values explicitly specified in the rule's copts attribute) will be removed from COPTS for purposes of compiling this rule. This attribute should not be needed or used outside of third_party. The values are not preprocessed in any way other than the "Make" variable substitution.2""�
include_prefix�The prefix to add to the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at is the value of this attribute prepended to their repository-relative path.

The prefix in the strip_include_prefix attribute is removed before this prefix is added.2""�
strip_include_prefix�The prefix to strip from the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at their path with this prefix cut off.

If it's a relative path, it's taken as a package-relative one. If it's an absolute one, it's understood as a repository-relative path.

The prefix in the include_prefix attribute is added after this prefix is stripped.2""�
textual_hdrs�The list of header files published by this library to be textually included by sources in dependent rules.

This is the location for declaring header files that cannot be compiled on their own; that is, they always need to be textually included by other source files to build valid code.2[]"2

cc_archive$//cc_hdrs_map/private:cc_archive.bzl*�
DefaultInfo
CcInfo
HdrsMapInfo
DefaultInfo<native>
CcInfo<native>8
HdrsMapInfo)//cc_hdrs_map/providers:hdrs_map_info.bzl,
*
nameA unique name for this target. �
�
archive_lib_name�Specify the name of the created .a file (that is decoupled from the rule instance name).
Note, that the 'cc_archive' is opinionated and will remove any leading 'lib' prefix and any '.a' in the name
(meaning 'libTest.a.x64.a' will become 'Test.x64' and will produce 'libTest.x64.a')2""

reexport_deps2[]�
�
data�The list of files needed by this target at runtime. See general comments about data at Typical attributes defined by most build rules.2[]:
8
deps*The list of dependencies of current target2[]'
%
srcsThe list of source files. �
�
hdrstList of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.2[]�
�
implementation_hdrsjList of headers that CANNOT be included by dependent rules.
Notice: the cutoff happens during compilation.2[]�
�
hdrs_map�Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory.2{}�
�
module_interfaces�The list of files that are regarded as C++20 Modules Interface.

C++ Standard has no restriction about module interface file extension
* Clang use cppm
* GCC can use any source file extension
* MSVC use ixx

The use is guarded by the flag --experimental_cpp_modules.2[]�
�
win_def_file�The Windows DEF file to be passed to linker.

This attribute should only be used when Windows is the target platform. It can be used to export symbols during linking a shared library.2None�
�
additional_compiler_inputs�Any additional files you might want to pass to the compiler command line, such as sanitizer ignorelists, for example.
Files specified here can then be used in copts with the $(location) function.2[]�
�
additional_linker_inputs�Any additional files that you may want to pass to the linker, for example, linker scripts.
You have to separately pass any linker flags that the linker needs in order to be aware of this file.
You can do so via the linkopts attribute.2[]�
�
	conlyoptsvAdd these options to the C compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.2[]�
�
copts�Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.
Each string in this attribute is added in the given order to COPTS before compiling the binary target. The flags take effect only for compiling this target, not its dependencies, so be careful about header files included elsewhere. All paths should be relative to the workspace, not to the current package.

If the package declares the feature no_copts_tokenization, Bourne shell tokenization applies only to strings that consist of a single "Make" variable.2[]�
�
cxxoptsxAdd these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.2[]�
�
defines�List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line to this target, as well as to every rule that depends on it. Be very careful, since this may have far-reaching effects. When in doubt, add define values to local_defines instead.2[]�
�
dynamic_deps�In contrast to `rules_cc`, the dynamic_deps of `rules_cc_hdrs_map` are simply translated into deps parameter,
and the providers (CcInfo vs CcSharedInfo) are used to steer the behavior further.2[]�
�
implementation_deps�The list of other libraries that the library target depends on. Unlike with deps, the headers and include paths of these libraries (and all their transitive deps) are only used for compilation of this library, and not libraries that depend on it. Libraries specified with implementation_deps are still linked in binary targets that depend on this library.2[]�
�
includes�List of include dirs to be added to the compile line.
Subject to "Make variable" substitution. Each string is prepended with -isystem and added to COPTS. Unlike COPTS, these flags are added for this rule and every rule that depends on it. (Note: not the rules it depends upon!) Be very careful, since this may have far-reaching effects. When in doubt, add "-I" flags to COPTS instead.

Headers must be added to srcs or hdrs, otherwise they will not be available to dependent rules when compilation is sandboxed (the default).2[]�
�
linkopts�Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.2[]�
�

linksharedwCreate a shared library. To enable this attribute, include linkshared=True in your rule. By default this option is off.2False�
�
	linkstamp�Simultaneously compiles and links the specified C++ source file into the final binary. This trickery is required to introduce timestamp information into binaries; if we compiled the source file to an object file in the usual way, the timestamp would be incorrect. A linkstamp compilation may not include any particular set of compiler flags and so should not depend on any particular header, compiler option, or other build variable. This option should only be needed in the base package.2None�
�

linkstatic�If enabled and this is a binary or test, this option tells the build tool to link in .a's instead of .so's for user libraries whenever possible. System libraries such as libc (but not the C/C++ runtime libraries, see below) are still linked dynamically, as are libraries for which there is no static library. So the resulting executable will still be dynamically linked, hence only mostly static.
The linkstatic attribute has a different meaning if used on a cc_library() rule. For a C++ library, linkstatic=True indicates that only static linking is allowed, so no .so will be produced. linkstatic=False does not prevent static libraries from being created. The attribute is meant to control the creation of dynamic libraries.2False�
�
local_defines�List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line for this target, but not to its dependents.2[]�
�
nocopts�Remove matching options from the C++ compilation command. Subject to "Make" variable substitution. The value of this attribute is interpreted as a regular expression. Any preexisting COPTS that match this regular expression (including values explicitly specified in the rule's copts attribute) will be removed from COPTS for purposes of compiling this rule. This attribute should not be needed or used outside of third_party. The values are not preprocessed in any way other than the "Make" variable substitution.2""�
�
include_prefix�The prefix to add to the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at is the value of this attribute prepended to their repository-relative path.

The prefix in the strip_include_prefix attribute is removed before this prefix is added.2""�
�
strip_include_prefix�The prefix to strip from the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at their path with this prefix cut off.

If it's a relative path, it's taken as a package-relative one. If it's an absolute one, it's understood as a repository-relative path.

The prefix in the include_prefix attribute is added after this prefix is stripped.2""�
�
textual_hdrs�The list of header files published by this library to be textually included by sources in dependent rules.

This is the location for declaring header files that cannot be compiled on their own; that is, they always need to be textually included by other source files to build valid code.2[]�~cc_bin�Produce exectuable binary.

It is intended for this rule, to differ from rules_cc's `cc_binary` in the following
fashion: it aims to automatically gather all of its dynamic dependencies and make them
available during binary execution."�|
�?
cc_bin�Produce exectuable binary.

It is intended for this rule, to differ from rules_cc's `cc_binary` in the following
fashion: it aims to automatically gather all of its dynamic dependencies and make them
available during binary execution.*
nameA unique name for this target. �
stamp�Whether to encode build information into the binary. Possible values:

  * stamp = 1: Always stamp the build information into the binary, even in --nostamp builds. This setting should be avoided, since it potentially kills remote caching for the binary and any downstream actions that depend on it.

  * stamp = 0: Always replace build information by constant values. This gives good build result caching.

  * stamp = -1: Embedding of build information is controlled by the --[no]stamp flag.

Stamped binaries are not rebuilt unless their dependencies change.2-1
reexport_deps2[]�
data�The list of files needed by this target at runtime. See general comments about data at Typical attributes defined by most build rules.2[]8
deps*The list of dependencies of current target2[]%
srcsThe list of source files. �
hdrstList of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.2[]�
hdrs_map�Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory.2{}�
module_interfaces�The list of files that are regarded as C++20 Modules Interface.

C++ Standard has no restriction about module interface file extension
* Clang use cppm
* GCC can use any source file extension
* MSVC use ixx

The use is guarded by the flag --experimental_cpp_modules.2[]�
win_def_file�The Windows DEF file to be passed to linker.

This attribute should only be used when Windows is the target platform. It can be used to export symbols during linking a shared library.2None�
additional_compiler_inputs�Any additional files you might want to pass to the compiler command line, such as sanitizer ignorelists, for example.
Files specified here can then be used in copts with the $(location) function.2[]�
additional_linker_inputs�Any additional files that you may want to pass to the linker, for example, linker scripts.
You have to separately pass any linker flags that the linker needs in order to be aware of this file.
You can do so via the linkopts attribute.2[]�
	conlyoptsvAdd these options to the C compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.2[]�
copts�Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.
Each string in this attribute is added in the given order to COPTS before compiling the binary target. The flags take effect only for compiling this target, not its dependencies, so be careful about header files included elsewhere. All paths should be relative to the workspace, not to the current package.

If the package declares the feature no_copts_tokenization, Bourne shell tokenization applies only to strings that consist of a single "Make" variable.2[]�
cxxoptsxAdd these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.2[]�
defines�List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line to this target, as well as to every rule that depends on it. Be very careful, since this may have far-reaching effects. When in doubt, add define values to local_defines instead.2[]�
dynamic_deps�In contrast to `rules_cc`, the dynamic_deps of `rules_cc_hdrs_map` are simply translated into deps parameter,
and the providers (CcInfo vs CcSharedInfo) are used to steer the behavior further.2[]�
includes�List of include dirs to be added to the compile line.
Subject to "Make variable" substitution. Each string is prepended with -isystem and added to COPTS. Unlike COPTS, these flags are added for this rule and every rule that depends on it. (Note: not the rules it depends upon!) Be very careful, since this may have far-reaching effects. When in doubt, add "-I" flags to COPTS instead.

Headers must be added to srcs or hdrs, otherwise they will not be available to dependent rules when compilation is sandboxed (the default).2[]�
link_extra_lib�Control linking of extra libraries.

By default, C++ binaries are linked against //tools/cpp:link_extra_lib, which by default depends on the label flag //tools/cpp:link_extra_libs. Without setting the flag, this library is empty by default. Setting the label flag allows linking optional dependencies, such as overrides for weak symbols, interceptors for shared library functions, or special runtime libraries (for malloc replacements, prefer malloc or --custom_malloc). Setting this attribute to None disables this behaviour.2None�
linkopts�Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.2[]�

linksharedwCreate a shared library. To enable this attribute, include linkshared=True in your rule. By default this option is off.2False�

linkstatic�If enabled and this is a binary or test, this option tells the build tool to link in .a's instead of .so's for user libraries whenever possible. System libraries such as libc (but not the C/C++ runtime libraries, see below) are still linked dynamically, as are libraries for which there is no static library. So the resulting executable will still be dynamically linked, hence only mostly static.
The linkstatic attribute has a different meaning if used on a cc_library() rule. For a C++ library, linkstatic=True indicates that only static linking is allowed, so no .so will be produced. linkstatic=False does not prevent static libraries from being created. The attribute is meant to control the creation of dynamic libraries.2False�
local_defines�List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line for this target, but not to its dependents.2[]�
malloc�Override the default dependency on malloc.

By default, C++ binaries are linked against //tools/cpp:malloc, which is an empty library so the binary ends up using libc malloc. This label must refer to a cc_library. If compilation is for a non-C++ rule, this option has no effect. The value of this attribute is ignored if linkshared=True is specified.2None�
nocopts�Remove matching options from the C++ compilation command. Subject to "Make" variable substitution. The value of this attribute is interpreted as a regular expression. Any preexisting COPTS that match this regular expression (including values explicitly specified in the rule's copts attribute) will be removed from COPTS for purposes of compiling this rule. This attribute should not be needed or used outside of third_party. The values are not preprocessed in any way other than the "Make" variable substitution.2"""*
cc_bin //cc_hdrs_map/private:cc_bin.bzl8,
*
nameA unique name for this target. �
�
stamp�Whether to encode build information into the binary. Possible values:

  * stamp = 1: Always stamp the build information into the binary, even in --nostamp builds. This setting should be avoided, since it potentially kills remote caching for the binary and any downstream actions that depend on it.

  * stamp = 0: Always replace build information by constant values. This gives good build result caching.

  * stamp = -1: Embedding of build information is controlled by the --[no]stamp flag.

Stamped binaries are not rebuilt unless their dependencies change.2-1

reexport_deps2[]�
�
data�The list of files needed by this target at runtime. See general comments about data at Typical attributes defined by most build rules.2[]:
8
deps*The list of dependencies of current target2[]'
%
srcsThe list of source files. �
�
hdrstList of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.2[]�
�
hdrs_map�Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory.2{}�
�
module_interfaces�The list of files that are regarded as C++20 Modules Interface.

C++ Standard has no restriction about module interface file extension
* Clang use cppm
* GCC can use any source file extension
* MSVC use ixx

The use is guarded by the flag --experimental_cpp_modules.2[]�
�
win_def_file�The Windows DEF file to be passed to linker.

This attribute should only be used when Windows is the target platform. It can be used to export symbols during linking a shared library.2None�
�
additional_compiler_inputs�Any additional files you might want to pass to the compiler command line, such as sanitizer ignorelists, for example.
Files specified here can then be used in copts with the $(location) function.2[]�
�
additional_linker_inputs�Any additional files that you may want to pass to the linker, for example, linker scripts.
You have to separately pass any linker flags that the linker needs in order to be aware of this file.
You can do so via the linkopts attribute.2[]�
�
	conlyoptsvAdd these options to the C compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.2[]�
�
copts�Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.
Each string in this attribute is added in the given order to COPTS before compiling the binary target. The flags take effect only for compiling this target, not its dependencies, so be careful about header files included elsewhere. All paths should be relative to the workspace, not to the current package.

If the package declares the feature no_copts_tokenization, Bourne shell tokenization applies only to strings that consist of a single "Make" variable.2[]�
�
cxxoptsxAdd these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.2[]�
�
defines�List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line to this target, as well as to every rule that depends on it. Be very careful, since this may have far-reaching effects. When in doubt, add define values to local_defines instead.2[]�
�
dynamic_deps�In contrast to `rules_cc`, the dynamic_deps of `rules_cc_hdrs_map` are simply translated into deps parameter,
and the providers (CcInfo vs CcSharedInfo) are used to steer the behavior further.2[]�
�
includes�List of include dirs to be added to the compile line.
Subject to "Make variable" substitution. Each string is prepended with -isystem and added to COPTS. Unlike COPTS, these flags are added for this rule and every rule that depends on it. (Note: not the rules it depends upon!) Be very careful, since this may have far-reaching effects. When in doubt, add "-I" flags to COPTS instead.

Headers must be added to srcs or hdrs, otherwise they will not be available to dependent rules when compilation is sandboxed (the default).2[]�
�
link_extra_lib�Control linking of extra libraries.

By default, C++ binaries are linked against //tools/cpp:link_extra_lib, which by default depends on the label flag //tools/cpp:link_extra_libs. Without setting the flag, this library is empty by default. Setting the label flag allows linking optional dependencies, such as overrides for weak symbols, interceptors for shared library functions, or special runtime libraries (for malloc replacements, prefer malloc or --custom_malloc). Setting this attribute to None disables this behaviour.2None�
�
linkopts�Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.2[]�
�

linksharedwCreate a shared library. To enable this attribute, include linkshared=True in your rule. By default this option is off.2False�
�

linkstatic�If enabled and this is a binary or test, this option tells the build tool to link in .a's instead of .so's for user libraries whenever possible. System libraries such as libc (but not the C/C++ runtime libraries, see below) are still linked dynamically, as are libraries for which there is no static library. So the resulting executable will still be dynamically linked, hence only mostly static.
The linkstatic attribute has a different meaning if used on a cc_library() rule. For a C++ library, linkstatic=True indicates that only static linking is allowed, so no .so will be produced. linkstatic=False does not prevent static libraries from being created. The attribute is meant to control the creation of dynamic libraries.2False�
�
local_defines�List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line for this target, but not to its dependents.2[]�
�
malloc�Override the default dependency on malloc.

By default, C++ binaries are linked against //tools/cpp:malloc, which is an empty library so the binary ends up using libc malloc. This label must refer to a cc_library. If compilation is for a non-C++ rule, this option has no effect. The value of this attribute is ignored if linkshared=True is specified.2None�
�
nocopts�Remove matching options from the C++ compilation command. Subject to "Make" variable substitution. The value of this attribute is interpreted as a regular expression. Any preexisting COPTS that match this regular expression (including values explicitly specified in the rule's copts attribute) will be removed from COPTS for purposes of compiling this rule. This attribute should not be needed or used outside of third_party. The values are not preprocessed in any way other than the "Make" variable substitution.2""�cc_hdrs�Define header files properties.

This rule groups headers into a singular target and allows
to attach 'include_path' modifications information to them,
so that wherever the header files are being used, they can
be used with their intended include paths."�
�
cc_hdrs�Define header files properties.

This rule groups headers into a singular target and allows
to attach 'include_path' modifications information to them,
so that wherever the header files are being used, they can
be used with their intended include paths.*
nameA unique name for this target. �
data�The list of files needed by this target at runtime. See general comments about data at Typical attributes defined by most build rules.2[]8
deps*The list of dependencies of current target2[]�
hdrstList of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.2[]�
implementation_hdrsjList of headers that CANNOT be included by dependent rules.
Notice: the cutoff happens during compilation.2[]�
hdrs_map�Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory.2{}�
module_interfaces�The list of files that are regarded as C++20 Modules Interface.

C++ Standard has no restriction about module interface file extension
* Clang use cppm
* GCC can use any source file extension
* MSVC use ixx

The use is guarded by the flag --experimental_cpp_modules.2[]�
win_def_file�The Windows DEF file to be passed to linker.

This attribute should only be used when Windows is the target platform. It can be used to export symbols during linking a shared library.2None",
cc_hdrs!//cc_hdrs_map/private:cc_hdrs.bzl*m
DefaultInfo
HdrsMapInfo
DefaultInfo<native>8
HdrsMapInfo)//cc_hdrs_map/providers:hdrs_map_info.bzl,
*
nameA unique name for this target. �
�
data�The list of files needed by this target at runtime. See general comments about data at Typical attributes defined by most build rules.2[]:
8
deps*The list of dependencies of current target2[]�
�
hdrstList of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.2[]�
�
implementation_hdrsjList of headers that CANNOT be included by dependent rules.
Notice: the cutoff happens during compilation.2[]�
�
hdrs_map�Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory.2{}�
�
module_interfaces�The list of files that are regarded as C++20 Modules Interface.

C++ Standard has no restriction about module interface file extension
* Clang use cppm
* GCC can use any source file extension
* MSVC use ixx

The use is guarded by the flag --experimental_cpp_modules.2[]�
�
win_def_file�The Windows DEF file to be passed to linker.

This attribute should only be used when Windows is the target platform. It can be used to export symbols during linking a shared library.2None˴cc_so�Produce shared object library.

The intended difference between this rule and the rules_cc's cc_shared_library is to:
 1) remove 'cc_library' out of the equation (no more targets that produce either archive or sol)
 2) unify handling of dependencies that are equipped with CcInfo and CcSharedLibraryInfo
    (use singular attribute of deps to track them both)."ӱ
�Z
cc_so�Produce shared object library.

The intended difference between this rule and the rules_cc's cc_shared_library is to:
 1) remove 'cc_library' out of the equation (no more targets that produce either archive or sol)
 2) unify handling of dependencies that are equipped with CcInfo and CcSharedLibraryInfo
    (use singular attribute of deps to track them both).*
nameA unique name for this target. �

alwayslink�If 1, any binary that depends (directly or indirectly) on this C++ precompiled library will link in all the object files archived in the static library, even if some contain no symbols referenced by the binary. This is useful if your code isn't explicitly called by code in the binary, e.g., if your code registers to receive some callback provided by some service.2False�
exports_filter�This attribute contains a list of targets that are claimed to be exported by the current shared library.

Any target deps is already understood to be exported by the shared library. This attribute should be used to list any targets that are exported by the shared library but are transitive dependencies of deps.

Note that this attribute is not actually adding a dependency edge to those targets, the dependency edge should instead be created by deps.The entries in this attribute are just strings. Keep in mind that when placing a target in this attribute, this is considered a claim that the shared library exports the symbols from that target. The cc_shared_library logic doesn't actually handle telling the linker which symbols should be exported.

The following syntax is allowed:

//foo:__pkg__ to account for any target in foo/BUILD

//foo:__subpackages__ to account for any target in foo/BUILD or any other package below foo/ like foo/bar/BUILD2[]$
roots(Not yet implemented)2[]�
shared_lib_name�Specify the name of the created SOL file (that is decoupled from the rule instance name).
Note, that the 'cc_so' is opinionated and will remove any leading 'lib' prefix and any '.so' in the name
(meaning 'libTest.so.x64.so' will become 'Test.x64' and will produce 'libTest.x64.so')2""�
data�The list of files needed by this target at runtime. See general comments about data at Typical attributes defined by most build rules.2[]8
deps*The list of dependencies of current target2[]%
srcsThe list of source files. �
hdrstList of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.2[]�
implementation_hdrsjList of headers that CANNOT be included by dependent rules.
Notice: the cutoff happens during compilation.2[]�
hdrs_map�Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory.2{}�
module_interfaces�The list of files that are regarded as C++20 Modules Interface.

C++ Standard has no restriction about module interface file extension
* Clang use cppm
* GCC can use any source file extension
* MSVC use ixx

The use is guarded by the flag --experimental_cpp_modules.2[]�
win_def_file�The Windows DEF file to be passed to linker.

This attribute should only be used when Windows is the target platform. It can be used to export symbols during linking a shared library.2None�
additional_compiler_inputs�Any additional files you might want to pass to the compiler command line, such as sanitizer ignorelists, for example.
Files specified here can then be used in copts with the $(location) function.2[]�
additional_linker_inputs�Any additional files that you may want to pass to the linker, for example, linker scripts.
You have to separately pass any linker flags that the linker needs in order to be aware of this file.
You can do so via the linkopts attribute.2[]�
	conlyoptsvAdd these options to the C compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.2[]�
copts�Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.
Each string in this attribute is added in the given order to COPTS before compiling the binary target. The flags take effect only for compiling this target, not its dependencies, so be careful about header files included elsewhere. All paths should be relative to the workspace, not to the current package.

If the package declares the feature no_copts_tokenization, Bourne shell tokenization applies only to strings that consist of a single "Make" variable.2[]�
cxxoptsxAdd these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.2[]�
defines�List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line to this target, as well as to every rule that depends on it. Be very careful, since this may have far-reaching effects. When in doubt, add define values to local_defines instead.2[]�
dynamic_deps�In contrast to `rules_cc`, the dynamic_deps of `rules_cc_hdrs_map` are simply translated into deps parameter,
and the providers (CcInfo vs CcSharedInfo) are used to steer the behavior further.2[]�
implementation_deps�The list of other libraries that the library target depends on. Unlike with deps, the headers and include paths of these libraries (and all their transitive deps) are only used for compilation of this library, and not libraries that depend on it. Libraries specified with implementation_deps are still linked in binary targets that depend on this library.2[]�
includes�List of include dirs to be added to the compile line.
Subject to "Make variable" substitution. Each string is prepended with -isystem and added to COPTS. Unlike COPTS, these flags are added for this rule and every rule that depends on it. (Note: not the rules it depends upon!) Be very careful, since this may have far-reaching effects. When in doubt, add "-I" flags to COPTS instead.

Headers must be added to srcs or hdrs, otherwise they will not be available to dependent rules when compilation is sandboxed (the default).2[]�
link_extra_lib�Control linking of extra libraries.

By default, C++ binaries are linked against //tools/cpp:link_extra_lib, which by default depends on the label flag //tools/cpp:link_extra_libs. Without setting the flag, this library is empty by default. Setting the label flag allows linking optional dependencies, such as overrides for weak symbols, interceptors for shared library functions, or special runtime libraries (for malloc replacements, prefer malloc or --custom_malloc). Setting this attribute to None disables this behaviour.2None�
linkopts�Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.2[]�

linksharedwCreate a shared library. To enable this attribute, include linkshared=True in your rule. By default this option is off.2False�
	linkstamp�Simultaneously compiles and links the specified C++ source file into the final binary. This trickery is required to introduce timestamp information into binaries; if we compiled the source file to an object file in the usual way, the timestamp would be incorrect. A linkstamp compilation may not include any particular set of compiler flags and so should not depend on any particular header, compiler option, or other build variable. This option should only be needed in the base package.2None�

linkstatic�If enabled and this is a binary or test, this option tells the build tool to link in .a's instead of .so's for user libraries whenever possible. System libraries such as libc (but not the C/C++ runtime libraries, see below) are still linked dynamically, as are libraries for which there is no static library. So the resulting executable will still be dynamically linked, hence only mostly static.
The linkstatic attribute has a different meaning if used on a cc_library() rule. For a C++ library, linkstatic=True indicates that only static linking is allowed, so no .so will be produced. linkstatic=False does not prevent static libraries from being created. The attribute is meant to control the creation of dynamic libraries.2False�
local_defines�List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line for this target, but not to its dependents.2[]�
malloc�Override the default dependency on malloc.

By default, C++ binaries are linked against //tools/cpp:malloc, which is an empty library so the binary ends up using libc malloc. This label must refer to a cc_library. If compilation is for a non-C++ rule, this option has no effect. The value of this attribute is ignored if linkshared=True is specified.2None�
nocopts�Remove matching options from the C++ compilation command. Subject to "Make" variable substitution. The value of this attribute is interpreted as a regular expression. Any preexisting COPTS that match this regular expression (including values explicitly specified in the rule's copts attribute) will be removed from COPTS for purposes of compiling this rule. This attribute should not be needed or used outside of third_party. The values are not preprocessed in any way other than the "Make" variable substitution.2""�
include_prefix�The prefix to add to the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at is the value of this attribute prepended to their repository-relative path.

The prefix in the strip_include_prefix attribute is removed before this prefix is added.2""�
strip_include_prefix�The prefix to strip from the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at their path with this prefix cut off.

If it's a relative path, it's taken as a package-relative one. If it's an absolute one, it's understood as a repository-relative path.

The prefix in the include_prefix attribute is added after this prefix is stripped.2""�
textual_hdrs�The list of header files published by this library to be textually included by sources in dependent rules.

This is the location for declaring header files that cannot be compiled on their own; that is, they always need to be textually included by other source files to build valid code.2[]"(
cc_so//cc_hdrs_map/private:cc_so.bzl*�
DefaultInfo
CcSharedLibraryInfo
HdrsMapInfo
DefaultInfo<native>D
CcSharedLibraryInfo-@@_builtins//:common/cc/cc_shared_library.bzl8
HdrsMapInfo)//cc_hdrs_map/providers:hdrs_map_info.bzl,
*
nameA unique name for this target. �
�

alwayslink�If 1, any binary that depends (directly or indirectly) on this C++ precompiled library will link in all the object files archived in the static library, even if some contain no symbols referenced by the binary. This is useful if your code isn't explicitly called by code in the binary, e.g., if your code registers to receive some callback provided by some service.2False�
�
exports_filter�This attribute contains a list of targets that are claimed to be exported by the current shared library.

Any target deps is already understood to be exported by the shared library. This attribute should be used to list any targets that are exported by the shared library but are transitive dependencies of deps.

Note that this attribute is not actually adding a dependency edge to those targets, the dependency edge should instead be created by deps.The entries in this attribute are just strings. Keep in mind that when placing a target in this attribute, this is considered a claim that the shared library exports the symbols from that target. The cc_shared_library logic doesn't actually handle telling the linker which symbols should be exported.

The following syntax is allowed:

//foo:__pkg__ to account for any target in foo/BUILD

//foo:__subpackages__ to account for any target in foo/BUILD or any other package below foo/ like foo/bar/BUILD2[]&
$
roots(Not yet implemented)2[]�
�
shared_lib_name�Specify the name of the created SOL file (that is decoupled from the rule instance name).
Note, that the 'cc_so' is opinionated and will remove any leading 'lib' prefix and any '.so' in the name
(meaning 'libTest.so.x64.so' will become 'Test.x64' and will produce 'libTest.x64.so')2""�
�
data�The list of files needed by this target at runtime. See general comments about data at Typical attributes defined by most build rules.2[]:
8
deps*The list of dependencies of current target2[]'
%
srcsThe list of source files. �
�
hdrstList of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.2[]�
�
implementation_hdrsjList of headers that CANNOT be included by dependent rules.
Notice: the cutoff happens during compilation.2[]�
�
hdrs_map�Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory.2{}�
�
module_interfaces�The list of files that are regarded as C++20 Modules Interface.

C++ Standard has no restriction about module interface file extension
* Clang use cppm
* GCC can use any source file extension
* MSVC use ixx

The use is guarded by the flag --experimental_cpp_modules.2[]�
�
win_def_file�The Windows DEF file to be passed to linker.

This attribute should only be used when Windows is the target platform. It can be used to export symbols during linking a shared library.2None�
�
additional_compiler_inputs�Any additional files you might want to pass to the compiler command line, such as sanitizer ignorelists, for example.
Files specified here can then be used in copts with the $(location) function.2[]�
�
additional_linker_inputs�Any additional files that you may want to pass to the linker, for example, linker scripts.
You have to separately pass any linker flags that the linker needs in order to be aware of this file.
You can do so via the linkopts attribute.2[]�
�
	conlyoptsvAdd these options to the C compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.2[]�
�
copts�Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.
Each string in this attribute is added in the given order to COPTS before compiling the binary target. The flags take effect only for compiling this target, not its dependencies, so be careful about header files included elsewhere. All paths should be relative to the workspace, not to the current package.

If the package declares the feature no_copts_tokenization, Bourne shell tokenization applies only to strings that consist of a single "Make" variable.2[]�
�
cxxoptsxAdd these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.2[]�
�
defines�List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line to this target, as well as to every rule that depends on it. Be very careful, since this may have far-reaching effects. When in doubt, add define values to local_defines instead.2[]�
�
dynamic_deps�In contrast to `rules_cc`, the dynamic_deps of `rules_cc_hdrs_map` are simply translated into deps parameter,
and the providers (CcInfo vs CcSharedInfo) are used to steer the behavior further.2[]�
�
implementation_deps�The list of other libraries that the library target depends on. Unlike with deps, the headers and include paths of these libraries (and all their transitive deps) are only used for compilation of this library, and not libraries that depend on it. Libraries specified with implementation_deps are still linked in binary targets that depend on this library.2[]�
�
includes�List of include dirs to be added to the compile line.
Subject to "Make variable" substitution. Each string is prepended with -isystem and added to COPTS. Unlike COPTS, these flags are added for this rule and every rule that depends on it. (Note: not the rules it depends upon!) Be very careful, since this may have far-reaching effects. When in doubt, add "-I" flags to COPTS instead.

Headers must be added to srcs or hdrs, otherwise they will not be available to dependent rules when compilation is sandboxed (the default).2[]�
�
link_extra_lib�Control linking of extra libraries.

By default, C++ binaries are linked against //tools/cpp:link_extra_lib, which by default depends on the label flag //tools/cpp:link_extra_libs. Without setting the flag, this library is empty by default. Setting the label flag allows linking optional dependencies, such as overrides for weak symbols, interceptors for shared library functions, or special runtime libraries (for malloc replacements, prefer malloc or --custom_malloc). Setting this attribute to None disables this behaviour.2None�
�
linkopts�Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.2[]�
�

linksharedwCreate a shared library. To enable this attribute, include linkshared=True in your rule. By default this option is off.2False�
�
	linkstamp�Simultaneously compiles and links the specified C++ source file into the final binary. This trickery is required to introduce timestamp information into binaries; if we compiled the source file to an object file in the usual way, the timestamp would be incorrect. A linkstamp compilation may not include any particular set of compiler flags and so should not depend on any particular header, compiler option, or other build variable. This option should only be needed in the base package.2None�
�

linkstatic�If enabled and this is a binary or test, this option tells the build tool to link in .a's instead of .so's for user libraries whenever possible. System libraries such as libc (but not the C/C++ runtime libraries, see below) are still linked dynamically, as are libraries for which there is no static library. So the resulting executable will still be dynamically linked, hence only mostly static.
The linkstatic attribute has a different meaning if used on a cc_library() rule. For a C++ library, linkstatic=True indicates that only static linking is allowed, so no .so will be produced. linkstatic=False does not prevent static libraries from being created. The attribute is meant to control the creation of dynamic libraries.2False�
�
local_defines�List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line for this target, but not to its dependents.2[]�
�
malloc�Override the default dependency on malloc.

By default, C++ binaries are linked against //tools/cpp:malloc, which is an empty library so the binary ends up using libc malloc. This label must refer to a cc_library. If compilation is for a non-C++ rule, this option has no effect. The value of this attribute is ignored if linkshared=True is specified.2None�
�
nocopts�Remove matching options from the C++ compilation command. Subject to "Make" variable substitution. The value of this attribute is interpreted as a regular expression. Any preexisting COPTS that match this regular expression (including values explicitly specified in the rule's copts attribute) will be removed from COPTS for purposes of compiling this rule. This attribute should not be needed or used outside of third_party. The values are not preprocessed in any way other than the "Make" variable substitution.2""�
�
include_prefix�The prefix to add to the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at is the value of this attribute prepended to their repository-relative path.

The prefix in the strip_include_prefix attribute is removed before this prefix is added.2""�
�
strip_include_prefix�The prefix to strip from the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at their path with this prefix cut off.

If it's a relative path, it's taken as a package-relative one. If it's an absolute one, it's understood as a repository-relative path.

The prefix in the include_prefix attribute is added after this prefix is stripped.2""�
�
textual_hdrs�The list of header files published by this library to be textually included by sources in dependent rules.

This is the location for declaring header files that cannot be compiled on their own; that is, they always need to be textually included by other source files to build valid code.2[]�8cc_so_import�Import precompiled C/C++ shared object library.

The intended difference between this rule and the rules_cc's cc_import is to directly
provide CcSharedLibrary info to force linking and early deps cutoff."�7
�
cc_so_import�Import precompiled C/C++ shared object library.

The intended difference between this rule and the rules_cc's cc_import is to directly
provide CcSharedLibrary info to force linking and early deps cutoff.*
nameA unique name for this target. �
shared_librarytA single precompiled shared library. This ruleset will ensure it will be available to depending cc_hdrs_map targets. t
cascade`Please DO NOT USE. This makes the SOL being propagated upwards to every dependee of this target.2False�
data�The list of files needed by this target at runtime. See general comments about data at Typical attributes defined by most build rules.2[]8
deps*The list of dependencies of current target2[]�
hdrstList of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.2[]�
hdrs_map�Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory.2{}�
additional_linker_inputs�Any additional files that you may want to pass to the linker, for example, linker scripts.
You have to separately pass any linker flags that the linker needs in order to be aware of this file.
You can do so via the linkopts attribute.2[]�
dynamic_deps�In contrast to `rules_cc`, the dynamic_deps of `rules_cc_hdrs_map` are simply translated into deps parameter,
and the providers (CcInfo vs CcSharedInfo) are used to steer the behavior further.2[]�
implementation_deps�The list of other libraries that the library target depends on. Unlike with deps, the headers and include paths of these libraries (and all their transitive deps) are only used for compilation of this library, and not libraries that depend on it. Libraries specified with implementation_deps are still linked in binary targets that depend on this library.2[]�
linkopts�Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.2[]�
include_prefix�The prefix to add to the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at is the value of this attribute prepended to their repository-relative path.

The prefix in the strip_include_prefix attribute is removed before this prefix is added.2""�
strip_include_prefix�The prefix to strip from the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at their path with this prefix cut off.

If it's a relative path, it's taken as a package-relative one. If it's an absolute one, it's understood as a repository-relative path.

The prefix in the include_prefix attribute is added after this prefix is stripped.2"""6
cc_so_import&//cc_hdrs_map/private:cc_so_import.bzl*�
DefaultInfo
CcSharedLibraryInfo
HdrsMapInfo
DefaultInfo<native>D
CcSharedLibraryInfo-@@_builtins//:common/cc/cc_shared_library.bzl8
HdrsMapInfo)//cc_hdrs_map/providers:hdrs_map_info.bzl,
*
nameA unique name for this target. �
�
shared_librarytA single precompiled shared library. This ruleset will ensure it will be available to depending cc_hdrs_map targets. v
t
cascade`Please DO NOT USE. This makes the SOL being propagated upwards to every dependee of this target.2False�
�
data�The list of files needed by this target at runtime. See general comments about data at Typical attributes defined by most build rules.2[]:
8
deps*The list of dependencies of current target2[]�
�
hdrstList of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.2[]�
�
hdrs_map�Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory.2{}�
�
additional_linker_inputs�Any additional files that you may want to pass to the linker, for example, linker scripts.
You have to separately pass any linker flags that the linker needs in order to be aware of this file.
You can do so via the linkopts attribute.2[]�
�
dynamic_deps�In contrast to `rules_cc`, the dynamic_deps of `rules_cc_hdrs_map` are simply translated into deps parameter,
and the providers (CcInfo vs CcSharedInfo) are used to steer the behavior further.2[]�
�
implementation_deps�The list of other libraries that the library target depends on. Unlike with deps, the headers and include paths of these libraries (and all their transitive deps) are only used for compilation of this library, and not libraries that depend on it. Libraries specified with implementation_deps are still linked in binary targets that depend on this library.2[]�
�
linkopts�Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.2[]�
�
include_prefix�The prefix to add to the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at is the value of this attribute prepended to their repository-relative path.

The prefix in the strip_include_prefix attribute is removed before this prefix is added.2""�
�
strip_include_prefix�The prefix to strip from the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at their path with this prefix cut off.

If it's a relative path, it's taken as a package-relative one. If it's an absolute one, it's understood as a repository-relative path.

The prefix in the include_prefix attribute is added after this prefix is stripped.2""�)providers_helper.materialize_hdrs_mapping�Materialize the expected file hierarchy.

Creates the header file hierarchy accordingly to specifications
in passed-in hdrs_map under 'vhm' directory.
*�
�
)providers_helper.materialize_hdrs_mapping6
invoker_label!label of rule invoking the method ( 
actionsbazel ctx.actions (<
hdrs_map,HdrsMapInfo representing the headers mapping (K
hdrs?list of all header files that should be matched against the map (�Materialize the expected file hierarchy.

Creates the header file hierarchy accordingly to specifications
in passed-in hdrs_map under 'vhm' directory.
"�
�(materialized_include_path, materialized_hdrs_files): tuple of include_path to
the created header files dir and list of paths to all header files created.2@
materialize_hdrs_mapping$//cc_hdrs_map/providers:hdrs_map.bzl8
6
invoker_label!label of rule invoking the method ("
 
actionsbazel ctx.actions (>
<
hdrs_map,HdrsMapInfo representing the headers mapping (M
K
hdrs?list of all header files that should be matched against the map (�
.providers_helper.merge_cc_shared_library_infos?Merge CcSharedLibraryInfos from targets into singualr provider.*�	
�
.providers_helper.merge_cc_shared_library_infos~
targetsmlist of Bazel targets that should be merged. They must
contain either CcInfo or CcSharedLibraryInfo provider.[](Q
dynamic_deps9sequence of Depsets representing additional dynamic deps.None(I
exports6cc_libraries that are linked statically and exported".None(S
linker_input;the resultign linker inptu artifact for the shared library.None(s
link_once_static_libsRall libraries linked statically into this library that should
only be linked once.None(?Merge CcSharedLibraryInfos from targets into singualr provider."
CcSharedLibraryInfo provider.2S
merge_cc_shared_library_infos2//cc_hdrs_map/providers:cc_shared_library_info.bzl�
~
targetsmlist of Bazel targets that should be merged. They must
contain either CcInfo or CcSharedLibraryInfo provider.[](S
Q
dynamic_deps9sequence of Depsets representing additional dynamic deps.None(K
I
exports6cc_libraries that are linked statically and exported".None(U
S
linker_input;the resultign linker inptu artifact for the shared library.None(u
s
link_once_static_libsRall libraries linked statically into this library that should
only be linked once.None(�%providers_helper.merge_hdrs_map_infos?Merge all HdrsMapInfo providers from targets into singular one.*�
�
%providers_helper.merge_hdrs_map_infos
targets[](3
hdrs#additional header files to include,None(L
implementation_hdrs-additional implementation headers to include,None(F
hdrs_map2initial hdrs_map to use as a foundation for merge,None(<
hdrs_map_deps#additional dependencies to include,None(g
pin_down_non_globsIwheather the final hdrs_map should have its
non_glob dependencies pinned.True(?Merge all HdrsMapInfo providers from targets into singular one."N
LHdrsMapInfo provider that represents merge of all HdrsMapInfos from targets.2A
merge_hdrs_map_infos)//cc_hdrs_map/providers:hdrs_map_info.bzl

targets[](5
3
hdrs#additional header files to include,None(N
L
implementation_hdrs-additional implementation headers to include,None(H
F
hdrs_map2initial hdrs_map to use as a foundation for merge,None(>
<
hdrs_map_deps#additional dependencies to include,None(i
g
pin_down_non_globsIwheather the final hdrs_map should have its
non_glob dependencies pinned.True(�providers_helper.new_hdrs_map&Create new instance of HdrsMap struct.*�
�
providers_helper.new_hdrs_map
	from_dict{}(
_globNone(
	_non_globNone(&Create new instance of HdrsMap struct.24
new_hdrs_map$//cc_hdrs_map/providers:hdrs_map.bzl

	from_dict{}(

_globNone(

	_non_globNone(�5providers_helper.quotient_map_cc_shared_library_infos�Transform list of Bazel targets into CcSharedLibrayInfo attribue groups.

For given list of Bazel targets, attributes relating to CcSharedLibraryInfo
(dynamic_deps, exports, linker_inputs, link_once_static_libs) will be extracted
from said targets and the output will contain groups of that values.
*�
�
5providers_helper.quotient_map_cc_shared_library_infos~
targetsmlist of Bazel targets that should be mapped. They must
contain either CcInfo or CcSharedLibraryInfo provider.[](Q
dynamic_deps9sequence of Depsets representing additional dynamic deps.None(I
exports6cc_libraries that are linked statically and exported".None(S
linker_input;the resultign linker inptu artifact for the shared library.None(s
link_once_static_libsRall libraries linked statically into this library that should
only be linked once.None(�Transform list of Bazel targets into CcSharedLibrayInfo attribue groups.

For given list of Bazel targets, attributes relating to CcSharedLibraryInfo
(dynamic_deps, exports, linker_inputs, link_once_static_libs) will be extracted
from said targets and the output will contain groups of that values.
"?
=(dynamic_deps, exports, linker_inptuts, link_once_static_lib)2Z
$quotient_map_cc_shared_library_infos2//cc_hdrs_map/providers:cc_shared_library_info.bzl�
~
targetsmlist of Bazel targets that should be mapped. They must
contain either CcInfo or CcSharedLibraryInfo provider.[](S
Q
dynamic_deps9sequence of Depsets representing additional dynamic deps.None(K
I
exports6cc_libraries that are linked statically and exported".None(U
S
linker_input;the resultign linker inptu artifact for the shared library.None(u
s
link_once_static_libsRall libraries linked statically into this library that should
only be linked once.None(�,providers_helper.quotient_map_hdrs_map_infos7Take all HdrsMapInfo key-values and group them by keys.*�
�
,providers_helper.quotient_map_hdrs_map_infos
targets[](3
hdrs#additional header files to include,None(L
implementation_hdrs-additional implementation headers to include,None(F
hdrs_map2initial hdrs_map to use as a foundation for merge,None(;
hdrs_map_deps"additional dependencies to includeNone(D
traverse_deps+wheather to gather HdrsMapInfos transitvelyTrue(7Take all HdrsMapInfo key-values and group them by keys."=
;(hdrs, implementation_hdrs, hdrs_map, hdr_maps_deps): tuple2H
quotient_map_hdrs_map_infos)//cc_hdrs_map/providers:hdrs_map_info.bzl

targets[](5
3
hdrs#additional header files to include,None(N
L
implementation_hdrs-additional implementation headers to include,None(H
F
hdrs_map2initial hdrs_map to use as a foundation for merge,None(=
;
hdrs_map_deps"additional dependencies to includeNone(F
D
traverse_deps+wheather to gather HdrsMapInfos transitvelyTrue(�actions.compile_kwargs*z
W
actions.compile_kwargs	
ctx (

rule_attrs (2 //cc_hdrs_map/actions:defs.bzl
	
ctx (


rule_attrs (�actions.link_to_archive_kwargs*�
_
actions.link_to_archive_kwargs	
ctx (

rule_attrs (2 //cc_hdrs_map/actions:defs.bzl
	
ctx (


rule_attrs (�actions.link_to_binary_kwargs*�
^
actions.link_to_binary_kwargs	
ctx (

rule_attrs (2 //cc_hdrs_map/actions:defs.bzl
	
ctx (


rule_attrs (�actions.link_to_so_kwargs*}
Z
actions.link_to_so_kwargs	
ctx (

rule_attrs (2 //cc_hdrs_map/actions:defs.bzl
	
ctx (


rule_attrs (�
actions.prepare_for_compilation�Materialize information from hdrs map.

This function creates a epheremal directory, that contains all of the
patterns specified within hdrs_map providers, thus making them all
available under singular, temporary include statment.
*�
�
actions.prepare_for_compilation
sctxsubrule context (i
input_hdrs_mapSlist of HdrsMapInfo which should be used for materialization of compilation context (7

input_hdrs%direct headers provided to the action (F
input_implementation_hdrs%direct headers provided to the action (7

input_deps%dependencies specified for the action (A
input_includes+include statements specified for the action (�Materialize information from hdrs map.

This function creates a epheremal directory, that contains all of the
patterns specified within hdrs_map providers, thus making them all
available under singular, temporary include statment.
2?
_prepare_for_compilation#//cc_hdrs_map/actions:cc_helper.bzl

sctxsubrule context (k
i
input_hdrs_mapSlist of HdrsMapInfo which should be used for materialization of compilation context (9
7

input_hdrs%direct headers provided to the action (H
F
input_implementation_hdrs%direct headers provided to the action (9
7

input_deps%dependencies specified for the action (C
A
input_includes+include statements specified for the action (�(cc_helper.expand_make_variables_in_copts*�
�
(cc_helper.expand_make_variables_in_copts	
ctx (
cc_info (
action_kwargs (

opts (2F
_expand_make_variables_in_copts#//cc_hdrs_map/actions:cc_helper.bzl
	
ctx (

cc_info (

action_kwargs (


opts (�*cc_helper.expand_make_variables_in_defines*�
�
*cc_helper.expand_make_variables_in_defines	
ctx (
cc_info (
action_kwargs (
defines (
localFalse(2H
!_expand_make_variables_in_defines#//cc_hdrs_map/actions:cc_helper.bzl
	
ctx (

cc_info (

action_kwargs (

defines (

localFalse(�+cc_helper.expand_make_variables_in_linkopts*�
�
+cc_helper.expand_make_variables_in_linkopts	
ctx (
cc_info (
action_kwargs (

opts (2I
"_expand_make_variables_in_linkopts#//cc_hdrs_map/actions:cc_helper.bzl
	
ctx (

cc_info (

action_kwargs (


opts (mcc_helper.extensions.cc_header*I
G
cc_helper.extensions.cc_header2%#//cc_hdrs_map/actions:cc_helper.bzlmcc_helper.extensions.cc_source*I
G
cc_helper.extensions.cc_source2%#//cc_hdrs_map/actions:cc_helper.bzl�cc_helper.extract_headers*r
a
cc_helper.extract_headers
files (27
_extract_headers#//cc_hdrs_map/actions:cc_helper.bzl

files (�cc_helper.extract_sources*r
a
cc_helper.extract_sources
files (27
_extract_sources#//cc_hdrs_map/actions:cc_helper.bzl

files (�$cc_helper.get_cc_flags_make_variable*�
�
$cc_helper.get_cc_flags_make_variable
cc_toolchain (
feature_configuration (2B
_get_cc_flags_make_variable#//cc_hdrs_map/actions:cc_helper.bzl

cc_toolchain (

feature_configuration (�!cc_helper.get_compilation_defines*�
�
!cc_helper.get_compilation_defines	
ctx (
defines[](
deps[](.
&additional_make_variable_substitutions{}(
additional_targets[](2?
_get_compilation_defines#//cc_hdrs_map/actions:cc_helper.bzl
	
ctx (

defines[](

deps[](0
.
&additional_make_variable_substitutions{}(

additional_targets[](�cc_helper.get_compilation_opts*�
�
cc_helper.get_compilation_opts	
ctx (

opts (
feature_configuration (.
&additional_make_variable_substitutions{}(
additional_inputs[](2<
_get_compilation_opts#//cc_hdrs_map/actions:cc_helper.bzl
	
ctx (


opts (

feature_configuration (0
.
&additional_make_variable_substitutions{}(

additional_inputs[](�cc_helper.get_linking_opts*�
�
cc_helper.get_linking_opts	
ctx (

opts (.
&additional_make_variable_substitutions{}(
additional_inputs[](28
_get_linking_opts#//cc_hdrs_map/actions:cc_helper.bzl
	
ctx (


opts (0
.
&additional_make_variable_substitutions{}(

additional_inputs[](�/cc_helper.get_local_defines_for_runfiles_lookup*�
�
/cc_helper.get_local_defines_for_runfiles_lookup	
ctx (
all_deps (2M
&_get_local_defines_for_runfiles_lookup#//cc_hdrs_map/actions:cc_helper.bzl
	
ctx (

all_deps (�-cc_helper.get_toolchain_global_make_variables*�
�
-cc_helper.get_toolchain_global_make_variables
cc_toolchain (2K
$_get_toolchain_global_make_variables#//cc_hdrs_map/actions:cc_helper.bzl

cc_toolchain (�
!cc_helper.prepare_for_compilation�Materialize information from hdrs map.

This function creates a epheremal directory, that contains all of the
patterns specified within hdrs_map providers, thus making them all
available under singular, temporary include statment.
*�
�
!cc_helper.prepare_for_compilation
sctxsubrule context (i
input_hdrs_mapSlist of HdrsMapInfo which should be used for materialization of compilation context (7

input_hdrs%direct headers provided to the action (F
input_implementation_hdrs%direct headers provided to the action (7

input_deps%dependencies specified for the action (A
input_includes+include statements specified for the action (�Materialize information from hdrs map.

This function creates a epheremal directory, that contains all of the
patterns specified within hdrs_map providers, thus making them all
available under singular, temporary include statment.
2?
_prepare_for_compilation#//cc_hdrs_map/actions:cc_helper.bzl

sctxsubrule context (k
i
input_hdrs_mapSlist of HdrsMapInfo which should be used for materialization of compilation context (9
7

input_hdrs%direct headers provided to the action (H
F
input_implementation_hdrs%direct headers provided to the action (9
7

input_deps%dependencies specified for the action (C
A
input_includes+include statements specified for the action (�CascadingCcSharedLibraryInfoXRepresents CcSharedLibrary that should cascade and be link in every transitive dependee.2�
�
CascadingCcSharedLibraryInfoXRepresents CcSharedLibrary that should cascade and be link in every transitive dependee.h
cc_shared_library_infosM[] of CcSharedLibraryInfo providers that describes what needs to be cascaded."\
CascadingCcSharedLibraryInfo<//cc_hdrs_map/providers:cascading_cc_shared_library_info.bzlj
h
cc_shared_library_infosM[] of CcSharedLibraryInfo providers that describes what needs to be cascaded.�HdrsMapInfoTRepresents grouping of CC header files, alongsdie with their intended include paths.2�
�
HdrsMapInfoTRepresents grouping of CC header files, alongsdie with their intended include paths.F
hdrs>Headers which should be exposed after the compilation is done.S
implementation_hdrs<Headers that should not be propagated after the compilation.L
hdrs_map@(hdrs_map struct) object describing desired header file mappingsw
depsoCcInfo/CcSharedLibraryInfo-aware dependencies that need to be propagated, for this provider to compile and link"8
HdrsMapInfo)//cc_hdrs_map/providers:hdrs_map_info.bzlH
F
hdrs>Headers which should be exposed after the compilation is done.U
S
implementation_hdrs<Headers that should not be propagated after the compilation.N
L
hdrs_map@(hdrs_map struct) object describing desired header file mappingsy
w
depsoCcInfo/CcSharedLibraryInfo-aware dependencies that need to be propagated, for this provider to compile and link�rules_cc_hdrs_map
---
[![ci](https://github.com/AleksanderGondek/rules_cc_hdrs_map/actions/workflows/ci.yaml/badge.svg)](https://github.com/AleksanderGondek/rules_cc_hdrs_map/actions/workflows/ci.yaml)

This project extends Bazel `CC` build capabilities with headers map implementation (allowing for easy support for most bizzare include path schemes).

In addition, it exposes CC compilation and linking functions in form of Bazel [subrules](https://docs.google.com/document/d/1RbNC88QieKvBEwir7iV5zZU08AaMlOzxhVkPnmKDedQ).

See [examples](/examples) for how to use `rules_cc_hdrs_map` (and why).

## Shortest possible example

```
$ cat foo.hpp
const std::string GREETINGS = "Hello";

$ cat foo.cpp
#include "bar/foo.h"
...

$ cat BUILD.bazel
load("@rules_cc_hdrs_map//cc_hdrs_map:defs.bzl", "cc_bin")

cc_bin(
    name = "foo",
    srcs = [
        "foo.cpp",
        "foo.hpp",
    ],
    hdrs_map = {
        "**/foo.hpp": ["bar/{filename}"],
    }
)

```

## Table of contents
1. [What issue is being addressed?](#what-issue-is-being-addressed)
2. [How the issue is being addressed?](#what-issue-is-being-addressed)
3. [What issue is being addressed?](#how-the-issue-is-being-addressed)
4. Rules
    1. [cc_archive](#cc_archive)
    2. [cc_bin](#cc_bin)
    3. [cc_hdrs](#cc_hdrs)
    4. [cc_so](#cc_so)
5. [HdrsMapInfo provider](#hdrsmapinfo)

## What issue is being addressed?

Creation of arbitrary include paths from existing sources.

_Scenario_: we want to build a C/CPP codebase with Bazel.

One of its key characteristics is that most of the include statements do not reflect the code structure in the project - for example, header file located under path “name/a.hpp” is never included as “name/a.hpp”, instead an arbitrary list of aliases is used in the code (“x/y/z/a.hpp”, “b.hpp” etc.).  There is no overarching convention that could be used to generalize those statements into another file file hierarchy - in other words, every header file is a special case of its own.

Unfortunately we are forbidden from modifying the code itself and the directory structure (hello from enterprise word).

As Bazel `rules_cc` have the expectation of header files being included in a way that resembles the file structure in the WORKSPACE (and one can only provide single “include prefix” per library), we need to prepare the “expected file structure” before passing them into the `rules_cc`.

In the most naive approach, said “expected file structure” is being prepared for each compilable target (copying over files), passing on the already created structure to targets that depend on it. Very quickly conflicts occur and change of a single header file may cascade into rebuilding hundreds of targets.

There has to be a better way!

## How the issue is being addressed?

The concept of header map is introduced - it is a dictionary, containing mapping between simple glob paths and their desired include paths. For example: “**/a.hpp”: “x/y/z/a.hpp” expresses the intent to import any header file with name “a.hpp”, present during compilation , as “x/y/z/a.hpp”.

Said header map is propagated across all compatible C/C++ rules (meaning those from this WORKSPACE) and is being merged with all other header maps present.

No action is being performed up until the moment of compilation - header mappings, resulting from the header map dictionary, are created only for the purposes of compilation and are _NOT_ part of any rule output. This ensures the impact for the Bazel cache is minimal and the compatibility with original `rules_cc`.�
=cc_hdrs_map/providers$cascading_cc_shared_library_info.bzl�CascadingCcSharedLibraryInfoXRepresents CcSharedLibrary that should cascade and be link in every transitive dependee.2�
�
CascadingCcSharedLibraryInfoXRepresents CcSharedLibrary that should cascade and be link in every transitive dependee.h
cc_shared_library_infosM[] of CcSharedLibraryInfo providers that describes what needs to be cascaded."\
CascadingCcSharedLibraryInfo<//cc_hdrs_map/providers:cascading_cc_shared_library_info.bzlj
h
cc_shared_library_infosM[] of CcSharedLibraryInfo providers that describes what needs to be cascaded.WThis module contains function that help with dealing with CcSharedLibraryInfo provider.�
3cc_hdrs_map/providerscc_shared_library_info.bzl�$quotient_map_cc_shared_library_infos�Transform list of Bazel targets into CcSharedLibrayInfo attribue groups.

For given list of Bazel targets, attributes relating to CcSharedLibraryInfo
(dynamic_deps, exports, linker_inputs, link_once_static_libs) will be extracted
from said targets and the output will contain groups of that values.
*�
�
$quotient_map_cc_shared_library_infos~
targetsmlist of Bazel targets that should be mapped. They must
contain either CcInfo or CcSharedLibraryInfo provider.[](Q
dynamic_deps9sequence of Depsets representing additional dynamic deps.None(I
exports6cc_libraries that are linked statically and exported".None(S
linker_input;the resultign linker inptu artifact for the shared library.None(s
link_once_static_libsRall libraries linked statically into this library that should
only be linked once.None(�Transform list of Bazel targets into CcSharedLibrayInfo attribue groups.

For given list of Bazel targets, attributes relating to CcSharedLibraryInfo
(dynamic_deps, exports, linker_inputs, link_once_static_libs) will be extracted
from said targets and the output will contain groups of that values.
"?
=(dynamic_deps, exports, linker_inptuts, link_once_static_lib)2Z
$quotient_map_cc_shared_library_infos2//cc_hdrs_map/providers:cc_shared_library_info.bzl�
~
targetsmlist of Bazel targets that should be mapped. They must
contain either CcInfo or CcSharedLibraryInfo provider.[](S
Q
dynamic_deps9sequence of Depsets representing additional dynamic deps.None(K
I
exports6cc_libraries that are linked statically and exported".None(U
S
linker_input;the resultign linker inptu artifact for the shared library.None(u
s
link_once_static_libsRall libraries linked statically into this library that should
only be linked once.None(�
merge_cc_shared_library_infos?Merge CcSharedLibraryInfos from targets into singualr provider.*�	
�
merge_cc_shared_library_infos~
targetsmlist of Bazel targets that should be merged. They must
contain either CcInfo or CcSharedLibraryInfo provider.[](Q
dynamic_deps9sequence of Depsets representing additional dynamic deps.None(I
exports6cc_libraries that are linked statically and exported".None(S
linker_input;the resultign linker inptu artifact for the shared library.None(s
link_once_static_libsRall libraries linked statically into this library that should
only be linked once.None(?Merge CcSharedLibraryInfos from targets into singualr provider."
CcSharedLibraryInfo provider.2S
merge_cc_shared_library_infos2//cc_hdrs_map/providers:cc_shared_library_info.bzl�
~
targetsmlist of Bazel targets that should be merged. They must
contain either CcInfo or CcSharedLibraryInfo provider.[](S
Q
dynamic_deps9sequence of Depsets representing additional dynamic deps.None(K
I
exports6cc_libraries that are linked statically and exported".None(U
S
linker_input;the resultign linker inptu artifact for the shared library.None(u
s
link_once_static_libsRall libraries linked statically into this library that should
only be linked once.None(WThis module contains function that help with dealing with CcSharedLibraryInfo provider.�
%cc_hdrs_map/providershdrs_map.bzl�new_hdrs_map&Create new instance of HdrsMap struct.*�
�
new_hdrs_map
	from_dict{}(
_globNone(
	_non_globNone(&Create new instance of HdrsMap struct.24
new_hdrs_map$//cc_hdrs_map/providers:hdrs_map.bzl

	from_dict{}(

_globNone(

	_non_globNone(�materialize_hdrs_mapping�Materialize the expected file hierarchy.

Creates the header file hierarchy accordingly to specifications
in passed-in hdrs_map under 'vhm' directory.
*�
�
materialize_hdrs_mapping6
invoker_label!label of rule invoking the method ( 
actionsbazel ctx.actions (<
hdrs_map,HdrsMapInfo representing the headers mapping (K
hdrs?list of all header files that should be matched against the map (�Materialize the expected file hierarchy.

Creates the header file hierarchy accordingly to specifications
in passed-in hdrs_map under 'vhm' directory.
"�
�(materialized_include_path, materialized_hdrs_files): tuple of include_path to
the created header files dir and list of paths to all header files created.2@
materialize_hdrs_mapping$//cc_hdrs_map/providers:hdrs_map.bzl8
6
invoker_label!label of rule invoking the method ("
 
actionsbazel ctx.actions (>
<
hdrs_map,HdrsMapInfo representing the headers mapping (M
K
hdrs?list of all header files that should be matched against the map (=Module describing HdrsMap struct and common operations on it.�
*cc_hdrs_map/providershdrs_map_info.bzl�quotient_map_hdrs_map_infos7Take all HdrsMapInfo key-values and group them by keys.*�
�
quotient_map_hdrs_map_infos
targets[](3
hdrs#additional header files to include,None(L
implementation_hdrs-additional implementation headers to include,None(F
hdrs_map2initial hdrs_map to use as a foundation for merge,None(;
hdrs_map_deps"additional dependencies to includeNone(D
traverse_deps+wheather to gather HdrsMapInfos transitvelyTrue(7Take all HdrsMapInfo key-values and group them by keys."=
;(hdrs, implementation_hdrs, hdrs_map, hdr_maps_deps): tuple2H
quotient_map_hdrs_map_infos)//cc_hdrs_map/providers:hdrs_map_info.bzl

targets[](5
3
hdrs#additional header files to include,None(N
L
implementation_hdrs-additional implementation headers to include,None(H
F
hdrs_map2initial hdrs_map to use as a foundation for merge,None(=
;
hdrs_map_deps"additional dependencies to includeNone(F
D
traverse_deps+wheather to gather HdrsMapInfos transitvelyTrue(�merge_hdrs_map_infos?Merge all HdrsMapInfo providers from targets into singular one.*�
�
merge_hdrs_map_infos
targets[](3
hdrs#additional header files to include,None(L
implementation_hdrs-additional implementation headers to include,None(F
hdrs_map2initial hdrs_map to use as a foundation for merge,None(<
hdrs_map_deps#additional dependencies to include,None(g
pin_down_non_globsIwheather the final hdrs_map should have its
non_glob dependencies pinned.True(?Merge all HdrsMapInfo providers from targets into singular one."N
LHdrsMapInfo provider that represents merge of all HdrsMapInfos from targets.2A
merge_hdrs_map_infos)//cc_hdrs_map/providers:hdrs_map_info.bzl

targets[](5
3
hdrs#additional header files to include,None(N
L
implementation_hdrs-additional implementation headers to include,None(H
F
hdrs_map2initial hdrs_map to use as a foundation for merge,None(>
<
hdrs_map_deps#additional dependencies to include,None(i
g
pin_down_non_globsIwheather the final hdrs_map should have its
non_glob dependencies pinned.True(�HdrsMapInfoTRepresents grouping of CC header files, alongsdie with their intended include paths.2�
�
HdrsMapInfoTRepresents grouping of CC header files, alongsdie with their intended include paths.F
hdrs>Headers which should be exposed after the compilation is done.S
implementation_hdrs<Headers that should not be propagated after the compilation.L
hdrs_map@(hdrs_map struct) object describing desired header file mappingsw
depsoCcInfo/CcSharedLibraryInfo-aware dependencies that need to be propagated, for this provider to compile and link"8
HdrsMapInfo)//cc_hdrs_map/providers:hdrs_map_info.bzlH
F
hdrs>Headers which should be exposed after the compilation is done.U
S
implementation_hdrs<Headers that should not be propagated after the compilation.N
L
hdrs_map@(hdrs_map struct) object describing desired header file mappingsy
w
depsoCcInfo/CcSharedLibraryInfo-aware dependencies that need to be propagated, for this provider to compile and linkCModule describing HdrsMapInfo provider and common operations on it.�6
#cc_hdrs_map/providers
helper.bzl�)providers_helper.materialize_hdrs_mapping�Materialize the expected file hierarchy.

Creates the header file hierarchy accordingly to specifications
in passed-in hdrs_map under 'vhm' directory.
*�
�
)providers_helper.materialize_hdrs_mapping6
invoker_label!label of rule invoking the method ( 
actionsbazel ctx.actions (<
hdrs_map,HdrsMapInfo representing the headers mapping (K
hdrs?list of all header files that should be matched against the map (�Materialize the expected file hierarchy.

Creates the header file hierarchy accordingly to specifications
in passed-in hdrs_map under 'vhm' directory.
"�
�(materialized_include_path, materialized_hdrs_files): tuple of include_path to
the created header files dir and list of paths to all header files created.2@
materialize_hdrs_mapping$//cc_hdrs_map/providers:hdrs_map.bzl8
6
invoker_label!label of rule invoking the method ("
 
actionsbazel ctx.actions (>
<
hdrs_map,HdrsMapInfo representing the headers mapping (M
K
hdrs?list of all header files that should be matched against the map (�
.providers_helper.merge_cc_shared_library_infos?Merge CcSharedLibraryInfos from targets into singualr provider.*�	
�
.providers_helper.merge_cc_shared_library_infos~
targetsmlist of Bazel targets that should be merged. They must
contain either CcInfo or CcSharedLibraryInfo provider.[](Q
dynamic_deps9sequence of Depsets representing additional dynamic deps.None(I
exports6cc_libraries that are linked statically and exported".None(S
linker_input;the resultign linker inptu artifact for the shared library.None(s
link_once_static_libsRall libraries linked statically into this library that should
only be linked once.None(?Merge CcSharedLibraryInfos from targets into singualr provider."
CcSharedLibraryInfo provider.2S
merge_cc_shared_library_infos2//cc_hdrs_map/providers:cc_shared_library_info.bzl�
~
targetsmlist of Bazel targets that should be merged. They must
contain either CcInfo or CcSharedLibraryInfo provider.[](S
Q
dynamic_deps9sequence of Depsets representing additional dynamic deps.None(K
I
exports6cc_libraries that are linked statically and exported".None(U
S
linker_input;the resultign linker inptu artifact for the shared library.None(u
s
link_once_static_libsRall libraries linked statically into this library that should
only be linked once.None(�%providers_helper.merge_hdrs_map_infos?Merge all HdrsMapInfo providers from targets into singular one.*�
�
%providers_helper.merge_hdrs_map_infos
targets[](3
hdrs#additional header files to include,None(L
implementation_hdrs-additional implementation headers to include,None(F
hdrs_map2initial hdrs_map to use as a foundation for merge,None(<
hdrs_map_deps#additional dependencies to include,None(g
pin_down_non_globsIwheather the final hdrs_map should have its
non_glob dependencies pinned.True(?Merge all HdrsMapInfo providers from targets into singular one."N
LHdrsMapInfo provider that represents merge of all HdrsMapInfos from targets.2A
merge_hdrs_map_infos)//cc_hdrs_map/providers:hdrs_map_info.bzl

targets[](5
3
hdrs#additional header files to include,None(N
L
implementation_hdrs-additional implementation headers to include,None(H
F
hdrs_map2initial hdrs_map to use as a foundation for merge,None(>
<
hdrs_map_deps#additional dependencies to include,None(i
g
pin_down_non_globsIwheather the final hdrs_map should have its
non_glob dependencies pinned.True(�providers_helper.new_hdrs_map&Create new instance of HdrsMap struct.*�
�
providers_helper.new_hdrs_map
	from_dict{}(
_globNone(
	_non_globNone(&Create new instance of HdrsMap struct.24
new_hdrs_map$//cc_hdrs_map/providers:hdrs_map.bzl

	from_dict{}(

_globNone(

	_non_globNone(�5providers_helper.quotient_map_cc_shared_library_infos�Transform list of Bazel targets into CcSharedLibrayInfo attribue groups.

For given list of Bazel targets, attributes relating to CcSharedLibraryInfo
(dynamic_deps, exports, linker_inputs, link_once_static_libs) will be extracted
from said targets and the output will contain groups of that values.
*�
�
5providers_helper.quotient_map_cc_shared_library_infos~
targetsmlist of Bazel targets that should be mapped. They must
contain either CcInfo or CcSharedLibraryInfo provider.[](Q
dynamic_deps9sequence of Depsets representing additional dynamic deps.None(I
exports6cc_libraries that are linked statically and exported".None(S
linker_input;the resultign linker inptu artifact for the shared library.None(s
link_once_static_libsRall libraries linked statically into this library that should
only be linked once.None(�Transform list of Bazel targets into CcSharedLibrayInfo attribue groups.

For given list of Bazel targets, attributes relating to CcSharedLibraryInfo
(dynamic_deps, exports, linker_inputs, link_once_static_libs) will be extracted
from said targets and the output will contain groups of that values.
"?
=(dynamic_deps, exports, linker_inptuts, link_once_static_lib)2Z
$quotient_map_cc_shared_library_infos2//cc_hdrs_map/providers:cc_shared_library_info.bzl�
~
targetsmlist of Bazel targets that should be mapped. They must
contain either CcInfo or CcSharedLibraryInfo provider.[](S
Q
dynamic_deps9sequence of Depsets representing additional dynamic deps.None(K
I
exports6cc_libraries that are linked statically and exported".None(U
S
linker_input;the resultign linker inptu artifact for the shared library.None(u
s
link_once_static_libsRall libraries linked statically into this library that should
only be linked once.None(�,providers_helper.quotient_map_hdrs_map_infos7Take all HdrsMapInfo key-values and group them by keys.*�
�
,providers_helper.quotient_map_hdrs_map_infos
targets[](3
hdrs#additional header files to include,None(L
implementation_hdrs-additional implementation headers to include,None(F
hdrs_map2initial hdrs_map to use as a foundation for merge,None(;
hdrs_map_deps"additional dependencies to includeNone(D
traverse_deps+wheather to gather HdrsMapInfos transitvelyTrue(7Take all HdrsMapInfo key-values and group them by keys."=
;(hdrs, implementation_hdrs, hdrs_map, hdr_maps_deps): tuple2H
quotient_map_hdrs_map_infos)//cc_hdrs_map/providers:hdrs_map_info.bzl

targets[](5
3
hdrs#additional header files to include,None(N
L
implementation_hdrs-additional implementation headers to include,None(H
F
hdrs_map2initial hdrs_map to use as a foundation for merge,None(=
;
hdrs_map_deps"additional dependencies to includeNone(F
D
traverse_deps+wheather to gather HdrsMapInfos transitvelyTrue(TThis module exposes the common operatiosn done towards providers as a helper struct.�
!cc_hdrs_mapworkspace_deps.bzl�cc_hdrs_map_workspace_deps%Load all dependencies of cc_hdrs_map.*�
�
cc_hdrs_map_workspace_deps%Load all dependencies of cc_hdrs_map.2>
cc_hdrs_map_workspace_deps //cc_hdrs_map:workspace_deps.bzlHThis module exposes a way to load rule dependencies in non-bzlmod usage.߮
*
rules_cc_hdrs_mapcc_hdrs_mapdefs.bzl��
cc_archive�Produce an archive file.

The intended major difference between this rule and rules_cc's `cc_static_library`,
is that this rule does not intend to pull-in all static dependencies."��
�G

cc_archive�Produce an archive file.

The intended major difference between this rule and rules_cc's `cc_static_library`,
is that this rule does not intend to pull-in all static dependencies.*
nameA unique name for this target. �
archive_lib_name�Specify the name of the created .a file (that is decoupled from the rule instance name).
Note, that the 'cc_archive' is opinionated and will remove any leading 'lib' prefix and any '.a' in the name
(meaning 'libTest.a.x64.a' will become 'Test.x64' and will produce 'libTest.x64.a')2""
reexport_deps2[]�
data�The list of files needed by this target at runtime. See general comments about data at Typical attributes defined by most build rules.2[]8
deps*The list of dependencies of current target2[]%
srcsThe list of source files. �
hdrstList of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.2[]�
implementation_hdrsjList of headers that CANNOT be included by dependent rules.
Notice: the cutoff happens during compilation.2[]�
hdrs_map�Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory.2{}�
module_interfaces�The list of files that are regarded as C++20 Modules Interface.

C++ Standard has no restriction about module interface file extension
* Clang use cppm
* GCC can use any source file extension
* MSVC use ixx

The use is guarded by the flag --experimental_cpp_modules.2[]�
win_def_file�The Windows DEF file to be passed to linker.

This attribute should only be used when Windows is the target platform. It can be used to export symbols during linking a shared library.2None�
additional_compiler_inputs�Any additional files you might want to pass to the compiler command line, such as sanitizer ignorelists, for example.
Files specified here can then be used in copts with the $(location) function.2[]�
additional_linker_inputs�Any additional files that you may want to pass to the linker, for example, linker scripts.
You have to separately pass any linker flags that the linker needs in order to be aware of this file.
You can do so via the linkopts attribute.2[]�
	conlyoptsvAdd these options to the C compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.2[]�
copts�Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.
Each string in this attribute is added in the given order to COPTS before compiling the binary target. The flags take effect only for compiling this target, not its dependencies, so be careful about header files included elsewhere. All paths should be relative to the workspace, not to the current package.

If the package declares the feature no_copts_tokenization, Bourne shell tokenization applies only to strings that consist of a single "Make" variable.2[]�
cxxoptsxAdd these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.2[]�
defines�List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line to this target, as well as to every rule that depends on it. Be very careful, since this may have far-reaching effects. When in doubt, add define values to local_defines instead.2[]�
dynamic_deps�In contrast to `rules_cc`, the dynamic_deps of `rules_cc_hdrs_map` are simply translated into deps parameter,
and the providers (CcInfo vs CcSharedInfo) are used to steer the behavior further.2[]�
implementation_deps�The list of other libraries that the library target depends on. Unlike with deps, the headers and include paths of these libraries (and all their transitive deps) are only used for compilation of this library, and not libraries that depend on it. Libraries specified with implementation_deps are still linked in binary targets that depend on this library.2[]�
includes�List of include dirs to be added to the compile line.
Subject to "Make variable" substitution. Each string is prepended with -isystem and added to COPTS. Unlike COPTS, these flags are added for this rule and every rule that depends on it. (Note: not the rules it depends upon!) Be very careful, since this may have far-reaching effects. When in doubt, add "-I" flags to COPTS instead.

Headers must be added to srcs or hdrs, otherwise they will not be available to dependent rules when compilation is sandboxed (the default).2[]�
linkopts�Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.2[]�

linksharedwCreate a shared library. To enable this attribute, include linkshared=True in your rule. By default this option is off.2False�
	linkstamp�Simultaneously compiles and links the specified C++ source file into the final binary. This trickery is required to introduce timestamp information into binaries; if we compiled the source file to an object file in the usual way, the timestamp would be incorrect. A linkstamp compilation may not include any particular set of compiler flags and so should not depend on any particular header, compiler option, or other build variable. This option should only be needed in the base package.2None�

linkstatic�If enabled and this is a binary or test, this option tells the build tool to link in .a's instead of .so's for user libraries whenever possible. System libraries such as libc (but not the C/C++ runtime libraries, see below) are still linked dynamically, as are libraries for which there is no static library. So the resulting executable will still be dynamically linked, hence only mostly static.
The linkstatic attribute has a different meaning if used on a cc_library() rule. For a C++ library, linkstatic=True indicates that only static linking is allowed, so no .so will be produced. linkstatic=False does not prevent static libraries from being created. The attribute is meant to control the creation of dynamic libraries.2False�
local_defines�List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line for this target, but not to its dependents.2[]�
nocopts�Remove matching options from the C++ compilation command. Subject to "Make" variable substitution. The value of this attribute is interpreted as a regular expression. Any preexisting COPTS that match this regular expression (including values explicitly specified in the rule's copts attribute) will be removed from COPTS for purposes of compiling this rule. This attribute should not be needed or used outside of third_party. The values are not preprocessed in any way other than the "Make" variable substitution.2""�
include_prefix�The prefix to add to the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at is the value of this attribute prepended to their repository-relative path.

The prefix in the strip_include_prefix attribute is removed before this prefix is added.2""�
strip_include_prefix�The prefix to strip from the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at their path with this prefix cut off.

If it's a relative path, it's taken as a package-relative one. If it's an absolute one, it's understood as a repository-relative path.

The prefix in the include_prefix attribute is added after this prefix is stripped.2""�
textual_hdrs�The list of header files published by this library to be textually included by sources in dependent rules.

This is the location for declaring header files that cannot be compiled on their own; that is, they always need to be textually included by other source files to build valid code.2[]"D

cc_archive6@rules_cc_hdrs_map//cc_hdrs_map/private:cc_archive.bzl*�
DefaultInfo
CcInfo
HdrsMapInfo
DefaultInfo<native>
CcInfo<native>J
HdrsMapInfo;@rules_cc_hdrs_map//cc_hdrs_map/providers:hdrs_map_info.bzl,
*
nameA unique name for this target. �
�
archive_lib_name�Specify the name of the created .a file (that is decoupled from the rule instance name).
Note, that the 'cc_archive' is opinionated and will remove any leading 'lib' prefix and any '.a' in the name
(meaning 'libTest.a.x64.a' will become 'Test.x64' and will produce 'libTest.x64.a')2""

reexport_deps2[]�
�
data�The list of files needed by this target at runtime. See general comments about data at Typical attributes defined by most build rules.2[]:
8
deps*The list of dependencies of current target2[]'
%
srcsThe list of source files. �
�
hdrstList of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.2[]�
�
implementation_hdrsjList of headers that CANNOT be included by dependent rules.
Notice: the cutoff happens during compilation.2[]�
�
hdrs_map�Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory.2{}�
�
module_interfaces�The list of files that are regarded as C++20 Modules Interface.

C++ Standard has no restriction about module interface file extension
* Clang use cppm
* GCC can use any source file extension
* MSVC use ixx

The use is guarded by the flag --experimental_cpp_modules.2[]�
�
win_def_file�The Windows DEF file to be passed to linker.

This attribute should only be used when Windows is the target platform. It can be used to export symbols during linking a shared library.2None�
�
additional_compiler_inputs�Any additional files you might want to pass to the compiler command line, such as sanitizer ignorelists, for example.
Files specified here can then be used in copts with the $(location) function.2[]�
�
additional_linker_inputs�Any additional files that you may want to pass to the linker, for example, linker scripts.
You have to separately pass any linker flags that the linker needs in order to be aware of this file.
You can do so via the linkopts attribute.2[]�
�
	conlyoptsvAdd these options to the C compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.2[]�
�
copts�Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.
Each string in this attribute is added in the given order to COPTS before compiling the binary target. The flags take effect only for compiling this target, not its dependencies, so be careful about header files included elsewhere. All paths should be relative to the workspace, not to the current package.

If the package declares the feature no_copts_tokenization, Bourne shell tokenization applies only to strings that consist of a single "Make" variable.2[]�
�
cxxoptsxAdd these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.2[]�
�
defines�List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line to this target, as well as to every rule that depends on it. Be very careful, since this may have far-reaching effects. When in doubt, add define values to local_defines instead.2[]�
�
dynamic_deps�In contrast to `rules_cc`, the dynamic_deps of `rules_cc_hdrs_map` are simply translated into deps parameter,
and the providers (CcInfo vs CcSharedInfo) are used to steer the behavior further.2[]�
�
implementation_deps�The list of other libraries that the library target depends on. Unlike with deps, the headers and include paths of these libraries (and all their transitive deps) are only used for compilation of this library, and not libraries that depend on it. Libraries specified with implementation_deps are still linked in binary targets that depend on this library.2[]�
�
includes�List of include dirs to be added to the compile line.
Subject to "Make variable" substitution. Each string is prepended with -isystem and added to COPTS. Unlike COPTS, these flags are added for this rule and every rule that depends on it. (Note: not the rules it depends upon!) Be very careful, since this may have far-reaching effects. When in doubt, add "-I" flags to COPTS instead.

Headers must be added to srcs or hdrs, otherwise they will not be available to dependent rules when compilation is sandboxed (the default).2[]�
�
linkopts�Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.2[]�
�

linksharedwCreate a shared library. To enable this attribute, include linkshared=True in your rule. By default this option is off.2False�
�
	linkstamp�Simultaneously compiles and links the specified C++ source file into the final binary. This trickery is required to introduce timestamp information into binaries; if we compiled the source file to an object file in the usual way, the timestamp would be incorrect. A linkstamp compilation may not include any particular set of compiler flags and so should not depend on any particular header, compiler option, or other build variable. This option should only be needed in the base package.2None�
�

linkstatic�If enabled and this is a binary or test, this option tells the build tool to link in .a's instead of .so's for user libraries whenever possible. System libraries such as libc (but not the C/C++ runtime libraries, see below) are still linked dynamically, as are libraries for which there is no static library. So the resulting executable will still be dynamically linked, hence only mostly static.
The linkstatic attribute has a different meaning if used on a cc_library() rule. For a C++ library, linkstatic=True indicates that only static linking is allowed, so no .so will be produced. linkstatic=False does not prevent static libraries from being created. The attribute is meant to control the creation of dynamic libraries.2False�
�
local_defines�List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line for this target, but not to its dependents.2[]�
�
nocopts�Remove matching options from the C++ compilation command. Subject to "Make" variable substitution. The value of this attribute is interpreted as a regular expression. Any preexisting COPTS that match this regular expression (including values explicitly specified in the rule's copts attribute) will be removed from COPTS for purposes of compiling this rule. This attribute should not be needed or used outside of third_party. The values are not preprocessed in any way other than the "Make" variable substitution.2""�
�
include_prefix�The prefix to add to the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at is the value of this attribute prepended to their repository-relative path.

The prefix in the strip_include_prefix attribute is removed before this prefix is added.2""�
�
strip_include_prefix�The prefix to strip from the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at their path with this prefix cut off.

If it's a relative path, it's taken as a package-relative one. If it's an absolute one, it's understood as a repository-relative path.

The prefix in the include_prefix attribute is added after this prefix is stripped.2""�
�
textual_hdrs�The list of header files published by this library to be textually included by sources in dependent rules.

This is the location for declaring header files that cannot be compiled on their own; that is, they always need to be textually included by other source files to build valid code.2[]�~cc_bin�Produce exectuable binary.

It is intended for this rule, to differ from rules_cc's `cc_binary` in the following
fashion: it aims to automatically gather all of its dynamic dependencies and make them
available during binary execution."�|
�?
cc_bin�Produce exectuable binary.

It is intended for this rule, to differ from rules_cc's `cc_binary` in the following
fashion: it aims to automatically gather all of its dynamic dependencies and make them
available during binary execution.*
nameA unique name for this target. �
stamp�Whether to encode build information into the binary. Possible values:

  * stamp = 1: Always stamp the build information into the binary, even in --nostamp builds. This setting should be avoided, since it potentially kills remote caching for the binary and any downstream actions that depend on it.

  * stamp = 0: Always replace build information by constant values. This gives good build result caching.

  * stamp = -1: Embedding of build information is controlled by the --[no]stamp flag.

Stamped binaries are not rebuilt unless their dependencies change.2-1
reexport_deps2[]�
data�The list of files needed by this target at runtime. See general comments about data at Typical attributes defined by most build rules.2[]8
deps*The list of dependencies of current target2[]%
srcsThe list of source files. �
hdrstList of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.2[]�
hdrs_map�Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory.2{}�
module_interfaces�The list of files that are regarded as C++20 Modules Interface.

C++ Standard has no restriction about module interface file extension
* Clang use cppm
* GCC can use any source file extension
* MSVC use ixx

The use is guarded by the flag --experimental_cpp_modules.2[]�
win_def_file�The Windows DEF file to be passed to linker.

This attribute should only be used when Windows is the target platform. It can be used to export symbols during linking a shared library.2None�
additional_compiler_inputs�Any additional files you might want to pass to the compiler command line, such as sanitizer ignorelists, for example.
Files specified here can then be used in copts with the $(location) function.2[]�
additional_linker_inputs�Any additional files that you may want to pass to the linker, for example, linker scripts.
You have to separately pass any linker flags that the linker needs in order to be aware of this file.
You can do so via the linkopts attribute.2[]�
	conlyoptsvAdd these options to the C compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.2[]�
copts�Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.
Each string in this attribute is added in the given order to COPTS before compiling the binary target. The flags take effect only for compiling this target, not its dependencies, so be careful about header files included elsewhere. All paths should be relative to the workspace, not to the current package.

If the package declares the feature no_copts_tokenization, Bourne shell tokenization applies only to strings that consist of a single "Make" variable.2[]�
cxxoptsxAdd these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.2[]�
defines�List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line to this target, as well as to every rule that depends on it. Be very careful, since this may have far-reaching effects. When in doubt, add define values to local_defines instead.2[]�
dynamic_deps�In contrast to `rules_cc`, the dynamic_deps of `rules_cc_hdrs_map` are simply translated into deps parameter,
and the providers (CcInfo vs CcSharedInfo) are used to steer the behavior further.2[]�
includes�List of include dirs to be added to the compile line.
Subject to "Make variable" substitution. Each string is prepended with -isystem and added to COPTS. Unlike COPTS, these flags are added for this rule and every rule that depends on it. (Note: not the rules it depends upon!) Be very careful, since this may have far-reaching effects. When in doubt, add "-I" flags to COPTS instead.

Headers must be added to srcs or hdrs, otherwise they will not be available to dependent rules when compilation is sandboxed (the default).2[]�
link_extra_lib�Control linking of extra libraries.

By default, C++ binaries are linked against //tools/cpp:link_extra_lib, which by default depends on the label flag //tools/cpp:link_extra_libs. Without setting the flag, this library is empty by default. Setting the label flag allows linking optional dependencies, such as overrides for weak symbols, interceptors for shared library functions, or special runtime libraries (for malloc replacements, prefer malloc or --custom_malloc). Setting this attribute to None disables this behaviour.2None�
linkopts�Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.2[]�

linksharedwCreate a shared library. To enable this attribute, include linkshared=True in your rule. By default this option is off.2False�

linkstatic�If enabled and this is a binary or test, this option tells the build tool to link in .a's instead of .so's for user libraries whenever possible. System libraries such as libc (but not the C/C++ runtime libraries, see below) are still linked dynamically, as are libraries for which there is no static library. So the resulting executable will still be dynamically linked, hence only mostly static.
The linkstatic attribute has a different meaning if used on a cc_library() rule. For a C++ library, linkstatic=True indicates that only static linking is allowed, so no .so will be produced. linkstatic=False does not prevent static libraries from being created. The attribute is meant to control the creation of dynamic libraries.2False�
local_defines�List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line for this target, but not to its dependents.2[]�
malloc�Override the default dependency on malloc.

By default, C++ binaries are linked against //tools/cpp:malloc, which is an empty library so the binary ends up using libc malloc. This label must refer to a cc_library. If compilation is for a non-C++ rule, this option has no effect. The value of this attribute is ignored if linkshared=True is specified.2None�
nocopts�Remove matching options from the C++ compilation command. Subject to "Make" variable substitution. The value of this attribute is interpreted as a regular expression. Any preexisting COPTS that match this regular expression (including values explicitly specified in the rule's copts attribute) will be removed from COPTS for purposes of compiling this rule. This attribute should not be needed or used outside of third_party. The values are not preprocessed in any way other than the "Make" variable substitution.2"""<
cc_bin2@rules_cc_hdrs_map//cc_hdrs_map/private:cc_bin.bzl8,
*
nameA unique name for this target. �
�
stamp�Whether to encode build information into the binary. Possible values:

  * stamp = 1: Always stamp the build information into the binary, even in --nostamp builds. This setting should be avoided, since it potentially kills remote caching for the binary and any downstream actions that depend on it.

  * stamp = 0: Always replace build information by constant values. This gives good build result caching.

  * stamp = -1: Embedding of build information is controlled by the --[no]stamp flag.

Stamped binaries are not rebuilt unless their dependencies change.2-1

reexport_deps2[]�
�
data�The list of files needed by this target at runtime. See general comments about data at Typical attributes defined by most build rules.2[]:
8
deps*The list of dependencies of current target2[]'
%
srcsThe list of source files. �
�
hdrstList of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.2[]�
�
hdrs_map�Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory.2{}�
�
module_interfaces�The list of files that are regarded as C++20 Modules Interface.

C++ Standard has no restriction about module interface file extension
* Clang use cppm
* GCC can use any source file extension
* MSVC use ixx

The use is guarded by the flag --experimental_cpp_modules.2[]�
�
win_def_file�The Windows DEF file to be passed to linker.

This attribute should only be used when Windows is the target platform. It can be used to export symbols during linking a shared library.2None�
�
additional_compiler_inputs�Any additional files you might want to pass to the compiler command line, such as sanitizer ignorelists, for example.
Files specified here can then be used in copts with the $(location) function.2[]�
�
additional_linker_inputs�Any additional files that you may want to pass to the linker, for example, linker scripts.
You have to separately pass any linker flags that the linker needs in order to be aware of this file.
You can do so via the linkopts attribute.2[]�
�
	conlyoptsvAdd these options to the C compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.2[]�
�
copts�Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.
Each string in this attribute is added in the given order to COPTS before compiling the binary target. The flags take effect only for compiling this target, not its dependencies, so be careful about header files included elsewhere. All paths should be relative to the workspace, not to the current package.

If the package declares the feature no_copts_tokenization, Bourne shell tokenization applies only to strings that consist of a single "Make" variable.2[]�
�
cxxoptsxAdd these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.2[]�
�
defines�List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line to this target, as well as to every rule that depends on it. Be very careful, since this may have far-reaching effects. When in doubt, add define values to local_defines instead.2[]�
�
dynamic_deps�In contrast to `rules_cc`, the dynamic_deps of `rules_cc_hdrs_map` are simply translated into deps parameter,
and the providers (CcInfo vs CcSharedInfo) are used to steer the behavior further.2[]�
�
includes�List of include dirs to be added to the compile line.
Subject to "Make variable" substitution. Each string is prepended with -isystem and added to COPTS. Unlike COPTS, these flags are added for this rule and every rule that depends on it. (Note: not the rules it depends upon!) Be very careful, since this may have far-reaching effects. When in doubt, add "-I" flags to COPTS instead.

Headers must be added to srcs or hdrs, otherwise they will not be available to dependent rules when compilation is sandboxed (the default).2[]�
�
link_extra_lib�Control linking of extra libraries.

By default, C++ binaries are linked against //tools/cpp:link_extra_lib, which by default depends on the label flag //tools/cpp:link_extra_libs. Without setting the flag, this library is empty by default. Setting the label flag allows linking optional dependencies, such as overrides for weak symbols, interceptors for shared library functions, or special runtime libraries (for malloc replacements, prefer malloc or --custom_malloc). Setting this attribute to None disables this behaviour.2None�
�
linkopts�Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.2[]�
�

linksharedwCreate a shared library. To enable this attribute, include linkshared=True in your rule. By default this option is off.2False�
�

linkstatic�If enabled and this is a binary or test, this option tells the build tool to link in .a's instead of .so's for user libraries whenever possible. System libraries such as libc (but not the C/C++ runtime libraries, see below) are still linked dynamically, as are libraries for which there is no static library. So the resulting executable will still be dynamically linked, hence only mostly static.
The linkstatic attribute has a different meaning if used on a cc_library() rule. For a C++ library, linkstatic=True indicates that only static linking is allowed, so no .so will be produced. linkstatic=False does not prevent static libraries from being created. The attribute is meant to control the creation of dynamic libraries.2False�
�
local_defines�List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line for this target, but not to its dependents.2[]�
�
malloc�Override the default dependency on malloc.

By default, C++ binaries are linked against //tools/cpp:malloc, which is an empty library so the binary ends up using libc malloc. This label must refer to a cc_library. If compilation is for a non-C++ rule, this option has no effect. The value of this attribute is ignored if linkshared=True is specified.2None�
�
nocopts�Remove matching options from the C++ compilation command. Subject to "Make" variable substitution. The value of this attribute is interpreted as a regular expression. Any preexisting COPTS that match this regular expression (including values explicitly specified in the rule's copts attribute) will be removed from COPTS for purposes of compiling this rule. This attribute should not be needed or used outside of third_party. The values are not preprocessed in any way other than the "Make" variable substitution.2""�cc_hdrs�Define header files properties.

This rule groups headers into a singular target and allows
to attach 'include_path' modifications information to them,
so that wherever the header files are being used, they can
be used with their intended include paths."�
�
cc_hdrs�Define header files properties.

This rule groups headers into a singular target and allows
to attach 'include_path' modifications information to them,
so that wherever the header files are being used, they can
be used with their intended include paths.*
nameA unique name for this target. �
data�The list of files needed by this target at runtime. See general comments about data at Typical attributes defined by most build rules.2[]8
deps*The list of dependencies of current target2[]�
hdrstList of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.2[]�
implementation_hdrsjList of headers that CANNOT be included by dependent rules.
Notice: the cutoff happens during compilation.2[]�
hdrs_map�Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory.2{}�
module_interfaces�The list of files that are regarded as C++20 Modules Interface.

C++ Standard has no restriction about module interface file extension
* Clang use cppm
* GCC can use any source file extension
* MSVC use ixx

The use is guarded by the flag --experimental_cpp_modules.2[]�
win_def_file�The Windows DEF file to be passed to linker.

This attribute should only be used when Windows is the target platform. It can be used to export symbols during linking a shared library.2None">
cc_hdrs3@rules_cc_hdrs_map//cc_hdrs_map/private:cc_hdrs.bzl*
DefaultInfo
HdrsMapInfo
DefaultInfo<native>J
HdrsMapInfo;@rules_cc_hdrs_map//cc_hdrs_map/providers:hdrs_map_info.bzl,
*
nameA unique name for this target. �
�
data�The list of files needed by this target at runtime. See general comments about data at Typical attributes defined by most build rules.2[]:
8
deps*The list of dependencies of current target2[]�
�
hdrstList of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.2[]�
�
implementation_hdrsjList of headers that CANNOT be included by dependent rules.
Notice: the cutoff happens during compilation.2[]�
�
hdrs_map�Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory.2{}�
�
module_interfaces�The list of files that are regarded as C++20 Modules Interface.

C++ Standard has no restriction about module interface file extension
* Clang use cppm
* GCC can use any source file extension
* MSVC use ixx

The use is guarded by the flag --experimental_cpp_modules.2[]�
�
win_def_file�The Windows DEF file to be passed to linker.

This attribute should only be used when Windows is the target platform. It can be used to export symbols during linking a shared library.2None�cc_so�Produce shared object library.

The intended difference between this rule and the rules_cc's cc_shared_library is to:
 1) remove 'cc_library' out of the equation (no more targets that produce either archive or sol)
 2) unify handling of dependencies that are equipped with CcInfo and CcSharedLibraryInfo
    (use singular attribute of deps to track them both)."��
�[
cc_so�Produce shared object library.

The intended difference between this rule and the rules_cc's cc_shared_library is to:
 1) remove 'cc_library' out of the equation (no more targets that produce either archive or sol)
 2) unify handling of dependencies that are equipped with CcInfo and CcSharedLibraryInfo
    (use singular attribute of deps to track them both).*
nameA unique name for this target. �

alwayslink�If 1, any binary that depends (directly or indirectly) on this C++ precompiled library will link in all the object files archived in the static library, even if some contain no symbols referenced by the binary. This is useful if your code isn't explicitly called by code in the binary, e.g., if your code registers to receive some callback provided by some service.2False�
exports_filter�This attribute contains a list of targets that are claimed to be exported by the current shared library.

Any target deps is already understood to be exported by the shared library. This attribute should be used to list any targets that are exported by the shared library but are transitive dependencies of deps.

Note that this attribute is not actually adding a dependency edge to those targets, the dependency edge should instead be created by deps.The entries in this attribute are just strings. Keep in mind that when placing a target in this attribute, this is considered a claim that the shared library exports the symbols from that target. The cc_shared_library logic doesn't actually handle telling the linker which symbols should be exported.

The following syntax is allowed:

//foo:__pkg__ to account for any target in foo/BUILD

//foo:__subpackages__ to account for any target in foo/BUILD or any other package below foo/ like foo/bar/BUILD2[]$
roots(Not yet implemented)2[]�
shared_lib_name�Specify the name of the created SOL file (that is decoupled from the rule instance name).
Note, that the 'cc_so' is opinionated and will remove any leading 'lib' prefix and any '.so' in the name
(meaning 'libTest.so.x64.so' will become 'Test.x64' and will produce 'libTest.x64.so')2""�
data�The list of files needed by this target at runtime. See general comments about data at Typical attributes defined by most build rules.2[]8
deps*The list of dependencies of current target2[]%
srcsThe list of source files. �
hdrstList of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.2[]�
implementation_hdrsjList of headers that CANNOT be included by dependent rules.
Notice: the cutoff happens during compilation.2[]�
hdrs_map�Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory.2{}�
module_interfaces�The list of files that are regarded as C++20 Modules Interface.

C++ Standard has no restriction about module interface file extension
* Clang use cppm
* GCC can use any source file extension
* MSVC use ixx

The use is guarded by the flag --experimental_cpp_modules.2[]�
win_def_file�The Windows DEF file to be passed to linker.

This attribute should only be used when Windows is the target platform. It can be used to export symbols during linking a shared library.2None�
additional_compiler_inputs�Any additional files you might want to pass to the compiler command line, such as sanitizer ignorelists, for example.
Files specified here can then be used in copts with the $(location) function.2[]�
additional_linker_inputs�Any additional files that you may want to pass to the linker, for example, linker scripts.
You have to separately pass any linker flags that the linker needs in order to be aware of this file.
You can do so via the linkopts attribute.2[]�
	conlyoptsvAdd these options to the C compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.2[]�
copts�Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.
Each string in this attribute is added in the given order to COPTS before compiling the binary target. The flags take effect only for compiling this target, not its dependencies, so be careful about header files included elsewhere. All paths should be relative to the workspace, not to the current package.

If the package declares the feature no_copts_tokenization, Bourne shell tokenization applies only to strings that consist of a single "Make" variable.2[]�
cxxoptsxAdd these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.2[]�
defines�List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line to this target, as well as to every rule that depends on it. Be very careful, since this may have far-reaching effects. When in doubt, add define values to local_defines instead.2[]�
dynamic_deps�In contrast to `rules_cc`, the dynamic_deps of `rules_cc_hdrs_map` are simply translated into deps parameter,
and the providers (CcInfo vs CcSharedInfo) are used to steer the behavior further.2[]�
implementation_deps�The list of other libraries that the library target depends on. Unlike with deps, the headers and include paths of these libraries (and all their transitive deps) are only used for compilation of this library, and not libraries that depend on it. Libraries specified with implementation_deps are still linked in binary targets that depend on this library.2[]�
includes�List of include dirs to be added to the compile line.
Subject to "Make variable" substitution. Each string is prepended with -isystem and added to COPTS. Unlike COPTS, these flags are added for this rule and every rule that depends on it. (Note: not the rules it depends upon!) Be very careful, since this may have far-reaching effects. When in doubt, add "-I" flags to COPTS instead.

Headers must be added to srcs or hdrs, otherwise they will not be available to dependent rules when compilation is sandboxed (the default).2[]�
link_extra_lib�Control linking of extra libraries.

By default, C++ binaries are linked against //tools/cpp:link_extra_lib, which by default depends on the label flag //tools/cpp:link_extra_libs. Without setting the flag, this library is empty by default. Setting the label flag allows linking optional dependencies, such as overrides for weak symbols, interceptors for shared library functions, or special runtime libraries (for malloc replacements, prefer malloc or --custom_malloc). Setting this attribute to None disables this behaviour.2None�
linkopts�Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.2[]�

linksharedwCreate a shared library. To enable this attribute, include linkshared=True in your rule. By default this option is off.2False�
	linkstamp�Simultaneously compiles and links the specified C++ source file into the final binary. This trickery is required to introduce timestamp information into binaries; if we compiled the source file to an object file in the usual way, the timestamp would be incorrect. A linkstamp compilation may not include any particular set of compiler flags and so should not depend on any particular header, compiler option, or other build variable. This option should only be needed in the base package.2None�

linkstatic�If enabled and this is a binary or test, this option tells the build tool to link in .a's instead of .so's for user libraries whenever possible. System libraries such as libc (but not the C/C++ runtime libraries, see below) are still linked dynamically, as are libraries for which there is no static library. So the resulting executable will still be dynamically linked, hence only mostly static.
The linkstatic attribute has a different meaning if used on a cc_library() rule. For a C++ library, linkstatic=True indicates that only static linking is allowed, so no .so will be produced. linkstatic=False does not prevent static libraries from being created. The attribute is meant to control the creation of dynamic libraries.2False�
local_defines�List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line for this target, but not to its dependents.2[]�
malloc�Override the default dependency on malloc.

By default, C++ binaries are linked against //tools/cpp:malloc, which is an empty library so the binary ends up using libc malloc. This label must refer to a cc_library. If compilation is for a non-C++ rule, this option has no effect. The value of this attribute is ignored if linkshared=True is specified.2None�
nocopts�Remove matching options from the C++ compilation command. Subject to "Make" variable substitution. The value of this attribute is interpreted as a regular expression. Any preexisting COPTS that match this regular expression (including values explicitly specified in the rule's copts attribute) will be removed from COPTS for purposes of compiling this rule. This attribute should not be needed or used outside of third_party. The values are not preprocessed in any way other than the "Make" variable substitution.2""�
include_prefix�The prefix to add to the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at is the value of this attribute prepended to their repository-relative path.

The prefix in the strip_include_prefix attribute is removed before this prefix is added.2""�
strip_include_prefix�The prefix to strip from the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at their path with this prefix cut off.

If it's a relative path, it's taken as a package-relative one. If it's an absolute one, it's understood as a repository-relative path.

The prefix in the include_prefix attribute is added after this prefix is stripped.2""�
textual_hdrs�The list of header files published by this library to be textually included by sources in dependent rules.

This is the location for declaring header files that cannot be compiled on their own; that is, they always need to be textually included by other source files to build valid code.2[]":
cc_so1@rules_cc_hdrs_map//cc_hdrs_map/private:cc_so.bzl*�
DefaultInfo
CcSharedLibraryInfo
HdrsMapInfo
DefaultInfo<native>D
CcSharedLibraryInfo-@@_builtins//:common/cc/cc_shared_library.bzlJ
HdrsMapInfo;@rules_cc_hdrs_map//cc_hdrs_map/providers:hdrs_map_info.bzl,
*
nameA unique name for this target. �
�

alwayslink�If 1, any binary that depends (directly or indirectly) on this C++ precompiled library will link in all the object files archived in the static library, even if some contain no symbols referenced by the binary. This is useful if your code isn't explicitly called by code in the binary, e.g., if your code registers to receive some callback provided by some service.2False�
�
exports_filter�This attribute contains a list of targets that are claimed to be exported by the current shared library.

Any target deps is already understood to be exported by the shared library. This attribute should be used to list any targets that are exported by the shared library but are transitive dependencies of deps.

Note that this attribute is not actually adding a dependency edge to those targets, the dependency edge should instead be created by deps.The entries in this attribute are just strings. Keep in mind that when placing a target in this attribute, this is considered a claim that the shared library exports the symbols from that target. The cc_shared_library logic doesn't actually handle telling the linker which symbols should be exported.

The following syntax is allowed:

//foo:__pkg__ to account for any target in foo/BUILD

//foo:__subpackages__ to account for any target in foo/BUILD or any other package below foo/ like foo/bar/BUILD2[]&
$
roots(Not yet implemented)2[]�
�
shared_lib_name�Specify the name of the created SOL file (that is decoupled from the rule instance name).
Note, that the 'cc_so' is opinionated and will remove any leading 'lib' prefix and any '.so' in the name
(meaning 'libTest.so.x64.so' will become 'Test.x64' and will produce 'libTest.x64.so')2""�
�
data�The list of files needed by this target at runtime. See general comments about data at Typical attributes defined by most build rules.2[]:
8
deps*The list of dependencies of current target2[]'
%
srcsThe list of source files. �
�
hdrstList of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.2[]�
�
implementation_hdrsjList of headers that CANNOT be included by dependent rules.
Notice: the cutoff happens during compilation.2[]�
�
hdrs_map�Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory.2{}�
�
module_interfaces�The list of files that are regarded as C++20 Modules Interface.

C++ Standard has no restriction about module interface file extension
* Clang use cppm
* GCC can use any source file extension
* MSVC use ixx

The use is guarded by the flag --experimental_cpp_modules.2[]�
�
win_def_file�The Windows DEF file to be passed to linker.

This attribute should only be used when Windows is the target platform. It can be used to export symbols during linking a shared library.2None�
�
additional_compiler_inputs�Any additional files you might want to pass to the compiler command line, such as sanitizer ignorelists, for example.
Files specified here can then be used in copts with the $(location) function.2[]�
�
additional_linker_inputs�Any additional files that you may want to pass to the linker, for example, linker scripts.
You have to separately pass any linker flags that the linker needs in order to be aware of this file.
You can do so via the linkopts attribute.2[]�
�
	conlyoptsvAdd these options to the C compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.2[]�
�
copts�Add these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.
Each string in this attribute is added in the given order to COPTS before compiling the binary target. The flags take effect only for compiling this target, not its dependencies, so be careful about header files included elsewhere. All paths should be relative to the workspace, not to the current package.

If the package declares the feature no_copts_tokenization, Bourne shell tokenization applies only to strings that consist of a single "Make" variable.2[]�
�
cxxoptsxAdd these options to the C++ compilation command. Subject to "Make variable" substitution and Bourne shell tokenization.2[]�
�
defines�List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line to this target, as well as to every rule that depends on it. Be very careful, since this may have far-reaching effects. When in doubt, add define values to local_defines instead.2[]�
�
dynamic_deps�In contrast to `rules_cc`, the dynamic_deps of `rules_cc_hdrs_map` are simply translated into deps parameter,
and the providers (CcInfo vs CcSharedInfo) are used to steer the behavior further.2[]�
�
implementation_deps�The list of other libraries that the library target depends on. Unlike with deps, the headers and include paths of these libraries (and all their transitive deps) are only used for compilation of this library, and not libraries that depend on it. Libraries specified with implementation_deps are still linked in binary targets that depend on this library.2[]�
�
includes�List of include dirs to be added to the compile line.
Subject to "Make variable" substitution. Each string is prepended with -isystem and added to COPTS. Unlike COPTS, these flags are added for this rule and every rule that depends on it. (Note: not the rules it depends upon!) Be very careful, since this may have far-reaching effects. When in doubt, add "-I" flags to COPTS instead.

Headers must be added to srcs or hdrs, otherwise they will not be available to dependent rules when compilation is sandboxed (the default).2[]�
�
link_extra_lib�Control linking of extra libraries.

By default, C++ binaries are linked against //tools/cpp:link_extra_lib, which by default depends on the label flag //tools/cpp:link_extra_libs. Without setting the flag, this library is empty by default. Setting the label flag allows linking optional dependencies, such as overrides for weak symbols, interceptors for shared library functions, or special runtime libraries (for malloc replacements, prefer malloc or --custom_malloc). Setting this attribute to None disables this behaviour.2None�
�
linkopts�Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.2[]�
�

linksharedwCreate a shared library. To enable this attribute, include linkshared=True in your rule. By default this option is off.2False�
�
	linkstamp�Simultaneously compiles and links the specified C++ source file into the final binary. This trickery is required to introduce timestamp information into binaries; if we compiled the source file to an object file in the usual way, the timestamp would be incorrect. A linkstamp compilation may not include any particular set of compiler flags and so should not depend on any particular header, compiler option, or other build variable. This option should only be needed in the base package.2None�
�

linkstatic�If enabled and this is a binary or test, this option tells the build tool to link in .a's instead of .so's for user libraries whenever possible. System libraries such as libc (but not the C/C++ runtime libraries, see below) are still linked dynamically, as are libraries for which there is no static library. So the resulting executable will still be dynamically linked, hence only mostly static.
The linkstatic attribute has a different meaning if used on a cc_library() rule. For a C++ library, linkstatic=True indicates that only static linking is allowed, so no .so will be produced. linkstatic=False does not prevent static libraries from being created. The attribute is meant to control the creation of dynamic libraries.2False�
�
local_defines�List of defines to add to the compile line. Subject to "Make" variable substitution and Bourne shell tokenization. Each string, which must consist of a single Bourne shell token, is prepended with -D and added to the compile command line for this target, but not to its dependents.2[]�
�
malloc�Override the default dependency on malloc.

By default, C++ binaries are linked against //tools/cpp:malloc, which is an empty library so the binary ends up using libc malloc. This label must refer to a cc_library. If compilation is for a non-C++ rule, this option has no effect. The value of this attribute is ignored if linkshared=True is specified.2None�
�
nocopts�Remove matching options from the C++ compilation command. Subject to "Make" variable substitution. The value of this attribute is interpreted as a regular expression. Any preexisting COPTS that match this regular expression (including values explicitly specified in the rule's copts attribute) will be removed from COPTS for purposes of compiling this rule. This attribute should not be needed or used outside of third_party. The values are not preprocessed in any way other than the "Make" variable substitution.2""�
�
include_prefix�The prefix to add to the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at is the value of this attribute prepended to their repository-relative path.

The prefix in the strip_include_prefix attribute is removed before this prefix is added.2""�
�
strip_include_prefix�The prefix to strip from the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at their path with this prefix cut off.

If it's a relative path, it's taken as a package-relative one. If it's an absolute one, it's understood as a repository-relative path.

The prefix in the include_prefix attribute is added after this prefix is stripped.2""�
�
textual_hdrs�The list of header files published by this library to be textually included by sources in dependent rules.

This is the location for declaring header files that cannot be compiled on their own; that is, they always need to be textually included by other source files to build valid code.2[]�9cc_so_import�Import precompiled C/C++ shared object library.

The intended difference between this rule and the rules_cc's cc_import is to directly
provide CcSharedLibrary info to force linking and early deps cutoff."�7
�
cc_so_import�Import precompiled C/C++ shared object library.

The intended difference between this rule and the rules_cc's cc_import is to directly
provide CcSharedLibrary info to force linking and early deps cutoff.*
nameA unique name for this target. �
shared_librarytA single precompiled shared library. This ruleset will ensure it will be available to depending cc_hdrs_map targets. t
cascade`Please DO NOT USE. This makes the SOL being propagated upwards to every dependee of this target.2False�
data�The list of files needed by this target at runtime. See general comments about data at Typical attributes defined by most build rules.2[]8
deps*The list of dependencies of current target2[]�
hdrstList of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.2[]�
hdrs_map�Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory.2{}�
additional_linker_inputs�Any additional files that you may want to pass to the linker, for example, linker scripts.
You have to separately pass any linker flags that the linker needs in order to be aware of this file.
You can do so via the linkopts attribute.2[]�
dynamic_deps�In contrast to `rules_cc`, the dynamic_deps of `rules_cc_hdrs_map` are simply translated into deps parameter,
and the providers (CcInfo vs CcSharedInfo) are used to steer the behavior further.2[]�
implementation_deps�The list of other libraries that the library target depends on. Unlike with deps, the headers and include paths of these libraries (and all their transitive deps) are only used for compilation of this library, and not libraries that depend on it. Libraries specified with implementation_deps are still linked in binary targets that depend on this library.2[]�
linkopts�Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.2[]�
include_prefix�The prefix to add to the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at is the value of this attribute prepended to their repository-relative path.

The prefix in the strip_include_prefix attribute is removed before this prefix is added.2""�
strip_include_prefix�The prefix to strip from the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at their path with this prefix cut off.

If it's a relative path, it's taken as a package-relative one. If it's an absolute one, it's understood as a repository-relative path.

The prefix in the include_prefix attribute is added after this prefix is stripped.2"""H
cc_so_import8@rules_cc_hdrs_map//cc_hdrs_map/private:cc_so_import.bzl*�
DefaultInfo
CcSharedLibraryInfo
HdrsMapInfo
DefaultInfo<native>D
CcSharedLibraryInfo-@@_builtins//:common/cc/cc_shared_library.bzlJ
HdrsMapInfo;@rules_cc_hdrs_map//cc_hdrs_map/providers:hdrs_map_info.bzl,
*
nameA unique name for this target. �
�
shared_librarytA single precompiled shared library. This ruleset will ensure it will be available to depending cc_hdrs_map targets. v
t
cascade`Please DO NOT USE. This makes the SOL being propagated upwards to every dependee of this target.2False�
�
data�The list of files needed by this target at runtime. See general comments about data at Typical attributes defined by most build rules.2[]:
8
deps*The list of dependencies of current target2[]�
�
hdrstList of headers that may be included by dependent rules transitively.
Notice: the cutoff happens during compilation.2[]�
�
hdrs_map�Dictionary describing paths under which header files should be avaiable as.

Keys are simple glob pathnames, used to match agains all header files avaiable in the rule.
Values are list of paths to which matching header files should be mapped.

'{filename}' is special token used to signify to matching file name.

For example:
'"**/*o.hpp": ["a/{filename}"]' - will ensure all hpp files with names ending with '0'
will be also avaible as if they were placed in a subdirectory.2{}�
�
additional_linker_inputs�Any additional files that you may want to pass to the linker, for example, linker scripts.
You have to separately pass any linker flags that the linker needs in order to be aware of this file.
You can do so via the linkopts attribute.2[]�
�
dynamic_deps�In contrast to `rules_cc`, the dynamic_deps of `rules_cc_hdrs_map` are simply translated into deps parameter,
and the providers (CcInfo vs CcSharedInfo) are used to steer the behavior further.2[]�
�
implementation_deps�The list of other libraries that the library target depends on. Unlike with deps, the headers and include paths of these libraries (and all their transitive deps) are only used for compilation of this library, and not libraries that depend on it. Libraries specified with implementation_deps are still linked in binary targets that depend on this library.2[]�
�
linkopts�Add these flags to the C++ linker command. Subject to "Make" variable substitution, Bourne shell tokenization and label expansion. Each string in this attribute is added to LINKOPTS before linking the binary target.
Each element of this list that does not start with $ or - is assumed to be the label of a target in deps. The list of files generated by that target is appended to the linker options. An error is reported if the label is invalid, or is not declared in deps.2[]�
�
include_prefix�The prefix to add to the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at is the value of this attribute prepended to their repository-relative path.

The prefix in the strip_include_prefix attribute is removed before this prefix is added.2""�
�
strip_include_prefix�The prefix to strip from the paths of the headers of this rule.
When set, the headers in the hdrs attribute of this rule are accessible at their path with this prefix cut off.

If it's a relative path, it's taken as a package-relative one. If it's an absolute one, it's understood as a repository-relative path.

The prefix in the include_prefix attribute is added after this prefix is stripped.2""�)providers_helper.materialize_hdrs_mapping�Materialize the expected file hierarchy.

Creates the header file hierarchy accordingly to specifications
in passed-in hdrs_map under 'vhm' directory.
*�
�
)providers_helper.materialize_hdrs_mapping6
invoker_label!label of rule invoking the method ( 
actionsbazel ctx.actions (<
hdrs_map,HdrsMapInfo representing the headers mapping (K
hdrs?list of all header files that should be matched against the map (�Materialize the expected file hierarchy.

Creates the header file hierarchy accordingly to specifications
in passed-in hdrs_map under 'vhm' directory.
"�
�(materialized_include_path, materialized_hdrs_files): tuple of include_path to
the created header files dir and list of paths to all header files created.2R
materialize_hdrs_mapping6@rules_cc_hdrs_map//cc_hdrs_map/providers:hdrs_map.bzl8
6
invoker_label!label of rule invoking the method ("
 
actionsbazel ctx.actions (>
<
hdrs_map,HdrsMapInfo representing the headers mapping (M
K
hdrs?list of all header files that should be matched against the map (�
.providers_helper.merge_cc_shared_library_infos?Merge CcSharedLibraryInfos from targets into singualr provider.*�	
�
.providers_helper.merge_cc_shared_library_infos~
targetsmlist of Bazel targets that should be merged. They must
contain either CcInfo or CcSharedLibraryInfo provider.[](Q
dynamic_deps9sequence of Depsets representing additional dynamic deps.None(I
exports6cc_libraries that are linked statically and exported".None(S
linker_input;the resultign linker inptu artifact for the shared library.None(s
link_once_static_libsRall libraries linked statically into this library that should
only be linked once.None(?Merge CcSharedLibraryInfos from targets into singualr provider."
CcSharedLibraryInfo provider.2e
merge_cc_shared_library_infosD@rules_cc_hdrs_map//cc_hdrs_map/providers:cc_shared_library_info.bzl�
~
targetsmlist of Bazel targets that should be merged. They must
contain either CcInfo or CcSharedLibraryInfo provider.[](S
Q
dynamic_deps9sequence of Depsets representing additional dynamic deps.None(K
I
exports6cc_libraries that are linked statically and exported".None(U
S
linker_input;the resultign linker inptu artifact for the shared library.None(u
s
link_once_static_libsRall libraries linked statically into this library that should
only be linked once.None(�	%providers_helper.merge_hdrs_map_infos?Merge all HdrsMapInfo providers from targets into singular one.*�
�
%providers_helper.merge_hdrs_map_infos
targets[](3
hdrs#additional header files to include,None(L
implementation_hdrs-additional implementation headers to include,None(F
hdrs_map2initial hdrs_map to use as a foundation for merge,None(<
hdrs_map_deps#additional dependencies to include,None(g
pin_down_non_globsIwheather the final hdrs_map should have its
non_glob dependencies pinned.True(?Merge all HdrsMapInfo providers from targets into singular one."N
LHdrsMapInfo provider that represents merge of all HdrsMapInfos from targets.2S
merge_hdrs_map_infos;@rules_cc_hdrs_map//cc_hdrs_map/providers:hdrs_map_info.bzl

targets[](5
3
hdrs#additional header files to include,None(N
L
implementation_hdrs-additional implementation headers to include,None(H
F
hdrs_map2initial hdrs_map to use as a foundation for merge,None(>
<
hdrs_map_deps#additional dependencies to include,None(i
g
pin_down_non_globsIwheather the final hdrs_map should have its
non_glob dependencies pinned.True(�providers_helper.new_hdrs_map&Create new instance of HdrsMap struct.*�
�
providers_helper.new_hdrs_map
	from_dict{}(
_globNone(
	_non_globNone(&Create new instance of HdrsMap struct.2F
new_hdrs_map6@rules_cc_hdrs_map//cc_hdrs_map/providers:hdrs_map.bzl

	from_dict{}(

_globNone(

	_non_globNone(�5providers_helper.quotient_map_cc_shared_library_infos�Transform list of Bazel targets into CcSharedLibrayInfo attribue groups.

For given list of Bazel targets, attributes relating to CcSharedLibraryInfo
(dynamic_deps, exports, linker_inputs, link_once_static_libs) will be extracted
from said targets and the output will contain groups of that values.
*�
�
5providers_helper.quotient_map_cc_shared_library_infos~
targetsmlist of Bazel targets that should be mapped. They must
contain either CcInfo or CcSharedLibraryInfo provider.[](Q
dynamic_deps9sequence of Depsets representing additional dynamic deps.None(I
exports6cc_libraries that are linked statically and exported".None(S
linker_input;the resultign linker inptu artifact for the shared library.None(s
link_once_static_libsRall libraries linked statically into this library that should
only be linked once.None(�Transform list of Bazel targets into CcSharedLibrayInfo attribue groups.

For given list of Bazel targets, attributes relating to CcSharedLibraryInfo
(dynamic_deps, exports, linker_inputs, link_once_static_libs) will be extracted
from said targets and the output will contain groups of that values.
"?
=(dynamic_deps, exports, linker_inptuts, link_once_static_lib)2l
$quotient_map_cc_shared_library_infosD@rules_cc_hdrs_map//cc_hdrs_map/providers:cc_shared_library_info.bzl�
~
targetsmlist of Bazel targets that should be mapped. They must
contain either CcInfo or CcSharedLibraryInfo provider.[](S
Q
dynamic_deps9sequence of Depsets representing additional dynamic deps.None(K
I
exports6cc_libraries that are linked statically and exported".None(U
S
linker_input;the resultign linker inptu artifact for the shared library.None(u
s
link_once_static_libsRall libraries linked statically into this library that should
only be linked once.None(�,providers_helper.quotient_map_hdrs_map_infos7Take all HdrsMapInfo key-values and group them by keys.*�
�
,providers_helper.quotient_map_hdrs_map_infos
targets[](3
hdrs#additional header files to include,None(L
implementation_hdrs-additional implementation headers to include,None(F
hdrs_map2initial hdrs_map to use as a foundation for merge,None(;
hdrs_map_deps"additional dependencies to includeNone(D
traverse_deps+wheather to gather HdrsMapInfos transitvelyTrue(7Take all HdrsMapInfo key-values and group them by keys."=
;(hdrs, implementation_hdrs, hdrs_map, hdr_maps_deps): tuple2Z
quotient_map_hdrs_map_infos;@rules_cc_hdrs_map//cc_hdrs_map/providers:hdrs_map_info.bzl

targets[](5
3
hdrs#additional header files to include,None(N
L
implementation_hdrs-additional implementation headers to include,None(H
F
hdrs_map2initial hdrs_map to use as a foundation for merge,None(=
;
hdrs_map_deps"additional dependencies to includeNone(F
D
traverse_deps+wheather to gather HdrsMapInfos transitvelyTrue(�actions.compile_kwargs*�
i
actions.compile_kwargs	
ctx (

rule_attrs (220@rules_cc_hdrs_map//cc_hdrs_map/actions:defs.bzl
	
ctx (


rule_attrs (�actions.link_to_archive_kwargs*�
q
actions.link_to_archive_kwargs	
ctx (

rule_attrs (220@rules_cc_hdrs_map//cc_hdrs_map/actions:defs.bzl
	
ctx (


rule_attrs (�actions.link_to_binary_kwargs*�
p
actions.link_to_binary_kwargs	
ctx (

rule_attrs (220@rules_cc_hdrs_map//cc_hdrs_map/actions:defs.bzl
	
ctx (


rule_attrs (�actions.link_to_so_kwargs*�
l
actions.link_to_so_kwargs	
ctx (

rule_attrs (220@rules_cc_hdrs_map//cc_hdrs_map/actions:defs.bzl
	
ctx (


rule_attrs (�actions.prepare_for_compilation�Materialize information from hdrs map.

This function creates a epheremal directory, that contains all of the
patterns specified within hdrs_map providers, thus making them all
available under singular, temporary include statment.
*�
�
actions.prepare_for_compilation
sctxsubrule context (i
input_hdrs_mapSlist of HdrsMapInfo which should be used for materialization of compilation context (7

input_hdrs%direct headers provided to the action (F
input_implementation_hdrs%direct headers provided to the action (7

input_deps%dependencies specified for the action (A
input_includes+include statements specified for the action (�Materialize information from hdrs map.

This function creates a epheremal directory, that contains all of the
patterns specified within hdrs_map providers, thus making them all
available under singular, temporary include statment.
2Q
_prepare_for_compilation5@rules_cc_hdrs_map//cc_hdrs_map/actions:cc_helper.bzl

sctxsubrule context (k
i
input_hdrs_mapSlist of HdrsMapInfo which should be used for materialization of compilation context (9
7

input_hdrs%direct headers provided to the action (H
F
input_implementation_hdrs%direct headers provided to the action (9
7

input_deps%dependencies specified for the action (C
A
input_includes+include statements specified for the action (�(cc_helper.expand_make_variables_in_copts*�
�
(cc_helper.expand_make_variables_in_copts	
ctx (
cc_info (
action_kwargs (

opts (2X
_expand_make_variables_in_copts5@rules_cc_hdrs_map//cc_hdrs_map/actions:cc_helper.bzl
	
ctx (

cc_info (

action_kwargs (


opts (�*cc_helper.expand_make_variables_in_defines*�
�
*cc_helper.expand_make_variables_in_defines	
ctx (
cc_info (
action_kwargs (
defines (
localFalse(2Z
!_expand_make_variables_in_defines5@rules_cc_hdrs_map//cc_hdrs_map/actions:cc_helper.bzl
	
ctx (

cc_info (

action_kwargs (

defines (

localFalse(�+cc_helper.expand_make_variables_in_linkopts*�
�
+cc_helper.expand_make_variables_in_linkopts	
ctx (
cc_info (
action_kwargs (

opts (2[
"_expand_make_variables_in_linkopts5@rules_cc_hdrs_map//cc_hdrs_map/actions:cc_helper.bzl
	
ctx (

cc_info (

action_kwargs (


opts (cc_helper.extensions.cc_header*[
Y
cc_helper.extensions.cc_header275@rules_cc_hdrs_map//cc_hdrs_map/actions:cc_helper.bzlcc_helper.extensions.cc_source*[
Y
cc_helper.extensions.cc_source275@rules_cc_hdrs_map//cc_hdrs_map/actions:cc_helper.bzl�cc_helper.extract_headers*�
s
cc_helper.extract_headers
files (2I
_extract_headers5@rules_cc_hdrs_map//cc_hdrs_map/actions:cc_helper.bzl

files (�cc_helper.extract_sources*�
s
cc_helper.extract_sources
files (2I
_extract_sources5@rules_cc_hdrs_map//cc_hdrs_map/actions:cc_helper.bzl

files (�$cc_helper.get_cc_flags_make_variable*�
�
$cc_helper.get_cc_flags_make_variable
cc_toolchain (
feature_configuration (2T
_get_cc_flags_make_variable5@rules_cc_hdrs_map//cc_hdrs_map/actions:cc_helper.bzl

cc_toolchain (

feature_configuration (�!cc_helper.get_compilation_defines*�
�
!cc_helper.get_compilation_defines	
ctx (
defines[](
deps[](.
&additional_make_variable_substitutions{}(
additional_targets[](2Q
_get_compilation_defines5@rules_cc_hdrs_map//cc_hdrs_map/actions:cc_helper.bzl
	
ctx (

defines[](

deps[](0
.
&additional_make_variable_substitutions{}(

additional_targets[](�cc_helper.get_compilation_opts*�
�
cc_helper.get_compilation_opts	
ctx (

opts (
feature_configuration (.
&additional_make_variable_substitutions{}(
additional_inputs[](2N
_get_compilation_opts5@rules_cc_hdrs_map//cc_hdrs_map/actions:cc_helper.bzl
	
ctx (


opts (

feature_configuration (0
.
&additional_make_variable_substitutions{}(

additional_inputs[](�cc_helper.get_linking_opts*�
�
cc_helper.get_linking_opts	
ctx (

opts (.
&additional_make_variable_substitutions{}(
additional_inputs[](2J
_get_linking_opts5@rules_cc_hdrs_map//cc_hdrs_map/actions:cc_helper.bzl
	
ctx (


opts (0
.
&additional_make_variable_substitutions{}(

additional_inputs[](�/cc_helper.get_local_defines_for_runfiles_lookup*�
�
/cc_helper.get_local_defines_for_runfiles_lookup	
ctx (
all_deps (2_
&_get_local_defines_for_runfiles_lookup5@rules_cc_hdrs_map//cc_hdrs_map/actions:cc_helper.bzl
	
ctx (

all_deps (�-cc_helper.get_toolchain_global_make_variables*�
�
-cc_helper.get_toolchain_global_make_variables
cc_toolchain (2]
$_get_toolchain_global_make_variables5@rules_cc_hdrs_map//cc_hdrs_map/actions:cc_helper.bzl

cc_toolchain (�!cc_helper.prepare_for_compilation�Materialize information from hdrs map.

This function creates a epheremal directory, that contains all of the
patterns specified within hdrs_map providers, thus making them all
available under singular, temporary include statment.
*�
�
!cc_helper.prepare_for_compilation
sctxsubrule context (i
input_hdrs_mapSlist of HdrsMapInfo which should be used for materialization of compilation context (7

input_hdrs%direct headers provided to the action (F
input_implementation_hdrs%direct headers provided to the action (7

input_deps%dependencies specified for the action (A
input_includes+include statements specified for the action (�Materialize information from hdrs map.

This function creates a epheremal directory, that contains all of the
patterns specified within hdrs_map providers, thus making them all
available under singular, temporary include statment.
2Q
_prepare_for_compilation5@rules_cc_hdrs_map//cc_hdrs_map/actions:cc_helper.bzl

sctxsubrule context (k
i
input_hdrs_mapSlist of HdrsMapInfo which should be used for materialization of compilation context (9
7

input_hdrs%direct headers provided to the action (H
F
input_implementation_hdrs%direct headers provided to the action (9
7

input_deps%dependencies specified for the action (C
A
input_includes+include statements specified for the action (�CascadingCcSharedLibraryInfoXRepresents CcSharedLibrary that should cascade and be link in every transitive dependee.2�
�
CascadingCcSharedLibraryInfoXRepresents CcSharedLibrary that should cascade and be link in every transitive dependee.h
cc_shared_library_infosM[] of CcSharedLibraryInfo providers that describes what needs to be cascaded."n
CascadingCcSharedLibraryInfoN@rules_cc_hdrs_map//cc_hdrs_map/providers:cascading_cc_shared_library_info.bzlj
h
cc_shared_library_infosM[] of CcSharedLibraryInfo providers that describes what needs to be cascaded.�HdrsMapInfoTRepresents grouping of CC header files, alongsdie with their intended include paths.2�
�
HdrsMapInfoTRepresents grouping of CC header files, alongsdie with their intended include paths.F
hdrs>Headers which should be exposed after the compilation is done.S
implementation_hdrs<Headers that should not be propagated after the compilation.L
hdrs_map@(hdrs_map struct) object describing desired header file mappingsw
depsoCcInfo/CcSharedLibraryInfo-aware dependencies that need to be propagated, for this provider to compile and link"J
HdrsMapInfo;@rules_cc_hdrs_map//cc_hdrs_map/providers:hdrs_map_info.bzlH
F
hdrs>Headers which should be exposed after the compilation is done.U
S
implementation_hdrs<Headers that should not be propagated after the compilation.N
L
hdrs_map@(hdrs_map struct) object describing desired header file mappingsy
w
depsoCcInfo/CcSharedLibraryInfo-aware dependencies that need to be propagated, for this provider to compile and link�rules_cc_hdrs_map
---
[![ci](https://github.com/AleksanderGondek/rules_cc_hdrs_map/actions/workflows/ci.yaml/badge.svg)](https://github.com/AleksanderGondek/rules_cc_hdrs_map/actions/workflows/ci.yaml)

This project extends Bazel `CC` build capabilities with headers map implementation (allowing for easy support for most bizzare include path schemes).

In addition, it exposes CC compilation and linking functions in form of Bazel [subrules](https://docs.google.com/document/d/1RbNC88QieKvBEwir7iV5zZU08AaMlOzxhVkPnmKDedQ).

See [examples](/examples) for how to use `rules_cc_hdrs_map` (and why).

## Shortest possible example

```
$ cat foo.hpp
const std::string GREETINGS = "Hello";

$ cat foo.cpp
#include "bar/foo.h"
...

$ cat BUILD.bazel
load("@rules_cc_hdrs_map//cc_hdrs_map:defs.bzl", "cc_bin")

cc_bin(
    name = "foo",
    srcs = [
        "foo.cpp",
        "foo.hpp",
    ],
    hdrs_map = {
        "**/foo.hpp": ["bar/{filename}"],
    }
)

```

## Table of contents
1. [What issue is being addressed?](#what-issue-is-being-addressed)
2. [How the issue is being addressed?](#what-issue-is-being-addressed)
3. [What issue is being addressed?](#how-the-issue-is-being-addressed)
4. Rules
    1. [cc_archive](#cc_archive)
    2. [cc_bin](#cc_bin)
    3. [cc_hdrs](#cc_hdrs)
    4. [cc_so](#cc_so)
5. [HdrsMapInfo provider](#hdrsmapinfo)

## What issue is being addressed?

Creation of arbitrary include paths from existing sources.

_Scenario_: we want to build a C/CPP codebase with Bazel.

One of its key characteristics is that most of the include statements do not reflect the code structure in the project - for example, header file located under path “name/a.hpp” is never included as “name/a.hpp”, instead an arbitrary list of aliases is used in the code (“x/y/z/a.hpp”, “b.hpp” etc.).  There is no overarching convention that could be used to generalize those statements into another file file hierarchy - in other words, every header file is a special case of its own.

Unfortunately we are forbidden from modifying the code itself and the directory structure (hello from enterprise word).

As Bazel `rules_cc` have the expectation of header files being included in a way that resembles the file structure in the WORKSPACE (and one can only provide single “include prefix” per library), we need to prepare the “expected file structure” before passing them into the `rules_cc`.

In the most naive approach, said “expected file structure” is being prepared for each compilable target (copying over files), passing on the already created structure to targets that depend on it. Very quickly conflicts occur and change of a single header file may cascade into rebuilding hundreds of targets.

There has to be a better way!

## How the issue is being addressed?

The concept of header map is introduced - it is a dictionary, containing mapping between simple glob paths and their desired include paths. For example: “**/a.hpp”: “x/y/z/a.hpp” expresses the intent to import any header file with name “a.hpp”, present during compilation , as “x/y/z/a.hpp”.

Said header map is propagated across all compatible C/C++ rules (meaning those from this WORKSPACE) and is being merged with all other header maps present.

No action is being performed up until the moment of compilation - header mappings, resulting from the header map dictionary, are created only for the purposes of compilation and are _NOT_ part of any rule output. This ensures the impact for the Bazel cache is minimal and the compatibility with original `rules_cc`. 