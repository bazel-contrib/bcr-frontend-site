�L
)
rules_codeownerstoolscodeowners.bzl�
codeowners�
A codeowners-rule represents one or many rows in a CODEOWNERS file.

`team` and `teams` are mutually exclusive.
`pattern` and `patterns` are mutually exclusive.
`unowned` can not be combined with `team` or `teams`.

The `global_owners` of the `generate_codeowners` are added to the rows, unless `include_global_owners = False`
or `unowned = True`.
"�
�

codeowners�
A codeowners-rule represents one or many rows in a CODEOWNERS file.

`team` and `teams` are mutually exclusive.
`pattern` and `patterns` are mutually exclusive.
`unowned` can not be combined with `team` or `teams`.

The `global_owners` of the `generate_codeowners` are added to the rows, unless `include_global_owners = False`
or `unowned = True`.
*
nameA unique name for this target. �
commentvA comment to print above the rows, after a blank line. Each line of it becomes a `#` line in the generated CODEOWNERS.2""x
include_global_ownersWSet to False to not add the `global_owners` of the `generate_codeowners` to these rows.2True�
pattern�A pattern of files (eg: '*.bzl') that the team(s) should get ownership of. In the generated CODEOWNERS, the path to this target will be prepended to the pattern. A pattern starting with `//` is anchored at the root of the repository instead, eg `//docs/foo/` becomes `/docs/foo/`, so a package can own files outside of it.2""o
patterns]A list of patterns, one row will be printed per pattern. See docs of `pattern` for more info.2[]z
teamlThe GitHub team that should get ownership of the matching files. One of team, teams and unowned must be set.2""�
teamswA list of the GitHub teams that should get ownership of the matching files. One of team, teams and unowned must be set.2[]�
unowned�Set to True to explicitly mark the matching files as having no owner. The row is written without any teams, which overrides ownership from earlier rows. Can not be combined with team or teams.2False"6

codeowners(@@rules_codeowners//tools:codeowners.bzl
��,
*
nameA unique name for this target. �
�
commentvA comment to print above the rows, after a blank line. Each line of it becomes a `#` line in the generated CODEOWNERS.2""z
x
include_global_ownersWSet to False to not add the `global_owners` of the `generate_codeowners` to these rows.2True�
�
pattern�A pattern of files (eg: '*.bzl') that the team(s) should get ownership of. In the generated CODEOWNERS, the path to this target will be prepended to the pattern. A pattern starting with `//` is anchored at the root of the repository instead, eg `//docs/foo/` becomes `/docs/foo/`, so a package can own files outside of it.2""q
o
patterns]A list of patterns, one row will be printed per pattern. See docs of `pattern` for more info.2[]|
z
teamlThe GitHub team that should get ownership of the matching files. One of team, teams and unowned must be set.2""�
�
teamswA list of the GitHub teams that should get ownership of the matching files. One of team, teams and unowned must be set.2[]�
�
unowned�Set to True to explicitly mark the matching files as having no owner. The row is written without any teams, which overrides ownership from earlier rows. Can not be combined with team or teams.2False�(generate_codeowners�
Creates a GitHub-compatible CODEOWNERS file based on the `owners`.

When `global_owners` is set, a `*` row with the global owners is written first, and the global owners are added to
all other rows (unless the `codeowners` sets `include_global_owners = False`, or `unowned = True`). This includes the
rows of nested `generate_codeowners`, which can not set `global_owners` themselves.

When `fallback_owners` is set, they own the `*` row together with the global owners, but are not added to the other
rows. Use it for the owners of files that no other row matches, instead of a `codeowners` with `pattern = "*"`, which
would come after the `*` row of the global owners and replace it.
"�"
�
generate_codeowners�
Creates a GitHub-compatible CODEOWNERS file based on the `owners`.

When `global_owners` is set, a `*` row with the global owners is written first, and the global owners are added to
all other rows (unless the `codeowners` sets `include_global_owners = False`, or `unowned = True`). This includes the
rows of nested `generate_codeowners`, which can not set `global_owners` themselves.

When `fallback_owners` is set, they own the `*` row together with the global owners, but are not added to the other
rows. Use it for the owners of files that no other row matches, instead of a `codeowners` with `pattern = "*"`, which
would come after the `*` row of the global owners and replace it.
*
nameA unique name for this target. �
allowed_orgs�The GitHub organizations that teams (`@org/team`) can be in, usually the one that owns the repository. When set, a team in any other organization fails the build, since GitHub ignores it in CODEOWNERS. This applies to the rows of nested generate_codeowners, the `global_owners` and the `fallback_owners`. Users and email addresses are always allowed.2[]�
fallback_owners�A list of GitHub teams that own the files that no other row matches. They are written in the `*` row first in the file, followed by the `global_owners`, but not added to any other row. Can not be set on a generate_codeowners that is nested in another.2[]�
generated_comment4A comment to insert at the top of the generated file2O"# This file was generated by rules_codeowners / Bazel. Don't edit it directly"�
global_owners�A list of GitHub teams that own all files. They are written as a `*` row first in the file, and added to the rows of all `codeowners`, so that they can approve changes everywhere, including the rows of nested generate_codeowners. Can not be set on a generate_codeowners that is nested in another.2[]�
owners�A list of codeowners and generate_codeowners. One generate_codeowners can include another generate_codeowners to achieve nested rules. *
CodeownersInfo�
sort_owners�Set to True to sort the owners of each row (by their bytes, after the `global_owners` are added), and remove duplicate owners. The `*` row is sorted too. This applies to the rows of nested generate_codeowners too.2False�
validate�Set to True to fail the build when a row is outside the package of its `codeowners`, which a pattern starting with `//` allows. This applies to the rows of nested generate_codeowners too.2False"?
generate_codeowners(@@rules_codeowners//tools:codeowners.bzl
��,
*
nameA unique name for this target. �
�
allowed_orgs�The GitHub organizations that teams (`@org/team`) can be in, usually the one that owns the repository. When set, a team in any other organization fails the build, since GitHub ignores it in CODEOWNERS. This applies to the rows of nested generate_codeowners, the `global_owners` and the `fallback_owners`. Users and email addresses are always allowed.2[]�
�
fallback_owners�A list of GitHub teams that own the files that no other row matches. They are written in the `*` row first in the file, followed by the `global_owners`, but not added to any other row. Can not be set on a generate_codeowners that is nested in another.2[]�
�
generated_comment4A comment to insert at the top of the generated file2O"# This file was generated by rules_codeowners / Bazel. Don't edit it directly"�
�
global_owners�A list of GitHub teams that own all files. They are written as a `*` row first in the file, and added to the rows of all `codeowners`, so that they can approve changes everywhere, including the rows of nested generate_codeowners. Can not be set on a generate_codeowners that is nested in another.2[]�
�
owners�A list of codeowners and generate_codeowners. One generate_codeowners can include another generate_codeowners to achieve nested rules. *
CodeownersInfo�
�
sort_owners�Set to True to sort the owners of each row (by their bytes, after the `global_owners` are added), and remove duplicate owners. The `*` row is sorted too. This applies to the rows of nested generate_codeowners too.2False�
�
validate�Set to True to fail the build when a row is outside the package of its `codeowners`, which a pattern starting with `//` allows. This applies to the rows of nested generate_codeowners too.2False�
CodeownersInfo`The CODEOWNERS rows of a codeowners or generate_codeowners target, without the generated header.2�	
�
CodeownersInfo`The CODEOWNERS rows of a codeowners or generate_codeowners target, without the generated header.�
entries�The rows, and the comment and blank lines above them, in order. Each is a struct with:
`text`: the comment or blank line, or None for a row.
`path`: the path of the row, or None for a comment or blank line.
`owners`: the owners of the row.
`include_global_owners`: whether the global_owners of a generate_codeowners should be added to the row.
`label`: the label of the codeowners that wrote the row.
`package_path`: the path of that codeowners' package, which the row is expected to start with.":
CodeownersInfo(@@rules_codeowners//tools:codeowners.bzl
�
�
entries�The rows, and the comment and blank lines above them, in order. Each is a struct with:
`text`: the comment or blank line, or None for a row.
`path`: the path of the row, or None for a comment or blank line.
`owners`: the owners of the row.
`include_global_owners`: whether the global_owners of a generate_codeowners should be added to the row.
`label`: the label of the codeowners that wrote the row.
`package_path`: the path of that codeowners' package, which the row is expected to start with. 