��
(

rules_dartdart/ext/_shareddefs.bzl�Flibrary_builder_library�Compose per-src direct-output codegen + wrapping dart_library.

For builders that emit a fully-formed `.dart` library directly
(LibraryBuilder), not a SharedPart shard. One `dart_codegen` per src,
then a wrapping `dart_library`.


Collects Dart sources and propagates dependency information via `DartInfo`. Does not compile or assemble; consumers co-locate generated sources."�C
�#
library_builder_library�Compose per-src direct-output codegen + wrapping dart_library.

For builders that emit a fully-formed `.dart` library directly
(LibraryBuilder), not a SharedPart shard. One `dart_codegen` per src,
then a wrapping `dart_library`.


Collects Dart sources and propagates dependency information via `DartInfo`. Does not compile or assemble; consumers co-locate generated sources.*
nameA unique name for this target. �
code_assets�Native code assets this package owns (see the `dart_code_asset` rule). Assets declared here propagate to every `dart_binary`/`dart_test` that depends on this library, directly or transitively â matching upstream, where depending on a package gets you its assets with no opt-in. Each `asset_id` must be namespaced to this library's `package_name`.*
DartCodeAssetInfo2[]�
depsuOther `dart_library` targets this library depends on. Their sources and package metadata are propagated transitively.*

DartInfo2[]�
has_unreplaced_hook�Path of a pub build hook (`hook/build.dart` / `hook/link.dart`) this package ships that rules_dart has no replacement for. Set by `pub.from_lock()`; hand-written `dart_library` targets leave it empty. A `dart_binary`/`dart_test` reaching such a package fails with an explanation, rather than producing a binary whose `@Native` bindings silently fail to resolve at runtime.2""�
language_version�Dart language version implied by the package's `environment.sdk` constraint, in `<major>.<minor>` form. Emitted as `languageVersion` in generated `package_config.json` entries. For pub packages this is set automatically by `pub.from_lock()`; for hand-written `dart_library` targets, set it from your workspace's `pubspec.yaml` if you want analyzer behaviour to match.2""�
package�A `dart_package_metadata` declaring this Dart package's `package_name` and `language_version`. Mutually exclusive with the inline `package_name` / `language_version` attributes: set `package` to state those facts once for every rule building this package, or set them inline, but never both. Referencing a target is what lets rules in *different* BUILD files share one declaration, which a macro cannot do.*
DartPackageMetadataInfo2None�
package_name�The Dart package name used in `package:` imports. If omitted, defaults to the last component of the Bazel package path. Set this or `package`, not both.2""�
	resources�Non-Dart files this package ships inside `lib/` â part of its published surface, but never compiled. `package:sky_engine`'s `lib/_embedder.yaml`, which the analyzer reads to resolve `dart:ui`, and `package:dwds`'s `lib/src/injected/client.js`, which it serves to the browser, are both this. Anything under `lib/` is addressable as `package:<name>/<path>` whatever its extension, so these are members of the package, not a consumer's `data`. They are staged wherever the package itself is staged â the analyzer's hermetic project tree â and ride the runfiles of every `dart_binary`/`dart_test` that depends on this library, mirroring pub, where the package directory exists whole on disk at run time. They are never compile inputs. `.dart` files belong in `srcs`; files outside `lib/` have no `package:` URI and belong in a consumer's `data`.2[]�
srcs�Dart source files (`.dart`), source-tree or generated. Typically `glob(["lib/**/*.dart"])`, optionally plus `dart_codegen` outputs. Generated members are co-located with the rest of the package by the consuming `dart_binary`/`dart_test`. Mutually exclusive with `srcs_dir`.2[]�
srcs_dir�A pre-assembled source directory (a `dart_source_set`) to use as this library's package root, instead of `srcs`. The directory is opaque and carries the package's non-Dart files too, so `resources` is rejected alongside it. For reuse/composition; usually you just list files in `srcs`.2None�
version�The package's own version, as resolved by pub (e.g. `2.2.0`). Set automatically by `pub.package()` / `pub.from_lock()`; leave it empty on hand-written targets, which have no resolved version to state. Its only use is agreement checking: when one package name arrives twice â two pub hubs each supplying `ffi`, say â a build whose two records name different versions would otherwise compile against whichever came first in dependency order, silently ignoring the other. Two *known*, differing versions fail the build; an empty one never conflicts.2""
nn,
*
nameA unique name for this target. �
�
code_assets�Native code assets this package owns (see the `dart_code_asset` rule). Assets declared here propagate to every `dart_binary`/`dart_test` that depends on this library, directly or transitively â matching upstream, where depending on a package gets you its assets with no opt-in. Each `asset_id` must be namespaced to this library's `package_name`.*
DartCodeAssetInfo2[]�
�
depsuOther `dart_library` targets this library depends on. Their sources and package metadata are propagated transitively.*

DartInfo2[]�
�
has_unreplaced_hook�Path of a pub build hook (`hook/build.dart` / `hook/link.dart`) this package ships that rules_dart has no replacement for. Set by `pub.from_lock()`; hand-written `dart_library` targets leave it empty. A `dart_binary`/`dart_test` reaching such a package fails with an explanation, rather than producing a binary whose `@Native` bindings silently fail to resolve at runtime.2""�
�
language_version�Dart language version implied by the package's `environment.sdk` constraint, in `<major>.<minor>` form. Emitted as `languageVersion` in generated `package_config.json` entries. For pub packages this is set automatically by `pub.from_lock()`; for hand-written `dart_library` targets, set it from your workspace's `pubspec.yaml` if you want analyzer behaviour to match.2""�
�
package�A `dart_package_metadata` declaring this Dart package's `package_name` and `language_version`. Mutually exclusive with the inline `package_name` / `language_version` attributes: set `package` to state those facts once for every rule building this package, or set them inline, but never both. Referencing a target is what lets rules in *different* BUILD files share one declaration, which a macro cannot do.*
DartPackageMetadataInfo2None�
�
package_name�The Dart package name used in `package:` imports. If omitted, defaults to the last component of the Bazel package path. Set this or `package`, not both.2""�
�
	resources�Non-Dart files this package ships inside `lib/` â part of its published surface, but never compiled. `package:sky_engine`'s `lib/_embedder.yaml`, which the analyzer reads to resolve `dart:ui`, and `package:dwds`'s `lib/src/injected/client.js`, which it serves to the browser, are both this. Anything under `lib/` is addressable as `package:<name>/<path>` whatever its extension, so these are members of the package, not a consumer's `data`. They are staged wherever the package itself is staged â the analyzer's hermetic project tree â and ride the runfiles of every `dart_binary`/`dart_test` that depends on this library, mirroring pub, where the package directory exists whole on disk at run time. They are never compile inputs. `.dart` files belong in `srcs`; files outside `lib/` have no `package:` URI and belong in a consumer's `data`.2[]�
�
srcs�Dart source files (`.dart`), source-tree or generated. Typically `glob(["lib/**/*.dart"])`, optionally plus `dart_codegen` outputs. Generated members are co-located with the rest of the package by the consuming `dart_binary`/`dart_test`. Mutually exclusive with `srcs_dir`.2[]�
�
srcs_dir�A pre-assembled source directory (a `dart_source_set`) to use as this library's package root, instead of `srcs`. The directory is opaque and carries the package's non-Dart files too, so `resources` is rejected alongside it. For reuse/composition; usually you just list files in `srcs`.2None�
�
version�The package's own version, as resolved by pub (e.g. `2.2.0`). Set automatically by `pub.package()` / `pub.from_lock()`; leave it empty on hand-written targets, which have no resolved version to state. Its only use is agreement checking: when one package name arrives twice â two pub hubs each supplying `ffi`, say â a build whose two records name different versions would otherwise compile against whichever came first in dependency order, silently ignoring the other. Two *known*, differing versions fail the build; an empty one never conflicts.2""�Jshared_part_library�Compose per-src SharedPart codegen + combining stage + wrapping dart_library.

One `dart_codegen` per src runs the provided shim to produce a
`.<builder>.g.part` shard; a second `dart_codegen` per src runs the
combining shim over that shard (plus any other `part_suffix` shards
wired by the caller via Gazelle's DAG synthesis) to produce a single
`<src>.g.dart`. The wrapping `dart_library` then includes every
per-src combined output alongside the user's original `srcs`.


Collects Dart sources and propagates dependency information via `DartInfo`. Does not compile or assemble; consumers co-locate generated sources."�E
�$
shared_part_library�Compose per-src SharedPart codegen + combining stage + wrapping dart_library.

One `dart_codegen` per src runs the provided shim to produce a
`.<builder>.g.part` shard; a second `dart_codegen` per src runs the
combining shim over that shard (plus any other `part_suffix` shards
wired by the caller via Gazelle's DAG synthesis) to produce a single
`<src>.g.dart`. The wrapping `dart_library` then includes every
per-src combined output alongside the user's original `srcs`.


Collects Dart sources and propagates dependency information via `DartInfo`. Does not compile or assemble; consumers co-locate generated sources.*
nameA unique name for this target. �
code_assets�Native code assets this package owns (see the `dart_code_asset` rule). Assets declared here propagate to every `dart_binary`/`dart_test` that depends on this library, directly or transitively â matching upstream, where depending on a package gets you its assets with no opt-in. Each `asset_id` must be namespaced to this library's `package_name`.*
DartCodeAssetInfo2[]�
depsuOther `dart_library` targets this library depends on. Their sources and package metadata are propagated transitively.*

DartInfo2[]�
has_unreplaced_hook�Path of a pub build hook (`hook/build.dart` / `hook/link.dart`) this package ships that rules_dart has no replacement for. Set by `pub.from_lock()`; hand-written `dart_library` targets leave it empty. A `dart_binary`/`dart_test` reaching such a package fails with an explanation, rather than producing a binary whose `@Native` bindings silently fail to resolve at runtime.2""�
language_version�Dart language version implied by the package's `environment.sdk` constraint, in `<major>.<minor>` form. Emitted as `languageVersion` in generated `package_config.json` entries. For pub packages this is set automatically by `pub.from_lock()`; for hand-written `dart_library` targets, set it from your workspace's `pubspec.yaml` if you want analyzer behaviour to match.2""�
package�A `dart_package_metadata` declaring this Dart package's `package_name` and `language_version`. Mutually exclusive with the inline `package_name` / `language_version` attributes: set `package` to state those facts once for every rule building this package, or set them inline, but never both. Referencing a target is what lets rules in *different* BUILD files share one declaration, which a macro cannot do.*
DartPackageMetadataInfo2None�
package_name�The Dart package name used in `package:` imports. If omitted, defaults to the last component of the Bazel package path. Set this or `package`, not both.2""�
	resources�Non-Dart files this package ships inside `lib/` â part of its published surface, but never compiled. `package:sky_engine`'s `lib/_embedder.yaml`, which the analyzer reads to resolve `dart:ui`, and `package:dwds`'s `lib/src/injected/client.js`, which it serves to the browser, are both this. Anything under `lib/` is addressable as `package:<name>/<path>` whatever its extension, so these are members of the package, not a consumer's `data`. They are staged wherever the package itself is staged â the analyzer's hermetic project tree â and ride the runfiles of every `dart_binary`/`dart_test` that depends on this library, mirroring pub, where the package directory exists whole on disk at run time. They are never compile inputs. `.dart` files belong in `srcs`; files outside `lib/` have no `package:` URI and belong in a consumer's `data`.2[]�
srcs�Dart source files (`.dart`), source-tree or generated. Typically `glob(["lib/**/*.dart"])`, optionally plus `dart_codegen` outputs. Generated members are co-located with the rest of the package by the consuming `dart_binary`/`dart_test`. Mutually exclusive with `srcs_dir`.2[]�
srcs_dir�A pre-assembled source directory (a `dart_source_set`) to use as this library's package root, instead of `srcs`. The directory is opaque and carries the package's non-Dart files too, so `resources` is rejected alongside it. For reuse/composition; usually you just list files in `srcs`.2None�
version�The package's own version, as resolved by pub (e.g. `2.2.0`). Set automatically by `pub.package()` / `pub.from_lock()`; leave it empty on hand-written targets, which have no resolved version to state. Its only use is agreement checking: when one package name arrives twice â two pub hubs each supplying `ffi`, say â a build whose two records name different versions would otherwise compile against whichever came first in dependency order, silently ignoring the other. Two *known*, differing versions fail the build; an empty one never conflicts.2""
,
*
nameA unique name for this target. �
�
code_assets�Native code assets this package owns (see the `dart_code_asset` rule). Assets declared here propagate to every `dart_binary`/`dart_test` that depends on this library, directly or transitively â matching upstream, where depending on a package gets you its assets with no opt-in. Each `asset_id` must be namespaced to this library's `package_name`.*
DartCodeAssetInfo2[]�
�
depsuOther `dart_library` targets this library depends on. Their sources and package metadata are propagated transitively.*

DartInfo2[]�
�
has_unreplaced_hook�Path of a pub build hook (`hook/build.dart` / `hook/link.dart`) this package ships that rules_dart has no replacement for. Set by `pub.from_lock()`; hand-written `dart_library` targets leave it empty. A `dart_binary`/`dart_test` reaching such a package fails with an explanation, rather than producing a binary whose `@Native` bindings silently fail to resolve at runtime.2""�
�
language_version�Dart language version implied by the package's `environment.sdk` constraint, in `<major>.<minor>` form. Emitted as `languageVersion` in generated `package_config.json` entries. For pub packages this is set automatically by `pub.from_lock()`; for hand-written `dart_library` targets, set it from your workspace's `pubspec.yaml` if you want analyzer behaviour to match.2""�
�
package�A `dart_package_metadata` declaring this Dart package's `package_name` and `language_version`. Mutually exclusive with the inline `package_name` / `language_version` attributes: set `package` to state those facts once for every rule building this package, or set them inline, but never both. Referencing a target is what lets rules in *different* BUILD files share one declaration, which a macro cannot do.*
DartPackageMetadataInfo2None�
�
package_name�The Dart package name used in `package:` imports. If omitted, defaults to the last component of the Bazel package path. Set this or `package`, not both.2""�
�
	resources�Non-Dart files this package ships inside `lib/` â part of its published surface, but never compiled. `package:sky_engine`'s `lib/_embedder.yaml`, which the analyzer reads to resolve `dart:ui`, and `package:dwds`'s `lib/src/injected/client.js`, which it serves to the browser, are both this. Anything under `lib/` is addressable as `package:<name>/<path>` whatever its extension, so these are members of the package, not a consumer's `data`. They are staged wherever the package itself is staged â the analyzer's hermetic project tree â and ride the runfiles of every `dart_binary`/`dart_test` that depends on this library, mirroring pub, where the package directory exists whole on disk at run time. They are never compile inputs. `.dart` files belong in `srcs`; files outside `lib/` have no `package:` URI and belong in a consumer's `data`.2[]�
�
srcs�Dart source files (`.dart`), source-tree or generated. Typically `glob(["lib/**/*.dart"])`, optionally plus `dart_codegen` outputs. Generated members are co-located with the rest of the package by the consuming `dart_binary`/`dart_test`. Mutually exclusive with `srcs_dir`.2[]�
�
srcs_dir�A pre-assembled source directory (a `dart_source_set`) to use as this library's package root, instead of `srcs`. The directory is opaque and carries the package's non-Dart files too, so `resources` is rejected alongside it. For reuse/composition; usually you just list files in `srcs`.2None�
�
version�The package's own version, as resolved by pub (e.g. `2.2.0`). Set automatically by `pub.package()` / `pub.from_lock()`; leave it empty on hand-written targets, which have no resolved version to state. Its only use is agreement checking: when one package name arrives twice â two pub hubs each supplying `ffi`, say â a build whose two records name different versions would otherwise compile against whichever came first in dependency order, silently ignoring the other. Two *known*, differing versions fail the build; an empty one never conflicts.2""�
//dart:defs.bzlr�


rules_dartdartdefs.bzl*
dart_codegendart_codegen
%1*
dart_librarydart_library
5A
C�Composable macros used by per-builder `dart/ext/*/defs.bzl` wrappers.

`shared_part_library` wires the full SharedPart flow: per-src codegen
action emitting a `.<builder>.g.part` shard, per-src combining action
merging any matching shards into `<src>.g.dart`, and a wrapping
`dart_library` that picks up the combined outputs alongside the user's
`srcs`.

`library_builder_library` wires a direct-output builder (LibraryBuilder)
that emits `<src>.<ext>.dart` straight into the source tree (no combining).
�
,

rules_dartdart/ext/built_valuedefs.bzl�built_value_library*�
�
built_value_library

name (

srcs (
package_name""(
language_version""(
deps[](-
annotation_dep"@pub_deps//:built_value"(
config""(

kwargs(2B
built_value_library+@@rules_dart//dart/ext/built_value:defs.bzl
*shared_part_library2shared_part_library�
//dart/ext/_shared:defs.bzlrr
(

rules_dartdart/ext/_shareddefs.bzl8
shared_part_libraryshared_part_library
1D
F.Convenience macro for the built_value builder.�
8

rules_dart dart/ext/copy_with_extension_gendefs.bzl�copy_with_library*�
�
copy_with_library

name (

srcs (
package_name""(
language_version""(
deps[](5
annotation_dep!"@pub_deps//:copy_with_extension"(
config""(

kwargs(2L
copy_with_library7@@rules_dart//dart/ext/copy_with_extension_gen:defs.bzl
*shared_part_library2shared_part_library�
//dart/ext/_shared:defs.bzlrr
(

rules_dartdart/ext/_shareddefs.bzl8
shared_part_libraryshared_part_library
1D
F:Convenience macro for the copy_with_extension_gen builder.�O
&

rules_dartdart/ext/driftdefs.bzl�Cdrift_library�A dart_library augmented by drift_dev's full multi-stage codegen.

Collects Dart sources and propagates dependency information via `DartInfo`. Does not compile or assemble; consumers co-locate generated sources."�A
�!
drift_library�A dart_library augmented by drift_dev's full multi-stage codegen.

Collects Dart sources and propagates dependency information via `DartInfo`. Does not compile or assemble; consumers co-locate generated sources.*
nameA unique name for this target. �
code_assets�Native code assets this package owns (see the `dart_code_asset` rule). Assets declared here propagate to every `dart_binary`/`dart_test` that depends on this library, directly or transitively â matching upstream, where depending on a package gets you its assets with no opt-in. Each `asset_id` must be namespaced to this library's `package_name`.*
DartCodeAssetInfo2[]�
depsuOther `dart_library` targets this library depends on. Their sources and package metadata are propagated transitively.*

DartInfo2[]�
has_unreplaced_hook�Path of a pub build hook (`hook/build.dart` / `hook/link.dart`) this package ships that rules_dart has no replacement for. Set by `pub.from_lock()`; hand-written `dart_library` targets leave it empty. A `dart_binary`/`dart_test` reaching such a package fails with an explanation, rather than producing a binary whose `@Native` bindings silently fail to resolve at runtime.2""�
language_version�Dart language version implied by the package's `environment.sdk` constraint, in `<major>.<minor>` form. Emitted as `languageVersion` in generated `package_config.json` entries. For pub packages this is set automatically by `pub.from_lock()`; for hand-written `dart_library` targets, set it from your workspace's `pubspec.yaml` if you want analyzer behaviour to match.2""�
package�A `dart_package_metadata` declaring this Dart package's `package_name` and `language_version`. Mutually exclusive with the inline `package_name` / `language_version` attributes: set `package` to state those facts once for every rule building this package, or set them inline, but never both. Referencing a target is what lets rules in *different* BUILD files share one declaration, which a macro cannot do.*
DartPackageMetadataInfo2None�
package_name�The Dart package name used in `package:` imports. If omitted, defaults to the last component of the Bazel package path. Set this or `package`, not both.2""�
	resources�Non-Dart files this package ships inside `lib/` â part of its published surface, but never compiled. `package:sky_engine`'s `lib/_embedder.yaml`, which the analyzer reads to resolve `dart:ui`, and `package:dwds`'s `lib/src/injected/client.js`, which it serves to the browser, are both this. Anything under `lib/` is addressable as `package:<name>/<path>` whatever its extension, so these are members of the package, not a consumer's `data`. They are staged wherever the package itself is staged â the analyzer's hermetic project tree â and ride the runfiles of every `dart_binary`/`dart_test` that depends on this library, mirroring pub, where the package directory exists whole on disk at run time. They are never compile inputs. `.dart` files belong in `srcs`; files outside `lib/` have no `package:` URI and belong in a consumer's `data`.2[]�
srcs�Dart source files (`.dart`), source-tree or generated. Typically `glob(["lib/**/*.dart"])`, optionally plus `dart_codegen` outputs. Generated members are co-located with the rest of the package by the consuming `dart_binary`/`dart_test`. Mutually exclusive with `srcs_dir`.2[]�
srcs_dir�A pre-assembled source directory (a `dart_source_set`) to use as this library's package root, instead of `srcs`. The directory is opaque and carries the package's non-Dart files too, so `resources` is rejected alongside it. For reuse/composition; usually you just list files in `srcs`.2None�
version�The package's own version, as resolved by pub (e.g. `2.2.0`). Set automatically by `pub.package()` / `pub.from_lock()`; leave it empty on hand-written targets, which have no resolved version to state. Its only use is agreement checking: when one package name arrives twice â two pub hubs each supplying `ffi`, say â a build whose two records name different versions would otherwise compile against whichever came first in dependency order, silently ignoring the other. Two *known*, differing versions fail the build; an empty one never conflicts.2""
)),
*
nameA unique name for this target. �
�
code_assets�Native code assets this package owns (see the `dart_code_asset` rule). Assets declared here propagate to every `dart_binary`/`dart_test` that depends on this library, directly or transitively â matching upstream, where depending on a package gets you its assets with no opt-in. Each `asset_id` must be namespaced to this library's `package_name`.*
DartCodeAssetInfo2[]�
�
depsuOther `dart_library` targets this library depends on. Their sources and package metadata are propagated transitively.*

DartInfo2[]�
�
has_unreplaced_hook�Path of a pub build hook (`hook/build.dart` / `hook/link.dart`) this package ships that rules_dart has no replacement for. Set by `pub.from_lock()`; hand-written `dart_library` targets leave it empty. A `dart_binary`/`dart_test` reaching such a package fails with an explanation, rather than producing a binary whose `@Native` bindings silently fail to resolve at runtime.2""�
�
language_version�Dart language version implied by the package's `environment.sdk` constraint, in `<major>.<minor>` form. Emitted as `languageVersion` in generated `package_config.json` entries. For pub packages this is set automatically by `pub.from_lock()`; for hand-written `dart_library` targets, set it from your workspace's `pubspec.yaml` if you want analyzer behaviour to match.2""�
�
package�A `dart_package_metadata` declaring this Dart package's `package_name` and `language_version`. Mutually exclusive with the inline `package_name` / `language_version` attributes: set `package` to state those facts once for every rule building this package, or set them inline, but never both. Referencing a target is what lets rules in *different* BUILD files share one declaration, which a macro cannot do.*
DartPackageMetadataInfo2None�
�
package_name�The Dart package name used in `package:` imports. If omitted, defaults to the last component of the Bazel package path. Set this or `package`, not both.2""�
�
	resources�Non-Dart files this package ships inside `lib/` â part of its published surface, but never compiled. `package:sky_engine`'s `lib/_embedder.yaml`, which the analyzer reads to resolve `dart:ui`, and `package:dwds`'s `lib/src/injected/client.js`, which it serves to the browser, are both this. Anything under `lib/` is addressable as `package:<name>/<path>` whatever its extension, so these are members of the package, not a consumer's `data`. They are staged wherever the package itself is staged â the analyzer's hermetic project tree â and ride the runfiles of every `dart_binary`/`dart_test` that depends on this library, mirroring pub, where the package directory exists whole on disk at run time. They are never compile inputs. `.dart` files belong in `srcs`; files outside `lib/` have no `package:` URI and belong in a consumer's `data`.2[]�
�
srcs�Dart source files (`.dart`), source-tree or generated. Typically `glob(["lib/**/*.dart"])`, optionally plus `dart_codegen` outputs. Generated members are co-located with the rest of the package by the consuming `dart_binary`/`dart_test`. Mutually exclusive with `srcs_dir`.2[]�
�
srcs_dir�A pre-assembled source directory (a `dart_source_set`) to use as this library's package root, instead of `srcs`. The directory is opaque and carries the package's non-Dart files too, so `resources` is rejected alongside it. For reuse/composition; usually you just list files in `srcs`.2None�
�
version�The package's own version, as resolved by pub (e.g. `2.2.0`). Set automatically by `pub.package()` / `pub.from_lock()`; leave it empty on hand-written targets, which have no resolved version to state. Its only use is agreement checking: when one package name arrives twice â two pub hubs each supplying `ffi`, say â a build whose two records name different versions would otherwise compile against whichever came first in dependency order, silently ignoring the other. Two *known*, differing versions fail the build; an empty one never conflicts.2""�
//dart:defs.bzlr�


rules_dartdartdefs.bzl*
dart_codegendart_codegen
*
dart_librarydart_library
0
dart_sqlcodegendart_sqlcodegen

�	Convenience macro for drift_dev.

Implements the upstream `drift_dev` 4-stage Builder pipeline on top of
the rules_dart shim-contract primitives:

  1. `shim_prep` (`PreprocessBuilder`) â runs on each `.drift`/`.moor`;
     emits `.drift_prep.json` + `.expr.temp.dart`.
  2. `shim_discover` (`DriftDiscover`) â runs on each `.drift`/`.moor`;
     emits `.drift.drift_elements.json`. Consumed by drift's
     `BuildCacheReader.readDiscovery` (keyed on `.drift_elements.json`).
  3. `shim_analyzer` (`DriftAnalyzer`) â runs on each `.drift`/`.moor`;
     emits `.drift.drift_module.json` + `.drift.types.temp.dart`.
     Consumed by `BuildCacheReader.readElementCacheFor`.
  4. `shim_drift` (`[discover, analyzer, driftBuilder]`) â runs on each
     `.dart` source; emits `.drift.g.part` (SharedPart shard). The dart
     side runs discover+analyzer in-memory; the per-`.drift`-file stages
     above are required so that `@DriftDatabase(include: {'file.drift'})`
     finds the cached discovery/analysis when the driver's
     `findsLocalElementsReliably` is true.

After shim_drift, the combining shim merges the `.g.part` shard into
`.g.dart`. Pass empty `drift_srcs` for Dart-only setups â stages 1â3 are
skipped entirely.
�
(

rules_dartdart/ext/freezeddefs.bzl�freezed_library>A dart_library whose sources are augmented by freezed codegen.*�
�
freezed_library

name (

srcs (
package_name""(
language_version""(
deps[](4
annotation_dep "@pub_deps//:freezed_annotation"(
config""(

kwargs(>A dart_library whose sources are augmented by freezed codegen.2:
freezed_library'@@rules_dart//dart/ext/freezed:defs.bzl
*library_builder_library2library_builder_library�
//dart/ext/_shared:defs.bzlrz
(

rules_dartdart/ext/_shareddefs.bzl@
library_builder_librarylibrary_builder_library
1H
JJConvenience macro for the freezed builder (produces `<src>.freezed.dart`).�
*

rules_dartdart/ext/go_routerdefs.bzl�go_router_library*�
�
go_router_library

name (

srcs (
package_name""(
language_version""(
deps[](+
annotation_dep"@pub_deps//:go_router"(
config""(

kwargs(2>
go_router_library)@@rules_dart//dart/ext/go_router:defs.bzl
*shared_part_library2shared_part_library�
//dart/ext/_shared:defs.bzlrr
(

rules_dartdart/ext/_shareddefs.bzl8
shared_part_libraryshared_part_library
1D
F4Convenience macro for the go_router_builder builder.�J
+

rules_dartdart/ext/injectabledefs.bzl�Cinjectable_library�A dart_library augmented by injectable_generator's two-stage codegen.

Collects Dart sources and propagates dependency information via `DartInfo`. Does not compile or assemble; consumers co-locate generated sources."�A
�!
injectable_library�A dart_library augmented by injectable_generator's two-stage codegen.

Collects Dart sources and propagates dependency information via `DartInfo`. Does not compile or assemble; consumers co-locate generated sources.*
nameA unique name for this target. �
code_assets�Native code assets this package owns (see the `dart_code_asset` rule). Assets declared here propagate to every `dart_binary`/`dart_test` that depends on this library, directly or transitively â matching upstream, where depending on a package gets you its assets with no opt-in. Each `asset_id` must be namespaced to this library's `package_name`.*
DartCodeAssetInfo2[]�
depsuOther `dart_library` targets this library depends on. Their sources and package metadata are propagated transitively.*

DartInfo2[]�
has_unreplaced_hook�Path of a pub build hook (`hook/build.dart` / `hook/link.dart`) this package ships that rules_dart has no replacement for. Set by `pub.from_lock()`; hand-written `dart_library` targets leave it empty. A `dart_binary`/`dart_test` reaching such a package fails with an explanation, rather than producing a binary whose `@Native` bindings silently fail to resolve at runtime.2""�
language_version�Dart language version implied by the package's `environment.sdk` constraint, in `<major>.<minor>` form. Emitted as `languageVersion` in generated `package_config.json` entries. For pub packages this is set automatically by `pub.from_lock()`; for hand-written `dart_library` targets, set it from your workspace's `pubspec.yaml` if you want analyzer behaviour to match.2""�
package�A `dart_package_metadata` declaring this Dart package's `package_name` and `language_version`. Mutually exclusive with the inline `package_name` / `language_version` attributes: set `package` to state those facts once for every rule building this package, or set them inline, but never both. Referencing a target is what lets rules in *different* BUILD files share one declaration, which a macro cannot do.*
DartPackageMetadataInfo2None�
package_name�The Dart package name used in `package:` imports. If omitted, defaults to the last component of the Bazel package path. Set this or `package`, not both.2""�
	resources�Non-Dart files this package ships inside `lib/` â part of its published surface, but never compiled. `package:sky_engine`'s `lib/_embedder.yaml`, which the analyzer reads to resolve `dart:ui`, and `package:dwds`'s `lib/src/injected/client.js`, which it serves to the browser, are both this. Anything under `lib/` is addressable as `package:<name>/<path>` whatever its extension, so these are members of the package, not a consumer's `data`. They are staged wherever the package itself is staged â the analyzer's hermetic project tree â and ride the runfiles of every `dart_binary`/`dart_test` that depends on this library, mirroring pub, where the package directory exists whole on disk at run time. They are never compile inputs. `.dart` files belong in `srcs`; files outside `lib/` have no `package:` URI and belong in a consumer's `data`.2[]�
srcs�Dart source files (`.dart`), source-tree or generated. Typically `glob(["lib/**/*.dart"])`, optionally plus `dart_codegen` outputs. Generated members are co-located with the rest of the package by the consuming `dart_binary`/`dart_test`. Mutually exclusive with `srcs_dir`.2[]�
srcs_dir�A pre-assembled source directory (a `dart_source_set`) to use as this library's package root, instead of `srcs`. The directory is opaque and carries the package's non-Dart files too, so `resources` is rejected alongside it. For reuse/composition; usually you just list files in `srcs`.2None�
version�The package's own version, as resolved by pub (e.g. `2.2.0`). Set automatically by `pub.package()` / `pub.from_lock()`; leave it empty on hand-written targets, which have no resolved version to state. Its only use is agreement checking: when one package name arrives twice â two pub hubs each supplying `ffi`, say â a build whose two records name different versions would otherwise compile against whichever came first in dependency order, silently ignoring the other. Two *known*, differing versions fail the build; an empty one never conflicts.2""
,
*
nameA unique name for this target. �
�
code_assets�Native code assets this package owns (see the `dart_code_asset` rule). Assets declared here propagate to every `dart_binary`/`dart_test` that depends on this library, directly or transitively â matching upstream, where depending on a package gets you its assets with no opt-in. Each `asset_id` must be namespaced to this library's `package_name`.*
DartCodeAssetInfo2[]�
�
depsuOther `dart_library` targets this library depends on. Their sources and package metadata are propagated transitively.*

DartInfo2[]�
�
has_unreplaced_hook�Path of a pub build hook (`hook/build.dart` / `hook/link.dart`) this package ships that rules_dart has no replacement for. Set by `pub.from_lock()`; hand-written `dart_library` targets leave it empty. A `dart_binary`/`dart_test` reaching such a package fails with an explanation, rather than producing a binary whose `@Native` bindings silently fail to resolve at runtime.2""�
�
language_version�Dart language version implied by the package's `environment.sdk` constraint, in `<major>.<minor>` form. Emitted as `languageVersion` in generated `package_config.json` entries. For pub packages this is set automatically by `pub.from_lock()`; for hand-written `dart_library` targets, set it from your workspace's `pubspec.yaml` if you want analyzer behaviour to match.2""�
�
package�A `dart_package_metadata` declaring this Dart package's `package_name` and `language_version`. Mutually exclusive with the inline `package_name` / `language_version` attributes: set `package` to state those facts once for every rule building this package, or set them inline, but never both. Referencing a target is what lets rules in *different* BUILD files share one declaration, which a macro cannot do.*
DartPackageMetadataInfo2None�
�
package_name�The Dart package name used in `package:` imports. If omitted, defaults to the last component of the Bazel package path. Set this or `package`, not both.2""�
�
	resources�Non-Dart files this package ships inside `lib/` â part of its published surface, but never compiled. `package:sky_engine`'s `lib/_embedder.yaml`, which the analyzer reads to resolve `dart:ui`, and `package:dwds`'s `lib/src/injected/client.js`, which it serves to the browser, are both this. Anything under `lib/` is addressable as `package:<name>/<path>` whatever its extension, so these are members of the package, not a consumer's `data`. They are staged wherever the package itself is staged â the analyzer's hermetic project tree â and ride the runfiles of every `dart_binary`/`dart_test` that depends on this library, mirroring pub, where the package directory exists whole on disk at run time. They are never compile inputs. `.dart` files belong in `srcs`; files outside `lib/` have no `package:` URI and belong in a consumer's `data`.2[]�
�
srcs�Dart source files (`.dart`), source-tree or generated. Typically `glob(["lib/**/*.dart"])`, optionally plus `dart_codegen` outputs. Generated members are co-located with the rest of the package by the consuming `dart_binary`/`dart_test`. Mutually exclusive with `srcs_dir`.2[]�
�
srcs_dir�A pre-assembled source directory (a `dart_source_set`) to use as this library's package root, instead of `srcs`. The directory is opaque and carries the package's non-Dart files too, so `resources` is rejected alongside it. For reuse/composition; usually you just list files in `srcs`.2None�
�
version�The package's own version, as resolved by pub (e.g. `2.2.0`). Set automatically by `pub.package()` / `pub.from_lock()`; leave it empty on hand-written targets, which have no resolved version to state. Its only use is agreement checking: when one package name arrives twice â two pub hubs each supplying `ffi`, say â a build whose two records name different versions would otherwise compile against whichever came first in dependency order, silently ignoring the other. Two *known*, differing versions fail the build; an empty one never conflicts.2""�
//dart:defs.bzlr�


rules_dartdartdefs.bzl>
dart_aggregate_codegendart_aggregate_codegen
%;*
dart_codegendart_codegen
?K*
dart_librarydart_library
O[
]�Convenience macro for injectable_generator.

Two stages:

  1. Per-class metadata: `injectable_builder` runs over every file in
     `srcs` and emits a `<src>.injectable.json` shard.
  2. Per-init container: `injectable_config_builder` (aggregate) runs
     over the single file declaring `@InjectableInit` and, fed every
     metadata shard from stage 1, emits `<init>.config.dart` plus a
     `<init>.module.dart` shard for any module classes. Both outputs
     are wired through the shim's multi-output routing.
�
2

rules_dartdart/ext/json_serializabledefs.bzl�json_serializable_library*�
�
json_serializable_library

name (

srcs (
package_name""(
language_version""(
deps[](1
annotation_dep"@pub_deps//:json_annotation"(
config""(

kwargs(2N
json_serializable_library1@@rules_dart//dart/ext/json_serializable:defs.bzl
*shared_part_library2shared_part_library�
//dart/ext/_shared:defs.bzlrr
(

rules_dartdart/ext/_shareddefs.bzl8
shared_part_libraryshared_part_library
1D
F4Convenience macro for the json_serializable builder.�
(

rules_dartdart/ext/mockitodefs.bzl�mockito_library,A dart_library augmented by mockito codegen.*�
�
mockito_library

name (

srcs (
package_name""(
language_version""(
deps[]()
annotation_dep"@pub_deps//:mockito"(
config""(

kwargs(,A dart_library augmented by mockito codegen.2:
mockito_library'@@rules_dart//dart/ext/mockito:defs.bzl
*library_builder_library2library_builder_library�
//dart/ext/_shared:defs.bzlrz
(

rules_dartdart/ext/_shareddefs.bzl@
library_builder_librarylibrary_builder_library
	1	H
		J�Convenience macro for the mockito builder.

mockito's `@GenerateMocks` typically lives in test files and generates
`<file>.mocks.dart` directly (no SharedPart shards). Any types being
mocked (`MockFoo`) must live in a `dart_library` passed via `deps` so the
Resolver can read them.
�
(

rules_dartdart/ext/sqlite3defs.bzl�sqlite3_code_asset@Returns the label of the rules_dart-provided sqlite3 code asset.*�
�
sqlite3_code_asset@Returns the label of the rules_dart-provided sqlite3 code asset.2=
sqlite3_code_asset'@@rules_dart//dart/ext/sqlite3:defs.bzl
�Convenience accessor for the sqlite3 code asset.

Usage in a `dart_test` / `dart_binary` that uses `package:sqlite3` (directly
or transitively, e.g. via `drift`'s `NativeDatabase`):

    load("@rules_dart//dart/ext/sqlite3:defs.bzl", "sqlite3_code_asset")

    dart_test(
        name = "db_test",
        main = "test/db_test.dart",   # plain NativeDatabase.memory(), no FFI ceremony
        code_assets = [sqlite3_code_asset()],
        deps = [...],
    )
�
(

rules_dartdart/ext/stackeddefs.bzl�stacked_bottomsheet_libraryOA dart_library augmented by stackedBottomsheetGenerator (`.bottomsheets.dart`).*�
�
stacked_bottomsheet_library

name (

srcs (
package_name""(
language_version""(
deps[]()
annotation_dep"@pub_deps//:stacked"(
config""(

kwargs(OA dart_library augmented by stackedBottomsheetGenerator (`.bottomsheets.dart`).2F
stacked_bottomsheet_library'@@rules_dart//dart/ext/stacked:defs.bzl
��*library_builder_library2library_builder_library�stacked_dialog_libraryEA dart_library augmented by stackedDialogGenerator (`.dialogs.dart`).*�
�
stacked_dialog_library

name (

srcs (
package_name""(
language_version""(
deps[]()
annotation_dep"@pub_deps//:stacked"(
config""(

kwargs(EA dart_library augmented by stackedDialogGenerator (`.dialogs.dart`).2A
stacked_dialog_library'@@rules_dart//dart/ext/stacked:defs.bzl
jj*library_builder_library2library_builder_library�stacked_form_library@A dart_library augmented by stackedFormGenerator (`.form.dart`).*�
�
stacked_form_library

name (

srcs (
package_name""(
language_version""(
deps[]()
annotation_dep"@pub_deps//:stacked"(
config""(

kwargs(@A dart_library augmented by stackedFormGenerator (`.form.dart`).2?
stacked_form_library'@@rules_dart//dart/ext/stacked:defs.bzl
<<*library_builder_library2library_builder_library�stacked_locator_libraryFA dart_library augmented by stackedLocatorGenerator (`.locator.dart`).*�
�
stacked_locator_library

name (

srcs (
package_name""(
language_version""(
deps[]()
annotation_dep"@pub_deps//:stacked"(
config""(

kwargs(FA dart_library augmented by stackedLocatorGenerator (`.locator.dart`).2B
stacked_locator_library'@@rules_dart//dart/ext/stacked:defs.bzl
%%*library_builder_library2library_builder_library�stacked_logger_libraryDA dart_library augmented by stackedLoggerGenerator (`.logger.dart`).*�
�
stacked_logger_library

name (

srcs (
package_name""(
language_version""(
deps[]()
annotation_dep"@pub_deps//:stacked"(
config""(

kwargs(DA dart_library augmented by stackedLoggerGenerator (`.logger.dart`).2A
stacked_logger_library'@@rules_dart//dart/ext/stacked:defs.bzl
SS*library_builder_library2library_builder_library�stacked_router_libraryDA dart_library augmented by stackedRouterGenerator (`.router.dart`).*�
�
stacked_router_library

name (

srcs (
package_name""(
language_version""(
deps[]()
annotation_dep"@pub_deps//:stacked"(
config""(

kwargs(DA dart_library augmented by stackedRouterGenerator (`.router.dart`).2A
stacked_router_library'@@rules_dart//dart/ext/stacked:defs.bzl
*library_builder_library2library_builder_library�
//dart/ext/_shared:defs.bzlrz
(

rules_dartdart/ext/_shareddefs.bzl@
library_builder_librarylibrary_builder_library

1
H


J�Convenience macros for stacked_generator's six LibraryBuilders.

Each macro wires one of stacked_generator's sub-builders (`router`,
`locator`, `form`, `logger`, `dialog`, `bottomsheet`) through the
`library_builder_library` helper. The `@StackedApp` annotation triggers
five of the six (all except `form`, which uses `@FormView`); Gazelle
emits the corresponding macros per registered sub-builder.
�
$

rules_dartdart/extregistry.bzl�curated_code_assetsBReturns curated `dart_code_asset` labels for a locked pub package.*�
�
curated_code_assets)
package_nameThe pub package name. (=
version.The exact version resolved from the lock file. (BReturns curated `dart_code_asset` labels for a locked pub package."`
^List of label strings; empty when rules_dart curates nothing for this
package at this version.2:
curated_code_assets#@@rules_dart//dart/ext:registry.bzl
--�curated_packages�Returns the pub package names rules_dart curates assets for.

Used to tell a user which packages have a replacement available when their
lock pins an unsupported version.
*�
�
curated_packages�Returns the pub package names rules_dart curates assets for.

Used to tell a user which packages have a replacement available when their
lock pins an unsupported version.
"
Sorted list of package names.27
curated_packages#@@rules_dart//dart/ext:registry.bzl
EEu
//dart/pub:defs.bzlr\
 

rules_dartdart/pubdefs.bzl*
parse_semverparse_semver
!)!5
!!7�Curated code-asset entries for pub packages that ship a `hook/build.dart`.

A pub package with a build hook produces native libraries that rules_dart
cannot build by running the hook (it is non-hermetic and emits a directory
Bazel cannot predeclare). Where rules_dart provides a Bazel replacement under
`//dart/ext/<package>`, this registry binds it to the package name so that
`pub.from_lock()` attaches it automatically â the user does not name the asset,
and does not have to know that, say, `drift` needs `sqlite3`.

**Supported API for other rule sets.** `curated_code_assets()` and
`curated_packages()` are loadable as `@rules_dart//dart/ext:registry.bzl` and
are covered by this repo's compatibility expectations. rules_flutter calls
them from its own pub-spoke generator, which cannot route through
`pub_lock_package` because Flutter spokes carry plugin metadata and
Apple/Android sub-packages of their own. Both functions return plain strings,
so a caller never handles a registry type, and the labels are fully qualified
(`@rules_dart//â¦`) so they resolve from a foreign repository.

`_ENTRIES` stays **private** and its shape is free to change â downstream goes
through the two functions rather than reading or mirroring the table. It is the
only asset *producer* today; the resolution path in `extensions.bzl` consults
producers in order, which is where a package-shipped manifest or a user overlay
would slot in later.

Entries are version-bounded because an asset id is a path inside a *particular*
version of a package: `//dart/ext/sqlite3` binds
`package:sqlite3/src/ffi/libsqlite3.g.dart`, which is where that package's
bindings live today. Attaching it to a lock pinning a version whose bindings
moved would be silently wrong. `min_version` is inclusive, `max_version`
exclusive; either may be empty for an open bound.
�
.

rules_dartdart/privatebuild_settings.bzl�dart_defines_flag�A repeatable list of Dart environment declarations (`KEY=VALUE`), appended after a target's own `defines` so the command line wins on a key collision."�
�
dart_defines_flag�A repeatable list of Dart environment declarations (`KEY=VALUE`), appended after a target's own `defines` so the command line wins on a key collision.*
nameA unique name for this target. "B
dart_defines_flag-@@rules_dart//dart/private:build_settings.bzl
::,
*
nameA unique name for this target. �dart_define_error?Returns an error string if `define` is not a usable `-D` entry.*�
�
dart_define_errorz
definelA define string. Normally `KEY=VALUE`; a bare `KEY` is a key with
no value, which the Dart compilers accept. (a
whatUWhere the define came from, named in the message — a target label
or the flag name. (?Returns an error string if `define` is not a usable `-D` entry."4
2An error string, or None when the entry is usable.2B
dart_define_error-@@rules_dart//dart/private:build_settings.bzl
�merge_dart_defines�Merges a target's `defines` attr with the `extra_dart_defines` flag.

The flag validates its own value in its rule implementation, so only the
attr is validated here.
*�
�
merge_dart_definesE
ctx:Rule context carrying `defines` and `_extra_dart_defines`. (�Merges a target's `defines` attr with the `extra_dart_defines` flag.

The flag validates its own value in its rule implementation, so only the
attr is validated here.
"6
4The merged list of define strings, flag values last.2C
merge_dart_defines-@@rules_dart//dart/private:build_settings.bzl
LL�validate_dart_defines#Fails on the first unusable define.*�
�
validate_dart_defines&
definesList of define strings. (?
what3Where they came from, named in any failure message. (#Fails on the first unusable define.2F
validate_dart_defines-@@rules_dart//dart/private:build_settings.bzl
**�
//rules:common_settings.bzlrn
*
bazel_skylibrulescommon_settings.bzl2
BuildSettingInfoBuildSettingInfo
3C
E�The `//dart:extra_dart_defines` build setting and its plumbing.

A `defines` attribute pins environment declarations to one target. This flag is
the command-line channel for the same thing: a `.bazelrc` config group can point
an entire build at an environment without editing BUILD files, which is what
makes `--config=staging` reach a binary, its tests, and its probes alike.

Flag values are appended *after* a target's own `defines`, so the command line
wins on a key collision â every Dart compiler takes the last `-D` for a
repeated key.

Unlike rules_flutter's equivalent, no define keys are reserved here. That list
exists there because the Flutter build sets `dart.vm.product` and friends itself
from the compilation mode, and a user value would silently fight it. rules_dart
maps compilation mode to `--enable-asserts` and gen-snapshot options only and
sets no define of its own, so it has nothing to protect.
��
&

rules_dartdart/private
common.bzl�add_shim_contract_args�Appends the typed shim-contract flags to `args`.

Covers `--package`, `--root-language-version`, `--dep` (repeatable —
`<exec_path>|<asset_path>` form — one per entry in `auto_stage_srcs`
and `asset_deps`), `--part`, `--config`, `--package-config`,
`--sdk-path`. Callers add `--input`, `--output`, and `--input-asset`
themselves (those are specific to the calling impl's per-src /
per-output loop).
*�
�
add_shim_contract_args?
args3The `ctx.actions.args()` object to append flags to. (C
ctx8The rule context (reads `package_name`, `config`, etc.). (�
synth_pcuThe synthesised `package_config.json` File from
`synth_package_config`, or `None` for targets without
`library_deps`. (�
sdk_dart�The `dart` executable File (from the caller's resolved
toolchain) used to compute `--sdk-path`. Passed in so this helper
stays agnostic of which toolchain type the caller resolves. (�
auto_stage_srcs�List of Files to emit as `--dep` with
automatically-computed asset paths. The rule layer calls
`same_package_library_dep_files` to compute this — users do not
hand-list sibling files.[](�

asset_deps�List of Files from the rule's `asset_deps` attr (non-Dart
files the Builder's Resolver must see via `findAssets` /
`readAsString`). De-duplicated against `auto_stage_srcs` by exec
path.[](q
lib_root_The Dart package's lib_root (used to compute asset paths
for `auto_stage_srcs` / `asset_deps`).""(�Appends the typed shim-contract flags to `args`.

Covers `--package`, `--root-language-version`, `--dep` (repeatable —
`<exec_path>|<asset_path>` form — one per entry in `auto_stage_srcs`
and `asset_deps`), `--part`, `--config`, `--package-config`,
`--sdk-path`. Callers add `--input`, `--output`, and `--input-asset`
themselves (those are specific to the calling impl's per-src /
per-output loop).
"f
dA list of extra action-input Files that callers must include in
their `ctx.actions.run(inputs=...)`.2?
add_shim_contract_args%@@rules_dart//dart/private:common.bzl
���analysis_options_closure�Normalizes an `options` attribute to the closure its `include:`s need.

Every rule that stages a project for an SDK tool — `dart_analyze_test`,
`dart_fix`, `dart_format_test` — accepts the same three shapes: unset, a
bare `.yaml` label, and a `dart_analysis_options` target. Only the third
carries packages, because only a `package:` URI needs resolving; this is
the single place that distinction is made, so the rules cannot drift into
staging different closures for the same options file.

The packages are for resolution alone. Callers merge them into the list
that builds `package_config.json` and stage the files, but they never enter
the analyzed target's own `DartInfo` — see `dart_analysis_options`.
*�
�
analysis_options_closureB
options_attr.The rule's `ctx.attr.options` (may be `None`). (�Normalizes an `options` attribute to the closure its `include:`s need.

Every rule that stages a project for an SDK tool — `dart_analyze_test`,
`dart_fix`, `dart_format_test` — accepts the same three shapes: unset, a
bare `.yaml` label, and a `dart_analysis_options` target. Only the third
carries packages, because only a `package:` URI needs resolving; this is
the single place that distinction is made, so the rules cannot drift into
staging different closures for the same options file.

The packages are for resolution alone. Callers merge them into the list
that builds `package_config.json` and stage the files, but they never enter
the analyzed target's own `DartInfo` — see `dart_analysis_options`.
"�
�`struct(packages, files)` — `DartPackageInfo` records the includes may
reference, and the files of those packages to stage. Both empty unless
the attribute is a `dart_analysis_options` target.2A
analysis_options_closure%@@rules_dart//dart/private:common.bzl
���analyzable_closure�Normalizes an analyze/fix operand to the closure and the loose sources.

`dart_analyze_test` and `dart_fix` accept either provider — `DartInfo` from
a library, `DartAnalyzableInfo` from an executable — and this is the single
place that OR is resolved, so neither rule has to branch and the two cannot
drift into disagreeing about what "the sources to analyze" means.
*�
�
analyzable_closureD
target6A target providing `DartAnalyzableInfo` or `DartInfo`. (�Normalizes an analyze/fix operand to the closure and the loose sources.

`dart_analyze_test` and `dart_fix` accept either provider — `DartInfo` from
a library, `DartAnalyzableInfo` from an executable — and this is the single
place that OR is resolved, so neither rule has to branch and the two cannot
drift into disagreeing about what "the sources to analyze" means.
"�
�`struct(dart_info, srcs)` — the dependency closure, and the target's own
package-less entrypoint sources (empty for a library, whose every source
is already inside the closure).2;
analyzable_closure%@@rules_dart//dart/private:common.bzl
���analyze_operand�Returns the target a `dart_analyze_test` / `dart_fix` was pointed at.

Both rules name the operand `target` and still answer to the older `lib`.
Neither attribute can be `mandatory` while the other exists, so the
missing-attribute error Bazel used to raise for `lib` has to be raised here
instead — and with it the both-set case, where picking one silently would
analyze something the BUILD file did not ask for.
*�
�
analyze_operandC
ctx8The rule context (must declare both `target` and `lib`). (�Returns the target a `dart_analyze_test` / `dart_fix` was pointed at.

Both rules name the operand `target` and still answer to the older `lib`.
Neither attribute can be `mandatory` while the other exists, so the
missing-attribute error Bazel used to raise for `lib` has to be raised here
instead — and with it the both-set case, where picking one silently would
analyze something the BUILD file did not ask for.
"
The chosen target.28
analyze_operand%@@rules_dart//dart/private:common.bzl
���asset_path_for�	Computes the in-package asset path for a File.

Strips `lib_root` (plus the trailing `/`) from the short_path. When
`lib_root` is empty the short_path is returned unchanged — that's the
root-package case and the file's short_path IS its asset path.

Generated files need one extra step first: `declare_file` paths are
relative to the *producing rule's* Bazel package, so when a codegen
target lives in a different Bazel package than the Dart package root,
the generated short_path is `owner.package + "/" + declared_path`
where `declared_path` embeds the source's short_path (`dart_codegen`
declares outputs source-relative). Stripping `owner.package` and then
`lib_root` recovers the in-package asset path. When the declared path
does not start with `lib_root` (the codegen target's package is at or
below the Dart package root with a same-package src), the generated
short_path mirrors a source file's and the plain `lib_root` strip
below stays correct.

Fails loudly when neither derivation matches. Previously this
silently returned the unmatched short_path, which produced
`--input-asset` / `--dep` values that couldn't be resolved to any
`package:` URI — the builder would then produce no output or emit an
unhelpful `AssetNotFoundException`.
*�
�
asset_path_for3
file'The File to compute the asset path for. (�
lib_root�The Dart package's short_path prefix (empty for the root
workspace; e.g. `external/pub_deps++pub+foo` for external pub
packages). (�	Computes the in-package asset path for a File.

Strips `lib_root` (plus the trailing `/`) from the short_path. When
`lib_root` is empty the short_path is returned unchanged — that's the
root-package case and the file's short_path IS its asset path.

Generated files need one extra step first: `declare_file` paths are
relative to the *producing rule's* Bazel package, so when a codegen
target lives in a different Bazel package than the Dart package root,
the generated short_path is `owner.package + "/" + declared_path`
where `declared_path` embeds the source's short_path (`dart_codegen`
declares outputs source-relative). Stripping `owner.package` and then
`lib_root` recovers the in-package asset path. When the declared path
does not start with `lib_root` (the codegen target's package is at or
below the Dart package root with a same-package src), the generated
short_path mirrors a source file's and the plain `lib_root` strip
below stays correct.

Fails loudly when neither derivation matches. Previously this
silently returned the unmatched short_path, which produced
`--input-asset` / `--dep` values that couldn't be resolved to any
`package:` URI — the builder would then produce no output or emit an
unhelpful `AssetNotFoundException`.
"<
:The asset path string (relative to the Dart package root).27
asset_path_for%@@rules_dart//dart/private:common.bzl
�
�
�check_single_root_package�Checks that at most one package claims the empty (root) `lib_root`.

Two or more empty-lib_root packages are ambiguous: the empty-prefix match
would race to claim any `lib/`-prefixed source.
*�
�
check_single_root_package2
packages"List of DartPackageInfo providers. (�Checks that at most one package claims the empty (root) `lib_root`.

Two or more empty-lib_root packages are ambiguous: the empty-prefix match
would race to claim any `lib/`-prefixed source.
"Z
XAn error message string when more than one package has an empty
`lib_root`, else `None`.2B
check_single_root_package%@@rules_dart//dart/private:common.bzl
���check_unreplaced_hooks�Checks that no package in the closure has an unreplaced build hook.

A pub package shipping `hook/build.dart` builds native libraries at
`pub get` time. rules_dart cannot run that hook, so without a Bazel
replacement the package's `@Native` bindings resolve to nothing — the
manifest is simply missing an entry, and the failure surfaces at runtime
as "couldn't resolve native function", with nothing pointing at the cause.

Deliberately checked here rather than when the spoke repo is generated:
`pub.from_lock()` materialises the whole lock file, so failing at
generation would fail on packages nothing depends on and on platforms
where the hook is irrelevant. Only a package actually reached by a binary
or test is a problem, and only here is the depending target known.
*�
�
check_unreplaced_hooks*
labelThe consuming target's label. (D
packages4List of `DartPackageInfo` in the transitive closure. (�Checks that no package in the closure has an unreplaced build hook.

A pub package shipping `hook/build.dart` builds native libraries at
`pub get` time. rules_dart cannot run that hook, so without a Bazel
replacement the package's `@Native` bindings resolve to nothing — the
manifest is simply missing an entry, and the failure surfaces at runtime
as "couldn't resolve native function", with nothing pointing at the cause.

Deliberately checked here rather than when the spoke repo is generated:
`pub.from_lock()` materialises the whole lock file, so failing at
generation would fail on packages nothing depends on and on platforms
where the hook is irrelevant. Only a package actually reached by a binary
or test is a problem, and only here is the depending target known.
"%
#An error message string, or `None`.2?
check_unreplaced_hooks%@@rules_dart//dart/private:common.bzl
�	�	�code_asset_entriesFBuilds manifest entries and the runfiles library list for code assets.*�
�
code_asset_entries>
label1The consuming target's label, for error messages. (*
assetsList of `DartCodeAssetInfo`. (c

output_dirQDirectory the manifest's `relative` paths resolve against
(the dill's `dirname`). (FBuilds manifest entries and the runfiles library list for code assets."x
v`(entries, libraries)` — entries for `generate_native_assets_yaml`, and
the `File`s that must be staged in runfiles.2;
code_asset_entries%@@rules_dart//dart/private:common.bzl
�	�	�codegen_identity_error�Reports a generated source whose package identity contradicts its library.

`dart_codegen` and its consuming `dart_library` each state the package the
generated file belongs to, and `dart_codegen`'s own documentation has always
required them to match — with nothing checking that they do. They cannot be
made to agree by construction either: the library depends on the codegen's
output, so no provider reaches from the codegen to the library, and the two
are routinely written in different BUILD files. `srcs` is where they meet.

The language version compared here is the generator's *effective* one, so a
`dart_codegen` that states none — and therefore ran under
`DEFAULT_ROOT_LANGUAGE_VERSION` — is reported against a library that states
3.11, instead of the mismatch surfacing later as a generated file the
analyzer rejects. A library that states none of its own asks for nothing and
is not second-guessed: `e2e/fix/clean` is that shape, both sides silent, and
it is not this function's business to invent an opinion for it.
*�
�

codegen_identity_error?
label2The consuming rule's label, for the error message. (B
srcs6The consuming rule's `srcs` targets (`ctx.attr.srcs`). (K
identity;The consuming rule's own `resolve_package_identity` result. (�Reports a generated source whose package identity contradicts its library.

`dart_codegen` and its consuming `dart_library` each state the package the
generated file belongs to, and `dart_codegen`'s own documentation has always
required them to match — with nothing checking that they do. They cannot be
made to agree by construction either: the library depends on the codegen's
output, so no provider reaches from the codegen to the library, and the two
are routinely written in different BUILD files. `srcs` is where they meet.

The language version compared here is the generator's *effective* one, so a
`dart_codegen` that states none — and therefore ran under
`DEFAULT_ROOT_LANGUAGE_VERSION` — is reported against a library that states
3.11, instead of the mismatch surfacing later as a generated file the
analyzer rejects. A library that states none of its own asks for nothing and
is not second-guessed: `e2e/fix/clean` is that shape, both sides silent, and
it is not this function's business to invent an opinion for it.
">
<An error message string, or `None` when nothing contradicts.2?
codegen_identity_error%@@rules_dart//dart/private:common.bzl
���collect_code_asset_files:Merges `DartInfo.transitive_code_asset_files` across deps.*�
�
collect_code_asset_files1
deps%List of targets providing `DartInfo`. (:Merges `DartInfo.transitive_code_asset_files` across deps."B
@`depset[File]` of every transitive code asset's dynamic library.2A
collect_code_asset_files%@@rules_dart//dart/private:common.bzl
xx�collect_packages�Collect unique DartPackageInfo providers from transitive deps.

Flattens the merged transitive depset exactly once (package metadata is
inspected per-entry for dedup, so a flatten is unavoidable here — but it
is bounded by the package count, not the source-file count).
*�
�
collect_packages/
deps#List of targets providing DartInfo. (�Collect unique DartPackageInfo providers from transitive deps.

Flattens the merged transitive depset exactly once (package metadata is
inspected per-entry for dedup, so a flatten is unavoidable here — but it
is bounded by the package count, not the source-file count).
"?
=List of unique DartPackageInfo providers in dependency order.29
collect_packages%@@rules_dart//dart/private:common.bzl
���collect_transitive_code_assetsGCollects `DartCodeAssetInfo` from every package reachable through deps.*�
�
collect_transitive_code_assets1
deps%List of targets providing `DartInfo`. (GCollects `DartCodeAssetInfo` from every package reachable through deps."~
|List of `DartCodeAssetInfo`, in dependency order, with duplicates from
diamonds left in place — callers dedup by asset id.2G
collect_transitive_code_assets%@@rules_dart//dart/private:common.bzl
���collect_transitive_resources�Collect all transitive `resources` files from DartInfo deps.

The sibling of `collect_transitive_srcs`, for the non-Dart files a package
ships inside `lib/`. Kept a separate call rather than folded into that one
so every consumer has to say which of the two it means: staging a package
whole wants both, feeding the compiler wants only the sources.
*�
�
collect_transitive_resources/
deps#List of targets providing DartInfo. (�Collect all transitive `resources` files from DartInfo deps.

The sibling of `collect_transitive_srcs`, for the non-Dart files a package
ships inside `lib/`. Kept a separate call rather than folded into that one
so every consumer has to say which of the two it means: staging a package
whole wants both, feeding the compiler wants only the sources.
"7
5Depset of Files from the transitive resource closure.2E
collect_transitive_resources%@@rules_dart//dart/private:common.bzl
���collect_transitive_srcs�Collect all transitive source files from DartInfo deps.

Returns a depset so consumers can feed action inputs / runfiles without
flattening. Callers that genuinely inspect per-file paths (package
colocation, package_config root resolution) call `.to_list()` exactly
once at that point.
*�
�
collect_transitive_srcs/
deps#List of targets providing DartInfo. (�Collect all transitive source files from DartInfo deps.

Returns a depset so consumers can feed action inputs / runfiles without
flattening. Callers that genuinely inspect per-file paths (package
colocation, package_config root resolution) call `.to_list()` exactly
once at that point.
"5
3Depset of Files from the transitive source closure.2@
collect_transitive_srcs%@@rules_dart//dart/private:common.bzl
���create_test_executable�Create a test executable by symlinking a pre-compiled tool binary.

Handles .exe extension on Windows. Returns the executable file and a
RunEnvironmentInfo provider for passing configuration via env vars.
*�
�
create_test_executable
ctxThe rule context. (B
tool6The pre-compiled tool target (from a cfg="exec" attr). (O
envDDict of environment variable names to values for RunEnvironmentInfo. (�Create a test executable by symlinking a pre-compiled tool binary.

Handles .exe extension on Windows. Returns the executable file and a
RunEnvironmentInfo provider for passing configuration via env vars.
"I
GTuple of (executable File, RunEnvironmentInfo provider, tool runfiles).2?
create_test_executable%@@rules_dart//dart/private:common.bzl
HH�dart_lib_root_for_package�Looks up the Dart package's lib_root from the transitive DartInfo set.

Scans every dep in `deps`; the first `DartPackageInfo` whose
`package_name` matches wins.

The rule layer uses this to compute asset paths that survive the
codegen rule living at a deeper Bazel-package path than the Dart
package root (e.g. `//myapp/lib:codegen` where the Dart package is
`//myapp`).
*�
�
dart_lib_root_for_package0
deps$List of targets carrying `DartInfo`. (5
package_name!The Dart package name to look up. (�Looks up the Dart package's lib_root from the transitive DartInfo set.

Scans every dep in `deps`; the first `DartPackageInfo` whose
`package_name` matches wins.

The rule layer uses this to compute asset paths that survive the
codegen rule living at a deeper Bazel-package path than the Dart
package root (e.g. `//myapp/lib:codegen` where the Dart package is
`//myapp`).
"r
pThe lib_root string (possibly `""` for the root workspace package),
or `None` when no matching package is found.2B
dart_lib_root_for_package%@@rules_dart//dart/private:common.bzl
���find_sdk_kernel_tools�Locates the gen_kernel toolchain files within the SDK tree.

Returns a struct with the `dartaotruntime` executable, the
`gen_kernel_aot.dart.snapshot`, and `vm_platform_strong.dill` Files,
found by exact path under the SDK root within `dart_sdk_info.tool_files`.
*�
�
find_sdk_kernel_tools:
dart_sdk_info%The `DartSdkInfo` from the toolchain. (�Locates the gen_kernel toolchain files within the SDK tree.

Returns a struct with the `dartaotruntime` executable, the
`gen_kernel_aot.dart.snapshot`, and `vm_platform_strong.dill` Files,
found by exact path under the SDK root within `dart_sdk_info.tool_files`.
"H
F`struct(dartaotruntime, gen_kernel_snapshot, platform_dill)` of Files.2>
find_sdk_kernel_tools%@@rules_dart//dart/private:common.bzl
���gen_kernel_native_assets_action�Runs `gen_kernel --native-assets=<yaml>` to produce a kernel `.dill`.

Invokes `dartaotruntime gen_kernel_aot.dart.snapshot --platform <dill>
--packages <pc> --native-assets <yaml> -o <output> <main>`, embedding the
code-asset mapping as `vm:ffi:native-assets` metadata. The `.so` files are
NOT inputs — gen_kernel only embeds the yaml text; the libraries are a
runtime (runfiles) dependency.
*�

�

gen_kernel_native_assets_action
ctxThe rule context. (:
dart_sdk_info%The `DartSdkInfo` from the toolchain. ("
mainThe main `.dart` File. (9
transitive_srcs"Depset of transitive source Files. (J
package_config4The build-time `package_config.json` File (or None). (@
native_assets_yaml&The generated native_assets.yaml File. (6
output_dill#The output `.dill` File to produce. (
	main_pathjOptional path string to compile instead of `main.path` (e.g. a
path inside an assembled `main` directory).None(�
defines�Environment declarations; each entry becomes a `-D` flag. This
action runs the front end, so it is the only stage where they can still
reach constant evaluation — `dart compile` on the resulting `.dill`
would accept them and silently do nothing.[](�Runs `gen_kernel --native-assets=<yaml>` to produce a kernel `.dill`.

Invokes `dartaotruntime gen_kernel_aot.dart.snapshot --platform <dill>
--packages <pc> --native-assets <yaml> -o <output> <main>`, embedding the
code-asset mapping as `vm:ffi:native-assets` metadata. The `.so` files are
NOT inputs — gen_kernel only embeds the yaml text; the libraries are a
runtime (runfiles) dependency.
2H
gen_kernel_native_assets_action%@@rules_dart//dart/private:common.bzl
�
�
�generate_dev_package_config�`generate_package_config` variant for live hot reload of codegen apps.

A package whose hand-written and generated sources straddle the source tree
and `bazel-out` would, under the normal generator, get a `rootUri` pointing
at the frozen assembled (`*.pkgsrcs`) directory — so a dev tool reading it
sees stale generated output and never sees live source edits. Instead, this
emits a `<scheme>:///<lib_root>` `rootUri` for each such package and reports
the filesystem roots the frontend_server must search (`--filesystem-root`,
`--filesystem-scheme`) to resolve those scheme URIs across BOTH the live
source tree and the generated `bazel-out` outputs. Non-assembled packages
(pub deps, pure source packages) keep their normal relative `rootUri` —
the frontend_server resolves a mix of scheme and relative `rootUri`s.
*�
�
generate_dev_package_configu
packageseList of DartPackageInfo providers (pre-colocation, so the app
package still has its real `lib_root`). (P
all_srcs@List of File objects (pre-colocation, so `is_source` is intact). (Q
config_file>The output File for the dev package_config.json (for dirname). (S
scheme3Filesystem scheme for assembled packages' rootUris."org-dartlang-app"(�`generate_package_config` variant for live hot reload of codegen apps.

A package whose hand-written and generated sources straddle the source tree
and `bazel-out` would, under the normal generator, get a `rootUri` pointing
at the frozen assembled (`*.pkgsrcs`) directory — so a dev tool reading it
sees stale generated output and never sees live source edits. Instead, this
emits a `<scheme>:///<lib_root>` `rootUri` for each such package and reports
the filesystem roots the frontend_server must search (`--filesystem-root`,
`--filesystem-scheme`) to resolve those scheme URIs across BOTH the live
source tree and the generated `bazel-out` outputs. Non-assembled packages
(pub deps, pure source packages) keep their normal relative `rootUri` —
the frontend_server resolves a mix of scheme and relative `rootUri`s.
"�
�struct(content, filesystem_roots, scheme, generated_source_paths, generated_source_uris, source_packages):
content: package_config.json text.
filesystem_roots: deduped exec-root-relative dirs for `--filesystem-root`
  (source roots first, then generated roots); empty when nothing needed
  assembly (then the config equals the normal one and no scheme is used).
scheme: the filesystem scheme (meaningful only when roots are non-empty).
generated_source_paths: exec-root-relative paths of the generated files
  in assembled packages — the dev tool re-stats these after a rebuild to
  add changed ones to the reload invalidation set.
generated_source_uris: the `package:` URI for each entry in
  generated_source_paths, index-aligned, so the dev tool can map a
  changed file straight to the URI to invalidate without re-deriving it.
source_packages: (name, lib_root) for each package contributing a
  first-party (editable, main-repo) source file — the dev tool's
  path->package: map for live edits. Excludes pub/external deps and
  generated-only packages.2D
generate_dev_package_config%@@rules_dart//dart/private:common.bzl
���generate_native_assets_yaml�Generates the `native_assets.yaml` content for `gen_kernel --native-assets`.

Emits the documented format (JSON, which is valid YAML); the VM reads it
as `vm:ffi:native-assets` kernel metadata.
*�
�
generate_native_assets_yaml=
abi2The `<os>_<arch>` ABI key (see `target_dart_abi`). (t
asset_entries_List of `(asset_id, path_list)` tuples, where `path_list`
comes from `native_assets_path_list`. (�Generates the `native_assets.yaml` content for `gen_kernel --native-assets`.

Emits the documented format (JSON, which is valid YAML); the VM reads it
as `vm:ffi:native-assets` kernel metadata.
"0
.String content of the native_assets.yaml file.2D
generate_native_assets_yaml%@@rules_dart//dart/private:common.bzl
�
�
�generate_package_config�Generate package_config.json content using short_path-based lib_root.

Resolves exec-root paths from source files, then computes relative
rootUri from config_file's dirname to each package's exec-root location.
*�
�
generate_package_config2
packages"List of DartPackageInfo providers. (H
all_srcs8List of File objects from the transitive source closure. (N
config_file;The output File for package_config.json (used for dirname). (�Generate package_config.json content using short_path-based lib_root.

Resolves exec-root paths from source files, then computes relative
rootUri from config_file's dirname to each package's exec-root location.
"1
/String content of the package_config.json file.2@
generate_package_config%@@rules_dart//dart/private:common.bzl
���generate_package_config_content�Generate package_config.json content string (prefix-based).

Simple version for staging-directory contexts where the relationship between
the config file and package roots is known statically (e.g., dart_analyze
where config is at .dart_tool/ and packages are at ../<lib_root>).
*�
�
generate_package_config_content2
packages"List of DartPackageInfo providers. (L
prefix>Path prefix to prepend to each package's lib_root for rootUri. (�Generate package_config.json content string (prefix-based).

Simple version for staging-directory contexts where the relationship between
the config file and package roots is known statically (e.g., dart_analyze
where config is at .dart_tool/ and packages are at ../<lib_root>).
"1
/String content of the package_config.json file.2H
generate_package_config_content%@@rules_dart//dart/private:common.bzl
���merge_package_records�Dedups package records by name, unioning their code assets.

One `package_name` can legitimately appear with several `lib_root`s:

  * a package split across `dart_library` targets — the case
    `colocate_packages` exists to serve; and
  * a package supplied independently by two pub hubs, e.g. rules_flutter's
    `flutter.pub()` and rules_dart's `pub.from_lock()` both generating a
    spoke for `ffi`.

So the first record wins for source resolution, as it always has. Code
assets are the exception: dropping a later record's assets would silently
lose a native library, and the failure would surface at runtime as an
unresolved `@Native` symbol. Union them instead, and let
`resolve_code_assets` fail later if — and only if — two assets genuinely
claim one id, which is the case the Dart VM cannot resolve either.

First-record-wins is only safe once the records are known to agree, so this
calls `package_agreement_error` first and fails when two of them state
different `version`s or `language_version`s. `has_unreplaced_hook` stays
order-decided and deliberately unchecked: unlike the other two it is derived
at repo generation rather than stated by a developer, and two hubs can
legitimately disagree — one curating `code_assets` so the hook counts as
replaced while the other still flags it.

Split out from `collect_packages` because the dedup and union rules are a
pure function of the record list, which makes them directly testable
without synthesising `DartInfo`-bearing targets. The agreement check keeps
that property by living in its own function and returning its message.
*�
�
merge_package_recordsL
merged>List of DartPackageInfo, with duplicates, in dependency order. (�Dedups package records by name, unioning their code assets.

One `package_name` can legitimately appear with several `lib_root`s:

  * a package split across `dart_library` targets — the case
    `colocate_packages` exists to serve; and
  * a package supplied independently by two pub hubs, e.g. rules_flutter's
    `flutter.pub()` and rules_dart's `pub.from_lock()` both generating a
    spoke for `ffi`.

So the first record wins for source resolution, as it always has. Code
assets are the exception: dropping a later record's assets would silently
lose a native library, and the failure would surface at runtime as an
unresolved `@Native` symbol. Union them instead, and let
`resolve_code_assets` fail later if — and only if — two assets genuinely
claim one id, which is the case the Dart VM cannot resolve either.

First-record-wins is only safe once the records are known to agree, so this
calls `package_agreement_error` first and fails when two of them state
different `version`s or `language_version`s. `has_unreplaced_hook` stays
order-decided and deliberately unchecked: unlike the other two it is derived
at repo generation rather than stated by a developer, and two hubs can
legitimately disagree — one curating `code_assets` so the hook counts as
replaced while the other still flags it.

Split out from `collect_packages` because the dedup and union rules are a
pure function of the record list, which makes them directly testable
without synthesising `DartInfo`-bearing targets. The agreement check keeps
that property by living in its own function and returning its message.
"?
=List of unique DartPackageInfo providers in dependency order.2>
merge_package_records%@@rules_dart//dart/private:common.bzl
���native_assets_path_list?Returns the VM path-list for one code asset, per its link mode.*�
�
native_assets_path_list>
label1The consuming target's label, for error messages. (0
	link_modeOne of `CODE_ASSET_LINK_MODES`. (`
relative_lib_pathGPath to the library relative to the dill, for
`dynamic_loading_bundle`. (G

system_uri5The system library URI, for `dynamic_loading_system`. (?Returns the VM path-list for one code asset, per its link mode."5
3List of strings forming the asset's JSON path-list.2@
native_assets_path_list%@@rules_dart//dart/private:common.bzl
�	�	�noop_test_executable�Symlinks the do-nothing binary as a test rule's executable.

`dart_analyze_test` and `dart_format_test` both decide their verdict in a
build action: when the action fails the build fails, and nothing is left
for the test binary to check. Both must still *be* tests, so both hand
Bazel the same pass-through executable.
*�
�
noop_test_executableC
ctx8The rule context (must carry `WINDOWS_CONSTRAINT_ATTR`). (3
tool'The `//dart/private/tools:noop` target. (�Symlinks the do-nothing binary as a test rule's executable.

`dart_analyze_test` and `dart_format_test` both decide their verdict in a
build action: when the action fails the build fails, and nothing is left
for the test binary to check. Both must still *be* tests, so both hand
Bazel the same pass-through executable.
"�
�`struct(executable, runfiles)` — the declared symlink and the tool's own
runfiles, for the caller to merge with whatever stamp it produced.2=
noop_test_executable%@@rules_dart//dart/private:common.bzl
���own_package_record�Returns the `DartPackageInfo` for the package a `DartInfo` itself owns.

A `DartInfo` names its own package by `package_name`/`lib_root` but does
not carry that package's record: the record sits in `transitive_packages`
beside every dependency's. Both fields are the key, not the name alone —
one `package_name` legitimately maps to several `lib_root`s (a package
split across targets; two pub hubs each supplying `meta`), so matching on
the name would sometimes return a dependency's record instead of this
target's, and with it a dependency's language version.
*�
�
own_package_record
infoA `DartInfo`. (�Returns the `DartPackageInfo` for the package a `DartInfo` itself owns.

A `DartInfo` names its own package by `package_name`/`lib_root` but does
not carry that package's record: the record sits in `transitive_packages`
beside every dependency's. Both fields are the key, not the name alone —
one `package_name` legitimately maps to several `lib_root`s (a package
split across targets; two pub hubs each supplying `meta`), so matching on
the name would sometimes return a dependency's record instead of this
target's, and with it a dependency's language version.
"�
�The matching `DartPackageInfo`, or `None` when the target contributes no
package of its own (`dart_info_no_package`) or no record matches.2;
own_package_record%@@rules_dart//dart/private:common.bzl
���package_agreement_error�Reports every duplicate record that states facts its twin contradicts.

Two records for one `package_name` are normal — see `merge_package_records`
for why — but they are supposed to describe the *same* package. When they
disagree, `merge_package_records` keeps the first and discards the second,
which silently substitutes one version's entire source tree for the other's.
A skewed pair of lock files reproduces exactly that: the build succeeds, no
diagnostic is emitted, and a package compiles against sources its own lock
does not pin.

Only two *known* values can disagree. A record whose producer does not emit
the field carries "" — every `DartPackageInfo` built by a rule set that
predates it, and every hand-written `dart_library`, which has no version to
state. Treating "" as a disagreement would fail every dual-hub build
including the agreeing ones; treating it as "knows less" is what lets the
field be adopted one producer at a time.

Every disagreement is reported at once, across both fields, because the
cause is almost always one skew producing many of them: a pair of lock
files that drifted apart disagrees about every package whose version moved
between them. Naming only the first turns one reconciliation into a round
of fix-one, re-analyse, see-the-next per package, and `--keep_going` buys
nothing since every failing target reports that same first name. The full
list costs nothing to produce — it is already accumulated before the first
is found.

Pure, and separate from `merge_package_records`, for the same reason
`check_code_asset_ownership` is separate from `dart_info`: the caller owns
the `fail`, so the rule can be tested by calling it.
*�
�
package_agreement_errorL
merged>List of DartPackageInfo, with duplicates, in dependency order. (�Reports every duplicate record that states facts its twin contradicts.

Two records for one `package_name` are normal — see `merge_package_records`
for why — but they are supposed to describe the *same* package. When they
disagree, `merge_package_records` keeps the first and discards the second,
which silently substitutes one version's entire source tree for the other's.
A skewed pair of lock files reproduces exactly that: the build succeeds, no
diagnostic is emitted, and a package compiles against sources its own lock
does not pin.

Only two *known* values can disagree. A record whose producer does not emit
the field carries "" — every `DartPackageInfo` built by a rule set that
predates it, and every hand-written `dart_library`, which has no version to
state. Treating "" as a disagreement would fail every dual-hub build
including the agreeing ones; treating it as "knows less" is what lets the
field be adopted one producer at a time.

Every disagreement is reported at once, across both fields, because the
cause is almost always one skew producing many of them: a pair of lock
files that drifted apart disagrees about every package whose version moved
between them. Naming only the first turns one reconciliation into a round
of fix-one, re-analyse, see-the-next per package, and `--keep_going` buys
nothing since every failing target reports that same first name. The full
list costs nothing to produce — it is already accumulated before the first
is found.

Pure, and separate from `merge_package_records`, for the same reason
`check_code_asset_ownership` is separate from `dart_info`: the caller owns
the `fail`, so the rule can be tested by calling it.
"[
YAn error message string naming every disagreement, or `None` when every
duplicate agrees.2@
package_agreement_error%@@rules_dart//dart/private:common.bzl
���package_code_assets�Code assets declared on a `DartPackageInfo`, tolerating older producers.

`code_assets` is optional in the same sense `language_version` is: a
`DartPackageInfo` built against a rules_dart that predates the field omits
it, and such a record keeps working — it simply contributes no assets.
`//dart/tests/no_lv_fixture` pins that tolerance, emitting a record with
only `package_name` and `lib_root`.
*�
�
package_code_assets
pkgA `DartPackageInfo`. (�Code assets declared on a `DartPackageInfo`, tolerating older producers.

`code_assets` is optional in the same sense `language_version` is: a
`DartPackageInfo` built against a rules_dart that predates the field omits
it, and such a record keeps working — it simply contributes no assets.
`//dart/tests/no_lv_fixture` pins that tolerance, emitting a record with
only `package_name` and `lib_root`.
"?
=Tuple of `DartCodeAssetInfo`; empty when the field is absent.2<
package_code_assets%@@rules_dart//dart/private:common.bzl
gg�relative_path�Compute the relative path from one directory to another.

Both paths must be in the same coordinate system (e.g., both exec-root-relative).
*�
�
relative_path,
from_dirThe starting directory path. ((
to_dirThe target directory path. (�Compute the relative path from one directory to another.

Both paths must be in the same coordinate system (e.g., both exec-root-relative).
"1
/A relative path string from from_dir to to_dir.26
relative_path%@@rules_dart//dart/private:common.bzl
���	resolve_code_assets�Unions transitively-propagated code assets with explicitly named ones.

An asset id may legitimately arrive many times — through a diamond, or
because the user named explicitly what a dependency already supplies. Those
collapse. Two *different* assets claiming one id do not: the Dart VM
resolves an id to exactly one library, so silently keeping either one would
pick a native library by graph-traversal order.
*�
�
resolve_code_assets>
label1The consuming target's label, for error messages. (D
transitive_assets+`DartCodeAssetInfo` reached through `deps`. (K
explicit_assets4`DartCodeAssetInfo` named in the `code_assets` attr. (�Unions transitively-propagated code assets with explicitly named ones.

An asset id may legitimately arrive many times — through a diamond, or
because the user named explicitly what a dependency already supplies. Those
collapse. Two *different* assets claiming one id do not: the Dart VM
resolves an id to exactly one library, so silently keeping either one would
pick a native library by graph-traversal order.
"C
AList of `DartCodeAssetInfo`, one per asset id, in a stable order.2<
resolve_code_assets%@@rules_dart//dart/private:common.bzl
�	�	�resolve_package_identity�Resolves a rule's Dart package identity from `package` or inline attrs.

Two ways to state one thing would be two ways for it to be wrong, so this
refuses the overlap outright rather than defining a precedence: a rule that
sets `package` and an inline attribute fails, whether or not the two agree.
Agreement today is not agreement after the next edit, and a silently ignored
attribute is the failure this whole mechanism exists to remove. The same
call `analyze_operand` makes for `target` / `lib`.

Tolerant about which attributes the calling rule actually declares:
`dart_format_test` has a `language_version` and no `package_name`, and a
rule that grows one later needs no change here.
*�
�
resolve_package_identityj
ctx_The rule context. Must declare `package`; may declare
`package_name` and/or `language_version`. (�Resolves a rule's Dart package identity from `package` or inline attrs.

Two ways to state one thing would be two ways for it to be wrong, so this
refuses the overlap outright rather than defining a precedence: a rule that
sets `package` and an inline attribute fails, whether or not the two agree.
Agreement today is not agreement after the next edit, and a silently ignored
attribute is the failure this whole mechanism exists to remove. The same
call `analyze_operand` makes for `target` / `lib`.

Tolerant about which attributes the calling rule actually declares:
`dart_format_test` has a `language_version` and no `package_name`, and a
rule that grows one later needs no change here.
"F
D`struct(package_name, language_version)`, either of which may be "".2A
resolve_package_identity%@@rules_dart//dart/private:common.bzl
���resolve_package_roots�
Match packages to source files, returning exec-root-relative roots.

Ownership is `package_for`'s and only `package_for`'s: a file resolves a
package's root only if it is one the package could actually export — under
`<lib_root>/lib/`, or the `lib_root` directory itself. Matching anything
else under `lib_root` was the bug: a `dart_test` sitting in the same Bazel
package as the library it tests (`packages/foo/BUILD.bazel` declaring both
`dart_library(foo)` and its test, which is the ordinary pub layout) makes
the rule declare its dependencies' assembled `.pkgsrcs` directories at
`packages/foo/<test>.<dep>.pkgsrcs`. That path starts with `packages/foo/`,
so `foo` claimed it and resolved its own root to
`bazel-out/.../bin/packages/foo` — a directory with no `lib/` in it — and
every `package:foo/…` import failed to read.

Having the match live in one function also keeps this in step with
`generate_dev_package_config`, which groups the same files by `package_for`
and then reads the roots computed here; the two disagreeing meant a
package's files and its root could come from different packages.

Two or more packages with an empty `lib_root` are ambiguous — the
empty-prefix match would race to claim any `lib/`-prefixed source.
Fail loud if detected; callers should not be building transitive
`DartInfo` graphs with colliding root assignments.
*�
�
resolve_package_roots2
packages"List of DartPackageInfo providers. (H
all_srcs8List of File objects from the transitive source closure. (�
Match packages to source files, returning exec-root-relative roots.

Ownership is `package_for`'s and only `package_for`'s: a file resolves a
package's root only if it is one the package could actually export — under
`<lib_root>/lib/`, or the `lib_root` directory itself. Matching anything
else under `lib_root` was the bug: a `dart_test` sitting in the same Bazel
package as the library it tests (`packages/foo/BUILD.bazel` declaring both
`dart_library(foo)` and its test, which is the ordinary pub layout) makes
the rule declare its dependencies' assembled `.pkgsrcs` directories at
`packages/foo/<test>.<dep>.pkgsrcs`. That path starts with `packages/foo/`,
so `foo` claimed it and resolved its own root to
`bazel-out/.../bin/packages/foo` — a directory with no `lib/` in it — and
every `package:foo/…` import failed to read.

Having the match live in one function also keeps this in step with
`generate_dev_package_config`, which groups the same files by `package_for`
and then reads the roots computed here; the two disagreeing meant a
package's files and its root could come from different packages.

Two or more packages with an empty `lib_root` are ambiguous — the
empty-prefix match would race to claim any `lib/`-prefixed source.
Fail loud if detected; callers should not be building transitive
`DartInfo` graphs with colliding root assignments.
"D
BDict mapping package_name to exec-root-relative package root path.2>
resolve_package_roots%@@rules_dart//dart/private:common.bzl
���runfiles_path-Convert a File to its runfiles-relative path.*�
�
runfiles_path
fA File object. (>
workspace_name(The workspace name (ctx.workspace_name). (-Convert a File to its runfiles-relative path."$
"The runfiles-relative path string.26
runfiles_path%@@rules_dart//dart/private:common.bzl
::�same_package_library_dep_files�Returns same-package sibling files from `deps` plus the package's lib_root.

Files at `<lib_root>/lib/...` in any transitive package whose name
matches `package_name` are returned. Filenames whose exec path is in
`exclude_paths` (e.g. the action's own `src` file) are skipped so the
input isn't staged twice.
*�
�
same_package_library_dep_files0
deps$List of targets carrying `DartInfo`. (7
package_name#The Dart package name to filter on. (D
exclude_paths+Optional list of exec path strings to skip.None(�Returns same-package sibling files from `deps` plus the package's lib_root.

Files at `<lib_root>/lib/...` in any transitive package whose name
matches `package_name` are returned. Filenames whose exec path is in
`exclude_paths` (e.g. the action's own `src` file) are skipped so the
input isn't staged twice.
"�
�`(files, lib_root)` — the matching sibling Files and the package's
lib_root. Returns `([], None)` when no matching package is found.2G
same_package_library_dep_files%@@rules_dart//dart/private:common.bzl
���sdk_path_from_dart�Returns the SDK installation root by stripping `/bin/dart` from a dart File path.

AOT-compiled shims pass this via `--sdk-path` so the analyzer's
`AnalysisContextCollection` can locate the SDK's libraries.
*�
�
sdk_path_from_dart8
	dart_file'The toolchain's `dart` executable File. (�Returns the SDK installation root by stripping `/bin/dart` from a dart File path.

AOT-compiled shims pass this via `--sdk-path` so the analyzer's
`AnalysisContextCollection` can locate the SDK's libraries.
"
The SDK root path string.2;
sdk_path_from_dart%@@rules_dart//dart/private:common.bzl
���synth_package_config@Synthesises a `package_config.json` from `dart_library` targets.*�
�
synth_package_config>
ctx3The rule context (used to declare the output file). (<
library_deps(List of `dart_library` targets to merge. (@Synthesises a `package_config.json` from `dart_library` targets."�
�`(package_config_file, transitive_srcs_depset)`, or `(None, None)`
when `library_deps` is empty. The caller is expected to add both to
the action's `inputs` (the depset flattens lazily at execution time).2=
synth_package_config%@@rules_dart//dart/private:common.bzl
���target_dart_abi�Returns the Dart code-asset ABI string for the target platform.

Format `<os>_<arch>` (e.g. `macos_arm64`, `linux_x64`, `windows_x64`,
`linux_riscv64`, `linux_arm`), matching
`kTargetOperatingSystemName_kTargetArchitectureName` in the VM
(`runtime/vm/ffi/native_assets.cc`) and the `TARGET_PLATFORMS` table in
`toolchains_repo.bzl`. Reads `DART_ABI_CONSTRAINT_ATTRS` constraints.
*�
�
target_dart_abiO
ctxDThe rule context (must spread `DART_ABI_CONSTRAINT_ATTRS` in attrs). (�Returns the Dart code-asset ABI string for the target platform.

Format `<os>_<arch>` (e.g. `macos_arm64`, `linux_x64`, `windows_x64`,
`linux_riscv64`, `linux_arm`), matching
`kTargetOperatingSystemName_kTargetArchitectureName` in the VM
(`runtime/vm/ffi/native_assets.cc`) and the `TARGET_PLATFORMS` table in
`toolchains_repo.bzl`. Reads `DART_ABI_CONSTRAINT_ATTRS` constraints.
"
The `<os>_<arch>` ABI string.28
target_dart_abi%@@rules_dart//dart/private:common.bzl
���writable_home_env�The environment an SDK build action needs to have a writable home.

Windows `dart.exe` takes a POSIX `/tmp` literally and crashes, so it is
pointed at a directory that exists on the platform running it instead.
*�
�
writable_home_envJ
dart>The SDK's `dart` File, whose basename identifies the platform. (@
beside2A File whose directory serves as the Windows home. (�The environment an SDK build action needs to have a writable home.

Windows `dart.exe` takes a POSIX `/tmp` literally and crashes, so it is
pointed at a directory that exists on the platform running it instead.
"*
(A dict for `ctx.actions.run(env = ...)`.2:
writable_home_env%@@rules_dart//dart/private:common.bzl
���
//dart:providers.bzlr�
!

rules_dartdartproviders.bzl<
CODE_ASSET_LINK_MODESCODE_ASSET_LINK_MODES
*?@
DartAnalysisOptionsInfoDartAnalysisOptionsInfo
CZ6
DartAnalyzableInfoDartAnalyzableInfo
^p"
DartInfoDartInfo
t|B
DartPackageMetadataInfoDartPackageMetadataInfo
��
��
//dart/private:dart_info.bzlr�
)

rules_dartdart/privatedart_info.bzl:
derived_package_infoderived_package_info
2F6
package_lib_prefixpackage_lib_prefix
J\
^�
//dart/private:source_set.bzlr�
*

rules_dartdart/privatesource_set.bzl<
needs_source_assemblyneeds_source_assembly
3H(
package_forpackage_for
LW
Y-	DEFAULT_ROOT_LANGUAGE_VERSION3.0j3.0�
	BASH_RUNFILES_INIT�# --- begin runfiles.bash initialization v3 ---
set -uo pipefail; set +e; f=bazel_tools/tools/bash/runfiles/runfiles.bash
# shellcheck disable=SC1090
source "${RUNFILES_DIR:-/dev/null}/$f" 2>/dev/null ||   source "$(grep -sm1 "^$f " "${RUNFILES_MANIFEST_FILE:-/dev/null}" | cut -f2- -d' ')" 2>/dev/null ||   source "$0.runfiles/$f" 2>/dev/null ||   source "$(grep -sm1 "^$f " "$0.runfiles_manifest" | cut -f2- -d' ')" 2>/dev/null ||   source "$(grep -sm1 "^$f " "$0.exe.runfiles_manifest" | cut -f2- -d' ')" 2>/dev/null ||   { echo>&2 "ERROR: cannot find $f"; exit 1; }; f=; set -e
# --- end runfiles.bash initialization v3 ---j��# --- begin runfiles.bash initialization v3 ---
set -uo pipefail; set +e; f=bazel_tools/tools/bash/runfiles/runfiles.bash
# shellcheck disable=SC1090
source "${RUNFILES_DIR:-/dev/null}/$f" 2>/dev/null ||   source "$(grep -sm1 "^$f " "${RUNFILES_MANIFEST_FILE:-/dev/null}" | cut -f2- -d' ')" 2>/dev/null ||   source "$0.runfiles/$f" 2>/dev/null ||   source "$(grep -sm1 "^$f " "$0.runfiles_manifest" | cut -f2- -d' ')" 2>/dev/null ||   source "$(grep -sm1 "^$f " "$0.exe.runfiles_manifest" | cut -f2- -d' ')" 2>/dev/null ||   { echo>&2 "ERROR: cannot find $f"; exit 1; }; f=; set -e
# --- end runfiles.bash initialization v3 --- Shared utilities for Dart rules.�C
6

rules_dartdart/privatedart_aggregate_codegen.bzl�-dart_aggregate_codegenfRuns a package-level aggregate Dart code generator, producing one or more declared outputs per target."�,
�
dart_aggregate_codegenfRuns a package-level aggregate Dart code generator, producing one or more declared outputs per target.*
nameA unique name for this target. �

asset_deps�Non-Dart files the Builder's `Resolver` / `findAssets` must see (e.g. generated data shards, JSON/YAML sidecars). Each file is staged and passed as `--dep <exec>|<asset>` using `asset_path_for`.2[]U
configEBuilder options as a JSON object string. Passed as `--config <json>`.2""�
deps�`dart_library`-shaped targets (anything exporting `DartInfo`) whose transitive sources populate a synthesised `package_config.json`. Same-package siblings not already in `srcs` are auto-staged as `--dep`.*

DartInfo2[]X
generator_args@Escape-hatch additional arguments. Prefer the typed attrs above.2[]�
generator_binxPre-compiled generator executable matching the rules_dart shim CLI contract. Mutually exclusive with `generator_script`.2Noney
generator_script]A `.dart` script to run via `dart run` as the generator. Mutually exclusive with `generator`.2None�
language_versionrDart language version of the consuming package, in `<major>.<minor>` form. Empty falls back to a built-in default.2""�
outputs�Output file paths (package-relative). One entry per builder-produced extension â e.g. `['lib/app.config.dart', 'lib/app.module.dart']` for injectable's config stage. �
package�A `dart_package_metadata` declaring this Dart package's `package_name` and `language_version`. Mutually exclusive with the inline `package_name` / `language_version` attributes: set `package` to state those facts once for every rule building this package, or set them inline, but never both. Referencing a target is what lets rules in *different* BUILD files share one declaration, which a macro cannot do.*
DartPackageMetadataInfo2Noneq
package_configWOptional pre-existing `package_config.json`; overrides the one synthesised from `deps`.2None�
package_name�Dart package name owning `srcs`. Must match the consuming `dart_library`'s `package_name` â enforced where the two meet, in that library's `srcs`. Set this or `package`, not both; `package` is how one declaration serves every rule building the package, including rules in other BUILD files.2""a
partsRAdditional input files passed as `--part <path>` (for combining-style aggregates).2[]�
srcs�All source files the builder analyses. The first entry is the primary input passed as `--input` (its extension must match one in the builder's `buildExtensions` map); the rest are passed as `--input-asset-extra` and staged so the Builder's `findAssets` / `readAsString` see them. Typically a mix of `.dart` source files and generated data shards (e.g. `.injectable.json` for the injectable aggregate). "O
dart_aggregate_codegen5@@rules_dart//dart/private:dart_aggregate_codegen.bzl
��,
*
nameA unique name for this target. �
�

asset_deps�Non-Dart files the Builder's `Resolver` / `findAssets` must see (e.g. generated data shards, JSON/YAML sidecars). Each file is staged and passed as `--dep <exec>|<asset>` using `asset_path_for`.2[]W
U
configEBuilder options as a JSON object string. Passed as `--config <json>`.2""�
�
deps�`dart_library`-shaped targets (anything exporting `DartInfo`) whose transitive sources populate a synthesised `package_config.json`. Same-package siblings not already in `srcs` are auto-staged as `--dep`.*

DartInfo2[]Z
X
generator_args@Escape-hatch additional arguments. Prefer the typed attrs above.2[]�
�
generator_binxPre-compiled generator executable matching the rules_dart shim CLI contract. Mutually exclusive with `generator_script`.2None{
y
generator_script]A `.dart` script to run via `dart run` as the generator. Mutually exclusive with `generator`.2None�
�
language_versionrDart language version of the consuming package, in `<major>.<minor>` form. Empty falls back to a built-in default.2""�
�
outputs�Output file paths (package-relative). One entry per builder-produced extension â e.g. `['lib/app.config.dart', 'lib/app.module.dart']` for injectable's config stage. �
�
package�A `dart_package_metadata` declaring this Dart package's `package_name` and `language_version`. Mutually exclusive with the inline `package_name` / `language_version` attributes: set `package` to state those facts once for every rule building this package, or set them inline, but never both. Referencing a target is what lets rules in *different* BUILD files share one declaration, which a macro cannot do.*
DartPackageMetadataInfo2Nones
q
package_configWOptional pre-existing `package_config.json`; overrides the one synthesised from `deps`.2None�
�
package_name�Dart package name owning `srcs`. Must match the consuming `dart_library`'s `package_name` â enforced where the two meet, in that library's `srcs`. Set this or `package`, not both; `package` is how one declaration serves every rule building the package, including rules in other BUILD files.2""c
a
partsRAdditional input files passed as `--part <path>` (for combining-style aggregates).2[]�
�
srcs�All source files the builder analyses. The first entry is the primary input passed as `--input` (its extension must match one in the builder's `buildExtensions` map); the rest are passed as `--input-asset-extra` and staged so the Builder's `findAssets` / `readAsString` see them. Typically a mix of `.dart` source files and generated data shards (e.g. `.injectable.json` for the injectable aggregate). �
//dart:providers.bzlr�
!

rules_dartdartproviders.bzl"
DartInfoDartInfo
0*02@
DartPackageMetadataInfoDartPackageMetadataInfo
060M
00O�
//dart/private:common.bzlr�
&

rules_dartdart/private
common.bzlL
DEFAULT_ROOT_LANGUAGE_VERSIONDEFAULT_ROOT_LANGUAGE_VERSION
33#>
PACKAGE_IDENTITY_ATTRSPACKAGE_IDENTITY_ATTRS
44>
add_shim_contract_argsadd_shim_contract_args
55.
asset_path_forasset_path_for
66D
dart_lib_root_for_packagedart_lib_root_for_package
77B
resolve_package_identityresolve_package_identity
88N
same_package_library_dep_filessame_package_library_dep_files
99$:
synth_package_configsynth_package_config
::
1;�Package-level aggregate Dart code generation.

Unlike per-file `dart_codegen`, `dart_aggregate_codegen` takes ALL sources
in a Dart package and produces one or more aggregate outputs. Used by
builders like `injectable_generator`'s config stage (DI container +
optional modules) and any `PackageBuilder` that needs a whole-package
view of metadata.

The generator (`generator` binary or `generator_script`) receives:

  - `--input <path>`: the primary input (first entry in `srcs`).
  - `--input-asset <asset>`: the primary's Dart asset path.
  - `--input-asset-extra <exec>|<asset>` (repeatable): one per additional
    source in `srcs`. Exposed to the Builder as primary asset inputs.
  - `--output <path>` (repeatable): one per `outputs` entry. Multi-output
    aggregates (e.g. injectable config emitting both `.config.dart` and
    `.module.dart`) declare all paths here.
  - `--dep <exec>|<asset>` (repeatable): one per auto-staged sibling.
  - `--part <path>` (repeatable): each `parts` entry.
  - `--package <name>`: the Dart package name.
  - `--config <json>`: builder options as a JSON object string.
  - `--package-config <path>`: synthesised from `deps`.
  - `--root-language-version <major.minor>`.
  - `--sdk-path <path>`.

Usage:

    load("@rules_dart//dart:defs.bzl", "dart_aggregate_codegen")

    dart_aggregate_codegen(
        name = "di_config",
        srcs = [":metadata_shards"] + SAME_PACKAGE_SOURCES,
        generator_bin = "@rules_dart//dart/ext/injectable:shim_config",
        outputs = ["lib/main.config.dart", "lib/main.module.dart"],
        deps = ["@pub_deps//:injectable"],
        package_name = "my_app",
    )

`deps` is a list of `dart_library`-shaped targets (anything exporting
`DartInfo`). Their transitive sources populate a synthesised
`package_config.json` for the shim's analyzer; any same-package sibling
not already in `srcs` is auto-staged as `--dep`.

Worker mode (`supports-workers=1`, protobuf, singleplex) is enabled for
`generator_bin` actions; worker requests go through `dart/ext/lib/worker_entry.dart`.
�
5

rules_dartdart/privatedart_analysis_options.bzl�dart_analysis_options�An `analysis_options.yaml` bundled with the packages its `include:` directives resolve against, for use as `dart_analyze_test`'s `options`."�
�
dart_analysis_options�An `analysis_options.yaml` bundled with the packages its `include:` directives resolve against, for use as `dart_analyze_test`'s `options`.*
nameA unique name for this target. �
deps�Dart packages whose files this options file `include`s by `package:` URI. Staged for resolution only â these are not analyzed, and do not become dependencies of the analyzed library.*

DartInfo2[],
src!The `analysis_options.yaml` file. "M
dart_analysis_options4@@rules_dart//dart/private:dart_analysis_options.bzl
--,
*
nameA unique name for this target. �
�
deps�Dart packages whose files this options file `include`s by `package:` URI. Staged for resolution only â these are not analyzed, and do not become dependencies of the analyzed library.*

DartInfo2[].
,
src!The `analysis_options.yaml` file. �
//dart:providers.bzlr�
!

rules_dartdartproviders.bzl@
DartAnalysisOptionsInfoDartAnalysisOptionsInfo
*A"
DartInfoDartInfo
EM
O�
//dart/private:common.bzlr�
&

rules_dartdart/private
common.bzl2
collect_packagescollect_packages
/?J
collect_transitive_resourcescollect_transitive_resources
C_@
collect_transitive_srcscollect_transitive_srcs
cz
|�
Implementation of the dart_analysis_options rule.

An `analysis_options.yaml` is not always self-contained. The published way to
share a lint ruleset is to depend on a pub package and `include` its yaml by
`package:` URI:

    include: package:very_good_analysis/analysis_options.yaml

The analyzer resolves that URI through the *project's* `package_config.json`,
exactly as it resolves an import. So an options file is not merely a file â it
can carry package dependencies, and whether it loads depends on the package
closure of whatever project it is applied to.

Passing a bare `.yaml` label leaves no way to express that, and the only way to
make the include resolve is to add the ruleset to the analyzed library's own
`deps`. That works and is wrong: a lint ruleset then rides in the library's
`DartInfo`, so every `dart_binary` and `dart_test` downstream stages sources it
will never compile, and the package_config of unrelated targets grows an entry
that exists only to satisfy a linter.

This rule keeps the file and the packages its includes resolve against together
in one target, so `dart_analyze_test` can stage that closure for options
resolution alone. The packages land in the non-analyzed `extpkgs` region beside
pub sources â resolvable, never themselves analyzed â and never reach the
analyzed target's own provider.
�
,

rules_dartdart/privatedart_analyze.bzl�dart_analyze_testnRuns `dart analyze` on a Dart target as a build-time action. Fails the build if any analysis issues are found."�
�
dart_analyze_testnRuns `dart analyze` on a Dart target as a build-time action. Fails the build if any analysis issues are found.*
nameA unique name for this target. q
lib@Deprecated alias for `target`. Set one or the other, never both.*

DartInfo*
DartAnalyzableInfo2None�
options�A `dart_analysis_options` target, or a bare `analysis_options.yaml`. Use the target form when the file `include`s a ruleset by `package:` URI. If omitted, the Dart SDK's default analysis options are used, and are pinned hermetically rather than left to whatever file happens to sit above the staged sources.2None�
target�The target whose Dart sources to analyze â a `dart_library`, or a `dart_binary`/`dart_test`/web binary, whose entrypoint is analyzed along with its whole transitive closure.*

DartInfo*
DartAnalyzableInfo2None"@
dart_analyze_test+@@rules_dart//dart/private:dart_analyze.bzl
gg,
*
nameA unique name for this target. s
q
lib@Deprecated alias for `target`. Set one or the other, never both.*

DartInfo*
DartAnalyzableInfo2None�
�
options�A `dart_analysis_options` target, or a bare `analysis_options.yaml`. Use the target form when the file `include`s a ruleset by `package:` URI. If omitted, the Dart SDK's default analysis options are used, and are pinned hermetically rather than left to whatever file happens to sit above the staged sources.2None�
�
target�The target whose Dart sources to analyze â a `dart_library`, or a `dart_binary`/`dart_test`/web binary, whose entrypoint is analyzed along with its whole transitive closure.*

DartInfo*
DartAnalyzableInfo2None�
//dart:providers.bzlr�
!

rules_dartdartproviders.bzl6
DartAnalyzableInfoDartAnalyzableInfo
*<"
DartInfoDartInfo
@H
J�
//dart/private:common.bzlr�
&

rules_dartdart/private
common.bzl@
WINDOWS_CONSTRAINT_ATTRWINDOWS_CONSTRAINT_ATTR
B
analysis_options_closureanalysis_options_closure
6
analyzable_closureanalyzable_closure
0
analyze_operandanalyze_operand
<
merge_package_recordsmerge_package_records
:
noop_test_executablenoop_test_executable
4
writable_home_envwritable_home_env

�
"//dart/private:project_staging.bzlr�
/

rules_dartdart/privateproject_staging.bzl*
pubspec_stubpubspec_stub
8D6
stage_dart_projectstage_dart_project
HZ6
stage_root_optionsstage_root_options
^p
r�
//dart/private:source_set.bzlr�
*

rules_dartdart/privatesource_set.bzlJ
COPY_TO_DIRECTORY_TOOLCHAINSCOPY_TO_DIRECTORY_TOOLCHAINS
 3 O
  Q�Implementation of the dart_analyze_test rule.

Runs `dart analyze` on a Dart target as a Bazel test. The analysis runs at build
time as an action â if analysis fails, the build fails. The test target itself is
a trivial pass-through that always succeeds.

The operand is a `dart_library` or an executable (`dart_binary`, `dart_test`, a
web binary). An executable's entrypoint belongs to no package's `lib/`, so it
reaches this rule through `DartAnalyzableInfo` rather than `DartInfo` â see that
provider for why an executable does not simply hand out the latter.

The analyzer wants a project directory (pubspec.yaml, .dart_tool/, sources),
which is staged hermetically from declared artifacts (see `project_staging.bzl`)
and analyzed via the compiled `analyze_runner` tool â no shell, no mktemp.
External (pub) dep sources sit in sibling `extpkgs` trees outside the analyzed
directory: their `package:` imports resolve, but they are not themselves
analyzed (pub packages aren't held to this target's `--fatal-infos` bar).
�D
+

rules_dartdart/privatedart_binary.bzl�*dart_binary1Compiles a Dart application using `dart compile`."�*
�
dart_binary1Compiles a Dart application using `dart compile`.*
nameA unique name for this target. �
code_assets�Native code assets (e.g. `//dart/ext/sqlite3:code_asset`) the binary's `@Native` FFI bindings resolve against. When set, the main is compiled to a kernel with the code-asset mapping embedded (`gen_kernel --native-assets`) before the snapshot/exe is produced, and the libraries are staged in runfiles so the Dart VM resolves them relative to the executable at runtime. Each entry must provide `DartCodeAssetInfo` (see the `dart_code_asset` rule).*
DartCodeAssetInfo2[]�
code_assets_from_deps�Whether to pick up native code assets propagated through `deps`.

Leave this on for a program that runs the packages it depends on. Turn it off for a `dart_binary` used purely as a *build tool* â a code generator, a linter â which imports pub packages for their Dart API but never loads their native libraries. Without the opt-out such a tool would build (and in an exec configuration, cross-build) every native library anywhere in its dependency closure. rules_dart's own `dart/ext` builder shims set this to `False`: `drift_dev` depends on `package:sqlite3`, but generating code never calls into libsqlite3.

Also suppresses the unreplaced-`hook/build.dart` diagnostic, on the same grounds â a tool that never loads native code is unaffected by a package whose native code was not built.2True�
compile_mode�The `dart compile` mode. Determines the output format:

- `exe` (default): Self-contained native machine code. No Dart SDK needed at runtime. Best for deployment.
- `aot-snapshot`: AOT-compiled snapshot. Requires `dartaotruntime` to execute. Smaller than `exe`.
- `kernel`: Dart kernel binary (`.dill`). Requires `dart` to execute. Fastest compilation, useful for development.
- `jit-snapshot`: JIT snapshot with trained profile data. Requires `dart` to execute. Fastest startup after warmup.
2"exe"�
dart_compile_flags�Extra flags passed to `dart compile` after compilation-mode defaults. Flags appear last so they can override defaults (e.g., `--extra-gen-snapshot-options=--optimization_level=3`).2[]�
data�Additional files needed at runtime. These are added to runfiles so they can be found via the runfiles tree when using `bazel run`.2[]f
definesUDart environment declarations (`key=value`). Each entry becomes a `-Dkey=value` flag.2[]H
deps.`dart_library` targets this binary depends on.*

DartInfo2[]N
mainBThe Dart entrypoint file containing a top-level `main()` function. o
srcsaAdditional Dart source files that are part of this binary's package but not reachable via `deps`.2[]"9
dart_binary*@@rules_dart//dart/private:dart_binary.bzl
��,
*
nameA unique name for this target. �
�
code_assets�Native code assets (e.g. `//dart/ext/sqlite3:code_asset`) the binary's `@Native` FFI bindings resolve against. When set, the main is compiled to a kernel with the code-asset mapping embedded (`gen_kernel --native-assets`) before the snapshot/exe is produced, and the libraries are staged in runfiles so the Dart VM resolves them relative to the executable at runtime. Each entry must provide `DartCodeAssetInfo` (see the `dart_code_asset` rule).*
DartCodeAssetInfo2[]�
�
code_assets_from_deps�Whether to pick up native code assets propagated through `deps`.

Leave this on for a program that runs the packages it depends on. Turn it off for a `dart_binary` used purely as a *build tool* â a code generator, a linter â which imports pub packages for their Dart API but never loads their native libraries. Without the opt-out such a tool would build (and in an exec configuration, cross-build) every native library anywhere in its dependency closure. rules_dart's own `dart/ext` builder shims set this to `False`: `drift_dev` depends on `package:sqlite3`, but generating code never calls into libsqlite3.

Also suppresses the unreplaced-`hook/build.dart` diagnostic, on the same grounds â a tool that never loads native code is unaffected by a package whose native code was not built.2True�
�
compile_mode�The `dart compile` mode. Determines the output format:

- `exe` (default): Self-contained native machine code. No Dart SDK needed at runtime. Best for deployment.
- `aot-snapshot`: AOT-compiled snapshot. Requires `dartaotruntime` to execute. Smaller than `exe`.
- `kernel`: Dart kernel binary (`.dill`). Requires `dart` to execute. Fastest compilation, useful for development.
- `jit-snapshot`: JIT snapshot with trained profile data. Requires `dart` to execute. Fastest startup after warmup.
2"exe"�
�
dart_compile_flags�Extra flags passed to `dart compile` after compilation-mode defaults. Flags appear last so they can override defaults (e.g., `--extra-gen-snapshot-options=--optimization_level=3`).2[]�
�
data�Additional files needed at runtime. These are added to runfiles so they can be found via the runfiles tree when using `bazel run`.2[]h
f
definesUDart environment declarations (`key=value`). Each entry becomes a `-Dkey=value` flag.2[]J
H
deps.`dart_library` targets this binary depends on.*

DartInfo2[]P
N
mainBThe Dart entrypoint file containing a top-level `main()` function. q
o
srcsaAdditional Dart source files that are part of this binary's package but not reachable via `deps`.2[]�
binary_output_basename�Returns a `dart_binary`'s output filename with the platform exe extension.

Includes the platform-appropriate executable extension.

A native `exe` gets a `.exe` suffix on Windows so it is launchable and
discoverable by the conventional name (e.g. via runfiles
`rlocation("…/app.exe")`). Without it the output is a bare `app`, and a
consumer looking up `app.exe` misses — falling through to a non-existent
path. The snapshot modes use fixed extensions on every platform.
*�
�
binary_output_basename/
name#The target name (`ctx.label.name`). (K
compile_mode7One of `exe`, `aot-snapshot`, `kernel`, `jit-snapshot`. (9

is_windows'Whether the target platform is Windows. (�Returns a `dart_binary`'s output filename with the platform exe extension.

Includes the platform-appropriate executable extension.

A native `exe` gets a `.exe` suffix on Windows so it is launchable and
discoverable by the conventional name (e.g. via runfiles
`rlocation("…/app.exe")`). Without it the output is a bare `app`, and a
consumer looking up `app.exe` misses — falling through to a non-existent
path. The snapshot modes use fixed extensions on every platform.
"
The output filename string.2D
binary_output_basename*@@rules_dart//dart/private:dart_binary.bzl
�
//dart:providers.bzlr�
!

rules_dartdartproviders.bzl4
DartCodeAssetInfoDartCodeAssetInfo
*;0
DartCompileInfoDartCompileInfo
?N"
DartInfoDartInfo
RZ
\�
!//dart/private:build_settings.bzlr�
.

rules_dartdart/privatebuild_settings.bzl@
EXTRA_DART_DEFINES_ATTREXTRA_DART_DEFINES_ATTR
7N6
merge_dart_definesmerge_dart_defines
Rd
f�
//dart/private:common.bzlr�
&

rules_dartdart/private
common.bzlD
DART_ABI_CONSTRAINT_ATTRSDART_ABI_CONSTRAINT_ATTRS
>
check_unreplaced_hookscheck_unreplaced_hooks
6
code_asset_entriescode_asset_entries
		2
collect_packagescollect_packages


N
collect_transitive_code_assetscollect_transitive_code_assets
$J
collect_transitive_resourcescollect_transitive_resources
"@
collect_transitive_srcscollect_transitive_srcs
P
gen_kernel_native_assets_actiongen_kernel_native_assets_action
%H
generate_native_assets_yamlgenerate_native_assets_yaml
!@
generate_package_configgenerate_package_config
8
resolve_code_assetsresolve_code_assets
0
target_dart_abitarget_dart_abi

�
//dart/private:dart_compile.bzlrv
,

rules_dartdart/privatedart_compile.bzl8
dart_compile_actiondart_compile_action
5H
J�
//dart/private:dart_info.bzlru
)

rules_dartdart/privatedart_info.bzl:
dart_analyzable_infodart_analyzable_info
2F
H�
//dart/private:source_set.bzlr�
*

rules_dartdart/privatesource_set.bzlJ
COPY_TO_DIRECTORY_TOOLCHAINSCOPY_TO_DIRECTORY_TOOLCHAINS
3O8
colocate_entrypointcolocate_entrypoint
Sf4
colocate_packagescolocate_packages
j{
}'Implementation of the dart_binary rule.�
/

rules_dartdart/privatedart_code_asset.bzl�dart_code_assetwBinds a Bazel-built native dynamic library to a Dart code-asset id, for use in `dart_test`/`dart_binary` `code_assets`."�
�

dart_code_assetwBinds a Bazel-built native dynamic library to a Dart code-asset id, for use in `dart_test`/`dart_binary` `code_assets`.*
nameA unique name for this target. �
asset_id�The code-asset id the owning package's `@Native`/`@ffi.DefaultAsset` declares (e.g. `package:sqlite3/src/ffi/libsqlite3.g.dart`). �
	link_mode�How the runtime loads this asset. One of `dynamic_loading_bundle` (a Bazel-built library shipped alongside the app), `dynamic_loading_system` (a library already present on the target system, named by `system_uri`), `dynamic_loading_executable`, or `dynamic_loading_process`. The reserved `static` mode fails fast â neither the Dart VM nor the Flutter engine implements it.

May be a `select()`: an ext package that bundles on one platform and uses the system library on another expresses that here, and consumers see a single target.2"dynamic_loading_bundle"�
shared_library�A `cc_shared_library` target whose dynamic library backs this code asset. Required for `dynamic_loading_bundle`; forbidden for the other link modes.*
CcSharedLibraryInfo2None�

system_urivSystem library URI, e.g. `libsqlite3.so.0`. Required for `dynamic_loading_system`; forbidden for the other link modes.2"""A
dart_code_asset.@@rules_dart//dart/private:dart_code_asset.bzl
__,
*
nameA unique name for this target. �
�
asset_id�The code-asset id the owning package's `@Native`/`@ffi.DefaultAsset` declares (e.g. `package:sqlite3/src/ffi/libsqlite3.g.dart`). �
�
	link_mode�How the runtime loads this asset. One of `dynamic_loading_bundle` (a Bazel-built library shipped alongside the app), `dynamic_loading_system` (a library already present on the target system, named by `system_uri`), `dynamic_loading_executable`, or `dynamic_loading_process`. The reserved `static` mode fails fast â neither the Dart VM nor the Flutter engine implements it.

May be a `select()`: an ext package that bundles on one platform and uses the system library on another expresses that here, and consumers see a single target.2"dynamic_loading_bundle"�
�
shared_library�A `cc_shared_library` target whose dynamic library backs this code asset. Required for `dynamic_loading_bundle`; forbidden for the other link modes.*
CcSharedLibraryInfo2None�
�

system_urivSystem library URI, e.g. `libsqlite3.so.0`. Required for `dynamic_loading_system`; forbidden for the other link modes.2""�
&//cc/common:cc_shared_library_info.bzlr{
1
rules_cc	cc/commoncc_shared_library_info.bzl8
CcSharedLibraryInfoCcSharedLibraryInfo
:M
O�
//dart:providers.bzlr�
!

rules_dartdartproviders.bzl<
CODE_ASSET_LINK_MODESCODE_ASSET_LINK_MODES
*?4
DartCodeAssetInfoDartCodeAssetInfo
CT
V�The `dart_code_asset` rule.

Binds a `cc_shared_library` (a Bazel-built native dynamic library) to the Dart
code-asset id that the owning package's `@Native`/`@ffi.DefaultAsset` bindings
use. This is the seam between Bazel's native build and Dart's code-asset
resolution: `dart_test` / `dart_binary` consume `DartCodeAssetInfo` via their
`code_assets` attribute and synthesise the `native_assets.yaml` that
`gen_kernel --native-assets` embeds into the kernel.

Two-tier usage: a native-asset-owning package can ship a target exposing
`DartCodeAssetInfo` itself; otherwise rules_dart provides one under
`//dart/ext/<package>` (see `//dart/ext/sqlite3`).

`DartCodeAssetInfo` deliberately carries only what upstream's `CodeAsset`
carries â id, link mode, and the library. Bundling concerns (where the file
lands inside an application, what it is renamed to) belong to the consumer;
rules_flutter layers those on top of this provider rather than rules_dart
guessing at them.
�V
,

rules_dartdart/privatedart_codegen.bzl�5dart_codegenURuns a per-file Dart code generator, producing one or more sibling outputs per input."�4
�
dart_codegenURuns a per-file Dart code generator, producing one or more sibling outputs per input.*
nameA unique name for this target. �

asset_deps�Non-Dart files the Builder's `Resolver` / `findAssets` must see (e.g. `.drift` schemas, `.drift_prep.json` sidecars, `.yaml` configs read via `BuildStep`). Each file is staged as an action input and passed as `--dep <exec>|<asset>` using `asset_path_for`. For Dart libraries, use `deps`. For files that only need to exist on disk for a subprocess / runfile (not read through `package:build`), use `data`.2[]�
config�Builder options as a JSON object string. Passed as `--config <json>`. Shape mirrors build_runner's `build.yaml` `options:` block for the underlying builder.2""�
data�Additional data files added to the action inputs but not passed as flagged args. Sandbox-only â NOT visible to the Builder's `Resolver` / `findAssets`. For files the Builder must see via its AssetReader, use `asset_deps` instead.2[]�
deps�`dart_library`-shaped targets (anything exporting `DartInfo`) whose transitive sources populate a synthesised `package_config.json` for the shim's analyzer. Any file belonging to the same Dart package as `src` is also auto-staged as `--dep` so the Resolver can walk siblings.*

DartInfo2[]l
	generatorWA `.dart` script to run as the code generator. Mutually exclusive with `generator_bin`.2NoneX
generator_args@Escape-hatch additional arguments. Prefer the typed attrs above.2[]�
generator_binsA pre-compiled generator executable matching the rules_dart shim CLI contract. Mutually exclusive with `generator`.2None�
language_version�Dart language version of the consuming package, in `<major>.<minor>` form (e.g. `3.11`). When empty, defers to a built-in safe default â set explicitly only when pinning to a specific language-version behaviour.2""�
output_suffixes�One or more suffixes appended to the input stem to derive output file paths. E.g. `['.g.dart']` for a SharedPart combining output; `['.config.dart', '.module.dart']` for injectable's config stage, which emits both per input. At least one suffix is required. �
package�A `dart_package_metadata` declaring this Dart package's `package_name` and `language_version`. Mutually exclusive with the inline `package_name` / `language_version` attributes: set `package` to state those facts once for every rule building this package, or set them inline, but never both. Referencing a target is what lets rules in *different* BUILD files share one declaration, which a macro cannot do.*
DartPackageMetadataInfo2None�
package_config�Optional pre-existing `package_config.json` passed as `--package-config <path>`. When unset the rule synthesises one from `deps`.2None�
package_name�Dart package name owning `src`. Must match the consuming `dart_library`'s `package_name` â enforced where the two meet, in that library's `srcs`. Passed as `--package`. Set this or `package`, not both; `package` is how one declaration serves every rule building the package, including rules in other BUILD files.2""x
partsiAdditional input files passed as `--part <path>` (used by the combining shim to merge SharedPart shards).2[]]
srcRThe single `.dart` input file to process. Use one `dart_codegen` target per input. ";
dart_codegen+@@rules_dart//dart/private:dart_codegen.bzl
��,
*
nameA unique name for this target. �
�

asset_deps�Non-Dart files the Builder's `Resolver` / `findAssets` must see (e.g. `.drift` schemas, `.drift_prep.json` sidecars, `.yaml` configs read via `BuildStep`). Each file is staged as an action input and passed as `--dep <exec>|<asset>` using `asset_path_for`. For Dart libraries, use `deps`. For files that only need to exist on disk for a subprocess / runfile (not read through `package:build`), use `data`.2[]�
�
config�Builder options as a JSON object string. Passed as `--config <json>`. Shape mirrors build_runner's `build.yaml` `options:` block for the underlying builder.2""�
�
data�Additional data files added to the action inputs but not passed as flagged args. Sandbox-only â NOT visible to the Builder's `Resolver` / `findAssets`. For files the Builder must see via its AssetReader, use `asset_deps` instead.2[]�
�
deps�`dart_library`-shaped targets (anything exporting `DartInfo`) whose transitive sources populate a synthesised `package_config.json` for the shim's analyzer. Any file belonging to the same Dart package as `src` is also auto-staged as `--dep` so the Resolver can walk siblings.*

DartInfo2[]n
l
	generatorWA `.dart` script to run as the code generator. Mutually exclusive with `generator_bin`.2NoneZ
X
generator_args@Escape-hatch additional arguments. Prefer the typed attrs above.2[]�
�
generator_binsA pre-compiled generator executable matching the rules_dart shim CLI contract. Mutually exclusive with `generator`.2None�
�
language_version�Dart language version of the consuming package, in `<major>.<minor>` form (e.g. `3.11`). When empty, defers to a built-in safe default â set explicitly only when pinning to a specific language-version behaviour.2""�
�
output_suffixes�One or more suffixes appended to the input stem to derive output file paths. E.g. `['.g.dart']` for a SharedPart combining output; `['.config.dart', '.module.dart']` for injectable's config stage, which emits both per input. At least one suffix is required. �
�
package�A `dart_package_metadata` declaring this Dart package's `package_name` and `language_version`. Mutually exclusive with the inline `package_name` / `language_version` attributes: set `package` to state those facts once for every rule building this package, or set them inline, but never both. Referencing a target is what lets rules in *different* BUILD files share one declaration, which a macro cannot do.*
DartPackageMetadataInfo2None�
�
package_config�Optional pre-existing `package_config.json` passed as `--package-config <path>`. When unset the rule synthesises one from `deps`.2None�
�
package_name�Dart package name owning `src`. Must match the consuming `dart_library`'s `package_name` â enforced where the two meet, in that library's `srcs`. Passed as `--package`. Set this or `package`, not both; `package` is how one declaration serves every rule building the package, including rules in other BUILD files.2""z
x
partsiAdditional input files passed as `--part <path>` (used by the combining shim to merge SharedPart shards).2[]_
]
srcRThe single `.dart` input file to process. Use one `dart_codegen` target per input. �compute_codegen_output_namewCompute the output file path for a codegen source file.

Replaces the trailing `.dart` extension with `output_suffix`.
*�
�
compute_codegen_output_name>
src_path.Source file path (e.g. `some/dir/model.dart`). (O
output_suffix:Suffix to append after stripping `.dart` (e.g. `.g.dart`). (wCompute the output file path for a codegen source file.

Replaces the trailing `.dart` extension with `output_suffix`.
"6
4The output file path (e.g. `some/dir/model.g.dart`).2J
compute_codegen_output_name+@@rules_dart//dart/private:dart_codegen.bzl
JJ�
//dart:providers.bzlr�
!

rules_dartdartproviders.bzl"
DartInfoDartInfo
=*=2@
DartPackageMetadataInfoDartPackageMetadataInfo
=6=M
==O�
//dart/private:common.bzlr�
&

rules_dartdart/private
common.bzlL
DEFAULT_ROOT_LANGUAGE_VERSIONDEFAULT_ROOT_LANGUAGE_VERSION
@@#>
PACKAGE_IDENTITY_ATTRSPACKAGE_IDENTITY_ATTRS
AA>
add_shim_contract_argsadd_shim_contract_args
BB.
asset_path_forasset_path_for
CCD
dart_lib_root_for_packagedart_lib_root_for_package
DDB
resolve_package_identityresolve_package_identity
EEN
same_package_library_dep_filessame_package_library_dep_files
FF$:
synth_package_configsynth_package_config
GG
>H�Per-file Dart code generation.

Runs a `package:build` Builder (via the rules_dart shim runner) over a
single Dart source file, producing one or more sibling output files whose
paths derive from the input's stem + each entry in `output_suffixes`.

The generator (`generator` script or `generator_bin` binary) receives:

  - `--input <path>`: the input source file's exec-root path.
  - `--input-asset <asset>`: the input's Dart asset path, relative to the
    owning Dart package (e.g. `lib/src/models/user.dart`).
  - `--output <path>` (repeatable): one per `output_suffixes` entry.
  - `--package <name>`: the Dart package name owning the input.
  - `--dep <exec>|<asset>` (repeatable): one per same-package sibling file
    auto-staged from `deps`. The shim mounts each entry so the Builder's
    Resolver / `findAssets` / `readAsString` see it.
  - `--part <path>` (repeatable): one per `parts` entry, for the combining
    shim merging `.<builder>.g.part` shards into a final `.g.dart`.
  - `--config <json>`: builder options as a JSON object string.
  - `--package-config <path>`: a `package_config.json` synthesised from
    `deps`' transitive Dart packages. Overridden by the user-supplied
    `package_config` attr when set.
  - `--root-language-version <major.minor>`: the consuming package's Dart
    language version (propagated through the synthesised PackageConfig).
  - `--sdk-path <path>`: the Dart SDK root (the analyzer's AOT shim can't
    auto-detect it).
  - Anything in `generator_args` (escape hatch â prefer the typed attrs).

Usage:

    load("@rules_dart//dart:defs.bzl", "dart_codegen")

    dart_codegen(
        name = "user_g",
        src = "lib/user.dart",
        generator_bin = "@rules_dart//dart/ext/json_serializable:shim",
        output_suffixes = [".json_serializable.g.part"],
        package_name = "my_pkg",
        deps = [
            ":models",                          # same-package sibling
            "@pub_deps//:json_annotation",      # import source
        ],
    )

`deps` is a list of `dart_library`-shaped targets (anything exporting
`DartInfo`). Their transitive sources populate a `package_config.json`
so `package:` imports resolve; any file that belongs to the *same* Dart
package as `src` is also auto-staged as `--dep` so the Resolver can walk
sibling files without the caller listing them explicitly.

The generated files can be used as srcs in a downstream `dart_library`.

When `generator_bin` is set, actions run through a persistent Bazel worker
(singleplex, protobuf protocol) via `dart/ext/lib/worker_entry.dart` +
`package:bazel_worker`. The analyzer driver is fresh per request â
reusing across requests is a silent-corruption hazard due to
`source_gen`'s CWD-pinned `rootPackageName` â but the Dart VM startup
cost is amortised across the worker's lifetime.
�
,

rules_dartdart/privatedart_compile.bzl�	dart_compile_actionCreates a Dart compile action.*�	
�	
dart_compile_action
ctxThe rule context. ()
dart_binThe dart executable File. (B
	sdk_files1Depset of all SDK files needed for the toolchain. (�
main�The main File to add to action inputs. Usually the entrypoint
`.dart` File; an assembled directory when `main_path` points inside it. (R
srcsFList of all source Files needed for compilation (direct + transitive). (3
package_configThe package_config.json File. ()
outputThe output File to produce. (`
compile_modeGThe compilation mode ("exe", "aot-snapshot", "kernel", "jit-snapshot")."exe"(P
	target_os=Cross-compilation target OS (e.g. "linux"). Empty for native.""(Z
target_archECross-compilation target architecture (e.g. "x64"). Empty for native.""(S
extra_flags>Additional compiler flags (from dart_compile_flags attribute).[](H
defines7Environment declarations; each entry becomes a -D flag.[](�
	main_path}Optional path string to pass as the compile target instead of
`main.path` (e.g. a path inside an assembled `main` directory).None(Creates a Dart compile action.2B
dart_compile_action+@@rules_dart//dart/private:dart_compile.bzl
;;�defines_stage_error�Returns an error string if `defines` would reach the compiler too late.

`-D` values are consumed by the front end during constant evaluation —
`String.fromEnvironment` and friends resolve there, not at run time. When
`main` is a pre-built kernel (signalled by a `None` `package_config`) the
front end has already run, and `dart compile` accepts `-D` and silently
ignores it: no error, no warning, just the default value baked into the
output. Environment declarations for a kernel input have to go to whatever
action produced that kernel.
*�
�
defines_stage_errorA
defines2Environment declarations destined for this action. (a
package_configKThe `package_config.json` File, or None when `main` is
a pre-built `.dill`. (�Returns an error string if `defines` would reach the compiler too late.

`-D` values are consumed by the front end during constant evaluation —
`String.fromEnvironment` and friends resolve there, not at run time. When
`main` is a pre-built kernel (signalled by a `None` `package_config`) the
front end has already run, and `dart compile` accepts `-D` and silently
ignores it: no error, no warning, just the default value baked into the
output. Environment declarations for a kernel input have to go to whatever
action produced that kernel.
"9
7An error string, or None when the combination is sound.2B
defines_stage_error+@@rules_dart//dart/private:dart_compile.bzl
�get_compilation_mode_flags>Returns compiler flags for the current Bazel compilation mode.*�
�
get_compilation_mode_flagsG
ctx<The rule context (used to read ctx.var["COMPILATION_MODE"]). (\
compile_modeHThe Dart compile mode ("exe", "aot-snapshot", "kernel", "jit-snapshot"). (>Returns compiler flags for the current Bazel compilation mode."
A list of flag strings.2I
get_compilation_mode_flags+@@rules_dart//dart/private:dart_compile.bzl
�
//dart/private:common.bzlrl
&

rules_dartdart/private
common.bzl4
writable_home_envwritable_home_env
/@
B+Shared compilation action helpers for Dart.�(
(

rules_dartdart/privatedart_fix.bzl�dart_fix�Applies `dart fix` to a Dart target's sources. `bazel run` writes the fixes into the workspace; `bazel run ... -- --dry-run` prints them instead. Generated files are never written.

Output Groups:
  dart_fix_fixes: A directory of the changed files, at their workspace-relative paths.
  dart_fix_manifest: JSON recording which files were fixed and which changes were discarded as ineligible.

Build either directly to inspect what a run would do without rewriting anything, e.g. `bazel build //pkg:fix --output_groups=+dart_fix_manifest`."�
�

dart_fix�Applies `dart fix` to a Dart target's sources. `bazel run` writes the fixes into the workspace; `bazel run ... -- --dry-run` prints them instead. Generated files are never written.

Output Groups:
  dart_fix_fixes: A directory of the changed files, at their workspace-relative paths.
  dart_fix_manifest: JSON recording which files were fixed and which changes were discarded as ineligible.

Build either directly to inspect what a run would do without rewriting anything, e.g. `bazel build //pkg:fix --output_groups=+dart_fix_manifest`.*
nameA unique name for this target. q
lib@Deprecated alias for `target`. Set one or the other, never both.*

DartInfo*
DartAnalyzableInfo2None�
options�A `dart_analysis_options` target, or a bare `analysis_options.yaml`. Should be the same target the matching `dart_analyze_test` uses: fixes are driven by the lints that are enabled, so differing options mean `bazel run` cannot turn the analyze test green.2None�
target�The target whose Dart sources to fix â a `dart_library`, or a `dart_binary`/`dart_test`/web binary, whose entrypoint is fixed too. Its whole transitive closure is considered, matching `dart_analyze_test`.*

DartInfo*
DartAnalyzableInfo2None"3
dart_fix'@@rules_dart//dart/private:dart_fix.bzl
��,
*
nameA unique name for this target. s
q
lib@Deprecated alias for `target`. Set one or the other, never both.*

DartInfo*
DartAnalyzableInfo2None�
�
options�A `dart_analysis_options` target, or a bare `analysis_options.yaml`. Should be the same target the matching `dart_analyze_test` uses: fixes are driven by the lints that are enabled, so differing options mean `bazel run` cannot turn the analyze test green.2None�
�
target�The target whose Dart sources to fix â a `dart_library`, or a `dart_binary`/`dart_test`/web binary, whose entrypoint is fixed too. Its whole transitive closure is considered, matching `dart_analyze_test`.*

DartInfo*
DartAnalyzableInfo2None�
//dart:providers.bzlr�
!

rules_dartdartproviders.bzl6
DartAnalyzableInfoDartAnalyzableInfo
*<"
DartInfoDartInfo
@H
J�
//dart/private:common.bzlr�
&

rules_dartdart/private
common.bzl@
WINDOWS_CONSTRAINT_ATTRWINDOWS_CONSTRAINT_ATTR
B
analysis_options_closureanalysis_options_closure
6
analyzable_closureanalyzable_closure
  0
analyze_operandanalyze_operand
!!<
merge_package_recordsmerge_package_records
""4
writable_home_envwritable_home_env
##
$�
"//dart/private:project_staging.bzlr�
/

rules_dartdart/privateproject_staging.bzl*
pubspec_stubpubspec_stub
''6
stage_dart_projectstage_dart_project
((:
staged_pubspec_pathsstaged_pubspec_paths
))
%*�
//dart/private:source_set.bzlr�
*

rules_dartdart/privatesource_set.bzlJ
COPY_TO_DIRECTORY_TOOLCHAINSCOPY_TO_DIRECTORY_TOOLCHAINS
+3+O
++Q�Implementation of the dart_fix rule.

`dart fix --apply` is the analyzer's automated-fix pass â the quick-fixes an IDE
offers, driven by whatever lints `analysis_options.yaml` enables. Running it
under Bazel is awkward for one reason: it edits sources in place, and a build
action may only write to declared outputs inside a sandbox whose inputs are
read-only.

So the work splits in two. A build action computes the fixes hermetically â
staging the project exactly as `dart_analyze_test` does, fixing a scratch copy,
and emitting *only the changed files* plus a manifest â and the rule's
executable copies those files into the source tree under `bazel run`. That is
the same shape as `//tools:preset.update` and buildifier's check/fix split, and
it means the fixes are always computed from the sources currently on disk:
`bazel run` rebuilds the action first.

Generated files are protected twice over. A synthesized wrapper options file
excludes every staged non-source file, so the analyzer resolves them (a
hand-written library that `part`s its `.g.dart` does not analyze without it) but
proposes no fixes for them. And independently, only files that were `is_source`
at analysis time are ever eligible for write-back. The second is the guarantee;
the first only keeps `dart fix` from wasting passes on files it must not touch.
Both are needed because `dart fix`'s own built-in generated-file skip matches
`*.g.dart` and nothing else â a `.freezed.dart` part gets rewritten.
��
)

rules_dartdart/privatedart_info.bzl�	check_code_asset_ownership�Checks that every declared asset id is namespaced to this package.

Upstream requires `CodeAsset.id` to be `package:<package>/<name>` where
`<package>` is the package that owns the asset — "Code assets are
name-spaced in their own package to avoid naming conflicts". Since assets
ride `DartPackageInfo`, an id belonging to some other package would
propagate under the wrong owner and be impossible to trace back.
*�
�
check_code_asset_ownershipE
label8The owning rule's label (included in the error message). (;
package_name'The package name this library declares. (*
assetsList of `DartCodeAssetInfo`. (�Checks that every declared asset id is namespaced to this package.

Upstream requires `CodeAsset.id` to be `package:<package>/<name>` where
`<package>` is the package that owns the asset — "Code assets are
name-spaced in their own package to avoid naming conflicts". Since assets
ride `DartPackageInfo`, an id belonging to some other package would
propagate under the wrong owner and be impossible to trace back.
"=
;An error message string on the first mismatch, else `None`.2F
check_code_asset_ownership(@@rules_dart//dart/private:dart_info.bzl
ii�dart_analyzable_info�Builds a `DartAnalyzableInfo` for an executable target.

The third constructor, and the one place `DartAnalyzableInfo` is built. It
adds no depset of its own beyond `srcs`: the closure is the `DartInfo` that
`dart_info_no_package()` already knows how to merge, carried whole rather
than re-enumerated field by field — which is the mistake this file exists to
prevent, and which a provider with its own `transitive_*` fields would
reintroduce one merge at a time.

`srcs` is the one thing that `DartInfo` genuinely cannot carry. An
entrypoint contributes no package (under pub it belongs to the root package
but lives outside its `lib/`), so no `DartPackageInfo` can name it and no
`package:` URI reaches it — but the analyzer still has to see it.
*�	
�	
dart_analyzable_infoQ
depsCTargets providing `DartInfo` whose closures the entrypoint reaches.[](�
srcs�The target's own entrypoint sources (its `main` and `srcs`). Pass
the rule's own `File`s, before any colocation copy: consumers stage by
`short_path`, and a colocated copy's is the assembled directory's.[](�Builds a `DartAnalyzableInfo` for an executable target.

The third constructor, and the one place `DartAnalyzableInfo` is built. It
adds no depset of its own beyond `srcs`: the closure is the `DartInfo` that
`dart_info_no_package()` already knows how to merge, carried whole rather
than re-enumerated field by field — which is the mistake this file exists to
prevent, and which a provider with its own `transitive_*` fields would
reintroduce one merge at a time.

`srcs` is the one thing that `DartInfo` genuinely cannot carry. An
entrypoint contributes no package (under pub it belongs to the root package
but lives outside its `lib/`), so no `DartPackageInfo` can name it and no
`package:` URI reaches it — but the analyzer still has to see it.
"
A `DartAnalyzableInfo`.2@
dart_analyzable_info(@@rules_dart//dart/private:dart_info.bzl
���&!dart_analyzable_info_with_package�Builds a `DartAnalyzableInfo` for an executable that contributes a package.

The sibling of `dart_analyzable_info()`, for the one case its narrow
signature cannot state: a target that is an executable *and* owns a package.
A downstream `flutter_test` is the shape — it names a `package_name` and its
sources are that package's `lib/` files, which import each other by
`package:` URI. Built through `dart_analyzable_info()`, those imports have no
package record to resolve against and every one of them reports
`uri_does_not_exist`; the analyzer is right, because nothing in a
package-less closure names the package they ask for.

So this nests a `dart_info()` where the other nests a
`dart_info_no_package()`, and that is the whole difference. Neither
enumerates a `DartInfo` field, which is what keeps a rule in this position
from writing `DartAnalyzableInfo(dart_info = dart_info(...))` by hand — a
second construction site for the outer provider, and precisely what this
file exists to prevent.

The two source lists are not interchangeable, and swapping them fails
silently rather than loudly: staging places both by `short_path`, so
analysis resolves either way, and a `lib/` file routed through `srcs` is
merely invisible to every `DartInfo` consumer downstream. Split them by
`package:` reachability — a file under `lib_root`'s `lib/`, reachable as
`package:<package_name>/…`, belongs in `package_srcs`; a file outside it (a
`test/` entrypoint, a `bin/` main) belongs in `srcs`, which no
`DartPackageInfo` can name.
*�
�
!dart_analyzable_info_with_package?
label2The constructing rule's label, for error messages. (�
package_name�The Dart package name this target provides. Required: an
executable contributing no package is what `dart_analyzable_info()` is
for. (r
lib_rootb`short_path`-based path to the package root (parent of `lib/`).
Empty string for the root package. (�
language_version�Dart language version in `<major>.<minor>` form, or ""
when the package states none. Required to pass — not because a package
must have one, but because omitting the argument and stating `""` are
different intentions that used to produce the same call. An absent
`languageVersion` in `package_config.json` is not "no language version",
it is *the current SDK's*, so a forgotten argument silently compiles the
package under newer semantics than its pubspec allows. `""` remains a
legal, meaningful value; only not answering is gone. (H
deps:Targets providing `DartInfo` whose closures are merged in.[](�
srcs�The target's own sources belonging to no package's `lib/` — its
entrypoint. Pass the rule's own `File`s, before any colocation copy:
consumers stage by `short_path`, and a colocated copy's is the assembled
directory's.[](�
package_srcsjThe target's own sources that *are* the package's `lib/`
files, reachable as `package:<package_name>/…`.[](A
	resources.This target's own non-Dart files under `lib/`.[](R
code_assets=Targets providing `DartCodeAssetInfo` that this package owns.[](H
version7The package's own resolved version, or "" when unknown.""(�Builds a `DartAnalyzableInfo` for an executable that contributes a package.

The sibling of `dart_analyzable_info()`, for the one case its narrow
signature cannot state: a target that is an executable *and* owns a package.
A downstream `flutter_test` is the shape — it names a `package_name` and its
sources are that package's `lib/` files, which import each other by
`package:` URI. Built through `dart_analyzable_info()`, those imports have no
package record to resolve against and every one of them reports
`uri_does_not_exist`; the analyzer is right, because nothing in a
package-less closure names the package they ask for.

So this nests a `dart_info()` where the other nests a
`dart_info_no_package()`, and that is the whole difference. Neither
enumerates a `DartInfo` field, which is what keeps a rule in this position
from writing `DartAnalyzableInfo(dart_info = dart_info(...))` by hand — a
second construction site for the outer provider, and precisely what this
file exists to prevent.

The two source lists are not interchangeable, and swapping them fails
silently rather than loudly: staging places both by `short_path`, so
analysis resolves either way, and a `lib/` file routed through `srcs` is
merely invisible to every `DartInfo` consumer downstream. Split them by
`package:` reachability — a file under `lib_root`'s `lib/`, reachable as
`package:<package_name>/…`, belongs in `package_srcs`; a file outside it (a
`test/` entrypoint, a `bin/` main) belongs in `srcs`, which no
`DartPackageInfo` can name.
"F
DA `DartAnalyzableInfo` whose nested `DartInfo` records this package.2M
!dart_analyzable_info_with_package(@@rules_dart//dart/private:dart_info.bzl
���	dart_info�Builds a `DartInfo` for a library, merging its dependencies' closures.

The caller supplies only what this target contributes itself; everything
transitive is merged here. Adding a field to `DartInfo` is therefore a
change to this file and nothing else.

Attribute hygiene stays with the calling rule — whether `srcs` and
`srcs_dir` are mutually exclusive, whether a file sits under the package's
`lib/` — because those are statements about that rule's attributes, and a
rule generating its package as one tree artifact has no such files to check.
What belongs here is what is true of any `DartInfo`: the merges, the package
record, and code-asset ownership.
*�
�
	dart_info?
label2The constructing rule's label, for error messages. (?
package_name+The Dart package name this target provides. (r
lib_rootb`short_path`-based path to the package root (parent of `lib/`).
Empty string for the root package. (�
language_version�Dart language version in `<major>.<minor>` form, or ""
when the package states none. Required to pass — not because a package
must have one, but because omitting the argument and stating `""` are
different intentions that used to produce the same call. An absent
`languageVersion` in `package_config.json` is not "no language version",
it is *the current SDK's*, so a forgotten argument silently compiles the
package under newer semantics than its pubspec allows. `""` remains a
legal, meaningful value; only not answering is gone. (H
deps:Targets providing `DartInfo` whose closures are merged in.[](G
srcs9This target's own Dart sources (or its source directory).[](A
	resources.This target's own non-Dart files under `lib/`.[](R
code_assets=Targets providing `DartCodeAssetInfo` that this package owns.[](W
has_unreplaced_hook:Path of a pub build hook with no Bazel replacement,
or "".""(�
versionThe package's own resolved version, or "" when unknown. Only pub
spokes know it; a hand-written `dart_library` leaves it empty.""(�Builds a `DartInfo` for a library, merging its dependencies' closures.

The caller supplies only what this target contributes itself; everything
transitive is merged here. Adding a field to `DartInfo` is therefore a
change to this file and nothing else.

Attribute hygiene stays with the calling rule — whether `srcs` and
`srcs_dir` are mutually exclusive, whether a file sits under the package's
`lib/` — because those are statements about that rule's attributes, and a
rule generating its package as one tree artifact has no such files to check.
What belongs here is what is true of any `DartInfo`: the merges, the package
record, and code-asset ownership.
"
A `DartInfo`.25
	dart_info(@@rules_dart//dart/private:dart_info.bzl
���dart_info_no_package�Builds a `DartInfo` for a target that contributes no Dart package.

For a target that has to be listed in a `deps` attribute requiring
`DartInfo` but ships no Dart: `flutter_material_icons` provides a font, and
wants the provider present, not contributing. It records no
`DartPackageInfo`, so nothing it is listed on gains a `package_config.json`
entry or a source to compile.

There is deliberately no `package_name`, `lib_root`, `srcs`, `resources` or
`code_assets` here. `DartInfo.package_name` and `.lib_root` describe the
package a target contributes, and no consumer reads them off the provider —
package identity is read from `transitive_packages` — so a no-package target
reports the empty string for both rather than inventing a name with no
record behind it. Code assets are owned by a `DartPackageInfo`, which this
target does not have.

`deps` exists because a facade that groups other libraries is still a
coherent no-package target, and forwarding their closures is then the whole
job.
*�	
�	
dart_info_no_packageH
deps:Targets providing `DartInfo` whose closures are merged in.[](�Builds a `DartInfo` for a target that contributes no Dart package.

For a target that has to be listed in a `deps` attribute requiring
`DartInfo` but ships no Dart: `flutter_material_icons` provides a font, and
wants the provider present, not contributing. It records no
`DartPackageInfo`, so nothing it is listed on gains a `package_config.json`
entry or a source to compile.

There is deliberately no `package_name`, `lib_root`, `srcs`, `resources` or
`code_assets` here. `DartInfo.package_name` and `.lib_root` describe the
package a target contributes, and no consumer reads them off the provider —
package identity is read from `transitive_packages` — so a no-package target
reports the empty string for both rather than inventing a name with no
record behind it. Code assets are owned by a `DartPackageInfo`, which this
target does not have.

`deps` exists because a facade that groups other libraries is still a
coherent no-package target, and forwarding their closures is then the whole
job.
"D
BA `DartInfo` carrying its dependencies' closures and nothing else.2@
dart_info_no_package(@@rules_dart//dart/private:dart_info.bzl
���derived_package_info�Copies `pkg`, overriding the named fields and carrying the rest through.

Deriving one package record from another — `colocate_packages` rewriting
`lib_root` to an assembled directory, `merge_package_records` unioning two
records' assets — is a copy, not a construction, and the caller has an
opinion about one or two fields at most. Passing the rest through by
default means a field added to `DartPackageInfo` reaches every derived
record without those sites being touched, and means neither of them can be
the one that quietly drops it.

Reads are tolerant (`getattr` with a default) for the same reason
`package_code_assets` is: a `DartPackageInfo` built by an older producer,
or by `//dart/tests/no_lv_fixture`, legitimately omits the later fields,
and a derived copy of such a record should be as complete as the original
rather than failing on it.
*�	
�	
derived_package_infoN
pkgCThe `DartPackageInfo` (or `DartPackageInfo`-shaped struct) to copy. (F
lib_root2Replacement `lib_root`, or `None` to keep `pkg`'s.None(R
code_assets;Replacement `code_assets` tuple, or `None` to keep `pkg`'s.None(�Copies `pkg`, overriding the named fields and carrying the rest through.

Deriving one package record from another — `colocate_packages` rewriting
`lib_root` to an assembled directory, `merge_package_records` unioning two
records' assets — is a copy, not a construction, and the caller has an
opinion about one or two fields at most. Passing the rest through by
default means a field added to `DartPackageInfo` reaches every derived
record without those sites being touched, and means neither of them can be
the one that quietly drops it.

Reads are tolerant (`getattr` with a default) for the same reason
`package_code_assets` is: a `DartPackageInfo` built by an older producer,
or by `//dart/tests/no_lv_fixture`, legitimately omits the later fields,
and a derived copy of such a record should be as complete as the original
rather than failing on it.
"
A `DartPackageInfo`.2@
derived_package_info(@@rules_dart//dart/private:dart_info.bzl
���package_lib_prefix�Returns the short_path prefix under which a package's importable files live.

A Dart package resolves `package:<name>/x.dart` against `<lib_root>/lib/`,
so that — not `lib_root` itself — is the prefix that answers "does this file
belong to the package?" and "what is this file's package-relative path?".
The root package (empty `lib_root`) is the same rule with an empty left half,
which is the whole reason to write it once: open-coded, the conditional is
easy to drop, and dropping it silently widens the prefix to the package's
entire directory — `test/`, `tool/` and `bin/` included.

Lives here, next to the `DartPackageInfo` that defines `lib_root`, because
this file loads only `//dart:providers.bzl` while `source_set.bzl`,
`common.bzl` and `dart_library.bzl` — the three consumers — already load it.
Any other home would introduce a load cycle or a new edge.
*�	
�	
package_lib_prefixu
lib_rooteA `DartPackageInfo.lib_root` — the package root's short_path,
empty for the root workspace package. (�Returns the short_path prefix under which a package's importable files live.

A Dart package resolves `package:<name>/x.dart` against `<lib_root>/lib/`,
so that — not `lib_root` itself — is the prefix that answers "does this file
belong to the package?" and "what is this file's package-relative path?".
The root package (empty `lib_root`) is the same rule with an empty left half,
which is the whole reason to write it once: open-coded, the conditional is
easy to drop, and dropping it silently widens the prefix to the package's
entire directory — `test/`, `tool/` and `bin/` included.

Lives here, next to the `DartPackageInfo` that defines `lib_root`, because
this file loads only `//dart:providers.bzl` while `source_set.bzl`,
`common.bzl` and `dart_library.bzl` — the three consumers — already load it.
Any other home would introduce a load cycle or a new edge.
"B
@The trailing-slashed prefix, e.g. `"pkgs/sub/lib/"` or `"lib/"`.2>
package_lib_prefix(@@rules_dart//dart/private:dart_info.bzl
PP�
//dart:providers.bzlr�
!

rules_dartdartproviders.bzl6
DartAnalyzableInfoDartAnalyzableInfo
N*N<4
DartCodeAssetInfoDartCodeAssetInfo
N@NQ"
DartInfoDartInfo
NUN]0
DartPackageInfoDartPackageInfo
NaNp
NNr�&Construction of `DartInfo` and the `DartPackageInfo` records it carries.

`DartInfo` is read by everything and built by more than rules_dart: a rule set
that wraps Dart libraries â `flutter_library`, `dart_proto_library` â has to
produce one too. Building it by hand means enumerating every field and merging
every transitive depset one at a time, which made each new field a breaking
change for every such rule set, and made each of them independently work out how
the new field merges.

The worse half of that is not the churn. When a field is missing, the correct
fix (forward the dependencies' values) and the tempting fix (declare it
`depset()` to silence the error) look identical in a diff, and the second one
silently drops every dependency's contribution at that boundary. Handing the
merge to one function makes that mistake unrepresentable rather than merely
warned against.

Two constructors cover every `DartInfo` a build produces. `dart_info()` is for a
target that *contributes a package* â it always records one `DartPackageInfo` of
its own. `dart_info_no_package()` is for one that deliberately carries none:
`flutter_material_icons` ships a font and no Dart, and provides `DartInfo` only
because `flutter_application(deps = ...)` requires one on every dep. Neither
takes a field list, and the enumeration they share lives in `_merged_dart_info`
below, so a field added to `DartInfo` is a change to this file and nowhere else.

The narrow signature is the point for the second one. A target with no package
can have no `srcs`, no `lib_root`, and no `code_assets` â assets ride
`DartPackageInfo`, which it does not have â so leaving them out makes the
degeneracy structural rather than a convention a caller has to honour.

`DartPackageInfo` â the record `transitive_packages` carries â has a second
construction shape that needed the same treatment: *derivation*.
`colocate_packages` rewrites a package's `lib_root` to its assembled directory
and `merge_package_records` unions two records' code assets; each builds a
record from an existing one. Hand-written, those sites re-list the fields they
carry, and a field one of them forgets is dropped from *that record only* â so
the loss is conditional on which build shape reached which site (a package that
happened to need source assembly loses it, a pure-source package keeps it),
which is worse to diagnose than losing it everywhere. `derived_package_info()`
carries every field through and overrides only what is named.

`DartAnalyzableInfo` is built here for the same reason rather than beside the
rules that provide it: it is a `DartInfo` plus the sources that belong to no
package's `lib/`, and the tempting alternative â a provider with its own
`transitive_*` fields â is precisely the second enumeration point everything
above exists to prevent. Its two constructors therefore nest a `DartInfo` some
constructor above built, instead of restating any part of it:
`dart_analyzable_info()` nests a `dart_info_no_package()` for an entrypoint that
contributes nothing, and `dart_analyzable_info_with_package()` nests a
`dart_info()` for an executable whose sources *are* a package â the shape a
downstream `flutter_test` has, and the one that made hand-building the outer
provider look like the only option.

So construction goes through here and reading does not: `DartInfo` stays public
and is indexed directly by every consumer. The one deliberate exception is
`//dart/tests/no_lv_fixture`, which hand-builds a provider missing
`language_version` precisely to prove the tolerance for pre-existing shapes
still holds; a fixture asserting that older producers keep working cannot be
written through a constructor that makes them current.

`language_version` is the one parameter these constructors require rather than
default, which is a deliberate exception to the paragraph above: adding a field
here is supposed to reach every call site *without* touching them, and this one
obliges every caller to state it. The reason is that its empty value is not
inert. An absent `languageVersion` in a generated `package_config.json` does not
mean "no language version" â the SDK reads it as the *current* one, so a caller
that simply forgot the argument silently compiles that package under newer
syntax and semantics than its own pubspec allows. Defaulting made "I forgot" and
"this package states none" the same call, and the two have different
consequences. The other optional parameters do not share that shape: the
collections mean "none of these", `version`'s empty is a supported state
`package_agreement_error` reads as "knows less", and `has_unreplaced_hook` is
derived at repository generation rather than stated by a developer. Requiring the
argument narrows how the constructors may be *called*, not what a package may
say: `language_version = ""` remains legal and keeps its meaning, which
`dart_info_fixture`'s `empty_language_version_test` pins.
�l
,

rules_dartdart/privatedart_library.bzl�Cdart_library�Collects Dart sources and propagates dependency information via `DartInfo`. Does not compile or assemble; consumers co-locate generated sources."�A
�!
dart_library�Collects Dart sources and propagates dependency information via `DartInfo`. Does not compile or assemble; consumers co-locate generated sources.*
nameA unique name for this target. �
code_assets�Native code assets this package owns (see the `dart_code_asset` rule). Assets declared here propagate to every `dart_binary`/`dart_test` that depends on this library, directly or transitively â matching upstream, where depending on a package gets you its assets with no opt-in. Each `asset_id` must be namespaced to this library's `package_name`.*
DartCodeAssetInfo2[]�
depsuOther `dart_library` targets this library depends on. Their sources and package metadata are propagated transitively.*

DartInfo2[]�
has_unreplaced_hook�Path of a pub build hook (`hook/build.dart` / `hook/link.dart`) this package ships that rules_dart has no replacement for. Set by `pub.from_lock()`; hand-written `dart_library` targets leave it empty. A `dart_binary`/`dart_test` reaching such a package fails with an explanation, rather than producing a binary whose `@Native` bindings silently fail to resolve at runtime.2""�
language_version�Dart language version implied by the package's `environment.sdk` constraint, in `<major>.<minor>` form. Emitted as `languageVersion` in generated `package_config.json` entries. For pub packages this is set automatically by `pub.from_lock()`; for hand-written `dart_library` targets, set it from your workspace's `pubspec.yaml` if you want analyzer behaviour to match.2""�
package�A `dart_package_metadata` declaring this Dart package's `package_name` and `language_version`. Mutually exclusive with the inline `package_name` / `language_version` attributes: set `package` to state those facts once for every rule building this package, or set them inline, but never both. Referencing a target is what lets rules in *different* BUILD files share one declaration, which a macro cannot do.*
DartPackageMetadataInfo2None�
package_name�The Dart package name used in `package:` imports. If omitted, defaults to the last component of the Bazel package path. Set this or `package`, not both.2""�
	resources�Non-Dart files this package ships inside `lib/` â part of its published surface, but never compiled. `package:sky_engine`'s `lib/_embedder.yaml`, which the analyzer reads to resolve `dart:ui`, and `package:dwds`'s `lib/src/injected/client.js`, which it serves to the browser, are both this. Anything under `lib/` is addressable as `package:<name>/<path>` whatever its extension, so these are members of the package, not a consumer's `data`. They are staged wherever the package itself is staged â the analyzer's hermetic project tree â and ride the runfiles of every `dart_binary`/`dart_test` that depends on this library, mirroring pub, where the package directory exists whole on disk at run time. They are never compile inputs. `.dart` files belong in `srcs`; files outside `lib/` have no `package:` URI and belong in a consumer's `data`.2[]�
srcs�Dart source files (`.dart`), source-tree or generated. Typically `glob(["lib/**/*.dart"])`, optionally plus `dart_codegen` outputs. Generated members are co-located with the rest of the package by the consuming `dart_binary`/`dart_test`. Mutually exclusive with `srcs_dir`.2[]�
srcs_dir�A pre-assembled source directory (a `dart_source_set`) to use as this library's package root, instead of `srcs`. The directory is opaque and carries the package's non-Dart files too, so `resources` is rejected alongside it. For reuse/composition; usually you just list files in `srcs`.2None�
version�The package's own version, as resolved by pub (e.g. `2.2.0`). Set automatically by `pub.package()` / `pub.from_lock()`; leave it empty on hand-written targets, which have no resolved version to state. Its only use is agreement checking: when one package name arrives twice â two pub hubs each supplying `ffi`, say â a build whose two records name different versions would otherwise compile against whichever came first in dependency order, silently ignoring the other. Two *known*, differing versions fail the build; an empty one never conflicts.2""";
dart_library+@@rules_dart//dart/private:dart_library.bzl
��,
*
nameA unique name for this target. �
�
code_assets�Native code assets this package owns (see the `dart_code_asset` rule). Assets declared here propagate to every `dart_binary`/`dart_test` that depends on this library, directly or transitively â matching upstream, where depending on a package gets you its assets with no opt-in. Each `asset_id` must be namespaced to this library's `package_name`.*
DartCodeAssetInfo2[]�
�
depsuOther `dart_library` targets this library depends on. Their sources and package metadata are propagated transitively.*

DartInfo2[]�
�
has_unreplaced_hook�Path of a pub build hook (`hook/build.dart` / `hook/link.dart`) this package ships that rules_dart has no replacement for. Set by `pub.from_lock()`; hand-written `dart_library` targets leave it empty. A `dart_binary`/`dart_test` reaching such a package fails with an explanation, rather than producing a binary whose `@Native` bindings silently fail to resolve at runtime.2""�
�
language_version�Dart language version implied by the package's `environment.sdk` constraint, in `<major>.<minor>` form. Emitted as `languageVersion` in generated `package_config.json` entries. For pub packages this is set automatically by `pub.from_lock()`; for hand-written `dart_library` targets, set it from your workspace's `pubspec.yaml` if you want analyzer behaviour to match.2""�
�
package�A `dart_package_metadata` declaring this Dart package's `package_name` and `language_version`. Mutually exclusive with the inline `package_name` / `language_version` attributes: set `package` to state those facts once for every rule building this package, or set them inline, but never both. Referencing a target is what lets rules in *different* BUILD files share one declaration, which a macro cannot do.*
DartPackageMetadataInfo2None�
�
package_name�The Dart package name used in `package:` imports. If omitted, defaults to the last component of the Bazel package path. Set this or `package`, not both.2""�
�
	resources�Non-Dart files this package ships inside `lib/` â part of its published surface, but never compiled. `package:sky_engine`'s `lib/_embedder.yaml`, which the analyzer reads to resolve `dart:ui`, and `package:dwds`'s `lib/src/injected/client.js`, which it serves to the browser, are both this. Anything under `lib/` is addressable as `package:<name>/<path>` whatever its extension, so these are members of the package, not a consumer's `data`. They are staged wherever the package itself is staged â the analyzer's hermetic project tree â and ride the runfiles of every `dart_binary`/`dart_test` that depends on this library, mirroring pub, where the package directory exists whole on disk at run time. They are never compile inputs. `.dart` files belong in `srcs`; files outside `lib/` have no `package:` URI and belong in a consumer's `data`.2[]�
�
srcs�Dart source files (`.dart`), source-tree or generated. Typically `glob(["lib/**/*.dart"])`, optionally plus `dart_codegen` outputs. Generated members are co-located with the rest of the package by the consuming `dart_binary`/`dart_test`. Mutually exclusive with `srcs_dir`.2[]�
�
srcs_dir�A pre-assembled source directory (a `dart_source_set`) to use as this library's package root, instead of `srcs`. The directory is opaque and carries the package's non-Dart files too, so `resources` is rejected alongside it. For reuse/composition; usually you just list files in `srcs`.2None�
�
version�The package's own version, as resolved by pub (e.g. `2.2.0`). Set automatically by `pub.package()` / `pub.from_lock()`; leave it empty on hand-written targets, which have no resolved version to state. Its only use is agreement checking: when one package name arrives twice â two pub hubs each supplying `ffi`, say â a build whose two records name different versions would otherwise compile against whichever came first in dependency order, silently ignoring the other. Two *known*, differing versions fail the build; an empty one never conflicts.2""�check_files_under_lib_root�Detects `srcs`/`resources` entries that do not sit under the package's `lib/`.

A Dart package resolves `package:<name>/x.dart` to `<lib_root>/lib/x.dart`,
and the consumer stages a package by stripping `lib_root` from each file
(`colocate_packages`). A file outside `<lib_root>/lib/` therefore lands
outside `lib/` in the staged tree and resolves to nothing. Nothing fails
until the kernel compile, which reports only a missing path inside a
`.pkgsrcs` directory — no target name, no mention of `lib/`.

Generated files are subject to the same rule: `declare_file` paths are
relative to the *producing* rule's Bazel package, so a codegen target
outside the Dart package root emits a path that no longer starts with
`lib_root`.
*�	
�	
check_files_under_lib_rootE
label8The owning rule's label (included in the error message). (�
lib_rootqThe package's library root, from `derive_lib_root`. Empty for a
root package, where files sit at `lib/` directly. (&
filesThe file list to inspect. (P
	attr_name9Attribute the list came from, named in the error message."srcs"(�Detects `srcs`/`resources` entries that do not sit under the package's `lib/`.

A Dart package resolves `package:<name>/x.dart` to `<lib_root>/lib/x.dart`,
and the consumer stages a package by stripping `lib_root` from each file
(`colocate_packages`). A file outside `<lib_root>/lib/` therefore lands
outside `lib/` in the staged tree and resolves to nothing. Nothing fails
until the kernel compile, which reports only a missing path inside a
`.pkgsrcs` directory — no target name, no mention of `lib/`.

Generated files are subject to the same rule: `declare_file` paths are
relative to the *producing* rule's Bazel package, so a codegen target
outside the Dart package root emits a path that no longer starts with
`lib_root`.
"B
@An error message string for the first offending file, or `None`.2I
check_files_under_lib_root+@@rules_dart//dart/private:dart_library.bzl
;;�	check_no_duplicate_srcs�Detects two entries that resolve to the same package-relative path.

Typically fires when a stale `build_runner`-generated file is listed in
the source tree alongside a codegen target producing the same output.
*�
�
check_no_duplicate_srcsE
label8The owning rule's label (included in the error message). (!
srcsThe files to inspect. (�
	attr_name�The attribute the files came from, named in the message so a
collision between two `resources` does not send the reader searching
`srcs`. A caller passing srcs and resources together keeps the default:
a src-vs-resource collision is unreachable, because identical short
paths imply identical extensions and a `.dart` file in `resources` is
refused before this runs — so a mixed list can only collide inside
`srcs`."srcs"(�Detects two entries that resolve to the same package-relative path.

Typically fires when a stale `build_runner`-generated file is listed in
the source tree alongside a codegen target producing the same output.
"G
EAn error message string if a collision is found, or `None` otherwise.2F
check_no_duplicate_srcs+@@rules_dart//dart/private:dart_library.bzl
�derive_lib_root�Derive the library root path (short_path-based, without /lib suffix).

For external repos, converts "external/X" to "../X" to match
File.short_path convention. Strips trailing /lib since Dart's
packageUri: "lib/" is appended to rootUri in package_config.json.
*�
�
derive_lib_rootQ
workspace_root;The workspace root of the label (ctx.label.workspace_root). (F
label_package1The Bazel label package path (ctx.label.package). (�Derive the library root path (short_path-based, without /lib suffix).

For external repos, converts "external/X" to "../X" to match
File.short_path convention. Strips trailing /lib since Dart's
packageUri: "lib/" is appended to rootUri in package_config.json.
"8
6The library root path with any trailing /lib stripped.2>
derive_lib_root+@@rules_dart//dart/private:dart_library.bzl
cc�derive_package_name<Derive the Dart package name from rule attributes and label.*�
�
derive_package_nameJ
package_name_attr1Explicit package name attribute, or empty string. (2
label_packageThe Bazel label package path. ('

label_nameThe Bazel label name. (<Derive the Dart package name from rule attributes and label." 
The derived Dart package name.2B
derive_package_name+@@rules_dart//dart/private:dart_library.bzl
�
//dart:providers.bzlr�
!

rules_dartdartproviders.bzl4
DartCodeAssetInfoDartCodeAssetInfo
*;"
DartInfoDartInfo
?G
I�
//dart/private:common.bzlr�
&

rules_dartdart/private
common.bzl>
PACKAGE_IDENTITY_ATTRSPACKAGE_IDENTITY_ATTRS
/E>
codegen_identity_errorcodegen_identity_error
I_B
resolve_package_identityresolve_package_identity
c{
}�
//dart/private:dart_info.bzlr�
)

rules_dartdart/privatedart_info.bzl$
	dart_info	dart_info
2;6
package_lib_prefixpackage_lib_prefix
?Q
S(Implementation of the dart_library rule.�$
5

rules_dartdart/privatedart_package_metadata.bzl�"dart_package_metadata�Declares a Dart package's name and language version once, for every rule that builds part of it.

Point `dart_library`, `dart_codegen`, `dart_aggregate_codegen`, `dart_sqlcodegen`
and `dart_format_test` at it with `package = ":<name>"` instead of repeating
`package_name` and `language_version` on each:

```starlark
dart_package_metadata(
    name = "pkg",
    package_name = "my_app",
    language_version = "3.11",
)

dart_codegen(
    name = "model_g",
    package = ":pkg",
    src = "lib/model.dart",
    generator = "//tools:gen.dart",
    output_suffixes = [".g.dart"],
)

dart_library(
    name = "my_app",
    package = ":pkg",
    srcs = ["lib/model.dart", ":model_g"],
)
```

A rule takes these two facts from `package` or from the inline `package_name` /
`language_version` attributes, never both â setting both fails, so the two can
never drift into disagreeing. The inline attributes remain fully supported and
are still the contract every rule is defined against; they are what generated
spoke repositories emit, where a generator writes both from one value and there
is no duplication to remove. `dart_package_metadata` is for hand-written packages, where
there is.

Visible across BUILD files, which is the case a macro cannot reach: a package
whose `dart_library` sits in `app/BUILD.bazel` and whose `dart_codegen` sits in
`gen/BUILD.bazel` has two files stating the same two strings, and only a target
can be referenced from both.

Not to be confused with `pub.package()`, the module extension tag that fetches a
published package from pub.dev. This declares facts about a package you are
building yourself."�
�
dart_package_metadata�Declares a Dart package's name and language version once, for every rule that builds part of it.

Point `dart_library`, `dart_codegen`, `dart_aggregate_codegen`, `dart_sqlcodegen`
and `dart_format_test` at it with `package = ":<name>"` instead of repeating
`package_name` and `language_version` on each:

```starlark
dart_package_metadata(
    name = "pkg",
    package_name = "my_app",
    language_version = "3.11",
)

dart_codegen(
    name = "model_g",
    package = ":pkg",
    src = "lib/model.dart",
    generator = "//tools:gen.dart",
    output_suffixes = [".g.dart"],
)

dart_library(
    name = "my_app",
    package = ":pkg",
    srcs = ["lib/model.dart", ":model_g"],
)
```

A rule takes these two facts from `package` or from the inline `package_name` /
`language_version` attributes, never both â setting both fails, so the two can
never drift into disagreeing. The inline attributes remain fully supported and
are still the contract every rule is defined against; they are what generated
spoke repositories emit, where a generator writes both from one value and there
is no duplication to remove. `dart_package_metadata` is for hand-written packages, where
there is.

Visible across BUILD files, which is the case a macro cannot reach: a package
whose `dart_library` sits in `app/BUILD.bazel` and whose `dart_codegen` sits in
`gen/BUILD.bazel` has two files stating the same two strings, and only a target
can be referenced from both.

Not to be confused with `pub.package()`, the module extension tag that fetches a
published package from pub.dev. This declares facts about a package you are
building yourself.*
nameA unique name for this target. �
language_version�Dart language version implied by the package's `environment.sdk` constraint, in `<major>.<minor>` form (e.g. `3.11`). Emitted as `languageVersion` in generated `package_config.json` entries and passed to code generators as the root language version. Leave empty to state none.2""z
package_namefThe Dart package name used in `package:` imports â the `name:` from the package's `pubspec.yaml`. "M
dart_package_metadata4@@rules_dart//dart/private:dart_package_metadata.bzl
,
*
nameA unique name for this target. �
�
language_version�Dart language version implied by the package's `environment.sdk` constraint, in `<major>.<minor>` form (e.g. `3.11`). Emitted as `languageVersion` in generated `package_config.json` entries and passed to code generators as the root language version. Leave empty to state none.2""|
z
package_namefThe Dart package name used in `package:` imports â the `name:` from the package's `pubspec.yaml`. �
//dart:providers.bzlrs
!

rules_dartdartproviders.bzl@
DartPackageMetadataInfoDartPackageMetadataInfo
*A
CWThe `dart_package_metadata` rule: a package's name and language version, declared once.�
/

rules_dartdart/privatedart_sdk_binary.bzl�dart_sdk_binaryMExposes the Dart SDK binary from the resolved toolchain as a runnable target."�
�
dart_sdk_binaryMExposes the Dart SDK binary from the resolved toolchain as a runnable target.*
nameA unique name for this target. "A
dart_sdk_binary.@@rules_dart//dart/private:dart_sdk_binary.bzl
//,
*
nameA unique name for this target. �
//dart/private:common.bzlr�
&

rules_dartdart/private
common.bzl6
BASH_RUNFILES_ATTRBASH_RUNFILES_ATTR
/A6
BASH_RUNFILES_INITBASH_RUNFILES_INIT
EW
Y�A runnable target that exposes the Dart SDK binary via toolchain resolution.

Usage:
    bazel run @rules_dart//dart -- --version
    bazel run @rules_dart//dart -- analyze lib/
�4
/

rules_dartdart/privatedart_sqlcodegen.bzl�'dart_sqlcodegentRuns a Dart code generator over a non-Dart input (`.drift`, `.moor`, â¦), producing one or more sibling outputs."�&
�
dart_sqlcodegentRuns a Dart code generator over a non-Dart input (`.drift`, `.moor`, â¦), producing one or more sibling outputs.*
nameA unique name for this target. �

asset_deps�Non-Dart files the Builder's `Resolver` / `findAssets` must see. Each file is staged as an action input and passed as `--dep <exec>|<asset>` using `asset_path_for`.2[]8
config(Builder options as a JSON object string.2""�
data�Additional data files added to action inputs but not passed as flagged args. Sandbox-only â NOT visible to the Builder's `Resolver` / `findAssets`. For files the Builder must see via its AssetReader, use `asset_deps`.2[]�
deps�`dart_library`-shaped targets (anything exporting `DartInfo`) whose transitive sources populate a synthesised `package_config.json`. Same-package siblings are auto-staged as `--dep`.*

DartInfo2[]:
generator_args"Escape-hatch additional arguments.2[]a
generator_binLPre-compiled generator executable matching the rules_dart shim CLI contract. r
language_versionXDart language version in `<major>.<minor>` form. Empty falls back to a built-in default.2""�
output_suffixes�Suffixes appended to the source stem (after stripping its extension). E.g. `['.drift_prep.json']`. Multi-output builders (e.g. drift_dev's preparing stage emits both `.drift_prep.json` and `.expr.temp.dart`) declare all suffixes here. �
package�A `dart_package_metadata` declaring this Dart package's `package_name` and `language_version`. Mutually exclusive with the inline `package_name` / `language_version` attributes: set `package` to state those facts once for every rule building this package, or set them inline, but never both. Referencing a target is what lets rules in *different* BUILD files share one declaration, which a macro cannot do.*
DartPackageMetadataInfo2Noneq
package_configWOptional pre-existing `package_config.json`; overrides the one synthesised from `deps`.2None�
package_name�Dart package name owning `src`. Must match the consuming `dart_library`'s `package_name` â enforced where the two meet, in that library's `srcs`. Set this or `package`, not both; `package` is how one declaration serves every rule building the package, including rules in other BUILD files.2""@
parts1Additional input files passed as `--part <path>`.2[]F
src;The single non-Dart input file (`.drift`, `.moor`, â¦). "A
dart_sqlcodegen.@@rules_dart//dart/private:dart_sqlcodegen.bzl
��,
*
nameA unique name for this target. �
�

asset_deps�Non-Dart files the Builder's `Resolver` / `findAssets` must see. Each file is staged as an action input and passed as `--dep <exec>|<asset>` using `asset_path_for`.2[]:
8
config(Builder options as a JSON object string.2""�
�
data�Additional data files added to action inputs but not passed as flagged args. Sandbox-only â NOT visible to the Builder's `Resolver` / `findAssets`. For files the Builder must see via its AssetReader, use `asset_deps`.2[]�
�
deps�`dart_library`-shaped targets (anything exporting `DartInfo`) whose transitive sources populate a synthesised `package_config.json`. Same-package siblings are auto-staged as `--dep`.*

DartInfo2[]<
:
generator_args"Escape-hatch additional arguments.2[]c
a
generator_binLPre-compiled generator executable matching the rules_dart shim CLI contract. t
r
language_versionXDart language version in `<major>.<minor>` form. Empty falls back to a built-in default.2""�
�
output_suffixes�Suffixes appended to the source stem (after stripping its extension). E.g. `['.drift_prep.json']`. Multi-output builders (e.g. drift_dev's preparing stage emits both `.drift_prep.json` and `.expr.temp.dart`) declare all suffixes here. �
�
package�A `dart_package_metadata` declaring this Dart package's `package_name` and `language_version`. Mutually exclusive with the inline `package_name` / `language_version` attributes: set `package` to state those facts once for every rule building this package, or set them inline, but never both. Referencing a target is what lets rules in *different* BUILD files share one declaration, which a macro cannot do.*
DartPackageMetadataInfo2Nones
q
package_configWOptional pre-existing `package_config.json`; overrides the one synthesised from `deps`.2None�
�
package_name�Dart package name owning `src`. Must match the consuming `dart_library`'s `package_name` â enforced where the two meet, in that library's `srcs`. Set this or `package`, not both; `package` is how one declaration serves every rule building the package, including rules in other BUILD files.2""B
@
parts1Additional input files passed as `--part <path>`.2[]H
F
src;The single non-Dart input file (`.drift`, `.moor`, â¦). �
//dart:providers.bzlr�
!

rules_dartdartproviders.bzl"
DartInfoDartInfo
*2@
DartPackageMetadataInfoDartPackageMetadataInfo
6M
O�
//dart/private:common.bzlr�
&

rules_dartdart/private
common.bzlL
DEFAULT_ROOT_LANGUAGE_VERSIONDEFAULT_ROOT_LANGUAGE_VERSION
#>
PACKAGE_IDENTITY_ATTRSPACKAGE_IDENTITY_ATTRS
>
add_shim_contract_argsadd_shim_contract_args
.
asset_path_forasset_path_for
D
dart_lib_root_for_packagedart_lib_root_for_package
  B
resolve_package_identityresolve_package_identity
!!N
same_package_library_dep_filessame_package_library_dep_files
""$:
synth_package_configsynth_package_config
##
$�Code generation from non-Dart input files (drift `.drift` / `.moor`).

Mirrors `dart_codegen` in shape but accepts any file extension on `src`.
Same shim-contract attrs (`package_name`, `deps`, `parts`, `config`,
`package_config`, `generator_args`); same per-file behaviour â one input,
one or more outputs derived by applying each `output_suffixes` entry.

Used to wire SQL-input builders like `drift_dev`'s preparing stage into
the same rules_dart shim contract as Dart-input builders.

Usage:

    load("@rules_dart//dart:defs.bzl", "dart_sqlcodegen")

    dart_sqlcodegen(
        name = "schema_prep",
        src = "schema.drift",
        generator_bin = "@rules_dart//dart/ext/drift:shim_prep",
        output_suffixes = [".drift_prep.json"],
        package_name = "my_app",
        deps = ["@pub_deps//:drift"],
    )
�%
4

rules_dartdart/privatedart_web_application.bzl�dart_js_binaryDCompiles a Dart web application to JavaScript via `dart compile js`."�

�
dart_js_binaryDCompiles a Dart web application to JavaScript via `dart compile js`.*
nameA unique name for this target. �
dart_compile_flags�Extra flags passed to `dart compile` after compilation-mode defaults. Flags appear last so they can override defaults (e.g., `-O4` for dart2js).2[]f
definesUDart environment declarations (`key=value`). Each entry becomes a `-Dkey=value` flag.2[]M
deps3`dart_library` targets this application depends on.*

DartInfo2[]N
mainBThe Dart entrypoint file containing a top-level `main()` function. t
srcsfAdditional Dart source files that are part of this application's package but not reachable via `deps`.2[]"E
dart_js_binary3@@rules_dart//dart/private:dart_web_application.bzl
��,
*
nameA unique name for this target. �
�
dart_compile_flags�Extra flags passed to `dart compile` after compilation-mode defaults. Flags appear last so they can override defaults (e.g., `-O4` for dart2js).2[]h
f
definesUDart environment declarations (`key=value`). Each entry becomes a `-Dkey=value` flag.2[]O
M
deps3`dart_library` targets this application depends on.*

DartInfo2[]P
N
mainBThe Dart entrypoint file containing a top-level `main()` function. v
t
srcsfAdditional Dart source files that are part of this application's package but not reachable via `deps`.2[]�dart_wasm_binaryoCompiles a Dart web application to WebAssembly via `dart compile wasm`. Requires a browser with WasmGC support."�
�
dart_wasm_binaryoCompiles a Dart web application to WebAssembly via `dart compile wasm`. Requires a browser with WasmGC support.*
nameA unique name for this target. �
dart_compile_flags�Extra flags passed to `dart compile` after compilation-mode defaults. Flags appear last so they can override defaults (e.g., `-O4` for dart2js).2[]f
definesUDart environment declarations (`key=value`). Each entry becomes a `-Dkey=value` flag.2[]M
deps3`dart_library` targets this application depends on.*

DartInfo2[]N
mainBThe Dart entrypoint file containing a top-level `main()` function. t
srcsfAdditional Dart source files that are part of this application's package but not reachable via `deps`.2[]"G
dart_wasm_binary3@@rules_dart//dart/private:dart_web_application.bzl
��,
*
nameA unique name for this target. �
�
dart_compile_flags�Extra flags passed to `dart compile` after compilation-mode defaults. Flags appear last so they can override defaults (e.g., `-O4` for dart2js).2[]h
f
definesUDart environment declarations (`key=value`). Each entry becomes a `-Dkey=value` flag.2[]O
M
deps3`dart_library` targets this application depends on.*

DartInfo2[]P
N
mainBThe Dart entrypoint file containing a top-level `main()` function. v
t
srcsfAdditional Dart source files that are part of this application's package but not reachable via `deps`.2[]o
//dart:providers.bzlrU
!

rules_dartdartproviders.bzl"
DartInfoDartInfo

*
2


4�
!//dart/private:build_settings.bzlr�
.

rules_dartdart/privatebuild_settings.bzl@
EXTRA_DART_DEFINES_ATTREXTRA_DART_DEFINES_ATTR
7N6
merge_dart_definesmerge_dart_defines
Rd
f�
//dart/private:common.bzlr�
&

rules_dartdart/private
common.bzl2
collect_packagescollect_packages
/?J
collect_transitive_resourcescollect_transitive_resources
C_@
collect_transitive_srcscollect_transitive_srcs
cz5
writable_home_envwritable_home_env
~�
��
//dart/private:dart_info.bzlru
)

rules_dartdart/privatedart_info.bzl:
dart_analyzable_infodart_analyzable_info
2F
H�
"//dart/private:project_staging.bzlrw
/

rules_dartdart/privateproject_staging.bzl6
stage_dart_projectstage_dart_project
8J
L�
//dart/private:source_set.bzlr�
*

rules_dartdart/privatesource_set.bzlJ
COPY_TO_DIRECTORY_TOOLCHAINSCOPY_TO_DIRECTORY_TOOLCHAINS
3O
Q�Implementation of dart_js_binary and dart_wasm_binary rules.

Compiles a Dart application to JavaScript or WebAssembly for use in a browser.
`dart compile js|wasm` accepts no `--packages` flag, so the compiler resolves
packages by walking up from the entrypoint to a `.dart_tool/package_config.json`.
The rules stage that layout hermetically from declared artifacts (see
`project_staging.bzl`) and invoke the compiler directly â no shell, no mktemp.
�

.

rules_dartdart/privatepackage_config.bzl�generate_package_configGGenerates a package_config.json file from transitive Dart dependencies."�
�
generate_package_configGGenerates a package_config.json file from transitive Dart dependencies.*
nameA unique name for this target. `
depsFdart_library targets whose transitive closure forms the package graph.*

DartInfo2[]"H
generate_package_config-@@rules_dart//dart/private:package_config.bzl
,
*
nameA unique name for this target. b
`
depsFdart_library targets whose transitive closure forms the package graph.*

DartInfo2[]�
//dart:providers.bzlr�
!

rules_dartdartproviders.bzl"
DartInfoDartInfo
*2<
DartPackageConfigInfoDartPackageConfigInfo
6K
M�
//dart/private:common.bzlr�
&

rules_dartdart/private
common.bzl2
collect_packagescollect_packages
	/	?@
collect_transitive_srcscollect_transitive_srcs
	C	ZC
generate_package_configgenerate_package_config_fn
	]	w
		��Generate package_config.json from the transitive DartInfo dependency graph.

This is a standalone rule for generating package_config.json. The dart_binary
rule generates its own package_config inline and does not use this rule.
This rule is useful for custom build scenarios.
�]
/

rules_dartdart/privateproject_staging.bzl�main_package_roots�Returns the main-repo package roots that receive a stub pubspec.

One entry per distinct `lib_root`; when several package records share a
root (the split-package case), the lexically-first name wins so the choice
is deterministic. External (`../`-prefixed) packages are excluded — they
live outside the staged project and are never analyzed.
*�
�
main_package_rootsB
packages2List of DartPackageInfo (from `collect_packages`). (�Returns the main-repo package roots that receive a stub pubspec.

One entry per distinct `lib_root`; when several package records share a
root (the split-package case), the lexically-first name wins so the choice
is deterministic. External (`../`-prefixed) packages are excluded — they
live outside the staged project and are never analyzed.
"1
/Sorted list of (lib_root, package_name) tuples.2D
main_package_roots.@@rules_dart//dart/private:project_staging.bzl
���mangle_package_dirKReturns `name` with path-hostile characters replaced for use as a dir name.*�
�
mangle_package_dir0
name$A Dart package name (or any string). (KReturns `name` with path-hostile characters replaced for use as a dir name."5
3The mangled string (`/`, `:`, `.`, `+` become `_`).2D
mangle_package_dir.@@rules_dart//dart/private:project_staging.bzl
''�pubspec_stub�	Builds a `pubspec.yaml` for the staged project or a package within it.

The analyzer resolves imports through `package_config.json`, never through
this file — but lint rules read it, so it has to be a *valid* pubspec, not
just a parseable one. A placeholder name trips `package_names`, and every
cross-package import trips `depend_on_referenced_packages` unless the
package is listed here. Both fire on the harness rather than on the code
under analysis, so a strict ruleset would blame the user for rules_dart's
staging. Dependencies are sorted because `sort_pub_dependencies` would be
the next one.

Constraints are `any`: nothing resolves them, and a real constraint here
would be a second place to keep a version in sync. The stub's own name is
excluded from the dependency list; `depend_on_referenced_packages`
special-cases the containing package, so a `package:self/…` import never
needs a self-dependency (measured on Dart 3.12.2).

Shared by `dart_analyze_test` and `dart_fix` rather than written out in
each: fixes are driven by the lints a project reports, so the two staging
the same project is what lets `bazel run :fix` turn a red analyze green.
*�
�
pubspec_stub�
packagespList of DartPackageInfo (from `collect_packages`) — every
package the staged `package_config.json` will carry. (�
name�The pubspec's `name:` field. The default names the harness-level
stub at the project root; per-package stubs pass the real package name
so the analyzer attributes each staged file to its true package."analyze_stub"(�	Builds a `pubspec.yaml` for the staged project or a package within it.

The analyzer resolves imports through `package_config.json`, never through
this file — but lint rules read it, so it has to be a *valid* pubspec, not
just a parseable one. A placeholder name trips `package_names`, and every
cross-package import trips `depend_on_referenced_packages` unless the
package is listed here. Both fire on the harness rather than on the code
under analysis, so a strict ruleset would blame the user for rules_dart's
staging. Dependencies are sorted because `sort_pub_dependencies` would be
the next one.

Constraints are `any`: nothing resolves them, and a real constraint here
would be a second place to keep a version in sync. The stub's own name is
excluded from the dependency list; `depend_on_referenced_packages`
special-cases the containing package, so a `package:self/…` import never
needs a self-dependency (measured on Dart 3.12.2).

Shared by `dart_analyze_test` and `dart_fix` rather than written out in
each: fixes are driven by the lints a project reports, so the two staging
the same project is what lets `bazel run :fix` turn a red analyze green.
"+
)The pubspec file's contents, as a string.2>
pubspec_stub.@@rules_dart//dart/private:project_staging.bzl
tt�stage_dart_project@Stages packages and sources into a hermetic Dart project layout.*�
�
stage_dart_projectH
ctx=The rule context (must carry `COPY_TO_DIRECTORY_TOOLCHAINS`). (B
packages2List of DartPackageInfo (from `collect_packages`). (m
all_srcs]Flat list of Files to stage (the rule's own srcs/main plus the
flattened transitive closure). (�
extra_proj_files�Dict of `<filename> -> content string` written as
declared files directly under `<name>.proj/` (e.g. a `pubspec.yaml`
stub for `dart analyze`).{}(@Stages packages and sources into a hermetic Dart project layout."�
�struct(
  proj_path: exec path of the `<name>.proj` directory,
  src_tree: the `src` tree artifact File,
  package_config: the written package_config File,
  inputs: list of Files to add to the consuming action's inputs,
)2D
stage_dart_project.@@rules_dart//dart/private:project_staging.bzl
���stage_root_options�Declares `<name>.proj/analysis_options.yaml` — always, even when unset.

`dart analyze` and `dart format` both discover analysis options by an
unbounded lexical walk up from the path they are handed, and neither stops
at the project root. Under a non-sandboxed strategy the staged project sits
inside the execroot, whose top level mirrors the workspace — so a project
root with no options file of its own lets the tool climb out and adopt
whatever `analysis_options.yaml` the workspace happens to have. The verdict
then depends on the spawn strategy and on a file no action declared.

The *nearest* options file is what ends the walk, so one is staged
unconditionally: the user's when they named it, and a comment-only stub
otherwise. An empty options file is equivalent to no file at all when
nothing above interferes (measured on Dart 3.12.2), so the stub changes no
verdict — it removes only the ancestor read.

`dart_fix` is not a caller: it already writes a root options file in every
case, because it must compose its own exclusions over the user's.
*�

�

stage_root_options
ctxThe rule context. (G
options_file3The user's `analysis_options.yaml` File, or `None`. (�Declares `<name>.proj/analysis_options.yaml` — always, even when unset.

`dart analyze` and `dart format` both discover analysis options by an
unbounded lexical walk up from the path they are handed, and neither stops
at the project root. Under a non-sandboxed strategy the staged project sits
inside the execroot, whose top level mirrors the workspace — so a project
root with no options file of its own lets the tool climb out and adopt
whatever `analysis_options.yaml` the workspace happens to have. The verdict
then depends on the spawn strategy and on a file no action declared.

The *nearest* options file is what ends the walk, so one is staged
unconditionally: the user's when they named it, and a comment-only stub
otherwise. An empty options file is equivalent to no file at all when
nothing above interferes (measured on Dart 3.12.2), so the stub changes no
verdict — it removes only the ancestor read.

`dart_fix` is not a caller: it already writes a root options file in every
case, because it must compose its own exclusions over the user's.
"5
3The staged File, for the consuming action's inputs.2D
stage_root_options.@@rules_dart//dart/private:project_staging.bzl
���staged_package_config_content�Builds package_config.json content for the staged-project layout.

The config lives at `<proj_name>.proj/.dart_tool/package_config.json`:
main-repo packages resolve to `../src[/<lib_root>]`, external packages to
`../../<proj_name>.extpkgs/<mangled>[/<sub>]`.
*�
�
staged_package_config_content2
packages"List of DartPackageInfo providers. (�

ext_staged�Dict of package_name -> True for external packages that
actually have a staged tree (those without one are skipped — nothing
to point at). (A
	proj_name0The staging name prefix (the rule's label name). (�Builds package_config.json content for the staged-project layout.

The config lives at `<proj_name>.proj/.dart_tool/package_config.json`:
main-repo packages resolve to `../src[/<lib_root>]`, external packages to
`../../<proj_name>.extpkgs/<mangled>[/<sub>]`.
"1
/String content of the package_config.json file.2O
staged_package_config_content.@@rules_dart//dart/private:project_staging.bzl
EE�staged_pubspec_paths�Project-relative paths of the per-package stub pubspecs staging writes.

`dart_fix` composes its wrapper `analysis_options.yaml` before calling
`stage_dart_project`, so the stub paths it must exclude from fixing are
computed here, from the same dedupe rule staging uses, rather than
returned by it.
*�
�
staged_pubspec_pathsB
packages2List of DartPackageInfo (from `collect_packages`). (�Project-relative paths of the per-package stub pubspecs staging writes.

`dart_fix` composes its wrapper `analysis_options.yaml` before calling
`stage_dart_project`, so the stub paths it must exclude from fixing are
computed here, from the same dedupe rule staging uses, rather than
returned by it.
">
<Sorted list of `src/...` path strings, one per stub pubspec.2F
staged_pubspec_paths.@@rules_dart//dart/private:project_staging.bzl
���
//dart/private:source_set.bzlr�
*

rules_dartdart/privatesource_set.bzl8
assemble_source_dirassemble_source_dir
%3%F(
package_forpackage_for
%J%U
%%W�Hermetic staged-project assembly for rules that need a real project layout.

`dart compile js|wasm` accepts no `--packages` flag and `dart analyze` wants a
project directory, so both resolve packages by walking up from their input to a
`.dart_tool/package_config.json`. This module stages that layout entirely from
declared artifacts â no `mktemp`, no shell â as sibling outputs:

    <name>.proj/.dart_tool/package_config.json   (declared file)
    <name>.proj/src/...                          (tree artifact; workspace-relative paths)
    <name>.proj/src/<lib_root>/pubspec.yaml      (stub, one per main-repo package)
    <name>.extpkgs/<pkg>/...                     (one tree artifact per external package)

Main-repo sources (hand-written and generated) merge into one `src` tree at
their workspace-relative paths, so every main-repo package's `lib_root` is a
real directory under `src/`. External (pub) packages cannot share that tree â
`copy_to_directory` maps external files repo-relative, so two pub spokes would
collide at `lib/...` â and get one tree each, referenced from the config via a
`../../` rootUri (package resolution follows rootUris outside the project dir).

Each main-repo package root also receives a stub `pubspec.yaml`. Imports
resolve through `package_config.json` alone, but the analyzer attributes a
file to a package by walking up to the *nearest enclosing pubspec.yaml*
(`findPackageFor` in `pkg/analyzer`'s pub workspace), and a family of lints â
`public_member_api_docs`, `always_use_package_imports`,
`prefer_relative_imports`, `avoid_renaming_method_parameters`, and every rule
consulting `WorkspacePackage.contains` â decides whether to fire from that
package's root (`isInLibDir` is `<package root>/lib` containing the file).
With only a project-level pubspec, a staged file's "package root" would be
`<name>.proj` itself, its path relative to it `src/<lib_root>/lib/â¦`, and
those lints silently decline. The stubs restore each package's true root; a
nested pubspec does not split analysis contexts (context roots split on
options/package_config files, not pubspecs â `ContextLocatorImpl`, verified
on Dart 3.12.2), so the project-root `analysis_options.yaml` still governs
every file.
�
2

rules_dartdart/privateresolved_toolchain.bzl�resolved_toolchain�Exposes a concrete toolchain which is the result of Bazel resolving the
toolchain for the execution or target platform.
Workaround for https://github.com/bazelbuild/bazel/issues/14009
"�
�
resolved_toolchain�Exposes a concrete toolchain which is the result of Bazel resolving the
toolchain for the execution or target platform.
Workaround for https://github.com/bazelbuild/bazel/issues/14009
*
nameA unique name for this target. "G
resolved_toolchain1@@rules_dart//dart/private:resolved_toolchain.bzl
,
*
nameA unique name for this target. �	DOC�Exposes a concrete toolchain which is the result of Bazel resolving the
toolchain for the execution or target platform.
Workaround for https://github.com/bazelbuild/bazel/issues/14009
j��Exposes a concrete toolchain which is the result of Bazel resolving the
toolchain for the execution or target platform.
Workaround for https://github.com/bazelbuild/bazel/issues/14009
?This module implements an alias rule to the resolved toolchain.�Q
*

rules_dartdart/privatesource_set.bzl�
dart_source_set�Assembles Dart sources (hand-written + generated) into one tree-artifact directory. Package-agnostic; consume via `dart_library`'s `srcs_dir`."�	
�
dart_source_set�Assembles Dart sources (hand-written + generated) into one tree-artifact directory. Package-agnostic; consume via `dart_library`'s `srcs_dir`.*
nameA unique name for this target. �
replace_prefixes}Map of output-path prefixes to rewrite, applied after `root_paths` stripping. Use to place cross-package inputs under `lib/`.
2{}�

root_paths�Paths treated as roots in the output directory (stripped). `"."` is this target's Bazel package. Set additional roots to flatten files from other packages.2["."]a
srcsUDart files (source and/or generated, from any target) to assemble into one directory. "<
dart_source_set)@@rules_dart//dart/private:source_set.bzl
��,
*
nameA unique name for this target. �
�
replace_prefixes}Map of output-path prefixes to rewrite, applied after `root_paths` stripping. Use to place cross-package inputs under `lib/`.
2{}�
�

root_paths�Paths treated as roots in the output directory (stripped). `"."` is this target's Bazel package. Set additional roots to flatten files from other packages.2["."]c
a
srcsUDart files (source and/or generated, from any target) to assemble into one directory. �assemble_source_dir�Assembles `srcs` into one tree-artifact directory and returns it.

Source and generated files are copied into a single declared directory at
their package-relative paths (default `root_paths = ["."]` strips the owning
Bazel package prefix, yielding the `lib/...` layout the Dart `rootUri`
expects).
*�
�
assemble_source_dirH
ctx=The rule context (must carry `COPY_TO_DIRECTORY_TOOLCHAINS`). (L
name@Basename for the declared directory (unique within the package). (G
srcs;List of File objects (source and/or generated) to assemble. (T

root_paths=`copy_to_directory` root paths; `"."` is the current package.["."](W
replace_prefixes=`copy_to_directory` prefix rewrites for cross-package layout.{}(�
include_external_repositories�`copy_to_directory` external repo name
patterns; external files are excluded unless their repo matches, and
matching files are staged at their repo-relative paths.[](�Assembles `srcs` into one tree-artifact directory and returns it.

Source and generated files are copied into a single declared directory at
their package-relative paths (default `root_paths = ["."]` strips the owning
Bazel package prefix, yielding the `lib/...` layout the Dart `rootUri`
expects).
"1
/The assembled directory File (a tree artifact).2@
assemble_source_dir)@@rules_dart//dart/private:source_set.bzl
))2copy_to_directory_bin_action�colocate_entrypoint�Co-locates an entrypoint `main` with its own generated sibling sources.

A `dart_binary`/`dart_test` whose own `srcs` include a generated file that is
a `part`/relative-import sibling of `main` (e.g. a mockito `.mocks.dart`
generated for the test file itself) needs `main` and those files in one real
directory. When that's the case, assemble them and compile `main` from inside
the assembled directory.
*�
�
colocate_entrypointH
ctx=The rule context (must carry `COPY_TO_DIRECTORY_TOOLCHAINS`). ((
mainThe entrypoint `.dart` File. (D
own_srcs4The rule's own `srcs` Files (not those from `deps`). (�Co-locates an entrypoint `main` with its own generated sibling sources.

A `dart_binary`/`dart_test` whose own `srcs` include a generated file that is
a `part`/relative-import sibling of `main` (e.g. a mockito `.mocks.dart`
generated for the test file itself) needs `main` and those files in one real
directory. When that's the case, assemble them and compile `main` from inside
the assembled directory.
"�
�`(main_input, main_arg, extra_inputs)` — `main_input` is the File to add to
action inputs (the assembled directory when assembled, else `main`);
`main_arg` is the path string to pass as the compile target; `extra_inputs`
are `own_srcs` to add as inputs when not assembled (empty when assembled).2@
colocate_entrypoint)@@rules_dart//dart/private:source_set.bzl
���colocate_packages�Co-locates each package's split source/generated files into one directory.

Groups `all_srcs` by the package whose `lib/` they belong to (longest
`lib_root` match — see `package_for`).
Any package with at least one generated file (and not already a single
pre-assembled directory) is assembled into one tree-artifact directory, so it
has a single real `rootUri` at compile time. This is what makes a package
whose files are split across the source tree and `bazel-out` (codegen) and/or
across several `dart_library` targets resolve — the consumer is the only place
that sees the package's complete file set.
*�
�
colocate_packagesH
ctx=The rule context (must carry `COPY_TO_DIRECTORY_TOOLCHAINS`). (D
packages4List of `DartPackageInfo` (from `collect_packages`). (5
all_srcs%Flat list of transitive source Files. (�Co-locates each package's split source/generated files into one directory.

Groups `all_srcs` by the package whose `lib/` they belong to (longest
`lib_root` match — see `package_for`).
Any package with at least one generated file (and not already a single
pre-assembled directory) is assembled into one tree-artifact directory, so it
has a single real `rootUri` at compile time. This is what makes a package
whose files are split across the source tree and `bazel-out` (codegen) and/or
across several `dart_library` targets resolve — the consumer is the only place
that sees the package's complete file set.
"�
�`(packages2, srcs2)` — packages with each assembled package's `lib_root`
rewritten to its assembled directory, and the matching File list (assembled
directories plus untouched files) to feed the compile action.2>
colocate_packages)@@rules_dart//dart/private:source_set.bzl
xx�needs_source_assembly�Whether `srcs` must be assembled into one directory before compilation.

A pure source-tree package already lives in one directory; the moment any
member is generated (in `bazel-out`), the package's files straddle two real
directories and must be co-located.
*�
�
needs_source_assemblyC
srcs7A list of File objects (a rule's own `ctx.files.srcs`). (�Whether `srcs` must be assembled into one directory before compilation.

A pure source-tree package already lives in one directory; the moment any
member is generated (in `bazel-out`), the package's files straddle two real
directories and must be co-located.
"7
5True iff at least one File is not a source-tree file.2B
needs_source_assembly)@@rules_dart//dart/private:source_set.bzl
�package_for�Returns the package_name owning `short_path`, by longest matching `lib_root`.

A package owns its `<lib_root>/lib/` subtree and nothing else in the
directory: `lib/` is what a `package:` URI can reach, and staging strips
`lib_root`, so a `test/` or `tool/` file co-located into the package would
land somewhere no import resolves — and a generated entrypoint would lose
the relative imports that resolved from its real location. The rule is the
same wherever the package sits. Among several matches the longest `lib_root`
wins; the root package's is empty, so it is taken only when nothing else
matched at all.

The one path that is not under `lib/` is `lib_root` itself, which matches
exactly. That is a package whose files arrive as one opaque directory — a
`dart_library(srcs_dir = ...)`, or a record `colocate_packages` already
rewrote to its `.pkgsrcs` directory — where the directory *is* the package
root and `lib/` sits inside it.
*�	
�	
package_for(

short_pathA File's `short_path`. (S
packagesCList of `DartPackageInfo` (read for `package_name` and `lib_root`). (�Returns the package_name owning `short_path`, by longest matching `lib_root`.

A package owns its `<lib_root>/lib/` subtree and nothing else in the
directory: `lib/` is what a `package:` URI can reach, and staging strips
`lib_root`, so a `test/` or `tool/` file co-located into the package would
land somewhere no import resolves — and a generated entrypoint would lose
the relative imports that resolved from its real location. The rule is the
same wherever the package sits. Among several matches the longest `lib_root`
wins; the root package's is empty, so it is taken only when nothing else
matched at all.

The one path that is not under `lib/` is `lib_root` itself, which matches
exactly. That is a package whose files arrive as one opaque directory — a
`dart_library(srcs_dir = ...)`, or a record `colocate_packages` already
rewrote to its `.pkgsrcs` directory — where the directory *is* the package
root and `lib/` sits inside it.
"E
CThe matching `package_name`, or `None` if no package owns the path.28
package_for)@@rules_dart//dart/private:source_set.bzl
KK�
//lib:copy_to_directory.bzlr�
'
	bazel_liblibcopy_to_directory.bzlJ
copy_to_directory_bin_actioncopy_to_directory_bin_action
0L
N�
//dart/private:dart_info.bzlr�
)

rules_dartdart/privatedart_info.bzl:
derived_package_infoderived_package_info
2F6
package_lib_prefixpackage_lib_prefix
J\
^X	COPY_TO_DIRECTORY_TOOLCHAINSj624
20@bazel_lib//lib:copy_to_directory_toolchain_type�`dart_source_set` and the shared source-assembly helper.

The Dart toolchain resolves a `part` directive by filesystem adjacency to its
library, and a package's `package:` imports against a single `rootUri`. So a
package whose files are split between the source tree and `bazel-out` (because a
`dart_codegen` writes generated members) must be reassembled into one real
directory before `dart compile`/`dart` will resolve it.

`assemble_source_dir` does that with bazel-lib's `copy_to_directory` (portable on
Windows, no bash, no symlink privilege). The consuming `dart_binary`/`dart_test`
assemble each package's complete file set at build time via `colocate_packages`
and `colocate_entrypoint` â the consumer is the only place that sees a package's
files across all of its `dart_library` fragments. `dart_source_set` exposes the
same assembly as a standalone, package-agnostic primitive (consumed via
`dart_library`'s `srcs_dir`).
�
/

rules_dartdart/privatetoolchains_repo.bzl�toolchains_repolCreates a repository with toolchain definitions for all known platforms
which can be registered or selected.R�

�
toolchains_repolCreates a repository with toolchain definitions for all known platforms
which can be registered or selected..
name"A unique name for this repository. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 C
user_repository_name%what the user chose for the base name2""*A
toolchains_repo.@@rules_dart//dart/private:toolchains_repo.bzl
�"�"0
.
name"A unique name for this repository. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 E
C
user_repository_name%what the user chose for the base name2""�Create a repository to hold the toolchains

This follows guidance here:
https://docs.bazel.build/versions/main/skylark/deploying.html#registering-toolchains
"
Note that in order to resolve toolchains in the analysis phase
Bazel needs to analyze all toolchain targets that are registered.
Bazel will not need to analyze all targets referenced by toolchain.toolchain attribute.
If in order to register toolchains you need to perform complex computation in the repository,
consider splitting the repository with toolchain targets
from the repository with <LANG>_toolchain targets.
Former will be always fetched,
and the latter will only be fetched when user actually needs to build <LANG> code.
"
The "complex computation" in our case is simply downloading large artifacts.
This guidance tells us how to avoid that: we put the toolchain targets in the alias repository
with only the toolchain attribute pointing into the platform-specific repositories.
o
(

rules_dartdart/privateversions.bzlCDart SDK release versions and their SHA-256 checksums per platform.�
1

rules_dartdart/pub/privatebuild_content.bzl�make_dart_library_build_content�Generate the BUILD.bazel content for a single `dart_library` spoke.

The shape — `srcs = glob(["lib/**/*.dart"], allow_empty = True)`, the
non-Dart remainder of `lib/` as `resources`, a `package_name` matching the
target name, public visibility, optional deps block — is the canonical
pub-spoke layout. Resource-only and Swift-only/Kotlin-only Flutter platform
packages produce empty source globs but must still resolve as labels, hence
`allow_empty`.

The two globs partition `lib/` rather than covering only the Dart half of
it. A published package's `lib/` is addressable as `package:<name>/<path>`
whatever the extension, so a spoke that keeps only `*.dart` is a package
with pieces missing — `dwds` without the client JavaScript it serves,
`lints` without the YAML every `analysis_options.yaml` includes. Whatever
a future package ships lands in one of the two globs, so nothing is
dropped for being unanticipated.
*�
�
make_dart_library_build_contentG
name;Target name (also the `package_name` for the dart_library). (�
depszList of fully-qualified Bazel label strings for sibling spokes
(e.g. `"@hub__dep//:dep"`). Pass an empty list for no deps. (�
language_version�Dart language version string (e.g. `"3.0"`),
usually derived from the package's pubspec SDK constraint via
`derive_language_version`. (�
code_assets�List of `dart_code_asset` label strings replacing this
package's `hook/build.dart` output. Attaching them here rather
than at the consuming binary is what makes them propagate: they
become part of the package's own metadata.[](�
has_unreplaced_hook�Path of a build hook this package ships that has
no replacement, or empty. Recorded so a consuming binary can fail
with an explanation instead of at runtime.""(�
version�The resolved package version this spoke was fetched at, or
empty. A trailing keyword with a default because this helper is
re-exported for rule sets outside //dart/pub — notably
rules_flutter's `flutter_pub_package` — whose existing calls must
keep working; a spoke that omits it simply states no version, and
an unstated version never conflicts with a stated one.""(�Generate the BUILD.bazel content for a single `dart_library` spoke.

The shape — `srcs = glob(["lib/**/*.dart"], allow_empty = True)`, the
non-Dart remainder of `lib/` as `resources`, a `package_name` matching the
target name, public visibility, optional deps block — is the canonical
pub-spoke layout. Resource-only and Swift-only/Kotlin-only Flutter platform
packages produce empty source globs but must still resolve as labels, hence
`allow_empty`.

The two globs partition `lib/` rather than covering only the Dart half of
it. A published package's `lib/` is addressable as `package:<name>/<path>`
whatever the extension, so a spoke that keeps only `*.dart` is a package
with pieces missing — `dwds` without the client JavaScript it serves,
`lints` without the YAML every `analysis_options.yaml` includes. Whatever
a future package ships lands in one of the two globs, so nothing is
dropped for being unanticipated.
""
 BUILD.bazel content as a string.2S
make_dart_library_build_content0@@rules_dart//dart/pub/private:build_content.bzl
		�The BUILD file shape every pub spoke repository carries.

`pub.package()` and `pub.from_lock()` each materialise a pub.dev package as
its own repository holding a single `dart_library`. Both emit that target
through the one generator here, so a field added to the shape reaches both
paths instead of only the one whose template was edited.
�
4

rules_dartdart/pub/privatelanguage_version.bzl�derive_language_versionOCompute the language version string implied by an `environment.sdk` constraint.*�
�
derive_language_version�
sdk_constraintnVerbatim string from `pubspec.yaml`'s `environment.sdk`
field, or empty / `None` if the constraint is missing. (OCompute the language version string implied by an `environment.sdk` constraint.".
,A `<major>.<minor>` language version string.2N
derive_language_version3@@rules_dart//dart/pub/private:language_version.bzl
(	DEFAULT_LANGUAGE_VERSION2.7j2.7�	Derive a Dart language version from an `environment.sdk` constraint string.

Replicates `pub`'s `LanguageVersion.fromSdkConstraint` from
`dart-lang/pub/lib/src/language_version.dart`. The output is the value pub
writes into the `languageVersion` field of each `package_config.json` entry â
`<major>.<minor>` form, defaulting to `"2.7"` when the constraint is missing
or has no lower bound.

The algorithm mirrors pub's source:

  - Empty / `null` constraint â DEFAULT (`"2.7"`).
  - Caret (`^X.Y.Z`) â `"X.Y"`.
  - Range (`>=X.Y.Z <A.B.C`, `>=X.Y.Z`, `>X.Y.Z`, etc.) â lower bound's
    `<major>.<minor>`. If only an upper bound is present, â DEFAULT.
  - Bare exact version (`X.Y.Z`) â `"X.Y"`.
  - Union (`alt1 || alt2`) â derive on each alternative; take the result
    corresponding to the smallest min (or DEFAULT if any alternative has no
    lower bound and that one sorts first). Pub sorts internally; users
    typically write unions in ascending order.

Patch / prerelease / build-metadata suffixes are dropped before formatting.

The DEFAULT (`"2.7"`) is intentionally fixed at the version pub adopted
language versioning at. It is **not** the running SDK's language version. See
the `defaultLanguageVersion` const in pub's source.
�
2

rules_dartdart/pub/privatepub_repository.bzl�pub_packageFDownloads a pub.dev package and generates a dart_library BUILD target.R�
�
pub_packageFDownloads a pub.dev package and generates a dart_library BUILD target..
name"A unique name for this repository. G
deps9Repository names of pub packages this package depends on.2[]-
package_nameThe pub.dev package name. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 X
sha256HSHA256 hash of the package archive for integrity verification. Optional.2""/
version The package version to download. *@
pub_package1@@rules_dart//dart/pub/private:pub_repository.bzl
&&0
.
name"A unique name for this repository. I
G
deps9Repository names of pub packages this package depends on.2[]/
-
package_nameThe pub.dev package name. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 Z
X
sha256HSHA256 hash of the package archive for integrity verification. Optional.2""1
/
version The package version to download. �
//dart/pub:yaml_parser.bzlr�
'

rules_dartdart/pubyaml_parser.bzlJ
parse_pubspec_sdk_constraintparse_pubspec_sdk_constraint
0L
N�
$//dart/pub/private:build_content.bzlr�
1

rules_dartdart/pub/privatebuild_content.bzlP
make_dart_library_build_contentmake_dart_library_build_content
:Y
[�
'//dart/pub/private:language_version.bzlr�
4

rules_dartdart/pub/privatelanguage_version.bzl@
derive_language_versionderive_language_version
=T
V9Repository rule for downloading a single pub.dev package.�
+

rules_dartdart/pub/privateversion.bzl�parse_semver�Parses a semver string into a comparable tuple.

Follows semver spec: major.minor.patch[-prerelease][+buildmeta].
A version without prerelease is greater than the same version with one
(e.g., `1.0.0` > `1.0.0-dev.1`). Build metadata (`+N` / `+sha.123`) is
stripped before comparison, matching semver precedence rules.

Both the stable and prerelease paths return a 5-tuple:

    (major, minor, patch, kind_sentinel, prerelease_segments)

where `kind_sentinel` is `(1,)` for stable versions and `(0,)` for
prereleases, and `prerelease_segments` is a (possibly empty) tuple of
3-tuples encoding each prerelease segment. This shape comparison is
consistent regardless of whether either operand has a prerelease, so
`semver_gt("1.0.0", "1.0.0-dev.1")` returns cleanly without raising a
type mismatch.
*�
�
parse_semverI
version:A semver string like `1.9.1`, `2.0.0-dev.1`, or `3.0.0+4`. (�Parses a semver string into a comparable tuple.

Follows semver spec: major.minor.patch[-prerelease][+buildmeta].
A version without prerelease is greater than the same version with one
(e.g., `1.0.0` > `1.0.0-dev.1`). Build metadata (`+N` / `+sha.123`) is
stripped before comparison, matching semver precedence rules.

Both the stable and prerelease paths return a 5-tuple:

    (major, minor, patch, kind_sentinel, prerelease_segments)

where `kind_sentinel` is `(1,)` for stable versions and `(0,)` for
prereleases, and `prerelease_segments` is a (possibly empty) tuple of
3-tuples encoding each prerelease segment. This shape comparison is
consistent regardless of whether either operand has a prerelease, so
`semver_gt("1.0.0", "1.0.0-dev.1")` returns cleanly without raising a
type mismatch.
"V
TA tuple that can be compared with `>`, `<`, or `==` to other
`parse_semver` results.2:
parse_semver*@@rules_dart//dart/pub/private:version.bzl
�	semver_gt@Returns True if semver string a is greater than semver string b.*�
�
	semver_gt
a (
b (@Returns True if semver string a is greater than semver string b.27
	semver_gt*@@rules_dart//dart/pub/private:version.bzl
::9Semantic version parsing and comparison for pub packages.�
 

rules_dartdart/pubdefs.bzl�parse_semver�Parses a semver string into a comparable tuple.

Follows semver spec: major.minor.patch[-prerelease][+buildmeta].
A version without prerelease is greater than the same version with one
(e.g., `1.0.0` > `1.0.0-dev.1`). Build metadata (`+N` / `+sha.123`) is
stripped before comparison, matching semver precedence rules.

Both the stable and prerelease paths return a 5-tuple:

    (major, minor, patch, kind_sentinel, prerelease_segments)

where `kind_sentinel` is `(1,)` for stable versions and `(0,)` for
prereleases, and `prerelease_segments` is a (possibly empty) tuple of
3-tuples encoding each prerelease segment. This shape comparison is
consistent regardless of whether either operand has a prerelease, so
`semver_gt("1.0.0", "1.0.0-dev.1")` returns cleanly without raising a
type mismatch.
*�
�
parse_semverI
version:A semver string like `1.9.1`, `2.0.0-dev.1`, or `3.0.0+4`. (�Parses a semver string into a comparable tuple.

Follows semver spec: major.minor.patch[-prerelease][+buildmeta].
A version without prerelease is greater than the same version with one
(e.g., `1.0.0` > `1.0.0-dev.1`). Build metadata (`+N` / `+sha.123`) is
stripped before comparison, matching semver precedence rules.

Both the stable and prerelease paths return a 5-tuple:

    (major, minor, patch, kind_sentinel, prerelease_segments)

where `kind_sentinel` is `(1,)` for stable versions and `(0,)` for
prereleases, and `prerelease_segments` is a (possibly empty) tuple of
3-tuples encoding each prerelease segment. This shape comparison is
consistent regardless of whether either operand has a prerelease, so
`semver_gt("1.0.0", "1.0.0-dev.1")` returns cleanly without raising a
type mismatch.
"V
TA tuple that can be compared with `>`, `<`, or `==` to other
`parse_semver` results.2:
parse_semver*@@rules_dart//dart/pub/private:version.bzl
�
//dart/pub/private:version.bzlrh
+

rules_dartdart/pub/privateversion.bzl+
parse_semver_parse_semver
3@
R�Pub.dev package management.

This file is reserved for future pub-related build rules. To declare pub
dependencies, use the module extension in your MODULE.bazel instead:

    pub = use_extension("@rules_dart//dart/pub:extensions.bzl", "pub")

    # Individual packages:
    pub.package(name = "path", version = "1.9.1", sha256 = "...")
    use_repo(pub, "path")

    # Or from a lockfile:
    pub.from_lock(name = "my_deps", lock = "//:pubspec.lock")
    use_repo(pub, "my_deps")
�+
&

rules_dartdart/pubextensions.bzl�#pubSDeclares pub.dev package dependencies for download and use as dart_library targets.J�#
�
pubSDeclares pub.dev package dependencies for download and use as dart_library targets.�
packageH
name<The pub.dev package name (also used as the repository name). G
deps9Repository names of pub packages this package depends on.2[]1
sha256#SHA256 hash of the package archive. /
version The package version to download. �	
	from_lock�
name�Repository name for the resolved packages. The name is global to the extension, not scoped to the declaring module: every `from_lock` that states it â in any module in the build â contributes to one hub holding the union of those locks, and each package is aliased once. That is what makes two modules that both call their hub the obvious thing work when a third depends on both. It also means a module can reach a package only another module's lock names, which resolves today and breaks the day that module leaves the build, so state in your own lock everything you import. Package versions are reconciled across the union â see `on_version_conflict`. �
ignore_hooks�Pub package names whose `hook/build.dart` is knowingly irrelevant to this build (its native code is never reached). Suppresses the unreplaced-hook error for them. This is a declaration you make deliberately; it is never a default.2[]+
lockThe pubspec.lock file to parse. �
on_version_conflict�What to do when another lock file provides a higher version of a package. 'error' (default) fails the build. 'upgrade' accepts the higher version.2"error"",
pub%@@rules_dart//dart/pub:extensions.bzl
���
�
packageH
name<The pub.dev package name (also used as the repository name). G
deps9Repository names of pub packages this package depends on.2[]1
sha256#SHA256 hash of the package archive. /
version The package version to download. J
H
name<The pub.dev package name (also used as the repository name). I
G
deps9Repository names of pub packages this package depends on.2[]3
1
sha256#SHA256 hash of the package archive. 1
/
version The package version to download. �
�	
	from_lock�
name�Repository name for the resolved packages. The name is global to the extension, not scoped to the declaring module: every `from_lock` that states it â in any module in the build â contributes to one hub holding the union of those locks, and each package is aliased once. That is what makes two modules that both call their hub the obvious thing work when a third depends on both. It also means a module can reach a package only another module's lock names, which resolves today and breaks the day that module leaves the build, so state in your own lock everything you import. Package versions are reconciled across the union â see `on_version_conflict`. �
ignore_hooks�Pub package names whose `hook/build.dart` is knowingly irrelevant to this build (its native code is never reached). Suppresses the unreplaced-hook error for them. This is a declaration you make deliberately; it is never a default.2[]+
lockThe pubspec.lock file to parse. �
on_version_conflict�What to do when another lock file provides a higher version of a package. 'error' (default) fails the build. 'upgrade' accepts the higher version.2"error"�
�
name�Repository name for the resolved packages. The name is global to the extension, not scoped to the declaring module: every `from_lock` that states it â in any module in the build â contributes to one hub holding the union of those locks, and each package is aliased once. That is what makes two modules that both call their hub the obvious thing work when a third depends on both. It also means a module can reach a package only another module's lock names, which resolves today and breaks the day that module leaves the build, so state in your own lock everything you import. Package versions are reconciled across the union â see `on_version_conflict`. �
�
ignore_hooks�Pub package names whose `hook/build.dart` is knowingly irrelevant to this build (its native code is never reached). Suppresses the unreplaced-hook error for them. This is a declaration you make deliberately; it is never a default.2[]-
+
lockThe pubspec.lock file to parse. �
�
on_version_conflict�What to do when another lock file provides a higher version of a package. 'error' (default) fails the build. 'upgrade' accepts the higher version.2"error"�
//dart/ext:registry.bzlrn
$

rules_dartdart/extregistry.bzl8
curated_code_assetscurated_code_assets
-@
B�
//dart/pub:pub_lock_hub.bzlrd
(

rules_dartdart/pubpub_lock_hub.bzl*
pub_lock_hubpub_lock_hub
1=
?�
//dart/pub:pub_lock_package.bzlrp
,

rules_dartdart/pubpub_lock_package.bzl2
pub_lock_packagepub_lock_package
5E
G�
//dart/pub:yaml_parser.bzlro
'

rules_dartdart/pubyaml_parser.bzl6
parse_pubspec_lockparse_pubspec_lock
0B
D�
%//dart/pub/private:pub_repository.bzlrl
2

rules_dartdart/pub/privatepub_repository.bzl(
pub_packagepub_package
;F
H�
//dart/pub/private:version.bzlra
+

rules_dartdart/pub/privateversion.bzl$
	semver_gt	semver_gt
4=
?<Module extension for declaring pub.dev package dependencies.�
(

rules_dartdart/pubpub_lock_hub.bzl�pub_lock_hubKCreates a hub repo with aliases pointing to individual spoke package repos.R�
�
pub_lock_hubKCreates a hub repo with aliases pointing to individual spoke package repos..
name"A unique name for this repository. S
hub_nameCThe apparent name of this hub repo (for constructing spoke labels). ?
packages/All hosted package names to create aliases for. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 R
spoke_prefix<Prefix for spoke repo names. If empty, defaults to hub_name.2""*7
pub_lock_hub'@@rules_dart//dart/pub:pub_lock_hub.bzl
0
.
name"A unique name for this repository. U
S
hub_nameCThe apparent name of this hub repo (for constructing spoke labels). A
?
packages/All hosted package names to create aliases for. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 T
R
spoke_prefix<Prefix for spoke repo names. If empty, defaults to hub_name.2""�Hub repository rule for pubspec.lock packages.

Generates a BUILD file with aliases from each package name to its
spoke repository: `@hub//:pkg` â `@hub__pkg//:pkg`.
�<
,

rules_dartdart/pubpub_lock_package.bzl�derive_language_versionOCompute the language version string implied by an `environment.sdk` constraint.*�
�
derive_language_version�
sdk_constraintnVerbatim string from `pubspec.yaml`'s `environment.sdk`
field, or empty / `None` if the constraint is missing. (OCompute the language version string implied by an `environment.sdk` constraint.".
,A `<major>.<minor>` language version string.2N
derive_language_version3@@rules_dart//dart/pub/private:language_version.bzl
�make_dart_library_build_content�Generate the BUILD.bazel content for a single `dart_library` spoke.

The shape — `srcs = glob(["lib/**/*.dart"], allow_empty = True)`, the
non-Dart remainder of `lib/` as `resources`, a `package_name` matching the
target name, public visibility, optional deps block — is the canonical
pub-spoke layout. Resource-only and Swift-only/Kotlin-only Flutter platform
packages produce empty source globs but must still resolve as labels, hence
`allow_empty`.

The two globs partition `lib/` rather than covering only the Dart half of
it. A published package's `lib/` is addressable as `package:<name>/<path>`
whatever the extension, so a spoke that keeps only `*.dart` is a package
with pieces missing — `dwds` without the client JavaScript it serves,
`lints` without the YAML every `analysis_options.yaml` includes. Whatever
a future package ships lands in one of the two globs, so nothing is
dropped for being unanticipated.
*�
�
make_dart_library_build_contentG
name;Target name (also the `package_name` for the dart_library). (�
depszList of fully-qualified Bazel label strings for sibling spokes
(e.g. `"@hub__dep//:dep"`). Pass an empty list for no deps. (�
language_version�Dart language version string (e.g. `"3.0"`),
usually derived from the package's pubspec SDK constraint via
`derive_language_version`. (�
code_assets�List of `dart_code_asset` label strings replacing this
package's `hook/build.dart` output. Attaching them here rather
than at the consuming binary is what makes them propagate: they
become part of the package's own metadata.[](�
has_unreplaced_hook�Path of a build hook this package ships that has
no replacement, or empty. Recorded so a consuming binary can fail
with an explanation instead of at runtime.""(�
version�The resolved package version this spoke was fetched at, or
empty. A trailing keyword with a default because this helper is
re-exported for rule sets outside //dart/pub — notably
rules_flutter's `flutter_pub_package` — whose existing calls must
keep working; a spoke that omits it simply states no version, and
an unstated version never conflicts with a stated one.""(�Generate the BUILD.bazel content for a single `dart_library` spoke.

The shape — `srcs = glob(["lib/**/*.dart"], allow_empty = True)`, the
non-Dart remainder of `lib/` as `resources`, a `package_name` matching the
target name, public visibility, optional deps block — is the canonical
pub-spoke layout. Resource-only and Swift-only/Kotlin-only Flutter platform
packages produce empty source globs but must still resolve as labels, hence
`allow_empty`.

The two globs partition `lib/` rather than covering only the Dart half of
it. A published package's `lib/` is addressable as `package:<name>/<path>`
whatever the extension, so a spoke that keeps only `*.dart` is a package
with pieces missing — `dwds` without the client JavaScript it serves,
`lints` without the YAML every `analysis_options.yaml` includes. Whatever
a future package ships lands in one of the two globs, so nothing is
dropped for being unanticipated.
""
 BUILD.bazel content as a string.2S
make_dart_library_build_content0@@rules_dart//dart/pub/private:build_content.bzl
		�pub_lock_packageQDownloads a single hosted package from a pubspec.lock and generates a BUILD file.R�
�
pub_lock_packageQDownloads a single hosted package from a pubspec.lock and generates a BUILD file..
name"A unique name for this repository. A
base_url Base URL for the pub repository.2"https://pub.dev"�
code_assets�Labels of `dart_code_asset` targets replacing this package's `hook/build.dart` output. Resolved by the `pub` extension from rules_dart's curated registry; attached to the generated `dart_library` so they propagate to every consumer.2[]O
hub_name?Name of the hub repo (for constructing cross-spoke dep labels). �
ignore_hookxSuppress the unreplaced-hook diagnostic for this package. Set by `pub.from_lock(ignore_hooks = [...])`; never a default.2FalseU
lock_packages>All hosted package names in the lock file (for dep filtering).2[]-
package_nameThe pub.dev package name. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 3
sha256#SHA256 hash of the package archive.2""/
version The package version to download. *?
pub_lock_package+@@rules_dart//dart/pub:pub_lock_package.bzl
`#`#0
.
name"A unique name for this repository. C
A
base_url Base URL for the pub repository.2"https://pub.dev"�
�
code_assets�Labels of `dart_code_asset` targets replacing this package's `hook/build.dart` output. Resolved by the `pub` extension from rules_dart's curated registry; attached to the generated `dart_library` so they propagate to every consumer.2[]Q
O
hub_name?Name of the hub repo (for constructing cross-spoke dep labels). �
�
ignore_hookxSuppress the unreplaced-hook diagnostic for this package. Set by `pub.from_lock(ignore_hooks = [...])`; never a default.2FalseW
U
lock_packages>All hosted package names in the lock file (for dep filtering).2[]/
-
package_nameThe pub.dev package name. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 5
3
sha256#SHA256 hash of the package archive.2""1
/
version The package version to download. �
//dart/pub:yaml_parser.bzlr�
'

rules_dartdart/pubyaml_parser.bzl6
parse_pubspec_depsparse_pubspec_deps
0BJ
parse_pubspec_sdk_constraintparse_pubspec_sdk_constraint
Fb
d�
$//dart/pub/private:build_content.bzlr�
1

rules_dartdart/pub/privatebuild_content.bzlQ
make_dart_library_build_content _make_dart_library_build_content
9Y
~�
'//dart/pub/private:language_version.bzlr�
4

rules_dartdart/pub/privatelanguage_version.bzlA
derive_language_version_derive_language_version
<T
q�Repository rule that downloads a single package from a pubspec.lock.

Each hosted package gets its own external repository (spoke), with the hub
repo providing aliases for backward-compatible `@hub//:pkg` labels.

Also re-exports `make_dart_library_build_content` as a public Starlark
helper. Other Bazel rule sets (notably rules_flutter's `flutter_pub_package`,
the `flutter pub get` analog) reuse this helper to emit the same
`dart_library` shape for non-plugin packages without duplicating the format.
�
'

rules_dartdart/pubyaml_parser.bzl�parse_pubspec_depsrExtract dependency names from a pubspec.yaml file.

Only extracts package names from the `dependencies:` section.
*�
�
parse_pubspec_deps6
content'String contents of a pubspec.yaml file. (rExtract dependency names from a pubspec.yaml file.

Only extracts package names from the `dependencies:` section.
"#
!List of dependency package names.2<
parse_pubspec_deps&@@rules_dart//dart/pub:yaml_parser.bzl
77�parse_pubspec_lock6Parse a pubspec.lock file into a dict of package info.*�
�
parse_pubspec_lock6
content'String contents of a pubspec.lock file. (6Parse a pubspec.lock file into a dict of package info."�
�Dict of package_name -> {
    "dependency": str,
    "source": str,
    "version": str,
    "description": dict (keys vary by source type),
}2<
parse_pubspec_lock&@@rules_dart//dart/pub:yaml_parser.bzl
�parse_pubspec_sdk_constraint�Extract the `environment.sdk` constraint from a pubspec.yaml file.

Returns the value of `environment.sdk` as a string. Returns the empty
string when the constraint is missing.
*�
�
parse_pubspec_sdk_constraint6
content'String contents of a pubspec.yaml file. (�Extract the `environment.sdk` constraint from a pubspec.yaml file.

Returns the value of `environment.sdk` as a string. Returns the empty
string when the constraint is missing.
"H
FThe SDK version constraint string, e.g. `^3.5.0` or `>=2.12.0 <4.0.0`.2F
parse_pubspec_sdk_constraint&@@rules_dart//dart/pub:yaml_parser.bzl
JJO
	:yaml.bzlr@

yaml.bzlyaml.bzl
yamlyaml
#
%�Pubspec-shape extractors for pubspec.lock and pubspec.yaml files.

Generic YAML parsing is delegated to `@yaml.bzl//:yaml.bzl`; this module
just projects the parsed value down to the exact shapes the rules_dart
pub extension and repository rules consume.
�
7

rules_dartdart/tests/no_lv_fixtureno_lv_rules.bzl�no_lv_dart_libraryUA `dart_library`-shaped rule that emits `DartPackageInfo` without `language_version`."�
�
no_lv_dart_libraryUA `dart_library`-shaped rule that emits `DartPackageInfo` without `language_version`.*
nameA unique name for this target. &
package_nameDart package name. 
srcsDart source files. "L
no_lv_dart_library6@@rules_dart//dart/tests/no_lv_fixture:no_lv_rules.bzl
,
*
nameA unique name for this target. (
&
package_nameDart package name.  

srcsDart source files. �
//dart:providers.bzlr�
!

rules_dartdartproviders.bzl"
DartInfoDartInfo
*20
DartPackageInfoDartPackageInfo
6E
GGTest-only rule that emits `DartPackageInfo` without `language_version`.�	
)

rules_dart
dart/testssmall_suite.bzl�small_unittest_suiteCDeclares `unittest.suite(name, *test_rules)` with `size = "small"`.*�
�
small_unittest_suiteO
nameCName of the generated `test_suite`, and prefix of each test target. (6

test_rules&Test rules created by `unittest.make`.(CDeclares `unittest.suite(name, *test_rules)` with `size = "small"`.2@
small_unittest_suite(@@rules_dart//dart/tests:small_suite.bzl
i
//lib:partial.bzlrR
 
bazel_skyliblibpartial.bzl 
partialpartial
)0
2m
//lib:unittest.bzlrU
!
bazel_skyliblibunittest.bzl"
unittestunittest
*2
4�`unittest.suite`, with every generated target declared `size = "small"`.

Skylib's suites leave Bazel's default `medium` size in place â a 300s timeout
for Starlark tests that finish in well under a second. Bazel notices the gap
and prints "There were tests whose specified size is too big" on every run,
which buries real diagnostics in CI logs.

`partial.make` is skylib's documented way to set attributes on the targets
`unittest.suite` generates; there is no plain keyword argument for it.
��


rules_dartdartdefs.bzl�,dart_aggregate_codegenfRuns a package-level aggregate Dart code generator, producing one or more declared outputs per target."�+
�
dart_aggregate_codegenfRuns a package-level aggregate Dart code generator, producing one or more declared outputs per target.*
nameA unique name for this target. �

asset_deps�Non-Dart files the Builder's `Resolver` / `findAssets` must see (e.g. generated data shards, JSON/YAML sidecars). Each file is staged and passed as `--dep <exec>|<asset>` using `asset_path_for`.2[]U
configEBuilder options as a JSON object string. Passed as `--config <json>`.2""�
deps�`dart_library`-shaped targets (anything exporting `DartInfo`) whose transitive sources populate a synthesised `package_config.json`. Same-package siblings not already in `srcs` are auto-staged as `--dep`.*

DartInfo2[]X
generator_args@Escape-hatch additional arguments. Prefer the typed attrs above.2[]�
generator_binxPre-compiled generator executable matching the rules_dart shim CLI contract. Mutually exclusive with `generator_script`.2Noney
generator_script]A `.dart` script to run via `dart run` as the generator. Mutually exclusive with `generator`.2None�
language_versionrDart language version of the consuming package, in `<major>.<minor>` form. Empty falls back to a built-in default.2""�
outputs�Output file paths (package-relative). One entry per builder-produced extension â e.g. `['lib/app.config.dart', 'lib/app.module.dart']` for injectable's config stage. �
package�A `dart_package_metadata` declaring this Dart package's `package_name` and `language_version`. Mutually exclusive with the inline `package_name` / `language_version` attributes: set `package` to state those facts once for every rule building this package, or set them inline, but never both. Referencing a target is what lets rules in *different* BUILD files share one declaration, which a macro cannot do.*
DartPackageMetadataInfo2Noneq
package_configWOptional pre-existing `package_config.json`; overrides the one synthesised from `deps`.2None�
package_name�Dart package name owning `srcs`. Must match the consuming `dart_library`'s `package_name` â enforced where the two meet, in that library's `srcs`. Set this or `package`, not both; `package` is how one declaration serves every rule building the package, including rules in other BUILD files.2""a
partsRAdditional input files passed as `--part <path>` (for combining-style aggregates).2[]�
srcs�All source files the builder analyses. The first entry is the primary input passed as `--input` (its extension must match one in the builder's `buildExtensions` map); the rest are passed as `--input-asset-extra` and staged so the Builder's `findAssets` / `readAsString` see them. Typically a mix of `.dart` source files and generated data shards (e.g. `.injectable.json` for the injectable aggregate). "5
dart_aggregate_codegen@@rules_dart//dart:defs.bzl
��,
*
nameA unique name for this target. �
�

asset_deps�Non-Dart files the Builder's `Resolver` / `findAssets` must see (e.g. generated data shards, JSON/YAML sidecars). Each file is staged and passed as `--dep <exec>|<asset>` using `asset_path_for`.2[]W
U
configEBuilder options as a JSON object string. Passed as `--config <json>`.2""�
�
deps�`dart_library`-shaped targets (anything exporting `DartInfo`) whose transitive sources populate a synthesised `package_config.json`. Same-package siblings not already in `srcs` are auto-staged as `--dep`.*

DartInfo2[]Z
X
generator_args@Escape-hatch additional arguments. Prefer the typed attrs above.2[]�
�
generator_binxPre-compiled generator executable matching the rules_dart shim CLI contract. Mutually exclusive with `generator_script`.2None{
y
generator_script]A `.dart` script to run via `dart run` as the generator. Mutually exclusive with `generator`.2None�
�
language_versionrDart language version of the consuming package, in `<major>.<minor>` form. Empty falls back to a built-in default.2""�
�
outputs�Output file paths (package-relative). One entry per builder-produced extension â e.g. `['lib/app.config.dart', 'lib/app.module.dart']` for injectable's config stage. �
�
package�A `dart_package_metadata` declaring this Dart package's `package_name` and `language_version`. Mutually exclusive with the inline `package_name` / `language_version` attributes: set `package` to state those facts once for every rule building this package, or set them inline, but never both. Referencing a target is what lets rules in *different* BUILD files share one declaration, which a macro cannot do.*
DartPackageMetadataInfo2Nones
q
package_configWOptional pre-existing `package_config.json`; overrides the one synthesised from `deps`.2None�
�
package_name�Dart package name owning `srcs`. Must match the consuming `dart_library`'s `package_name` â enforced where the two meet, in that library's `srcs`. Set this or `package`, not both; `package` is how one declaration serves every rule building the package, including rules in other BUILD files.2""c
a
partsRAdditional input files passed as `--part <path>` (for combining-style aggregates).2[]�
�
srcs�All source files the builder analyses. The first entry is the primary input passed as `--input` (its extension must match one in the builder's `buildExtensions` map); the rest are passed as `--input-asset-extra` and staged so the Builder's `findAssets` / `readAsString` see them. Typically a mix of `.dart` source files and generated data shards (e.g. `.injectable.json` for the injectable aggregate). �dart_analysis_options�An `analysis_options.yaml` bundled with the packages its `include:` directives resolve against, for use as `dart_analyze_test`'s `options`."�
�
dart_analysis_options�An `analysis_options.yaml` bundled with the packages its `include:` directives resolve against, for use as `dart_analyze_test`'s `options`.*
nameA unique name for this target. �
deps�Dart packages whose files this options file `include`s by `package:` URI. Staged for resolution only â these are not analyzed, and do not become dependencies of the analyzed library.*

DartInfo2[],
src!The `analysis_options.yaml` file. "4
dart_analysis_options@@rules_dart//dart:defs.bzl
--,
*
nameA unique name for this target. �
�
deps�Dart packages whose files this options file `include`s by `package:` URI. Staged for resolution only â these are not analyzed, and do not become dependencies of the analyzed library.*

DartInfo2[].
,
src!The `analysis_options.yaml` file. �dart_analyze_testnRuns `dart analyze` on a Dart target as a build-time action. Fails the build if any analysis issues are found."�
�
dart_analyze_testnRuns `dart analyze` on a Dart target as a build-time action. Fails the build if any analysis issues are found.*
nameA unique name for this target. q
lib@Deprecated alias for `target`. Set one or the other, never both.*

DartInfo*
DartAnalyzableInfo2None�
options�A `dart_analysis_options` target, or a bare `analysis_options.yaml`. Use the target form when the file `include`s a ruleset by `package:` URI. If omitted, the Dart SDK's default analysis options are used, and are pinned hermetically rather than left to whatever file happens to sit above the staged sources.2None�
target�The target whose Dart sources to analyze â a `dart_library`, or a `dart_binary`/`dart_test`/web binary, whose entrypoint is analyzed along with its whole transitive closure.*

DartInfo*
DartAnalyzableInfo2None"0
dart_analyze_test@@rules_dart//dart:defs.bzl
gg,
*
nameA unique name for this target. s
q
lib@Deprecated alias for `target`. Set one or the other, never both.*

DartInfo*
DartAnalyzableInfo2None�
�
options�A `dart_analysis_options` target, or a bare `analysis_options.yaml`. Use the target form when the file `include`s a ruleset by `package:` URI. If omitted, the Dart SDK's default analysis options are used, and are pinned hermetically rather than left to whatever file happens to sit above the staged sources.2None�
�
target�The target whose Dart sources to analyze â a `dart_library`, or a `dart_binary`/`dart_test`/web binary, whose entrypoint is analyzed along with its whole transitive closure.*

DartInfo*
DartAnalyzableInfo2None�*dart_binary1Compiles a Dart application using `dart compile`."�*
�
dart_binary1Compiles a Dart application using `dart compile`.*
nameA unique name for this target. �
code_assets�Native code assets (e.g. `//dart/ext/sqlite3:code_asset`) the binary's `@Native` FFI bindings resolve against. When set, the main is compiled to a kernel with the code-asset mapping embedded (`gen_kernel --native-assets`) before the snapshot/exe is produced, and the libraries are staged in runfiles so the Dart VM resolves them relative to the executable at runtime. Each entry must provide `DartCodeAssetInfo` (see the `dart_code_asset` rule).*
DartCodeAssetInfo2[]�
code_assets_from_deps�Whether to pick up native code assets propagated through `deps`.

Leave this on for a program that runs the packages it depends on. Turn it off for a `dart_binary` used purely as a *build tool* â a code generator, a linter â which imports pub packages for their Dart API but never loads their native libraries. Without the opt-out such a tool would build (and in an exec configuration, cross-build) every native library anywhere in its dependency closure. rules_dart's own `dart/ext` builder shims set this to `False`: `drift_dev` depends on `package:sqlite3`, but generating code never calls into libsqlite3.

Also suppresses the unreplaced-`hook/build.dart` diagnostic, on the same grounds â a tool that never loads native code is unaffected by a package whose native code was not built.2True�
compile_mode�The `dart compile` mode. Determines the output format:

- `exe` (default): Self-contained native machine code. No Dart SDK needed at runtime. Best for deployment.
- `aot-snapshot`: AOT-compiled snapshot. Requires `dartaotruntime` to execute. Smaller than `exe`.
- `kernel`: Dart kernel binary (`.dill`). Requires `dart` to execute. Fastest compilation, useful for development.
- `jit-snapshot`: JIT snapshot with trained profile data. Requires `dart` to execute. Fastest startup after warmup.
2"exe"�
dart_compile_flags�Extra flags passed to `dart compile` after compilation-mode defaults. Flags appear last so they can override defaults (e.g., `--extra-gen-snapshot-options=--optimization_level=3`).2[]�
data�Additional files needed at runtime. These are added to runfiles so they can be found via the runfiles tree when using `bazel run`.2[]f
definesUDart environment declarations (`key=value`). Each entry becomes a `-Dkey=value` flag.2[]H
deps.`dart_library` targets this binary depends on.*

DartInfo2[]N
mainBThe Dart entrypoint file containing a top-level `main()` function. o
srcsaAdditional Dart source files that are part of this binary's package but not reachable via `deps`.2[]"*
dart_binary@@rules_dart//dart:defs.bzl
��,
*
nameA unique name for this target. �
�
code_assets�Native code assets (e.g. `//dart/ext/sqlite3:code_asset`) the binary's `@Native` FFI bindings resolve against. When set, the main is compiled to a kernel with the code-asset mapping embedded (`gen_kernel --native-assets`) before the snapshot/exe is produced, and the libraries are staged in runfiles so the Dart VM resolves them relative to the executable at runtime. Each entry must provide `DartCodeAssetInfo` (see the `dart_code_asset` rule).*
DartCodeAssetInfo2[]�
�
code_assets_from_deps�Whether to pick up native code assets propagated through `deps`.

Leave this on for a program that runs the packages it depends on. Turn it off for a `dart_binary` used purely as a *build tool* â a code generator, a linter â which imports pub packages for their Dart API but never loads their native libraries. Without the opt-out such a tool would build (and in an exec configuration, cross-build) every native library anywhere in its dependency closure. rules_dart's own `dart/ext` builder shims set this to `False`: `drift_dev` depends on `package:sqlite3`, but generating code never calls into libsqlite3.

Also suppresses the unreplaced-`hook/build.dart` diagnostic, on the same grounds â a tool that never loads native code is unaffected by a package whose native code was not built.2True�
�
compile_mode�The `dart compile` mode. Determines the output format:

- `exe` (default): Self-contained native machine code. No Dart SDK needed at runtime. Best for deployment.
- `aot-snapshot`: AOT-compiled snapshot. Requires `dartaotruntime` to execute. Smaller than `exe`.
- `kernel`: Dart kernel binary (`.dill`). Requires `dart` to execute. Fastest compilation, useful for development.
- `jit-snapshot`: JIT snapshot with trained profile data. Requires `dart` to execute. Fastest startup after warmup.
2"exe"�
�
dart_compile_flags�Extra flags passed to `dart compile` after compilation-mode defaults. Flags appear last so they can override defaults (e.g., `--extra-gen-snapshot-options=--optimization_level=3`).2[]�
�
data�Additional files needed at runtime. These are added to runfiles so they can be found via the runfiles tree when using `bazel run`.2[]h
f
definesUDart environment declarations (`key=value`). Each entry becomes a `-Dkey=value` flag.2[]J
H
deps.`dart_library` targets this binary depends on.*

DartInfo2[]P
N
mainBThe Dart entrypoint file containing a top-level `main()` function. q
o
srcsaAdditional Dart source files that are part of this binary's package but not reachable via `deps`.2[]�dart_code_assetwBinds a Bazel-built native dynamic library to a Dart code-asset id, for use in `dart_test`/`dart_binary` `code_assets`."�
�

dart_code_assetwBinds a Bazel-built native dynamic library to a Dart code-asset id, for use in `dart_test`/`dart_binary` `code_assets`.*
nameA unique name for this target. �
asset_id�The code-asset id the owning package's `@Native`/`@ffi.DefaultAsset` declares (e.g. `package:sqlite3/src/ffi/libsqlite3.g.dart`). �
	link_mode�How the runtime loads this asset. One of `dynamic_loading_bundle` (a Bazel-built library shipped alongside the app), `dynamic_loading_system` (a library already present on the target system, named by `system_uri`), `dynamic_loading_executable`, or `dynamic_loading_process`. The reserved `static` mode fails fast â neither the Dart VM nor the Flutter engine implements it.

May be a `select()`: an ext package that bundles on one platform and uses the system library on another expresses that here, and consumers see a single target.2"dynamic_loading_bundle"�
shared_library�A `cc_shared_library` target whose dynamic library backs this code asset. Required for `dynamic_loading_bundle`; forbidden for the other link modes.*
CcSharedLibraryInfo2None�

system_urivSystem library URI, e.g. `libsqlite3.so.0`. Required for `dynamic_loading_system`; forbidden for the other link modes.2""".
dart_code_asset@@rules_dart//dart:defs.bzl
__,
*
nameA unique name for this target. �
�
asset_id�The code-asset id the owning package's `@Native`/`@ffi.DefaultAsset` declares (e.g. `package:sqlite3/src/ffi/libsqlite3.g.dart`). �
�
	link_mode�How the runtime loads this asset. One of `dynamic_loading_bundle` (a Bazel-built library shipped alongside the app), `dynamic_loading_system` (a library already present on the target system, named by `system_uri`), `dynamic_loading_executable`, or `dynamic_loading_process`. The reserved `static` mode fails fast â neither the Dart VM nor the Flutter engine implements it.

May be a `select()`: an ext package that bundles on one platform and uses the system library on another expresses that here, and consumers see a single target.2"dynamic_loading_bundle"�
�
shared_library�A `cc_shared_library` target whose dynamic library backs this code asset. Required for `dynamic_loading_bundle`; forbidden for the other link modes.*
CcSharedLibraryInfo2None�
�

system_urivSystem library URI, e.g. `libsqlite3.so.0`. Required for `dynamic_loading_system`; forbidden for the other link modes.2""�5dart_codegenURuns a per-file Dart code generator, producing one or more sibling outputs per input."�4
�
dart_codegenURuns a per-file Dart code generator, producing one or more sibling outputs per input.*
nameA unique name for this target. �

asset_deps�Non-Dart files the Builder's `Resolver` / `findAssets` must see (e.g. `.drift` schemas, `.drift_prep.json` sidecars, `.yaml` configs read via `BuildStep`). Each file is staged as an action input and passed as `--dep <exec>|<asset>` using `asset_path_for`. For Dart libraries, use `deps`. For files that only need to exist on disk for a subprocess / runfile (not read through `package:build`), use `data`.2[]�
config�Builder options as a JSON object string. Passed as `--config <json>`. Shape mirrors build_runner's `build.yaml` `options:` block for the underlying builder.2""�
data�Additional data files added to the action inputs but not passed as flagged args. Sandbox-only â NOT visible to the Builder's `Resolver` / `findAssets`. For files the Builder must see via its AssetReader, use `asset_deps` instead.2[]�
deps�`dart_library`-shaped targets (anything exporting `DartInfo`) whose transitive sources populate a synthesised `package_config.json` for the shim's analyzer. Any file belonging to the same Dart package as `src` is also auto-staged as `--dep` so the Resolver can walk siblings.*

DartInfo2[]l
	generatorWA `.dart` script to run as the code generator. Mutually exclusive with `generator_bin`.2NoneX
generator_args@Escape-hatch additional arguments. Prefer the typed attrs above.2[]�
generator_binsA pre-compiled generator executable matching the rules_dart shim CLI contract. Mutually exclusive with `generator`.2None�
language_version�Dart language version of the consuming package, in `<major>.<minor>` form (e.g. `3.11`). When empty, defers to a built-in safe default â set explicitly only when pinning to a specific language-version behaviour.2""�
output_suffixes�One or more suffixes appended to the input stem to derive output file paths. E.g. `['.g.dart']` for a SharedPart combining output; `['.config.dart', '.module.dart']` for injectable's config stage, which emits both per input. At least one suffix is required. �
package�A `dart_package_metadata` declaring this Dart package's `package_name` and `language_version`. Mutually exclusive with the inline `package_name` / `language_version` attributes: set `package` to state those facts once for every rule building this package, or set them inline, but never both. Referencing a target is what lets rules in *different* BUILD files share one declaration, which a macro cannot do.*
DartPackageMetadataInfo2None�
package_config�Optional pre-existing `package_config.json` passed as `--package-config <path>`. When unset the rule synthesises one from `deps`.2None�
package_name�Dart package name owning `src`. Must match the consuming `dart_library`'s `package_name` â enforced where the two meet, in that library's `srcs`. Passed as `--package`. Set this or `package`, not both; `package` is how one declaration serves every rule building the package, including rules in other BUILD files.2""x
partsiAdditional input files passed as `--part <path>` (used by the combining shim to merge SharedPart shards).2[]]
srcRThe single `.dart` input file to process. Use one `dart_codegen` target per input. "+
dart_codegen@@rules_dart//dart:defs.bzl
��,
*
nameA unique name for this target. �
�

asset_deps�Non-Dart files the Builder's `Resolver` / `findAssets` must see (e.g. `.drift` schemas, `.drift_prep.json` sidecars, `.yaml` configs read via `BuildStep`). Each file is staged as an action input and passed as `--dep <exec>|<asset>` using `asset_path_for`. For Dart libraries, use `deps`. For files that only need to exist on disk for a subprocess / runfile (not read through `package:build`), use `data`.2[]�
�
config�Builder options as a JSON object string. Passed as `--config <json>`. Shape mirrors build_runner's `build.yaml` `options:` block for the underlying builder.2""�
�
data�Additional data files added to the action inputs but not passed as flagged args. Sandbox-only â NOT visible to the Builder's `Resolver` / `findAssets`. For files the Builder must see via its AssetReader, use `asset_deps` instead.2[]�
�
deps�`dart_library`-shaped targets (anything exporting `DartInfo`) whose transitive sources populate a synthesised `package_config.json` for the shim's analyzer. Any file belonging to the same Dart package as `src` is also auto-staged as `--dep` so the Resolver can walk siblings.*

DartInfo2[]n
l
	generatorWA `.dart` script to run as the code generator. Mutually exclusive with `generator_bin`.2NoneZ
X
generator_args@Escape-hatch additional arguments. Prefer the typed attrs above.2[]�
�
generator_binsA pre-compiled generator executable matching the rules_dart shim CLI contract. Mutually exclusive with `generator`.2None�
�
language_version�Dart language version of the consuming package, in `<major>.<minor>` form (e.g. `3.11`). When empty, defers to a built-in safe default â set explicitly only when pinning to a specific language-version behaviour.2""�
�
output_suffixes�One or more suffixes appended to the input stem to derive output file paths. E.g. `['.g.dart']` for a SharedPart combining output; `['.config.dart', '.module.dart']` for injectable's config stage, which emits both per input. At least one suffix is required. �
�
package�A `dart_package_metadata` declaring this Dart package's `package_name` and `language_version`. Mutually exclusive with the inline `package_name` / `language_version` attributes: set `package` to state those facts once for every rule building this package, or set them inline, but never both. Referencing a target is what lets rules in *different* BUILD files share one declaration, which a macro cannot do.*
DartPackageMetadataInfo2None�
�
package_config�Optional pre-existing `package_config.json` passed as `--package-config <path>`. When unset the rule synthesises one from `deps`.2None�
�
package_name�Dart package name owning `src`. Must match the consuming `dart_library`'s `package_name` â enforced where the two meet, in that library's `srcs`. Passed as `--package`. Set this or `package`, not both; `package` is how one declaration serves every rule building the package, including rules in other BUILD files.2""z
x
partsiAdditional input files passed as `--part <path>` (used by the combining shim to merge SharedPart shards).2[]_
]
srcRThe single `.dart` input file to process. Use one `dart_codegen` target per input. �dart_fix�Applies `dart fix` to a Dart target's sources. `bazel run` writes the fixes into the workspace; `bazel run ... -- --dry-run` prints them instead. Generated files are never written.

Output Groups:
  dart_fix_fixes: A directory of the changed files, at their workspace-relative paths.
  dart_fix_manifest: JSON recording which files were fixed and which changes were discarded as ineligible.

Build either directly to inspect what a run would do without rewriting anything, e.g. `bazel build //pkg:fix --output_groups=+dart_fix_manifest`."�
�

dart_fix�Applies `dart fix` to a Dart target's sources. `bazel run` writes the fixes into the workspace; `bazel run ... -- --dry-run` prints them instead. Generated files are never written.

Output Groups:
  dart_fix_fixes: A directory of the changed files, at their workspace-relative paths.
  dart_fix_manifest: JSON recording which files were fixed and which changes were discarded as ineligible.

Build either directly to inspect what a run would do without rewriting anything, e.g. `bazel build //pkg:fix --output_groups=+dart_fix_manifest`.*
nameA unique name for this target. q
lib@Deprecated alias for `target`. Set one or the other, never both.*

DartInfo*
DartAnalyzableInfo2None�
options�A `dart_analysis_options` target, or a bare `analysis_options.yaml`. Should be the same target the matching `dart_analyze_test` uses: fixes are driven by the lints that are enabled, so differing options mean `bazel run` cannot turn the analyze test green.2None�
target�The target whose Dart sources to fix â a `dart_library`, or a `dart_binary`/`dart_test`/web binary, whose entrypoint is fixed too. Its whole transitive closure is considered, matching `dart_analyze_test`.*

DartInfo*
DartAnalyzableInfo2None"'
dart_fix@@rules_dart//dart:defs.bzl
��,
*
nameA unique name for this target. s
q
lib@Deprecated alias for `target`. Set one or the other, never both.*

DartInfo*
DartAnalyzableInfo2None�
�
options�A `dart_analysis_options` target, or a bare `analysis_options.yaml`. Should be the same target the matching `dart_analyze_test` uses: fixes are driven by the lints that are enabled, so differing options mean `bazel run` cannot turn the analyze test green.2None�
�
target�The target whose Dart sources to fix â a `dart_library`, or a `dart_binary`/`dart_test`/web binary, whose entrypoint is fixed too. Its whole transitive closure is considered, matching `dart_analyze_test`.*

DartInfo*
DartAnalyzableInfo2None�dart_js_binaryDCompiles a Dart web application to JavaScript via `dart compile js`."�

�
dart_js_binaryDCompiles a Dart web application to JavaScript via `dart compile js`.*
nameA unique name for this target. �
dart_compile_flags�Extra flags passed to `dart compile` after compilation-mode defaults. Flags appear last so they can override defaults (e.g., `-O4` for dart2js).2[]f
definesUDart environment declarations (`key=value`). Each entry becomes a `-Dkey=value` flag.2[]M
deps3`dart_library` targets this application depends on.*

DartInfo2[]N
mainBThe Dart entrypoint file containing a top-level `main()` function. t
srcsfAdditional Dart source files that are part of this application's package but not reachable via `deps`.2[]"-
dart_js_binary@@rules_dart//dart:defs.bzl
��,
*
nameA unique name for this target. �
�
dart_compile_flags�Extra flags passed to `dart compile` after compilation-mode defaults. Flags appear last so they can override defaults (e.g., `-O4` for dart2js).2[]h
f
definesUDart environment declarations (`key=value`). Each entry becomes a `-Dkey=value` flag.2[]O
M
deps3`dart_library` targets this application depends on.*

DartInfo2[]P
N
mainBThe Dart entrypoint file containing a top-level `main()` function. v
t
srcsfAdditional Dart source files that are part of this application's package but not reachable via `deps`.2[]�Cdart_library�Collects Dart sources and propagates dependency information via `DartInfo`. Does not compile or assemble; consumers co-locate generated sources."�A
�!
dart_library�Collects Dart sources and propagates dependency information via `DartInfo`. Does not compile or assemble; consumers co-locate generated sources.*
nameA unique name for this target. �
code_assets�Native code assets this package owns (see the `dart_code_asset` rule). Assets declared here propagate to every `dart_binary`/`dart_test` that depends on this library, directly or transitively â matching upstream, where depending on a package gets you its assets with no opt-in. Each `asset_id` must be namespaced to this library's `package_name`.*
DartCodeAssetInfo2[]�
depsuOther `dart_library` targets this library depends on. Their sources and package metadata are propagated transitively.*

DartInfo2[]�
has_unreplaced_hook�Path of a pub build hook (`hook/build.dart` / `hook/link.dart`) this package ships that rules_dart has no replacement for. Set by `pub.from_lock()`; hand-written `dart_library` targets leave it empty. A `dart_binary`/`dart_test` reaching such a package fails with an explanation, rather than producing a binary whose `@Native` bindings silently fail to resolve at runtime.2""�
language_version�Dart language version implied by the package's `environment.sdk` constraint, in `<major>.<minor>` form. Emitted as `languageVersion` in generated `package_config.json` entries. For pub packages this is set automatically by `pub.from_lock()`; for hand-written `dart_library` targets, set it from your workspace's `pubspec.yaml` if you want analyzer behaviour to match.2""�
package�A `dart_package_metadata` declaring this Dart package's `package_name` and `language_version`. Mutually exclusive with the inline `package_name` / `language_version` attributes: set `package` to state those facts once for every rule building this package, or set them inline, but never both. Referencing a target is what lets rules in *different* BUILD files share one declaration, which a macro cannot do.*
DartPackageMetadataInfo2None�
package_name�The Dart package name used in `package:` imports. If omitted, defaults to the last component of the Bazel package path. Set this or `package`, not both.2""�
	resources�Non-Dart files this package ships inside `lib/` â part of its published surface, but never compiled. `package:sky_engine`'s `lib/_embedder.yaml`, which the analyzer reads to resolve `dart:ui`, and `package:dwds`'s `lib/src/injected/client.js`, which it serves to the browser, are both this. Anything under `lib/` is addressable as `package:<name>/<path>` whatever its extension, so these are members of the package, not a consumer's `data`. They are staged wherever the package itself is staged â the analyzer's hermetic project tree â and ride the runfiles of every `dart_binary`/`dart_test` that depends on this library, mirroring pub, where the package directory exists whole on disk at run time. They are never compile inputs. `.dart` files belong in `srcs`; files outside `lib/` have no `package:` URI and belong in a consumer's `data`.2[]�
srcs�Dart source files (`.dart`), source-tree or generated. Typically `glob(["lib/**/*.dart"])`, optionally plus `dart_codegen` outputs. Generated members are co-located with the rest of the package by the consuming `dart_binary`/`dart_test`. Mutually exclusive with `srcs_dir`.2[]�
srcs_dir�A pre-assembled source directory (a `dart_source_set`) to use as this library's package root, instead of `srcs`. The directory is opaque and carries the package's non-Dart files too, so `resources` is rejected alongside it. For reuse/composition; usually you just list files in `srcs`.2None�
version�The package's own version, as resolved by pub (e.g. `2.2.0`). Set automatically by `pub.package()` / `pub.from_lock()`; leave it empty on hand-written targets, which have no resolved version to state. Its only use is agreement checking: when one package name arrives twice â two pub hubs each supplying `ffi`, say â a build whose two records name different versions would otherwise compile against whichever came first in dependency order, silently ignoring the other. Two *known*, differing versions fail the build; an empty one never conflicts.2"""+
dart_library@@rules_dart//dart:defs.bzl
��,
*
nameA unique name for this target. �
�
code_assets�Native code assets this package owns (see the `dart_code_asset` rule). Assets declared here propagate to every `dart_binary`/`dart_test` that depends on this library, directly or transitively â matching upstream, where depending on a package gets you its assets with no opt-in. Each `asset_id` must be namespaced to this library's `package_name`.*
DartCodeAssetInfo2[]�
�
depsuOther `dart_library` targets this library depends on. Their sources and package metadata are propagated transitively.*

DartInfo2[]�
�
has_unreplaced_hook�Path of a pub build hook (`hook/build.dart` / `hook/link.dart`) this package ships that rules_dart has no replacement for. Set by `pub.from_lock()`; hand-written `dart_library` targets leave it empty. A `dart_binary`/`dart_test` reaching such a package fails with an explanation, rather than producing a binary whose `@Native` bindings silently fail to resolve at runtime.2""�
�
language_version�Dart language version implied by the package's `environment.sdk` constraint, in `<major>.<minor>` form. Emitted as `languageVersion` in generated `package_config.json` entries. For pub packages this is set automatically by `pub.from_lock()`; for hand-written `dart_library` targets, set it from your workspace's `pubspec.yaml` if you want analyzer behaviour to match.2""�
�
package�A `dart_package_metadata` declaring this Dart package's `package_name` and `language_version`. Mutually exclusive with the inline `package_name` / `language_version` attributes: set `package` to state those facts once for every rule building this package, or set them inline, but never both. Referencing a target is what lets rules in *different* BUILD files share one declaration, which a macro cannot do.*
DartPackageMetadataInfo2None�
�
package_name�The Dart package name used in `package:` imports. If omitted, defaults to the last component of the Bazel package path. Set this or `package`, not both.2""�
�
	resources�Non-Dart files this package ships inside `lib/` â part of its published surface, but never compiled. `package:sky_engine`'s `lib/_embedder.yaml`, which the analyzer reads to resolve `dart:ui`, and `package:dwds`'s `lib/src/injected/client.js`, which it serves to the browser, are both this. Anything under `lib/` is addressable as `package:<name>/<path>` whatever its extension, so these are members of the package, not a consumer's `data`. They are staged wherever the package itself is staged â the analyzer's hermetic project tree â and ride the runfiles of every `dart_binary`/`dart_test` that depends on this library, mirroring pub, where the package directory exists whole on disk at run time. They are never compile inputs. `.dart` files belong in `srcs`; files outside `lib/` have no `package:` URI and belong in a consumer's `data`.2[]�
�
srcs�Dart source files (`.dart`), source-tree or generated. Typically `glob(["lib/**/*.dart"])`, optionally plus `dart_codegen` outputs. Generated members are co-located with the rest of the package by the consuming `dart_binary`/`dart_test`. Mutually exclusive with `srcs_dir`.2[]�
�
srcs_dir�A pre-assembled source directory (a `dart_source_set`) to use as this library's package root, instead of `srcs`. The directory is opaque and carries the package's non-Dart files too, so `resources` is rejected alongside it. For reuse/composition; usually you just list files in `srcs`.2None�
�
version�The package's own version, as resolved by pub (e.g. `2.2.0`). Set automatically by `pub.package()` / `pub.from_lock()`; leave it empty on hand-written targets, which have no resolved version to state. Its only use is agreement checking: when one package name arrives twice â two pub hubs each supplying `ffi`, say â a build whose two records name different versions would otherwise compile against whichever came first in dependency order, silently ignoring the other. Two *known*, differing versions fail the build; an empty one never conflicts.2""�!dart_package_metadata�Declares a Dart package's name and language version once, for every rule that builds part of it.

Point `dart_library`, `dart_codegen`, `dart_aggregate_codegen`, `dart_sqlcodegen`
and `dart_format_test` at it with `package = ":<name>"` instead of repeating
`package_name` and `language_version` on each:

```starlark
dart_package_metadata(
    name = "pkg",
    package_name = "my_app",
    language_version = "3.11",
)

dart_codegen(
    name = "model_g",
    package = ":pkg",
    src = "lib/model.dart",
    generator = "//tools:gen.dart",
    output_suffixes = [".g.dart"],
)

dart_library(
    name = "my_app",
    package = ":pkg",
    srcs = ["lib/model.dart", ":model_g"],
)
```

A rule takes these two facts from `package` or from the inline `package_name` /
`language_version` attributes, never both â setting both fails, so the two can
never drift into disagreeing. The inline attributes remain fully supported and
are still the contract every rule is defined against; they are what generated
spoke repositories emit, where a generator writes both from one value and there
is no duplication to remove. `dart_package_metadata` is for hand-written packages, where
there is.

Visible across BUILD files, which is the case a macro cannot reach: a package
whose `dart_library` sits in `app/BUILD.bazel` and whose `dart_codegen` sits in
`gen/BUILD.bazel` has two files stating the same two strings, and only a target
can be referenced from both.

Not to be confused with `pub.package()`, the module extension tag that fetches a
published package from pub.dev. This declares facts about a package you are
building yourself."�
�
dart_package_metadata�Declares a Dart package's name and language version once, for every rule that builds part of it.

Point `dart_library`, `dart_codegen`, `dart_aggregate_codegen`, `dart_sqlcodegen`
and `dart_format_test` at it with `package = ":<name>"` instead of repeating
`package_name` and `language_version` on each:

```starlark
dart_package_metadata(
    name = "pkg",
    package_name = "my_app",
    language_version = "3.11",
)

dart_codegen(
    name = "model_g",
    package = ":pkg",
    src = "lib/model.dart",
    generator = "//tools:gen.dart",
    output_suffixes = [".g.dart"],
)

dart_library(
    name = "my_app",
    package = ":pkg",
    srcs = ["lib/model.dart", ":model_g"],
)
```

A rule takes these two facts from `package` or from the inline `package_name` /
`language_version` attributes, never both â setting both fails, so the two can
never drift into disagreeing. The inline attributes remain fully supported and
are still the contract every rule is defined against; they are what generated
spoke repositories emit, where a generator writes both from one value and there
is no duplication to remove. `dart_package_metadata` is for hand-written packages, where
there is.

Visible across BUILD files, which is the case a macro cannot reach: a package
whose `dart_library` sits in `app/BUILD.bazel` and whose `dart_codegen` sits in
`gen/BUILD.bazel` has two files stating the same two strings, and only a target
can be referenced from both.

Not to be confused with `pub.package()`, the module extension tag that fetches a
published package from pub.dev. This declares facts about a package you are
building yourself.*
nameA unique name for this target. �
language_version�Dart language version implied by the package's `environment.sdk` constraint, in `<major>.<minor>` form (e.g. `3.11`). Emitted as `languageVersion` in generated `package_config.json` entries and passed to code generators as the root language version. Leave empty to state none.2""z
package_namefThe Dart package name used in `package:` imports â the `name:` from the package's `pubspec.yaml`. "4
dart_package_metadata@@rules_dart//dart:defs.bzl
,
*
nameA unique name for this target. �
�
language_version�Dart language version implied by the package's `environment.sdk` constraint, in `<major>.<minor>` form (e.g. `3.11`). Emitted as `languageVersion` in generated `package_config.json` entries and passed to code generators as the root language version. Leave empty to state none.2""|
z
package_namefThe Dart package name used in `package:` imports â the `name:` from the package's `pubspec.yaml`. �
dart_source_set�Assembles Dart sources (hand-written + generated) into one tree-artifact directory. Package-agnostic; consume via `dart_library`'s `srcs_dir`."�	
�
dart_source_set�Assembles Dart sources (hand-written + generated) into one tree-artifact directory. Package-agnostic; consume via `dart_library`'s `srcs_dir`.*
nameA unique name for this target. �
replace_prefixes}Map of output-path prefixes to rewrite, applied after `root_paths` stripping. Use to place cross-package inputs under `lib/`.
2{}�

root_paths�Paths treated as roots in the output directory (stripped). `"."` is this target's Bazel package. Set additional roots to flatten files from other packages.2["."]a
srcsUDart files (source and/or generated, from any target) to assemble into one directory. ".
dart_source_set@@rules_dart//dart:defs.bzl
��,
*
nameA unique name for this target. �
�
replace_prefixes}Map of output-path prefixes to rewrite, applied after `root_paths` stripping. Use to place cross-package inputs under `lib/`.
2{}�
�

root_paths�Paths treated as roots in the output directory (stripped). `"."` is this target's Bazel package. Set additional roots to flatten files from other packages.2["."]c
a
srcsUDart files (source and/or generated, from any target) to assemble into one directory. �&dart_sqlcodegentRuns a Dart code generator over a non-Dart input (`.drift`, `.moor`, â¦), producing one or more sibling outputs."�%
�
dart_sqlcodegentRuns a Dart code generator over a non-Dart input (`.drift`, `.moor`, â¦), producing one or more sibling outputs.*
nameA unique name for this target. �

asset_deps�Non-Dart files the Builder's `Resolver` / `findAssets` must see. Each file is staged as an action input and passed as `--dep <exec>|<asset>` using `asset_path_for`.2[]8
config(Builder options as a JSON object string.2""�
data�Additional data files added to action inputs but not passed as flagged args. Sandbox-only â NOT visible to the Builder's `Resolver` / `findAssets`. For files the Builder must see via its AssetReader, use `asset_deps`.2[]�
deps�`dart_library`-shaped targets (anything exporting `DartInfo`) whose transitive sources populate a synthesised `package_config.json`. Same-package siblings are auto-staged as `--dep`.*

DartInfo2[]:
generator_args"Escape-hatch additional arguments.2[]a
generator_binLPre-compiled generator executable matching the rules_dart shim CLI contract. r
language_versionXDart language version in `<major>.<minor>` form. Empty falls back to a built-in default.2""�
output_suffixes�Suffixes appended to the source stem (after stripping its extension). E.g. `['.drift_prep.json']`. Multi-output builders (e.g. drift_dev's preparing stage emits both `.drift_prep.json` and `.expr.temp.dart`) declare all suffixes here. �
package�A `dart_package_metadata` declaring this Dart package's `package_name` and `language_version`. Mutually exclusive with the inline `package_name` / `language_version` attributes: set `package` to state those facts once for every rule building this package, or set them inline, but never both. Referencing a target is what lets rules in *different* BUILD files share one declaration, which a macro cannot do.*
DartPackageMetadataInfo2Noneq
package_configWOptional pre-existing `package_config.json`; overrides the one synthesised from `deps`.2None�
package_name�Dart package name owning `src`. Must match the consuming `dart_library`'s `package_name` â enforced where the two meet, in that library's `srcs`. Set this or `package`, not both; `package` is how one declaration serves every rule building the package, including rules in other BUILD files.2""@
parts1Additional input files passed as `--part <path>`.2[]F
src;The single non-Dart input file (`.drift`, `.moor`, â¦). ".
dart_sqlcodegen@@rules_dart//dart:defs.bzl
��,
*
nameA unique name for this target. �
�

asset_deps�Non-Dart files the Builder's `Resolver` / `findAssets` must see. Each file is staged as an action input and passed as `--dep <exec>|<asset>` using `asset_path_for`.2[]:
8
config(Builder options as a JSON object string.2""�
�
data�Additional data files added to action inputs but not passed as flagged args. Sandbox-only â NOT visible to the Builder's `Resolver` / `findAssets`. For files the Builder must see via its AssetReader, use `asset_deps`.2[]�
�
deps�`dart_library`-shaped targets (anything exporting `DartInfo`) whose transitive sources populate a synthesised `package_config.json`. Same-package siblings are auto-staged as `--dep`.*

DartInfo2[]<
:
generator_args"Escape-hatch additional arguments.2[]c
a
generator_binLPre-compiled generator executable matching the rules_dart shim CLI contract. t
r
language_versionXDart language version in `<major>.<minor>` form. Empty falls back to a built-in default.2""�
�
output_suffixes�Suffixes appended to the source stem (after stripping its extension). E.g. `['.drift_prep.json']`. Multi-output builders (e.g. drift_dev's preparing stage emits both `.drift_prep.json` and `.expr.temp.dart`) declare all suffixes here. �
�
package�A `dart_package_metadata` declaring this Dart package's `package_name` and `language_version`. Mutually exclusive with the inline `package_name` / `language_version` attributes: set `package` to state those facts once for every rule building this package, or set them inline, but never both. Referencing a target is what lets rules in *different* BUILD files share one declaration, which a macro cannot do.*
DartPackageMetadataInfo2Nones
q
package_configWOptional pre-existing `package_config.json`; overrides the one synthesised from `deps`.2None�
�
package_name�Dart package name owning `src`. Must match the consuming `dart_library`'s `package_name` â enforced where the two meet, in that library's `srcs`. Set this or `package`, not both; `package` is how one declaration serves every rule building the package, including rules in other BUILD files.2""B
@
parts1Additional input files passed as `--part <path>`.2[]H
F
src;The single non-Dart input file (`.drift`, `.moor`, â¦). �dart_wasm_binaryoCompiles a Dart web application to WebAssembly via `dart compile wasm`. Requires a browser with WasmGC support."�
�
dart_wasm_binaryoCompiles a Dart web application to WebAssembly via `dart compile wasm`. Requires a browser with WasmGC support.*
nameA unique name for this target. �
dart_compile_flags�Extra flags passed to `dart compile` after compilation-mode defaults. Flags appear last so they can override defaults (e.g., `-O4` for dart2js).2[]f
definesUDart environment declarations (`key=value`). Each entry becomes a `-Dkey=value` flag.2[]M
deps3`dart_library` targets this application depends on.*

DartInfo2[]N
mainBThe Dart entrypoint file containing a top-level `main()` function. t
srcsfAdditional Dart source files that are part of this application's package but not reachable via `deps`.2[]"/
dart_wasm_binary@@rules_dart//dart:defs.bzl
��,
*
nameA unique name for this target. �
�
dart_compile_flags�Extra flags passed to `dart compile` after compilation-mode defaults. Flags appear last so they can override defaults (e.g., `-O4` for dart2js).2[]h
f
definesUDart environment declarations (`key=value`). Each entry becomes a `-Dkey=value` flag.2[]O
M
deps3`dart_library` targets this application depends on.*

DartInfo2[]P
N
mainBThe Dart entrypoint file containing a top-level `main()` function. v
t
srcsfAdditional Dart source files that are part of this application's package but not reachable via `deps`.2[]�DartCodeAssetInfo�A native code asset (a Bazel-built dynamic library) bound to the Dart `@Native`/`@DefaultAsset` asset id the owning package uses.

Produced by the `dart_code_asset` rule and consumed via the `code_assets` attribute of `dart_test` / `dart_binary`, which embed the mapping into the compiled kernel (`gen_kernel --native-assets`) so the Dart VM resolves the package's `@Native` symbols against the Bazel-built library at runtime.2�
�	
DartCodeAssetInfo�A native code asset (a Bazel-built dynamic library) bound to the Dart `@Native`/`@DefaultAsset` asset id the owning package uses.

Produced by the `dart_code_asset` rule and consumed via the `code_assets` attribute of `dart_test` / `dart_binary`, which embed the mapping into the compiled kernel (`gen_kernel --native-assets`) so the Dart VM resolves the package's `@Native` symbols against the Bazel-built library at runtime.�
asset_id�str: The code-asset id the owning package declares (its `@ffi.DefaultAsset` / `@Native(assetId:)`), e.g. `package:sqlite3/src/ffi/libsqlite3.g.dart`.�
	link_mode�str: How the runtime loads the asset. One of `dynamic_loading_bundle`, `dynamic_loading_system`, `dynamic_loading_executable`, `dynamic_loading_process` â the upstream `code_assets` strings, verbatim.�
dynamic_library�File or None: The dynamic library (`.so`/`.dylib`/`.dll`) the asset resolves to. Set only for `dynamic_loading_bundle`; `None` otherwise.t

system_urifstr: System library URI (e.g. `libsqlite3.so.0`) for `dynamic_loading_system`. Empty string otherwise."0
DartCodeAssetInfo@@rules_dart//dart:defs.bzl
���
�
asset_id�str: The code-asset id the owning package declares (its `@ffi.DefaultAsset` / `@Native(assetId:)`), e.g. `package:sqlite3/src/ffi/libsqlite3.g.dart`.�
�
	link_mode�str: How the runtime loads the asset. One of `dynamic_loading_bundle`, `dynamic_loading_system`, `dynamic_loading_executable`, `dynamic_loading_process` â the upstream `code_assets` strings, verbatim.�
�
dynamic_library�File or None: The dynamic library (`.so`/`.dylib`/`.dll`) the asset resolves to. Set only for `dynamic_loading_bundle`; `None` otherwise.v
t

system_urifstr: System library URI (e.g. `libsqlite3.so.0`) for `dynamic_loading_system`. Empty string otherwise.�
//dart:providers.bzlrh
!

rules_dartdartproviders.bzl5
DartCodeAssetInfo_DartCodeAssetInfo
);
R�
)//dart/private:dart_aggregate_codegen.bzlr�
6

rules_dartdart/privatedart_aggregate_codegen.bzl?
dart_aggregate_codegen_dart_aggregate_codegen
>U
q�
(//dart/private:dart_analysis_options.bzlr�
5

rules_dartdart/privatedart_analysis_options.bzl=
dart_analysis_options_dart_analysis_options
=S
n�
//dart/private:dart_analyze.bzlrs
,

rules_dartdart/privatedart_analyze.bzl5
dart_analyze_test_dart_analyze_test
4F
]�
//dart/private:dart_binary.bzlrf
+

rules_dartdart/privatedart_binary.bzl)
dart_binary_dart_binary
3?
P�
"//dart/private:dart_code_asset.bzlrr
/

rules_dartdart/privatedart_code_asset.bzl1
dart_code_asset_dart_code_asset
7G
\�
//dart/private:dart_codegen.bzlri
,

rules_dartdart/privatedart_codegen.bzl+
dart_codegen_dart_codegen
4A
S~
//dart/private:dart_fix.bzlr]
(

rules_dartdart/privatedart_fix.bzl#
dart_fix	_dart_fix
09
G�
#//dart/private:dart_format_test.bzlru
0

rules_dartdart/privatedart_format_test.bzl3
dart_format_test_dart_format_test
8I
_�
//dart/private:dart_library.bzlri
,

rules_dartdart/privatedart_library.bzl+
dart_library_dart_library
4A
S�
(//dart/private:dart_package_metadata.bzlr�
5

rules_dartdart/privatedart_package_metadata.bzl=
dart_package_metadata_dart_package_metadata
 = S
  n�
"//dart/private:dart_sqlcodegen.bzlrr
/

rules_dartdart/privatedart_sqlcodegen.bzl1
dart_sqlcodegen_dart_sqlcodegen
!7!G
!!\�
//dart/private:dart_test.bzlr`
)

rules_dartdart/privatedart_test.bzl%
	dart_test
_dart_test
"1";
""J�
'//dart/private:dart_web_application.bzlr�
4

rules_dartdart/privatedart_web_application.bzl/
dart_js_binary_dart_js_binary
#<#K3
dart_wasm_binary_dart_wasm_binary
#`#q
##��
//dart/private:source_set.bzlrm
*

rules_dartdart/privatesource_set.bzl1
dart_source_set_dart_source_set
$2$B
$$W�Rules for building, testing, and analyzing Dart code.

Load this file from your BUILD files to access the following rules:

- `dart_library`: Collects Dart sources and propagates dependency information. Does not compile.
- `dart_package_metadata`: Declares a Dart package's name and language version once, for every rule that builds part of it.
- `dart_source_set`: Assembles Dart sources (hand-written + generated) into one directory.
- `dart_binary`: Compiles a Dart application (`exe`, `aot-snapshot`, `kernel`, or `jit-snapshot`).
- `dart_test`: Runs a Dart test file using the Dart VM.
- `dart_analyze_test`: Runs `dart analyze` on a library as a build-time action.
- `dart_analysis_options`: An `analysis_options.yaml` plus the packages its `include:` directives resolve against.
- `dart_fix`: Applies `dart fix` to a library's sources via `bazel run`.
- `dart_format_test`: Checks that sources match `dart format` output.
- `dart_js_binary`: Compiles a Dart web application to JavaScript.
- `dart_wasm_binary`: Compiles a Dart web application to WebAssembly.
- `dart_codegen`: Runs a Dart code generator on source files, producing generated .dart outputs.
- `dart_aggregate_codegen`: Runs a package-level aggregate code generator over all sources.
- `dart_sqlcodegen`: Like `dart_codegen` but accepts non-Dart inputs (e.g. `.drift` files).
- `dart_code_asset`: Binds a Bazel-built native dynamic library to a Dart code-asset id, for use in `dart_test`/`dart_binary` `code_assets`.
�
"

rules_dartdartextensions.bzl�dartgInstalls a Dart SDK toolchain. Multiple modules may request different versions; the latest is selected.J�
�
dartgInstalls a Dart SDK toolchain. Multiple modules may request different versions; the latest is selected.�
	toolchain�
name�Base name for generated repositories, allowing more than one Dart toolchain to be registered.
Overriding the default is only permitted in the root module.
2"dart"5
dart_version!Explicit version of the Dart SDK. ")
dart!@@rules_dart//dart:extensions.bzl
==�
�
	toolchain�
name�Base name for generated repositories, allowing more than one Dart toolchain to be registered.
Overriding the default is only permitted in the root module.
2"dart"5
dart_version!Explicit version of the Dart SDK. �
�
name�Base name for generated repositories, allowing more than one Dart toolchain to be registered.
Overriding the default is only permitted in the root module.
2"dart"7
5
dart_version!Explicit version of the Dart SDK. �
//dart:repositories.bzlrx
$

rules_dartdartrepositories.bzlB
dart_register_toolchainsdart_register_toolchains
-E
G�Extensions for bzlmod.

Installs a Dart toolchain.
Every module can define a toolchain version under the default name, "dart".
The latest of those versions will be selected (the rest discarded),
and will always be registered by rules_dart.

Additionally, the root module can define arbitrarily many more toolchain versions under different
names (the latest version will be picked for each name) and can register them as it sees fit,
effectively overriding the default named toolchain due to toolchain resolution precedence.
՘
!

rules_dartdartproviders.bzl�DartAnalysisOptionsInfo�An `analysis_options.yaml` together with the packages its `include:` directives resolve against.

A shared lint ruleset is published as a pub package and pulled in by `package:` URI, which the analyzer resolves through the staged project's `package_config.json`. So an options file can carry package dependencies, and the only alternative â adding the ruleset to the analyzed library's own `deps` â leaks a lint-only package into that library's `DartInfo`, and from there into every binary and test downstream of it.

Produced by `dart_analysis_options` and consumed by `dart_analyze_test`'s `options` attribute, which stages these packages for options resolution alone: they are resolvable from the project, never themselves analyzed, and never merged into the analyzed target's provider.2�
�	
DartAnalysisOptionsInfo�An `analysis_options.yaml` together with the packages its `include:` directives resolve against.

A shared lint ruleset is published as a pub package and pulled in by `package:` URI, which the analyzer resolves through the staged project's `package_config.json`. So an options file can carry package dependencies, and the only alternative â adding the ruleset to the analyzed library's own `deps` â leaks a lint-only package into that library's `DartInfo`, and from there into every binary and test downstream of it.

Produced by `dart_analysis_options` and consumed by `dart_analyze_test`'s `options` attribute, which stages these packages for options resolution alone: they are resolvable from the project, never themselves analyzed, and never merged into the analyzed target's provider.*
file"File: The `analysis_options.yaml`.`
packagesTlist[DartPackageInfo]: Package records for every package the includes may reference.@
transitive_srcs-depset[File]: Dart sources of those packages.�
transitive_resourcesmdepset[File]: Non-Dart `lib/` files of those packages â where a published ruleset's yaml actually lives.";
DartAnalysisOptionsInfo @@rules_dart//dart:providers.bzl
�#�#,
*
file"File: The `analysis_options.yaml`.b
`
packagesTlist[DartPackageInfo]: Package records for every package the includes may reference.B
@
transitive_srcs-depset[File]: Dart sources of those packages.�
�
transitive_resourcesmdepset[File]: Non-Dart `lib/` files of those packages â where a published ruleset's yaml actually lives.�"DartAnalyzableInfo�An executable target's analyzable closure: everything `dart_analyze_test` / `dart_fix` need to stage a project around its entrypoint.

Provided by executable rules â `dart_binary`, `dart_test`, `dart_js_binary`, `dart_wasm_binary` here, and downstream by rules whose target is an executable that *also* contributes a package (a `flutter_test` whose `srcs` are its own package's `lib/` files). A library needs nothing extra: for it `DartInfo` *is* the analyzable closure, and `dart_analyze_test`/`dart_fix` accept either provider, which is what keeps `flutter_library` and `dart_proto_library` analyzable without adopting anything.

The separation is what makes an entrypoint analyzable without making it a valid dependency. Every `deps` attribute in this rule set and downstream ones gates on `providers = [DartInfo]`, so an executable returning `DartInfo` would make `dart_library(deps = [":some_binary"])` legal â and Bazel has no way to express "provides it but is not a dep", `attr.label(providers = ...)` being require-only. A distinct outer provider that *nests* the `DartInfo` says the same thing structurally: consumable by whoever asks for it, invisible to whoever asks for `DartInfo`.

Build one with either constructor in `//dart:utils.bzl`, never by hand. `dart_analyzable_info()` builds the nested `DartInfo` through `dart_info_no_package()`, for an entrypoint that contributes no package â under pub it belongs to the root package but sits outside its `lib/`. `dart_analyzable_info_with_package()` builds it through `dart_info()`, for a target whose sources *are* a package: without that record its own `package:<self>/â¦` imports resolve against nothing and every one of them reports `uri_does_not_exist`.2�
�
DartAnalyzableInfo�An executable target's analyzable closure: everything `dart_analyze_test` / `dart_fix` need to stage a project around its entrypoint.

Provided by executable rules â `dart_binary`, `dart_test`, `dart_js_binary`, `dart_wasm_binary` here, and downstream by rules whose target is an executable that *also* contributes a package (a `flutter_test` whose `srcs` are its own package's `lib/` files). A library needs nothing extra: for it `DartInfo` *is* the analyzable closure, and `dart_analyze_test`/`dart_fix` accept either provider, which is what keeps `flutter_library` and `dart_proto_library` analyzable without adopting anything.

The separation is what makes an entrypoint analyzable without making it a valid dependency. Every `deps` attribute in this rule set and downstream ones gates on `providers = [DartInfo]`, so an executable returning `DartInfo` would make `dart_library(deps = [":some_binary"])` legal â and Bazel has no way to express "provides it but is not a dep", `attr.label(providers = ...)` being require-only. A distinct outer provider that *nests* the `DartInfo` says the same thing structurally: consumable by whoever asks for it, invisible to whoever asks for `DartInfo`.

Build one with either constructor in `//dart:utils.bzl`, never by hand. `dart_analyzable_info()` builds the nested `DartInfo` through `dart_info_no_package()`, for an entrypoint that contributes no package â under pub it belongs to the root package but sits outside its `lib/`. `dart_analyzable_info_with_package()` builds it through `dart_info()`, for a target whose sources *are* a package: without that record its own `package:<self>/â¦` imports resolve against nothing and every one of them reports `uri_does_not_exist`.�
	dart_info�DartInfo: the dependency closure, as the `dart_analyzable_info*()` constructors build it â package-less, or carrying this target's own package record.�
srcs�depset[File]: the target's own sources that belong to no package's `lib/` â its `main`, a `test/` entrypoint â and which therefore no `DartPackageInfo` can name. Sources that *are* a package's `lib/` files ride the nested `DartInfo` instead."6
DartAnalyzableInfo @@rules_dart//dart:providers.bzl
OO�
�
	dart_info�DartInfo: the dependency closure, as the `dart_analyzable_info*()` constructors build it â package-less, or carrying this target's own package record.�
�
srcs�depset[File]: the target's own sources that belong to no package's `lib/` â its `main`, a `test/` entrypoint â and which therefore no `DartPackageInfo` can name. Sources that *are* a package's `lib/` files ride the nested `DartInfo` instead.�DartCodeAssetInfo�A native code asset (a Bazel-built dynamic library) bound to the Dart `@Native`/`@DefaultAsset` asset id the owning package uses.

Produced by the `dart_code_asset` rule and consumed via the `code_assets` attribute of `dart_test` / `dart_binary`, which embed the mapping into the compiled kernel (`gen_kernel --native-assets`) so the Dart VM resolves the package's `@Native` symbols against the Bazel-built library at runtime.2�
�	
DartCodeAssetInfo�A native code asset (a Bazel-built dynamic library) bound to the Dart `@Native`/`@DefaultAsset` asset id the owning package uses.

Produced by the `dart_code_asset` rule and consumed via the `code_assets` attribute of `dart_test` / `dart_binary`, which embed the mapping into the compiled kernel (`gen_kernel --native-assets`) so the Dart VM resolves the package's `@Native` symbols against the Bazel-built library at runtime.�
asset_id�str: The code-asset id the owning package declares (its `@ffi.DefaultAsset` / `@Native(assetId:)`), e.g. `package:sqlite3/src/ffi/libsqlite3.g.dart`.�
	link_mode�str: How the runtime loads the asset. One of `dynamic_loading_bundle`, `dynamic_loading_system`, `dynamic_loading_executable`, `dynamic_loading_process` â the upstream `code_assets` strings, verbatim.�
dynamic_library�File or None: The dynamic library (`.so`/`.dylib`/`.dll`) the asset resolves to. Set only for `dynamic_loading_bundle`; `None` otherwise.t

system_urifstr: System library URI (e.g. `libsqlite3.so.0`) for `dynamic_loading_system`. Empty string otherwise."5
DartCodeAssetInfo @@rules_dart//dart:providers.bzl
���
�
asset_id�str: The code-asset id the owning package declares (its `@ffi.DefaultAsset` / `@Native(assetId:)`), e.g. `package:sqlite3/src/ffi/libsqlite3.g.dart`.�
�
	link_mode�str: How the runtime loads the asset. One of `dynamic_loading_bundle`, `dynamic_loading_system`, `dynamic_loading_executable`, `dynamic_loading_process` â the upstream `code_assets` strings, verbatim.�
�
dynamic_library�File or None: The dynamic library (`.so`/`.dylib`/`.dll`) the asset resolves to. Set only for `dynamic_loading_bundle`; `None` otherwise.v
t

system_urifstr: System library URI (e.g. `libsqlite3.so.0`) for `dynamic_loading_system`. Empty string otherwise.�DartCompileInfo)Information about a compiled Dart output.2�
�
DartCompileInfo)Information about a compiled Dart output.-

executableFile: The compiled output file.d
compile_modeTstr: The compilation mode used (`exe`, `aot-snapshot`, `kernel`, or `jit-snapshot`)."3
DartCompileInfo @@rules_dart//dart:providers.bzl
yy/
-

executableFile: The compiled output file.f
d
compile_modeTstr: The compilation mode used (`exe`, `aot-snapshot`, `kernel`, or `jit-snapshot`).�DartInfo�Information about a Dart library's sources and transitive dependencies.

Read this directly off any target that provides it. To *build* one, call `dart_info()` from `//dart:utils.bzl` rather than this constructor â or `dart_info_no_package()` when the target ships no Dart package and provides `DartInfo` only to satisfy a `deps` attribute requiring one. Either takes what a target contributes itself and merges every dependency's closure internally, so a field added here needs no change in the rule sets that produce `DartInfo` â rules_flutter and rules_dart_proto both do. Constructing it here means enumerating and merging each field by hand, and a field left empty rather than forwarded silently discards every dependency's values.2�
�
DartInfo�Information about a Dart library's sources and transitive dependencies.

Read this directly off any target that provides it. To *build* one, call `dart_info()` from `//dart:utils.bzl` rather than this constructor â or `dart_info_no_package()` when the target ships no Dart package and provides `DartInfo` only to satisfy a `deps` attribute requiring one. Either takes what a target contributes itself and merges every dependency's closure internally, so a field added here needs no change in the rule sets that produce `DartInfo` â rules_flutter and rules_dart_proto both do. Constructing it here means enumerating and merging each field by hand, and a field left empty rather than forwarded silently discards every dependency's values.<
package_name,str: The Dart package name for this library.�
lib_root�str: The short_path-based path to the package root directory (parent of `lib/`). Configuration-independent; consumers derive exec-root paths from source File objects.h
transitive_srcsUdepset[File]: All transitive Dart source files, including this library's own sources.�
transitive_resources�depset[File]: Non-Dart files shipped inside `lib/` (see `dart_library`'s `resources`) by this library and all transitive deps. Carried beside `transitive_srcs` rather than within it because the two are routed differently: everything that stages a whole package wants both, and nothing that feeds the compiler wants these.i
transitive_packagesRdepset[DartPackageInfo]: Package records for this library and all transitive deps.�
transitive_code_asset_files�depset[File]: The dynamic libraries of every transitive code asset. Carried separately from `transitive_packages` because a depset of providers cannot be turned back into files for runfiles.",
DartInfo @@rules_dart//dart:providers.bzl
>
<
package_name,str: The Dart package name for this library.�
�
lib_root�str: The short_path-based path to the package root directory (parent of `lib/`). Configuration-independent; consumers derive exec-root paths from source File objects.j
h
transitive_srcsUdepset[File]: All transitive Dart source files, including this library's own sources.�
�
transitive_resources�depset[File]: Non-Dart files shipped inside `lib/` (see `dart_library`'s `resources`) by this library and all transitive deps. Carried beside `transitive_srcs` rather than within it because the two are routed differently: everything that stages a whole package wants both, and nothing that feeds the compiler wants these.k
i
transitive_packagesRdepset[DartPackageInfo]: Package records for this library and all transitive deps.�
�
transitive_code_asset_files�depset[File]: The dynamic libraries of every transitive code asset. Carried separately from `transitive_packages` because a depset of providers cannot be turned back into files for runfiles.�DartPackageConfigInfoUA generated `package_config.json` file that maps `package:` URIs to source locations.2�
�
DartPackageConfigInfoUA generated `package_config.json` file that maps `package:` URIs to source locations.0
file(File: The generated package_config.json."9
DartPackageConfigInfo @@rules_dart//dart:providers.bzl
r!r!2
0
file(File: The generated package_config.json.�DartPackageInfoWRecord of a single Dart package in the build graph, carried in depsets within DartInfo.2�
�

DartPackageInfoWRecord of a single Dart package in the build graph, carried in depsets within DartInfo.5
package_name%str: The Dart package name. Required.�
lib_root�str: The short_path-based path to the package root directory (parent of `lib/`). Configuration-independent. Required; empty string for the root package.�
version�str: The package's own version, as resolved by pub (e.g. `2.2.0`). Optional; empty string when unknown, which is what a `dart_library` written by hand and a producer predating this field both carry. Recorded so that two records for one package name can be checked for agreement â see `package_agreement_error`.�
language_version�str: Dart language version implied by the package's `environment.sdk` constraint, in `<major>.<minor>` form. Optional; empty string when unknown.�
code_assets�tuple[DartCodeAssetInfo]: Native code assets this package owns. A tuple rather than a list because `DartPackageInfo` is carried in a depset, whose elements must be hashable.�
has_unreplaced_hook�str: Path of a `hook/build.dart`/`hook/link.dart` this package ships that has no Bazel replacement (empty when none). Recorded at repo generation; acted on by `dart_binary`/`dart_test`."3
DartPackageInfo @@rules_dart//dart:providers.bzl
CC7
5
package_name%str: The Dart package name. Required.�
�
lib_root�str: The short_path-based path to the package root directory (parent of `lib/`). Configuration-independent. Required; empty string for the root package.�
�
version�str: The package's own version, as resolved by pub (e.g. `2.2.0`). Optional; empty string when unknown, which is what a `dart_library` written by hand and a producer predating this field both carry. Recorded so that two records for one package name can be checked for agreement â see `package_agreement_error`.�
�
language_version�str: Dart language version implied by the package's `environment.sdk` constraint, in `<major>.<minor>` form. Optional; empty string when unknown.�
�
code_assets�tuple[DartCodeAssetInfo]: Native code assets this package owns. A tuple rather than a list because `DartPackageInfo` is carried in a depset, whose elements must be hashable.�
�
has_unreplaced_hook�str: Path of a `hook/build.dart`/`hook/link.dart` this package ships that has no Bazel replacement (empty when none). Recorded at repo generation; acted on by `dart_binary`/`dart_test`.�DartPackageMetadataInfo�	The two facts a Dart package states about itself: its name and the language version its sources are written against.

Distinct from `DartPackageInfo`, which is a *record of a package in the build graph* â where its sources live, what version pub resolved, what native assets it owns â accumulated by `dart_info()` and carried in depsets. This is the *declaration* a `dart_package_metadata` target makes, read back through an attribute by the rules that would otherwise each ask for the same two strings.

It exists because those two facts are properties of a package, not of a rule, and a package is routinely built by more than one rule: a `dart_codegen` generating part of it and the `dart_library` collecting the result must agree on both, and `sibling_aggregate_pkg` shows the two living in different BUILD files, where no macro can hold them together. A referenceable declaration can.

Deliberately a leaf: it carries no `DartInfo`, so a `dart_package_metadata` cannot be mistaken for a dependency. `attr.label(providers = ...)` is require-only, and a target providing `DartInfo` would make `dart_library(deps = [":pkg"])` legal with nothing to say about it â the same trap `DartAnalyzableInfo` exists to avoid.2�
�
DartPackageMetadataInfo�	The two facts a Dart package states about itself: its name and the language version its sources are written against.

Distinct from `DartPackageInfo`, which is a *record of a package in the build graph* â where its sources live, what version pub resolved, what native assets it owns â accumulated by `dart_info()` and carried in depsets. This is the *declaration* a `dart_package_metadata` target makes, read back through an attribute by the rules that would otherwise each ask for the same two strings.

It exists because those two facts are properties of a package, not of a rule, and a package is routinely built by more than one rule: a `dart_codegen` generating part of it and the `dart_library` collecting the result must agree on both, and `sibling_aggregate_pkg` shows the two living in different BUILD files, where no macro can hold them together. A referenceable declaration can.

Deliberately a leaf: it carries no `DartInfo`, so a `dart_package_metadata` cannot be mistaken for a dependency. `attr.label(providers = ...)` is require-only, and a target providing `DartInfo` would make `dart_library(deps = [":pkg"])` legal with nothing to say about it â the same trap `DartAnalyzableInfo` exists to avoid.P
package_name@str: The Dart package name used in `package:` imports. Required.�
language_version�str: Dart language version implied by the package's `environment.sdk` constraint, in `<major>.<minor>` form. Empty when the package states none.";
DartPackageMetadataInfo @@rules_dart//dart:providers.bzl
(#(#R
P
package_name@str: The Dart package name used in `package:` imports. Required.�
�
language_version�str: Dart language version implied by the package's `environment.sdk` constraint, in `<major>.<minor>` form. Empty when the package states none.Providers for Dart rules.�
$

rules_dartdartrepositories.bzl�dart_register_toolchains�Convenience macro for setting up Dart SDK repositories.

- create a repository for each built-in platform like "dart_linux_x64"
- create a repository exposing toolchains for each platform like "dart_toolchains"
Users can avoid this macro and do these steps themselves, if they want more control.
*�
�
dart_register_toolchains8
name,base name for all created repos, like "dart" (1
kwargs%passed to each dart_repositories call(�Convenience macro for setting up Dart SDK repositories.

- create a repository for each built-in platform like "dart_linux_x64"
- create a repository exposing toolchains for each platform like "dart_toolchains"
Users can avoid this macro and do these steps themselves, if they want more control.
2?
dart_register_toolchains#@@rules_dart//dart:repositories.bzl
ff*dart_repositories2dart_repositories2toolchains_repo�dart_repositories3Fetch the Dart SDK for a given version and platformR�
�
dart_repositories3Fetch the Dart SDK for a given version and platform.
name"A unique name for this repository. q
dart_version]The Dart SDK version to download (e.g. `3.11.0`). Must be a version listed in `versions.bzl`. �
platform�The host platform whose SDK this repository downloads (e.g. `macos-arm64`, `linux-x64`). Must match a key in `PLATFORMS` â cross-only targets have no SDK of their own, so they are not valid here. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 *8
dart_repositories#@@rules_dart//dart:repositories.bzl
`$`$0
.
name"A unique name for this repository. s
q
dart_version]The Dart SDK version to download (e.g. `3.11.0`). Must be a version listed in `versions.bzl`. �
�
platform�The host platform whose SDK this repository downloads (e.g. `macos-arm64`, `linux-x64`). Must match a key in `PLATFORMS` â cross-only targets have no SDK of their own, so they are not valid here. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
"//dart/private:toolchains_repo.bzlr�
/

rules_dartdart/privatetoolchains_repo.bzl,
CROSS_TARGETSCROSS_TARGETS
8E$
	PLATFORMS	PLATFORMS
IR2
TARGET_PLATFORMSTARGET_PLATFORMS
Vf0
toolchains_repotoolchains_repo
jy
{�
//dart/private:versions.bzlrf
(

rules_dartdart/privateversions.bzl,
TOOL_VERSIONSTOOL_VERSIONS
1>
@�Declare runtime dependencies

These are needed for local dev, and users must install them as well.
See https://docs.bazel.build/versions/main/skylark/deploying.html#dependencies
�
!

rules_dartdarttoolchain.bzl�
dart_toolchain]Defines a Dart SDK toolchain. Typically generated by the `dart_repositories` repository rule."�	
�
dart_toolchain]Defines a Dart SDK toolchain. Typically generated by the `dart_repositories` repository rule.*
nameA unique name for this target. B
dart6The `dart` executable from the SDK's `bin/` directory. g
sdk_rootWA filegroup containing all SDK files. Used as action inputs when invoking the compiler. p
target_arch[Cross-compilation target architecture (`x64`, `arm64`). Leave empty for native compilation.2""q
	target_os^Cross-compilation target OS (`macos`, `linux`, `windows`). Leave empty for native compilation.2""6
version'The SDK version string (e.g. `3.11.0`). "2
dart_toolchain @@rules_dart//dart:toolchain.bzl
//,
*
nameA unique name for this target. D
B
dart6The `dart` executable from the SDK's `bin/` directory. i
g
sdk_rootWA filegroup containing all SDK files. Used as action inputs when invoking the compiler. r
p
target_arch[Cross-compilation target architecture (`x64`, `arm64`). Leave empty for native compilation.2""s
q
	target_os^Cross-compilation target OS (`macos`, `linux`, `windows`). Leave empty for native compilation.2""8
6
version'The SDK version string (e.g. `3.11.0`). �
DartSdkInfo9Information about the Dart SDK provided by the toolchain.2�	
�
DartSdkInfo9Information about the Dart SDK provided by the toolchain.$
dartFile: The `dart` executable.P
sdk_rootDTarget: The root directory of the SDK, containing `lib/` and `bin/`.7
version,str: The SDK version string (e.g. `3.11.0`).�

tool_files�depset[File]: All files needed to run the SDK. Pass as a `transitive` entry to action inputs / `ctx.runfiles(transitive_files = ...)`; flatten only to inspect paths.a
	target_osTstr: Cross-compilation target OS (`macos`, `linux`, `windows`), or empty for native.`
target_archQstr: Cross-compilation target architecture (`x64`, `arm64`), or empty for native."/
DartSdkInfo @@rules_dart//dart:toolchain.bzl
&
$
dartFile: The `dart` executable.R
P
sdk_rootDTarget: The root directory of the SDK, containing `lib/` and `bin/`.9
7
version,str: The SDK version string (e.g. `3.11.0`).�
�

tool_files�depset[File]: All files needed to run the SDK. Pass as a `transitive` entry to action inputs / `ctx.runfiles(transitive_files = ...)`; flatten only to inspect paths.c
a
	target_osTstr: Cross-compilation target OS (`macos`, `linux`, `windows`), or empty for native.b
`
target_archQstr: Cross-compilation target architecture (`x64`, `arm64`), or empty for native.3This module implements the Dart SDK toolchain rule.��


rules_dartdart	utils.bzl�collect_packages�Collect unique DartPackageInfo providers from transitive deps.

Flattens the merged transitive depset exactly once (package metadata is
inspected per-entry for dedup, so a flatten is unavoidable here — but it
is bounded by the package count, not the source-file count).
*�
�
collect_packages/
deps#List of targets providing DartInfo. (�Collect unique DartPackageInfo providers from transitive deps.

Flattens the merged transitive depset exactly once (package metadata is
inspected per-entry for dedup, so a flatten is unavoidable here — but it
is bounded by the package count, not the source-file count).
"?
=List of unique DartPackageInfo providers in dependency order.29
collect_packages%@@rules_dart//dart/private:common.bzl
���collect_transitive_resources�Collect all transitive `resources` files from DartInfo deps.

The sibling of `collect_transitive_srcs`, for the non-Dart files a package
ships inside `lib/`. Kept a separate call rather than folded into that one
so every consumer has to say which of the two it means: staging a package
whole wants both, feeding the compiler wants only the sources.
*�
�
collect_transitive_resources/
deps#List of targets providing DartInfo. (�Collect all transitive `resources` files from DartInfo deps.

The sibling of `collect_transitive_srcs`, for the non-Dart files a package
ships inside `lib/`. Kept a separate call rather than folded into that one
so every consumer has to say which of the two it means: staging a package
whole wants both, feeding the compiler wants only the sources.
"7
5Depset of Files from the transitive resource closure.2E
collect_transitive_resources%@@rules_dart//dart/private:common.bzl
���collect_transitive_srcs�Collect all transitive source files from DartInfo deps.

Returns a depset so consumers can feed action inputs / runfiles without
flattening. Callers that genuinely inspect per-file paths (package
colocation, package_config root resolution) call `.to_list()` exactly
once at that point.
*�
�
collect_transitive_srcs/
deps#List of targets providing DartInfo. (�Collect all transitive source files from DartInfo deps.

Returns a depset so consumers can feed action inputs / runfiles without
flattening. Callers that genuinely inspect per-file paths (package
colocation, package_config root resolution) call `.to_list()` exactly
once at that point.
"5
3Depset of Files from the transitive source closure.2@
collect_transitive_srcs%@@rules_dart//dart/private:common.bzl
���colocate_entrypoint�Co-locates an entrypoint `main` with its own generated sibling sources.

A `dart_binary`/`dart_test` whose own `srcs` include a generated file that is
a `part`/relative-import sibling of `main` (e.g. a mockito `.mocks.dart`
generated for the test file itself) needs `main` and those files in one real
directory. When that's the case, assemble them and compile `main` from inside
the assembled directory.
*�
�
colocate_entrypointH
ctx=The rule context (must carry `COPY_TO_DIRECTORY_TOOLCHAINS`). ((
mainThe entrypoint `.dart` File. (D
own_srcs4The rule's own `srcs` Files (not those from `deps`). (�Co-locates an entrypoint `main` with its own generated sibling sources.

A `dart_binary`/`dart_test` whose own `srcs` include a generated file that is
a `part`/relative-import sibling of `main` (e.g. a mockito `.mocks.dart`
generated for the test file itself) needs `main` and those files in one real
directory. When that's the case, assemble them and compile `main` from inside
the assembled directory.
"�
�`(main_input, main_arg, extra_inputs)` — `main_input` is the File to add to
action inputs (the assembled directory when assembled, else `main`);
`main_arg` is the path string to pass as the compile target; `extra_inputs`
are `own_srcs` to add as inputs when not assembled (empty when assembled).2@
colocate_entrypoint)@@rules_dart//dart/private:source_set.bzl
���colocate_packages�Co-locates each package's split source/generated files into one directory.

Groups `all_srcs` by the package whose `lib/` they belong to (longest
`lib_root` match — see `package_for`).
Any package with at least one generated file (and not already a single
pre-assembled directory) is assembled into one tree-artifact directory, so it
has a single real `rootUri` at compile time. This is what makes a package
whose files are split across the source tree and `bazel-out` (codegen) and/or
across several `dart_library` targets resolve — the consumer is the only place
that sees the package's complete file set.
*�
�
colocate_packagesH
ctx=The rule context (must carry `COPY_TO_DIRECTORY_TOOLCHAINS`). (D
packages4List of `DartPackageInfo` (from `collect_packages`). (5
all_srcs%Flat list of transitive source Files. (�Co-locates each package's split source/generated files into one directory.

Groups `all_srcs` by the package whose `lib/` they belong to (longest
`lib_root` match — see `package_for`).
Any package with at least one generated file (and not already a single
pre-assembled directory) is assembled into one tree-artifact directory, so it
has a single real `rootUri` at compile time. This is what makes a package
whose files are split across the source tree and `bazel-out` (codegen) and/or
across several `dart_library` targets resolve — the consumer is the only place
that sees the package's complete file set.
"�
�`(packages2, srcs2)` — packages with each assembled package's `lib_root`
rewritten to its assembled directory, and the matching File list (assembled
directories plus untouched files) to feed the compile action.2>
colocate_packages)@@rules_dart//dart/private:source_set.bzl
xx�dart_analyzable_info�Builds a `DartAnalyzableInfo` for an executable target.

The third constructor, and the one place `DartAnalyzableInfo` is built. It
adds no depset of its own beyond `srcs`: the closure is the `DartInfo` that
`dart_info_no_package()` already knows how to merge, carried whole rather
than re-enumerated field by field — which is the mistake this file exists to
prevent, and which a provider with its own `transitive_*` fields would
reintroduce one merge at a time.

`srcs` is the one thing that `DartInfo` genuinely cannot carry. An
entrypoint contributes no package (under pub it belongs to the root package
but lives outside its `lib/`), so no `DartPackageInfo` can name it and no
`package:` URI reaches it — but the analyzer still has to see it.
*�	
�	
dart_analyzable_infoQ
depsCTargets providing `DartInfo` whose closures the entrypoint reaches.[](�
srcs�The target's own entrypoint sources (its `main` and `srcs`). Pass
the rule's own `File`s, before any colocation copy: consumers stage by
`short_path`, and a colocated copy's is the assembled directory's.[](�Builds a `DartAnalyzableInfo` for an executable target.

The third constructor, and the one place `DartAnalyzableInfo` is built. It
adds no depset of its own beyond `srcs`: the closure is the `DartInfo` that
`dart_info_no_package()` already knows how to merge, carried whole rather
than re-enumerated field by field — which is the mistake this file exists to
prevent, and which a provider with its own `transitive_*` fields would
reintroduce one merge at a time.

`srcs` is the one thing that `DartInfo` genuinely cannot carry. An
entrypoint contributes no package (under pub it belongs to the root package
but lives outside its `lib/`), so no `DartPackageInfo` can name it and no
`package:` URI reaches it — but the analyzer still has to see it.
"
A `DartAnalyzableInfo`.2@
dart_analyzable_info(@@rules_dart//dart/private:dart_info.bzl
���&!dart_analyzable_info_with_package�Builds a `DartAnalyzableInfo` for an executable that contributes a package.

The sibling of `dart_analyzable_info()`, for the one case its narrow
signature cannot state: a target that is an executable *and* owns a package.
A downstream `flutter_test` is the shape — it names a `package_name` and its
sources are that package's `lib/` files, which import each other by
`package:` URI. Built through `dart_analyzable_info()`, those imports have no
package record to resolve against and every one of them reports
`uri_does_not_exist`; the analyzer is right, because nothing in a
package-less closure names the package they ask for.

So this nests a `dart_info()` where the other nests a
`dart_info_no_package()`, and that is the whole difference. Neither
enumerates a `DartInfo` field, which is what keeps a rule in this position
from writing `DartAnalyzableInfo(dart_info = dart_info(...))` by hand — a
second construction site for the outer provider, and precisely what this
file exists to prevent.

The two source lists are not interchangeable, and swapping them fails
silently rather than loudly: staging places both by `short_path`, so
analysis resolves either way, and a `lib/` file routed through `srcs` is
merely invisible to every `DartInfo` consumer downstream. Split them by
`package:` reachability — a file under `lib_root`'s `lib/`, reachable as
`package:<package_name>/…`, belongs in `package_srcs`; a file outside it (a
`test/` entrypoint, a `bin/` main) belongs in `srcs`, which no
`DartPackageInfo` can name.
*�
�
!dart_analyzable_info_with_package?
label2The constructing rule's label, for error messages. (�
package_name�The Dart package name this target provides. Required: an
executable contributing no package is what `dart_analyzable_info()` is
for. (r
lib_rootb`short_path`-based path to the package root (parent of `lib/`).
Empty string for the root package. (�
language_version�Dart language version in `<major>.<minor>` form, or ""
when the package states none. Required to pass — not because a package
must have one, but because omitting the argument and stating `""` are
different intentions that used to produce the same call. An absent
`languageVersion` in `package_config.json` is not "no language version",
it is *the current SDK's*, so a forgotten argument silently compiles the
package under newer semantics than its pubspec allows. `""` remains a
legal, meaningful value; only not answering is gone. (H
deps:Targets providing `DartInfo` whose closures are merged in.[](�
srcs�The target's own sources belonging to no package's `lib/` — its
entrypoint. Pass the rule's own `File`s, before any colocation copy:
consumers stage by `short_path`, and a colocated copy's is the assembled
directory's.[](�
package_srcsjThe target's own sources that *are* the package's `lib/`
files, reachable as `package:<package_name>/…`.[](A
	resources.This target's own non-Dart files under `lib/`.[](R
code_assets=Targets providing `DartCodeAssetInfo` that this package owns.[](H
version7The package's own resolved version, or "" when unknown.""(�Builds a `DartAnalyzableInfo` for an executable that contributes a package.

The sibling of `dart_analyzable_info()`, for the one case its narrow
signature cannot state: a target that is an executable *and* owns a package.
A downstream `flutter_test` is the shape — it names a `package_name` and its
sources are that package's `lib/` files, which import each other by
`package:` URI. Built through `dart_analyzable_info()`, those imports have no
package record to resolve against and every one of them reports
`uri_does_not_exist`; the analyzer is right, because nothing in a
package-less closure names the package they ask for.

So this nests a `dart_info()` where the other nests a
`dart_info_no_package()`, and that is the whole difference. Neither
enumerates a `DartInfo` field, which is what keeps a rule in this position
from writing `DartAnalyzableInfo(dart_info = dart_info(...))` by hand — a
second construction site for the outer provider, and precisely what this
file exists to prevent.

The two source lists are not interchangeable, and swapping them fails
silently rather than loudly: staging places both by `short_path`, so
analysis resolves either way, and a `lib/` file routed through `srcs` is
merely invisible to every `DartInfo` consumer downstream. Split them by
`package:` reachability — a file under `lib_root`'s `lib/`, reachable as
`package:<package_name>/…`, belongs in `package_srcs`; a file outside it (a
`test/` entrypoint, a `bin/` main) belongs in `srcs`, which no
`DartPackageInfo` can name.
"F
DA `DartAnalyzableInfo` whose nested `DartInfo` records this package.2M
!dart_analyzable_info_with_package(@@rules_dart//dart/private:dart_info.bzl
���	dart_info�Builds a `DartInfo` for a library, merging its dependencies' closures.

The caller supplies only what this target contributes itself; everything
transitive is merged here. Adding a field to `DartInfo` is therefore a
change to this file and nothing else.

Attribute hygiene stays with the calling rule — whether `srcs` and
`srcs_dir` are mutually exclusive, whether a file sits under the package's
`lib/` — because those are statements about that rule's attributes, and a
rule generating its package as one tree artifact has no such files to check.
What belongs here is what is true of any `DartInfo`: the merges, the package
record, and code-asset ownership.
*�
�
	dart_info?
label2The constructing rule's label, for error messages. (?
package_name+The Dart package name this target provides. (r
lib_rootb`short_path`-based path to the package root (parent of `lib/`).
Empty string for the root package. (�
language_version�Dart language version in `<major>.<minor>` form, or ""
when the package states none. Required to pass — not because a package
must have one, but because omitting the argument and stating `""` are
different intentions that used to produce the same call. An absent
`languageVersion` in `package_config.json` is not "no language version",
it is *the current SDK's*, so a forgotten argument silently compiles the
package under newer semantics than its pubspec allows. `""` remains a
legal, meaningful value; only not answering is gone. (H
deps:Targets providing `DartInfo` whose closures are merged in.[](G
srcs9This target's own Dart sources (or its source directory).[](A
	resources.This target's own non-Dart files under `lib/`.[](R
code_assets=Targets providing `DartCodeAssetInfo` that this package owns.[](W
has_unreplaced_hook:Path of a pub build hook with no Bazel replacement,
or "".""(�
versionThe package's own resolved version, or "" when unknown. Only pub
spokes know it; a hand-written `dart_library` leaves it empty.""(�Builds a `DartInfo` for a library, merging its dependencies' closures.

The caller supplies only what this target contributes itself; everything
transitive is merged here. Adding a field to `DartInfo` is therefore a
change to this file and nothing else.

Attribute hygiene stays with the calling rule — whether `srcs` and
`srcs_dir` are mutually exclusive, whether a file sits under the package's
`lib/` — because those are statements about that rule's attributes, and a
rule generating its package as one tree artifact has no such files to check.
What belongs here is what is true of any `DartInfo`: the merges, the package
record, and code-asset ownership.
"
A `DartInfo`.25
	dart_info(@@rules_dart//dart/private:dart_info.bzl
���dart_info_no_package�Builds a `DartInfo` for a target that contributes no Dart package.

For a target that has to be listed in a `deps` attribute requiring
`DartInfo` but ships no Dart: `flutter_material_icons` provides a font, and
wants the provider present, not contributing. It records no
`DartPackageInfo`, so nothing it is listed on gains a `package_config.json`
entry or a source to compile.

There is deliberately no `package_name`, `lib_root`, `srcs`, `resources` or
`code_assets` here. `DartInfo.package_name` and `.lib_root` describe the
package a target contributes, and no consumer reads them off the provider —
package identity is read from `transitive_packages` — so a no-package target
reports the empty string for both rather than inventing a name with no
record behind it. Code assets are owned by a `DartPackageInfo`, which this
target does not have.

`deps` exists because a facade that groups other libraries is still a
coherent no-package target, and forwarding their closures is then the whole
job.
*�	
�	
dart_info_no_packageH
deps:Targets providing `DartInfo` whose closures are merged in.[](�Builds a `DartInfo` for a target that contributes no Dart package.

For a target that has to be listed in a `deps` attribute requiring
`DartInfo` but ships no Dart: `flutter_material_icons` provides a font, and
wants the provider present, not contributing. It records no
`DartPackageInfo`, so nothing it is listed on gains a `package_config.json`
entry or a source to compile.

There is deliberately no `package_name`, `lib_root`, `srcs`, `resources` or
`code_assets` here. `DartInfo.package_name` and `.lib_root` describe the
package a target contributes, and no consumer reads them off the provider —
package identity is read from `transitive_packages` — so a no-package target
reports the empty string for both rather than inventing a name with no
record behind it. Code assets are owned by a `DartPackageInfo`, which this
target does not have.

`deps` exists because a facade that groups other libraries is still a
coherent no-package target, and forwarding their closures is then the whole
job.
"D
BA `DartInfo` carrying its dependencies' closures and nothing else.2@
dart_info_no_package(@@rules_dart//dart/private:dart_info.bzl
���derive_lib_root�Derive the library root path (short_path-based, without /lib suffix).

For external repos, converts "external/X" to "../X" to match
File.short_path convention. Strips trailing /lib since Dart's
packageUri: "lib/" is appended to rootUri in package_config.json.
*�
�
derive_lib_rootQ
workspace_root;The workspace root of the label (ctx.label.workspace_root). (F
label_package1The Bazel label package path (ctx.label.package). (�Derive the library root path (short_path-based, without /lib suffix).

For external repos, converts "external/X" to "../X" to match
File.short_path convention. Strips trailing /lib since Dart's
packageUri: "lib/" is appended to rootUri in package_config.json.
"8
6The library root path with any trailing /lib stripped.2>
derive_lib_root+@@rules_dart//dart/private:dart_library.bzl
cc�derive_package_name<Derive the Dart package name from rule attributes and label.*�
�
derive_package_nameJ
package_name_attr1Explicit package name attribute, or empty string. (2
label_packageThe Bazel label package path. ('

label_nameThe Bazel label name. (<Derive the Dart package name from rule attributes and label." 
The derived Dart package name.2B
derive_package_name+@@rules_dart//dart/private:dart_library.bzl
�generate_dev_package_config�`generate_package_config` variant for live hot reload of codegen apps.

A package whose hand-written and generated sources straddle the source tree
and `bazel-out` would, under the normal generator, get a `rootUri` pointing
at the frozen assembled (`*.pkgsrcs`) directory — so a dev tool reading it
sees stale generated output and never sees live source edits. Instead, this
emits a `<scheme>:///<lib_root>` `rootUri` for each such package and reports
the filesystem roots the frontend_server must search (`--filesystem-root`,
`--filesystem-scheme`) to resolve those scheme URIs across BOTH the live
source tree and the generated `bazel-out` outputs. Non-assembled packages
(pub deps, pure source packages) keep their normal relative `rootUri` —
the frontend_server resolves a mix of scheme and relative `rootUri`s.
*�
�
generate_dev_package_configu
packageseList of DartPackageInfo providers (pre-colocation, so the app
package still has its real `lib_root`). (P
all_srcs@List of File objects (pre-colocation, so `is_source` is intact). (Q
config_file>The output File for the dev package_config.json (for dirname). (S
scheme3Filesystem scheme for assembled packages' rootUris."org-dartlang-app"(�`generate_package_config` variant for live hot reload of codegen apps.

A package whose hand-written and generated sources straddle the source tree
and `bazel-out` would, under the normal generator, get a `rootUri` pointing
at the frozen assembled (`*.pkgsrcs`) directory — so a dev tool reading it
sees stale generated output and never sees live source edits. Instead, this
emits a `<scheme>:///<lib_root>` `rootUri` for each such package and reports
the filesystem roots the frontend_server must search (`--filesystem-root`,
`--filesystem-scheme`) to resolve those scheme URIs across BOTH the live
source tree and the generated `bazel-out` outputs. Non-assembled packages
(pub deps, pure source packages) keep their normal relative `rootUri` —
the frontend_server resolves a mix of scheme and relative `rootUri`s.
"�
�struct(content, filesystem_roots, scheme, generated_source_paths, generated_source_uris, source_packages):
content: package_config.json text.
filesystem_roots: deduped exec-root-relative dirs for `--filesystem-root`
  (source roots first, then generated roots); empty when nothing needed
  assembly (then the config equals the normal one and no scheme is used).
scheme: the filesystem scheme (meaningful only when roots are non-empty).
generated_source_paths: exec-root-relative paths of the generated files
  in assembled packages — the dev tool re-stats these after a rebuild to
  add changed ones to the reload invalidation set.
generated_source_uris: the `package:` URI for each entry in
  generated_source_paths, index-aligned, so the dev tool can map a
  changed file straight to the URI to invalidate without re-deriving it.
source_packages: (name, lib_root) for each package contributing a
  first-party (editable, main-repo) source file — the dev tool's
  path->package: map for live edits. Excludes pub/external deps and
  generated-only packages.2D
generate_dev_package_config%@@rules_dart//dart/private:common.bzl
���generate_package_config�Generate package_config.json content using short_path-based lib_root.

Resolves exec-root paths from source files, then computes relative
rootUri from config_file's dirname to each package's exec-root location.
*�
�
generate_package_config2
packages"List of DartPackageInfo providers. (H
all_srcs8List of File objects from the transitive source closure. (N
config_file;The output File for package_config.json (used for dirname). (�Generate package_config.json content using short_path-based lib_root.

Resolves exec-root paths from source files, then computes relative
rootUri from config_file's dirname to each package's exec-root location.
"1
/String content of the package_config.json file.2@
generate_package_config%@@rules_dart//dart/private:common.bzl
���generate_package_config_content�Generate package_config.json content string (prefix-based).

Simple version for staging-directory contexts where the relationship between
the config file and package roots is known statically (e.g., dart_analyze
where config is at .dart_tool/ and packages are at ../<lib_root>).
*�
�
generate_package_config_content2
packages"List of DartPackageInfo providers. (L
prefix>Path prefix to prepend to each package's lib_root for rootUri. (�Generate package_config.json content string (prefix-based).

Simple version for staging-directory contexts where the relationship between
the config file and package roots is known statically (e.g., dart_analyze
where config is at .dart_tool/ and packages are at ../<lib_root>).
"1
/String content of the package_config.json file.2H
generate_package_config_content%@@rules_dart//dart/private:common.bzl
���runfiles_path-Convert a File to its runfiles-relative path.*�
�
runfiles_path
fA File object. (>
workspace_name(The workspace name (ctx.workspace_name). (-Convert a File to its runfiles-relative path."$
"The runfiles-relative path string.26
runfiles_path%@@rules_dart//dart/private:common.bzl
::�
//dart/private:common.bzlr�
&

rules_dartdart/private
common.bzl3
collect_packages_collect_packages


K
collect_transitive_resources_collect_transitive_resources
"A
collect_transitive_srcs_collect_transitive_srcs
I
generate_dev_package_config_generate_dev_package_config
!A
generate_package_config_generate_package_config
Q
generate_package_config_content _generate_package_config_content
%-
runfiles_path_runfiles_path

�
//dart/private:dart_info.bzlr�
)

rules_dartdart/privatedart_info.bzl;
dart_analyzable_info_dart_analyzable_info
U
!dart_analyzable_info_with_package"_dart_analyzable_info_with_package
'%
	dart_info
_dart_info
;
dart_info_no_package_dart_info_no_package

�
//dart/private:dart_library.bzlr�
,

rules_dartdart/privatedart_library.bzl1
derive_lib_root_derive_lib_root
9
derive_package_name_derive_package_name

�
//dart/private:source_set.bzlr�
*

rules_dartdart/privatesource_set.bzlK
COPY_TO_DIRECTORY_TOOLCHAINS_COPY_TO_DIRECTORY_TOOLCHAINS
  "9
colocate_entrypoint_colocate_entrypoint
!!5
colocate_packages_colocate_packages
""
#X	COPY_TO_DIRECTORY_TOOLCHAINSj624
20@bazel_lib//lib:copy_to_directory_toolchain_type�Public utility functions for Dart rules.

Re-exports commonly needed helpers for package resolution, source collection,
library root derivation, `package_config.json` generation, and source
co-location. These are used by both rules_dart and rules_flutter.
 