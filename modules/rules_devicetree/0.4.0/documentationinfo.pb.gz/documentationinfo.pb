�
3
rules_devicetree
devicetreedevicetree_info.bzl�DevicetreeInfo�Headers and include directories of a devicetree target.

Any rule may return this provider to make its generated `.dtsi` and
`.h` files usable from the `deps` of
[`dtb()`](dtb.md#dtb) and [`dtbo()`](dtbo.md#dtbo); it is not limited
to [`devicetree_library()`](devicetree_library.md#devicetree_library).

Both depsets must be constructed with `order = "postorder"` so that
include directories from dependencies precede those of the target
itself. See
[`devicetree_library(includes=)`](devicetree_library.md#devicetree_library-includes).2�

�
DevicetreeInfo�Headers and include directories of a devicetree target.

Any rule may return this provider to make its generated `.dtsi` and
`.h` files usable from the `deps` of
[`dtb()`](dtb.md#dtb) and [`dtbo()`](dtbo.md#dtbo); it is not limited
to [`devicetree_library()`](devicetree_library.md#devicetree_library).

Both depsets must be constructed with `order = "postorder"` so that
include directories from dependencies precede those of the target
itself. See
[`devicetree_library(includes=)`](devicetree_library.md#devicetree_library-includes).�
hdrs�(`depset` of `File`) Header files (`.h`, `.dtsi`) made
available to dependents, including those of dependencies. These
become inputs of the preprocessor and `dtc` actions.�
includes�(`depset` of `File`) Directories added to the
preprocessor (`-I`) and `dtc` (`-i`) search path, including those
of dependencies. These are `File`s of directories, not of files."K
DevicetreeInfo9@rules_devicetree//devicetree/private:devicetree_info.bzl�
�
hdrs�(`depset` of `File`) Header files (`.h`, `.dtsi`) made
available to dependents, including those of dependencies. These
become inputs of the preprocessor and `dtc` actions.�
�
includes�(`depset` of `File`) Directories added to the
preprocessor (`-I`) and `dtc` (`-i`) search path, including those
of dependencies. These are `File`s of directories, not of files.7Headers and include directories of a devicetree target.�
6
rules_devicetree
devicetreedevicetree_library.bzl�devicetree_librarykA library of `.dtsi` and `.h` files that can be used in
[`dtb()`](dtb.md#dtb) and [`dtbo()`](dtbo.md#dtbo)."�
�	
devicetree_librarykA library of `.dtsi` and `.h` files that can be used in
[`dtb()`](dtb.md#dtb) and [`dtbo()`](dtbo.md#dtbo).*
nameA unique name for this target. �
deps*Transitive `devicetree_library()` targets.*]
DevicetreeInfoK
DevicetreeInfo9@rules_devicetree//devicetree/private:devicetree_info.bzl2[]�
hdrs�List of exported included files (`.h`, `.dtsi`).

These files are visible to all targets that transitively depend
on this target.2[]�
includes�List of exported include directories in the current package.

These `-i` are added to all [`dtb()`](dtb.md#dtb) and
[`dtbo()`](dtbo.md#dtbo) targets that transitively depend on
this target.

These should be labels to **directories**, not files. For
example:

```starlark
devicetree_library(
    name = "mylib",
    hdrs = ["include/myfile.dtsi"],
    includes = ["include"],
)
```

**Ordering**

Include directories are collected with `postorder` traversal;
that is, `includes` from dependencies are added
first, then `includes` from this target are added.2[]"R
devicetree_library<@rules_devicetree//devicetree/private:devicetree_library.bzl*]
DevicetreeInfoK
DevicetreeInfo9@rules_devicetree//devicetree/private:devicetree_info.bzl,
*
nameA unique name for this target. �
�
deps*Transitive `devicetree_library()` targets.*]
DevicetreeInfoK
DevicetreeInfo9@rules_devicetree//devicetree/private:devicetree_info.bzl2[]�
�
hdrs�List of exported included files (`.h`, `.dtsi`).

These files are visible to all targets that transitively depend
on this target.2[]�
�
includes�List of exported include directories in the current package.

These `-i` are added to all [`dtb()`](dtb.md#dtb) and
[`dtbo()`](dtbo.md#dtbo) targets that transitively depend on
this target.

These should be labels to **directories**, not files. For
example:

```starlark
devicetree_library(
    name = "mylib",
    hdrs = ["include/myfile.dtsi"],
    includes = ["include"],
)
```

**Ordering**

Include directories are collected with `postorder` traversal;
that is, `includes` from dependencies are added
first, then `includes` from this target are added.2[]kA library of `.dtsi` and `.h` files that can be used in [`dtb()`](dtb.md#dtb)
and [`dtbo()`](dtbo.md#dtbo).�
'
rules_devicetree
devicetreedtb.bzl�dtboBuild a base devicetree blob (DTB).

Example:

```starlark
dtb(
    name = "foo",
    srcs = ["foo.dts"],
)
```"�
�
dtboBuild a base devicetree blob (DTB).

Example:

```starlark
dtb(
    name = "foo",
    srcs = ["foo.dts"],
)
```*
nameA unique name for this target. �
deps�List of [`devicetree_library()`](devicetree_library.md#devicetree_library) targets for `.dtsi` and `.h` inclusion.

Order matters. See
[`devicetree_library(includes=)`](devicetree_library.md#devicetree_library-includes)
for details about ordering of include directories.*]
DevicetreeInfoK
DevicetreeInfo9@rules_devicetree//devicetree/private:devicetree_info.bzl2[]&
dtcoptsList of flags to dtc.2[]}
generate_symbols`Enable generation of symbols (-@).

This is necessary if you are applying overlays on top of it.2False�
outOutput file name. This should end with `.dtb`.

Default is `name + ".dtb"`, if name does not end with `.dtb`;
otherwise `name`.2""�
preprocessopts�List of flags to the C preprocessor.

These are appended after
[`devicetree_toolchain(default_preprocessopts=)`](toolchain.md#devicetree_toolchain-default_preprocessopts).

Setting this when
[preprocessing](../configuring_toolchain.md#supporting-c-preprocessor-directives)
is not enabled is an error, because the flags would be silently
dropped.2[]�
srcs�List of sources.

There must be exactly one `.dts` file.

`.dtsi` and `.h` files in the same directory or subdirectories may
also be specified if you do not need extra search directories
(`-i` option to `dtc`). If you do need to pair search
directories with `.dtsi` and `.h` files, use
[`devicetree_library()`](devicetree_library.md#devicetree_library)
and add them to [`deps`](#dtb-deps).2[]"4
dtb-@rules_devicetree//devicetree/private:dtb.bzl,
*
nameA unique name for this target. �
�
deps�List of [`devicetree_library()`](devicetree_library.md#devicetree_library) targets for `.dtsi` and `.h` inclusion.

Order matters. See
[`devicetree_library(includes=)`](devicetree_library.md#devicetree_library-includes)
for details about ordering of include directories.*]
DevicetreeInfoK
DevicetreeInfo9@rules_devicetree//devicetree/private:devicetree_info.bzl2[](
&
dtcoptsList of flags to dtc.2[]
}
generate_symbols`Enable generation of symbols (-@).

This is necessary if you are applying overlays on top of it.2False�
�
outOutput file name. This should end with `.dtb`.

Default is `name + ".dtb"`, if name does not end with `.dtb`;
otherwise `name`.2""�
�
preprocessopts�List of flags to the C preprocessor.

These are appended after
[`devicetree_toolchain(default_preprocessopts=)`](toolchain.md#devicetree_toolchain-default_preprocessopts).

Setting this when
[preprocessing](../configuring_toolchain.md#supporting-c-preprocessor-directives)
is not enabled is an error, because the flags would be silently
dropped.2[]�
�
srcs�List of sources.

There must be exactly one `.dts` file.

`.dtsi` and `.h` files in the same directory or subdirectories may
also be specified if you do not need extra search directories
(`-i` option to `dtc`). If you do need to pair search
directories with `.dtsi` and `.h` files, use
[`devicetree_library()`](devicetree_library.md#devicetree_library)
and add them to [`deps`](#dtb-deps).2[]Builds device tree blobs.�
1
rules_devicetree
devicetreedtb_composite.bzl�dtb_composite:Builds a composite dtb by applying overlays on a base dtb."�
�
dtb_composite:Builds a composite dtb by applying overlays on a base dtb.*
nameA unique name for this target. w
basekBase `.dtb` to apply overlays on.

This usually comes from a `dtb()` target with
`generate_symbols = True`. b
outUOutput file name.

Default is `name + ".dtb"` if missing extension, otherwise `name`.2""4
overlays"List of `.dtbo` overlays to apply.2[]"H
dtb_composite7@rules_devicetree//devicetree/private:dtb_composite.bzl,
*
nameA unique name for this target. y
w
basekBase `.dtb` to apply overlays on.

This usually comes from a `dtb()` target with
`generate_symbols = True`. d
b
outUOutput file name.

Default is `name + ".dtb"` if missing extension, otherwise `name`.2""6
4
overlays"List of `.dtbo` overlays to apply.2[]:Builds a composite dtb by applying overlays on a base dtb.�
(
rules_devicetree
devicetreedtbo.bzl�dtbozBuild a base devicetree blob overlay (DTBO).

Example:

```starlark
dtbo(
    name = "baz",
    srcs = ["baz.dtso"],
)
```"�
�
dtbozBuild a base devicetree blob overlay (DTBO).

Example:

```starlark
dtbo(
    name = "baz",
    srcs = ["baz.dtso"],
)
```*
nameA unique name for this target. �
deps�List of [`devicetree_library()`](devicetree_library.md#devicetree_library) targets for `.dtsi` and `.h` inclusion.

Order matters. See
[`devicetree_library(includes=)`](devicetree_library.md#devicetree_library-includes)
for details about ordering of include directories.*]
DevicetreeInfoK
DevicetreeInfo9@rules_devicetree//devicetree/private:devicetree_info.bzl2[]&
dtcoptsList of flags to dtc.2[]�
out�Output file name. This should end with `.dtbo`.

Default is `name + ".dtbo"`, if name does not end with `.dtbo`;
otherwise `name`.2""�
preprocessopts�List of flags to the C preprocessor.

These are appended after
[`devicetree_toolchain(default_preprocessopts=)`](toolchain.md#devicetree_toolchain-default_preprocessopts).

Setting this when
[preprocessing](../configuring_toolchain.md#supporting-c-preprocessor-directives)
is not enabled is an error, because the flags would be silently
dropped.2[]�
srcs�List of sources.

There must be exactly one `.dtso` file.

`.dtsi` and `.h` files in the same directory or subdirectories may
also be specified if you do not need extra search directories
(`-i` option to `dtc`). If you do need to pair search
directories with `.dtsi` and `.h` files, use
[`devicetree_library()`](devicetree_library.md#devicetree_library)
and add them to [`deps`](#dtb-deps).2[]"5
dtbo-@rules_devicetree//devicetree/private:dtb.bzl,
*
nameA unique name for this target. �
�
deps�List of [`devicetree_library()`](devicetree_library.md#devicetree_library) targets for `.dtsi` and `.h` inclusion.

Order matters. See
[`devicetree_library(includes=)`](devicetree_library.md#devicetree_library-includes)
for details about ordering of include directories.*]
DevicetreeInfoK
DevicetreeInfo9@rules_devicetree//devicetree/private:devicetree_info.bzl2[](
&
dtcoptsList of flags to dtc.2[]�
�
out�Output file name. This should end with `.dtbo`.

Default is `name + ".dtbo"`, if name does not end with `.dtbo`;
otherwise `name`.2""�
�
preprocessopts�List of flags to the C preprocessor.

These are appended after
[`devicetree_toolchain(default_preprocessopts=)`](toolchain.md#devicetree_toolchain-default_preprocessopts).

Setting this when
[preprocessing](../configuring_toolchain.md#supporting-c-preprocessor-directives)
is not enabled is an error, because the flags would be silently
dropped.2[]�
�
srcs�List of sources.

There must be exactly one `.dtso` file.

`.dtsi` and `.h` files in the same directory or subdirectories may
also be specified if you do not need extra search directories
(`-i` option to `dtc`). If you do need to pair search
directories with `.dtsi` and `.h` files, use
[`devicetree_library()`](devicetree_library.md#devicetree_library)
and add them to [`deps`](#dtb-deps).2[]!Builds device tree blob overlays.�
-
rules_devicetree
devicetreetoolchain.bzl�devicetree_toolchainzDefines a devicetree toolchain.

For usage see https://docs.bazel.build/versions/main/toolchains.html#defining-toolchains."�
�
devicetree_toolchainzDefines a devicetree toolchain.

For usage see https://docs.bazel.build/versions/main/toolchains.html#defining-toolchains.*
nameA unique name for this target. "
dtcdevicetree compiler2None2

fdtoverlayexecutable to apply overlays2None5
default_dtcoptsDefault list of flags to dtc2[]�
default_preprocessopts�Default list of flags to the C preprocessor.

These are added after the flags that `dtb()` and `dtbo()` always pass
(`-undef -D__DTS__` and the include directories from `deps`), and
before `dtb(preprocessopts=)` and `dtbo(preprocessopts=)`.

Setting this on a toolchain that does not preprocess is an error,
because the flags would be silently dropped.2[]�

preprocess�Whether source files are preprocessed.

If true, allow preprocessing directives in source files (`*.dts`, `*.dtso`).
The CC toolchain must be available.

If false, preprocessing directives are not allowed. "K
devicetree_toolchain3@rules_devicetree//devicetree/private:toolchain.bzl,
*
nameA unique name for this target. $
"
dtcdevicetree compiler2None4
2

fdtoverlayexecutable to apply overlays2None7
5
default_dtcoptsDefault list of flags to dtc2[]�
�
default_preprocessopts�Default list of flags to the C preprocessor.

These are added after the flags that `dtb()` and `dtbo()` always pass
(`-undef -D__DTS__` and the include directories from `deps`), and
before `dtb(preprocessopts=)` and `dtbo(preprocessopts=)`.

Setting this on a toolchain that does not preprocess is an error,
because the flags would be silently dropped.2[]�
�

preprocess�Whether source files are preprocessed.

If true, allow preprocessing directives in source files (`*.dts`, `*.dtso`).
The CC toolchain must be available.

If false, preprocessing directives are not allowed. <This module implements the language-specific toolchain rule. 