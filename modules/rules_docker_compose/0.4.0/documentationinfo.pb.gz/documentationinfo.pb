��
B
rules_docker_composedocker_compose/privatedocker_compose.bzl�docker_compose_binary�
Creates a runnable target for invoking docker-compose with a generated configuration.

This rule consumes a `docker_compose_yaml` target and produces an executable that:

1. Loads container images into Docker using the specified loader targets
2. Runs `docker-compose -f <yaml> <args...>` forwarding all command-line arguments

Use this rule when you need to interactively manage docker-compose services
(e.g. `bazel run :compose -- up -d`, `bazel run :compose -- down`).

Supported image loader types:

| Loader | Source |
|--------|--------|
| [oci_load](https://github.com/bazel-contrib/rules_oci/blob/main/docs/load.md#oci_load) | rules_oci |
| [image_load](https://github.com/bazel-contrib/rules_img/blob/main/docs/load.md#image_load) | rules_img |

Example:
```python
load("@rules_docker_compose//docker_compose:defs.bzl", "docker_compose_binary", "docker_compose_yaml")
load("@rules_oci//oci:defs.bzl", "oci_load")

oci_load(
    name = "my_service.load",
    image = ":my_service",
    repo_tags = ["my-service:latest"],
)

docker_compose_yaml(
    name = "compose_yaml",
    yamls = ["docker-compose.yaml"],
    images = [":my_service.load"],
)

docker_compose_binary(
    name = "compose",
    yaml = ":compose_yaml",
    images = [":my_service.load"],
)
```

Then run with:
```bash
bazel run :compose -- up -d
bazel run :compose -- down
bazel run :compose -- ps
```
"�
�
docker_compose_binary�
Creates a runnable target for invoking docker-compose with a generated configuration.

This rule consumes a `docker_compose_yaml` target and produces an executable that:

1. Loads container images into Docker using the specified loader targets
2. Runs `docker-compose -f <yaml> <args...>` forwarding all command-line arguments

Use this rule when you need to interactively manage docker-compose services
(e.g. `bazel run :compose -- up -d`, `bazel run :compose -- down`).

Supported image loader types:

| Loader | Source |
|--------|--------|
| [oci_load](https://github.com/bazel-contrib/rules_oci/blob/main/docs/load.md#oci_load) | rules_oci |
| [image_load](https://github.com/bazel-contrib/rules_img/blob/main/docs/load.md#image_load) | rules_img |

Example:
```python
load("@rules_docker_compose//docker_compose:defs.bzl", "docker_compose_binary", "docker_compose_yaml")
load("@rules_oci//oci:defs.bzl", "oci_load")

oci_load(
    name = "my_service.load",
    image = ":my_service",
    repo_tags = ["my-service:latest"],
)

docker_compose_yaml(
    name = "compose_yaml",
    yamls = ["docker-compose.yaml"],
    images = [":my_service.load"],
)

docker_compose_binary(
    name = "compose",
    yaml = ":compose_yaml",
    images = [":my_service.load"],
)
```

Then run with:
```bash
bazel run :compose -- up -d
bazel run :compose -- down
bazel run :compose -- ps
```
*
nameA unique name for this target. �
images�Image loader targets that provide the container images for the docker-compose services. Each image will be loaded into Docker before docker-compose is invoked. See the rule documentation for supported loader types.2[]v
yamlQA `docker_compose_yaml` target providing the merged docker-compose configuration. *
DockerComposeYamlInfo"Z
docker_compose_binaryA@@rules_docker_compose//docker_compose/private:docker_compose.bzl
��,
*
nameA unique name for this target. �
�
images�Image loader targets that provide the container images for the docker-compose services. Each image will be loaded into Docker before docker-compose is invoked. See the rule documentation for supported loader types.2[]x
v
yamlQA `docker_compose_yaml` target providing the merged docker-compose configuration. *
DockerComposeYamlInfo�5docker_compose_test�Runs a test with docker-compose services.

This rule starts docker-compose services, waits for them to be ready, runs a test binary,
and then tears down the services. The test lifecycle is:

1. Loading container images into Docker (under a per-original-tag daemon-level lock)
   and retagging each loaded image to a content-derived unique tag
2. Starting services with `docker-compose up` against the unique-tag-rewritten YAML
3. Waiting for containers to be running (with health checks)
4. Running the test binary with optional arguments
5. Cleaning up with `docker-compose down`

The test requires network access and Docker to be available on the host.

Supported image loader types:

| Loader | Source |
|--------|--------|
| [oci_load](https://github.com/bazel-contrib/rules_oci/blob/main/docs/load.md#oci_load) | rules_oci |
| [image_load](https://github.com/bazel-contrib/rules_img/blob/main/docs/load.md#image_load) | rules_img |

Example:
```python
load("@rules_docker_compose//docker_compose:docker_compose_test.bzl", "docker_compose_test")
load("@rules_oci//oci:defs.bzl", "oci_load")

oci_load(
    name = "my_service.load",
    image = ":my_service",
    repo_tags = ["my-service:latest"],
)

docker_compose_test(
    name = "integration_test",
    yamls = ["docker-compose.yaml"],
    images = [":my_service.load"],
    test = ":my_test_binary",
    test_args = ["-host", "localhost:8080"],
    delay = 2,  # Wait 2 seconds after containers start
)
```
"�*
�
docker_compose_test�Runs a test with docker-compose services.

This rule starts docker-compose services, waits for them to be ready, runs a test binary,
and then tears down the services. The test lifecycle is:

1. Loading container images into Docker (under a per-original-tag daemon-level lock)
   and retagging each loaded image to a content-derived unique tag
2. Starting services with `docker-compose up` against the unique-tag-rewritten YAML
3. Waiting for containers to be running (with health checks)
4. Running the test binary with optional arguments
5. Cleaning up with `docker-compose down`

The test requires network access and Docker to be available on the host.

Supported image loader types:

| Loader | Source |
|--------|--------|
| [oci_load](https://github.com/bazel-contrib/rules_oci/blob/main/docs/load.md#oci_load) | rules_oci |
| [image_load](https://github.com/bazel-contrib/rules_img/blob/main/docs/load.md#image_load) | rules_img |

Example:
```python
load("@rules_docker_compose//docker_compose:docker_compose_test.bzl", "docker_compose_test")
load("@rules_oci//oci:defs.bzl", "oci_load")

oci_load(
    name = "my_service.load",
    image = ":my_service",
    repo_tags = ["my-service:latest"],
)

docker_compose_test(
    name = "integration_test",
    yamls = ["docker-compose.yaml"],
    images = [":my_service.load"],
    test = ":my_test_binary",
    test_args = ["-host", "localhost:8080"],
    delay = 2,  # Wait 2 seconds after containers start
)
```
*
nameA unique name for this target. ;
data-Additional runtime dependencies for the test.2[]�
delay�Seconds to wait after containers are running before executing the test. Useful for services that need initialization time beyond their health checks.21h
env[Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution
2{}�
env_inherit~Specifies additional environment variables to inherit from the external environment when the test is executed by `bazel test`.2[]�
images�Image loader targets that provide the container images for the docker-compose services. Each image will be loaded into Docker before `docker-compose up` is called. See the rule documentation for supported loader types.2[]�
interpolate�Whether to resolve `${VAR}` references when merging raw `yamls` at build time.
See the `docker_compose_yaml` rule for details.

Setting this is an error when `yamls` is a single `docker_compose_yaml` target,
which carries its own `interpolate` setting.

Note that `bazel test` runs with a sanitized environment, so a deferred variable
also needs to be listed in `env_inherit` (or set in `env`) to reach
docker-compose at runtime.
2True�
interpolation_env�Environment variables used to interpolate raw `yamls` at build time. See the
`docker_compose_yaml` rule for details.

This is distinct from `env`, which sets the environment of the test process
itself. Setting this is an error when `yamls` is a single `docker_compose_yaml`
target; declare it on that target instead.

2{}|
testlThe test binary to execute after containers are running. The binary will receive arguments from `test_args`.2None8
	test_args%Arguments to pass to the test binary.2[]�
yamlssOne or more docker-compose YAML files defining the services to run. Files are merged using `docker-compose config`.2[]"X
docker_compose_testA@@rules_docker_compose//docker_compose/private:docker_compose.bzl
��,
*
nameA unique name for this target. =
;
data-Additional runtime dependencies for the test.2[]�
�
delay�Seconds to wait after containers are running before executing the test. Useful for services that need initialization time beyond their health checks.21j
h
env[Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution
2{}�
�
env_inherit~Specifies additional environment variables to inherit from the external environment when the test is executed by `bazel test`.2[]�
�
images�Image loader targets that provide the container images for the docker-compose services. Each image will be loaded into Docker before `docker-compose up` is called. See the rule documentation for supported loader types.2[]�
�
interpolate�Whether to resolve `${VAR}` references when merging raw `yamls` at build time.
See the `docker_compose_yaml` rule for details.

Setting this is an error when `yamls` is a single `docker_compose_yaml` target,
which carries its own `interpolate` setting.

Note that `bazel test` runs with a sanitized environment, so a deferred variable
also needs to be listed in `env_inherit` (or set in `env`) to reach
docker-compose at runtime.
2True�
�
interpolation_env�Environment variables used to interpolate raw `yamls` at build time. See the
`docker_compose_yaml` rule for details.

This is distinct from `env`, which sets the environment of the test process
itself. Setting this is an error when `yamls` is a single `docker_compose_yaml`
target; declare it on that target instead.

2{}~
|
testlThe test binary to execute after containers are running. The binary will receive arguments from `test_args`.2None:
8
	test_args%Arguments to pass to the test binary.2[]�
�
yamlssOne or more docker-compose YAML files defining the services to run. Files are merged using `docker-compose config`.2[]�Rdocker_compose_yaml�Merges docker-compose configurations and validates image references.

This rule uses `docker-compose config` to merge one or more docker-compose YAML files
(and/or an inline Starlark configuration) into a single, canonical configuration. It
also validates that all images referenced in the configuration have corresponding loader
targets specified in the `images` attribute.

At least one of `yamls` or `config` must be provided. When both are given, they are
merged together using `docker-compose config` (the `config` JSON is applied on top of
the YAML files).

The merged YAML preserves the original image tags declared in your inputs â it is
diff-reviewable and safe to share outside Bazel (e.g. check it into version control,
hand off to a teammate's `docker compose -f` invocation, etc.).

For each image with a registered loader, the merger ALSO computes a content digest
(`sha256(index.json)` for rules_oci, `sha256(manifest_file)` for rules_img) and emits
a second YAML where `services.*.image` references are rewritten to a content-derived
unique tag of the form `<repo>:rdc-<digest12>`. That rewritten YAML is consumed only
by `docker_compose_test` to isolate parallel test runs on a shared engine.
`docker_compose_binary` (and the default output of this rule) use the original tags.

Supported image loader types:

| Loader | Source |
|--------|--------|
| [oci_load](https://github.com/bazel-contrib/rules_oci/blob/main/docs/load.md#oci_load) | rules_oci |
| [image_load](https://github.com/bazel-contrib/rules_img/blob/main/docs/load.md#image_load) | rules_img |

Example with YAML files:
```python
load("@rules_docker_compose//docker_compose:docker_compose_yaml.bzl", "docker_compose_yaml")
load("@rules_oci//oci:defs.bzl", "oci_load")

oci_load(
    name = "my_image.load",
    image = ":my_image",
    repo_tags = ["my-app:latest"],
)

docker_compose_yaml(
    name = "compose",
    yamls = ["docker-compose.yaml"],
    images = [":my_image.load"],
)
```

Example with inline Starlark config:
```python
load("@rules_docker_compose//docker_compose:docker_compose_config.bzl", "docker_compose_config")
load("@rules_docker_compose//docker_compose:docker_compose_yaml.bzl", "docker_compose_yaml")
load("@rules_oci//oci:defs.bzl", "oci_load")

oci_load(
    name = "nginx.load",
    image = ":nginx",
    repo_tags = ["my-app/nginx:latest"],
)

docker_compose_yaml(
    name = "compose",
    config = docker_compose_config(
        services = {
            "web": {
                "image": "my-app/nginx:latest",
                "ports": ["8080:80"],
            },
        },
    ),
    images = [":nginx.load"],
)
```
"�=
�)
docker_compose_yaml�Merges docker-compose configurations and validates image references.

This rule uses `docker-compose config` to merge one or more docker-compose YAML files
(and/or an inline Starlark configuration) into a single, canonical configuration. It
also validates that all images referenced in the configuration have corresponding loader
targets specified in the `images` attribute.

At least one of `yamls` or `config` must be provided. When both are given, they are
merged together using `docker-compose config` (the `config` JSON is applied on top of
the YAML files).

The merged YAML preserves the original image tags declared in your inputs â it is
diff-reviewable and safe to share outside Bazel (e.g. check it into version control,
hand off to a teammate's `docker compose -f` invocation, etc.).

For each image with a registered loader, the merger ALSO computes a content digest
(`sha256(index.json)` for rules_oci, `sha256(manifest_file)` for rules_img) and emits
a second YAML where `services.*.image` references are rewritten to a content-derived
unique tag of the form `<repo>:rdc-<digest12>`. That rewritten YAML is consumed only
by `docker_compose_test` to isolate parallel test runs on a shared engine.
`docker_compose_binary` (and the default output of this rule) use the original tags.

Supported image loader types:

| Loader | Source |
|--------|--------|
| [oci_load](https://github.com/bazel-contrib/rules_oci/blob/main/docs/load.md#oci_load) | rules_oci |
| [image_load](https://github.com/bazel-contrib/rules_img/blob/main/docs/load.md#image_load) | rules_img |

Example with YAML files:
```python
load("@rules_docker_compose//docker_compose:docker_compose_yaml.bzl", "docker_compose_yaml")
load("@rules_oci//oci:defs.bzl", "oci_load")

oci_load(
    name = "my_image.load",
    image = ":my_image",
    repo_tags = ["my-app:latest"],
)

docker_compose_yaml(
    name = "compose",
    yamls = ["docker-compose.yaml"],
    images = [":my_image.load"],
)
```

Example with inline Starlark config:
```python
load("@rules_docker_compose//docker_compose:docker_compose_config.bzl", "docker_compose_config")
load("@rules_docker_compose//docker_compose:docker_compose_yaml.bzl", "docker_compose_yaml")
load("@rules_oci//oci:defs.bzl", "oci_load")

oci_load(
    name = "nginx.load",
    image = ":nginx",
    repo_tags = ["my-app/nginx:latest"],
)

docker_compose_yaml(
    name = "compose",
    config = docker_compose_config(
        services = {
            "web": {
                "image": "my-app/nginx:latest",
                "ports": ["8080:80"],
            },
        },
    ),
    images = [":nginx.load"],
)
```
*
nameA unique name for this target. �
config�A JSON-encoded docker-compose configuration string. Use `docker_compose_config()` to produce this value from structured Starlark dicts. Can be used alone or combined with `yamls`.2""�
data�Additional files referenced by the docker-compose configuration (e.g. env_file, config files, secret files, bind-mount sources). These are made available during the merge action and propagated to consuming rules for runtime availability.2[]�
images�Image loader targets that provide the container images referenced in the configuration. Each image referenced in the docker-compose config must have a corresponding loader target. See the rule documentation for supported loader types.2[]�
interpolate�Whether to resolve `${VAR}` references when merging.

When `True` (the default), `docker-compose config` interpolates every variable
at build time. Bazel actions run with a sanitized environment, so a variable
that isn't declared in `interpolation_env` resolves to an empty string.

Set to `False` to keep `${VAR}` references verbatim in the merged YAML so
docker-compose resolves them at runtime instead â the right choice for
per-developer or per-machine values like `${USER}`. `services.*.image` is
always resolved at build time regardless, because each image reference must be
matched to a loader target; declare any variables it uses in
`interpolation_env`.
2True�
interpolation_env�Environment variables used to interpolate the compose files at build time.

These are visible only to the merge action, not to the containers. Because the
values are declared in the BUILD file rather than read from the invoking shell,
they keep the merged YAML hermetic and correctly cached.

When `interpolate = False` this applies to `services.*.image` only, since that
is the only field still resolved at build time; every other reference is left
for docker-compose to resolve at runtime.

To set variables the containers see at runtime, use the compose file's own
`environment`/`env_file` keys. To let a variable come from the host at runtime,
set `interpolate = False` and (for `bazel test`) list it in the
`env_inherit` attribute of `docker_compose_test`.

2{}o
outfOptional output filename for the merged docker-compose YAML. Defaults to `{name}/docker-compose.yaml`.�
yamls�One or more docker-compose YAML files to merge. Files are merged in order using `docker-compose config`. At least one of `yamls` or `config` must be provided.2[]"X
docker_compose_yamlA@@rules_docker_compose//docker_compose/private:docker_compose.bzl
��,
*
nameA unique name for this target. �
�
config�A JSON-encoded docker-compose configuration string. Use `docker_compose_config()` to produce this value from structured Starlark dicts. Can be used alone or combined with `yamls`.2""�
�
data�Additional files referenced by the docker-compose configuration (e.g. env_file, config files, secret files, bind-mount sources). These are made available during the merge action and propagated to consuming rules for runtime availability.2[]�
�
images�Image loader targets that provide the container images referenced in the configuration. Each image referenced in the docker-compose config must have a corresponding loader target. See the rule documentation for supported loader types.2[]�
�
interpolate�Whether to resolve `${VAR}` references when merging.

When `True` (the default), `docker-compose config` interpolates every variable
at build time. Bazel actions run with a sanitized environment, so a variable
that isn't declared in `interpolation_env` resolves to an empty string.

Set to `False` to keep `${VAR}` references verbatim in the merged YAML so
docker-compose resolves them at runtime instead â the right choice for
per-developer or per-machine values like `${USER}`. `services.*.image` is
always resolved at build time regardless, because each image reference must be
matched to a loader target; declare any variables it uses in
`interpolation_env`.
2True�
�
interpolation_env�Environment variables used to interpolate the compose files at build time.

These are visible only to the merge action, not to the containers. Because the
values are declared in the BUILD file rather than read from the invoking shell,
they keep the merged YAML hermetic and correctly cached.

When `interpolate = False` this applies to `services.*.image` only, since that
is the only field still resolved at build time; every other reference is left
for docker-compose to resolve at runtime.

To set variables the containers see at runtime, use the compose file's own
`environment`/`env_file` keys. To let a variable come from the host at runtime,
set `interpolate = False` and (for `bazel test`) list it in the
`env_inherit` attribute of `docker_compose_test`.

2{}q
o
outfOptional output filename for the merged docker-compose YAML. Defaults to `{name}/docker-compose.yaml`.�
�
yamls�One or more docker-compose YAML files to merge. Files are merged in order using `docker-compose config`. At least one of `yamls` or `config` must be provided.2[]�docker_compose_config�Encode a docker-compose configuration as a JSON string.

Parameters mirror the top-level keys of the
[Compose Specification](https://docs.docker.com/reference/compose-file/).
The returned string is suitable for passing to the `config` attribute
of `docker_compose_yaml`.
*�	
�
docker_compose_config�
services�A dict mapping service names to their configuration dicts.
Each value follows the Compose `services.<name>` schema (image,
ports, environment, volumes, depends_on, etc.).{}(z
networkshA dict mapping network names to their configuration dicts.
Follows the Compose `networks.<name>` schema.{}(w
volumesfA dict mapping volume names to their configuration dicts.
Follows the Compose `volumes.<name>` schema.{}(w
configsfA dict mapping config names to their configuration dicts.
Follows the Compose `configs.<name>` schema.{}(w
secretsfA dict mapping secret names to their configuration dicts.
Follows the Compose `secrets.<name>` schema.{}(�Encode a docker-compose configuration as a JSON string.

Parameters mirror the top-level keys of the
[Compose Specification](https://docs.docker.com/reference/compose-file/).
The returned string is suitable for passing to the `config` attribute
of `docker_compose_yaml`.
"F
DA JSON-encoded string representing the docker-compose configuration.2Z
docker_compose_configA@@rules_docker_compose//docker_compose/private:docker_compose.bzl
�DockerComposeYamlInfo�Provides information about a resolved docker-compose YAML configuration.

This provider is returned by `docker_compose_yaml` and contains the merged
docker-compose configuration along with metadata about images and dependencies.
It can be consumed by `docker_compose_test` or other rules that need to work
with docker-compose configurations.
2�
�

DockerComposeYamlInfo�Provides information about a resolved docker-compose YAML configuration.

This provider is returned by `docker_compose_yaml` and contains the merged
docker-compose configuration along with metadata about images and dependencies.
It can be consumed by `docker_compose_test` or other rules that need to work
with docker-compose configurations.
}
dataudepset[File]: Additional data files referenced by the configuration (env_file, configs, secrets, bind-mount sources).[
imagesQdepset[File]: The image loader executables for each image referenced in the yaml.�
runtime_manifestzFile: A JSON manifest mapping each loader to its (original_tag, unique_tag) rewrites, consumed by the runner and launcher.�
yaml�File: The merged docker-compose YAML file with original image tags preserved. This is the user-facing artifact, suitable for sharing outside Bazel.l
	yaml_deps_depset[File]: All files which contributed to the merged yaml (input yamls and image manifests).�
yaml_rewritten�File: The merged docker-compose YAML with each loader-backed image rewritten to a content-derived unique tag. Used internally by `docker_compose_test` to isolate parallel test runs on a shared engine."Z
DockerComposeYamlInfoA@@rules_docker_compose//docker_compose/private:docker_compose.bzl
0!0!
}
dataudepset[File]: Additional data files referenced by the configuration (env_file, configs, secrets, bind-mount sources).]
[
imagesQdepset[File]: The image loader executables for each image referenced in the yaml.�
�
runtime_manifestzFile: A JSON manifest mapping each loader to its (original_tag, unique_tag) rewrites, consumed by the runner and launcher.�
�
yaml�File: The merged docker-compose YAML file with original image tags preserved. This is the user-facing artifact, suitable for sharing outside Bazel.n
l
	yaml_deps_depset[File]: All files which contributed to the merged yaml (input yamls and image manifests).�
�
yaml_rewritten�File: The merged docker-compose YAML with each loader-backed image rewritten to a content-derived unique tag. Used internally by `docker_compose_test` to isolate parallel test runs on a shared engine.�
(//docker_compose/private:image_utils.bzlr�
?
rules_docker_composedocker_compose/privateimage_utils.bzl@
ImageLoadRepositoryInfoImageLoadRepositoryInfo
H_J
image_load_repository_aspectimage_load_repository_aspect
c
��
&//docker_compose/private:toolchain.bzlr}
=
rules_docker_composedocker_compose/privatetoolchain.bzl.
TOOLCHAIN_TYPETOOLCHAIN_TYPE
FT
VDocker-Compose rules�
?
rules_docker_composedocker_compose/privateimage_utils.bzl�ImageLoadRepositoryInfoJRepository and image information for a given oci_load or image_load target2�
�
ImageLoadRepositoryInfoJRepository and image information for a given oci_load or image_load target2
loader(File: The executable for loading images.9
loader_runfiles&depset[File]: Runfiles for the loader.M
manifest_file<File (optional): The manifest JSON file for rules_img imagesb

oci_layoutTFile (optional): The OCI layout directory for rules_oci images (contains index.json)v
	tag_filesiList[File]: List of files containing tags (one per line, format: repository:tag) used for the load target"Y
ImageLoadRepositoryInfo>@@rules_docker_compose//docker_compose/private:image_utils.bzl
##4
2
loader(File: The executable for loading images.;
9
loader_runfiles&depset[File]: Runfiles for the loader.O
M
manifest_file<File (optional): The manifest JSON file for rules_img imagesd
b

oci_layoutTFile (optional): The OCI layout directory for rules_oci images (contains index.json)x
v
	tag_filesiList[File]: List of files containing tags (one per line, format: repository:tag) used for the load target�image_load_repository_aspectPProvides the repository and image_root for a given oci_load or image_load target:�
�
image_load_repository_aspectPProvides the repository and image_root for a given oci_load or image_load target"*
nameA unique name for this target. *^
image_load_repository_aspect>@@rules_docker_compose//docker_compose/private:image_utils.bzl
o&o&,
*
nameA unique name for this target. �image_push_repository_aspectPProvides the repository and image_root for a given oci_load or image_load target:�
�
image_push_repository_aspectPProvides the repository and image_root for a given oci_load or image_load target"*
nameA unique name for this target. *^
image_push_repository_aspect>@@rules_docker_compose//docker_compose/private:image_utils.bzl
o&o&,
*
nameA unique name for this target. Utilities for container images� 
=
rules_docker_composedocker_compose/privatetoolchain.bzl� current_docker_compose_toolchainDAccess the `docker_compose_toolchain` for the current configuration."�
�
 current_docker_compose_toolchainDAccess the `docker_compose_toolchain` for the current configuration.*
nameA unique name for this target. "`
 current_docker_compose_toolchain<@@rules_docker_compose//docker_compose/private:toolchain.bzl
�(�(,
*
nameA unique name for this target. �docker_compose_toolchain�A toolchain for providing Docker-Compose to Bazel rules.

Example:

```python
load("@rules_docker_compose//docker_compose:docker_compose_toolchain.bzl", "docker_compose_toolchain")

filegroup(
    name = "docker_compose_bin",
    srcs = ["docker_compose/docker_compose.exe"],
    # Note that additional runfiles associated with a hermetic archive
    # of docker_compose should be associated with the target passed to the
    # `docker_compose` attribute.
    data = glob(["docker_compose/**"]),
)

docker_compose_toolchain(
    name = "docker_compose_toolchain",
    docker_compose = ":docker_compose_bin",
    visibility = ["//visibility:public"],
)
```

For users looking to use a system install of Docker-Compose, a shell/batch script
should be added that points to the system install.

Example or non-hermetic toolchain:

`docker_compose.sh`
```bash
#!/usr/bin/env bash
set -euo pipefail
exec /usr/bin/docker_compose $@
```

`docker_compose.bat`
```batch
@ECHO OFF
C:\Program Files\Docker\Docker\resources\docker-compose.exe %*
set EXITCODE=%ERRORLEVEL%
exit /b %EXITCODE%
```

```python
load("@rules_docker_compose//docker_compose:docker_compose_toolchain.bzl", "docker_compose_toolchain")

filegroup(
    name = "docker_compose_bin",
    srcs = select({
        "@platforms//os:windows": ["docker_compose.bat"],
        "//conditions:default": ["docker_compose.sh"],
    }),
)

docker_compose_toolchain(
    name = "docker_compose_toolchain",
    docker_compose = ":docker_compose_bin",
    visibility = ["//visibility:public"],
)
```
"�
�
docker_compose_toolchain�A toolchain for providing Docker-Compose to Bazel rules.

Example:

```python
load("@rules_docker_compose//docker_compose:docker_compose_toolchain.bzl", "docker_compose_toolchain")

filegroup(
    name = "docker_compose_bin",
    srcs = ["docker_compose/docker_compose.exe"],
    # Note that additional runfiles associated with a hermetic archive
    # of docker_compose should be associated with the target passed to the
    # `docker_compose` attribute.
    data = glob(["docker_compose/**"]),
)

docker_compose_toolchain(
    name = "docker_compose_toolchain",
    docker_compose = ":docker_compose_bin",
    visibility = ["//visibility:public"],
)
```

For users looking to use a system install of Docker-Compose, a shell/batch script
should be added that points to the system install.

Example or non-hermetic toolchain:

`docker_compose.sh`
```bash
#!/usr/bin/env bash
set -euo pipefail
exec /usr/bin/docker_compose $@
```

`docker_compose.bat`
```batch
@ECHO OFF
C:\Program Files\Docker\Docker\resources\docker-compose.exe %*
set EXITCODE=%ERRORLEVEL%
exit /b %EXITCODE%
```

```python
load("@rules_docker_compose//docker_compose:docker_compose_toolchain.bzl", "docker_compose_toolchain")

filegroup(
    name = "docker_compose_bin",
    srcs = select({
        "@platforms//os:windows": ["docker_compose.bat"],
        "//conditions:default": ["docker_compose.sh"],
    }),
)

docker_compose_toolchain(
    name = "docker_compose_toolchain",
    docker_compose = ":docker_compose_bin",
    visibility = ["//visibility:public"],
)
```
*
nameA unique name for this target. 4
docker_composeThe docker-compose executable. -
versionThe version of docker-compose. "X
docker_compose_toolchain<@@rules_docker_compose//docker_compose/private:toolchain.bzl
  ,
*
nameA unique name for this target. 6
4
docker_composeThe docker-compose executable. /
-
versionThe version of docker-compose. Z	TOOLCHAIN_TYPE!@@//docker_compose:toolchain_typej#!@@//docker_compose:toolchain_typeDocker-Compose toolchain�(
B
rules_docker_composedocker_compose/privatetoolchain_repo.bzl�docker_compose_tools_repositoryDDownload a version of Docker-Compose and instantiate targets for it.*�
�
docker_compose_tools_repository1
name%The name of the repository to create. (>
version/The version of Docker-Compose (e.g., "2.24.0"). (M
platform=The target platform (e.g., "linux-x86_64", "darwin-aarch64"). (2
urls&The URLs to fetch Docker-Compose from. (F
	integrity5The integrity checksum of the Docker-Compose archive. (DDownload a version of Docker-Compose and instantiate targets for it."%
#str: Return `name` for convenience.2d
docker_compose_tools_repositoryA@@rules_docker_compose//docker_compose/private:toolchain_repo.bzl
AA2#docker_compose_toolchain_repository�#docker_compose_toolchain_repository.A rule for defining docker-compose toolchains.R�

�
#docker_compose_toolchain_repository.A rule for defining docker-compose toolchains..
name"A unique name for this repository. 0
docker_composeThe docker-compose binary. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 -
versionThe version of docker-compose. *h
#docker_compose_toolchain_repositoryA@@rules_docker_compose//docker_compose/private:toolchain_repo.bzl
16160
.
name"A unique name for this repository. 2
0
docker_composeThe docker-compose binary. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 /
-
versionThe version of docker-compose. �'docker_compose_toolchain_repository_hub�Generates a toolchain-bearing repository that declares a set of Docker-Compose toolchains from other repositories. This exists to allow registering a set of toolchains in one go with the `:all` target.R�
�

'docker_compose_toolchain_repository_hub�Generates a toolchain-bearing repository that declares a set of Docker-Compose toolchains from other repositories. This exists to allow registering a set of toolchains in one go with the `:all` target..
name"A unique name for this repository. y
exec_compatible_with]A list of constraints for the execution platform for this toolchain, keyed by toolchain name. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 x
target_compatible_withZA list of constraints for the target platform for this toolchain, keyed by toolchain name. q
target_settingsZA list of constraints for the target platform for this toolchain, keyed by toolchain name. a
toolchain_labelsIThe name of the toolchain implementation target, keyed by toolchain name.
 
toolchain_names *l
'docker_compose_toolchain_repository_hubA@@rules_docker_compose//docker_compose/private:toolchain_repo.bzl
�:�:0
.
name"A unique name for this repository. {
y
exec_compatible_with]A list of constraints for the execution platform for this toolchain, keyed by toolchain name. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 z
x
target_compatible_withZA list of constraints for the target platform for this toolchain, keyed by toolchain name. s
q
target_settingsZA list of constraints for the target platform for this toolchain, keyed by toolchain name. c
a
toolchain_labelsIThe name of the toolchain implementation target, keyed by toolchain name.
 

toolchain_names �
 //tools/build_defs/repo:http.bzlrd
.
bazel_toolstools/build_defs/repohttp.bzl$
	http_file	http_file
7@
B�
%//docker_compose/private:versions.bzlr�
<
rules_docker_composedocker_compose/privateversions.bzlA
DOCKER_COMPOSE_VERSIONS_DOCKER_COMPOSE_VERSIONS
D\
y1Docker-Compose toolchain repository configuration�
<
rules_docker_composedocker_compose/privateversions.bzl�Docker-Compose Versions

A mapping of platform to integrity of the archive for said platform for each version of Docker-Compose available.
�
=
rules_docker_composedocker_compose/settingssettings.bzl�version$The target version of docker-compose*�
�
version
name	"version"($The target version of docker-compose2G
version<@@rules_docker_compose//docker_compose/settings:settings.bzl
"string_flag2string_flag�
//rules:common_settings.bzlrd
*
bazel_skylibrulescommon_settings.bzl(
string_flagstring_flag

	�
%//docker_compose/private:versions.bzlr�
<
rules_docker_composedocker_compose/privateversions.bzl@
DOCKER_COMPOSE_VERSIONSDOCKER_COMPOSE_VERSIONS

E
\


^`# Docker-Compose settings

Definitions for all `@rules_docker_compose//docker_compose` settings
��
0
rules_docker_composedocker_composedefs.bzl�docker_compose_binary�
Creates a runnable target for invoking docker-compose with a generated configuration.

This rule consumes a `docker_compose_yaml` target and produces an executable that:

1. Loads container images into Docker using the specified loader targets
2. Runs `docker-compose -f <yaml> <args...>` forwarding all command-line arguments

Use this rule when you need to interactively manage docker-compose services
(e.g. `bazel run :compose -- up -d`, `bazel run :compose -- down`).

Supported image loader types:

| Loader | Source |
|--------|--------|
| [oci_load](https://github.com/bazel-contrib/rules_oci/blob/main/docs/load.md#oci_load) | rules_oci |
| [image_load](https://github.com/bazel-contrib/rules_img/blob/main/docs/load.md#image_load) | rules_img |

Example:
```python
load("@rules_docker_compose//docker_compose:defs.bzl", "docker_compose_binary", "docker_compose_yaml")
load("@rules_oci//oci:defs.bzl", "oci_load")

oci_load(
    name = "my_service.load",
    image = ":my_service",
    repo_tags = ["my-service:latest"],
)

docker_compose_yaml(
    name = "compose_yaml",
    yamls = ["docker-compose.yaml"],
    images = [":my_service.load"],
)

docker_compose_binary(
    name = "compose",
    yaml = ":compose_yaml",
    images = [":my_service.load"],
)
```

Then run with:
```bash
bazel run :compose -- up -d
bazel run :compose -- down
bazel run :compose -- ps
```
"�
�
docker_compose_binary�
Creates a runnable target for invoking docker-compose with a generated configuration.

This rule consumes a `docker_compose_yaml` target and produces an executable that:

1. Loads container images into Docker using the specified loader targets
2. Runs `docker-compose -f <yaml> <args...>` forwarding all command-line arguments

Use this rule when you need to interactively manage docker-compose services
(e.g. `bazel run :compose -- up -d`, `bazel run :compose -- down`).

Supported image loader types:

| Loader | Source |
|--------|--------|
| [oci_load](https://github.com/bazel-contrib/rules_oci/blob/main/docs/load.md#oci_load) | rules_oci |
| [image_load](https://github.com/bazel-contrib/rules_img/blob/main/docs/load.md#image_load) | rules_img |

Example:
```python
load("@rules_docker_compose//docker_compose:defs.bzl", "docker_compose_binary", "docker_compose_yaml")
load("@rules_oci//oci:defs.bzl", "oci_load")

oci_load(
    name = "my_service.load",
    image = ":my_service",
    repo_tags = ["my-service:latest"],
)

docker_compose_yaml(
    name = "compose_yaml",
    yamls = ["docker-compose.yaml"],
    images = [":my_service.load"],
)

docker_compose_binary(
    name = "compose",
    yaml = ":compose_yaml",
    images = [":my_service.load"],
)
```

Then run with:
```bash
bazel run :compose -- up -d
bazel run :compose -- down
bazel run :compose -- ps
```
*
nameA unique name for this target. �
images�Image loader targets that provide the container images for the docker-compose services. Each image will be loaded into Docker before docker-compose is invoked. See the rule documentation for supported loader types.2[]v
yamlQA `docker_compose_yaml` target providing the merged docker-compose configuration. *
DockerComposeYamlInfo"H
docker_compose_binary/@@rules_docker_compose//docker_compose:defs.bzl
��,
*
nameA unique name for this target. �
�
images�Image loader targets that provide the container images for the docker-compose services. Each image will be loaded into Docker before docker-compose is invoked. See the rule documentation for supported loader types.2[]x
v
yamlQA `docker_compose_yaml` target providing the merged docker-compose configuration. *
DockerComposeYamlInfo�docker_compose_toolchain�A toolchain for providing Docker-Compose to Bazel rules.

Example:

```python
load("@rules_docker_compose//docker_compose:docker_compose_toolchain.bzl", "docker_compose_toolchain")

filegroup(
    name = "docker_compose_bin",
    srcs = ["docker_compose/docker_compose.exe"],
    # Note that additional runfiles associated with a hermetic archive
    # of docker_compose should be associated with the target passed to the
    # `docker_compose` attribute.
    data = glob(["docker_compose/**"]),
)

docker_compose_toolchain(
    name = "docker_compose_toolchain",
    docker_compose = ":docker_compose_bin",
    visibility = ["//visibility:public"],
)
```

For users looking to use a system install of Docker-Compose, a shell/batch script
should be added that points to the system install.

Example or non-hermetic toolchain:

`docker_compose.sh`
```bash
#!/usr/bin/env bash
set -euo pipefail
exec /usr/bin/docker_compose $@
```

`docker_compose.bat`
```batch
@ECHO OFF
C:\Program Files\Docker\Docker\resources\docker-compose.exe %*
set EXITCODE=%ERRORLEVEL%
exit /b %EXITCODE%
```

```python
load("@rules_docker_compose//docker_compose:docker_compose_toolchain.bzl", "docker_compose_toolchain")

filegroup(
    name = "docker_compose_bin",
    srcs = select({
        "@platforms//os:windows": ["docker_compose.bat"],
        "//conditions:default": ["docker_compose.sh"],
    }),
)

docker_compose_toolchain(
    name = "docker_compose_toolchain",
    docker_compose = ":docker_compose_bin",
    visibility = ["//visibility:public"],
)
```
"�
�
docker_compose_toolchain�A toolchain for providing Docker-Compose to Bazel rules.

Example:

```python
load("@rules_docker_compose//docker_compose:docker_compose_toolchain.bzl", "docker_compose_toolchain")

filegroup(
    name = "docker_compose_bin",
    srcs = ["docker_compose/docker_compose.exe"],
    # Note that additional runfiles associated with a hermetic archive
    # of docker_compose should be associated with the target passed to the
    # `docker_compose` attribute.
    data = glob(["docker_compose/**"]),
)

docker_compose_toolchain(
    name = "docker_compose_toolchain",
    docker_compose = ":docker_compose_bin",
    visibility = ["//visibility:public"],
)
```

For users looking to use a system install of Docker-Compose, a shell/batch script
should be added that points to the system install.

Example or non-hermetic toolchain:

`docker_compose.sh`
```bash
#!/usr/bin/env bash
set -euo pipefail
exec /usr/bin/docker_compose $@
```

`docker_compose.bat`
```batch
@ECHO OFF
C:\Program Files\Docker\Docker\resources\docker-compose.exe %*
set EXITCODE=%ERRORLEVEL%
exit /b %EXITCODE%
```

```python
load("@rules_docker_compose//docker_compose:docker_compose_toolchain.bzl", "docker_compose_toolchain")

filegroup(
    name = "docker_compose_bin",
    srcs = select({
        "@platforms//os:windows": ["docker_compose.bat"],
        "//conditions:default": ["docker_compose.sh"],
    }),
)

docker_compose_toolchain(
    name = "docker_compose_toolchain",
    docker_compose = ":docker_compose_bin",
    visibility = ["//visibility:public"],
)
```
*
nameA unique name for this target. 4
docker_composeThe docker-compose executable. -
versionThe version of docker-compose. "K
docker_compose_toolchain/@@rules_docker_compose//docker_compose:defs.bzl
  ,
*
nameA unique name for this target. 6
4
docker_composeThe docker-compose executable. /
-
versionThe version of docker-compose. �Rdocker_compose_yaml�Merges docker-compose configurations and validates image references.

This rule uses `docker-compose config` to merge one or more docker-compose YAML files
(and/or an inline Starlark configuration) into a single, canonical configuration. It
also validates that all images referenced in the configuration have corresponding loader
targets specified in the `images` attribute.

At least one of `yamls` or `config` must be provided. When both are given, they are
merged together using `docker-compose config` (the `config` JSON is applied on top of
the YAML files).

The merged YAML preserves the original image tags declared in your inputs â it is
diff-reviewable and safe to share outside Bazel (e.g. check it into version control,
hand off to a teammate's `docker compose -f` invocation, etc.).

For each image with a registered loader, the merger ALSO computes a content digest
(`sha256(index.json)` for rules_oci, `sha256(manifest_file)` for rules_img) and emits
a second YAML where `services.*.image` references are rewritten to a content-derived
unique tag of the form `<repo>:rdc-<digest12>`. That rewritten YAML is consumed only
by `docker_compose_test` to isolate parallel test runs on a shared engine.
`docker_compose_binary` (and the default output of this rule) use the original tags.

Supported image loader types:

| Loader | Source |
|--------|--------|
| [oci_load](https://github.com/bazel-contrib/rules_oci/blob/main/docs/load.md#oci_load) | rules_oci |
| [image_load](https://github.com/bazel-contrib/rules_img/blob/main/docs/load.md#image_load) | rules_img |

Example with YAML files:
```python
load("@rules_docker_compose//docker_compose:docker_compose_yaml.bzl", "docker_compose_yaml")
load("@rules_oci//oci:defs.bzl", "oci_load")

oci_load(
    name = "my_image.load",
    image = ":my_image",
    repo_tags = ["my-app:latest"],
)

docker_compose_yaml(
    name = "compose",
    yamls = ["docker-compose.yaml"],
    images = [":my_image.load"],
)
```

Example with inline Starlark config:
```python
load("@rules_docker_compose//docker_compose:docker_compose_config.bzl", "docker_compose_config")
load("@rules_docker_compose//docker_compose:docker_compose_yaml.bzl", "docker_compose_yaml")
load("@rules_oci//oci:defs.bzl", "oci_load")

oci_load(
    name = "nginx.load",
    image = ":nginx",
    repo_tags = ["my-app/nginx:latest"],
)

docker_compose_yaml(
    name = "compose",
    config = docker_compose_config(
        services = {
            "web": {
                "image": "my-app/nginx:latest",
                "ports": ["8080:80"],
            },
        },
    ),
    images = [":nginx.load"],
)
```
"�=
�)
docker_compose_yaml�Merges docker-compose configurations and validates image references.

This rule uses `docker-compose config` to merge one or more docker-compose YAML files
(and/or an inline Starlark configuration) into a single, canonical configuration. It
also validates that all images referenced in the configuration have corresponding loader
targets specified in the `images` attribute.

At least one of `yamls` or `config` must be provided. When both are given, they are
merged together using `docker-compose config` (the `config` JSON is applied on top of
the YAML files).

The merged YAML preserves the original image tags declared in your inputs â it is
diff-reviewable and safe to share outside Bazel (e.g. check it into version control,
hand off to a teammate's `docker compose -f` invocation, etc.).

For each image with a registered loader, the merger ALSO computes a content digest
(`sha256(index.json)` for rules_oci, `sha256(manifest_file)` for rules_img) and emits
a second YAML where `services.*.image` references are rewritten to a content-derived
unique tag of the form `<repo>:rdc-<digest12>`. That rewritten YAML is consumed only
by `docker_compose_test` to isolate parallel test runs on a shared engine.
`docker_compose_binary` (and the default output of this rule) use the original tags.

Supported image loader types:

| Loader | Source |
|--------|--------|
| [oci_load](https://github.com/bazel-contrib/rules_oci/blob/main/docs/load.md#oci_load) | rules_oci |
| [image_load](https://github.com/bazel-contrib/rules_img/blob/main/docs/load.md#image_load) | rules_img |

Example with YAML files:
```python
load("@rules_docker_compose//docker_compose:docker_compose_yaml.bzl", "docker_compose_yaml")
load("@rules_oci//oci:defs.bzl", "oci_load")

oci_load(
    name = "my_image.load",
    image = ":my_image",
    repo_tags = ["my-app:latest"],
)

docker_compose_yaml(
    name = "compose",
    yamls = ["docker-compose.yaml"],
    images = [":my_image.load"],
)
```

Example with inline Starlark config:
```python
load("@rules_docker_compose//docker_compose:docker_compose_config.bzl", "docker_compose_config")
load("@rules_docker_compose//docker_compose:docker_compose_yaml.bzl", "docker_compose_yaml")
load("@rules_oci//oci:defs.bzl", "oci_load")

oci_load(
    name = "nginx.load",
    image = ":nginx",
    repo_tags = ["my-app/nginx:latest"],
)

docker_compose_yaml(
    name = "compose",
    config = docker_compose_config(
        services = {
            "web": {
                "image": "my-app/nginx:latest",
                "ports": ["8080:80"],
            },
        },
    ),
    images = [":nginx.load"],
)
```
*
nameA unique name for this target. �
config�A JSON-encoded docker-compose configuration string. Use `docker_compose_config()` to produce this value from structured Starlark dicts. Can be used alone or combined with `yamls`.2""�
data�Additional files referenced by the docker-compose configuration (e.g. env_file, config files, secret files, bind-mount sources). These are made available during the merge action and propagated to consuming rules for runtime availability.2[]�
images�Image loader targets that provide the container images referenced in the configuration. Each image referenced in the docker-compose config must have a corresponding loader target. See the rule documentation for supported loader types.2[]�
interpolate�Whether to resolve `${VAR}` references when merging.

When `True` (the default), `docker-compose config` interpolates every variable
at build time. Bazel actions run with a sanitized environment, so a variable
that isn't declared in `interpolation_env` resolves to an empty string.

Set to `False` to keep `${VAR}` references verbatim in the merged YAML so
docker-compose resolves them at runtime instead â the right choice for
per-developer or per-machine values like `${USER}`. `services.*.image` is
always resolved at build time regardless, because each image reference must be
matched to a loader target; declare any variables it uses in
`interpolation_env`.
2True�
interpolation_env�Environment variables used to interpolate the compose files at build time.

These are visible only to the merge action, not to the containers. Because the
values are declared in the BUILD file rather than read from the invoking shell,
they keep the merged YAML hermetic and correctly cached.

When `interpolate = False` this applies to `services.*.image` only, since that
is the only field still resolved at build time; every other reference is left
for docker-compose to resolve at runtime.

To set variables the containers see at runtime, use the compose file's own
`environment`/`env_file` keys. To let a variable come from the host at runtime,
set `interpolate = False` and (for `bazel test`) list it in the
`env_inherit` attribute of `docker_compose_test`.

2{}o
outfOptional output filename for the merged docker-compose YAML. Defaults to `{name}/docker-compose.yaml`.�
yamls�One or more docker-compose YAML files to merge. Files are merged in order using `docker-compose config`. At least one of `yamls` or `config` must be provided.2[]"F
docker_compose_yaml/@@rules_docker_compose//docker_compose:defs.bzl
��,
*
nameA unique name for this target. �
�
config�A JSON-encoded docker-compose configuration string. Use `docker_compose_config()` to produce this value from structured Starlark dicts. Can be used alone or combined with `yamls`.2""�
�
data�Additional files referenced by the docker-compose configuration (e.g. env_file, config files, secret files, bind-mount sources). These are made available during the merge action and propagated to consuming rules for runtime availability.2[]�
�
images�Image loader targets that provide the container images referenced in the configuration. Each image referenced in the docker-compose config must have a corresponding loader target. See the rule documentation for supported loader types.2[]�
�
interpolate�Whether to resolve `${VAR}` references when merging.

When `True` (the default), `docker-compose config` interpolates every variable
at build time. Bazel actions run with a sanitized environment, so a variable
that isn't declared in `interpolation_env` resolves to an empty string.

Set to `False` to keep `${VAR}` references verbatim in the merged YAML so
docker-compose resolves them at runtime instead â the right choice for
per-developer or per-machine values like `${USER}`. `services.*.image` is
always resolved at build time regardless, because each image reference must be
matched to a loader target; declare any variables it uses in
`interpolation_env`.
2True�
�
interpolation_env�Environment variables used to interpolate the compose files at build time.

These are visible only to the merge action, not to the containers. Because the
values are declared in the BUILD file rather than read from the invoking shell,
they keep the merged YAML hermetic and correctly cached.

When `interpolate = False` this applies to `services.*.image` only, since that
is the only field still resolved at build time; every other reference is left
for docker-compose to resolve at runtime.

To set variables the containers see at runtime, use the compose file's own
`environment`/`env_file` keys. To let a variable come from the host at runtime,
set `interpolate = False` and (for `bazel test`) list it in the
`env_inherit` attribute of `docker_compose_test`.

2{}q
o
outfOptional output filename for the merged docker-compose YAML. Defaults to `{name}/docker-compose.yaml`.�
�
yamls�One or more docker-compose YAML files to merge. Files are merged in order using `docker-compose config`. At least one of `yamls` or `config` must be provided.2[]�docker_compose_config�Encode a docker-compose configuration as a JSON string.

Parameters mirror the top-level keys of the
[Compose Specification](https://docs.docker.com/reference/compose-file/).
The returned string is suitable for passing to the `config` attribute
of `docker_compose_yaml`.
*�	
�
docker_compose_config�
services�A dict mapping service names to their configuration dicts.
Each value follows the Compose `services.<name>` schema (image,
ports, environment, volumes, depends_on, etc.).{}(z
networkshA dict mapping network names to their configuration dicts.
Follows the Compose `networks.<name>` schema.{}(w
volumesfA dict mapping volume names to their configuration dicts.
Follows the Compose `volumes.<name>` schema.{}(w
configsfA dict mapping config names to their configuration dicts.
Follows the Compose `configs.<name>` schema.{}(w
secretsfA dict mapping secret names to their configuration dicts.
Follows the Compose `secrets.<name>` schema.{}(�Encode a docker-compose configuration as a JSON string.

Parameters mirror the top-level keys of the
[Compose Specification](https://docs.docker.com/reference/compose-file/).
The returned string is suitable for passing to the `config` attribute
of `docker_compose_yaml`.
"F
DA JSON-encoded string representing the docker-compose configuration.2Z
docker_compose_configA@@rules_docker_compose//docker_compose/private:docker_compose.bzl
�
*//docker_compose:docker_compose_binary.bzlr�
A
rules_docker_composedocker_composedocker_compose_binary.bzl=
docker_compose_binary_docker_compose_binary

�
*//docker_compose:docker_compose_config.bzlr�
A
rules_docker_composedocker_composedocker_compose_config.bzl=
docker_compose_config_docker_compose_config
		

�
(//docker_compose:docker_compose_test.bzlr�
?
rules_docker_composedocker_composedocker_compose_test.bzl9
docker_compose_test_docker_compose_test

�
-//docker_compose:docker_compose_toolchain.bzlr�
D
rules_docker_composedocker_composedocker_compose_toolchain.bzlC
docker_compose_toolchain_docker_compose_toolchain

�
(//docker_compose:docker_compose_yaml.bzlr�
?
rules_docker_composedocker_composedocker_compose_yaml.bzl9
docker_compose_yaml_docker_compose_yaml

# Docker Compose�
A
rules_docker_composedocker_composedocker_compose_binary.bzl�docker_compose_binary�
Creates a runnable target for invoking docker-compose with a generated configuration.

This rule consumes a `docker_compose_yaml` target and produces an executable that:

1. Loads container images into Docker using the specified loader targets
2. Runs `docker-compose -f <yaml> <args...>` forwarding all command-line arguments

Use this rule when you need to interactively manage docker-compose services
(e.g. `bazel run :compose -- up -d`, `bazel run :compose -- down`).

Supported image loader types:

| Loader | Source |
|--------|--------|
| [oci_load](https://github.com/bazel-contrib/rules_oci/blob/main/docs/load.md#oci_load) | rules_oci |
| [image_load](https://github.com/bazel-contrib/rules_img/blob/main/docs/load.md#image_load) | rules_img |

Example:
```python
load("@rules_docker_compose//docker_compose:defs.bzl", "docker_compose_binary", "docker_compose_yaml")
load("@rules_oci//oci:defs.bzl", "oci_load")

oci_load(
    name = "my_service.load",
    image = ":my_service",
    repo_tags = ["my-service:latest"],
)

docker_compose_yaml(
    name = "compose_yaml",
    yamls = ["docker-compose.yaml"],
    images = [":my_service.load"],
)

docker_compose_binary(
    name = "compose",
    yaml = ":compose_yaml",
    images = [":my_service.load"],
)
```

Then run with:
```bash
bazel run :compose -- up -d
bazel run :compose -- down
bazel run :compose -- ps
```
"�
�
docker_compose_binary�
Creates a runnable target for invoking docker-compose with a generated configuration.

This rule consumes a `docker_compose_yaml` target and produces an executable that:

1. Loads container images into Docker using the specified loader targets
2. Runs `docker-compose -f <yaml> <args...>` forwarding all command-line arguments

Use this rule when you need to interactively manage docker-compose services
(e.g. `bazel run :compose -- up -d`, `bazel run :compose -- down`).

Supported image loader types:

| Loader | Source |
|--------|--------|
| [oci_load](https://github.com/bazel-contrib/rules_oci/blob/main/docs/load.md#oci_load) | rules_oci |
| [image_load](https://github.com/bazel-contrib/rules_img/blob/main/docs/load.md#image_load) | rules_img |

Example:
```python
load("@rules_docker_compose//docker_compose:defs.bzl", "docker_compose_binary", "docker_compose_yaml")
load("@rules_oci//oci:defs.bzl", "oci_load")

oci_load(
    name = "my_service.load",
    image = ":my_service",
    repo_tags = ["my-service:latest"],
)

docker_compose_yaml(
    name = "compose_yaml",
    yamls = ["docker-compose.yaml"],
    images = [":my_service.load"],
)

docker_compose_binary(
    name = "compose",
    yaml = ":compose_yaml",
    images = [":my_service.load"],
)
```

Then run with:
```bash
bazel run :compose -- up -d
bazel run :compose -- down
bazel run :compose -- ps
```
*
nameA unique name for this target. �
images�Image loader targets that provide the container images for the docker-compose services. Each image will be loaded into Docker before docker-compose is invoked. See the rule documentation for supported loader types.2[]v
yamlQA `docker_compose_yaml` target providing the merged docker-compose configuration. *
DockerComposeYamlInfo"Y
docker_compose_binary@@@rules_docker_compose//docker_compose:docker_compose_binary.bzl
��,
*
nameA unique name for this target. �
�
images�Image loader targets that provide the container images for the docker-compose services. Each image will be loaded into Docker before docker-compose is invoked. See the rule documentation for supported loader types.2[]x
v
yamlQA `docker_compose_yaml` target providing the merged docker-compose configuration. *
DockerComposeYamlInfo�
+//docker_compose/private:docker_compose.bzlr�
B
rules_docker_composedocker_compose/privatedocker_compose.bzl=
docker_compose_binary_docker_compose_binary

# docker_compose_binary�
A
rules_docker_composedocker_composedocker_compose_config.bzl�docker_compose_config�Encode a docker-compose configuration as a JSON string.

Parameters mirror the top-level keys of the
[Compose Specification](https://docs.docker.com/reference/compose-file/).
The returned string is suitable for passing to the `config` attribute
of `docker_compose_yaml`.
*�	
�
docker_compose_config�
services�A dict mapping service names to their configuration dicts.
Each value follows the Compose `services.<name>` schema (image,
ports, environment, volumes, depends_on, etc.).{}(z
networkshA dict mapping network names to their configuration dicts.
Follows the Compose `networks.<name>` schema.{}(w
volumesfA dict mapping volume names to their configuration dicts.
Follows the Compose `volumes.<name>` schema.{}(w
configsfA dict mapping config names to their configuration dicts.
Follows the Compose `configs.<name>` schema.{}(w
secretsfA dict mapping secret names to their configuration dicts.
Follows the Compose `secrets.<name>` schema.{}(�Encode a docker-compose configuration as a JSON string.

Parameters mirror the top-level keys of the
[Compose Specification](https://docs.docker.com/reference/compose-file/).
The returned string is suitable for passing to the `config` attribute
of `docker_compose_yaml`.
"F
DA JSON-encoded string representing the docker-compose configuration.2Z
docker_compose_configA@@rules_docker_compose//docker_compose/private:docker_compose.bzl
�
+//docker_compose/private:docker_compose.bzlr�
B
rules_docker_composedocker_compose/privatedocker_compose.bzl=
docker_compose_config_docker_compose_config

# docker_compose_config�
D
rules_docker_composedocker_composedocker_compose_toolchain.bzl�docker_compose_toolchain�A toolchain for providing Docker-Compose to Bazel rules.

Example:

```python
load("@rules_docker_compose//docker_compose:docker_compose_toolchain.bzl", "docker_compose_toolchain")

filegroup(
    name = "docker_compose_bin",
    srcs = ["docker_compose/docker_compose.exe"],
    # Note that additional runfiles associated with a hermetic archive
    # of docker_compose should be associated with the target passed to the
    # `docker_compose` attribute.
    data = glob(["docker_compose/**"]),
)

docker_compose_toolchain(
    name = "docker_compose_toolchain",
    docker_compose = ":docker_compose_bin",
    visibility = ["//visibility:public"],
)
```

For users looking to use a system install of Docker-Compose, a shell/batch script
should be added that points to the system install.

Example or non-hermetic toolchain:

`docker_compose.sh`
```bash
#!/usr/bin/env bash
set -euo pipefail
exec /usr/bin/docker_compose $@
```

`docker_compose.bat`
```batch
@ECHO OFF
C:\Program Files\Docker\Docker\resources\docker-compose.exe %*
set EXITCODE=%ERRORLEVEL%
exit /b %EXITCODE%
```

```python
load("@rules_docker_compose//docker_compose:docker_compose_toolchain.bzl", "docker_compose_toolchain")

filegroup(
    name = "docker_compose_bin",
    srcs = select({
        "@platforms//os:windows": ["docker_compose.bat"],
        "//conditions:default": ["docker_compose.sh"],
    }),
)

docker_compose_toolchain(
    name = "docker_compose_toolchain",
    docker_compose = ":docker_compose_bin",
    visibility = ["//visibility:public"],
)
```
"�
�
docker_compose_toolchain�A toolchain for providing Docker-Compose to Bazel rules.

Example:

```python
load("@rules_docker_compose//docker_compose:docker_compose_toolchain.bzl", "docker_compose_toolchain")

filegroup(
    name = "docker_compose_bin",
    srcs = ["docker_compose/docker_compose.exe"],
    # Note that additional runfiles associated with a hermetic archive
    # of docker_compose should be associated with the target passed to the
    # `docker_compose` attribute.
    data = glob(["docker_compose/**"]),
)

docker_compose_toolchain(
    name = "docker_compose_toolchain",
    docker_compose = ":docker_compose_bin",
    visibility = ["//visibility:public"],
)
```

For users looking to use a system install of Docker-Compose, a shell/batch script
should be added that points to the system install.

Example or non-hermetic toolchain:

`docker_compose.sh`
```bash
#!/usr/bin/env bash
set -euo pipefail
exec /usr/bin/docker_compose $@
```

`docker_compose.bat`
```batch
@ECHO OFF
C:\Program Files\Docker\Docker\resources\docker-compose.exe %*
set EXITCODE=%ERRORLEVEL%
exit /b %EXITCODE%
```

```python
load("@rules_docker_compose//docker_compose:docker_compose_toolchain.bzl", "docker_compose_toolchain")

filegroup(
    name = "docker_compose_bin",
    srcs = select({
        "@platforms//os:windows": ["docker_compose.bat"],
        "//conditions:default": ["docker_compose.sh"],
    }),
)

docker_compose_toolchain(
    name = "docker_compose_toolchain",
    docker_compose = ":docker_compose_bin",
    visibility = ["//visibility:public"],
)
```
*
nameA unique name for this target. 4
docker_composeThe docker-compose executable. -
versionThe version of docker-compose. "_
docker_compose_toolchainC@@rules_docker_compose//docker_compose:docker_compose_toolchain.bzl
  ,
*
nameA unique name for this target. 6
4
docker_composeThe docker-compose executable. /
-
versionThe version of docker-compose. �
&//docker_compose/private:toolchain.bzlr�
=
rules_docker_composedocker_compose/privatetoolchain.bzlC
docker_compose_toolchain_docker_compose_toolchain

# docker_compose_toolchain�T
?
rules_docker_composedocker_composedocker_compose_yaml.bzl�Rdocker_compose_yaml�Merges docker-compose configurations and validates image references.

This rule uses `docker-compose config` to merge one or more docker-compose YAML files
(and/or an inline Starlark configuration) into a single, canonical configuration. It
also validates that all images referenced in the configuration have corresponding loader
targets specified in the `images` attribute.

At least one of `yamls` or `config` must be provided. When both are given, they are
merged together using `docker-compose config` (the `config` JSON is applied on top of
the YAML files).

The merged YAML preserves the original image tags declared in your inputs â it is
diff-reviewable and safe to share outside Bazel (e.g. check it into version control,
hand off to a teammate's `docker compose -f` invocation, etc.).

For each image with a registered loader, the merger ALSO computes a content digest
(`sha256(index.json)` for rules_oci, `sha256(manifest_file)` for rules_img) and emits
a second YAML where `services.*.image` references are rewritten to a content-derived
unique tag of the form `<repo>:rdc-<digest12>`. That rewritten YAML is consumed only
by `docker_compose_test` to isolate parallel test runs on a shared engine.
`docker_compose_binary` (and the default output of this rule) use the original tags.

Supported image loader types:

| Loader | Source |
|--------|--------|
| [oci_load](https://github.com/bazel-contrib/rules_oci/blob/main/docs/load.md#oci_load) | rules_oci |
| [image_load](https://github.com/bazel-contrib/rules_img/blob/main/docs/load.md#image_load) | rules_img |

Example with YAML files:
```python
load("@rules_docker_compose//docker_compose:docker_compose_yaml.bzl", "docker_compose_yaml")
load("@rules_oci//oci:defs.bzl", "oci_load")

oci_load(
    name = "my_image.load",
    image = ":my_image",
    repo_tags = ["my-app:latest"],
)

docker_compose_yaml(
    name = "compose",
    yamls = ["docker-compose.yaml"],
    images = [":my_image.load"],
)
```

Example with inline Starlark config:
```python
load("@rules_docker_compose//docker_compose:docker_compose_config.bzl", "docker_compose_config")
load("@rules_docker_compose//docker_compose:docker_compose_yaml.bzl", "docker_compose_yaml")
load("@rules_oci//oci:defs.bzl", "oci_load")

oci_load(
    name = "nginx.load",
    image = ":nginx",
    repo_tags = ["my-app/nginx:latest"],
)

docker_compose_yaml(
    name = "compose",
    config = docker_compose_config(
        services = {
            "web": {
                "image": "my-app/nginx:latest",
                "ports": ["8080:80"],
            },
        },
    ),
    images = [":nginx.load"],
)
```
"�=
�)
docker_compose_yaml�Merges docker-compose configurations and validates image references.

This rule uses `docker-compose config` to merge one or more docker-compose YAML files
(and/or an inline Starlark configuration) into a single, canonical configuration. It
also validates that all images referenced in the configuration have corresponding loader
targets specified in the `images` attribute.

At least one of `yamls` or `config` must be provided. When both are given, they are
merged together using `docker-compose config` (the `config` JSON is applied on top of
the YAML files).

The merged YAML preserves the original image tags declared in your inputs â it is
diff-reviewable and safe to share outside Bazel (e.g. check it into version control,
hand off to a teammate's `docker compose -f` invocation, etc.).

For each image with a registered loader, the merger ALSO computes a content digest
(`sha256(index.json)` for rules_oci, `sha256(manifest_file)` for rules_img) and emits
a second YAML where `services.*.image` references are rewritten to a content-derived
unique tag of the form `<repo>:rdc-<digest12>`. That rewritten YAML is consumed only
by `docker_compose_test` to isolate parallel test runs on a shared engine.
`docker_compose_binary` (and the default output of this rule) use the original tags.

Supported image loader types:

| Loader | Source |
|--------|--------|
| [oci_load](https://github.com/bazel-contrib/rules_oci/blob/main/docs/load.md#oci_load) | rules_oci |
| [image_load](https://github.com/bazel-contrib/rules_img/blob/main/docs/load.md#image_load) | rules_img |

Example with YAML files:
```python
load("@rules_docker_compose//docker_compose:docker_compose_yaml.bzl", "docker_compose_yaml")
load("@rules_oci//oci:defs.bzl", "oci_load")

oci_load(
    name = "my_image.load",
    image = ":my_image",
    repo_tags = ["my-app:latest"],
)

docker_compose_yaml(
    name = "compose",
    yamls = ["docker-compose.yaml"],
    images = [":my_image.load"],
)
```

Example with inline Starlark config:
```python
load("@rules_docker_compose//docker_compose:docker_compose_config.bzl", "docker_compose_config")
load("@rules_docker_compose//docker_compose:docker_compose_yaml.bzl", "docker_compose_yaml")
load("@rules_oci//oci:defs.bzl", "oci_load")

oci_load(
    name = "nginx.load",
    image = ":nginx",
    repo_tags = ["my-app/nginx:latest"],
)

docker_compose_yaml(
    name = "compose",
    config = docker_compose_config(
        services = {
            "web": {
                "image": "my-app/nginx:latest",
                "ports": ["8080:80"],
            },
        },
    ),
    images = [":nginx.load"],
)
```
*
nameA unique name for this target. �
config�A JSON-encoded docker-compose configuration string. Use `docker_compose_config()` to produce this value from structured Starlark dicts. Can be used alone or combined with `yamls`.2""�
data�Additional files referenced by the docker-compose configuration (e.g. env_file, config files, secret files, bind-mount sources). These are made available during the merge action and propagated to consuming rules for runtime availability.2[]�
images�Image loader targets that provide the container images referenced in the configuration. Each image referenced in the docker-compose config must have a corresponding loader target. See the rule documentation for supported loader types.2[]�
interpolate�Whether to resolve `${VAR}` references when merging.

When `True` (the default), `docker-compose config` interpolates every variable
at build time. Bazel actions run with a sanitized environment, so a variable
that isn't declared in `interpolation_env` resolves to an empty string.

Set to `False` to keep `${VAR}` references verbatim in the merged YAML so
docker-compose resolves them at runtime instead â the right choice for
per-developer or per-machine values like `${USER}`. `services.*.image` is
always resolved at build time regardless, because each image reference must be
matched to a loader target; declare any variables it uses in
`interpolation_env`.
2True�
interpolation_env�Environment variables used to interpolate the compose files at build time.

These are visible only to the merge action, not to the containers. Because the
values are declared in the BUILD file rather than read from the invoking shell,
they keep the merged YAML hermetic and correctly cached.

When `interpolate = False` this applies to `services.*.image` only, since that
is the only field still resolved at build time; every other reference is left
for docker-compose to resolve at runtime.

To set variables the containers see at runtime, use the compose file's own
`environment`/`env_file` keys. To let a variable come from the host at runtime,
set `interpolate = False` and (for `bazel test`) list it in the
`env_inherit` attribute of `docker_compose_test`.

2{}o
outfOptional output filename for the merged docker-compose YAML. Defaults to `{name}/docker-compose.yaml`.�
yamls�One or more docker-compose YAML files to merge. Files are merged in order using `docker-compose config`. At least one of `yamls` or `config` must be provided.2[]"U
docker_compose_yaml>@@rules_docker_compose//docker_compose:docker_compose_yaml.bzl
��,
*
nameA unique name for this target. �
�
config�A JSON-encoded docker-compose configuration string. Use `docker_compose_config()` to produce this value from structured Starlark dicts. Can be used alone or combined with `yamls`.2""�
�
data�Additional files referenced by the docker-compose configuration (e.g. env_file, config files, secret files, bind-mount sources). These are made available during the merge action and propagated to consuming rules for runtime availability.2[]�
�
images�Image loader targets that provide the container images referenced in the configuration. Each image referenced in the docker-compose config must have a corresponding loader target. See the rule documentation for supported loader types.2[]�
�
interpolate�Whether to resolve `${VAR}` references when merging.

When `True` (the default), `docker-compose config` interpolates every variable
at build time. Bazel actions run with a sanitized environment, so a variable
that isn't declared in `interpolation_env` resolves to an empty string.

Set to `False` to keep `${VAR}` references verbatim in the merged YAML so
docker-compose resolves them at runtime instead â the right choice for
per-developer or per-machine values like `${USER}`. `services.*.image` is
always resolved at build time regardless, because each image reference must be
matched to a loader target; declare any variables it uses in
`interpolation_env`.
2True�
�
interpolation_env�Environment variables used to interpolate the compose files at build time.

These are visible only to the merge action, not to the containers. Because the
values are declared in the BUILD file rather than read from the invoking shell,
they keep the merged YAML hermetic and correctly cached.

When `interpolate = False` this applies to `services.*.image` only, since that
is the only field still resolved at build time; every other reference is left
for docker-compose to resolve at runtime.

To set variables the containers see at runtime, use the compose file's own
`environment`/`env_file` keys. To let a variable come from the host at runtime,
set `interpolate = False` and (for `bazel test`) list it in the
`env_inherit` attribute of `docker_compose_test`.

2{}q
o
outfOptional output filename for the merged docker-compose YAML. Defaults to `{name}/docker-compose.yaml`.�
�
yamls�One or more docker-compose YAML files to merge. Files are merged in order using `docker-compose config`. At least one of `yamls` or `config` must be provided.2[]�
+//docker_compose/private:docker_compose.bzlr�
B
rules_docker_composedocker_compose/privatedocker_compose.bzl9
docker_compose_yaml_docker_compose_yaml

# docker_compose_yaml�
6
rules_docker_composedocker_composeextensions.bzl�docker_compose$Bzlmod extensions for Docker-ComposeJ�

docker_compose$Bzlmod extensions for Docker-Compose"G
docker_compose5@@rules_docker_compose//docker_compose:extensions.bzl
."."�
+//docker_compose/private:toolchain_repo.bzlr�
B
rules_docker_composedocker_compose/privatetoolchain_repo.bzl@
DOCKER_COMPOSE_VERSIONSDOCKER_COMPOSE_VERSIONS
@
PLATFORM_TO_CONSTRAINTSPLATFORM_TO_CONSTRAINTS
`
'docker_compose_toolchain_repository_hub'docker_compose_toolchain_repository_hub
-P
docker_compose_tools_repositorydocker_compose_tools_repository
%
	 Docker-Compose bzlmod extensions`
#
rules_docker_composeversion.bzl	VERSION0.4.0j0.4.0rules_docker_compose version 