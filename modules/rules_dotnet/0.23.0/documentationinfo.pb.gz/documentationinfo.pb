��
dotnetdefs.bzl�blazor_devserver�Serve a Blazor WebAssembly application, with debugging.

Takes anything that produces one, so a publish can be served exactly as it will
be deployed:

```python
publish_binary(
    name = "publish",
    binary = ":app",
    target_framework = "net11.0",
    wasm = True,
)

blazor_devserver(
    name = "serve",
    app = ":publish",
)
```

`bazel run //path/to:serve` then serves it on `http://127.0.0.1:5000/`; pass
`--urls` to change the address."�
�
blazor_devserver�Serve a Blazor WebAssembly application, with debugging.

Takes anything that produces one, so a publish can be served exactly as it will
be deployed:

```python
publish_binary(
    name = "publish",
    binary = ":app",
    target_framework = "net11.0",
    wasm = True,
)

blazor_devserver(
    name = "serve",
    app = ":publish",
)
```

`bazel run //path/to:serve` then serves it on `http://127.0.0.1:5000/`; pass
`--urls` to change the address.*
nameA unique name for this target. �
appoThe application to serve: a `publish_binary` with `wasm = True`, or a binary with `project_sdk = "blazorwasm"`. *J
BlazorWasmSiteInfo4
BlazorWasmSiteInfo//dotnet/private:providers.bzl"?
blazor_devserver+//dotnet/private/rules/blazor:devserver.bzl8,
*
nameA unique name for this target. �
�
appoThe application to serve: a `publish_binary` with `wasm = True`, or a binary with `project_sdk = "blazorwasm"`. *J
BlazorWasmSiteInfo4
BlazorWasmSiteInfo//dotnet/private:providers.bzl�5import_library�Imports prebuilt assemblies, such as the contents of a NuGet package, as a dependency of .NET targets.

`nuget_repo` and the `paket` module extension declare one per package; the
file groups are expected to already be resolved for the target framework and
runtime identifier being built."�3
�
import_library�Imports prebuilt assemblies, such as the contents of a NuGet package, as a dependency of .NET targets.

`nuget_repo` and the `paket` module extension declare one per package; the
file groups are expected to already be resolved for the target framework and
runtime identifier being built.*
nameA unique name for this target. h
library_nameTThe package id. Names the library in the `deps.json` of a binary that depends on it. %
versionThe package version.2""]
typeprovidersFThe design time assemblies of any F# type providers the package ships.2[]a
static_web_assetsFFiles the package serves over HTTP, from its `staticwebassets` folder.2[]�
static_web_assets_base_path�Where `static_web_assets` are served from, as the package's manifest declares it.

`/` is the root, which is where .NET 11 serves a framework's own scripts from.
Empty for `_content/<library_name>`, MSBuild's default.2""T
libsFThe assemblies a binary that depends on this import loads at run time.2[]\
nativeLThe native libraries a binary that depends on this import loads at run time.2[]F
	analyzers3Analyzers and source generators for every language.2[]F
analyzers_csharp,Analyzers and source generators for C# only.2[]0
analyzers_fsharpAnalyzers for F# only.2[]L
analyzers_vb6Analyzers and source generators for Visual Basic only.2[]5
refs'The assemblies the compiler references.2[]f
resource_assembliesILocalized satellite assemblies, each in a folder named after its culture.2[]�
deps1The imports and libraries this import depends on.*�
DotnetAssemblyRuntimeInfo
DotnetAssemblyCompileInfo;
DotnetAssemblyRuntimeInfo//dotnet/private:providers.bzl;
DotnetAssemblyCompileInfo//dotnet/private:providers.bzl2[]-
dataOther files needed at run time.2[]�
targeting_pack_overrides�For a targeting pack: the packages the framework provides itself.

Maps a lower cased package id to the newest version the framework supersedes.
A dependency on that package at or below that version is not referenced.
2{}�
framework_list�For a targeting pack: the assemblies the framework provides.

Maps a lower cased assembly name to the version the framework ships. A
dependency on an assembly of the same name is only referenced when it is
newer.
2{}\
framework_list_file_versions6The file version of each assembly in `framework_list`.
2{}p
framework_list_profilesOThe `;` separated profiles of each assembly in `framework_list` that is in any.
2{}�
 framework_list_analyzer_profilesuThe `;` separated profiles of each analyzer the pack's FrameworkList.xml lists, keyed by its path inside the package.
2{}y
framework_references[The shared frameworks the package needs, from the `<frameworkReferences>` of its `.nuspec`.2[]}
sha512mThe subresource integrity of the `.nupkg`, written to the `deps.json` of binaries that depend on this import.2""D
nupkg3The `.nupkg` this import was unpacked from, if any.2None�
portable_assets�Every runtime's assets of the package, for an app that runs on any runtime.

A .NET tool package ships these. Without them, a tool package that depends on
this import ships `libs` as they are and cannot ship `native`.*T
NuGetPortableAssetsInfo9
NuGetPortableAssetsInfo//dotnet/private:providers.bzl2None":
import_library(//dotnet/private/rules/nuget:imports.bzl,
*
nameA unique name for this target. j
h
library_nameTThe package id. Names the library in the `deps.json` of a binary that depends on it. '
%
versionThe package version.2""_
]
typeprovidersFThe design time assemblies of any F# type providers the package ships.2[]c
a
static_web_assetsFFiles the package serves over HTTP, from its `staticwebassets` folder.2[]�
�
static_web_assets_base_path�Where `static_web_assets` are served from, as the package's manifest declares it.

`/` is the root, which is where .NET 11 serves a framework's own scripts from.
Empty for `_content/<library_name>`, MSBuild's default.2""V
T
libsFThe assemblies a binary that depends on this import loads at run time.2[]^
\
nativeLThe native libraries a binary that depends on this import loads at run time.2[]H
F
	analyzers3Analyzers and source generators for every language.2[]H
F
analyzers_csharp,Analyzers and source generators for C# only.2[]2
0
analyzers_fsharpAnalyzers for F# only.2[]N
L
analyzers_vb6Analyzers and source generators for Visual Basic only.2[]7
5
refs'The assemblies the compiler references.2[]h
f
resource_assembliesILocalized satellite assemblies, each in a folder named after its culture.2[]�
�
deps1The imports and libraries this import depends on.*�
DotnetAssemblyRuntimeInfo
DotnetAssemblyCompileInfo;
DotnetAssemblyRuntimeInfo//dotnet/private:providers.bzl;
DotnetAssemblyCompileInfo//dotnet/private:providers.bzl2[]/
-
dataOther files needed at run time.2[]�
�
targeting_pack_overrides�For a targeting pack: the packages the framework provides itself.

Maps a lower cased package id to the newest version the framework supersedes.
A dependency on that package at or below that version is not referenced.
2{}�
�
framework_list�For a targeting pack: the assemblies the framework provides.

Maps a lower cased assembly name to the version the framework ships. A
dependency on an assembly of the same name is only referenced when it is
newer.
2{}^
\
framework_list_file_versions6The file version of each assembly in `framework_list`.
2{}r
p
framework_list_profilesOThe `;` separated profiles of each assembly in `framework_list` that is in any.
2{}�
�
 framework_list_analyzer_profilesuThe `;` separated profiles of each analyzer the pack's FrameworkList.xml lists, keyed by its path inside the package.
2{}{
y
framework_references[The shared frameworks the package needs, from the `<frameworkReferences>` of its `.nuspec`.2[]
}
sha512mThe subresource integrity of the `.nupkg`, written to the `deps.json` of binaries that depend on this import.2""F
D
nupkg3The `.nupkg` this import was unpacked from, if any.2None�
�
portable_assets�Every runtime's assets of the package, for an app that runs on any runtime.

A .NET tool package ships these. Without them, a tool package that depends on
this import ships `libs` as they are and cannot ship `native`.*T
NuGetPortableAssetsInfo9
NuGetPortableAssetsInfo//dotnet/private:providers.bzl2None�
import_dlldImports a single prebuilt assembly, which is both referenced at compile time and loaded at run time."�
�

import_dlldImports a single prebuilt assembly, which is both referenced at compile time and loaded at run time.*
nameA unique name for this target. J
dll?The assembly. Its file name, less `.dll`, is the assembly name. -
versionThe version of the assembly.2""-
dataOther files needed at run time.2[]"6

import_dll(//dotnet/private/rules/nuget:imports.bzl,
*
nameA unique name for this target. L
J
dll?The assembly. Its file name, less `.dll`, is the assembly name. /
-
versionThe version of the assembly.2""/
-
dataOther files needed at run time.2[]�dotnet_tool�Runs a .NET command-line tool from a NuGet package with the hermetic .NET runtime.

`bazel run` runs the tool in the directory it was invoked from.

The tool runs on the one .NET runtime the toolchain carries, for the newest of
its frameworks that is no newer than that runtime. A tool for an older major
release rolls forward onto the runtime, as `dotnet tool install
--allow-roll-forward` lets it (`DOTNET_ROLL_FORWARD=Major`), unless
`DOTNET_ROLL_FORWARD` is already set in the environment.

Prefer adding the tool to `paket.dependencies`: every dotnet tool in a
dependency group is then available as `@paket.<group>//<package>/tools:<command>`
without declaring this rule."�
�

dotnet_tool�Runs a .NET command-line tool from a NuGet package with the hermetic .NET runtime.

`bazel run` runs the tool in the directory it was invoked from.

The tool runs on the one .NET runtime the toolchain carries, for the newest of
its frameworks that is no newer than that runtime. A tool for an older major
release rolls forward onto the runtime, as `dotnet tool install
--allow-roll-forward` lets it (`DOTNET_ROLL_FORWARD=Major`), unless
`DOTNET_ROLL_FORWARD` is already set in the environment.

Prefer adding the tool to `paket.dependencies`: every dotnet tool in a
dependency group is then available as `@paket.<group>//<package>/tools:<command>`
without declaring this rule.*
nameA unique name for this target. �
target_frameworkslThe frameworks the package ships the tool for. The newest one no newer than the toolchain's runtime is used. �

entrypointtThe file name of the assembly to run, keyed by target framework, as the package's `DotnetToolSettings.xml` names it.
 _
runnerQHow to run the entrypoint, keyed by target framework. Only `dotnet` is supported.
 �
deps4The `tools` target of the package's `nuget_archive`. *P
DotnetToolInfo>
DotnetToolInfo,//dotnet/private/rules/nuget:dotnet_tool.bzl";
dotnet_tool,//dotnet/private/rules/nuget:dotnet_tool.bzl8,
*
nameA unique name for this target. �
�
target_frameworkslThe frameworks the package ships the tool for. The newest one no newer than the toolchain's runtime is used. �
�

entrypointtThe file name of the assembly to run, keyed by target framework, as the package's `DotnetToolSettings.xml` names it.
 a
_
runnerQHow to run the entrypoint, keyed by target framework. Only `dotnet` is supported.
 �
�
deps4The `tools` target of the package's `nuget_archive`. *P
DotnetToolInfo>
DotnetToolInfo,//dotnet/private/rules/nuget:dotnet_tool.bzl�dotnet_content_files�	Groups data files and controls where they are copied next to a consuming assembly.

Reference the target from the `content_files` attribute of a `csharp_library`, `csharp_binary`,
`csharp_test`, `fsharp_library`, `fsharp_binary`, or `fsharp_test`. Each file's destination,
relative to the assembly's directory (`AppContext.BaseDirectory` at run time), is its path
relative to this target's package with `strip_prefix` removed and `prefix` prepended. A file
outside this package's directory starts from its file name.

Like the `Link` metadata of an MSBuild
[`Content`](https://learn.microsoft.com/en-us/visualstudio/msbuild/common-msbuild-project-items#content)
item copied to the output directory, this can flatten a directory, relocate files or re-root a
tree, which plain `content_files` cannot.

Example:

```starlark
load("@rules_dotnet//dotnet:defs.bzl", "csharp_binary", "dotnet_content_files")

# Files live under `assets/` but should ship under `config/` next to the assembly.
dotnet_content_files(
    name = "config",
    srcs = glob(["assets/**"]),
    strip_prefix = "assets",
    prefix = "config",
)

csharp_binary(
    name = "app",
    srcs = ["Program.cs"],
    content_files = [":config"],
)
```"�
�
dotnet_content_files�	Groups data files and controls where they are copied next to a consuming assembly.

Reference the target from the `content_files` attribute of a `csharp_library`, `csharp_binary`,
`csharp_test`, `fsharp_library`, `fsharp_binary`, or `fsharp_test`. Each file's destination,
relative to the assembly's directory (`AppContext.BaseDirectory` at run time), is its path
relative to this target's package with `strip_prefix` removed and `prefix` prepended. A file
outside this package's directory starts from its file name.

Like the `Link` metadata of an MSBuild
[`Content`](https://learn.microsoft.com/en-us/visualstudio/msbuild/common-msbuild-project-items#content)
item copied to the output directory, this can flatten a directory, relocate files or re-root a
tree, which plain `content_files` cannot.

Example:

```starlark
load("@rules_dotnet//dotnet:defs.bzl", "csharp_binary", "dotnet_content_files")

# Files live under `assets/` but should ship under `config/` next to the assembly.
dotnet_content_files(
    name = "config",
    srcs = glob(["assets/**"]),
    strip_prefix = "assets",
    prefix = "config",
)

csharp_binary(
    name = "app",
    srcs = ["Program.cs"],
    content_files = [":config"],
)
```*
nameA unique name for this target. %
srcsThe data files to copy.2[]�
strip_prefix�A leading directory, relative to this target's package, to remove from each file's path. Files outside it keep their whole path.2""t
prefixdA directory, relative to the assembly's directory, to place every file under. Must not contain `..`.2"""N
dotnet_content_files6//dotnet/private/rules/content_files:content_files.bzl,
*
nameA unique name for this target. '
%
srcsThe data files to copy.2[]�
�
strip_prefix�A leading directory, relative to this target's package, to remove from each file's path. Files outside it keep their whole path.2""v
t
prefixdA directory, relative to the assembly's directory, to place every file under. Must not contain `..`.2""�~
nuget_pack�Builds a NuGet package.

From a `library`, a package with the assembly under `lib/<tfm>/` for every
framework in `target_frameworks`, its reference assembly under `ref/<tfm>/`,
its documentation, and a dependency group per framework. From a `binary`, a
.NET tool package (`dotnet tool install`) with the binary's framework-dependent
publish under `tools/<tfm>/any/`.

A tool installs on any operating system, so its publish is portable, as
`dotnet pack` makes it: the NuGet packages it uses bring their RID-agnostic
assemblies and every runtime's native libraries and assemblies, under
`runtimes/<rid>/`, for the host to pick the ones for the machine it runs on.
A native library built in this workspace exists for the runtime being built
alone, so a tool that depends on one fails to pack.

A library built with `is_analyzer` packs as an analyzer package instead:
nothing goes under `lib/`, and the analyzer goes under `analyzers/dotnet/` with
the libraries built in this workspace it depends on and its
`analyzer_runtime_deps`, in the language folder below it when it is
language-specific. A Razor class library ships the files it serves under
`staticwebassets/`, with the MSBuild file that points a consuming project at
them.

The package is `<name>/<package_id>.<version>.nupkg`, deterministic for the
same inputs, and `nuget_push` publishes it. The manifest it carries is also
written on its own, in the `nuspec` output group.

What a dependency of the library becomes:

  * a NuGet package is declared as a dependency;
  * an assembly shipped by a package in `deps` is declared as a dependency on
    that package;
  * an analyzer or source generator built in this workspace, which ran in the
    compiler, is left out unless a package in `deps` ships it;
  * any other library built in this workspace follows `first_party_deps`.

An analyzer resolves none of these: the assemblies the compiler was handed
travel with it, so only the packages listed in `deps` are declared."�n
�>

nuget_pack�Builds a NuGet package.

From a `library`, a package with the assembly under `lib/<tfm>/` for every
framework in `target_frameworks`, its reference assembly under `ref/<tfm>/`,
its documentation, and a dependency group per framework. From a `binary`, a
.NET tool package (`dotnet tool install`) with the binary's framework-dependent
publish under `tools/<tfm>/any/`.

A tool installs on any operating system, so its publish is portable, as
`dotnet pack` makes it: the NuGet packages it uses bring their RID-agnostic
assemblies and every runtime's native libraries and assemblies, under
`runtimes/<rid>/`, for the host to pick the ones for the machine it runs on.
A native library built in this workspace exists for the runtime being built
alone, so a tool that depends on one fails to pack.

A library built with `is_analyzer` packs as an analyzer package instead:
nothing goes under `lib/`, and the analyzer goes under `analyzers/dotnet/` with
the libraries built in this workspace it depends on and its
`analyzer_runtime_deps`, in the language folder below it when it is
language-specific. A Razor class library ships the files it serves under
`staticwebassets/`, with the MSBuild file that points a consuming project at
them.

The package is `<name>/<package_id>.<version>.nupkg`, deterministic for the
same inputs, and `nuget_push` publishes it. The manifest it carries is also
written on its own, in the `nuspec` output group.

What a dependency of the library becomes:

  * a NuGet package is declared as a dependency;
  * an assembly shipped by a package in `deps` is declared as a dependency on
    that package;
  * an analyzer or source generator built in this workspace, which ran in the
    compiler, is left out unless a package in `deps` ships it;
  * any other library built in this workspace follows `first_party_deps`.

An analyzer resolves none of these: the assemblies the compiler was handed
travel with it, so only the packages listed in `deps` are declared.*
nameA unique name for this target. �
libraryqThe library to pack: a package, or an analyzer package when the
library sets `is_analyzer`. Set this or `binary`.*�
DotnetAssemblyCompileInfo
DotnetAssemblyRuntimeInfo;
DotnetAssemblyCompileInfo//dotnet/private:providers.bzl;
DotnetAssemblyRuntimeInfo//dotnet/private:providers.bzl2None�
binary9The binary to pack as a .NET tool. Set this or `library`.*�
DotnetAssemblyCompileInfo
DotnetAssemblyRuntimeInfo
DotnetBinaryInfo;
DotnetAssemblyCompileInfo//dotnet/private:providers.bzl;
DotnetAssemblyRuntimeInfo//dotnet/private:providers.bzl2
DotnetBinaryInfo//dotnet/private:providers.bzl2None�
target_frameworksjThe frameworks the package ships. Each must be one the packed
target lists in its own `target_frameworks`. �
runtime_identifiers�Makes the package RID-specific: the library is built once per
runtime identifier and shipped under `runtimes/<rid>/lib/<tfm>/`, with one
reference assembly under `ref/<tfm>/` to compile against. Native libraries of
the library and of the assemblies bundled with it go under
`runtimes/<rid>/native/`. Each runtime identifier builds the library's whole
dependency graph again, so use this only when the assembly differs per
runtime identifier.2[]�
deps�Other `nuget_pack` targets. A dependency on an assembly one of them
ships is declared as a dependency on that package, and every listed package
is declared as a dependency.*@
NuGetPackInfo/
NuGetPackInfo//dotnet/private:providers.bzl2[]�
first_party_deps�What becomes of a dependency built in this workspace that no package
in `deps` ships. `reference` declares a dependency on a package named after
the assembly, with the assembly's version, which is what a `nuget_pack` of
it defaults to: a workspace that publishes every library as its own package
needs no `deps`. `bundle` copies the assembly into this package and does the
same for its dependencies. `error` fails, so that every such dependency has
to be listed in `deps`.2"reference"J"reference"J"bundle"J"error"B

package_id.The package id. Defaults to the assembly name.2""P
version?The package version. Defaults to the packed target's `version`.2""�
version_file�A file whose first non-empty line is the package version, read when
the package is built, for versions that come from a stamp. The package is then
`<name>/<name>.nupkg`, as its version is not known until it is built. The
packed assemblies keep the version they were compiled with.2None#
authorsThe package authors. 0
descriptionA description of the package. &
titleA human-friendly title.2""%
	copyrightCopyright details.2""8
project_url#The URL of the project's home page.2""6
release_notesRelease notes for this version.2""C
package_tags-Tags for the package, for feeds to search by.2[]r
license_expressionVAn SPDX license expression, such as `MIT` or `Apache-2.0`. Set this or `license_file`.2""]
license_fileEA license file, packed at the root. Set this or `license_expression`.2None8
readme&A Markdown readme, packed at the root.2NoneJ
icon:An icon, packed at the root. PNG or JPEG, ideally 128x128.2NoneN
repository_type2The kind of repository `repository_url` points at.2"git"9
repository_url!The URL of the source repository.2""A
repository_branch&The branch the package was built from.2""A
repository_commit&The commit the package was built from.2""f
require_license_acceptance?Whether a consumer has to accept the license before installing.2Falsep
development_dependencyMMarks a package that is only needed at development time, such as an analyzer.2FalseY
min_client_version=The lowest NuGet client version that can install the package.2""�
files�Further files, keyed by their path in the package and valued by the
targets that go there. A path ending in `/` is a folder that every file of its
targets goes into by name; otherwise the path names one file, so it takes one
target of one file. A target can go to several paths, such as a props file
under both `build/` and `buildTransitive/`:
`{"build/": ["My.props"], "buildTransitive/": ["My.props", ":my_targets"]}`.
Use this for `build/<tfm>/<package_id>.props`, `buildTransitive/`, and the
like. An analyzer that needs an assembly out of a NuGet package ships it
this way, under `analyzers/dotnet/cs/`.2{}�
content_files�Files a consuming project gets, keyed by their path under
`contentFiles/` and valued by the targets that go there. The path is
`<language>/<framework>/<path>`, such as `any/any/settings.json`, and may end
in `/` like in `files`. The `content_files_*` attributes say what a consumer
does with them.2{}�
content_files_build_action=The build action a consuming project gives the content files.2	"Content"J	"Content"J"None"J"EmbeddedResource"J	"Compile"l
content_files_copy_to_outputCWhether a consuming project copies the content files to its output.2FalseR
content_files_flatten0Whether copied content files lose their folders.2False�
symbols�Where the symbols go: nowhere, `embedded` beside the assemblies in the
package, or into a `.snupkg` symbol package next to the package, which
`nuget_push` publishes along with it. A tool package ships its symbols
beside its assemblies, as a publish does, unless they go into a `.snupkg`.2"none"J"none"J
"embedded"J"snupkg"�
reference_assemblies�Whether to ship the reference assembly under `ref/<tfm>/`, so that
consumers compile against the public surface alone. Always on for a
RID-specific package, which has nothing under `lib/` to compile against.2Truem
command_nameWThe command a tool package installs. Defaults to the assembly name. Only with `binary`.2""�
roll_forward_behaviorBThe roll-forward policy of a tool package's runtime configuration.2"Major"J"Minor"J"Major"J"LatestPatch"J"LatestMinor"J"LatestMajor"J	"Disable"">

nuget_pack0//dotnet/private/rules/nuget_pack:nuget_pack.bzl,
*
nameA unique name for this target. �
�
libraryqThe library to pack: a package, or an analyzer package when the
library sets `is_analyzer`. Set this or `binary`.*�
DotnetAssemblyCompileInfo
DotnetAssemblyRuntimeInfo;
DotnetAssemblyCompileInfo//dotnet/private:providers.bzl;
DotnetAssemblyRuntimeInfo//dotnet/private:providers.bzl2None�
�
binary9The binary to pack as a .NET tool. Set this or `library`.*�
DotnetAssemblyCompileInfo
DotnetAssemblyRuntimeInfo
DotnetBinaryInfo;
DotnetAssemblyCompileInfo//dotnet/private:providers.bzl;
DotnetAssemblyRuntimeInfo//dotnet/private:providers.bzl2
DotnetBinaryInfo//dotnet/private:providers.bzl2None�
�
target_frameworksjThe frameworks the package ships. Each must be one the packed
target lists in its own `target_frameworks`. �
�
runtime_identifiers�Makes the package RID-specific: the library is built once per
runtime identifier and shipped under `runtimes/<rid>/lib/<tfm>/`, with one
reference assembly under `ref/<tfm>/` to compile against. Native libraries of
the library and of the assemblies bundled with it go under
`runtimes/<rid>/native/`. Each runtime identifier builds the library's whole
dependency graph again, so use this only when the assembly differs per
runtime identifier.2[]�
�
deps�Other `nuget_pack` targets. A dependency on an assembly one of them
ships is declared as a dependency on that package, and every listed package
is declared as a dependency.*@
NuGetPackInfo/
NuGetPackInfo//dotnet/private:providers.bzl2[]�
�
first_party_deps�What becomes of a dependency built in this workspace that no package
in `deps` ships. `reference` declares a dependency on a package named after
the assembly, with the assembly's version, which is what a `nuget_pack` of
it defaults to: a workspace that publishes every library as its own package
needs no `deps`. `bundle` copies the assembly into this package and does the
same for its dependencies. `error` fails, so that every such dependency has
to be listed in `deps`.2"reference"J"reference"J"bundle"J"error"D
B

package_id.The package id. Defaults to the assembly name.2""R
P
version?The package version. Defaults to the packed target's `version`.2""�
�
version_file�A file whose first non-empty line is the package version, read when
the package is built, for versions that come from a stamp. The package is then
`<name>/<name>.nupkg`, as its version is not known until it is built. The
packed assemblies keep the version they were compiled with.2None%
#
authorsThe package authors. 2
0
descriptionA description of the package. (
&
titleA human-friendly title.2""'
%
	copyrightCopyright details.2"":
8
project_url#The URL of the project's home page.2""8
6
release_notesRelease notes for this version.2""E
C
package_tags-Tags for the package, for feeds to search by.2[]t
r
license_expressionVAn SPDX license expression, such as `MIT` or `Apache-2.0`. Set this or `license_file`.2""_
]
license_fileEA license file, packed at the root. Set this or `license_expression`.2None:
8
readme&A Markdown readme, packed at the root.2NoneL
J
icon:An icon, packed at the root. PNG or JPEG, ideally 128x128.2NoneP
N
repository_type2The kind of repository `repository_url` points at.2"git";
9
repository_url!The URL of the source repository.2""C
A
repository_branch&The branch the package was built from.2""C
A
repository_commit&The commit the package was built from.2""h
f
require_license_acceptance?Whether a consumer has to accept the license before installing.2Falser
p
development_dependencyMMarks a package that is only needed at development time, such as an analyzer.2False[
Y
min_client_version=The lowest NuGet client version that can install the package.2""�
�
files�Further files, keyed by their path in the package and valued by the
targets that go there. A path ending in `/` is a folder that every file of its
targets goes into by name; otherwise the path names one file, so it takes one
target of one file. A target can go to several paths, such as a props file
under both `build/` and `buildTransitive/`:
`{"build/": ["My.props"], "buildTransitive/": ["My.props", ":my_targets"]}`.
Use this for `build/<tfm>/<package_id>.props`, `buildTransitive/`, and the
like. An analyzer that needs an assembly out of a NuGet package ships it
this way, under `analyzers/dotnet/cs/`.2{}�
�
content_files�Files a consuming project gets, keyed by their path under
`contentFiles/` and valued by the targets that go there. The path is
`<language>/<framework>/<path>`, such as `any/any/settings.json`, and may end
in `/` like in `files`. The `content_files_*` attributes say what a consumer
does with them.2{}�
�
content_files_build_action=The build action a consuming project gives the content files.2	"Content"J	"Content"J"None"J"EmbeddedResource"J	"Compile"n
l
content_files_copy_to_outputCWhether a consuming project copies the content files to its output.2FalseT
R
content_files_flatten0Whether copied content files lose their folders.2False�
�
symbols�Where the symbols go: nowhere, `embedded` beside the assemblies in the
package, or into a `.snupkg` symbol package next to the package, which
`nuget_push` publishes along with it. A tool package ships its symbols
beside its assemblies, as a publish does, unless they go into a `.snupkg`.2"none"J"none"J
"embedded"J"snupkg"�
�
reference_assemblies�Whether to ship the reference assembly under `ref/<tfm>/`, so that
consumers compile against the public surface alone. Always on for a
RID-specific package, which has nothing under `lib/` to compile against.2Trueo
m
command_nameWThe command a tool package installs. Defaults to the assembly name. Only with `binary`.2""�
�
roll_forward_behaviorBThe roll-forward policy of a tool package's runtime configuration.2"Major"J"Minor"J"Major"J"LatestPatch"J"LatestMinor"J"LatestMajor"J	"Disable"�
nuget_push�Publishes packages to a NuGet feed when run.

    bazel run //:push
    bazel run //:push -- --api-key <key>
    bazel run //:push -- --source ./local-feed

Runs `dotnet nuget push` from the toolchain's SDK once per package, with a
`.snupkg` built beside a package pushed along with it. Arguments after `--`
go to `dotnet nuget push`; an explicit `--source` or `--api-key` there wins
over the target's `source` and over the `NUGET_API_KEY` environment variable,
which stands in for `--api-key` when set (`NUGET_SYMBOL_API_KEY` likewise for
`--symbol-api-key`). Failing both, credentials come from the user's
`NuGet.Config` as they would for any `dotnet nuget push`. Set
`RULES_DOTNET_NUGET_PUSH_DRY_RUN=1` to print the commands instead of running
them; a key taken from the environment is printed as the variable's name."�
�

nuget_push�Publishes packages to a NuGet feed when run.

    bazel run //:push
    bazel run //:push -- --api-key <key>
    bazel run //:push -- --source ./local-feed

Runs `dotnet nuget push` from the toolchain's SDK once per package, with a
`.snupkg` built beside a package pushed along with it. Arguments after `--`
go to `dotnet nuget push`; an explicit `--source` or `--api-key` there wins
over the target's `source` and over the `NUGET_API_KEY` environment variable,
which stands in for `--api-key` when set (`NUGET_SYMBOL_API_KEY` likewise for
`--symbol-api-key`). Failing both, credentials come from the user's
`NuGet.Config` as they would for any `dotnet nuget push`. Set
`RULES_DOTNET_NUGET_PUSH_DRY_RUN=1` to print the commands instead of running
them; a key taken from the environment is printed as the variable's name.*
nameA unique name for this target. E
packages5The `nuget_pack` targets, or `.nupkg` files, to push. �
source�The feed to push to: a URL such as `https://api.nuget.org/v3/index.json`,
a folder, or the name of a source in `NuGet.Config`. Unset, the feed has to be
given with `--source` when the target is run.2""[
symbol_sourceDA separate feed for the symbol packages. Unset, they go to `source`.2""c
skip_duplicateIWhether a version the feed already has is a warning rather than an error.2True@

no_symbols)Whether to leave the symbol packages out.2FalseS
timeoutCSeconds to wait for a push, or 0 for `dotnet nuget push`'s default.20\
nuget_configDA `NuGet.Config` to use in place of the user's, for a hermetic push.2None">

nuget_push0//dotnet/private/rules/nuget_pack:nuget_push.bzl8,
*
nameA unique name for this target. G
E
packages5The `nuget_pack` targets, or `.nupkg` files, to push. �
�
source�The feed to push to: a URL such as `https://api.nuget.org/v3/index.json`,
a folder, or the name of a source in `NuGet.Config`. Unset, the feed has to be
given with `--source` when the target is run.2""]
[
symbol_sourceDA separate feed for the symbol packages. Unset, they go to `source`.2""e
c
skip_duplicateIWhether a version the feed already has is a warning rather than an error.2TrueB
@

no_symbols)Whether to leave the symbol packages out.2FalseU
S
timeoutCSeconds to wait for a push, or 0 for `dotnet nuget push`'s default.20^
\
nuget_configDA `NuGet.Config` to use in place of the user's, for a hermetic push.2None�resx_resource�Sets a logical name or culture on `.resx` files, or gives them the files they reference.

Pass it in `resources`. Paths are relative to this package.

```starlark
resx_resource(
    name = "messages",
    srcs = ["Messages.resx", "Messages.fr.resx"],
    logical_names = {"Messages.resx": "MyApp.Messages"},
)
```"�
�
resx_resource�Sets a logical name or culture on `.resx` files, or gives them the files they reference.

Pass it in `resources`. Paths are relative to this package.

```starlark
resx_resource(
    name = "messages",
    srcs = ["Messages.resx", "Messages.fr.resx"],
    logical_names = {"Messages.resx": "MyApp.Messages"},
)
```*
nameA unique name for this target. 
srcsThe `.resx` files. Q
dataCFiles referenced by `ResXFileRef` entries, relative to the `.resx`.2[]i
logical_namesRNeutral `.resx` to the `ResourceManager` base name to use. Its cultures follow it.
2{}f
culturesT`.resx` to its culture, or `""` for neutral. Overrides the culture in the file name.
2{}"7
resx_resource&//dotnet/private/rules/common:resx.bzl,
*
nameA unique name for this target.  

srcsThe `.resx` files. S
Q
dataCFiles referenced by `ResXFileRef` entries, relative to the `.resx`.2[]k
i
logical_namesRNeutral `.resx` to the `ResourceManager` base name to use. Its cultures follow it.
2{}h
f
culturesT`.resx` to its culture, or `""` for neutral. Overrides the culture in the file name.
2{}�csharp_binary�Builds a C# executable.

With `project_sdk = "blazorwasm"` it builds a Blazor WebAssembly
application instead, which runs in a browser: `bazel run` serves it with a
development server.
*�
�
csharp_binary
nameThe target name. (*
kwargsPassed to the underlying rule.(�Builds a C# executable.

With `project_sdk = "blazorwasm"` it builds a Blazor WebAssembly
application instead, which runs in a browser: `bazel run` serves it with a
development server.
2"
csharp_binary//dotnet:defs.bzl

nameThe target name. (,
*
kwargsPassed to the underlying rule.(�fsharp_binary]Builds an F# executable.

See `csharp_binary` for what `project_sdk = "blazorwasm"` changes.
*�
�
fsharp_binary
nameThe target name. (*
kwargsPassed to the underlying rule.(]Builds an F# executable.

See `csharp_binary` for what `project_sdk = "blazorwasm"` changes.
2"
fsharp_binary//dotnet:defs.bzl

nameThe target name. (,
*
kwargsPassed to the underlying rule.(�csharp_libraryBuilds a C# library.*�
�
csharp_library
nameThe target name. (*
kwargsPassed to the underlying rule.(Builds a C# library.2#
csharp_library//dotnet:defs.bzl

nameThe target name. (,
*
kwargsPassed to the underlying rule.(�csharp_test-Builds a C# executable and runs it as a test.*�
�
csharp_test
nameThe target name. (*
kwargsPassed to the underlying rule.(-Builds a C# executable and runs it as a test.2 
csharp_test//dotnet:defs.bzl

nameThe target name. (,
*
kwargsPassed to the underlying rule.(�fsharp_libraryBuilds an F# library.*�
�
fsharp_library
nameThe target name. (*
kwargsPassed to the underlying rule.(Builds an F# library.2#
fsharp_library//dotnet:defs.bzl

nameThe target name. (,
*
kwargsPassed to the underlying rule.(�fsharp_test.Builds an F# executable and runs it as a test.*�
�
fsharp_test
nameThe target name. (*
kwargsPassed to the underlying rule.(.Builds an F# executable and runs it as a test.2 
fsharp_test//dotnet:defs.bzl

nameThe target name. (,
*
kwargsPassed to the underlying rule.(�csharp_nunit_test�Builds an NUnit test: a `csharp_test` that runs its tests with NUnitLite.

NUnit and NUnitLite are added to `deps`, and an entry point that runs the
tests to `srcs`.
*�
�
csharp_nunit_test$
kwargsPassed to `csharp_test`.(�Builds an NUnit test: a `csharp_test` that runs its tests with NUnitLite.

NUnit and NUnitLite are added to `deps`, and an entry point that runs the
tests to `srcs`.
2A
csharp_nunit_test,//dotnet/private/rules/csharp:nunit_test.bzl&
$
kwargsPassed to `csharp_test`.(�fsharp_nunit_test�Builds an NUnit test: a `fsharp_test` that runs its tests with NUnitLite.

NUnit and NUnitLite are added to `deps`, and an entry point that runs the
tests to `srcs`.
*�
�
fsharp_nunit_test$
kwargsPassed to `fsharp_test`.(�Builds an NUnit test: a `fsharp_test` that runs its tests with NUnitLite.

NUnit and NUnitLite are added to `deps`, and an entry point that runs the
tests to `srcs`.
2A
fsharp_nunit_test,//dotnet/private/rules/fsharp:nunit_test.bzl&
$
kwargsPassed to `fsharp_test`.(�
nuget_repo�Declares a repository for a set of resolved NuGet packages.

Prefer pointing the `paket` module extension at a `paket.lock` file. This
is the lower level entry point, for a module extension that resolves the
package list some other way.

A package is addressed as `@<name>//<lower cased id>`, and a dotnet tool
it ships as `@<name>//<lower cased id>/tools:<command>`. The dependencies
a package declares resolve among the packages of the same repository; one
that is not listed is left out. A package is only downloaded when a build
needs it.
*�

�

nuget_repo 
nameThe repository name. (�
packages�Dicts describing each resolved package, with keys `id`,
`version` (normalized, e.g. `6.0.0` rather than `6.0`), `sources` (the
feeds to download it from, in order) and optionally `sha512` (the
subresource integrity of the `.nupkg`) and `netrc` (a label of a netrc
file with credentials for the feeds). (�Declares a repository for a set of resolved NuGet packages.

Prefer pointing the `paket` module extension at a `paket.lock` file. This
is the lower level entry point, for a module extension that resolves the
package list some other way.

A package is addressed as `@<name>//<lower cased id>`, and a dotnet tool
it ships as `@<name>//<lower cased id>/tools:<command>`. The dependencies
a package declares resolve among the packages of the same repository; one
that is not listed is left out. A package is only downloaded when a build
needs it.
29

nuget_repo+//dotnet/private/rules/nuget:nuget_repo.bzl"
 
nameThe repository name. (�
�
packages�Dicts describing each resolved package, with keys `id`,
`version` (normalized, e.g. `6.0.0` rather than `6.0`), `sources` (the
feeds to download it from, in order) and optionally `sha512` (the
subresource integrity of the `.nupkg`) and `netrc` (a label of a netrc
file with credentials for the feeds). (�nuget_archive�Downloads one NuGet package and exposes its contents as targets.

Prefer the `paket` module extension or `nuget_repo`, which declare an archive
per package and wire up the dependencies between packages.

Every file of the package is exported by its path in the package, and
`:files` groups all of them. The other targets resolve the package's assets
for the target framework and runtime identifier being built.R�
�
nuget_archive�Downloads one NuGet package and exposes its contents as targets.

Prefer the `paket` module extension or `nuget_repo`, which declare an archive
per package and wire up the dependencies between packages.

Every file of the package is exported by its path in the package, and
`:files` groups all of them. The other targets resolve the package's assets
for the target framework and runtime identifier being built..
name"A unique name for this repository. �
sources�The feeds to download the package from, tried in order.

A URL ending in `index.json` is a NuGet V3 service index; any other URL is a
NuGet V2 feed.2[]d
netrcSA netrc file with the credentials for the feeds. Defaults to the user's netrc file.2None
idThe package id.2""j
versionYThe package version, normalized the way NuGet names its files: `6.0.0` rather than `6.0`.2""�
sha512wThe subresource integrity of the `.nupkg`, e.g. `sha512-<base64>`.

Empty to download the package without verifying it.2""*?
nuget_archive.//dotnet/private/rules/nuget:nuget_archive.bzl0
.
name"A unique name for this repository. �
�
sources�The feeds to download the package from, tried in order.

A URL ending in `index.json` is a NuGet V3 service index; any other URL is a
NuGet V2 feed.2[]f
d
netrcSA netrc file with the credentials for the feeds. Defaults to the user's netrc file.2None

idThe package id.2""l
j
versionYThe package version, normalized the way NuGet names its files: `6.0.0` rather than `6.0`.2""�
�
sha512wThe subresource integrity of the `.nupkg`, e.g. `sha512-<base64>`.

Empty to download the package without verifying it.2""�gpublish_binary�
Publishes a .NET binary for deployment, as `dotnet publish` does.

By default the publish is framework-dependent: a directory holding the
application, its dependencies and an executable that starts it on an installed
.NET runtime. `self_contained` ships the runtime too, `single_file` bundles
everything into one executable, `native_aot` compiles it ahead of time to
native code, `ready_to_run` precompiles the assemblies to shorten startup, and
`wasm` publishes a Blazor WebAssembly application as a static site.

Data files are carried as runfiles; resolve them with the runfiles library.

Except for `wasm`, the publish is also split into the layers of a container
image, each a directory in its `<layer>_layer` output group. Stacked in this
order they give the publish directory:

* `runtime`: the runtime of a self-contained publish, empty otherwise.
* `third_party`: what the application's NuGet packages contribute.
* `first_party`: the libraries built in this repository.
* `app`: the application's assembly, executable, `deps.json`,
  `runtimeconfig.json`, app settings and static web assets.

Together they also hold the runfiles tree beside the executable, each data
file in the layer of the target it belongs to.

A .NET Framework binary is published as its output directory, without PDBs.Z�]
�3
publish_binary�
Publishes a .NET binary for deployment, as `dotnet publish` does.

By default the publish is framework-dependent: a directory holding the
application, its dependencies and an executable that starts it on an installed
.NET runtime. `self_contained` ships the runtime too, `single_file` bundles
everything into one executable, `native_aot` compiles it ahead of time to
native code, `ready_to_run` precompiles the assemblies to shorten startup, and
`wasm` publishes a Blazor WebAssembly application as a static site.

Data files are carried as runfiles; resolve them with the runfiles library.

Except for `wasm`, the publish is also split into the layers of a container
image, each a directory in its `<layer>_layer` output group. Stacked in this
order they give the publish directory:

* `runtime`: the runtime of a self-contained publish, empty otherwise.
* `third_party`: what the application's NuGet packages contribute.
* `first_party`: the libraries built in this repository.
* `app`: the application's assembly, executable, `deps.json`,
  `runtimeconfig.json`, app settings and static web assets.

Together they also hold the runfiles tree beside the executable, each data
file in the layer of the target it belongs to.

A .NET Framework binary is published as its output directory, without PDBs.�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@�
	trim_mode�How much of a published Blazor WebAssembly application is trimmed away.

* `partial` (the default, as in `dotnet publish`): trims the framework and the
  assemblies that declare themselves trimmable, and keeps every other assembly
  whole.
* `full`: trims every assembly. Smaller, but it can remove code that is only
  reached through reflection, and no trim warnings are reported.
* `copyused`: keeps every member of every assembly that is used at all. Worth
  trying if a trimmed application misbehaves.2""8J""J"full"J	"partial"J
"copyused"J"copy"�
application_environment�The hosting environment a Blazor WebAssembly application starts in, as
`IWebAssemblyHostEnvironment.Environment` reports it.

Defaults to `Development` for `bazel run` and to `Production` for a publish.2""8�
invariant_globalization�Run a Blazor WebAssembly application without globalization data.

Culture-sensitive formatting, parsing and comparison then behave as in the
invariant culture. The site no longer downloads the ICU data, at the cost of
culture-correct behaviour.2False8�
wasm�Publish a Blazor WebAssembly application as a static site.

The output is a `wwwroot` directory rather than something to run, so it carries
no apphost and no runtime configuration.2False8
expect_failure2None@ 
transitive_configs2None8@
deprecation2None8@
tags2None8@
testonly2None8@
features2None@
compatible_with2None8@
restricted_to2None8@
package_metadata2None8@
aspect_hints2None@P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@
exec_properties
2None@"
exec_compatible_with2None8@(
exec_group_compatible_with2None8@Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@
args2None@
output_licenses2None@�
binaryThe .NET binary to publish. *F
DotnetBinaryInfo2
DotnetBinaryInfo//dotnet/private:providers.bzl*P
DotnetNativeToolsInfo7
DotnetNativeToolsInfo//dotnet/private:providers.bzl�
self_contained�Ship the .NET runtime with the application.

A framework-dependent publish, the default, needs a matching .NET runtime
installed on the machine it runs on. A self-contained one carries the runtime
for `runtime_identifier` and runs without one.2NoneO
target_framework7The target framework to publish for, such as `net10.0`. �
runtime_identifier�The runtime identifier to publish for, such as `linux-x64`. Defaults to the platform being built for. See https://learn.microsoft.com/en-us/dotnet/core/rid-catalog2None�
roll_forward_behavior�Which installed runtime a framework-dependent publish may run on: https://learn.microsoft.com/en-us/dotnet/core/versions/selection#control-roll-forward-behavior2NoneJ"Minor"J"Major"J"LatestPatch"J"LatestMinor"J"LatestMajor"J	"Disable"�
ready_to_run�Compile the published assemblies to ReadyToRun.

ReadyToRun adds native code alongside the IL so the JIT has less to do at
startup. The published files keep their names; each assembly is replaced by
its compiled image.2None�
ready_to_run_composite�Compile a single composite ReadyToRun image.

One image covers every assembly, framework included, which lets code be
inlined across assembly boundaries. Requires `ready_to_run` and
`self_contained`.2None�

native_aot�Compile the publish ahead of time to a native executable.

The output is one self-contained executable with no IL and no JIT, so there is
no `deps.json`, `runtimeconfig.json` or apphost; native libraries, app
settings, content files and static web assets still sit beside it. Implies
trimming. Needs a C/C++ toolchain registered for the target platform, and a
binary built for .NET 10 or later. Cannot be combined with `ready_to_run` or
`single_file`.2None�
single_file�Bundle the application, its managed dependencies and the runtime into a single executable.

Mirrors MSBuild's `<PublishSingleFile>true</PublishSingleFile>`. Requires
`self_contained`. App settings, content files, static web assets and (unless
`include_native_libraries_for_self_extract` is set) native libraries stay
beside the executable.2None�
)include_native_libraries_for_self_extract�Bundle native libraries too, extracted to disk at startup.

Mirrors MSBuild's `<IncludeNativeLibrariesForSelfExtract>true</IncludeNativeLibrariesForSelfExtract>`.
Requires `single_file`.2None�
!enable_compression_in_single_file�Compress the files bundled into a single-file executable.

Mirrors MSBuild's `<EnableCompressionInSingleFile>true</EnableCompressionInSingleFile>`.
Requires `single_file`.2None"J
publish_binary8//dotnet/private/rules/publish_binary:publish_binary.bzl�
�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �
�

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@�
�
	trim_mode�How much of a published Blazor WebAssembly application is trimmed away.

* `partial` (the default, as in `dotnet publish`): trims the framework and the
  assemblies that declare themselves trimmable, and keeps every other assembly
  whole.
* `full`: trims every assembly. Smaller, but it can remove code that is only
  reached through reflection, and no trim warnings are reported.
* `copyused`: keeps every member of every assembly that is used at all. Worth
  trying if a trimmed application misbehaves.2""8J""J"full"J	"partial"J
"copyused"J"copy"�
�
application_environment�The hosting environment a Blazor WebAssembly application starts in, as
`IWebAssemblyHostEnvironment.Environment` reports it.

Defaults to `Development` for `bazel run` and to `Production` for a publish.2""8�
�
invariant_globalization�Run a Blazor WebAssembly application without globalization data.

Culture-sensitive formatting, parsing and comparison then behave as in the
invariant culture. The site no longer downloads the ICU data, at the cost of
culture-correct behaviour.2False8�
�
wasm�Publish a Blazor WebAssembly application as a static site.

The output is a `wwwroot` directory rather than something to run, so it carries
no apphost and no runtime configuration.2False8

expect_failure2None@"
 
transitive_configs2None8@

deprecation2None8@

tags2None8@

testonly2None8@

features2None@

compatible_with2None8@

restricted_to2None8@ 

package_metadata2None8@

aspect_hints2None@R
P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@

exec_properties
2None@$
"
exec_compatible_with2None8@*
(
exec_group_compatible_with2None8@\
Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@

args2None@

output_licenses2None@�
�
binaryThe .NET binary to publish. *F
DotnetBinaryInfo2
DotnetBinaryInfo//dotnet/private:providers.bzl*P
DotnetNativeToolsInfo7
DotnetNativeToolsInfo//dotnet/private:providers.bzl�
�
self_contained�Ship the .NET runtime with the application.

A framework-dependent publish, the default, needs a matching .NET runtime
installed on the machine it runs on. A self-contained one carries the runtime
for `runtime_identifier` and runs without one.2NoneQ
O
target_framework7The target framework to publish for, such as `net10.0`. �
�
runtime_identifier�The runtime identifier to publish for, such as `linux-x64`. Defaults to the platform being built for. See https://learn.microsoft.com/en-us/dotnet/core/rid-catalog2None�
�
roll_forward_behavior�Which installed runtime a framework-dependent publish may run on: https://learn.microsoft.com/en-us/dotnet/core/versions/selection#control-roll-forward-behavior2NoneJ"Minor"J"Major"J"LatestPatch"J"LatestMinor"J"LatestMajor"J	"Disable"�
�
ready_to_run�Compile the published assemblies to ReadyToRun.

ReadyToRun adds native code alongside the IL so the JIT has less to do at
startup. The published files keep their names; each assembly is replaced by
its compiled image.2None�
�
ready_to_run_composite�Compile a single composite ReadyToRun image.

One image covers every assembly, framework included, which lets code be
inlined across assembly boundaries. Requires `ready_to_run` and
`self_contained`.2None�
�

native_aot�Compile the publish ahead of time to a native executable.

The output is one self-contained executable with no IL and no JIT, so there is
no `deps.json`, `runtimeconfig.json` or apphost; native libraries, app
settings, content files and static web assets still sit beside it. Implies
trimming. Needs a C/C++ toolchain registered for the target platform, and a
binary built for .NET 10 or later. Cannot be combined with `ready_to_run` or
`single_file`.2None�
�
single_file�Bundle the application, its managed dependencies and the runtime into a single executable.

Mirrors MSBuild's `<PublishSingleFile>true</PublishSingleFile>`. Requires
`self_contained`. App settings, content files, static web assets and (unless
`include_native_libraries_for_self_extract` is set) native libraries stay
beside the executable.2None�
�
)include_native_libraries_for_self_extract�Bundle native libraries too, extracted to disk at startup.

Mirrors MSBuild's `<IncludeNativeLibrariesForSelfExtract>true</IncludeNativeLibrariesForSelfExtract>`.
Requires `single_file`.2None�
�
!enable_compression_in_single_file�Compress the files bundled into a single-file executable.

Mirrors MSBuild's `<EnableCompressionInSingleFile>true</EnableCompressionInSingleFile>`.
Requires `single_file`.2None^The public API of rules_dotnet.

Load the rules from here rather than from `//dotnet/private`.�
dotnetextensions.bzl�dotnetJ�
�

dotnet�
	toolchain�The .Net SDK to build with.

When several modules declare one, the module closest to the root wins, so the
root module's choice overrides the default rules_dotnet declares.�
dotnet_version�Version of the .Net SDK, such as `11.0.100`.

Any SDK from .NET 6 onwards in Microsoft's release metadata can be used,
previews included. Its archives and their hashes are looked up there the first
time and recorded in `MODULE.bazel.lock`, after which builds no longer need the
metadata.

Set this or `global_json`.2""�
global_json�A `global.json` whose `sdk.version` is the version of the .Net SDK.

This lets the `dotnet` CLI and IDEs outside Bazel pin the same SDK as the build.
Bazel uses exactly `sdk.version`: `rollForward` and `allowPrerelease` do not
apply. Comments and trailing commas are allowed, as the `dotnet` CLI allows
them. Set this or `dotnet_version`.2None�
bootstrap_toolchainGInternal to rules_dotnet: the SDK that builds rules_dotnet's own tools.�
dotnet_version�Version of the .Net SDK, such as `11.0.100`.

Any SDK from .NET 6 onwards in Microsoft's release metadata can be used,
previews included. Its archives and their hashes are looked up there the first
time and recorded in `MODULE.bazel.lock`, after which builds no longer need the
metadata. "//dotnet:extensions.bzl�
�
	toolchain�The .Net SDK to build with.

When several modules declare one, the module closest to the root wins, so the
root module's choice overrides the default rules_dotnet declares.�
dotnet_version�Version of the .Net SDK, such as `11.0.100`.

Any SDK from .NET 6 onwards in Microsoft's release metadata can be used,
previews included. Its archives and their hashes are looked up there the first
time and recorded in `MODULE.bazel.lock`, after which builds no longer need the
metadata.

Set this or `global_json`.2""�
global_json�A `global.json` whose `sdk.version` is the version of the .Net SDK.

This lets the `dotnet` CLI and IDEs outside Bazel pin the same SDK as the build.
Bazel uses exactly `sdk.version`: `rollForward` and `allowPrerelease` do not
apply. Comments and trailing commas are allowed, as the `dotnet` CLI allows
them. Set this or `dotnet_version`.2None�
�
dotnet_version�Version of the .Net SDK, such as `11.0.100`.

Any SDK from .NET 6 onwards in Microsoft's release metadata can be used,
previews included. Its archives and their hashes are looked up there the first
time and recorded in `MODULE.bazel.lock`, after which builds no longer need the
metadata.

Set this or `global_json`.2""�
�
global_json�A `global.json` whose `sdk.version` is the version of the .Net SDK.

This lets the `dotnet` CLI and IDEs outside Bazel pin the same SDK as the build.
Bazel uses exactly `sdk.version`: `rollForward` and `allowPrerelease` do not
apply. Comments and trailing commas are allowed, as the `dotnet` CLI allows
them. Set this or `dotnet_version`.2None�
�
bootstrap_toolchainGInternal to rules_dotnet: the SDK that builds rules_dotnet's own tools.�
dotnet_version�Version of the .Net SDK, such as `11.0.100`.

Any SDK from .NET 6 onwards in Microsoft's release metadata can be used,
previews included. Its archives and their hashes are looked up there the first
time and recorded in `MODULE.bazel.lock`, after which builds no longer need the
metadata. �
�
dotnet_version�Version of the .Net SDK, such as `11.0.100`.

Any SDK from .NET 6 onwards in Microsoft's release metadata can be used,
previews included. Its archives and their hashes are looked up there the first
time and recorded in `MODULE.bazel.lock`, after which builds no longer need the
metadata. JThe `dotnet` module extension, which registers the .NET SDK to build with.�&
dotnet	paket.bzl� paket/Resolves NuGet packages from a Paket lock file.J� 
�
paket/Resolves NuGet packages from a Paket lock file.�

parseFMakes the dependency groups of a `paket.lock` file available to Bazel.E
lock9The `paket.lock` file to read the resolved packages from. �
dependencies�The `paket.dependencies` the lock file was resolved from.

Optional. When given, a lock file that no longer covers the packages and exact
versions this file asks for is reported with a warning naming the command
that regenerates it.2None�
groups�The dependency groups to make available.

Defaults to every group in the lock file. Listing groups explicitly is useful
to keep test-only groups out of a module's public dependencies, by declaring
them on a second, `dev_dependency = True` usage of this extension.2[]�
repo_prefix�Prepended to the lower cased group name to name its repository.

The `Build` group of a lock file parsed with the default prefix is addressed
as `@paket.build//<package>`. Change it when two lock files in the same build
have a group in common.2"paket."Y
netrcHA netrc file with the credentials for the feeds. Defaults to the user's.2None�
verify_integrity�Whether to verify each package against the hash its feed publishes.

Paket does not record hashes, so they are looked up on the feeds and recorded
in `MODULE.bazel.lock`. A package whose feed publishes no hash, such as one on
a NuGet V2 feed, is pinned by version alone.2True"&$//dotnet/private/paket:extension.bzl�
�

parseFMakes the dependency groups of a `paket.lock` file available to Bazel.E
lock9The `paket.lock` file to read the resolved packages from. �
dependencies�The `paket.dependencies` the lock file was resolved from.

Optional. When given, a lock file that no longer covers the packages and exact
versions this file asks for is reported with a warning naming the command
that regenerates it.2None�
groups�The dependency groups to make available.

Defaults to every group in the lock file. Listing groups explicitly is useful
to keep test-only groups out of a module's public dependencies, by declaring
them on a second, `dev_dependency = True` usage of this extension.2[]�
repo_prefix�Prepended to the lower cased group name to name its repository.

The `Build` group of a lock file parsed with the default prefix is addressed
as `@paket.build//<package>`. Change it when two lock files in the same build
have a group in common.2"paket."Y
netrcHA netrc file with the credentials for the feeds. Defaults to the user's.2None�
verify_integrity�Whether to verify each package against the hash its feed publishes.

Paket does not record hashes, so they are looked up on the feeds and recorded
in `MODULE.bazel.lock`. A package whose feed publishes no hash, such as one on
a NuGet V2 feed, is pinned by version alone.2TrueG
E
lock9The `paket.lock` file to read the resolved packages from. �
�
dependencies�The `paket.dependencies` the lock file was resolved from.

Optional. When given, a lock file that no longer covers the packages and exact
versions this file asks for is reported with a warning naming the command
that regenerates it.2None�
�
groups�The dependency groups to make available.

Defaults to every group in the lock file. Listing groups explicitly is useful
to keep test-only groups out of a module's public dependencies, by declaring
them on a second, `dev_dependency = True` usage of this extension.2[]�
�
repo_prefix�Prepended to the lower cased group name to name its repository.

The `Build` group of a lock file parsed with the default prefix is addressed
as `@paket.build//<package>`. Change it when two lock files in the same build
have a group in common.2"paket."[
Y
netrcHA netrc file with the credentials for the feeds. Defaults to the user's.2None�
�
verify_integrity�Whether to verify each package against the hash its feed publishes.

Paket does not record hashes, so they are looked up on the feeds and recorded
in `MODULE.bazel.lock`. A package whose feed publishes no hash, such as one on
a NuGet V2 feed, is pinned by version alone.2True�The `paket` module extension.

Point it at a [Paket](https://fsprojects.github.io/Paket/) lock file to make
its NuGet packages available to Bazel:

```starlark
paket = use_extension("@rules_dotnet//dotnet:paket.bzl", "paket")
paket.parse(
    dependencies = "//:paket.dependencies",
    lock = "//:paket.lock",
)
use_repo(paket, "paket.main")
```

Each dependency group becomes its own repository, so a package in the `Main`
group is `@paket.main//fsharp.core` and one in a `Build` group is
`@paket.build//fake.core`. A dotnet tool package's commands can be run as
`@paket.<group>//<package>/tools:<command>`. Run `bazel mod tidy` to keep the
`use_repo` call in step with the groups in the lock file.�
dotnetrepositories.bzl�dotnet_sdk_repositories�Declares the per-platform repositories holding one .Net SDK.

Named after the SDK version rather than the toolchain they back, so that two
toolchains pinned to the same version share one download and one extraction,
and so a compile's action key turns on the SDK it used rather than on which
toolchain resolved it.
*�
�
dotnet_sdk_repositoriesc
sdkXThe .Net SDK to fetch, as `resolve_sdk` in
//dotnet/private/sdk:releases.bzl returns it. (3
kwargs'passed to each dotnet_repositories call(�Declares the per-platform repositories holding one .Net SDK.

Named after the SDK version rather than the toolchain they back, so that two
toolchains pinned to the same version share one download and one extraction,
and so a compile's action key turns on the SDK it used rather than on which
toolchain resolved it.
24
dotnet_sdk_repositories//dotnet:repositories.bzle
c
sdkXThe .Net SDK to fetch, as `resolve_sdk` in
//dotnet/private/sdk:releases.bzl returns it. (5
3
kwargs'passed to each dotnet_repositories call(�	dotnet_toolchains_repo�Declares the repository of `toolchain` targets for one .Net SDK.

Holds only the `toolchain` targets Bazel has to analyze up front; the SDK
itself stays in the repositories `dotnet_sdk_repositories` declares, which
are fetched only once a build actually needs them.
*�
�
dotnet_toolchains_repo1
name%The name of the generated repository. (C
dotnet_version-The .Net SDK version the toolchains point at. (
toolchain_type9The toolchain type the generated toolchains register for.0"@rules_dotnet//dotnet/toolchain:toolchain_type"(�Declares the repository of `toolchain` targets for one .Net SDK.

Holds only the `toolchain` targets Bazel has to analyze up front; the SDK
itself stays in the repositories `dotnet_sdk_repositories` declares, which
are fetched only once a build actually needs them.
23
dotnet_toolchains_repo//dotnet:repositories.bzl3
1
name%The name of the generated repository. (E
C
dotnet_version-The .Net SDK version the toolchains point at. (�

toolchain_type9The toolchain type the generated toolchains register for.0"@rules_dotnet//dotnet/toolchain:toolchain_type"(�	dotnet_repositoriesLDownloads the .NET SDK for one platform and declares its `dotnet_toolchain`.R�	
�
dotnet_repositoriesLDownloads the .NET SDK for one platform and declares its `dotnet_toolchain`..
name"A unique name for this repository. 
dotnet_version �
platform J"x86_64-apple-darwin"J"aarch64-apple-darwin"J"x86_64-unknown-linux-gnu"J"arm64-unknown-linux-gnu"J"x86_64-pc-windows-msvc"J"arm64-pc-windows-msvc"V
urlIThe SDK archive for the platform, or empty if it was not released for it.2""7
	integrity$The archive's subresource integrity.2""
runtime_version 
runtime_tfm 
csharp_default_version2""
fsharp_default_version2""*0
dotnet_repositories//dotnet:repositories.bzl0
.
name"A unique name for this repository. 

dotnet_version �
�
platform J"x86_64-apple-darwin"J"aarch64-apple-darwin"J"x86_64-unknown-linux-gnu"J"arm64-unknown-linux-gnu"J"x86_64-pc-windows-msvc"J"arm64-pc-windows-msvc"X
V
urlIThe SDK archive for the platform, or empty if it was not released for it.2""9
7
	integrity$The archive's subresource integrity.2""

runtime_version 

runtime_tfm  

csharp_default_version2"" 

fsharp_default_version2""�Repository rules that download a .NET SDK and declare the toolchains backed by it.

The `dotnet` module extension declares these: register an SDK with
`dotnet.toolchain` rather than calling them directly.�C
!dotnet/toolchaintoolchain.bzl�-dotnet_toolchain�Defines a dotnet compiler/runtime toolchain.

For usage see https://docs.bazel.build/versions/main/toolchains.html#defining-toolchains."�,
�
dotnet_toolchain�Defines a dotnet compiler/runtime toolchain.

For usage see https://docs.bazel.build/versions/main/toolchains.html#defining-toolchains.*
nameA unique name for this target. !
runtimeThe dotnet CLI2None�
compiler_host�The dotnet host a compilation runs on: the muxer, hostfxr and Microsoft.NETCore.App.

Defaults to `runtime`, which also carries the SDK the compilers do not need.2None�
runtime_host�The dotnet host a binary runs on: the muxer, hostfxr and every shared framework.

Defaults to `runtime`, which also carries the SDK a binary does not need.2NoneL
runtime_path6Path to the dotnet CLI. Do not set if `runtime` is set2""1
csharp_compilerThe C# compiler binary2Noned
csharp_compiler_pathFPath to the C# compiler binary. Do not set if `csharp_compiler` is set2""1
fsharp_compilerThe F# compiler binary2Noned
fsharp_compiler_pathFPath to the F# compiler binary. Do not set if `fsharp_compiler` is set2""2

host_modelThe System.NET.HostModel DLL2None�
msbuild_dlls�The SDK's `Microsoft.Build.Framework`, `Microsoft.Build.Utilities.Core` and
`Microsoft.NET.StringTools`, which the rules need to run the SDK's MSBuild tasks.2[]�
static_web_assets_tasks}The `Microsoft.NET.Sdk.StaticWebAssets` task assembly and its dependencies,
which compile the scoped CSS of Razor components.2Nonec
msbuild_tasksJ`Microsoft.Build.Tasks.Core` and its dependencies, for `GenerateResource`.2None�
wpf_build_tasksfThe SDK's `PresentationBuildTasks`, which compile WPF XAML, and the assemblies they load from the SDK.2None�
razor_source_generators�The Razor source generator assemblies, which compile `.razor` and `.cshtml` sources.

As under MSBuild, their version follows the SDK rather than the target
framework.2None�
csharp_net_analyzerscThe C# .NET analyzer assemblies (`CAxxxx`) shipped in the SDK (`Sdks/Microsoft.NET.Sdk/analyzers`).2None�
net_analyzer_configsrThe built-in `.globalconfig` files for the SDK's .NET analyzers (`Sdks/Microsoft.NET.Sdk/analyzers/build/config`).2None�
csharp_codestyle_analyzersmThe C# code style analyzer assemblies (`IDExxxx`) shipped in the SDK (`Sdks/Microsoft.NET.Sdk/codestyle/cs`).2None
web_sdk_analyzersbThe ASP.NET Core and MVC analyzer assemblies shipped in `Sdks/Microsoft.NET.Sdk.Web/analyzers/cs`.2NoneV
os1The operating system the toolchain's tools run on J"linux"J"osx"J	"windows"<
sdk_version)The SDK version of the current dotnet SDK D
runtime_version-The runtime version of the current dotnet SDK Q
runtime_tfm>The runtime target framework moniker of the current dotnet SDK S
csharp_default_version5The default C# version used by the current dotnet SDK S
fsharp_default_version5The default F# version used by the current dotnet SDK "4
dotnet_toolchain //dotnet/toolchain:toolchain.bzl,
*
nameA unique name for this target. #
!
runtimeThe dotnet CLI2None�
�
compiler_host�The dotnet host a compilation runs on: the muxer, hostfxr and Microsoft.NETCore.App.

Defaults to `runtime`, which also carries the SDK the compilers do not need.2None�
�
runtime_host�The dotnet host a binary runs on: the muxer, hostfxr and every shared framework.

Defaults to `runtime`, which also carries the SDK a binary does not need.2NoneN
L
runtime_path6Path to the dotnet CLI. Do not set if `runtime` is set2""3
1
csharp_compilerThe C# compiler binary2Nonef
d
csharp_compiler_pathFPath to the C# compiler binary. Do not set if `csharp_compiler` is set2""3
1
fsharp_compilerThe F# compiler binary2Nonef
d
fsharp_compiler_pathFPath to the F# compiler binary. Do not set if `fsharp_compiler` is set2""4
2

host_modelThe System.NET.HostModel DLL2None�
�
msbuild_dlls�The SDK's `Microsoft.Build.Framework`, `Microsoft.Build.Utilities.Core` and
`Microsoft.NET.StringTools`, which the rules need to run the SDK's MSBuild tasks.2[]�
�
static_web_assets_tasks}The `Microsoft.NET.Sdk.StaticWebAssets` task assembly and its dependencies,
which compile the scoped CSS of Razor components.2Nonee
c
msbuild_tasksJ`Microsoft.Build.Tasks.Core` and its dependencies, for `GenerateResource`.2None�
�
wpf_build_tasksfThe SDK's `PresentationBuildTasks`, which compile WPF XAML, and the assemblies they load from the SDK.2None�
�
razor_source_generators�The Razor source generator assemblies, which compile `.razor` and `.cshtml` sources.

As under MSBuild, their version follows the SDK rather than the target
framework.2None�
�
csharp_net_analyzerscThe C# .NET analyzer assemblies (`CAxxxx`) shipped in the SDK (`Sdks/Microsoft.NET.Sdk/analyzers`).2None�
�
net_analyzer_configsrThe built-in `.globalconfig` files for the SDK's .NET analyzers (`Sdks/Microsoft.NET.Sdk/analyzers/build/config`).2None�
�
csharp_codestyle_analyzersmThe C# code style analyzer assemblies (`IDExxxx`) shipped in the SDK (`Sdks/Microsoft.NET.Sdk/codestyle/cs`).2None�

web_sdk_analyzersbThe ASP.NET Core and MVC analyzer assemblies shipped in `Sdks/Microsoft.NET.Sdk.Web/analyzers/cs`.2NoneX
V
os1The operating system the toolchain's tools run on J"linux"J"osx"J	"windows">
<
sdk_version)The SDK version of the current dotnet SDK F
D
runtime_version-The runtime version of the current dotnet SDK S
Q
runtime_tfm>The runtime target framework moniker of the current dotnet SDK U
S
csharp_default_version5The default C# version used by the current dotnet SDK U
S
fsharp_default_version5The default F# version used by the current dotnet SDK �
DotnetInfo&Information about the dotnet toolchain2�
�


DotnetInfo&Information about the dotnet toolchain-
runtime_pathPath to the dotnet executable�
runtime_files�depset[File]: Files required in runfiles to make the dotnet executable available.

This is the dotnet host and every shared framework, since a binary's
`project_sdk` decides which one it asks for, but not the SDK.

May be empty if the runtime_path points to a locally installed tool binary.:
csharp_compiler_path"Path to the C# compiler executable�
csharp_compiler_files�depset[File]: Files required in runfiles to make the C# compiler executable available.

May be empty if the csharp_compiler_path points to a locally installed tool binary.:
fsharp_compiler_path"Path to the F# compiler executable�
fsharp_compiler_files�depset[File]: Files required in runfiles to make the F# compiler executable available.

May be empty if the fsharp_compiler_path points to a locally installed tool binary.d
os^string: The operating system the toolchain's tools run on, one of
`linux`, `osx` or `windows`.(
sdk_versionVersion of the dotnet SDK0
runtime_versionVersion of the dotnet runtime?
runtime_tfm0The target framework moniker for the current SDK<
csharp_default_version"Default version of the C# language<
fsharp_default_version"Default version of the F# language".

DotnetInfo //dotnet/toolchain:toolchain.bzl/
-
runtime_pathPath to the dotnet executable�
�
runtime_files�depset[File]: Files required in runfiles to make the dotnet executable available.

This is the dotnet host and every shared framework, since a binary's
`project_sdk` decides which one it asks for, but not the SDK.

May be empty if the runtime_path points to a locally installed tool binary.<
:
csharp_compiler_path"Path to the C# compiler executable�
�
csharp_compiler_files�depset[File]: Files required in runfiles to make the C# compiler executable available.

May be empty if the csharp_compiler_path points to a locally installed tool binary.<
:
fsharp_compiler_path"Path to the F# compiler executable�
�
fsharp_compiler_files�depset[File]: Files required in runfiles to make the F# compiler executable available.

May be empty if the fsharp_compiler_path points to a locally installed tool binary.f
d
os^string: The operating system the toolchain's tools run on, one of
`linux`, `osx` or `windows`.*
(
sdk_versionVersion of the dotnet SDK2
0
runtime_versionVersion of the dotnet runtimeA
?
runtime_tfm0The target framework moniker for the current SDK>
<
csharp_default_version"Default version of the C# language>
<
fsharp_default_version"Default version of the F# language6Rules to configure the .NET toolchain of rules_dotnet. 