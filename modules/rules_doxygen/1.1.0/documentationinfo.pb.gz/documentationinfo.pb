�

rules_doxygendoxygen.bzl�doxygen�Generates documentation using Doxygen.

### Example

```starlark
# MODULE.bazel file
bazel_dep(name = "rules_doxygen", dev_dependency = True)
doxygen_extension = use_extension("@rules_doxygen//:extensions.bzl", "doxygen_extension")
use_repo(doxygen_extension, "doxygen")
```

```starlark
# BUILD.bazel file
load("@doxygen//:doxygen.bzl", "doxygen")

doxygen(
    name = "doxygen",
    srcs = glob([
        "*.h",
        "*.cpp",
    ]),
    project_brief = "Example project for doxygen",
    project_name = "example",
)
```
*�
�
doxygen"
nameA name for the target. (A
srcs5A list of source files to generate documentation for. (0
project_nameThe name of the project.None(<
project_brief#A brief description of the project.None(Y
configurationsAA list of additional configuration parameters to pass to Doxygen.[](�
doxyfile_template�The template file to use to generate the Doxyfile.
The following substitutions are available:<br>
- `# {{INPUT}}`: Subpackage directory in the sandbox.<br>
- `# {{ADDITIONAL PARAMETERS}}`: Additional parameters given in the `configurations` attribute.<br>
- `# {{OUTPUT DIRECTORY}}`: The directory provided in the `outs` attribute."@doxygen//:Doxyfile.template"(�
outs�The output folders bazel will keep. If only the html outputs is of interest, the default value will do.
otherwise, a list of folders to keep is expected (e.g. ["html", "latex"]).["html"](�Generates documentation using Doxygen.

### Example

```starlark
# MODULE.bazel file
bazel_dep(name = "rules_doxygen", dev_dependency = True)
doxygen_extension = use_extension("@rules_doxygen//:extensions.bzl", "doxygen_extension")
use_repo(doxygen_extension, "doxygen")
```

```starlark
# BUILD.bazel file
load("@doxygen//:doxygen.bzl", "doxygen")

doxygen(
    name = "doxygen",
    srcs = glob([
        "*.h",
        "*.cpp",
    ]),
    project_brief = "Example project for doxygen",
    project_name = "example",
)
```
2(
doxygen@@rules_doxygen//:doxygen.bzl
VV"_doxygen2_doxygenDoxygen rule for Bazel.�

rules_doxygenextensions.bzl�doxygen_extension�
Module extension for declaring the doxygen version to use.

The resulting repository will have the following targets:
- `@doxygen//:doxygen.bzl`, containing the doxygen macro used to generate the documentation.
- `@doxygen//:Doxyfile.template`, default Doxyfile template used to generate the Doxyfile.

### Example

```starlark
bazel_dep(name = "rules_doxygen", version = "...", dev_dependency = True)

doxygen_extension = use_extension("@rules_doxygen//:extensions.bzl", "doxygen_extension")

# Using the 1.10.0 version of Doxygen on Windows instead of the default 1.11.0
doxygen_extension.version(version = "1.10.0", sha256 = "2135c1d5bdd6e067b3d0c40a4daac5d63d0fee1b3f4d6ef1e4f092db0d632d5b")

use_repo(doxygen_extension, "doxygen")
```
J�

�
doxygen_extension�
Module extension for declaring the doxygen version to use.

The resulting repository will have the following targets:
- `@doxygen//:doxygen.bzl`, containing the doxygen macro used to generate the documentation.
- `@doxygen//:Doxyfile.template`, default Doxyfile template used to generate the Doxyfile.

### Example

```starlark
bazel_dep(name = "rules_doxygen", version = "...", dev_dependency = True)

doxygen_extension = use_extension("@rules_doxygen//:extensions.bzl", "doxygen_extension")

# Using the 1.10.0 version of Doxygen on Windows instead of the default 1.11.0
doxygen_extension.version(version = "1.10.0", sha256 = "2135c1d5bdd6e067b3d0c40a4daac5d63d0fee1b3f4d6ef1e4f092db0d632d5b")

use_repo(doxygen_extension, "doxygen")
```
�
versionh
sha256XThe sha256 hash of the doxygen archive. If not specified, an all-zero hash will be used.2"",
versionThe version of doxygen to use "5
doxygen_extension @@rules_doxygen//:extensions.bzl
>%>%�
�
versionh
sha256XThe sha256 hash of the doxygen archive. If not specified, an all-zero hash will be used.2"",
versionThe version of doxygen to use j
h
sha256XThe sha256 hash of the doxygen archive. If not specified, an all-zero hash will be used.2"".
,
versionThe version of doxygen to use �
 //tools/build_defs/repo:http.bzlrj
.
bazel_toolstools/build_defs/repohttp.bzl*
http_archivehttp_archive
7C
EWRepository rule for downloading the correct version of doxygen using module extensions. 