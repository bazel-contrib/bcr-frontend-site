�&

rules_doxygendoxygen.bzl�%doxygen�Generates documentation using Doxygen.

### Example

```starlark
# MODULE.bazel file
bazel_dep(name = "rules_doxygen", dev_dependency = True)
doxygen_extension = use_extension("@rules_doxygen//:extensions.bzl", "doxygen_extension")
use_repo(doxygen_extension, "doxygen")
```

```starlark
# BUILD.bazel file
load("@doxygen//:doxygen.bzl", "doxygen")

doxygen(
    name = "doxygen",
    srcs = glob([
        "*.h",
        "*.cpp",
    ]),
    project_brief = "Example project for doxygen",
    project_name = "example",
)
```


Run the doxygen binary to generate the documentation.

It is advised to use the `doxygen` macro instead of this rule directly.

### Example

```starlark
# MODULE.bazel file
bazel_dep(name = "rules_doxygen", dev_dependency = True)
doxygen_extension = use_extension("@rules_doxygen//:extensions.bzl", "doxygen_extension")
use_repo(doxygen_extension, "doxygen")
```

```starlark
# BUILD.bazel file
load("@doxygen//:doxygen.bzl", "doxygen")

doxygen(
    name = "doxygen",
    srcs = glob([
        "*.h",
        "*.cpp",
    ]),
    project_brief = "Example project for doxygen",
    project_name = "example",
)
```
"�
�
doxygen�Generates documentation using Doxygen.

### Example

```starlark
# MODULE.bazel file
bazel_dep(name = "rules_doxygen", dev_dependency = True)
doxygen_extension = use_extension("@rules_doxygen//:extensions.bzl", "doxygen_extension")
use_repo(doxygen_extension, "doxygen")
```

```starlark
# BUILD.bazel file
load("@doxygen//:doxygen.bzl", "doxygen")

doxygen(
    name = "doxygen",
    srcs = glob([
        "*.h",
        "*.cpp",
    ]),
    project_brief = "Example project for doxygen",
    project_name = "example",
)
```


Run the doxygen binary to generate the documentation.

It is advised to use the `doxygen` macro instead of this rule directly.

### Example

```starlark
# MODULE.bazel file
bazel_dep(name = "rules_doxygen", dev_dependency = True)
doxygen_extension = use_extension("@rules_doxygen//:extensions.bzl", "doxygen_extension")
use_repo(doxygen_extension, "doxygen")
```

```starlark
# BUILD.bazel file
load("@doxygen//:doxygen.bzl", "doxygen")

doxygen(
    name = "doxygen",
    srcs = glob([
        "*.h",
        "*.cpp",
    ]),
    project_brief = "Example project for doxygen",
    project_name = "example",
)
```
*
nameA unique name for this target. �
configurations�Additional configuration parameters to append to the Doxyfile. For example, to set the project name, use `PROJECT_NAME = example`.2[]V
dot_executable<The dot executable to use. Must refer to an executable file.2None�
doxyfile_template�The template file to use to generate the Doxyfile. You can provide your own or use the default one. 
The following substitutions are available: 
- `# {{INPUT}}`: Subpackage directory in the sandbox.
- `# {{DOT_PATH}}`: Indicate to doxygen the location of the `dot_executable`
- `# {{ADDITIONAL PARAMETERS}}`: Additional parameters given in the `configurations` attribute.
- `# {{OUTPUT DIRECTORY}}`: The directory provided in the `outs` attribute.
2@@doxygen//:Doxyfile.templateN
doxygen_extra_args2Extra arguments to pass to the doxygen executable.2[]�
outs�The output folders to keep. If only the html outputs is of interest, the default value will do. Otherwise, a list of folders to keep is expected (e.g. `["html", "latex"]`).2["html"]�
srcs}The source files to generate documentation for. Can include header files, source files, and any other file Doxygen can parse.2[]")
_doxygen@@rules_doxygen//:doxygen.bzl
]],
*
nameA unique name for this target. �
�
configurations�Additional configuration parameters to append to the Doxyfile. For example, to set the project name, use `PROJECT_NAME = example`.2[]X
V
dot_executable<The dot executable to use. Must refer to an executable file.2None�
�
doxyfile_template�The template file to use to generate the Doxyfile. You can provide your own or use the default one. 
The following substitutions are available: 
- `# {{INPUT}}`: Subpackage directory in the sandbox.
- `# {{DOT_PATH}}`: Indicate to doxygen the location of the `dot_executable`
- `# {{ADDITIONAL PARAMETERS}}`: Additional parameters given in the `configurations` attribute.
- `# {{OUTPUT DIRECTORY}}`: The directory provided in the `outs` attribute.
2@@doxygen//:Doxyfile.templateP
N
doxygen_extra_args2Extra arguments to pass to the doxygen executable.2[]�
�
outs�The output folders to keep. If only the html outputs is of interest, the default value will do. Otherwise, a list of folders to keep is expected (e.g. `["html", "latex"]`).2["html"]�
�
srcs}The source files to generate documentation for. Can include header files, source files, and any other file Doxygen can parse.2[]Doxygen rule for Bazel.�:

rules_doxygenextensions.bzl�local_repository_doxygen�
Repository rule for doxygen.

Used to create a local repository for doxygen, containing the installed doxygen binary and all the necessary files to run the doxygen macro.
In order to use this rule, you must have doxygen installed on your system and the binary (named doxygen) must available in the PATH.
Keep in mind that this will break the hermeticity of your build, as it will now depend on the environment.

### Example

```starlark
local_repository_doxygen(
    name = "doxygen",
)
```
R�
�
local_repository_doxygen�
Repository rule for doxygen.

Used to create a local repository for doxygen, containing the installed doxygen binary and all the necessary files to run the doxygen macro.
In order to use this rule, you must have doxygen installed on your system and the binary (named doxygen) must available in the PATH.
Keep in mind that this will break the hermeticity of your build, as it will now depend on the environment.

### Example

```starlark
local_repository_doxygen(
    name = "doxygen",
)
```
.
name"A unique name for this repository. R
build The BUILD file of the repository2%@@rules_doxygen//:doxygen.BUILD.bazelX
doxyfile_templateThe Doxyfile template to use2#@@rules_doxygen//:Doxyfile.template^
doxygen_bzl.The starlark file containing the doxygen macro2@@rules_doxygen//:doxygen.bzl�

executablepThe doxygen executable to use. Must refer to an executable file. Defaults to the doxygen executable in the PATH.2None�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 *<
local_repository_doxygen @@rules_doxygen//:extensions.bzl
 + +0
.
name"A unique name for this repository. T
R
build The BUILD file of the repository2%@@rules_doxygen//:doxygen.BUILD.bazelZ
X
doxyfile_templateThe Doxyfile template to use2#@@rules_doxygen//:Doxyfile.template`
^
doxygen_bzl.The starlark file containing the doxygen macro2@@rules_doxygen//:doxygen.bzl�
�

executablepThe doxygen executable to use. Must refer to an executable file. Defaults to the doxygen executable in the PATH.2None�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �!doxygen_extension�
Module extension for declaring the doxygen version to use.

The resulting repository will have the following targets:
- `@doxygen//:doxygen.bzl`, containing the doxygen macro used to generate the documentation.
- `@doxygen//:Doxyfile.template`, default Doxyfile template used to generate the Doxyfile.

By default, version `1.12.0` of Doxygen is used. To select a different version, indicate it in the `version` module:

If you don't know the SHA256 of the Doxygen binary, just leave it empty.
The build will fail with an error message containing the correct SHA256.

```bash
Download from https://github.com/doxygen/doxygen/releases/download/Release_1_10_0/doxygen-1.10.0.windows.x64.bin.zip failed: class com.google.devtools.build.lib.bazel.repository.downloader.UnrecoverableHttpException Checksum was 2135c1d5bdd6e067b3d0c40a4daac5d63d0fee1b3f4d6ef1e4f092db0d632d5b but wanted 0000000000000000000000000000000000000000000000000000000000000000
```

If you set the version to `0.0.0`, the doxygen executable will be assumed to be available from the PATH.
No download will be performed and bazel will use the installed version of doxygen.
Keep in mind that this will break the hermeticity of your build, as it will now depend on the environment.

### Example

```starlark
bazel_dep(name = "rules_doxygen", version = "...", dev_dependency = True)

doxygen_extension = use_extension("@rules_doxygen//:extensions.bzl", "doxygen_extension")

# Using the 1.10.0 version of Doxygen on Windows instead of the default 1.12.0
doxygen_extension.version(version = "1.10.0", sha256 = "2135c1d5bdd6e067b3d0c40a4daac5d63d0fee1b3f4d6ef1e4f092db0d632d5b")

use_repo(doxygen_extension, "doxygen")
```
J�
�
doxygen_extension�
Module extension for declaring the doxygen version to use.

The resulting repository will have the following targets:
- `@doxygen//:doxygen.bzl`, containing the doxygen macro used to generate the documentation.
- `@doxygen//:Doxyfile.template`, default Doxyfile template used to generate the Doxyfile.

By default, version `1.12.0` of Doxygen is used. To select a different version, indicate it in the `version` module:

If you don't know the SHA256 of the Doxygen binary, just leave it empty.
The build will fail with an error message containing the correct SHA256.

```bash
Download from https://github.com/doxygen/doxygen/releases/download/Release_1_10_0/doxygen-1.10.0.windows.x64.bin.zip failed: class com.google.devtools.build.lib.bazel.repository.downloader.UnrecoverableHttpException Checksum was 2135c1d5bdd6e067b3d0c40a4daac5d63d0fee1b3f4d6ef1e4f092db0d632d5b but wanted 0000000000000000000000000000000000000000000000000000000000000000
```

If you set the version to `0.0.0`, the doxygen executable will be assumed to be available from the PATH.
No download will be performed and bazel will use the installed version of doxygen.
Keep in mind that this will break the hermeticity of your build, as it will now depend on the environment.

### Example

```starlark
bazel_dep(name = "rules_doxygen", version = "...", dev_dependency = True)

doxygen_extension = use_extension("@rules_doxygen//:extensions.bzl", "doxygen_extension")

# Using the 1.10.0 version of Doxygen on Windows instead of the default 1.12.0
doxygen_extension.version(version = "1.10.0", sha256 = "2135c1d5bdd6e067b3d0c40a4daac5d63d0fee1b3f4d6ef1e4f092db0d632d5b")

use_repo(doxygen_extension, "doxygen")
```
�
versionh
sha256XThe sha256 hash of the doxygen archive. If not specified, an all-zero hash will be used.2""�
versionvThe version of doxygen to use. If set to `0.0.0`, the doxygen executable will be assumed to be available from the PATH "5
doxygen_extension @@rules_doxygen//:extensions.bzl
�%�%�
�
versionh
sha256XThe sha256 hash of the doxygen archive. If not specified, an all-zero hash will be used.2""�
versionvThe version of doxygen to use. If set to `0.0.0`, the doxygen executable will be assumed to be available from the PATH j
h
sha256XThe sha256 hash of the doxygen archive. If not specified, an all-zero hash will be used.2""�
�
versionvThe version of doxygen to use. If set to `0.0.0`, the doxygen executable will be assumed to be available from the PATH �
 //tools/build_defs/repo:http.bzlrj
.
bazel_toolstools/build_defs/repohttp.bzl*
http_archivehttp_archive
7C
EWRepository rule for downloading the correct version of doxygen using module extensions. 