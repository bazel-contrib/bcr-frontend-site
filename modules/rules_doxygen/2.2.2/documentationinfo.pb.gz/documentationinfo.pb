�1
%
rules_doxygendoxygendoxygen.bzl�1doxygen�Generates documentation using Doxygen.

The set of attributes the macro provides is a subset of the Doxygen configuration options.
Depending on the type of the attribute, the macro will convert it to the appropriate string:

- None (default): the attribute will not be included in the Doxyfile
- bool: the value of the attribute is the string "YES" or "NO" respectively
- list: the value of the attribute is a string with the elements separated by spaces and enclosed in double quotes
- str: the value of the attribute is will be set to the string, unchanged. You may need to provide proper quoting if the value contains spaces

### Example

```starlark
# MODULE.bazel file
bazel_dep(name = "rules_doxygen", dev_dependency = True)
doxygen_extension = use_extension("@rules_doxygen//:extensions.bzl", "doxygen_extension")
use_repo(doxygen_extension, "doxygen")
```

```starlark
# BUILD.bazel file
load("@doxygen//:doxygen.bzl", "doxygen")

doxygen(
    name = "doxygen",
    srcs = glob([
        "*.h",
        "*.cpp",
    ]),
    aliases = [
        "licence=@par Licence:^^",
        "verb{1}=@verbatim \\1 @endverbatim",
    ],
    optimize_output_for_c = True,
    project_brief = "Example project for doxygen",
    project_name = "example",
)
```


Run the doxygen binary to generate the documentation.

It is advised to use the `doxygen` macro instead of this rule directly.

### Example

```starlark
# MODULE.bazel file
bazel_dep(name = "rules_doxygen", dev_dependency = True)
doxygen_extension = use_extension("@rules_doxygen//:extensions.bzl", "doxygen_extension")
use_repo(doxygen_extension, "doxygen")
```

```starlark
# BUILD.bazel file
load("@doxygen//:doxygen.bzl", "doxygen")

doxygen(
    name = "doxygen",
    srcs = glob([
        "*.h",
        "*.cpp",
    ]),
    project_brief = "Example project for doxygen",
    project_name = "example",
)
```
"�"
�
doxygen�Generates documentation using Doxygen.

The set of attributes the macro provides is a subset of the Doxygen configuration options.
Depending on the type of the attribute, the macro will convert it to the appropriate string:

- None (default): the attribute will not be included in the Doxyfile
- bool: the value of the attribute is the string "YES" or "NO" respectively
- list: the value of the attribute is a string with the elements separated by spaces and enclosed in double quotes
- str: the value of the attribute is will be set to the string, unchanged. You may need to provide proper quoting if the value contains spaces

### Example

```starlark
# MODULE.bazel file
bazel_dep(name = "rules_doxygen", dev_dependency = True)
doxygen_extension = use_extension("@rules_doxygen//:extensions.bzl", "doxygen_extension")
use_repo(doxygen_extension, "doxygen")
```

```starlark
# BUILD.bazel file
load("@doxygen//:doxygen.bzl", "doxygen")

doxygen(
    name = "doxygen",
    srcs = glob([
        "*.h",
        "*.cpp",
    ]),
    aliases = [
        "licence=@par Licence:^^",
        "verb{1}=@verbatim \\1 @endverbatim",
    ],
    optimize_output_for_c = True,
    project_brief = "Example project for doxygen",
    project_name = "example",
)
```


Run the doxygen binary to generate the documentation.

It is advised to use the `doxygen` macro instead of this rule directly.

### Example

```starlark
# MODULE.bazel file
bazel_dep(name = "rules_doxygen", dev_dependency = True)
doxygen_extension = use_extension("@rules_doxygen//:extensions.bzl", "doxygen_extension")
use_repo(doxygen_extension, "doxygen")
```

```starlark
# BUILD.bazel file
load("@doxygen//:doxygen.bzl", "doxygen")

doxygen(
    name = "doxygen",
    srcs = glob([
        "*.h",
        "*.cpp",
    ]),
    project_brief = "Example project for doxygen",
    project_name = "example",
)
```
*
nameA unique name for this target. �
configurations�Additional configuration parameters to append to the Doxyfile. For example, to set the project name, use `PROJECT_NAME = example`.2[]V
dot_executable<The dot executable to use. Must refer to an executable file.2None�
doxyfile_template�The template file to use to generate the Doxyfile. You can provide your own or use the default one. 
The following substitutions are available: 
- `# {{INPUT}}`: Subpackage directory in the sandbox.
- `# {{DOT_PATH}}`: Indicate to doxygen the location of the `dot_executable`
- `# {{ADDITIONAL PARAMETERS}}`: Additional parameters given in the `configurations` attribute.
- `# {{OUTPUT DIRECTORY}}`: The directory provided in the `outs` attribute.
2*@@rules_doxygen//doxygen:Doxyfile.templateN
doxygen_extra_args2Extra arguments to pass to the doxygen executable.2[]�
outs�The output folders to keep. If only the html outputs is of interest, the default value will do. Otherwise, a list of folders to keep is expected (e.g. `["html", "latex"]`).2["html"]�
srcs}The source files to generate documentation for. Can include header files, source files, and any other file Doxygen can parse.2[]"0
_doxygen$@@rules_doxygen//doxygen:doxygen.bzl
��,
*
nameA unique name for this target. �
�
configurations�Additional configuration parameters to append to the Doxyfile. For example, to set the project name, use `PROJECT_NAME = example`.2[]X
V
dot_executable<The dot executable to use. Must refer to an executable file.2None�
�
doxyfile_template�The template file to use to generate the Doxyfile. You can provide your own or use the default one. 
The following substitutions are available: 
- `# {{INPUT}}`: Subpackage directory in the sandbox.
- `# {{DOT_PATH}}`: Indicate to doxygen the location of the `dot_executable`
- `# {{ADDITIONAL PARAMETERS}}`: Additional parameters given in the `configurations` attribute.
- `# {{OUTPUT DIRECTORY}}`: The directory provided in the `outs` attribute.
2*@@rules_doxygen//doxygen:Doxyfile.templateP
N
doxygen_extra_args2Extra arguments to pass to the doxygen executable.2[]�
�
outs�The output folders to keep. If only the html outputs is of interest, the default value will do. Otherwise, a list of folders to keep is expected (e.g. `["html", "latex"]`).2["html"]�
�
srcs}The source files to generate documentation for. Can include header files, source files, and any other file Doxygen can parse.2[]Doxygen rule for Bazel.�$
B
rules_doxygenexamples/substitutionsmake_var_substitution.bzl�!make_var_substitution�	Provides a set of variables to the template engine.
Any variable defined as $(VAR_NAME) in the rule using this as a toolchain will be replaced by the value of VAR_NAME.
It provides the following substitution variables by default:

- build_description: The version of the build. If the build is stamped, it will be taken from --stamp-version. Otherwise, it will be "0.0.0".

Example:

```bzl
filegroup(
    name = "header",
    srcs = ["header.html"],
)

make_var_substitution(
    variables = {
        "MY_VARIABLE": "my_value",
        "VERSION": "1.0.0",
    },
    locations = {
        "HEADER": ":header",
    },
)

doxygen(
    name = "doxygen",
    srcs = ["main.cpp", ":header"],
    project_brief = "$(MY_VARIABLE)", # => "my_value"
    project_number = "$(VERSION)", # => "1.0.0"
    html_header = "$(HEADER)", # => "header.html"
    toolchains = [":make_var_substitution"],
)
```

This will make the variable `MY_VARIABLE` available to the template engine
and replace it with the value `my_value` in the generated files.
It will also make the variable `HEADER` available to the template engine
and replace it with the path to the file `header.html` generated by the rule `header`.
"�
�
make_var_substitution�	Provides a set of variables to the template engine.
Any variable defined as $(VAR_NAME) in the rule using this as a toolchain will be replaced by the value of VAR_NAME.
It provides the following substitution variables by default:

- build_description: The version of the build. If the build is stamped, it will be taken from --stamp-version. Otherwise, it will be "0.0.0".

Example:

```bzl
filegroup(
    name = "header",
    srcs = ["header.html"],
)

make_var_substitution(
    variables = {
        "MY_VARIABLE": "my_value",
        "VERSION": "1.0.0",
    },
    locations = {
        "HEADER": ":header",
    },
)

doxygen(
    name = "doxygen",
    srcs = ["main.cpp", ":header"],
    project_brief = "$(MY_VARIABLE)", # => "my_value"
    project_number = "$(VERSION)", # => "1.0.0"
    html_header = "$(HEADER)", # => "header.html"
    toolchains = [":make_var_substitution"],
)
```

This will make the variable `MY_VARIABLE` available to the template engine
and replace it with the value `my_value` in the generated files.
It will also make the variable `HEADER` available to the template engine
and replace it with the path to the file `header.html` generated by the rule `header`.
*
nameA unique name for this target. 
	locations	2{}�
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.
2-1
	variables
2{}"Z
make_var_substitutionA@@rules_doxygen//examples/substitutions:make_var_substitution.bzl
,
*
nameA unique name for this target. 

	locations	2{}�
�
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.
2-1

	variables
2{}�
//lib:stamping.bzlr�
%
aspect_bazel_liblibstamping.bzl(
STAMP_ATTRSSTAMP_ATTRS
.9(
maybe_stampmaybe_stamp
=H
J�
//rules:common_settings.bzlrn
*
bazel_skylibrulescommon_settings.bzl2
BuildSettingInfoBuildSettingInfo
3C
EȲ

rules_doxygenextensions.bzl�get_default_canonical_id�Returns the default canonical id to use for downloads.

Copied from [@bazel_tools//tools/build_defs/repo:cache.bzl](https://github.com/bazelbuild/bazel/blob/dbb05116a07429ec3524bcf7252cedbb11269bea/tools/build_defs/repo/cache.bzl)
to avoid a dependency on the whole `@bazel_tools` package, since its visibility changed from private to public between Bazel 7.0.0 and 8.0.0.

Returns `""` (empty string) when Bazel is run with
`--repo_env=BAZEL_HTTP_RULES_URLS_AS_DEFAULT_CANONICAL_ID=0`.

e.g.
```python
load("@bazel_tools//tools/build_defs/repo:cache.bzl", "get_default_canonical_id")
# ...
    repository_ctx.download_and_extract(
        url = urls,
        integrity = integrity
        canonical_id = get_default_canonical_id(repository_ctx, urls),
    ),
```
*�	
�	
get_default_canonical_idb
repository_ctxLThe repository context of the repository rule calling this utility
function. (z
urlsnA list of URLs matching what is passed to `repository_ctx.download` and
`repository_ctx.download_and_extract`. (�Returns the default canonical id to use for downloads.

Copied from [@bazel_tools//tools/build_defs/repo:cache.bzl](https://github.com/bazelbuild/bazel/blob/dbb05116a07429ec3524bcf7252cedbb11269bea/tools/build_defs/repo/cache.bzl)
to avoid a dependency on the whole `@bazel_tools` package, since its visibility changed from private to public between Bazel 7.0.0 and 8.0.0.

Returns `""` (empty string) when Bazel is run with
`--repo_env=BAZEL_HTTP_RULES_URLS_AS_DEFAULT_CANONICAL_ID=0`.

e.g.
```python
load("@bazel_tools//tools/build_defs/repo:cache.bzl", "get_default_canonical_id")
# ...
    repository_ctx.download_and_extract(
        url = urls,
        integrity = integrity
        canonical_id = get_default_canonical_id(repository_ctx, urls),
    ),
```
"�
~The canonical ID to use for the download, or an empty string if
`BAZEL_HTTP_RULES_URLS_AS_DEFAULT_CANONICAL_ID` is set to `0`.2<
get_default_canonical_id @@rules_doxygen//:extensions.bzl
�8doxygen_repository�
Repository rule for doxygen.

It can be provided with a configuration for each of the three platforms (windows, mac, mac-arm, linux, linux-arm) to download the correct version of doxygen only when the configuration matches the current platform.
Depending on the version, the behavior will change:
- If the version is set to `0.0.0`, the repository will use the installed version of doxygen, getting the binary from the PATH.
- If a version is specified, the repository will download the correct version of doxygen and make it available to the requesting module.

> [!Warning]  
> If version is set to `0.0.0`, the rules needs doxygen to be installed on your system and the binary (named doxygen) must available in the PATH.
> Keep in mind that this will break the hermeticity of your build, as it will now depend on the environment.

You can further customize the repository by specifying the `doxygen_bzl`, `build`, and `doxyfile_template` attributes, but the default values should be enough for most use cases.

### Example

```starlark
# Download the os specific version 1.12.0 of doxygen supporting all the indicated platforms
doxygen_repository(
    name = "doxygen",
    versions = ["1.12.0", "1.12.0", "1.12.0"],
    sha256s = [
        "07f1c92cbbb32816689c725539c0951f92c6371d3d7f66dfa3192cbe88dd3138",
        "6ace7dde967d41f4e293d034a67eb2c7edd61318491ee3131112173a77344001",
        "3c42c3f3fb206732b503862d9c9c11978920a8214f223a3950bbf2520be5f647",
    ]
    platforms = ["windows", "mac", "linux"],
    executables = ["", "", ""],
)

# Use the system installed version of doxygen on linux and download version 1.11.0 for windows. Use the provided executable on mac-arm
doxygen_repository(
    name = "doxygen",
    version = ["0.0.0", "1.11.0", ""],
    sha256s = ["", "478fc9897d00ca181835d248a4d3e5c83c26a32d1c7571f4321ddb0f2e97459f", ""],
    platforms = ["linux", "windows", "mac-arm"],
    executables = ["", "", "/path/to/doxygen"],
)
```
R�(
�
doxygen_repository�
Repository rule for doxygen.

It can be provided with a configuration for each of the three platforms (windows, mac, mac-arm, linux, linux-arm) to download the correct version of doxygen only when the configuration matches the current platform.
Depending on the version, the behavior will change:
- If the version is set to `0.0.0`, the repository will use the installed version of doxygen, getting the binary from the PATH.
- If a version is specified, the repository will download the correct version of doxygen and make it available to the requesting module.

> [!Warning]  
> If version is set to `0.0.0`, the rules needs doxygen to be installed on your system and the binary (named doxygen) must available in the PATH.
> Keep in mind that this will break the hermeticity of your build, as it will now depend on the environment.

You can further customize the repository by specifying the `doxygen_bzl`, `build`, and `doxyfile_template` attributes, but the default values should be enough for most use cases.

### Example

```starlark
# Download the os specific version 1.12.0 of doxygen supporting all the indicated platforms
doxygen_repository(
    name = "doxygen",
    versions = ["1.12.0", "1.12.0", "1.12.0"],
    sha256s = [
        "07f1c92cbbb32816689c725539c0951f92c6371d3d7f66dfa3192cbe88dd3138",
        "6ace7dde967d41f4e293d034a67eb2c7edd61318491ee3131112173a77344001",
        "3c42c3f3fb206732b503862d9c9c11978920a8214f223a3950bbf2520be5f647",
    ]
    platforms = ["windows", "mac", "linux"],
    executables = ["", "", ""],
)

# Use the system installed version of doxygen on linux and download version 1.11.0 for windows. Use the provided executable on mac-arm
doxygen_repository(
    name = "doxygen",
    version = ["0.0.0", "1.11.0", ""],
    sha256s = ["", "478fc9897d00ca181835d248a4d3e5c83c26a32d1c7571f4321ddb0f2e97459f", ""],
    platforms = ["linux", "windows", "mac-arm"],
    executables = ["", "", "/path/to/doxygen"],
)
```
.
name"A unique name for this repository. Q
build The BUILD file of the repository2$@@rules_doxygen//doxygen:BUILD.bazel_
doxyfile_templateThe Doxyfile template to use2*@@rules_doxygen//doxygen:Doxyfile.templatee
doxygen_bzl.The starlark file containing the doxygen macro2$@@rules_doxygen//doxygen:doxygen.bzl�
executables�List of paths to doxygen executables to use. If set, no download will take place and the provided doxygen executable will be used. Mutually exclusive with `version`. Must be the same length as `version`, `sha256s` and `platforms`. �
	platforms�List of platforms to download the doxygen binary for. Available options are (windows, mac, mac-arm, linux, linux-arm). Must be the same length as `version`, `sha256s` and `executables`. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
sha256srList of sha256 hashes of the doxygen archive. Must be the same length as `versions, `platforms` and `executables`. �
versions�List of versions of doxygen to use. If set to `0.0.0`, the doxygen executable will be assumed to be available from the PATH. Must be the same length as `sha256s`, `platforms` and `executables`. *6
doxygen_repository @@rules_doxygen//:extensions.bzl
�%�%0
.
name"A unique name for this repository. S
Q
build The BUILD file of the repository2$@@rules_doxygen//doxygen:BUILD.bazela
_
doxyfile_templateThe Doxyfile template to use2*@@rules_doxygen//doxygen:Doxyfile.templateg
e
doxygen_bzl.The starlark file containing the doxygen macro2$@@rules_doxygen//doxygen:doxygen.bzl�
�
executables�List of paths to doxygen executables to use. If set, no download will take place and the provided doxygen executable will be used. Mutually exclusive with `version`. Must be the same length as `version`, `sha256s` and `platforms`. �
�
	platforms�List of platforms to download the doxygen binary for. Available options are (windows, mac, mac-arm, linux, linux-arm). Must be the same length as `version`, `sha256s` and `executables`. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
�
sha256srList of sha256 hashes of the doxygen archive. Must be the same length as `versions, `platforms` and `executables`. �
�
versions�List of versions of doxygen to use. If set to `0.0.0`, the doxygen executable will be assumed to be available from the PATH. Must be the same length as `sha256s`, `platforms` and `executables`. �idoxygen_extension�(
Module extension for declaring the doxygen configurations to use.

The resulting repository will have the following targets:
- `@doxygen//:doxygen.bzl`, containing the doxygen macro used to generate the documentation.
- `@doxygen//:Doxyfile.template`, default Doxyfile template used to generate the Doxyfile.

The extension will create a default configuration for all platforms with the version `1.13.2` of Doxygen.
You can override this value with a custom one for each supported platform, i.e. _windows_, _mac_, _mac-arm_, _linux_ and _linux-arm_.

```bzl
# MODULE.bazel file

bazel_dep(name = "rules_doxygen", version = "...", dev_dependency = True)

doxygen_extension = use_extension("@rules_doxygen//:extensions.bzl", "doxygen_extension")

# Download doxygen version 1.10.0 on linux, default version on all other platforms
doxygen_extension.configuration(
    version = "1.10.0",
    sha256 = "dcfc9aa4cc05aef1f0407817612ad9e9201d9bf2ce67cecf95a024bba7d39747",
    platform = "linux",
)

use_repo(doxygen_extension, "doxygen")
```

When you do so, you must also provide the SHA256 of the given doxygen archive.
If you don't know the SHA256 value, just leave it empty.
The build will fail with an error message containing the correct SHA256.

```bash
Download from https://github.com/doxygen/doxygen/releases/download/Release_1_10_0/doxygen-1.10.0.windows.x64.bin.zip failed: class com.google.devtools.build.lib.bazel.repository.downloader.UnrecoverableHttpException Checksum was 2135c1d5bdd6e067b3d0c40a4daac5d63d0fee1b3f4d6ef1e4f092db0d632d5b but wanted 0000000000000000000000000000000000000000000000000000000000000000
```

> [!Tip]  
> Not indicating the platform will make the configuration apply to the platform it is running on.
> The build will fail when the download does not match the SHA256 checksum, i.e. when the platform changes.
> Unless you are using a system-wide doxygen installation, you should always specify the platform.

#### System-wide doxygen installation

If you set the version to `0.0.0`, the doxygen executable will be assumed to be available from the PATH.
No download will be performed and bazel will use the installed version of doxygen.

> [!Warning]  
> Setting the version to `0.0.0` this will break the hermeticity of your build, as it will now depend on the environment.

#### Using a local doxygen executable

You can also provide a label pointing to the `doxygen` executable you want to use by using the `executable` parameter in the extension configuration.
No download will be performed, and the file indicated by the label will be used as the doxygen executable.

> [!Note]  
> `version` and `executable` are mutually exclusive.
> You must provide exactly one of them.

### Examples

```starlark
# MODULE.bazel file

bazel_dep(name = "rules_doxygen", version = "...", dev_dependency = True)

doxygen_extension = use_extension("@rules_doxygen//:extensions.bzl", "doxygen_extension")

# Using the 1.10.0 version of Doxygen instead of the default one.
# Note that che checksum is correct only if the platform is windows.
# If the platform is different, the build will fail.
doxygen_extension.configuration(
    version = "1.10.0",
    sha256 = "2135c1d5bdd6e067b3d0c40a4daac5d63d0fee1b3f4d6ef1e4f092db0d632d5b",
)

use_repo(doxygen_extension, "doxygen")
```

```starlark
# MODULE.bazel file

bazel_dep(name = "rules_doxygen", version = "...", dev_dependency = True)

doxygen_extension = use_extension("@rules_doxygen//:extensions.bzl", "doxygen_extension")

doxygen_extension.configuration(
    version = "1.10.0",
    sha256 = "dcfc9aa4cc05aef1f0407817612ad9e9201d9bf2ce67cecf95a024bba7d39747",
    platform = "linux",
)
doxygen_extension.configuration(
    version = "1.10.0",
    sha256 = "dcfc9aa4cc05aef1f0407817612ad9e9201d9bf2ce67cecf95a024bba7d39747",
    platform = "linux-arm",
)
doxygen_extension.configuration(
    version = "1.12.0",
    sha256 = "6ace7dde967d41f4e293d034a67eb2c7edd61318491ee3131112173a77344001",
    platform = "mac",
)
doxygen_extension.configuration(
    version = "1.12.0",
    sha256 = "6ace7dde967d41f4e293d034a67eb2c7edd61318491ee3131112173a77344001",
    platform = "mac-arm",
)
doxygen_extension.configuration(
    version = "1.11.0",
    sha256 = "478fc9897d00ca181835d248a4d3e5c83c26a32d1c7571f4321ddb0f2e97459f",
    platform = "windows",
)

use_repo(doxygen_extension, "doxygen")
```

```bzl
# MODULE.bazel file

bazel_dep(name = "rules_doxygen", version = "...", dev_dependency = True)

doxygen_extension = use_extension("@rules_doxygen//:extensions.bzl", "doxygen_extension")

# Download doxygen version 1.10.0 on linux
doxygen_extension.configuration(
    version = "1.10.0",
    sha256 = "dcfc9aa4cc05aef1f0407817612ad9e9201d9bf2ce67cecf95a024bba7d39747",
    platform = "linux",
)
# Use the local doxygen installation on mac
doxygen_extension.configuration(
    version = "0.0.0",
    platform = "mac",
)
# Use the doxygen provided executable on mac-arm
doxygen_extension.configuration(
    executable = "@my_module//path/to/doxygen:doxygen",
    platform = "mac-arm",
)
# Since no configuration has been provided for them,
# all other platforms will fallback to the default version

use_repo(doxygen_extension, "doxygen")
```
J�@
�1
doxygen_extension�(
Module extension for declaring the doxygen configurations to use.

The resulting repository will have the following targets:
- `@doxygen//:doxygen.bzl`, containing the doxygen macro used to generate the documentation.
- `@doxygen//:Doxyfile.template`, default Doxyfile template used to generate the Doxyfile.

The extension will create a default configuration for all platforms with the version `1.13.2` of Doxygen.
You can override this value with a custom one for each supported platform, i.e. _windows_, _mac_, _mac-arm_, _linux_ and _linux-arm_.

```bzl
# MODULE.bazel file

bazel_dep(name = "rules_doxygen", version = "...", dev_dependency = True)

doxygen_extension = use_extension("@rules_doxygen//:extensions.bzl", "doxygen_extension")

# Download doxygen version 1.10.0 on linux, default version on all other platforms
doxygen_extension.configuration(
    version = "1.10.0",
    sha256 = "dcfc9aa4cc05aef1f0407817612ad9e9201d9bf2ce67cecf95a024bba7d39747",
    platform = "linux",
)

use_repo(doxygen_extension, "doxygen")
```

When you do so, you must also provide the SHA256 of the given doxygen archive.
If you don't know the SHA256 value, just leave it empty.
The build will fail with an error message containing the correct SHA256.

```bash
Download from https://github.com/doxygen/doxygen/releases/download/Release_1_10_0/doxygen-1.10.0.windows.x64.bin.zip failed: class com.google.devtools.build.lib.bazel.repository.downloader.UnrecoverableHttpException Checksum was 2135c1d5bdd6e067b3d0c40a4daac5d63d0fee1b3f4d6ef1e4f092db0d632d5b but wanted 0000000000000000000000000000000000000000000000000000000000000000
```

> [!Tip]  
> Not indicating the platform will make the configuration apply to the platform it is running on.
> The build will fail when the download does not match the SHA256 checksum, i.e. when the platform changes.
> Unless you are using a system-wide doxygen installation, you should always specify the platform.

#### System-wide doxygen installation

If you set the version to `0.0.0`, the doxygen executable will be assumed to be available from the PATH.
No download will be performed and bazel will use the installed version of doxygen.

> [!Warning]  
> Setting the version to `0.0.0` this will break the hermeticity of your build, as it will now depend on the environment.

#### Using a local doxygen executable

You can also provide a label pointing to the `doxygen` executable you want to use by using the `executable` parameter in the extension configuration.
No download will be performed, and the file indicated by the label will be used as the doxygen executable.

> [!Note]  
> `version` and `executable` are mutually exclusive.
> You must provide exactly one of them.

### Examples

```starlark
# MODULE.bazel file

bazel_dep(name = "rules_doxygen", version = "...", dev_dependency = True)

doxygen_extension = use_extension("@rules_doxygen//:extensions.bzl", "doxygen_extension")

# Using the 1.10.0 version of Doxygen instead of the default one.
# Note that che checksum is correct only if the platform is windows.
# If the platform is different, the build will fail.
doxygen_extension.configuration(
    version = "1.10.0",
    sha256 = "2135c1d5bdd6e067b3d0c40a4daac5d63d0fee1b3f4d6ef1e4f092db0d632d5b",
)

use_repo(doxygen_extension, "doxygen")
```

```starlark
# MODULE.bazel file

bazel_dep(name = "rules_doxygen", version = "...", dev_dependency = True)

doxygen_extension = use_extension("@rules_doxygen//:extensions.bzl", "doxygen_extension")

doxygen_extension.configuration(
    version = "1.10.0",
    sha256 = "dcfc9aa4cc05aef1f0407817612ad9e9201d9bf2ce67cecf95a024bba7d39747",
    platform = "linux",
)
doxygen_extension.configuration(
    version = "1.10.0",
    sha256 = "dcfc9aa4cc05aef1f0407817612ad9e9201d9bf2ce67cecf95a024bba7d39747",
    platform = "linux-arm",
)
doxygen_extension.configuration(
    version = "1.12.0",
    sha256 = "6ace7dde967d41f4e293d034a67eb2c7edd61318491ee3131112173a77344001",
    platform = "mac",
)
doxygen_extension.configuration(
    version = "1.12.0",
    sha256 = "6ace7dde967d41f4e293d034a67eb2c7edd61318491ee3131112173a77344001",
    platform = "mac-arm",
)
doxygen_extension.configuration(
    version = "1.11.0",
    sha256 = "478fc9897d00ca181835d248a4d3e5c83c26a32d1c7571f4321ddb0f2e97459f",
    platform = "windows",
)

use_repo(doxygen_extension, "doxygen")
```

```bzl
# MODULE.bazel file

bazel_dep(name = "rules_doxygen", version = "...", dev_dependency = True)

doxygen_extension = use_extension("@rules_doxygen//:extensions.bzl", "doxygen_extension")

# Download doxygen version 1.10.0 on linux
doxygen_extension.configuration(
    version = "1.10.0",
    sha256 = "dcfc9aa4cc05aef1f0407817612ad9e9201d9bf2ce67cecf95a024bba7d39747",
    platform = "linux",
)
# Use the local doxygen installation on mac
doxygen_extension.configuration(
    version = "0.0.0",
    platform = "mac",
)
# Use the doxygen provided executable on mac-arm
doxygen_extension.configuration(
    executable = "@my_module//path/to/doxygen:doxygen",
    platform = "mac-arm",
)
# Since no configuration has been provided for them,
# all other platforms will fallback to the default version

use_repo(doxygen_extension, "doxygen")
```
�
configuration�

executable�Target pointing to the doxygen executable to use. If set, no download will take place and the provided doxygen executable will be used. Mutually exclusive with `version`.2None�
platform�The platform this configuration applies to. Available options are (windows, mac, mac-arm, linux, linux-arm). If not specified, the configuration will apply to the platform it is currently running on.2""h
sha256XThe sha256 hash of the doxygen archive. If not specified, an all-zero hash will be used.2""�
version�The version of doxygen to use. If set to `0.0.0`, the doxygen executable will be assumed to be available from the PATH. Mutually exclusive with `executable`.2""�

repository�
name�The name of the repository the extension will create. Useful if you don't use 'rules_doxygen' as a dev_dependency, since it will avoid name collision for module depending on yours. Can only be specified once. Defaults to 'doxygen'. "5
doxygen_extension @@rules_doxygen//:extensions.bzl
�%�%�
�
configuration�

executable�Target pointing to the doxygen executable to use. If set, no download will take place and the provided doxygen executable will be used. Mutually exclusive with `version`.2None�
platform�The platform this configuration applies to. Available options are (windows, mac, mac-arm, linux, linux-arm). If not specified, the configuration will apply to the platform it is currently running on.2""h
sha256XThe sha256 hash of the doxygen archive. If not specified, an all-zero hash will be used.2""�
version�The version of doxygen to use. If set to `0.0.0`, the doxygen executable will be assumed to be available from the PATH. Mutually exclusive with `executable`.2""�
�

executable�Target pointing to the doxygen executable to use. If set, no download will take place and the provided doxygen executable will be used. Mutually exclusive with `version`.2None�
�
platform�The platform this configuration applies to. Available options are (windows, mac, mac-arm, linux, linux-arm). If not specified, the configuration will apply to the platform it is currently running on.2""j
h
sha256XThe sha256 hash of the doxygen archive. If not specified, an all-zero hash will be used.2""�
�
version�The version of doxygen to use. If set to `0.0.0`, the doxygen executable will be assumed to be available from the PATH. Mutually exclusive with `executable`.2""�
�

repository�
name�The name of the repository the extension will create. Useful if you don't use 'rules_doxygen' as a dev_dependency, since it will avoid name collision for module depending on yours. Can only be specified once. Defaults to 'doxygen'. �
�
name�The name of the repository the extension will create. Useful if you don't use 'rules_doxygen' as a dev_dependency, since it will avoid name collision for module depending on yours. Can only be specified once. Defaults to 'doxygen'. WRepository rule for downloading the correct version of doxygen using module extensions. 