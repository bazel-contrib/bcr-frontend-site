�
%
rules_doxygendoxygendoxygen.bzl��doxygen�0Generates documentation using Doxygen.

The set of attributes the macro provides is a subset of the Doxygen configuration options.
Depending on the type of the attribute, the macro will convert it to the appropriate string:

- None (default): the attribute will not be included in the Doxyfile
- bool: the value of the attribute is the string "YES" or "NO" respectively
- list: the value of the attribute is a string with the elements separated by spaces and enclosed in double quotes
- str: the value of the attribute is will be set to the string, unchanged. You may need to provide proper quoting if the value contains spaces

For the complete list of Doxygen configuration options, please refer to the [Doxygen documentation](https://www.doxygen.nl/manual/config.html).

> [!NOTE]
> If not istructed otherwise, the rule will use the Doxyfile from its default `doxygen` version.
> Any update could change some default values or add some flags which will be unrecognized by older `doxygen` versions, resulting in innocuous warnings.
> If you want to use a specific Doxyfile, just generate one with `doxygen -g` and specify it in the `doxyfile_template` attribute.

### Make variables

There are cases where you need access to information about the build environment, such as the output directory doxygen is writing to.
In such cases, you can use make variables in the parameters of the macro.
The `doxygen` rule will take care of expanding them to the appropriate values.

By default, the following make variables are available:

- `$(OUTDIR)`: The output directory where the documentation will be generated.
- All the predefined variables indicated in the [Bazel documentation](https://bazel.build/reference/be/make-variables#predefined_variables).

The former is particularly useful when `doxygen` needs to generate unusual files, such as [tag files](https://www.doxygen.nl/manual/config.html#cfg_generate_tagfile).
An example of this is shown below, where the tag file `PolyVox.tag` is stored in the `tags` output directory.

```bzl
doxygen(
    name = "doxygen",
    srcs = ["README.md"] + glob(["*.h", "*.cpp"]),
    outs = ["html", "tags"],
    generate_tagfile = "$(OUTDIR)/tags/PolyVox.tag",
)
```

> [!NOTE]
> Make sure that generated files are put in some directory and that directory is included in the `outs` attribute.

You can add your own substitutions by adding a rule that returns a TemplateVariableInfo provider in the `toolchains` attribute of the `doxygen` rule.
See [this example](../examples/substitutions/) for more details.

### Differences between `srcs` and `deps`

The `srcs` and `deps` attributes work differently and are not interchangeable.

`srcs` is a list of files that will be passed to Doxygen for documentation generation.
You can use `glob` to include a collection of multiple files.
On the other hand, if you indicate a target (e.g., `:my_genrule`), it will include all the files produced by that target.
More precisely, the files in the DefaultInfo provider the target returns.
Hence, when the documentation is generated, all rules in the `srcs` attribute **will** be built, and the files they output will be passed to Doxygen.

On the other hand, `deps` is a list of targets whose sources will be included in the documentation generation.
It will automatically include all the files in the `srcs`, `hdrs`, and `data` attributes of the target, and the same applies to all of its transitive dependencies, recursively.
Since we are only interested in the source files, the `deps` targets **will not** be built when the documentation is generated.

```bzl
# My BUILD.bazel file
load("@doxygen//:doxygen.bzl", "doxygen")
load("@rules_cc//cc:defs.bzl", "cc_library")

cc_library(
    name = "lib",
    hdrs = ["add.h", "sub.h"],
    srcs = ["add.cpp", "sub.cpp"],
)

cc_library(
    name = "main",
    srcs = ["main.cpp"],
    deps = [":lib"],
)


genrule(
    name = "section",
    outs = ["Section.md"],
    cmd = """
        echo "# Section " > $@
        echo "This is some amazing documentation with section!!  " >> $@
        echo "Incredible." >> $@
    """,
)

doxygen(
    name = "doxygen",
    project_name = "dependencies",

    # The output of the genrule will be included in the documentation.
    # The genrule will be executed when the documentation is generated.
    srcs = [
        "README.md",  # file
        ":section",  # genrule

        # WARNING: By adding this, the main target will be built
        # and only the output files `libmain.so` and `libmain.a`
        # will be passed to Doxygen, which is likely not what you want.
        # ":main"
    ],

    # The sources of the main target and its dependencies will be included.
    # No compilation will be performed, so compile error won't be reported.
    deps = [":main"],  # cc_library

    # Always starts at the root folder
    use_mdfile_as_mainpage = "dependencies/README.md",
)
```

### Excluding Bazel specific folders

Including the root directory among the input directories, which happens when a target starting with `//:` is used as a source,
may cause Bazel specific folders, such as `external`, to be explored by Doxygen.
This can slow down the documentation generation or even cause an input buffer overflow.
To avoid this, it is recommended to use the `exclude_patterns` parameter and set it to something like `["*/external/*"]`, extending it with other patterns as needed.

### Example

```bzl
# MODULE.bazel file
bazel_dep(name = "rules_doxygen", dev_dependency = True)
doxygen_extension = use_extension("@rules_doxygen//:extensions.bzl", "doxygen_extension")
use_repo(doxygen_extension, "doxygen")
```

```bzl
# BUILD.bazel file
load("@doxygen//:doxygen.bzl", "doxygen")
load("@rules_cc//cc:defs.bzl", "cc_library")

cc_library(
    name = "lib",
    srcs = ["add.cpp", "sub.cpp"],
    hdrs = ["add.h", "sub.h"],
)

cc_library(
    name = "main",
    srcs = ["main.cpp"],
    deps = [":lib"],
)

doxygen(
    name = "doxygen",
    srcs = glob([
        "*.md",
    ]),
    deps = [":main"]
    aliases = [
        "licence=@par Licence:^^",
        "verb{1}=@verbatim \\1 @endverbatim",
    ],
    optimize_output_for_c = True,
    project_brief = "Example project for doxygen",
    project_name = "example",
)
```
*��
��
doxygen 
nameName for the target. (�
srcs�List of source files to generate documentation for.
Can include any file that Doxygen can parse, as well as targets that return a DefaultInfo provider (usually genrules).
Since we are only considering the outputs files and not the sources, these targets **will** be built if necessary.[](�
deps�List of dependencies targets whose files present in the 'src', 'hdrs' and 'data' attributes will be collected to generate the documentation.
Transitive dependencies are also taken into account.
Since we are only considering the source files and not the outputs, these targets **will not** be built.[](6

executable Label of the doxygen executable.None(p
dot_executableVLabel of the doxygen executable. Make sure it is also added to the `srcs` of the macroNone(Y
configurations?List of additional configuration parameters to pass to Doxygen.None(<
doxyfile_prefix#Prefix to add to the Doxyfile path.""(�
doxyfile_template�The template file to use to generate the Doxyfile.
The following substitutions are available:<br>
- `# {{INPUT}}`: Subpackage directory in the sandbox.<br>
- `# {{ADDITIONAL PARAMETERS}}`: Additional parameters given in the `configurations` attribute.<br>
- `# {{OUTPUT DIRECTORY}}`: The directory provided in the `outs` attribute.<br>
- `{{OUTDIR}}`: The output directory where the generated documentation will be placed.
    Can be used anywhere in the Doxyfile, usually to generate additional output files, like tag files.None(N
doxygen_extra_args2Extra arguments to pass to the doxygen executable.[](d
use_default_shell_envBWhether to use the default shell environment when running doxygen.False(J
env=Additional environment variables to set when running doxygen.{}(�
tools�List of additional tools to include in the doxygen environment. Tools are executable inputs that may have their own runfiles which are automatically made available to the action.[](�
outs�Output folders bazel will keep. If only the html outputs is of interest, the default value will do.
otherwise, a list of folders to keep is expected (e.g. ["html", "latex"]).
Note that the rule will also generate an output group for each folder in the outs list having the same name.["html"]({
doxyfile_encoding^This tag specifies the encoding used for all characters in the configuration file that follow.None(�
project_name�The `project_name` tag is a single word (or a sequence of words surrounded by double-quotes, unless you are using Doxywizard) that should identify the project for which the documentation is generated.None(e
project_numberKThe `project_number` tag can be used to enter a project or revision number.None(�
project_brief�Using the `project_brief` tag one can provide an optional one line description for a project that appears at the top of each page and should give viewer a quick idea about the purpose of the project.None(|
project_logodWith the `project_logo` tag one can specify a logo or an icon that is included in the documentation.None(�
project_iconqWith the `project_icon` tag one can specify an icon that is included in the tabs when the HTML document is shown.None(�
create_subdirs�If the `create_subdirs` tag is set to `True` then Doxygen will create up to 4096 sub-directories (in 2 levels) under the output directory of each output format and will distribute the generated files over these directories.None(�
create_subdirs_levelgControls the number of sub-directories that will be created when `create_subdirs` tag is set to `True`.None(�
allow_unicode_names�If the `allow_unicode_names` tag is set to `True`, Doxygen will allow non-ASCII characters to appear in the names of generated files.None(�
output_languageuThe `output_language` tag is used to specify the language in which all documentation generated by Doxygen is written.None(�
brief_member_desc�If the `brief_member_desc` tag is set to `True`, Doxygen will include brief member descriptions after the members that are listed in the file and class documentation (similar to Javadoc).None(�
repeat_brief�If the `repeat_brief` tag is set to `True`, Doxygen will prepend the brief description of a member or function before the detailed description Note: If both `hide_undoc_members` and `brief_member_desc` are set to `False`, the brief descriptions will be completely suppressed.None(�
abbreviate_briefxThis tag implements a quasi-intelligent brief description abbreviator that is used to form the text in various listings.None(�
always_detailed_sec�If the `always_detailed_sec` and `repeat_brief` tags are both set to `True` then Doxygen will generate a detailed section even if there is only a brief description.None(�
inline_inherited_memb�If the `inline_inherited_memb` tag is set to `True`, Doxygen will show all inherited members of a class in the documentation of that class as if those members were ordinary class members.None(�
full_path_names�If the `full_path_names` tag is set to `True`, Doxygen will prepend the full path before files name in the file list and in the header files.None(j
strip_from_pathOThe `strip_from_path` tag can be used to strip a user-defined part of the path.None(�
strip_from_inc_path�The `strip_from_inc_path` tag can be used to strip a user-defined part of the path mentioned in the documentation of a class, which tells the reader which header file to include in order to use a class.None(�
short_namesmIf the `short_names` tag is set to `True`, Doxygen will generate much shorter (but less readable) file names.None(�
javadoc_autobrief�If the `javadoc_autobrief` tag is set to `True` then Doxygen will interpret the first line (until the first dot) of a Javadoc-style comment as the brief description.None(�
javadoc_banner�If the `javadoc_banner` tag is set to `True` then Doxygen will interpret a line such as /*************** as being the beginning of a Javadoc-style comment "banner".None(�
qt_autobrief�If the `qt_autobrief` tag is set to `True` then Doxygen will interpret the first line (until the first dot) of a Qt-style comment as the brief description.None(�
multiline_cpp_is_brief�The `multiline_cpp_is_brief` tag can be set to `True` to make Doxygen treat a multi-line C++ special comment block (i.e. a block of //! or /// comments) as a brief description.None(�
python_docstringnBy default Python docstrings are displayed as preformatted text and Doxygen's special commands cannot be used.None(�
inherit_docs�If the `inherit_docs` tag is set to `True` then an undocumented member inherits the documentation from any documented member that it re-implements.None(�
separate_member_pagesiIf the `separate_member_pages` tag is set to `True` then Doxygen will produce a new page for each member.None(X
tab_sizeDThe `tab_size` tag can be used to set the number of spaces in a tab.None(q
aliases^This tag can be used to specify a number of aliases that act as commands in the documentation.None(z
optimize_output_for_cYSet the `optimize_output_for_c` tag to `True` if your project consists of C sources only.None(�
optimize_output_javaeSet the `optimize_output_java` tag to `True` if your project consists of Java or Python sources only.None(y
optimize_for_fortranYSet the `optimize_for_fortran` tag to `True` if your project consists of Fortran sources.None(v
optimize_output_vhdlVSet the `optimize_output_vhdl` tag to `True` if your project consists of VHDL sources.None(~
optimize_output_slice]Set the `optimize_output_slice` tag to `True` if your project consists of Slice sources only.None(q
extension_mappingTDoxygen selects the parser to use depending on the extension of the files it parses.None(�
markdown_support�If the `markdown_support` tag is enabled then Doxygen pre-processes all comments according to the Markdown format, which allows for more readable documentation.None(�
markdown_strict�If the markdown_strict tag is enabled then Doxygen treats text in comments as Markdown formatted also in cases where Doxygen's native markup format conflicts with that of Markdown.None(�
toc_include_headings�When the `toc_include_headings` tag is set to a non-zero value, all headings up to that level are automatically included in the table of contents, even if they do not have an id attribute.None(�
markdown_id_stylexThe `markdown_id_style` tag can be used to specify the algorithm used to generate identifiers for the Markdown headings.None(�
autolink_support�When enabled Doxygen tries to link words that correspond to documented classes, or namespaces to their corresponding documentation.None(�
autolink_ignore_words�This tag specifies a list of words that, when matching the start of a word in the documentation, will suppress auto links generation, if it is enabled via autolink_support.None(�
builtin_stl_support�If you use STL classes (i.e. std::string, std::vector, etc.) but do not want to include (a tag file for) the STL sources as input, then you should set this tag to `True` in order to let Doxygen match functions declarations and definitions whose arguments contain STL classes (e.g. func(std::string); versus func(std::string) {}).None(�
cpp_cli_supporthIf you use Microsoft's C++/CLI language, you should set this option to `True` to enable parsing support.None(�
sip_support�Set the `sip_support` tag to `True` if your project consists of sip (see: https://www.riverbankcomputing.com/software) sources only.None(�
idl_property_supportrFor Microsoft's IDL there are propget and propput attributes to indicate getter and setter methods for a property.None(�
distribute_group_doc�If member grouping is used in the documentation and the `distribute_group_doc` tag is set to `True` then Doxygen will reuse the documentation of the first member in the group (if any) for the other members of the group.None(�
group_nested_compounds�If one adds a struct or class to a group and this option is enabled, then also any nested class or struct is added to the same group.None(�
subgrouping�Set the `subgrouping` tag to `True` to allow class member groups of the same type (for instance a group of public functions) to be put as a subgroup of that type (e.g. under the Public Functions section).None(�
inline_grouped_classes�When the `inline_grouped_classes` tag is set to `True`, classes, structs and unions are shown inside the group in which they are included (e.g. using \ingroup) instead of on a separate page (for HTML and Man pages) or section (for LaTeX and RTF).None(�
inline_simple_structs�When the `inline_simple_structs` tag is set to `True`, structs, classes, and unions with only public data fields or simple typedef fields will be shown inline in the documentation of the scope in which they are defined (i.e. file, namespace, or group documentation), provided this scope is documented.None(�
typedef_hides_struct�When `typedef_hides_struct` tag is enabled, a typedef of a struct, union, or enum is documented as struct, union, or enum with the name of the typedef.None(f
lookup_cache_sizeIThe size of the symbol lookup cache can be set using `lookup_cache_size`.None(
num_proc_threadscThe `num_proc_threads` specifies the number of threads Doxygen is allowed to use during processing.None(�
	timestamp�If the `timestamp` tag is set different from `False` then each generated page will contain the date or date and time when the page was generated.None(�
extract_all�If the `extract_all` tag is set to `True`, Doxygen will assume all entities in documentation are documented, even if no documentation was available.None(�
extract_privatetIf the `extract_private` tag is set to `True`, all private members of a class will be included in the documentation.None(�
extract_priv_virtual�If the `extract_priv_virtual` tag is set to `True`, documented private virtual methods of a class will be included in the documentation.None(�
extract_package�If the `extract_package` tag is set to `True`, all members with package or internal scope will be included in the documentation.None(�
extract_staticqIf the `extract_static` tag is set to `True`, all static members of a file will be included in the documentation.None(�
extract_local_classes�If the `extract_local_classes` tag is set to `True`, classes (and structs) defined locally in source files will be included in the documentation.None(O
extract_local_methods.This flag is only useful for Objective-C code.None(�
extract_anon_nspaces�If this flag is set to `True`, the members of anonymous namespaces will be extracted and appear in the documentation as a namespace called 'anonymous_namespace{file}', where file will be replaced with the base name of the file that contains the anonymous namespace.None(�
resolve_unnamed_params�If this flag is set to `True`, the name of an unnamed parameter in a declaration will be determined by the corresponding definition.None(�
hide_undoc_members�If the `hide_undoc_members` tag is set to `True`, Doxygen will hide all undocumented members inside documented classes or files.None(�
hide_undoc_classes�If the `hide_undoc_classes` tag is set to `True`, Doxygen will hide all undocumented classes that are normally visible in the class hierarchy.None(�
hide_undoc_namespaces�If the hide_undoc_namespaces tag is set to YES, Doxygen will hide all undocumented namespaces that are normally visible in the namespace hierarchy.None(�
hide_friend_compounds_If the `hide_friend_compounds` tag is set to `True`, Doxygen will hide all friend declarations.None(�
hide_in_body_docs�If the `hide_in_body_docs` tag is set to `True`, Doxygen will hide any documentation blocks found inside the body of a function.None(�
internal_docshThe `internal_docs` tag determines if documentation that is typed after a \internal command is included.None(�
case_sense_names�With the correct setting of option `case_sense_names` Doxygen will better be able to match the capabilities of the underlying filesystem.None(�
hide_scope_names�If the `hide_scope_names` tag is set to `False` then Doxygen will show members with their full class and namespace scopes in the documentation.None(�
hide_compound_reference�If the `hide_compound_reference` tag is set to `False` (default) then Doxygen will append additional text to a page's title, such as Class Reference.None(�
show_headerfile�If the `show_headerfile` tag is set to `True` then the documentation for a class will show which file needs to be included to use the class.None(�
show_include_files�If the `show_include_files` tag is set to `True` then Doxygen will put a list of the files that are included by a file in the documentation of that file.None(�
show_grouped_memb_inc�If the `show_grouped_memb_inc` tag is set to `True` then Doxygen will add for each grouped member an include statement to the documentation, telling the reader which file to include in order to use the member.None(�
force_local_includes�If the `force_local_includes` tag is set to `True` then Doxygen will list include files with double quotes in the documentation rather than with sharp brackets.None(�
inline_inforIf the `inline_info` tag is set to `True` then a tag [inline] is inserted in the documentation for inline members.None(�
sort_member_docs�If the `sort_member_docs` tag is set to `True` then Doxygen will sort the (detailed) documentation of file and class members alphabetically by member name.None(�
sort_brief_docs�If the `sort_brief_docs` tag is set to `True` then Doxygen will sort the brief descriptions of file, namespace and class members alphabetically by member name.None(�
sort_members_ctors_1st�If the `sort_members_ctors_1st` tag is set to `True` then Doxygen will sort the (brief and detailed) documentation of class members so that constructors and destructors are listed first.None(�
sort_group_names{If the `sort_group_names` tag is set to `True` then Doxygen will sort the hierarchy of group names into alphabetical order.None(�
sort_by_scope_nameIf the `sort_by_scope_name` tag is set to `True`, the class list will be sorted by fully-qualified names, including namespaces.None(�
strict_proto_matching�If the `strict_proto_matching` option is enabled and Doxygen fails to do proper type resolution of all parameters of a function it will reject a match between the prototype and the implementation of a member function even if there is only one candidate or it is obvious which candidate to choose by doing a simple string match.None(s
generate_todolistVThe `generate_todolist` tag can be used to enable (YES) or disable (NO) the todo list.None(s
generate_testlistVThe `generate_testlist` tag can be used to enable (YES) or disable (NO) the test list.None(p
generate_buglistTThe `generate_buglist` tag can be used to enable (YES) or disable (NO) the bug list.None(�
generate_deprecatedlistbThe `generate_deprecatedlist` tag can be used to enable (YES) or disable (NO) the deprecated list.None(�
enabled_sections�The `enabled_sections` tag can be used to enable conditional documentation sections, marked by \if <section_label> ... \endif and \cond <section_label> ... \endcond blocks.None(�
max_initializer_lines�The `max_initializer_lines` tag determines the maximum number of lines that the initial value of a variable or macro / define can have for it to appear in the documentation.None(�
show_used_files�Set the `show_used_files` tag to `False` to disable the list of files generated at the bottom of the documentation of classes and structs.None(f

show_filesPSet the `show_files` tag to `False` to disable the generation of the Files page.None(u
show_namespacesZSet the `show_namespaces` tag to `False` to disable the generation of the Namespaces page.None(�
file_version_filter�The `file_version_filter` tag can be used to specify a program or script that Doxygen should invoke to get the current version for each file (typically from the version control system).None(r
layout_file[The `layout_file` tag can be used to specify a layout file which will be parsed by Doxygen.None(�
cite_bib_fileskThe `cite_bib_files` tag can be used to specify one or more bib files containing the reference definitions.None(�
external_tool_path�The `external_tool_path` tag can be used to extend the search path (PATH environment variable) so that external tools such as latex and gs can be found.None(z
quietiThe `quiet` tag can be used to turn on/off the messages that are generated to standard output by Doxygen.None(�
warnings|The `warnings` tag can be used to turn on/off the warning messages that are generated to standard error (stderr) by Doxygen.None(�
warn_if_undocumentedpIf the `warn_if_undocumented` tag is set to `True` then Doxygen will generate warnings for undocumented members.None(�
warn_if_doc_error�If the `warn_if_doc_error` tag is set to `True`, Doxygen will generate warnings for potential errors in the documentation, such as documenting some parameters in a documented function twice, or documenting parameters that don't exist or using markup commands wrongly.None(�
warn_if_incomplete_docrIf `warn_if_incomplete_doc` is set to `True`, Doxygen will warn about incomplete function parameter documentation.None(�
warn_no_paramdoc�This `warn_no_paramdoc` option can be enabled to get warnings for functions that are documented, but have no documentation for their parameters or return value.None(�
warn_if_undoc_enum_valmIf `warn_if_undoc_enum_val` option is set to `True`, Doxygen will warn about undocumented enumeration values.None(�
warn_layout_file�If warn_layout_file option is set to `True`, Doxygen will warn about issues found while parsing the user defined layout file, such as missing or wrong elementsNone(�
warn_as_errormIf the `warn_as_error` tag is set to `True` then Doxygen will immediately stop when a warning is encountered.None(t
warn_format]The `warn_format` tag determines the format of the warning messages that Doxygen can produce.None(�
warn_line_formatqIn the $text part of the `warn_format` command it is possible that a reference to a more specific place is given.None(�
warn_logfilekThe `warn_logfile` tag can be used to specify a file to which warning and error messages should be written.None(v
inputeThe `input` tag is used to specify the files and/or directories that contain documented source files.None(y
input_encoding_This tag can be used to specify the character encoding of the source files that Doxygen parses.None(�
input_file_encoding�This tag can be used to specify the character encoding of the source files that Doxygen parses The `input_file_encoding` tag can be used to specify character encoding on a per file pattern basis.None(�
file_patterns�If the value of the `input` tag contains directories, you can use the `file_patterns` tag to specify one or more wildcard patterns (like *.cpp and *.h) to filter out the source-files in the directories.None(�
	recursivetThe `recursive` tag can be used to specify whether or not subdirectories should be searched for input files as well.None(�
excludexThe `exclude` tag can be used to specify files and/or directories that should be excluded from the `input` source files.None(�
exclude_symlinks�The `exclude_symlinks` tag can be used to select whether or not files or directories that are symbolic links (a Unix file system feature) are excluded from the input.None(�
exclude_patterns�If the value of the `input` tag contains directories, you can use the `exclude_patterns` tag to specify one or more wildcard patterns to exclude certain files from those directories.None(�
exclude_symbols�The `exclude_symbols` tag can be used to specify one or more symbol names (namespaces, classes, functions, etc.) that should be excluded from the output.None(�
example_path�The `example_path` tag can be used to specify one or more files or directories that contain example code fragments that are included (see the \include command).None(�
example_patterns�If the value of the `example_path` tag contains directories, you can use the `example_patterns` tag to specify one or more wildcard pattern (like *.cpp and *.h) to filter out the source-files in the directories.None(�
example_recursive�If the `example_recursive` tag is set to `True` then subdirectories will be searched for input files to be used with the \include or \dontinclude commands irrespective of the value of the `recursive` tag.None(�

image_path�The `image_path` tag can be used to specify one or more files or directories that contain images that are to be included in the documentation (see the \image command).None(�
input_filterqThe `input_filter` tag can be used to specify a program that Doxygen should invoke to filter for each input file.None(p
filter_patternsUThe `filter_patterns` tag can be used to specify filters on a per file pattern basis.None(�
filter_source_files�If the `filter_source_files` tag is set to `True`, the input filter (if set using `input_filter`) will also be used to filter the input files that are used for producing the source files to browse (i.e. when `source_browser` is set to `True`).None(z
filter_source_patternsXThe `filter_source_patterns` tag can be used to specify source filters per file pattern.None(�
use_mdfile_as_mainpage�If the `use_mdfile_as_mainpage` tag refers to the name of a markdown file that is part of the input, its contents will be placed on the main page (index.html).None(�
implicit_dir_docs�If the implicit_dir_docs tag is set to `True`, any README.md file found in subdirectories of the project's root, is used as the documentation for that subdirectory, except when the README.md starts with a \dir, \page or \mainpage command.None(�
fortran_comment_after�The Fortran standard specifies that for fixed formatted Fortran code all characters from position 72 are to be considered as comment.None(u
source_browser[If the `source_browser` tag is set to `True` then a list of source files will be generated.None(�
inline_sources�Setting the `inline_sources` tag to `True` will include the body of functions, multi-line macros, enums or list initialized variables directly into the documentation.None(�
strip_code_comments�Setting the `strip_code_comments` tag to `True` will instruct Doxygen to hide any special comment blocks from generated source code fragments.None(�
referenced_by_relation�If the `referenced_by_relation` tag is set to `True` then for each documented entity all documented functions referencing it will be listed.None(�
references_relation�If the `references_relation` tag is set to `True` then for each documented function all documented entities called/used by that function will be listed.None(�
references_link_source�If the `references_link_source` tag is set to `True` and `source_browser` tag is set to `True` then the hyperlinks from functions in `references_relation` and `referenced_by_relation` lists will link to the source code.None(�
source_tooltips�If `source_tooltips` is enabled (the default) then hovering a hyperlink in the source code will show a tooltip with additional information such as prototype, brief description and links to the definition and documentation.None(�
	use_htags�If the `use_htags` tag is set to `True` then the references to source code will point to the HTML generated by the htags(1) tool instead of Doxygen built-in source browser.None(�
verbatim_headers�If the `verbatim_headers` tag is set the `True` then Doxygen will generate a verbatim copy of the header file for each class for which an include is specified.None(�
clang_assisted_parsing�If the `clang_assisted_parsing` tag is set to `True` then Doxygen will use the clang parser (see: http://clang.llvm.org/) for more accurate parsing at the cost of reduced performance.None(�
clang_add_inc_paths�If the `clang_assisted_parsing` tag is set to `True` and the `clang_add_inc_paths` tag is set to `True` then Doxygen will add the directory of each input to the include path.None(�
clang_options�If clang assisted parsing is enabled you can provide the compiler with command line options that you would normally use when invoking the compiler.None(�
clang_database_path�If clang assisted parsing is enabled you can provide the clang parser with the path to the directory containing a file called compile_commands.json.None(�
alphabetical_indexkIf the `alphabetical_index` tag is set to `True`, an alphabetical index of all compounds will be generated.None(�
ignore_prefix�The `ignore_prefix` tag can be used to specify a prefix (or a list of prefixes) that should be ignored while generating the index headers.None(�
generate_htmllIf the `generate_html` tag is set to `True`, Doxygen will generate HTML output The default value is: `True`.None(`
html_outputIThe `html_output` tag is used to specify where the HTML docs will be put.None(�
html_file_extension�The `html_file_extension` tag can be used to specify the file extension for each generated HTML page (for example: .htm, .php, .asp).None(�
html_headerjThe `html_header` tag can be used to specify a user-defined HTML header file for each generated HTML page.None(|
html_footereThe `html_footer` tag can be used to specify a user-defined HTML footer for each generated HTML page.None(�
html_stylesheetuThe `html_stylesheet` tag can be used to specify a user-defined cascading style sheet that is used by each HTML page.None(�
html_extra_stylesheet�The `html_extra_stylesheet` tag can be used to specify additional user-defined cascading style sheets that are included after the standard style sheets created by Doxygen.None(�
html_extra_files�The `html_extra_files` tag can be used to specify one or more extra images or other source files which should be copied to the HTML output directory.None(�
html_colorstyle|The `html_colorstyle` tag can be used to specify if the generated HTML output should be rendered with a dark or light theme.None(c
html_colorstyle_hueDThe `html_colorstyle_hue` tag controls the color of the HTML output.None(�
html_colorstyle_satcThe `html_colorstyle_sat` tag controls the purity (or saturation) of the colors in the HTML output.None(�
html_colorstyle_gamma�The `html_colorstyle_gamma` tag controls the gamma correction applied to the luminance component of the colors in the HTML output.None(�
html_dynamic_menus�If the `html_dynamic_menus` tag is set to `True` then the generated HTML documentation will contain a main index with vertical navigation menus that are dynamically created via JavaScript.None(�
html_dynamic_sections�If the `html_dynamic_sections` tag is set to `True` then the generated HTML documentation will contain sections that can be hidden and shown after the page has loaded.None(�
html_code_folding�If the `html_code_folding` tag is set to `True` then classes and functions can be dynamically folded and expanded in the generated HTML source code.None(�
html_copy_clipboard�If the `html_copy_clipboard` tag is set to `True` then Doxygen will show an icon in the top right corner of code and text fragments that allows the user to copy its content to the clipboard.None(r
html_project_cookieSDoxygen stores a couple of settings persistently in the browser (via e.g. cookies).None(�
html_index_num_entries�With `html_index_num_entries` one can control the preferred number of entries shown in the various tree structured indices initially; the user can expand and collapse entries dynamically later on.None(�
generate_docset�If the `generate_docset` tag is set to `True`, additional index files will be generated that can be used as input for Apple's Xcode 3 integrated development environment (see: https://developer.apple.com/xcode/), introduced with OSX 10.5 (Leopard).None(K
docset_feedname0This tag determines the name of the docset feed.None(I
docset_feedurl/This tag determines the URL of the docset feed.None(s
docset_bundle_idWThis tag specifies a string that should uniquely identify the documentation set bundle.None(�
docset_publisher_idkThe `docset_publisher_id` tag specifies a string that should uniquely identify the documentation publisher.None(h
docset_publisher_nameGThe `docset_publisher_name` tag identifies the documentation publisher.None(�
generate_htmlhelp�If the `generate_htmlhelp` tag is set to `True` then Doxygen generates three additional HTML index files: index.hhp, index.hhc, and index.hhk.None(g
chm_fileSThe `chm_file` tag can be used to specify the file name of the resulting .chm file.None(�
hhc_location�The `hhc_location` tag can be used to specify the location (absolute path including file name) of the HTML help compiler (hhc.exe).None(�
generate_chi�The `generate_chi` flag controls if a separate .chi index file is generated (YES) or that it should be included in the main .chm file (NO).None(�
chm_index_encodinghThe `chm_index_encoding` is used to encode HtmlHelp index (hhk), content (hhc) and project file content.None(�

binary_toc�The `binary_toc` flag controls whether a binary table of contents is generated (YES) or a normal table of contents (NO) in the .chm file.None(�

toc_expand�The `toc_expand` flag can be set to `True` to add extra items for group members to the table of contents of the HTML help documentation and to the tree view.None(�
sitemap_url�The `sitemap_url` tag is used to specify the full URL of the place where the generated documentation will be placed on the server by the user during the deployment of the documentation.None(�
generate_qhp�If the `generate_qhp` tag is set to `True` and both `qhp_namespace` and `qhp_virtual_folder` are set, an additional index file will be generated that can be used as input for Qt's qhelpgenerator to generate a Qt Compressed Help (.qch) of the generated HTML documentation.None(�
qch_file{If the `qhg_location` tag is specified, the `qch_file` tag can be used to specify the file name of the resulting .qch file.None(w
qhp_namespace^The `qhp_namespace` tag specifies the namespace to use when generating Qt Help Project output.None(�
qhp_virtual_foldercThe `qhp_virtual_folder` tag specifies the namespace to use when generating Qt Help Project output.None(z
qhp_cust_filter_nameZIf the `qhp_cust_filter_name` tag is set, it specifies the name of a custom filter to add.None(�
qhp_cust_filter_attrsaThe `qhp_cust_filter_attrs` tag specifies the list of the attributes of the custom filter to add.None(�
qhp_sect_filter_attrskThe `qhp_sect_filter_attrs` tag specifies the list of the attributes this project's filter section matches.None(�
qhg_locationvThe `qhg_location` tag can be used to specify the location (absolute path including file name) of Qt's qhelpgenerator.None(�
generate_eclipsehelp�If the `generate_eclipsehelp` tag is set to `True`, additional index files will be generated, together with the HTML files, they form an Eclipse help plugin.None(J
eclipse_doc_id0A unique identifier for the Eclipse help plugin.None(�
disable_index�If you want full control over the layout of the generated HTML pages it might be necessary to disable the index and replace it with your own.None(�
generate_treeview�The `generate_treeview` tag is used to specify whether a tree-like index structure should be generated to display hierarchical information.None(�
page_outline_panel�When `generate_treeview` is set to YES, the `page_outline_panel` option determines if an additional navigation panel is shown at the right hand side of the screen, displaying an outline of the contents of the main page, similar to e.g. https://developer.android.com/reference.None(�
full_sidebar�When `generate_treeview` is set to `True`, the `full_sidebar` option determines if the side bar is limited to only the treeview area (value `False`) or if it should extend to the full height of the window (value `True`).None(�
enum_values_per_line�The `enum_values_per_line` tag can be used to set the number of enum values that Doxygen will group on one line in the generated HTML documentation.None(�
show_enum_values|When the `show_enum_values` tag is set doxygen will show the specified enumeration values besides the enumeration mnemonics.None(�
treeview_width�If the treeview is enabled (see `generate_treeview`) then this tag can be used to set the initial width (in pixels) of the frame in which the tree is shown.None(�
ext_links_in_window�If the `ext_links_in_window` option is set to `True`, Doxygen will open links to external symbols imported via tag files in a separate window.None(s
obfuscate_emailsWIf the `obfuscate_emails` tag is set to `True`, Doxygen will obfuscate email addresses.None(�
html_formula_format�If the `html_formula_format` option is set to svg, Doxygen will use the pdf2svg tool (see https://github.com/dawbarton/pdf2svg) or inkscape (see https://inkscape.org) to generate formulas as SVG images instead of PNGs for the HTML output.None(�
formula_fontsizedUse this tag to change the font size of LaTeX formulas included as images in the HTML documentation.None(�
formula_macrofile�The `formula_macrofile` can contain LaTeX \newcommand and \renewcommand commands to create new LaTeX commands to be used in formulas as building blocks.None(�
use_mathjax�Enable the `use_mathjax` option to render LaTeX formulas using MathJax (see https://www.mathjax.org) which uses client side JavaScript for the rendering instead of using pre-rendered bitmaps.None(k
mathjax_versionPWith `mathjax_version` it is possible to specify the MathJax version to be used.None(z
mathjax_format`When MathJax is enabled you can set the default output format to be used for the MathJax output.None(�
mathjax_relpath�When MathJax is enabled you need to specify the location relative to the HTML output directory using the `mathjax_relpath` option.None(�
mathjax_extensions�The `mathjax_extensions` tag can be used to specify one or more MathJax extension names that should be enabled during MathJax rendering.None(�
mathjax_codefile�The `mathjax_codefile` tag can be used to specify a file with JavaScript pieces of code that will be used on startup of the MathJax code.None(v
searchengine^When the `searchengine` tag is enabled Doxygen will generate a search box for the HTML output.None(�
server_based_search�When the `server_based_search` tag is enabled the search engine will be implemented using a web server instead of a web client using JavaScript.None(~
external_searchcWhen `external_search` tag is enabled Doxygen will no longer generate the PHP script for searching.None(�
searchengine_url�The `searchengine_url` should point to a search engine hosted by a web server which will return the search results when `external_search` is enabled.None(�
searchdata_file�When `server_based_search` and `external_search` are both enabled the unindexed search data is written to a file for indexing by an external tool.None(�
external_search_id�When `server_based_search` and `external_search` are both enabled the `external_search_id` tag can be used as an identifier for the project.None(�
extra_search_mappings�The `extra_search_mappings` tag can be used to enable searching through Doxygen projects other than the one defined by this configuration file, but that are all added to the same external search index.None(k
generate_latexQIf the `generate_latex` tag is set to `True`, Doxygen will generate LaTeX output.None(c
latex_outputKThe `latex_output` tag is used to specify where the LaTeX docs will be put.None(o
latex_cmd_nameUThe `latex_cmd_name` tag can be used to specify the LaTeX command name to be invoked.None(
makeindex_cmd_nameaThe `makeindex_cmd_name` tag can be used to specify the command name to generate index for LaTeX.None(�
latex_makeindex_cmdbThe `latex_makeindex_cmd` tag can be used to specify the command name to generate index for LaTeX.None(u
compact_latex\If the `compact_latex` tag is set to `True`, Doxygen generates more compact LaTeX documents.None(i

paper_typeSThe `paper_type` tag can be used to set the paper type that is used by the printer.None(�
extra_packages|The `extra_packages` tag can be used to specify one or more LaTeX package names that should be included in the LaTeX output.None(�
latex_headerkThe `latex_header` tag can be used to specify a user-defined LaTeX header for the generated LaTeX document.None(�
latex_footerkThe `latex_footer` tag can be used to specify a user-defined LaTeX footer for the generated LaTeX document.None(�
latex_extra_stylesheet�The `latex_extra_stylesheet` tag can be used to specify additional user-defined LaTeX style sheets that are included after the standard style sheets created by Doxygen.None(�
latex_extra_files�The `latex_extra_files` tag can be used to specify one or more extra images or other source files which should be copied to the `latex_output` output directory.None(�
pdf_hyperlinks�If the `pdf_hyperlinks` tag is set to `True`, the LaTeX that is generated is prepared for conversion to PDF (using ps2pdf or pdflatex).None(�
use_pdflatex�If the `use_pdflatex` tag is set to `True`, Doxygen will use the engine as specified with `latex_cmd_name` to generate the PDF file directly from the LaTeX files.None(g
latex_batchmodeLThe `latex_batchmode` tag signals the behavior of LaTeX in case of an error.None(�
latex_hide_indices�If the `latex_hide_indices` tag is set to `True` then Doxygen will not include the index chapters (such as File Index, Compound Index, etc.) in the output.None(�
latex_bib_styleqThe `latex_bib_style` tag can be used to specify the style to use for the bibliography, e.g. plainnat, or ieeetr.None(�
latex_emoji_directory|The `latex_emoji_directory` tag is used to specify the (relative or absolute) path from which the emoji images will be read.None(e
generate_rtfMIf the `generate_rtf` tag is set to `True`, Doxygen will generate RTF output.None(]

rtf_outputGThe `rtf_output` tag is used to specify where the RTF docs will be put.None(o
compact_rtfXIf the `compact_rtf` tag is set to `True`, Doxygen generates more compact RTF documents.None(�
rtf_hyperlinksfIf the `rtf_hyperlinks` tag is set to `True`, the RTF that is generated will contain hyperlink fields.None(E
rtf_stylesheet_file&Load stylesheet definitions from file.None(`
rtf_extensions_fileASet optional variables used in the generation of an RTF document.None(�
rtf_extra_files�The `rtf_extra_files` tag can be used to specify one or more extra images or other source files which should be copied to the `rtf_output` output directory.None(z
generate_manbIf the `generate_man` tag is set to `True`, Doxygen will generate man pages for classes and files.None(^

man_outputHThe `man_output` tag is used to specify where the man pages will be put.None(s
man_extensionZThe `man_extension` tag determines the extension that is added to the generated man pages.None(�

man_subdirxThe `man_subdir` tag determines the name of the directory created within `man_output` in which the man pages are placed.None(�
	man_links�If the `man_links` tag is set to `True` and Doxygen generates man output, then it will generate one additional man file for each entity documented in the real man page(s).None(�
generate_xml�If the `generate_xml` tag is set to `True`, Doxygen will generate an XML file that captures the structure of the code including all documentation.None(^

xml_outputHThe `xml_output` tag is used to specify where the XML pages will be put.None(�
xml_programlisting�If the `xml_programlisting` tag is set to `True`, Doxygen will dump the program listings (including syntax highlighting and cross-referencing information) to the XML output.None(�
xml_ns_memb_file_scope�If the `xml_ns_memb_file_scope` tag is set to `True`, Doxygen will include namespace members in file scope as well, matching the HTML output.None(�
generate_docbookuIf the `generate_docbook` tag is set to `True`, Doxygen will generate Docbook files that can be used to generate PDF.None(j
docbook_outputPThe `docbook_output` tag is used to specify where the Docbook pages will be put.None(�
generate_autogen_def�If the `generate_autogen_def` tag is set to `True`, Doxygen will generate an AutoGen Definitions (see https://autogen.sourceforge.net/) file that captures the structure of the code including all documentation.None(�
generate_sqlite3�If the `generate_sqlite3` tag is set to `True` Doxygen will generate a Sqlite3 database with symbols found by Doxygen stored in tables.None(m
sqlite3_outputSThe `sqlite3_output` tag is used to specify where the Sqlite3 database will be put.None(�
sqlite3_recreate_db�The `sqlite3_recreate_db` tag is set to `True`, the existing doxygen_sqlite3.db database file will be recreated with each Doxygen run.None(�
generate_perlmod�If the `generate_perlmod` tag is set to `True`, Doxygen will generate a Perl module file that captures the structure of the code including all documentation.None(�
perlmod_latex�If the `perlmod_latex` tag is set to `True`, Doxygen will generate the necessary Makefile rules, Perl scripts and LaTeX code to be able to generate PDF and DVI output from the Perl module output.None(�
perlmod_pretty�If the `perlmod_pretty` tag is set to `True`, the Perl module output will be nicely formatted so it can be parsed by a human reader.None(�
perlmod_makevar_prefix�The names of the make variables in the generated doxyrules.make file are prefixed with the string contained in `perlmod_makevar_prefix`.None(�
enable_preprocessing�If the `enable_preprocessing` tag is set to `True`, Doxygen will evaluate all C-preprocessor directives found in the sources and include files.None(�
macro_expansionfIf the `macro_expansion` tag is set to `True`, Doxygen will expand all macro names in the source code.None(�
expand_only_predef�If the `expand_only_predef` and `macro_expansion` tags are both set to `True` then the macro expansion is limited to the macros specified with the `predefined` and `expand_as_defined` tags.None(�
search_includesIf the `search_includes` tag is set to `True`, the include files in the `include_path` will be searched if a #include is found.None(�
include_path�The `include_path` tag can be used to specify one or more directories that contain include files that are not input files but should be processed by the preprocessor.None(�
include_file_patterns�You can use the `include_file_patterns` tag to specify one or more wildcard patterns (like *.h and *.hpp) to filter out the header-files in the directories.None(�

predefined�The `predefined` tag can be used to specify one or more macro names that are defined before the preprocessor is started (similar to the -D option of e.g. gcc).None(�
expand_as_defined�If the `macro_expansion` and `expand_only_predef` tags are set to `True` then this tag can be used to specify a list of macro names that should be expanded.None(�
skip_function_macros�If the `skip_function_macros` tag is set to `True` then Doxygen's preprocessor will remove all references to function-like macros that are alone on a line, have an all uppercase name, and do not end with a semicolon.None(T
tagfiles@The `tagfiles` tag can be used to specify one or more tag files.None(�
generate_tagfile�When a file name is specified after `generate_tagfile`, Doxygen will create a tag file that is based on the input files it reads.None(�
allexternals�If the `allexternals` tag is set to `True`, all external classes and namespaces will be listed in the class and namespace index.None(�
external_groupseIf the `external_groups` tag is set to `True`, all external groups will be listed in the topic index.None(�
external_pageskIf the `external_pages` tag is set to `True`, all external pages will be listed in the related pages index.None(�
hide_undoc_relations�If set to `True` the inheritance and collaboration graphs will hide inheritance and usage relations if the target is undocumented or is not a class.None(}
have_dotiIf you set the `have_dot` tag to `True` then Doxygen will assume the dot tool is available from the path.None(
dot_num_threadsdThe `dot_num_threads` specifies the number of dot invocations Doxygen is allowed to run in parallel.None(k
dot_common_attrP`dot_common_attr` is common attributes for nodes, edges and labels of subgraphs.None(P
dot_edge_attr7`dot_edge_attr` is concatenated with `dot_common_attr`.None(P
dot_node_attr7`dot_node_attr` is concatenated with `dot_common_attr`.None(�
dot_fontpathtYou can set the path where dot can find font specified with fontname in `dot_common_attr` and others dot attributes.None(�
dot_transparentsIf the `dot_transparent` tag is set to `True`, then the images generated by dot will have a transparent background.None(�
class_graph�If the `class_graph` tag is set to `True` or GRAPH or BUILTIN then Doxygen will generate a graph for each documented class showing the direct and indirect inheritance relations.None(�
collaboration_graph�If the `collaboration_graph` tag is set to `True` then Doxygen will generate a graph for each documented class showing the direct and indirect implementation dependencies (inheritance, containment, and class references variables) of the class with other documented classes.None(�
group_graphs�If the `group_graphs` tag is set to `True` then Doxygen will generate a graph for groups, showing the direct groups dependencies.None(�
uml_look�If the `uml_look` tag is set to `True`, Doxygen will generate inheritance and collaboration diagrams in a style similar to the OMG's Unified Modeling Language.None(y
uml_limit_num_fieldsYIf the `uml_look` tag is enabled, the fields and methods are shown inside the class node.None(
uml_max_edge_labels`If the `uml_look` tag is enabled, field labels are shown along the edge between two class nodes.None(�
dot_uml_details�If the `dot_uml_details` tag is set to `False`, Doxygen will show attributes and methods without types and arguments in the UML graphs.None(�
dot_wrap_thresholdmThe `dot_wrap_threshold` tag can be used to set the maximum number of characters to display on a single line.None(�
template_relations�If the `template_relations` tag is set to `True` then the inheritance and collaboration graphs will show the relations between templates and their instances.None(�
include_graph�If the `include_graph`, `enable_preprocessing` and `search_includes` tags are set to `True` then Doxygen will generate a graph for each documented file showing the direct and indirect include dependencies of the file with other documented files.None(�
included_by_graph�If the `included_by_graph`, `enable_preprocessing` and `search_includes` tags are set to `True` then Doxygen will generate a graph for each documented file showing the direct and indirect include dependencies of the file with other documented files.None(�

call_graph�If the `call_graph` tag is set to `True` then Doxygen will generate a call dependency graph for every global function or class method.None(�
caller_graph�If the `caller_graph` tag is set to `True` then Doxygen will generate a caller dependency graph for every global function or class method.None(�
graphical_hierarchy�If the `graphical_hierarchy` tag is set to `True` then Doxygen will graphical hierarchy of all classes instead of a textual one.None(�
directory_graph�If the `directory_graph` tag is set to `True` then Doxygen will show the dependencies a directory has on other directories in a graphical way.None(�
dir_graph_max_depth�The `dir_graph_max_depth` tag can be used to limit the maximum number of levels of child directories generated in directory dependency graphs by dot.None(z
dot_image_format^The `dot_image_format` tag can be used to set the image format of the images generated by dot.None(�
interactive_svg�If `dot_image_format` is set to svg, then this option can be set to `True` to enable generation of interactive SVG images that allow zooming and panning.None(g
dot_pathSThe `dot_path` tag can be used to specify the path where the dot tool can be found.None(�
dotfile_dirs�The `dotfile_dirs` tag can be used to specify one or more directories that contain dot files that are included in the documentation (see the \dotfile command).None(T
dia_path@You can include diagrams made with dia in Doxygen documentation.None(�
diafile_dirs�The `diafile_dirs` tag can be used to specify one or more directories that contain dia files that are included in the documentation (see the \diafile command).None(�
plantuml_jar_path�When using PlantUML, the `plantuml_jar_path` tag should be used to specify the path where java can find the plantuml.jar file or to the filename of jar file to be used.None(�
plantuml_cfg_filejWhen using PlantUML, the `plantuml_cfg_file` tag can be used to specify a configuration file for PlantUML.None(�
plantuml_include_pathxWhen using PlantUML, the specified paths are searched for files specified by the !include statement in a PlantUML block.None(�
plantumlfile_dirs�The plantumlfile_dirs tag can be used to specify one or more directories that contain PlantUml files that are included in the documentation (see the \plantumlfile command).None(�
dot_graph_max_nodesmThe `dot_graph_max_nodes` tag can be used to set the maximum number of nodes that will be shown in the graph.None(�
max_dot_graph_depthbThe `max_dot_graph_depth` tag can be used to set the maximum depth of the graphs generated by dot.None(�
dot_multi_targets�Set the `dot_multi_targets` tag to `True` to allow dot to generate multiple output files in one run (i.e. multiple -o and -T options on the command line).None(�
generate_legend�If the `generate_legend` tag is set to `True` Doxygen will generate a legend page explaining the meaning of the various boxes and arrows in the dot generated graphs.None(�
dot_cleanup�If the `dot_cleanup` tag is set to `True`, Doxygen will remove the intermediate files that are used to generate the various graphs.None(m
mscgen_toolVYou can define message sequence charts within Doxygen comments using the \msc command.None(�
mscfile_dirs�The `mscfile_dirs` tag can be used to specify one or more directories that contain msc files that are included in the documentation (see the \mscfile command).None(u
kwargsiAdditional arguments to pass to the rule (e.g. `visibility = ["//visibility:public"], tags = ["manual"]`)(�0Generates documentation using Doxygen.

The set of attributes the macro provides is a subset of the Doxygen configuration options.
Depending on the type of the attribute, the macro will convert it to the appropriate string:

- None (default): the attribute will not be included in the Doxyfile
- bool: the value of the attribute is the string "YES" or "NO" respectively
- list: the value of the attribute is a string with the elements separated by spaces and enclosed in double quotes
- str: the value of the attribute is will be set to the string, unchanged. You may need to provide proper quoting if the value contains spaces

For the complete list of Doxygen configuration options, please refer to the [Doxygen documentation](https://www.doxygen.nl/manual/config.html).

> [!NOTE]
> If not istructed otherwise, the rule will use the Doxyfile from its default `doxygen` version.
> Any update could change some default values or add some flags which will be unrecognized by older `doxygen` versions, resulting in innocuous warnings.
> If you want to use a specific Doxyfile, just generate one with `doxygen -g` and specify it in the `doxyfile_template` attribute.

### Make variables

There are cases where you need access to information about the build environment, such as the output directory doxygen is writing to.
In such cases, you can use make variables in the parameters of the macro.
The `doxygen` rule will take care of expanding them to the appropriate values.

By default, the following make variables are available:

- `$(OUTDIR)`: The output directory where the documentation will be generated.
- All the predefined variables indicated in the [Bazel documentation](https://bazel.build/reference/be/make-variables#predefined_variables).

The former is particularly useful when `doxygen` needs to generate unusual files, such as [tag files](https://www.doxygen.nl/manual/config.html#cfg_generate_tagfile).
An example of this is shown below, where the tag file `PolyVox.tag` is stored in the `tags` output directory.

```bzl
doxygen(
    name = "doxygen",
    srcs = ["README.md"] + glob(["*.h", "*.cpp"]),
    outs = ["html", "tags"],
    generate_tagfile = "$(OUTDIR)/tags/PolyVox.tag",
)
```

> [!NOTE]
> Make sure that generated files are put in some directory and that directory is included in the `outs` attribute.

You can add your own substitutions by adding a rule that returns a TemplateVariableInfo provider in the `toolchains` attribute of the `doxygen` rule.
See [this example](../examples/substitutions/) for more details.

### Differences between `srcs` and `deps`

The `srcs` and `deps` attributes work differently and are not interchangeable.

`srcs` is a list of files that will be passed to Doxygen for documentation generation.
You can use `glob` to include a collection of multiple files.
On the other hand, if you indicate a target (e.g., `:my_genrule`), it will include all the files produced by that target.
More precisely, the files in the DefaultInfo provider the target returns.
Hence, when the documentation is generated, all rules in the `srcs` attribute **will** be built, and the files they output will be passed to Doxygen.

On the other hand, `deps` is a list of targets whose sources will be included in the documentation generation.
It will automatically include all the files in the `srcs`, `hdrs`, and `data` attributes of the target, and the same applies to all of its transitive dependencies, recursively.
Since we are only interested in the source files, the `deps` targets **will not** be built when the documentation is generated.

```bzl
# My BUILD.bazel file
load("@doxygen//:doxygen.bzl", "doxygen")
load("@rules_cc//cc:defs.bzl", "cc_library")

cc_library(
    name = "lib",
    hdrs = ["add.h", "sub.h"],
    srcs = ["add.cpp", "sub.cpp"],
)

cc_library(
    name = "main",
    srcs = ["main.cpp"],
    deps = [":lib"],
)


genrule(
    name = "section",
    outs = ["Section.md"],
    cmd = """
        echo "# Section " > $@
        echo "This is some amazing documentation with section!!  " >> $@
        echo "Incredible." >> $@
    """,
)

doxygen(
    name = "doxygen",
    project_name = "dependencies",

    # The output of the genrule will be included in the documentation.
    # The genrule will be executed when the documentation is generated.
    srcs = [
        "README.md",  # file
        ":section",  # genrule

        # WARNING: By adding this, the main target will be built
        # and only the output files `libmain.so` and `libmain.a`
        # will be passed to Doxygen, which is likely not what you want.
        # ":main"
    ],

    # The sources of the main target and its dependencies will be included.
    # No compilation will be performed, so compile error won't be reported.
    deps = [":main"],  # cc_library

    # Always starts at the root folder
    use_mdfile_as_mainpage = "dependencies/README.md",
)
```

### Excluding Bazel specific folders

Including the root directory among the input directories, which happens when a target starting with `//:` is used as a source,
may cause Bazel specific folders, such as `external`, to be explored by Doxygen.
This can slow down the documentation generation or even cause an input buffer overflow.
To avoid this, it is recommended to use the `exclude_patterns` parameter and set it to something like `["*/external/*"]`, extending it with other patterns as needed.

### Example

```bzl
# MODULE.bazel file
bazel_dep(name = "rules_doxygen", dev_dependency = True)
doxygen_extension = use_extension("@rules_doxygen//:extensions.bzl", "doxygen_extension")
use_repo(doxygen_extension, "doxygen")
```

```bzl
# BUILD.bazel file
load("@doxygen//:doxygen.bzl", "doxygen")
load("@rules_cc//cc:defs.bzl", "cc_library")

cc_library(
    name = "lib",
    srcs = ["add.cpp", "sub.cpp"],
    hdrs = ["add.h", "sub.h"],
)

cc_library(
    name = "main",
    srcs = ["main.cpp"],
    deps = [":lib"],
)

doxygen(
    name = "doxygen",
    srcs = glob([
        "*.md",
    ]),
    deps = [":main"]
    aliases = [
        "licence=@par Licence:^^",
        "verb{1}=@verbatim \\1 @endverbatim",
    ],
    optimize_output_for_c = True,
    project_brief = "Example project for doxygen",
    project_name = "example",
)
```
2.
doxygen#@rules_doxygen//doxygen:doxygen.bzl"
 
nameName for the target. (�
�
srcs�List of source files to generate documentation for.
Can include any file that Doxygen can parse, as well as targets that return a DefaultInfo provider (usually genrules).
Since we are only considering the outputs files and not the sources, these targets **will** be built if necessary.[](�
�
deps�List of dependencies targets whose files present in the 'src', 'hdrs' and 'data' attributes will be collected to generate the documentation.
Transitive dependencies are also taken into account.
Since we are only considering the source files and not the outputs, these targets **will not** be built.[](8
6

executable Label of the doxygen executable.None(r
p
dot_executableVLabel of the doxygen executable. Make sure it is also added to the `srcs` of the macroNone([
Y
configurations?List of additional configuration parameters to pass to Doxygen.None(>
<
doxyfile_prefix#Prefix to add to the Doxyfile path.""(�
�
doxyfile_template�The template file to use to generate the Doxyfile.
The following substitutions are available:<br>
- `# {{INPUT}}`: Subpackage directory in the sandbox.<br>
- `# {{ADDITIONAL PARAMETERS}}`: Additional parameters given in the `configurations` attribute.<br>
- `# {{OUTPUT DIRECTORY}}`: The directory provided in the `outs` attribute.<br>
- `{{OUTDIR}}`: The output directory where the generated documentation will be placed.
    Can be used anywhere in the Doxyfile, usually to generate additional output files, like tag files.None(P
N
doxygen_extra_args2Extra arguments to pass to the doxygen executable.[](f
d
use_default_shell_envBWhether to use the default shell environment when running doxygen.False(L
J
env=Additional environment variables to set when running doxygen.{}(�
�
tools�List of additional tools to include in the doxygen environment. Tools are executable inputs that may have their own runfiles which are automatically made available to the action.[](�
�
outs�Output folders bazel will keep. If only the html outputs is of interest, the default value will do.
otherwise, a list of folders to keep is expected (e.g. ["html", "latex"]).
Note that the rule will also generate an output group for each folder in the outs list having the same name.["html"](}
{
doxyfile_encoding^This tag specifies the encoding used for all characters in the configuration file that follow.None(�
�
project_name�The `project_name` tag is a single word (or a sequence of words surrounded by double-quotes, unless you are using Doxywizard) that should identify the project for which the documentation is generated.None(g
e
project_numberKThe `project_number` tag can be used to enter a project or revision number.None(�
�
project_brief�Using the `project_brief` tag one can provide an optional one line description for a project that appears at the top of each page and should give viewer a quick idea about the purpose of the project.None(~
|
project_logodWith the `project_logo` tag one can specify a logo or an icon that is included in the documentation.None(�
�
project_iconqWith the `project_icon` tag one can specify an icon that is included in the tabs when the HTML document is shown.None(�
�
create_subdirs�If the `create_subdirs` tag is set to `True` then Doxygen will create up to 4096 sub-directories (in 2 levels) under the output directory of each output format and will distribute the generated files over these directories.None(�
�
create_subdirs_levelgControls the number of sub-directories that will be created when `create_subdirs` tag is set to `True`.None(�
�
allow_unicode_names�If the `allow_unicode_names` tag is set to `True`, Doxygen will allow non-ASCII characters to appear in the names of generated files.None(�
�
output_languageuThe `output_language` tag is used to specify the language in which all documentation generated by Doxygen is written.None(�
�
brief_member_desc�If the `brief_member_desc` tag is set to `True`, Doxygen will include brief member descriptions after the members that are listed in the file and class documentation (similar to Javadoc).None(�
�
repeat_brief�If the `repeat_brief` tag is set to `True`, Doxygen will prepend the brief description of a member or function before the detailed description Note: If both `hide_undoc_members` and `brief_member_desc` are set to `False`, the brief descriptions will be completely suppressed.None(�
�
abbreviate_briefxThis tag implements a quasi-intelligent brief description abbreviator that is used to form the text in various listings.None(�
�
always_detailed_sec�If the `always_detailed_sec` and `repeat_brief` tags are both set to `True` then Doxygen will generate a detailed section even if there is only a brief description.None(�
�
inline_inherited_memb�If the `inline_inherited_memb` tag is set to `True`, Doxygen will show all inherited members of a class in the documentation of that class as if those members were ordinary class members.None(�
�
full_path_names�If the `full_path_names` tag is set to `True`, Doxygen will prepend the full path before files name in the file list and in the header files.None(l
j
strip_from_pathOThe `strip_from_path` tag can be used to strip a user-defined part of the path.None(�
�
strip_from_inc_path�The `strip_from_inc_path` tag can be used to strip a user-defined part of the path mentioned in the documentation of a class, which tells the reader which header file to include in order to use a class.None(�
�
short_namesmIf the `short_names` tag is set to `True`, Doxygen will generate much shorter (but less readable) file names.None(�
�
javadoc_autobrief�If the `javadoc_autobrief` tag is set to `True` then Doxygen will interpret the first line (until the first dot) of a Javadoc-style comment as the brief description.None(�
�
javadoc_banner�If the `javadoc_banner` tag is set to `True` then Doxygen will interpret a line such as /*************** as being the beginning of a Javadoc-style comment "banner".None(�
�
qt_autobrief�If the `qt_autobrief` tag is set to `True` then Doxygen will interpret the first line (until the first dot) of a Qt-style comment as the brief description.None(�
�
multiline_cpp_is_brief�The `multiline_cpp_is_brief` tag can be set to `True` to make Doxygen treat a multi-line C++ special comment block (i.e. a block of //! or /// comments) as a brief description.None(�
�
python_docstringnBy default Python docstrings are displayed as preformatted text and Doxygen's special commands cannot be used.None(�
�
inherit_docs�If the `inherit_docs` tag is set to `True` then an undocumented member inherits the documentation from any documented member that it re-implements.None(�
�
separate_member_pagesiIf the `separate_member_pages` tag is set to `True` then Doxygen will produce a new page for each member.None(Z
X
tab_sizeDThe `tab_size` tag can be used to set the number of spaces in a tab.None(s
q
aliases^This tag can be used to specify a number of aliases that act as commands in the documentation.None(|
z
optimize_output_for_cYSet the `optimize_output_for_c` tag to `True` if your project consists of C sources only.None(�
�
optimize_output_javaeSet the `optimize_output_java` tag to `True` if your project consists of Java or Python sources only.None({
y
optimize_for_fortranYSet the `optimize_for_fortran` tag to `True` if your project consists of Fortran sources.None(x
v
optimize_output_vhdlVSet the `optimize_output_vhdl` tag to `True` if your project consists of VHDL sources.None(�
~
optimize_output_slice]Set the `optimize_output_slice` tag to `True` if your project consists of Slice sources only.None(s
q
extension_mappingTDoxygen selects the parser to use depending on the extension of the files it parses.None(�
�
markdown_support�If the `markdown_support` tag is enabled then Doxygen pre-processes all comments according to the Markdown format, which allows for more readable documentation.None(�
�
markdown_strict�If the markdown_strict tag is enabled then Doxygen treats text in comments as Markdown formatted also in cases where Doxygen's native markup format conflicts with that of Markdown.None(�
�
toc_include_headings�When the `toc_include_headings` tag is set to a non-zero value, all headings up to that level are automatically included in the table of contents, even if they do not have an id attribute.None(�
�
markdown_id_stylexThe `markdown_id_style` tag can be used to specify the algorithm used to generate identifiers for the Markdown headings.None(�
�
autolink_support�When enabled Doxygen tries to link words that correspond to documented classes, or namespaces to their corresponding documentation.None(�
�
autolink_ignore_words�This tag specifies a list of words that, when matching the start of a word in the documentation, will suppress auto links generation, if it is enabled via autolink_support.None(�
�
builtin_stl_support�If you use STL classes (i.e. std::string, std::vector, etc.) but do not want to include (a tag file for) the STL sources as input, then you should set this tag to `True` in order to let Doxygen match functions declarations and definitions whose arguments contain STL classes (e.g. func(std::string); versus func(std::string) {}).None(�
�
cpp_cli_supporthIf you use Microsoft's C++/CLI language, you should set this option to `True` to enable parsing support.None(�
�
sip_support�Set the `sip_support` tag to `True` if your project consists of sip (see: https://www.riverbankcomputing.com/software) sources only.None(�
�
idl_property_supportrFor Microsoft's IDL there are propget and propput attributes to indicate getter and setter methods for a property.None(�
�
distribute_group_doc�If member grouping is used in the documentation and the `distribute_group_doc` tag is set to `True` then Doxygen will reuse the documentation of the first member in the group (if any) for the other members of the group.None(�
�
group_nested_compounds�If one adds a struct or class to a group and this option is enabled, then also any nested class or struct is added to the same group.None(�
�
subgrouping�Set the `subgrouping` tag to `True` to allow class member groups of the same type (for instance a group of public functions) to be put as a subgroup of that type (e.g. under the Public Functions section).None(�
�
inline_grouped_classes�When the `inline_grouped_classes` tag is set to `True`, classes, structs and unions are shown inside the group in which they are included (e.g. using \ingroup) instead of on a separate page (for HTML and Man pages) or section (for LaTeX and RTF).None(�
�
inline_simple_structs�When the `inline_simple_structs` tag is set to `True`, structs, classes, and unions with only public data fields or simple typedef fields will be shown inline in the documentation of the scope in which they are defined (i.e. file, namespace, or group documentation), provided this scope is documented.None(�
�
typedef_hides_struct�When `typedef_hides_struct` tag is enabled, a typedef of a struct, union, or enum is documented as struct, union, or enum with the name of the typedef.None(h
f
lookup_cache_sizeIThe size of the symbol lookup cache can be set using `lookup_cache_size`.None(�

num_proc_threadscThe `num_proc_threads` specifies the number of threads Doxygen is allowed to use during processing.None(�
�
	timestamp�If the `timestamp` tag is set different from `False` then each generated page will contain the date or date and time when the page was generated.None(�
�
extract_all�If the `extract_all` tag is set to `True`, Doxygen will assume all entities in documentation are documented, even if no documentation was available.None(�
�
extract_privatetIf the `extract_private` tag is set to `True`, all private members of a class will be included in the documentation.None(�
�
extract_priv_virtual�If the `extract_priv_virtual` tag is set to `True`, documented private virtual methods of a class will be included in the documentation.None(�
�
extract_package�If the `extract_package` tag is set to `True`, all members with package or internal scope will be included in the documentation.None(�
�
extract_staticqIf the `extract_static` tag is set to `True`, all static members of a file will be included in the documentation.None(�
�
extract_local_classes�If the `extract_local_classes` tag is set to `True`, classes (and structs) defined locally in source files will be included in the documentation.None(Q
O
extract_local_methods.This flag is only useful for Objective-C code.None(�
�
extract_anon_nspaces�If this flag is set to `True`, the members of anonymous namespaces will be extracted and appear in the documentation as a namespace called 'anonymous_namespace{file}', where file will be replaced with the base name of the file that contains the anonymous namespace.None(�
�
resolve_unnamed_params�If this flag is set to `True`, the name of an unnamed parameter in a declaration will be determined by the corresponding definition.None(�
�
hide_undoc_members�If the `hide_undoc_members` tag is set to `True`, Doxygen will hide all undocumented members inside documented classes or files.None(�
�
hide_undoc_classes�If the `hide_undoc_classes` tag is set to `True`, Doxygen will hide all undocumented classes that are normally visible in the class hierarchy.None(�
�
hide_undoc_namespaces�If the hide_undoc_namespaces tag is set to YES, Doxygen will hide all undocumented namespaces that are normally visible in the namespace hierarchy.None(�
�
hide_friend_compounds_If the `hide_friend_compounds` tag is set to `True`, Doxygen will hide all friend declarations.None(�
�
hide_in_body_docs�If the `hide_in_body_docs` tag is set to `True`, Doxygen will hide any documentation blocks found inside the body of a function.None(�
�
internal_docshThe `internal_docs` tag determines if documentation that is typed after a \internal command is included.None(�
�
case_sense_names�With the correct setting of option `case_sense_names` Doxygen will better be able to match the capabilities of the underlying filesystem.None(�
�
hide_scope_names�If the `hide_scope_names` tag is set to `False` then Doxygen will show members with their full class and namespace scopes in the documentation.None(�
�
hide_compound_reference�If the `hide_compound_reference` tag is set to `False` (default) then Doxygen will append additional text to a page's title, such as Class Reference.None(�
�
show_headerfile�If the `show_headerfile` tag is set to `True` then the documentation for a class will show which file needs to be included to use the class.None(�
�
show_include_files�If the `show_include_files` tag is set to `True` then Doxygen will put a list of the files that are included by a file in the documentation of that file.None(�
�
show_grouped_memb_inc�If the `show_grouped_memb_inc` tag is set to `True` then Doxygen will add for each grouped member an include statement to the documentation, telling the reader which file to include in order to use the member.None(�
�
force_local_includes�If the `force_local_includes` tag is set to `True` then Doxygen will list include files with double quotes in the documentation rather than with sharp brackets.None(�
�
inline_inforIf the `inline_info` tag is set to `True` then a tag [inline] is inserted in the documentation for inline members.None(�
�
sort_member_docs�If the `sort_member_docs` tag is set to `True` then Doxygen will sort the (detailed) documentation of file and class members alphabetically by member name.None(�
�
sort_brief_docs�If the `sort_brief_docs` tag is set to `True` then Doxygen will sort the brief descriptions of file, namespace and class members alphabetically by member name.None(�
�
sort_members_ctors_1st�If the `sort_members_ctors_1st` tag is set to `True` then Doxygen will sort the (brief and detailed) documentation of class members so that constructors and destructors are listed first.None(�
�
sort_group_names{If the `sort_group_names` tag is set to `True` then Doxygen will sort the hierarchy of group names into alphabetical order.None(�
�
sort_by_scope_nameIf the `sort_by_scope_name` tag is set to `True`, the class list will be sorted by fully-qualified names, including namespaces.None(�
�
strict_proto_matching�If the `strict_proto_matching` option is enabled and Doxygen fails to do proper type resolution of all parameters of a function it will reject a match between the prototype and the implementation of a member function even if there is only one candidate or it is obvious which candidate to choose by doing a simple string match.None(u
s
generate_todolistVThe `generate_todolist` tag can be used to enable (YES) or disable (NO) the todo list.None(u
s
generate_testlistVThe `generate_testlist` tag can be used to enable (YES) or disable (NO) the test list.None(r
p
generate_buglistTThe `generate_buglist` tag can be used to enable (YES) or disable (NO) the bug list.None(�
�
generate_deprecatedlistbThe `generate_deprecatedlist` tag can be used to enable (YES) or disable (NO) the deprecated list.None(�
�
enabled_sections�The `enabled_sections` tag can be used to enable conditional documentation sections, marked by \if <section_label> ... \endif and \cond <section_label> ... \endcond blocks.None(�
�
max_initializer_lines�The `max_initializer_lines` tag determines the maximum number of lines that the initial value of a variable or macro / define can have for it to appear in the documentation.None(�
�
show_used_files�Set the `show_used_files` tag to `False` to disable the list of files generated at the bottom of the documentation of classes and structs.None(h
f

show_filesPSet the `show_files` tag to `False` to disable the generation of the Files page.None(w
u
show_namespacesZSet the `show_namespaces` tag to `False` to disable the generation of the Namespaces page.None(�
�
file_version_filter�The `file_version_filter` tag can be used to specify a program or script that Doxygen should invoke to get the current version for each file (typically from the version control system).None(t
r
layout_file[The `layout_file` tag can be used to specify a layout file which will be parsed by Doxygen.None(�
�
cite_bib_fileskThe `cite_bib_files` tag can be used to specify one or more bib files containing the reference definitions.None(�
�
external_tool_path�The `external_tool_path` tag can be used to extend the search path (PATH environment variable) so that external tools such as latex and gs can be found.None(|
z
quietiThe `quiet` tag can be used to turn on/off the messages that are generated to standard output by Doxygen.None(�
�
warnings|The `warnings` tag can be used to turn on/off the warning messages that are generated to standard error (stderr) by Doxygen.None(�
�
warn_if_undocumentedpIf the `warn_if_undocumented` tag is set to `True` then Doxygen will generate warnings for undocumented members.None(�
�
warn_if_doc_error�If the `warn_if_doc_error` tag is set to `True`, Doxygen will generate warnings for potential errors in the documentation, such as documenting some parameters in a documented function twice, or documenting parameters that don't exist or using markup commands wrongly.None(�
�
warn_if_incomplete_docrIf `warn_if_incomplete_doc` is set to `True`, Doxygen will warn about incomplete function parameter documentation.None(�
�
warn_no_paramdoc�This `warn_no_paramdoc` option can be enabled to get warnings for functions that are documented, but have no documentation for their parameters or return value.None(�
�
warn_if_undoc_enum_valmIf `warn_if_undoc_enum_val` option is set to `True`, Doxygen will warn about undocumented enumeration values.None(�
�
warn_layout_file�If warn_layout_file option is set to `True`, Doxygen will warn about issues found while parsing the user defined layout file, such as missing or wrong elementsNone(�
�
warn_as_errormIf the `warn_as_error` tag is set to `True` then Doxygen will immediately stop when a warning is encountered.None(v
t
warn_format]The `warn_format` tag determines the format of the warning messages that Doxygen can produce.None(�
�
warn_line_formatqIn the $text part of the `warn_format` command it is possible that a reference to a more specific place is given.None(�
�
warn_logfilekThe `warn_logfile` tag can be used to specify a file to which warning and error messages should be written.None(x
v
inputeThe `input` tag is used to specify the files and/or directories that contain documented source files.None({
y
input_encoding_This tag can be used to specify the character encoding of the source files that Doxygen parses.None(�
�
input_file_encoding�This tag can be used to specify the character encoding of the source files that Doxygen parses The `input_file_encoding` tag can be used to specify character encoding on a per file pattern basis.None(�
�
file_patterns�If the value of the `input` tag contains directories, you can use the `file_patterns` tag to specify one or more wildcard patterns (like *.cpp and *.h) to filter out the source-files in the directories.None(�
�
	recursivetThe `recursive` tag can be used to specify whether or not subdirectories should be searched for input files as well.None(�
�
excludexThe `exclude` tag can be used to specify files and/or directories that should be excluded from the `input` source files.None(�
�
exclude_symlinks�The `exclude_symlinks` tag can be used to select whether or not files or directories that are symbolic links (a Unix file system feature) are excluded from the input.None(�
�
exclude_patterns�If the value of the `input` tag contains directories, you can use the `exclude_patterns` tag to specify one or more wildcard patterns to exclude certain files from those directories.None(�
�
exclude_symbols�The `exclude_symbols` tag can be used to specify one or more symbol names (namespaces, classes, functions, etc.) that should be excluded from the output.None(�
�
example_path�The `example_path` tag can be used to specify one or more files or directories that contain example code fragments that are included (see the \include command).None(�
�
example_patterns�If the value of the `example_path` tag contains directories, you can use the `example_patterns` tag to specify one or more wildcard pattern (like *.cpp and *.h) to filter out the source-files in the directories.None(�
�
example_recursive�If the `example_recursive` tag is set to `True` then subdirectories will be searched for input files to be used with the \include or \dontinclude commands irrespective of the value of the `recursive` tag.None(�
�

image_path�The `image_path` tag can be used to specify one or more files or directories that contain images that are to be included in the documentation (see the \image command).None(�
�
input_filterqThe `input_filter` tag can be used to specify a program that Doxygen should invoke to filter for each input file.None(r
p
filter_patternsUThe `filter_patterns` tag can be used to specify filters on a per file pattern basis.None(�
�
filter_source_files�If the `filter_source_files` tag is set to `True`, the input filter (if set using `input_filter`) will also be used to filter the input files that are used for producing the source files to browse (i.e. when `source_browser` is set to `True`).None(|
z
filter_source_patternsXThe `filter_source_patterns` tag can be used to specify source filters per file pattern.None(�
�
use_mdfile_as_mainpage�If the `use_mdfile_as_mainpage` tag refers to the name of a markdown file that is part of the input, its contents will be placed on the main page (index.html).None(�
�
implicit_dir_docs�If the implicit_dir_docs tag is set to `True`, any README.md file found in subdirectories of the project's root, is used as the documentation for that subdirectory, except when the README.md starts with a \dir, \page or \mainpage command.None(�
�
fortran_comment_after�The Fortran standard specifies that for fixed formatted Fortran code all characters from position 72 are to be considered as comment.None(w
u
source_browser[If the `source_browser` tag is set to `True` then a list of source files will be generated.None(�
�
inline_sources�Setting the `inline_sources` tag to `True` will include the body of functions, multi-line macros, enums or list initialized variables directly into the documentation.None(�
�
strip_code_comments�Setting the `strip_code_comments` tag to `True` will instruct Doxygen to hide any special comment blocks from generated source code fragments.None(�
�
referenced_by_relation�If the `referenced_by_relation` tag is set to `True` then for each documented entity all documented functions referencing it will be listed.None(�
�
references_relation�If the `references_relation` tag is set to `True` then for each documented function all documented entities called/used by that function will be listed.None(�
�
references_link_source�If the `references_link_source` tag is set to `True` and `source_browser` tag is set to `True` then the hyperlinks from functions in `references_relation` and `referenced_by_relation` lists will link to the source code.None(�
�
source_tooltips�If `source_tooltips` is enabled (the default) then hovering a hyperlink in the source code will show a tooltip with additional information such as prototype, brief description and links to the definition and documentation.None(�
�
	use_htags�If the `use_htags` tag is set to `True` then the references to source code will point to the HTML generated by the htags(1) tool instead of Doxygen built-in source browser.None(�
�
verbatim_headers�If the `verbatim_headers` tag is set the `True` then Doxygen will generate a verbatim copy of the header file for each class for which an include is specified.None(�
�
clang_assisted_parsing�If the `clang_assisted_parsing` tag is set to `True` then Doxygen will use the clang parser (see: http://clang.llvm.org/) for more accurate parsing at the cost of reduced performance.None(�
�
clang_add_inc_paths�If the `clang_assisted_parsing` tag is set to `True` and the `clang_add_inc_paths` tag is set to `True` then Doxygen will add the directory of each input to the include path.None(�
�
clang_options�If clang assisted parsing is enabled you can provide the compiler with command line options that you would normally use when invoking the compiler.None(�
�
clang_database_path�If clang assisted parsing is enabled you can provide the clang parser with the path to the directory containing a file called compile_commands.json.None(�
�
alphabetical_indexkIf the `alphabetical_index` tag is set to `True`, an alphabetical index of all compounds will be generated.None(�
�
ignore_prefix�The `ignore_prefix` tag can be used to specify a prefix (or a list of prefixes) that should be ignored while generating the index headers.None(�
�
generate_htmllIf the `generate_html` tag is set to `True`, Doxygen will generate HTML output The default value is: `True`.None(b
`
html_outputIThe `html_output` tag is used to specify where the HTML docs will be put.None(�
�
html_file_extension�The `html_file_extension` tag can be used to specify the file extension for each generated HTML page (for example: .htm, .php, .asp).None(�
�
html_headerjThe `html_header` tag can be used to specify a user-defined HTML header file for each generated HTML page.None(~
|
html_footereThe `html_footer` tag can be used to specify a user-defined HTML footer for each generated HTML page.None(�
�
html_stylesheetuThe `html_stylesheet` tag can be used to specify a user-defined cascading style sheet that is used by each HTML page.None(�
�
html_extra_stylesheet�The `html_extra_stylesheet` tag can be used to specify additional user-defined cascading style sheets that are included after the standard style sheets created by Doxygen.None(�
�
html_extra_files�The `html_extra_files` tag can be used to specify one or more extra images or other source files which should be copied to the HTML output directory.None(�
�
html_colorstyle|The `html_colorstyle` tag can be used to specify if the generated HTML output should be rendered with a dark or light theme.None(e
c
html_colorstyle_hueDThe `html_colorstyle_hue` tag controls the color of the HTML output.None(�
�
html_colorstyle_satcThe `html_colorstyle_sat` tag controls the purity (or saturation) of the colors in the HTML output.None(�
�
html_colorstyle_gamma�The `html_colorstyle_gamma` tag controls the gamma correction applied to the luminance component of the colors in the HTML output.None(�
�
html_dynamic_menus�If the `html_dynamic_menus` tag is set to `True` then the generated HTML documentation will contain a main index with vertical navigation menus that are dynamically created via JavaScript.None(�
�
html_dynamic_sections�If the `html_dynamic_sections` tag is set to `True` then the generated HTML documentation will contain sections that can be hidden and shown after the page has loaded.None(�
�
html_code_folding�If the `html_code_folding` tag is set to `True` then classes and functions can be dynamically folded and expanded in the generated HTML source code.None(�
�
html_copy_clipboard�If the `html_copy_clipboard` tag is set to `True` then Doxygen will show an icon in the top right corner of code and text fragments that allows the user to copy its content to the clipboard.None(t
r
html_project_cookieSDoxygen stores a couple of settings persistently in the browser (via e.g. cookies).None(�
�
html_index_num_entries�With `html_index_num_entries` one can control the preferred number of entries shown in the various tree structured indices initially; the user can expand and collapse entries dynamically later on.None(�
�
generate_docset�If the `generate_docset` tag is set to `True`, additional index files will be generated that can be used as input for Apple's Xcode 3 integrated development environment (see: https://developer.apple.com/xcode/), introduced with OSX 10.5 (Leopard).None(M
K
docset_feedname0This tag determines the name of the docset feed.None(K
I
docset_feedurl/This tag determines the URL of the docset feed.None(u
s
docset_bundle_idWThis tag specifies a string that should uniquely identify the documentation set bundle.None(�
�
docset_publisher_idkThe `docset_publisher_id` tag specifies a string that should uniquely identify the documentation publisher.None(j
h
docset_publisher_nameGThe `docset_publisher_name` tag identifies the documentation publisher.None(�
�
generate_htmlhelp�If the `generate_htmlhelp` tag is set to `True` then Doxygen generates three additional HTML index files: index.hhp, index.hhc, and index.hhk.None(i
g
chm_fileSThe `chm_file` tag can be used to specify the file name of the resulting .chm file.None(�
�
hhc_location�The `hhc_location` tag can be used to specify the location (absolute path including file name) of the HTML help compiler (hhc.exe).None(�
�
generate_chi�The `generate_chi` flag controls if a separate .chi index file is generated (YES) or that it should be included in the main .chm file (NO).None(�
�
chm_index_encodinghThe `chm_index_encoding` is used to encode HtmlHelp index (hhk), content (hhc) and project file content.None(�
�

binary_toc�The `binary_toc` flag controls whether a binary table of contents is generated (YES) or a normal table of contents (NO) in the .chm file.None(�
�

toc_expand�The `toc_expand` flag can be set to `True` to add extra items for group members to the table of contents of the HTML help documentation and to the tree view.None(�
�
sitemap_url�The `sitemap_url` tag is used to specify the full URL of the place where the generated documentation will be placed on the server by the user during the deployment of the documentation.None(�
�
generate_qhp�If the `generate_qhp` tag is set to `True` and both `qhp_namespace` and `qhp_virtual_folder` are set, an additional index file will be generated that can be used as input for Qt's qhelpgenerator to generate a Qt Compressed Help (.qch) of the generated HTML documentation.None(�
�
qch_file{If the `qhg_location` tag is specified, the `qch_file` tag can be used to specify the file name of the resulting .qch file.None(y
w
qhp_namespace^The `qhp_namespace` tag specifies the namespace to use when generating Qt Help Project output.None(�
�
qhp_virtual_foldercThe `qhp_virtual_folder` tag specifies the namespace to use when generating Qt Help Project output.None(|
z
qhp_cust_filter_nameZIf the `qhp_cust_filter_name` tag is set, it specifies the name of a custom filter to add.None(�
�
qhp_cust_filter_attrsaThe `qhp_cust_filter_attrs` tag specifies the list of the attributes of the custom filter to add.None(�
�
qhp_sect_filter_attrskThe `qhp_sect_filter_attrs` tag specifies the list of the attributes this project's filter section matches.None(�
�
qhg_locationvThe `qhg_location` tag can be used to specify the location (absolute path including file name) of Qt's qhelpgenerator.None(�
�
generate_eclipsehelp�If the `generate_eclipsehelp` tag is set to `True`, additional index files will be generated, together with the HTML files, they form an Eclipse help plugin.None(L
J
eclipse_doc_id0A unique identifier for the Eclipse help plugin.None(�
�
disable_index�If you want full control over the layout of the generated HTML pages it might be necessary to disable the index and replace it with your own.None(�
�
generate_treeview�The `generate_treeview` tag is used to specify whether a tree-like index structure should be generated to display hierarchical information.None(�
�
page_outline_panel�When `generate_treeview` is set to YES, the `page_outline_panel` option determines if an additional navigation panel is shown at the right hand side of the screen, displaying an outline of the contents of the main page, similar to e.g. https://developer.android.com/reference.None(�
�
full_sidebar�When `generate_treeview` is set to `True`, the `full_sidebar` option determines if the side bar is limited to only the treeview area (value `False`) or if it should extend to the full height of the window (value `True`).None(�
�
enum_values_per_line�The `enum_values_per_line` tag can be used to set the number of enum values that Doxygen will group on one line in the generated HTML documentation.None(�
�
show_enum_values|When the `show_enum_values` tag is set doxygen will show the specified enumeration values besides the enumeration mnemonics.None(�
�
treeview_width�If the treeview is enabled (see `generate_treeview`) then this tag can be used to set the initial width (in pixels) of the frame in which the tree is shown.None(�
�
ext_links_in_window�If the `ext_links_in_window` option is set to `True`, Doxygen will open links to external symbols imported via tag files in a separate window.None(u
s
obfuscate_emailsWIf the `obfuscate_emails` tag is set to `True`, Doxygen will obfuscate email addresses.None(�
�
html_formula_format�If the `html_formula_format` option is set to svg, Doxygen will use the pdf2svg tool (see https://github.com/dawbarton/pdf2svg) or inkscape (see https://inkscape.org) to generate formulas as SVG images instead of PNGs for the HTML output.None(�
�
formula_fontsizedUse this tag to change the font size of LaTeX formulas included as images in the HTML documentation.None(�
�
formula_macrofile�The `formula_macrofile` can contain LaTeX \newcommand and \renewcommand commands to create new LaTeX commands to be used in formulas as building blocks.None(�
�
use_mathjax�Enable the `use_mathjax` option to render LaTeX formulas using MathJax (see https://www.mathjax.org) which uses client side JavaScript for the rendering instead of using pre-rendered bitmaps.None(m
k
mathjax_versionPWith `mathjax_version` it is possible to specify the MathJax version to be used.None(|
z
mathjax_format`When MathJax is enabled you can set the default output format to be used for the MathJax output.None(�
�
mathjax_relpath�When MathJax is enabled you need to specify the location relative to the HTML output directory using the `mathjax_relpath` option.None(�
�
mathjax_extensions�The `mathjax_extensions` tag can be used to specify one or more MathJax extension names that should be enabled during MathJax rendering.None(�
�
mathjax_codefile�The `mathjax_codefile` tag can be used to specify a file with JavaScript pieces of code that will be used on startup of the MathJax code.None(x
v
searchengine^When the `searchengine` tag is enabled Doxygen will generate a search box for the HTML output.None(�
�
server_based_search�When the `server_based_search` tag is enabled the search engine will be implemented using a web server instead of a web client using JavaScript.None(�
~
external_searchcWhen `external_search` tag is enabled Doxygen will no longer generate the PHP script for searching.None(�
�
searchengine_url�The `searchengine_url` should point to a search engine hosted by a web server which will return the search results when `external_search` is enabled.None(�
�
searchdata_file�When `server_based_search` and `external_search` are both enabled the unindexed search data is written to a file for indexing by an external tool.None(�
�
external_search_id�When `server_based_search` and `external_search` are both enabled the `external_search_id` tag can be used as an identifier for the project.None(�
�
extra_search_mappings�The `extra_search_mappings` tag can be used to enable searching through Doxygen projects other than the one defined by this configuration file, but that are all added to the same external search index.None(m
k
generate_latexQIf the `generate_latex` tag is set to `True`, Doxygen will generate LaTeX output.None(e
c
latex_outputKThe `latex_output` tag is used to specify where the LaTeX docs will be put.None(q
o
latex_cmd_nameUThe `latex_cmd_name` tag can be used to specify the LaTeX command name to be invoked.None(�

makeindex_cmd_nameaThe `makeindex_cmd_name` tag can be used to specify the command name to generate index for LaTeX.None(�
�
latex_makeindex_cmdbThe `latex_makeindex_cmd` tag can be used to specify the command name to generate index for LaTeX.None(w
u
compact_latex\If the `compact_latex` tag is set to `True`, Doxygen generates more compact LaTeX documents.None(k
i

paper_typeSThe `paper_type` tag can be used to set the paper type that is used by the printer.None(�
�
extra_packages|The `extra_packages` tag can be used to specify one or more LaTeX package names that should be included in the LaTeX output.None(�
�
latex_headerkThe `latex_header` tag can be used to specify a user-defined LaTeX header for the generated LaTeX document.None(�
�
latex_footerkThe `latex_footer` tag can be used to specify a user-defined LaTeX footer for the generated LaTeX document.None(�
�
latex_extra_stylesheet�The `latex_extra_stylesheet` tag can be used to specify additional user-defined LaTeX style sheets that are included after the standard style sheets created by Doxygen.None(�
�
latex_extra_files�The `latex_extra_files` tag can be used to specify one or more extra images or other source files which should be copied to the `latex_output` output directory.None(�
�
pdf_hyperlinks�If the `pdf_hyperlinks` tag is set to `True`, the LaTeX that is generated is prepared for conversion to PDF (using ps2pdf or pdflatex).None(�
�
use_pdflatex�If the `use_pdflatex` tag is set to `True`, Doxygen will use the engine as specified with `latex_cmd_name` to generate the PDF file directly from the LaTeX files.None(i
g
latex_batchmodeLThe `latex_batchmode` tag signals the behavior of LaTeX in case of an error.None(�
�
latex_hide_indices�If the `latex_hide_indices` tag is set to `True` then Doxygen will not include the index chapters (such as File Index, Compound Index, etc.) in the output.None(�
�
latex_bib_styleqThe `latex_bib_style` tag can be used to specify the style to use for the bibliography, e.g. plainnat, or ieeetr.None(�
�
latex_emoji_directory|The `latex_emoji_directory` tag is used to specify the (relative or absolute) path from which the emoji images will be read.None(g
e
generate_rtfMIf the `generate_rtf` tag is set to `True`, Doxygen will generate RTF output.None(_
]

rtf_outputGThe `rtf_output` tag is used to specify where the RTF docs will be put.None(q
o
compact_rtfXIf the `compact_rtf` tag is set to `True`, Doxygen generates more compact RTF documents.None(�
�
rtf_hyperlinksfIf the `rtf_hyperlinks` tag is set to `True`, the RTF that is generated will contain hyperlink fields.None(G
E
rtf_stylesheet_file&Load stylesheet definitions from file.None(b
`
rtf_extensions_fileASet optional variables used in the generation of an RTF document.None(�
�
rtf_extra_files�The `rtf_extra_files` tag can be used to specify one or more extra images or other source files which should be copied to the `rtf_output` output directory.None(|
z
generate_manbIf the `generate_man` tag is set to `True`, Doxygen will generate man pages for classes and files.None(`
^

man_outputHThe `man_output` tag is used to specify where the man pages will be put.None(u
s
man_extensionZThe `man_extension` tag determines the extension that is added to the generated man pages.None(�
�

man_subdirxThe `man_subdir` tag determines the name of the directory created within `man_output` in which the man pages are placed.None(�
�
	man_links�If the `man_links` tag is set to `True` and Doxygen generates man output, then it will generate one additional man file for each entity documented in the real man page(s).None(�
�
generate_xml�If the `generate_xml` tag is set to `True`, Doxygen will generate an XML file that captures the structure of the code including all documentation.None(`
^

xml_outputHThe `xml_output` tag is used to specify where the XML pages will be put.None(�
�
xml_programlisting�If the `xml_programlisting` tag is set to `True`, Doxygen will dump the program listings (including syntax highlighting and cross-referencing information) to the XML output.None(�
�
xml_ns_memb_file_scope�If the `xml_ns_memb_file_scope` tag is set to `True`, Doxygen will include namespace members in file scope as well, matching the HTML output.None(�
�
generate_docbookuIf the `generate_docbook` tag is set to `True`, Doxygen will generate Docbook files that can be used to generate PDF.None(l
j
docbook_outputPThe `docbook_output` tag is used to specify where the Docbook pages will be put.None(�
�
generate_autogen_def�If the `generate_autogen_def` tag is set to `True`, Doxygen will generate an AutoGen Definitions (see https://autogen.sourceforge.net/) file that captures the structure of the code including all documentation.None(�
�
generate_sqlite3�If the `generate_sqlite3` tag is set to `True` Doxygen will generate a Sqlite3 database with symbols found by Doxygen stored in tables.None(o
m
sqlite3_outputSThe `sqlite3_output` tag is used to specify where the Sqlite3 database will be put.None(�
�
sqlite3_recreate_db�The `sqlite3_recreate_db` tag is set to `True`, the existing doxygen_sqlite3.db database file will be recreated with each Doxygen run.None(�
�
generate_perlmod�If the `generate_perlmod` tag is set to `True`, Doxygen will generate a Perl module file that captures the structure of the code including all documentation.None(�
�
perlmod_latex�If the `perlmod_latex` tag is set to `True`, Doxygen will generate the necessary Makefile rules, Perl scripts and LaTeX code to be able to generate PDF and DVI output from the Perl module output.None(�
�
perlmod_pretty�If the `perlmod_pretty` tag is set to `True`, the Perl module output will be nicely formatted so it can be parsed by a human reader.None(�
�
perlmod_makevar_prefix�The names of the make variables in the generated doxyrules.make file are prefixed with the string contained in `perlmod_makevar_prefix`.None(�
�
enable_preprocessing�If the `enable_preprocessing` tag is set to `True`, Doxygen will evaluate all C-preprocessor directives found in the sources and include files.None(�
�
macro_expansionfIf the `macro_expansion` tag is set to `True`, Doxygen will expand all macro names in the source code.None(�
�
expand_only_predef�If the `expand_only_predef` and `macro_expansion` tags are both set to `True` then the macro expansion is limited to the macros specified with the `predefined` and `expand_as_defined` tags.None(�
�
search_includesIf the `search_includes` tag is set to `True`, the include files in the `include_path` will be searched if a #include is found.None(�
�
include_path�The `include_path` tag can be used to specify one or more directories that contain include files that are not input files but should be processed by the preprocessor.None(�
�
include_file_patterns�You can use the `include_file_patterns` tag to specify one or more wildcard patterns (like *.h and *.hpp) to filter out the header-files in the directories.None(�
�

predefined�The `predefined` tag can be used to specify one or more macro names that are defined before the preprocessor is started (similar to the -D option of e.g. gcc).None(�
�
expand_as_defined�If the `macro_expansion` and `expand_only_predef` tags are set to `True` then this tag can be used to specify a list of macro names that should be expanded.None(�
�
skip_function_macros�If the `skip_function_macros` tag is set to `True` then Doxygen's preprocessor will remove all references to function-like macros that are alone on a line, have an all uppercase name, and do not end with a semicolon.None(V
T
tagfiles@The `tagfiles` tag can be used to specify one or more tag files.None(�
�
generate_tagfile�When a file name is specified after `generate_tagfile`, Doxygen will create a tag file that is based on the input files it reads.None(�
�
allexternals�If the `allexternals` tag is set to `True`, all external classes and namespaces will be listed in the class and namespace index.None(�
�
external_groupseIf the `external_groups` tag is set to `True`, all external groups will be listed in the topic index.None(�
�
external_pageskIf the `external_pages` tag is set to `True`, all external pages will be listed in the related pages index.None(�
�
hide_undoc_relations�If set to `True` the inheritance and collaboration graphs will hide inheritance and usage relations if the target is undocumented or is not a class.None(
}
have_dotiIf you set the `have_dot` tag to `True` then Doxygen will assume the dot tool is available from the path.None(�

dot_num_threadsdThe `dot_num_threads` specifies the number of dot invocations Doxygen is allowed to run in parallel.None(m
k
dot_common_attrP`dot_common_attr` is common attributes for nodes, edges and labels of subgraphs.None(R
P
dot_edge_attr7`dot_edge_attr` is concatenated with `dot_common_attr`.None(R
P
dot_node_attr7`dot_node_attr` is concatenated with `dot_common_attr`.None(�
�
dot_fontpathtYou can set the path where dot can find font specified with fontname in `dot_common_attr` and others dot attributes.None(�
�
dot_transparentsIf the `dot_transparent` tag is set to `True`, then the images generated by dot will have a transparent background.None(�
�
class_graph�If the `class_graph` tag is set to `True` or GRAPH or BUILTIN then Doxygen will generate a graph for each documented class showing the direct and indirect inheritance relations.None(�
�
collaboration_graph�If the `collaboration_graph` tag is set to `True` then Doxygen will generate a graph for each documented class showing the direct and indirect implementation dependencies (inheritance, containment, and class references variables) of the class with other documented classes.None(�
�
group_graphs�If the `group_graphs` tag is set to `True` then Doxygen will generate a graph for groups, showing the direct groups dependencies.None(�
�
uml_look�If the `uml_look` tag is set to `True`, Doxygen will generate inheritance and collaboration diagrams in a style similar to the OMG's Unified Modeling Language.None({
y
uml_limit_num_fieldsYIf the `uml_look` tag is enabled, the fields and methods are shown inside the class node.None(�

uml_max_edge_labels`If the `uml_look` tag is enabled, field labels are shown along the edge between two class nodes.None(�
�
dot_uml_details�If the `dot_uml_details` tag is set to `False`, Doxygen will show attributes and methods without types and arguments in the UML graphs.None(�
�
dot_wrap_thresholdmThe `dot_wrap_threshold` tag can be used to set the maximum number of characters to display on a single line.None(�
�
template_relations�If the `template_relations` tag is set to `True` then the inheritance and collaboration graphs will show the relations between templates and their instances.None(�
�
include_graph�If the `include_graph`, `enable_preprocessing` and `search_includes` tags are set to `True` then Doxygen will generate a graph for each documented file showing the direct and indirect include dependencies of the file with other documented files.None(�
�
included_by_graph�If the `included_by_graph`, `enable_preprocessing` and `search_includes` tags are set to `True` then Doxygen will generate a graph for each documented file showing the direct and indirect include dependencies of the file with other documented files.None(�
�

call_graph�If the `call_graph` tag is set to `True` then Doxygen will generate a call dependency graph for every global function or class method.None(�
�
caller_graph�If the `caller_graph` tag is set to `True` then Doxygen will generate a caller dependency graph for every global function or class method.None(�
�
graphical_hierarchy�If the `graphical_hierarchy` tag is set to `True` then Doxygen will graphical hierarchy of all classes instead of a textual one.None(�
�
directory_graph�If the `directory_graph` tag is set to `True` then Doxygen will show the dependencies a directory has on other directories in a graphical way.None(�
�
dir_graph_max_depth�The `dir_graph_max_depth` tag can be used to limit the maximum number of levels of child directories generated in directory dependency graphs by dot.None(|
z
dot_image_format^The `dot_image_format` tag can be used to set the image format of the images generated by dot.None(�
�
interactive_svg�If `dot_image_format` is set to svg, then this option can be set to `True` to enable generation of interactive SVG images that allow zooming and panning.None(i
g
dot_pathSThe `dot_path` tag can be used to specify the path where the dot tool can be found.None(�
�
dotfile_dirs�The `dotfile_dirs` tag can be used to specify one or more directories that contain dot files that are included in the documentation (see the \dotfile command).None(V
T
dia_path@You can include diagrams made with dia in Doxygen documentation.None(�
�
diafile_dirs�The `diafile_dirs` tag can be used to specify one or more directories that contain dia files that are included in the documentation (see the \diafile command).None(�
�
plantuml_jar_path�When using PlantUML, the `plantuml_jar_path` tag should be used to specify the path where java can find the plantuml.jar file or to the filename of jar file to be used.None(�
�
plantuml_cfg_filejWhen using PlantUML, the `plantuml_cfg_file` tag can be used to specify a configuration file for PlantUML.None(�
�
plantuml_include_pathxWhen using PlantUML, the specified paths are searched for files specified by the !include statement in a PlantUML block.None(�
�
plantumlfile_dirs�The plantumlfile_dirs tag can be used to specify one or more directories that contain PlantUml files that are included in the documentation (see the \plantumlfile command).None(�
�
dot_graph_max_nodesmThe `dot_graph_max_nodes` tag can be used to set the maximum number of nodes that will be shown in the graph.None(�
�
max_dot_graph_depthbThe `max_dot_graph_depth` tag can be used to set the maximum depth of the graphs generated by dot.None(�
�
dot_multi_targets�Set the `dot_multi_targets` tag to `True` to allow dot to generate multiple output files in one run (i.e. multiple -o and -T options on the command line).None(�
�
generate_legend�If the `generate_legend` tag is set to `True` Doxygen will generate a legend page explaining the meaning of the various boxes and arrows in the dot generated graphs.None(�
�
dot_cleanup�If the `dot_cleanup` tag is set to `True`, Doxygen will remove the intermediate files that are used to generate the various graphs.None(o
m
mscgen_toolVYou can define message sequence charts within Doxygen comments using the \msc command.None(�
�
mscfile_dirs�The `mscfile_dirs` tag can be used to specify one or more directories that contain msc files that are included in the documentation (see the \mscfile command).None(w
u
kwargsiAdditional arguments to pass to the rule (e.g. `visibility = ["//visibility:public"], tags = ["manual"]`)(�TransitiveSourcesInfoTA provider to collect source files transitively from the target and its dependencies2�
�
TransitiveSourcesInfoTA provider to collect source files transitively from the target and its dependenciesM
srcsEdepset of source files collected from the target and its dependencies"<
TransitiveSourcesInfo#@rules_doxygen//doxygen:doxygen.bzlO
M
srcsEdepset of source files collected from the target and its dependencies�collect_files_aspect�When applied to a target, this aspect collects the source files from the target and its dependencies, and makes them available in the TransitiveSourcesInfo provider.:�
�
collect_files_aspect�When applied to a target, this aspect collects the source files from the target and its dependencies, and makes them available in the TransitiveSourcesInfo provider.deps*;
collect_files_aspect#@rules_doxygen//doxygen:doxygen.bzlDoxygen rule for Bazel.��

rules_doxygenextensions.bzl�get_default_canonical_id�Returns the default canonical id to use for downloads.

Copied from [@bazel_tools//tools/build_defs/repo:cache.bzl](https://github.com/bazelbuild/bazel/blob/dbb05116a07429ec3524bcf7252cedbb11269bea/tools/build_defs/repo/cache.bzl)
to avoid a dependency on the whole `@bazel_tools` package, since its visibility changed from private to public between Bazel 7.0.0 and 8.0.0.

Returns `""` (empty string) when Bazel is run with
`--repo_env=BAZEL_HTTP_RULES_URLS_AS_DEFAULT_CANONICAL_ID=0`.

e.g.
```python
load("@bazel_tools//tools/build_defs/repo:cache.bzl", "get_default_canonical_id")
# ...
    repository_ctx.download_and_extract(
        url = urls,
        integrity = integrity
        canonical_id = get_default_canonical_id(repository_ctx, urls),
    ),
```
*�
�	
get_default_canonical_idb
repository_ctxLThe repository context of the repository rule calling this utility
function. (z
urlsnA list of URLs matching what is passed to `repository_ctx.download` and
`repository_ctx.download_and_extract`. (�Returns the default canonical id to use for downloads.

Copied from [@bazel_tools//tools/build_defs/repo:cache.bzl](https://github.com/bazelbuild/bazel/blob/dbb05116a07429ec3524bcf7252cedbb11269bea/tools/build_defs/repo/cache.bzl)
to avoid a dependency on the whole `@bazel_tools` package, since its visibility changed from private to public between Bazel 7.0.0 and 8.0.0.

Returns `""` (empty string) when Bazel is run with
`--repo_env=BAZEL_HTTP_RULES_URLS_AS_DEFAULT_CANONICAL_ID=0`.

e.g.
```python
load("@bazel_tools//tools/build_defs/repo:cache.bzl", "get_default_canonical_id")
# ...
    repository_ctx.download_and_extract(
        url = urls,
        integrity = integrity
        canonical_id = get_default_canonical_id(repository_ctx, urls),
    ),
```
"�
~The canonical ID to use for the download, or an empty string if
`BAZEL_HTTP_RULES_URLS_AS_DEFAULT_CANONICAL_ID` is set to `0`.2;
get_default_canonical_id@rules_doxygen//:extensions.bzld
b
repository_ctxLThe repository context of the repository rule calling this utility
function. (|
z
urlsnA list of URLs matching what is passed to `repository_ctx.download` and
`repository_ctx.download_and_extract`. (�qdoxygen_extension�-Module extension for declaring the doxygen configurations to use.

The resulting repository will have the following targets:
- `@doxygen//:doxygen.bzl`, containing the doxygen macro used to generate the documentation.
- `@doxygen//:Doxyfile.template`, default Doxyfile template used to generate the Doxyfile.

The extension will create a default configuration for all platforms with the version `1.15.0` of Doxygen.
You can override this value with a custom one for each supported platform, i.e. _windows_, _mac_, _mac-arm_, _linux_ and _linux-arm_.

```bzl
# MODULE.bazel file

bazel_dep(name = "rules_doxygen", version = "...", dev_dependency = True)

doxygen_extension = use_extension("@rules_doxygen//:extensions.bzl", "doxygen_extension")

# Download doxygen version 1.10.0 on linux, default version on all other platforms
doxygen_extension.configuration(
    version = "1.10.0",
    sha256 = "dcfc9aa4cc05aef1f0407817612ad9e9201d9bf2ce67cecf95a024bba7d39747",
    platform = "linux",
)

use_repo(doxygen_extension, "doxygen")
```

When you do so, you must also provide the SHA256 of the given doxygen archive.
If you don't know the SHA256 value, just leave it empty.
The build will fail with an error message containing the correct SHA256.

```bash
Download from https://github.com/doxygen/doxygen/releases/download/Release_1_10_0/doxygen-1.10.0.windows.x64.bin.zip failed: class com.google.devtools.build.lib.bazel.repository.downloader.UnrecoverableHttpException Checksum was 2135c1d5bdd6e067b3d0c40a4daac5d63d0fee1b3f4d6ef1e4f092db0d632d5b but wanted 0000000000000000000000000000000000000000000000000000000000000000
```

> [!Tip]
> Not indicating the platform will make the configuration apply to the platform it is running on.
> The build will fail when the download does not match the SHA256 checksum, i.e. when the platform changes.
> Unless you are using a system-wide doxygen installation, you should always specify the platform.

> [!Note]
> When a version is specified, the extension will download the doxygen binary from the official [Doxygen releases](https://github.com/doxygen/doxygen/releases).
> If a binary for the specified platform is not available (e.g., _linux-arm_, _mac-arm_), the build may fail.
> If that happens, you can either:
> - Use a different version of doxygen that supports your platform.
> - Use a system-wide doxygen installation by setting the version to `0.0.0`.
> - Use a local doxygen executable by providing a label pointing to the doxygen executable in the `executable` parameter.

#### System-wide doxygen installation

If you set the version to `0.0.0`, the doxygen executable will be assumed to be available from the PATH.
No download will be performed and bazel will use the installed version of doxygen.

> [!Warning]
> Setting the version to `0.0.0` this will break the hermeticity of your build, as it will now depend on the environment.

#### Using a local doxygen executable

You can also provide a label pointing to the `doxygen` executable you want to use by using the `executable` parameter in the extension configuration.
No download will be performed, and the file indicated by the label will be used as the doxygen executable.

> [!Note]
> `version` and `executable` are mutually exclusive.
> You must provide exactly one of them.

### Examples

```bzl
# MODULE.bazel file

bazel_dep(name = "rules_doxygen", version = "...", dev_dependency = True)

doxygen_extension = use_extension("@rules_doxygen//:extensions.bzl", "doxygen_extension")

# Using the 1.10.0 version of Doxygen instead of the default one.
# Note that che checksum is correct only if the platform is windows.
# If the platform is different, the build will fail.
doxygen_extension.configuration(
    version = "1.10.0",
    sha256 = "2135c1d5bdd6e067b3d0c40a4daac5d63d0fee1b3f4d6ef1e4f092db0d632d5b",
)

use_repo(doxygen_extension, "doxygen")
```

```bzl
# MODULE.bazel file

bazel_dep(name = "rules_doxygen", version = "...", dev_dependency = True)

doxygen_extension = use_extension("@rules_doxygen//:extensions.bzl", "doxygen_extension")

doxygen_extension.configuration(
    version = "1.10.0",
    sha256 = "dcfc9aa4cc05aef1f0407817612ad9e9201d9bf2ce67cecf95a024bba7d39747",
    platform = "linux",
)
doxygen_extension.configuration(
    version = "1.10.0",
    sha256 = "dcfc9aa4cc05aef1f0407817612ad9e9201d9bf2ce67cecf95a024bba7d39747",
    platform = "linux-arm",
)
doxygen_extension.configuration(
    version = "1.12.0",
    sha256 = "6ace7dde967d41f4e293d034a67eb2c7edd61318491ee3131112173a77344001",
    platform = "mac",
)
doxygen_extension.configuration(
    version = "1.12.0",
    sha256 = "6ace7dde967d41f4e293d034a67eb2c7edd61318491ee3131112173a77344001",
    platform = "mac-arm",
)
doxygen_extension.configuration(
    version = "1.11.0",
    sha256 = "478fc9897d00ca181835d248a4d3e5c83c26a32d1c7571f4321ddb0f2e97459f",
    platform = "windows",
)

use_repo(doxygen_extension, "doxygen")
```

```bzl
# MODULE.bazel file

bazel_dep(name = "rules_doxygen", version = "...", dev_dependency = True)

doxygen_extension = use_extension("@rules_doxygen//:extensions.bzl", "doxygen_extension")

# Download doxygen version 1.10.0 on linux
doxygen_extension.configuration(
    version = "1.10.0",
    sha256 = "dcfc9aa4cc05aef1f0407817612ad9e9201d9bf2ce67cecf95a024bba7d39747",
    platform = "linux",
)
# Use the local doxygen installation on mac
doxygen_extension.configuration(
    version = "0.0.0",
    platform = "mac",
)
# Use the doxygen provided executable on mac-arm
doxygen_extension.configuration(
    executable = "@my_module//path/to/doxygen:doxygen",
    platform = "mac-arm",
)
# Since no configuration has been provided for them,
# all other platforms will fallback to the default version

use_repo(doxygen_extension, "doxygen")
```J�D
�5
doxygen_extension�-Module extension for declaring the doxygen configurations to use.

The resulting repository will have the following targets:
- `@doxygen//:doxygen.bzl`, containing the doxygen macro used to generate the documentation.
- `@doxygen//:Doxyfile.template`, default Doxyfile template used to generate the Doxyfile.

The extension will create a default configuration for all platforms with the version `1.15.0` of Doxygen.
You can override this value with a custom one for each supported platform, i.e. _windows_, _mac_, _mac-arm_, _linux_ and _linux-arm_.

```bzl
# MODULE.bazel file

bazel_dep(name = "rules_doxygen", version = "...", dev_dependency = True)

doxygen_extension = use_extension("@rules_doxygen//:extensions.bzl", "doxygen_extension")

# Download doxygen version 1.10.0 on linux, default version on all other platforms
doxygen_extension.configuration(
    version = "1.10.0",
    sha256 = "dcfc9aa4cc05aef1f0407817612ad9e9201d9bf2ce67cecf95a024bba7d39747",
    platform = "linux",
)

use_repo(doxygen_extension, "doxygen")
```

When you do so, you must also provide the SHA256 of the given doxygen archive.
If you don't know the SHA256 value, just leave it empty.
The build will fail with an error message containing the correct SHA256.

```bash
Download from https://github.com/doxygen/doxygen/releases/download/Release_1_10_0/doxygen-1.10.0.windows.x64.bin.zip failed: class com.google.devtools.build.lib.bazel.repository.downloader.UnrecoverableHttpException Checksum was 2135c1d5bdd6e067b3d0c40a4daac5d63d0fee1b3f4d6ef1e4f092db0d632d5b but wanted 0000000000000000000000000000000000000000000000000000000000000000
```

> [!Tip]
> Not indicating the platform will make the configuration apply to the platform it is running on.
> The build will fail when the download does not match the SHA256 checksum, i.e. when the platform changes.
> Unless you are using a system-wide doxygen installation, you should always specify the platform.

> [!Note]
> When a version is specified, the extension will download the doxygen binary from the official [Doxygen releases](https://github.com/doxygen/doxygen/releases).
> If a binary for the specified platform is not available (e.g., _linux-arm_, _mac-arm_), the build may fail.
> If that happens, you can either:
> - Use a different version of doxygen that supports your platform.
> - Use a system-wide doxygen installation by setting the version to `0.0.0`.
> - Use a local doxygen executable by providing a label pointing to the doxygen executable in the `executable` parameter.

#### System-wide doxygen installation

If you set the version to `0.0.0`, the doxygen executable will be assumed to be available from the PATH.
No download will be performed and bazel will use the installed version of doxygen.

> [!Warning]
> Setting the version to `0.0.0` this will break the hermeticity of your build, as it will now depend on the environment.

#### Using a local doxygen executable

You can also provide a label pointing to the `doxygen` executable you want to use by using the `executable` parameter in the extension configuration.
No download will be performed, and the file indicated by the label will be used as the doxygen executable.

> [!Note]
> `version` and `executable` are mutually exclusive.
> You must provide exactly one of them.

### Examples

```bzl
# MODULE.bazel file

bazel_dep(name = "rules_doxygen", version = "...", dev_dependency = True)

doxygen_extension = use_extension("@rules_doxygen//:extensions.bzl", "doxygen_extension")

# Using the 1.10.0 version of Doxygen instead of the default one.
# Note that che checksum is correct only if the platform is windows.
# If the platform is different, the build will fail.
doxygen_extension.configuration(
    version = "1.10.0",
    sha256 = "2135c1d5bdd6e067b3d0c40a4daac5d63d0fee1b3f4d6ef1e4f092db0d632d5b",
)

use_repo(doxygen_extension, "doxygen")
```

```bzl
# MODULE.bazel file

bazel_dep(name = "rules_doxygen", version = "...", dev_dependency = True)

doxygen_extension = use_extension("@rules_doxygen//:extensions.bzl", "doxygen_extension")

doxygen_extension.configuration(
    version = "1.10.0",
    sha256 = "dcfc9aa4cc05aef1f0407817612ad9e9201d9bf2ce67cecf95a024bba7d39747",
    platform = "linux",
)
doxygen_extension.configuration(
    version = "1.10.0",
    sha256 = "dcfc9aa4cc05aef1f0407817612ad9e9201d9bf2ce67cecf95a024bba7d39747",
    platform = "linux-arm",
)
doxygen_extension.configuration(
    version = "1.12.0",
    sha256 = "6ace7dde967d41f4e293d034a67eb2c7edd61318491ee3131112173a77344001",
    platform = "mac",
)
doxygen_extension.configuration(
    version = "1.12.0",
    sha256 = "6ace7dde967d41f4e293d034a67eb2c7edd61318491ee3131112173a77344001",
    platform = "mac-arm",
)
doxygen_extension.configuration(
    version = "1.11.0",
    sha256 = "478fc9897d00ca181835d248a4d3e5c83c26a32d1c7571f4321ddb0f2e97459f",
    platform = "windows",
)

use_repo(doxygen_extension, "doxygen")
```

```bzl
# MODULE.bazel file

bazel_dep(name = "rules_doxygen", version = "...", dev_dependency = True)

doxygen_extension = use_extension("@rules_doxygen//:extensions.bzl", "doxygen_extension")

# Download doxygen version 1.10.0 on linux
doxygen_extension.configuration(
    version = "1.10.0",
    sha256 = "dcfc9aa4cc05aef1f0407817612ad9e9201d9bf2ce67cecf95a024bba7d39747",
    platform = "linux",
)
# Use the local doxygen installation on mac
doxygen_extension.configuration(
    version = "0.0.0",
    platform = "mac",
)
# Use the doxygen provided executable on mac-arm
doxygen_extension.configuration(
    executable = "@my_module//path/to/doxygen:doxygen",
    platform = "mac-arm",
)
# Since no configuration has been provided for them,
# all other platforms will fallback to the default version

use_repo(doxygen_extension, "doxygen")
```�
configuration�
version�The version of doxygen to use. If set to `0.0.0`, the doxygen executable will be assumed to be available from the PATH. Mutually exclusive with `executable`.2""h
sha256XThe sha256 hash of the doxygen archive. If not specified, an all-zero hash will be used.2""�
platform�The platform this configuration applies to. Available options are (windows, mac, mac-arm, linux, linux-arm). If not specified, the configuration will apply to the platform it is currently running on.2""�

executable�Target pointing to the doxygen executable to use. If set, no download will take place and the provided doxygen executable will be used. Mutually exclusive with `version`.2None�

repository�
name�The name of the repository the extension will create. Useful if you don't use 'rules_doxygen' as a dev_dependency, since it will avoid name collision for module depending on yours. Can only be specified once. Defaults to 'doxygen'. "!@rules_doxygen//:extensions.bzl�
�
configuration�
version�The version of doxygen to use. If set to `0.0.0`, the doxygen executable will be assumed to be available from the PATH. Mutually exclusive with `executable`.2""h
sha256XThe sha256 hash of the doxygen archive. If not specified, an all-zero hash will be used.2""�
platform�The platform this configuration applies to. Available options are (windows, mac, mac-arm, linux, linux-arm). If not specified, the configuration will apply to the platform it is currently running on.2""�

executable�Target pointing to the doxygen executable to use. If set, no download will take place and the provided doxygen executable will be used. Mutually exclusive with `version`.2None�
�
version�The version of doxygen to use. If set to `0.0.0`, the doxygen executable will be assumed to be available from the PATH. Mutually exclusive with `executable`.2""j
h
sha256XThe sha256 hash of the doxygen archive. If not specified, an all-zero hash will be used.2""�
�
platform�The platform this configuration applies to. Available options are (windows, mac, mac-arm, linux, linux-arm). If not specified, the configuration will apply to the platform it is currently running on.2""�
�

executable�Target pointing to the doxygen executable to use. If set, no download will take place and the provided doxygen executable will be used. Mutually exclusive with `version`.2None�
�

repository�
name�The name of the repository the extension will create. Useful if you don't use 'rules_doxygen' as a dev_dependency, since it will avoid name collision for module depending on yours. Can only be specified once. Defaults to 'doxygen'. �
�
name�The name of the repository the extension will create. Useful if you don't use 'rules_doxygen' as a dev_dependency, since it will avoid name collision for module depending on yours. Can only be specified once. Defaults to 'doxygen'. �:doxygen_repository�Repository rule for doxygen.

It can be provided with a configuration for each of the three platforms (windows, mac, mac-arm, linux, linux-arm) to download the correct version of doxygen only when the configuration matches the current platform.
Depending on the version, the behavior will change:
- If the version is set to `0.0.0`, the repository will use the installed version of doxygen, getting the binary from the PATH.
- If a version is specified, the repository will download the correct version of doxygen and make it available to the requesting module.

> [!Warning]
> If version is set to `0.0.0`, the rules needs doxygen to be installed on your system and the binary (named doxygen) must available in the PATH.
> Keep in mind that this will break the hermeticity of your build, as it will now depend on the environment.

You can further customize the repository by specifying the `doxygen_bzl`, `build`, and `doxyfile_template` attributes, but the default values should be enough for most use cases.

### Example

```bzl
# Download the os specific version 1.12.0 of doxygen supporting all the indicated platforms
doxygen_repository(
    name = "doxygen",
    versions = ["1.12.0", "1.12.0", "1.12.0"],
    sha256s = [
        "07f1c92cbbb32816689c725539c0951f92c6371d3d7f66dfa3192cbe88dd3138",
        "6ace7dde967d41f4e293d034a67eb2c7edd61318491ee3131112173a77344001",
        "3c42c3f3fb206732b503862d9c9c11978920a8214f223a3950bbf2520be5f647",
    ]
    platforms = ["windows", "mac", "linux"],
    executables = ["", "", ""],
)

# Use the system installed version of doxygen on linux and download version 1.11.0 for windows. Use the provided executable on mac-arm
doxygen_repository(
    name = "doxygen",
    version = ["0.0.0", "1.11.0", ""],
    sha256s = ["", "478fc9897d00ca181835d248a4d3e5c83c26a32d1c7571f4321ddb0f2e97459f", ""],
    platforms = ["linux", "windows", "mac-arm"],
    executables = ["", "", "/path/to/doxygen"],
)
```R�+
�
doxygen_repository�Repository rule for doxygen.

It can be provided with a configuration for each of the three platforms (windows, mac, mac-arm, linux, linux-arm) to download the correct version of doxygen only when the configuration matches the current platform.
Depending on the version, the behavior will change:
- If the version is set to `0.0.0`, the repository will use the installed version of doxygen, getting the binary from the PATH.
- If a version is specified, the repository will download the correct version of doxygen and make it available to the requesting module.

> [!Warning]
> If version is set to `0.0.0`, the rules needs doxygen to be installed on your system and the binary (named doxygen) must available in the PATH.
> Keep in mind that this will break the hermeticity of your build, as it will now depend on the environment.

You can further customize the repository by specifying the `doxygen_bzl`, `build`, and `doxyfile_template` attributes, but the default values should be enough for most use cases.

### Example

```bzl
# Download the os specific version 1.12.0 of doxygen supporting all the indicated platforms
doxygen_repository(
    name = "doxygen",
    versions = ["1.12.0", "1.12.0", "1.12.0"],
    sha256s = [
        "07f1c92cbbb32816689c725539c0951f92c6371d3d7f66dfa3192cbe88dd3138",
        "6ace7dde967d41f4e293d034a67eb2c7edd61318491ee3131112173a77344001",
        "3c42c3f3fb206732b503862d9c9c11978920a8214f223a3950bbf2520be5f647",
    ]
    platforms = ["windows", "mac", "linux"],
    executables = ["", "", ""],
)

# Use the system installed version of doxygen on linux and download version 1.11.0 for windows. Use the provided executable on mac-arm
doxygen_repository(
    name = "doxygen",
    version = ["0.0.0", "1.11.0", ""],
    sha256s = ["", "478fc9897d00ca181835d248a4d3e5c83c26a32d1c7571f4321ddb0f2e97459f", ""],
    platforms = ["linux", "windows", "mac-arm"],
    executables = ["", "", "/path/to/doxygen"],
)
```.
name"A unique name for this repository. �
repo_mapping�In `WORKSPACE` context only: a dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.

For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).

This attribute is _not_ supported in `MODULE.bazel` context (when invoking a repository rule inside a module extension's implementation function).
�
versions�List of versions of doxygen to use. If set to `0.0.0`, the doxygen executable will be assumed to be available from the PATH. Must be the same length as `sha256s`, `platforms` and `executables`. �
sha256srList of sha256 hashes of the doxygen archive. Must be the same length as `versions, `platforms` and `executables`. �
	platforms�List of platforms to download the doxygen binary for. Available options are (windows, mac, mac-arm, linux, linux-arm). Must be the same length as `version`, `sha256s` and `executables`. �
executables�List of paths to doxygen executables to use. If set, no download will take place and the provided doxygen executable will be used. Mutually exclusive with `version`. Must be the same length as `version`, `sha256s` and `platforms`. f
doxygen_bzl.The starlark file containing the doxygen macro2%"@rules_doxygen//doxygen:doxygen.bzl"R
build The BUILD file of the repository2%"@rules_doxygen//doxygen:BUILD.bazel"`
doxyfile_templateThe Doxyfile template to use2+"@rules_doxygen//doxygen:Doxyfile.template"*5
doxygen_repository@rules_doxygen//:extensions.bzl0
.
name"A unique name for this repository. �
�
repo_mapping�In `WORKSPACE` context only: a dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.

For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).

This attribute is _not_ supported in `MODULE.bazel` context (when invoking a repository rule inside a module extension's implementation function).
�
�
versions�List of versions of doxygen to use. If set to `0.0.0`, the doxygen executable will be assumed to be available from the PATH. Must be the same length as `sha256s`, `platforms` and `executables`. �
�
sha256srList of sha256 hashes of the doxygen archive. Must be the same length as `versions, `platforms` and `executables`. �
�
	platforms�List of platforms to download the doxygen binary for. Available options are (windows, mac, mac-arm, linux, linux-arm). Must be the same length as `version`, `sha256s` and `executables`. �
�
executables�List of paths to doxygen executables to use. If set, no download will take place and the provided doxygen executable will be used. Mutually exclusive with `version`. Must be the same length as `version`, `sha256s` and `platforms`. h
f
doxygen_bzl.The starlark file containing the doxygen macro2%"@rules_doxygen//doxygen:doxygen.bzl"T
R
build The BUILD file of the repository2%"@rules_doxygen//doxygen:BUILD.bazel"b
`
doxyfile_templateThe Doxyfile template to use2+"@rules_doxygen//doxygen:Doxyfile.template"WRepository rule for downloading the correct version of doxygen using module extensions. 