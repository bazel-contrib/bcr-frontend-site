
)
rules_formatjsformatjsaggregate.bzl�Tformatjs_aggregate�%Aggregate messages from multiple extraction targets into a single file.

This rule provides a declarative way to merge messages from multiple `formatjs_extract`
targets across your codebase. It's ideal for monorepos where messages are extracted
from different packages or modules and need to be combined for translation workflows.

## Platform Support

Works seamlessly across all platforms through Bazel's toolchain resolution:
- macOS (Apple Silicon and Intel)
- Linux (x86_64 and aarch64)
- Windows (x86_64)

The jq.bzl toolchain automatically provides the correct binary for your build platform.
No platform-specific configuration is required in BUILD files.

## Features

- **Automatic Traversal**: Automatically applies aspect to collect messages from dependencies
- **Transitive Collection**: Gathers messages from the entire dependency graph
- **Merge & Sort**: Merges all messages and sorts keys alphabetically
- **Duplicate Handling**: Later values override earlier ones for duplicate message IDs
- **Simple API**: Just list your extraction targets as deps
- **Cross-Platform**: Identical output across all platforms (UTF-8, sorted keys)

## How It Works

1. The rule attaches `formatjs_aggregate_aspect` to all `deps`
2. The aspect traverses the dependency graph collecting message files
3. All collected messages are merged using jq
4. Keys are sorted alphabetically for deterministic output
5. Result is written to `<name>.json`

## Use Cases

### Monorepo with multiple packages:
```starlark
# Package 1 - Frontend
formatjs_extract(
    name = "frontend_messages",
    srcs = glob(["frontend/**/*.tsx"]),
)

# Package 2 - Backend
formatjs_extract(
    name = "backend_messages",
    srcs = glob(["backend/**/*.tsx"]),
)

# Aggregate all messages
formatjs_aggregate(
    name = "all_messages",
    deps = [
        ":frontend_messages",
        ":backend_messages",
    ],
)
```

### Multi-module application:
```starlark
formatjs_aggregate(
    name = "app_messages",
    deps = [
        "//modules/auth:messages",
        "//modules/dashboard:messages",
        "//modules/settings:messages",
        "//modules/admin:messages",
    ],
)
```

### Nested aggregation:
```starlark
# Aggregate messages per feature
formatjs_aggregate(
    name = "feature_a_messages",
    deps = [
        "//features/a/component1:messages",
        "//features/a/component2:messages",
    ],
)

# Aggregate all features
formatjs_aggregate(
    name = "all_features",
    deps = [
        ":feature_a_messages",
        "//features/b:messages",
        "//features/c:messages",
    ],
)
```

## Output

The rule produces a JSON file named `<target_name>.json` in bazel-bin:
```bash
bazel build //:all_messages
# Output: bazel-bin/all_messages.json
```

The output format is standard FormatJS JSON:
```json
{
  "app.auth.login": {
    "id": "app.auth.login",
    "defaultMessage": "Log in",
    "description": "Login button"
  },
  "app.dashboard.welcome": {
    "id": "app.dashboard.welcome",
    "defaultMessage": "Welcome back!",
    "description": "Dashboard greeting"
  }
}
```

## Duplicate Message IDs

If the same message ID appears in multiple sources, the last one wins:
- Messages are merged in the order they appear in the dependency graph
- Later definitions override earlier ones
- This allows for intentional overrides (e.g., customizing messages per module)

## Usage in Translation Workflow

```starlark
# 1. Aggregate all messages
formatjs_aggregate(
    name = "source_messages",
    deps = ["//..."],  # All extraction targets
)

# 2. Verify translations
formatjs_verify_test(
    name = "verify_translations",
    translations = [
        ":source_messages",
        "translations/fr.json",
        "translations/de.json",
    ],
)

# 3. Compile for production
formatjs_compile(
    name = "compiled_fr",
    src = "translations/fr.json",
    out = "compiled-fr.json",
    ast = True,
)
```

## Cross-Platform Builds

The aggregation process produces identical output across all platforms:
- JSON is UTF-8 encoded with consistent line endings
- Keys are sorted alphabetically for deterministic output
- Checksums match across macOS, Linux, and Windows builds
- Remote caching works seamlessly across heterogeneous build fleets

This ensures that:
- CI builds are reproducible regardless of runner platform
- Developers on different OS can share build artifacts
- Remote execution works with mixed execution platforms

## See Also

- `formatjs_extract`: Extract messages from source files
- `formatjs_aggregate_aspect`: Lower-level aspect for advanced use cases
- `formatjs_verify_test`: Verify translations against aggregated messages
- `formatjs_compile`: Compile aggregated messages for production
- FormatJS CLI documentation: https://formatjs.github.io/docs/tooling/cli
"�.
�*
formatjs_aggregate�%Aggregate messages from multiple extraction targets into a single file.

This rule provides a declarative way to merge messages from multiple `formatjs_extract`
targets across your codebase. It's ideal for monorepos where messages are extracted
from different packages or modules and need to be combined for translation workflows.

## Platform Support

Works seamlessly across all platforms through Bazel's toolchain resolution:
- macOS (Apple Silicon and Intel)
- Linux (x86_64 and aarch64)
- Windows (x86_64)

The jq.bzl toolchain automatically provides the correct binary for your build platform.
No platform-specific configuration is required in BUILD files.

## Features

- **Automatic Traversal**: Automatically applies aspect to collect messages from dependencies
- **Transitive Collection**: Gathers messages from the entire dependency graph
- **Merge & Sort**: Merges all messages and sorts keys alphabetically
- **Duplicate Handling**: Later values override earlier ones for duplicate message IDs
- **Simple API**: Just list your extraction targets as deps
- **Cross-Platform**: Identical output across all platforms (UTF-8, sorted keys)

## How It Works

1. The rule attaches `formatjs_aggregate_aspect` to all `deps`
2. The aspect traverses the dependency graph collecting message files
3. All collected messages are merged using jq
4. Keys are sorted alphabetically for deterministic output
5. Result is written to `<name>.json`

## Use Cases

### Monorepo with multiple packages:
```starlark
# Package 1 - Frontend
formatjs_extract(
    name = "frontend_messages",
    srcs = glob(["frontend/**/*.tsx"]),
)

# Package 2 - Backend
formatjs_extract(
    name = "backend_messages",
    srcs = glob(["backend/**/*.tsx"]),
)

# Aggregate all messages
formatjs_aggregate(
    name = "all_messages",
    deps = [
        ":frontend_messages",
        ":backend_messages",
    ],
)
```

### Multi-module application:
```starlark
formatjs_aggregate(
    name = "app_messages",
    deps = [
        "//modules/auth:messages",
        "//modules/dashboard:messages",
        "//modules/settings:messages",
        "//modules/admin:messages",
    ],
)
```

### Nested aggregation:
```starlark
# Aggregate messages per feature
formatjs_aggregate(
    name = "feature_a_messages",
    deps = [
        "//features/a/component1:messages",
        "//features/a/component2:messages",
    ],
)

# Aggregate all features
formatjs_aggregate(
    name = "all_features",
    deps = [
        ":feature_a_messages",
        "//features/b:messages",
        "//features/c:messages",
    ],
)
```

## Output

The rule produces a JSON file named `<target_name>.json` in bazel-bin:
```bash
bazel build //:all_messages
# Output: bazel-bin/all_messages.json
```

The output format is standard FormatJS JSON:
```json
{
  "app.auth.login": {
    "id": "app.auth.login",
    "defaultMessage": "Log in",
    "description": "Login button"
  },
  "app.dashboard.welcome": {
    "id": "app.dashboard.welcome",
    "defaultMessage": "Welcome back!",
    "description": "Dashboard greeting"
  }
}
```

## Duplicate Message IDs

If the same message ID appears in multiple sources, the last one wins:
- Messages are merged in the order they appear in the dependency graph
- Later definitions override earlier ones
- This allows for intentional overrides (e.g., customizing messages per module)

## Usage in Translation Workflow

```starlark
# 1. Aggregate all messages
formatjs_aggregate(
    name = "source_messages",
    deps = ["//..."],  # All extraction targets
)

# 2. Verify translations
formatjs_verify_test(
    name = "verify_translations",
    translations = [
        ":source_messages",
        "translations/fr.json",
        "translations/de.json",
    ],
)

# 3. Compile for production
formatjs_compile(
    name = "compiled_fr",
    src = "translations/fr.json",
    out = "compiled-fr.json",
    ast = True,
)
```

## Cross-Platform Builds

The aggregation process produces identical output across all platforms:
- JSON is UTF-8 encoded with consistent line endings
- Keys are sorted alphabetically for deterministic output
- Checksums match across macOS, Linux, and Windows builds
- Remote caching works seamlessly across heterogeneous build fleets

This ensures that:
- CI builds are reproducible regardless of runner platform
- Developers on different OS can share build artifacts
- Remote execution works with mixed execution platforms

## See Also

- `formatjs_extract`: Extract messages from source files
- `formatjs_aggregate_aspect`: Lower-level aspect for advanced use cases
- `formatjs_verify_test`: Verify translations against aggregated messages
- `formatjs_compile`: Compile aggregated messages for production
- FormatJS CLI documentation: https://formatjs.github.io/docs/tooling/cli
*
nameA unique name for this target. �
deps�Dependencies to aggregate messages from.

Should be `formatjs_extract` targets or other targets that provide
`FormatjsExtractInfo`. The rule will automatically apply the
`formatjs_aggregate_aspect` to traverse the entire dependency graph
and collect all messages.

Example:
```starlark
deps = [
    "//frontend:messages",
    "//backend:messages",
    "//shared:messages",
]
```
2[]W
outNOutput file for the aggregated messages (JSON format). Defaults to <name>.json">
formatjs_aggregate(@@rules_formatjs//formatjs:aggregate.bzl
��,
*
nameA unique name for this target. �
�
deps�Dependencies to aggregate messages from.

Should be `formatjs_extract` targets or other targets that provide
`FormatjsExtractInfo`. The rule will automatically apply the
`formatjs_aggregate_aspect` to traverse the entire dependency graph
and collect all messages.

Example:
```starlark
deps = [
    "//frontend:messages",
    "//backend:messages",
    "//shared:messages",
]
```
2[]Y
W
outNOutput file for the aggregated messages (JSON format). Defaults to <name>.json�FormatjsAggregateInfo�Provider containing aggregated messages from multiple targets.

This provider is returned by both the `formatjs_aggregate` rule and the
`formatjs_aggregate_aspect`. It contains the collected message files and
metadata about the aggregation.
2�
�
FormatjsAggregateInfo�Provider containing aggregated messages from multiple targets.

This provider is returned by both the `formatjs_aggregate` rule and the
`formatjs_aggregate_aspect`. It contains the collected message files and
metadata about the aggregation.
W
messagesKdepset of message JSON files collected from the target and its dependencies4
count+Number of message files collected (integer)"A
FormatjsAggregateInfo(@@rules_formatjs//formatjs:aggregate.bzl
+!+!Y
W
messagesKdepset of message JSON files collected from the target and its dependencies6
4
count+Number of message files collected (integer)�!formatjs_aggregate_aspect�Aspect that aggregates extracted messages across dependency graphs.

This aspect provides a powerful way to collect and merge FormatJS messages from
a target and all its transitive dependencies. It automatically traverses the
dependency graph, collecting messages from any target that provides `FormatjsExtractInfo`.

## Platform Support

Works across all platforms through Bazel's toolchain resolution:
- macOS (Apple Silicon and Intel)
- Linux (x86_64 and aarch64)
- Windows (x86_64)

The jq.bzl toolchain automatically provides the correct binary for your platform.

## How It Works

The aspect:
1. Attaches to targets via `deps` and `srcs` attributes
2. Collects message files from targets with `FormatjsExtractInfo`
3. Recursively collects from dependencies
4. Merges all messages into a single JSON file using jq
5. Sorts keys alphabetically for deterministic builds

## Merge Strategy

Messages are merged using jq's object multiplication (`*`) operator:
- Later values override earlier ones for duplicate message IDs
- All unique message IDs are preserved
- Sorted alphabetically by key in the final output
- Ensures deterministic output across all platforms

## Usage Patterns

### Basic aspect usage - aggregate all messages:
```bash
bazel build //app:main \
    --aspects=@rules_formatjs//formatjs:aggregate.bzl%formatjs_aggregate_aspect \
    --output_groups=aggregated_messages
```

### Get individual message files (not merged):
```bash
bazel build //app:main \
    --aspects=@rules_formatjs//formatjs:aggregate.bzl%formatjs_aggregate_aspect \
    --output_groups=all_messages
```

## Output Groups

- `aggregated_messages`: Single merged JSON file with all messages
- `all_messages`: All individual message JSON files (not merged)

The aggregated file will be named: `<target_name>_aggregated_messages.json`

## Cross-Platform Considerations

- JSON output is identical across all platforms (UTF-8, sorted keys)
- jq binary is automatically selected for your build platform
- No platform-specific configuration needed in BUILD files
:�
�
formatjs_aggregate_aspect�Aspect that aggregates extracted messages across dependency graphs.

This aspect provides a powerful way to collect and merge FormatJS messages from
a target and all its transitive dependencies. It automatically traverses the
dependency graph, collecting messages from any target that provides `FormatjsExtractInfo`.

## Platform Support

Works across all platforms through Bazel's toolchain resolution:
- macOS (Apple Silicon and Intel)
- Linux (x86_64 and aarch64)
- Windows (x86_64)

The jq.bzl toolchain automatically provides the correct binary for your platform.

## How It Works

The aspect:
1. Attaches to targets via `deps` and `srcs` attributes
2. Collects message files from targets with `FormatjsExtractInfo`
3. Recursively collects from dependencies
4. Merges all messages into a single JSON file using jq
5. Sorts keys alphabetically for deterministic builds

## Merge Strategy

Messages are merged using jq's object multiplication (`*`) operator:
- Later values override earlier ones for duplicate message IDs
- All unique message IDs are preserved
- Sorted alphabetically by key in the final output
- Ensures deterministic output across all platforms

## Usage Patterns

### Basic aspect usage - aggregate all messages:
```bash
bazel build //app:main \
    --aspects=@rules_formatjs//formatjs:aggregate.bzl%formatjs_aggregate_aspect \
    --output_groups=aggregated_messages
```

### Get individual message files (not merged):
```bash
bazel build //app:main \
    --aspects=@rules_formatjs//formatjs:aggregate.bzl%formatjs_aggregate_aspect \
    --output_groups=all_messages
```

## Output Groups

- `aggregated_messages`: Single merged JSON file with all messages
- `all_messages`: All individual message JSON files (not merged)

The aggregated file will be named: `<target_name>_aggregated_messages.json`

## Cross-Platform Considerations

- JSON output is identical across all platforms (UTF-8, sorted keys)
- jq binary is automatically selected for your build platform
- No platform-specific configuration needed in BUILD files
depssrcs"*
nameA unique name for this target. *E
formatjs_aggregate_aspect(@@rules_formatjs//formatjs:aggregate.bzl
x#x#,
*
nameA unique name for this target. �
//formatjs:extract.bzlrq
'
rules_formatjsformatjsextract.bzl8
FormatjsExtractInfoFormatjsExtractInfo
)0)C
))E�Rules and aspects for aggregating messages across dependency trees.

This module provides tools for merging extracted messages from multiple targets
and their dependencies into a single, consolidated JSON file. This is useful for
large monorepo projects where messages are extracted from multiple packages or
modules and need to be combined for translation or compilation.

## Platform Support

These rules work across all platforms supported by the jq.bzl toolchain:
- macOS (Apple Silicon and Intel)
- Linux (x86_64 and aarch64)
- Windows (x86_64)

Bazel automatically selects the appropriate jq binary for your platform through
the toolchain resolution system. No platform-specific configuration is needed.

## Aggregation Process

1. Traverses the dependency graph collecting all extracted message files
2. Merges messages using jq with object multiplication semantics
3. Sorts keys alphabetically for deterministic output
4. Handles duplicate message IDs (later values override earlier ones)

## Usage Patterns

Aggregation can be used via:
- `formatjs_aggregate` rule: Declarative approach for common use cases
- `formatjs_aggregate_aspect`: Aspect-based approach for advanced scenarios

## Dependencies

This module depends on:
- `jq.bzl` toolchain for JSON merging and sorting operations
- `FormatjsExtractInfo` provider from extract.bzl for message collection

For more information about FormatJS message aggregation workflows, see:
https://formatjs.github.io/docs/tooling/cli
�
'
rules_formatjsformatjsaspects.bzl�message_collector_aspect�Example aspect that collects all messages from a dependency tree.

This aspect can be used to gather all extracted messages from a target
and all its dependencies, useful for creating combined translation files.

Usage:
    bazel build //path/to:target --aspects=//formatjs:aspects.bzl%message_collector_aspect \
                                  --output_groups=all_messages
:�
�
message_collector_aspect�Example aspect that collects all messages from a dependency tree.

This aspect can be used to gather all extracted messages from a target
and all its dependencies, useful for creating combined translation files.

Usage:
    bazel build //path/to:target --aspects=//formatjs:aspects.bzl%message_collector_aspect \
                                  --output_groups=all_messages
deps"*
nameA unique name for this target. *B
message_collector_aspect&@@rules_formatjs//formatjs:aspects.bzl
�"�",
*
nameA unique name for this target. �message_stats_aspect�Example aspect that collects statistics about extracted messages.

Usage:
    bazel build //path/to:target --aspects=//formatjs:aspects.bzl%message_stats_aspect \
                                  --output_groups=message_stats
:�
�
message_stats_aspect�Example aspect that collects statistics about extracted messages.

Usage:
    bazel build //path/to:target --aspects=//formatjs:aspects.bzl%message_stats_aspect \
                                  --output_groups=message_stats
"*
nameA unique name for this target. *>
message_stats_aspect&@@rules_formatjs//formatjs:aspects.bzl
00,
*
nameA unique name for this target. �message_validator_aspect�Example aspect that validates extracted messages.

Usage:
    bazel build //path/to:target --aspects=//formatjs:aspects.bzl%message_validator_aspect \
                                  --output_groups=message_validation
:�
�
message_validator_aspect�Example aspect that validates extracted messages.

Usage:
    bazel build //path/to:target --aspects=//formatjs:aspects.bzl%message_validator_aspect \
                                  --output_groups=message_validation
"*
nameA unique name for this target. *B
message_validator_aspect&@@rules_formatjs//formatjs:aspects.bzl
j"j",
*
nameA unique name for this target. �
//formatjs:extract.bzlrq
'
rules_formatjsformatjsextract.bzl8
FormatjsExtractInfoFormatjsExtractInfo
0C
E�Example aspects for use with formatjs_extract rule

This module demonstrates how to create aspects that work with formatjs_extract.
�O
'
rules_formatjsformatjscompile.bzl�Jformatjs_compile�Compile extracted messages into optimized runtime formats.

This rule compiles FormatJS message files (typically from `formatjs_extract` or
translation files) into optimized formats suitable for production use. The compilation
process pre-parses messages and can generate AST format for faster runtime performance.

## Features

- **AST Compilation**: Pre-parse messages into AST for faster runtime evaluation
- **Multiple Input Formats**: Support for simple, Crowdin, Smartling, and Transifex formats
- **Optimized Output**: Reduces bundle size and improves runtime performance
- **Toolchain Support**: Uses native FormatJS CLI for fast compilation

## Benefits of AST Compilation

When `ast = True`, messages are pre-parsed into Abstract Syntax Tree format:
- **Faster Runtime**: No parsing overhead when formatting messages
- **Smaller Bundles**: Parser code not needed in your application
- **Better Performance**: Especially beneficial for complex ICU MessageFormat strings

## Examples

### Basic compilation:
```starlark
formatjs_compile(
    name = "messages_compiled",
    srcs = [":messages"],  # from formatjs_extract
    out = "messages.json",
)
```

### Compile with AST for production:
```starlark
formatjs_compile(
    name = "messages_prod",
    srcs = ["translations/en.json"],
    out = "compiled-en.json",
    ast = True,
)
```

### Compile multiple translation files:
```starlark
formatjs_compile(
    name = "messages_merged",
    srcs = [
        ":base_messages",
        "translations/overrides.json",
    ],
    out = "compiled-messages.json",
    ast = True,
)
```

### Compile translation files from Crowdin:
```starlark
formatjs_compile(
    name = "fr_messages",
    srcs = ["translations/fr.json"],
    out = "compiled-fr.json",
    format = "crowdin",
    ast = True,
)
```

## Output

The compiled messages can be imported directly in your application:
```javascript
import messages from './compiled-en.json';

<IntlProvider messages={messages} locale="en">
  <App />
</IntlProvider>
```

## See Also

- `formatjs_extract`: Extract messages from source files
- `formatjs_verify_test`: Verify translations before compilation
- FormatJS CLI documentation: https://formatjs.github.io/docs/tooling/cli
"�9
�%
formatjs_compile�Compile extracted messages into optimized runtime formats.

This rule compiles FormatJS message files (typically from `formatjs_extract` or
translation files) into optimized formats suitable for production use. The compilation
process pre-parses messages and can generate AST format for faster runtime performance.

## Features

- **AST Compilation**: Pre-parse messages into AST for faster runtime evaluation
- **Multiple Input Formats**: Support for simple, Crowdin, Smartling, and Transifex formats
- **Optimized Output**: Reduces bundle size and improves runtime performance
- **Toolchain Support**: Uses native FormatJS CLI for fast compilation

## Benefits of AST Compilation

When `ast = True`, messages are pre-parsed into Abstract Syntax Tree format:
- **Faster Runtime**: No parsing overhead when formatting messages
- **Smaller Bundles**: Parser code not needed in your application
- **Better Performance**: Especially beneficial for complex ICU MessageFormat strings

## Examples

### Basic compilation:
```starlark
formatjs_compile(
    name = "messages_compiled",
    srcs = [":messages"],  # from formatjs_extract
    out = "messages.json",
)
```

### Compile with AST for production:
```starlark
formatjs_compile(
    name = "messages_prod",
    srcs = ["translations/en.json"],
    out = "compiled-en.json",
    ast = True,
)
```

### Compile multiple translation files:
```starlark
formatjs_compile(
    name = "messages_merged",
    srcs = [
        ":base_messages",
        "translations/overrides.json",
    ],
    out = "compiled-messages.json",
    ast = True,
)
```

### Compile translation files from Crowdin:
```starlark
formatjs_compile(
    name = "fr_messages",
    srcs = ["translations/fr.json"],
    out = "compiled-fr.json",
    format = "crowdin",
    ast = True,
)
```

## Output

The compiled messages can be imported directly in your application:
```javascript
import messages from './compiled-en.json';

<IntlProvider messages={messages} locale="en">
  <App />
</IntlProvider>
```

## See Also

- `formatjs_extract`: Extract messages from source files
- `formatjs_verify_test`: Verify translations before compilation
- FormatJS CLI documentation: https://formatjs.github.io/docs/tooling/cli
*
nameA unique name for this target. �
ast�Compile to AST (Abstract Syntax Tree) format for faster runtime parsing.

When enabled, messages are pre-parsed into an optimized AST representation:
- Faster message formatting at runtime
- Smaller JavaScript bundles (parser not needed)
- Ideal for production builds

Recommended: Enable for production, disable for development for easier debugging.
2False�
format�Input format of the source file.

Supported formats:
- `default`: Default formatter: extracts defaultMessage from MessageDescriptor objects
- `simple`: Simple formatter: pass-through for Record<string, string>
- `crowdin`: Crowdin translation platform format
- `smartling`: Smartling translation platform format
- `transifex`: Transifex translation platform format
- `lokalise`: Lokalise translation platform format

Use the appropriate format based on your translation management system.
If not specified, uses the default formatter.
2""�

ignore_tag�Treat HTML/XML tags as string literals instead of parsing them as tag tokens.

When enabled, tags like `<b>` are treated as plain text rather than formatting tags.
Useful for messages that need to preserve literal tag syntax.
2False�
out�Output compiled JSON file name.

Example: `out = "messages-compiled.json"`

The compiled file will be placed in the bazel-bin directory and can be
referenced by other rules or copied to your output directory.
 �
pseudo_locale�Generate pseudo-locale files for testing.

Requires `ast = True`. Available pseudo-locales:
- `xx-LS`: Longer strings (tests UI expansion)
- `xx-AC`: Accented characters (tests character encoding)
- `xx-HA`: Right-to-left text (tests RTL layout)
- `en-XA`: Accented English
- `en-XB`: Bracketed English

Pseudo-locales help identify i18n issues without actual translations.
2""�
skip_errors�Continue compiling after errors.

When enabled, keys with errors are excluded from output but compilation continues.
When disabled (default), compilation fails on the first error.
Useful for partially migrating or dealing with incomplete translations.
2False�
srcs�Source JSON files with extracted messages.

Can include:
- Multiple outputs from `formatjs_extract` rules
- Multiple translation files from translators
- Aggregated messages from `formatjs_aggregate`

When multiple files are provided, they will be merged during compilation.
The files should contain messages in FormatJS JSON format.
 ":
formatjs_compile&@@rules_formatjs//formatjs:compile.bzl
;;,
*
nameA unique name for this target. �
�
ast�Compile to AST (Abstract Syntax Tree) format for faster runtime parsing.

When enabled, messages are pre-parsed into an optimized AST representation:
- Faster message formatting at runtime
- Smaller JavaScript bundles (parser not needed)
- Ideal for production builds

Recommended: Enable for production, disable for development for easier debugging.
2False�
�
format�Input format of the source file.

Supported formats:
- `default`: Default formatter: extracts defaultMessage from MessageDescriptor objects
- `simple`: Simple formatter: pass-through for Record<string, string>
- `crowdin`: Crowdin translation platform format
- `smartling`: Smartling translation platform format
- `transifex`: Transifex translation platform format
- `lokalise`: Lokalise translation platform format

Use the appropriate format based on your translation management system.
If not specified, uses the default formatter.
2""�
�

ignore_tag�Treat HTML/XML tags as string literals instead of parsing them as tag tokens.

When enabled, tags like `<b>` are treated as plain text rather than formatting tags.
Useful for messages that need to preserve literal tag syntax.
2False�
�
out�Output compiled JSON file name.

Example: `out = "messages-compiled.json"`

The compiled file will be placed in the bazel-bin directory and can be
referenced by other rules or copied to your output directory.
 �
�
pseudo_locale�Generate pseudo-locale files for testing.

Requires `ast = True`. Available pseudo-locales:
- `xx-LS`: Longer strings (tests UI expansion)
- `xx-AC`: Accented characters (tests character encoding)
- `xx-HA`: Right-to-left text (tests RTL layout)
- `en-XA`: Accented English
- `en-XB`: Bracketed English

Pseudo-locales help identify i18n issues without actual translations.
2""�
�
skip_errors�Continue compiling after errors.

When enabled, keys with errors are excluded from output but compilation continues.
When disabled (default), compilation fails on the first error.
Useful for partially migrating or dealing with incomplete translations.
2False�
�
srcs�Source JSON files with extracted messages.

Can include:
- Multiple outputs from `formatjs_extract` rules
- Multiple translation files from translators
- Aggregated messages from `formatjs_aggregate`

When multiple files are provided, they will be merged during compilation.
The files should contain messages in FormatJS JSON format.
 �Rules for compiling messages into optimized runtime formats.

This module provides the `formatjs_compile` rule for compiling extracted message
files into optimized formats for use at runtime. The compilation process can
optionally generate AST (Abstract Syntax Tree) format for faster parsing and
reduced bundle size in production applications.

Compiled messages are optimized for runtime performance and can be used directly
with react-intl or other FormatJS libraries.

For more information about the FormatJS CLI and its compilation features, see:
https://formatjs.github.io/docs/tooling/cli
��
$
rules_formatjsformatjsdefs.bzl�Tformatjs_aggregate�%Aggregate messages from multiple extraction targets into a single file.

This rule provides a declarative way to merge messages from multiple `formatjs_extract`
targets across your codebase. It's ideal for monorepos where messages are extracted
from different packages or modules and need to be combined for translation workflows.

## Platform Support

Works seamlessly across all platforms through Bazel's toolchain resolution:
- macOS (Apple Silicon and Intel)
- Linux (x86_64 and aarch64)
- Windows (x86_64)

The jq.bzl toolchain automatically provides the correct binary for your build platform.
No platform-specific configuration is required in BUILD files.

## Features

- **Automatic Traversal**: Automatically applies aspect to collect messages from dependencies
- **Transitive Collection**: Gathers messages from the entire dependency graph
- **Merge & Sort**: Merges all messages and sorts keys alphabetically
- **Duplicate Handling**: Later values override earlier ones for duplicate message IDs
- **Simple API**: Just list your extraction targets as deps
- **Cross-Platform**: Identical output across all platforms (UTF-8, sorted keys)

## How It Works

1. The rule attaches `formatjs_aggregate_aspect` to all `deps`
2. The aspect traverses the dependency graph collecting message files
3. All collected messages are merged using jq
4. Keys are sorted alphabetically for deterministic output
5. Result is written to `<name>.json`

## Use Cases

### Monorepo with multiple packages:
```starlark
# Package 1 - Frontend
formatjs_extract(
    name = "frontend_messages",
    srcs = glob(["frontend/**/*.tsx"]),
)

# Package 2 - Backend
formatjs_extract(
    name = "backend_messages",
    srcs = glob(["backend/**/*.tsx"]),
)

# Aggregate all messages
formatjs_aggregate(
    name = "all_messages",
    deps = [
        ":frontend_messages",
        ":backend_messages",
    ],
)
```

### Multi-module application:
```starlark
formatjs_aggregate(
    name = "app_messages",
    deps = [
        "//modules/auth:messages",
        "//modules/dashboard:messages",
        "//modules/settings:messages",
        "//modules/admin:messages",
    ],
)
```

### Nested aggregation:
```starlark
# Aggregate messages per feature
formatjs_aggregate(
    name = "feature_a_messages",
    deps = [
        "//features/a/component1:messages",
        "//features/a/component2:messages",
    ],
)

# Aggregate all features
formatjs_aggregate(
    name = "all_features",
    deps = [
        ":feature_a_messages",
        "//features/b:messages",
        "//features/c:messages",
    ],
)
```

## Output

The rule produces a JSON file named `<target_name>.json` in bazel-bin:
```bash
bazel build //:all_messages
# Output: bazel-bin/all_messages.json
```

The output format is standard FormatJS JSON:
```json
{
  "app.auth.login": {
    "id": "app.auth.login",
    "defaultMessage": "Log in",
    "description": "Login button"
  },
  "app.dashboard.welcome": {
    "id": "app.dashboard.welcome",
    "defaultMessage": "Welcome back!",
    "description": "Dashboard greeting"
  }
}
```

## Duplicate Message IDs

If the same message ID appears in multiple sources, the last one wins:
- Messages are merged in the order they appear in the dependency graph
- Later definitions override earlier ones
- This allows for intentional overrides (e.g., customizing messages per module)

## Usage in Translation Workflow

```starlark
# 1. Aggregate all messages
formatjs_aggregate(
    name = "source_messages",
    deps = ["//..."],  # All extraction targets
)

# 2. Verify translations
formatjs_verify_test(
    name = "verify_translations",
    translations = [
        ":source_messages",
        "translations/fr.json",
        "translations/de.json",
    ],
)

# 3. Compile for production
formatjs_compile(
    name = "compiled_fr",
    src = "translations/fr.json",
    out = "compiled-fr.json",
    ast = True,
)
```

## Cross-Platform Builds

The aggregation process produces identical output across all platforms:
- JSON is UTF-8 encoded with consistent line endings
- Keys are sorted alphabetically for deterministic output
- Checksums match across macOS, Linux, and Windows builds
- Remote caching works seamlessly across heterogeneous build fleets

This ensures that:
- CI builds are reproducible regardless of runner platform
- Developers on different OS can share build artifacts
- Remote execution works with mixed execution platforms

## See Also

- `formatjs_extract`: Extract messages from source files
- `formatjs_aggregate_aspect`: Lower-level aspect for advanced use cases
- `formatjs_verify_test`: Verify translations against aggregated messages
- `formatjs_compile`: Compile aggregated messages for production
- FormatJS CLI documentation: https://formatjs.github.io/docs/tooling/cli
"�.
�*
formatjs_aggregate�%Aggregate messages from multiple extraction targets into a single file.

This rule provides a declarative way to merge messages from multiple `formatjs_extract`
targets across your codebase. It's ideal for monorepos where messages are extracted
from different packages or modules and need to be combined for translation workflows.

## Platform Support

Works seamlessly across all platforms through Bazel's toolchain resolution:
- macOS (Apple Silicon and Intel)
- Linux (x86_64 and aarch64)
- Windows (x86_64)

The jq.bzl toolchain automatically provides the correct binary for your build platform.
No platform-specific configuration is required in BUILD files.

## Features

- **Automatic Traversal**: Automatically applies aspect to collect messages from dependencies
- **Transitive Collection**: Gathers messages from the entire dependency graph
- **Merge & Sort**: Merges all messages and sorts keys alphabetically
- **Duplicate Handling**: Later values override earlier ones for duplicate message IDs
- **Simple API**: Just list your extraction targets as deps
- **Cross-Platform**: Identical output across all platforms (UTF-8, sorted keys)

## How It Works

1. The rule attaches `formatjs_aggregate_aspect` to all `deps`
2. The aspect traverses the dependency graph collecting message files
3. All collected messages are merged using jq
4. Keys are sorted alphabetically for deterministic output
5. Result is written to `<name>.json`

## Use Cases

### Monorepo with multiple packages:
```starlark
# Package 1 - Frontend
formatjs_extract(
    name = "frontend_messages",
    srcs = glob(["frontend/**/*.tsx"]),
)

# Package 2 - Backend
formatjs_extract(
    name = "backend_messages",
    srcs = glob(["backend/**/*.tsx"]),
)

# Aggregate all messages
formatjs_aggregate(
    name = "all_messages",
    deps = [
        ":frontend_messages",
        ":backend_messages",
    ],
)
```

### Multi-module application:
```starlark
formatjs_aggregate(
    name = "app_messages",
    deps = [
        "//modules/auth:messages",
        "//modules/dashboard:messages",
        "//modules/settings:messages",
        "//modules/admin:messages",
    ],
)
```

### Nested aggregation:
```starlark
# Aggregate messages per feature
formatjs_aggregate(
    name = "feature_a_messages",
    deps = [
        "//features/a/component1:messages",
        "//features/a/component2:messages",
    ],
)

# Aggregate all features
formatjs_aggregate(
    name = "all_features",
    deps = [
        ":feature_a_messages",
        "//features/b:messages",
        "//features/c:messages",
    ],
)
```

## Output

The rule produces a JSON file named `<target_name>.json` in bazel-bin:
```bash
bazel build //:all_messages
# Output: bazel-bin/all_messages.json
```

The output format is standard FormatJS JSON:
```json
{
  "app.auth.login": {
    "id": "app.auth.login",
    "defaultMessage": "Log in",
    "description": "Login button"
  },
  "app.dashboard.welcome": {
    "id": "app.dashboard.welcome",
    "defaultMessage": "Welcome back!",
    "description": "Dashboard greeting"
  }
}
```

## Duplicate Message IDs

If the same message ID appears in multiple sources, the last one wins:
- Messages are merged in the order they appear in the dependency graph
- Later definitions override earlier ones
- This allows for intentional overrides (e.g., customizing messages per module)

## Usage in Translation Workflow

```starlark
# 1. Aggregate all messages
formatjs_aggregate(
    name = "source_messages",
    deps = ["//..."],  # All extraction targets
)

# 2. Verify translations
formatjs_verify_test(
    name = "verify_translations",
    translations = [
        ":source_messages",
        "translations/fr.json",
        "translations/de.json",
    ],
)

# 3. Compile for production
formatjs_compile(
    name = "compiled_fr",
    src = "translations/fr.json",
    out = "compiled-fr.json",
    ast = True,
)
```

## Cross-Platform Builds

The aggregation process produces identical output across all platforms:
- JSON is UTF-8 encoded with consistent line endings
- Keys are sorted alphabetically for deterministic output
- Checksums match across macOS, Linux, and Windows builds
- Remote caching works seamlessly across heterogeneous build fleets

This ensures that:
- CI builds are reproducible regardless of runner platform
- Developers on different OS can share build artifacts
- Remote execution works with mixed execution platforms

## See Also

- `formatjs_extract`: Extract messages from source files
- `formatjs_aggregate_aspect`: Lower-level aspect for advanced use cases
- `formatjs_verify_test`: Verify translations against aggregated messages
- `formatjs_compile`: Compile aggregated messages for production
- FormatJS CLI documentation: https://formatjs.github.io/docs/tooling/cli
*
nameA unique name for this target. �
deps�Dependencies to aggregate messages from.

Should be `formatjs_extract` targets or other targets that provide
`FormatjsExtractInfo`. The rule will automatically apply the
`formatjs_aggregate_aspect` to traverse the entire dependency graph
and collect all messages.

Example:
```starlark
deps = [
    "//frontend:messages",
    "//backend:messages",
    "//shared:messages",
]
```
2[]W
outNOutput file for the aggregated messages (JSON format). Defaults to <name>.json"9
formatjs_aggregate#@@rules_formatjs//formatjs:defs.bzl
��,
*
nameA unique name for this target. �
�
deps�Dependencies to aggregate messages from.

Should be `formatjs_extract` targets or other targets that provide
`FormatjsExtractInfo`. The rule will automatically apply the
`formatjs_aggregate_aspect` to traverse the entire dependency graph
and collect all messages.

Example:
```starlark
deps = [
    "//frontend:messages",
    "//backend:messages",
    "//shared:messages",
]
```
2[]Y
W
outNOutput file for the aggregated messages (JSON format). Defaults to <name>.json�Jformatjs_compile�Compile extracted messages into optimized runtime formats.

This rule compiles FormatJS message files (typically from `formatjs_extract` or
translation files) into optimized formats suitable for production use. The compilation
process pre-parses messages and can generate AST format for faster runtime performance.

## Features

- **AST Compilation**: Pre-parse messages into AST for faster runtime evaluation
- **Multiple Input Formats**: Support for simple, Crowdin, Smartling, and Transifex formats
- **Optimized Output**: Reduces bundle size and improves runtime performance
- **Toolchain Support**: Uses native FormatJS CLI for fast compilation

## Benefits of AST Compilation

When `ast = True`, messages are pre-parsed into Abstract Syntax Tree format:
- **Faster Runtime**: No parsing overhead when formatting messages
- **Smaller Bundles**: Parser code not needed in your application
- **Better Performance**: Especially beneficial for complex ICU MessageFormat strings

## Examples

### Basic compilation:
```starlark
formatjs_compile(
    name = "messages_compiled",
    srcs = [":messages"],  # from formatjs_extract
    out = "messages.json",
)
```

### Compile with AST for production:
```starlark
formatjs_compile(
    name = "messages_prod",
    srcs = ["translations/en.json"],
    out = "compiled-en.json",
    ast = True,
)
```

### Compile multiple translation files:
```starlark
formatjs_compile(
    name = "messages_merged",
    srcs = [
        ":base_messages",
        "translations/overrides.json",
    ],
    out = "compiled-messages.json",
    ast = True,
)
```

### Compile translation files from Crowdin:
```starlark
formatjs_compile(
    name = "fr_messages",
    srcs = ["translations/fr.json"],
    out = "compiled-fr.json",
    format = "crowdin",
    ast = True,
)
```

## Output

The compiled messages can be imported directly in your application:
```javascript
import messages from './compiled-en.json';

<IntlProvider messages={messages} locale="en">
  <App />
</IntlProvider>
```

## See Also

- `formatjs_extract`: Extract messages from source files
- `formatjs_verify_test`: Verify translations before compilation
- FormatJS CLI documentation: https://formatjs.github.io/docs/tooling/cli
"�9
�%
formatjs_compile�Compile extracted messages into optimized runtime formats.

This rule compiles FormatJS message files (typically from `formatjs_extract` or
translation files) into optimized formats suitable for production use. The compilation
process pre-parses messages and can generate AST format for faster runtime performance.

## Features

- **AST Compilation**: Pre-parse messages into AST for faster runtime evaluation
- **Multiple Input Formats**: Support for simple, Crowdin, Smartling, and Transifex formats
- **Optimized Output**: Reduces bundle size and improves runtime performance
- **Toolchain Support**: Uses native FormatJS CLI for fast compilation

## Benefits of AST Compilation

When `ast = True`, messages are pre-parsed into Abstract Syntax Tree format:
- **Faster Runtime**: No parsing overhead when formatting messages
- **Smaller Bundles**: Parser code not needed in your application
- **Better Performance**: Especially beneficial for complex ICU MessageFormat strings

## Examples

### Basic compilation:
```starlark
formatjs_compile(
    name = "messages_compiled",
    srcs = [":messages"],  # from formatjs_extract
    out = "messages.json",
)
```

### Compile with AST for production:
```starlark
formatjs_compile(
    name = "messages_prod",
    srcs = ["translations/en.json"],
    out = "compiled-en.json",
    ast = True,
)
```

### Compile multiple translation files:
```starlark
formatjs_compile(
    name = "messages_merged",
    srcs = [
        ":base_messages",
        "translations/overrides.json",
    ],
    out = "compiled-messages.json",
    ast = True,
)
```

### Compile translation files from Crowdin:
```starlark
formatjs_compile(
    name = "fr_messages",
    srcs = ["translations/fr.json"],
    out = "compiled-fr.json",
    format = "crowdin",
    ast = True,
)
```

## Output

The compiled messages can be imported directly in your application:
```javascript
import messages from './compiled-en.json';

<IntlProvider messages={messages} locale="en">
  <App />
</IntlProvider>
```

## See Also

- `formatjs_extract`: Extract messages from source files
- `formatjs_verify_test`: Verify translations before compilation
- FormatJS CLI documentation: https://formatjs.github.io/docs/tooling/cli
*
nameA unique name for this target. �
ast�Compile to AST (Abstract Syntax Tree) format for faster runtime parsing.

When enabled, messages are pre-parsed into an optimized AST representation:
- Faster message formatting at runtime
- Smaller JavaScript bundles (parser not needed)
- Ideal for production builds

Recommended: Enable for production, disable for development for easier debugging.
2False�
format�Input format of the source file.

Supported formats:
- `default`: Default formatter: extracts defaultMessage from MessageDescriptor objects
- `simple`: Simple formatter: pass-through for Record<string, string>
- `crowdin`: Crowdin translation platform format
- `smartling`: Smartling translation platform format
- `transifex`: Transifex translation platform format
- `lokalise`: Lokalise translation platform format

Use the appropriate format based on your translation management system.
If not specified, uses the default formatter.
2""�

ignore_tag�Treat HTML/XML tags as string literals instead of parsing them as tag tokens.

When enabled, tags like `<b>` are treated as plain text rather than formatting tags.
Useful for messages that need to preserve literal tag syntax.
2False�
out�Output compiled JSON file name.

Example: `out = "messages-compiled.json"`

The compiled file will be placed in the bazel-bin directory and can be
referenced by other rules or copied to your output directory.
 �
pseudo_locale�Generate pseudo-locale files for testing.

Requires `ast = True`. Available pseudo-locales:
- `xx-LS`: Longer strings (tests UI expansion)
- `xx-AC`: Accented characters (tests character encoding)
- `xx-HA`: Right-to-left text (tests RTL layout)
- `en-XA`: Accented English
- `en-XB`: Bracketed English

Pseudo-locales help identify i18n issues without actual translations.
2""�
skip_errors�Continue compiling after errors.

When enabled, keys with errors are excluded from output but compilation continues.
When disabled (default), compilation fails on the first error.
Useful for partially migrating or dealing with incomplete translations.
2False�
srcs�Source JSON files with extracted messages.

Can include:
- Multiple outputs from `formatjs_extract` rules
- Multiple translation files from translators
- Aggregated messages from `formatjs_aggregate`

When multiple files are provided, they will be merged during compilation.
The files should contain messages in FormatJS JSON format.
 "7
formatjs_compile#@@rules_formatjs//formatjs:defs.bzl
;;,
*
nameA unique name for this target. �
�
ast�Compile to AST (Abstract Syntax Tree) format for faster runtime parsing.

When enabled, messages are pre-parsed into an optimized AST representation:
- Faster message formatting at runtime
- Smaller JavaScript bundles (parser not needed)
- Ideal for production builds

Recommended: Enable for production, disable for development for easier debugging.
2False�
�
format�Input format of the source file.

Supported formats:
- `default`: Default formatter: extracts defaultMessage from MessageDescriptor objects
- `simple`: Simple formatter: pass-through for Record<string, string>
- `crowdin`: Crowdin translation platform format
- `smartling`: Smartling translation platform format
- `transifex`: Transifex translation platform format
- `lokalise`: Lokalise translation platform format

Use the appropriate format based on your translation management system.
If not specified, uses the default formatter.
2""�
�

ignore_tag�Treat HTML/XML tags as string literals instead of parsing them as tag tokens.

When enabled, tags like `<b>` are treated as plain text rather than formatting tags.
Useful for messages that need to preserve literal tag syntax.
2False�
�
out�Output compiled JSON file name.

Example: `out = "messages-compiled.json"`

The compiled file will be placed in the bazel-bin directory and can be
referenced by other rules or copied to your output directory.
 �
�
pseudo_locale�Generate pseudo-locale files for testing.

Requires `ast = True`. Available pseudo-locales:
- `xx-LS`: Longer strings (tests UI expansion)
- `xx-AC`: Accented characters (tests character encoding)
- `xx-HA`: Right-to-left text (tests RTL layout)
- `en-XA`: Accented English
- `en-XB`: Bracketed English

Pseudo-locales help identify i18n issues without actual translations.
2""�
�
skip_errors�Continue compiling after errors.

When enabled, keys with errors are excluded from output but compilation continues.
When disabled (default), compilation fails on the first error.
Useful for partially migrating or dealing with incomplete translations.
2False�
�
srcs�Source JSON files with extracted messages.

Can include:
- Multiple outputs from `formatjs_extract` rules
- Multiple translation files from translators
- Aggregated messages from `formatjs_aggregate`

When multiple files are provided, they will be merged during compilation.
The files should contain messages in FormatJS JSON format.
 �Yformatjs_extract�Extract internationalized messages from source files using FormatJS CLI.

This rule extracts i18n messages from TypeScript, JavaScript, JSX, TSX, and Rust files
using the native FormatJS CLI toolchain. The extracted messages are output as a
JSON file with alphabetically sorted keys for deterministic builds.

## Features

- **Automatic ID Generation**: Use content-based hashing to generate stable message IDs
- **Multiple Formats**: Extract from `<FormattedMessage>` components, `formatMessage()` calls, and custom components
- **Sorted Output**: Keys are automatically sorted alphabetically (formatjs_cli v0.1.1+)
- **Toolchain Support**: Uses native FormatJS CLI binaries for fast extraction

## Message Format

The output JSON file contains messages in the format:
```json
{
  "message.id": {
    "id": "message.id",
    "defaultMessage": "Hello, world!",
    "description": "Greeting message"
  }
}
```

## Examples

### Basic extraction with auto-generated IDs:
```starlark
formatjs_extract(
    name = "messages",
    srcs = glob(["src/**/*.tsx"]),
    id_interpolation_pattern = "[sha512:contenthash:base64:6]",
)
```

### Extract from formatMessage() calls:
```starlark
formatjs_extract(
    name = "messages",
    srcs = ["src/app.tsx"],
    extract_from_format_message_call = True,
)
```

### Custom components and functions:
```starlark
formatjs_extract(
    name = "messages",
    srcs = glob(["src/**/*.tsx"]),
    additional_component_names = ["Trans", "Translate"],
    additional_function_names = ["t", "$t"],
)
```

## Output

The rule produces a JSON file (default: `<name>.json`) containing all extracted
messages. This file can be used with `formatjs_compile` to generate compiled
message catalogs or with `formatjs_aggregate` to merge messages from multiple
targets.

## See Also

- `formatjs_compile`: Compile messages for runtime use
- `formatjs_aggregate`: Merge messages from multiple extraction targets
- `formatjs_verify_test`: Verify translation files against extracted messages
- FormatJS CLI documentation: https://formatjs.github.io/docs/tooling/cli
"�I
�,
formatjs_extract�Extract internationalized messages from source files using FormatJS CLI.

This rule extracts i18n messages from TypeScript, JavaScript, JSX, TSX, and Rust files
using the native FormatJS CLI toolchain. The extracted messages are output as a
JSON file with alphabetically sorted keys for deterministic builds.

## Features

- **Automatic ID Generation**: Use content-based hashing to generate stable message IDs
- **Multiple Formats**: Extract from `<FormattedMessage>` components, `formatMessage()` calls, and custom components
- **Sorted Output**: Keys are automatically sorted alphabetically (formatjs_cli v0.1.1+)
- **Toolchain Support**: Uses native FormatJS CLI binaries for fast extraction

## Message Format

The output JSON file contains messages in the format:
```json
{
  "message.id": {
    "id": "message.id",
    "defaultMessage": "Hello, world!",
    "description": "Greeting message"
  }
}
```

## Examples

### Basic extraction with auto-generated IDs:
```starlark
formatjs_extract(
    name = "messages",
    srcs = glob(["src/**/*.tsx"]),
    id_interpolation_pattern = "[sha512:contenthash:base64:6]",
)
```

### Extract from formatMessage() calls:
```starlark
formatjs_extract(
    name = "messages",
    srcs = ["src/app.tsx"],
    extract_from_format_message_call = True,
)
```

### Custom components and functions:
```starlark
formatjs_extract(
    name = "messages",
    srcs = glob(["src/**/*.tsx"]),
    additional_component_names = ["Trans", "Translate"],
    additional_function_names = ["t", "$t"],
)
```

## Output

The rule produces a JSON file (default: `<name>.json`) containing all extracted
messages. This file can be used with `formatjs_compile` to generate compiled
message catalogs or with `formatjs_aggregate` to merge messages from multiple
targets.

## See Also

- `formatjs_compile`: Compile messages for runtime use
- `formatjs_aggregate`: Merge messages from multiple extraction targets
- `formatjs_verify_test`: Verify translation files against extracted messages
- FormatJS CLI documentation: https://formatjs.github.io/docs/tooling/cli
*
nameA unique name for this target. �
additional_component_names�Additional React component names to extract messages from.

Allows extraction from custom wrapper components that use FormatJS internally.
Example: `additional_component_names = ["Trans", "LocalizedText"]`

The components should accept FormatJS-compatible props like `id`, `defaultMessage`,
and `description`.
2[]�
additional_function_names�Additional function names to extract messages from.

Allows extraction from custom wrapper functions that use FormatJS internally.
Example: `additional_function_names = ["t", "$t", "i18n"]`

The functions should accept FormatJS-compatible message descriptors.
2[]�
deps�Dependencies that this extraction depends on (for aspect propagation).

Used when applying aspects that need to traverse the dependency graph.
Typically not needed for basic extraction workflows.
*
FormatjsExtractInfo*
DefaultInfo2[]�
extract_source_location�Whether to extract metadata about message location in source file.

When enabled, the output will include file paths and line numbers for each message.
This is useful for debugging and tracking message origins.
2False�
flattenWhether to hoist selectors and flatten sentences.

This flattens complex message structures for simpler translation workflows.
2False�
format�Formatter to use for output format.

Available formatters:
- `default` - Default formatter: extracts defaultMessage from MessageDescriptor objects
- `simple` - Simple formatter: pass-through for Record<string, string>
- `transifex` - Transifex formatter: extracts string field
- `smartling` - Smartling formatter: extracts message field
- `lokalise` - Lokalise formatter: extracts translation field
- `crowdin` - Crowdin formatter: extracts message field

If not specified, uses the default formatter.
2""�
id_interpolation_pattern�Pattern for generating message IDs automatically.

Uses content-based hashing to generate stable, unique IDs. Common patterns:
- `[sha512:contenthash:base64:6]` - 6-char base64-encoded SHA-512 hash
- `[sha256:contenthash:hex:8]` - 8-char hex-encoded SHA-256 hash
- `[contenthash:5]` - 5-char hash (default algorithm)

If not specified, messages must provide explicit `id` attributes.
Default: `[sha512:contenthash:base64:6]`
2""�
ignore�List of glob patterns to exclude from extraction.

Files matching these patterns will not be processed.
Example: `ignore = ["**/*.test.tsx", "**/__mocks__/**"]`
2[]�
out�Output file name (optional).

If not specified, defaults to `<target_name>.json`.
Example: `out = "extracted-messages.json"`

When specified, the output file can be referenced directly by its path
(e.g., `:messages/en.json` if out = "messages/en.json").
|
pragmalParse custom pragma for file metadata.

Example: `pragma = "@intl-meta"` to parse custom metadata comments.
2""�
preserve_whitespace�Whether to preserve whitespace and newlines in extracted messages.

By default, whitespace is normalized. Enable this to preserve exact formatting.
2False�
srcs�Source files to extract messages from.

Supports TypeScript (.ts, .tsx), JavaScript (.js, .jsx), ES modules (.mjs, .cjs),
and Rust (.rs).
Use glob patterns to extract from multiple files:
```starlark
srcs = glob(["src/**/*.{ts,tsx}"])
```
 �
throws�Whether to throw an exception when failing to process any file.

When enabled (default), the extraction will fail if any source file cannot be processed.
When disabled, problematic files are skipped with warnings.
2True"7
formatjs_extract#@@rules_formatjs//formatjs:defs.bzl
oo,
*
nameA unique name for this target. �
�
additional_component_names�Additional React component names to extract messages from.

Allows extraction from custom wrapper components that use FormatJS internally.
Example: `additional_component_names = ["Trans", "LocalizedText"]`

The components should accept FormatJS-compatible props like `id`, `defaultMessage`,
and `description`.
2[]�
�
additional_function_names�Additional function names to extract messages from.

Allows extraction from custom wrapper functions that use FormatJS internally.
Example: `additional_function_names = ["t", "$t", "i18n"]`

The functions should accept FormatJS-compatible message descriptors.
2[]�
�
deps�Dependencies that this extraction depends on (for aspect propagation).

Used when applying aspects that need to traverse the dependency graph.
Typically not needed for basic extraction workflows.
*
FormatjsExtractInfo*
DefaultInfo2[]�
�
extract_source_location�Whether to extract metadata about message location in source file.

When enabled, the output will include file paths and line numbers for each message.
This is useful for debugging and tracking message origins.
2False�
�
flattenWhether to hoist selectors and flatten sentences.

This flattens complex message structures for simpler translation workflows.
2False�
�
format�Formatter to use for output format.

Available formatters:
- `default` - Default formatter: extracts defaultMessage from MessageDescriptor objects
- `simple` - Simple formatter: pass-through for Record<string, string>
- `transifex` - Transifex formatter: extracts string field
- `smartling` - Smartling formatter: extracts message field
- `lokalise` - Lokalise formatter: extracts translation field
- `crowdin` - Crowdin formatter: extracts message field

If not specified, uses the default formatter.
2""�
�
id_interpolation_pattern�Pattern for generating message IDs automatically.

Uses content-based hashing to generate stable, unique IDs. Common patterns:
- `[sha512:contenthash:base64:6]` - 6-char base64-encoded SHA-512 hash
- `[sha256:contenthash:hex:8]` - 8-char hex-encoded SHA-256 hash
- `[contenthash:5]` - 5-char hash (default algorithm)

If not specified, messages must provide explicit `id` attributes.
Default: `[sha512:contenthash:base64:6]`
2""�
�
ignore�List of glob patterns to exclude from extraction.

Files matching these patterns will not be processed.
Example: `ignore = ["**/*.test.tsx", "**/__mocks__/**"]`
2[]�
�
out�Output file name (optional).

If not specified, defaults to `<target_name>.json`.
Example: `out = "extracted-messages.json"`

When specified, the output file can be referenced directly by its path
(e.g., `:messages/en.json` if out = "messages/en.json").
~
|
pragmalParse custom pragma for file metadata.

Example: `pragma = "@intl-meta"` to parse custom metadata comments.
2""�
�
preserve_whitespace�Whether to preserve whitespace and newlines in extracted messages.

By default, whitespace is normalized. Enable this to preserve exact formatting.
2False�
�
srcs�Source files to extract messages from.

Supports TypeScript (.ts, .tsx), JavaScript (.js, .jsx), ES modules (.mjs, .cjs),
and Rust (.rs).
Use glob patterns to extract from multiple files:
```starlark
srcs = glob(["src/**/*.{ts,tsx}"])
```
 �
�
throws�Whether to throw an exception when failing to process any file.

When enabled (default), the extraction will fail if any source file cannot be processed.
When disabled, problematic files are skipped with warnings.
2True�Dformatjs_verify_test�Test rule that verifies translation files are valid and complete.

This rule creates a test target that uses the FormatJS CLI to verify translation
files against a source locale. It can detect missing translations, extra keys, and
structural mismatches in ICU MessageFormat strings.

## Verification Checks

The test performs the following checks (each can be enabled/disabled):

- **Missing Keys** (`check_missing_keys`): Ensures all message IDs in the source
  locale exist in translation files. Missing keys indicate incomplete translations.

- **Extra Keys** (`check_extra_keys`): Detects message IDs in translation files
  that don't exist in the source. Extra keys may indicate outdated translations.

- **Structural Equality** (`check_structural_equality`): Validates that ICU
  MessageFormat syntax is compatible between source and translations. For example,
  if source uses `{count, plural, ...}`, translation must too.

## Usage Examples

### Basic verification of translations:
```starlark
formatjs_verify_test(
    name = "verify_translations",
    translations = [
        "messages/en.json",  # source locale (first file)
        "messages/fr.json",
        "messages/es.json",
    ],
)
```

### Specify source locale explicitly:
```starlark
formatjs_verify_test(
    name = "verify_translations",
    translations = [
        "messages/en.json",
        "messages/fr.json",
        "messages/de.json",
    ],
    source_locale = "en",
)
```

### Only check for missing keys:
```starlark
formatjs_verify_test(
    name = "check_complete",
    translations = [
        ":messages",  # extracted source messages
        "translations/fr.json",
    ],
    check_missing_keys = True,
    check_extra_keys = False,
    check_structural_equality = False,
)
```

### Negative test - expect validation to fail:
```starlark
formatjs_verify_test(
    name = "test_incomplete_translations_fail",
    translations = [
        "test_data/en.json",
        "test_data/incomplete-fr.json",
    ],
    expected_exit_code = 1,  # Expect failure
)
```

## Integration with Extraction

Use with `formatjs_extract` to verify translations against extracted messages:
```starlark
formatjs_extract(
    name = "source_messages",
    srcs = glob(["src/**/*.tsx"]),
)

formatjs_verify_test(
    name = "verify_fr",
    translations = [
        ":source_messages",
        "translations/fr.json",
    ],
)
```

## Test Output

The FormatJS CLI provides detailed error messages about any verification failures,
including which keys are missing or extra, and what structural differences exist.

## See Also

- `formatjs_extract`: Extract source messages for verification
- `formatjs_compile`: Compile verified translations for production use
- `formatjs_aggregate`: Aggregate messages from multiple sources
- FormatJS CLI documentation: https://formatjs.github.io/docs/tooling/cli
"�.
�"
formatjs_verify_test�Test rule that verifies translation files are valid and complete.

This rule creates a test target that uses the FormatJS CLI to verify translation
files against a source locale. It can detect missing translations, extra keys, and
structural mismatches in ICU MessageFormat strings.

## Verification Checks

The test performs the following checks (each can be enabled/disabled):

- **Missing Keys** (`check_missing_keys`): Ensures all message IDs in the source
  locale exist in translation files. Missing keys indicate incomplete translations.

- **Extra Keys** (`check_extra_keys`): Detects message IDs in translation files
  that don't exist in the source. Extra keys may indicate outdated translations.

- **Structural Equality** (`check_structural_equality`): Validates that ICU
  MessageFormat syntax is compatible between source and translations. For example,
  if source uses `{count, plural, ...}`, translation must too.

## Usage Examples

### Basic verification of translations:
```starlark
formatjs_verify_test(
    name = "verify_translations",
    translations = [
        "messages/en.json",  # source locale (first file)
        "messages/fr.json",
        "messages/es.json",
    ],
)
```

### Specify source locale explicitly:
```starlark
formatjs_verify_test(
    name = "verify_translations",
    translations = [
        "messages/en.json",
        "messages/fr.json",
        "messages/de.json",
    ],
    source_locale = "en",
)
```

### Only check for missing keys:
```starlark
formatjs_verify_test(
    name = "check_complete",
    translations = [
        ":messages",  # extracted source messages
        "translations/fr.json",
    ],
    check_missing_keys = True,
    check_extra_keys = False,
    check_structural_equality = False,
)
```

### Negative test - expect validation to fail:
```starlark
formatjs_verify_test(
    name = "test_incomplete_translations_fail",
    translations = [
        "test_data/en.json",
        "test_data/incomplete-fr.json",
    ],
    expected_exit_code = 1,  # Expect failure
)
```

## Integration with Extraction

Use with `formatjs_extract` to verify translations against extracted messages:
```starlark
formatjs_extract(
    name = "source_messages",
    srcs = glob(["src/**/*.tsx"]),
)

formatjs_verify_test(
    name = "verify_fr",
    translations = [
        ":source_messages",
        "translations/fr.json",
    ],
)
```

## Test Output

The FormatJS CLI provides detailed error messages about any verification failures,
including which keys are missing or extra, and what structural differences exist.

## See Also

- `formatjs_extract`: Extract source messages for verification
- `formatjs_compile`: Compile verified translations for production use
- `formatjs_aggregate`: Aggregate messages from multiple sources
- FormatJS CLI documentation: https://formatjs.github.io/docs/tooling/cli
*
nameA unique name for this target. �
check_extra_keys�Whether to fail if translation files contain message IDs not in the source.

Useful for detecting stale translations. Default: True.
2True�
check_missing_keys�Whether to fail if translation files are missing message IDs that exist in the source.

Disable for partial translations. Default: True.
2True�
check_structural_equality�Whether to fail if message format structures don't match between source and translations.

For example, if source has `{count, plural, ...}` but translation has plain text.
Default: True.
2True�
expected_exit_code�Expected exit code from the verify command.

Set to 1 for negative tests that expect verification to fail.
Useful for testing that incomplete translations are properly detected.
Default: 0 (expect success).
20�
source_locale�Source locale identifier (e.g., 'en', 'en-US').

If not provided, the first file in `translations` is used as the source.
This parameter helps identify which file is the source when translations
are not in alphabetical order.
2""�
translations�List of translation JSON files to verify.

Must include the source locale file (typically first in the list).
Can reference `formatjs_extract` targets directly using label syntax (`:messages`).

Example:
```starlark
translations = [
    "messages/en.json",  # source locale
    "messages/fr.json",
    "messages/es.json",
]
```
 ";
formatjs_verify_test#@@rules_formatjs//formatjs:defs.bzl
[[,
*
nameA unique name for this target. �
�
check_extra_keys�Whether to fail if translation files contain message IDs not in the source.

Useful for detecting stale translations. Default: True.
2True�
�
check_missing_keys�Whether to fail if translation files are missing message IDs that exist in the source.

Disable for partial translations. Default: True.
2True�
�
check_structural_equality�Whether to fail if message format structures don't match between source and translations.

For example, if source has `{count, plural, ...}` but translation has plain text.
Default: True.
2True�
�
expected_exit_code�Expected exit code from the verify command.

Set to 1 for negative tests that expect verification to fail.
Useful for testing that incomplete translations are properly detected.
Default: 0 (expect success).
20�
�
source_locale�Source locale identifier (e.g., 'en', 'en-US').

If not provided, the first file in `translations` is used as the source.
This parameter helps identify which file is the source when translations
are not in alphabetical order.
2""�
�
translations�List of translation JSON files to verify.

Must include the source locale file (typically first in the list).
Can reference `formatjs_extract` targets directly using label syntax (`:messages`).

Example:
```starlark
translations = [
    "messages/en.json",  # source locale
    "messages/fr.json",
    "messages/es.json",
]
```
 �FormatjsAggregateInfo�Provider containing aggregated messages from multiple targets.

This provider is returned by both the `formatjs_aggregate` rule and the
`formatjs_aggregate_aspect`. It contains the collected message files and
metadata about the aggregation.
2�
�
FormatjsAggregateInfo�Provider containing aggregated messages from multiple targets.

This provider is returned by both the `formatjs_aggregate` rule and the
`formatjs_aggregate_aspect`. It contains the collected message files and
metadata about the aggregation.
W
messagesKdepset of message JSON files collected from the target and its dependencies4
count+Number of message files collected (integer)"<
FormatjsAggregateInfo#@@rules_formatjs//formatjs:defs.bzl
+!+!Y
W
messagesKdepset of message JSON files collected from the target and its dependencies6
4
count+Number of message files collected (integer)�FormatjsExtractInfo�Provider containing information about extracted FormatJS messages.

This provider is returned by the `formatjs_extract` rule and can be used by
aspects or other rules to access the extracted messages and metadata.
2�
�
FormatjsExtractInfo�Provider containing information about extracted FormatJS messages.

This provider is returned by the `formatjs_extract` rule and can be used by
aspects or other rules to access the extracted messages and metadata.
N
messagesBFile containing extracted messages in JSON format with sorted keys7
srcs/depset of source files that were extracted fromj
id_interpolation_patternNPattern used for message ID generation (e.g., '[sha512:contenthash:base64:6]')":
FormatjsExtractInfo#@@rules_formatjs//formatjs:defs.bzl
P
N
messagesBFile containing extracted messages in JSON format with sorted keys9
7
srcs/depset of source files that were extracted froml
j
id_interpolation_patternNPattern used for message ID generation (e.g., '[sha512:contenthash:base64:6]')�!formatjs_aggregate_aspect�Aspect that aggregates extracted messages across dependency graphs.

This aspect provides a powerful way to collect and merge FormatJS messages from
a target and all its transitive dependencies. It automatically traverses the
dependency graph, collecting messages from any target that provides `FormatjsExtractInfo`.

## Platform Support

Works across all platforms through Bazel's toolchain resolution:
- macOS (Apple Silicon and Intel)
- Linux (x86_64 and aarch64)
- Windows (x86_64)

The jq.bzl toolchain automatically provides the correct binary for your platform.

## How It Works

The aspect:
1. Attaches to targets via `deps` and `srcs` attributes
2. Collects message files from targets with `FormatjsExtractInfo`
3. Recursively collects from dependencies
4. Merges all messages into a single JSON file using jq
5. Sorts keys alphabetically for deterministic builds

## Merge Strategy

Messages are merged using jq's object multiplication (`*`) operator:
- Later values override earlier ones for duplicate message IDs
- All unique message IDs are preserved
- Sorted alphabetically by key in the final output
- Ensures deterministic output across all platforms

## Usage Patterns

### Basic aspect usage - aggregate all messages:
```bash
bazel build //app:main \
    --aspects=@rules_formatjs//formatjs:aggregate.bzl%formatjs_aggregate_aspect \
    --output_groups=aggregated_messages
```

### Get individual message files (not merged):
```bash
bazel build //app:main \
    --aspects=@rules_formatjs//formatjs:aggregate.bzl%formatjs_aggregate_aspect \
    --output_groups=all_messages
```

## Output Groups

- `aggregated_messages`: Single merged JSON file with all messages
- `all_messages`: All individual message JSON files (not merged)

The aggregated file will be named: `<target_name>_aggregated_messages.json`

## Cross-Platform Considerations

- JSON output is identical across all platforms (UTF-8, sorted keys)
- jq binary is automatically selected for your build platform
- No platform-specific configuration needed in BUILD files
:�
�
formatjs_aggregate_aspect�Aspect that aggregates extracted messages across dependency graphs.

This aspect provides a powerful way to collect and merge FormatJS messages from
a target and all its transitive dependencies. It automatically traverses the
dependency graph, collecting messages from any target that provides `FormatjsExtractInfo`.

## Platform Support

Works across all platforms through Bazel's toolchain resolution:
- macOS (Apple Silicon and Intel)
- Linux (x86_64 and aarch64)
- Windows (x86_64)

The jq.bzl toolchain automatically provides the correct binary for your platform.

## How It Works

The aspect:
1. Attaches to targets via `deps` and `srcs` attributes
2. Collects message files from targets with `FormatjsExtractInfo`
3. Recursively collects from dependencies
4. Merges all messages into a single JSON file using jq
5. Sorts keys alphabetically for deterministic builds

## Merge Strategy

Messages are merged using jq's object multiplication (`*`) operator:
- Later values override earlier ones for duplicate message IDs
- All unique message IDs are preserved
- Sorted alphabetically by key in the final output
- Ensures deterministic output across all platforms

## Usage Patterns

### Basic aspect usage - aggregate all messages:
```bash
bazel build //app:main \
    --aspects=@rules_formatjs//formatjs:aggregate.bzl%formatjs_aggregate_aspect \
    --output_groups=aggregated_messages
```

### Get individual message files (not merged):
```bash
bazel build //app:main \
    --aspects=@rules_formatjs//formatjs:aggregate.bzl%formatjs_aggregate_aspect \
    --output_groups=all_messages
```

## Output Groups

- `aggregated_messages`: Single merged JSON file with all messages
- `all_messages`: All individual message JSON files (not merged)

The aggregated file will be named: `<target_name>_aggregated_messages.json`

## Cross-Platform Considerations

- JSON output is identical across all platforms (UTF-8, sorted keys)
- jq binary is automatically selected for your build platform
- No platform-specific configuration needed in BUILD files
depssrcs"*
nameA unique name for this target. *@
formatjs_aggregate_aspect#@@rules_formatjs//formatjs:defs.bzl
x#x#,
*
nameA unique name for this target. �
//formatjs:aggregate.bzlr�
)
rules_formatjsformatjsaggregate.bzl=
FormatjsAggregateInfo_FormatjsAggregateInfo
7
formatjs_aggregate_formatjs_aggregate
		E
formatjs_aggregate_aspect_formatjs_aggregate_aspect



�
//formatjs:compile.bzlrl
'
rules_formatjsformatjscompile.bzl3
formatjs_compile_formatjs_compile
/@
V�
//formatjs:extract.bzlr�
'
rules_formatjsformatjsextract.bzl9
FormatjsExtractInfo_FormatjsExtractInfo
/C3
formatjs_extract_formatjs_extract
]n
��
//formatjs:verify.bzlrs
&
rules_formatjsformatjs
verify.bzl;
formatjs_verify_test_formatjs_verify_test
.C
]tPublic API for FormatJS Bazel rules

This module provides the main entry points for using FormatJS in Bazel builds.
�h
'
rules_formatjsformatjsextract.bzl�Yformatjs_extract�Extract internationalized messages from source files using FormatJS CLI.

This rule extracts i18n messages from TypeScript, JavaScript, JSX, TSX, and Rust files
using the native FormatJS CLI toolchain. The extracted messages are output as a
JSON file with alphabetically sorted keys for deterministic builds.

## Features

- **Automatic ID Generation**: Use content-based hashing to generate stable message IDs
- **Multiple Formats**: Extract from `<FormattedMessage>` components, `formatMessage()` calls, and custom components
- **Sorted Output**: Keys are automatically sorted alphabetically (formatjs_cli v0.1.1+)
- **Toolchain Support**: Uses native FormatJS CLI binaries for fast extraction

## Message Format

The output JSON file contains messages in the format:
```json
{
  "message.id": {
    "id": "message.id",
    "defaultMessage": "Hello, world!",
    "description": "Greeting message"
  }
}
```

## Examples

### Basic extraction with auto-generated IDs:
```starlark
formatjs_extract(
    name = "messages",
    srcs = glob(["src/**/*.tsx"]),
    id_interpolation_pattern = "[sha512:contenthash:base64:6]",
)
```

### Extract from formatMessage() calls:
```starlark
formatjs_extract(
    name = "messages",
    srcs = ["src/app.tsx"],
    extract_from_format_message_call = True,
)
```

### Custom components and functions:
```starlark
formatjs_extract(
    name = "messages",
    srcs = glob(["src/**/*.tsx"]),
    additional_component_names = ["Trans", "Translate"],
    additional_function_names = ["t", "$t"],
)
```

## Output

The rule produces a JSON file (default: `<name>.json`) containing all extracted
messages. This file can be used with `formatjs_compile` to generate compiled
message catalogs or with `formatjs_aggregate` to merge messages from multiple
targets.

## See Also

- `formatjs_compile`: Compile messages for runtime use
- `formatjs_aggregate`: Merge messages from multiple extraction targets
- `formatjs_verify_test`: Verify translation files against extracted messages
- FormatJS CLI documentation: https://formatjs.github.io/docs/tooling/cli
"�I
�,
formatjs_extract�Extract internationalized messages from source files using FormatJS CLI.

This rule extracts i18n messages from TypeScript, JavaScript, JSX, TSX, and Rust files
using the native FormatJS CLI toolchain. The extracted messages are output as a
JSON file with alphabetically sorted keys for deterministic builds.

## Features

- **Automatic ID Generation**: Use content-based hashing to generate stable message IDs
- **Multiple Formats**: Extract from `<FormattedMessage>` components, `formatMessage()` calls, and custom components
- **Sorted Output**: Keys are automatically sorted alphabetically (formatjs_cli v0.1.1+)
- **Toolchain Support**: Uses native FormatJS CLI binaries for fast extraction

## Message Format

The output JSON file contains messages in the format:
```json
{
  "message.id": {
    "id": "message.id",
    "defaultMessage": "Hello, world!",
    "description": "Greeting message"
  }
}
```

## Examples

### Basic extraction with auto-generated IDs:
```starlark
formatjs_extract(
    name = "messages",
    srcs = glob(["src/**/*.tsx"]),
    id_interpolation_pattern = "[sha512:contenthash:base64:6]",
)
```

### Extract from formatMessage() calls:
```starlark
formatjs_extract(
    name = "messages",
    srcs = ["src/app.tsx"],
    extract_from_format_message_call = True,
)
```

### Custom components and functions:
```starlark
formatjs_extract(
    name = "messages",
    srcs = glob(["src/**/*.tsx"]),
    additional_component_names = ["Trans", "Translate"],
    additional_function_names = ["t", "$t"],
)
```

## Output

The rule produces a JSON file (default: `<name>.json`) containing all extracted
messages. This file can be used with `formatjs_compile` to generate compiled
message catalogs or with `formatjs_aggregate` to merge messages from multiple
targets.

## See Also

- `formatjs_compile`: Compile messages for runtime use
- `formatjs_aggregate`: Merge messages from multiple extraction targets
- `formatjs_verify_test`: Verify translation files against extracted messages
- FormatJS CLI documentation: https://formatjs.github.io/docs/tooling/cli
*
nameA unique name for this target. �
additional_component_names�Additional React component names to extract messages from.

Allows extraction from custom wrapper components that use FormatJS internally.
Example: `additional_component_names = ["Trans", "LocalizedText"]`

The components should accept FormatJS-compatible props like `id`, `defaultMessage`,
and `description`.
2[]�
additional_function_names�Additional function names to extract messages from.

Allows extraction from custom wrapper functions that use FormatJS internally.
Example: `additional_function_names = ["t", "$t", "i18n"]`

The functions should accept FormatJS-compatible message descriptors.
2[]�
deps�Dependencies that this extraction depends on (for aspect propagation).

Used when applying aspects that need to traverse the dependency graph.
Typically not needed for basic extraction workflows.
*
FormatjsExtractInfo*
DefaultInfo2[]�
extract_source_location�Whether to extract metadata about message location in source file.

When enabled, the output will include file paths and line numbers for each message.
This is useful for debugging and tracking message origins.
2False�
flattenWhether to hoist selectors and flatten sentences.

This flattens complex message structures for simpler translation workflows.
2False�
format�Formatter to use for output format.

Available formatters:
- `default` - Default formatter: extracts defaultMessage from MessageDescriptor objects
- `simple` - Simple formatter: pass-through for Record<string, string>
- `transifex` - Transifex formatter: extracts string field
- `smartling` - Smartling formatter: extracts message field
- `lokalise` - Lokalise formatter: extracts translation field
- `crowdin` - Crowdin formatter: extracts message field

If not specified, uses the default formatter.
2""�
id_interpolation_pattern�Pattern for generating message IDs automatically.

Uses content-based hashing to generate stable, unique IDs. Common patterns:
- `[sha512:contenthash:base64:6]` - 6-char base64-encoded SHA-512 hash
- `[sha256:contenthash:hex:8]` - 8-char hex-encoded SHA-256 hash
- `[contenthash:5]` - 5-char hash (default algorithm)

If not specified, messages must provide explicit `id` attributes.
Default: `[sha512:contenthash:base64:6]`
2""�
ignore�List of glob patterns to exclude from extraction.

Files matching these patterns will not be processed.
Example: `ignore = ["**/*.test.tsx", "**/__mocks__/**"]`
2[]�
out�Output file name (optional).

If not specified, defaults to `<target_name>.json`.
Example: `out = "extracted-messages.json"`

When specified, the output file can be referenced directly by its path
(e.g., `:messages/en.json` if out = "messages/en.json").
|
pragmalParse custom pragma for file metadata.

Example: `pragma = "@intl-meta"` to parse custom metadata comments.
2""�
preserve_whitespace�Whether to preserve whitespace and newlines in extracted messages.

By default, whitespace is normalized. Enable this to preserve exact formatting.
2False�
srcs�Source files to extract messages from.

Supports TypeScript (.ts, .tsx), JavaScript (.js, .jsx), ES modules (.mjs, .cjs),
and Rust (.rs).
Use glob patterns to extract from multiple files:
```starlark
srcs = glob(["src/**/*.{ts,tsx}"])
```
 �
throws�Whether to throw an exception when failing to process any file.

When enabled (default), the extraction will fail if any source file cannot be processed.
When disabled, problematic files are skipped with warnings.
2True":
formatjs_extract&@@rules_formatjs//formatjs:extract.bzl
oo,
*
nameA unique name for this target. �
�
additional_component_names�Additional React component names to extract messages from.

Allows extraction from custom wrapper components that use FormatJS internally.
Example: `additional_component_names = ["Trans", "LocalizedText"]`

The components should accept FormatJS-compatible props like `id`, `defaultMessage`,
and `description`.
2[]�
�
additional_function_names�Additional function names to extract messages from.

Allows extraction from custom wrapper functions that use FormatJS internally.
Example: `additional_function_names = ["t", "$t", "i18n"]`

The functions should accept FormatJS-compatible message descriptors.
2[]�
�
deps�Dependencies that this extraction depends on (for aspect propagation).

Used when applying aspects that need to traverse the dependency graph.
Typically not needed for basic extraction workflows.
*
FormatjsExtractInfo*
DefaultInfo2[]�
�
extract_source_location�Whether to extract metadata about message location in source file.

When enabled, the output will include file paths and line numbers for each message.
This is useful for debugging and tracking message origins.
2False�
�
flattenWhether to hoist selectors and flatten sentences.

This flattens complex message structures for simpler translation workflows.
2False�
�
format�Formatter to use for output format.

Available formatters:
- `default` - Default formatter: extracts defaultMessage from MessageDescriptor objects
- `simple` - Simple formatter: pass-through for Record<string, string>
- `transifex` - Transifex formatter: extracts string field
- `smartling` - Smartling formatter: extracts message field
- `lokalise` - Lokalise formatter: extracts translation field
- `crowdin` - Crowdin formatter: extracts message field

If not specified, uses the default formatter.
2""�
�
id_interpolation_pattern�Pattern for generating message IDs automatically.

Uses content-based hashing to generate stable, unique IDs. Common patterns:
- `[sha512:contenthash:base64:6]` - 6-char base64-encoded SHA-512 hash
- `[sha256:contenthash:hex:8]` - 8-char hex-encoded SHA-256 hash
- `[contenthash:5]` - 5-char hash (default algorithm)

If not specified, messages must provide explicit `id` attributes.
Default: `[sha512:contenthash:base64:6]`
2""�
�
ignore�List of glob patterns to exclude from extraction.

Files matching these patterns will not be processed.
Example: `ignore = ["**/*.test.tsx", "**/__mocks__/**"]`
2[]�
�
out�Output file name (optional).

If not specified, defaults to `<target_name>.json`.
Example: `out = "extracted-messages.json"`

When specified, the output file can be referenced directly by its path
(e.g., `:messages/en.json` if out = "messages/en.json").
~
|
pragmalParse custom pragma for file metadata.

Example: `pragma = "@intl-meta"` to parse custom metadata comments.
2""�
�
preserve_whitespace�Whether to preserve whitespace and newlines in extracted messages.

By default, whitespace is normalized. Enable this to preserve exact formatting.
2False�
�
srcs�Source files to extract messages from.

Supports TypeScript (.ts, .tsx), JavaScript (.js, .jsx), ES modules (.mjs, .cjs),
and Rust (.rs).
Use glob patterns to extract from multiple files:
```starlark
srcs = glob(["src/**/*.{ts,tsx}"])
```
 �
�
throws�Whether to throw an exception when failing to process any file.

When enabled (default), the extraction will fail if any source file cannot be processed.
When disabled, problematic files are skipped with warnings.
2True�FormatjsExtractInfo�Provider containing information about extracted FormatJS messages.

This provider is returned by the `formatjs_extract` rule and can be used by
aspects or other rules to access the extracted messages and metadata.
2�
�
FormatjsExtractInfo�Provider containing information about extracted FormatJS messages.

This provider is returned by the `formatjs_extract` rule and can be used by
aspects or other rules to access the extracted messages and metadata.
N
messagesBFile containing extracted messages in JSON format with sorted keys7
srcs/depset of source files that were extracted fromj
id_interpolation_patternNPattern used for message ID generation (e.g., '[sha512:contenthash:base64:6]')"=
FormatjsExtractInfo&@@rules_formatjs//formatjs:extract.bzl
P
N
messagesBFile containing extracted messages in JSON format with sorted keys9
7
srcs/depset of source files that were extracted froml
j
id_interpolation_patternNPattern used for message ID generation (e.g., '[sha512:contenthash:base64:6]')�Rules for extracting internationalized messages from source files.

This module provides the `formatjs_extract` rule for extracting messages from
TypeScript, JavaScript, JSX, TSX, and Rust files using the FormatJS CLI. The extracted
messages are output in JSON format with automatic key sorting.

The FormatJS CLI supports various message formats including:
- `<FormattedMessage>` components
- `intl.formatMessage()` calls (with `extract_from_format_message_call = True`)
- Custom component names (via `additional_component_names`)
- Custom function names (via `additional_function_names`)

Message IDs can be automatically generated using content-based hashing patterns,
ensuring consistent IDs across your codebase.

For more information about the FormatJS CLI and its extraction features, see:
https://formatjs.github.io/docs/tooling/cli
�J
&
rules_formatjsformatjs
verify.bzl�Dformatjs_verify_test�Test rule that verifies translation files are valid and complete.

This rule creates a test target that uses the FormatJS CLI to verify translation
files against a source locale. It can detect missing translations, extra keys, and
structural mismatches in ICU MessageFormat strings.

## Verification Checks

The test performs the following checks (each can be enabled/disabled):

- **Missing Keys** (`check_missing_keys`): Ensures all message IDs in the source
  locale exist in translation files. Missing keys indicate incomplete translations.

- **Extra Keys** (`check_extra_keys`): Detects message IDs in translation files
  that don't exist in the source. Extra keys may indicate outdated translations.

- **Structural Equality** (`check_structural_equality`): Validates that ICU
  MessageFormat syntax is compatible between source and translations. For example,
  if source uses `{count, plural, ...}`, translation must too.

## Usage Examples

### Basic verification of translations:
```starlark
formatjs_verify_test(
    name = "verify_translations",
    translations = [
        "messages/en.json",  # source locale (first file)
        "messages/fr.json",
        "messages/es.json",
    ],
)
```

### Specify source locale explicitly:
```starlark
formatjs_verify_test(
    name = "verify_translations",
    translations = [
        "messages/en.json",
        "messages/fr.json",
        "messages/de.json",
    ],
    source_locale = "en",
)
```

### Only check for missing keys:
```starlark
formatjs_verify_test(
    name = "check_complete",
    translations = [
        ":messages",  # extracted source messages
        "translations/fr.json",
    ],
    check_missing_keys = True,
    check_extra_keys = False,
    check_structural_equality = False,
)
```

### Negative test - expect validation to fail:
```starlark
formatjs_verify_test(
    name = "test_incomplete_translations_fail",
    translations = [
        "test_data/en.json",
        "test_data/incomplete-fr.json",
    ],
    expected_exit_code = 1,  # Expect failure
)
```

## Integration with Extraction

Use with `formatjs_extract` to verify translations against extracted messages:
```starlark
formatjs_extract(
    name = "source_messages",
    srcs = glob(["src/**/*.tsx"]),
)

formatjs_verify_test(
    name = "verify_fr",
    translations = [
        ":source_messages",
        "translations/fr.json",
    ],
)
```

## Test Output

The FormatJS CLI provides detailed error messages about any verification failures,
including which keys are missing or extra, and what structural differences exist.

## See Also

- `formatjs_extract`: Extract source messages for verification
- `formatjs_compile`: Compile verified translations for production use
- `formatjs_aggregate`: Aggregate messages from multiple sources
- FormatJS CLI documentation: https://formatjs.github.io/docs/tooling/cli
"�.
�"
formatjs_verify_test�Test rule that verifies translation files are valid and complete.

This rule creates a test target that uses the FormatJS CLI to verify translation
files against a source locale. It can detect missing translations, extra keys, and
structural mismatches in ICU MessageFormat strings.

## Verification Checks

The test performs the following checks (each can be enabled/disabled):

- **Missing Keys** (`check_missing_keys`): Ensures all message IDs in the source
  locale exist in translation files. Missing keys indicate incomplete translations.

- **Extra Keys** (`check_extra_keys`): Detects message IDs in translation files
  that don't exist in the source. Extra keys may indicate outdated translations.

- **Structural Equality** (`check_structural_equality`): Validates that ICU
  MessageFormat syntax is compatible between source and translations. For example,
  if source uses `{count, plural, ...}`, translation must too.

## Usage Examples

### Basic verification of translations:
```starlark
formatjs_verify_test(
    name = "verify_translations",
    translations = [
        "messages/en.json",  # source locale (first file)
        "messages/fr.json",
        "messages/es.json",
    ],
)
```

### Specify source locale explicitly:
```starlark
formatjs_verify_test(
    name = "verify_translations",
    translations = [
        "messages/en.json",
        "messages/fr.json",
        "messages/de.json",
    ],
    source_locale = "en",
)
```

### Only check for missing keys:
```starlark
formatjs_verify_test(
    name = "check_complete",
    translations = [
        ":messages",  # extracted source messages
        "translations/fr.json",
    ],
    check_missing_keys = True,
    check_extra_keys = False,
    check_structural_equality = False,
)
```

### Negative test - expect validation to fail:
```starlark
formatjs_verify_test(
    name = "test_incomplete_translations_fail",
    translations = [
        "test_data/en.json",
        "test_data/incomplete-fr.json",
    ],
    expected_exit_code = 1,  # Expect failure
)
```

## Integration with Extraction

Use with `formatjs_extract` to verify translations against extracted messages:
```starlark
formatjs_extract(
    name = "source_messages",
    srcs = glob(["src/**/*.tsx"]),
)

formatjs_verify_test(
    name = "verify_fr",
    translations = [
        ":source_messages",
        "translations/fr.json",
    ],
)
```

## Test Output

The FormatJS CLI provides detailed error messages about any verification failures,
including which keys are missing or extra, and what structural differences exist.

## See Also

- `formatjs_extract`: Extract source messages for verification
- `formatjs_compile`: Compile verified translations for production use
- `formatjs_aggregate`: Aggregate messages from multiple sources
- FormatJS CLI documentation: https://formatjs.github.io/docs/tooling/cli
*
nameA unique name for this target. �
check_extra_keys�Whether to fail if translation files contain message IDs not in the source.

Useful for detecting stale translations. Default: True.
2True�
check_missing_keys�Whether to fail if translation files are missing message IDs that exist in the source.

Disable for partial translations. Default: True.
2True�
check_structural_equality�Whether to fail if message format structures don't match between source and translations.

For example, if source has `{count, plural, ...}` but translation has plain text.
Default: True.
2True�
expected_exit_code�Expected exit code from the verify command.

Set to 1 for negative tests that expect verification to fail.
Useful for testing that incomplete translations are properly detected.
Default: 0 (expect success).
20�
source_locale�Source locale identifier (e.g., 'en', 'en-US').

If not provided, the first file in `translations` is used as the source.
This parameter helps identify which file is the source when translations
are not in alphabetical order.
2""�
translations�List of translation JSON files to verify.

Must include the source locale file (typically first in the list).
Can reference `formatjs_extract` targets directly using label syntax (`:messages`).

Example:
```starlark
translations = [
    "messages/en.json",  # source locale
    "messages/fr.json",
    "messages/es.json",
]
```
 "=
formatjs_verify_test%@@rules_formatjs//formatjs:verify.bzl
[[,
*
nameA unique name for this target. �
�
check_extra_keys�Whether to fail if translation files contain message IDs not in the source.

Useful for detecting stale translations. Default: True.
2True�
�
check_missing_keys�Whether to fail if translation files are missing message IDs that exist in the source.

Disable for partial translations. Default: True.
2True�
�
check_structural_equality�Whether to fail if message format structures don't match between source and translations.

For example, if source has `{count, plural, ...}` but translation has plain text.
Default: True.
2True�
�
expected_exit_code�Expected exit code from the verify command.

Set to 1 for negative tests that expect verification to fail.
Useful for testing that incomplete translations are properly detected.
Default: 0 (expect success).
20�
�
source_locale�Source locale identifier (e.g., 'en', 'en-US').

If not provided, the first file in `translations` is used as the source.
This parameter helps identify which file is the source when translations
are not in alphabetical order.
2""�
�
translations�List of translation JSON files to verify.

Must include the source locale file (typically first in the list).
Can reference `formatjs_extract` targets directly using label syntax (`:messages`).

Example:
```starlark
translations = [
    "messages/en.json",  # source locale
    "messages/fr.json",
    "messages/es.json",
]
```
 �Rules for verifying translation file completeness and correctness.

This module provides the `formatjs_verify_test` rule for creating test targets that
verify translation files against source messages. The verification ensures translation
files are complete, don't have extra keys, and maintain structural compatibility with
the source messages.

Verification tests are essential in i18n workflows to catch translation errors early
in the development process, preventing runtime errors and ensuring translation quality.

For more information about the FormatJS CLI and its verification features, see:
https://formatjs.github.io/docs/tooling/cli
�q
.
rules_formatjsformatjs_cliextensions.bzl�`formatjs_cli�Module extension for configuring FormatJS CLI toolchains.

This extension manages the FormatJS CLI binary distribution across different
platforms. The CLI is distributed as native binaries (no Node.js required) for
fast execution and easy integration into Bazel builds.

## Features

- **Version Selection**: Choose specific FormatJS CLI versions
- **Multi-Platform**: Automatic platform detection across multiple architectures
- **SHA256 Verification**: All binaries are verified with checksums
- **No Node.js**: Native binaries for maximum performance
- **Automatic Registration**: Toolchains are automatically registered when you
  add `rules_formatjs` as a dependency

## Basic Usage

Most users don't need to interact with this extension directly. Simply add
`rules_formatjs` as a dependency and the toolchains will be automatically
configured:

```starlark
bazel_dep(name = "rules_formatjs", version = "1.0.0")
```

## Advanced: Custom Version Selection

If you need to override the default FormatJS CLI version, use this extension:

```starlark
formatjs_cli = use_extension("@rules_formatjs//formatjs_cli:extensions.bzl", "formatjs_cli")
formatjs_cli.toolchain(version = "0.1.1")
use_repo(
    formatjs_cli,
    "formatjs_cli_toolchains",
    "formatjs_cli_toolchains_darwin_arm64",
    "formatjs_cli_toolchains_darwin_x86_64",
    "formatjs_cli_toolchains_linux_x64",
    "formatjs_cli_toolchains_linux_aarch64",
    "formatjs_cli_toolchains_windows_x86_64",
)
register_toolchains("@formatjs_cli_toolchains//:all")
```

## Advanced: Custom Platform Binaries

If you need to use a custom binary for a specific platform (e.g., unreleased version,
custom build, or platform not in the built-in list), configure custom platforms
in a single toolchain call:

```starlark
formatjs_cli = use_extension("@rules_formatjs//formatjs_cli:extensions.bzl", "formatjs_cli")

# Configure custom binaries for version 0.1.0 (similar to rules_nodejs pattern)
formatjs_cli.toolchain(
    name = "formatjs_v0_1_0",
    formatjs_repositories = {
        "0.1.0.darwin-arm64": [
            "https://github.com/formatjs/formatjs/releases/download/formatjs_cli_v0.1.0/formatjs_cli-darwin-arm64",
            "9b2c736b48cc65e763cf19ac7c190e527f9a8d4aa0798185e602f58becb99feb",
        ],
        "0.1.0.linux-x64": [
            "https://github.com/formatjs/formatjs/releases/download/formatjs_cli_v0.1.0/formatjs_cli-linux-x64",
            "884b9a41b9f6be649ea72277ebf22af0146043466d2ab94b28a57f95ffb7da1a",
        ],
    },
)

use_repo(
    formatjs_cli,
    "formatjs_cli_toolchains",
    "formatjs_v0_1_0_darwin_arm64",
    "formatjs_v0_1_0_linux_x64",
    "formatjs_v0_1_0_toolchains",
)

register_toolchains(
    "@formatjs_cli_toolchains//:all",
    "@formatjs_v0_1_0_toolchains//:all",
)
```

**formatjs_repositories** uses keys in `{version}.{platform}` format and values as `[url, sha256]` lists.
Supported platforms: `darwin-arm64`, `darwin-x86_64`, `linux-x64`, `linux-aarch64`, `windows-x86_64`

## Version History

- **1.2.0**: Latest built-in version
- **1.1.7**: Added Windows x86_64 support
- **1.1.5**: Added Linux ARM64 support
- **0.1.2**: Added native key sorting
- **0.1.1**: Added key sorting support
- **0.1.0**: Initial release

## Platform Support

Bazel's toolchain resolution automatically selects the correct binary for your platform.

**Binaries currently available for:**
- **macOS Apple Silicon** (M1/M2/M3): darwin-arm64 binary
- **Linux x86_64**: linux-x64 binary
- **Linux ARM64**: linux-aarch64 binary
- **Windows x86_64**: windows-x86_64 binary

**Toolchain definitions exist for future support:**
- **macOS Intel**: darwin-x86_64

If your platform doesn't have a binary available yet, the build will fail with a clear
error message. Contributions for additional platform binaries are welcome!

## See Also

- `repositories.bzl`: Contains version definitions and checksums
- `toolchain.bzl`: Toolchain implementation details
J�A
�,
formatjs_cli�Module extension for configuring FormatJS CLI toolchains.

This extension manages the FormatJS CLI binary distribution across different
platforms. The CLI is distributed as native binaries (no Node.js required) for
fast execution and easy integration into Bazel builds.

## Features

- **Version Selection**: Choose specific FormatJS CLI versions
- **Multi-Platform**: Automatic platform detection across multiple architectures
- **SHA256 Verification**: All binaries are verified with checksums
- **No Node.js**: Native binaries for maximum performance
- **Automatic Registration**: Toolchains are automatically registered when you
  add `rules_formatjs` as a dependency

## Basic Usage

Most users don't need to interact with this extension directly. Simply add
`rules_formatjs` as a dependency and the toolchains will be automatically
configured:

```starlark
bazel_dep(name = "rules_formatjs", version = "1.0.0")
```

## Advanced: Custom Version Selection

If you need to override the default FormatJS CLI version, use this extension:

```starlark
formatjs_cli = use_extension("@rules_formatjs//formatjs_cli:extensions.bzl", "formatjs_cli")
formatjs_cli.toolchain(version = "0.1.1")
use_repo(
    formatjs_cli,
    "formatjs_cli_toolchains",
    "formatjs_cli_toolchains_darwin_arm64",
    "formatjs_cli_toolchains_darwin_x86_64",
    "formatjs_cli_toolchains_linux_x64",
    "formatjs_cli_toolchains_linux_aarch64",
    "formatjs_cli_toolchains_windows_x86_64",
)
register_toolchains("@formatjs_cli_toolchains//:all")
```

## Advanced: Custom Platform Binaries

If you need to use a custom binary for a specific platform (e.g., unreleased version,
custom build, or platform not in the built-in list), configure custom platforms
in a single toolchain call:

```starlark
formatjs_cli = use_extension("@rules_formatjs//formatjs_cli:extensions.bzl", "formatjs_cli")

# Configure custom binaries for version 0.1.0 (similar to rules_nodejs pattern)
formatjs_cli.toolchain(
    name = "formatjs_v0_1_0",
    formatjs_repositories = {
        "0.1.0.darwin-arm64": [
            "https://github.com/formatjs/formatjs/releases/download/formatjs_cli_v0.1.0/formatjs_cli-darwin-arm64",
            "9b2c736b48cc65e763cf19ac7c190e527f9a8d4aa0798185e602f58becb99feb",
        ],
        "0.1.0.linux-x64": [
            "https://github.com/formatjs/formatjs/releases/download/formatjs_cli_v0.1.0/formatjs_cli-linux-x64",
            "884b9a41b9f6be649ea72277ebf22af0146043466d2ab94b28a57f95ffb7da1a",
        ],
    },
)

use_repo(
    formatjs_cli,
    "formatjs_cli_toolchains",
    "formatjs_v0_1_0_darwin_arm64",
    "formatjs_v0_1_0_linux_x64",
    "formatjs_v0_1_0_toolchains",
)

register_toolchains(
    "@formatjs_cli_toolchains//:all",
    "@formatjs_v0_1_0_toolchains//:all",
)
```

**formatjs_repositories** uses keys in `{version}.{platform}` format and values as `[url, sha256]` lists.
Supported platforms: `darwin-arm64`, `darwin-x86_64`, `linux-x64`, `linux-aarch64`, `windows-x86_64`

## Version History

- **1.2.0**: Latest built-in version
- **1.1.7**: Added Windows x86_64 support
- **1.1.5**: Added Linux ARM64 support
- **0.1.2**: Added native key sorting
- **0.1.1**: Added key sorting support
- **0.1.0**: Initial release

## Platform Support

Bazel's toolchain resolution automatically selects the correct binary for your platform.

**Binaries currently available for:**
- **macOS Apple Silicon** (M1/M2/M3): darwin-arm64 binary
- **Linux x86_64**: linux-x64 binary
- **Linux ARM64**: linux-aarch64 binary
- **Windows x86_64**: windows-x86_64 binary

**Toolchain definitions exist for future support:**
- **macOS Intel**: darwin-x86_64

If your platform doesn't have a binary available yet, the build will fail with a clear
error message. Contributions for additional platform binaries are welcome!

## See Also

- `repositories.bzl`: Contains version definitions and checksums
- `toolchain.bzl`: Toolchain implementation details
�
	toolchain�
name�Name for this toolchain configuration.

            Used as a prefix for generated repositories. If not specified, defaults to "formatjs_cli_toolchains".
            For custom configurations, use a descriptive name like "formatjs_v0_1_0".

            Example:
            ```starlark
            formatjs_cli.toolchain(name = "formatjs_v0_1_0")
            ```
            2""�
formatjs_repositories�Custom platform binaries configuration.

            Map keys use format "{version}.{platform}" and values are lists of [url, sha256].
            This allows specifying multiple platforms for a version.

            Example:
            ```starlark
            formatjs_repositories = {
                "0.1.0.darwin-arm64": [
                    "https://github.com/.../formatjs_cli-darwin-arm64",
                    "9b2c736b48cc65e763cf19ac7c190e527f9a8d4aa0798185e602f58becb99feb",
                ],
                "0.1.0.linux-x64": [
                    "https://github.com/.../formatjs_cli-linux-x64",
                    "884b9a41b9f6be649ea72277ebf22af0146043466d2ab94b28a57f95ffb7da1a",
                ],
            }
            ```

            Similar to rules_nodejs node_repositories pattern.
             �
version�Version of FormatJS CLI to use.

            If not specified, uses the default version: 1.2.0

            For built-in versions, see `FORMATJS_CLI_VERSIONS` in `repositories.bzl`.
            For custom binaries, specify any version string (e.g., "0.1.0", "0.1.3-rc1").

            Example:
            ```starlark
            formatjs_cli.toolchain(version = "0.1.2")
            ```
            2"""=
formatjs_cli-@@rules_formatjs//formatjs_cli:extensions.bzl
� � �
�

	toolchain�
name�Name for this toolchain configuration.

Used as a prefix for generated repositories. If not specified, defaults to "formatjs_cli_toolchains".
For custom configurations, use a descriptive name like "formatjs_v0_1_0".

Example:
```starlark
formatjs_cli.toolchain(name = "formatjs_v0_1_0")
```
2""�
formatjs_repositories�Custom platform binaries configuration.

Map keys use format "{version}.{platform}" and values are lists of [url, sha256].
This allows specifying multiple platforms for a version.

Example:
```starlark
formatjs_repositories = {
    "0.1.0.darwin-arm64": [
        "https://github.com/.../formatjs_cli-darwin-arm64",
        "9b2c736b48cc65e763cf19ac7c190e527f9a8d4aa0798185e602f58becb99feb",
    ],
    "0.1.0.linux-x64": [
        "https://github.com/.../formatjs_cli-linux-x64",
        "884b9a41b9f6be649ea72277ebf22af0146043466d2ab94b28a57f95ffb7da1a",
    ],
}
```

Similar to rules_nodejs node_repositories pattern.
 �
version�Version of FormatJS CLI to use.

If not specified, uses the default version: 1.2.0

For built-in versions, see `FORMATJS_CLI_VERSIONS` in `repositories.bzl`.
For custom binaries, specify any version string (e.g., "0.1.0", "0.1.3-rc1").

Example:
```starlark
formatjs_cli.toolchain(version = "0.1.2")
```
2""�
�
name�Name for this toolchain configuration.

Used as a prefix for generated repositories. If not specified, defaults to "formatjs_cli_toolchains".
For custom configurations, use a descriptive name like "formatjs_v0_1_0".

Example:
```starlark
formatjs_cli.toolchain(name = "formatjs_v0_1_0")
```
2""�
�
formatjs_repositories�Custom platform binaries configuration.

Map keys use format "{version}.{platform}" and values are lists of [url, sha256].
This allows specifying multiple platforms for a version.

Example:
```starlark
formatjs_repositories = {
    "0.1.0.darwin-arm64": [
        "https://github.com/.../formatjs_cli-darwin-arm64",
        "9b2c736b48cc65e763cf19ac7c190e527f9a8d4aa0798185e602f58becb99feb",
    ],
    "0.1.0.linux-x64": [
        "https://github.com/.../formatjs_cli-linux-x64",
        "884b9a41b9f6be649ea72277ebf22af0146043466d2ab94b28a57f95ffb7da1a",
    ],
}
```

Similar to rules_nodejs node_repositories pattern.
 �
�
version�Version of FormatJS CLI to use.

If not specified, uses the default version: 1.2.0

For built-in versions, see `FORMATJS_CLI_VERSIONS` in `repositories.bzl`.
For custom binaries, specify any version string (e.g., "0.1.0", "0.1.3-rc1").

Example:
```starlark
formatjs_cli.toolchain(version = "0.1.2")
```
2""�
//formatjs_cli:repositories.bzlr�
0
rules_formatjsformatjs_clirepositories.bzl0
DEFAULT_VERSIONDEFAULT_VERSION
;9;HR
 formatjs_cli_register_toolchains formatjs_cli_register_toolchains
;L;l5
formatjs_cli_repoformatjs_cli_repo
;p;�L
formatjs_cli_toolchains_repoformatjs_cli_toolchains_repo
;�;�
;;��Module extension for configuring FormatJS CLI toolchains.

This module extension allows you to specify which version of the FormatJS CLI
to use in your Bazel workspace. The FormatJS CLI is a native binary (Rust-based)
that provides fast message extraction, compilation, and verification.

## Supported Versions

Available versions can be found in `repositories.bzl` under `FORMATJS_CLI_VERSIONS`.
The current default version is defined by `DEFAULT_VERSION`.

## Supported Platforms

Current binaries are available for:
- macOS Apple Silicon (darwin-arm64)
- Linux x86_64 (linux-x64)
- Linux ARM64 (linux-aarch64)
- Windows x86_64 (windows-x86_64)

Toolchain definitions also exist for future support:
- macOS Intel (darwin-x86_64)

## Usage

For most users, simply adding `rules_formatjs` as a dependency is sufficient:

```starlark
bazel_dep(name = "rules_formatjs", version = "1.0.0")
```

The toolchains are automatically registered and Bazel will select the appropriate
one for your platform.

### Advanced: Custom Version Selection

If you need to use a specific FormatJS CLI version different from the default,
you can configure it with the extension:

```starlark
formatjs_cli = use_extension("@rules_formatjs//formatjs_cli:extensions.bzl", "formatjs_cli")
formatjs_cli.toolchain(version = "0.1.1")
use_repo(
    formatjs_cli,
    "formatjs_cli_toolchains",
    "formatjs_cli_toolchains_darwin_arm64",
    "formatjs_cli_toolchains_darwin_x86_64",
    "formatjs_cli_toolchains_linux_x64",
    "formatjs_cli_toolchains_linux_aarch64",
    "formatjs_cli_toolchains_windows_x86_64",
)
register_toolchains("@formatjs_cli_toolchains//:all")
```

**Note**: This advanced configuration is only needed if you want to override the
default FormatJS CLI version. In most cases, using the default version provided
by `rules_formatjs` is recommended.
�#
0
rules_formatjsformatjs_clirepositories.bzl� formatjs_cli_register_toolchains=Register FormatJS CLI toolchains for all supported platforms.*�
�
 formatjs_cli_register_toolchains4
name(Base name for the toolchain repositories (1
versionFormatJS CLI version to use"1.2.0"(g
registerSWhether to register the toolchains (set to False when called from module extension)True(=Register FormatJS CLI toolchains for all supported platforms.2S
 formatjs_cli_register_toolchains/@@rules_formatjs//formatjs_cli:repositories.bzl
��2_formatjs_cli_toolchains_repo�formatjs_cli_repoR�
�	
formatjs_cli_repo.
name"A unique name for this repository. <
exec_compatible_withExecution platform constraints2[]T
platformDTarget platform (e.g., 'darwin-arm64', 'linux-x64', 'linux-aarch64') �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
sha256�SHA256 checksum of the custom binary.

Required if url is provided. This ensures the downloaded binary
matches the expected checksum for security and reproducibility.
2"";
target_compatible_withTarget platform constraints2[]�
url�Custom URL to download the FormatJS CLI binary from.

If provided along with sha256, this overrides the built-in version URLs.
Useful for testing unreleased versions or using custom builds.
2""#
versionFormatJS CLI version *D
formatjs_cli_repo/@@rules_formatjs//formatjs_cli:repositories.bzl
�%�%0
.
name"A unique name for this repository. >
<
exec_compatible_withExecution platform constraints2[]V
T
platformDTarget platform (e.g., 'darwin-arm64', 'linux-x64', 'linux-aarch64') �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
�
sha256�SHA256 checksum of the custom binary.

Required if url is provided. This ensures the downloaded binary
matches the expected checksum for security and reproducibility.
2""=
;
target_compatible_withTarget platform constraints2[]�
�
url�Custom URL to download the FormatJS CLI binary from.

If provided along with sha256, this overrides the built-in version URLs.
Useful for testing unreleased versions or using custom builds.
2""%
#
versionFormatJS CLI version �formatjs_cli_toolchains_repolCreates a repository with toolchain definitions for all known platforms
which can be registered or selected.R�

�
formatjs_cli_toolchains_repolCreates a repository with toolchain definitions for all known platforms
which can be registered or selected..
name"A unique name for this repository. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 A
user_repository_name#Base name for toolchains repository2""*O
formatjs_cli_toolchains_repo/@@rules_formatjs//formatjs_cli:repositories.bzl
�0�00
.
name"A unique name for this repository. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 C
A
user_repository_name#Base name for toolchains repository2""#	DEFAULT_VERSION1.2.0j1.2.0-Repository rules for FormatJS CLI toolchains.�	
-
rules_formatjsformatjs_clitoolchain.bzl�formatjs_cli_executableJExposes the FormatJS CLI selected by the toolchain as an executable target"�
�
formatjs_cli_executableJExposes the FormatJS CLI selected by the toolchain as an executable target*
nameA unique name for this target. "G
formatjs_cli_executable,@@rules_formatjs//formatjs_cli:toolchain.bzl
33,
*
nameA unique name for this target. �formatjs_cli_toolchain Defines a FormatJS CLI toolchain"�
�
formatjs_cli_toolchain Defines a FormatJS CLI toolchain*
nameA unique name for this target. &
cliThe FormatJS CLI executable "F
formatjs_cli_toolchain,@@rules_formatjs//formatjs_cli:toolchain.bzl
,
*
nameA unique name for this target. (
&
cliThe FormatJS CLI executable �FormatjsCliToolchainInfo,Information about the FormatJS CLI toolchain2�
�
FormatjsCliToolchainInfo,Information about the FormatJS CLI toolchain"
cliThe FormatJS CLI executable/
cli_path#Path to the FormatJS CLI executable"H
FormatjsCliToolchainInfo,@@rules_formatjs//formatjs_cli:toolchain.bzl
$$$
"
cliThe FormatJS CLI executable1
/
cli_path#Path to the FormatJS CLI executable&FormatJS CLI toolchain implementation.ŧ

rules_formatjsformatjs.bzl�Jformatjs_compile�Compile extracted messages into optimized runtime formats.

This rule compiles FormatJS message files (typically from `formatjs_extract` or
translation files) into optimized formats suitable for production use. The compilation
process pre-parses messages and can generate AST format for faster runtime performance.

## Features

- **AST Compilation**: Pre-parse messages into AST for faster runtime evaluation
- **Multiple Input Formats**: Support for simple, Crowdin, Smartling, and Transifex formats
- **Optimized Output**: Reduces bundle size and improves runtime performance
- **Toolchain Support**: Uses native FormatJS CLI for fast compilation

## Benefits of AST Compilation

When `ast = True`, messages are pre-parsed into Abstract Syntax Tree format:
- **Faster Runtime**: No parsing overhead when formatting messages
- **Smaller Bundles**: Parser code not needed in your application
- **Better Performance**: Especially beneficial for complex ICU MessageFormat strings

## Examples

### Basic compilation:
```starlark
formatjs_compile(
    name = "messages_compiled",
    srcs = [":messages"],  # from formatjs_extract
    out = "messages.json",
)
```

### Compile with AST for production:
```starlark
formatjs_compile(
    name = "messages_prod",
    srcs = ["translations/en.json"],
    out = "compiled-en.json",
    ast = True,
)
```

### Compile multiple translation files:
```starlark
formatjs_compile(
    name = "messages_merged",
    srcs = [
        ":base_messages",
        "translations/overrides.json",
    ],
    out = "compiled-messages.json",
    ast = True,
)
```

### Compile translation files from Crowdin:
```starlark
formatjs_compile(
    name = "fr_messages",
    srcs = ["translations/fr.json"],
    out = "compiled-fr.json",
    format = "crowdin",
    ast = True,
)
```

## Output

The compiled messages can be imported directly in your application:
```javascript
import messages from './compiled-en.json';

<IntlProvider messages={messages} locale="en">
  <App />
</IntlProvider>
```

## See Also

- `formatjs_extract`: Extract messages from source files
- `formatjs_verify_test`: Verify translations before compilation
- FormatJS CLI documentation: https://formatjs.github.io/docs/tooling/cli
"�9
�%
formatjs_compile�Compile extracted messages into optimized runtime formats.

This rule compiles FormatJS message files (typically from `formatjs_extract` or
translation files) into optimized formats suitable for production use. The compilation
process pre-parses messages and can generate AST format for faster runtime performance.

## Features

- **AST Compilation**: Pre-parse messages into AST for faster runtime evaluation
- **Multiple Input Formats**: Support for simple, Crowdin, Smartling, and Transifex formats
- **Optimized Output**: Reduces bundle size and improves runtime performance
- **Toolchain Support**: Uses native FormatJS CLI for fast compilation

## Benefits of AST Compilation

When `ast = True`, messages are pre-parsed into Abstract Syntax Tree format:
- **Faster Runtime**: No parsing overhead when formatting messages
- **Smaller Bundles**: Parser code not needed in your application
- **Better Performance**: Especially beneficial for complex ICU MessageFormat strings

## Examples

### Basic compilation:
```starlark
formatjs_compile(
    name = "messages_compiled",
    srcs = [":messages"],  # from formatjs_extract
    out = "messages.json",
)
```

### Compile with AST for production:
```starlark
formatjs_compile(
    name = "messages_prod",
    srcs = ["translations/en.json"],
    out = "compiled-en.json",
    ast = True,
)
```

### Compile multiple translation files:
```starlark
formatjs_compile(
    name = "messages_merged",
    srcs = [
        ":base_messages",
        "translations/overrides.json",
    ],
    out = "compiled-messages.json",
    ast = True,
)
```

### Compile translation files from Crowdin:
```starlark
formatjs_compile(
    name = "fr_messages",
    srcs = ["translations/fr.json"],
    out = "compiled-fr.json",
    format = "crowdin",
    ast = True,
)
```

## Output

The compiled messages can be imported directly in your application:
```javascript
import messages from './compiled-en.json';

<IntlProvider messages={messages} locale="en">
  <App />
</IntlProvider>
```

## See Also

- `formatjs_extract`: Extract messages from source files
- `formatjs_verify_test`: Verify translations before compilation
- FormatJS CLI documentation: https://formatjs.github.io/docs/tooling/cli
*
nameA unique name for this target. �
ast�Compile to AST (Abstract Syntax Tree) format for faster runtime parsing.

When enabled, messages are pre-parsed into an optimized AST representation:
- Faster message formatting at runtime
- Smaller JavaScript bundles (parser not needed)
- Ideal for production builds

Recommended: Enable for production, disable for development for easier debugging.
2False�
format�Input format of the source file.

Supported formats:
- `default`: Default formatter: extracts defaultMessage from MessageDescriptor objects
- `simple`: Simple formatter: pass-through for Record<string, string>
- `crowdin`: Crowdin translation platform format
- `smartling`: Smartling translation platform format
- `transifex`: Transifex translation platform format
- `lokalise`: Lokalise translation platform format

Use the appropriate format based on your translation management system.
If not specified, uses the default formatter.
2""�

ignore_tag�Treat HTML/XML tags as string literals instead of parsing them as tag tokens.

When enabled, tags like `<b>` are treated as plain text rather than formatting tags.
Useful for messages that need to preserve literal tag syntax.
2False�
out�Output compiled JSON file name.

Example: `out = "messages-compiled.json"`

The compiled file will be placed in the bazel-bin directory and can be
referenced by other rules or copied to your output directory.
 �
pseudo_locale�Generate pseudo-locale files for testing.

Requires `ast = True`. Available pseudo-locales:
- `xx-LS`: Longer strings (tests UI expansion)
- `xx-AC`: Accented characters (tests character encoding)
- `xx-HA`: Right-to-left text (tests RTL layout)
- `en-XA`: Accented English
- `en-XB`: Bracketed English

Pseudo-locales help identify i18n issues without actual translations.
2""�
skip_errors�Continue compiling after errors.

When enabled, keys with errors are excluded from output but compilation continues.
When disabled (default), compilation fails on the first error.
Useful for partially migrating or dealing with incomplete translations.
2False�
srcs�Source JSON files with extracted messages.

Can include:
- Multiple outputs from `formatjs_extract` rules
- Multiple translation files from translators
- Aggregated messages from `formatjs_aggregate`

When multiple files are provided, they will be merged during compilation.
The files should contain messages in FormatJS JSON format.
 "3
formatjs_compile@@rules_formatjs//:formatjs.bzl
;;,
*
nameA unique name for this target. �
�
ast�Compile to AST (Abstract Syntax Tree) format for faster runtime parsing.

When enabled, messages are pre-parsed into an optimized AST representation:
- Faster message formatting at runtime
- Smaller JavaScript bundles (parser not needed)
- Ideal for production builds

Recommended: Enable for production, disable for development for easier debugging.
2False�
�
format�Input format of the source file.

Supported formats:
- `default`: Default formatter: extracts defaultMessage from MessageDescriptor objects
- `simple`: Simple formatter: pass-through for Record<string, string>
- `crowdin`: Crowdin translation platform format
- `smartling`: Smartling translation platform format
- `transifex`: Transifex translation platform format
- `lokalise`: Lokalise translation platform format

Use the appropriate format based on your translation management system.
If not specified, uses the default formatter.
2""�
�

ignore_tag�Treat HTML/XML tags as string literals instead of parsing them as tag tokens.

When enabled, tags like `<b>` are treated as plain text rather than formatting tags.
Useful for messages that need to preserve literal tag syntax.
2False�
�
out�Output compiled JSON file name.

Example: `out = "messages-compiled.json"`

The compiled file will be placed in the bazel-bin directory and can be
referenced by other rules or copied to your output directory.
 �
�
pseudo_locale�Generate pseudo-locale files for testing.

Requires `ast = True`. Available pseudo-locales:
- `xx-LS`: Longer strings (tests UI expansion)
- `xx-AC`: Accented characters (tests character encoding)
- `xx-HA`: Right-to-left text (tests RTL layout)
- `en-XA`: Accented English
- `en-XB`: Bracketed English

Pseudo-locales help identify i18n issues without actual translations.
2""�
�
skip_errors�Continue compiling after errors.

When enabled, keys with errors are excluded from output but compilation continues.
When disabled (default), compilation fails on the first error.
Useful for partially migrating or dealing with incomplete translations.
2False�
�
srcs�Source JSON files with extracted messages.

Can include:
- Multiple outputs from `formatjs_extract` rules
- Multiple translation files from translators
- Aggregated messages from `formatjs_aggregate`

When multiple files are provided, they will be merged during compilation.
The files should contain messages in FormatJS JSON format.
 �Yformatjs_extract�Extract internationalized messages from source files using FormatJS CLI.

This rule extracts i18n messages from TypeScript, JavaScript, JSX, TSX, and Rust files
using the native FormatJS CLI toolchain. The extracted messages are output as a
JSON file with alphabetically sorted keys for deterministic builds.

## Features

- **Automatic ID Generation**: Use content-based hashing to generate stable message IDs
- **Multiple Formats**: Extract from `<FormattedMessage>` components, `formatMessage()` calls, and custom components
- **Sorted Output**: Keys are automatically sorted alphabetically (formatjs_cli v0.1.1+)
- **Toolchain Support**: Uses native FormatJS CLI binaries for fast extraction

## Message Format

The output JSON file contains messages in the format:
```json
{
  "message.id": {
    "id": "message.id",
    "defaultMessage": "Hello, world!",
    "description": "Greeting message"
  }
}
```

## Examples

### Basic extraction with auto-generated IDs:
```starlark
formatjs_extract(
    name = "messages",
    srcs = glob(["src/**/*.tsx"]),
    id_interpolation_pattern = "[sha512:contenthash:base64:6]",
)
```

### Extract from formatMessage() calls:
```starlark
formatjs_extract(
    name = "messages",
    srcs = ["src/app.tsx"],
    extract_from_format_message_call = True,
)
```

### Custom components and functions:
```starlark
formatjs_extract(
    name = "messages",
    srcs = glob(["src/**/*.tsx"]),
    additional_component_names = ["Trans", "Translate"],
    additional_function_names = ["t", "$t"],
)
```

## Output

The rule produces a JSON file (default: `<name>.json`) containing all extracted
messages. This file can be used with `formatjs_compile` to generate compiled
message catalogs or with `formatjs_aggregate` to merge messages from multiple
targets.

## See Also

- `formatjs_compile`: Compile messages for runtime use
- `formatjs_aggregate`: Merge messages from multiple extraction targets
- `formatjs_verify_test`: Verify translation files against extracted messages
- FormatJS CLI documentation: https://formatjs.github.io/docs/tooling/cli
"�I
�,
formatjs_extract�Extract internationalized messages from source files using FormatJS CLI.

This rule extracts i18n messages from TypeScript, JavaScript, JSX, TSX, and Rust files
using the native FormatJS CLI toolchain. The extracted messages are output as a
JSON file with alphabetically sorted keys for deterministic builds.

## Features

- **Automatic ID Generation**: Use content-based hashing to generate stable message IDs
- **Multiple Formats**: Extract from `<FormattedMessage>` components, `formatMessage()` calls, and custom components
- **Sorted Output**: Keys are automatically sorted alphabetically (formatjs_cli v0.1.1+)
- **Toolchain Support**: Uses native FormatJS CLI binaries for fast extraction

## Message Format

The output JSON file contains messages in the format:
```json
{
  "message.id": {
    "id": "message.id",
    "defaultMessage": "Hello, world!",
    "description": "Greeting message"
  }
}
```

## Examples

### Basic extraction with auto-generated IDs:
```starlark
formatjs_extract(
    name = "messages",
    srcs = glob(["src/**/*.tsx"]),
    id_interpolation_pattern = "[sha512:contenthash:base64:6]",
)
```

### Extract from formatMessage() calls:
```starlark
formatjs_extract(
    name = "messages",
    srcs = ["src/app.tsx"],
    extract_from_format_message_call = True,
)
```

### Custom components and functions:
```starlark
formatjs_extract(
    name = "messages",
    srcs = glob(["src/**/*.tsx"]),
    additional_component_names = ["Trans", "Translate"],
    additional_function_names = ["t", "$t"],
)
```

## Output

The rule produces a JSON file (default: `<name>.json`) containing all extracted
messages. This file can be used with `formatjs_compile` to generate compiled
message catalogs or with `formatjs_aggregate` to merge messages from multiple
targets.

## See Also

- `formatjs_compile`: Compile messages for runtime use
- `formatjs_aggregate`: Merge messages from multiple extraction targets
- `formatjs_verify_test`: Verify translation files against extracted messages
- FormatJS CLI documentation: https://formatjs.github.io/docs/tooling/cli
*
nameA unique name for this target. �
additional_component_names�Additional React component names to extract messages from.

Allows extraction from custom wrapper components that use FormatJS internally.
Example: `additional_component_names = ["Trans", "LocalizedText"]`

The components should accept FormatJS-compatible props like `id`, `defaultMessage`,
and `description`.
2[]�
additional_function_names�Additional function names to extract messages from.

Allows extraction from custom wrapper functions that use FormatJS internally.
Example: `additional_function_names = ["t", "$t", "i18n"]`

The functions should accept FormatJS-compatible message descriptors.
2[]�
deps�Dependencies that this extraction depends on (for aspect propagation).

Used when applying aspects that need to traverse the dependency graph.
Typically not needed for basic extraction workflows.
*
FormatjsExtractInfo*
DefaultInfo2[]�
extract_source_location�Whether to extract metadata about message location in source file.

When enabled, the output will include file paths and line numbers for each message.
This is useful for debugging and tracking message origins.
2False�
flattenWhether to hoist selectors and flatten sentences.

This flattens complex message structures for simpler translation workflows.
2False�
format�Formatter to use for output format.

Available formatters:
- `default` - Default formatter: extracts defaultMessage from MessageDescriptor objects
- `simple` - Simple formatter: pass-through for Record<string, string>
- `transifex` - Transifex formatter: extracts string field
- `smartling` - Smartling formatter: extracts message field
- `lokalise` - Lokalise formatter: extracts translation field
- `crowdin` - Crowdin formatter: extracts message field

If not specified, uses the default formatter.
2""�
id_interpolation_pattern�Pattern for generating message IDs automatically.

Uses content-based hashing to generate stable, unique IDs. Common patterns:
- `[sha512:contenthash:base64:6]` - 6-char base64-encoded SHA-512 hash
- `[sha256:contenthash:hex:8]` - 8-char hex-encoded SHA-256 hash
- `[contenthash:5]` - 5-char hash (default algorithm)

If not specified, messages must provide explicit `id` attributes.
Default: `[sha512:contenthash:base64:6]`
2""�
ignore�List of glob patterns to exclude from extraction.

Files matching these patterns will not be processed.
Example: `ignore = ["**/*.test.tsx", "**/__mocks__/**"]`
2[]�
out�Output file name (optional).

If not specified, defaults to `<target_name>.json`.
Example: `out = "extracted-messages.json"`

When specified, the output file can be referenced directly by its path
(e.g., `:messages/en.json` if out = "messages/en.json").
|
pragmalParse custom pragma for file metadata.

Example: `pragma = "@intl-meta"` to parse custom metadata comments.
2""�
preserve_whitespace�Whether to preserve whitespace and newlines in extracted messages.

By default, whitespace is normalized. Enable this to preserve exact formatting.
2False�
srcs�Source files to extract messages from.

Supports TypeScript (.ts, .tsx), JavaScript (.js, .jsx), ES modules (.mjs, .cjs),
and Rust (.rs).
Use glob patterns to extract from multiple files:
```starlark
srcs = glob(["src/**/*.{ts,tsx}"])
```
 �
throws�Whether to throw an exception when failing to process any file.

When enabled (default), the extraction will fail if any source file cannot be processed.
When disabled, problematic files are skipped with warnings.
2True"3
formatjs_extract@@rules_formatjs//:formatjs.bzl
oo,
*
nameA unique name for this target. �
�
additional_component_names�Additional React component names to extract messages from.

Allows extraction from custom wrapper components that use FormatJS internally.
Example: `additional_component_names = ["Trans", "LocalizedText"]`

The components should accept FormatJS-compatible props like `id`, `defaultMessage`,
and `description`.
2[]�
�
additional_function_names�Additional function names to extract messages from.

Allows extraction from custom wrapper functions that use FormatJS internally.
Example: `additional_function_names = ["t", "$t", "i18n"]`

The functions should accept FormatJS-compatible message descriptors.
2[]�
�
deps�Dependencies that this extraction depends on (for aspect propagation).

Used when applying aspects that need to traverse the dependency graph.
Typically not needed for basic extraction workflows.
*
FormatjsExtractInfo*
DefaultInfo2[]�
�
extract_source_location�Whether to extract metadata about message location in source file.

When enabled, the output will include file paths and line numbers for each message.
This is useful for debugging and tracking message origins.
2False�
�
flattenWhether to hoist selectors and flatten sentences.

This flattens complex message structures for simpler translation workflows.
2False�
�
format�Formatter to use for output format.

Available formatters:
- `default` - Default formatter: extracts defaultMessage from MessageDescriptor objects
- `simple` - Simple formatter: pass-through for Record<string, string>
- `transifex` - Transifex formatter: extracts string field
- `smartling` - Smartling formatter: extracts message field
- `lokalise` - Lokalise formatter: extracts translation field
- `crowdin` - Crowdin formatter: extracts message field

If not specified, uses the default formatter.
2""�
�
id_interpolation_pattern�Pattern for generating message IDs automatically.

Uses content-based hashing to generate stable, unique IDs. Common patterns:
- `[sha512:contenthash:base64:6]` - 6-char base64-encoded SHA-512 hash
- `[sha256:contenthash:hex:8]` - 8-char hex-encoded SHA-256 hash
- `[contenthash:5]` - 5-char hash (default algorithm)

If not specified, messages must provide explicit `id` attributes.
Default: `[sha512:contenthash:base64:6]`
2""�
�
ignore�List of glob patterns to exclude from extraction.

Files matching these patterns will not be processed.
Example: `ignore = ["**/*.test.tsx", "**/__mocks__/**"]`
2[]�
�
out�Output file name (optional).

If not specified, defaults to `<target_name>.json`.
Example: `out = "extracted-messages.json"`

When specified, the output file can be referenced directly by its path
(e.g., `:messages/en.json` if out = "messages/en.json").
~
|
pragmalParse custom pragma for file metadata.

Example: `pragma = "@intl-meta"` to parse custom metadata comments.
2""�
�
preserve_whitespace�Whether to preserve whitespace and newlines in extracted messages.

By default, whitespace is normalized. Enable this to preserve exact formatting.
2False�
�
srcs�Source files to extract messages from.

Supports TypeScript (.ts, .tsx), JavaScript (.js, .jsx), ES modules (.mjs, .cjs),
and Rust (.rs).
Use glob patterns to extract from multiple files:
```starlark
srcs = glob(["src/**/*.{ts,tsx}"])
```
 �
�
throws�Whether to throw an exception when failing to process any file.

When enabled (default), the extraction will fail if any source file cannot be processed.
When disabled, problematic files are skipped with warnings.
2True�
//formatjs:defs.bzlr�
$
rules_formatjsformatjsdefs.bzl3
formatjs_compile_formatjs_compile

,
=3
formatjs_extract_formatjs_extract

T
e


{�Public API for rules_formatjs

Load this file to access FormatJS Bazel rules:

```starlark
load("@rules_formatjs//formatjs:defs.bzl", "formatjs_extract", "formatjs_compile")
```
 