�
"
rules_gherkingherkindefs.bzl*�ModuleInfo request error: invalid argument: Traceback (most recent call last):
	File "external/rules_gherkin/gherkin/defs.bzl", line 2, column 33, in <toplevel>
		load("@rules_cc//cc:defs.bzl", "cc_binary")
Error: file '@rules_cc//cc:defs.bzl' does not contain symbol 'cc_binary' 