�
 
	rules_idbidbextensions.bzl�idb>Fetches the prebuilt idb_companion distribution for rules_idb.J}
m
idb>Fetches the prebuilt idb_companion distribution for rules_idb."&
idb@@rules_idb//idb:extensions.bzl
00�
 //tools/build_defs/repo:http.bzlrj
.
bazel_toolstools/build_defs/repohttp.bzl*
http_archivehttp_archive
7C
E'	COMPANION_RELEASEv0.3.0jv0.3.0�	COMPANION_SHA256@1edd25393d4922ba08946b9f7dd3c84cd905004e0e775216713d8c9b75d3396ajB@1edd25393d4922ba08946b9f7dd3c84cd905004e0e775216713d8c9b75d3396a�Module extension fetching the prebuilt idb_companion distribution.

The artifact is built by rules_idb's release pipeline from a pinned
facebook/idb commit plus patches/idb-build-fixes.patch; each release's notes
record the commit, patch, and the Xcode version it was built and verified
with. To use a locally built companion instead, set the
RULES_IDB_COMPANION_PATH environment variable at test time (see
docs/BUILDING_IDB.md).
�M
%
	rules_idbidbidb_test_runner.bzl�Fios_idb_test_runner�
Creates a test runner for `ios_unit_test` and `ios_ui_test` targets that
executes tests with Facebook's idb instead of xcodebuild.

Example:

```bzl
load("@rules_idb//idb:idb_test_runner.bzl", "ios_idb_test_runner")

ios_idb_test_runner(
    name = "idb_runner",
    device_type = "iPhone 17 Pro",
)

ios_unit_test(
    name = "HostedTests",
    minimum_os_version = "16.0",
    runner = ":idb_runner",
    test_host = ":HostApp",
    deps = [":HostedTestsLib"],
)
```

Or use the predefined runner `@rules_idb//idb:default_runner`.
"�A
�#
ios_idb_test_runner�
Creates a test runner for `ios_unit_test` and `ios_ui_test` targets that
executes tests with Facebook's idb instead of xcodebuild.

Example:

```bzl
load("@rules_idb//idb:idb_test_runner.bzl", "ios_idb_test_runner")

ios_idb_test_runner(
    name = "idb_runner",
    device_type = "iPhone 17 Pro",
)

ios_unit_test(
    name = "HostedTests",
    minimum_os_version = "16.0",
    runner = ":idb_runner",
    test_host = ":HostApp",
    deps = [":HostedTestsLib"],
)
```

Or use the predefined runner `@rules_idb//idb:default_runner`.
*
nameA unique name for this target. �
clean_up_simulator_action�
Optional binary that cleans up the simulator produced by
`create_simulator_action`. Runs after the `post_action`, regardless of test
outcome, with `SIMULATOR_UDID` and `SIMULATOR_REUSE_SIMULATOR` set. Only
used when `create_simulator_action` is also set.
2None�
create_simulator_action�
Optional binary that produces the UDID of a simulator to run the tests on,
replacing the built-in flock-based simulator pool. The binary must print
only the UDID to stdout. It receives the same environment contract as
rules_apple's `ios_xctestrun_runner`: `SIMULATOR_DEVICE_TYPE`,
`SIMULATOR_OS_VERSION`, and `SIMULATOR_REUSE_SIMULATOR` (always "1" unless
`shutdown_simulator_after_test` is set). Teams with an existing custom
`simulator_creator` can plug it in here unchanged; most users should prefer
the built-in pool, which already provides concurrency-safe simulator
acquisition.
2None�
device_type�
The simulator device type to run tests on, e.g. `iPhone 17 Pro`. Values
correspond to `xcrun simctl list devicetypes`. If empty, the newest available
iPhone device type is used.
2""�
idb_path�
Path to an `idb` client binary. When empty (the default) the client bundled
with rules_idb is used; nothing needs to be installed. Can be overridden at
test time with the `RULES_IDB_IDB_PATH` environment variable (and
`RULES_IDB_COMPANION_PATH` for the companion).
2""�
max_concurrent_boots�
Maximum number of simulators created/booted concurrently, machine-wide
across all pools and test actions; already-booted simulators are
unaffected. `0` (the default) means auto: half the machine's CPU cores.
Measured on an M4 Max (16 cores, so auto = 8): parallelism won at every
tested level â 8 create+first-boots took 87s uncapped vs 115s at cap 4 vs
much longer serialized â while low-memory or busy CI machines benefit from
a low explicit cap. Can be overridden at test time with the
`RULES_IDB_MAX_CONCURRENT_BOOTS` environment variable.
20�

os_version�
The iOS version to run tests on, e.g. `26.2`. Values correspond to
`xcrun simctl list runtimes`. If empty, the newest available iOS runtime is
used.
2""�
	pool_size�
Maximum number of pooled simulators per (device_type, os_version)
combination. `0` (the default) grows on demand; concurrency is naturally
bounded by Bazel's `--local_test_jobs`. Idle footprint is bounded
separately: after a test, only the first `RULES_IDB_WARM_POOL_SIZE`
(default 4) slots keep their simulator booted (each booted simulator holds
~60-100 CoreSimulator processes); higher slots shut theirs down. Can be
overridden at test time with the `RULES_IDB_POOL_SIZE` environment variable.
Ignored when a custom `create_simulator_action` is provided.
20�
post_action�
A binary to run following test execution, before test result handling. Sets
`$TEST_EXIT_CODE`, `$TEST_LOG_FILE`, and `$SIMULATOR_UDID`, in addition to
any other variables available to the test runner.
2None�
 post_action_determines_exit_code�
When true, the exit code of the test run is the exit code of the
`post_action`. Useful for tests that need to fail based on their own
criteria.
2False�

pre_action�
A binary to run prior to test execution, after simulator acquisition. Sets
the `$SIMULATOR_UDID` environment variable, in addition to any other
variables available to the test runner.
2None�
random�
Whether to run the tests in random order to identify unintended state
dependencies. Requires a test host (hosted or UI tests).
2False�
shutdown_simulator_after_test�
Shut the pooled simulator down after the test finishes. The default keeps
simulators booted so subsequent test runs reuse a warm simulator, which is
substantially faster. Enable this to trade speed for a lower idle memory
footprint.
2False";
ios_idb_test_runner$@@rules_idb//idb:idb_test_runner.bzl
yy,
*
nameA unique name for this target. �
�
clean_up_simulator_action�
Optional binary that cleans up the simulator produced by
`create_simulator_action`. Runs after the `post_action`, regardless of test
outcome, with `SIMULATOR_UDID` and `SIMULATOR_REUSE_SIMULATOR` set. Only
used when `create_simulator_action` is also set.
2None�
�
create_simulator_action�
Optional binary that produces the UDID of a simulator to run the tests on,
replacing the built-in flock-based simulator pool. The binary must print
only the UDID to stdout. It receives the same environment contract as
rules_apple's `ios_xctestrun_runner`: `SIMULATOR_DEVICE_TYPE`,
`SIMULATOR_OS_VERSION`, and `SIMULATOR_REUSE_SIMULATOR` (always "1" unless
`shutdown_simulator_after_test` is set). Teams with an existing custom
`simulator_creator` can plug it in here unchanged; most users should prefer
the built-in pool, which already provides concurrency-safe simulator
acquisition.
2None�
�
device_type�
The simulator device type to run tests on, e.g. `iPhone 17 Pro`. Values
correspond to `xcrun simctl list devicetypes`. If empty, the newest available
iPhone device type is used.
2""�
�
idb_path�
Path to an `idb` client binary. When empty (the default) the client bundled
with rules_idb is used; nothing needs to be installed. Can be overridden at
test time with the `RULES_IDB_IDB_PATH` environment variable (and
`RULES_IDB_COMPANION_PATH` for the companion).
2""�
�
max_concurrent_boots�
Maximum number of simulators created/booted concurrently, machine-wide
across all pools and test actions; already-booted simulators are
unaffected. `0` (the default) means auto: half the machine's CPU cores.
Measured on an M4 Max (16 cores, so auto = 8): parallelism won at every
tested level â 8 create+first-boots took 87s uncapped vs 115s at cap 4 vs
much longer serialized â while low-memory or busy CI machines benefit from
a low explicit cap. Can be overridden at test time with the
`RULES_IDB_MAX_CONCURRENT_BOOTS` environment variable.
20�
�

os_version�
The iOS version to run tests on, e.g. `26.2`. Values correspond to
`xcrun simctl list runtimes`. If empty, the newest available iOS runtime is
used.
2""�
�
	pool_size�
Maximum number of pooled simulators per (device_type, os_version)
combination. `0` (the default) grows on demand; concurrency is naturally
bounded by Bazel's `--local_test_jobs`. Idle footprint is bounded
separately: after a test, only the first `RULES_IDB_WARM_POOL_SIZE`
(default 4) slots keep their simulator booted (each booted simulator holds
~60-100 CoreSimulator processes); higher slots shut theirs down. Can be
overridden at test time with the `RULES_IDB_POOL_SIZE` environment variable.
Ignored when a custom `create_simulator_action` is provided.
20�
�
post_action�
A binary to run following test execution, before test result handling. Sets
`$TEST_EXIT_CODE`, `$TEST_LOG_FILE`, and `$SIMULATOR_UDID`, in addition to
any other variables available to the test runner.
2None�
�
 post_action_determines_exit_code�
When true, the exit code of the test run is the exit code of the
`post_action`. Useful for tests that need to fail based on their own
criteria.
2False�
�

pre_action�
A binary to run prior to test execution, after simulator acquisition. Sets
the `$SIMULATOR_UDID` environment variable, in addition to any other
variables available to the test runner.
2None�
�
random�
Whether to run the tests in random order to identify unintended state
dependencies. Requires a test host (hosted or UI tests).
2False�
�
shutdown_simulator_after_test�
Shut the pooled simulator down after the test finishes. The default keeps
simulators booted so subsequent test runs reuse a warm simulator, which is
substantially faster. Enable this to trade speed for a lower idle memory
footprint.
2False�
//apple:providers.bzlr�
#
rules_appleappleproviders.bzlD
AppleDeviceTestRunnerInfoAppleDeviceTestRunnerInfo
.
apple_providerapple_provider

�An iOS test runner rule that runs XCTest bundles on simulators via
Facebook's idb (https://github.com/facebook/idb) instead of xcodebuild.

Compared to the default rules_apple runners this runner:

* Uses `idb` + `idb_companion` to install and run hosted, logic, and UI
  tests, which uses far less memory than `xcodebuild
  test-without-building`.
* Supports `--local_test_jobs=N` out of the box: each concurrently running
  test acquires its own simulator from a pool guarded by kernel `flock`
  locks. Locks are tied to the runner process lifetime, so they are released
  automatically even when a test is killed (no stale lock files, no traps).
 