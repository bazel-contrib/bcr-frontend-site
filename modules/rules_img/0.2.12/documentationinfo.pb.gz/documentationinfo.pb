�

	rules_imgimgconvert.bzl�	image_manifest_from_oci_layout"�
�
image_manifest_from_oci_layout*
nameA unique name for this target. C
src8The directory containing the OCI layout to convert from. C
architecture/The target architecture for the image manifest. =
os3The target operating system for the image manifest. o
layersaA list of layer media types. Use the well-defined media types in @rules_img//img:media_types.bzl. S
variantBThe platform variant (e.g., 'v3' for amd64/v3, 'v8' for arm64/v8).2"""a
image_manifest_from_oci_layout?@rules_img//img/private/conversion:manifest_from_oci_layout.bzl*]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl,
*
nameA unique name for this target. E
C
src8The directory containing the OCI layout to convert from. E
C
architecture/The target architecture for the image manifest. ?
=
os3The target operating system for the image manifest. q
o
layersaA list of layer media types. Use the well-defined media types in @rules_img//img:media_types.bzl. U
S
variantBThe platform variant (e.g., 'v3' for amd64/v3, 'v8' for arm64/v8).2""�image_index_from_oci_layout"�
�
image_index_from_oci_layout*
nameA unique name for this target. C
src8The directory containing the OCI layout to convert from. �
layers�A list of layer media types. This applies to all manifests. Use the well-defined media types in @rules_img//img:media_types.bzl. �
	manifests�An ordered list of platform specifications in 'os/architecture' or 'os/architecture/variant' format.
Example: ["linux/arm64", "linux/amd64/v3"] "[
image_index_from_oci_layout<@rules_img//img/private/conversion:index_from_oci_layout.bzl*T
ImageIndexInfoB
ImageIndexInfo0@rules_img//img/private/providers:index_info.bzl,
*
nameA unique name for this target. E
C
src8The directory containing the OCI layout to convert from. �
�
layers�A list of layer media types. This applies to all manifests. Use the well-defined media types in @rules_img//img:media_types.bzl. �
�
	manifests�An ordered list of platform specifications in 'os/architecture' or 'os/architecture/variant' format.
Example: ["linux/arm64", "linux/amd64/v3"] �Rules to convert OCI layout directories to container images.

Use `image_manifest_from_oci_layout` to convert an OCI layout directory
to a single-platform container image manifest, and
`image_index_from_oci_layout` to convert an OCI layout directory
to a multi-platform container image index.��

	rules_imgimg	image.bzl�Pimage_manifest�Builds a single-platform OCI container image from a set of layers.

This rule assembles container images by combining:
- Optional base image layers (from another image_manifest or image_index)
- Additional layers created by image_layer rules
- Image configuration (entrypoint, environment, labels, etc.)

The rule produces:
- OCI manifest and config JSON files
- An optional OCI layout directory or tar (via output groups)
- ImageManifestInfo provider for use by image_index or image_push

Example:

```python
image_manifest(
    name = "my_app",
    base = "@distroless_cc",
    layers = [
        ":app_layer",
        ":config_layer",
    ],
    entrypoint = ["/usr/bin/app"],
    env = {
        "APP_ENV": "production",
    },
)
```

Output groups:
- `descriptor`: OCI descriptor JSON file
- `digest`: Digest of the image (sha256:...)
- `oci_layout`: Complete OCI layout directory with blobs
- `oci_tarball`: OCI layout packaged as a tar file for downstream use"�H
�(
image_manifest�Builds a single-platform OCI container image from a set of layers.

This rule assembles container images by combining:
- Optional base image layers (from another image_manifest or image_index)
- Additional layers created by image_layer rules
- Image configuration (entrypoint, environment, labels, etc.)

The rule produces:
- OCI manifest and config JSON files
- An optional OCI layout directory or tar (via output groups)
- ImageManifestInfo provider for use by image_index or image_push

Example:

```python
image_manifest(
    name = "my_app",
    base = "@distroless_cc",
    layers = [
        ":app_layer",
        ":config_layer",
    ],
    entrypoint = ["/usr/bin/app"],
    env = {
        "APP_ENV": "production",
    },
)
```

Output groups:
- `descriptor`: OCI descriptor JSON file
- `digest`: Digest of the image (sha256:...)
- `oci_layout`: Complete OCI layout directory with blobs
- `oci_tarball`: OCI layout packaged as a tar file for downstream use*
nameA unique name for this target. f
baseVBase image to inherit layers from. Should provide ImageManifestInfo or ImageIndexInfo.2Nonel
layers\Layers to include in the image. Either a LayerInfo provider or a DefaultInfo with tar files.2[]�
platform�Optional target platform to build this manifest for.

When specified, the image will be built for the provided platform regardless
of the current build configuration. This enables building single-platform images
for specific architectures.

Example:
```python
image_manifest(
    name = "app_arm64",
    platform = "//platforms:linux_arm64",
    base = "@ubuntu",
    layers = [":app_layer"],
)
```*(
PlatformInfo
PlatformInfo<native>2None�
user�The username or UID which is a platform-specific structure that allows specific control over which user the process run as.
This acts as a default value to use when the value is not specified when creating a container.2""�
env�Default environment variables to set when starting a container based on this image.

Subject to [template expansion](/docs/templating.md).
2{}�

entrypoint�A list of arguments to use as the command to execute when the container starts. These values act as defaults and may be replaced by an entrypoint specified when creating a container.2[]�
cmd�Default arguments to the entrypoint of the container. These values act as defaults and may be replaced by any specified when creating a container. If an Entrypoint value is not specified, then the first entry of the Cmd array SHOULD be interpreted as the executable to run.2[]�
working_dir�Sets the current working directory of the entrypoint process in the container. This value acts as a default and may be replaced by a working directory specified when creating a container.2""�
labelspThis field contains arbitrary metadata for the container.

Subject to [template expansion](/docs/templating.md).
2{}�
annotationsoThis field contains arbitrary metadata for the manifest.

Subject to [template expansion](/docs/templating.md).
2{}�
annotations_file�File containing newline-delimited KEY=VALUE annotations for the manifest.

The file should contain one annotation per line in KEY=VALUE format. Empty lines are ignored.
Annotations from this file are merged with annotations specified via the `annotations` attribute.

Example file content:
```
version=1.0.0
build.date=2024-01-15
source.url=https://github.com/...
```

Each annotation is subject to [template expansion](/docs/templating.md).2None�
stop_signal�This field contains the system call signal that will be sent to the container to exit. The signal can be a signal name in the format SIGNAME, for instance SIGKILL or SIGRTMIN+3.2""�
config_fragmentnOptional JSON file containing a partial image config, which will be used as a base for the final image config.2None�
created�Optional file containing a datetime string (RFC 3339 format) for when the image was created.

This is commonly used with Bazel's stamping mechanism to embed the build timestamp.2None�
build_settings�Build settings for template expansion.

Maps template variable names to string_flag targets. These values can be used in
env, labels, and annotations attributes using `{{.VARIABLE_NAME}}` syntax (Go template).

Example:
```python
build_settings = {
    "REGISTRY": "//settings:docker_registry",
    "VERSION": "//settings:app_version",
}
```

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
stamp�Enable build stamping for template expansion.

Controls whether to include volatile build information:
- **`auto`** (default): Uses the global stamping configuration
- **`enabled`**: Always include stamp information (BUILD_TIMESTAMP, BUILD_USER, etc.) if Bazel's "--stamp" flag is set
- **`disabled`**: Never include stamp information

See [template expansion](/docs/templating.md) for available stamp variables.2"auto""6
image_manifest$@rules_img//img/private:manifest.bzl*]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl,
*
nameA unique name for this target. h
f
baseVBase image to inherit layers from. Should provide ImageManifestInfo or ImageIndexInfo.2Nonen
l
layers\Layers to include in the image. Either a LayerInfo provider or a DefaultInfo with tar files.2[]�
�
platform�Optional target platform to build this manifest for.

When specified, the image will be built for the provided platform regardless
of the current build configuration. This enables building single-platform images
for specific architectures.

Example:
```python
image_manifest(
    name = "app_arm64",
    platform = "//platforms:linux_arm64",
    base = "@ubuntu",
    layers = [":app_layer"],
)
```*(
PlatformInfo
PlatformInfo<native>2None�
�
user�The username or UID which is a platform-specific structure that allows specific control over which user the process run as.
This acts as a default value to use when the value is not specified when creating a container.2""�
�
env�Default environment variables to set when starting a container based on this image.

Subject to [template expansion](/docs/templating.md).
2{}�
�

entrypoint�A list of arguments to use as the command to execute when the container starts. These values act as defaults and may be replaced by an entrypoint specified when creating a container.2[]�
�
cmd�Default arguments to the entrypoint of the container. These values act as defaults and may be replaced by any specified when creating a container. If an Entrypoint value is not specified, then the first entry of the Cmd array SHOULD be interpreted as the executable to run.2[]�
�
working_dir�Sets the current working directory of the entrypoint process in the container. This value acts as a default and may be replaced by a working directory specified when creating a container.2""�
�
labelspThis field contains arbitrary metadata for the container.

Subject to [template expansion](/docs/templating.md).
2{}�
�
annotationsoThis field contains arbitrary metadata for the manifest.

Subject to [template expansion](/docs/templating.md).
2{}�
�
annotations_file�File containing newline-delimited KEY=VALUE annotations for the manifest.

The file should contain one annotation per line in KEY=VALUE format. Empty lines are ignored.
Annotations from this file are merged with annotations specified via the `annotations` attribute.

Example file content:
```
version=1.0.0
build.date=2024-01-15
source.url=https://github.com/...
```

Each annotation is subject to [template expansion](/docs/templating.md).2None�
�
stop_signal�This field contains the system call signal that will be sent to the container to exit. The signal can be a signal name in the format SIGNAME, for instance SIGKILL or SIGRTMIN+3.2""�
�
config_fragmentnOptional JSON file containing a partial image config, which will be used as a base for the final image config.2None�
�
created�Optional file containing a datetime string (RFC 3339 format) for when the image was created.

This is commonly used with Bazel's stamping mechanism to embed the build timestamp.2None�
�
build_settings�Build settings for template expansion.

Maps template variable names to string_flag targets. These values can be used in
env, labels, and annotations attributes using `{{.VARIABLE_NAME}}` syntax (Go template).

Example:
```python
build_settings = {
    "REGISTRY": "//settings:docker_registry",
    "VERSION": "//settings:app_version",
}
```

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
�
stamp�Enable build stamping for template expansion.

Controls whether to include volatile build information:
- **`auto`** (default): Uses the global stamping configuration
- **`enabled`**: Always include stamp information (BUILD_TIMESTAMP, BUILD_USER, etc.) if Bazel's "--stamp" flag is set
- **`disabled`**: Never include stamp information

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"�2image_index�	Creates a multi-platform OCI image index from platform-specific manifests.

This rule combines multiple single-platform images (created by image_manifest) into
a multi-platform image index. The index allows container runtimes to automatically
select the appropriate image for their platform.

The rule supports two usage patterns:
1. Explicit manifests: Provide pre-built manifests for each platform
2. Platform transitions: Provide one manifest target and a list of platforms

The rule produces:
- OCI image index JSON file
- An optional OCI layout directory or tar (via output groups)
- ImageIndexInfo provider for use by image_push

Example (explicit manifests):

```python
image_index(
    name = "multiarch_app",
    manifests = [
        ":app_linux_amd64",
        ":app_linux_arm64",
        ":app_darwin_amd64",
    ],
)
```

Example (platform transitions):
```python
image_index(
    name = "multiarch_app",
    manifests = [":app"],
    platforms = [
        "//platform:linux-x86_64",
        "//platform:linux-aarch64",
    ],
)
```

Output groups:
- `digest`: Digest of the image (sha256:...)
- `oci_layout`: Complete OCI layout directory with all platform blobs
- `oci_tarball`: OCI layout packaged as a tar file for downstream use"�)
�
image_index�	Creates a multi-platform OCI image index from platform-specific manifests.

This rule combines multiple single-platform images (created by image_manifest) into
a multi-platform image index. The index allows container runtimes to automatically
select the appropriate image for their platform.

The rule supports two usage patterns:
1. Explicit manifests: Provide pre-built manifests for each platform
2. Platform transitions: Provide one manifest target and a list of platforms

The rule produces:
- OCI image index JSON file
- An optional OCI layout directory or tar (via output groups)
- ImageIndexInfo provider for use by image_push

Example (explicit manifests):

```python
image_index(
    name = "multiarch_app",
    manifests = [
        ":app_linux_amd64",
        ":app_linux_arm64",
        ":app_darwin_amd64",
    ],
)
```

Example (platform transitions):
```python
image_index(
    name = "multiarch_app",
    manifests = [":app"],
    platforms = [
        "//platform:linux-x86_64",
        "//platform:linux-aarch64",
    ],
)
```

Output groups:
- `digest`: Digest of the image (sha256:...)
- `oci_layout`: Complete OCI layout directory with all platform blobs
- `oci_tarball`: OCI layout packaged as a tar file for downstream use*
nameA unique name for this target. �
	manifests)List of manifests for specific platforms.*]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl2[]�
	platforms�(Optional) list of target platforms to build the manifest for. Uses a split transition. If specified, the 'manifests' attribute should contain exactly one manifest.*(
PlatformInfo
PlatformInfo<native>2[]s
annotations^Arbitrary metadata for the image index.

Subject to [template expansion](/docs/templating.md).
2{}�
annotations_file�File containing newline-delimited KEY=VALUE annotations for the image index.

The file should contain one annotation per line in KEY=VALUE format. Empty lines are ignored.
Annotations from this file are merged with annotations specified via the `annotations` attribute.

Example file content:
```
version=1.0.0
build.date=2024-01-15
source.url=https://github.com/...
```

Each annotation is subject to [template expansion](/docs/templating.md).2None�
build_settings�Build settings for template expansion.

Maps template variable names to string_flag targets. These values can be used in
the annotations attribute using `{{.VARIABLE_NAME}}` syntax (Go template).

Example:
```python
build_settings = {
    "REGISTRY": "//settings:docker_registry",
    "VERSION": "//settings:app_version",
}
```

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
stamp�Enable build stamping for template expansion.

Controls whether to include volatile build information:
- **`auto`** (default): Uses the global stamping configuration
- **`enabled`**: Always include stamp information (BUILD_TIMESTAMP, BUILD_USER, etc.) if Bazel's "--stamp" flag is set
- **`disabled`**: Never include stamp information

See [template expansion](/docs/templating.md) for available stamp variables.2"auto""0
image_index!@rules_img//img/private:index.bzl,
*
nameA unique name for this target. �
�
	manifests)List of manifests for specific platforms.*]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl2[]�
�
	platforms�(Optional) list of target platforms to build the manifest for. Uses a split transition. If specified, the 'manifests' attribute should contain exactly one manifest.*(
PlatformInfo
PlatformInfo<native>2[]u
s
annotations^Arbitrary metadata for the image index.

Subject to [template expansion](/docs/templating.md).
2{}�
�
annotations_file�File containing newline-delimited KEY=VALUE annotations for the image index.

The file should contain one annotation per line in KEY=VALUE format. Empty lines are ignored.
Annotations from this file are merged with annotations specified via the `annotations` attribute.

Example file content:
```
version=1.0.0
build.date=2024-01-15
source.url=https://github.com/...
```

Each annotation is subject to [template expansion](/docs/templating.md).2None�
�
build_settings�Build settings for template expansion.

Maps template variable names to string_flag targets. These values can be used in
the annotations attribute using `{{.VARIABLE_NAME}}` syntax (Go template).

Example:
```python
build_settings = {
    "REGISTRY": "//settings:docker_registry",
    "VERSION": "//settings:app_version",
}
```

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
�
stamp�Enable build stamping for template expansion.

Controls whether to include volatile build information:
- **`auto`** (default): Uses the global stamping configuration
- **`enabled`**: Always include stamp information (BUILD_TIMESTAMP, BUILD_USER, etc.) if Bazel's "--stamp" flag is set
- **`disabled`**: Never include stamp information

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"�Rules to build container images from layers.

Use `image_manifest` to create a single-platform container image,
and `image_index` to compose a multi-platform container image index.�a

	rules_imgimg	layer.bzl�6image_layer�	Creates a container image layer from files, executables, and directories.

This rule packages files into a layer that can be used in container images. It supports:
- Adding files at specific paths in the image
- Setting file permissions and ownership
- Creating symlinks
- Including executables with their runfiles
- Compression (gzip, zstd) and eStargz optimization

Example:

```python
load("@rules_img//img:layer.bzl", "image_layer", "file_metadata")

# Simple layer with files
image_layer(
    name = "app_layer",
    srcs = {
        "/app/bin/server": "//cmd/server",
        "/app/config.json": ":config.json",
    },
)

# Layer with custom permissions
image_layer(
    name = "secure_layer",
    srcs = {
        "/etc/app/config": ":config",
        "/etc/app/secret": ":secret",
    },
    default_metadata = file_metadata(
        mode = "0644",
        uid = 1000,
        gid = 1000,
    ),
    file_metadata = {
        "/etc/app/secret": file_metadata(mode = "0600"),
    },
)

# Layer with symlinks
image_layer(
    name = "bin_layer",
    srcs = {
        "/usr/local/bin/app": "//cmd/app",
    },
    symlinks = {
        "/usr/bin/app": "/usr/local/bin/app",
    },
)
```"�,
�
image_layer�	Creates a container image layer from files, executables, and directories.

This rule packages files into a layer that can be used in container images. It supports:
- Adding files at specific paths in the image
- Setting file permissions and ownership
- Creating symlinks
- Including executables with their runfiles
- Compression (gzip, zstd) and eStargz optimization

Example:

```python
load("@rules_img//img:layer.bzl", "image_layer", "file_metadata")

# Simple layer with files
image_layer(
    name = "app_layer",
    srcs = {
        "/app/bin/server": "//cmd/server",
        "/app/config.json": ":config.json",
    },
)

# Layer with custom permissions
image_layer(
    name = "secure_layer",
    srcs = {
        "/etc/app/config": ":config",
        "/etc/app/secret": ":secret",
    },
    default_metadata = file_metadata(
        mode = "0644",
        uid = 1000,
        gid = 1000,
    ),
    file_metadata = {
        "/etc/app/secret": file_metadata(mode = "0600"),
    },
)

# Layer with symlinks
image_layer(
    name = "bin_layer",
    srcs = {
        "/usr/local/bin/app": "//cmd/app",
    },
    symlinks = {
        "/usr/bin/app": "/usr/local/bin/app",
    },
)
```*
nameA unique name for this target. �
srcs�Files to include in the layer. Keys are paths in the image (e.g., "/app/bin/server"),
values are labels to files or executables. Executables automatically include their runfiles unless include_runfiles is set to False.2{}}
symlinkskSymlinks to create in the layer. Keys are symlink paths in the image,
values are the targets they point to.
2{}r
compress\Compression algorithm to use. If set to 'auto', uses the global default compression setting.2"auto"�
estargz�Whether to use estargz format. If set to 'auto', uses the global default estargz setting.
When enabled, the layer will be optimized for lazy pulling and will be compatible with the estargz format.2"auto"�
create_parent_directories�Whether to automatically create parent directory entries in the tar file for all files.
If set to 'auto', uses the global default create_parent_directories setting.
When enabled, parent directories will be created automatically for all files in the layer.2"auto"�
include_runfiles�Whether to include runfiles for executable targets.
When True (default), executables in srcs will include their runfiles tree.
When False, only the executable file itself is included, without runfiles.2TrueQ
annotations<Annotations to add to the layer metadata as key-value pairs.
2{}�
annotations_file�File containing newline-delimited KEY=VALUE annotations for the layer.

The file should contain one annotation per line in KEY=VALUE format. Empty lines are ignored.
Annotations from this file are merged with annotations specified via the `annotations` attribute.

Example file content:
```
version=1.0.0
build.date=2024-01-15
source.url=https://github.com/...
```2None�
default_metadata�JSON-encoded default metadata to apply to all files in the layer.
Can include fields like mode, uid, gid, uname, gname, mtime, and pax_records.2""�
file_metadata�Per-file metadata overrides as a dict mapping file paths to JSON-encoded metadata.
The path should match the path in the image (the key in srcs attribute).
Metadata specified here overrides any defaults from default_metadata.
2{}"0
image_layer!@rules_img//img/private:layer.bzl*J
	LayerInfo=
	LayerInfo0@rules_img//img/private/providers:layer_info.bzl,
*
nameA unique name for this target. �
�
srcs�Files to include in the layer. Keys are paths in the image (e.g., "/app/bin/server"),
values are labels to files or executables. Executables automatically include their runfiles unless include_runfiles is set to False.2{}
}
symlinkskSymlinks to create in the layer. Keys are symlink paths in the image,
values are the targets they point to.
2{}t
r
compress\Compression algorithm to use. If set to 'auto', uses the global default compression setting.2"auto"�
�
estargz�Whether to use estargz format. If set to 'auto', uses the global default estargz setting.
When enabled, the layer will be optimized for lazy pulling and will be compatible with the estargz format.2"auto"�
�
create_parent_directories�Whether to automatically create parent directory entries in the tar file for all files.
If set to 'auto', uses the global default create_parent_directories setting.
When enabled, parent directories will be created automatically for all files in the layer.2"auto"�
�
include_runfiles�Whether to include runfiles for executable targets.
When True (default), executables in srcs will include their runfiles tree.
When False, only the executable file itself is included, without runfiles.2TrueS
Q
annotations<Annotations to add to the layer metadata as key-value pairs.
2{}�
�
annotations_file�File containing newline-delimited KEY=VALUE annotations for the layer.

The file should contain one annotation per line in KEY=VALUE format. Empty lines are ignored.
Annotations from this file are merged with annotations specified via the `annotations` attribute.

Example file content:
```
version=1.0.0
build.date=2024-01-15
source.url=https://github.com/...
```2None�
�
default_metadata�JSON-encoded default metadata to apply to all files in the layer.
Can include fields like mode, uid, gid, uname, gname, mtime, and pax_records.2""�
�
file_metadata�Per-file metadata overrides as a dict mapping file paths to JSON-encoded metadata.
The path should match the path in the image (the key in srcs attribute).
Metadata specified here overrides any defaults from default_metadata.
2{}�layer_from_tar�Creates a container image layer from an existing tar archive.

This rule converts tar files into container image layers, useful for incorporating
pre-built artifacts, third-party distributions, or legacy build outputs.

The rule can:
- Use tar files as-is or recompress them
- Optimize tar contents by deduplicating files
- Add annotations to the layer metadata

Example:

```python
load("@rules_img//img:layer.bzl", "layer_from_tar")

# Use an existing tar file as a layer
layer_from_tar(
    name = "third_party_layer",
    src = "@third_party_lib//:lib.tar.gz",
)

# Optimize and recompress
layer_from_tar(
    name = "optimized_layer",
    src = "//legacy:build_output.tar",
    optimize = True,  # Deduplicate contents
    compress = "zstd",  # Use zstd compression
)

# Add metadata annotations
layer_from_tar(
    name = "annotated_layer",
    src = "//vendor:dependencies.tar.gz",
    annotations = {
        "org.opencontainers.image.title": "Vendor Dependencies",
        "org.opencontainers.image.version": "1.2.3",
    },
)
```"�
�
layer_from_tar�Creates a container image layer from an existing tar archive.

This rule converts tar files into container image layers, useful for incorporating
pre-built artifacts, third-party distributions, or legacy build outputs.

The rule can:
- Use tar files as-is or recompress them
- Optimize tar contents by deduplicating files
- Add annotations to the layer metadata

Example:

```python
load("@rules_img//img:layer.bzl", "layer_from_tar")

# Use an existing tar file as a layer
layer_from_tar(
    name = "third_party_layer",
    src = "@third_party_lib//:lib.tar.gz",
)

# Optimize and recompress
layer_from_tar(
    name = "optimized_layer",
    src = "//legacy:build_output.tar",
    optimize = True,  # Deduplicate contents
    compress = "zstd",  # Use zstd compression
)

# Add metadata annotations
layer_from_tar(
    name = "annotated_layer",
    src = "//vendor:dependencies.tar.gz",
    annotations = {
        "org.opencontainers.image.title": "Vendor Dependencies",
        "org.opencontainers.image.version": "1.2.3",
    },
)
```*
nameA unique name for this target. b
srcWThe tar file to convert into a layer. Must be a valid tar file (optionally compressed). �
compresswCompression algorithm to use. If set to 'auto', it keeps the existing compression, unless the layer is being optimized.2"auto"�
optimize�If set, rewrites the tar file to deduplicate it's contents.
This is useful for reducing the size of the image, but will take extra time and space to store the optimized layer.2False�
estargz�Whether to use estargz format. If set to 'auto', uses the global default estargz setting.
When enabled, the layer will be optimized for lazy pulling and will be compatible with the estargz format.2"auto"Q
annotations<Annotations to add to the layer metadata as key-value pairs.
2{}"<
layer_from_tar*@rules_img//img/private:layer_from_tar.bzl*J
	LayerInfo=
	LayerInfo0@rules_img//img/private/providers:layer_info.bzl,
*
nameA unique name for this target. d
b
srcWThe tar file to convert into a layer. Must be a valid tar file (optionally compressed). �
�
compresswCompression algorithm to use. If set to 'auto', it keeps the existing compression, unless the layer is being optimized.2"auto"�
�
optimize�If set, rewrites the tar file to deduplicate it's contents.
This is useful for reducing the size of the image, but will take extra time and space to store the optimized layer.2False�
�
estargz�Whether to use estargz format. If set to 'auto', uses the global default estargz setting.
When enabled, the layer will be optimized for lazy pulling and will be compatible with the estargz format.2"auto"S
Q
annotations<Annotations to add to the layer metadata as key-value pairs.
2{}�file_metadata�Creates a JSON-encoded file metadata string for use with image_layer rules.

This function generates JSON metadata that can be used to customize file attributes
in container image layers, such as permissions, ownership, and timestamps.
*�

�
file_metadataK
mode;File permission mode (e.g., "0755", "0644"). String format.None(2
uid#User ID of the file owner. Integer.None(3
gid$Group ID of the file owner. Integer.None(5
uname$User name of the file owner. String.None(6
gname%Group name of the file owner. String.None(\
mtimeKModification time in RFC3339 format (e.g., "2023-01-01T00:00:00Z"). String.None(J
pax_records3Dict of extended attributes to set via PAX records.None(�Creates a JSON-encoded file metadata string for use with image_layer rules.

This function generates JSON metadata that can be used to customize file attributes
in container image layers, such as permissions, ownership, and timestamps.
"3
1JSON-encoded string containing the file metadata.2:
file_metadata)@rules_img//img/private:file_metadata.bzlM
K
mode;File permission mode (e.g., "0755", "0644"). String format.None(4
2
uid#User ID of the file owner. Integer.None(5
3
gid$Group ID of the file owner. Integer.None(7
5
uname$User name of the file owner. String.None(8
6
gname%Group name of the file owner. String.None(^
\
mtimeKModification time in RFC3339 format (e.g., "2023-01-01T00:00:00Z"). String.None(L
J
pax_records3Dict of extended attributes to set via PAX records.None(+Public API for container image layer rules.�Y

	rules_imgimgload.bzl�N
image_load�Loads container images into a local daemon (Docker or containerd).

This rule creates an executable target that imports OCI images into your local
container runtime. It supports both Docker and containerd, with intelligent
detection of the best loading method for optimal performance.

Key features:
- **Incremental loading**: Skips blobs that already exist in the daemon
- **Multi-platform support**: Can load entire image indexes or specific platforms
- **Direct containerd integration**: Bypasses Docker for faster imports when possible
- **Platform filtering**: Use `--platform` flag at runtime to select specific platforms

The rule produces an executable that can be run with `bazel run`.

Output groups:
- `tarball`: Docker save compatible tarball (only available for single-platform images)

Example:

```python
load("@rules_img//img:load.bzl", "image_load")

# Load a single-platform image with a single tag
image_load(
    name = "load_app",
    image = ":my_app",  # References an image_manifest
    tag = "my-app:latest",
)

# Load with multiple tags
image_load(
    name = "load_multi",
    image = ":my_app",
    tag_list = ["my-app:latest", "my-app:v1.0.0", "my-app:stable"],
)

# Load a multi-platform image
image_load(
    name = "load_multiarch",
    image = ":my_app_index",  # References an image_index
    tag = "my-app:latest",
    daemon = "containerd",  # Explicitly use containerd
)

# Load with dynamic tagging
image_load(
    name = "load_dynamic",
    image = ":my_app",
    tag = "my-app:{{.BUILD_USER}}",  # Template expansion
    build_settings = {
        "BUILD_USER": "//settings:username",
    },
)
```

Runtime usage:
```bash
# Load all platforms
bazel run //path/to:load_app

# Load specific platform only
bazel run //path/to:load_multiarch -- --platform linux/arm64

# Build Docker save tarball
bazel build //path/to:load_app --output_groups=tarball
```

Performance notes:
- When Docker uses containerd storage (Docker 23.0+), images are loaded directly
  into containerd for better performance if the containerd socket is accessible.
- For older Docker versions, falls back to `docker load` which requires building
  a tar file (slower and limited to single-platform images)
- The `--platform` flag filters which platforms are loaded from multi-platform images"�<
�'

image_load�Loads container images into a local daemon (Docker or containerd).

This rule creates an executable target that imports OCI images into your local
container runtime. It supports both Docker and containerd, with intelligent
detection of the best loading method for optimal performance.

Key features:
- **Incremental loading**: Skips blobs that already exist in the daemon
- **Multi-platform support**: Can load entire image indexes or specific platforms
- **Direct containerd integration**: Bypasses Docker for faster imports when possible
- **Platform filtering**: Use `--platform` flag at runtime to select specific platforms

The rule produces an executable that can be run with `bazel run`.

Output groups:
- `tarball`: Docker save compatible tarball (only available for single-platform images)

Example:

```python
load("@rules_img//img:load.bzl", "image_load")

# Load a single-platform image with a single tag
image_load(
    name = "load_app",
    image = ":my_app",  # References an image_manifest
    tag = "my-app:latest",
)

# Load with multiple tags
image_load(
    name = "load_multi",
    image = ":my_app",
    tag_list = ["my-app:latest", "my-app:v1.0.0", "my-app:stable"],
)

# Load a multi-platform image
image_load(
    name = "load_multiarch",
    image = ":my_app_index",  # References an image_index
    tag = "my-app:latest",
    daemon = "containerd",  # Explicitly use containerd
)

# Load with dynamic tagging
image_load(
    name = "load_dynamic",
    image = ":my_app",
    tag = "my-app:{{.BUILD_USER}}",  # Template expansion
    build_settings = {
        "BUILD_USER": "//settings:username",
    },
)
```

Runtime usage:
```bash
# Load all platforms
bazel run //path/to:load_app

# Load specific platform only
bazel run //path/to:load_multiarch -- --platform linux/arm64

# Build Docker save tarball
bazel build //path/to:load_app --output_groups=tarball
```

Performance notes:
- When Docker uses containerd storage (Docker 23.0+), images are loaded directly
  into containerd for better performance if the containerd socket is accessible.
- For older Docker versions, falls back to `docker load` which requires building
  a tar file (slower and limited to single-platform images)
- The `--platform` flag filters which platforms are loaded from multi-platform images*
nameA unique name for this target. O
imageBImage to load. Should provide ImageManifestInfo or ImageIndexInfo. �
daemon�Container daemon to use for loading the image.

Available options:
- **`auto`** (default): Uses the global default setting (usually `docker`)
- **`containerd`**: Loads directly into containerd namespace. Supports multi-platform images
  and incremental loading.
- **`docker`**: Loads via Docker daemon. When Docker uses containerd storage (23.0+),
  loads directly into containerd. Otherwise falls back to `docker load` command which
  is slower and limited to single-platform images.

The best performance is achieved with:
- Direct containerd access (daemon = "containerd")
- Docker 23.0+ with containerd storage enabled and accessible containerd socket2"auto"�
tag�Tag to apply when loading the image.

Optional - if omitted, the image is loaded without a tag.

Subject to [template expansion](/docs/templating.md).2""�
tag_list�List of tags to apply when loading the image.

Useful for applying multiple tags in a single load:

```python
tag_list = ["latest", "v1.0.0", "stable"]
```

Cannot be used together with `tag`. Can be combined with `tag_file` to merge tags from both sources.
Each tag is subject to [template expansion](/docs/templating.md).2[]�
tag_file�File containing newline-delimited tags to apply when loading the image.

The file should contain one tag per line. Empty lines are ignored. Tags from this file
are merged with tags specified via `tag` or `tag_list` attributes.

Example file content:
```
latest
v1.0.0
stable
```

Can be combined with `tag` or `tag_list` to merge tags from multiple sources.
Each tag is subject to [template expansion](/docs/templating.md).2None�
strategy�Strategy for handling image layers during load.

Available strategies:
- **`auto`** (default): Uses the global default load strategy
- **`eager`**: Downloads all layers during the build phase. Ensures all layers are
  available locally before running the load command.
- **`lazy`**: Downloads layers only when needed during the load operation. More
  efficient for large images where some layers might already exist in the daemon.2"auto"�
build_settings�Build settings to use for [template expansion](/docs/templating.md). Keys are setting names, values are labels to string_flag targets.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
stamp�Whether to use stamping for [template expansion](/docs/templating.md). If 'enabled', uses volatile-status.txt and version.txt if present. 'auto' uses the global default setting.2"auto"".

image_load @rules_img//img/private:load.bzl8,
*
nameA unique name for this target. Q
O
imageBImage to load. Should provide ImageManifestInfo or ImageIndexInfo. �
�
daemon�Container daemon to use for loading the image.

Available options:
- **`auto`** (default): Uses the global default setting (usually `docker`)
- **`containerd`**: Loads directly into containerd namespace. Supports multi-platform images
  and incremental loading.
- **`docker`**: Loads via Docker daemon. When Docker uses containerd storage (23.0+),
  loads directly into containerd. Otherwise falls back to `docker load` command which
  is slower and limited to single-platform images.

The best performance is achieved with:
- Direct containerd access (daemon = "containerd")
- Docker 23.0+ with containerd storage enabled and accessible containerd socket2"auto"�
�
tag�Tag to apply when loading the image.

Optional - if omitted, the image is loaded without a tag.

Subject to [template expansion](/docs/templating.md).2""�
�
tag_list�List of tags to apply when loading the image.

Useful for applying multiple tags in a single load:

```python
tag_list = ["latest", "v1.0.0", "stable"]
```

Cannot be used together with `tag`. Can be combined with `tag_file` to merge tags from both sources.
Each tag is subject to [template expansion](/docs/templating.md).2[]�
�
tag_file�File containing newline-delimited tags to apply when loading the image.

The file should contain one tag per line. Empty lines are ignored. Tags from this file
are merged with tags specified via `tag` or `tag_list` attributes.

Example file content:
```
latest
v1.0.0
stable
```

Can be combined with `tag` or `tag_list` to merge tags from multiple sources.
Each tag is subject to [template expansion](/docs/templating.md).2None�
�
strategy�Strategy for handling image layers during load.

Available strategies:
- **`auto`** (default): Uses the global default load strategy
- **`eager`**: Downloads all layers during the build phase. Ensures all layers are
  available locally before running the load command.
- **`lazy`**: Downloads layers only when needed during the load operation. More
  efficient for large images where some layers might already exist in the daemon.2"auto"�
�
build_settings�Build settings to use for [template expansion](/docs/templating.md). Keys are setting names, values are labels to string_flag targets.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
�
stamp�Whether to use stamping for [template expansion](/docs/templating.md). If 'enabled', uses volatile-status.txt and version.txt if present. 'auto' uses the global default setting.2"auto"�
Public API for loading container images into a daemon.

The `image_load` rule creates an executable target that loads container images into a local daemon (containerd or Docker).

## Example

```python
load("@rules_img//img:image.bzl", "image_manifest")
load("@rules_img//img:load.bzl", "image_load")
load("@rules_img//img:layer.bzl", "image_layer")

# Create a simple layer
image_layer(
    name = "app_layer",
    srcs = {
        "/app/hello.txt": "hello.txt",
    },
)

# Build an image
image_manifest(
    name = "my_image",
    base = "@alpine",
    layers = [":app_layer"],
)

# Create a load target with a single tag
image_load(
    name = "load",
    image = ":my_image",
    tag = "my-app:latest",
)

# Load with multiple tags
image_load(
    name = "load_multi",
    image = ":my_image",
    tag_list = ["my-app:latest", "my-app:v1.0.0"],
)
```

Then run:
```bash
# Load the image into your local daemon
bazel run //:load
```

## Platform Selection

When running the load target, you can use the `--platform` flag to filter which platforms to load from multi-platform images:

```bash
# Load all platforms (default)
bazel run //path/to:load_target

# Load only linux/amd64
bazel run //path/to:load_target -- --platform linux/amd64
```

**Note**: Docker daemon only supports loading a single platform at a time. If multiple platforms are specified with Docker, an error will be returned.�&
"
	rules_imgimgmulti_deploy.bzl�%multi_deploy�Merges multiple deploy operations into a single unified deployment command.

This rule takes multiple operations (typically from image_push or image_load rules)
that provide DeployInfo and merges them into a single command that can deploy all
operations in parallel. This is useful for scenarios where you need to push and/or
load multiple related images as a coordinated deployment.

The rule produces an executable that can be run with `bazel run`.

Example:

```python
load("@rules_img//img:push.bzl", "image_push")
load("@rules_img//img:load.bzl", "image_load")
load("@rules_img//img:multi_deploy.bzl", "multi_deploy")

# Individual operations
image_push(
    name = "push_frontend",
    image = ":frontend",
    registry = "gcr.io",
    repository = "my-project/frontend",
    tag = "latest",
)

image_push(
    name = "push_backend",
    image = ":backend",
    registry = "gcr.io",
    repository = "my-project/backend",
    tag = "latest",
)

image_load(
    name = "load_database",
    image = ":database",
    tag = "my-database:latest",
)

# Unified deployment
multi_deploy(
    name = "deploy_all",
    operations = [
        ":push_frontend",
        ":push_backend",
        ":load_database",
    ],
    push_strategy = "lazy",
    load_strategy = "eager",
)
```

Runtime usage:
```bash
# Deploy all operations together
bazel run //path/to:deploy_all
```

The deploy-merge subcommand will execute all push and load operations in sequence,
allowing for coordinated deployment of related container images."�
�
multi_deploy�Merges multiple deploy operations into a single unified deployment command.

This rule takes multiple operations (typically from image_push or image_load rules)
that provide DeployInfo and merges them into a single command that can deploy all
operations in parallel. This is useful for scenarios where you need to push and/or
load multiple related images as a coordinated deployment.

The rule produces an executable that can be run with `bazel run`.

Example:

```python
load("@rules_img//img:push.bzl", "image_push")
load("@rules_img//img:load.bzl", "image_load")
load("@rules_img//img:multi_deploy.bzl", "multi_deploy")

# Individual operations
image_push(
    name = "push_frontend",
    image = ":frontend",
    registry = "gcr.io",
    repository = "my-project/frontend",
    tag = "latest",
)

image_push(
    name = "push_backend",
    image = ":backend",
    registry = "gcr.io",
    repository = "my-project/backend",
    tag = "latest",
)

image_load(
    name = "load_database",
    image = ":database",
    tag = "my-database:latest",
)

# Unified deployment
multi_deploy(
    name = "deploy_all",
    operations = [
        ":push_frontend",
        ":push_backend",
        ":load_database",
    ],
    push_strategy = "lazy",
    load_strategy = "eager",
)
```

Runtime usage:
```bash
# Deploy all operations together
bazel run //path/to:deploy_all
```

The deploy-merge subcommand will execute all push and load operations in sequence,
allowing for coordinated deployment of related container images.*
nameA unique name for this target. �

operations�List of operations to deploy together.

Each operation must provide DeployInfo (typically from image_push or image_load rules).
All operations will be merged and executed in the order specified. *M

DeployInfo?

DeployInfo1@rules_img//img/private/providers:deploy_info.bzl�
push_strategy�Push strategy to use for all push operations in the deployment.

See [push strategies documentation](/docs/push-strategies.md) for detailed information.2"auto"�
load_strategy�Load strategy to use for all load operations in the deployment.

Available strategies:
- **`auto`** (default): Uses the global default load strategy
- **`eager`**: Downloads all layers during the build phase
- **`lazy`**: Downloads layers only when needed during the load operation2"auto""8
multi_deploy(@rules_img//img/private:multi_deploy.bzl8,
*
nameA unique name for this target. �
�

operations�List of operations to deploy together.

Each operation must provide DeployInfo (typically from image_push or image_load rules).
All operations will be merged and executed in the order specified. *M

DeployInfo?

DeployInfo1@rules_img//img/private/providers:deploy_info.bzl�
�
push_strategy�Push strategy to use for all push operations in the deployment.

See [push strategies documentation](/docs/push-strategies.md) for detailed information.2"auto"�
�
load_strategy�Load strategy to use for all load operations in the deployment.

Available strategies:
- **`auto`** (default): Uses the global default load strategy
- **`eager`**: Downloads all layers during the build phase
- **`lazy`**: Downloads layers only when needed during the load operation2"auto"1Public API for container image multi deploy rule.�;

	rules_imgimgpull.bzl�:pull�Pulls a container image from a registry using shallow pulling.

This repository rule implements shallow pulling - it only downloads the image manifest
and config, not the actual layer blobs. The layers are downloaded on-demand during
push operations or when explicitly needed. This significantly reduces bandwidth usage
and speeds up builds, especially for large base images.

Example usage in MODULE.bazel:
```starlark
pull = use_repo_rule("@rules_img//img:pull.bzl", "pull")

pull(
    name = "ubuntu",
    digest = "sha256:1e622c5f073b4f6bfad6632f2616c7f59ef256e96fe78bf6a595d1dc4376ac02",
    registry = "index.docker.io",
    repository = "library/ubuntu",
    tag = "24.04",
)
```

The `digest` parameter is recommended for reproducible builds. If omitted, the rule
will resolve the tag to a digest at fetch time and print a warning.R�4
�
pull�Pulls a container image from a registry using shallow pulling.

This repository rule implements shallow pulling - it only downloads the image manifest
and config, not the actual layer blobs. The layers are downloaded on-demand during
push operations or when explicitly needed. This significantly reduces bandwidth usage
and speeds up builds, especially for large base images.

Example usage in MODULE.bazel:
```starlark
pull = use_repo_rule("@rules_img//img:pull.bzl", "pull")

pull(
    name = "ubuntu",
    digest = "sha256:1e622c5f073b4f6bfad6632f2616c7f59ef256e96fe78bf6a595d1dc4376ac02",
    registry = "index.docker.io",
    repository = "library/ubuntu",
    tag = "24.04",
)
```

The `digest` parameter is recommended for reproducible builds. If omitted, the rule
will resolve the tag to a digest at fetch time and print a warning..
name"A unique name for this repository. �
repo_mapping�In `WORKSPACE` context only: a dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.

For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).

This attribute is _not_ supported in `MODULE.bazel` context (when invoking a repository rule inside a module extension's implementation function).
�
registry�Primary registry to pull from (e.g., "index.docker.io", "gcr.io").

If not specified, defaults to Docker Hub. Can be overridden by entries in registries list.2""�

registries�List of mirror registries to try in order.

These registries will be tried in order before the primary registry. Useful for
corporate environments with registry mirrors or air-gapped setups.2[]�

repository�The image repository within the registry (e.g., "library/ubuntu", "my-project/my-image").

For Docker Hub, official images use "library/" prefix (e.g., "library/ubuntu"). �
tag�The image tag to pull (e.g., "latest", "24.04", "v1.2.3").

While required, it's recommended to also specify a digest for reproducible builds.2""�
digest�The image digest for reproducible pulls (e.g., "sha256:abc123...").

When specified, the image is pulled by digest instead of tag, ensuring reproducible
builds. The digest must be a full SHA256 digest starting with "sha256:".2""�
layer_handling�Strategy for handling image layers.

This attribute controls when and how layer data is fetched from the registry.

**Available strategies:**

* **`shallow`** (default): Layer data is fetched only if needed during push operations,
  but is not available during the build. This is the most efficient option for images
  that are only used as base images for pushing.

* **`eager`**: Layer data is fetched in the repository rule and is always available.
  This ensures layers are accessible in build actions but is inefficient as all layers
  are downloaded regardless of whether they're needed. Use this for base images that
  need to be read or inspected during the build.

* **`lazy`**: Layer data is downloaded in a build action when requested. This provides
  access to layers during builds while avoiding unnecessary downloads, but requires
  network access during the build phase. **EXPERIMENTAL:** Use at your own risk.2	"shallow"�

downloader�The tool to use for downloading manifests and blobs.

**Available options:**

* **`img_tool`** (default): Uses the `img` tool for all downloads.

* **`bazel`**: Uses Bazel's native HTTP capabilities for downloading manifests and blobs.2
"img_tool"*9
pull1@rules_img//img/private/repository_rules:pull.bzl0
.
name"A unique name for this repository. �
�
repo_mapping�In `WORKSPACE` context only: a dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.

For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).

This attribute is _not_ supported in `MODULE.bazel` context (when invoking a repository rule inside a module extension's implementation function).
�
�
registry�Primary registry to pull from (e.g., "index.docker.io", "gcr.io").

If not specified, defaults to Docker Hub. Can be overridden by entries in registries list.2""�
�

registries�List of mirror registries to try in order.

These registries will be tried in order before the primary registry. Useful for
corporate environments with registry mirrors or air-gapped setups.2[]�
�

repository�The image repository within the registry (e.g., "library/ubuntu", "my-project/my-image").

For Docker Hub, official images use "library/" prefix (e.g., "library/ubuntu"). �
�
tag�The image tag to pull (e.g., "latest", "24.04", "v1.2.3").

While required, it's recommended to also specify a digest for reproducible builds.2""�
�
digest�The image digest for reproducible pulls (e.g., "sha256:abc123...").

When specified, the image is pulled by digest instead of tag, ensuring reproducible
builds. The digest must be a full SHA256 digest starting with "sha256:".2""�
�
layer_handling�Strategy for handling image layers.

This attribute controls when and how layer data is fetched from the registry.

**Available strategies:**

* **`shallow`** (default): Layer data is fetched only if needed during push operations,
  but is not available during the build. This is the most efficient option for images
  that are only used as base images for pushing.

* **`eager`**: Layer data is fetched in the repository rule and is always available.
  This ensures layers are accessible in build actions but is inefficient as all layers
  are downloaded regardless of whether they're needed. Use this for base images that
  need to be read or inspected during the build.

* **`lazy`**: Layer data is downloaded in a build action when requested. This provides
  access to layers during builds while avoiding unnecessary downloads, but requires
  network access during the build phase. **EXPERIMENTAL:** Use at your own risk.2	"shallow"�
�

downloader�The tool to use for downloading manifests and blobs.

**Available options:**

* **`img_tool`** (default): Uses the `img` tool for all downloads.

* **`bazel`**: Uses Bazel's native HTTP capabilities for downloading manifests and blobs.2
"img_tool"-Public API for pulling base container images.�S

	rules_imgimgpush.bzl�S
image_push�Pushes container images to a registry.

This rule creates an executable target that uploads OCI images to container registries.
It supports multiple push strategies optimized for different use cases, from simple
uploads to advanced content-addressable storage integration.

Key features:
- **Multiple push strategies**: Choose between eager, lazy, CAS-based, or BES-integrated pushing
- **Template expansion**: Dynamic registry, repository, and tag values using build settings
- **Stamping support**: Include build information in image tags
- **Incremental uploads**: Skip blobs that already exist in the registry

The rule produces an executable that can be run with `bazel run`.

Example:

```python
load("@rules_img//img:push.bzl", "image_push")

# Simple push to Docker Hub
image_push(
    name = "push_app",
    image = ":my_app",
    registry = "index.docker.io",
    repository = "myorg/myapp",
    tag = "latest",
)

# Push multi-platform image with multiple tags
image_push(
    name = "push_multiarch",
    image = ":my_app_index",  # References an image_index
    registry = "gcr.io",
    repository = "my-project/my-app",
    tag_list = ["latest", "v1.0.0"],
)

# Dynamic push with build settings
image_push(
    name = "push_dynamic",
    image = ":my_app",
    registry = "{{.REGISTRY}}",
    repository = "{{.PROJECT}}/my-app",
    tag = "{{.VERSION}}",
    build_settings = {
        "REGISTRY": "//settings:registry",
        "PROJECT": "//settings:project",
        "VERSION": "//settings:version",
    },
)

# Push with stamping for unique tags
image_push(
    name = "push_stamped",
    image = ":my_app",
    registry = "index.docker.io",
    repository = "myorg/myapp",
    tag = "latest-{{.BUILD_TIMESTAMP}}",
    stamp = "enabled",
)

# Digest-only push (no tag)
image_push(
    name = "push_by_digest",
    image = ":my_app",
    registry = "gcr.io",
    repository = "my-project/my-app",
    # No tag specified - will push by digest only
)
```

Push strategies:
- **`eager`**: Materializes all layers next to push binary. Simple, correct, but may be inefficient.
- **`lazy`**: Layers are not stored locally. Missing layers are streamed from Bazel's remote cache.
- **`cas_registry`**: Uses content-addressable storage for extreme efficiency. Requires
  CAS-enabled infrastructure.
- **`bes`**: Image is pushed as side-effect of Build Event Stream upload. No "bazel run" command needed.
  Requires Build Event Service integration.

See [push strategies documentation](/docs/push-strategies.md) for detailed comparisons.

Runtime usage:
```bash
# Push to registry
bazel run //path/to:push_app

# The push command will output the image digest
```"�>
�)

image_push�Pushes container images to a registry.

This rule creates an executable target that uploads OCI images to container registries.
It supports multiple push strategies optimized for different use cases, from simple
uploads to advanced content-addressable storage integration.

Key features:
- **Multiple push strategies**: Choose between eager, lazy, CAS-based, or BES-integrated pushing
- **Template expansion**: Dynamic registry, repository, and tag values using build settings
- **Stamping support**: Include build information in image tags
- **Incremental uploads**: Skip blobs that already exist in the registry

The rule produces an executable that can be run with `bazel run`.

Example:

```python
load("@rules_img//img:push.bzl", "image_push")

# Simple push to Docker Hub
image_push(
    name = "push_app",
    image = ":my_app",
    registry = "index.docker.io",
    repository = "myorg/myapp",
    tag = "latest",
)

# Push multi-platform image with multiple tags
image_push(
    name = "push_multiarch",
    image = ":my_app_index",  # References an image_index
    registry = "gcr.io",
    repository = "my-project/my-app",
    tag_list = ["latest", "v1.0.0"],
)

# Dynamic push with build settings
image_push(
    name = "push_dynamic",
    image = ":my_app",
    registry = "{{.REGISTRY}}",
    repository = "{{.PROJECT}}/my-app",
    tag = "{{.VERSION}}",
    build_settings = {
        "REGISTRY": "//settings:registry",
        "PROJECT": "//settings:project",
        "VERSION": "//settings:version",
    },
)

# Push with stamping for unique tags
image_push(
    name = "push_stamped",
    image = ":my_app",
    registry = "index.docker.io",
    repository = "myorg/myapp",
    tag = "latest-{{.BUILD_TIMESTAMP}}",
    stamp = "enabled",
)

# Digest-only push (no tag)
image_push(
    name = "push_by_digest",
    image = ":my_app",
    registry = "gcr.io",
    repository = "my-project/my-app",
    # No tag specified - will push by digest only
)
```

Push strategies:
- **`eager`**: Materializes all layers next to push binary. Simple, correct, but may be inefficient.
- **`lazy`**: Layers are not stored locally. Missing layers are streamed from Bazel's remote cache.
- **`cas_registry`**: Uses content-addressable storage for extreme efficiency. Requires
  CAS-enabled infrastructure.
- **`bes`**: Image is pushed as side-effect of Build Event Stream upload. No "bazel run" command needed.
  Requires Build Event Service integration.

See [push strategies documentation](/docs/push-strategies.md) for detailed comparisons.

Runtime usage:
```bash
# Push to registry
bazel run //path/to:push_app

# The push command will output the image digest
```*
nameA unique name for this target. �
registry�Registry URL to push the image to.

Common registries:
- Docker Hub: `index.docker.io`
- Google Container Registry: `gcr.io` or `us.gcr.io`
- GitHub Container Registry: `ghcr.io`
- Amazon ECR: `123456789.dkr.ecr.us-east-1.amazonaws.com`

Subject to [template expansion](/docs/templating.md).2""o

repository[Repository path within the registry.

Subject to [template expansion](/docs/templating.md).2""�
tag�Tag to apply to the pushed image.

Optional - if omitted, the image is pushed by digest only.

Subject to [template expansion](/docs/templating.md).2""�
tag_list�List of tags to apply to the pushed image.

Useful for applying multiple tags in a single push:

```python
tag_list = ["latest", "v1.0.0", "stable"]
```

Cannot be used together with `tag`. Can be combined with `tag_file` to merge tags from both sources.
Each tag is subject to [template expansion](/docs/templating.md).2[]�
tag_file�File containing newline-delimited tags to apply to the pushed image.

The file should contain one tag per line. Empty lines are ignored. Tags from this file
are merged with tags specified via `tag` or `tag_list` attributes.

Example file content:
```
latest
v1.0.0
stable
```

Can be combined with `tag` or `tag_list` to merge tags from multiple sources.
Each tag is subject to [template expansion](/docs/templating.md).2NoneO
imageBImage to push. Should provide ImageManifestInfo or ImageIndexInfo. �
strategynPush strategy to use.

See [push strategies documentation](/docs/push-strategies.md) for detailed information.2"auto"�
build_settings�Build settings for template expansion.

Maps template variable names to string_flag targets. These values can be used in
registry, repository, and tag attributes using `{{.VARIABLE_NAME}}` syntax (Go template).

Example:
```python
build_settings = {
    "REGISTRY": "//settings:docker_registry",
    "VERSION": "//settings:app_version",
}
```

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
stamp�Enable build stamping for template expansion.

Controls whether to include volatile build information:
- **`auto`** (default): Uses the global stamping configuration
- **`enabled`**: Always include stamp information (BUILD_TIMESTAMP, BUILD_USER, etc.) if Bazel's "--stamp" flag is set
- **`disabled`**: Never include stamp information

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"".

image_push @rules_img//img/private:push.bzl8,
*
nameA unique name for this target. �
�
registry�Registry URL to push the image to.

Common registries:
- Docker Hub: `index.docker.io`
- Google Container Registry: `gcr.io` or `us.gcr.io`
- GitHub Container Registry: `ghcr.io`
- Amazon ECR: `123456789.dkr.ecr.us-east-1.amazonaws.com`

Subject to [template expansion](/docs/templating.md).2""q
o

repository[Repository path within the registry.

Subject to [template expansion](/docs/templating.md).2""�
�
tag�Tag to apply to the pushed image.

Optional - if omitted, the image is pushed by digest only.

Subject to [template expansion](/docs/templating.md).2""�
�
tag_list�List of tags to apply to the pushed image.

Useful for applying multiple tags in a single push:

```python
tag_list = ["latest", "v1.0.0", "stable"]
```

Cannot be used together with `tag`. Can be combined with `tag_file` to merge tags from both sources.
Each tag is subject to [template expansion](/docs/templating.md).2[]�
�
tag_file�File containing newline-delimited tags to apply to the pushed image.

The file should contain one tag per line. Empty lines are ignored. Tags from this file
are merged with tags specified via `tag` or `tag_list` attributes.

Example file content:
```
latest
v1.0.0
stable
```

Can be combined with `tag` or `tag_list` to merge tags from multiple sources.
Each tag is subject to [template expansion](/docs/templating.md).2NoneQ
O
imageBImage to push. Should provide ImageManifestInfo or ImageIndexInfo. �
�
strategynPush strategy to use.

See [push strategies documentation](/docs/push-strategies.md) for detailed information.2"auto"�
�
build_settings�Build settings for template expansion.

Maps template variable names to string_flag targets. These values can be used in
registry, repository, and tag attributes using `{{.VARIABLE_NAME}}` syntax (Go template).

Example:
```python
build_settings = {
    "REGISTRY": "//settings:docker_registry",
    "VERSION": "//settings:app_version",
}
```

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
�
stamp�Enable build stamping for template expansion.

Controls whether to include volatile build information:
- **`auto`** (default): Uses the global stamping configuration
- **`enabled`**: Always include stamp information (BUILD_TIMESTAMP, BUILD_USER, etc.) if Bazel's "--stamp" flag is set
- **`disabled`**: Never include stamp information

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"*Public API for container image push rules. 