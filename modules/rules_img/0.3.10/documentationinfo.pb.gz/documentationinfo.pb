�

	rules_imgimgconvert.bzl�image_manifest_from_oci_layout"�
�
image_manifest_from_oci_layout*
nameA unique name for this target. C
src8The directory containing the OCI layout to convert from. �
architecture/The target architecture for the image manifest. J"386"J"amd64"J"arm"J"arm64"J"mips64"J	"ppc64le"J	"riscv64"�
os3The target operating system for the image manifest. J	"android"J"darwin"J	"freebsd"J"ios"J"linux"J"netbsd"J	"openbsd"J"wasip1"J	"windows"o
layersaA list of layer media types. Use the well-defined media types in @rules_img//img:media_types.bzl. S
variantBThe platform variant (e.g., 'v3' for amd64/v3, 'v8' for arm64/v8).2"""a
image_manifest_from_oci_layout?@rules_img//img/private/conversion:manifest_from_oci_layout.bzl*]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl,
*
nameA unique name for this target. E
C
src8The directory containing the OCI layout to convert from. �
�
architecture/The target architecture for the image manifest. J"386"J"amd64"J"arm"J"arm64"J"mips64"J	"ppc64le"J	"riscv64"�
�
os3The target operating system for the image manifest. J	"android"J"darwin"J	"freebsd"J"ios"J"linux"J"netbsd"J	"openbsd"J"wasip1"J	"windows"q
o
layersaA list of layer media types. Use the well-defined media types in @rules_img//img:media_types.bzl. U
S
variantBThe platform variant (e.g., 'v3' for amd64/v3, 'v8' for arm64/v8).2""�image_index_from_oci_layout"�
�
image_index_from_oci_layout*
nameA unique name for this target. C
src8The directory containing the OCI layout to convert from. �
layers�A list of layer media types. This applies to all manifests. Use the well-defined media types in @rules_img//img:media_types.bzl. �
	manifests�An ordered list of platform specifications in 'os/architecture' or 'os/architecture/variant' format.
Example: ["linux/arm64", "linux/amd64/v3"] "[
image_index_from_oci_layout<@rules_img//img/private/conversion:index_from_oci_layout.bzl*T
ImageIndexInfoB
ImageIndexInfo0@rules_img//img/private/providers:index_info.bzl,
*
nameA unique name for this target. E
C
src8The directory containing the OCI layout to convert from. �
�
layers�A list of layer media types. This applies to all manifests. Use the well-defined media types in @rules_img//img:media_types.bzl. �
�
	manifests�An ordered list of platform specifications in 'os/architecture' or 'os/architecture/variant' format.
Example: ["linux/arm64", "linux/amd64/v3"] �Rules to convert OCI layout directories to container images.

Use `image_manifest_from_oci_layout` to convert an OCI layout directory
to a single-platform container image manifest, and
`image_index_from_oci_layout` to convert an OCI layout directory
to a multi-platform container image index.�r
 
	rules_imgimgextensions.bzl�qimages�Module extension for pulling container images in Bzlmod projects.

This extension enables declarative pulling of container images using Bazel's module
system. Images are pulled once and shared across all modules, with automatic deduplication
of blobs for efficient storage.

Example usage in MODULE.bazel:

```starlark
images = use_extension("@rules_img//img:extensions.bzl", "images")

# Pull with friendly name
images.pull(
    name = "ubuntu",
    digest = "sha256:1e622c5f073b4f6bfad6632f2616c7f59ef256e96fe78bf6a595d1dc4376ac02",
    registry = "index.docker.io",
    repository = "library/ubuntu",
    tag = "24.04",
)

# Pull without name - use repository as identifier
images.pull(
    digest = "sha256:029d4461bd98f124e531380505ceea2072418fdf28752aa73b7b273ba3048903",
    registry = "gcr.io",
    repository = "distroless/base",
)

use_repo(images, "rules_img_images.bzl")
```

Access pulled images in BUILD files using the generated helper. The `name` attribute
is optional - if not specified, use the `repository` value to reference the image:

```starlark
load("@rules_img_images.bzl", "image")

image_manifest(
    name = "my_app",
    base = image("ubuntu"),  # References the friendly name
    ...
)

image_manifest(
    name = "my_other_app",
    base = image("distroless/base"),  # References the repository
    ...
)
```

The extension creates deduplicated blob repositories, so pulling multiple images
from the same base only downloads shared layers once. The `digest` parameter is
required for reproducibility.J�e
�*
images�Module extension for pulling container images in Bzlmod projects.

This extension enables declarative pulling of container images using Bazel's module
system. Images are pulled once and shared across all modules, with automatic deduplication
of blobs for efficient storage.

Example usage in MODULE.bazel:

```starlark
images = use_extension("@rules_img//img:extensions.bzl", "images")

# Pull with friendly name
images.pull(
    name = "ubuntu",
    digest = "sha256:1e622c5f073b4f6bfad6632f2616c7f59ef256e96fe78bf6a595d1dc4376ac02",
    registry = "index.docker.io",
    repository = "library/ubuntu",
    tag = "24.04",
)

# Pull without name - use repository as identifier
images.pull(
    digest = "sha256:029d4461bd98f124e531380505ceea2072418fdf28752aa73b7b273ba3048903",
    registry = "gcr.io",
    repository = "distroless/base",
)

use_repo(images, "rules_img_images.bzl")
```

Access pulled images in BUILD files using the generated helper. The `name` attribute
is optional - if not specified, use the `repository` value to reference the image:

```starlark
load("@rules_img_images.bzl", "image")

image_manifest(
    name = "my_app",
    base = image("ubuntu"),  # References the friendly name
    ...
)

image_manifest(
    name = "my_other_app",
    base = image("distroless/base"),  # References the repository
    ...
)
```

The extension creates deduplicated blob repositories, so pulling multiple images
from the same base only downloads shared layers once. The `digest` parameter is
required for reproducibility.�
pull�
name�Friendly name for the image (e.g., 'ubuntu', 'distroless-base').

This name is used to reference the image in your code via the `image()` helper function.
If not specified, defaults to the repository name.2""�
registry�Primary registry to pull from (e.g., "index.docker.io", "gcr.io").

If not specified, defaults to Docker Hub. Can be overridden by entries in registries list.2""�

registries�List of mirror registries to try in order.

These registries will be tried in order before the primary registry. Useful for
corporate environments with registry mirrors or air-gapped setups.2[]�

repository�The image repository within the registry (e.g., "library/ubuntu", "my-project/my-image").

For Docker Hub, official images use "library/" prefix (e.g., "library/ubuntu"). �
tag�The image tag to pull (e.g., "latest", "24.04", "v1.2.3").

While optional, it's recommended to also specify a digest for reproducible builds.2""�
digest�The image digest for reproducible pulls (e.g., "sha256:abc123...").

When specified, the image is pulled by digest instead of tag, ensuring reproducible builds.
The digest must be a full SHA256 digest starting with "sha256:".2""�
layer_handling�Strategy for handling image layers.

This attribute controls when and how layer data is fetched from the registry.

**Available strategies:**

* **`shallow`** (default): Layer data is fetched only if needed during push operations,
  but is not available during the build. This is the most efficient option for images
  that are only used as base images for pushing.

* **`eager`**: Layer data is fetched in the repository rule and is always available.
  This ensures layers are accessible in build actions but is inefficient as all layers
  are downloaded regardless of whether they're needed. Use this for base images that
  need to be read or inspected during the build.

* **`lazy`**: Layer data is downloaded in a build action when requested. This provides
  access to layers during builds while avoiding unnecessary downloads, but requires
  network access during the build phase. **EXPERIMENTAL:** Use at your own risk.2	"shallow"J	"shallow"J"eager"J"lazy"�
settings�

downloader�The tool to use for downloading manifests and blobs if the current module is the root module.

**Available options:**

* **`img_tool`** (default): Uses the `img` tool for all downloads.

* **`bazel`**: Uses Bazel's native HTTP capabilities for downloading manifests and blobs.2
"img_tool"J
"img_tool"J"bazel"�
hub_repo�Controls visibility of the hub repository @rules_img_images.bzl for image access via the images macro.

**Available options:**

* **`auto`** (default): The hub repository is made visible if named repositories cannot be mapped in the current Bazel version.
                        This means you either get @rules_img_images.bzl or one repository per image.

* **`enabled`**: Always create and expose the hub repository @rules_img_images.bzl for image access via the images macro.

* **`disabled`**: Do not create the hub repository.2"auto"J"auto"J	"enabled"J
"disabled"�
image_repos�Controls visibility of individual image repositories for direct access. Repos internally use the naming scheme img_<digest> and are mapped via friendly names (i.e. "ubuntu") if possible.

**Available options:**

* **`auto`** (default): Individual image repositories are made visible if named repositories can be mapped in the current Bazel version.
                        This means you either get one repository per image or @rules_img_images.bzl.

* **`enabled`**: Always expose individual image repositories for direct access.

* **`disabled`**: Do not expose individual image repositories.2"auto"J"auto"J	"enabled"J
"disabled""/-@rules_img//img/private/extensions:images.bzl�"
�
pull�
name�Friendly name for the image (e.g., 'ubuntu', 'distroless-base').

This name is used to reference the image in your code via the `image()` helper function.
If not specified, defaults to the repository name.2""�
registry�Primary registry to pull from (e.g., "index.docker.io", "gcr.io").

If not specified, defaults to Docker Hub. Can be overridden by entries in registries list.2""�

registries�List of mirror registries to try in order.

These registries will be tried in order before the primary registry. Useful for
corporate environments with registry mirrors or air-gapped setups.2[]�

repository�The image repository within the registry (e.g., "library/ubuntu", "my-project/my-image").

For Docker Hub, official images use "library/" prefix (e.g., "library/ubuntu"). �
tag�The image tag to pull (e.g., "latest", "24.04", "v1.2.3").

While optional, it's recommended to also specify a digest for reproducible builds.2""�
digest�The image digest for reproducible pulls (e.g., "sha256:abc123...").

When specified, the image is pulled by digest instead of tag, ensuring reproducible builds.
The digest must be a full SHA256 digest starting with "sha256:".2""�
layer_handling�Strategy for handling image layers.

This attribute controls when and how layer data is fetched from the registry.

**Available strategies:**

* **`shallow`** (default): Layer data is fetched only if needed during push operations,
  but is not available during the build. This is the most efficient option for images
  that are only used as base images for pushing.

* **`eager`**: Layer data is fetched in the repository rule and is always available.
  This ensures layers are accessible in build actions but is inefficient as all layers
  are downloaded regardless of whether they're needed. Use this for base images that
  need to be read or inspected during the build.

* **`lazy`**: Layer data is downloaded in a build action when requested. This provides
  access to layers during builds while avoiding unnecessary downloads, but requires
  network access during the build phase. **EXPERIMENTAL:** Use at your own risk.2	"shallow"J	"shallow"J"eager"J"lazy"�
�
name�Friendly name for the image (e.g., 'ubuntu', 'distroless-base').

This name is used to reference the image in your code via the `image()` helper function.
If not specified, defaults to the repository name.2""�
�
registry�Primary registry to pull from (e.g., "index.docker.io", "gcr.io").

If not specified, defaults to Docker Hub. Can be overridden by entries in registries list.2""�
�

registries�List of mirror registries to try in order.

These registries will be tried in order before the primary registry. Useful for
corporate environments with registry mirrors or air-gapped setups.2[]�
�

repository�The image repository within the registry (e.g., "library/ubuntu", "my-project/my-image").

For Docker Hub, official images use "library/" prefix (e.g., "library/ubuntu"). �
�
tag�The image tag to pull (e.g., "latest", "24.04", "v1.2.3").

While optional, it's recommended to also specify a digest for reproducible builds.2""�
�
digest�The image digest for reproducible pulls (e.g., "sha256:abc123...").

When specified, the image is pulled by digest instead of tag, ensuring reproducible builds.
The digest must be a full SHA256 digest starting with "sha256:".2""�
�
layer_handling�Strategy for handling image layers.

This attribute controls when and how layer data is fetched from the registry.

**Available strategies:**

* **`shallow`** (default): Layer data is fetched only if needed during push operations,
  but is not available during the build. This is the most efficient option for images
  that are only used as base images for pushing.

* **`eager`**: Layer data is fetched in the repository rule and is always available.
  This ensures layers are accessible in build actions but is inefficient as all layers
  are downloaded regardless of whether they're needed. Use this for base images that
  need to be read or inspected during the build.

* **`lazy`**: Layer data is downloaded in a build action when requested. This provides
  access to layers during builds while avoiding unnecessary downloads, but requires
  network access during the build phase. **EXPERIMENTAL:** Use at your own risk.2	"shallow"J	"shallow"J"eager"J"lazy"�
�
settings�

downloader�The tool to use for downloading manifests and blobs if the current module is the root module.

**Available options:**

* **`img_tool`** (default): Uses the `img` tool for all downloads.

* **`bazel`**: Uses Bazel's native HTTP capabilities for downloading manifests and blobs.2
"img_tool"J
"img_tool"J"bazel"�
hub_repo�Controls visibility of the hub repository @rules_img_images.bzl for image access via the images macro.

**Available options:**

* **`auto`** (default): The hub repository is made visible if named repositories cannot be mapped in the current Bazel version.
                        This means you either get @rules_img_images.bzl or one repository per image.

* **`enabled`**: Always create and expose the hub repository @rules_img_images.bzl for image access via the images macro.

* **`disabled`**: Do not create the hub repository.2"auto"J"auto"J	"enabled"J
"disabled"�
image_repos�Controls visibility of individual image repositories for direct access. Repos internally use the naming scheme img_<digest> and are mapped via friendly names (i.e. "ubuntu") if possible.

**Available options:**

* **`auto`** (default): Individual image repositories are made visible if named repositories can be mapped in the current Bazel version.
                        This means you either get one repository per image or @rules_img_images.bzl.

* **`enabled`**: Always expose individual image repositories for direct access.

* **`disabled`**: Do not expose individual image repositories.2"auto"J"auto"J	"enabled"J
"disabled"�
�

downloader�The tool to use for downloading manifests and blobs if the current module is the root module.

**Available options:**

* **`img_tool`** (default): Uses the `img` tool for all downloads.

* **`bazel`**: Uses Bazel's native HTTP capabilities for downloading manifests and blobs.2
"img_tool"J
"img_tool"J"bazel"�
�
hub_repo�Controls visibility of the hub repository @rules_img_images.bzl for image access via the images macro.

**Available options:**

* **`auto`** (default): The hub repository is made visible if named repositories cannot be mapped in the current Bazel version.
                        This means you either get @rules_img_images.bzl or one repository per image.

* **`enabled`**: Always create and expose the hub repository @rules_img_images.bzl for image access via the images macro.

* **`disabled`**: Do not create the hub repository.2"auto"J"auto"J	"enabled"J
"disabled"�
�
image_repos�Controls visibility of individual image repositories for direct access. Repos internally use the naming scheme img_<digest> and are mapped via friendly names (i.e. "ubuntu") if possible.

**Available options:**

* **`auto`** (default): Individual image repositories are made visible if named repositories can be mapped in the current Bazel version.
                        This means you either get one repository per image or @rules_img_images.bzl.

* **`enabled`**: Always expose individual image repositories for direct access.

* **`disabled`**: Do not expose individual image repositories.2"auto"J"auto"J	"enabled"J
"disabled"+Public API for rules_img module extensions.��

	rules_imgimg	image.bzl��image_manifest�Builds a single-platform OCI container image from a set of layers.

This rule assembles container images by combining:
- Optional base image layers (from another image_manifest or image_index)
- Additional layers created by image_layer rules
- Image configuration (entrypoint, environment, labels, etc.)

The rule produces:
- OCI manifest and config JSON files
- An optional OCI layout directory or tar (via output groups)
- ImageManifestInfo provider for use by image_index or image_push

Example:

```python
image_manifest(
    name = "my_app",
    base = "@distroless_cc",
    layers = [
        ":app_layer",
        ":config_layer",
    ],
    entrypoint = ["/usr/bin/app"],
    env = {
        "APP_ENV": "production",
    },
)
```

Output groups:
- `descriptor`: OCI descriptor JSON file
- `digest`: Digest of the image (sha256:...)
- `oci_layout`: Complete OCI layout directory with blobs
- `oci_tarball`: OCI layout packaged as a tar file for downstream use"��
�D
image_manifest�Builds a single-platform OCI container image from a set of layers.

This rule assembles container images by combining:
- Optional base image layers (from another image_manifest or image_index)
- Additional layers created by image_layer rules
- Image configuration (entrypoint, environment, labels, etc.)

The rule produces:
- OCI manifest and config JSON files
- An optional OCI layout directory or tar (via output groups)
- ImageManifestInfo provider for use by image_index or image_push

Example:

```python
image_manifest(
    name = "my_app",
    base = "@distroless_cc",
    layers = [
        ":app_layer",
        ":config_layer",
    ],
    entrypoint = ["/usr/bin/app"],
    env = {
        "APP_ENV": "production",
    },
)
```

Output groups:
- `descriptor`: OCI descriptor JSON file
- `digest`: Digest of the image (sha256:...)
- `oci_layout`: Complete OCI layout directory with blobs
- `oci_tarball`: OCI layout packaged as a tar file for downstream use*
nameA unique name for this target. f
baseVBase image to inherit layers from. Should provide ImageManifestInfo or ImageIndexInfo.2Nonem
layers]Layers to include in the image. Either a LayersInfo provider or a DefaultInfo with tar files.2[]�
platform�Optional target platform to build this manifest for.

When specified, the image will be built for the provided platform regardless
of the current build configuration. This enables building single-platform images
for specific architectures.

Example:
```python
image_manifest(
    name = "app_arm64",
    platform = "//platforms:linux_arm64",
    base = "@ubuntu",
    layers = [":app_layer"],
)
```*(
PlatformInfo
PlatformInfo<native>2None�
user�The username or UID which is a platform-specific structure that allows specific control over which user the process run as.
This acts as a default value to use when the value is not specified when creating a container.2""�
env�Default environment variables to set when starting a container based on this image.

Subject to [template expansion](/docs/templating.md).
2{}�

entrypoint�A list of arguments to use as the command to execute when the container starts. These values act as defaults and may be replaced by an entrypoint specified when creating a container.2[]�
cmd�Default arguments to the entrypoint of the container. These values act as defaults and may be replaced by any specified when creating a container. If an Entrypoint value is not specified, then the first entry of the Cmd array SHOULD be interpreted as the executable to run.2[]�
working_dir�Sets the current working directory of the entrypoint process in the container. This value acts as a default and may be replaced by a working directory specified when creating a container.2""�
labelspThis field contains arbitrary metadata for the container.

Subject to [template expansion](/docs/templating.md).
2{}�
label_files�Files containing newline-delimited KEY=VALUE labels for the image config.

Each file should contain one label per line in KEY=VALUE format. Empty lines are ignored.
Labels from these files are merged together, and then merged with labels specified via
the `labels` attribute. Values from files take precedence over the `labels` attribute
for matching keys.

Example file content:
```
org.opencontainers.image.version=1.0.0
org.opencontainers.image.authors=team@example.com
```

Each label value is subject to [template expansion](/docs/templating.md).2[]�
annotationsoThis field contains arbitrary metadata for the manifest.

Subject to [template expansion](/docs/templating.md).
2{}�
annotations_file�File containing newline-delimited KEY=VALUE annotations for the manifest.

The file should contain one annotation per line in KEY=VALUE format. Empty lines are ignored.
Annotations from this file are merged with annotations specified via the `annotations` attribute.

Example file content:
```
version=1.0.0
build.date=2024-01-15
source.url=https://github.com/...
```

Each annotation is subject to [template expansion](/docs/templating.md).2None�
stop_signal�This field contains the system call signal that will be sent to the container to exit. The signal can be a signal name in the format SIGNAME, for instance SIGKILL or SIGRTMIN+3.2""�
config_fragment�Optional JSON file containing a partial image config, which will be used as a base for the final image config. When config_media_type is set to a non-OCI type (e.g. Helm), this file is used as the entire config blob as-is.2None�
config_media_type�Override the config blob media type.

When set to "application/vnd.oci.empty.v1+json", config_fragment is optional. If omitted, an empty
JSON config descriptor is produced automatically with the content inlined as data (`"data": "e30="`).

For other non-OCI types (e.g. "application/vnd.cncf.helm.config.v1+json" for Helm charts),
config_fragment is required and used verbatim as the config blob (no OCI image structure).2""�
artifact_type�Optional IANA media type of the artifact when the manifest is used for an artifact.

This sets the `artifactType` field in the OCI manifest, as defined in the
[OCI Image Spec](https://github.com/opencontainers/image-spec/blob/main/manifest.md#image-manifest-property-descriptions).

Common values include `application/vnd.cncf.helm.chart.v1` for Helm charts
or `application/spdx+json` for SPDX SBOMs.2""�
subject�Optional subject for the manifest.

Sets the `subject` field in the OCI manifest, which is a descriptor pointing to
another manifest or index. This is used for establishing referrer relationships,
such as attaching SBOMs, signatures, or attestations to an existing image.

The target must provide either ImageManifestInfo or ImageIndexInfo.*]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl*T
ImageIndexInfoB
ImageIndexInfo0@rules_img//img/private/providers:index_info.bzl2None�
created�Optional file containing a datetime string (RFC 3339 format) for when the image was created.

This is commonly used with Bazel's stamping mechanism to embed the build timestamp.2None�
build_settings�Build settings for template expansion.

Maps template variable names to string_flag targets. These values can be used in
env, labels, and annotations attributes using `{{.VARIABLE_NAME}}` syntax (Go template).

Example:
```python
build_settings = {
    "REGISTRY": "//settings:docker_registry",
    "VERSION": "//settings:app_version",
}
```

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"J"auto"J"force"J
"disabled"�

push_specs�Push configurations to produce DeployInfo for this image.

Each entry should be an `image_push_spec` target (providing `PushConfigInfo`).
When set (together with or without `load_specs`), this rule additionally returns
`DeployInfo`, making it directly usable as an operation in `multi_deploy`.

Example:
```python
image_push_spec(
    name = "push_config",
    registry = "gcr.io",
    repository = "my-project/my-app",
    tag = "latest",
)

image_manifest(
    name = "my_app",
    base = "@distroless_cc",
    layers = [":app_layer"],
    push_specs = [":push_config"],
)

multi_deploy(
    name = "deploy",
    operations = [":my_app"],
)
```*Z
PushConfigInfoH
PushConfigInfo6@rules_img//img/private/providers:push_config_info.bzl2[]�

load_specs�Load configurations to produce DeployInfo for this image.

Each entry should be an `image_load_spec` target (providing `LoadConfigInfo`).
When set (together with or without `push_specs`), this rule additionally returns
`DeployInfo`, making it directly usable as an operation in `multi_deploy`.

Example:
```python
image_load_spec(
    name = "load_config",
    tag = "my-app:latest",
)

image_manifest(
    name = "my_app",
    base = "@distroless_cc",
    layers = [":app_layer"],
    load_specs = [":load_config"],
)

multi_deploy(
    name = "deploy",
    operations = [":my_app"],
)
```*Z
LoadConfigInfoH
LoadConfigInfo6@rules_img//img/private/providers:load_config_info.bzl2[]"6
image_manifest$@rules_img//img/private:manifest.bzl*]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl,
*
nameA unique name for this target. h
f
baseVBase image to inherit layers from. Should provide ImageManifestInfo or ImageIndexInfo.2Noneo
m
layers]Layers to include in the image. Either a LayersInfo provider or a DefaultInfo with tar files.2[]�
�
platform�Optional target platform to build this manifest for.

When specified, the image will be built for the provided platform regardless
of the current build configuration. This enables building single-platform images
for specific architectures.

Example:
```python
image_manifest(
    name = "app_arm64",
    platform = "//platforms:linux_arm64",
    base = "@ubuntu",
    layers = [":app_layer"],
)
```*(
PlatformInfo
PlatformInfo<native>2None�
�
user�The username or UID which is a platform-specific structure that allows specific control over which user the process run as.
This acts as a default value to use when the value is not specified when creating a container.2""�
�
env�Default environment variables to set when starting a container based on this image.

Subject to [template expansion](/docs/templating.md).
2{}�
�

entrypoint�A list of arguments to use as the command to execute when the container starts. These values act as defaults and may be replaced by an entrypoint specified when creating a container.2[]�
�
cmd�Default arguments to the entrypoint of the container. These values act as defaults and may be replaced by any specified when creating a container. If an Entrypoint value is not specified, then the first entry of the Cmd array SHOULD be interpreted as the executable to run.2[]�
�
working_dir�Sets the current working directory of the entrypoint process in the container. This value acts as a default and may be replaced by a working directory specified when creating a container.2""�
�
labelspThis field contains arbitrary metadata for the container.

Subject to [template expansion](/docs/templating.md).
2{}�
�
label_files�Files containing newline-delimited KEY=VALUE labels for the image config.

Each file should contain one label per line in KEY=VALUE format. Empty lines are ignored.
Labels from these files are merged together, and then merged with labels specified via
the `labels` attribute. Values from files take precedence over the `labels` attribute
for matching keys.

Example file content:
```
org.opencontainers.image.version=1.0.0
org.opencontainers.image.authors=team@example.com
```

Each label value is subject to [template expansion](/docs/templating.md).2[]�
�
annotationsoThis field contains arbitrary metadata for the manifest.

Subject to [template expansion](/docs/templating.md).
2{}�
�
annotations_file�File containing newline-delimited KEY=VALUE annotations for the manifest.

The file should contain one annotation per line in KEY=VALUE format. Empty lines are ignored.
Annotations from this file are merged with annotations specified via the `annotations` attribute.

Example file content:
```
version=1.0.0
build.date=2024-01-15
source.url=https://github.com/...
```

Each annotation is subject to [template expansion](/docs/templating.md).2None�
�
stop_signal�This field contains the system call signal that will be sent to the container to exit. The signal can be a signal name in the format SIGNAME, for instance SIGKILL or SIGRTMIN+3.2""�
�
config_fragment�Optional JSON file containing a partial image config, which will be used as a base for the final image config. When config_media_type is set to a non-OCI type (e.g. Helm), this file is used as the entire config blob as-is.2None�
�
config_media_type�Override the config blob media type.

When set to "application/vnd.oci.empty.v1+json", config_fragment is optional. If omitted, an empty
JSON config descriptor is produced automatically with the content inlined as data (`"data": "e30="`).

For other non-OCI types (e.g. "application/vnd.cncf.helm.config.v1+json" for Helm charts),
config_fragment is required and used verbatim as the config blob (no OCI image structure).2""�
�
artifact_type�Optional IANA media type of the artifact when the manifest is used for an artifact.

This sets the `artifactType` field in the OCI manifest, as defined in the
[OCI Image Spec](https://github.com/opencontainers/image-spec/blob/main/manifest.md#image-manifest-property-descriptions).

Common values include `application/vnd.cncf.helm.chart.v1` for Helm charts
or `application/spdx+json` for SPDX SBOMs.2""�
�
subject�Optional subject for the manifest.

Sets the `subject` field in the OCI manifest, which is a descriptor pointing to
another manifest or index. This is used for establishing referrer relationships,
such as attaching SBOMs, signatures, or attestations to an existing image.

The target must provide either ImageManifestInfo or ImageIndexInfo.*]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl*T
ImageIndexInfoB
ImageIndexInfo0@rules_img//img/private/providers:index_info.bzl2None�
�
created�Optional file containing a datetime string (RFC 3339 format) for when the image was created.

This is commonly used with Bazel's stamping mechanism to embed the build timestamp.2None�
�
build_settings�Build settings for template expansion.

Maps template variable names to string_flag targets. These values can be used in
env, labels, and annotations attributes using `{{.VARIABLE_NAME}}` syntax (Go template).

Example:
```python
build_settings = {
    "REGISTRY": "//settings:docker_registry",
    "VERSION": "//settings:app_version",
}
```

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"J"auto"J"force"J
"disabled"�
�

push_specs�Push configurations to produce DeployInfo for this image.

Each entry should be an `image_push_spec` target (providing `PushConfigInfo`).
When set (together with or without `load_specs`), this rule additionally returns
`DeployInfo`, making it directly usable as an operation in `multi_deploy`.

Example:
```python
image_push_spec(
    name = "push_config",
    registry = "gcr.io",
    repository = "my-project/my-app",
    tag = "latest",
)

image_manifest(
    name = "my_app",
    base = "@distroless_cc",
    layers = [":app_layer"],
    push_specs = [":push_config"],
)

multi_deploy(
    name = "deploy",
    operations = [":my_app"],
)
```*Z
PushConfigInfoH
PushConfigInfo6@rules_img//img/private/providers:push_config_info.bzl2[]�
�

load_specs�Load configurations to produce DeployInfo for this image.

Each entry should be an `image_load_spec` target (providing `LoadConfigInfo`).
When set (together with or without `push_specs`), this rule additionally returns
`DeployInfo`, making it directly usable as an operation in `multi_deploy`.

Example:
```python
image_load_spec(
    name = "load_config",
    tag = "my-app:latest",
)

image_manifest(
    name = "my_app",
    base = "@distroless_cc",
    layers = [":app_layer"],
    load_specs = [":load_config"],
)

multi_deploy(
    name = "deploy",
    operations = [":my_app"],
)
```*Z
LoadConfigInfoH
LoadConfigInfo6@rules_img//img/private/providers:load_config_info.bzl2[]�Jimage_index�	Creates a multi-platform OCI image index from platform-specific manifests.

This rule combines multiple single-platform images (created by image_manifest) into
a multi-platform image index. The index allows container runtimes to automatically
select the appropriate image for their platform.

The rule supports two usage patterns:
1. Explicit manifests: Provide pre-built manifests for each platform
2. Platform transitions: Provide one manifest target and a list of platforms

The rule produces:
- OCI image index JSON file
- An optional OCI layout directory or tar (via output groups)
- ImageIndexInfo provider for use by image_push

Example (explicit manifests):

```python
image_index(
    name = "multiarch_app",
    manifests = [
        ":app_linux_amd64",
        ":app_linux_arm64",
        ":app_darwin_amd64",
    ],
)
```

Example (platform transitions):
```python
image_index(
    name = "multiarch_app",
    manifests = [":app"],
    platforms = [
        "//platform:linux-x86_64",
        "//platform:linux-aarch64",
    ],
)
```

Output groups:
- `digest`: Digest of the image (sha256:...)
- `oci_layout`: Complete OCI layout directory with all platform blobs
- `oci_tarball`: OCI layout packaged as a tar file for downstream use"�@
�%
image_index�	Creates a multi-platform OCI image index from platform-specific manifests.

This rule combines multiple single-platform images (created by image_manifest) into
a multi-platform image index. The index allows container runtimes to automatically
select the appropriate image for their platform.

The rule supports two usage patterns:
1. Explicit manifests: Provide pre-built manifests for each platform
2. Platform transitions: Provide one manifest target and a list of platforms

The rule produces:
- OCI image index JSON file
- An optional OCI layout directory or tar (via output groups)
- ImageIndexInfo provider for use by image_push

Example (explicit manifests):

```python
image_index(
    name = "multiarch_app",
    manifests = [
        ":app_linux_amd64",
        ":app_linux_arm64",
        ":app_darwin_amd64",
    ],
)
```

Example (platform transitions):
```python
image_index(
    name = "multiarch_app",
    manifests = [":app"],
    platforms = [
        "//platform:linux-x86_64",
        "//platform:linux-aarch64",
    ],
)
```

Output groups:
- `digest`: Digest of the image (sha256:...)
- `oci_layout`: Complete OCI layout directory with all platform blobs
- `oci_tarball`: OCI layout packaged as a tar file for downstream use*
nameA unique name for this target. �
	manifests)List of manifests for specific platforms.*]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl2[]�
	platforms�(Optional) list of target platforms to build the manifest for. Uses a split transition. If specified, the 'manifests' attribute should contain exactly one manifest.*(
PlatformInfo
PlatformInfo<native>2[]�
subject�Optional subject for the index.

Sets the `subject` field in the OCI index, which is a descriptor pointing to
another manifest or index. This is used for establishing referrer relationships,
such as attaching SBOMs, signatures, or attestations to an existing image.

The target must provide either ImageManifestInfo or ImageIndexInfo.*]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl*T
ImageIndexInfoB
ImageIndexInfo0@rules_img//img/private/providers:index_info.bzl2Nones
annotations^Arbitrary metadata for the image index.

Subject to [template expansion](/docs/templating.md).
2{}�
annotations_file�File containing newline-delimited KEY=VALUE annotations for the image index.

The file should contain one annotation per line in KEY=VALUE format. Empty lines are ignored.
Annotations from this file are merged with annotations specified via the `annotations` attribute.

Example file content:
```
version=1.0.0
build.date=2024-01-15
source.url=https://github.com/...
```

Each annotation is subject to [template expansion](/docs/templating.md).2None�
build_settings�Build settings for template expansion.

Maps template variable names to string_flag targets. These values can be used in
the annotations attribute using `{{.VARIABLE_NAME}}` syntax (Go template).

Example:
```python
build_settings = {
    "REGISTRY": "//settings:docker_registry",
    "VERSION": "//settings:app_version",
}
```

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"J"auto"J"force"J
"disabled"�

push_specs�Push configurations to produce DeployInfo for this image index.

Each entry should be an `image_push_spec` target (providing `PushConfigInfo`).
When set (together with or without `load_specs`), this rule additionally returns
`DeployInfo`, making it directly usable as an operation in `multi_deploy`.

For multi-platform pushes, `manifest_tags` on the push spec are expanded
per child manifest with platform variables (`{{.os}}`, `{{.architecture}}`, etc.).*Z
PushConfigInfoH
PushConfigInfo6@rules_img//img/private/providers:push_config_info.bzl2[]�

load_specs�Load configurations to produce DeployInfo for this image index.

Each entry should be an `image_load_spec` target (providing `LoadConfigInfo`).
When set (together with or without `push_specs`), this rule additionally returns
`DeployInfo`, making it directly usable as an operation in `multi_deploy`.*Z
LoadConfigInfoH
LoadConfigInfo6@rules_img//img/private/providers:load_config_info.bzl2[]"0
image_index!@rules_img//img/private:index.bzl,
*
nameA unique name for this target. �
�
	manifests)List of manifests for specific platforms.*]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl2[]�
�
	platforms�(Optional) list of target platforms to build the manifest for. Uses a split transition. If specified, the 'manifests' attribute should contain exactly one manifest.*(
PlatformInfo
PlatformInfo<native>2[]�
�
subject�Optional subject for the index.

Sets the `subject` field in the OCI index, which is a descriptor pointing to
another manifest or index. This is used for establishing referrer relationships,
such as attaching SBOMs, signatures, or attestations to an existing image.

The target must provide either ImageManifestInfo or ImageIndexInfo.*]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl*T
ImageIndexInfoB
ImageIndexInfo0@rules_img//img/private/providers:index_info.bzl2Noneu
s
annotations^Arbitrary metadata for the image index.

Subject to [template expansion](/docs/templating.md).
2{}�
�
annotations_file�File containing newline-delimited KEY=VALUE annotations for the image index.

The file should contain one annotation per line in KEY=VALUE format. Empty lines are ignored.
Annotations from this file are merged with annotations specified via the `annotations` attribute.

Example file content:
```
version=1.0.0
build.date=2024-01-15
source.url=https://github.com/...
```

Each annotation is subject to [template expansion](/docs/templating.md).2None�
�
build_settings�Build settings for template expansion.

Maps template variable names to string_flag targets. These values can be used in
the annotations attribute using `{{.VARIABLE_NAME}}` syntax (Go template).

Example:
```python
build_settings = {
    "REGISTRY": "//settings:docker_registry",
    "VERSION": "//settings:app_version",
}
```

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"J"auto"J"force"J
"disabled"�
�

push_specs�Push configurations to produce DeployInfo for this image index.

Each entry should be an `image_push_spec` target (providing `PushConfigInfo`).
When set (together with or without `load_specs`), this rule additionally returns
`DeployInfo`, making it directly usable as an operation in `multi_deploy`.

For multi-platform pushes, `manifest_tags` on the push spec are expanded
per child manifest with platform variables (`{{.os}}`, `{{.architecture}}`, etc.).*Z
PushConfigInfoH
PushConfigInfo6@rules_img//img/private/providers:push_config_info.bzl2[]�
�

load_specs�Load configurations to produce DeployInfo for this image index.

Each entry should be an `image_load_spec` target (providing `LoadConfigInfo`).
When set (together with or without `push_specs`), this rule additionally returns
`DeployInfo`, making it directly usable as an operation in `multi_deploy`.*Z
LoadConfigInfoH
LoadConfigInfo6@rules_img//img/private/providers:load_config_info.bzl2[]��image_from_binary�Packages a *_binary target into a container image.

This is a convenience macro that combines layer_from_binary and image_manifest (or image_index)
into a single target. It is the simplest way to containerize any Bazel `*_binary` target
(Go, C++, Python, Java, Rust, etc.).

The binary's `args`, `env`, and runfiles are automatically extracted and applied to the
image configuration:
- **entrypoint** is set to the binary's path inside the image
- **cmd** is populated from the binary's `args` attribute
- **env** is populated from the binary's `env` attribute (or RunEnvironmentInfo provider)
- **working_dir** is set to the binary's runfiles root

If the binary provides RunfilesGroupInfo (from rules_runfiles_group), the runfiles are split
into separate layers based on the groups. This allows for better caching: stable layers
(interpreter, stdlib) change infrequently and can be shared, while the application code layer
changes with each build. The resolution protocol respects RunfilesGroupTransformInfo and
RunfilesGroupMetadataInfo from the binary's aspect_hints.

All image_manifest attributes (base, env, labels, annotations, etc.) are inherited and
forwarded to the underlying image_manifest. The binary layer is always appended as the
last layer, after any layers specified in the `layers` attribute.

Example:

```python
load("@rules_go//go:def.bzl", "go_binary")
load("@rules_img//img:image.bzl", "image_from_binary")

go_binary(
    name = "server",
    srcs = ["main.go"],
    env = {"GIN_MODE": "release"},
)

# Package the Go binary with a distroless base
image_from_binary(
    name = "app_image",
    binary = ":server",
    base = "@distroless_base",
)

# Custom path and additional layers
image_from_binary(
    name = "full_image",
    binary = "//cmd/server",
    base = "@ubuntu",
    path = "/usr/local/bin/",
    layers = [":config_layer"],
    env = {"LOG_LEVEL": "info"},
)

# Multi-platform image
image_from_binary(
    name = "multiarch_image",
    binary = "//cmd/server",
    base = "@distroless_base",
    platforms = [
        "//:linux_amd64",
        "//:linux_arm64",
    ],
)
```

Targets created:
- `<name>.layer`: The layer_from_binary containing the executable and its runfiles
- `<name>` (or `<name>.manifest` + `<name>` for multi-platform): The image manifest/indexZ�
�a
image_from_binary�Packages a *_binary target into a container image.

This is a convenience macro that combines layer_from_binary and image_manifest (or image_index)
into a single target. It is the simplest way to containerize any Bazel `*_binary` target
(Go, C++, Python, Java, Rust, etc.).

The binary's `args`, `env`, and runfiles are automatically extracted and applied to the
image configuration:
- **entrypoint** is set to the binary's path inside the image
- **cmd** is populated from the binary's `args` attribute
- **env** is populated from the binary's `env` attribute (or RunEnvironmentInfo provider)
- **working_dir** is set to the binary's runfiles root

If the binary provides RunfilesGroupInfo (from rules_runfiles_group), the runfiles are split
into separate layers based on the groups. This allows for better caching: stable layers
(interpreter, stdlib) change infrequently and can be shared, while the application code layer
changes with each build. The resolution protocol respects RunfilesGroupTransformInfo and
RunfilesGroupMetadataInfo from the binary's aspect_hints.

All image_manifest attributes (base, env, labels, annotations, etc.) are inherited and
forwarded to the underlying image_manifest. The binary layer is always appended as the
last layer, after any layers specified in the `layers` attribute.

Example:

```python
load("@rules_go//go:def.bzl", "go_binary")
load("@rules_img//img:image.bzl", "image_from_binary")

go_binary(
    name = "server",
    srcs = ["main.go"],
    env = {"GIN_MODE": "release"},
)

# Package the Go binary with a distroless base
image_from_binary(
    name = "app_image",
    binary = ":server",
    base = "@distroless_base",
)

# Custom path and additional layers
image_from_binary(
    name = "full_image",
    binary = "//cmd/server",
    base = "@ubuntu",
    path = "/usr/local/bin/",
    layers = [":config_layer"],
    env = {"LOG_LEVEL": "info"},
)

# Multi-platform image
image_from_binary(
    name = "multiarch_image",
    binary = "//cmd/server",
    base = "@distroless_base",
    platforms = [
        "//:linux_amd64",
        "//:linux_arm64",
    ],
)
```

Targets created:
- `<name>.layer`: The layer_from_binary containing the executable and its runfiles
- `<name>` (or `<name>.manifest` + `<name>` for multi-platform): The image manifest/index�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@�
binary�The *_binary target to package into the image.

The binary's `args` and `env` attributes are extracted and applied as image configuration
(cmd and env). The `data` attribute is used for `$(location)` expansion in args and env values.

If the binary provides RunfilesGroupInfo, the runfiles are split into separate layers per group. �
path�Optional path of the binary inside the image.
If the path ends with a slash ("/"), the basename of the binary will be automatically appended.
If unset, this defaults to the rlocationpath of the binary (e.g., "_main/cmd/server/server_/server").2""~
layersnAdditional layers to include in the image.
The binary layer is automatically appended to the end of this list.2[]�
include_runfiles�Whether to include runfiles for the binary target.
When True (default), the binary's runfiles tree is included and the working directory
is set to the runfiles root. Set to False for statically linked binaries that don't
need runfiles.2True�
layer_budget�Maximum number of runfiles group layers.
If set to a value > 0 and the binary provides RunfilesGroupInfo, groups are merged down to this
limit using the merge algorithm from rules_runfiles_group. The algorithm respects group rank
(only merges within the same rank), do_not_merge flags, and weight hints (lighter groups merge first).
0 means no limit (all groups become separate layers).20�
kind�The kind of image to produce.

* "auto": Creates a single-platform manifest if zero or one platforms are provided, otherwise creates an index.
* "manifest": Always creates a single-platform manifest. Fails if multiple platforms are provided.
* "index": Always creates a multi-platform index.2"auto"8J"auto"J
"manifest"J"index"�
	platforms�Target platforms to build the image for.
If empty, the image is built for the current target platform.
If more than one platform is provided, an image_index is automatically created.2[]8
expect_failure2None@ 
transitive_configs2None8@
deprecation2None8@
tags2None8@
testonly2None8@
features2None@
compatible_with2None8@
restricted_to2None8@
package_metadata2None8@
aspect_hints2None@P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@
exec_properties
2None@"
exec_compatible_with2None8@(
exec_group_compatible_with2None8@Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@f
baseVBase image to inherit layers from. Should provide ImageManifestInfo or ImageIndexInfo.2None�
user�The username or UID which is a platform-specific structure that allows specific control over which user the process run as.
This acts as a default value to use when the value is not specified when creating a container.2None�
env�Default environment variables to set when starting a container based on this image.

Subject to [template expansion](/docs/templating.md).
2None�

entrypoint�A list of arguments to use as the command to execute when the container starts. These values act as defaults and may be replaced by an entrypoint specified when creating a container.2None�
cmd�Default arguments to the entrypoint of the container. These values act as defaults and may be replaced by any specified when creating a container. If an Entrypoint value is not specified, then the first entry of the Cmd array SHOULD be interpreted as the executable to run.2None�
working_dir�Sets the current working directory of the entrypoint process in the container. This value acts as a default and may be replaced by a working directory specified when creating a container.2None�
labelspThis field contains arbitrary metadata for the container.

Subject to [template expansion](/docs/templating.md).
2None�
label_files�Files containing newline-delimited KEY=VALUE labels for the image config.

Each file should contain one label per line in KEY=VALUE format. Empty lines are ignored.
Labels from these files are merged together, and then merged with labels specified via
the `labels` attribute. Values from files take precedence over the `labels` attribute
for matching keys.

Example file content:
```
org.opencontainers.image.version=1.0.0
org.opencontainers.image.authors=team@example.com
```

Each label value is subject to [template expansion](/docs/templating.md).2None�
annotationsoThis field contains arbitrary metadata for the manifest.

Subject to [template expansion](/docs/templating.md).
2None�
annotations_file�File containing newline-delimited KEY=VALUE annotations for the manifest.

The file should contain one annotation per line in KEY=VALUE format. Empty lines are ignored.
Annotations from this file are merged with annotations specified via the `annotations` attribute.

Example file content:
```
version=1.0.0
build.date=2024-01-15
source.url=https://github.com/...
```

Each annotation is subject to [template expansion](/docs/templating.md).2None�
stop_signal�This field contains the system call signal that will be sent to the container to exit. The signal can be a signal name in the format SIGNAME, for instance SIGKILL or SIGRTMIN+3.2None�
config_fragment�Optional JSON file containing a partial image config, which will be used as a base for the final image config. When config_media_type is set to a non-OCI type (e.g. Helm), this file is used as the entire config blob as-is.2None�
config_media_type�Override the config blob media type.

When set to "application/vnd.oci.empty.v1+json", config_fragment is optional. If omitted, an empty
JSON config descriptor is produced automatically with the content inlined as data (`"data": "e30="`).

For other non-OCI types (e.g. "application/vnd.cncf.helm.config.v1+json" for Helm charts),
config_fragment is required and used verbatim as the config blob (no OCI image structure).2None�
artifact_type�Optional IANA media type of the artifact when the manifest is used for an artifact.

This sets the `artifactType` field in the OCI manifest, as defined in the
[OCI Image Spec](https://github.com/opencontainers/image-spec/blob/main/manifest.md#image-manifest-property-descriptions).

Common values include `application/vnd.cncf.helm.chart.v1` for Helm charts
or `application/spdx+json` for SPDX SBOMs.2None�
subject�Optional subject for the manifest.

Sets the `subject` field in the OCI manifest, which is a descriptor pointing to
another manifest or index. This is used for establishing referrer relationships,
such as attaching SBOMs, signatures, or attestations to an existing image.

The target must provide either ImageManifestInfo or ImageIndexInfo.*]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl*T
ImageIndexInfoB
ImageIndexInfo0@rules_img//img/private/providers:index_info.bzl2None�
created�Optional file containing a datetime string (RFC 3339 format) for when the image was created.

This is commonly used with Bazel's stamping mechanism to embed the build timestamp.2None�
build_settings�Build settings for template expansion.

Maps template variable names to string_flag targets. These values can be used in
env, labels, and annotations attributes using `{{.VARIABLE_NAME}}` syntax (Go template).

Example:
```python
build_settings = {
    "REGISTRY": "//settings:docker_registry",
    "VERSION": "//settings:app_version",
}
```

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2None�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2NoneJ"auto"J"force"J
"disabled"�

push_specs�Push configurations to produce DeployInfo for this image.

Each entry should be an `image_push_spec` target (providing `PushConfigInfo`).
When set (together with or without `load_specs`), this rule additionally returns
`DeployInfo`, making it directly usable as an operation in `multi_deploy`.

Example:
```python
image_push_spec(
    name = "push_config",
    registry = "gcr.io",
    repository = "my-project/my-app",
    tag = "latest",
)

image_manifest(
    name = "my_app",
    base = "@distroless_cc",
    layers = [":app_layer"],
    push_specs = [":push_config"],
)

multi_deploy(
    name = "deploy",
    operations = [":my_app"],
)
```*Z
PushConfigInfoH
PushConfigInfo6@rules_img//img/private/providers:push_config_info.bzl2None�

load_specs�Load configurations to produce DeployInfo for this image.

Each entry should be an `image_load_spec` target (providing `LoadConfigInfo`).
When set (together with or without `push_specs`), this rule additionally returns
`DeployInfo`, making it directly usable as an operation in `multi_deploy`.

Example:
```python
image_load_spec(
    name = "load_config",
    tag = "my-app:latest",
)

image_manifest(
    name = "my_app",
    base = "@distroless_cc",
    layers = [":app_layer"],
    load_specs = [":load_config"],
)

multi_deploy(
    name = "deploy",
    operations = [":my_app"],
)
```*Z
LoadConfigInfoH
LoadConfigInfo6@rules_img//img/private/providers:load_config_info.bzl2None"B
image_from_binary-@rules_img//img/private:image_from_binary.bzl�
�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �
�

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@�
�
binary�The *_binary target to package into the image.

The binary's `args` and `env` attributes are extracted and applied as image configuration
(cmd and env). The `data` attribute is used for `$(location)` expansion in args and env values.

If the binary provides RunfilesGroupInfo, the runfiles are split into separate layers per group. �
�
path�Optional path of the binary inside the image.
If the path ends with a slash ("/"), the basename of the binary will be automatically appended.
If unset, this defaults to the rlocationpath of the binary (e.g., "_main/cmd/server/server_/server").2""�
~
layersnAdditional layers to include in the image.
The binary layer is automatically appended to the end of this list.2[]�
�
include_runfiles�Whether to include runfiles for the binary target.
When True (default), the binary's runfiles tree is included and the working directory
is set to the runfiles root. Set to False for statically linked binaries that don't
need runfiles.2True�
�
layer_budget�Maximum number of runfiles group layers.
If set to a value > 0 and the binary provides RunfilesGroupInfo, groups are merged down to this
limit using the merge algorithm from rules_runfiles_group. The algorithm respects group rank
(only merges within the same rank), do_not_merge flags, and weight hints (lighter groups merge first).
0 means no limit (all groups become separate layers).20�
�
kind�The kind of image to produce.

* "auto": Creates a single-platform manifest if zero or one platforms are provided, otherwise creates an index.
* "manifest": Always creates a single-platform manifest. Fails if multiple platforms are provided.
* "index": Always creates a multi-platform index.2"auto"8J"auto"J
"manifest"J"index"�
�
	platforms�Target platforms to build the image for.
If empty, the image is built for the current target platform.
If more than one platform is provided, an image_index is automatically created.2[]8

expect_failure2None@"
 
transitive_configs2None8@

deprecation2None8@

tags2None8@

testonly2None8@

features2None@

compatible_with2None8@

restricted_to2None8@ 

package_metadata2None8@

aspect_hints2None@R
P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@

exec_properties
2None@$
"
exec_compatible_with2None8@*
(
exec_group_compatible_with2None8@\
Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@h
f
baseVBase image to inherit layers from. Should provide ImageManifestInfo or ImageIndexInfo.2None�
�
user�The username or UID which is a platform-specific structure that allows specific control over which user the process run as.
This acts as a default value to use when the value is not specified when creating a container.2None�
�
env�Default environment variables to set when starting a container based on this image.

Subject to [template expansion](/docs/templating.md).
2None�
�

entrypoint�A list of arguments to use as the command to execute when the container starts. These values act as defaults and may be replaced by an entrypoint specified when creating a container.2None�
�
cmd�Default arguments to the entrypoint of the container. These values act as defaults and may be replaced by any specified when creating a container. If an Entrypoint value is not specified, then the first entry of the Cmd array SHOULD be interpreted as the executable to run.2None�
�
working_dir�Sets the current working directory of the entrypoint process in the container. This value acts as a default and may be replaced by a working directory specified when creating a container.2None�
�
labelspThis field contains arbitrary metadata for the container.

Subject to [template expansion](/docs/templating.md).
2None�
�
label_files�Files containing newline-delimited KEY=VALUE labels for the image config.

Each file should contain one label per line in KEY=VALUE format. Empty lines are ignored.
Labels from these files are merged together, and then merged with labels specified via
the `labels` attribute. Values from files take precedence over the `labels` attribute
for matching keys.

Example file content:
```
org.opencontainers.image.version=1.0.0
org.opencontainers.image.authors=team@example.com
```

Each label value is subject to [template expansion](/docs/templating.md).2None�
�
annotationsoThis field contains arbitrary metadata for the manifest.

Subject to [template expansion](/docs/templating.md).
2None�
�
annotations_file�File containing newline-delimited KEY=VALUE annotations for the manifest.

The file should contain one annotation per line in KEY=VALUE format. Empty lines are ignored.
Annotations from this file are merged with annotations specified via the `annotations` attribute.

Example file content:
```
version=1.0.0
build.date=2024-01-15
source.url=https://github.com/...
```

Each annotation is subject to [template expansion](/docs/templating.md).2None�
�
stop_signal�This field contains the system call signal that will be sent to the container to exit. The signal can be a signal name in the format SIGNAME, for instance SIGKILL or SIGRTMIN+3.2None�
�
config_fragment�Optional JSON file containing a partial image config, which will be used as a base for the final image config. When config_media_type is set to a non-OCI type (e.g. Helm), this file is used as the entire config blob as-is.2None�
�
config_media_type�Override the config blob media type.

When set to "application/vnd.oci.empty.v1+json", config_fragment is optional. If omitted, an empty
JSON config descriptor is produced automatically with the content inlined as data (`"data": "e30="`).

For other non-OCI types (e.g. "application/vnd.cncf.helm.config.v1+json" for Helm charts),
config_fragment is required and used verbatim as the config blob (no OCI image structure).2None�
�
artifact_type�Optional IANA media type of the artifact when the manifest is used for an artifact.

This sets the `artifactType` field in the OCI manifest, as defined in the
[OCI Image Spec](https://github.com/opencontainers/image-spec/blob/main/manifest.md#image-manifest-property-descriptions).

Common values include `application/vnd.cncf.helm.chart.v1` for Helm charts
or `application/spdx+json` for SPDX SBOMs.2None�
�
subject�Optional subject for the manifest.

Sets the `subject` field in the OCI manifest, which is a descriptor pointing to
another manifest or index. This is used for establishing referrer relationships,
such as attaching SBOMs, signatures, or attestations to an existing image.

The target must provide either ImageManifestInfo or ImageIndexInfo.*]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl*T
ImageIndexInfoB
ImageIndexInfo0@rules_img//img/private/providers:index_info.bzl2None�
�
created�Optional file containing a datetime string (RFC 3339 format) for when the image was created.

This is commonly used with Bazel's stamping mechanism to embed the build timestamp.2None�
�
build_settings�Build settings for template expansion.

Maps template variable names to string_flag targets. These values can be used in
env, labels, and annotations attributes using `{{.VARIABLE_NAME}}` syntax (Go template).

Example:
```python
build_settings = {
    "REGISTRY": "//settings:docker_registry",
    "VERSION": "//settings:app_version",
}
```

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2None�
�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2NoneJ"auto"J"force"J
"disabled"�
�

push_specs�Push configurations to produce DeployInfo for this image.

Each entry should be an `image_push_spec` target (providing `PushConfigInfo`).
When set (together with or without `load_specs`), this rule additionally returns
`DeployInfo`, making it directly usable as an operation in `multi_deploy`.

Example:
```python
image_push_spec(
    name = "push_config",
    registry = "gcr.io",
    repository = "my-project/my-app",
    tag = "latest",
)

image_manifest(
    name = "my_app",
    base = "@distroless_cc",
    layers = [":app_layer"],
    push_specs = [":push_config"],
)

multi_deploy(
    name = "deploy",
    operations = [":my_app"],
)
```*Z
PushConfigInfoH
PushConfigInfo6@rules_img//img/private/providers:push_config_info.bzl2None�
�

load_specs�Load configurations to produce DeployInfo for this image.

Each entry should be an `image_load_spec` target (providing `LoadConfigInfo`).
When set (together with or without `push_specs`), this rule additionally returns
`DeployInfo`, making it directly usable as an operation in `multi_deploy`.

Example:
```python
image_load_spec(
    name = "load_config",
    tag = "my-app:latest",
)

image_manifest(
    name = "my_app",
    base = "@distroless_cc",
    layers = [":app_layer"],
    load_specs = [":load_config"],
)

multi_deploy(
    name = "deploy",
    operations = [":my_app"],
)
```*Z
LoadConfigInfoH
LoadConfigInfo6@rules_img//img/private/providers:load_config_info.bzl2None�Rules to build container images from layers.

Use `image_from_binary` to package any `*_binary` target into a container image,
`image_manifest` to create a single-platform container image from layers,
and `image_index` to compose a multi-platform container image index.��

	rules_imgimg	layer.bzl�@image_layer�	Creates a container image layer from files, executables, and directories.

This rule packages files into a layer that can be used in container images. It supports:
- Adding files at specific paths in the image
- Setting file permissions and ownership
- Creating symlinks
- Including executables with their runfiles
- Compression (gzip, zstd) and eStargz optimization

Example:

```python
load("@rules_img//img:layer.bzl", "image_layer", "file_metadata")

# Simple layer with files
image_layer(
    name = "app_layer",
    srcs = {
        "/app/bin/server": "//cmd/server",
        "/app/config.json": ":config.json",
    },
)

# Layer with custom permissions
image_layer(
    name = "secure_layer",
    srcs = {
        "/etc/app/config": ":config",
        "/etc/app/secret": ":secret",
    },
    default_metadata = file_metadata(
        mode = "0644",
        uid = 1000,
        gid = 1000,
    ),
    file_metadata = {
        "/etc/app/secret": file_metadata(mode = "0600"),
    },
)

# Layer with symlinks
image_layer(
    name = "bin_layer",
    srcs = {
        "/usr/local/bin/app": "//cmd/app",
    },
    symlinks = {
        "/usr/bin/app": "/usr/local/bin/app",
    },
)
```"�7
� 
image_layer�	Creates a container image layer from files, executables, and directories.

This rule packages files into a layer that can be used in container images. It supports:
- Adding files at specific paths in the image
- Setting file permissions and ownership
- Creating symlinks
- Including executables with their runfiles
- Compression (gzip, zstd) and eStargz optimization

Example:

```python
load("@rules_img//img:layer.bzl", "image_layer", "file_metadata")

# Simple layer with files
image_layer(
    name = "app_layer",
    srcs = {
        "/app/bin/server": "//cmd/server",
        "/app/config.json": ":config.json",
    },
)

# Layer with custom permissions
image_layer(
    name = "secure_layer",
    srcs = {
        "/etc/app/config": ":config",
        "/etc/app/secret": ":secret",
    },
    default_metadata = file_metadata(
        mode = "0644",
        uid = 1000,
        gid = 1000,
    ),
    file_metadata = {
        "/etc/app/secret": file_metadata(mode = "0600"),
    },
)

# Layer with symlinks
image_layer(
    name = "bin_layer",
    srcs = {
        "/usr/local/bin/app": "//cmd/app",
    },
    symlinks = {
        "/usr/bin/app": "/usr/local/bin/app",
    },
)
```*
nameA unique name for this target. �
srcs�Files to include in the layer. Keys are paths in the image (e.g., "/app/bin/server"),
values are labels to files or executables. Executables automatically include their runfiles unless include_runfiles is set to False.2{}}
symlinkskSymlinks to create in the layer. Keys are symlink paths in the image,
values are the targets they point to.
2{}�
default_metadata�JSON-encoded default metadata to apply to all files in the layer.
Can include fields like mode, uid, gid, uname, gname, mtime, and pax_records.2""�
file_metadata�Per-file metadata overrides as a dict mapping file paths to JSON-encoded metadata.
The path should match the path in the image (the key in srcs attribute).
Metadata specified here overrides any defaults from default_metadata.
2{}�
compress\Compression algorithm to use. If set to 'auto', uses the global default compression setting.2"auto"J"auto"J"gzip"J"zstd"�
estargz�Whether to use estargz format. If set to 'auto', uses the global default estargz setting.
When enabled, the layer will be optimized for lazy pulling and will be compatible with the estargz format.2"auto"J"auto"J	"enabled"J
"disabled"�
create_parent_directories�Whether to automatically create parent directory entries in the tar file for all files.
If set to 'auto', uses the global default create_parent_directories setting.
When enabled, parent directories will be created automatically for all files in the layer.2"auto"J"auto"J	"enabled"J
"disabled"�
tree_artifact_handling�How to handle duplicate tree artifacts (directories) in the layer.
If set to 'full', each tree artifact is stored at its intended path (no deduplication).
If set to 'deduplicate_symlink', duplicate tree artifacts are replaced with symlinks to the first occurrence.
If set to 'auto', uses the global default from --@rules_img//img/settings:layer_tree_artifact_handling.2"auto"J"auto"J"full"J"deduplicate_symlink"�
include_runfiles�Whether to include runfiles for executable targets.
When True (default), executables in srcs will include their runfiles tree.
When False, only the executable file itself is included, without runfiles.2TrueQ
annotations<Annotations to add to the layer metadata as key-value pairs.
2{}�
annotations_file�File containing newline-delimited KEY=VALUE annotations for the layer.

The file should contain one annotation per line in KEY=VALUE format. Empty lines are ignored.
Annotations from this file are merged with annotations specified via the `annotations` attribute.

Example file content:
```
version=1.0.0
build.date=2024-01-15
source.url=https://github.com/...
```2None~

media_typejOverride the layer media type. By default, the media type is auto-detected from the compression algorithm.2"""0
image_layer!@rules_img//img/private:layer.bzl*M

LayersInfo?

LayersInfo1@rules_img//img/private/providers:layers_info.bzl,
*
nameA unique name for this target. �
�
srcs�Files to include in the layer. Keys are paths in the image (e.g., "/app/bin/server"),
values are labels to files or executables. Executables automatically include their runfiles unless include_runfiles is set to False.2{}
}
symlinkskSymlinks to create in the layer. Keys are symlink paths in the image,
values are the targets they point to.
2{}�
�
default_metadata�JSON-encoded default metadata to apply to all files in the layer.
Can include fields like mode, uid, gid, uname, gname, mtime, and pax_records.2""�
�
file_metadata�Per-file metadata overrides as a dict mapping file paths to JSON-encoded metadata.
The path should match the path in the image (the key in srcs attribute).
Metadata specified here overrides any defaults from default_metadata.
2{}�
�
compress\Compression algorithm to use. If set to 'auto', uses the global default compression setting.2"auto"J"auto"J"gzip"J"zstd"�
�
estargz�Whether to use estargz format. If set to 'auto', uses the global default estargz setting.
When enabled, the layer will be optimized for lazy pulling and will be compatible with the estargz format.2"auto"J"auto"J	"enabled"J
"disabled"�
�
create_parent_directories�Whether to automatically create parent directory entries in the tar file for all files.
If set to 'auto', uses the global default create_parent_directories setting.
When enabled, parent directories will be created automatically for all files in the layer.2"auto"J"auto"J	"enabled"J
"disabled"�
�
tree_artifact_handling�How to handle duplicate tree artifacts (directories) in the layer.
If set to 'full', each tree artifact is stored at its intended path (no deduplication).
If set to 'deduplicate_symlink', duplicate tree artifacts are replaced with symlinks to the first occurrence.
If set to 'auto', uses the global default from --@rules_img//img/settings:layer_tree_artifact_handling.2"auto"J"auto"J"full"J"deduplicate_symlink"�
�
include_runfiles�Whether to include runfiles for executable targets.
When True (default), executables in srcs will include their runfiles tree.
When False, only the executable file itself is included, without runfiles.2TrueS
Q
annotations<Annotations to add to the layer metadata as key-value pairs.
2{}�
�
annotations_file�File containing newline-delimited KEY=VALUE annotations for the layer.

The file should contain one annotation per line in KEY=VALUE format. Empty lines are ignored.
Annotations from this file are merged with annotations specified via the `annotations` attribute.

Example file content:
```
version=1.0.0
build.date=2024-01-15
source.url=https://github.com/...
```2None�
~

media_typejOverride the layer media type. By default, the media type is auto-detected from the compression algorithm.2""�mlayer_from_binary�Creates a container image layer from a *_binary target.

This rule packages a binary executable and its runfiles into a layer, and additionally
provides image configuration (entrypoint, cmd, env, working_dir) via ImageLayerConfigInfo.
When used as a layer in image_manifest, the configuration is automatically applied to the
image with Dockerfile-like semantics.

The binary's `args` attribute becomes the image `cmd`, its `env` attribute (or
RunEnvironmentInfo provider) becomes `env`, and the binary path becomes the `entrypoint`.
When include_runfiles is True (default), the working directory is set to the runfiles root.

If the binary provides RunfilesGroupInfo (from rules_runfiles_group), the runfiles are split
into separate layers based on the groups. This allows for better caching: stable layers
(interpreter, stdlib) change infrequently and can be shared, while the application code layer
changes with each build. The resolution protocol respects RunfilesGroupTransformInfo and
RunfilesGroupMetadataInfo from the binary's aspect_hints.

When the number of groups exceeds what is practical for a container image, use `layer_budget`
to merge groups down to a maximum count. The merge algorithm respects group rank (only merges
within the same rank), do_not_merge flags, and weight hints (lighter groups merge first).

Example:

```python
load("@rules_img//img:layer.bzl", "layer_from_binary")
load("@rules_img//img:image.bzl", "image_manifest")

# Package a Go binary with its runfiles
layer_from_binary(
    name = "app_layer",
    binary = "//cmd/server",
)

# Use in an image - entrypoint, cmd, env, and working_dir are set automatically
image_manifest(
    name = "image",
    base = "@distroless_base",
    layers = [":app_layer"],
)

# Override the path inside the image
layer_from_binary(
    name = "custom_path_layer",
    binary = "//cmd/server",
    path = "/usr/local/bin/",
)

# Without runfiles (static binary)
layer_from_binary(
    name = "static_layer",
    binary = "//cmd/server",
    path = "/usr/local/bin/server",
    include_runfiles = False,
)
```"�\
�6
layer_from_binary�Creates a container image layer from a *_binary target.

This rule packages a binary executable and its runfiles into a layer, and additionally
provides image configuration (entrypoint, cmd, env, working_dir) via ImageLayerConfigInfo.
When used as a layer in image_manifest, the configuration is automatically applied to the
image with Dockerfile-like semantics.

The binary's `args` attribute becomes the image `cmd`, its `env` attribute (or
RunEnvironmentInfo provider) becomes `env`, and the binary path becomes the `entrypoint`.
When include_runfiles is True (default), the working directory is set to the runfiles root.

If the binary provides RunfilesGroupInfo (from rules_runfiles_group), the runfiles are split
into separate layers based on the groups. This allows for better caching: stable layers
(interpreter, stdlib) change infrequently and can be shared, while the application code layer
changes with each build. The resolution protocol respects RunfilesGroupTransformInfo and
RunfilesGroupMetadataInfo from the binary's aspect_hints.

When the number of groups exceeds what is practical for a container image, use `layer_budget`
to merge groups down to a maximum count. The merge algorithm respects group rank (only merges
within the same rank), do_not_merge flags, and weight hints (lighter groups merge first).

Example:

```python
load("@rules_img//img:layer.bzl", "layer_from_binary")
load("@rules_img//img:image.bzl", "image_manifest")

# Package a Go binary with its runfiles
layer_from_binary(
    name = "app_layer",
    binary = "//cmd/server",
)

# Use in an image - entrypoint, cmd, env, and working_dir are set automatically
image_manifest(
    name = "image",
    base = "@distroless_base",
    layers = [":app_layer"],
)

# Override the path inside the image
layer_from_binary(
    name = "custom_path_layer",
    binary = "//cmd/server",
    path = "/usr/local/bin/",
)

# Without runfiles (static binary)
layer_from_binary(
    name = "static_layer",
    binary = "//cmd/server",
    path = "/usr/local/bin/server",
    include_runfiles = False,
)
```*
nameA unique name for this target. �
binary�The *_binary target to package into the layer.

The binary's `args` and `env` attributes are extracted and provided as image configuration
(cmd and env) via ImageLayerConfigInfo. The `data` attribute is used for `$(location)` expansion
in args and env values.

If the binary provides RunfilesGroupInfo, the runfiles are split into separate layers per group. �
path�Optional path of the binary inside the image.
If the path ends with a slash ("/"), the basename of the binary will be automatically appended.
If unset, this defaults to the rlocationpath of the binary (e.g., "_main/cmd/server/server_/server").2""�
runfiles_path�Optional path of the runfiles directory of the binary inside the image.
If unset, this defaults to the path of the binary with a .runfiles suffix (e.g., "_main/cmd/server/server_/server.runfiles").
Note: depending on the runfiles_sharing_mode, this may be a symlink to a shared runfiles directory.2""�
runfiles_shared_path�Optional path of the shared runfiles directory inside the image.
This is only used when runfiles sharing is enabled and has a global default.2""�
runfiles_sharing_mode�How to process runfiles.
Runfiles can either be placed next to the executable (in a directory with a .runfiles suffix, the runfiles_path attribute),
or placed in a shared runfiles path. When sharing runfiles, there will be symlink added: {runfiles_path} -> {runfiles_shared_path}.

Possible settings:

* `"auto"`: Share runfiles based on the global default and based on the presence of `RunfilesGroupInfo`.
    Globally, runfiles sharing can be set to `"shared"`, `"private"`, or `"auto"`, where auto shares runfiles if `RunfilesGroupInfo` is provided.
* `"shared"`: Always share runfiles.
* `"private"`: Never share runfiles2"auto"J"auto"J"shared"J	"private"�
layer_budget�Maximum total number of layers produced by this rule.
If set to a value > 0 and the binary provides RunfilesGroupInfo, groups are merged
using the merge algorithm from rules_runfiles_group. The algorithm respects
group rank (only merges within the same rank), do_not_merge flags, and weight hints
(lighter groups merge first).

When a group is marked as executable_group in RunfilesGroupMetadataInfo, the binary
executable and supporting files are merged into that group's layer, and the full budget
is available for runfiles groups. When no executable_group exists, one layer is reserved
for a separate binary layer, and the remaining budget (layer_budget - 1) is used for groups;
layer_budget=1 without an executable_group skips the grouped path entirely.

0 means no limit (all groups become separate layers, plus a binary layer unless
an executable_group absorbs it).20�
compress\Compression algorithm to use. If set to 'auto', uses the global default compression setting.2"auto"J"auto"J"gzip"J"zstd"�
estargz�Whether to use estargz format. If set to 'auto', uses the global default estargz setting.
When enabled, the layer will be optimized for lazy pulling and will be compatible with the estargz format.2"auto"J"auto"J	"enabled"J
"disabled"�
create_parent_directories�Whether to automatically create parent directory entries in the tar file for all files.
If set to 'auto', uses the global default create_parent_directories setting.
When enabled, parent directories will be created automatically for all files in the layer.2"auto"J"auto"J	"enabled"J
"disabled"�
tree_artifact_handling�How to handle duplicate tree artifacts (directories) in the layer.
If set to 'full', each tree artifact is stored at its intended path (no deduplication).
If set to 'deduplicate_symlink', duplicate tree artifacts are replaced with symlinks to the first occurrence.
If set to 'auto', uses the global default from --@rules_img//img/settings:layer_tree_artifact_handling.2"auto"J"auto"J"full"J"deduplicate_symlink"�
include_runfiles�Whether to include runfiles for executable targets.
When True (default), executables in srcs will include their runfiles tree.
When False, only the executable file itself is included, without runfiles.2TrueQ
annotations<Annotations to add to the layer metadata as key-value pairs.
2{}�
annotations_file�File containing newline-delimited KEY=VALUE annotations for the layer.

The file should contain one annotation per line in KEY=VALUE format. Empty lines are ignored.
Annotations from this file are merged with annotations specified via the `annotations` attribute.

Example file content:
```
version=1.0.0
build.date=2024-01-15
source.url=https://github.com/...
```2None~

media_typejOverride the layer media type. By default, the media type is auto-detected from the compression algorithm.2"""B
layer_from_binary-@rules_img//img/private:layer_from_binary.bzl*M

LayersInfo?

LayersInfo1@rules_img//img/private/providers:layers_info.bzl,
*
nameA unique name for this target. �
�
binary�The *_binary target to package into the layer.

The binary's `args` and `env` attributes are extracted and provided as image configuration
(cmd and env) via ImageLayerConfigInfo. The `data` attribute is used for `$(location)` expansion
in args and env values.

If the binary provides RunfilesGroupInfo, the runfiles are split into separate layers per group. �
�
path�Optional path of the binary inside the image.
If the path ends with a slash ("/"), the basename of the binary will be automatically appended.
If unset, this defaults to the rlocationpath of the binary (e.g., "_main/cmd/server/server_/server").2""�
�
runfiles_path�Optional path of the runfiles directory of the binary inside the image.
If unset, this defaults to the path of the binary with a .runfiles suffix (e.g., "_main/cmd/server/server_/server.runfiles").
Note: depending on the runfiles_sharing_mode, this may be a symlink to a shared runfiles directory.2""�
�
runfiles_shared_path�Optional path of the shared runfiles directory inside the image.
This is only used when runfiles sharing is enabled and has a global default.2""�
�
runfiles_sharing_mode�How to process runfiles.
Runfiles can either be placed next to the executable (in a directory with a .runfiles suffix, the runfiles_path attribute),
or placed in a shared runfiles path. When sharing runfiles, there will be symlink added: {runfiles_path} -> {runfiles_shared_path}.

Possible settings:

* `"auto"`: Share runfiles based on the global default and based on the presence of `RunfilesGroupInfo`.
    Globally, runfiles sharing can be set to `"shared"`, `"private"`, or `"auto"`, where auto shares runfiles if `RunfilesGroupInfo` is provided.
* `"shared"`: Always share runfiles.
* `"private"`: Never share runfiles2"auto"J"auto"J"shared"J	"private"�
�
layer_budget�Maximum total number of layers produced by this rule.
If set to a value > 0 and the binary provides RunfilesGroupInfo, groups are merged
using the merge algorithm from rules_runfiles_group. The algorithm respects
group rank (only merges within the same rank), do_not_merge flags, and weight hints
(lighter groups merge first).

When a group is marked as executable_group in RunfilesGroupMetadataInfo, the binary
executable and supporting files are merged into that group's layer, and the full budget
is available for runfiles groups. When no executable_group exists, one layer is reserved
for a separate binary layer, and the remaining budget (layer_budget - 1) is used for groups;
layer_budget=1 without an executable_group skips the grouped path entirely.

0 means no limit (all groups become separate layers, plus a binary layer unless
an executable_group absorbs it).20�
�
compress\Compression algorithm to use. If set to 'auto', uses the global default compression setting.2"auto"J"auto"J"gzip"J"zstd"�
�
estargz�Whether to use estargz format. If set to 'auto', uses the global default estargz setting.
When enabled, the layer will be optimized for lazy pulling and will be compatible with the estargz format.2"auto"J"auto"J	"enabled"J
"disabled"�
�
create_parent_directories�Whether to automatically create parent directory entries in the tar file for all files.
If set to 'auto', uses the global default create_parent_directories setting.
When enabled, parent directories will be created automatically for all files in the layer.2"auto"J"auto"J	"enabled"J
"disabled"�
�
tree_artifact_handling�How to handle duplicate tree artifacts (directories) in the layer.
If set to 'full', each tree artifact is stored at its intended path (no deduplication).
If set to 'deduplicate_symlink', duplicate tree artifacts are replaced with symlinks to the first occurrence.
If set to 'auto', uses the global default from --@rules_img//img/settings:layer_tree_artifact_handling.2"auto"J"auto"J"full"J"deduplicate_symlink"�
�
include_runfiles�Whether to include runfiles for executable targets.
When True (default), executables in srcs will include their runfiles tree.
When False, only the executable file itself is included, without runfiles.2TrueS
Q
annotations<Annotations to add to the layer metadata as key-value pairs.
2{}�
�
annotations_file�File containing newline-delimited KEY=VALUE annotations for the layer.

The file should contain one annotation per line in KEY=VALUE format. Empty lines are ignored.
Annotations from this file are merged with annotations specified via the `annotations` attribute.

Example file content:
```
version=1.0.0
build.date=2024-01-15
source.url=https://github.com/...
```2None�
~

media_typejOverride the layer media type. By default, the media type is auto-detected from the compression algorithm.2""�layer_from_file�Creates a container image layer from an arbitrary file.

This rule uses any file as a container image layer blob, computing the
necessary metadata (digest, size) without any tar-specific processing
like compression or optimization.

This is useful for non-tar layer content such as Helm charts, WASM
modules, or other OCI artifacts.

If you want to use an existing tar file as a layer, use layer_from_tar instead.

Example:

```python
load("@rules_img//img:layer.bzl", "layer_from_file")

# Use an arbitrary artifact as a layer
layer_from_file(
    name = "artifact_layer",
    src = ":artifact.bin",
    media_type = "application/octet-stream",
    annotations = {
        "org.opencontainers.image.title": "artifact.bin",
    },
)
```"�
�
layer_from_file�Creates a container image layer from an arbitrary file.

This rule uses any file as a container image layer blob, computing the
necessary metadata (digest, size) without any tar-specific processing
like compression or optimization.

This is useful for non-tar layer content such as Helm charts, WASM
modules, or other OCI artifacts.

If you want to use an existing tar file as a layer, use layer_from_tar instead.

Example:

```python
load("@rules_img//img:layer.bzl", "layer_from_file")

# Use an arbitrary artifact as a layer
layer_from_file(
    name = "artifact_layer",
    src = ":artifact.bin",
    media_type = "application/octet-stream",
    annotations = {
        "org.opencontainers.image.title": "artifact.bin",
    },
)
```*
nameA unique name for this target. +
src The file to use as a layer blob. Q
annotations<Annotations to add to the layer metadata as key-value pairs.
2{}\
base_name_annotations=List of annotations that are set to the basename of the file.2[]�

media_typeRLayer media type. Defaults to "application/vnd.oci.image.layer.v1.tar" if not set.2("application/vnd.oci.image.layer.v1.tar"�
diff_id�If set, interprets the file as a (potentially compressed) tar file and calculates the diff_id. Warning: if you do this, you probably want to use layer_from_tar instead.2Falset
diff_id_annotationsWList of annotations that are set to the diff_id of the file. Only works with tar files.2[]">
layer_from_file+@rules_img//img/private:layer_from_file.bzl*M

LayersInfo?

LayersInfo1@rules_img//img/private/providers:layers_info.bzl,
*
nameA unique name for this target. -
+
src The file to use as a layer blob. S
Q
annotations<Annotations to add to the layer metadata as key-value pairs.
2{}^
\
base_name_annotations=List of annotations that are set to the basename of the file.2[]�
�

media_typeRLayer media type. Defaults to "application/vnd.oci.image.layer.v1.tar" if not set.2("application/vnd.oci.image.layer.v1.tar"�
�
diff_id�If set, interprets the file as a (potentially compressed) tar file and calculates the diff_id. Warning: if you do this, you probably want to use layer_from_tar instead.2Falsev
t
diff_id_annotationsWList of annotations that are set to the diff_id of the file. Only works with tar files.2[]�!layer_from_tar�Creates a container image layer from an existing tar archive.

This rule converts tar files into container image layers, useful for incorporating
pre-built artifacts, third-party distributions, or legacy build outputs.

The rule can:
- Use tar files as-is or recompress them
- Optimize tar contents by deduplicating files
- Add annotations to the layer metadata

Example:

```python
load("@rules_img//img:layer.bzl", "layer_from_tar")

# Use an existing tar file as a layer
layer_from_tar(
    name = "third_party_layer",
    src = "@third_party_lib//:lib.tar.gz",
)

# Optimize and recompress
layer_from_tar(
    name = "optimized_layer",
    src = "//legacy:build_output.tar",
    optimize = True,  # Deduplicate contents
    compress = "zstd",  # Use zstd compression
)

# Add metadata annotations
layer_from_tar(
    name = "annotated_layer",
    src = "//vendor:dependencies.tar.gz",
    annotations = {
        "org.opencontainers.image.title": "Vendor Dependencies",
        "org.opencontainers.image.version": "1.2.3",
    },
)
```"�
�
layer_from_tar�Creates a container image layer from an existing tar archive.

This rule converts tar files into container image layers, useful for incorporating
pre-built artifacts, third-party distributions, or legacy build outputs.

The rule can:
- Use tar files as-is or recompress them
- Optimize tar contents by deduplicating files
- Add annotations to the layer metadata

Example:

```python
load("@rules_img//img:layer.bzl", "layer_from_tar")

# Use an existing tar file as a layer
layer_from_tar(
    name = "third_party_layer",
    src = "@third_party_lib//:lib.tar.gz",
)

# Optimize and recompress
layer_from_tar(
    name = "optimized_layer",
    src = "//legacy:build_output.tar",
    optimize = True,  # Deduplicate contents
    compress = "zstd",  # Use zstd compression
)

# Add metadata annotations
layer_from_tar(
    name = "annotated_layer",
    src = "//vendor:dependencies.tar.gz",
    annotations = {
        "org.opencontainers.image.title": "Vendor Dependencies",
        "org.opencontainers.image.version": "1.2.3",
    },
)
```*
nameA unique name for this target. b
srcWThe tar file to convert into a layer. Must be a valid tar file (optionally compressed). �
compresswCompression algorithm to use. If set to 'auto', it keeps the existing compression, unless the layer is being optimized.2"auto"J"auto"J"gzip"J"zstd"J"none"�
optimize�If set, rewrites the tar file to deduplicate it's contents.
This is useful for reducing the size of the image, but will take extra time and space to store the optimized layer.2False�
estargz�Whether to use estargz format. If set to 'auto', uses the global default estargz setting.
When enabled, the layer will be optimized for lazy pulling and will be compatible with the estargz format.2"auto"J"auto"J	"enabled"J
"disabled"Q
annotations<Annotations to add to the layer metadata as key-value pairs.
2{}y

media_typeeOverride layer media type. Use e.g. "application/vnd.cncf.helm.chart.content.v1.tar" for Helm charts.2"""<
layer_from_tar*@rules_img//img/private:layer_from_tar.bzl*M

LayersInfo?

LayersInfo1@rules_img//img/private/providers:layers_info.bzl,
*
nameA unique name for this target. d
b
srcWThe tar file to convert into a layer. Must be a valid tar file (optionally compressed). �
�
compresswCompression algorithm to use. If set to 'auto', it keeps the existing compression, unless the layer is being optimized.2"auto"J"auto"J"gzip"J"zstd"J"none"�
�
optimize�If set, rewrites the tar file to deduplicate it's contents.
This is useful for reducing the size of the image, but will take extra time and space to store the optimized layer.2False�
�
estargz�Whether to use estargz format. If set to 'auto', uses the global default estargz setting.
When enabled, the layer will be optimized for lazy pulling and will be compatible with the estargz format.2"auto"J"auto"J	"enabled"J
"disabled"S
Q
annotations<Annotations to add to the layer metadata as key-value pairs.
2{}{
y

media_typeeOverride layer media type. Use e.g. "application/vnd.cncf.helm.chart.content.v1.tar" for Helm charts.2""�file_metadata�Creates a JSON-encoded file metadata string for use with image_layer rules.

This function generates JSON metadata that can be used to customize file attributes
in container image layers, such as permissions, ownership, and timestamps.
*�

�
file_metadataK
mode;File permission mode (e.g., "0755", "0644"). String format.None(2
uid#User ID of the file owner. Integer.None(3
gid$Group ID of the file owner. Integer.None(5
uname$User name of the file owner. String.None(6
gname%Group name of the file owner. String.None(\
mtimeKModification time in RFC3339 format (e.g., "2023-01-01T00:00:00Z"). String.None(J
pax_records3Dict of extended attributes to set via PAX records.None(�Creates a JSON-encoded file metadata string for use with image_layer rules.

This function generates JSON metadata that can be used to customize file attributes
in container image layers, such as permissions, ownership, and timestamps.
"3
1JSON-encoded string containing the file metadata.2:
file_metadata)@rules_img//img/private:file_metadata.bzlM
K
mode;File permission mode (e.g., "0755", "0644"). String format.None(4
2
uid#User ID of the file owner. Integer.None(5
3
gid$Group ID of the file owner. Integer.None(7
5
uname$User name of the file owner. String.None(8
6
gname%Group name of the file owner. String.None(^
\
mtimeKModification time in RFC3339 format (e.g., "2023-01-01T00:00:00Z"). String.None(L
J
pax_records3Dict of extended attributes to set via PAX records.None(+Public API for container image layer rules.��

	rules_imgimgload.bzl�o
image_load�Loads container images into a local daemon (Docker, containerd, or Podman).

This rule creates an executable target that imports OCI images into your local
container runtime. It supports Docker, Podman, and containerd, with intelligent
detection of the best loading method for optimal performance.

Key features:
- **Incremental loading**: Skips blobs that already exist in the daemon
- **Multi-platform support**: Can load entire image indexes or specific platforms
- **Direct containerd integration**: Bypasses Docker for faster imports when possible
- **Platform filtering**: Use `--platform` flag at runtime to select specific platforms

The rule produces an executable that can be run with `bazel run`.

Output groups:
- `tarball`: "docker save" compatible tarball with OCI layout (available for both single and multi-platform images).
  For multi-platform images, the first manifest is used as the default in `manifest.json`,
  and all manifests are included in `index.json`.

Example:

```python
load("@rules_img//img:load.bzl", "image_load")

# Load a single-platform image with a single tag
image_load(
    name = "load_app",
    image = ":my_app",  # References an image_manifest
    tag = "my-app:latest",
)

# Load with multiple tags
image_load(
    name = "load_multi",
    image = ":my_app",
    tag_list = ["my-app:latest", "my-app:v1.0.0", "my-app:stable"],
)

# Load a multi-platform image
image_load(
    name = "load_multiarch",
    image = ":my_app_index",  # References an image_index
    tag = "my-app:latest",
    daemon = "containerd",  # Explicitly use containerd
)

# Load with dynamic tagging
image_load(
    name = "load_dynamic",
    image = ":my_app",
    tag = "my-app:{{.BUILD_USER}}",  # Template expansion
    build_settings = {
        "BUILD_USER": "//settings:username",
    },
)
```

Runtime usage:
```bash
# Load all platforms
bazel run //path/to:load_app

# Load specific platform only
bazel run //path/to:load_multiarch -- --platform linux/arm64

# Build Docker save tarball
bazel build //path/to:load_app --output_groups=tarball
```

Performance notes:
- When Docker uses containerd storage (Docker 23.0+), images are loaded directly
  into containerd for better performance if the containerd socket is accessible.
- For older Docker versions, falls back to `docker load` which requires building
  a tar file (slower and limited to single-platform images)
- The `--platform` flag filters which platforms are loaded from multi-platform images"�\
�7

image_load�Loads container images into a local daemon (Docker, containerd, or Podman).

This rule creates an executable target that imports OCI images into your local
container runtime. It supports Docker, Podman, and containerd, with intelligent
detection of the best loading method for optimal performance.

Key features:
- **Incremental loading**: Skips blobs that already exist in the daemon
- **Multi-platform support**: Can load entire image indexes or specific platforms
- **Direct containerd integration**: Bypasses Docker for faster imports when possible
- **Platform filtering**: Use `--platform` flag at runtime to select specific platforms

The rule produces an executable that can be run with `bazel run`.

Output groups:
- `tarball`: "docker save" compatible tarball with OCI layout (available for both single and multi-platform images).
  For multi-platform images, the first manifest is used as the default in `manifest.json`,
  and all manifests are included in `index.json`.

Example:

```python
load("@rules_img//img:load.bzl", "image_load")

# Load a single-platform image with a single tag
image_load(
    name = "load_app",
    image = ":my_app",  # References an image_manifest
    tag = "my-app:latest",
)

# Load with multiple tags
image_load(
    name = "load_multi",
    image = ":my_app",
    tag_list = ["my-app:latest", "my-app:v1.0.0", "my-app:stable"],
)

# Load a multi-platform image
image_load(
    name = "load_multiarch",
    image = ":my_app_index",  # References an image_index
    tag = "my-app:latest",
    daemon = "containerd",  # Explicitly use containerd
)

# Load with dynamic tagging
image_load(
    name = "load_dynamic",
    image = ":my_app",
    tag = "my-app:{{.BUILD_USER}}",  # Template expansion
    build_settings = {
        "BUILD_USER": "//settings:username",
    },
)
```

Runtime usage:
```bash
# Load all platforms
bazel run //path/to:load_app

# Load specific platform only
bazel run //path/to:load_multiarch -- --platform linux/arm64

# Build Docker save tarball
bazel build //path/to:load_app --output_groups=tarball
```

Performance notes:
- When Docker uses containerd storage (Docker 23.0+), images are loaded directly
  into containerd for better performance if the containerd socket is accessible.
- For older Docker versions, falls back to `docker load` which requires building
  a tar file (slower and limited to single-platform images)
- The `--platform` flag filters which platforms are loaded from multi-platform images*
nameA unique name for this target. �	
daemon�	Container daemon to use for loading the image.

Available options:
- **`auto`** (default): Uses the global default setting (usually `docker`)
- **`containerd`**: Loads directly into containerd namespace. Supports multi-platform images
  and incremental loading.
- **`docker`**: Loads via Docker daemon. When Docker uses containerd storage (23.0+),
  loads directly into containerd. Otherwise falls back to `docker load` command which
  is slower and limited to single-platform images.
- **`podman`**: Loads via Podman daemon using `podman load` command. Similar to Docker
  fallback mode, this is slower than containerd and limited to single-platform images.
- **`generic`**: Loads via a custom container runtime. The loader will invoke the command
  specified in the `LOADER_BINARY` environment variable with the `load` subcommand. For example,
  if `LOADER_BINARY=nerdctl`, it will run `nerdctl load`. Limited to single-platform images.
  Requires `LOADER_BINARY` to be set at runtime.

The best performance is achieved with:
- Direct containerd access (daemon = "containerd")
- Docker 23.0+ with containerd storage enabled and accessible containerd socket2"auto"J"auto"J"docker"J"containerd"J"podman"J	"generic"�
tag�Tag to apply when loading the image.

Optional - if omitted, the image is loaded without a tag.

Subject to [template expansion](/docs/templating.md).2""�
tag_list�List of tags to apply when loading the image.

Useful for applying multiple tags in a single load:

```python
tag_list = ["latest", "v1.0.0", "stable"]
```

Cannot be used together with `tag`. Can be combined with `tag_file` to merge tags from both sources.
Each tag is subject to [template expansion](/docs/templating.md).2[]�
tag_file�File containing newline-delimited tags to apply when loading the image.

The file should contain one tag per line. Empty lines are ignored. Tags from this file
are merged with tags specified via `tag` or `tag_list` attributes.

Example file content:
```
latest
v1.0.0
stable
```

Can be combined with `tag` or `tag_list` to merge tags from multiple sources.
Each tag is subject to [template expansion](/docs/templating.md).2None�
strategy�Strategy for handling image layers during load.

Available strategies:
- **`auto`** (default): Uses the global default load strategy
- **`eager`**: Downloads all layers during the build phase. Ensures all layers are
  available locally before running the load command.
- **`lazy`**: Downloads layers only when needed during the load operation. More
  efficient for large images where some layers might already exist in the daemon.2"auto"J"auto"J"eager"J"lazy"�
build_settings�Build settings for template expansion.

Maps template variable names to string_flag targets. These values can be used in
tag attributes using `{{.VARIABLE_NAME}}` syntax (Go template).

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"J"auto"J"force"J
"disabled"O
imageBImage to load. Should provide ImageManifestInfo or ImageIndexInfo. �
tool_cfg�**Experimental**: This attribute may be removed if we find a way to automatically select the correct loader platform based on the context of use.
Configuration of the loader executable. By default, the loader executable is always chosen for the host platform, regardless of the value of `--platforms`. Setting this attribute to 'target' makes the loader match the target platform instead.
The `"target"` option is useful when the "image_load" target is used as a data dependency of an integration test.

Available options:
- **`host`** (default): Loader executable matches the host platform.
- **`target`**: Loader executable matches the target platform(s) specified via `--platforms`.2"host"J"host"J"target"�
deploy_tool�Optional label of a deploy tool target providing `DeployToolInfo` (created with `img_deploy_tool` from `@rules_img//img:deploy_tool.bzl`). When set, overrides `tool_cfg`.*Z
DeployToolInfoH
DeployToolInfo6@rules_img//img/private/providers:deploy_tool_info.bzl2None".

image_load @rules_img//img/private:load.bzl8,
*
nameA unique name for this target. �	
�	
daemon�	Container daemon to use for loading the image.

Available options:
- **`auto`** (default): Uses the global default setting (usually `docker`)
- **`containerd`**: Loads directly into containerd namespace. Supports multi-platform images
  and incremental loading.
- **`docker`**: Loads via Docker daemon. When Docker uses containerd storage (23.0+),
  loads directly into containerd. Otherwise falls back to `docker load` command which
  is slower and limited to single-platform images.
- **`podman`**: Loads via Podman daemon using `podman load` command. Similar to Docker
  fallback mode, this is slower than containerd and limited to single-platform images.
- **`generic`**: Loads via a custom container runtime. The loader will invoke the command
  specified in the `LOADER_BINARY` environment variable with the `load` subcommand. For example,
  if `LOADER_BINARY=nerdctl`, it will run `nerdctl load`. Limited to single-platform images.
  Requires `LOADER_BINARY` to be set at runtime.

The best performance is achieved with:
- Direct containerd access (daemon = "containerd")
- Docker 23.0+ with containerd storage enabled and accessible containerd socket2"auto"J"auto"J"docker"J"containerd"J"podman"J	"generic"�
�
tag�Tag to apply when loading the image.

Optional - if omitted, the image is loaded without a tag.

Subject to [template expansion](/docs/templating.md).2""�
�
tag_list�List of tags to apply when loading the image.

Useful for applying multiple tags in a single load:

```python
tag_list = ["latest", "v1.0.0", "stable"]
```

Cannot be used together with `tag`. Can be combined with `tag_file` to merge tags from both sources.
Each tag is subject to [template expansion](/docs/templating.md).2[]�
�
tag_file�File containing newline-delimited tags to apply when loading the image.

The file should contain one tag per line. Empty lines are ignored. Tags from this file
are merged with tags specified via `tag` or `tag_list` attributes.

Example file content:
```
latest
v1.0.0
stable
```

Can be combined with `tag` or `tag_list` to merge tags from multiple sources.
Each tag is subject to [template expansion](/docs/templating.md).2None�
�
strategy�Strategy for handling image layers during load.

Available strategies:
- **`auto`** (default): Uses the global default load strategy
- **`eager`**: Downloads all layers during the build phase. Ensures all layers are
  available locally before running the load command.
- **`lazy`**: Downloads layers only when needed during the load operation. More
  efficient for large images where some layers might already exist in the daemon.2"auto"J"auto"J"eager"J"lazy"�
�
build_settings�Build settings for template expansion.

Maps template variable names to string_flag targets. These values can be used in
tag attributes using `{{.VARIABLE_NAME}}` syntax (Go template).

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"J"auto"J"force"J
"disabled"Q
O
imageBImage to load. Should provide ImageManifestInfo or ImageIndexInfo. �
�
tool_cfg�**Experimental**: This attribute may be removed if we find a way to automatically select the correct loader platform based on the context of use.
Configuration of the loader executable. By default, the loader executable is always chosen for the host platform, regardless of the value of `--platforms`. Setting this attribute to 'target' makes the loader match the target platform instead.
The `"target"` option is useful when the "image_load" target is used as a data dependency of an integration test.

Available options:
- **`host`** (default): Loader executable matches the host platform.
- **`target`**: Loader executable matches the target platform(s) specified via `--platforms`.2"host"J"host"J"target"�
�
deploy_tool�Optional label of a deploy tool target providing `DeployToolInfo` (created with `img_deploy_tool` from `@rules_img//img:deploy_tool.bzl`). When set, overrides `tool_cfg`.*Z
DeployToolInfoH
DeployToolInfo6@rules_img//img/private/providers:deploy_tool_info.bzl2None�Nimage_load_spec�
Defines load configuration for container images without referencing a specific image.

This rule captures daemon, tag, and strategy settings that can be attached to
`image_manifest` or `image_index` targets via their `load_specs` attribute.
Template strings using Go template syntax (`{{.VAR}}`) are accepted but not
expanded — expansion happens when the deployment is consumed by the image rule.
Note that the template strings `{{.image_target_package}}` and `{{.image_target_name}}` are especially useful here.

This enables an inverted dependency pattern: instead of `image_load` depending
on the image, the image itself carries its load configuration, making it
directly usable with `multi_deploy`.

Example:

```python
load("@rules_img//img:load.bzl", "image_load_spec")

image_load_spec(
    name = "load_config",
    tag = "{{.image_target_package}}/{{.image_target_name}}:latest",
    daemon = "containerd",
)

# Attach to an image:
image_manifest(
    name = "my_app_a",
    base = "@distroless_cc",
    layers = [":app_layer"],
    load_specs = [":load_config"],
)

# Attach to another image:
image_manifest(
    name = "my_app_b",
    base = "@distroless_cc",
    layers = [":app_layer"],
    load_specs = [":load_config"],
)

# Now usable directly in multi_deploy:
multi_deploy(
    name = "deploy",
    operations = [
        ":my_app_a",
        ":my_app_b",
    ],
)
```"�C
�'
image_load_spec�
Defines load configuration for container images without referencing a specific image.

This rule captures daemon, tag, and strategy settings that can be attached to
`image_manifest` or `image_index` targets via their `load_specs` attribute.
Template strings using Go template syntax (`{{.VAR}}`) are accepted but not
expanded — expansion happens when the deployment is consumed by the image rule.
Note that the template strings `{{.image_target_package}}` and `{{.image_target_name}}` are especially useful here.

This enables an inverted dependency pattern: instead of `image_load` depending
on the image, the image itself carries its load configuration, making it
directly usable with `multi_deploy`.

Example:

```python
load("@rules_img//img:load.bzl", "image_load_spec")

image_load_spec(
    name = "load_config",
    tag = "{{.image_target_package}}/{{.image_target_name}}:latest",
    daemon = "containerd",
)

# Attach to an image:
image_manifest(
    name = "my_app_a",
    base = "@distroless_cc",
    layers = [":app_layer"],
    load_specs = [":load_config"],
)

# Attach to another image:
image_manifest(
    name = "my_app_b",
    base = "@distroless_cc",
    layers = [":app_layer"],
    load_specs = [":load_config"],
)

# Now usable directly in multi_deploy:
multi_deploy(
    name = "deploy",
    operations = [
        ":my_app_a",
        ":my_app_b",
    ],
)
```*
nameA unique name for this target. �	
daemon�	Container daemon to use for loading the image.

Available options:
- **`auto`** (default): Uses the global default setting (usually `docker`)
- **`containerd`**: Loads directly into containerd namespace. Supports multi-platform images
  and incremental loading.
- **`docker`**: Loads via Docker daemon. When Docker uses containerd storage (23.0+),
  loads directly into containerd. Otherwise falls back to `docker load` command which
  is slower and limited to single-platform images.
- **`podman`**: Loads via Podman daemon using `podman load` command. Similar to Docker
  fallback mode, this is slower than containerd and limited to single-platform images.
- **`generic`**: Loads via a custom container runtime. The loader will invoke the command
  specified in the `LOADER_BINARY` environment variable with the `load` subcommand. For example,
  if `LOADER_BINARY=nerdctl`, it will run `nerdctl load`. Limited to single-platform images.
  Requires `LOADER_BINARY` to be set at runtime.

The best performance is achieved with:
- Direct containerd access (daemon = "containerd")
- Docker 23.0+ with containerd storage enabled and accessible containerd socket2"auto"J"auto"J"docker"J"containerd"J"podman"J	"generic"�
tag�Tag to apply when loading the image.

Optional - if omitted, the image is loaded without a tag.

Subject to [template expansion](/docs/templating.md).2""�
tag_list�List of tags to apply when loading the image.

Useful for applying multiple tags in a single load:

```python
tag_list = ["latest", "v1.0.0", "stable"]
```

Cannot be used together with `tag`. Can be combined with `tag_file` to merge tags from both sources.
Each tag is subject to [template expansion](/docs/templating.md).2[]�
tag_file�File containing newline-delimited tags to apply when loading the image.

The file should contain one tag per line. Empty lines are ignored. Tags from this file
are merged with tags specified via `tag` or `tag_list` attributes.

Example file content:
```
latest
v1.0.0
stable
```

Can be combined with `tag` or `tag_list` to merge tags from multiple sources.
Each tag is subject to [template expansion](/docs/templating.md).2None�
strategy�Strategy for handling image layers during load.

Available strategies:
- **`auto`** (default): Uses the global default load strategy
- **`eager`**: Downloads all layers during the build phase. Ensures all layers are
  available locally before running the load command.
- **`lazy`**: Downloads layers only when needed during the load operation. More
  efficient for large images where some layers might already exist in the daemon.2"auto"J"auto"J"eager"J"lazy"�
build_settings�Build settings for template expansion.

Maps template variable names to string_flag targets. These values can be used in
tag attributes using `{{.VARIABLE_NAME}}` syntax (Go template).

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"J"auto"J"force"J
"disabled""8
image_load_spec%@rules_img//img/private:load_spec.bzl*Z
LoadConfigInfoH
LoadConfigInfo6@rules_img//img/private/providers:load_config_info.bzl,
*
nameA unique name for this target. �	
�	
daemon�	Container daemon to use for loading the image.

Available options:
- **`auto`** (default): Uses the global default setting (usually `docker`)
- **`containerd`**: Loads directly into containerd namespace. Supports multi-platform images
  and incremental loading.
- **`docker`**: Loads via Docker daemon. When Docker uses containerd storage (23.0+),
  loads directly into containerd. Otherwise falls back to `docker load` command which
  is slower and limited to single-platform images.
- **`podman`**: Loads via Podman daemon using `podman load` command. Similar to Docker
  fallback mode, this is slower than containerd and limited to single-platform images.
- **`generic`**: Loads via a custom container runtime. The loader will invoke the command
  specified in the `LOADER_BINARY` environment variable with the `load` subcommand. For example,
  if `LOADER_BINARY=nerdctl`, it will run `nerdctl load`. Limited to single-platform images.
  Requires `LOADER_BINARY` to be set at runtime.

The best performance is achieved with:
- Direct containerd access (daemon = "containerd")
- Docker 23.0+ with containerd storage enabled and accessible containerd socket2"auto"J"auto"J"docker"J"containerd"J"podman"J	"generic"�
�
tag�Tag to apply when loading the image.

Optional - if omitted, the image is loaded without a tag.

Subject to [template expansion](/docs/templating.md).2""�
�
tag_list�List of tags to apply when loading the image.

Useful for applying multiple tags in a single load:

```python
tag_list = ["latest", "v1.0.0", "stable"]
```

Cannot be used together with `tag`. Can be combined with `tag_file` to merge tags from both sources.
Each tag is subject to [template expansion](/docs/templating.md).2[]�
�
tag_file�File containing newline-delimited tags to apply when loading the image.

The file should contain one tag per line. Empty lines are ignored. Tags from this file
are merged with tags specified via `tag` or `tag_list` attributes.

Example file content:
```
latest
v1.0.0
stable
```

Can be combined with `tag` or `tag_list` to merge tags from multiple sources.
Each tag is subject to [template expansion](/docs/templating.md).2None�
�
strategy�Strategy for handling image layers during load.

Available strategies:
- **`auto`** (default): Uses the global default load strategy
- **`eager`**: Downloads all layers during the build phase. Ensures all layers are
  available locally before running the load command.
- **`lazy`**: Downloads layers only when needed during the load operation. More
  efficient for large images where some layers might already exist in the daemon.2"auto"J"auto"J"eager"J"lazy"�
�
build_settings�Build settings for template expansion.

Maps template variable names to string_flag targets. These values can be used in
tag attributes using `{{.VARIABLE_NAME}}` syntax (Go template).

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"J"auto"J"force"J
"disabled"�
Public API for loading container images into a daemon.

The `image_load` rule creates an executable target that loads container images into a local daemon (containerd, Docker, or Podman).

## Example

```python
load("@rules_img//img:image.bzl", "image_manifest")
load("@rules_img//img:load.bzl", "image_load")
load("@rules_img//img:layer.bzl", "image_layer")

# Create a simple layer
image_layer(
    name = "app_layer",
    srcs = {
        "/app/hello.txt": "hello.txt",
    },
)

# Build an image
image_manifest(
    name = "my_image",
    base = "@alpine",
    layers = [":app_layer"],
)

# Create a load target with a single tag
image_load(
    name = "load",
    image = ":my_image",
    tag = "my-app:latest",
)

# Load with multiple tags
image_load(
    name = "load_multi",
    image = ":my_image",
    tag_list = ["my-app:latest", "my-app:v1.0.0"],
)
```

Then run:
```bash
# Load the image into your local daemon
bazel run //:load
```

## Platform Selection

When running the load target, you can use the `--platform` flag to filter which platforms to load from multi-platform images:

```bash
# Load all platforms (default)
bazel run //path/to:load_target

# Load only linux/amd64
bazel run //path/to:load_target -- --platform linux/amd64
```

**Note**: Docker daemon only supports loading a single platform at a time. If multiple platforms are specified with Docker, an error will be returned.�.
"
	rules_imgimgmulti_deploy.bzl�-multi_deploy�Deploys multiple container images in a single coordinated command.

Use `push_specs` and `load_specs` on your image targets to attach deployment
configuration directly, then reference the images in `operations`:

```python
load("@rules_img//img:image.bzl", "image_manifest")
load("@rules_img//img:push.bzl", "image_push_spec")
load("@rules_img//img:multi_deploy.bzl", "multi_deploy")

image_push_spec(
    name = "push_spec",
    registry = "gcr.io",
    repository = "my-project/{{.image_target_name}}",
    tag = "latest",
)

image_manifest(
    name = "frontend",
    base = "@distroless_cc",
    layers = [":frontend_layer"],
    push_specs = [":push_spec"],
)

image_manifest(
    name = "backend",
    base = "@distroless_cc",
    layers = [":backend_layer"],
    push_specs = [":push_spec"],
)

multi_deploy(
    name = "deploy_all",
    operations = [
        ":frontend",
        ":backend",
    ],
)
```

Alternatively, standalone `image_push` or `image_load` targets that already
provide `DeployInfo` can be used directly in `operations`.

Runtime usage:
```bash
bazel run //path/to:deploy_all
```"�$
�
multi_deploy�Deploys multiple container images in a single coordinated command.

Use `push_specs` and `load_specs` on your image targets to attach deployment
configuration directly, then reference the images in `operations`:

```python
load("@rules_img//img:image.bzl", "image_manifest")
load("@rules_img//img:push.bzl", "image_push_spec")
load("@rules_img//img:multi_deploy.bzl", "multi_deploy")

image_push_spec(
    name = "push_spec",
    registry = "gcr.io",
    repository = "my-project/{{.image_target_name}}",
    tag = "latest",
)

image_manifest(
    name = "frontend",
    base = "@distroless_cc",
    layers = [":frontend_layer"],
    push_specs = [":push_spec"],
)

image_manifest(
    name = "backend",
    base = "@distroless_cc",
    layers = [":backend_layer"],
    push_specs = [":push_spec"],
)

multi_deploy(
    name = "deploy_all",
    operations = [
        ":frontend",
        ":backend",
    ],
)
```

Alternatively, standalone `image_push` or `image_load` targets that already
provide `DeployInfo` can be used directly in `operations`.

Runtime usage:
```bash
bazel run //path/to:deploy_all
```*
nameA unique name for this target. �

operations�List of operations to deploy together.

Each operation must provide DeployInfo (typically from image_push, image_load,
image_manifest with push_specs/load_specs, or image_index with push_specs/load_specs).
All operations will be merged and executed in the order specified. *M

DeployInfo?

DeployInfo1@rules_img//img/private/providers:deploy_info.bzl*]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl*T
ImageIndexInfoB
ImageIndexInfo0@rules_img//img/private/providers:index_info.bzl�
push_strategy�Push strategy to use for all push operations in the deployment.

See [push strategies documentation](/docs/push-strategies.md) for detailed information.2"auto"J"auto"J"eager"J"lazy"J"cas_registry"J"bes"�
load_strategy�Load strategy to use for all load operations in the deployment.

Available strategies:
- **`auto`** (default): Uses the global default load strategy
- **`eager`**: Downloads all layers during the build phase
- **`lazy`**: Downloads layers only when needed during the load operation2"auto"J"auto"J"eager"J"lazy"�
tool_cfg�Configuration of the deployer executable platform.

Available options:
- **`host`** (default): Deployer executable matches the host platform.
- **`target`**: Deployer executable matches the target platform(s) specified via `--platforms`.2"host"J"host"J"target"�
deploy_tool�Optional label of a deploy tool target providing `DeployToolInfo` (created with `img_deploy_tool` from `@rules_img//img:deploy_tool.bzl`). When set, overrides `tool_cfg`.*Z
DeployToolInfoH
DeployToolInfo6@rules_img//img/private/providers:deploy_tool_info.bzl2None"8
multi_deploy(@rules_img//img/private:multi_deploy.bzl8,
*
nameA unique name for this target. �
�

operations�List of operations to deploy together.

Each operation must provide DeployInfo (typically from image_push, image_load,
image_manifest with push_specs/load_specs, or image_index with push_specs/load_specs).
All operations will be merged and executed in the order specified. *M

DeployInfo?

DeployInfo1@rules_img//img/private/providers:deploy_info.bzl*]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl*T
ImageIndexInfoB
ImageIndexInfo0@rules_img//img/private/providers:index_info.bzl�
�
push_strategy�Push strategy to use for all push operations in the deployment.

See [push strategies documentation](/docs/push-strategies.md) for detailed information.2"auto"J"auto"J"eager"J"lazy"J"cas_registry"J"bes"�
�
load_strategy�Load strategy to use for all load operations in the deployment.

Available strategies:
- **`auto`** (default): Uses the global default load strategy
- **`eager`**: Downloads all layers during the build phase
- **`lazy`**: Downloads layers only when needed during the load operation2"auto"J"auto"J"eager"J"lazy"�
�
tool_cfg�Configuration of the deployer executable platform.

Available options:
- **`host`** (default): Deployer executable matches the host platform.
- **`target`**: Deployer executable matches the target platform(s) specified via `--platforms`.2"host"J"host"J"target"�
�
deploy_tool�Optional label of a deploy tool target providing `DeployToolInfo` (created with `img_deploy_tool` from `@rules_img//img:deploy_tool.bzl`). When set, overrides `tool_cfg`.*Z
DeployToolInfoH
DeployToolInfo6@rules_img//img/private/providers:deploy_tool_info.bzl2None1Public API for container image multi deploy rule.�w

	rules_imgimgoras.bzl�*oras_file_layer�Creates an ORAS-compatible layer from a single file.

This macro wraps `layer_from_file` and adds standard ORAS annotations so the
resulting layer can be pushed to and pulled from OCI registries using ORAS
tooling. The `org.opencontainers.image.title` annotation is automatically
set to the base name of the source file (or overridden via the `title` attr).

Two modes are supported via the `kind` attribute:

- `"file"` (default): The source file is used as an opaque blob.
- `"directory"`: The source file is treated as a tar archive. ORAS clients
  will unpack it on pull. The `io.deis.oras.content.unpack` and
  `io.deis.oras.content.digest` annotations are set automatically.

Example:

```python
load("@rules_img//img:oras.bzl", "oras_file_layer")

# Push a single file as an ORAS artifact
oras_file_layer(
    name = "readme_layer",
    src = "README.md",
    media_type = "text/plain",
)

# Push a tar archive that ORAS clients will unpack
oras_file_layer(
    name = "docs_layer",
    src = ":docs.tar.gz",
    kind = "directory",
)
```Z�"
�
oras_file_layer�Creates an ORAS-compatible layer from a single file.

This macro wraps `layer_from_file` and adds standard ORAS annotations so the
resulting layer can be pushed to and pulled from OCI registries using ORAS
tooling. The `org.opencontainers.image.title` annotation is automatically
set to the base name of the source file (or overridden via the `title` attr).

Two modes are supported via the `kind` attribute:

- `"file"` (default): The source file is used as an opaque blob.
- `"directory"`: The source file is treated as a tar archive. ORAS clients
  will unpack it on pull. The `io.deis.oras.content.unpack` and
  `io.deis.oras.content.digest` annotations are set automatically.

Example:

```python
load("@rules_img//img:oras.bzl", "oras_file_layer")

# Push a single file as an ORAS artifact
oras_file_layer(
    name = "readme_layer",
    src = "README.md",
    media_type = "text/plain",
)

# Push a tar archive that ORAS clients will unpack
oras_file_layer(
    name = "docs_layer",
    src = ":docs.tar.gz",
    kind = "directory",
)
```�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@�
titleyOptional override for org.opencontainers.image.title. If left empty, the title is derived from the base name of the blob.2""8�
kind|The kind of layer. "file" interprets the layer as-is, "directory" interprets the layer blob as a tar file containing a tree.2"file"8J"file"J"directory"S
annotations<Annotations to add to the layer metadata as key-value pairs.
2{}8
expect_failure2None@ 
transitive_configs2None8@
deprecation2None8@
tags2None8@
testonly2None8@
features2None@
compatible_with2None8@
restricted_to2None8@
package_metadata2None8@
aspect_hints2None@P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@
exec_properties
2None@"
exec_compatible_with2None8@(
exec_group_compatible_with2None8@Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@+
src The file to use as a layer blob. h

media_typeRLayer media type. Defaults to "application/vnd.oci.image.layer.v1.tar" if not set.2None">
oras_file_layer+@rules_img//img/private:oras_file_layer.bzl�
�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �
�

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@�
�
titleyOptional override for org.opencontainers.image.title. If left empty, the title is derived from the base name of the blob.2""8�
�
kind|The kind of layer. "file" interprets the layer as-is, "directory" interprets the layer blob as a tar file containing a tree.2"file"8J"file"J"directory"U
S
annotations<Annotations to add to the layer metadata as key-value pairs.
2{}8

expect_failure2None@"
 
transitive_configs2None8@

deprecation2None8@

tags2None8@

testonly2None8@

features2None@

compatible_with2None8@

restricted_to2None8@ 

package_metadata2None8@

aspect_hints2None@R
P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@

exec_properties
2None@$
"
exec_compatible_with2None8@*
(
exec_group_compatible_with2None8@\
Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@-
+
src The file to use as a layer blob. j
h

media_typeRLayer media type. Defaults to "application/vnd.oci.image.layer.v1.tar" if not set.2None�K
oras_layer�Creates an ORAS-compatible layer from files and directories.

This macro wraps `image_layer` and adds standard ORAS annotations so the
resulting layer can be pushed to and pulled from OCI registries using ORAS
tooling:

- `org.opencontainers.image.title` is set to the `title` attribute (defaults
  to the target name).
- `io.deis.oras.content.unpack` is set to `"true"` so ORAS clients unpack the
  layer on pull.
- `io.deis.oras.content.digest` is automatically derived from the layer's diff
  ID after the tar is produced.

Example:

```python
load("@rules_img//img:oras.bzl", "oras_layer")

# Package application files as an ORAS artifact
oras_layer(
    name = "app_layer",
    srcs = {
        "/app/bin/server": "//cmd/server",
        "/app/config.json": ":config",
    },
)
```Z�E
�%

oras_layer�Creates an ORAS-compatible layer from files and directories.

This macro wraps `image_layer` and adds standard ORAS annotations so the
resulting layer can be pushed to and pulled from OCI registries using ORAS
tooling:

- `org.opencontainers.image.title` is set to the `title` attribute (defaults
  to the target name).
- `io.deis.oras.content.unpack` is set to `"true"` so ORAS clients unpack the
  layer on pull.
- `io.deis.oras.content.digest` is automatically derived from the layer's diff
  ID after the tar is produced.

Example:

```python
load("@rules_img//img:oras.bzl", "oras_layer")

# Package application files as an ORAS artifact
oras_layer(
    name = "app_layer",
    srcs = {
        "/app/bin/server": "//cmd/server",
        "/app/config.json": ":config",
    },
)
```�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@}
titlelOptional value for org.opencontainers.image.title. If left empty, the title is derived from the target name.2""8S
annotations<Annotations to add to the layer metadata as key-value pairs.
2{}8
expect_failure2None@ 
transitive_configs2None8@
deprecation2None8@
tags2None8@
testonly2None8@
features2None@
compatible_with2None8@
restricted_to2None8@
package_metadata2None8@
aspect_hints2None@P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@
exec_properties
2None@"
exec_compatible_with2None8@(
exec_group_compatible_with2None8@Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@�
srcs�Files to include in the layer. Keys are paths in the image (e.g., "/app/bin/server"),
values are labels to files or executables. Executables automatically include their runfiles unless include_runfiles is set to False.2None
symlinkskSymlinks to create in the layer. Keys are symlink paths in the image,
values are the targets they point to.
2None�
default_metadata�JSON-encoded default metadata to apply to all files in the layer.
Can include fields like mode, uid, gid, uname, gname, mtime, and pax_records.2None�
file_metadata�Per-file metadata overrides as a dict mapping file paths to JSON-encoded metadata.
The path should match the path in the image (the key in srcs attribute).
Metadata specified here overrides any defaults from default_metadata.
2None�
compress\Compression algorithm to use. If set to 'auto', uses the global default compression setting.2NoneJ"auto"J"gzip"J"zstd"�
estargz�Whether to use estargz format. If set to 'auto', uses the global default estargz setting.
When enabled, the layer will be optimized for lazy pulling and will be compatible with the estargz format.2NoneJ"auto"J	"enabled"J
"disabled"�
create_parent_directories�Whether to automatically create parent directory entries in the tar file for all files.
If set to 'auto', uses the global default create_parent_directories setting.
When enabled, parent directories will be created automatically for all files in the layer.2NoneJ"auto"J	"enabled"J
"disabled"�
tree_artifact_handling�How to handle duplicate tree artifacts (directories) in the layer.
If set to 'full', each tree artifact is stored at its intended path (no deduplication).
If set to 'deduplicate_symlink', duplicate tree artifacts are replaced with symlinks to the first occurrence.
If set to 'auto', uses the global default from --@rules_img//img/settings:layer_tree_artifact_handling.2NoneJ"auto"J"full"J"deduplicate_symlink"�
include_runfiles�Whether to include runfiles for executable targets.
When True (default), executables in srcs will include their runfiles tree.
When False, only the executable file itself is included, without runfiles.2None�
annotations_file�File containing newline-delimited KEY=VALUE annotations for the layer.

The file should contain one annotation per line in KEY=VALUE format. Empty lines are ignored.
Annotations from this file are merged with annotations specified via the `annotations` attribute.

Example file content:
```
version=1.0.0
build.date=2024-01-15
source.url=https://github.com/...
```2None�

media_typejOverride the layer media type. By default, the media type is auto-detected from the compression algorithm.2None"4

oras_layer&@rules_img//img/private:oras_layer.bzl�
�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �
�

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@
}
titlelOptional value for org.opencontainers.image.title. If left empty, the title is derived from the target name.2""8U
S
annotations<Annotations to add to the layer metadata as key-value pairs.
2{}8

expect_failure2None@"
 
transitive_configs2None8@

deprecation2None8@

tags2None8@

testonly2None8@

features2None@

compatible_with2None8@

restricted_to2None8@ 

package_metadata2None8@

aspect_hints2None@R
P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@

exec_properties
2None@$
"
exec_compatible_with2None8@*
(
exec_group_compatible_with2None8@\
Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@�
�
srcs�Files to include in the layer. Keys are paths in the image (e.g., "/app/bin/server"),
values are labels to files or executables. Executables automatically include their runfiles unless include_runfiles is set to False.2None�

symlinkskSymlinks to create in the layer. Keys are symlink paths in the image,
values are the targets they point to.
2None�
�
default_metadata�JSON-encoded default metadata to apply to all files in the layer.
Can include fields like mode, uid, gid, uname, gname, mtime, and pax_records.2None�
�
file_metadata�Per-file metadata overrides as a dict mapping file paths to JSON-encoded metadata.
The path should match the path in the image (the key in srcs attribute).
Metadata specified here overrides any defaults from default_metadata.
2None�
�
compress\Compression algorithm to use. If set to 'auto', uses the global default compression setting.2NoneJ"auto"J"gzip"J"zstd"�
�
estargz�Whether to use estargz format. If set to 'auto', uses the global default estargz setting.
When enabled, the layer will be optimized for lazy pulling and will be compatible with the estargz format.2NoneJ"auto"J	"enabled"J
"disabled"�
�
create_parent_directories�Whether to automatically create parent directory entries in the tar file for all files.
If set to 'auto', uses the global default create_parent_directories setting.
When enabled, parent directories will be created automatically for all files in the layer.2NoneJ"auto"J	"enabled"J
"disabled"�
�
tree_artifact_handling�How to handle duplicate tree artifacts (directories) in the layer.
If set to 'full', each tree artifact is stored at its intended path (no deduplication).
If set to 'deduplicate_symlink', duplicate tree artifacts are replaced with symlinks to the first occurrence.
If set to 'auto', uses the global default from --@rules_img//img/settings:layer_tree_artifact_handling.2NoneJ"auto"J"full"J"deduplicate_symlink"�
�
include_runfiles�Whether to include runfiles for executable targets.
When True (default), executables in srcs will include their runfiles tree.
When False, only the executable file itself is included, without runfiles.2None�
�
annotations_file�File containing newline-delimited KEY=VALUE annotations for the layer.

The file should contain one annotation per line in KEY=VALUE format. Empty lines are ignored.
Annotations from this file are merged with annotations specified via the `annotations` attribute.

Example file content:
```
version=1.0.0
build.date=2024-01-15
source.url=https://github.com/...
```2None�
�

media_typejOverride the layer media type. By default, the media type is auto-detected from the compression algorithm.2None$Public API for container oras rules.�9

	rules_imgimgpull.bzl�9pull�Pulls a container image from a registry using shallow pulling.

This repository rule implements shallow pulling - it only downloads the image manifest
and config, not the actual layer blobs. The layers are downloaded on-demand during
push operations or when explicitly needed. This significantly reduces bandwidth usage
and speeds up builds, especially for large base images.

Example usage in MODULE.bazel:
```starlark
pull = use_repo_rule("@rules_img//img:pull.bzl", "pull")

pull(
    name = "ubuntu",
    digest = "sha256:1e622c5f073b4f6bfad6632f2616c7f59ef256e96fe78bf6a595d1dc4376ac02",
    registry = "index.docker.io",
    repository = "library/ubuntu",
    tag = "24.04",
)
```

The `digest` parameter is recommended for reproducible builds. If omitted, the rule
will resolve the tag to a digest at fetch time and print a warning.R�2
�
pull�Pulls a container image from a registry using shallow pulling.

This repository rule implements shallow pulling - it only downloads the image manifest
and config, not the actual layer blobs. The layers are downloaded on-demand during
push operations or when explicitly needed. This significantly reduces bandwidth usage
and speeds up builds, especially for large base images.

Example usage in MODULE.bazel:
```starlark
pull = use_repo_rule("@rules_img//img:pull.bzl", "pull")

pull(
    name = "ubuntu",
    digest = "sha256:1e622c5f073b4f6bfad6632f2616c7f59ef256e96fe78bf6a595d1dc4376ac02",
    registry = "index.docker.io",
    repository = "library/ubuntu",
    tag = "24.04",
)
```

The `digest` parameter is recommended for reproducible builds. If omitted, the rule
will resolve the tag to a digest at fetch time and print a warning..
name"A unique name for this repository. �
registry�Primary registry to pull from (e.g., "index.docker.io", "gcr.io").

If not specified, defaults to Docker Hub. Can be overridden by entries in registries list.2""�

registries�List of mirror registries to try in order.

These registries will be tried in order before the primary registry. Useful for
corporate environments with registry mirrors or air-gapped setups.2[]�

repository�The image repository within the registry (e.g., "library/ubuntu", "my-project/my-image").

For Docker Hub, official images use "library/" prefix (e.g., "library/ubuntu"). �
tag�The image tag to pull (e.g., "latest", "24.04", "v1.2.3").

While required, it's recommended to also specify a digest for reproducible builds.2""�
digest�The image digest for reproducible pulls (e.g., "sha256:abc123...").

When specified, the image is pulled by digest instead of tag, ensuring reproducible
builds. The digest must be a full SHA256 digest starting with "sha256:".2""�
layer_handling�Strategy for handling image layers.

This attribute controls when and how layer data is fetched from the registry.

**Available strategies:**

* **`shallow`** (default): Layer data is fetched only if needed during push operations,
  but is not available during the build. This is the most efficient option for images
  that are only used as base images for pushing.

* **`eager`**: Layer data is fetched in the repository rule and is always available.
  This ensures layers are accessible in build actions but is inefficient as all layers
  are downloaded regardless of whether they're needed. Use this for base images that
  need to be read or inspected during the build.

* **`lazy`**: Layer data is downloaded in a build action when requested. This provides
  access to layers during builds while avoiding unnecessary downloads, but requires
  network access during the build phase. **EXPERIMENTAL:** Use at your own risk.2	"shallow"J	"shallow"J"eager"J"lazy"�

downloader�The tool to use for downloading manifests and blobs.

**Available options:**

* **`img_tool`** (default): Uses the `img` tool for all downloads.

* **`bazel`**: Uses Bazel's native HTTP capabilities for downloading manifests and blobs.2
"img_tool"J
"img_tool"J"bazel"�
unsafe_allow_tag_without_digest�Allow pulling by tag without specifying a digest.

**WARNING:** This is not recommended for reproducible builds as tags can be moved
to point to different image versions. Only use this when you're managing reproducibility
through other means (e.g., content-based tags).

When enabled, the rule will resolve the tag to a digest at fetch time and use that
digest, but will not fail if no digest is explicitly provided.2False*9
pull1@rules_img//img/private/repository_rules:pull.bzl0
.
name"A unique name for this repository. �
�
registry�Primary registry to pull from (e.g., "index.docker.io", "gcr.io").

If not specified, defaults to Docker Hub. Can be overridden by entries in registries list.2""�
�

registries�List of mirror registries to try in order.

These registries will be tried in order before the primary registry. Useful for
corporate environments with registry mirrors or air-gapped setups.2[]�
�

repository�The image repository within the registry (e.g., "library/ubuntu", "my-project/my-image").

For Docker Hub, official images use "library/" prefix (e.g., "library/ubuntu"). �
�
tag�The image tag to pull (e.g., "latest", "24.04", "v1.2.3").

While required, it's recommended to also specify a digest for reproducible builds.2""�
�
digest�The image digest for reproducible pulls (e.g., "sha256:abc123...").

When specified, the image is pulled by digest instead of tag, ensuring reproducible
builds. The digest must be a full SHA256 digest starting with "sha256:".2""�
�
layer_handling�Strategy for handling image layers.

This attribute controls when and how layer data is fetched from the registry.

**Available strategies:**

* **`shallow`** (default): Layer data is fetched only if needed during push operations,
  but is not available during the build. This is the most efficient option for images
  that are only used as base images for pushing.

* **`eager`**: Layer data is fetched in the repository rule and is always available.
  This ensures layers are accessible in build actions but is inefficient as all layers
  are downloaded regardless of whether they're needed. Use this for base images that
  need to be read or inspected during the build.

* **`lazy`**: Layer data is downloaded in a build action when requested. This provides
  access to layers during builds while avoiding unnecessary downloads, but requires
  network access during the build phase. **EXPERIMENTAL:** Use at your own risk.2	"shallow"J	"shallow"J"eager"J"lazy"�
�

downloader�The tool to use for downloading manifests and blobs.

**Available options:**

* **`img_tool`** (default): Uses the `img` tool for all downloads.

* **`bazel`**: Uses Bazel's native HTTP capabilities for downloading manifests and blobs.2
"img_tool"J
"img_tool"J"bazel"�
�
unsafe_allow_tag_without_digest�Allow pulling by tag without specifying a digest.

**WARNING:** This is not recommended for reproducible builds as tags can be moved
to point to different image versions. Only use this when you're managing reproducibility
through other means (e.g., content-based tags).

When enabled, the rule will resolve the tag to a digest at fetch time and use that
digest, but will not fail if no digest is explicitly provided.2False-Public API for pulling base container images.��

	rules_imgimgpush.bzl��
image_push�Pushes container images to a registry.

This rule creates an executable target that uploads OCI images to container registries.
It supports multiple push strategies optimized for different use cases, from simple
uploads to advanced content-addressable storage integration.

Key features:
- **Multiple push strategies**: Choose between eager, lazy, CAS-based, or BES-integrated pushing
- **Template expansion**: Dynamic registry, repository, and tag values using build settings
- **Stamping support**: Include build information in image tags
- **Incremental uploads**: Skip blobs that already exist in the registry

The rule produces an executable that can be run with `bazel run`.

Example:

```python
load("@rules_img//img:push.bzl", "image_push")

# Simple push to Docker Hub
image_push(
    name = "push_app",
    image = ":my_app",
    registry = "index.docker.io",
    repository = "myorg/myapp",
    tag = "latest",
)

# Push multi-platform image with multiple tags
image_push(
    name = "push_multiarch",
    image = ":my_app_index",  # References an image_index
    registry = "gcr.io",
    repository = "my-project/my-app",
    tag_list = ["latest", "v1.0.0"],
)

# Dynamic push with build settings
image_push(
    name = "push_dynamic",
    image = ":my_app",
    registry = "{{.REGISTRY}}",
    repository = "{{.PROJECT}}/my-app",
    tag = "{{.VERSION}}",
    build_settings = {
        "REGISTRY": "//settings:registry",
        "PROJECT": "//settings:project",
        "VERSION": "//settings:version",
    },
)

# Push with stamping for unique tags
image_push(
    name = "push_stamped",
    image = ":my_app",
    registry = "index.docker.io",
    repository = "myorg/myapp",
    tag = "latest-{{.BUILD_TIMESTAMP}}",
    stamp = "force",
)

# Digest-only push (no tag)
image_push(
    name = "push_by_digest",
    image = ":my_app",
    registry = "gcr.io",
    repository = "my-project/my-app",
    # No tag specified - will push by digest only
)

# Push using a destination file (instead of registry/repository attributes)
image_push(
    name = "push_from_file",
    image = ":my_app",
    destination_file = ":push_destination.txt",
    tag = "latest",
)
```

Push strategies:
- **`eager`**: Materializes all layers next to push binary. Simple, correct, but may be inefficient.
- **`lazy`**: Layers are not stored locally. Missing layers are streamed from Bazel's remote cache.
- **`cas_registry`**: Uses content-addressable storage for extreme efficiency. Requires
  CAS-enabled infrastructure.
- **`bes`**: Image is pushed as side-effect of Build Event Stream upload. No "bazel run" command needed.
  Requires Build Event Service integration.

See [push strategies documentation](/docs/push-strategies.md) for detailed comparisons.

Runtime usage:
```bash
# Push to registry
bazel run //path/to:push_app

# The push command will output the image digest
```"�t
�E

image_push�Pushes container images to a registry.

This rule creates an executable target that uploads OCI images to container registries.
It supports multiple push strategies optimized for different use cases, from simple
uploads to advanced content-addressable storage integration.

Key features:
- **Multiple push strategies**: Choose between eager, lazy, CAS-based, or BES-integrated pushing
- **Template expansion**: Dynamic registry, repository, and tag values using build settings
- **Stamping support**: Include build information in image tags
- **Incremental uploads**: Skip blobs that already exist in the registry

The rule produces an executable that can be run with `bazel run`.

Example:

```python
load("@rules_img//img:push.bzl", "image_push")

# Simple push to Docker Hub
image_push(
    name = "push_app",
    image = ":my_app",
    registry = "index.docker.io",
    repository = "myorg/myapp",
    tag = "latest",
)

# Push multi-platform image with multiple tags
image_push(
    name = "push_multiarch",
    image = ":my_app_index",  # References an image_index
    registry = "gcr.io",
    repository = "my-project/my-app",
    tag_list = ["latest", "v1.0.0"],
)

# Dynamic push with build settings
image_push(
    name = "push_dynamic",
    image = ":my_app",
    registry = "{{.REGISTRY}}",
    repository = "{{.PROJECT}}/my-app",
    tag = "{{.VERSION}}",
    build_settings = {
        "REGISTRY": "//settings:registry",
        "PROJECT": "//settings:project",
        "VERSION": "//settings:version",
    },
)

# Push with stamping for unique tags
image_push(
    name = "push_stamped",
    image = ":my_app",
    registry = "index.docker.io",
    repository = "myorg/myapp",
    tag = "latest-{{.BUILD_TIMESTAMP}}",
    stamp = "force",
)

# Digest-only push (no tag)
image_push(
    name = "push_by_digest",
    image = ":my_app",
    registry = "gcr.io",
    repository = "my-project/my-app",
    # No tag specified - will push by digest only
)

# Push using a destination file (instead of registry/repository attributes)
image_push(
    name = "push_from_file",
    image = ":my_app",
    destination_file = ":push_destination.txt",
    tag = "latest",
)
```

Push strategies:
- **`eager`**: Materializes all layers next to push binary. Simple, correct, but may be inefficient.
- **`lazy`**: Layers are not stored locally. Missing layers are streamed from Bazel's remote cache.
- **`cas_registry`**: Uses content-addressable storage for extreme efficiency. Requires
  CAS-enabled infrastructure.
- **`bes`**: Image is pushed as side-effect of Build Event Stream upload. No "bazel run" command needed.
  Requires Build Event Service integration.

See [push strategies documentation](/docs/push-strategies.md) for detailed comparisons.

Runtime usage:
```bash
# Push to registry
bazel run //path/to:push_app

# The push command will output the image digest
```*
nameA unique name for this target. �
registry�Registry URL to push the image to.

Common registries:
- Docker Hub: `index.docker.io`
- Google Container Registry: `gcr.io` or `us.gcr.io`
- GitHub Container Registry: `ghcr.io`
- Amazon ECR: `123456789.dkr.ecr.us-east-1.amazonaws.com`

Subject to [template expansion](/docs/templating.md).2""o

repository[Repository path within the registry.

Subject to [template expansion](/docs/templating.md).2""�
tag�Tag to apply to the pushed image.

Optional - if omitted, the image is pushed by digest only.

Subject to [template expansion](/docs/templating.md).2""�
tag_list�List of tags to apply to the pushed image.

Useful for applying multiple tags in a single push:

```python
tag_list = ["latest", "v1.0.0", "stable"]
```

Cannot be used together with `tag`. Can be combined with `tag_file` to merge tags from both sources.
Each tag is subject to [template expansion](/docs/templating.md).2[]�

manifest_tags�
Per-platform tag templates for multi-platform (`image_index`) pushes.

Only valid when `image` provides `ImageIndexInfo`. For each entry in this list, the
deploy command produces one tag per child manifest in the index by expanding the
entry against the platform descriptor of that manifest.

Available template variables (lowercase):

- `{{.os}}` — platform OS (e.g. `linux`)
- `{{.architecture}}`, `{{.arch}}`, `{{.cpu}}` — architecture (e.g. `amd64`, `arm64`)
- `{{.variant}}` — architecture variant (e.g. `v8`), if set

The tags in `tag` / `tag_list` / `tag_file` continue to point at the index as a
whole; `manifest_tags` complement those by publishing additional tags that each
resolve to a single child manifest.

Example:

```python
image_push(
    name = "push_multiarch",
    image = ":my_app_index",
    registry = "gcr.io",
    repository = "my-project/my-app",
    tag_list = ["latest", "v1.0.0"],
    manifest_tags = [
        "latest-{{.os}}-{{.architecture}}",
        "v1.0.0-{{.os}}-{{.architecture}}",
    ],
)
```

Templates are expanded at build time per child manifest, so `build_settings`
and stamping variables are available (and override any platform variable of
the same name). The expanded tags are emitted as `registry_tag` operations
in the deploy manifest, so non-CLI strategies like `bes` can honor them.2[]�
tag_file�File containing newline-delimited tags to apply to the pushed image.

The file should contain one tag per line. Empty lines are ignored. Tags from this file
are merged with tags specified via `tag` or `tag_list` attributes.

Example file content:
```
latest
v1.0.0
stable
```

Can be combined with `tag` or `tag_list` to merge tags from multiple sources.
Each tag is subject to [template expansion](/docs/templating.md).2None�
destination_file�File containing the push destination as `{registry}/{repository}`.

The file should contain a single line with the registry and repository separated by
the first `/`. For example: `gcr.io/my-project/my-app`.

The content is read as a literal string without Go template expansion. Trailing
newlines and whitespace are stripped.

Cannot be used together with `registry` or `repository` attributes.2None�
	referrers�Additional manifests or indexes to push as referrers to the main image.

Each referrer is pushed to the same registry and repository as the main image,
but without tags (referrers are discovered via the OCI referrers API by digest).

Each target must provide ImageManifestInfo or ImageIndexInfo and must have its
`subject` field set to reference the main image being pushed.

Example:
```python
image_push(
    name = "push",
    image = ":my_app",
    referrers = [
        ":sbom_manifest",
        ":signature_manifest",
    ],
    registry = "ghcr.io",
    repository = "myorg/myapp",
    tag = "latest",
)
```*]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl*T
ImageIndexInfoB
ImageIndexInfo0@rules_img//img/private/providers:index_info.bzl2[]�
cross_mount_fromCAn image_push target whose layers may be cross-mounted during push.*M

DeployInfo?

DeployInfo1@rules_img//img/private/providers:deploy_info.bzl2None�
strategynPush strategy to use.

See [push strategies documentation](/docs/push-strategies.md) for detailed information.2"auto"J"auto"J"eager"J"lazy"J"cas_registry"J"bes"�
build_settings�Build settings for template expansion.

Maps template variable names to string_flag targets. These values can be used in
registry, repository, and tag attributes using `{{.VARIABLE_NAME}}` syntax (Go template).

Example:
```python
build_settings = {
    "REGISTRY": "//settings:docker_registry",
    "VERSION": "//settings:app_version",
}
```

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"J"auto"J"force"J
"disabled"O
imageBImage to push. Should provide ImageManifestInfo or ImageIndexInfo. �
tool_cfg�Configuration of the pusher executable platform.

Available options:
- **`host`** (default): Pusher executable matches the host platform.
- **`target`**: Pusher executable matches the target platform(s) specified via `--platforms`.2"host"J"host"J"target"�
deploy_tool�Optional label of a deploy tool target providing `DeployToolInfo` (created with `img_deploy_tool` from `@rules_img//img:deploy_tool.bzl`). When set, overrides `tool_cfg`.*Z
DeployToolInfoH
DeployToolInfo6@rules_img//img/private/providers:deploy_tool_info.bzl2None".

image_push @rules_img//img/private:push.bzl8,
*
nameA unique name for this target. �
�
registry�Registry URL to push the image to.

Common registries:
- Docker Hub: `index.docker.io`
- Google Container Registry: `gcr.io` or `us.gcr.io`
- GitHub Container Registry: `ghcr.io`
- Amazon ECR: `123456789.dkr.ecr.us-east-1.amazonaws.com`

Subject to [template expansion](/docs/templating.md).2""q
o

repository[Repository path within the registry.

Subject to [template expansion](/docs/templating.md).2""�
�
tag�Tag to apply to the pushed image.

Optional - if omitted, the image is pushed by digest only.

Subject to [template expansion](/docs/templating.md).2""�
�
tag_list�List of tags to apply to the pushed image.

Useful for applying multiple tags in a single push:

```python
tag_list = ["latest", "v1.0.0", "stable"]
```

Cannot be used together with `tag`. Can be combined with `tag_file` to merge tags from both sources.
Each tag is subject to [template expansion](/docs/templating.md).2[]�

�

manifest_tags�
Per-platform tag templates for multi-platform (`image_index`) pushes.

Only valid when `image` provides `ImageIndexInfo`. For each entry in this list, the
deploy command produces one tag per child manifest in the index by expanding the
entry against the platform descriptor of that manifest.

Available template variables (lowercase):

- `{{.os}}` — platform OS (e.g. `linux`)
- `{{.architecture}}`, `{{.arch}}`, `{{.cpu}}` — architecture (e.g. `amd64`, `arm64`)
- `{{.variant}}` — architecture variant (e.g. `v8`), if set

The tags in `tag` / `tag_list` / `tag_file` continue to point at the index as a
whole; `manifest_tags` complement those by publishing additional tags that each
resolve to a single child manifest.

Example:

```python
image_push(
    name = "push_multiarch",
    image = ":my_app_index",
    registry = "gcr.io",
    repository = "my-project/my-app",
    tag_list = ["latest", "v1.0.0"],
    manifest_tags = [
        "latest-{{.os}}-{{.architecture}}",
        "v1.0.0-{{.os}}-{{.architecture}}",
    ],
)
```

Templates are expanded at build time per child manifest, so `build_settings`
and stamping variables are available (and override any platform variable of
the same name). The expanded tags are emitted as `registry_tag` operations
in the deploy manifest, so non-CLI strategies like `bes` can honor them.2[]�
�
tag_file�File containing newline-delimited tags to apply to the pushed image.

The file should contain one tag per line. Empty lines are ignored. Tags from this file
are merged with tags specified via `tag` or `tag_list` attributes.

Example file content:
```
latest
v1.0.0
stable
```

Can be combined with `tag` or `tag_list` to merge tags from multiple sources.
Each tag is subject to [template expansion](/docs/templating.md).2None�
�
destination_file�File containing the push destination as `{registry}/{repository}`.

The file should contain a single line with the registry and repository separated by
the first `/`. For example: `gcr.io/my-project/my-app`.

The content is read as a literal string without Go template expansion. Trailing
newlines and whitespace are stripped.

Cannot be used together with `registry` or `repository` attributes.2None�
�
	referrers�Additional manifests or indexes to push as referrers to the main image.

Each referrer is pushed to the same registry and repository as the main image,
but without tags (referrers are discovered via the OCI referrers API by digest).

Each target must provide ImageManifestInfo or ImageIndexInfo and must have its
`subject` field set to reference the main image being pushed.

Example:
```python
image_push(
    name = "push",
    image = ":my_app",
    referrers = [
        ":sbom_manifest",
        ":signature_manifest",
    ],
    registry = "ghcr.io",
    repository = "myorg/myapp",
    tag = "latest",
)
```*]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl*T
ImageIndexInfoB
ImageIndexInfo0@rules_img//img/private/providers:index_info.bzl2[]�
�
cross_mount_fromCAn image_push target whose layers may be cross-mounted during push.*M

DeployInfo?

DeployInfo1@rules_img//img/private/providers:deploy_info.bzl2None�
�
strategynPush strategy to use.

See [push strategies documentation](/docs/push-strategies.md) for detailed information.2"auto"J"auto"J"eager"J"lazy"J"cas_registry"J"bes"�
�
build_settings�Build settings for template expansion.

Maps template variable names to string_flag targets. These values can be used in
registry, repository, and tag attributes using `{{.VARIABLE_NAME}}` syntax (Go template).

Example:
```python
build_settings = {
    "REGISTRY": "//settings:docker_registry",
    "VERSION": "//settings:app_version",
}
```

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"J"auto"J"force"J
"disabled"Q
O
imageBImage to push. Should provide ImageManifestInfo or ImageIndexInfo. �
�
tool_cfg�Configuration of the pusher executable platform.

Available options:
- **`host`** (default): Pusher executable matches the host platform.
- **`target`**: Pusher executable matches the target platform(s) specified via `--platforms`.2"host"J"host"J"target"�
�
deploy_tool�Optional label of a deploy tool target providing `DeployToolInfo` (created with `img_deploy_tool` from `@rules_img//img:deploy_tool.bzl`). When set, overrides `tool_cfg`.*Z
DeployToolInfoH
DeployToolInfo6@rules_img//img/private/providers:deploy_tool_info.bzl2None�mimage_push_spec�Defines push configuration for container images without referencing a specific image.

This rule captures registry, repository, tag, and strategy settings that can be
attached to `image_manifest` or `image_index` targets via their `push_specs`
attribute. Template strings using Go template syntax (`{{.VAR}}`) are accepted
but not expanded — expansion happens when the deployment is consumed by the
image rule.
Note that the template strings `{{.image_target_package}}` and `{{.image_target_name}}` are especially useful here.

This enables an inverted dependency pattern: instead of `image_push` depending
on the image, the image itself carries its deployment configuration, making it
directly usable with `multi_deploy`.

Example:

```python
load("@rules_img//img:push.bzl", "image_push_spec")

image_push_spec(
    name = "push_config",
    registry = "gcr.io",
    repository = "my-project/{{.image_target_package}}/{{.image_target_name}}",
    tag = "{{.VERSION}}",
    build_settings = {
        "VERSION": "//settings:version",
    },
    stamp = "force",
)

# Attach to an image:
image_manifest(
    name = "my_app_a",
    base = "@distroless_cc",
    layers = [":app_layer"],
    push_specs = [":push_config"],
)

# Attach to another image:
image_manifest(
    name = "my_app_b",
    base = "@distroless_cc",
    layers = [":app_layer"],
    push_specs = [":push_config"],
)

# Now usable directly in multi_deploy:
multi_deploy(
    name = "deploy",
    operations = [
        ":my_app_a",
        ":my_app_b",
    ],
)
```"�`
�6
image_push_spec�Defines push configuration for container images without referencing a specific image.

This rule captures registry, repository, tag, and strategy settings that can be
attached to `image_manifest` or `image_index` targets via their `push_specs`
attribute. Template strings using Go template syntax (`{{.VAR}}`) are accepted
but not expanded — expansion happens when the deployment is consumed by the
image rule.
Note that the template strings `{{.image_target_package}}` and `{{.image_target_name}}` are especially useful here.

This enables an inverted dependency pattern: instead of `image_push` depending
on the image, the image itself carries its deployment configuration, making it
directly usable with `multi_deploy`.

Example:

```python
load("@rules_img//img:push.bzl", "image_push_spec")

image_push_spec(
    name = "push_config",
    registry = "gcr.io",
    repository = "my-project/{{.image_target_package}}/{{.image_target_name}}",
    tag = "{{.VERSION}}",
    build_settings = {
        "VERSION": "//settings:version",
    },
    stamp = "force",
)

# Attach to an image:
image_manifest(
    name = "my_app_a",
    base = "@distroless_cc",
    layers = [":app_layer"],
    push_specs = [":push_config"],
)

# Attach to another image:
image_manifest(
    name = "my_app_b",
    base = "@distroless_cc",
    layers = [":app_layer"],
    push_specs = [":push_config"],
)

# Now usable directly in multi_deploy:
multi_deploy(
    name = "deploy",
    operations = [
        ":my_app_a",
        ":my_app_b",
    ],
)
```*
nameA unique name for this target. �
registry�Registry URL to push the image to.

Common registries:
- Docker Hub: `index.docker.io`
- Google Container Registry: `gcr.io` or `us.gcr.io`
- GitHub Container Registry: `ghcr.io`
- Amazon ECR: `123456789.dkr.ecr.us-east-1.amazonaws.com`

Subject to [template expansion](/docs/templating.md).2""o

repository[Repository path within the registry.

Subject to [template expansion](/docs/templating.md).2""�
tag�Tag to apply to the pushed image.

Optional - if omitted, the image is pushed by digest only.

Subject to [template expansion](/docs/templating.md).2""�
tag_list�List of tags to apply to the pushed image.

Useful for applying multiple tags in a single push:

```python
tag_list = ["latest", "v1.0.0", "stable"]
```

Cannot be used together with `tag`. Can be combined with `tag_file` to merge tags from both sources.
Each tag is subject to [template expansion](/docs/templating.md).2[]�

manifest_tags�
Per-platform tag templates for multi-platform (`image_index`) pushes.

Only valid when `image` provides `ImageIndexInfo`. For each entry in this list, the
deploy command produces one tag per child manifest in the index by expanding the
entry against the platform descriptor of that manifest.

Available template variables (lowercase):

- `{{.os}}` — platform OS (e.g. `linux`)
- `{{.architecture}}`, `{{.arch}}`, `{{.cpu}}` — architecture (e.g. `amd64`, `arm64`)
- `{{.variant}}` — architecture variant (e.g. `v8`), if set

The tags in `tag` / `tag_list` / `tag_file` continue to point at the index as a
whole; `manifest_tags` complement those by publishing additional tags that each
resolve to a single child manifest.

Example:

```python
image_push(
    name = "push_multiarch",
    image = ":my_app_index",
    registry = "gcr.io",
    repository = "my-project/my-app",
    tag_list = ["latest", "v1.0.0"],
    manifest_tags = [
        "latest-{{.os}}-{{.architecture}}",
        "v1.0.0-{{.os}}-{{.architecture}}",
    ],
)
```

Templates are expanded at build time per child manifest, so `build_settings`
and stamping variables are available (and override any platform variable of
the same name). The expanded tags are emitted as `registry_tag` operations
in the deploy manifest, so non-CLI strategies like `bes` can honor them.2[]�
tag_file�File containing newline-delimited tags to apply to the pushed image.

The file should contain one tag per line. Empty lines are ignored. Tags from this file
are merged with tags specified via `tag` or `tag_list` attributes.

Example file content:
```
latest
v1.0.0
stable
```

Can be combined with `tag` or `tag_list` to merge tags from multiple sources.
Each tag is subject to [template expansion](/docs/templating.md).2None�
destination_file�File containing the push destination as `{registry}/{repository}`.

The file should contain a single line with the registry and repository separated by
the first `/`. For example: `gcr.io/my-project/my-app`.

The content is read as a literal string without Go template expansion. Trailing
newlines and whitespace are stripped.

Cannot be used together with `registry` or `repository` attributes.2None�
	referrers�Additional manifests or indexes to push as referrers to the main image.

Each referrer is pushed to the same registry and repository as the main image,
but without tags (referrers are discovered via the OCI referrers API by digest).

Each target must provide ImageManifestInfo or ImageIndexInfo and must have its
`subject` field set to reference the main image being pushed.

Example:
```python
image_push(
    name = "push",
    image = ":my_app",
    referrers = [
        ":sbom_manifest",
        ":signature_manifest",
    ],
    registry = "ghcr.io",
    repository = "myorg/myapp",
    tag = "latest",
)
```*]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl*T
ImageIndexInfoB
ImageIndexInfo0@rules_img//img/private/providers:index_info.bzl2[]�
cross_mount_fromCAn image_push target whose layers may be cross-mounted during push.*M

DeployInfo?

DeployInfo1@rules_img//img/private/providers:deploy_info.bzl2None�
strategynPush strategy to use.

See [push strategies documentation](/docs/push-strategies.md) for detailed information.2"auto"J"auto"J"eager"J"lazy"J"cas_registry"J"bes"�
build_settings�Build settings for template expansion.

Maps template variable names to string_flag targets. These values can be used in
registry, repository, and tag attributes using `{{.VARIABLE_NAME}}` syntax (Go template).

Example:
```python
build_settings = {
    "REGISTRY": "//settings:docker_registry",
    "VERSION": "//settings:app_version",
}
```

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"J"auto"J"force"J
"disabled""8
image_push_spec%@rules_img//img/private:push_spec.bzl*Z
PushConfigInfoH
PushConfigInfo6@rules_img//img/private/providers:push_config_info.bzl,
*
nameA unique name for this target. �
�
registry�Registry URL to push the image to.

Common registries:
- Docker Hub: `index.docker.io`
- Google Container Registry: `gcr.io` or `us.gcr.io`
- GitHub Container Registry: `ghcr.io`
- Amazon ECR: `123456789.dkr.ecr.us-east-1.amazonaws.com`

Subject to [template expansion](/docs/templating.md).2""q
o

repository[Repository path within the registry.

Subject to [template expansion](/docs/templating.md).2""�
�
tag�Tag to apply to the pushed image.

Optional - if omitted, the image is pushed by digest only.

Subject to [template expansion](/docs/templating.md).2""�
�
tag_list�List of tags to apply to the pushed image.

Useful for applying multiple tags in a single push:

```python
tag_list = ["latest", "v1.0.0", "stable"]
```

Cannot be used together with `tag`. Can be combined with `tag_file` to merge tags from both sources.
Each tag is subject to [template expansion](/docs/templating.md).2[]�

�

manifest_tags�
Per-platform tag templates for multi-platform (`image_index`) pushes.

Only valid when `image` provides `ImageIndexInfo`. For each entry in this list, the
deploy command produces one tag per child manifest in the index by expanding the
entry against the platform descriptor of that manifest.

Available template variables (lowercase):

- `{{.os}}` — platform OS (e.g. `linux`)
- `{{.architecture}}`, `{{.arch}}`, `{{.cpu}}` — architecture (e.g. `amd64`, `arm64`)
- `{{.variant}}` — architecture variant (e.g. `v8`), if set

The tags in `tag` / `tag_list` / `tag_file` continue to point at the index as a
whole; `manifest_tags` complement those by publishing additional tags that each
resolve to a single child manifest.

Example:

```python
image_push(
    name = "push_multiarch",
    image = ":my_app_index",
    registry = "gcr.io",
    repository = "my-project/my-app",
    tag_list = ["latest", "v1.0.0"],
    manifest_tags = [
        "latest-{{.os}}-{{.architecture}}",
        "v1.0.0-{{.os}}-{{.architecture}}",
    ],
)
```

Templates are expanded at build time per child manifest, so `build_settings`
and stamping variables are available (and override any platform variable of
the same name). The expanded tags are emitted as `registry_tag` operations
in the deploy manifest, so non-CLI strategies like `bes` can honor them.2[]�
�
tag_file�File containing newline-delimited tags to apply to the pushed image.

The file should contain one tag per line. Empty lines are ignored. Tags from this file
are merged with tags specified via `tag` or `tag_list` attributes.

Example file content:
```
latest
v1.0.0
stable
```

Can be combined with `tag` or `tag_list` to merge tags from multiple sources.
Each tag is subject to [template expansion](/docs/templating.md).2None�
�
destination_file�File containing the push destination as `{registry}/{repository}`.

The file should contain a single line with the registry and repository separated by
the first `/`. For example: `gcr.io/my-project/my-app`.

The content is read as a literal string without Go template expansion. Trailing
newlines and whitespace are stripped.

Cannot be used together with `registry` or `repository` attributes.2None�
�
	referrers�Additional manifests or indexes to push as referrers to the main image.

Each referrer is pushed to the same registry and repository as the main image,
but without tags (referrers are discovered via the OCI referrers API by digest).

Each target must provide ImageManifestInfo or ImageIndexInfo and must have its
`subject` field set to reference the main image being pushed.

Example:
```python
image_push(
    name = "push",
    image = ":my_app",
    referrers = [
        ":sbom_manifest",
        ":signature_manifest",
    ],
    registry = "ghcr.io",
    repository = "myorg/myapp",
    tag = "latest",
)
```*]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl*T
ImageIndexInfoB
ImageIndexInfo0@rules_img//img/private/providers:index_info.bzl2[]�
�
cross_mount_fromCAn image_push target whose layers may be cross-mounted during push.*M

DeployInfo?

DeployInfo1@rules_img//img/private/providers:deploy_info.bzl2None�
�
strategynPush strategy to use.

See [push strategies documentation](/docs/push-strategies.md) for detailed information.2"auto"J"auto"J"eager"J"lazy"J"cas_registry"J"bes"�
�
build_settings�Build settings for template expansion.

Maps template variable names to string_flag targets. These values can be used in
registry, repository, and tag attributes using `{{.VARIABLE_NAME}}` syntax (Go template).

Example:
```python
build_settings = {
    "REGISTRY": "//settings:docker_registry",
    "VERSION": "//settings:app_version",
}
```

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"J"auto"J"force"J
"disabled"*Public API for container image push rules. 