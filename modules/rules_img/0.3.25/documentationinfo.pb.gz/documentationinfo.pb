Ր
!
	rules_imgimgbase_images.bzl��base_image_layer�Builds a single flat container image layer from base image content descriptions.

Takes any number of content-describing targets -- `linux_skeleton`, `etc_passwd`,
`trust_store` and the rest -- and merges everything they describe into one
layer. Nothing is materialized until this point: the content rules only
accumulate tar entry metadata, which propagates cheaply through dependencies.

For a path described by more than one `src`, the last one wins, so a rule can
override what an earlier one placed. Two entries for the same path with
different *types* (a directory where another src put a symlink) are an error
instead: that is a rule authoring mistake rather than a deliberate override.

The resulting layer is an ordinary rules_img layer and supports the same
compression, eStargz, SOCI and compact-stream settings as `image_layer`.

Example:

```python
load(
    "@rules_img//img:base_images.bzl",
    "base_image_layer",
    "etc_passwd",
    "linux_skeleton",
    "passwd_entry",
    "trust_store",
)
load("@rules_img//img:image.bzl", "image_manifest")

linux_skeleton(name = "skeleton")

etc_passwd(
    name = "users",
    users = [passwd_entry(username = "app", uid = 1000, gid = 1000, home = "/home/app")],
)

trust_store(
    name = "trust",
    certs = ["//pki:corporate-root.pem"],
)

base_image_layer(
    name = "base_layer",
    srcs = [
        ":skeleton",
        ":users",
        ":trust",
    ],
)

image_manifest(
    name = "base",
    layers = [":base_layer"],
)
```

### Output groups

- `layer`: the compressed layer blob
- `metadata`: the layer's OCI descriptor as JSON
- `mtree`: a single [mtree](https://man.freebsd.org/cgi/man.cgi?mtree(5)) text file"؉
�K
base_image_layer�Builds a single flat container image layer from base image content descriptions.

Takes any number of content-describing targets -- `linux_skeleton`, `etc_passwd`,
`trust_store` and the rest -- and merges everything they describe into one
layer. Nothing is materialized until this point: the content rules only
accumulate tar entry metadata, which propagates cheaply through dependencies.

For a path described by more than one `src`, the last one wins, so a rule can
override what an earlier one placed. Two entries for the same path with
different *types* (a directory where another src put a symlink) are an error
instead: that is a rule authoring mistake rather than a deliberate override.

The resulting layer is an ordinary rules_img layer and supports the same
compression, eStargz, SOCI and compact-stream settings as `image_layer`.

Example:

```python
load(
    "@rules_img//img:base_images.bzl",
    "base_image_layer",
    "etc_passwd",
    "linux_skeleton",
    "passwd_entry",
    "trust_store",
)
load("@rules_img//img:image.bzl", "image_manifest")

linux_skeleton(name = "skeleton")

etc_passwd(
    name = "users",
    users = [passwd_entry(username = "app", uid = 1000, gid = 1000, home = "/home/app")],
)

trust_store(
    name = "trust",
    certs = ["//pki:corporate-root.pem"],
)

base_image_layer(
    name = "base_layer",
    srcs = [
        ":skeleton",
        ":users",
        ":trust",
    ],
)

image_manifest(
    name = "base",
    layers = [":base_layer"],
)
```

### Output groups

- `layer`: the compressed layer blob
- `metadata`: the layer's OCI descriptor as JSON
- `mtree`: a single [mtree](https://man.freebsd.org/cgi/man.cgi?mtree(5)) text file*
nameA unique name for this target. �
srcs�Base image content descriptions to merge into the layer.

Order matters: for a path described by more than one src, the last one wins.*m
BaseImageContentInfoU
BaseImageContentInfo=@rules_img//img/private/providers:base_image_content_info.bzl2[]�
default_metadata�JSON-encoded default metadata for entries that do not set it themselves.

Only the modification time is taken from here: an entry's own mode and ownership
are authoritative, since deciding them is the entire purpose of the rule that
produced it. Build the value with `file_metadata()` from
`@rules_img//img:layer.bzl`.2""�
file_metadata�Per-file metadata overrides, mapping image path to JSON-encoded metadata.

Unlike `default_metadata`, an override here replaces whatever the producing rule
chose. Use it to adjust a single entry without changing the rule that describes
it.
2{}�
compress�Compression algorithm to use. If set to 'auto', uses the global default compression setting.

'none' leaves the layer uncompressed, which is the useful choice for an EROFS layer
(the blob is then mountable as it is). EROFS layers cannot be gzip-compressed.

A `cpio` layer (an initramfs) is also left uncompressed by default. It can be compressed with
`gzip` or `zstd`, which the kernel unpacks as it is. The `ext4`, `fat32` and `iso9660` formats ignore this attribute.2"auto"J"auto"J"gzip"J"zstd"J"none"�
format�Container format of the layer blob, orthogonal to `compress`.

'tar' writes an OCI tar changeset. 'erofs' writes a mountable EROFS filesystem image. 'ext4' and 'fat32' write an
ext4 or FAT32 filesystem image, 'iso9660' an ISO 9660 image (with the Rock Ridge, Joliet and UDF extensions and
El Torito boot entries as options), 'cpio' a cpio archive in the newc format (an initramfs). If set to 'auto', uses the global default
--@rules_img//img/settings:layer_format setting.

An EROFS layer is a filesystem, not a changeset. See docs/erofs-layers.md before using it.

See docs/filesystems.md for how the formats compare.2"auto"J"auto"J"tar"J"erofs"J"ext4"J"fat32"J	"iso9660"J"cpio"�
format_config�Options of the filesystem image the layer is written as: an `ext4_config` target
for `format = "ext4"`, a `fat32_config` target for `format = "fat32"`, an `iso9660_config` target for `format = "iso9660"`,
a `cpio_config` target for `format = "cpio"`, or an `erofs_config`
target for `format = "erofs"`.

Without it, every option of the format is left at its default. A config for a
format other than the layer's own is a configuration error, since it would
silently have no effect.*\
Ext4ConfigInfoJ
Ext4ConfigInfo8@rules_img//img/private/providers:format_config_info.bzl*^
Fat32ConfigInfoK
Fat32ConfigInfo8@rules_img//img/private/providers:format_config_info.bzl*b
Iso9660ConfigInfoM
Iso9660ConfigInfo8@rules_img//img/private/providers:format_config_info.bzl*\
CpioConfigInfoJ
CpioConfigInfo8@rules_img//img/private/providers:format_config_info.bzl*^
ErofsConfigInfoK
ErofsConfigInfo8@rules_img//img/private/providers:format_config_info.bzl2None�
estargz�Whether to use estargz format. If set to 'auto', uses the global default estargz setting.
When enabled, the layer will be optimized for lazy pulling and will be compatible with the estargz format.2"auto"J"auto"J	"enabled"J
"disabled"�
zstd_chunked�Whether to use the zstd:chunked format. If set to 'auto', uses the global default zstd_chunked setting.
When enabled, the layer is written with content-defined chunks and a table of contents, so
compatible runtimes (podman, CRI-O) can fetch and deduplicate individual chunks.
Requires zstd compression and cannot be combined with estargz.2"auto"J"auto"J	"enabled"J
"disabled"�
soci�Whether to emit a SOCI ztoc (table of contents) for this layer. If set to 'auto',
uses the global default //img/settings:soci setting. When enabled and the layer is
gzip-compressed, a ztoc is produced in the layer action and recorded on the
SingleLayerInfo provider, so images that build a SOCI Index Manifest v2 can reuse
it instead of regenerating it. Non-gzip layers never emit a ztoc.2"auto"J"auto"J	"enabled"J
"disabled"�
create_parent_directories�Whether to automatically create parent directory entries in the tar file for all files.
If set to 'auto', uses the global default create_parent_directories setting.
When enabled, parent directories will be created automatically for all files in the layer.2"auto"J"auto"J	"enabled"J
"disabled"�
tree_artifact_handling�How to handle duplicate tree artifacts (directories) in the layer.
If set to 'full', each tree artifact is stored at its intended path (no deduplication).
If set to 'deduplicate_symlink', duplicate tree artifacts are replaced with symlinks to the first occurrence.
If set to 'auto', uses the global default from --@rules_img//img/settings:layer_tree_artifact_handling.
When file metadata is configured, trees are stored in full so path-specific metadata
is preserved. Regular files with identical contents and metadata still deduplicate.2"auto"J"auto"J"full"J"deduplicate_symlink"�
include_runfiles�Whether to include runfiles for executable targets.
When True (default), executables in srcs will include their runfiles tree.
When False, only the executable file itself is included, without runfiles.

Either way, any additional default outputs of the target (the rest of `DefaultInfo.files`
beyond the executable) are copied into the layer, placed relative to the executable,
as configured by `extra_default_outputs`.2True�
extra_default_outputs�How to handle an executable's additional default outputs (the rest of `DefaultInfo.files`
beyond the executable itself).

Those files are placed at the same offset relative to the executable that they have in the
source tree, so a file that lives above the executable's directory needs a path in the image
that is deep enough to place it. This setting decides what happens when it isn't:

- `"best_effort"` (default): place every additional default output that fits, and silently
  drop the ones that would land above the image root. This is what wrapper rules such as
  bazel-lib's `transition_binary` need, where the executable is a symlink in a sibling
  directory of the real outputs.
- `"drop"`: never place additional default outputs. Only the executable itself (and its
  runfiles, if `include_runfiles` is True) is included.
- `"strict"`: place every additional default output, and fail the build if any of them
  would land above the image root.2"best_effort"J"best_effort"J"drop"J"strict"Q
annotations<Annotations to add to the layer metadata as key-value pairs.
2{}�
annotations_file�File containing annotations for the layer, as JSON or newline-delimited text.

The file is parsed in one of the following formats, auto-detected from its contents:

- JSON object with string values: `{"key": "value"}`
- JSON object with list values: `{"key": ["value1", "value2"]}` (the last value wins)
- JSON array of `KEY=VALUE` strings: `["key=value"]`
- newline-delimited `KEY=VALUE` text (one per line; blank lines and `#` comments are ignored)

Values in JSON objects are used verbatim, so they can encode arbitrary strings including
values that contain `=`, spaces, or newlines. The `KEY=VALUE` forms (JSON array and text)
split on the first `=` and trim surrounding whitespace from the key and value.

Annotations from this file are merged with annotations specified via the `annotations`
attribute, which take precedence for matching keys.

Example file content:
```
version=1.0.0
build.date=2024-01-15
source.url=https://github.com/...
```2None~

media_typejOverride the layer media type. By default, the media type is auto-detected from the compression algorithm.2"""L
base_image_layer8@rules_img//img/private/base_images:base_image_layer.bzl*M

LayersInfo?

LayersInfo1@rules_img//img/private/providers:layers_info.bzl,
*
nameA unique name for this target. �
�
srcs�Base image content descriptions to merge into the layer.

Order matters: for a path described by more than one src, the last one wins.*m
BaseImageContentInfoU
BaseImageContentInfo=@rules_img//img/private/providers:base_image_content_info.bzl2[]�
�
default_metadata�JSON-encoded default metadata for entries that do not set it themselves.

Only the modification time is taken from here: an entry's own mode and ownership
are authoritative, since deciding them is the entire purpose of the rule that
produced it. Build the value with `file_metadata()` from
`@rules_img//img:layer.bzl`.2""�
�
file_metadata�Per-file metadata overrides, mapping image path to JSON-encoded metadata.

Unlike `default_metadata`, an override here replaces whatever the producing rule
chose. Use it to adjust a single entry without changing the rule that describes
it.
2{}�
�
compress�Compression algorithm to use. If set to 'auto', uses the global default compression setting.

'none' leaves the layer uncompressed, which is the useful choice for an EROFS layer
(the blob is then mountable as it is). EROFS layers cannot be gzip-compressed.

A `cpio` layer (an initramfs) is also left uncompressed by default. It can be compressed with
`gzip` or `zstd`, which the kernel unpacks as it is. The `ext4`, `fat32` and `iso9660` formats ignore this attribute.2"auto"J"auto"J"gzip"J"zstd"J"none"�
�
format�Container format of the layer blob, orthogonal to `compress`.

'tar' writes an OCI tar changeset. 'erofs' writes a mountable EROFS filesystem image. 'ext4' and 'fat32' write an
ext4 or FAT32 filesystem image, 'iso9660' an ISO 9660 image (with the Rock Ridge, Joliet and UDF extensions and
El Torito boot entries as options), 'cpio' a cpio archive in the newc format (an initramfs). If set to 'auto', uses the global default
--@rules_img//img/settings:layer_format setting.

An EROFS layer is a filesystem, not a changeset. See docs/erofs-layers.md before using it.

See docs/filesystems.md for how the formats compare.2"auto"J"auto"J"tar"J"erofs"J"ext4"J"fat32"J	"iso9660"J"cpio"�
�
format_config�Options of the filesystem image the layer is written as: an `ext4_config` target
for `format = "ext4"`, a `fat32_config` target for `format = "fat32"`, an `iso9660_config` target for `format = "iso9660"`,
a `cpio_config` target for `format = "cpio"`, or an `erofs_config`
target for `format = "erofs"`.

Without it, every option of the format is left at its default. A config for a
format other than the layer's own is a configuration error, since it would
silently have no effect.*\
Ext4ConfigInfoJ
Ext4ConfigInfo8@rules_img//img/private/providers:format_config_info.bzl*^
Fat32ConfigInfoK
Fat32ConfigInfo8@rules_img//img/private/providers:format_config_info.bzl*b
Iso9660ConfigInfoM
Iso9660ConfigInfo8@rules_img//img/private/providers:format_config_info.bzl*\
CpioConfigInfoJ
CpioConfigInfo8@rules_img//img/private/providers:format_config_info.bzl*^
ErofsConfigInfoK
ErofsConfigInfo8@rules_img//img/private/providers:format_config_info.bzl2None�
�
estargz�Whether to use estargz format. If set to 'auto', uses the global default estargz setting.
When enabled, the layer will be optimized for lazy pulling and will be compatible with the estargz format.2"auto"J"auto"J	"enabled"J
"disabled"�
�
zstd_chunked�Whether to use the zstd:chunked format. If set to 'auto', uses the global default zstd_chunked setting.
When enabled, the layer is written with content-defined chunks and a table of contents, so
compatible runtimes (podman, CRI-O) can fetch and deduplicate individual chunks.
Requires zstd compression and cannot be combined with estargz.2"auto"J"auto"J	"enabled"J
"disabled"�
�
soci�Whether to emit a SOCI ztoc (table of contents) for this layer. If set to 'auto',
uses the global default //img/settings:soci setting. When enabled and the layer is
gzip-compressed, a ztoc is produced in the layer action and recorded on the
SingleLayerInfo provider, so images that build a SOCI Index Manifest v2 can reuse
it instead of regenerating it. Non-gzip layers never emit a ztoc.2"auto"J"auto"J	"enabled"J
"disabled"�
�
create_parent_directories�Whether to automatically create parent directory entries in the tar file for all files.
If set to 'auto', uses the global default create_parent_directories setting.
When enabled, parent directories will be created automatically for all files in the layer.2"auto"J"auto"J	"enabled"J
"disabled"�
�
tree_artifact_handling�How to handle duplicate tree artifacts (directories) in the layer.
If set to 'full', each tree artifact is stored at its intended path (no deduplication).
If set to 'deduplicate_symlink', duplicate tree artifacts are replaced with symlinks to the first occurrence.
If set to 'auto', uses the global default from --@rules_img//img/settings:layer_tree_artifact_handling.
When file metadata is configured, trees are stored in full so path-specific metadata
is preserved. Regular files with identical contents and metadata still deduplicate.2"auto"J"auto"J"full"J"deduplicate_symlink"�
�
include_runfiles�Whether to include runfiles for executable targets.
When True (default), executables in srcs will include their runfiles tree.
When False, only the executable file itself is included, without runfiles.

Either way, any additional default outputs of the target (the rest of `DefaultInfo.files`
beyond the executable) are copied into the layer, placed relative to the executable,
as configured by `extra_default_outputs`.2True�
�
extra_default_outputs�How to handle an executable's additional default outputs (the rest of `DefaultInfo.files`
beyond the executable itself).

Those files are placed at the same offset relative to the executable that they have in the
source tree, so a file that lives above the executable's directory needs a path in the image
that is deep enough to place it. This setting decides what happens when it isn't:

- `"best_effort"` (default): place every additional default output that fits, and silently
  drop the ones that would land above the image root. This is what wrapper rules such as
  bazel-lib's `transition_binary` need, where the executable is a symlink in a sibling
  directory of the real outputs.
- `"drop"`: never place additional default outputs. Only the executable itself (and its
  runfiles, if `include_runfiles` is True) is included.
- `"strict"`: place every additional default output, and fail the build if any of them
  would land above the image root.2"best_effort"J"best_effort"J"drop"J"strict"S
Q
annotations<Annotations to add to the layer metadata as key-value pairs.
2{}�
�
annotations_file�File containing annotations for the layer, as JSON or newline-delimited text.

The file is parsed in one of the following formats, auto-detected from its contents:

- JSON object with string values: `{"key": "value"}`
- JSON object with list values: `{"key": ["value1", "value2"]}` (the last value wins)
- JSON array of `KEY=VALUE` strings: `["key=value"]`
- newline-delimited `KEY=VALUE` text (one per line; blank lines and `#` comments are ignored)

Values in JSON objects are used verbatim, so they can encode arbitrary strings including
values that contain `=`, spaces, or newlines. The `KEY=VALUE` forms (JSON array and text)
split on the first `=` and trim surrounding whitespace from the key and value.

Annotations from this file are merged with annotations specified via the `annotations`
attribute, which take precedence for matching keys.

Example file content:
```
version=1.0.0
build.date=2024-01-15
source.url=https://github.com/...
```2None�
~

media_typejOverride the layer media type. By default, the media type is auto-detected from the compression algorithm.2""�"etc_environment�Describes `/etc/environment`, the system-wide environment file read by PAM.

The file holds one `KEY="value"` assignment per line. Unlike a shell profile it
is not executed, so values are literal: no expansion, no `export`, no
conditionals.

This rule only applies when targeting Linux. On any other platform it is a
no-op that contributes nothing to the layer.

Example:

```python
load("@rules_img//img:base_images.bzl", "etc_environment")

etc_environment(
    name = "environment",
    env = {
        "PATH": "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
        "LANG": "C.UTF-8",
    },
)
```"�
�
etc_environment�Describes `/etc/environment`, the system-wide environment file read by PAM.

The file holds one `KEY="value"` assignment per line. Unlike a shell profile it
is not executed, so values are literal: no expansion, no `export`, no
conditionals.

This rule only applies when targeting Linux. On any other platform it is a
no-op that contributes nothing to the layer.

Example:

```python
load("@rules_img//img:base_images.bzl", "etc_environment")

etc_environment(
    name = "environment",
    env = {
        "PATH": "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
        "LANG": "C.UTF-8",
    },
)
```*
nameA unique name for this target. �
build_settings�Build settings for template expansion.

Maps template variable names to `string_flag` targets. The values can be
referenced from this rule's templated attributes with `{{.VARIABLE_NAME}}`
(Go template syntax).

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"J"auto"J"force"J
"disabled"�
envyEnvironment variables to write, as a mapping of name to value.

Values support [template expansion](/docs/templating.md).
2{}�
srcs�Existing environment files to merge in.

Files are read in order and later files win. Anything set via `env` overrides
all of them.2[]@
path"Path of the file inside the image.2"/etc/environment"�
quote�Whether to wrap values in double quotes.

Quoting is conventional and is what a distribution ships. Turn it off only if
something in the image parses the file naively.2TrueA
mode3Octal file mode, e.g. `"0644"`. Defaults to `0644`.2""">
etc_environment+@rules_img//img/private/base_images:etc.bzl*m
BaseImageContentInfoU
BaseImageContentInfo=@rules_img//img/private/providers:base_image_content_info.bzl,
*
nameA unique name for this target. �
�
build_settings�Build settings for template expansion.

Maps template variable names to `string_flag` targets. The values can be
referenced from this rule's templated attributes with `{{.VARIABLE_NAME}}`
(Go template syntax).

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"J"auto"J"force"J
"disabled"�
�
envyEnvironment variables to write, as a mapping of name to value.

Values support [template expansion](/docs/templating.md).
2{}�
�
srcs�Existing environment files to merge in.

Files are read in order and later files win. Anything set via `env` overrides
all of them.2[]B
@
path"Path of the file inside the image.2"/etc/environment"�
�
quote�Whether to wrap values in double quotes.

Quoting is conventional and is what a distribution ships. Turn it off only if
something in the image parses the file naively.2TrueC
A
mode3Octal file mode, e.g. `"0644"`. Defaults to `0644`.2""�!	etc_hosts�Describes `/etc/hosts`, the static hostname table.

Names accumulate per address rather than replacing each other, so the default
loopback entries and your own names for `127.0.0.1` end up on the same line.

This rule only applies when targeting Linux. On any other platform it is a
no-op that contributes nothing to the layer.

Example:

```python
load("@rules_img//img:base_images.bzl", "etc_hosts")

etc_hosts(
    name = "hosts",
    hosts = {
        "10.0.0.7": "database db.internal",
        "127.0.0.1": "myapp.local",
    },
)
```"�
�
	etc_hosts�Describes `/etc/hosts`, the static hostname table.

Names accumulate per address rather than replacing each other, so the default
loopback entries and your own names for `127.0.0.1` end up on the same line.

This rule only applies when targeting Linux. On any other platform it is a
no-op that contributes nothing to the layer.

Example:

```python
load("@rules_img//img:base_images.bzl", "etc_hosts")

etc_hosts(
    name = "hosts",
    hosts = {
        "10.0.0.7": "database db.internal",
        "127.0.0.1": "myapp.local",
    },
)
```*
nameA unique name for this target. �
build_settings�Build settings for template expansion.

Maps template variable names to `string_flag` targets. The values can be
referenced from this rule's templated attributes with `{{.VARIABLE_NAME}}`
(Go template syntax).

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"J"auto"J"force"J
"disabled"�
hosts�Host mappings, as a mapping of IP address to space-separated host names.

Values support [template expansion](/docs/templating.md).
2{}>
srcs0Existing hosts files to merge in, read in order.2[]�
include_defaults�Whether to include the standard loopback entries.

These are the `127.0.0.1 localhost` and IPv6 `::1`/`ff02::` entries that
`netbase` ships. Without them, resolving `localhost` inside the container
depends on the resolver's own fallbacks.2True:
path"Path of the file inside the image.2"/etc/hosts"A
mode3Octal file mode, e.g. `"0644"`. Defaults to `0644`.2"""8
	etc_hosts+@rules_img//img/private/base_images:etc.bzl*m
BaseImageContentInfoU
BaseImageContentInfo=@rules_img//img/private/providers:base_image_content_info.bzl,
*
nameA unique name for this target. �
�
build_settings�Build settings for template expansion.

Maps template variable names to `string_flag` targets. The values can be
referenced from this rule's templated attributes with `{{.VARIABLE_NAME}}`
(Go template syntax).

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"J"auto"J"force"J
"disabled"�
�
hosts�Host mappings, as a mapping of IP address to space-separated host names.

Values support [template expansion](/docs/templating.md).
2{}@
>
srcs0Existing hosts files to merge in, read in order.2[]�
�
include_defaults�Whether to include the standard loopback entries.

These are the `127.0.0.1 localhost` and IPv6 `::1`/`ff02::` entries that
`netbase` ships. Without them, resolving `localhost` inside the container
depends on the resolver's own fallbacks.2True<
:
path"Path of the file inside the image.2"/etc/hosts"C
A
mode3Octal file mode, e.g. `"0644"`. Defaults to `0644`.2""�0etc_release�Describes `/etc/os-release` (and optionally `/etc/lsb-release`).

`os-release` is the standard way for software in the image to identify the
distribution it is running on. Values are always written double-quoted, which is
valid for every field.

By default the real file is written to `/usr/lib/os-release` with
`/etc/os-release` as a relative symlink to it, which is what
[os-release(5)](https://www.freedesktop.org/software/systemd/man/os-release.html)
specifies so the identity travels with `/usr`.

This rule only applies when targeting Linux. On any other platform it is a
no-op that contributes nothing to the layer.

Example:

```python
load("@rules_img//img:base_images.bzl", "etc_release")

etc_release(
    name = "release",
    os_release = {
        "ID": "acme-base",
        "NAME": "ACME Base Image",
        "PRETTY_NAME": "ACME Base Image {{.VERSION}}",
        "VERSION_ID": "{{.VERSION}}",
    },
    build_settings = {"VERSION": "//settings:version"},
)
```"�)
�
etc_release�Describes `/etc/os-release` (and optionally `/etc/lsb-release`).

`os-release` is the standard way for software in the image to identify the
distribution it is running on. Values are always written double-quoted, which is
valid for every field.

By default the real file is written to `/usr/lib/os-release` with
`/etc/os-release` as a relative symlink to it, which is what
[os-release(5)](https://www.freedesktop.org/software/systemd/man/os-release.html)
specifies so the identity travels with `/usr`.

This rule only applies when targeting Linux. On any other platform it is a
no-op that contributes nothing to the layer.

Example:

```python
load("@rules_img//img:base_images.bzl", "etc_release")

etc_release(
    name = "release",
    os_release = {
        "ID": "acme-base",
        "NAME": "ACME Base Image",
        "PRETTY_NAME": "ACME Base Image {{.VERSION}}",
        "VERSION_ID": "{{.VERSION}}",
    },
    build_settings = {"VERSION": "//settings:version"},
)
```*
nameA unique name for this target. �
build_settings�Build settings for template expansion.

Maps template variable names to `string_flag` targets. The values can be
referenced from this rule's templated attributes with `{{.VARIABLE_NAME}}`
(Go template syntax).

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"J"auto"J"force"J
"disabled"�

os_releasen`os-release` entries, as a mapping of key to value.

Values support [template expansion](/docs/templating.md).
2{}�
lsb_release�`lsb-release` entries, as a mapping of key to value.

Only written when `write_lsb_release` is True. Values support
[template expansion](/docs/templating.md).
2{}N
os_release_srcs5Existing os-release files to merge in, read in order.2[]P
lsb_release_srcs6Existing lsb-release files to merge in, read in order.2[]�
write_lsb_release{Whether to also write the older LSB release file.

Most images do not need it; `os-release` is what current software reads.2False�
usr_lib_symlink�Whether to write the real file under `/usr/lib` and make `/etc/os-release` a symlink.

Set to False to write a plain file at `os_release_path` instead.2Truef
os_release_path>Path of the os-release file (or its symlink) inside the image.2"/etc/os-release"i
usr_lib_path@Path of the real os-release file when `usr_lib_symlink` is True.2"/usr/lib/os-release"X
lsb_release_path.Path of the lsb-release file inside the image.2"/etc/lsb-release"A
mode3Octal file mode, e.g. `"0644"`. Defaults to `0644`.2""":
etc_release+@rules_img//img/private/base_images:etc.bzl*m
BaseImageContentInfoU
BaseImageContentInfo=@rules_img//img/private/providers:base_image_content_info.bzl,
*
nameA unique name for this target. �
�
build_settings�Build settings for template expansion.

Maps template variable names to `string_flag` targets. The values can be
referenced from this rule's templated attributes with `{{.VARIABLE_NAME}}`
(Go template syntax).

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"J"auto"J"force"J
"disabled"�
�

os_releasen`os-release` entries, as a mapping of key to value.

Values support [template expansion](/docs/templating.md).
2{}�
�
lsb_release�`lsb-release` entries, as a mapping of key to value.

Only written when `write_lsb_release` is True. Values support
[template expansion](/docs/templating.md).
2{}P
N
os_release_srcs5Existing os-release files to merge in, read in order.2[]R
P
lsb_release_srcs6Existing lsb-release files to merge in, read in order.2[]�
�
write_lsb_release{Whether to also write the older LSB release file.

Most images do not need it; `os-release` is what current software reads.2False�
�
usr_lib_symlink�Whether to write the real file under `/usr/lib` and make `/etc/os-release` a symlink.

Set to False to write a plain file at `os_release_path` instead.2Trueh
f
os_release_path>Path of the os-release file (or its symlink) inside the image.2"/etc/os-release"k
i
usr_lib_path@Path of the real os-release file when `usr_lib_symlink` is True.2"/usr/lib/os-release"Z
X
lsb_release_path.Path of the lsb-release file inside the image.2"/etc/lsb-release"C
A
mode3Octal file mode, e.g. `"0644"`. Defaults to `0644`.2""�;linux_skeleton�Describes the empty directory skeleton of a Linux base image.

The defaults are a working Filesystem Hierarchy Standard layout with the modes a
stock distribution uses: `0755` for anything the system owns, `1777` for the
shared scratch directories, `0700` for `/root`, and `0555` for the kernel
pseudo-filesystem mount points. Each group of directories can be turned off
individually.

This rule only applies when targeting Linux. On any other platform it is a
no-op that contributes nothing to the layer.

Example:

```python
load("@rules_img//img:base_images.bzl", "linux_skeleton")

# A minimal skeleton for a static binary that needs nowhere to write.
linux_skeleton(
    name = "skeleton",
    home = "disabled",
    opt_srv = "disabled",
    var = "disabled",
)
```"�5
�
linux_skeleton�Describes the empty directory skeleton of a Linux base image.

The defaults are a working Filesystem Hierarchy Standard layout with the modes a
stock distribution uses: `0755` for anything the system owns, `1777` for the
shared scratch directories, `0700` for `/root`, and `0555` for the kernel
pseudo-filesystem mount points. Each group of directories can be turned off
individually.

This rule only applies when targeting Linux. On any other platform it is a
no-op that contributes nothing to the layer.

Example:

```python
load("@rules_img//img:base_images.bzl", "linux_skeleton")

# A minimal skeleton for a static binary that needs nowhere to write.
linux_skeleton(
    name = "skeleton",
    home = "disabled",
    opt_srv = "disabled",
    var = "disabled",
)
```*
nameA unique name for this target. �
build_settings�Build settings for template expansion.

Maps template variable names to `string_flag` targets. The values can be
referenced from this rule's templated attributes with `{{.VARIABLE_NAME}}`
(Go template syntax).

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"J"auto"J"force"J
"disabled"�

usr_merged�Whether to use the merged-`/usr` layout.

When True, `/bin`, `/sbin`, `/lib` and `/lib64` are symlinks into `/usr`, as
every current distribution does. When False they are real directories.

Set the same value on `system_libraries`, which places libraries accordingly.
Mismatching them fails the build rather than producing an image whose libraries
sit inside a symlink and cannot be found.2TrueI
etcWhether to create `/etc`.2"auto"J"auto"J	"enabled"J
"disabled"�
bin_and_lib�Whether to create the binary and library directories.

Covers `/usr` and its subdirectories, plus the top-level `/bin`, `/sbin`, `/lib`
and `/lib64` (as symlinks or real directories, per `usr_merged`).2"auto"J"auto"J	"enabled"J
"disabled"K
homeWhether to create `/home`.2"auto"J"auto"J	"enabled"J
"disabled"]
root,Whether to create `/root`, with mode `0700`.2"auto"J"auto"J	"enabled"J
"disabled"f
tmp6Whether to create `/tmp`, with the sticky mode `1777`.2"auto"J"auto"J	"enabled"J
"disabled"�
var�Whether to create `/var` and its standard subdirectories.

Covers `/var/log`, `/var/tmp` (sticky), `/var/cache`, `/var/lib` and
`/var/spool`. When the `run` group is enabled too, `/var/run` and `/var/lock`
are added as symlinks into `/run`.2"auto"J"auto"J	"enabled"J
"disabled"Y
run)Whether to create `/run` and `/run/lock`.2"auto"J"auto"J	"enabled"J
"disabled"�
mount_points�Whether to create the standard mount points.

Covers `/dev`, `/proc` and `/sys` (the kernel pseudo-filesystems a runtime
mounts over) plus `/mnt` and `/media`.2"auto"J"auto"J	"enabled"J
"disabled"X
opt_srv$Whether to create `/opt` and `/srv`.2"auto"J"auto"J	"enabled"J
"disabled"�
extra_directories�Additional directories to create, mapping path to JSON-encoded metadata.

Build the metadata with `file_metadata()` from `@rules_img//img:layer.bzl`. An
empty value uses mode `0755`, owned by root.

```python
extra_directories = {
    "/var/lib/myapp": file_metadata(mode = "0750", uid = 1000, gid = 1000),
}
```
2{}"H
linux_skeleton6@rules_img//img/private/base_images:linux_skeleton.bzl*m
BaseImageContentInfoU
BaseImageContentInfo=@rules_img//img/private/providers:base_image_content_info.bzl,
*
nameA unique name for this target. �
�
build_settings�Build settings for template expansion.

Maps template variable names to `string_flag` targets. The values can be
referenced from this rule's templated attributes with `{{.VARIABLE_NAME}}`
(Go template syntax).

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"J"auto"J"force"J
"disabled"�
�

usr_merged�Whether to use the merged-`/usr` layout.

When True, `/bin`, `/sbin`, `/lib` and `/lib64` are symlinks into `/usr`, as
every current distribution does. When False they are real directories.

Set the same value on `system_libraries`, which places libraries accordingly.
Mismatching them fails the build rather than producing an image whose libraries
sit inside a symlink and cannot be found.2TrueK
I
etcWhether to create `/etc`.2"auto"J"auto"J	"enabled"J
"disabled"�
�
bin_and_lib�Whether to create the binary and library directories.

Covers `/usr` and its subdirectories, plus the top-level `/bin`, `/sbin`, `/lib`
and `/lib64` (as symlinks or real directories, per `usr_merged`).2"auto"J"auto"J	"enabled"J
"disabled"M
K
homeWhether to create `/home`.2"auto"J"auto"J	"enabled"J
"disabled"_
]
root,Whether to create `/root`, with mode `0700`.2"auto"J"auto"J	"enabled"J
"disabled"h
f
tmp6Whether to create `/tmp`, with the sticky mode `1777`.2"auto"J"auto"J	"enabled"J
"disabled"�
�
var�Whether to create `/var` and its standard subdirectories.

Covers `/var/log`, `/var/tmp` (sticky), `/var/cache`, `/var/lib` and
`/var/spool`. When the `run` group is enabled too, `/var/run` and `/var/lock`
are added as symlinks into `/run`.2"auto"J"auto"J	"enabled"J
"disabled"[
Y
run)Whether to create `/run` and `/run/lock`.2"auto"J"auto"J	"enabled"J
"disabled"�
�
mount_points�Whether to create the standard mount points.

Covers `/dev`, `/proc` and `/sys` (the kernel pseudo-filesystems a runtime
mounts over) plus `/mnt` and `/media`.2"auto"J"auto"J	"enabled"J
"disabled"Z
X
opt_srv$Whether to create `/opt` and `/srv`.2"auto"J"auto"J	"enabled"J
"disabled"�
�
extra_directories�Additional directories to create, mapping path to JSON-encoded metadata.

Build the metadata with `file_metadata()` from `@rules_img//img:layer.bzl`. An
empty value uses mode `0755`, owned by root.

```python
extra_directories = {
    "/var/lib/myapp": file_metadata(mode = "0750", uid = 1000, gid = 1000),
}
```
2{}�?system_libraries�	Describes the shared libraries of a Linux base image.

Each library is placed in the configured library directory and given the
symlink named after its `SONAME`, which is the name the dynamic linker actually
resolves a dependency through. The `SONAME` is read out of the ELF file itself,
so a library named `libssl.so.3.0.14` automatically gains the `libssl.so.3` the
loader looks for.

An `/etc/ld.so.conf.d` fragment records the library directory, and a prebuilt
`/etc/ld.so.cache` can be generated so the loader does not have to scan at
startup.

Every file in `libs` must be an ELF shared object; anything else fails the
build. To pull the shared libraries out of a `cc_library`, name its output files
directly, or use a `filegroup` with the relevant output group -- this rule takes
plain files rather than `CcInfo` so that rules_img does not have to depend on
`rules_cc`.

This rule only applies when targeting Linux. On any other platform it is a
no-op that contributes nothing to the layer.

Example:

```python
load("@rules_img//img:base_images.bzl", "system_libraries")

system_libraries(
    name = "libs",
    libs = [
        "@sysroot//:lib/libssl.so.3.0.14",
        "@sysroot//:lib/libcrypto.so.3.0.14",
    ],
    libdir_layout = "multiarch",
)
```"�4
� 
system_libraries�	Describes the shared libraries of a Linux base image.

Each library is placed in the configured library directory and given the
symlink named after its `SONAME`, which is the name the dynamic linker actually
resolves a dependency through. The `SONAME` is read out of the ELF file itself,
so a library named `libssl.so.3.0.14` automatically gains the `libssl.so.3` the
loader looks for.

An `/etc/ld.so.conf.d` fragment records the library directory, and a prebuilt
`/etc/ld.so.cache` can be generated so the loader does not have to scan at
startup.

Every file in `libs` must be an ELF shared object; anything else fails the
build. To pull the shared libraries out of a `cc_library`, name its output files
directly, or use a `filegroup` with the relevant output group -- this rule takes
plain files rather than `CcInfo` so that rules_img does not have to depend on
`rules_cc`.

This rule only applies when targeting Linux. On any other platform it is a
no-op that contributes nothing to the layer.

Example:

```python
load("@rules_img//img:base_images.bzl", "system_libraries")

system_libraries(
    name = "libs",
    libs = [
        "@sysroot//:lib/libssl.so.3.0.14",
        "@sysroot//:lib/libcrypto.so.3.0.14",
    ],
    libdir_layout = "multiarch",
)
```*
nameA unique name for this target. �
build_settings�Build settings for template expansion.

Maps template variable names to `string_flag` targets. The values can be
referenced from this rule's templated attributes with `{{.VARIABLE_NAME}}`
(Go template syntax).

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"J"auto"J"force"J
"disabled"�
libs�Shared library files to place in the image.

Every file must be an ELF shared object. Two targets contributing the same
library are fine; two different files that would land at the same name are an
error.2[]�

usr_merged�Whether the image uses the merged-`/usr` layout.

When True, libraries go under `/usr/lib`; when False, under `/lib`.

Set the same value on `linux_skeleton`, which is what creates the
`/lib -> usr/lib` symlink. Mismatching them fails the build: placing a library
at `/lib/...` when the skeleton made `/lib` a symlink would produce an image
whose libraries are unreachable.2True�
libdir_layout�How the library directory is named.

- **`plain`** (default): `/usr/lib`.
- **`lib64`**: `/usr/lib64`, as Fedora and its derivatives use.
- **`multiarch`**: `/usr/lib/<tuple>` with the Debian multiarch tuple for the
  target architecture, e.g. `/usr/lib/x86_64-linux-gnu`.2"plain"J"plain"J"lib64"J"multiarch"c
	ldso_confNWhether to write an `/etc/ld.so.conf.d` fragment naming the library directory.2True�

ldso_cache�Whether to write a prebuilt `/etc/ld.so.cache`.

The cache is glibc-specific; musl ignores the file entirely. It saves the loader
a directory scan at startup, at the cost of a file that must be regenerated
whenever the library set changes -- which is why it is off by default.2False�
default_metadatayJSON-encoded metadata applied to every placed library.

Build it with `file_metadata()` from `@rules_img//img:layer.bzl`.2""�
file_metadata�Per-file metadata overrides, mapping image path to JSON-encoded metadata.

The path must be the library's full path in the image, including the library
directory.
2{}T
modeFOctal mode of the placed libraries, e.g. `"0755"`. Defaults to `0755`.2"""L
system_libraries8@rules_img//img/private/base_images:system_libraries.bzl*m
BaseImageContentInfoU
BaseImageContentInfo=@rules_img//img/private/providers:base_image_content_info.bzl,
*
nameA unique name for this target. �
�
build_settings�Build settings for template expansion.

Maps template variable names to `string_flag` targets. The values can be
referenced from this rule's templated attributes with `{{.VARIABLE_NAME}}`
(Go template syntax).

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"J"auto"J"force"J
"disabled"�
�
libs�Shared library files to place in the image.

Every file must be an ELF shared object. Two targets contributing the same
library are fine; two different files that would land at the same name are an
error.2[]�
�

usr_merged�Whether the image uses the merged-`/usr` layout.

When True, libraries go under `/usr/lib`; when False, under `/lib`.

Set the same value on `linux_skeleton`, which is what creates the
`/lib -> usr/lib` symlink. Mismatching them fails the build: placing a library
at `/lib/...` when the skeleton made `/lib` a symlink would produce an image
whose libraries are unreachable.2True�
�
libdir_layout�How the library directory is named.

- **`plain`** (default): `/usr/lib`.
- **`lib64`**: `/usr/lib64`, as Fedora and its derivatives use.
- **`multiarch`**: `/usr/lib/<tuple>` with the Debian multiarch tuple for the
  target architecture, e.g. `/usr/lib/x86_64-linux-gnu`.2"plain"J"plain"J"lib64"J"multiarch"e
c
	ldso_confNWhether to write an `/etc/ld.so.conf.d` fragment naming the library directory.2True�
�

ldso_cache�Whether to write a prebuilt `/etc/ld.so.cache`.

The cache is glibc-specific; musl ignores the file entirely. It saves the loader
a directory scan at startup, at the cost of a file that must be regenerated
whenever the library set changes -- which is why it is off by default.2False�
�
default_metadatayJSON-encoded metadata applied to every placed library.

Build it with `file_metadata()` from `@rules_img//img:layer.bzl`.2""�
�
file_metadata�Per-file metadata overrides, mapping image path to JSON-encoded metadata.

The path must be the library's full path in the image, including the library
directory.
2{}V
T
modeFOctal mode of the placed libraries, e.g. `"0755"`. Defaults to `0755`.2""�5
etc_passwd�Describes `/etc/passwd`, `/etc/group`, `/etc/shadow` and home directories.

Users and groups are declared with the `passwd_entry()` and `group_entry()`
helpers, and may also be merged in from existing files. Duplicate user names,
UIDs, group names or GIDs are an error rather than a last-one-wins merge.

Shadow entries are always written locked (`!*`). This rule never accepts a
password hash: anything it wrote would be readable by anyone who can pull the
image or read the Bazel cache.

This rule applies when targeting any Unix-like platform (Linux, macOS, the
BSDs). On Windows it is a no-op that contributes nothing to the layer.

Example:

```python
load("@rules_img//img:base_images.bzl", "etc_passwd", "group_entry", "passwd_entry")

etc_passwd(
    name = "users",
    users = [
        passwd_entry(username = "root", uid = 0, gid = 0, home = "/root", shell = "/bin/sh"),
        passwd_entry(username = "app", uid = 1000, gid = 1000, home = "/home/app"),
    ],
    groups = [
        group_entry(name = "root", gid = 0),
        group_entry(name = "app", gid = 1000, users = ["app"]),
    ],
)
```"�,
�

etc_passwd�Describes `/etc/passwd`, `/etc/group`, `/etc/shadow` and home directories.

Users and groups are declared with the `passwd_entry()` and `group_entry()`
helpers, and may also be merged in from existing files. Duplicate user names,
UIDs, group names or GIDs are an error rather than a last-one-wins merge.

Shadow entries are always written locked (`!*`). This rule never accepts a
password hash: anything it wrote would be readable by anyone who can pull the
image or read the Bazel cache.

This rule applies when targeting any Unix-like platform (Linux, macOS, the
BSDs). On Windows it is a no-op that contributes nothing to the layer.

Example:

```python
load("@rules_img//img:base_images.bzl", "etc_passwd", "group_entry", "passwd_entry")

etc_passwd(
    name = "users",
    users = [
        passwd_entry(username = "root", uid = 0, gid = 0, home = "/root", shell = "/bin/sh"),
        passwd_entry(username = "app", uid = 1000, gid = 1000, home = "/home/app"),
    ],
    groups = [
        group_entry(name = "root", gid = 0),
        group_entry(name = "app", gid = 1000, users = ["app"]),
    ],
)
```*
nameA unique name for this target. �
build_settings�Build settings for template expansion.

Maps template variable names to `string_flag` targets. The values can be
referenced from this rule's templated attributes with `{{.VARIABLE_NAME}}`
(Go template syntax).

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"J"auto"J"force"J
"disabled"�
usersvUsers to define, as JSON strings built by `passwd_entry()`.

Values support [template expansion](/docs/templating.md).2[]�
groupsvGroups to define, as JSON strings built by `group_entry()`.

Values support [template expansion](/docs/templating.md).2[]7
passwd_srcs"Existing passwd files to merge in.2[]5

group_srcs!Existing group files to merge in.2[]�
shadow_srcs�Existing shadow files to merge in.

Records found here are carried over verbatim, ageing fields included. Users with
no record get a locked entry.2[]�
create_home_directories�Whether to create a directory for each user's home.

Users whose home is `/` (the convention for a system account without one) are
skipped. Root's home is always created with mode `0700`.2TrueT
write_shadow<Whether to write `/etc/shadow` with a locked entry per user.2TrueH
home_directory_mode'Octal mode of created home directories.2"0750"I
passwd_path)Path of the passwd file inside the image.2"/etc/passwd"F

group_path(Path of the group file inside the image.2"/etc/group"I
shadow_path)Path of the shadow file inside the image.2"/etc/shadow"P
modeBOctal mode of passwd and group, e.g. `"0644"`. Defaults to `0644`.2""G
shadow_mode2Octal mode of the shadow file. Defaults to `0640`.2"""9

etc_passwd+@rules_img//img/private/base_images:etc.bzl*m
BaseImageContentInfoU
BaseImageContentInfo=@rules_img//img/private/providers:base_image_content_info.bzl,
*
nameA unique name for this target. �
�
build_settings�Build settings for template expansion.

Maps template variable names to `string_flag` targets. The values can be
referenced from this rule's templated attributes with `{{.VARIABLE_NAME}}`
(Go template syntax).

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"J"auto"J"force"J
"disabled"�
�
usersvUsers to define, as JSON strings built by `passwd_entry()`.

Values support [template expansion](/docs/templating.md).2[]�
�
groupsvGroups to define, as JSON strings built by `group_entry()`.

Values support [template expansion](/docs/templating.md).2[]9
7
passwd_srcs"Existing passwd files to merge in.2[]7
5

group_srcs!Existing group files to merge in.2[]�
�
shadow_srcs�Existing shadow files to merge in.

Records found here are carried over verbatim, ageing fields included. Users with
no record get a locked entry.2[]�
�
create_home_directories�Whether to create a directory for each user's home.

Users whose home is `/` (the convention for a system account without one) are
skipped. Root's home is always created with mode `0700`.2TrueV
T
write_shadow<Whether to write `/etc/shadow` with a locked entry per user.2TrueJ
H
home_directory_mode'Octal mode of created home directories.2"0750"K
I
passwd_path)Path of the passwd file inside the image.2"/etc/passwd"H
F

group_path(Path of the group file inside the image.2"/etc/group"K
I
shadow_path)Path of the shadow file inside the image.2"/etc/shadow"R
P
modeBOctal mode of passwd and group, e.g. `"0644"`. Defaults to `0644`.2""I
G
shadow_mode2Octal mode of the shadow file. Defaults to `0640`.2""�<trust_store�
Describes a CA certificate trust store.

Certificates are collected from raw files and from distribution packages,
deduplicated, and written in whichever layouts the image needs:

- a single concatenated PEM bundle, which is what `SSL_CERT_FILE` and most TLS
  libraries expect
- an exploded directory of one PEM file per certificate plus the
  `<subject_hash>.0` symlinks OpenSSL resolves `SSL_CERT_DIR` lookups through
- a PKCS#12 truststore for the JVM

Inputs are parsed strictly: a file that is not PEM, DER or PKCS#7 fails the
build rather than being skipped, because a base image quietly missing a CA fails
much later and much more confusingly.

Package inputs are typed separately from raw certificates so the two cannot be
mixed up. Only files under the standard CA certificate directories are read out
of a package; no other package metadata is interpreted. Packages whose payload
is xz-compressed are rejected: decompressing them would mean taking on a
dependency the core `img` tool deliberately does without.

Everything except the exploded tree is platform-independent, so this rule
applies on every target platform.

Example:

```python
load("@rules_img//img:base_images.bzl", "trust_store")

trust_store(
    name = "trust",
    certs = ["//pki:corporate-root.pem"],
    debs = ["@bookworm//ca-certificates/amd64:data"],
    java_keystore = True,
)
```"�1
�
trust_store�
Describes a CA certificate trust store.

Certificates are collected from raw files and from distribution packages,
deduplicated, and written in whichever layouts the image needs:

- a single concatenated PEM bundle, which is what `SSL_CERT_FILE` and most TLS
  libraries expect
- an exploded directory of one PEM file per certificate plus the
  `<subject_hash>.0` symlinks OpenSSL resolves `SSL_CERT_DIR` lookups through
- a PKCS#12 truststore for the JVM

Inputs are parsed strictly: a file that is not PEM, DER or PKCS#7 fails the
build rather than being skipped, because a base image quietly missing a CA fails
much later and much more confusingly.

Package inputs are typed separately from raw certificates so the two cannot be
mixed up. Only files under the standard CA certificate directories are read out
of a package; no other package metadata is interpreted. Packages whose payload
is xz-compressed are rejected: decompressing them would mean taking on a
dependency the core `img` tool deliberately does without.

Everything except the exploded tree is platform-independent, so this rule
applies on every target platform.

Example:

```python
load("@rules_img//img:base_images.bzl", "trust_store")

trust_store(
    name = "trust",
    certs = ["//pki:corporate-root.pem"],
    debs = ["@bookworm//ca-certificates/amd64:data"],
    java_keystore = True,
)
```*
nameA unique name for this target. �
build_settings�Build settings for template expansion.

Maps template variable names to `string_flag` targets. The values can be
referenced from this rule's templated attributes with `{{.VARIABLE_NAME}}`
(Go template syntax).

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"J"auto"J"force"J
"disabled"�
certs�Certificate files, in PEM, DER or PKCS#7 form.

A PEM file may hold any number of certificates. Blocks that are not certificates
(a key or a CRL sitting in the same file) are skipped.2[]
debsqDebian packages to harvest certificates from.

Only files under the standard CA certificate directories are read.2[]|
rpmsnRPM packages to harvest certificates from.

Only files under the standard CA certificate directories are read.2[]D
bundle2Whether to write a single concatenated PEM bundle.2True_
bundle_path(Path of the PEM bundle inside the image.2$"/etc/ssl/certs/ca-certificates.crt"�
exploded�Whether to write the exploded certificate directory.

This is the layout OpenSSL walks when an application sets `SSL_CERT_DIR` or
relies on the compiled-in default.2True`
exploded_dir<Directory of the exploded certificate tree inside the image.2"/etc/ssl/certs"�
java_keystore�Whether to write a PKCS#12 truststore for the JVM.

The store holds trusted certificate entries only and contains no private keys,
so the password protects only its integrity check.2Falseg
java_keystore_path0Path of the PKCS#12 truststore inside the image.2"/etc/ssl/certs/java/cacerts"�
java_keystore_password�Password protecting the truststore's integrity check.

`changeit` is the JDK's own default and what tooling assumes. There is no secret
in the store, so the value is not sensitive.2
"changeit"Q
modeCOctal mode of the written files, e.g. `"0644"`. Defaults to `0644`.2"""B
trust_store3@rules_img//img/private/base_images:trust_store.bzl*m
BaseImageContentInfoU
BaseImageContentInfo=@rules_img//img/private/providers:base_image_content_info.bzl,
*
nameA unique name for this target. �
�
build_settings�Build settings for template expansion.

Maps template variable names to `string_flag` targets. The values can be
referenced from this rule's templated attributes with `{{.VARIABLE_NAME}}`
(Go template syntax).

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"J"auto"J"force"J
"disabled"�
�
certs�Certificate files, in PEM, DER or PKCS#7 form.

A PEM file may hold any number of certificates. Blocks that are not certificates
(a key or a CRL sitting in the same file) are skipped.2[]�

debsqDebian packages to harvest certificates from.

Only files under the standard CA certificate directories are read.2[]~
|
rpmsnRPM packages to harvest certificates from.

Only files under the standard CA certificate directories are read.2[]F
D
bundle2Whether to write a single concatenated PEM bundle.2Truea
_
bundle_path(Path of the PEM bundle inside the image.2$"/etc/ssl/certs/ca-certificates.crt"�
�
exploded�Whether to write the exploded certificate directory.

This is the layout OpenSSL walks when an application sets `SSL_CERT_DIR` or
relies on the compiled-in default.2Trueb
`
exploded_dir<Directory of the exploded certificate tree inside the image.2"/etc/ssl/certs"�
�
java_keystore�Whether to write a PKCS#12 truststore for the JVM.

The store holds trusted certificate entries only and contains no private keys,
so the password protects only its integrity check.2Falsei
g
java_keystore_path0Path of the PKCS#12 truststore inside the image.2"/etc/ssl/certs/java/cacerts"�
�
java_keystore_password�Password protecting the truststore's integrity check.

`changeit` is the JDK's own default and what tooling assumes. There is no secret
in the store, so the value is not sensitive.2
"changeit"S
Q
modeCOctal mode of the written files, e.g. `"0644"`. Defaults to `0644`.2""�passwd_entry=Describes one user for the `users` attribute of `etc_passwd`.*�
�
passwd_entry#
usernameLogin name. String. ($
uidNumeric user ID. Integer. (;
gid0Numeric ID of the user's primary group. Integer. (F
gecos5Human-readable description (the GECOS field). String.None(K
home;Home directory. Defaults to `/`, meaning the user has none.None(Z
shellILogin shell. Defaults to `/sbin/nologin`, which denies interactive login.None(=Describes one user for the `users` attribute of `etc_passwd`.",
*A JSON-encoded string describing the user.2;
passwd_entry+@rules_img//img/private/base_images:etc.bzl%
#
usernameLogin name. String. (&
$
uidNumeric user ID. Integer. (=
;
gid0Numeric ID of the user's primary group. Integer. (H
F
gecos5Human-readable description (the GECOS field). String.None(M
K
home;Home directory. Defaults to `/`, meaning the user has none.None(\
Z
shellILogin shell. Defaults to `/sbin/nologin`, which denies interactive login.None(�group_entry?Describes one group for the `groups` attribute of `etc_passwd`.*�
�
group_entry
nameGroup name. String. (%
gidNumeric group ID. Integer. (�
usersrNames of users who are members of this group beyond the ones that
have it as their primary group. List of strings.None(?Describes one group for the `groups` attribute of `etc_passwd`."-
+A JSON-encoded string describing the group.2:
group_entry+@rules_img//img/private/base_images:etc.bzl!

nameGroup name. String. ('
%
gidNumeric group ID. Integer. (�
�
usersrNames of users who are members of this group beyond the ones that
have it as their primary group. List of strings.None(�
Public API for building bespoke container base images.

These rules describe the contents of a base image -- the directory skeleton,
users and groups, the CA trust store, shared libraries, the standard files under
`/etc` -- without building a layer. Each returns a `BaseImageContentInfo`
carrying nothing but tar entry metadata (plus the files that metadata points
at), so a description costs almost nothing to propagate through dependencies.

`base_image_layer` is what finally materializes them: it takes any number of
descriptions and merges them into a single flat layer.

Rules are scoped to the platforms they make sense on. `linux_skeleton` is
Linux-only, `etc_passwd` applies to any Unix, and `trust_store` applies
everywhere. A rule outside its scope is a no-op rather than an error, so one
BUILD file can describe a base image for several platforms without a `select()`
around every rule.

```python
load(
    "@rules_img//img:base_images.bzl",
    "base_image_layer",
    "etc_passwd",
    "linux_skeleton",
    "passwd_entry",
    "trust_store",
)

linux_skeleton(name = "skeleton")

etc_passwd(
    name = "users",
    users = [passwd_entry(username = "app", uid = 1000, gid = 1000, home = "/home/app")],
)

trust_store(
    name = "trust",
    debs = ["@bookworm//ca-certificates/amd64:data"],
)

base_image_layer(
    name = "base_layer",
    srcs = [":skeleton", ":users", ":trust"],
)
```�z

	rules_imgimgconvert.bzl�image_manifest_from_oci_layout"�
�
image_manifest_from_oci_layout*
nameA unique name for this target. C
src8The directory containing the OCI layout to convert from. �
architecture/The target architecture for the image manifest. J"386"J"amd64"J"arm"J"arm64"J"mips64"J	"ppc64le"J	"riscv64"�
os3The target operating system for the image manifest. J	"android"J"darwin"J	"freebsd"J"ios"J"linux"J"netbsd"J	"openbsd"J"wasip1"J	"windows"o
layersaA list of layer media types. Use the well-defined media types in @rules_img//img:media_types.bzl. S
variantBThe platform variant (e.g., 'v3' for amd64/v3, 'v8' for arm64/v8).2"""a
image_manifest_from_oci_layout?@rules_img//img/private/conversion:manifest_from_oci_layout.bzl*]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl,
*
nameA unique name for this target. E
C
src8The directory containing the OCI layout to convert from. �
�
architecture/The target architecture for the image manifest. J"386"J"amd64"J"arm"J"arm64"J"mips64"J	"ppc64le"J	"riscv64"�
�
os3The target operating system for the image manifest. J	"android"J"darwin"J	"freebsd"J"ios"J"linux"J"netbsd"J	"openbsd"J"wasip1"J	"windows"q
o
layersaA list of layer media types. Use the well-defined media types in @rules_img//img:media_types.bzl. U
S
variantBThe platform variant (e.g., 'v3' for amd64/v3, 'v8' for arm64/v8).2""�image_index_from_oci_layout�Converts an OCI layout directory to an image index when you know the layer media types.

For multi-platform tar archives, use `image_index_from_archive`. If you do not know the layer count, use `image_flatten`."�

�
image_index_from_oci_layout�Converts an OCI layout directory to an image index when you know the layer media types.

For multi-platform tar archives, use `image_index_from_archive`. If you do not know the layer count, use `image_flatten`.*
nameA unique name for this target. C
src8The directory containing the OCI layout to convert from. �
layers�A list of layer media types. This applies to all manifests. Use the well-defined media types in @rules_img//img:media_types.bzl. �
	manifests�An ordered list of platform specifications in 'os/architecture' or 'os/architecture/variant' format.
Example: ["linux/arm64", "linux/amd64/v3"] "[
image_index_from_oci_layout<@rules_img//img/private/conversion:index_from_oci_layout.bzl*T
ImageIndexInfoB
ImageIndexInfo0@rules_img//img/private/providers:index_info.bzl,
*
nameA unique name for this target. E
C
src8The directory containing the OCI layout to convert from. �
�
layers�A list of layer media types. This applies to all manifests. Use the well-defined media types in @rules_img//img:media_types.bzl. �
�
	manifests�An ordered list of platform specifications in 'os/architecture' or 'os/architecture/variant' format.
Example: ["linux/arm64", "linux/amd64/v3"] �image_manifest_from_archive�Converts an uncompressed Docker save or OCI layout tar archive to a single-platform image manifest.

Use this rule when the archive layer count is known at Bazel analysis time and you want to preserve individual layers. When the archive layer count is unknown or you want a single squashed layer, use `image_flatten` instead."�
�
image_manifest_from_archive�Converts an uncompressed Docker save or OCI layout tar archive to a single-platform image manifest.

Use this rule when the archive layer count is known at Bazel analysis time and you want to preserve individual layers. When the archive layer count is unknown or you want a single squashed layer, use `image_flatten` instead.*
nameA unique name for this target. L
srcAUncompressed Docker save or OCI layout `.tar` archive to convert. �
architecture/Target CPU architecture for the image manifest. J"386"J"amd64"J"arm"J"arm64"J"mips64"J	"ppc64le"J	"riscv64"J"s390x"J"wasm"�
os/Target operating system for the image manifest. J	"android"J"darwin"J	"freebsd"J"ios"J"linux"J"netbsd"J	"openbsd"J"wasip1"J	"windows"j
layers\Ordered list of layer media types. Use the constants from `@rules_img//img:media_types.bzl`. P
variant?Platform variant, for example 'v3' for amd64 or 'v8' for arm64.2"""M
image_manifest_from_archive.@rules_img//img/private/conversion:archive.bzl*]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl,
*
nameA unique name for this target. N
L
srcAUncompressed Docker save or OCI layout `.tar` archive to convert. �
�
architecture/Target CPU architecture for the image manifest. J"386"J"amd64"J"arm"J"arm64"J"mips64"J	"ppc64le"J	"riscv64"J"s390x"J"wasm"�
�
os/Target operating system for the image manifest. J	"android"J"darwin"J	"freebsd"J"ios"J"linux"J"netbsd"J	"openbsd"J"wasip1"J	"windows"l
j
layers\Ordered list of layer media types. Use the constants from `@rules_img//img:media_types.bzl`. R
P
variant?Platform variant, for example 'v3' for amd64 or 'v8' for arm64.2""�image_index_from_archive�Converts an uncompressed multi-platform OCI layout or Docker save tar archive to an image index.

Use this rule when every platform manifest in the archive has the same known layer count at Bazel analysis time. When layer counts are unknown or vary across platforms, use `image_flatten` with `manifests` instead."�

�
image_index_from_archive�Converts an uncompressed multi-platform OCI layout or Docker save tar archive to an image index.

Use this rule when every platform manifest in the archive has the same known layer count at Bazel analysis time. When layer counts are unknown or vary across platforms, use `image_flatten` with `manifests` instead.*
nameA unique name for this target. [
srcPUncompressed multi-platform OCI layout or Docker save `.tar` archive to convert. �
layersuOrdered list of layer media types applied to each manifest. Use the constants from `@rules_img//img:media_types.bzl`. �
	manifests�Ordered list of platform specifications in 'os/architecture' or 'os/architecture/variant' format.
Example: ["linux/arm64", "linux/amd64/v3"] "J
image_index_from_archive.@rules_img//img/private/conversion:archive.bzl*T
ImageIndexInfoB
ImageIndexInfo0@rules_img//img/private/providers:index_info.bzl,
*
nameA unique name for this target. ]
[
srcPUncompressed multi-platform OCI layout or Docker save `.tar` archive to convert. �
�
layersuOrdered list of layer media types applied to each manifest. Use the constants from `@rules_img//img:media_types.bzl`. �
�
	manifests�Ordered list of platform specifications in 'os/architecture' or 'os/architecture/variant' format.
Example: ["linux/arm64", "linux/amd64/v3"] �@image_flatten�Squashes all layers of a container image or multi-platform image index into a single compressed layer per platform and preserves image configuration.

Accepts either an existing `ImageManifestInfo` or `ImageIndexInfo` target via `image`, or an external container archive or OCI layout directory via `src`. Passing `src` lets Bazel import single-platform or multi-platform Docker save and OCI layout tarballs without knowing their layer counts at analysis time.

Example (single-platform archive):

```python
load("@rules_img//img:convert.bzl", "image_flatten")

image_flatten(
    name = "external_base",
    src = ":docker_save_image.tar",
    os = "linux",
    architecture = "amd64",
)
```

Example (multi-platform archive or OCI layout):

```python
load("@rules_img//img:convert.bzl", "image_flatten")

image_flatten(
    name = "external_multiarch_base",
    src = ":multiarch_oci.tar",
    manifests = [
        "linux/amd64",
        "linux/arm64",
    ],
)
```

**Known limitations.** `image_flatten` merges layers with `mutate.Extract` from go-containerregistry. Version v0.22.1 of that library has three limits. Most images do not hit them.

- If a later layer deletes the target of a hardlink, the flattened layer keeps a hardlink to a missing file. Docker then fails to load the image with a `linkat` error. The upstream report uses `RUN rm /usr/bin/git` on Alpine as an example. See [google/go-containerregistry#977](https://github.com/google/go-containerregistry/issues/977).
- If a later layer changes the target of a hardlink, the hardlink gets the new content. In the original image, the hardlink keeps the old content. See [google/go-containerregistry#2002](https://github.com/google/go-containerregistry/issues/2002).
- The library drops relative symlinks and hardlinks that point above the image root, for example `x/link -> ../../etc/file`. It does this on purpose to block path traversal. It keeps absolute links and relative links that stay inside the root. See [google/go-containerregistry#2227](https://github.com/google/go-containerregistry/pull/2227) and [google/go-containerregistry#2279](https://github.com/google/go-containerregistry/pull/2279)."�/
� 
image_flatten�Squashes all layers of a container image or multi-platform image index into a single compressed layer per platform and preserves image configuration.

Accepts either an existing `ImageManifestInfo` or `ImageIndexInfo` target via `image`, or an external container archive or OCI layout directory via `src`. Passing `src` lets Bazel import single-platform or multi-platform Docker save and OCI layout tarballs without knowing their layer counts at analysis time.

Example (single-platform archive):

```python
load("@rules_img//img:convert.bzl", "image_flatten")

image_flatten(
    name = "external_base",
    src = ":docker_save_image.tar",
    os = "linux",
    architecture = "amd64",
)
```

Example (multi-platform archive or OCI layout):

```python
load("@rules_img//img:convert.bzl", "image_flatten")

image_flatten(
    name = "external_multiarch_base",
    src = ":multiarch_oci.tar",
    manifests = [
        "linux/amd64",
        "linux/arm64",
    ],
)
```

**Known limitations.** `image_flatten` merges layers with `mutate.Extract` from go-containerregistry. Version v0.22.1 of that library has three limits. Most images do not hit them.

- If a later layer deletes the target of a hardlink, the flattened layer keeps a hardlink to a missing file. Docker then fails to load the image with a `linkat` error. The upstream report uses `RUN rm /usr/bin/git` on Alpine as an example. See [google/go-containerregistry#977](https://github.com/google/go-containerregistry/issues/977).
- If a later layer changes the target of a hardlink, the hardlink gets the new content. In the original image, the hardlink keeps the old content. See [google/go-containerregistry#2002](https://github.com/google/go-containerregistry/issues/2002).
- The library drops relative symlinks and hardlinks that point above the image root, for example `x/link -> ../../etc/file`. It does this on purpose to block path traversal. It keeps absolute links and relative links that stay inside the root. See [google/go-containerregistry#2227](https://github.com/google/go-containerregistry/pull/2227) and [google/go-containerregistry#2279](https://github.com/google/go-containerregistry/pull/2279).*
nameA unique name for this target. �
image�Image manifest or multi-platform image index target to flatten. All layer blobs must be available. Mutually exclusive with 'src'.*]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl*T
ImageIndexInfoB
ImageIndexInfo0@rules_img//img/private/providers:index_info.bzl2None�
src�Uncompressed Docker save `.tar` archive, OCI layout `.tar` archive, or OCI layout directory to flatten. Mutually exclusive with 'image'.2None�
	manifests�Ordered list of platform specifications in 'os/architecture' or 'os/architecture/variant' format when flattening a multi-platform 'src' into an ImageIndexInfo.
Example: ["linux/amd64", "linux/arm64"]2[]�
architecture=Target CPU architecture for single-platform 'src' flattening.2""J""J"386"J"amd64"J"arm"J"arm64"J"mips64"J	"ppc64le"J	"riscv64"J"s390x"J"wasm"�
os=Target operating system for single-platform 'src' flattening.2""J""J	"android"J"darwin"J	"freebsd"J"ios"J"linux"J"netbsd"J	"openbsd"J"wasip1"J	"windows"u
variantdPlatform variant for single-platform 'src' flattening, for example 'v3' for amd64 or 'v8' for arm64.2""�
compresspCompression algorithm for each flattened layer. When set to 'auto', uses the global default compression setting.2"auto"J"auto"J"gzip"J"zstd"J"none"�
history�Overrides the `created_by` history entry recorded for this layer.

By default the layer records one entry, "bazel build <label>", so two layers
with identical contents but different labels have different config digests.
`history = []` records no history entry, so identical contents give identical
config digests regardless of label. A single-element list is recorded verbatim.
The img tool records at most one history entry per layer, so longer lists are
rejected.2!["<default bazel build history>"]"?
image_flatten.@rules_img//img/private/conversion:flatten.bzl,
*
nameA unique name for this target. �
�
image�Image manifest or multi-platform image index target to flatten. All layer blobs must be available. Mutually exclusive with 'src'.*]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl*T
ImageIndexInfoB
ImageIndexInfo0@rules_img//img/private/providers:index_info.bzl2None�
�
src�Uncompressed Docker save `.tar` archive, OCI layout `.tar` archive, or OCI layout directory to flatten. Mutually exclusive with 'image'.2None�
�
	manifests�Ordered list of platform specifications in 'os/architecture' or 'os/architecture/variant' format when flattening a multi-platform 'src' into an ImageIndexInfo.
Example: ["linux/amd64", "linux/arm64"]2[]�
�
architecture=Target CPU architecture for single-platform 'src' flattening.2""J""J"386"J"amd64"J"arm"J"arm64"J"mips64"J	"ppc64le"J	"riscv64"J"s390x"J"wasm"�
�
os=Target operating system for single-platform 'src' flattening.2""J""J	"android"J"darwin"J	"freebsd"J"ios"J"linux"J"netbsd"J	"openbsd"J"wasip1"J	"windows"w
u
variantdPlatform variant for single-platform 'src' flattening, for example 'v3' for amd64 or 'v8' for arm64.2""�
�
compresspCompression algorithm for each flattened layer. When set to 'auto', uses the global default compression setting.2"auto"J"auto"J"gzip"J"zstd"J"none"�
�
history�Overrides the `created_by` history entry recorded for this layer.

By default the layer records one entry, "bazel build <label>", so two layers
with identical contents but different labels have different config digests.
`history = []` records no history entry, so identical contents give identical
config digests regardless of label. A single-element list is recorded verbatim.
The img tool records at most one history entry per layer, so longer lists are
rejected.2!["<default bazel build history>"]�Rules to convert OCI layouts and container archives into container images.

Use `image_manifest_from_oci_layout` and `image_index_from_oci_layout` to import
OCI layout directories. Use `image_manifest_from_archive` and
`image_index_from_archive` to import uncompressed Docker save or OCI layout
`.tar` archives when the layer count is known. Use `image_flatten` to squash a
single-platform image or multi-platform index, OCI layout, or `.tar` archive
into one layer per platform without requiring source layer counts at Bazel
analysis time.�Q

	rules_imgimgdd.bzl�Pimage_dd�(Experimental) Writes the bytes of a disk image or a layer, like `dd`.

The target is executable: `bazel run //:write_disk -- of=/dev/sdX bs=4M status=progress`
writes (or reconstructs) the bytes of the disk image or the layer to a block device,
a file or, without `of=`, to stdout. A layer is what `image_layer` produces,
for example a filesystem image (`format = "ext4"`, `"fat32"`, `"erofs"`) or an
initramfs (`format = "cpio"`) that goes onto a partition or a boot medium. It takes the operands of `dd(1)` as `name=value` or as
`--name=value`:

| Operand | |
|---------|-|
| `of=FILE` | where to write: a file, a block device, or `-` for stdout (default) |
| `bs=BYTES` | block size for writing and for detecting holes (default 1MiB) |
| `skip=N`, `count=N` | skip N input blocks, copy only N input blocks (`iflag=skip_bytes,count_bytes`: in bytes) |
| `seek=N` | skip N output blocks, leaving them as they are (`oflag=seek_bytes`: in bytes) |
| `status=none\|noxfer\|progress` | what to print to stderr (default: a summary at the end) |
| `conv=sparse` | seek over holes and blocks of zeros instead of writing them |
| `conv=nosparse` | write zeros |
| `conv=notrunc`, `conv=fsync` | don't truncate the output file; synchronize before finishing |

Holes (free space of the disk, and blocks of zeros) are not written to an output
file that is created or truncated, which leaves the file sparse. For an existing
device, or with `conv=notrunc`, the zeros are written, unless `conv=sparse` promises
that the output already reads as zeros (a new or erased device). Writing to a
device is destructive: the target does not ask.

If `image` is a `disk_image` built as an (experimental) extent stream
(`extent_stream = "enabled"`), or a layer built as a compact stream
(`experimental_compact_layers`), the target reconstructs the bytes from it. With
`strategy = "lazy"` (or `--@rules_img//img/settings:load_strategy=lazy`), only the extent
stream or compact stream is part of the runfiles: the streams and blobs it
references are fetched by digest when they are needed, from the Bazel disk cache
(`IMG_DISK_CACHE`) or the remote cache (`IMG_REAPI_ENDPOINT`, see
`--@rules_img//img/settings:remote_cache`), and only the parts that `skip` and `count`
select are read. With `eager`, the content-addressed directories are part of the
runfiles and are downloaded by Bazel before the target runs (a layer with a layer
file uses the file instead).

A disk image that is a raw image, and a layer that is only a file, are lazy the same
way: the runfiles only have a small description of the file (its digest and size,
which a layer has already), and the bytes are fetched by digest, from the same
sources, when the target runs. With `eager`, the file is part of the runfiles.

With `compact = "enabled"`, `image` is built as compact streams and an extent stream all
the way, whatever the command line says (see `compact`).

Operands that should always be passed can be set with the `args` attribute
(`args = ["bs=4M", "status=progress"]`); the ones on the command line come after them.

The image is written by the `img dd` command."�7
�(
image_dd�(Experimental) Writes the bytes of a disk image or a layer, like `dd`.

The target is executable: `bazel run //:write_disk -- of=/dev/sdX bs=4M status=progress`
writes (or reconstructs) the bytes of the disk image or the layer to a block device,
a file or, without `of=`, to stdout. A layer is what `image_layer` produces,
for example a filesystem image (`format = "ext4"`, `"fat32"`, `"erofs"`) or an
initramfs (`format = "cpio"`) that goes onto a partition or a boot medium. It takes the operands of `dd(1)` as `name=value` or as
`--name=value`:

| Operand | |
|---------|-|
| `of=FILE` | where to write: a file, a block device, or `-` for stdout (default) |
| `bs=BYTES` | block size for writing and for detecting holes (default 1MiB) |
| `skip=N`, `count=N` | skip N input blocks, copy only N input blocks (`iflag=skip_bytes,count_bytes`: in bytes) |
| `seek=N` | skip N output blocks, leaving them as they are (`oflag=seek_bytes`: in bytes) |
| `status=none\|noxfer\|progress` | what to print to stderr (default: a summary at the end) |
| `conv=sparse` | seek over holes and blocks of zeros instead of writing them |
| `conv=nosparse` | write zeros |
| `conv=notrunc`, `conv=fsync` | don't truncate the output file; synchronize before finishing |

Holes (free space of the disk, and blocks of zeros) are not written to an output
file that is created or truncated, which leaves the file sparse. For an existing
device, or with `conv=notrunc`, the zeros are written, unless `conv=sparse` promises
that the output already reads as zeros (a new or erased device). Writing to a
device is destructive: the target does not ask.

If `image` is a `disk_image` built as an (experimental) extent stream
(`extent_stream = "enabled"`), or a layer built as a compact stream
(`experimental_compact_layers`), the target reconstructs the bytes from it. With
`strategy = "lazy"` (or `--@rules_img//img/settings:load_strategy=lazy`), only the extent
stream or compact stream is part of the runfiles: the streams and blobs it
references are fetched by digest when they are needed, from the Bazel disk cache
(`IMG_DISK_CACHE`) or the remote cache (`IMG_REAPI_ENDPOINT`, see
`--@rules_img//img/settings:remote_cache`), and only the parts that `skip` and `count`
select are read. With `eager`, the content-addressed directories are part of the
runfiles and are downloaded by Bazel before the target runs (a layer with a layer
file uses the file instead).

A disk image that is a raw image, and a layer that is only a file, are lazy the same
way: the runfiles only have a small description of the file (its digest and size,
which a layer has already), and the bytes are fetched by digest, from the same
sources, when the target runs. With `eager`, the file is part of the runfiles.

With `compact = "enabled"`, `image` is built as compact streams and an extent stream all
the way, whatever the command line says (see `compact`).

Operands that should always be passed can be set with the `args` attribute
(`args = ["bs=4M", "status=progress"]`); the ones on the command line come after them.

The image is written by the `img dd` command.*
nameA unique name for this target. �
imageoThe `disk_image` or the layer (a target of `image_layer` or `layer_from_tar` that produces one layer) to write. *W
DiskImageInfoF
DiskImageInfo5@rules_img//img/private/providers:disk_image_info.bzl*M

LayersInfo?

LayersInfo1@rules_img//img/private/providers:layers_info.bzl�
compact�(Experimental) Whether to build `image` as compact streams and extent streams all the way.

- **`auto`** (default): `image` is built with the settings of the command line.
- **`enabled`**: layers are built as compact streams (`experimental_compact_layers`, without materializing the layer blob) and a `disk_image` as an extent stream (`disk_image_extent_stream`). The image then only references the files it is made of, which are fetched by digest when the target runs (see `strategy`), instead of being built in full.
- **`disabled`**: layers and disk images are built in full.

This changes the configuration of `image` and everything it depends on, so it is built separately from the same targets built with another value.2"auto"J"auto"J	"enabled"J
"disabled"�
strategy�How the bytes are made available.

- **`auto`** (default): uses the global `--@rules_img//img/settings:load_strategy`.
- **`eager`**: the file, or the files that a stream references, are part of the runfiles.
- **`lazy`**: only a stream or a description of the file (digest and size) is. The rest is fetched by digest when it is needed.2"auto"J"auto"J"eager"J"lazy"�
tool_cfg�**Experimental**: Configuration of the `img` executable. By default it matches the host platform; `"target"` makes it match the target platform.2"host"J"host"J"target"�
deploy_tool�Optional label of a deploy tool target providing `DeployToolInfo` (created with `img_deploy_tool` from `@rules_img//img:deploy_tool.bzl`). When set, overrides `tool_cfg`.*Z
DeployToolInfoH
DeployToolInfo6@rules_img//img/private/providers:deploy_tool_info.bzl2None"*
image_dd@rules_img//img/private:dd.bzl8,
*
nameA unique name for this target. �
�
imageoThe `disk_image` or the layer (a target of `image_layer` or `layer_from_tar` that produces one layer) to write. *W
DiskImageInfoF
DiskImageInfo5@rules_img//img/private/providers:disk_image_info.bzl*M

LayersInfo?

LayersInfo1@rules_img//img/private/providers:layers_info.bzl�
�
compact�(Experimental) Whether to build `image` as compact streams and extent streams all the way.

- **`auto`** (default): `image` is built with the settings of the command line.
- **`enabled`**: layers are built as compact streams (`experimental_compact_layers`, without materializing the layer blob) and a `disk_image` as an extent stream (`disk_image_extent_stream`). The image then only references the files it is made of, which are fetched by digest when the target runs (see `strategy`), instead of being built in full.
- **`disabled`**: layers and disk images are built in full.

This changes the configuration of `image` and everything it depends on, so it is built separately from the same targets built with another value.2"auto"J"auto"J	"enabled"J
"disabled"�
�
strategy�How the bytes are made available.

- **`auto`** (default): uses the global `--@rules_img//img/settings:load_strategy`.
- **`eager`**: the file, or the files that a stream references, are part of the runfiles.
- **`lazy`**: only a stream or a description of the file (digest and size) is. The rest is fetched by digest when it is needed.2"auto"J"auto"J"eager"J"lazy"�
�
tool_cfg�**Experimental**: Configuration of the `img` executable. By default it matches the host platform; `"target"` makes it match the target platform.2"host"J"host"J"target"�
�
deploy_tool�Optional label of a deploy tool target providing `DeployToolInfo` (created with `img_deploy_tool` from `@rules_img//img:deploy_tool.bzl`). When set, overrides `tool_cfg`.*Z
DeployToolInfoH
DeployToolInfo6@rules_img//img/private/providers:deploy_tool_info.bzl2NoneDPublic API for writing the bytes of disk images and layers, like dd.�}
 
	rules_imgimgdisk_image.bzl�H
disk_image�A disk image with a GPT (default) or MBR partition table, as a single file.

The partitions are the `disk_partition` targets in `partitions`, in order. Each
holds a file system image, typically the output of `image_layer` with
`format = "ext4"`, `"fat32"` or `"erofs"`. The disk is as small as the
partitions allow (plus the backup partition table of a GPT). Set `min_size`,
`max_size` or `disk_size` to make the disk larger, or to limit its size.

### Bootable UEFI disk image

A UEFI firmware boots from the EFI system partition: a FAT32 file system in a
partition of type `esp`, with the boot loader at `/EFI/BOOT/BOOTX64.EFI`
(`BOOTAA64.EFI` on arm64).

```python
load("@rules_img//img:disk_image.bzl", "disk_image", "disk_partition")
load("@rules_img//img:layer.bzl", "image_layer")

image_layer(
    name = "esp_layer",
    format = "fat32",
    srcs = {
        "/EFI/BOOT/BOOTX64.EFI": "@systemd_boot//:systemd-bootx64.efi",
        "/loader/loader.conf": ":loader.conf",
        "/EFI/Linux/linux.efi": ":unified_kernel_image",
    },
)

image_layer(
    name = "root_layer",
    format = "erofs",
    compress = "none",
    srcs = {"/": ":rootfs"},
)

disk_partition(name = "esp", image = ":esp_layer", type = "esp", label = "ESP")
disk_partition(name = "root", image = ":root_layer", type = "root-x86-64", label = "root")

disk_image(
    name = "disk",
    partitions = [":esp", ":root"],
)
```

### Extent streams (experimental)

With `extent_stream = "enabled"` (or the `disk_image_extent_stream` setting),
`disk_image` produces an [extent stream](extent-stream.md) of the disk image
instead of the image, which can be huge. The extent stream format is
experimental and may change incompatibly. The layers of the partitions that were
built as compact streams (see `experimental_compact_layers`) are referenced by
the digest of their compact stream, so the extent stream of the disk is tiny:
it embeds the partition table, describes the free space as holes and points at
the partitions. File system images that are not compact streams are referenced
as a whole (or embedded if they are small). The disk image is available in the
`image` output group, and is only built when requested. The `extent_stream` and
`cas` output groups have the extent stream and the content-addressed
directories (`sha256/<hex>`) with the compact streams of the partitions and the
blobs they reference, which `img extent-stream reconstruct --cas-dir` takes.

See [disk images](disk-images.md)."�4
�$

disk_image�A disk image with a GPT (default) or MBR partition table, as a single file.

The partitions are the `disk_partition` targets in `partitions`, in order. Each
holds a file system image, typically the output of `image_layer` with
`format = "ext4"`, `"fat32"` or `"erofs"`. The disk is as small as the
partitions allow (plus the backup partition table of a GPT). Set `min_size`,
`max_size` or `disk_size` to make the disk larger, or to limit its size.

### Bootable UEFI disk image

A UEFI firmware boots from the EFI system partition: a FAT32 file system in a
partition of type `esp`, with the boot loader at `/EFI/BOOT/BOOTX64.EFI`
(`BOOTAA64.EFI` on arm64).

```python
load("@rules_img//img:disk_image.bzl", "disk_image", "disk_partition")
load("@rules_img//img:layer.bzl", "image_layer")

image_layer(
    name = "esp_layer",
    format = "fat32",
    srcs = {
        "/EFI/BOOT/BOOTX64.EFI": "@systemd_boot//:systemd-bootx64.efi",
        "/loader/loader.conf": ":loader.conf",
        "/EFI/Linux/linux.efi": ":unified_kernel_image",
    },
)

image_layer(
    name = "root_layer",
    format = "erofs",
    compress = "none",
    srcs = {"/": ":rootfs"},
)

disk_partition(name = "esp", image = ":esp_layer", type = "esp", label = "ESP")
disk_partition(name = "root", image = ":root_layer", type = "root-x86-64", label = "root")

disk_image(
    name = "disk",
    partitions = [":esp", ":root"],
)
```

### Extent streams (experimental)

With `extent_stream = "enabled"` (or the `disk_image_extent_stream` setting),
`disk_image` produces an [extent stream](extent-stream.md) of the disk image
instead of the image, which can be huge. The extent stream format is
experimental and may change incompatibly. The layers of the partitions that were
built as compact streams (see `experimental_compact_layers`) are referenced by
the digest of their compact stream, so the extent stream of the disk is tiny:
it embeds the partition table, describes the free space as holes and points at
the partitions. File system images that are not compact streams are referenced
as a whole (or embedded if they are small). The disk image is available in the
`image` output group, and is only built when requested. The `extent_stream` and
`cas` output groups have the extent stream and the content-addressed
directories (`sha256/<hex>`) with the compact streams of the partitions and the
blobs they reference, which `img extent-stream reconstruct --cas-dir` takes.

See [disk images](disk-images.md).*
nameA unique name for this target. �

partitionsIThe `disk_partition` targets, in the order they are laid out on the disk. *V
PartitionInfoE
PartitionInfo4@rules_img//img/private/providers:partition_info.bzl�
partition_table�The partition table: a GUID partition table (`gpt`), or a classic MBR partition table (`mbr`, at most 4 partitions and 2 TiB with 512 byte sectors).2"gpt"J"gpt"J"mbr"�
sector_size�Logical sector size of the disk in bytes. FAT32 file systems in the partitions have to have the same sector size (see the `sector_size` attribute of the layer rules).2512J512J4096�
	alignment�Alignment of the start of every partition (a multiple of the sector size). The padding is part of the previous partition, and the default of 1 MiB is what current tools use.2"1MiB"�
	disk_size�Exact size of the disk, like `4GiB`. It is an error if the partitions need more. Cannot be combined with `min_size` or `max_size`.2""�
min_size�Minimum size of the disk. If the partitions need less, the disk has free space at the end (the backup partition table of a GPT is at the end of the disk).2""W
max_sizeEMaximum size of the disk. It is an error if the partitions need more.2""�
	disk_guid�GUID of the disk (GPT only). By default one is derived, so that equal inputs give equal disk images. Also the basis of the disk signature of an MBR.2""�
	boot_code�File with up to 440 bytes of boot code for the first sector: the MBR, or the protective MBR of a GPT (for booting a GPT disk with a legacy BIOS).2None�
extent_stream�(Experimental) Whether to produce an extent stream of the disk image instead of the disk image. If set to `auto`, uses the global `--@rules_img//img/settings:disk_image_extent_stream` setting.2"auto"J"auto"J	"enabled"J
"disabled"�
extent_inline_threshold�With an extent stream: file system images that are not compact streams and are smaller than this are embedded in the extent stream instead of being referenced.2"1MiB""4

disk_image&@rules_img//img/private:disk_image.bzl*W
DiskImageInfoF
DiskImageInfo5@rules_img//img/private/providers:disk_image_info.bzl,
*
nameA unique name for this target. �
�

partitionsIThe `disk_partition` targets, in the order they are laid out on the disk. *V
PartitionInfoE
PartitionInfo4@rules_img//img/private/providers:partition_info.bzl�
�
partition_table�The partition table: a GUID partition table (`gpt`), or a classic MBR partition table (`mbr`, at most 4 partitions and 2 TiB with 512 byte sectors).2"gpt"J"gpt"J"mbr"�
�
sector_size�Logical sector size of the disk in bytes. FAT32 file systems in the partitions have to have the same sector size (see the `sector_size` attribute of the layer rules).2512J512J4096�
�
	alignment�Alignment of the start of every partition (a multiple of the sector size). The padding is part of the previous partition, and the default of 1 MiB is what current tools use.2"1MiB"�
�
	disk_size�Exact size of the disk, like `4GiB`. It is an error if the partitions need more. Cannot be combined with `min_size` or `max_size`.2""�
�
min_size�Minimum size of the disk. If the partitions need less, the disk has free space at the end (the backup partition table of a GPT is at the end of the disk).2""Y
W
max_sizeEMaximum size of the disk. It is an error if the partitions need more.2""�
�
	disk_guid�GUID of the disk (GPT only). By default one is derived, so that equal inputs give equal disk images. Also the basis of the disk signature of an MBR.2""�
�
	boot_code�File with up to 440 bytes of boot code for the first sector: the MBR, or the protective MBR of a GPT (for booting a GPT disk with a legacy BIOS).2None�
�
extent_stream�(Experimental) Whether to produce an extent stream of the disk image instead of the disk image. If set to `auto`, uses the global `--@rules_img//img/settings:disk_image_extent_stream` setting.2"auto"J"auto"J	"enabled"J
"disabled"�
�
extent_inline_threshold�With an extent stream: file system images that are not compact streams and are smaller than this are embedded in the extent stream instead of being referenced.2"1MiB"�4disk_partition�A partition of a `disk_image`.

The partition holds a file system image: the output of a layer rule built with
`format = "ext4"`, `"fat32"` or `"erofs"` (see `image_layer`), or any file that
is a file system image. Without an `image`, it is an empty placeholder of the
given `partition_size`.

By default, the partition is as large as the file system, padded to the
alignment of the disk. A larger `partition_size` leaves free space at the end of the
partition.

Example:

```python
load("@rules_img//img:disk_image.bzl", "disk_partition")

disk_partition(
    name = "esp",
    image = ":esp_layer",  # an image_layer with format = "fat32"
    label = "ESP",
    type = "esp",
)

disk_partition(
    name = "root",
    image = ":root_layer",
    label = "root",
    type = "root-x86-64",
    partition_size = "2GiB",  # free space after the file system
)

disk_partition(
    name = "reserved",
    label = "reserved",
    partition_size = "16MiB",  # an empty placeholder
)
```"�,
�
disk_partition�A partition of a `disk_image`.

The partition holds a file system image: the output of a layer rule built with
`format = "ext4"`, `"fat32"` or `"erofs"` (see `image_layer`), or any file that
is a file system image. Without an `image`, it is an empty placeholder of the
given `partition_size`.

By default, the partition is as large as the file system, padded to the
alignment of the disk. A larger `partition_size` leaves free space at the end of the
partition.

Example:

```python
load("@rules_img//img:disk_image.bzl", "disk_partition")

disk_partition(
    name = "esp",
    image = ":esp_layer",  # an image_layer with format = "fat32"
    label = "ESP",
    type = "esp",
)

disk_partition(
    name = "root",
    image = ":root_layer",
    label = "root",
    type = "root-x86-64",
    partition_size = "2GiB",  # free space after the file system
)

disk_partition(
    name = "reserved",
    label = "reserved",
    partition_size = "16MiB",  # an empty placeholder
)
```*
nameA unique name for this target. �
image�The file system image of the partition: a layer rule target with a single layer of the `ext4`, `fat32` or `erofs` format, or a target with a single file (a file system image).

If the layer was built as a compact stream (see `experimental_compact_layers`), a `disk_image` that is built as an extent stream references the compact stream of the layer.2None]
labelNName of the partition, which a GPT stores. Defaults to the name of the target.2""�
type�Type of the partition: a name, or a GUID.

The names are `esp` (EFI system partition), `linux`, `root-x86-64`, `root-x86`, `root-arm64`, `root-arm`, `root-riscv64`, `usr-x86-64`, `usr-arm64`, `home`, `srv`, `var`, `tmp`, `swap`, `xbootldr`, `bios-boot`, `linux-lvm`, `linux-raid`, `microsoft-basic-data` and `fat32`. The partition types for the root file system (`root-*`) are those of the Discoverable Partitions Specification, which lets systemd find the root file system without a kernel command line.

An EFI system partition has to hold a FAT32 file system.2"linux"�
guid~Unique GUID of the partition (GPT only). By default one is derived from the disk, so that equal inputs give equal disk images.2""�
partition_size�Size of the partition, like `64MiB` or `1.5GiB` (binary suffixes KiB, MiB, GiB, TiB; KB, MB, GB, TB are decimal). `auto` makes the partition as large as its file system, padded to the alignment of the disk. A larger size leaves free space at the end of the partition. Placeholders need a `partition_size`.2"auto"�

attributes�GPT attributes of the partition: `required`, `no_block_io`, `legacy_bios_bootable`, `growfs`, `read_only`, `hidden`, `no_automount`, or a number (a mask of bits). GPT only.2[]�
mbr_type�Type byte of the partition in an MBR, like 0x83 (131). By default it follows from `type` (0xEF for `esp`, 0x83 for Linux, 0x0C for `fat32`).20_
activeLMarks the partition as bootable in an MBR (at most one partition). MBR only.2False�
hidden_sectors�Sets the hidden sectors field of a FAT32 file system (in its boot sector and in the backup boot sector) to the first sector of the partition. Some firmware and boot loaders use it to find the file system. Turn it off to keep the file system as it was built.2True"8
disk_partition&@rules_img//img/private:disk_image.bzl,
*
nameA unique name for this target. �
�
image�The file system image of the partition: a layer rule target with a single layer of the `ext4`, `fat32` or `erofs` format, or a target with a single file (a file system image).

If the layer was built as a compact stream (see `experimental_compact_layers`), a `disk_image` that is built as an extent stream references the compact stream of the layer.2None_
]
labelNName of the partition, which a GPT stores. Defaults to the name of the target.2""�
�
type�Type of the partition: a name, or a GUID.

The names are `esp` (EFI system partition), `linux`, `root-x86-64`, `root-x86`, `root-arm64`, `root-arm`, `root-riscv64`, `usr-x86-64`, `usr-arm64`, `home`, `srv`, `var`, `tmp`, `swap`, `xbootldr`, `bios-boot`, `linux-lvm`, `linux-raid`, `microsoft-basic-data` and `fat32`. The partition types for the root file system (`root-*`) are those of the Discoverable Partitions Specification, which lets systemd find the root file system without a kernel command line.

An EFI system partition has to hold a FAT32 file system.2"linux"�
�
guid~Unique GUID of the partition (GPT only). By default one is derived from the disk, so that equal inputs give equal disk images.2""�
�
partition_size�Size of the partition, like `64MiB` or `1.5GiB` (binary suffixes KiB, MiB, GiB, TiB; KB, MB, GB, TB are decimal). `auto` makes the partition as large as its file system, padded to the alignment of the disk. A larger size leaves free space at the end of the partition. Placeholders need a `partition_size`.2"auto"�
�

attributes�GPT attributes of the partition: `required`, `no_block_io`, `legacy_bios_bootable`, `growfs`, `read_only`, `hidden`, `no_automount`, or a number (a mask of bits). GPT only.2[]�
�
mbr_type�Type byte of the partition in an MBR, like 0x83 (131). By default it follows from `type` (0xEF for `esp`, 0x83 for Linux, 0x0C for `fat32`).20a
_
activeLMarks the partition as bootable in an MBR (at most one partition). MBR only.2False�
�
hidden_sectors�Sets the hidden sectors field of a FAT32 file system (in its boot sector and in the backup boot sector) to the first sector of the partition. Some firmware and boot loaders use it to find the file system. Turn it off to keep the file system as it was built.2True=Public API for disk images with a GPT or MBR partition table.��
 
	rules_imgimgextensions.bzlӘimages�Module extension for pulling container images in Bzlmod projects.

This extension enables declarative pulling of container images using Bazel's module
system. Images are pulled once and shared across all modules, with automatic deduplication
of blobs for efficient storage.

Example usage in MODULE.bazel:

```starlark
images = use_extension("@rules_img//img:extensions.bzl", "images")

# Pull with friendly name
images.pull(
    name = "ubuntu",
    digest = "sha256:1e622c5f073b4f6bfad6632f2616c7f59ef256e96fe78bf6a595d1dc4376ac02",
    registry = "index.docker.io",
    repository = "library/ubuntu",
    tag = "24.04",
)

# Pull without name - use repository as identifier
images.pull(
    digest = "sha256:029d4461bd98f124e531380505ceea2072418fdf28752aa73b7b273ba3048903",
    registry = "gcr.io",
    repository = "distroless/base",
)

use_repo(images, "rules_img_images.bzl")
```

Access pulled images in BUILD files using the generated helper. The `name` attribute
is optional - if not specified, use the `repository` value to reference the image:

```starlark
load("@rules_img_images.bzl", "image")

image_manifest(
    name = "my_app",
    base = image("ubuntu"),  # References the friendly name
    ...
)

image_manifest(
    name = "my_other_app",
    base = image("distroless/base"),  # References the repository
    ...
)
```

The extension creates deduplicated blob repositories, so pulling multiple images
from the same base only downloads shared layers once. The `digest` parameter is
required for reproducibility.Jǌ
�7
images�Module extension for pulling container images in Bzlmod projects.

This extension enables declarative pulling of container images using Bazel's module
system. Images are pulled once and shared across all modules, with automatic deduplication
of blobs for efficient storage.

Example usage in MODULE.bazel:

```starlark
images = use_extension("@rules_img//img:extensions.bzl", "images")

# Pull with friendly name
images.pull(
    name = "ubuntu",
    digest = "sha256:1e622c5f073b4f6bfad6632f2616c7f59ef256e96fe78bf6a595d1dc4376ac02",
    registry = "index.docker.io",
    repository = "library/ubuntu",
    tag = "24.04",
)

# Pull without name - use repository as identifier
images.pull(
    digest = "sha256:029d4461bd98f124e531380505ceea2072418fdf28752aa73b7b273ba3048903",
    registry = "gcr.io",
    repository = "distroless/base",
)

use_repo(images, "rules_img_images.bzl")
```

Access pulled images in BUILD files using the generated helper. The `name` attribute
is optional - if not specified, use the `repository` value to reference the image:

```starlark
load("@rules_img_images.bzl", "image")

image_manifest(
    name = "my_app",
    base = image("ubuntu"),  # References the friendly name
    ...
)

image_manifest(
    name = "my_other_app",
    base = image("distroless/base"),  # References the repository
    ...
)
```

The extension creates deduplicated blob repositories, so pulling multiple images
from the same base only downloads shared layers once. The `digest` parameter is
required for reproducibility.�
pull�
name�Friendly name for the image (e.g., 'ubuntu', 'distroless-base').

This name is used to reference the image in your code via the `image()` helper function.
If not specified, defaults to the repository name.2""�
registry�Primary registry to pull from (e.g., "index.docker.io", "gcr.io").

If not specified, defaults to Docker Hub. Can be overridden by entries in registries list.2""�

registries�List of mirror registries to try in order.

These registries will be tried in order before the primary registry. Useful for
corporate environments with registry mirrors or air-gapped setups.2[]�

repository�The image repository within the registry (e.g., "library/ubuntu", "my-project/my-image").

For Docker Hub, official images use "library/" prefix (e.g., "library/ubuntu"). �
tag�The image tag to pull (e.g., "latest", "24.04", "v1.2.3").

While optional, it's recommended to also specify a digest for reproducible builds.2""�
digest�The image digest for reproducible pulls (e.g., "sha256:abc123...").

When specified, the image is pulled by digest instead of tag, ensuring reproducible builds.
The digest must be a full SHA256 digest starting with "sha256:".2""�
unsafe_allow_tag_without_digest�Resolve `tag` to a digest each time the extension is evaluated, instead of requiring `digest`.

**WARNING:** Builds then follow the tag, so they are not reproducible.

The extension reports itself as not reproducible, so Bazel re-evaluates it in each new
server instead of recording the digest in the lockfile. Image and blob repositories stay
keyed by digest, so they come from the repo contents cache until the tag moves. Their
repository names contain the digest: reference the image through the hub's `image()`.2False�
layer_handling�Strategy for handling image layers.

This attribute controls when and how layer data is fetched from the registry.

**Available strategies:**

* **`shallow`** (default): Layer data is fetched only if needed during push operations,
  but is not available during the build. This is the most efficient option for images
  that are only used as base images for pushing.

* **`eager`**: Layer data is fetched in the repository rule and is always available.
  This ensures layers are accessible in build actions but is inefficient as all layers
  are downloaded regardless of whether they're needed. Use this for base images that
  need to be read or inspected during the build.

* **`lazy`**: Layer data is downloaded in a build action when requested. This provides
  access to layers during builds while avoiding unnecessary downloads, but requires
  network access during the build phase. **EXPERIMENTAL:** Use at your own risk.2	"shallow"J	"shallow"J"eager"J"lazy"�
settings�

downloader�The tool to use for downloading manifests and blobs if the current module is the root module.

**Available options:**

* **`img_tool`** (default): Uses the `img` tool for all downloads.

* **`bazel`**: Uses Bazel's native HTTP capabilities for downloading manifests and blobs.2
"img_tool"J
"img_tool"J"bazel"�
hub_repo�Controls visibility of the hub repository @rules_img_images.bzl for image access via the images macro.

**Available options:**

* **`auto`** (default): The hub repository is made visible if named repositories cannot be mapped in the current Bazel version.
                        This means you either get @rules_img_images.bzl or one repository per image.

* **`enabled`**: Always create and expose the hub repository @rules_img_images.bzl for image access via the images macro.

* **`disabled`**: Do not create the hub repository.2"auto"J"auto"J	"enabled"J
"disabled"�
credential_helper�Credential helper to use for registry authentication when the module extension runs the pull tool.

If omitted, the pull tool inherits `$IMG_CREDENTIAL_HELPER` (or `$IMG_CREDENTIAL_HELPER_OCI_REGISTRY`, which takes precedence) when present.2""�
docker_config_path�Path to Docker-compatible registry authentication config.

If omitted, the pull tool inherits `$REGISTRY_AUTH_FILE` when present.2""�
timeout�Maximum duration in seconds of each download performed for the pulled images.

**Only takes effect when `downloader` is `img_tool`**, since it is applied to the `img` tool
invocations run by this extension and by the repositories it creates. Bazel's own downloader
cannot be given a timeout from Starlark, so this setting is ignored when `downloader` is
`bazel` (scale Bazel's built-in HTTP timeouts with `--http_timeout_scaling` instead).

Defaults to `0`, which leaves the timeout unset, so Bazel's default for executions in module
extensions and repository rules (600 seconds) applies. Raise it when pulling large layers over
a slow connection.20�
image_repos�Controls visibility of individual image repositories for direct access. Repos internally use the naming scheme img_<digest> and are mapped via friendly names (i.e. "ubuntu") if possible.

**Available options:**

* **`auto`** (default): Individual image repositories are made visible if named repositories can be mapped in the current Bazel version.
                        This means you either get one repository per image or @rules_img_images.bzl.

* **`enabled`**: Always expose individual image repositories for direct access.

* **`disabled`**: Do not expose individual image repositories.2"auto"J"auto"J	"enabled"J
"disabled""/-@rules_img//img/private/extensions:images.bzl�+
�
pull�
name�Friendly name for the image (e.g., 'ubuntu', 'distroless-base').

This name is used to reference the image in your code via the `image()` helper function.
If not specified, defaults to the repository name.2""�
registry�Primary registry to pull from (e.g., "index.docker.io", "gcr.io").

If not specified, defaults to Docker Hub. Can be overridden by entries in registries list.2""�

registries�List of mirror registries to try in order.

These registries will be tried in order before the primary registry. Useful for
corporate environments with registry mirrors or air-gapped setups.2[]�

repository�The image repository within the registry (e.g., "library/ubuntu", "my-project/my-image").

For Docker Hub, official images use "library/" prefix (e.g., "library/ubuntu"). �
tag�The image tag to pull (e.g., "latest", "24.04", "v1.2.3").

While optional, it's recommended to also specify a digest for reproducible builds.2""�
digest�The image digest for reproducible pulls (e.g., "sha256:abc123...").

When specified, the image is pulled by digest instead of tag, ensuring reproducible builds.
The digest must be a full SHA256 digest starting with "sha256:".2""�
unsafe_allow_tag_without_digest�Resolve `tag` to a digest each time the extension is evaluated, instead of requiring `digest`.

**WARNING:** Builds then follow the tag, so they are not reproducible.

The extension reports itself as not reproducible, so Bazel re-evaluates it in each new
server instead of recording the digest in the lockfile. Image and blob repositories stay
keyed by digest, so they come from the repo contents cache until the tag moves. Their
repository names contain the digest: reference the image through the hub's `image()`.2False�
layer_handling�Strategy for handling image layers.

This attribute controls when and how layer data is fetched from the registry.

**Available strategies:**

* **`shallow`** (default): Layer data is fetched only if needed during push operations,
  but is not available during the build. This is the most efficient option for images
  that are only used as base images for pushing.

* **`eager`**: Layer data is fetched in the repository rule and is always available.
  This ensures layers are accessible in build actions but is inefficient as all layers
  are downloaded regardless of whether they're needed. Use this for base images that
  need to be read or inspected during the build.

* **`lazy`**: Layer data is downloaded in a build action when requested. This provides
  access to layers during builds while avoiding unnecessary downloads, but requires
  network access during the build phase. **EXPERIMENTAL:** Use at your own risk.2	"shallow"J	"shallow"J"eager"J"lazy"�
�
name�Friendly name for the image (e.g., 'ubuntu', 'distroless-base').

This name is used to reference the image in your code via the `image()` helper function.
If not specified, defaults to the repository name.2""�
�
registry�Primary registry to pull from (e.g., "index.docker.io", "gcr.io").

If not specified, defaults to Docker Hub. Can be overridden by entries in registries list.2""�
�

registries�List of mirror registries to try in order.

These registries will be tried in order before the primary registry. Useful for
corporate environments with registry mirrors or air-gapped setups.2[]�
�

repository�The image repository within the registry (e.g., "library/ubuntu", "my-project/my-image").

For Docker Hub, official images use "library/" prefix (e.g., "library/ubuntu"). �
�
tag�The image tag to pull (e.g., "latest", "24.04", "v1.2.3").

While optional, it's recommended to also specify a digest for reproducible builds.2""�
�
digest�The image digest for reproducible pulls (e.g., "sha256:abc123...").

When specified, the image is pulled by digest instead of tag, ensuring reproducible builds.
The digest must be a full SHA256 digest starting with "sha256:".2""�
�
unsafe_allow_tag_without_digest�Resolve `tag` to a digest each time the extension is evaluated, instead of requiring `digest`.

**WARNING:** Builds then follow the tag, so they are not reproducible.

The extension reports itself as not reproducible, so Bazel re-evaluates it in each new
server instead of recording the digest in the lockfile. Image and blob repositories stay
keyed by digest, so they come from the repo contents cache until the tag moves. Their
repository names contain the digest: reference the image through the hub's `image()`.2False�
�
layer_handling�Strategy for handling image layers.

This attribute controls when and how layer data is fetched from the registry.

**Available strategies:**

* **`shallow`** (default): Layer data is fetched only if needed during push operations,
  but is not available during the build. This is the most efficient option for images
  that are only used as base images for pushing.

* **`eager`**: Layer data is fetched in the repository rule and is always available.
  This ensures layers are accessible in build actions but is inefficient as all layers
  are downloaded regardless of whether they're needed. Use this for base images that
  need to be read or inspected during the build.

* **`lazy`**: Layer data is downloaded in a build action when requested. This provides
  access to layers during builds while avoiding unnecessary downloads, but requires
  network access during the build phase. **EXPERIMENTAL:** Use at your own risk.2	"shallow"J	"shallow"J"eager"J"lazy"�)
�
settings�

downloader�The tool to use for downloading manifests and blobs if the current module is the root module.

**Available options:**

* **`img_tool`** (default): Uses the `img` tool for all downloads.

* **`bazel`**: Uses Bazel's native HTTP capabilities for downloading manifests and blobs.2
"img_tool"J
"img_tool"J"bazel"�
hub_repo�Controls visibility of the hub repository @rules_img_images.bzl for image access via the images macro.

**Available options:**

* **`auto`** (default): The hub repository is made visible if named repositories cannot be mapped in the current Bazel version.
                        This means you either get @rules_img_images.bzl or one repository per image.

* **`enabled`**: Always create and expose the hub repository @rules_img_images.bzl for image access via the images macro.

* **`disabled`**: Do not create the hub repository.2"auto"J"auto"J	"enabled"J
"disabled"�
credential_helper�Credential helper to use for registry authentication when the module extension runs the pull tool.

If omitted, the pull tool inherits `$IMG_CREDENTIAL_HELPER` (or `$IMG_CREDENTIAL_HELPER_OCI_REGISTRY`, which takes precedence) when present.2""�
docker_config_path�Path to Docker-compatible registry authentication config.

If omitted, the pull tool inherits `$REGISTRY_AUTH_FILE` when present.2""�
timeout�Maximum duration in seconds of each download performed for the pulled images.

**Only takes effect when `downloader` is `img_tool`**, since it is applied to the `img` tool
invocations run by this extension and by the repositories it creates. Bazel's own downloader
cannot be given a timeout from Starlark, so this setting is ignored when `downloader` is
`bazel` (scale Bazel's built-in HTTP timeouts with `--http_timeout_scaling` instead).

Defaults to `0`, which leaves the timeout unset, so Bazel's default for executions in module
extensions and repository rules (600 seconds) applies. Raise it when pulling large layers over
a slow connection.20�
image_repos�Controls visibility of individual image repositories for direct access. Repos internally use the naming scheme img_<digest> and are mapped via friendly names (i.e. "ubuntu") if possible.

**Available options:**

* **`auto`** (default): Individual image repositories are made visible if named repositories can be mapped in the current Bazel version.
                        This means you either get one repository per image or @rules_img_images.bzl.

* **`enabled`**: Always expose individual image repositories for direct access.

* **`disabled`**: Do not expose individual image repositories.2"auto"J"auto"J	"enabled"J
"disabled"�
�

downloader�The tool to use for downloading manifests and blobs if the current module is the root module.

**Available options:**

* **`img_tool`** (default): Uses the `img` tool for all downloads.

* **`bazel`**: Uses Bazel's native HTTP capabilities for downloading manifests and blobs.2
"img_tool"J
"img_tool"J"bazel"�
�
hub_repo�Controls visibility of the hub repository @rules_img_images.bzl for image access via the images macro.

**Available options:**

* **`auto`** (default): The hub repository is made visible if named repositories cannot be mapped in the current Bazel version.
                        This means you either get @rules_img_images.bzl or one repository per image.

* **`enabled`**: Always create and expose the hub repository @rules_img_images.bzl for image access via the images macro.

* **`disabled`**: Do not create the hub repository.2"auto"J"auto"J	"enabled"J
"disabled"�
�
credential_helper�Credential helper to use for registry authentication when the module extension runs the pull tool.

If omitted, the pull tool inherits `$IMG_CREDENTIAL_HELPER` (or `$IMG_CREDENTIAL_HELPER_OCI_REGISTRY`, which takes precedence) when present.2""�
�
docker_config_path�Path to Docker-compatible registry authentication config.

If omitted, the pull tool inherits `$REGISTRY_AUTH_FILE` when present.2""�
�
timeout�Maximum duration in seconds of each download performed for the pulled images.

**Only takes effect when `downloader` is `img_tool`**, since it is applied to the `img` tool
invocations run by this extension and by the repositories it creates. Bazel's own downloader
cannot be given a timeout from Starlark, so this setting is ignored when `downloader` is
`bazel` (scale Bazel's built-in HTTP timeouts with `--http_timeout_scaling` instead).

Defaults to `0`, which leaves the timeout unset, so Bazel's default for executions in module
extensions and repository rules (600 seconds) applies. Raise it when pulling large layers over
a slow connection.20�
�
image_repos�Controls visibility of individual image repositories for direct access. Repos internally use the naming scheme img_<digest> and are mapped via friendly names (i.e. "ubuntu") if possible.

**Available options:**

* **`auto`** (default): Individual image repositories are made visible if named repositories can be mapped in the current Bazel version.
                        This means you either get one repository per image or @rules_img_images.bzl.

* **`enabled`**: Always expose individual image repositories for direct access.

* **`disabled`**: Do not expose individual image repositories.2"auto"J"auto"J	"enabled"J
"disabled"+Public API for rules_img module extensions.��

	rules_imgimg	image.bzl��image_manifest�Builds a single-platform OCI container image from a set of layers.

This rule assembles container images by combining:
- Optional base image layers (from another image_manifest or image_index)
- Additional layers created by image_layer rules
- Image configuration (entrypoint, environment, labels, etc.)

The rule produces:
- OCI manifest and config JSON files
- An optional OCI layout directory or tar (via output groups)
- ImageManifestInfo provider for use by image_index or image_push

Example:

```python
image_manifest(
    name = "my_app",
    base = "@distroless_cc",
    layers = [
        ":app_layer",
        ":config_layer",
    ],
    entrypoint = ["/usr/bin/app"],
    env = {
        "APP_ENV": "production",
    },
)
```

Output groups:
- `descriptor`: OCI descriptor JSON file
- `digest`: Digest of the image (sha256:...)
- `root_blob`: The manifest JSON blob file
- `oci_layout`: Complete OCI layout directory with blobs
- `oci_tarball`: OCI layout packaged as a tar file for downstream use
- `sparse_oci_layout`: Sparse OCI layout directory (without layer blobs, only layer descriptors)
- `mtree`: a single [mtree](https://man.freebsd.org/cgi/man.cgi?mtree(5)) text file describing the
  image's filesystem, merged (in layer order) from per-layer mtrees. Layers built by rules_img layer
  rules reuse their own `mtree`; for any other layer -- pulled/imported base-image layers, or raw
  tars added directly via `DefaultInfo` -- an mtree is rendered on the fly from the layer's tar blob.
  A layer is skipped on a best-effort basis only when its blob is unavailable (shallow/lazy layers)
  or is not a tar (empty layers, non-tar artifact blobs), so a skipped layer means the merged mtree
  reflects only a subset of the image. Only produced when at least one layer contributes an `mtree`."��
��
image_manifest�Builds a single-platform OCI container image from a set of layers.

This rule assembles container images by combining:
- Optional base image layers (from another image_manifest or image_index)
- Additional layers created by image_layer rules
- Image configuration (entrypoint, environment, labels, etc.)

The rule produces:
- OCI manifest and config JSON files
- An optional OCI layout directory or tar (via output groups)
- ImageManifestInfo provider for use by image_index or image_push

Example:

```python
image_manifest(
    name = "my_app",
    base = "@distroless_cc",
    layers = [
        ":app_layer",
        ":config_layer",
    ],
    entrypoint = ["/usr/bin/app"],
    env = {
        "APP_ENV": "production",
    },
)
```

Output groups:
- `descriptor`: OCI descriptor JSON file
- `digest`: Digest of the image (sha256:...)
- `root_blob`: The manifest JSON blob file
- `oci_layout`: Complete OCI layout directory with blobs
- `oci_tarball`: OCI layout packaged as a tar file for downstream use
- `sparse_oci_layout`: Sparse OCI layout directory (without layer blobs, only layer descriptors)
- `mtree`: a single [mtree](https://man.freebsd.org/cgi/man.cgi?mtree(5)) text file describing the
  image's filesystem, merged (in layer order) from per-layer mtrees. Layers built by rules_img layer
  rules reuse their own `mtree`; for any other layer -- pulled/imported base-image layers, or raw
  tars added directly via `DefaultInfo` -- an mtree is rendered on the fly from the layer's tar blob.
  A layer is skipped on a best-effort basis only when its blob is unavailable (shallow/lazy layers)
  or is not a tar (empty layers, non-tar artifact blobs), so a skipped layer means the merged mtree
  reflects only a subset of the image. Only produced when at least one layer contributes an `mtree`.*
nameA unique name for this target. f
baseVBase image to inherit layers from. Should provide ImageManifestInfo or ImageIndexInfo.2Nonem
layers]Layers to include in the image. Either a LayersInfo provider or a DefaultInfo with tar files.2[]�
platform�Optional target platform to build this manifest for.

When specified, the image will be built for the provided platform regardless
of the current build configuration. This enables building single-platform images
for specific architectures.

Example:
```python
image_manifest(
    name = "app_arm64",
    platform = "//platforms:linux_arm64",
    base = "@ubuntu",
    layers = [":app_layer"],
)
```*(
PlatformInfo
PlatformInfo<native>2None�
omit_media_type�Leave the top-level `mediaType` field out of the manifest.

The OCI image spec says a manifest SHOULD set `mediaType`, so keep the default unless the
manifest has to be byte-identical to one written by a tool that omits the field. `helm push`
is one: a Helm chart manifest whose config, layers and annotations match Helm's gets the
digest Helm pushes only when this attribute is set.

Only the manifest bytes change. The manifest's descriptor, its entries in an `image_index` or
OCI layout, and the `Content-Type` sent to a registry keep
`application/vnd.oci.image.manifest.v1+json`.

Example:
```python
image_manifest(
    name = "chart",
    config_fragment = ":chart_config.json",
    config_media_type = "application/vnd.cncf.helm.config.v1+json",
    layers = [":chart_layer"],
    omit_media_type = True,
)
```2False�
omit_platform�Leave the platform out of this manifest's descriptor.

By default, the descriptor advertises the platform the manifest was built for, which is what
lets an `image_index` pick the right manifest per platform.

Set this for a manifest that describes an artifact rather than a container image -- an ORAS
artifact, a Helm chart, an SBOM. Such a manifest has no platform of its own, so the descriptor
would fall back to whatever platform the build happened to target (the host platform, unless
`platform` is set). In an index, that is both misleading -- a runtime may resolve the index to
the artifact instead of the image -- and non-reproducible, since the index digest then depends
on the machine that ran the build.

Only the descriptor is affected: the image config still records its os and architecture.

Example:
```python
image_manifest(
    name = "sbom",
    artifact_type = "application/spdx+json",
    config_media_type = "application/vnd.oci.empty.v1+json",
    layers = [":sbom_layer"],
    omit_platform = True,
)
```2False�
user�The username or UID which is a platform-specific structure that allows specific control over which user the process run as.
This acts as a default value to use when the value is not specified when creating a container.

Defaults to `INHERIT_FROM_BASE`: the value is inherited from the base image. Set it to
an explicit value to override, or to `""` to unset it (do not inherit from the base).2"<inherit from base>"�
env�Default environment variables to set when starting a container based on this image.

Subject to [template expansion](/docs/templating.md).
2{}�
env_file�File containing environment variables to set when starting a container based on this image.

The file may be JSON or newline-delimited text, auto-detected from its contents:

- JSON object with string values: `{"KEY": "value"}`
- JSON object with list values: `{"KEY": ["value1", "value2"]}` (the last value wins)
- JSON array of `KEY=VALUE` strings: `["KEY=value"]`
- newline-delimited `KEY=VALUE` text (one per line; blank lines and `#` comments are ignored)

Values in JSON objects are used verbatim and may contain `=`, spaces, or newlines.
The `KEY=VALUE` forms split on the first `=` and trim surrounding whitespace.

Values from the `env` attribute (or expanded templates) take precedence over the file.2None�

entrypoint�A list of arguments to use as the command to execute when the container starts. These values act as defaults and may be replaced by an entrypoint specified when creating a container.

Defaults to `[INHERIT_FROM_BASE]`: the entrypoint is inherited from the base image (or,
for `image_from_binary`, from the packaged binary). Set it to an explicit list to override,
or to `[]` to unset it. An `INHERIT_FROM_BASE` item inside the list is replaced in place by
the base image's entrypoint, so `[INHERIT_FROM_BASE, "--flag"]` appends `"--flag"` to it.2["<inherit from base>"]�
cmd�Default arguments to the entrypoint of the container. These values act as defaults and may be replaced by any specified when creating a container. If an Entrypoint value is not specified, then the first entry of the Cmd array SHOULD be interpreted as the executable to run.

Defaults to `[INHERIT_FROM_BASE]`: the value is inherited from the base image (or, for
`image_from_binary`, from the packaged binary's `args`). Set it to an explicit list to
override, or to `[]` to unset it. An `INHERIT_FROM_BASE` item inside the list is replaced in
place by the base image's cmd, so `[INHERIT_FROM_BASE, "--flag"]` appends `"--flag"` to it.2["<inherit from base>"]�
working_dir�Sets the current working directory of the entrypoint process in the container. This value acts as a default and may be replaced by a working directory specified when creating a container.

Defaults to `INHERIT_FROM_BASE`: the value is inherited from the base image (or, for
`image_from_binary`, from the packaged binary). Set it to an explicit value to override, or
to `""` to unset it (do not inherit from the base).2"<inherit from base>"�
labelspThis field contains arbitrary metadata for the container.

Subject to [template expansion](/docs/templating.md).
2{}�
label_files�Files containing labels for the image config, as JSON or newline-delimited text.

Each file is parsed in one of the following formats, auto-detected from its contents:

- JSON object with string values: `{"key": "value"}`
- JSON object with list values: `{"key": ["value1", "value2"]}` (the last value wins)
- JSON array of `KEY=VALUE` strings: `["key=value"]`
- newline-delimited `KEY=VALUE` text (one per line; blank lines and `#` comments are ignored)

Values in JSON objects are used verbatim, so they can encode arbitrary strings including
values that contain `=`, spaces, or newlines. The `KEY=VALUE` forms (JSON array and text)
split on the first `=` and trim surrounding whitespace from the key and value.

Labels from these files are merged together, and then merged with labels specified via
the `labels` attribute. Values from files take precedence over the `labels` attribute
for matching keys.

Example file content:
```
org.opencontainers.image.version=1.0.0
org.opencontainers.image.authors=team@example.com
```

Each label value is subject to [template expansion](/docs/templating.md).2[]�
annotationsoThis field contains arbitrary metadata for the manifest.

Subject to [template expansion](/docs/templating.md).
2{}�
annotations_file�File containing annotations for the manifest, as JSON or newline-delimited text.

The file is parsed in one of the following formats, auto-detected from its contents:

- JSON object with string values: `{"key": "value"}`
- JSON object with list values: `{"key": ["value1", "value2"]}` (the last value wins)
- JSON array of `KEY=VALUE` strings: `["key=value"]`
- newline-delimited `KEY=VALUE` text (one per line; blank lines and `#` comments are ignored)

Values in JSON objects are used verbatim, so they can encode arbitrary strings including
values that contain `=`, spaces, or newlines. The `KEY=VALUE` forms (JSON array and text)
split on the first `=` and trim surrounding whitespace from the key and value.

Annotations from this file are merged with annotations specified via the `annotations`
attribute. Values from the file take precedence over the `annotations` attribute for matching keys.

Example file content:
```
version=1.0.0
build.date=2024-01-15
source.url=https://github.com/...
```

Each annotation is subject to [template expansion](/docs/templating.md).2None�
stop_signal�This field contains the system call signal that will be sent to the container to exit. The signal can be a signal name in the format SIGNAME, for instance SIGKILL or SIGRTMIN+3.

Defaults to `INHERIT_FROM_BASE`: the value is inherited from the base image. Set it to an
explicit value to override, or to `""` to unset it (do not inherit from the base).2"<inherit from base>"�
config_fragment�Optional JSON file containing a partial OCI image config, which will be used as a base for the final image config.

For OCI image configuration fields such as exposed ports or volumes, the JSON should use the top-level `config` object:

```json
{
  "config": {
    "ExposedPorts": {
      "8080/tcp": {}
    }
  }
}
```

When config_media_type is set to a non-OCI type (e.g. Helm), this file is used as the entire config blob as-is.2None�
config_media_type�Override the config blob media type.

When set to "application/vnd.oci.empty.v1+json", config_fragment is optional. If omitted, an empty
JSON config descriptor is produced automatically with the content inlined as data (`"data": "e30="`).

For other non-OCI types (e.g. "application/vnd.cncf.helm.config.v1+json" for Helm charts),
config_fragment is required and used verbatim as the config blob (no OCI image structure).2""�
artifact_type�Optional IANA media type of the artifact when the manifest is used for an artifact.

This sets the `artifactType` field in the OCI manifest, as defined in the
[OCI Image Spec](https://github.com/opencontainers/image-spec/blob/main/manifest.md#image-manifest-property-descriptions).

Common values include `application/vnd.cncf.helm.chart.v1` for Helm charts
or `application/spdx+json` for SPDX SBOMs.2""�
subject�Optional subject for the manifest.

Sets the `subject` field in the OCI manifest, which is a descriptor pointing to
another manifest or index. This is used for establishing referrer relationships,
such as attaching SBOMs, signatures, or attestations to an existing image.

The target must provide either ImageManifestInfo or ImageIndexInfo.*]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl*T
ImageIndexInfoB
ImageIndexInfo0@rules_img//img/private/providers:index_info.bzl2None�
created�Optional file containing a datetime string (RFC 3339 format) for when the image was created.

This is commonly used with Bazel's stamping mechanism to embed the build timestamp.

Mutually exclusive with `created_timestamp`. Takes precedence over `stamp_created`.2None�
created_timestamp�Optional datetime string (RFC 3339 format) for when the image was created.

Subject to [template expansion](/docs/templating.md), so the timestamp can come from
a stamp value. `{{.BUILD_TIMESTAMP_RFC3339}}` is Bazel's build time, converted from
the volatile `BUILD_TIMESTAMP` workspace status value:

```python
image_manifest(
    name = "my_app",
    created_timestamp = "{{.BUILD_TIMESTAMP_RFC3339}}",  # same as stamp_created = "enabled"
    layers = [":app_layer"],
)
```

If the expanded value is empty -- which is what happens when stamping is inactive --
the `created` field is left unset, keeping the image reproducible.

Mutually exclusive with `created`.2""�
stamp_created�Whether to stamp the image config's `created` timestamp with Bazel's build time.

Shorthand for `created_timestamp = "{{.BUILD_TIMESTAMP_RFC3339}}"`.

- **`auto`** (default): defers to the global `--@rules_img//img/settings:stamp_created`
  setting, which itself defaults to `disabled`.
- **`enabled`**: set the config's `created` field to the build time. Since `BUILD_TIMESTAMP`
  is a volatile workspace status value, this is best-effort: it makes the image
  non-reproducible, and the timestamp only refreshes when the image is rebuilt for
  other reasons (see [templating](/docs/templating.md)). Requires stamping to be
  active (Bazel's `--stamp`, or `stamp = "force"`); without it the field stays unset.
- **`disabled`**: never stamp the `created` field.

Ignored when `created` or `created_timestamp` is set.2"auto"J"auto"J	"enabled"J
"disabled"�
build_settings�Build settings for template expansion.

Maps template variable names to string_flag targets. These values can be used in
env, labels, and annotations attributes using `{{.VARIABLE_NAME}}` syntax (Go template).

Example:
```python
build_settings = {
    "REGISTRY": "//settings:docker_registry",
    "VERSION": "//settings:app_version",
}
```

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"J"auto"J"force"J
"disabled"�
soci�Whether to build a SOCI Index Manifest v2 for this image.

- **`auto`** (default): defers to the global `--@rules_img//img/settings:soci` setting.
- **`enabled`**: build a SOCI index. Each gzip layer's ztoc is reused from the layer
  (when the layer emitted one) or generated on the fly; the image manifest gains a
  `com.amazon.soci.index-digest` annotation (which changes its digest). For lazy
  pulling with soci-snapshotter to work end-to-end, wrap the image in an `image_index`
  (which emits the OCI-index cross-reference entry). See [SOCI](/docs/soci.md).
- **`disabled`**: never build a SOCI index.2"auto"J"auto"J	"enabled"J
"disabled"�
soci_span_sizetSpan size (uncompressed bytes between ztoc checkpoints). -1 (default) uses the global //img/settings:soci_span_size.2-1�
soci_min_layer_size�Layers smaller than this many bytes are omitted from the SOCI index. -1 (default) uses the global //img/settings:soci_min_layer_size.2-1�

push_specs�Push configurations to produce DeployInfo for this image.

Each entry should be an `image_push_spec` target (providing `PushConfigInfo`).
When set (together with or without `load_specs`), this rule additionally returns
`DeployInfo`, making it directly usable as an operation in `multi_deploy`.

Example:
```python
image_push_spec(
    name = "push_config",
    registry = "gcr.io",
    repository = "my-project/my-app",
    tag = "latest",
)

image_manifest(
    name = "my_app",
    base = "@distroless_cc",
    layers = [":app_layer"],
    push_specs = [":push_config"],
)

multi_deploy(
    name = "deploy",
    operations = [":my_app"],
)
```*Z
PushConfigInfoH
PushConfigInfo6@rules_img//img/private/providers:push_config_info.bzl2[]�

load_specs�Load configurations to produce DeployInfo for this image.

Each entry should be an `image_load_spec` target (providing `LoadConfigInfo`).
When set (together with or without `push_specs`), this rule additionally returns
`DeployInfo`, making it directly usable as an operation in `multi_deploy`.

Example:
```python
image_load_spec(
    name = "load_config",
    tag = "my-app:latest",
)

image_manifest(
    name = "my_app",
    base = "@distroless_cc",
    layers = [":app_layer"],
    load_specs = [":load_config"],
)

multi_deploy(
    name = "deploy",
    operations = [":my_app"],
)
```*Z
LoadConfigInfoH
LoadConfigInfo6@rules_img//img/private/providers:load_config_info.bzl2[]"6
image_manifest$@rules_img//img/private:manifest.bzl*]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl,
*
nameA unique name for this target. h
f
baseVBase image to inherit layers from. Should provide ImageManifestInfo or ImageIndexInfo.2Noneo
m
layers]Layers to include in the image. Either a LayersInfo provider or a DefaultInfo with tar files.2[]�
�
platform�Optional target platform to build this manifest for.

When specified, the image will be built for the provided platform regardless
of the current build configuration. This enables building single-platform images
for specific architectures.

Example:
```python
image_manifest(
    name = "app_arm64",
    platform = "//platforms:linux_arm64",
    base = "@ubuntu",
    layers = [":app_layer"],
)
```*(
PlatformInfo
PlatformInfo<native>2None�
�
omit_media_type�Leave the top-level `mediaType` field out of the manifest.

The OCI image spec says a manifest SHOULD set `mediaType`, so keep the default unless the
manifest has to be byte-identical to one written by a tool that omits the field. `helm push`
is one: a Helm chart manifest whose config, layers and annotations match Helm's gets the
digest Helm pushes only when this attribute is set.

Only the manifest bytes change. The manifest's descriptor, its entries in an `image_index` or
OCI layout, and the `Content-Type` sent to a registry keep
`application/vnd.oci.image.manifest.v1+json`.

Example:
```python
image_manifest(
    name = "chart",
    config_fragment = ":chart_config.json",
    config_media_type = "application/vnd.cncf.helm.config.v1+json",
    layers = [":chart_layer"],
    omit_media_type = True,
)
```2False�
�
omit_platform�Leave the platform out of this manifest's descriptor.

By default, the descriptor advertises the platform the manifest was built for, which is what
lets an `image_index` pick the right manifest per platform.

Set this for a manifest that describes an artifact rather than a container image -- an ORAS
artifact, a Helm chart, an SBOM. Such a manifest has no platform of its own, so the descriptor
would fall back to whatever platform the build happened to target (the host platform, unless
`platform` is set). In an index, that is both misleading -- a runtime may resolve the index to
the artifact instead of the image -- and non-reproducible, since the index digest then depends
on the machine that ran the build.

Only the descriptor is affected: the image config still records its os and architecture.

Example:
```python
image_manifest(
    name = "sbom",
    artifact_type = "application/spdx+json",
    config_media_type = "application/vnd.oci.empty.v1+json",
    layers = [":sbom_layer"],
    omit_platform = True,
)
```2False�
�
user�The username or UID which is a platform-specific structure that allows specific control over which user the process run as.
This acts as a default value to use when the value is not specified when creating a container.

Defaults to `INHERIT_FROM_BASE`: the value is inherited from the base image. Set it to
an explicit value to override, or to `""` to unset it (do not inherit from the base).2"<inherit from base>"�
�
env�Default environment variables to set when starting a container based on this image.

Subject to [template expansion](/docs/templating.md).
2{}�
�
env_file�File containing environment variables to set when starting a container based on this image.

The file may be JSON or newline-delimited text, auto-detected from its contents:

- JSON object with string values: `{"KEY": "value"}`
- JSON object with list values: `{"KEY": ["value1", "value2"]}` (the last value wins)
- JSON array of `KEY=VALUE` strings: `["KEY=value"]`
- newline-delimited `KEY=VALUE` text (one per line; blank lines and `#` comments are ignored)

Values in JSON objects are used verbatim and may contain `=`, spaces, or newlines.
The `KEY=VALUE` forms split on the first `=` and trim surrounding whitespace.

Values from the `env` attribute (or expanded templates) take precedence over the file.2None�
�

entrypoint�A list of arguments to use as the command to execute when the container starts. These values act as defaults and may be replaced by an entrypoint specified when creating a container.

Defaults to `[INHERIT_FROM_BASE]`: the entrypoint is inherited from the base image (or,
for `image_from_binary`, from the packaged binary). Set it to an explicit list to override,
or to `[]` to unset it. An `INHERIT_FROM_BASE` item inside the list is replaced in place by
the base image's entrypoint, so `[INHERIT_FROM_BASE, "--flag"]` appends `"--flag"` to it.2["<inherit from base>"]�
�
cmd�Default arguments to the entrypoint of the container. These values act as defaults and may be replaced by any specified when creating a container. If an Entrypoint value is not specified, then the first entry of the Cmd array SHOULD be interpreted as the executable to run.

Defaults to `[INHERIT_FROM_BASE]`: the value is inherited from the base image (or, for
`image_from_binary`, from the packaged binary's `args`). Set it to an explicit list to
override, or to `[]` to unset it. An `INHERIT_FROM_BASE` item inside the list is replaced in
place by the base image's cmd, so `[INHERIT_FROM_BASE, "--flag"]` appends `"--flag"` to it.2["<inherit from base>"]�
�
working_dir�Sets the current working directory of the entrypoint process in the container. This value acts as a default and may be replaced by a working directory specified when creating a container.

Defaults to `INHERIT_FROM_BASE`: the value is inherited from the base image (or, for
`image_from_binary`, from the packaged binary). Set it to an explicit value to override, or
to `""` to unset it (do not inherit from the base).2"<inherit from base>"�
�
labelspThis field contains arbitrary metadata for the container.

Subject to [template expansion](/docs/templating.md).
2{}�
�
label_files�Files containing labels for the image config, as JSON or newline-delimited text.

Each file is parsed in one of the following formats, auto-detected from its contents:

- JSON object with string values: `{"key": "value"}`
- JSON object with list values: `{"key": ["value1", "value2"]}` (the last value wins)
- JSON array of `KEY=VALUE` strings: `["key=value"]`
- newline-delimited `KEY=VALUE` text (one per line; blank lines and `#` comments are ignored)

Values in JSON objects are used verbatim, so they can encode arbitrary strings including
values that contain `=`, spaces, or newlines. The `KEY=VALUE` forms (JSON array and text)
split on the first `=` and trim surrounding whitespace from the key and value.

Labels from these files are merged together, and then merged with labels specified via
the `labels` attribute. Values from files take precedence over the `labels` attribute
for matching keys.

Example file content:
```
org.opencontainers.image.version=1.0.0
org.opencontainers.image.authors=team@example.com
```

Each label value is subject to [template expansion](/docs/templating.md).2[]�
�
annotationsoThis field contains arbitrary metadata for the manifest.

Subject to [template expansion](/docs/templating.md).
2{}�
�
annotations_file�File containing annotations for the manifest, as JSON or newline-delimited text.

The file is parsed in one of the following formats, auto-detected from its contents:

- JSON object with string values: `{"key": "value"}`
- JSON object with list values: `{"key": ["value1", "value2"]}` (the last value wins)
- JSON array of `KEY=VALUE` strings: `["key=value"]`
- newline-delimited `KEY=VALUE` text (one per line; blank lines and `#` comments are ignored)

Values in JSON objects are used verbatim, so they can encode arbitrary strings including
values that contain `=`, spaces, or newlines. The `KEY=VALUE` forms (JSON array and text)
split on the first `=` and trim surrounding whitespace from the key and value.

Annotations from this file are merged with annotations specified via the `annotations`
attribute. Values from the file take precedence over the `annotations` attribute for matching keys.

Example file content:
```
version=1.0.0
build.date=2024-01-15
source.url=https://github.com/...
```

Each annotation is subject to [template expansion](/docs/templating.md).2None�
�
stop_signal�This field contains the system call signal that will be sent to the container to exit. The signal can be a signal name in the format SIGNAME, for instance SIGKILL or SIGRTMIN+3.

Defaults to `INHERIT_FROM_BASE`: the value is inherited from the base image. Set it to an
explicit value to override, or to `""` to unset it (do not inherit from the base).2"<inherit from base>"�
�
config_fragment�Optional JSON file containing a partial OCI image config, which will be used as a base for the final image config.

For OCI image configuration fields such as exposed ports or volumes, the JSON should use the top-level `config` object:

```json
{
  "config": {
    "ExposedPorts": {
      "8080/tcp": {}
    }
  }
}
```

When config_media_type is set to a non-OCI type (e.g. Helm), this file is used as the entire config blob as-is.2None�
�
config_media_type�Override the config blob media type.

When set to "application/vnd.oci.empty.v1+json", config_fragment is optional. If omitted, an empty
JSON config descriptor is produced automatically with the content inlined as data (`"data": "e30="`).

For other non-OCI types (e.g. "application/vnd.cncf.helm.config.v1+json" for Helm charts),
config_fragment is required and used verbatim as the config blob (no OCI image structure).2""�
�
artifact_type�Optional IANA media type of the artifact when the manifest is used for an artifact.

This sets the `artifactType` field in the OCI manifest, as defined in the
[OCI Image Spec](https://github.com/opencontainers/image-spec/blob/main/manifest.md#image-manifest-property-descriptions).

Common values include `application/vnd.cncf.helm.chart.v1` for Helm charts
or `application/spdx+json` for SPDX SBOMs.2""�
�
subject�Optional subject for the manifest.

Sets the `subject` field in the OCI manifest, which is a descriptor pointing to
another manifest or index. This is used for establishing referrer relationships,
such as attaching SBOMs, signatures, or attestations to an existing image.

The target must provide either ImageManifestInfo or ImageIndexInfo.*]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl*T
ImageIndexInfoB
ImageIndexInfo0@rules_img//img/private/providers:index_info.bzl2None�
�
created�Optional file containing a datetime string (RFC 3339 format) for when the image was created.

This is commonly used with Bazel's stamping mechanism to embed the build timestamp.

Mutually exclusive with `created_timestamp`. Takes precedence over `stamp_created`.2None�
�
created_timestamp�Optional datetime string (RFC 3339 format) for when the image was created.

Subject to [template expansion](/docs/templating.md), so the timestamp can come from
a stamp value. `{{.BUILD_TIMESTAMP_RFC3339}}` is Bazel's build time, converted from
the volatile `BUILD_TIMESTAMP` workspace status value:

```python
image_manifest(
    name = "my_app",
    created_timestamp = "{{.BUILD_TIMESTAMP_RFC3339}}",  # same as stamp_created = "enabled"
    layers = [":app_layer"],
)
```

If the expanded value is empty -- which is what happens when stamping is inactive --
the `created` field is left unset, keeping the image reproducible.

Mutually exclusive with `created`.2""�
�
stamp_created�Whether to stamp the image config's `created` timestamp with Bazel's build time.

Shorthand for `created_timestamp = "{{.BUILD_TIMESTAMP_RFC3339}}"`.

- **`auto`** (default): defers to the global `--@rules_img//img/settings:stamp_created`
  setting, which itself defaults to `disabled`.
- **`enabled`**: set the config's `created` field to the build time. Since `BUILD_TIMESTAMP`
  is a volatile workspace status value, this is best-effort: it makes the image
  non-reproducible, and the timestamp only refreshes when the image is rebuilt for
  other reasons (see [templating](/docs/templating.md)). Requires stamping to be
  active (Bazel's `--stamp`, or `stamp = "force"`); without it the field stays unset.
- **`disabled`**: never stamp the `created` field.

Ignored when `created` or `created_timestamp` is set.2"auto"J"auto"J	"enabled"J
"disabled"�
�
build_settings�Build settings for template expansion.

Maps template variable names to string_flag targets. These values can be used in
env, labels, and annotations attributes using `{{.VARIABLE_NAME}}` syntax (Go template).

Example:
```python
build_settings = {
    "REGISTRY": "//settings:docker_registry",
    "VERSION": "//settings:app_version",
}
```

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"J"auto"J"force"J
"disabled"�
�
soci�Whether to build a SOCI Index Manifest v2 for this image.

- **`auto`** (default): defers to the global `--@rules_img//img/settings:soci` setting.
- **`enabled`**: build a SOCI index. Each gzip layer's ztoc is reused from the layer
  (when the layer emitted one) or generated on the fly; the image manifest gains a
  `com.amazon.soci.index-digest` annotation (which changes its digest). For lazy
  pulling with soci-snapshotter to work end-to-end, wrap the image in an `image_index`
  (which emits the OCI-index cross-reference entry). See [SOCI](/docs/soci.md).
- **`disabled`**: never build a SOCI index.2"auto"J"auto"J	"enabled"J
"disabled"�
�
soci_span_sizetSpan size (uncompressed bytes between ztoc checkpoints). -1 (default) uses the global //img/settings:soci_span_size.2-1�
�
soci_min_layer_size�Layers smaller than this many bytes are omitted from the SOCI index. -1 (default) uses the global //img/settings:soci_min_layer_size.2-1�
�

push_specs�Push configurations to produce DeployInfo for this image.

Each entry should be an `image_push_spec` target (providing `PushConfigInfo`).
When set (together with or without `load_specs`), this rule additionally returns
`DeployInfo`, making it directly usable as an operation in `multi_deploy`.

Example:
```python
image_push_spec(
    name = "push_config",
    registry = "gcr.io",
    repository = "my-project/my-app",
    tag = "latest",
)

image_manifest(
    name = "my_app",
    base = "@distroless_cc",
    layers = [":app_layer"],
    push_specs = [":push_config"],
)

multi_deploy(
    name = "deploy",
    operations = [":my_app"],
)
```*Z
PushConfigInfoH
PushConfigInfo6@rules_img//img/private/providers:push_config_info.bzl2[]�
�

load_specs�Load configurations to produce DeployInfo for this image.

Each entry should be an `image_load_spec` target (providing `LoadConfigInfo`).
When set (together with or without `push_specs`), this rule additionally returns
`DeployInfo`, making it directly usable as an operation in `multi_deploy`.

Example:
```python
image_load_spec(
    name = "load_config",
    tag = "my-app:latest",
)

image_manifest(
    name = "my_app",
    base = "@distroless_cc",
    layers = [":app_layer"],
    load_specs = [":load_config"],
)

multi_deploy(
    name = "deploy",
    operations = [":my_app"],
)
```*Z
LoadConfigInfoH
LoadConfigInfo6@rules_img//img/private/providers:load_config_info.bzl2[]�kimage_index�
Creates a multi-platform OCI image index from platform-specific manifests.

This rule combines multiple single-platform images (created by image_manifest) into
a multi-platform image index. The index allows container runtimes to automatically
select the appropriate image for their platform.

The rule supports two usage patterns:
1. Explicit manifests: Provide pre-built manifests for each platform
2. Platform transitions: Provide one manifest target and a list of platforms

The rule produces:
- OCI image index JSON file
- An optional OCI layout directory or tar (via output groups)
- ImageIndexInfo provider for use by image_push

Example (explicit manifests):

```python
image_index(
    name = "multiarch_app",
    manifests = [
        ":app_linux_amd64",
        ":app_linux_arm64",
        ":app_darwin_amd64",
    ],
)
```

Example (platform transitions):
```python
image_index(
    name = "multiarch_app",
    manifests = [":app"],
    platforms = [
        "//platform:linux-x86_64",
        "//platform:linux-aarch64",
    ],
)
```

Output groups:
- `digest`: Digest of the image (sha256:...)
- `root_blob`: The index JSON blob file
- `oci_layout`: Complete OCI layout directory with all platform blobs
- `oci_tarball`: OCI layout packaged as a tar file for downstream use
- `sparse_oci_layout`: Sparse OCI layout directory (without layer blobs, only layer descriptors)"�`
�5
image_index�
Creates a multi-platform OCI image index from platform-specific manifests.

This rule combines multiple single-platform images (created by image_manifest) into
a multi-platform image index. The index allows container runtimes to automatically
select the appropriate image for their platform.

The rule supports two usage patterns:
1. Explicit manifests: Provide pre-built manifests for each platform
2. Platform transitions: Provide one manifest target and a list of platforms

The rule produces:
- OCI image index JSON file
- An optional OCI layout directory or tar (via output groups)
- ImageIndexInfo provider for use by image_push

Example (explicit manifests):

```python
image_index(
    name = "multiarch_app",
    manifests = [
        ":app_linux_amd64",
        ":app_linux_arm64",
        ":app_darwin_amd64",
    ],
)
```

Example (platform transitions):
```python
image_index(
    name = "multiarch_app",
    manifests = [":app"],
    platforms = [
        "//platform:linux-x86_64",
        "//platform:linux-aarch64",
    ],
)
```

Output groups:
- `digest`: Digest of the image (sha256:...)
- `root_blob`: The index JSON blob file
- `oci_layout`: Complete OCI layout directory with all platform blobs
- `oci_tarball`: OCI layout packaged as a tar file for downstream use
- `sparse_oci_layout`: Sparse OCI layout directory (without layer blobs, only layer descriptors)*
nameA unique name for this target. �
	manifests)List of manifests for specific platforms.*]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl2[]�
	platforms�(Optional) list of target platforms to build the manifest for. Uses a split transition. If specified, the 'manifests' attribute should contain exactly one manifest.*(
PlatformInfo
PlatformInfo<native>2[]�

index_platform�
The platform this index is configured on when it has `platforms`.

- **`auto`** (default): defers to the global `--@rules_img//img/settings:index_platform` setting, which defaults to `inherited`.
- **`inherited`**: the platform it is reached from. An index used as the `base` of an image is configured on the platform of each manifest that uses it, so its attributes can `select()` on that platform.
- **`multiarch`**: `@rules_img//img/private/platforms:multiarch`, a platform with no constraints. An index used as the `base` of several images, or of an image built for several platforms, is then configured and analyzed once. Its manifests are still built for each of `platforms`.

Under `multiarch`, the index's own attributes are resolved on that platform:

- a `select()` on the target platform, including in `platforms`, takes its `//conditions:default` branch, or fails analysis without one;
- `target_compatible_with` that names platform constraints, such as `@platforms//os:linux`, makes the index incompatible, and so everything that depends on it;
- dependencies outside `manifests`, such as `subject`, `push_specs` and `load_specs`, are configured on that platform too, so an `image_manifest` among them needs its own `platform`.

Has no effect on an index without `platforms`.2"auto"J"auto"J"inherited"J"multiarch"�
subject�Optional subject for the index.

Sets the `subject` field in the OCI index, which is a descriptor pointing to
another manifest or index. This is used for establishing referrer relationships,
such as attaching SBOMs, signatures, or attestations to an existing image.

The target must provide either ImageManifestInfo or ImageIndexInfo.*]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl*T
ImageIndexInfoB
ImageIndexInfo0@rules_img//img/private/providers:index_info.bzl2Nones
annotations^Arbitrary metadata for the image index.

Subject to [template expansion](/docs/templating.md).
2{}�
annotations_file�File containing annotations for the image index, as JSON or newline-delimited text.

The file is parsed in one of the following formats, auto-detected from its contents:

- JSON object with string values: `{"key": "value"}`
- JSON object with list values: `{"key": ["value1", "value2"]}` (the last value wins)
- JSON array of `KEY=VALUE` strings: `["key=value"]`
- newline-delimited `KEY=VALUE` text (one per line; blank lines and `#` comments are ignored)

Values in JSON objects are used verbatim, so they can encode arbitrary strings including
values that contain `=`, spaces, or newlines. The `KEY=VALUE` forms (JSON array and text)
split on the first `=` and trim surrounding whitespace from the key and value.

Annotations from this file are merged with annotations specified via the `annotations`
attribute. Values from the file take precedence over the `annotations` attribute for matching keys.

Example file content:
```
version=1.0.0
build.date=2024-01-15
source.url=https://github.com/...
```

Each annotation is subject to [template expansion](/docs/templating.md).2None�
build_settings�Build settings for template expansion.

Maps template variable names to string_flag targets. These values can be used in
the annotations attribute using `{{.VARIABLE_NAME}}` syntax (Go template).

Example:
```python
build_settings = {
    "REGISTRY": "//settings:docker_registry",
    "VERSION": "//settings:app_version",
}
```

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"J"auto"J"force"J
"disabled"�

push_specs�Push configurations to produce DeployInfo for this image index.

Each entry should be an `image_push_spec` target (providing `PushConfigInfo`).
When set (together with or without `load_specs`), this rule additionally returns
`DeployInfo`, making it directly usable as an operation in `multi_deploy`.

For multi-platform pushes, `manifest_tags` on the push spec are expanded
per child manifest with platform variables (`{{.os}}`, `{{.architecture}}`, etc.).*Z
PushConfigInfoH
PushConfigInfo6@rules_img//img/private/providers:push_config_info.bzl2[]�

load_specs�Load configurations to produce DeployInfo for this image index.

Each entry should be an `image_load_spec` target (providing `LoadConfigInfo`).
When set (together with or without `push_specs`), this rule additionally returns
`DeployInfo`, making it directly usable as an operation in `multi_deploy`.*Z
LoadConfigInfoH
LoadConfigInfo6@rules_img//img/private/providers:load_config_info.bzl2[]"0
image_index!@rules_img//img/private:index.bzl,
*
nameA unique name for this target. �
�
	manifests)List of manifests for specific platforms.*]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl2[]�
�
	platforms�(Optional) list of target platforms to build the manifest for. Uses a split transition. If specified, the 'manifests' attribute should contain exactly one manifest.*(
PlatformInfo
PlatformInfo<native>2[]�

�

index_platform�
The platform this index is configured on when it has `platforms`.

- **`auto`** (default): defers to the global `--@rules_img//img/settings:index_platform` setting, which defaults to `inherited`.
- **`inherited`**: the platform it is reached from. An index used as the `base` of an image is configured on the platform of each manifest that uses it, so its attributes can `select()` on that platform.
- **`multiarch`**: `@rules_img//img/private/platforms:multiarch`, a platform with no constraints. An index used as the `base` of several images, or of an image built for several platforms, is then configured and analyzed once. Its manifests are still built for each of `platforms`.

Under `multiarch`, the index's own attributes are resolved on that platform:

- a `select()` on the target platform, including in `platforms`, takes its `//conditions:default` branch, or fails analysis without one;
- `target_compatible_with` that names platform constraints, such as `@platforms//os:linux`, makes the index incompatible, and so everything that depends on it;
- dependencies outside `manifests`, such as `subject`, `push_specs` and `load_specs`, are configured on that platform too, so an `image_manifest` among them needs its own `platform`.

Has no effect on an index without `platforms`.2"auto"J"auto"J"inherited"J"multiarch"�
�
subject�Optional subject for the index.

Sets the `subject` field in the OCI index, which is a descriptor pointing to
another manifest or index. This is used for establishing referrer relationships,
such as attaching SBOMs, signatures, or attestations to an existing image.

The target must provide either ImageManifestInfo or ImageIndexInfo.*]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl*T
ImageIndexInfoB
ImageIndexInfo0@rules_img//img/private/providers:index_info.bzl2Noneu
s
annotations^Arbitrary metadata for the image index.

Subject to [template expansion](/docs/templating.md).
2{}�
�
annotations_file�File containing annotations for the image index, as JSON or newline-delimited text.

The file is parsed in one of the following formats, auto-detected from its contents:

- JSON object with string values: `{"key": "value"}`
- JSON object with list values: `{"key": ["value1", "value2"]}` (the last value wins)
- JSON array of `KEY=VALUE` strings: `["key=value"]`
- newline-delimited `KEY=VALUE` text (one per line; blank lines and `#` comments are ignored)

Values in JSON objects are used verbatim, so they can encode arbitrary strings including
values that contain `=`, spaces, or newlines. The `KEY=VALUE` forms (JSON array and text)
split on the first `=` and trim surrounding whitespace from the key and value.

Annotations from this file are merged with annotations specified via the `annotations`
attribute. Values from the file take precedence over the `annotations` attribute for matching keys.

Example file content:
```
version=1.0.0
build.date=2024-01-15
source.url=https://github.com/...
```

Each annotation is subject to [template expansion](/docs/templating.md).2None�
�
build_settings�Build settings for template expansion.

Maps template variable names to string_flag targets. These values can be used in
the annotations attribute using `{{.VARIABLE_NAME}}` syntax (Go template).

Example:
```python
build_settings = {
    "REGISTRY": "//settings:docker_registry",
    "VERSION": "//settings:app_version",
}
```

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"J"auto"J"force"J
"disabled"�
�

push_specs�Push configurations to produce DeployInfo for this image index.

Each entry should be an `image_push_spec` target (providing `PushConfigInfo`).
When set (together with or without `load_specs`), this rule additionally returns
`DeployInfo`, making it directly usable as an operation in `multi_deploy`.

For multi-platform pushes, `manifest_tags` on the push spec are expanded
per child manifest with platform variables (`{{.os}}`, `{{.architecture}}`, etc.).*Z
PushConfigInfoH
PushConfigInfo6@rules_img//img/private/providers:push_config_info.bzl2[]�
�

load_specs�Load configurations to produce DeployInfo for this image index.

Each entry should be an `image_load_spec` target (providing `LoadConfigInfo`).
When set (together with or without `push_specs`), this rule additionally returns
`DeployInfo`, making it directly usable as an operation in `multi_deploy`.*Z
LoadConfigInfoH
LoadConfigInfo6@rules_img//img/private/providers:load_config_info.bzl2[]�image_optimize�Rewrites every available layer in an image manifest or image index.

This rule applies image-wide layer transformations, such as recompressing every
layer as eStargz. It is intentionally explicit because it requires every input
layer blob to be available to Bazel. Images that were pulled shallowly will fail
analysis instead of downloading missing base-image layers.

Example:

```python
load("@rules_img//img:image.bzl", "image_optimize")

image_optimize(
    name = "base_estargz",
    image = "@ubuntu//:image",
    estargz = "enabled",
)
```"�
�
image_optimize�Rewrites every available layer in an image manifest or image index.

This rule applies image-wide layer transformations, such as recompressing every
layer as eStargz. It is intentionally explicit because it requires every input
layer blob to be available to Bazel. Images that were pulled shallowly will fail
analysis instead of downloading missing base-image layers.

Example:

```python
load("@rules_img//img:image.bzl", "image_optimize")

image_optimize(
    name = "base_estargz",
    image = "@ubuntu//:image",
    estargz = "enabled",
)
```*
nameA unique name for this target. �
imageMImage manifest or image index to optimize. All layer blobs must be available. *]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl*T
ImageIndexInfoB
ImageIndexInfo0@rules_img//img/private/providers:index_info.bzl�
compressqCompression algorithm to use for rewritten layers. If set to 'auto', uses the global default compression setting.2"auto"J"auto"J"gzip"J"zstd"J"none"�
estargzcWhether to rewrite layers using eStargz. If set to 'auto', uses the global default eStargz setting.2"auto"J"auto"J	"enabled"J
"disabled"�
zstd_chunked�Whether to rewrite layers using zstd:chunked. If set to 'auto', uses the global default zstd_chunked setting. Requires zstd compression and cannot be combined with estargz.2"auto"J"auto"J	"enabled"J
"disabled""6
image_optimize$@rules_img//img/private:optimize.bzl,
*
nameA unique name for this target. �
�
imageMImage manifest or image index to optimize. All layer blobs must be available. *]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl*T
ImageIndexInfoB
ImageIndexInfo0@rules_img//img/private/providers:index_info.bzl�
�
compressqCompression algorithm to use for rewritten layers. If set to 'auto', uses the global default compression setting.2"auto"J"auto"J"gzip"J"zstd"J"none"�
�
estargzcWhether to rewrite layers using eStargz. If set to 'auto', uses the global default eStargz setting.2"auto"J"auto"J	"enabled"J
"disabled"�
�
zstd_chunked�Whether to rewrite layers using zstd:chunked. If set to 'auto', uses the global default zstd_chunked setting. Requires zstd compression and cannot be combined with estargz.2"auto"J"auto"J	"enabled"J
"disabled"��image_from_binary�Packages a *_binary target into a container image.

This is a convenience macro that combines layer_from_binary and image_manifest (or image_index)
into a single target. It is the simplest way to containerize any Bazel `*_binary` target
(Go, C++, Python, Java, Rust, etc.).

The binary's `args`, `env`, and runfiles are automatically extracted and applied to the
image configuration:
- **entrypoint** is set to the binary's path inside the image
- **cmd** is populated from the binary's `args` attribute
- **env** is populated from the binary's `env` attribute (or RunEnvironmentInfo provider)
- **working_dir** is set to the binary's runfiles root (unless `infer_working_dir = False`,
  which keeps the base image's working directory)

If the binary provides RunfilesGroupInfo (from rules_runfiles_group), the runfiles are split
into separate layers based on the groups. This allows for better caching: stable layers
(interpreter, stdlib) change infrequently and can be shared, while the application code layer
changes with each build. Layers are emitted in the groups' `rank` order (lowest first), and any
RunfilesGroupTransformInfo in the binary's `aspect_hints` is applied first.

Note that RunfilesGroupInfo emission is off by default in rules_runfiles_group. Build with
`--@rules_runfiles_group//runfiles_group:enabled=true` to opt in; without it, group-aware
binaries produce a single layer.

All image_manifest attributes (base, env, labels, annotations, etc.) are inherited and
forwarded to the underlying image_manifest. The binary layer is always appended as the
last layer, after any layers specified in the `layers` attribute.

Example:

```python
load("@rules_go//go:def.bzl", "go_binary")
load("@rules_img//img:image.bzl", "image_from_binary")

go_binary(
    name = "server",
    srcs = ["main.go"],
    env = {"GIN_MODE": "release"},
)

# Package the Go binary with a distroless base
image_from_binary(
    name = "app_image",
    binary = ":server",
    base = "@distroless_base",
)

# Custom path and additional layers
image_from_binary(
    name = "full_image",
    binary = "//cmd/server",
    base = "@ubuntu",
    path = "/usr/local/bin/",
    layers = [":config_layer"],
    env = {"LOG_LEVEL": "info"},
)

# Multi-platform image
image_from_binary(
    name = "multiarch_image",
    binary = "//cmd/server",
    base = "@distroless_base",
    platforms = [
        "//:linux_amd64",
        "//:linux_arm64",
    ],
)
```

Targets created:
- `<name>.layer`: The layer_from_binary containing the executable and its runfiles
- `<name>` (or `<name>.manifest` + `<name>` for multi-platform): The image manifest/indexZ�
��
image_from_binary�Packages a *_binary target into a container image.

This is a convenience macro that combines layer_from_binary and image_manifest (or image_index)
into a single target. It is the simplest way to containerize any Bazel `*_binary` target
(Go, C++, Python, Java, Rust, etc.).

The binary's `args`, `env`, and runfiles are automatically extracted and applied to the
image configuration:
- **entrypoint** is set to the binary's path inside the image
- **cmd** is populated from the binary's `args` attribute
- **env** is populated from the binary's `env` attribute (or RunEnvironmentInfo provider)
- **working_dir** is set to the binary's runfiles root (unless `infer_working_dir = False`,
  which keeps the base image's working directory)

If the binary provides RunfilesGroupInfo (from rules_runfiles_group), the runfiles are split
into separate layers based on the groups. This allows for better caching: stable layers
(interpreter, stdlib) change infrequently and can be shared, while the application code layer
changes with each build. Layers are emitted in the groups' `rank` order (lowest first), and any
RunfilesGroupTransformInfo in the binary's `aspect_hints` is applied first.

Note that RunfilesGroupInfo emission is off by default in rules_runfiles_group. Build with
`--@rules_runfiles_group//runfiles_group:enabled=true` to opt in; without it, group-aware
binaries produce a single layer.

All image_manifest attributes (base, env, labels, annotations, etc.) are inherited and
forwarded to the underlying image_manifest. The binary layer is always appended as the
last layer, after any layers specified in the `layers` attribute.

Example:

```python
load("@rules_go//go:def.bzl", "go_binary")
load("@rules_img//img:image.bzl", "image_from_binary")

go_binary(
    name = "server",
    srcs = ["main.go"],
    env = {"GIN_MODE": "release"},
)

# Package the Go binary with a distroless base
image_from_binary(
    name = "app_image",
    binary = ":server",
    base = "@distroless_base",
)

# Custom path and additional layers
image_from_binary(
    name = "full_image",
    binary = "//cmd/server",
    base = "@ubuntu",
    path = "/usr/local/bin/",
    layers = [":config_layer"],
    env = {"LOG_LEVEL": "info"},
)

# Multi-platform image
image_from_binary(
    name = "multiarch_image",
    binary = "//cmd/server",
    base = "@distroless_base",
    platforms = [
        "//:linux_amd64",
        "//:linux_arm64",
    ],
)
```

Targets created:
- `<name>.layer`: The layer_from_binary containing the executable and its runfiles
- `<name>` (or `<name>.manifest` + `<name>` for multi-platform): The image manifest/index�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@�
binary�The *_binary target to package into the image.

The binary's `args` and `env` attributes are extracted and applied as image configuration
(cmd and env). The `data` attribute is used for `$(location)` expansion in args and env values.

If the binary provides RunfilesGroupInfo, the runfiles are split into separate layers per group. �
path�Optional path of the binary inside the image.
If the path ends with a slash ("/"), the basename of the binary will be automatically appended.
If unset, this defaults to the rlocationpath of the binary (e.g., "_main/cmd/server/server_/server").2""~
layersnAdditional layers to include in the image.
The binary layer is automatically appended to the end of this list.2[]�
include_runfiles�Whether to include runfiles for the binary target.
When True (default), the binary's runfiles tree is included and the working directory
is set to the runfiles root. Set to False for statically linked binaries that don't
need runfiles.2True�
infer_working_dir�Whether to infer the image's working directory from the binary's runfiles tree.

When True (default) and `include_runfiles` is True, the working directory is set to the
main workspace directory inside the runfiles tree, which is where a binary launched
through the runfiles convention expects to run.

When False, the binary layer contributes no working directory, so the base image's
working directory is kept unless the `working_dir` attribute is set explicitly.2True�
layer_budget�Maximum number of runfiles group layers.
If set to a value > 0 and the binary provides RunfilesGroupInfo, groups are merged down to this
limit using the merge algorithm from rules_runfiles_group. The algorithm respects group rank
(only merges within the same rank), do_not_merge flags, merge affinity (groups sharing an
affinity are preferred merge partners), and weight hints (lighter groups merge first).
This is a target, not a hard cap: do_not_merge groups and groups alone in their rank cannot be
merged away, so a binary whose groups cannot be reduced far enough still produces more layers.
0 means no limit (all groups become separate layers).20�
kind�The kind of image to produce.

* "auto": Creates a single-platform manifest if zero or one platforms are provided, otherwise creates an index.
* "manifest": Always creates a single-platform manifest. Fails if multiple platforms are provided.
* "index": Always creates a multi-platform index.2"auto"8J"auto"J
"manifest"J"index"�
	platforms�Target platforms to build the image for.
If empty, the image is built for the current target platform.
If more than one platform is provided, an image_index is automatically created.2[]8
expect_failure2None@ 
transitive_configs2None8@
deprecation2None8@
tags2None8@
testonly2None8@
features2None@
compatible_with2None8@
restricted_to2None8@
package_metadata2None8@
aspect_hints2None@P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@
exec_properties
2None@"
exec_compatible_with2None8@(
exec_group_compatible_with2None8@Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@f
baseVBase image to inherit layers from. Should provide ImageManifestInfo or ImageIndexInfo.2None�
omit_media_type�Leave the top-level `mediaType` field out of the manifest.

The OCI image spec says a manifest SHOULD set `mediaType`, so keep the default unless the
manifest has to be byte-identical to one written by a tool that omits the field. `helm push`
is one: a Helm chart manifest whose config, layers and annotations match Helm's gets the
digest Helm pushes only when this attribute is set.

Only the manifest bytes change. The manifest's descriptor, its entries in an `image_index` or
OCI layout, and the `Content-Type` sent to a registry keep
`application/vnd.oci.image.manifest.v1+json`.

Example:
```python
image_manifest(
    name = "chart",
    config_fragment = ":chart_config.json",
    config_media_type = "application/vnd.cncf.helm.config.v1+json",
    layers = [":chart_layer"],
    omit_media_type = True,
)
```2None�
omit_platform�Leave the platform out of this manifest's descriptor.

By default, the descriptor advertises the platform the manifest was built for, which is what
lets an `image_index` pick the right manifest per platform.

Set this for a manifest that describes an artifact rather than a container image -- an ORAS
artifact, a Helm chart, an SBOM. Such a manifest has no platform of its own, so the descriptor
would fall back to whatever platform the build happened to target (the host platform, unless
`platform` is set). In an index, that is both misleading -- a runtime may resolve the index to
the artifact instead of the image -- and non-reproducible, since the index digest then depends
on the machine that ran the build.

Only the descriptor is affected: the image config still records its os and architecture.

Example:
```python
image_manifest(
    name = "sbom",
    artifact_type = "application/spdx+json",
    config_media_type = "application/vnd.oci.empty.v1+json",
    layers = [":sbom_layer"],
    omit_platform = True,
)
```2None�
user�The username or UID which is a platform-specific structure that allows specific control over which user the process run as.
This acts as a default value to use when the value is not specified when creating a container.

Defaults to `INHERIT_FROM_BASE`: the value is inherited from the base image. Set it to
an explicit value to override, or to `""` to unset it (do not inherit from the base).2None�
env�Default environment variables to set when starting a container based on this image.

Subject to [template expansion](/docs/templating.md).
2None�
env_file�File containing environment variables to set when starting a container based on this image.

The file may be JSON or newline-delimited text, auto-detected from its contents:

- JSON object with string values: `{"KEY": "value"}`
- JSON object with list values: `{"KEY": ["value1", "value2"]}` (the last value wins)
- JSON array of `KEY=VALUE` strings: `["KEY=value"]`
- newline-delimited `KEY=VALUE` text (one per line; blank lines and `#` comments are ignored)

Values in JSON objects are used verbatim and may contain `=`, spaces, or newlines.
The `KEY=VALUE` forms split on the first `=` and trim surrounding whitespace.

Values from the `env` attribute (or expanded templates) take precedence over the file.2None�

entrypoint�A list of arguments to use as the command to execute when the container starts. These values act as defaults and may be replaced by an entrypoint specified when creating a container.

Defaults to `[INHERIT_FROM_BASE]`: the entrypoint is inherited from the base image (or,
for `image_from_binary`, from the packaged binary). Set it to an explicit list to override,
or to `[]` to unset it. An `INHERIT_FROM_BASE` item inside the list is replaced in place by
the base image's entrypoint, so `[INHERIT_FROM_BASE, "--flag"]` appends `"--flag"` to it.2None�
cmd�Default arguments to the entrypoint of the container. These values act as defaults and may be replaced by any specified when creating a container. If an Entrypoint value is not specified, then the first entry of the Cmd array SHOULD be interpreted as the executable to run.

Defaults to `[INHERIT_FROM_BASE]`: the value is inherited from the base image (or, for
`image_from_binary`, from the packaged binary's `args`). Set it to an explicit list to
override, or to `[]` to unset it. An `INHERIT_FROM_BASE` item inside the list is replaced in
place by the base image's cmd, so `[INHERIT_FROM_BASE, "--flag"]` appends `"--flag"` to it.2None�
working_dir�Sets the current working directory of the entrypoint process in the container. This value acts as a default and may be replaced by a working directory specified when creating a container.

Defaults to `INHERIT_FROM_BASE`: the value is inherited from the base image (or, for
`image_from_binary`, from the packaged binary). Set it to an explicit value to override, or
to `""` to unset it (do not inherit from the base).2None�
labelspThis field contains arbitrary metadata for the container.

Subject to [template expansion](/docs/templating.md).
2None�
label_files�Files containing labels for the image config, as JSON or newline-delimited text.

Each file is parsed in one of the following formats, auto-detected from its contents:

- JSON object with string values: `{"key": "value"}`
- JSON object with list values: `{"key": ["value1", "value2"]}` (the last value wins)
- JSON array of `KEY=VALUE` strings: `["key=value"]`
- newline-delimited `KEY=VALUE` text (one per line; blank lines and `#` comments are ignored)

Values in JSON objects are used verbatim, so they can encode arbitrary strings including
values that contain `=`, spaces, or newlines. The `KEY=VALUE` forms (JSON array and text)
split on the first `=` and trim surrounding whitespace from the key and value.

Labels from these files are merged together, and then merged with labels specified via
the `labels` attribute. Values from files take precedence over the `labels` attribute
for matching keys.

Example file content:
```
org.opencontainers.image.version=1.0.0
org.opencontainers.image.authors=team@example.com
```

Each label value is subject to [template expansion](/docs/templating.md).2None�
annotationsoThis field contains arbitrary metadata for the manifest.

Subject to [template expansion](/docs/templating.md).
2None�
annotations_file�File containing annotations for the manifest, as JSON or newline-delimited text.

The file is parsed in one of the following formats, auto-detected from its contents:

- JSON object with string values: `{"key": "value"}`
- JSON object with list values: `{"key": ["value1", "value2"]}` (the last value wins)
- JSON array of `KEY=VALUE` strings: `["key=value"]`
- newline-delimited `KEY=VALUE` text (one per line; blank lines and `#` comments are ignored)

Values in JSON objects are used verbatim, so they can encode arbitrary strings including
values that contain `=`, spaces, or newlines. The `KEY=VALUE` forms (JSON array and text)
split on the first `=` and trim surrounding whitespace from the key and value.

Annotations from this file are merged with annotations specified via the `annotations`
attribute. Values from the file take precedence over the `annotations` attribute for matching keys.

Example file content:
```
version=1.0.0
build.date=2024-01-15
source.url=https://github.com/...
```

Each annotation is subject to [template expansion](/docs/templating.md).2None�
stop_signal�This field contains the system call signal that will be sent to the container to exit. The signal can be a signal name in the format SIGNAME, for instance SIGKILL or SIGRTMIN+3.

Defaults to `INHERIT_FROM_BASE`: the value is inherited from the base image. Set it to an
explicit value to override, or to `""` to unset it (do not inherit from the base).2None�
config_fragment�Optional JSON file containing a partial OCI image config, which will be used as a base for the final image config.

For OCI image configuration fields such as exposed ports or volumes, the JSON should use the top-level `config` object:

```json
{
  "config": {
    "ExposedPorts": {
      "8080/tcp": {}
    }
  }
}
```

When config_media_type is set to a non-OCI type (e.g. Helm), this file is used as the entire config blob as-is.2None�
config_media_type�Override the config blob media type.

When set to "application/vnd.oci.empty.v1+json", config_fragment is optional. If omitted, an empty
JSON config descriptor is produced automatically with the content inlined as data (`"data": "e30="`).

For other non-OCI types (e.g. "application/vnd.cncf.helm.config.v1+json" for Helm charts),
config_fragment is required and used verbatim as the config blob (no OCI image structure).2None�
artifact_type�Optional IANA media type of the artifact when the manifest is used for an artifact.

This sets the `artifactType` field in the OCI manifest, as defined in the
[OCI Image Spec](https://github.com/opencontainers/image-spec/blob/main/manifest.md#image-manifest-property-descriptions).

Common values include `application/vnd.cncf.helm.chart.v1` for Helm charts
or `application/spdx+json` for SPDX SBOMs.2None�
subject�Optional subject for the manifest.

Sets the `subject` field in the OCI manifest, which is a descriptor pointing to
another manifest or index. This is used for establishing referrer relationships,
such as attaching SBOMs, signatures, or attestations to an existing image.

The target must provide either ImageManifestInfo or ImageIndexInfo.*]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl*T
ImageIndexInfoB
ImageIndexInfo0@rules_img//img/private/providers:index_info.bzl2None�
created�Optional file containing a datetime string (RFC 3339 format) for when the image was created.

This is commonly used with Bazel's stamping mechanism to embed the build timestamp.

Mutually exclusive with `created_timestamp`. Takes precedence over `stamp_created`.2None�
created_timestamp�Optional datetime string (RFC 3339 format) for when the image was created.

Subject to [template expansion](/docs/templating.md), so the timestamp can come from
a stamp value. `{{.BUILD_TIMESTAMP_RFC3339}}` is Bazel's build time, converted from
the volatile `BUILD_TIMESTAMP` workspace status value:

```python
image_manifest(
    name = "my_app",
    created_timestamp = "{{.BUILD_TIMESTAMP_RFC3339}}",  # same as stamp_created = "enabled"
    layers = [":app_layer"],
)
```

If the expanded value is empty -- which is what happens when stamping is inactive --
the `created` field is left unset, keeping the image reproducible.

Mutually exclusive with `created`.2None�
stamp_created�Whether to stamp the image config's `created` timestamp with Bazel's build time.

Shorthand for `created_timestamp = "{{.BUILD_TIMESTAMP_RFC3339}}"`.

- **`auto`** (default): defers to the global `--@rules_img//img/settings:stamp_created`
  setting, which itself defaults to `disabled`.
- **`enabled`**: set the config's `created` field to the build time. Since `BUILD_TIMESTAMP`
  is a volatile workspace status value, this is best-effort: it makes the image
  non-reproducible, and the timestamp only refreshes when the image is rebuilt for
  other reasons (see [templating](/docs/templating.md)). Requires stamping to be
  active (Bazel's `--stamp`, or `stamp = "force"`); without it the field stays unset.
- **`disabled`**: never stamp the `created` field.

Ignored when `created` or `created_timestamp` is set.2NoneJ"auto"J	"enabled"J
"disabled"�
build_settings�Build settings for template expansion.

Maps template variable names to string_flag targets. These values can be used in
env, labels, and annotations attributes using `{{.VARIABLE_NAME}}` syntax (Go template).

Example:
```python
build_settings = {
    "REGISTRY": "//settings:docker_registry",
    "VERSION": "//settings:app_version",
}
```

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2None�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2NoneJ"auto"J"force"J
"disabled"�
soci�Whether to build a SOCI Index Manifest v2 for this image.

- **`auto`** (default): defers to the global `--@rules_img//img/settings:soci` setting.
- **`enabled`**: build a SOCI index. Each gzip layer's ztoc is reused from the layer
  (when the layer emitted one) or generated on the fly; the image manifest gains a
  `com.amazon.soci.index-digest` annotation (which changes its digest). For lazy
  pulling with soci-snapshotter to work end-to-end, wrap the image in an `image_index`
  (which emits the OCI-index cross-reference entry). See [SOCI](/docs/soci.md).
- **`disabled`**: never build a SOCI index.2NoneJ"auto"J	"enabled"J
"disabled"�
soci_span_sizetSpan size (uncompressed bytes between ztoc checkpoints). -1 (default) uses the global //img/settings:soci_span_size.2None�
soci_min_layer_size�Layers smaller than this many bytes are omitted from the SOCI index. -1 (default) uses the global //img/settings:soci_min_layer_size.2None�

push_specs�Push configurations to produce DeployInfo for this image.

Each entry should be an `image_push_spec` target (providing `PushConfigInfo`).
When set (together with or without `load_specs`), this rule additionally returns
`DeployInfo`, making it directly usable as an operation in `multi_deploy`.

Example:
```python
image_push_spec(
    name = "push_config",
    registry = "gcr.io",
    repository = "my-project/my-app",
    tag = "latest",
)

image_manifest(
    name = "my_app",
    base = "@distroless_cc",
    layers = [":app_layer"],
    push_specs = [":push_config"],
)

multi_deploy(
    name = "deploy",
    operations = [":my_app"],
)
```*Z
PushConfigInfoH
PushConfigInfo6@rules_img//img/private/providers:push_config_info.bzl2None�

load_specs�Load configurations to produce DeployInfo for this image.

Each entry should be an `image_load_spec` target (providing `LoadConfigInfo`).
When set (together with or without `push_specs`), this rule additionally returns
`DeployInfo`, making it directly usable as an operation in `multi_deploy`.

Example:
```python
image_load_spec(
    name = "load_config",
    tag = "my-app:latest",
)

image_manifest(
    name = "my_app",
    base = "@distroless_cc",
    layers = [":app_layer"],
    load_specs = [":load_config"],
)

multi_deploy(
    name = "deploy",
    operations = [":my_app"],
)
```*Z
LoadConfigInfoH
LoadConfigInfo6@rules_img//img/private/providers:load_config_info.bzl2None"B
image_from_binary-@rules_img//img/private:image_from_binary.bzl�
�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �
�

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@�
�
binary�The *_binary target to package into the image.

The binary's `args` and `env` attributes are extracted and applied as image configuration
(cmd and env). The `data` attribute is used for `$(location)` expansion in args and env values.

If the binary provides RunfilesGroupInfo, the runfiles are split into separate layers per group. �
�
path�Optional path of the binary inside the image.
If the path ends with a slash ("/"), the basename of the binary will be automatically appended.
If unset, this defaults to the rlocationpath of the binary (e.g., "_main/cmd/server/server_/server").2""�
~
layersnAdditional layers to include in the image.
The binary layer is automatically appended to the end of this list.2[]�
�
include_runfiles�Whether to include runfiles for the binary target.
When True (default), the binary's runfiles tree is included and the working directory
is set to the runfiles root. Set to False for statically linked binaries that don't
need runfiles.2True�
�
infer_working_dir�Whether to infer the image's working directory from the binary's runfiles tree.

When True (default) and `include_runfiles` is True, the working directory is set to the
main workspace directory inside the runfiles tree, which is where a binary launched
through the runfiles convention expects to run.

When False, the binary layer contributes no working directory, so the base image's
working directory is kept unless the `working_dir` attribute is set explicitly.2True�
�
layer_budget�Maximum number of runfiles group layers.
If set to a value > 0 and the binary provides RunfilesGroupInfo, groups are merged down to this
limit using the merge algorithm from rules_runfiles_group. The algorithm respects group rank
(only merges within the same rank), do_not_merge flags, merge affinity (groups sharing an
affinity are preferred merge partners), and weight hints (lighter groups merge first).
This is a target, not a hard cap: do_not_merge groups and groups alone in their rank cannot be
merged away, so a binary whose groups cannot be reduced far enough still produces more layers.
0 means no limit (all groups become separate layers).20�
�
kind�The kind of image to produce.

* "auto": Creates a single-platform manifest if zero or one platforms are provided, otherwise creates an index.
* "manifest": Always creates a single-platform manifest. Fails if multiple platforms are provided.
* "index": Always creates a multi-platform index.2"auto"8J"auto"J
"manifest"J"index"�
�
	platforms�Target platforms to build the image for.
If empty, the image is built for the current target platform.
If more than one platform is provided, an image_index is automatically created.2[]8

expect_failure2None@"
 
transitive_configs2None8@

deprecation2None8@

tags2None8@

testonly2None8@

features2None@

compatible_with2None8@

restricted_to2None8@ 

package_metadata2None8@

aspect_hints2None@R
P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@

exec_properties
2None@$
"
exec_compatible_with2None8@*
(
exec_group_compatible_with2None8@\
Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@h
f
baseVBase image to inherit layers from. Should provide ImageManifestInfo or ImageIndexInfo.2None�
�
omit_media_type�Leave the top-level `mediaType` field out of the manifest.

The OCI image spec says a manifest SHOULD set `mediaType`, so keep the default unless the
manifest has to be byte-identical to one written by a tool that omits the field. `helm push`
is one: a Helm chart manifest whose config, layers and annotations match Helm's gets the
digest Helm pushes only when this attribute is set.

Only the manifest bytes change. The manifest's descriptor, its entries in an `image_index` or
OCI layout, and the `Content-Type` sent to a registry keep
`application/vnd.oci.image.manifest.v1+json`.

Example:
```python
image_manifest(
    name = "chart",
    config_fragment = ":chart_config.json",
    config_media_type = "application/vnd.cncf.helm.config.v1+json",
    layers = [":chart_layer"],
    omit_media_type = True,
)
```2None�
�
omit_platform�Leave the platform out of this manifest's descriptor.

By default, the descriptor advertises the platform the manifest was built for, which is what
lets an `image_index` pick the right manifest per platform.

Set this for a manifest that describes an artifact rather than a container image -- an ORAS
artifact, a Helm chart, an SBOM. Such a manifest has no platform of its own, so the descriptor
would fall back to whatever platform the build happened to target (the host platform, unless
`platform` is set). In an index, that is both misleading -- a runtime may resolve the index to
the artifact instead of the image -- and non-reproducible, since the index digest then depends
on the machine that ran the build.

Only the descriptor is affected: the image config still records its os and architecture.

Example:
```python
image_manifest(
    name = "sbom",
    artifact_type = "application/spdx+json",
    config_media_type = "application/vnd.oci.empty.v1+json",
    layers = [":sbom_layer"],
    omit_platform = True,
)
```2None�
�
user�The username or UID which is a platform-specific structure that allows specific control over which user the process run as.
This acts as a default value to use when the value is not specified when creating a container.

Defaults to `INHERIT_FROM_BASE`: the value is inherited from the base image. Set it to
an explicit value to override, or to `""` to unset it (do not inherit from the base).2None�
�
env�Default environment variables to set when starting a container based on this image.

Subject to [template expansion](/docs/templating.md).
2None�
�
env_file�File containing environment variables to set when starting a container based on this image.

The file may be JSON or newline-delimited text, auto-detected from its contents:

- JSON object with string values: `{"KEY": "value"}`
- JSON object with list values: `{"KEY": ["value1", "value2"]}` (the last value wins)
- JSON array of `KEY=VALUE` strings: `["KEY=value"]`
- newline-delimited `KEY=VALUE` text (one per line; blank lines and `#` comments are ignored)

Values in JSON objects are used verbatim and may contain `=`, spaces, or newlines.
The `KEY=VALUE` forms split on the first `=` and trim surrounding whitespace.

Values from the `env` attribute (or expanded templates) take precedence over the file.2None�
�

entrypoint�A list of arguments to use as the command to execute when the container starts. These values act as defaults and may be replaced by an entrypoint specified when creating a container.

Defaults to `[INHERIT_FROM_BASE]`: the entrypoint is inherited from the base image (or,
for `image_from_binary`, from the packaged binary). Set it to an explicit list to override,
or to `[]` to unset it. An `INHERIT_FROM_BASE` item inside the list is replaced in place by
the base image's entrypoint, so `[INHERIT_FROM_BASE, "--flag"]` appends `"--flag"` to it.2None�
�
cmd�Default arguments to the entrypoint of the container. These values act as defaults and may be replaced by any specified when creating a container. If an Entrypoint value is not specified, then the first entry of the Cmd array SHOULD be interpreted as the executable to run.

Defaults to `[INHERIT_FROM_BASE]`: the value is inherited from the base image (or, for
`image_from_binary`, from the packaged binary's `args`). Set it to an explicit list to
override, or to `[]` to unset it. An `INHERIT_FROM_BASE` item inside the list is replaced in
place by the base image's cmd, so `[INHERIT_FROM_BASE, "--flag"]` appends `"--flag"` to it.2None�
�
working_dir�Sets the current working directory of the entrypoint process in the container. This value acts as a default and may be replaced by a working directory specified when creating a container.

Defaults to `INHERIT_FROM_BASE`: the value is inherited from the base image (or, for
`image_from_binary`, from the packaged binary). Set it to an explicit value to override, or
to `""` to unset it (do not inherit from the base).2None�
�
labelspThis field contains arbitrary metadata for the container.

Subject to [template expansion](/docs/templating.md).
2None�
�
label_files�Files containing labels for the image config, as JSON or newline-delimited text.

Each file is parsed in one of the following formats, auto-detected from its contents:

- JSON object with string values: `{"key": "value"}`
- JSON object with list values: `{"key": ["value1", "value2"]}` (the last value wins)
- JSON array of `KEY=VALUE` strings: `["key=value"]`
- newline-delimited `KEY=VALUE` text (one per line; blank lines and `#` comments are ignored)

Values in JSON objects are used verbatim, so they can encode arbitrary strings including
values that contain `=`, spaces, or newlines. The `KEY=VALUE` forms (JSON array and text)
split on the first `=` and trim surrounding whitespace from the key and value.

Labels from these files are merged together, and then merged with labels specified via
the `labels` attribute. Values from files take precedence over the `labels` attribute
for matching keys.

Example file content:
```
org.opencontainers.image.version=1.0.0
org.opencontainers.image.authors=team@example.com
```

Each label value is subject to [template expansion](/docs/templating.md).2None�
�
annotationsoThis field contains arbitrary metadata for the manifest.

Subject to [template expansion](/docs/templating.md).
2None�
�
annotations_file�File containing annotations for the manifest, as JSON or newline-delimited text.

The file is parsed in one of the following formats, auto-detected from its contents:

- JSON object with string values: `{"key": "value"}`
- JSON object with list values: `{"key": ["value1", "value2"]}` (the last value wins)
- JSON array of `KEY=VALUE` strings: `["key=value"]`
- newline-delimited `KEY=VALUE` text (one per line; blank lines and `#` comments are ignored)

Values in JSON objects are used verbatim, so they can encode arbitrary strings including
values that contain `=`, spaces, or newlines. The `KEY=VALUE` forms (JSON array and text)
split on the first `=` and trim surrounding whitespace from the key and value.

Annotations from this file are merged with annotations specified via the `annotations`
attribute. Values from the file take precedence over the `annotations` attribute for matching keys.

Example file content:
```
version=1.0.0
build.date=2024-01-15
source.url=https://github.com/...
```

Each annotation is subject to [template expansion](/docs/templating.md).2None�
�
stop_signal�This field contains the system call signal that will be sent to the container to exit. The signal can be a signal name in the format SIGNAME, for instance SIGKILL or SIGRTMIN+3.

Defaults to `INHERIT_FROM_BASE`: the value is inherited from the base image. Set it to an
explicit value to override, or to `""` to unset it (do not inherit from the base).2None�
�
config_fragment�Optional JSON file containing a partial OCI image config, which will be used as a base for the final image config.

For OCI image configuration fields such as exposed ports or volumes, the JSON should use the top-level `config` object:

```json
{
  "config": {
    "ExposedPorts": {
      "8080/tcp": {}
    }
  }
}
```

When config_media_type is set to a non-OCI type (e.g. Helm), this file is used as the entire config blob as-is.2None�
�
config_media_type�Override the config blob media type.

When set to "application/vnd.oci.empty.v1+json", config_fragment is optional. If omitted, an empty
JSON config descriptor is produced automatically with the content inlined as data (`"data": "e30="`).

For other non-OCI types (e.g. "application/vnd.cncf.helm.config.v1+json" for Helm charts),
config_fragment is required and used verbatim as the config blob (no OCI image structure).2None�
�
artifact_type�Optional IANA media type of the artifact when the manifest is used for an artifact.

This sets the `artifactType` field in the OCI manifest, as defined in the
[OCI Image Spec](https://github.com/opencontainers/image-spec/blob/main/manifest.md#image-manifest-property-descriptions).

Common values include `application/vnd.cncf.helm.chart.v1` for Helm charts
or `application/spdx+json` for SPDX SBOMs.2None�
�
subject�Optional subject for the manifest.

Sets the `subject` field in the OCI manifest, which is a descriptor pointing to
another manifest or index. This is used for establishing referrer relationships,
such as attaching SBOMs, signatures, or attestations to an existing image.

The target must provide either ImageManifestInfo or ImageIndexInfo.*]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl*T
ImageIndexInfoB
ImageIndexInfo0@rules_img//img/private/providers:index_info.bzl2None�
�
created�Optional file containing a datetime string (RFC 3339 format) for when the image was created.

This is commonly used with Bazel's stamping mechanism to embed the build timestamp.

Mutually exclusive with `created_timestamp`. Takes precedence over `stamp_created`.2None�
�
created_timestamp�Optional datetime string (RFC 3339 format) for when the image was created.

Subject to [template expansion](/docs/templating.md), so the timestamp can come from
a stamp value. `{{.BUILD_TIMESTAMP_RFC3339}}` is Bazel's build time, converted from
the volatile `BUILD_TIMESTAMP` workspace status value:

```python
image_manifest(
    name = "my_app",
    created_timestamp = "{{.BUILD_TIMESTAMP_RFC3339}}",  # same as stamp_created = "enabled"
    layers = [":app_layer"],
)
```

If the expanded value is empty -- which is what happens when stamping is inactive --
the `created` field is left unset, keeping the image reproducible.

Mutually exclusive with `created`.2None�
�
stamp_created�Whether to stamp the image config's `created` timestamp with Bazel's build time.

Shorthand for `created_timestamp = "{{.BUILD_TIMESTAMP_RFC3339}}"`.

- **`auto`** (default): defers to the global `--@rules_img//img/settings:stamp_created`
  setting, which itself defaults to `disabled`.
- **`enabled`**: set the config's `created` field to the build time. Since `BUILD_TIMESTAMP`
  is a volatile workspace status value, this is best-effort: it makes the image
  non-reproducible, and the timestamp only refreshes when the image is rebuilt for
  other reasons (see [templating](/docs/templating.md)). Requires stamping to be
  active (Bazel's `--stamp`, or `stamp = "force"`); without it the field stays unset.
- **`disabled`**: never stamp the `created` field.

Ignored when `created` or `created_timestamp` is set.2NoneJ"auto"J	"enabled"J
"disabled"�
�
build_settings�Build settings for template expansion.

Maps template variable names to string_flag targets. These values can be used in
env, labels, and annotations attributes using `{{.VARIABLE_NAME}}` syntax (Go template).

Example:
```python
build_settings = {
    "REGISTRY": "//settings:docker_registry",
    "VERSION": "//settings:app_version",
}
```

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2None�
�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2NoneJ"auto"J"force"J
"disabled"�
�
soci�Whether to build a SOCI Index Manifest v2 for this image.

- **`auto`** (default): defers to the global `--@rules_img//img/settings:soci` setting.
- **`enabled`**: build a SOCI index. Each gzip layer's ztoc is reused from the layer
  (when the layer emitted one) or generated on the fly; the image manifest gains a
  `com.amazon.soci.index-digest` annotation (which changes its digest). For lazy
  pulling with soci-snapshotter to work end-to-end, wrap the image in an `image_index`
  (which emits the OCI-index cross-reference entry). See [SOCI](/docs/soci.md).
- **`disabled`**: never build a SOCI index.2NoneJ"auto"J	"enabled"J
"disabled"�
�
soci_span_sizetSpan size (uncompressed bytes between ztoc checkpoints). -1 (default) uses the global //img/settings:soci_span_size.2None�
�
soci_min_layer_size�Layers smaller than this many bytes are omitted from the SOCI index. -1 (default) uses the global //img/settings:soci_min_layer_size.2None�
�

push_specs�Push configurations to produce DeployInfo for this image.

Each entry should be an `image_push_spec` target (providing `PushConfigInfo`).
When set (together with or without `load_specs`), this rule additionally returns
`DeployInfo`, making it directly usable as an operation in `multi_deploy`.

Example:
```python
image_push_spec(
    name = "push_config",
    registry = "gcr.io",
    repository = "my-project/my-app",
    tag = "latest",
)

image_manifest(
    name = "my_app",
    base = "@distroless_cc",
    layers = [":app_layer"],
    push_specs = [":push_config"],
)

multi_deploy(
    name = "deploy",
    operations = [":my_app"],
)
```*Z
PushConfigInfoH
PushConfigInfo6@rules_img//img/private/providers:push_config_info.bzl2None�
�

load_specs�Load configurations to produce DeployInfo for this image.

Each entry should be an `image_load_spec` target (providing `LoadConfigInfo`).
When set (together with or without `push_specs`), this rule additionally returns
`DeployInfo`, making it directly usable as an operation in `multi_deploy`.

Example:
```python
image_load_spec(
    name = "load_config",
    tag = "my-app:latest",
)

image_manifest(
    name = "my_app",
    base = "@distroless_cc",
    layers = [":app_layer"],
    load_specs = [":load_config"],
)

multi_deploy(
    name = "deploy",
    operations = [":my_app"],
)
```*Z
LoadConfigInfoH
LoadConfigInfo6@rules_img//img/private/providers:load_config_info.bzl2None�Rules to build container images from layers.

Use `image_from_binary` to package any `*_binary` target into a container image,
`image_manifest` to create a single-platform container image from layers,
and `image_index` to compose a multi-platform container image index.

`INHERIT_FROM_BASE` is a sentinel that can be used as (or inside) the `user`,
`working_dir`, `stop_signal`, `entrypoint`, and `cmd` attributes of
`image_manifest` / `image_from_binary` to explicitly inherit that config field
from the base image.��

	rules_imgimg	layer.bzl��image_layer�
Creates a container image layer from files, executables, and directories.

This rule packages files into a layer that can be used in container images. It supports:
- Adding files at specific paths in the image
- Setting file permissions and ownership
- Creating symlinks
- Including executables with their runfiles and any additional default outputs
- Compression (gzip, zstd) and eStargz optimization

Example:

```python
load("@rules_img//img:layer.bzl", "image_layer", "file_metadata")

# Simple layer with files
image_layer(
    name = "app_layer",
    srcs = {
        "/app/bin/server": "//cmd/server",
        "/app/config.json": ":config.json",
    },
)

# Layer with custom permissions
image_layer(
    name = "secure_layer",
    srcs = {
        "/etc/app/config": ":config",
        "/etc/app/secret": ":secret",
    },
    default_metadata = file_metadata(
        mode = "0644",
        uid = 1000,
        gid = 1000,
    ),
    file_metadata = {
        "/etc/app/secret": file_metadata(mode = "0600"),
    },
)

# Layer with symlinks
image_layer(
    name = "bin_layer",
    srcs = {
        "/usr/local/bin/app": "//cmd/app",
    },
    symlinks = {
        "/usr/bin/app": "/usr/local/bin/app",
    },
)
```

### Output groups

- `mtree`: a single [mtree](https://man.freebsd.org/cgi/man.cgi?mtree(5)) text file"ȧ
�Y
image_layer�
Creates a container image layer from files, executables, and directories.

This rule packages files into a layer that can be used in container images. It supports:
- Adding files at specific paths in the image
- Setting file permissions and ownership
- Creating symlinks
- Including executables with their runfiles and any additional default outputs
- Compression (gzip, zstd) and eStargz optimization

Example:

```python
load("@rules_img//img:layer.bzl", "image_layer", "file_metadata")

# Simple layer with files
image_layer(
    name = "app_layer",
    srcs = {
        "/app/bin/server": "//cmd/server",
        "/app/config.json": ":config.json",
    },
)

# Layer with custom permissions
image_layer(
    name = "secure_layer",
    srcs = {
        "/etc/app/config": ":config",
        "/etc/app/secret": ":secret",
    },
    default_metadata = file_metadata(
        mode = "0644",
        uid = 1000,
        gid = 1000,
    ),
    file_metadata = {
        "/etc/app/secret": file_metadata(mode = "0600"),
    },
)

# Layer with symlinks
image_layer(
    name = "bin_layer",
    srcs = {
        "/usr/local/bin/app": "//cmd/app",
    },
    symlinks = {
        "/usr/bin/app": "/usr/local/bin/app",
    },
)
```

### Output groups

- `mtree`: a single [mtree](https://man.freebsd.org/cgi/man.cgi?mtree(5)) text file*
nameA unique name for this target. �
srcs�Files to include in the layer. Keys are paths in the image (e.g., "/app/bin/server"),
values are labels to files or executables.

When a value is an executable, the executable is placed at the path key and its runfiles tree is
included (unless include_runfiles is set to False). Any additional default outputs of the target
(the rest of `DefaultInfo.files` beyond the executable) are also copied, each placed at the same
location relative to the executable that it has in the source tree. Outputs that live above the
executable need a path key deep enough to hold them; `extra_default_outputs` decides what happens
to the ones that don't fit (by default they are dropped).

When a value is a non-executable target that produces more than one default output, the path key is
treated as a directory and the outputs are placed inside it according to `multi_file_layout`. A path
key that ends with "/" is always treated as a directory, even when the target produces exactly one
output.2{}}
symlinkskSymlinks to create in the layer. Keys are symlink paths in the image,
values are the targets they point to.
2{}�
multi_file_layout�How to place a non-executable src that produces MORE THAN ONE default output.

- `"package_relative"` (default): treat the path key as a directory and place each file inside it,
  preserving its path relative to the producing target's package.
- `"flatten"`: place each file directly in the directory by basename (restores the older behavior).

A src that produces a single output is placed exactly at its path key, regardless of this
setting. To opt out of that shortcut, end the path key with "/": it then always denotes a
directory, and a single output is laid out inside it just like multiple outputs would be.2"package_relative"J"package_relative"J	"flatten"�
default_metadata�JSON-encoded default metadata to apply to all files in the layer.
Can include fields like mode, uid, gid, uname, gname, mtime, and pax_records.
Applies to regular files (including tree contents) and symlinks. Generated
directories inherit only mtime; use file_metadata for directory modes or ownership.2""�
file_metadata�Per-file metadata overrides as a dict mapping file paths to JSON-encoded metadata.
The path should match the path in the image, including paths inside directory inputs.
Directory paths should omit the trailing slash.
Metadata specified here overrides any defaults from default_metadata.
2{}�
history�Overrides the `created_by` history entry recorded for this layer.

By default the layer records one entry, "bazel build <label>", so two layers
with identical contents but different labels have different config digests.
`history = []` records no history entry, so identical contents give identical
config digests regardless of label. A single-element list is recorded verbatim.
The img tool records at most one history entry per layer, so longer lists are
rejected.2!["<default bazel build history>"]�
compress�Compression algorithm to use. If set to 'auto', uses the global default compression setting.

'none' leaves the layer uncompressed, which is the useful choice for an EROFS layer
(the blob is then mountable as it is). EROFS layers cannot be gzip-compressed.

A `cpio` layer (an initramfs) is also left uncompressed by default. It can be compressed with
`gzip` or `zstd`, which the kernel unpacks as it is. The `ext4`, `fat32` and `iso9660` formats ignore this attribute.2"auto"J"auto"J"gzip"J"zstd"J"none"�
format�Container format of the layer blob, orthogonal to `compress`.

'tar' writes an OCI tar changeset. 'erofs' writes a mountable EROFS filesystem image. 'ext4' and 'fat32' write an
ext4 or FAT32 filesystem image, 'iso9660' an ISO 9660 image (with the Rock Ridge, Joliet and UDF extensions and
El Torito boot entries as options), 'cpio' a cpio archive in the newc format (an initramfs). If set to 'auto', uses the global default
--@rules_img//img/settings:layer_format setting.

An EROFS layer is a filesystem, not a changeset. See docs/erofs-layers.md before using it.

See docs/filesystems.md for how the formats compare.2"auto"J"auto"J"tar"J"erofs"J"ext4"J"fat32"J	"iso9660"J"cpio"�
format_config�Options of the filesystem image the layer is written as: an `ext4_config` target
for `format = "ext4"`, a `fat32_config` target for `format = "fat32"`, an `iso9660_config` target for `format = "iso9660"`,
a `cpio_config` target for `format = "cpio"`, or an `erofs_config`
target for `format = "erofs"`.

Without it, every option of the format is left at its default. A config for a
format other than the layer's own is a configuration error, since it would
silently have no effect.*\
Ext4ConfigInfoJ
Ext4ConfigInfo8@rules_img//img/private/providers:format_config_info.bzl*^
Fat32ConfigInfoK
Fat32ConfigInfo8@rules_img//img/private/providers:format_config_info.bzl*b
Iso9660ConfigInfoM
Iso9660ConfigInfo8@rules_img//img/private/providers:format_config_info.bzl*\
CpioConfigInfoJ
CpioConfigInfo8@rules_img//img/private/providers:format_config_info.bzl*^
ErofsConfigInfoK
ErofsConfigInfo8@rules_img//img/private/providers:format_config_info.bzl2None�
estargz�Whether to use estargz format. If set to 'auto', uses the global default estargz setting.
When enabled, the layer will be optimized for lazy pulling and will be compatible with the estargz format.2"auto"J"auto"J	"enabled"J
"disabled"�
zstd_chunked�Whether to use the zstd:chunked format. If set to 'auto', uses the global default zstd_chunked setting.
When enabled, the layer is written with content-defined chunks and a table of contents, so
compatible runtimes (podman, CRI-O) can fetch and deduplicate individual chunks.
Requires zstd compression and cannot be combined with estargz.2"auto"J"auto"J	"enabled"J
"disabled"�
soci�Whether to emit a SOCI ztoc (table of contents) for this layer. If set to 'auto',
uses the global default //img/settings:soci setting. When enabled and the layer is
gzip-compressed, a ztoc is produced in the layer action and recorded on the
SingleLayerInfo provider, so images that build a SOCI Index Manifest v2 can reuse
it instead of regenerating it. Non-gzip layers never emit a ztoc.2"auto"J"auto"J	"enabled"J
"disabled"�
create_parent_directories�Whether to automatically create parent directory entries in the tar file for all files.
If set to 'auto', uses the global default create_parent_directories setting.
When enabled, parent directories will be created automatically for all files in the layer.2"auto"J"auto"J	"enabled"J
"disabled"�
tree_artifact_handling�How to handle duplicate tree artifacts (directories) in the layer.
If set to 'full', each tree artifact is stored at its intended path (no deduplication).
If set to 'deduplicate_symlink', duplicate tree artifacts are replaced with symlinks to the first occurrence.
If set to 'auto', uses the global default from --@rules_img//img/settings:layer_tree_artifact_handling.
When file metadata is configured, trees are stored in full so path-specific metadata
is preserved. Regular files with identical contents and metadata still deduplicate.2"auto"J"auto"J"full"J"deduplicate_symlink"�
include_runfiles�Whether to include runfiles for executable targets.
When True (default), executables in srcs will include their runfiles tree.
When False, only the executable file itself is included, without runfiles.

Either way, any additional default outputs of the target (the rest of `DefaultInfo.files`
beyond the executable) are copied into the layer, placed relative to the executable,
as configured by `extra_default_outputs`.2True�
extra_default_outputs�How to handle an executable's additional default outputs (the rest of `DefaultInfo.files`
beyond the executable itself).

Those files are placed at the same offset relative to the executable that they have in the
source tree, so a file that lives above the executable's directory needs a path in the image
that is deep enough to place it. This setting decides what happens when it isn't:

- `"best_effort"` (default): place every additional default output that fits, and silently
  drop the ones that would land above the image root. This is what wrapper rules such as
  bazel-lib's `transition_binary` need, where the executable is a symlink in a sibling
  directory of the real outputs.
- `"drop"`: never place additional default outputs. Only the executable itself (and its
  runfiles, if `include_runfiles` is True) is included.
- `"strict"`: place every additional default output, and fail the build if any of them
  would land above the image root.2"best_effort"J"best_effort"J"drop"J"strict"Q
annotations<Annotations to add to the layer metadata as key-value pairs.
2{}�
annotations_file�File containing annotations for the layer, as JSON or newline-delimited text.

The file is parsed in one of the following formats, auto-detected from its contents:

- JSON object with string values: `{"key": "value"}`
- JSON object with list values: `{"key": ["value1", "value2"]}` (the last value wins)
- JSON array of `KEY=VALUE` strings: `["key=value"]`
- newline-delimited `KEY=VALUE` text (one per line; blank lines and `#` comments are ignored)

Values in JSON objects are used verbatim, so they can encode arbitrary strings including
values that contain `=`, spaces, or newlines. The `KEY=VALUE` forms (JSON array and text)
split on the first `=` and trim surrounding whitespace from the key and value.

Annotations from this file are merged with annotations specified via the `annotations`
attribute, which take precedence for matching keys.

Example file content:
```
version=1.0.0
build.date=2024-01-15
source.url=https://github.com/...
```2None~

media_typejOverride the layer media type. By default, the media type is auto-detected from the compression algorithm.2"""0
image_layer!@rules_img//img/private:layer.bzl*M

LayersInfo?

LayersInfo1@rules_img//img/private/providers:layers_info.bzl,
*
nameA unique name for this target. �
�
srcs�Files to include in the layer. Keys are paths in the image (e.g., "/app/bin/server"),
values are labels to files or executables.

When a value is an executable, the executable is placed at the path key and its runfiles tree is
included (unless include_runfiles is set to False). Any additional default outputs of the target
(the rest of `DefaultInfo.files` beyond the executable) are also copied, each placed at the same
location relative to the executable that it has in the source tree. Outputs that live above the
executable need a path key deep enough to hold them; `extra_default_outputs` decides what happens
to the ones that don't fit (by default they are dropped).

When a value is a non-executable target that produces more than one default output, the path key is
treated as a directory and the outputs are placed inside it according to `multi_file_layout`. A path
key that ends with "/" is always treated as a directory, even when the target produces exactly one
output.2{}
}
symlinkskSymlinks to create in the layer. Keys are symlink paths in the image,
values are the targets they point to.
2{}�
�
multi_file_layout�How to place a non-executable src that produces MORE THAN ONE default output.

- `"package_relative"` (default): treat the path key as a directory and place each file inside it,
  preserving its path relative to the producing target's package.
- `"flatten"`: place each file directly in the directory by basename (restores the older behavior).

A src that produces a single output is placed exactly at its path key, regardless of this
setting. To opt out of that shortcut, end the path key with "/": it then always denotes a
directory, and a single output is laid out inside it just like multiple outputs would be.2"package_relative"J"package_relative"J	"flatten"�
�
default_metadata�JSON-encoded default metadata to apply to all files in the layer.
Can include fields like mode, uid, gid, uname, gname, mtime, and pax_records.
Applies to regular files (including tree contents) and symlinks. Generated
directories inherit only mtime; use file_metadata for directory modes or ownership.2""�
�
file_metadata�Per-file metadata overrides as a dict mapping file paths to JSON-encoded metadata.
The path should match the path in the image, including paths inside directory inputs.
Directory paths should omit the trailing slash.
Metadata specified here overrides any defaults from default_metadata.
2{}�
�
history�Overrides the `created_by` history entry recorded for this layer.

By default the layer records one entry, "bazel build <label>", so two layers
with identical contents but different labels have different config digests.
`history = []` records no history entry, so identical contents give identical
config digests regardless of label. A single-element list is recorded verbatim.
The img tool records at most one history entry per layer, so longer lists are
rejected.2!["<default bazel build history>"]�
�
compress�Compression algorithm to use. If set to 'auto', uses the global default compression setting.

'none' leaves the layer uncompressed, which is the useful choice for an EROFS layer
(the blob is then mountable as it is). EROFS layers cannot be gzip-compressed.

A `cpio` layer (an initramfs) is also left uncompressed by default. It can be compressed with
`gzip` or `zstd`, which the kernel unpacks as it is. The `ext4`, `fat32` and `iso9660` formats ignore this attribute.2"auto"J"auto"J"gzip"J"zstd"J"none"�
�
format�Container format of the layer blob, orthogonal to `compress`.

'tar' writes an OCI tar changeset. 'erofs' writes a mountable EROFS filesystem image. 'ext4' and 'fat32' write an
ext4 or FAT32 filesystem image, 'iso9660' an ISO 9660 image (with the Rock Ridge, Joliet and UDF extensions and
El Torito boot entries as options), 'cpio' a cpio archive in the newc format (an initramfs). If set to 'auto', uses the global default
--@rules_img//img/settings:layer_format setting.

An EROFS layer is a filesystem, not a changeset. See docs/erofs-layers.md before using it.

See docs/filesystems.md for how the formats compare.2"auto"J"auto"J"tar"J"erofs"J"ext4"J"fat32"J	"iso9660"J"cpio"�
�
format_config�Options of the filesystem image the layer is written as: an `ext4_config` target
for `format = "ext4"`, a `fat32_config` target for `format = "fat32"`, an `iso9660_config` target for `format = "iso9660"`,
a `cpio_config` target for `format = "cpio"`, or an `erofs_config`
target for `format = "erofs"`.

Without it, every option of the format is left at its default. A config for a
format other than the layer's own is a configuration error, since it would
silently have no effect.*\
Ext4ConfigInfoJ
Ext4ConfigInfo8@rules_img//img/private/providers:format_config_info.bzl*^
Fat32ConfigInfoK
Fat32ConfigInfo8@rules_img//img/private/providers:format_config_info.bzl*b
Iso9660ConfigInfoM
Iso9660ConfigInfo8@rules_img//img/private/providers:format_config_info.bzl*\
CpioConfigInfoJ
CpioConfigInfo8@rules_img//img/private/providers:format_config_info.bzl*^
ErofsConfigInfoK
ErofsConfigInfo8@rules_img//img/private/providers:format_config_info.bzl2None�
�
estargz�Whether to use estargz format. If set to 'auto', uses the global default estargz setting.
When enabled, the layer will be optimized for lazy pulling and will be compatible with the estargz format.2"auto"J"auto"J	"enabled"J
"disabled"�
�
zstd_chunked�Whether to use the zstd:chunked format. If set to 'auto', uses the global default zstd_chunked setting.
When enabled, the layer is written with content-defined chunks and a table of contents, so
compatible runtimes (podman, CRI-O) can fetch and deduplicate individual chunks.
Requires zstd compression and cannot be combined with estargz.2"auto"J"auto"J	"enabled"J
"disabled"�
�
soci�Whether to emit a SOCI ztoc (table of contents) for this layer. If set to 'auto',
uses the global default //img/settings:soci setting. When enabled and the layer is
gzip-compressed, a ztoc is produced in the layer action and recorded on the
SingleLayerInfo provider, so images that build a SOCI Index Manifest v2 can reuse
it instead of regenerating it. Non-gzip layers never emit a ztoc.2"auto"J"auto"J	"enabled"J
"disabled"�
�
create_parent_directories�Whether to automatically create parent directory entries in the tar file for all files.
If set to 'auto', uses the global default create_parent_directories setting.
When enabled, parent directories will be created automatically for all files in the layer.2"auto"J"auto"J	"enabled"J
"disabled"�
�
tree_artifact_handling�How to handle duplicate tree artifacts (directories) in the layer.
If set to 'full', each tree artifact is stored at its intended path (no deduplication).
If set to 'deduplicate_symlink', duplicate tree artifacts are replaced with symlinks to the first occurrence.
If set to 'auto', uses the global default from --@rules_img//img/settings:layer_tree_artifact_handling.
When file metadata is configured, trees are stored in full so path-specific metadata
is preserved. Regular files with identical contents and metadata still deduplicate.2"auto"J"auto"J"full"J"deduplicate_symlink"�
�
include_runfiles�Whether to include runfiles for executable targets.
When True (default), executables in srcs will include their runfiles tree.
When False, only the executable file itself is included, without runfiles.

Either way, any additional default outputs of the target (the rest of `DefaultInfo.files`
beyond the executable) are copied into the layer, placed relative to the executable,
as configured by `extra_default_outputs`.2True�
�
extra_default_outputs�How to handle an executable's additional default outputs (the rest of `DefaultInfo.files`
beyond the executable itself).

Those files are placed at the same offset relative to the executable that they have in the
source tree, so a file that lives above the executable's directory needs a path in the image
that is deep enough to place it. This setting decides what happens when it isn't:

- `"best_effort"` (default): place every additional default output that fits, and silently
  drop the ones that would land above the image root. This is what wrapper rules such as
  bazel-lib's `transition_binary` need, where the executable is a symlink in a sibling
  directory of the real outputs.
- `"drop"`: never place additional default outputs. Only the executable itself (and its
  runfiles, if `include_runfiles` is True) is included.
- `"strict"`: place every additional default output, and fail the build if any of them
  would land above the image root.2"best_effort"J"best_effort"J"drop"J"strict"S
Q
annotations<Annotations to add to the layer metadata as key-value pairs.
2{}�
�
annotations_file�File containing annotations for the layer, as JSON or newline-delimited text.

The file is parsed in one of the following formats, auto-detected from its contents:

- JSON object with string values: `{"key": "value"}`
- JSON object with list values: `{"key": ["value1", "value2"]}` (the last value wins)
- JSON array of `KEY=VALUE` strings: `["key=value"]`
- newline-delimited `KEY=VALUE` text (one per line; blank lines and `#` comments are ignored)

Values in JSON objects are used verbatim, so they can encode arbitrary strings including
values that contain `=`, spaces, or newlines. The `KEY=VALUE` forms (JSON array and text)
split on the first `=` and trim surrounding whitespace from the key and value.

Annotations from this file are merged with annotations specified via the `annotations`
attribute, which take precedence for matching keys.

Example file content:
```
version=1.0.0
build.date=2024-01-15
source.url=https://github.com/...
```2None�
~

media_typejOverride the layer media type. By default, the media type is auto-detected from the compression algorithm.2""��layer_from_binary�Creates a container image layer from a *_binary target.

This rule packages a binary executable and its runfiles into a layer, and additionally
provides image configuration (entrypoint, cmd, env, working_dir) via ImageLayerConfigInfo.
When used as a layer in image_manifest, the configuration is automatically applied to the
image with Dockerfile-like semantics.

The binary's `args` attribute becomes the image `cmd`, its `env` attribute (or
RunEnvironmentInfo provider) becomes `env`, and the binary path becomes the `entrypoint`.
When include_runfiles is True (default), the working directory is set to the runfiles root.
Set `infer_working_dir = False` to leave the working directory unset, so the base image's
working directory (or image_manifest's own `working_dir` attribute) applies instead.

In addition to the executable and its runfiles, any other default outputs of the binary
target (the rest of `DefaultInfo.files`) are copied into the layer, each placed at the same
location relative to the executable that it has in the source tree.

If the binary provides RunfilesGroupInfo (from rules_runfiles_group), the runfiles are split
into separate layers based on the groups. This allows for better caching: stable layers
(interpreter, stdlib) change infrequently and can be shared, while the application code layer
changes with each build. Layers are emitted in the groups' `rank` order (lowest first), so
foundational content ends up in the earliest, most cacheable layers. Any
RunfilesGroupTransformInfo in the binary's `aspect_hints` is applied first, which lets users
drop or re-shape groups per target.

Note that RunfilesGroupInfo emission is off by default in rules_runfiles_group. Build with
`--@rules_runfiles_group//runfiles_group:enabled=true` to opt in; without it, group-aware
binaries produce a single layer.

When the number of groups exceeds what is practical for a container image, use `layer_budget`
to merge groups down to a maximum count. The merge algorithm respects group rank (only merges
within the same rank), do_not_merge flags, merge affinity (groups sharing an affinity are
preferred merge partners), and weight hints (lighter groups merge first).

Example:

```python
load("@rules_img//img:layer.bzl", "layer_from_binary")
load("@rules_img//img:image.bzl", "image_manifest")

# Package a Go binary with its runfiles
layer_from_binary(
    name = "app_layer",
    binary = "//cmd/server",
)

# Use in an image - entrypoint, cmd, env, and working_dir are set automatically
image_manifest(
    name = "image",
    base = "@distroless_base",
    layers = [":app_layer"],
)

# Override the path inside the image
layer_from_binary(
    name = "custom_path_layer",
    binary = "//cmd/server",
    path = "/usr/local/bin/",
)

# Without runfiles (static binary)
layer_from_binary(
    name = "static_layer",
    binary = "//cmd/server",
    path = "/usr/local/bin/server",
    include_runfiles = False,
)
```

### Output groups

- `mtree`: one [mtree](https://man.freebsd.org/cgi/man.cgi?mtree(5)) text file per produced layer"��
�o
layer_from_binary�Creates a container image layer from a *_binary target.

This rule packages a binary executable and its runfiles into a layer, and additionally
provides image configuration (entrypoint, cmd, env, working_dir) via ImageLayerConfigInfo.
When used as a layer in image_manifest, the configuration is automatically applied to the
image with Dockerfile-like semantics.

The binary's `args` attribute becomes the image `cmd`, its `env` attribute (or
RunEnvironmentInfo provider) becomes `env`, and the binary path becomes the `entrypoint`.
When include_runfiles is True (default), the working directory is set to the runfiles root.
Set `infer_working_dir = False` to leave the working directory unset, so the base image's
working directory (or image_manifest's own `working_dir` attribute) applies instead.

In addition to the executable and its runfiles, any other default outputs of the binary
target (the rest of `DefaultInfo.files`) are copied into the layer, each placed at the same
location relative to the executable that it has in the source tree.

If the binary provides RunfilesGroupInfo (from rules_runfiles_group), the runfiles are split
into separate layers based on the groups. This allows for better caching: stable layers
(interpreter, stdlib) change infrequently and can be shared, while the application code layer
changes with each build. Layers are emitted in the groups' `rank` order (lowest first), so
foundational content ends up in the earliest, most cacheable layers. Any
RunfilesGroupTransformInfo in the binary's `aspect_hints` is applied first, which lets users
drop or re-shape groups per target.

Note that RunfilesGroupInfo emission is off by default in rules_runfiles_group. Build with
`--@rules_runfiles_group//runfiles_group:enabled=true` to opt in; without it, group-aware
binaries produce a single layer.

When the number of groups exceeds what is practical for a container image, use `layer_budget`
to merge groups down to a maximum count. The merge algorithm respects group rank (only merges
within the same rank), do_not_merge flags, merge affinity (groups sharing an affinity are
preferred merge partners), and weight hints (lighter groups merge first).

Example:

```python
load("@rules_img//img:layer.bzl", "layer_from_binary")
load("@rules_img//img:image.bzl", "image_manifest")

# Package a Go binary with its runfiles
layer_from_binary(
    name = "app_layer",
    binary = "//cmd/server",
)

# Use in an image - entrypoint, cmd, env, and working_dir are set automatically
image_manifest(
    name = "image",
    base = "@distroless_base",
    layers = [":app_layer"],
)

# Override the path inside the image
layer_from_binary(
    name = "custom_path_layer",
    binary = "//cmd/server",
    path = "/usr/local/bin/",
)

# Without runfiles (static binary)
layer_from_binary(
    name = "static_layer",
    binary = "//cmd/server",
    path = "/usr/local/bin/server",
    include_runfiles = False,
)
```

### Output groups

- `mtree`: one [mtree](https://man.freebsd.org/cgi/man.cgi?mtree(5)) text file per produced layer*
nameA unique name for this target. �
binary�The *_binary target to package into the layer.

The binary's `args` and `env` attributes are extracted and provided as image configuration
(cmd and env) via ImageLayerConfigInfo. The `data` attribute is used for `$(location)` expansion
in args and env values.

If the binary provides RunfilesGroupInfo, the runfiles are split into separate layers per group. �
path�Optional path of the binary inside the image.
If the path ends with a slash ("/"), the basename of the binary will be automatically appended.
If unset, this defaults to the rlocationpath of the binary (e.g., "_main/cmd/server/server_/server").2""�
runfiles_path�Optional path of the runfiles directory of the binary inside the image.
If unset, this defaults to the path of the binary with a .runfiles suffix (e.g., "_main/cmd/server/server_/server.runfiles").
Note: depending on the runfiles_sharing_mode, this may be a symlink to a shared runfiles directory.2""�
runfiles_shared_path�Optional path of the shared runfiles directory inside the image.
This is only used when runfiles sharing is enabled and has a global default.2""�
runfiles_sharing_mode�How to process runfiles.
Runfiles can either be placed next to the executable (in a directory with a .runfiles suffix, the runfiles_path attribute),
or placed in a shared runfiles path. When sharing runfiles, there will be symlink added: {runfiles_path} -> {runfiles_shared_path}.

Possible settings:

* `"auto"`: Share runfiles based on the global default and based on the presence of `RunfilesGroupInfo`.
    Globally, runfiles sharing can be set to `"shared"`, `"private"`, or `"auto"`, where auto shares runfiles if `RunfilesGroupInfo` is provided.
* `"shared"`: Always share runfiles.
* `"private"`: Never share runfiles2"auto"J"auto"J"shared"J	"private"�
default_metadata�JSON-encoded default metadata to apply to all files in the layers.
Can include fields like mode, uid, gid, uname, gname, mtime, and pax_records.
Applies to regular files (including tree contents) and symlinks. Generated
directories inherit only mtime, retaining their default mode and ownership.

Accepts the same value as image_layer's attribute of the same name, so
img/layer.bzl's file_metadata() builds it.2""�
infer_working_dir�Whether to infer the image's working directory from the binary's runfiles tree.

When True (default) and `include_runfiles` is True, `ImageLayerConfigInfo.working_dir`
is set to the main workspace directory inside the runfiles tree
(e.g. "/_main/cmd/server/server_/server.runfiles/_main"), which is the directory a
binary launched through the runfiles convention expects to run in.

When False, `ImageLayerConfigInfo.working_dir` is None, which carries no opinion:
`image_manifest` then keeps the base image's working directory, unless its own
`working_dir` attribute is set explicitly.2True�	
layer_budget�	Maximum total number of layers produced by this rule.
If set to a value > 0 and the binary provides RunfilesGroupInfo, groups are merged
using the merge algorithm from rules_runfiles_group. The algorithm respects
group rank (only merges within the same rank), do_not_merge flags, merge affinity
(groups sharing an affinity are preferred merge partners), and weight hints
(lighter groups merge first).

When the binary names an executable_group, the binary executable and supporting files
are merged into that group's layer, and the full budget is available for runfiles
groups. When no executable_group exists, one layer is reserved for a separate binary
layer, and the remaining budget (layer_budget - 1) is used for groups;
layer_budget=1 without an executable_group skips the grouped path entirely.

This is a target, not a hard cap: groups marked do_not_merge are never merged, and
groups at different ranks never merge with each other, so a binary whose groups cannot
be reduced far enough still produces more layers than the budget.

0 means no limit (all groups become separate layers, plus a binary layer unless
an executable_group absorbs it).20�
compress�Compression algorithm to use. If set to 'auto', uses the global default compression setting.

'none' leaves the layer uncompressed, which is the useful choice for an EROFS layer
(the blob is then mountable as it is). EROFS layers cannot be gzip-compressed.

A `cpio` layer (an initramfs) is also left uncompressed by default. It can be compressed with
`gzip` or `zstd`, which the kernel unpacks as it is. The `ext4`, `fat32` and `iso9660` formats ignore this attribute.2"auto"J"auto"J"gzip"J"zstd"J"none"�
format�Container format of the layer blob, orthogonal to `compress`.

'tar' writes an OCI tar changeset. 'erofs' writes a mountable EROFS filesystem image. 'ext4' and 'fat32' write an
ext4 or FAT32 filesystem image, 'iso9660' an ISO 9660 image (with the Rock Ridge, Joliet and UDF extensions and
El Torito boot entries as options), 'cpio' a cpio archive in the newc format (an initramfs). If set to 'auto', uses the global default
--@rules_img//img/settings:layer_format setting.

An EROFS layer is a filesystem, not a changeset. See docs/erofs-layers.md before using it.

See docs/filesystems.md for how the formats compare.2"auto"J"auto"J"tar"J"erofs"J"ext4"J"fat32"J	"iso9660"J"cpio"�
format_config�Options of the filesystem image the layer is written as: an `ext4_config` target
for `format = "ext4"`, a `fat32_config` target for `format = "fat32"`, an `iso9660_config` target for `format = "iso9660"`,
a `cpio_config` target for `format = "cpio"`, or an `erofs_config`
target for `format = "erofs"`.

Without it, every option of the format is left at its default. A config for a
format other than the layer's own is a configuration error, since it would
silently have no effect.*\
Ext4ConfigInfoJ
Ext4ConfigInfo8@rules_img//img/private/providers:format_config_info.bzl*^
Fat32ConfigInfoK
Fat32ConfigInfo8@rules_img//img/private/providers:format_config_info.bzl*b
Iso9660ConfigInfoM
Iso9660ConfigInfo8@rules_img//img/private/providers:format_config_info.bzl*\
CpioConfigInfoJ
CpioConfigInfo8@rules_img//img/private/providers:format_config_info.bzl*^
ErofsConfigInfoK
ErofsConfigInfo8@rules_img//img/private/providers:format_config_info.bzl2None�
estargz�Whether to use estargz format. If set to 'auto', uses the global default estargz setting.
When enabled, the layer will be optimized for lazy pulling and will be compatible with the estargz format.2"auto"J"auto"J	"enabled"J
"disabled"�
zstd_chunked�Whether to use the zstd:chunked format. If set to 'auto', uses the global default zstd_chunked setting.
When enabled, the layer is written with content-defined chunks and a table of contents, so
compatible runtimes (podman, CRI-O) can fetch and deduplicate individual chunks.
Requires zstd compression and cannot be combined with estargz.2"auto"J"auto"J	"enabled"J
"disabled"�
soci�Whether to emit a SOCI ztoc (table of contents) for this layer. If set to 'auto',
uses the global default //img/settings:soci setting. When enabled and the layer is
gzip-compressed, a ztoc is produced in the layer action and recorded on the
SingleLayerInfo provider, so images that build a SOCI Index Manifest v2 can reuse
it instead of regenerating it. Non-gzip layers never emit a ztoc.2"auto"J"auto"J	"enabled"J
"disabled"�
create_parent_directories�Whether to automatically create parent directory entries in the tar file for all files.
If set to 'auto', uses the global default create_parent_directories setting.
When enabled, parent directories will be created automatically for all files in the layer.2"auto"J"auto"J	"enabled"J
"disabled"�
tree_artifact_handling�How to handle duplicate tree artifacts (directories) in the layer.
If set to 'full', each tree artifact is stored at its intended path (no deduplication).
If set to 'deduplicate_symlink', duplicate tree artifacts are replaced with symlinks to the first occurrence.
If set to 'auto', uses the global default from --@rules_img//img/settings:layer_tree_artifact_handling.
When file metadata is configured, trees are stored in full so path-specific metadata
is preserved. Regular files with identical contents and metadata still deduplicate.2"auto"J"auto"J"full"J"deduplicate_symlink"�
include_runfiles�Whether to include runfiles for executable targets.
When True (default), executables in srcs will include their runfiles tree.
When False, only the executable file itself is included, without runfiles.

Either way, any additional default outputs of the target (the rest of `DefaultInfo.files`
beyond the executable) are copied into the layer, placed relative to the executable,
as configured by `extra_default_outputs`.2True�
extra_default_outputs�How to handle an executable's additional default outputs (the rest of `DefaultInfo.files`
beyond the executable itself).

Those files are placed at the same offset relative to the executable that they have in the
source tree, so a file that lives above the executable's directory needs a path in the image
that is deep enough to place it. This setting decides what happens when it isn't:

- `"best_effort"` (default): place every additional default output that fits, and silently
  drop the ones that would land above the image root. This is what wrapper rules such as
  bazel-lib's `transition_binary` need, where the executable is a symlink in a sibling
  directory of the real outputs.
- `"drop"`: never place additional default outputs. Only the executable itself (and its
  runfiles, if `include_runfiles` is True) is included.
- `"strict"`: place every additional default output, and fail the build if any of them
  would land above the image root.2"best_effort"J"best_effort"J"drop"J"strict"Q
annotations<Annotations to add to the layer metadata as key-value pairs.
2{}�
annotations_file�File containing annotations for the layer, as JSON or newline-delimited text.

The file is parsed in one of the following formats, auto-detected from its contents:

- JSON object with string values: `{"key": "value"}`
- JSON object with list values: `{"key": ["value1", "value2"]}` (the last value wins)
- JSON array of `KEY=VALUE` strings: `["key=value"]`
- newline-delimited `KEY=VALUE` text (one per line; blank lines and `#` comments are ignored)

Values in JSON objects are used verbatim, so they can encode arbitrary strings including
values that contain `=`, spaces, or newlines. The `KEY=VALUE` forms (JSON array and text)
split on the first `=` and trim surrounding whitespace from the key and value.

Annotations from this file are merged with annotations specified via the `annotations`
attribute, which take precedence for matching keys.

Example file content:
```
version=1.0.0
build.date=2024-01-15
source.url=https://github.com/...
```2None~

media_typejOverride the layer media type. By default, the media type is auto-detected from the compression algorithm.2"""B
layer_from_binary-@rules_img//img/private:layer_from_binary.bzl*M

LayersInfo?

LayersInfo1@rules_img//img/private/providers:layers_info.bzl,
*
nameA unique name for this target. �
�
binary�The *_binary target to package into the layer.

The binary's `args` and `env` attributes are extracted and provided as image configuration
(cmd and env) via ImageLayerConfigInfo. The `data` attribute is used for `$(location)` expansion
in args and env values.

If the binary provides RunfilesGroupInfo, the runfiles are split into separate layers per group. �
�
path�Optional path of the binary inside the image.
If the path ends with a slash ("/"), the basename of the binary will be automatically appended.
If unset, this defaults to the rlocationpath of the binary (e.g., "_main/cmd/server/server_/server").2""�
�
runfiles_path�Optional path of the runfiles directory of the binary inside the image.
If unset, this defaults to the path of the binary with a .runfiles suffix (e.g., "_main/cmd/server/server_/server.runfiles").
Note: depending on the runfiles_sharing_mode, this may be a symlink to a shared runfiles directory.2""�
�
runfiles_shared_path�Optional path of the shared runfiles directory inside the image.
This is only used when runfiles sharing is enabled and has a global default.2""�
�
runfiles_sharing_mode�How to process runfiles.
Runfiles can either be placed next to the executable (in a directory with a .runfiles suffix, the runfiles_path attribute),
or placed in a shared runfiles path. When sharing runfiles, there will be symlink added: {runfiles_path} -> {runfiles_shared_path}.

Possible settings:

* `"auto"`: Share runfiles based on the global default and based on the presence of `RunfilesGroupInfo`.
    Globally, runfiles sharing can be set to `"shared"`, `"private"`, or `"auto"`, where auto shares runfiles if `RunfilesGroupInfo` is provided.
* `"shared"`: Always share runfiles.
* `"private"`: Never share runfiles2"auto"J"auto"J"shared"J	"private"�
�
default_metadata�JSON-encoded default metadata to apply to all files in the layers.
Can include fields like mode, uid, gid, uname, gname, mtime, and pax_records.
Applies to regular files (including tree contents) and symlinks. Generated
directories inherit only mtime, retaining their default mode and ownership.

Accepts the same value as image_layer's attribute of the same name, so
img/layer.bzl's file_metadata() builds it.2""�
�
infer_working_dir�Whether to infer the image's working directory from the binary's runfiles tree.

When True (default) and `include_runfiles` is True, `ImageLayerConfigInfo.working_dir`
is set to the main workspace directory inside the runfiles tree
(e.g. "/_main/cmd/server/server_/server.runfiles/_main"), which is the directory a
binary launched through the runfiles convention expects to run in.

When False, `ImageLayerConfigInfo.working_dir` is None, which carries no opinion:
`image_manifest` then keeps the base image's working directory, unless its own
`working_dir` attribute is set explicitly.2True�	
�	
layer_budget�	Maximum total number of layers produced by this rule.
If set to a value > 0 and the binary provides RunfilesGroupInfo, groups are merged
using the merge algorithm from rules_runfiles_group. The algorithm respects
group rank (only merges within the same rank), do_not_merge flags, merge affinity
(groups sharing an affinity are preferred merge partners), and weight hints
(lighter groups merge first).

When the binary names an executable_group, the binary executable and supporting files
are merged into that group's layer, and the full budget is available for runfiles
groups. When no executable_group exists, one layer is reserved for a separate binary
layer, and the remaining budget (layer_budget - 1) is used for groups;
layer_budget=1 without an executable_group skips the grouped path entirely.

This is a target, not a hard cap: groups marked do_not_merge are never merged, and
groups at different ranks never merge with each other, so a binary whose groups cannot
be reduced far enough still produces more layers than the budget.

0 means no limit (all groups become separate layers, plus a binary layer unless
an executable_group absorbs it).20�
�
compress�Compression algorithm to use. If set to 'auto', uses the global default compression setting.

'none' leaves the layer uncompressed, which is the useful choice for an EROFS layer
(the blob is then mountable as it is). EROFS layers cannot be gzip-compressed.

A `cpio` layer (an initramfs) is also left uncompressed by default. It can be compressed with
`gzip` or `zstd`, which the kernel unpacks as it is. The `ext4`, `fat32` and `iso9660` formats ignore this attribute.2"auto"J"auto"J"gzip"J"zstd"J"none"�
�
format�Container format of the layer blob, orthogonal to `compress`.

'tar' writes an OCI tar changeset. 'erofs' writes a mountable EROFS filesystem image. 'ext4' and 'fat32' write an
ext4 or FAT32 filesystem image, 'iso9660' an ISO 9660 image (with the Rock Ridge, Joliet and UDF extensions and
El Torito boot entries as options), 'cpio' a cpio archive in the newc format (an initramfs). If set to 'auto', uses the global default
--@rules_img//img/settings:layer_format setting.

An EROFS layer is a filesystem, not a changeset. See docs/erofs-layers.md before using it.

See docs/filesystems.md for how the formats compare.2"auto"J"auto"J"tar"J"erofs"J"ext4"J"fat32"J	"iso9660"J"cpio"�
�
format_config�Options of the filesystem image the layer is written as: an `ext4_config` target
for `format = "ext4"`, a `fat32_config` target for `format = "fat32"`, an `iso9660_config` target for `format = "iso9660"`,
a `cpio_config` target for `format = "cpio"`, or an `erofs_config`
target for `format = "erofs"`.

Without it, every option of the format is left at its default. A config for a
format other than the layer's own is a configuration error, since it would
silently have no effect.*\
Ext4ConfigInfoJ
Ext4ConfigInfo8@rules_img//img/private/providers:format_config_info.bzl*^
Fat32ConfigInfoK
Fat32ConfigInfo8@rules_img//img/private/providers:format_config_info.bzl*b
Iso9660ConfigInfoM
Iso9660ConfigInfo8@rules_img//img/private/providers:format_config_info.bzl*\
CpioConfigInfoJ
CpioConfigInfo8@rules_img//img/private/providers:format_config_info.bzl*^
ErofsConfigInfoK
ErofsConfigInfo8@rules_img//img/private/providers:format_config_info.bzl2None�
�
estargz�Whether to use estargz format. If set to 'auto', uses the global default estargz setting.
When enabled, the layer will be optimized for lazy pulling and will be compatible with the estargz format.2"auto"J"auto"J	"enabled"J
"disabled"�
�
zstd_chunked�Whether to use the zstd:chunked format. If set to 'auto', uses the global default zstd_chunked setting.
When enabled, the layer is written with content-defined chunks and a table of contents, so
compatible runtimes (podman, CRI-O) can fetch and deduplicate individual chunks.
Requires zstd compression and cannot be combined with estargz.2"auto"J"auto"J	"enabled"J
"disabled"�
�
soci�Whether to emit a SOCI ztoc (table of contents) for this layer. If set to 'auto',
uses the global default //img/settings:soci setting. When enabled and the layer is
gzip-compressed, a ztoc is produced in the layer action and recorded on the
SingleLayerInfo provider, so images that build a SOCI Index Manifest v2 can reuse
it instead of regenerating it. Non-gzip layers never emit a ztoc.2"auto"J"auto"J	"enabled"J
"disabled"�
�
create_parent_directories�Whether to automatically create parent directory entries in the tar file for all files.
If set to 'auto', uses the global default create_parent_directories setting.
When enabled, parent directories will be created automatically for all files in the layer.2"auto"J"auto"J	"enabled"J
"disabled"�
�
tree_artifact_handling�How to handle duplicate tree artifacts (directories) in the layer.
If set to 'full', each tree artifact is stored at its intended path (no deduplication).
If set to 'deduplicate_symlink', duplicate tree artifacts are replaced with symlinks to the first occurrence.
If set to 'auto', uses the global default from --@rules_img//img/settings:layer_tree_artifact_handling.
When file metadata is configured, trees are stored in full so path-specific metadata
is preserved. Regular files with identical contents and metadata still deduplicate.2"auto"J"auto"J"full"J"deduplicate_symlink"�
�
include_runfiles�Whether to include runfiles for executable targets.
When True (default), executables in srcs will include their runfiles tree.
When False, only the executable file itself is included, without runfiles.

Either way, any additional default outputs of the target (the rest of `DefaultInfo.files`
beyond the executable) are copied into the layer, placed relative to the executable,
as configured by `extra_default_outputs`.2True�
�
extra_default_outputs�How to handle an executable's additional default outputs (the rest of `DefaultInfo.files`
beyond the executable itself).

Those files are placed at the same offset relative to the executable that they have in the
source tree, so a file that lives above the executable's directory needs a path in the image
that is deep enough to place it. This setting decides what happens when it isn't:

- `"best_effort"` (default): place every additional default output that fits, and silently
  drop the ones that would land above the image root. This is what wrapper rules such as
  bazel-lib's `transition_binary` need, where the executable is a symlink in a sibling
  directory of the real outputs.
- `"drop"`: never place additional default outputs. Only the executable itself (and its
  runfiles, if `include_runfiles` is True) is included.
- `"strict"`: place every additional default output, and fail the build if any of them
  would land above the image root.2"best_effort"J"best_effort"J"drop"J"strict"S
Q
annotations<Annotations to add to the layer metadata as key-value pairs.
2{}�
�
annotations_file�File containing annotations for the layer, as JSON or newline-delimited text.

The file is parsed in one of the following formats, auto-detected from its contents:

- JSON object with string values: `{"key": "value"}`
- JSON object with list values: `{"key": ["value1", "value2"]}` (the last value wins)
- JSON array of `KEY=VALUE` strings: `["key=value"]`
- newline-delimited `KEY=VALUE` text (one per line; blank lines and `#` comments are ignored)

Values in JSON objects are used verbatim, so they can encode arbitrary strings including
values that contain `=`, spaces, or newlines. The `KEY=VALUE` forms (JSON array and text)
split on the first `=` and trim surrounding whitespace from the key and value.

Annotations from this file are merged with annotations specified via the `annotations`
attribute, which take precedence for matching keys.

Example file content:
```
version=1.0.0
build.date=2024-01-15
source.url=https://github.com/...
```2None�
~

media_typejOverride the layer media type. By default, the media type is auto-detected from the compression algorithm.2""�layer_from_file�Creates a container image layer from an arbitrary file.

This rule uses any file as a container image layer blob, computing the
necessary metadata (digest, size) without any tar-specific processing
like compression or optimization.

This is useful for non-tar layer content such as Helm charts, WASM
modules, or other OCI artifacts.

If you want to use an existing tar file as a layer, use layer_from_tar instead.

Example:

```python
load("@rules_img//img:layer.bzl", "layer_from_file")

# Use an arbitrary artifact as a layer
layer_from_file(
    name = "artifact_layer",
    src = ":artifact.bin",
    media_type = "application/octet-stream",
    annotations = {
        "org.opencontainers.image.title": "artifact.bin",
    },
)
```"�
�
layer_from_file�Creates a container image layer from an arbitrary file.

This rule uses any file as a container image layer blob, computing the
necessary metadata (digest, size) without any tar-specific processing
like compression or optimization.

This is useful for non-tar layer content such as Helm charts, WASM
modules, or other OCI artifacts.

If you want to use an existing tar file as a layer, use layer_from_tar instead.

Example:

```python
load("@rules_img//img:layer.bzl", "layer_from_file")

# Use an arbitrary artifact as a layer
layer_from_file(
    name = "artifact_layer",
    src = ":artifact.bin",
    media_type = "application/octet-stream",
    annotations = {
        "org.opencontainers.image.title": "artifact.bin",
    },
)
```*
nameA unique name for this target. +
src The file to use as a layer blob. Q
annotations<Annotations to add to the layer metadata as key-value pairs.
2{}\
base_name_annotations=List of annotations that are set to the basename of the file.2[]�

media_typeRLayer media type. Defaults to "application/vnd.oci.image.layer.v1.tar" if not set.2("application/vnd.oci.image.layer.v1.tar"�
diff_id�If set, interprets the file as a (potentially compressed) tar file and calculates the diff_id. Warning: if you do this, you probably want to use layer_from_tar instead.2Falset
diff_id_annotationsWList of annotations that are set to the diff_id of the file. Only works with tar files.2[]">
layer_from_file+@rules_img//img/private:layer_from_file.bzl*M

LayersInfo?

LayersInfo1@rules_img//img/private/providers:layers_info.bzl,
*
nameA unique name for this target. -
+
src The file to use as a layer blob. S
Q
annotations<Annotations to add to the layer metadata as key-value pairs.
2{}^
\
base_name_annotations=List of annotations that are set to the basename of the file.2[]�
�

media_typeRLayer media type. Defaults to "application/vnd.oci.image.layer.v1.tar" if not set.2("application/vnd.oci.image.layer.v1.tar"�
�
diff_id�If set, interprets the file as a (potentially compressed) tar file and calculates the diff_id. Warning: if you do this, you probably want to use layer_from_tar instead.2Falsev
t
diff_id_annotationsWList of annotations that are set to the diff_id of the file. Only works with tar files.2[]�Qlayer_from_tar�Creates a container image layer from an existing tar archive.

This rule converts tar files into container image layers, useful for incorporating
pre-built artifacts, third-party distributions, or legacy build outputs.

The rule can:
- Use tar files as-is or recompress them
- Optimize tar contents by deduplicating files
- Add annotations to the layer metadata

Example:

```python
load("@rules_img//img:layer.bzl", "layer_from_tar")

# Use an existing tar file as a layer
layer_from_tar(
    name = "third_party_layer",
    src = "@third_party_lib//:lib.tar.gz",
)

# Optimize and recompress
layer_from_tar(
    name = "optimized_layer",
    src = "//legacy:build_output.tar",
    optimize = True,  # Deduplicate contents
    compress = "zstd",  # Use zstd compression
)

# Add metadata annotations
layer_from_tar(
    name = "annotated_layer",
    src = "//vendor:dependencies.tar.gz",
    annotations = {
        "org.opencontainers.image.title": "Vendor Dependencies",
        "org.opencontainers.image.version": "1.2.3",
    },
)
```

### Output groups

- `mtree`: a single [mtree](https://man.freebsd.org/cgi/man.cgi?mtree(5)) text file"�H
�)
layer_from_tar�Creates a container image layer from an existing tar archive.

This rule converts tar files into container image layers, useful for incorporating
pre-built artifacts, third-party distributions, or legacy build outputs.

The rule can:
- Use tar files as-is or recompress them
- Optimize tar contents by deduplicating files
- Add annotations to the layer metadata

Example:

```python
load("@rules_img//img:layer.bzl", "layer_from_tar")

# Use an existing tar file as a layer
layer_from_tar(
    name = "third_party_layer",
    src = "@third_party_lib//:lib.tar.gz",
)

# Optimize and recompress
layer_from_tar(
    name = "optimized_layer",
    src = "//legacy:build_output.tar",
    optimize = True,  # Deduplicate contents
    compress = "zstd",  # Use zstd compression
)

# Add metadata annotations
layer_from_tar(
    name = "annotated_layer",
    src = "//vendor:dependencies.tar.gz",
    annotations = {
        "org.opencontainers.image.title": "Vendor Dependencies",
        "org.opencontainers.image.version": "1.2.3",
    },
)
```

### Output groups

- `mtree`: a single [mtree](https://man.freebsd.org/cgi/man.cgi?mtree(5)) text file*
nameA unique name for this target. b
srcWThe tar file to convert into a layer. Must be a valid tar file (optionally compressed). �
compresswCompression algorithm to use. If set to 'auto', it keeps the existing compression, unless the layer is being optimized.2"auto"J"auto"J"gzip"J"zstd"J"none"�
optimize�If set, rewrites the tar file to deduplicate it's contents.
This is useful for reducing the size of the image, but will take extra time and space to store the optimized layer.2False�
estargz�Whether to use estargz format. If set to 'auto', uses the global default estargz setting.
When enabled, the layer will be optimized for lazy pulling and will be compatible with the estargz format.2"auto"J"auto"J	"enabled"J
"disabled"�
zstd_chunked�Whether to use the zstd:chunked format. If set to 'auto', uses the global default zstd_chunked setting.
When enabled, the layer is written with content-defined chunks and a table of contents, so
compatible runtimes (podman, CRI-O) can fetch and deduplicate individual chunks.
Requires zstd compression and cannot be combined with estargz.2"auto"J"auto"J	"enabled"J
"disabled"�
format�Container format of the layer blob. If set to 'auto', uses the global default
--@rules_img//img/settings:layer_format setting.

'erofs' converts the tar into a mountable EROFS filesystem image. That always rewrites the
layer (a format change cannot preserve the source blob) and defaults to `compress = "none"`,
since the resulting blob is mountable as it is. See docs/erofs-layers.md for what a
filesystem image means for the layers below it.

'ext4' converts the tar into an ext4 filesystem image the same way (always rewritten, never
compressed). Like every ext4 layer, it is not a valid OCI layer: use it on its own. The options
that only apply to tar layers (`compress`, `estargz`, `zstd_chunked`) are ignored. See docs/filesystems.md.

'iso9660' converts the tar into an ISO 9660 image the same way (always rewritten, never compressed), with the
Rock Ridge, Joliet and UDF extensions and El Torito boot entries configurable through an `iso9660_config` target.
'fat32' converts the tar into a FAT32 filesystem image the same way (always rewritten, never
compressed). It is not a valid OCI layer either. FAT cannot store symbolic links, device nodes and
FIFOs, so a tar with such entries fails. The options that only apply to tar layers are ignored.

'cpio' converts the tar into a cpio archive in the newc format (an initramfs) the same way. It is
left uncompressed unless `compress` asks for `gzip` or `zstd`, which the kernel unpacks as it is.
Like an ext4 layer, it is not a valid OCI layer, and `estargz` and `zstd_chunked` are ignored.2"auto"J"auto"J"tar"J"erofs"J"ext4"J"fat32"J	"iso9660"J"cpio"�
format_config�Options of the filesystem image the layer is written as: an `ext4_config` target
for `format = "ext4"`, a `fat32_config` target for `format = "fat32"`, an `iso9660_config` target for `format = "iso9660"`, a `cpio_config` target for `format = "cpio"`, or an `erofs_config` target
for `format = "erofs"`.

Without it, every option of the format is left at its default. A config for a format other
than the layer's own is a configuration error, since it would silently have no effect.*\
Ext4ConfigInfoJ
Ext4ConfigInfo8@rules_img//img/private/providers:format_config_info.bzl*^
Fat32ConfigInfoK
Fat32ConfigInfo8@rules_img//img/private/providers:format_config_info.bzl*b
Iso9660ConfigInfoM
Iso9660ConfigInfo8@rules_img//img/private/providers:format_config_info.bzl*\
CpioConfigInfoJ
CpioConfigInfo8@rules_img//img/private/providers:format_config_info.bzl*^
ErofsConfigInfoK
ErofsConfigInfo8@rules_img//img/private/providers:format_config_info.bzl2NoneQ
annotations<Annotations to add to the layer metadata as key-value pairs.
2{}y

media_typeeOverride layer media type. Use e.g. "application/vnd.cncf.helm.chart.content.v1.tar" for Helm charts.2"""<
layer_from_tar*@rules_img//img/private:layer_from_tar.bzl*M

LayersInfo?

LayersInfo1@rules_img//img/private/providers:layers_info.bzl,
*
nameA unique name for this target. d
b
srcWThe tar file to convert into a layer. Must be a valid tar file (optionally compressed). �
�
compresswCompression algorithm to use. If set to 'auto', it keeps the existing compression, unless the layer is being optimized.2"auto"J"auto"J"gzip"J"zstd"J"none"�
�
optimize�If set, rewrites the tar file to deduplicate it's contents.
This is useful for reducing the size of the image, but will take extra time and space to store the optimized layer.2False�
�
estargz�Whether to use estargz format. If set to 'auto', uses the global default estargz setting.
When enabled, the layer will be optimized for lazy pulling and will be compatible with the estargz format.2"auto"J"auto"J	"enabled"J
"disabled"�
�
zstd_chunked�Whether to use the zstd:chunked format. If set to 'auto', uses the global default zstd_chunked setting.
When enabled, the layer is written with content-defined chunks and a table of contents, so
compatible runtimes (podman, CRI-O) can fetch and deduplicate individual chunks.
Requires zstd compression and cannot be combined with estargz.2"auto"J"auto"J	"enabled"J
"disabled"�
�
format�Container format of the layer blob. If set to 'auto', uses the global default
--@rules_img//img/settings:layer_format setting.

'erofs' converts the tar into a mountable EROFS filesystem image. That always rewrites the
layer (a format change cannot preserve the source blob) and defaults to `compress = "none"`,
since the resulting blob is mountable as it is. See docs/erofs-layers.md for what a
filesystem image means for the layers below it.

'ext4' converts the tar into an ext4 filesystem image the same way (always rewritten, never
compressed). Like every ext4 layer, it is not a valid OCI layer: use it on its own. The options
that only apply to tar layers (`compress`, `estargz`, `zstd_chunked`) are ignored. See docs/filesystems.md.

'iso9660' converts the tar into an ISO 9660 image the same way (always rewritten, never compressed), with the
Rock Ridge, Joliet and UDF extensions and El Torito boot entries configurable through an `iso9660_config` target.
'fat32' converts the tar into a FAT32 filesystem image the same way (always rewritten, never
compressed). It is not a valid OCI layer either. FAT cannot store symbolic links, device nodes and
FIFOs, so a tar with such entries fails. The options that only apply to tar layers are ignored.

'cpio' converts the tar into a cpio archive in the newc format (an initramfs) the same way. It is
left uncompressed unless `compress` asks for `gzip` or `zstd`, which the kernel unpacks as it is.
Like an ext4 layer, it is not a valid OCI layer, and `estargz` and `zstd_chunked` are ignored.2"auto"J"auto"J"tar"J"erofs"J"ext4"J"fat32"J	"iso9660"J"cpio"�
�
format_config�Options of the filesystem image the layer is written as: an `ext4_config` target
for `format = "ext4"`, a `fat32_config` target for `format = "fat32"`, an `iso9660_config` target for `format = "iso9660"`, a `cpio_config` target for `format = "cpio"`, or an `erofs_config` target
for `format = "erofs"`.

Without it, every option of the format is left at its default. A config for a format other
than the layer's own is a configuration error, since it would silently have no effect.*\
Ext4ConfigInfoJ
Ext4ConfigInfo8@rules_img//img/private/providers:format_config_info.bzl*^
Fat32ConfigInfoK
Fat32ConfigInfo8@rules_img//img/private/providers:format_config_info.bzl*b
Iso9660ConfigInfoM
Iso9660ConfigInfo8@rules_img//img/private/providers:format_config_info.bzl*\
CpioConfigInfoJ
CpioConfigInfo8@rules_img//img/private/providers:format_config_info.bzl*^
ErofsConfigInfoK
ErofsConfigInfo8@rules_img//img/private/providers:format_config_info.bzl2NoneS
Q
annotations<Annotations to add to the layer metadata as key-value pairs.
2{}{
y

media_typeeOverride layer media type. Use e.g. "application/vnd.cncf.helm.chart.content.v1.tar" for Helm charts.2""�cpio_config�Options for layers written as a cpio archive.

Pass the target to the `format_config` attribute of a layer rule that uses
`format = "cpio"`. Options that are left at their default are decided by the
`img` tool or by the matching global setting. How the archive is compressed is
not an option of the format: it is the `compress` attribute of the layer.

Example:

```python
load("@rules_img//img:layer.bzl", "cpio_config", "image_layer")

cpio_config(
    name = "initramfs_config",
    # Store every file, even if two have the same content.
    deduplicate = "disabled",
)

image_layer(
    name = "initramfs",
    srcs = {"/init": ":init"},
    compress = "zstd",
    format = "cpio",
    format_config = ":initramfs_config",
)
```

See [docs/filesystems.md](filesystems.md) for the format itself."�
�

cpio_config�Options for layers written as a cpio archive.

Pass the target to the `format_config` attribute of a layer rule that uses
`format = "cpio"`. Options that are left at their default are decided by the
`img` tool or by the matching global setting. How the archive is compressed is
not an option of the format: it is the `compress` attribute of the layer.

Example:

```python
load("@rules_img//img:layer.bzl", "cpio_config", "image_layer")

cpio_config(
    name = "initramfs_config",
    # Store every file, even if two have the same content.
    deduplicate = "disabled",
)

image_layer(
    name = "initramfs",
    srcs = {"/init": ":init"},
    compress = "zstd",
    format = "cpio",
    format_config = ":initramfs_config",
)
```

See [docs/filesystems.md](filesystems.md) for the format itself.*
nameA unique name for this target. �
deduplicate�Whether regular files with the same content and metadata are stored once, as hard
links of each other (what tar layers do). If set to 'auto', uses the global default
`--@rules_img//img/settings:cpio_deduplicate` setting.

Turning it off spares reading file content only to find duplicates, at the cost of
a larger archive.2"auto"J"auto"J	"enabled"J
"disabled""8
cpio_config)@rules_img//img/private:format_config.bzl*\
CpioConfigInfoJ
CpioConfigInfo8@rules_img//img/private/providers:format_config_info.bzl,
*
nameA unique name for this target. �
�
deduplicate�Whether regular files with the same content and metadata are stored once, as hard
links of each other (what tar layers do). If set to 'auto', uses the global default
`--@rules_img//img/settings:cpio_deduplicate` setting.

Turning it off spares reading file content only to find duplicates, at the cost of
a larger archive.2"auto"J"auto"J	"enabled"J
"disabled"�2ext4_config�Options for layers written as an ext4 filesystem image.

Pass the target to the `format_config` attribute of a layer rule that uses
`format = "ext4"`. Options that are left at their default are decided by the
`img` tool (or, for `deduplicate`, by the global
`--@rules_img//img/settings:ext4_deduplicate` setting).

Example:

```python
load("@rules_img//img:layer.bzl", "ext4_config", "image_layer")

ext4_config(
    name = "rootfs_config",
    # Mountable on a machine with 4 KiB pages or more.
    block_size = 4096,
    label = "rootfs",
    # Room to write into the filesystem once it is mounted.
    min_size = "512MiB",
    bytes_per_inode = "16KiB",
)

image_layer(
    name = "rootfs",
    srcs = {"/etc/hostname": ":hostname"},
    format = "ext4",
    format_config = ":rootfs_config",
)
```

See [docs/filesystems.md](filesystems.md) for the format itself."�+
�
ext4_config�Options for layers written as an ext4 filesystem image.

Pass the target to the `format_config` attribute of a layer rule that uses
`format = "ext4"`. Options that are left at their default are decided by the
`img` tool (or, for `deduplicate`, by the global
`--@rules_img//img/settings:ext4_deduplicate` setting).

Example:

```python
load("@rules_img//img:layer.bzl", "ext4_config", "image_layer")

ext4_config(
    name = "rootfs_config",
    # Mountable on a machine with 4 KiB pages or more.
    block_size = 4096,
    label = "rootfs",
    # Room to write into the filesystem once it is mounted.
    min_size = "512MiB",
    bytes_per_inode = "16KiB",
)

image_layer(
    name = "rootfs",
    srcs = {"/etc/hostname": ":hostname"},
    format = "ext4",
    format_config = ":rootfs_config",
)
```

See [docs/filesystems.md](filesystems.md) for the format itself.*
nameA unique name for this target. �

block_size�Filesystem block size in bytes: a power of two between 1024 and 65536. 0 uses 4096.

Linux can only mount a filesystem whose block size is at most the page size of the
machine, so 4096 is the portable choice and 65536 only mounts on a machine with
64 KiB pages.20�
min_size�Minimum size of the image, with an optional binary unit (`"512MiB"`, `"2GiB"`).

The filesystem is otherwise exactly as large as its content needs. A larger size
leaves the extra space free, which is what a filesystem that is going to be written
to needs. Blocks that hold nothing are not written, so a sparse-aware filesystem
stores such an image in about the size of its content.2""�
bytes_per_inode�Reserve one inode for every this many bytes of `min_size`, in addition to the inodes the
content needs, with an optional binary unit (`"16KiB"`).

Only useful together with `min_size`: it decides how many files can be created in the
free space. Empty leaves only the inodes the content needs, plus `extra_inodes`.2""R
extra_inodes=Number of free inodes to leave beyond those the content uses.20@
label1Volume label of the filesystem, at most 16 bytes.2""�
uuid�Filesystem UUID, in the usual textual form (`"01234567-89ab-cdef-0123-456789abcdef"`).

Empty derives a UUID from the metadata of the content, so that equal inputs produce
equal images. Set it when something outside the image refers to the filesystem by
UUID, for example an `/etc/fstab` entry or a bootloader configuration.2""�
omit_lost_and_found�Leave out the `lost+found` directory, which fsck uses to reattach orphaned files.

An image that is only read does not need it, and leaving it out makes the layer's
`mtree` match the one a tar or EROFS layer of the same content produces. `fsck`
reports the directory as missing.2False�
deduplicate�Whether regular files with the same content and metadata are stored once, as hard
links of each other (what tar layers do). If set to 'auto', uses the global default
`--@rules_img//img/settings:ext4_deduplicate` setting.

Turning it off spares reading file content only to find duplicates, at the cost of
a larger image.2"auto"J"auto"J	"enabled"J
"disabled""8
ext4_config)@rules_img//img/private:format_config.bzl*\
Ext4ConfigInfoJ
Ext4ConfigInfo8@rules_img//img/private/providers:format_config_info.bzl,
*
nameA unique name for this target. �
�

block_size�Filesystem block size in bytes: a power of two between 1024 and 65536. 0 uses 4096.

Linux can only mount a filesystem whose block size is at most the page size of the
machine, so 4096 is the portable choice and 65536 only mounts on a machine with
64 KiB pages.20�
�
min_size�Minimum size of the image, with an optional binary unit (`"512MiB"`, `"2GiB"`).

The filesystem is otherwise exactly as large as its content needs. A larger size
leaves the extra space free, which is what a filesystem that is going to be written
to needs. Blocks that hold nothing are not written, so a sparse-aware filesystem
stores such an image in about the size of its content.2""�
�
bytes_per_inode�Reserve one inode for every this many bytes of `min_size`, in addition to the inodes the
content needs, with an optional binary unit (`"16KiB"`).

Only useful together with `min_size`: it decides how many files can be created in the
free space. Empty leaves only the inodes the content needs, plus `extra_inodes`.2""T
R
extra_inodes=Number of free inodes to leave beyond those the content uses.20B
@
label1Volume label of the filesystem, at most 16 bytes.2""�
�
uuid�Filesystem UUID, in the usual textual form (`"01234567-89ab-cdef-0123-456789abcdef"`).

Empty derives a UUID from the metadata of the content, so that equal inputs produce
equal images. Set it when something outside the image refers to the filesystem by
UUID, for example an `/etc/fstab` entry or a bootloader configuration.2""�
�
omit_lost_and_found�Leave out the `lost+found` directory, which fsck uses to reattach orphaned files.

An image that is only read does not need it, and leaving it out makes the layer's
`mtree` match the one a tar or EROFS layer of the same content produces. `fsck`
reports the directory as missing.2False�
�
deduplicate�Whether regular files with the same content and metadata are stored once, as hard
links of each other (what tar layers do). If set to 'auto', uses the global default
`--@rules_img//img/settings:ext4_deduplicate` setting.

Turning it off spares reading file content only to find duplicates, at the cost of
a larger image.2"auto"J"auto"J	"enabled"J
"disabled"�fat32_config�Options for layers written as a FAT32 filesystem image.

Pass the target to the `format_config` attribute of a layer rule that uses
`format = "fat32"`. Options that are left at their default are decided by the
`img` tool.

Example:

```python
load("@rules_img//img:layer.bzl", "fat32_config", "image_layer")

fat32_config(
    name = "esp_config",
    # The sector size of the disk the file system ends up in.
    sector_size = 4096,
)

image_layer(
    name = "esp",
    srcs = {"/EFI/BOOT/BOOTAA64.EFI": ":bootloader"},
    format = "fat32",
    format_config = ":esp_config",
)
```

See [docs/filesystems.md](filesystems.md) for the format itself."�
�	
fat32_config�Options for layers written as a FAT32 filesystem image.

Pass the target to the `format_config` attribute of a layer rule that uses
`format = "fat32"`. Options that are left at their default are decided by the
`img` tool.

Example:

```python
load("@rules_img//img:layer.bzl", "fat32_config", "image_layer")

fat32_config(
    name = "esp_config",
    # The sector size of the disk the file system ends up in.
    sector_size = 4096,
)

image_layer(
    name = "esp",
    srcs = {"/EFI/BOOT/BOOTAA64.EFI": ":bootloader"},
    format = "fat32",
    format_config = ":esp_config",
)
```

See [docs/filesystems.md](filesystems.md) for the format itself.*
nameA unique name for this target. �
sector_size�Logical sector size of the file system in bytes: 512, 1024, 2048 or 4096. 0 uses 512.

A FAT32 file system in a partition of a disk with 4096 byte sectors has to use the
sector size of the disk. A larger sector size makes the smallest possible volume
larger, because FAT32 needs at least 65525 clusters.20"9
fat32_config)@rules_img//img/private:format_config.bzl*^
Fat32ConfigInfoK
Fat32ConfigInfo8@rules_img//img/private/providers:format_config_info.bzl,
*
nameA unique name for this target. �
�
sector_size�Logical sector size of the file system in bytes: 512, 1024, 2048 or 4096. 0 uses 512.

A FAT32 file system in a partition of a disk with 4096 byte sectors has to use the
sector size of the disk. A larger sector size makes the smallest possible volume
larger, because FAT32 needs at least 65525 clusters.20�Hiso9660_config�Options for layers written as an ISO 9660 filesystem image.

Pass the target to the `format_config` attribute of a layer rule that uses
`format = "iso9660"`. Options that are left at their default are decided by the
`img` tool or by the matching global setting.

Plain ISO 9660 can only store upper case, 8.3-ish names and no POSIX metadata at
all, so the interesting part of the format is its extensions. Rock Ridge is on by
default; Joliet and UDF are not, because enabling them is a decision about who
reads the image.

Example:

```python
load("@rules_img//img:layer.bzl", "image_layer", "iso9660_config")

iso9660_config(
    name = "release_config",
    # Readable on Linux (Rock Ridge, on by default), on Windows (Joliet) and on
    # macOS (UDF).
    joliet = True,
    udf = True,
    volume_id = "MYPRODUCT_1_0",
)

image_layer(
    name = "release",
    srcs = {"/README.md": ":readme"},
    format = "iso9660",
    format_config = ":release_config",
)
```

See [docs/filesystems.md](filesystems.md) for the format itself and
`iso9660_boot_entry` for making the image bootable."�?
�$
iso9660_config�Options for layers written as an ISO 9660 filesystem image.

Pass the target to the `format_config` attribute of a layer rule that uses
`format = "iso9660"`. Options that are left at their default are decided by the
`img` tool or by the matching global setting.

Plain ISO 9660 can only store upper case, 8.3-ish names and no POSIX metadata at
all, so the interesting part of the format is its extensions. Rock Ridge is on by
default; Joliet and UDF are not, because enabling them is a decision about who
reads the image.

Example:

```python
load("@rules_img//img:layer.bzl", "image_layer", "iso9660_config")

iso9660_config(
    name = "release_config",
    # Readable on Linux (Rock Ridge, on by default), on Windows (Joliet) and on
    # macOS (UDF).
    joliet = True,
    udf = True,
    volume_id = "MYPRODUCT_1_0",
)

image_layer(
    name = "release",
    srcs = {"/README.md": ":readme"},
    format = "iso9660",
    format_config = ":release_config",
)
```

See [docs/filesystems.md](filesystems.md) for the format itself and
`iso9660_boot_entry` for making the image bootable.*
nameA unique name for this target. �
	volume_idqVolume identifier, at most 32 characters. Empty uses "CDROM".

It is what a mounted image is usually named after.2""w
	system_iddSystem identifier, at most 32 characters, naming the system that can act on the image's system area.2""E
volume_set_id.Volume set identifier, at most 128 characters.2""@
	publisher-Publisher identifier, at most 128 characters.2""H
data_preparer1Data preparer identifier, at most 128 characters.2""G
application_id/Application identifier, at most 128 characters.2""�

rock_ridge�Whether the image carries the Rock Ridge extension, which adds the real names,
the mode, the owner, the timestamps, symbolic links, device nodes, FIFOs and hard
links. This is what Linux uses.

'rationalized' additionally normalizes the metadata of every entry the way
`mkisofs -rational-rock` does: the owner becomes root, the mode becomes read-only
for everyone, the execute bit is kept and shared by all three classes, and the
setuid, setgid and sticky bits are cleared. It makes the image independent of
whoever built it, and it applies to the UDF metadata too, because that describes
the same entries.

Without the extension, symbolic links, device nodes and FIFOs cannot be stored and
a layer with such an entry fails. If set to 'auto', uses the global default
`--@rules_img//img/settings:iso9660_rock_ridge` setting.2"auto"J"auto"J	"enabled"J"rationalized"J
"disabled"�
joliet�Add a second directory hierarchy with UCS-2 names, which is what Windows reads.

It describes the same file data, so it only costs its directory extents and path
tables. Names are capped at the 64 characters of the specification unless
`joliet_long_names` is set.2False�
joliet_long_names�Raise the Joliet name limit from the 64 characters of the specification to the
103 every implementation accepts.

Only useful together with `joliet`.2False�
udf�Add UDF 1.02 structures describing the same file data, in the layout known as a
UDF bridge image. This is what macOS and Windows prefer.

UDF has the real names and POSIX metadata without an extension and no 4 GiB file
size limit. It costs one 2 KiB block per file and directory for its File Entry,
plus the blocks of the directories' file identifier descriptors.2False�
deduplicate�Whether regular files with the same content and metadata are stored once, sharing
one extent. With Rock Ridge they become hard links of each other (what tar layers
do). If set to 'auto', uses the global default
`--@rules_img//img/settings:iso9660_deduplicate` setting.

Turning it off spares reading file content only to find duplicates, at the cost of
a larger image.2"auto"J"auto"J	"enabled"J
"disabled"�
min_size�Minimum size of the image, with an optional binary unit (`"64MiB"`, `"2GiB"`).

The image is otherwise exactly as large as its content needs. Blocks that hold
nothing are not written, so a sparse-aware filesystem stores such an image in
about the size of its content.2""�
boot�El Torito boot entries, as `iso9660_boot_entry` targets, in the order the boot
catalog should list them.

The first one becomes the default entry; every further one becomes a section of
its own, so a single image can boot on BIOS and on UEFI.*h
Iso9660BootEntryInfoP
Iso9660BootEntryInfo8@rules_img//img/private/providers:format_config_info.bzl2[]";
iso9660_config)@rules_img//img/private:format_config.bzl*b
Iso9660ConfigInfoM
Iso9660ConfigInfo8@rules_img//img/private/providers:format_config_info.bzl,
*
nameA unique name for this target. �
�
	volume_idqVolume identifier, at most 32 characters. Empty uses "CDROM".

It is what a mounted image is usually named after.2""y
w
	system_iddSystem identifier, at most 32 characters, naming the system that can act on the image's system area.2""G
E
volume_set_id.Volume set identifier, at most 128 characters.2""B
@
	publisher-Publisher identifier, at most 128 characters.2""J
H
data_preparer1Data preparer identifier, at most 128 characters.2""I
G
application_id/Application identifier, at most 128 characters.2""�
�

rock_ridge�Whether the image carries the Rock Ridge extension, which adds the real names,
the mode, the owner, the timestamps, symbolic links, device nodes, FIFOs and hard
links. This is what Linux uses.

'rationalized' additionally normalizes the metadata of every entry the way
`mkisofs -rational-rock` does: the owner becomes root, the mode becomes read-only
for everyone, the execute bit is kept and shared by all three classes, and the
setuid, setgid and sticky bits are cleared. It makes the image independent of
whoever built it, and it applies to the UDF metadata too, because that describes
the same entries.

Without the extension, symbolic links, device nodes and FIFOs cannot be stored and
a layer with such an entry fails. If set to 'auto', uses the global default
`--@rules_img//img/settings:iso9660_rock_ridge` setting.2"auto"J"auto"J	"enabled"J"rationalized"J
"disabled"�
�
joliet�Add a second directory hierarchy with UCS-2 names, which is what Windows reads.

It describes the same file data, so it only costs its directory extents and path
tables. Names are capped at the 64 characters of the specification unless
`joliet_long_names` is set.2False�
�
joliet_long_names�Raise the Joliet name limit from the 64 characters of the specification to the
103 every implementation accepts.

Only useful together with `joliet`.2False�
�
udf�Add UDF 1.02 structures describing the same file data, in the layout known as a
UDF bridge image. This is what macOS and Windows prefer.

UDF has the real names and POSIX metadata without an extension and no 4 GiB file
size limit. It costs one 2 KiB block per file and directory for its File Entry,
plus the blocks of the directories' file identifier descriptors.2False�
�
deduplicate�Whether regular files with the same content and metadata are stored once, sharing
one extent. With Rock Ridge they become hard links of each other (what tar layers
do). If set to 'auto', uses the global default
`--@rules_img//img/settings:iso9660_deduplicate` setting.

Turning it off spares reading file content only to find duplicates, at the cost of
a larger image.2"auto"J"auto"J	"enabled"J
"disabled"�
�
min_size�Minimum size of the image, with an optional binary unit (`"64MiB"`, `"2GiB"`).

The image is otherwise exactly as large as its content needs. Blocks that hold
nothing are not written, so a sparse-aware filesystem stores such an image in
about the size of its content.2""�
�
boot�El Torito boot entries, as `iso9660_boot_entry` targets, in the order the boot
catalog should list them.

The first one becomes the default entry; every further one becomes a section of
its own, so a single image can boot on BIOS and on UEFI.*h
Iso9660BootEntryInfoP
Iso9660BootEntryInfo8@rules_img//img/private/providers:format_config_info.bzl2[]�2iso9660_boot_entry�
One El Torito boot entry of an ISO 9660 image.

El Torito makes an image bootable by pointing firmware at a boot image that is
an ordinary file of the filesystem. Pass the targets to the `boot` attribute of
an `iso9660_config`, in the order the boot catalog should list them: the first
one becomes the default entry, and every further one becomes a section of its
own, so a single image can boot on BIOS and on UEFI.

Example:

```python
load("@rules_img//img:layer.bzl", "image_layer", "iso9660_boot_entry", "iso9660_config")

# A BIOS boot sector that wants the boot information table patched in.
iso9660_boot_entry(
    name = "bios_boot",
    boot_info_table = True,
    image = "/isolinux/isolinux.bin",
    load_size = 4,
    platform = "bios",
)

# A FAT image the firmware mounts and reads the boot loader from.
iso9660_boot_entry(
    name = "efi_boot",
    id = "EFI",
    image = "/EFI/BOOT/efiboot.img",
    platform = "uefi",
)

iso9660_config(
    name = "installer_config",
    boot = [
        ":bios_boot",
        ":efi_boot",
    ],
    joliet = True,
)

image_layer(
    name = "installer",
    srcs = {
        "/isolinux/isolinux.bin": ":isolinux",
        "/EFI/BOOT/efiboot.img": ":esp_image",
    },
    format = "iso9660",
    format_config = ":installer_config",
)
```

See [docs/filesystems.md](filesystems.md) for the format itself."�'
�
iso9660_boot_entry�
One El Torito boot entry of an ISO 9660 image.

El Torito makes an image bootable by pointing firmware at a boot image that is
an ordinary file of the filesystem. Pass the targets to the `boot` attribute of
an `iso9660_config`, in the order the boot catalog should list them: the first
one becomes the default entry, and every further one becomes a section of its
own, so a single image can boot on BIOS and on UEFI.

Example:

```python
load("@rules_img//img:layer.bzl", "image_layer", "iso9660_boot_entry", "iso9660_config")

# A BIOS boot sector that wants the boot information table patched in.
iso9660_boot_entry(
    name = "bios_boot",
    boot_info_table = True,
    image = "/isolinux/isolinux.bin",
    load_size = 4,
    platform = "bios",
)

# A FAT image the firmware mounts and reads the boot loader from.
iso9660_boot_entry(
    name = "efi_boot",
    id = "EFI",
    image = "/EFI/BOOT/efiboot.img",
    platform = "uefi",
)

iso9660_config(
    name = "installer_config",
    boot = [
        ":bios_boot",
        ":efi_boot",
    ],
    joliet = True,
)

image_layer(
    name = "installer",
    srcs = {
        "/isolinux/isolinux.bin": ":isolinux",
        "/EFI/BOOT/efiboot.img": ":esp_image",
    },
    format = "iso9660",
    format_config = ":installer_config",
)
```

See [docs/filesystems.md](filesystems.md) for the format itself.*
nameA unique name for this target. �
image�Path of the boot image in the layer, which has to be a regular file with content.

A leading slash is optional. The file is stored once: the boot entry points at
the extent the directory record points at. �
platform�The firmware the entry is for.

'uefi' is what a current PC boots from; its boot image is usually a FAT
filesystem (an `image_layer` with `format = "fat32"`) that the firmware mounts
and reads the boot loader from.2"bios"J"bios"J	"powerpc"J"mac"J"uefi"�
	emulation�What the firmware emulates while it reads the boot image.

'none' loads the image as it is, which is what every current boot loader and
every UEFI firmware wants. The floppy and hard disk modes present the image as a
drive of that shape.2"none"J"none"J"floppy120"J"floppy144"J"floppy288"J
"harddisk"�
	load_size�How many 512 byte sectors the firmware loads.

0 loads the whole image (clamped to the 65535 sectors the field can hold), which
is what a UEFI boot image needs. isolinux wants 4.20b
load_segmentMThe real mode segment a BIOS entry is loaded at. 0 uses the default of 0x7C0.20�
boot_info_table�Patch the boot information table isolinux and its relatives expect into bytes 8
to 64 of the boot image.

The stored content then differs from the file that went in, so the boot image is
always carried in the image itself and never becomes a reference in a compact
stream. A boot image that shares its content with another entry cannot be
patched.2False�
id�Identifier recorded on the section header of an entry other than the first, at
most 28 characters.

"EFI" is conventional for a UEFI section, but nothing reads it.2"""?
iso9660_boot_entry)@rules_img//img/private:format_config.bzl*h
Iso9660BootEntryInfoP
Iso9660BootEntryInfo8@rules_img//img/private/providers:format_config_info.bzl,
*
nameA unique name for this target. �
�
image�Path of the boot image in the layer, which has to be a regular file with content.

A leading slash is optional. The file is stored once: the boot entry points at
the extent the directory record points at. �
�
platform�The firmware the entry is for.

'uefi' is what a current PC boots from; its boot image is usually a FAT
filesystem (an `image_layer` with `format = "fat32"`) that the firmware mounts
and reads the boot loader from.2"bios"J"bios"J	"powerpc"J"mac"J"uefi"�
�
	emulation�What the firmware emulates while it reads the boot image.

'none' loads the image as it is, which is what every current boot loader and
every UEFI firmware wants. The floppy and hard disk modes present the image as a
drive of that shape.2"none"J"none"J"floppy120"J"floppy144"J"floppy288"J
"harddisk"�
�
	load_size�How many 512 byte sectors the firmware loads.

0 loads the whole image (clamped to the 65535 sectors the field can hold), which
is what a UEFI boot image needs. isolinux wants 4.20d
b
load_segmentMThe real mode segment a BIOS entry is loaded at. 0 uses the default of 0x7C0.20�
�
boot_info_table�Patch the boot information table isolinux and its relatives expect into bytes 8
to 64 of the boot image.

The stored content then differs from the file that went in, so the boot image is
always carried in the image itself and never becomes a reference in a compact
stream. A boot image that shares its content with another entry cannot be
patched.2False�
�
id�Identifier recorded on the section header of an entry other than the first, at
most 28 characters.

"EFI" is conventional for a UEFI section, but nothing reads it.2""�erofs_config�Options for layers written as an EROFS filesystem image.

Pass the target to the `format_config` attribute of a layer rule that uses
`format = "erofs"`. Options that are left at their default are decided by the
`img` tool or by the matching global setting.

Example:

```python
load("@rules_img//img:layer.bzl", "erofs_config", "image_layer")

erofs_config(
    name = "layer_config",
    block_size = 4096,
)

image_layer(
    name = "layer",
    srcs = {"/etc/hostname": ":hostname"},
    format = "erofs",
    format_config = ":layer_config",
)
```

See [docs/erofs-layers.md](erofs-layers.md) for the format itself."�
�
erofs_config�Options for layers written as an EROFS filesystem image.

Pass the target to the `format_config` attribute of a layer rule that uses
`format = "erofs"`. Options that are left at their default are decided by the
`img` tool or by the matching global setting.

Example:

```python
load("@rules_img//img:layer.bzl", "erofs_config", "image_layer")

erofs_config(
    name = "layer_config",
    block_size = 4096,
)

image_layer(
    name = "layer",
    srcs = {"/etc/hostname": ":hostname"},
    format = "erofs",
    format_config = ":layer_config",
)
```

See [docs/erofs-layers.md](erofs-layers.md) for the format itself.*
nameA unique name for this target. �

block_sizepFilesystem block size in bytes: a power of two of at least 512. 0 uses 4096, which
matches the common page size.20�
inline_threshold�Maximum size (in bytes) of a file payload the layer may tail-pack into its inode.

A file at least this large gets a data extent of its own, and therefore becomes a
content-addressed reference in the compact stream rather than inline bytes. 0 packs
whatever fits in the inode's block. -1 uses the global default
`--@rules_img//img/settings:erofs_inline_threshold` setting.2-1�
synthetic_directories�Attributes for directories the layer has to invent because nothing describes them.

'inherit' copies the nearest described ancestor's ownership (what mkfs.erofs does),
'default' uses 0755 root:root, 'strict' fails the layer instead of guessing. If set
to 'auto', uses the global default
`--@rules_img//img/settings:erofs_synthetic_directories` setting.2"auto"J"auto"J	"inherit"J	"default"J"strict""9
erofs_config)@rules_img//img/private:format_config.bzl*^
ErofsConfigInfoK
ErofsConfigInfo8@rules_img//img/private/providers:format_config_info.bzl,
*
nameA unique name for this target. �
�

block_sizepFilesystem block size in bytes: a power of two of at least 512. 0 uses 4096, which
matches the common page size.20�
�
inline_threshold�Maximum size (in bytes) of a file payload the layer may tail-pack into its inode.

A file at least this large gets a data extent of its own, and therefore becomes a
content-addressed reference in the compact stream rather than inline bytes. 0 packs
whatever fits in the inode's block. -1 uses the global default
`--@rules_img//img/settings:erofs_inline_threshold` setting.2-1�
�
synthetic_directories�Attributes for directories the layer has to invent because nothing describes them.

'inherit' copies the nearest described ancestor's ownership (what mkfs.erofs does),
'default' uses 0755 root:root, 'strict' fails the layer instead of guessing. If set
to 'auto', uses the global default
`--@rules_img//img/settings:erofs_synthetic_directories` setting.2"auto"J"auto"J	"inherit"J	"default"J"strict"�file_metadata�Creates a JSON-encoded file metadata string for use with image_layer rules.

This function generates JSON metadata that can be used to customize file attributes
in container image layers, such as permissions, ownership, and timestamps.
*�

�
file_metadataK
mode;File permission mode (e.g., "0755", "0644"). String format.None(2
uid#User ID of the file owner. Integer.None(3
gid$Group ID of the file owner. Integer.None(5
uname$User name of the file owner. String.None(6
gname%Group name of the file owner. String.None(\
mtimeKModification time in RFC3339 format (e.g., "2023-01-01T00:00:00Z"). String.None(J
pax_records3Dict of extended attributes to set via PAX records.None(�Creates a JSON-encoded file metadata string for use with image_layer rules.

This function generates JSON metadata that can be used to customize file attributes
in container image layers, such as permissions, ownership, and timestamps.
"3
1JSON-encoded string containing the file metadata.2:
file_metadata)@rules_img//img/private:file_metadata.bzlM
K
mode;File permission mode (e.g., "0755", "0644"). String format.None(4
2
uid#User ID of the file owner. Integer.None(5
3
gid$Group ID of the file owner. Integer.None(7
5
uname$User name of the file owner. String.None(8
6
gname%Group name of the file owner. String.None(^
\
mtimeKModification time in RFC3339 format (e.g., "2023-01-01T00:00:00Z"). String.None(L
J
pax_records3Dict of extended attributes to set via PAX records.None(+Public API for container image layer rules.��

	rules_imgimgload.bzl��
image_load�(Loads container images into a local daemon (Docker, containerd, or Podman).

This rule creates an executable target that imports OCI images into your local
container runtime. It supports Docker, Podman, and containerd, with intelligent
detection of the best loading method for optimal performance.

Key features:
- **Incremental loading**: Skips blobs that already exist in the daemon
- **Multi-platform support**: Can load entire image indexes or specific platforms
- **Direct containerd integration**: Bypasses Docker for faster imports when possible
- **Platform filtering**: Use `--platform` flag at runtime to select specific platforms

The rule produces an executable that can be run with `bazel run`.

Image names: when loading into a local daemon the image name is ultimately just
a string, so a single fully-qualified `tag` (the rules_oci-compatible form) is
all a daemon needs. The rule also accepts the same `registry` / `repository` /
`tag` split as `image_push`; the loaded name is simply reconstructed as
`{registry}/{repository}:{tag}` (a `registry` may include a port). Splitting it
out is purely a convenience: it keeps the load target aligned with a matching
`image_push` so the same image is easy to push to a registry later.

The resulting name is used verbatim: nothing is prepended to it and no
`library/` namespace is inserted, so `tag = "my-app:latest"` really loads
`my-app:latest`. Only a missing tag is filled in with `:latest`; a name that is
not a valid image reference fails the build.

When the registry and repository are only known at build time, `destination_file`
takes their place: a file containing `{registry}/{repository}`, which puts the
target in the same split form.

Output groups:
- `tarball`: "docker save" compatible tarball with OCI layout (available for both single and multi-platform images).
  For multi-platform images, the first manifest is used as the default in `manifest.json`,
  and all manifests are included in `index.json`.
  With no `tag` at all, its `manifest.json` falls back to a `RepoTags` entry of `image:latest`.
  Alternatively, setting `daemon = "tar"` (or `--@rules_img//img/settings:load_daemon=tar`)
  produces the same format on-the-fly by streaming it to stdout at runtime.

Example:

```python
load("@rules_img//img:load.bzl", "image_load")

# Load using separate registry/repository/tag (same API as image_push).
# The loaded image name is reconstructed as gcr.io/my-project/my-app:latest.
image_load(
    name = "load_app",
    image = ":my_app",  # References an image_manifest
    registry = "gcr.io",
    repository = "my-project/my-app",
    tag = "latest",
)

# Load a multi-platform image with the split API
image_load(
    name = "load_multiarch",
    image = ":my_app_index",  # References an image_index
    registry = "gcr.io",
    repository = "my-project/my-app",
    tag = "latest",
    daemon = "containerd",  # Explicitly use containerd
)

# The rules_oci-compatible form still works: a single fully-qualified tag with no
# registry/repository is used verbatim as the loaded image name.
image_load(
    name = "load_legacy",
    image = ":my_app",
    tag = "my-app:latest",
)

# The registry/repository can also come from a file written by another rule,
# which loads gcr.io/my-project/my-app:latest if that is the file's content.
image_load(
    name = "load_from_destination_file",
    image = ":my_app",
    destination_file = ":destination.txt",
    tag = "latest",
)

# ...including multiple full-reference tags:
image_load(
    name = "load_multi",
    image = ":my_app",
    tag_list = ["my-app:latest", "my-app:v1.0.0", "my-app:stable"],
)

# Load with dynamic tagging (template expansion works with either form)
image_load(
    name = "load_dynamic",
    image = ":my_app",
    tag = "my-app:{{.BUILD_USER}}",  # Template expansion
    build_settings = {
        "BUILD_USER": "//settings:username",
    },
)
```

Runtime usage:
```bash
# Load all platforms
bazel run //path/to:load_app

# Load specific platform only
bazel run //path/to:load_multiarch -- --platform linux/arm64

# Build Docker save tarball
bazel build //path/to:load_app --output_groups=tarball

# Stream tar to stdout (e.g., pipe to another tool)
bazel run //path/to:load_app --@rules_img//img/settings:load_daemon=tar
```

Performance notes:
- When Docker uses containerd storage (Docker 23.0+), images are loaded directly
  into containerd for better performance if the containerd socket is accessible.
- For older Docker versions, falls back to `docker image load` which requires building
  a tar file (slower and limited to single-platform images)
- If `DOCKER_HOST` points at a daemon that is not reachable through a local socket
  (`tcp://`, `ssh://`, ...), the local containerd is skipped and `docker image load`
  is used, since that daemon does not read this machine's containerd content store
- The `--platform` flag filters which platforms are loaded from multi-platform images
- The `tar` daemon streams a unified OCI+Docker tar to stdout without loading into any daemon
- The `containerization` daemon uses Apple's Containerization framework via `container image load`"��
�f

image_load�(Loads container images into a local daemon (Docker, containerd, or Podman).

This rule creates an executable target that imports OCI images into your local
container runtime. It supports Docker, Podman, and containerd, with intelligent
detection of the best loading method for optimal performance.

Key features:
- **Incremental loading**: Skips blobs that already exist in the daemon
- **Multi-platform support**: Can load entire image indexes or specific platforms
- **Direct containerd integration**: Bypasses Docker for faster imports when possible
- **Platform filtering**: Use `--platform` flag at runtime to select specific platforms

The rule produces an executable that can be run with `bazel run`.

Image names: when loading into a local daemon the image name is ultimately just
a string, so a single fully-qualified `tag` (the rules_oci-compatible form) is
all a daemon needs. The rule also accepts the same `registry` / `repository` /
`tag` split as `image_push`; the loaded name is simply reconstructed as
`{registry}/{repository}:{tag}` (a `registry` may include a port). Splitting it
out is purely a convenience: it keeps the load target aligned with a matching
`image_push` so the same image is easy to push to a registry later.

The resulting name is used verbatim: nothing is prepended to it and no
`library/` namespace is inserted, so `tag = "my-app:latest"` really loads
`my-app:latest`. Only a missing tag is filled in with `:latest`; a name that is
not a valid image reference fails the build.

When the registry and repository are only known at build time, `destination_file`
takes their place: a file containing `{registry}/{repository}`, which puts the
target in the same split form.

Output groups:
- `tarball`: "docker save" compatible tarball with OCI layout (available for both single and multi-platform images).
  For multi-platform images, the first manifest is used as the default in `manifest.json`,
  and all manifests are included in `index.json`.
  With no `tag` at all, its `manifest.json` falls back to a `RepoTags` entry of `image:latest`.
  Alternatively, setting `daemon = "tar"` (or `--@rules_img//img/settings:load_daemon=tar`)
  produces the same format on-the-fly by streaming it to stdout at runtime.

Example:

```python
load("@rules_img//img:load.bzl", "image_load")

# Load using separate registry/repository/tag (same API as image_push).
# The loaded image name is reconstructed as gcr.io/my-project/my-app:latest.
image_load(
    name = "load_app",
    image = ":my_app",  # References an image_manifest
    registry = "gcr.io",
    repository = "my-project/my-app",
    tag = "latest",
)

# Load a multi-platform image with the split API
image_load(
    name = "load_multiarch",
    image = ":my_app_index",  # References an image_index
    registry = "gcr.io",
    repository = "my-project/my-app",
    tag = "latest",
    daemon = "containerd",  # Explicitly use containerd
)

# The rules_oci-compatible form still works: a single fully-qualified tag with no
# registry/repository is used verbatim as the loaded image name.
image_load(
    name = "load_legacy",
    image = ":my_app",
    tag = "my-app:latest",
)

# The registry/repository can also come from a file written by another rule,
# which loads gcr.io/my-project/my-app:latest if that is the file's content.
image_load(
    name = "load_from_destination_file",
    image = ":my_app",
    destination_file = ":destination.txt",
    tag = "latest",
)

# ...including multiple full-reference tags:
image_load(
    name = "load_multi",
    image = ":my_app",
    tag_list = ["my-app:latest", "my-app:v1.0.0", "my-app:stable"],
)

# Load with dynamic tagging (template expansion works with either form)
image_load(
    name = "load_dynamic",
    image = ":my_app",
    tag = "my-app:{{.BUILD_USER}}",  # Template expansion
    build_settings = {
        "BUILD_USER": "//settings:username",
    },
)
```

Runtime usage:
```bash
# Load all platforms
bazel run //path/to:load_app

# Load specific platform only
bazel run //path/to:load_multiarch -- --platform linux/arm64

# Build Docker save tarball
bazel build //path/to:load_app --output_groups=tarball

# Stream tar to stdout (e.g., pipe to another tool)
bazel run //path/to:load_app --@rules_img//img/settings:load_daemon=tar
```

Performance notes:
- When Docker uses containerd storage (Docker 23.0+), images are loaded directly
  into containerd for better performance if the containerd socket is accessible.
- For older Docker versions, falls back to `docker image load` which requires building
  a tar file (slower and limited to single-platform images)
- If `DOCKER_HOST` points at a daemon that is not reachable through a local socket
  (`tcp://`, `ssh://`, ...), the local containerd is skipped and `docker image load`
  is used, since that daemon does not read this machine's containerd content store
- The `--platform` flag filters which platforms are loaded from multi-platform images
- The `tar` daemon streams a unified OCI+Docker tar to stdout without loading into any daemon
- The `containerization` daemon uses Apple's Containerization framework via `container image load`*
nameA unique name for this target. �
daemon�Container daemon to use for loading the image.

Available options:
- **`auto`** (default): Uses the global default setting (usually `docker`)
- **`containerd`**: Loads directly into containerd namespace. Supports multi-platform images
  and incremental loading.
- **`docker`**: Loads via Docker daemon. When Docker uses containerd storage (23.0+),
  loads directly into containerd. Otherwise falls back to `docker image load` command which
  is slower and limited to single-platform images.
- **`podman`**: Loads via Podman daemon using `podman image load` command. Similar to Docker
  fallback mode, this is slower than containerd and limited to single-platform images.
- **`containerization`**: Loads via Apple's Containerization framework using `container image load`.
  Reads a unified OCI+Docker tar from stdin.
- **`tar`**: Does not load into any daemon. Instead, streams the unified OCI+Docker tar to stdout.
  Useful for piping to other tools or saving to a file.
- **`generic`**: Loads via a custom container runtime. The loader will invoke the command
  specified in the `LOADER_BINARY` environment variable with `image load` subcommands. For example,
  if `LOADER_BINARY=nerdctl`, it will run `nerdctl image load`.
  Requires `LOADER_BINARY` to be set at runtime.

The best performance is achieved with:
- Direct containerd access (daemon = "containerd")
- Docker 23.0+ with containerd storage enabled and accessible containerd socket2"auto"J"auto"J"docker"J"containerd"J"podman"J"containerization"J"tar"J	"generic"�
registry�Registry component of the image name to load.

Optional. When set, `repository` must also be set, and each entry in
`tag` / `tag_list` / `tag_file` is treated as a bare tag: the loaded image name
is reconstructed as `{registry}/{repository}:{tag}` (mirroring `image_push`).
May include a port (e.g. `docker.mycompany.tld:1234`).

When omitted but `repository` is set, the global
`--@rules_img//img/settings:destination_registry` flag is used as a fallback
(again mirroring `image_push`).

When omitted together with `repository`, the tags are used verbatim as full
image references, preserving the `rules_oci`-compatible behavior. In this mode
the `destination_registry` fallback does not apply.

Cannot be used together with `destination_file`, which names both components in
a file instead.

Whichever way the name is put together, it is then used as written: it never
goes through Docker's reference normalization (which would add `index.docker.io`
and the `library/` namespace), and a name that is not a valid image reference
fails the build.

Subject to [template expansion](/docs/templating.md).2""�

repository�Repository component of the image name to load.

Optional. Must be set together with `registry` (see `registry` for details).

Subject to [template expansion](/docs/templating.md).2""�
tag�Tag to apply when loading the image.

Optional - if omitted, the image is loaded without a name.

When `registry`/`repository` are set, this is a bare tag (e.g. `latest`);
otherwise it is a full image reference (e.g. `my-app:latest`) - a reference
written without a tag (e.g. `my-app`) is loaded as `my-app:latest`.

Subject to [template expansion](/docs/templating.md).2""�
tag_list�List of tags to apply when loading the image.

Useful for applying multiple tags in a single load:

```python
tag_list = ["latest", "v1.0.0", "stable"]
```

Cannot be used together with `tag`. Can be combined with `tag_file` to merge tags from both sources.
Each tag is subject to [template expansion](/docs/templating.md).2[]�
tag_file�File containing newline-delimited tags to apply when loading the image.

The file should contain one tag per line. Empty lines are ignored. Tags from this file
are merged with tags specified via `tag` or `tag_list` attributes.

Example file content:
```
latest
v1.0.0
stable
```

Can be combined with `tag` or `tag_list` to merge tags from multiple sources.
Each tag is subject to [template expansion](/docs/templating.md).2None�
destination_file�File containing the registry and repository as `{registry}/{repository}`.

An alternative to the `registry` / `repository` attributes for cases where the
destination is only known at build time (e.g. written by another rule). The file
should contain a single line with the registry and repository separated by the
first `/`. For example: `gcr.io/my-project/my-app`.

The content is read as a literal string without Go template expansion. Trailing
newlines and whitespace are stripped.

Setting it puts the load target in the split form, exactly as if `registry` and
`repository` had been set: each entry in `tag` / `tag_list` / `tag_file` is a
bare tag and the loaded image name is `{registry}/{repository}:{tag}`.

Cannot be used together with `registry` or `repository` attributes.2None�
strategy�Strategy for handling image layers during load.

Available strategies:
- **`auto`** (default): Uses the global default load strategy
- **`eager`**: Downloads all layers during the build phase. Ensures all layers are
  available locally before running the load command.
- **`lazy`**: Downloads layers only when needed during the load operation. More
  efficient for large images where some layers might already exist in the daemon.2"auto"J"auto"J"eager"J"lazy"�
build_settings�Build settings for template expansion.

Maps template variable names to string_flag targets. These values can be used in
tag attributes using `{{.VARIABLE_NAME}}` syntax (Go template).

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"J"auto"J"force"J
"disabled"�
tracks_content�When True, the template expansion action depends on the image digest.

A template string built from a volatile stamp value (e.g. `{{.BUILD_TIMESTAMP}}`) normally
freezes on the first build, because Bazel excludes the volatile workspace-status
file from the action cache key. With this enabled, the image descriptor becomes
an input to the tag-expansion action, so the tag re-stamps whenever the image
content (digest) changes, while unchanged content keeps the cached tag.

The digest is exposed to the `tag` templates as `{{.digest}}`. Referencing the
digest in the tag is optional: the re-stamp behavior applies whether or not the
tag contains it.2FalseO
imageBImage to load. Should provide ImageManifestInfo or ImageIndexInfo. �
tool_cfg�**Experimental**: This attribute may be removed if we find a way to automatically select the correct loader platform based on the context of use.
Configuration of the loader executable. By default, the loader executable is always chosen for the host platform, regardless of the value of `--platforms`. Setting this attribute to 'target' makes the loader match the target platform instead.
The `"target"` option is useful when the "image_load" target is used as a data dependency of an integration test.

Available options:
- **`host`** (default): Loader executable matches the host platform.
- **`target`**: Loader executable matches the target platform(s) specified via `--platforms`.2"host"J"host"J"target"�
deploy_tool�Optional label of a deploy tool target providing `DeployToolInfo` (created with `img_deploy_tool` from `@rules_img//img:deploy_tool.bzl`). When set, overrides `tool_cfg`.*Z
DeployToolInfoH
DeployToolInfo6@rules_img//img/private/providers:deploy_tool_info.bzl2None".

image_load @rules_img//img/private:load.bzl8,
*
nameA unique name for this target. �
�
daemon�Container daemon to use for loading the image.

Available options:
- **`auto`** (default): Uses the global default setting (usually `docker`)
- **`containerd`**: Loads directly into containerd namespace. Supports multi-platform images
  and incremental loading.
- **`docker`**: Loads via Docker daemon. When Docker uses containerd storage (23.0+),
  loads directly into containerd. Otherwise falls back to `docker image load` command which
  is slower and limited to single-platform images.
- **`podman`**: Loads via Podman daemon using `podman image load` command. Similar to Docker
  fallback mode, this is slower than containerd and limited to single-platform images.
- **`containerization`**: Loads via Apple's Containerization framework using `container image load`.
  Reads a unified OCI+Docker tar from stdin.
- **`tar`**: Does not load into any daemon. Instead, streams the unified OCI+Docker tar to stdout.
  Useful for piping to other tools or saving to a file.
- **`generic`**: Loads via a custom container runtime. The loader will invoke the command
  specified in the `LOADER_BINARY` environment variable with `image load` subcommands. For example,
  if `LOADER_BINARY=nerdctl`, it will run `nerdctl image load`.
  Requires `LOADER_BINARY` to be set at runtime.

The best performance is achieved with:
- Direct containerd access (daemon = "containerd")
- Docker 23.0+ with containerd storage enabled and accessible containerd socket2"auto"J"auto"J"docker"J"containerd"J"podman"J"containerization"J"tar"J	"generic"�
�
registry�Registry component of the image name to load.

Optional. When set, `repository` must also be set, and each entry in
`tag` / `tag_list` / `tag_file` is treated as a bare tag: the loaded image name
is reconstructed as `{registry}/{repository}:{tag}` (mirroring `image_push`).
May include a port (e.g. `docker.mycompany.tld:1234`).

When omitted but `repository` is set, the global
`--@rules_img//img/settings:destination_registry` flag is used as a fallback
(again mirroring `image_push`).

When omitted together with `repository`, the tags are used verbatim as full
image references, preserving the `rules_oci`-compatible behavior. In this mode
the `destination_registry` fallback does not apply.

Cannot be used together with `destination_file`, which names both components in
a file instead.

Whichever way the name is put together, it is then used as written: it never
goes through Docker's reference normalization (which would add `index.docker.io`
and the `library/` namespace), and a name that is not a valid image reference
fails the build.

Subject to [template expansion](/docs/templating.md).2""�
�

repository�Repository component of the image name to load.

Optional. Must be set together with `registry` (see `registry` for details).

Subject to [template expansion](/docs/templating.md).2""�
�
tag�Tag to apply when loading the image.

Optional - if omitted, the image is loaded without a name.

When `registry`/`repository` are set, this is a bare tag (e.g. `latest`);
otherwise it is a full image reference (e.g. `my-app:latest`) - a reference
written without a tag (e.g. `my-app`) is loaded as `my-app:latest`.

Subject to [template expansion](/docs/templating.md).2""�
�
tag_list�List of tags to apply when loading the image.

Useful for applying multiple tags in a single load:

```python
tag_list = ["latest", "v1.0.0", "stable"]
```

Cannot be used together with `tag`. Can be combined with `tag_file` to merge tags from both sources.
Each tag is subject to [template expansion](/docs/templating.md).2[]�
�
tag_file�File containing newline-delimited tags to apply when loading the image.

The file should contain one tag per line. Empty lines are ignored. Tags from this file
are merged with tags specified via `tag` or `tag_list` attributes.

Example file content:
```
latest
v1.0.0
stable
```

Can be combined with `tag` or `tag_list` to merge tags from multiple sources.
Each tag is subject to [template expansion](/docs/templating.md).2None�
�
destination_file�File containing the registry and repository as `{registry}/{repository}`.

An alternative to the `registry` / `repository` attributes for cases where the
destination is only known at build time (e.g. written by another rule). The file
should contain a single line with the registry and repository separated by the
first `/`. For example: `gcr.io/my-project/my-app`.

The content is read as a literal string without Go template expansion. Trailing
newlines and whitespace are stripped.

Setting it puts the load target in the split form, exactly as if `registry` and
`repository` had been set: each entry in `tag` / `tag_list` / `tag_file` is a
bare tag and the loaded image name is `{registry}/{repository}:{tag}`.

Cannot be used together with `registry` or `repository` attributes.2None�
�
strategy�Strategy for handling image layers during load.

Available strategies:
- **`auto`** (default): Uses the global default load strategy
- **`eager`**: Downloads all layers during the build phase. Ensures all layers are
  available locally before running the load command.
- **`lazy`**: Downloads layers only when needed during the load operation. More
  efficient for large images where some layers might already exist in the daemon.2"auto"J"auto"J"eager"J"lazy"�
�
build_settings�Build settings for template expansion.

Maps template variable names to string_flag targets. These values can be used in
tag attributes using `{{.VARIABLE_NAME}}` syntax (Go template).

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"J"auto"J"force"J
"disabled"�
�
tracks_content�When True, the template expansion action depends on the image digest.

A template string built from a volatile stamp value (e.g. `{{.BUILD_TIMESTAMP}}`) normally
freezes on the first build, because Bazel excludes the volatile workspace-status
file from the action cache key. With this enabled, the image descriptor becomes
an input to the tag-expansion action, so the tag re-stamps whenever the image
content (digest) changes, while unchanged content keeps the cached tag.

The digest is exposed to the `tag` templates as `{{.digest}}`. Referencing the
digest in the tag is optional: the re-stamp behavior applies whether or not the
tag contains it.2FalseQ
O
imageBImage to load. Should provide ImageManifestInfo or ImageIndexInfo. �
�
tool_cfg�**Experimental**: This attribute may be removed if we find a way to automatically select the correct loader platform based on the context of use.
Configuration of the loader executable. By default, the loader executable is always chosen for the host platform, regardless of the value of `--platforms`. Setting this attribute to 'target' makes the loader match the target platform instead.
The `"target"` option is useful when the "image_load" target is used as a data dependency of an integration test.

Available options:
- **`host`** (default): Loader executable matches the host platform.
- **`target`**: Loader executable matches the target platform(s) specified via `--platforms`.2"host"J"host"J"target"�
�
deploy_tool�Optional label of a deploy tool target providing `DeployToolInfo` (created with `img_deploy_tool` from `@rules_img//img:deploy_tool.bzl`). When set, overrides `tool_cfg`.*Z
DeployToolInfoH
DeployToolInfo6@rules_img//img/private/providers:deploy_tool_info.bzl2None݋image_load_spec�Defines load configuration for container images without referencing a specific image.

This rule captures registry, repository, daemon, tag, and strategy settings that
can be attached to `image_manifest` or `image_index` targets via their
`load_specs` attribute.
Template strings using Go template syntax (`{{.VAR}}`) are accepted but not
expanded — expansion happens when the deployment is consumed by the image rule.
Note that the template strings `{{.image_target_package}}` and `{{.image_target_name}}` are especially useful here.

This enables an inverted dependency pattern: instead of `image_load` depending
on the image, the image itself carries its load configuration, making it
directly usable with `multi_deploy`.

Example:

```python
load("@rules_img//img:load.bzl", "image_load_spec")

# Full image reference in a single tag (rules_oci-compatible).
image_load_spec(
    name = "load_config",
    tag = "{{.image_target_package}}/{{.image_target_name}}:latest",
    daemon = "containerd",
)

# Or split into registry/repository/tag (same API as image_push_spec):
image_load_spec(
    name = "load_config_split",
    registry = "gcr.io",
    repository = "my-project/{{.image_target_package}}/{{.image_target_name}}",
    tag = "latest",
    daemon = "containerd",
)

# Or take the registry/repository from a file written by another rule:
image_load_spec(
    name = "load_config_destination_file",
    destination_file = ":destination.txt",
    tag = "latest",
    daemon = "containerd",
)

# Attach to an image:
image_manifest(
    name = "my_app_a",
    base = "@distroless_cc",
    layers = [":app_layer"],
    load_specs = [":load_config"],
)

# Attach to another image:
image_manifest(
    name = "my_app_b",
    base = "@distroless_cc",
    layers = [":app_layer"],
    load_specs = [":load_config"],
)

# Now usable directly in multi_deploy:
multi_deploy(
    name = "deploy",
    operations = [
        ":my_app_a",
        ":my_app_b",
    ],
)
```"�|
�F
image_load_spec�Defines load configuration for container images without referencing a specific image.

This rule captures registry, repository, daemon, tag, and strategy settings that
can be attached to `image_manifest` or `image_index` targets via their
`load_specs` attribute.
Template strings using Go template syntax (`{{.VAR}}`) are accepted but not
expanded — expansion happens when the deployment is consumed by the image rule.
Note that the template strings `{{.image_target_package}}` and `{{.image_target_name}}` are especially useful here.

This enables an inverted dependency pattern: instead of `image_load` depending
on the image, the image itself carries its load configuration, making it
directly usable with `multi_deploy`.

Example:

```python
load("@rules_img//img:load.bzl", "image_load_spec")

# Full image reference in a single tag (rules_oci-compatible).
image_load_spec(
    name = "load_config",
    tag = "{{.image_target_package}}/{{.image_target_name}}:latest",
    daemon = "containerd",
)

# Or split into registry/repository/tag (same API as image_push_spec):
image_load_spec(
    name = "load_config_split",
    registry = "gcr.io",
    repository = "my-project/{{.image_target_package}}/{{.image_target_name}}",
    tag = "latest",
    daemon = "containerd",
)

# Or take the registry/repository from a file written by another rule:
image_load_spec(
    name = "load_config_destination_file",
    destination_file = ":destination.txt",
    tag = "latest",
    daemon = "containerd",
)

# Attach to an image:
image_manifest(
    name = "my_app_a",
    base = "@distroless_cc",
    layers = [":app_layer"],
    load_specs = [":load_config"],
)

# Attach to another image:
image_manifest(
    name = "my_app_b",
    base = "@distroless_cc",
    layers = [":app_layer"],
    load_specs = [":load_config"],
)

# Now usable directly in multi_deploy:
multi_deploy(
    name = "deploy",
    operations = [
        ":my_app_a",
        ":my_app_b",
    ],
)
```*
nameA unique name for this target. �
daemon�Container daemon to use for loading the image.

Available options:
- **`auto`** (default): Uses the global default setting (usually `docker`)
- **`containerd`**: Loads directly into containerd namespace. Supports multi-platform images
  and incremental loading.
- **`docker`**: Loads via Docker daemon. When Docker uses containerd storage (23.0+),
  loads directly into containerd. Otherwise falls back to `docker image load` command which
  is slower and limited to single-platform images.
- **`podman`**: Loads via Podman daemon using `podman image load` command. Similar to Docker
  fallback mode, this is slower than containerd and limited to single-platform images.
- **`containerization`**: Loads via Apple's Containerization framework using `container image load`.
  Reads a unified OCI+Docker tar from stdin.
- **`tar`**: Does not load into any daemon. Instead, streams the unified OCI+Docker tar to stdout.
  Useful for piping to other tools or saving to a file.
- **`generic`**: Loads via a custom container runtime. The loader will invoke the command
  specified in the `LOADER_BINARY` environment variable with `image load` subcommands. For example,
  if `LOADER_BINARY=nerdctl`, it will run `nerdctl image load`.
  Requires `LOADER_BINARY` to be set at runtime.

The best performance is achieved with:
- Direct containerd access (daemon = "containerd")
- Docker 23.0+ with containerd storage enabled and accessible containerd socket2"auto"J"auto"J"docker"J"containerd"J"podman"J"containerization"J"tar"J	"generic"�
registry�Registry component of the image name to load.

Optional. When set, `repository` must also be set, and each entry in
`tag` / `tag_list` / `tag_file` is treated as a bare tag: the loaded image name
is reconstructed as `{registry}/{repository}:{tag}` (mirroring `image_push`).
May include a port (e.g. `docker.mycompany.tld:1234`).

When omitted but `repository` is set, the global
`--@rules_img//img/settings:destination_registry` flag is used as a fallback
(again mirroring `image_push`).

When omitted together with `repository`, the tags are used verbatim as full
image references, preserving the `rules_oci`-compatible behavior. In this mode
the `destination_registry` fallback does not apply.

Cannot be used together with `destination_file`, which names both components in
a file instead.

Whichever way the name is put together, it is then used as written: it never
goes through Docker's reference normalization (which would add `index.docker.io`
and the `library/` namespace), and a name that is not a valid image reference
fails the build.

Subject to [template expansion](/docs/templating.md).2""�

repository�Repository component of the image name to load.

Optional. Must be set together with `registry` (see `registry` for details).

Subject to [template expansion](/docs/templating.md).2""�
tag�Tag to apply when loading the image.

Optional - if omitted, the image is loaded without a name.

When `registry`/`repository` are set, this is a bare tag (e.g. `latest`);
otherwise it is a full image reference (e.g. `my-app:latest`) - a reference
written without a tag (e.g. `my-app`) is loaded as `my-app:latest`.

Subject to [template expansion](/docs/templating.md).2""�
tag_list�List of tags to apply when loading the image.

Useful for applying multiple tags in a single load:

```python
tag_list = ["latest", "v1.0.0", "stable"]
```

Cannot be used together with `tag`. Can be combined with `tag_file` to merge tags from both sources.
Each tag is subject to [template expansion](/docs/templating.md).2[]�
tag_file�File containing newline-delimited tags to apply when loading the image.

The file should contain one tag per line. Empty lines are ignored. Tags from this file
are merged with tags specified via `tag` or `tag_list` attributes.

Example file content:
```
latest
v1.0.0
stable
```

Can be combined with `tag` or `tag_list` to merge tags from multiple sources.
Each tag is subject to [template expansion](/docs/templating.md).2None�
destination_file�File containing the registry and repository as `{registry}/{repository}`.

An alternative to the `registry` / `repository` attributes for cases where the
destination is only known at build time (e.g. written by another rule). The file
should contain a single line with the registry and repository separated by the
first `/`. For example: `gcr.io/my-project/my-app`.

The content is read as a literal string without Go template expansion. Trailing
newlines and whitespace are stripped.

Setting it puts the load target in the split form, exactly as if `registry` and
`repository` had been set: each entry in `tag` / `tag_list` / `tag_file` is a
bare tag and the loaded image name is `{registry}/{repository}:{tag}`.

Cannot be used together with `registry` or `repository` attributes.2None�
strategy�Strategy for handling image layers during load.

Available strategies:
- **`auto`** (default): Uses the global default load strategy
- **`eager`**: Downloads all layers during the build phase. Ensures all layers are
  available locally before running the load command.
- **`lazy`**: Downloads layers only when needed during the load operation. More
  efficient for large images where some layers might already exist in the daemon.2"auto"J"auto"J"eager"J"lazy"�
build_settings�Build settings for template expansion.

Maps template variable names to string_flag targets. These values can be used in
tag attributes using `{{.VARIABLE_NAME}}` syntax (Go template).

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"J"auto"J"force"J
"disabled"�
tracks_content�When True, the template expansion action depends on the image digest.

A template string built from a volatile stamp value (e.g. `{{.BUILD_TIMESTAMP}}`) normally
freezes on the first build, because Bazel excludes the volatile workspace-status
file from the action cache key. With this enabled, the image descriptor becomes
an input to the tag-expansion action, so the tag re-stamps whenever the image
content (digest) changes, while unchanged content keeps the cached tag.

The digest is exposed to the `tag` templates as `{{.digest}}`. Referencing the
digest in the tag is optional: the re-stamp behavior applies whether or not the
tag contains it.2False"8
image_load_spec%@rules_img//img/private:load_spec.bzl*Z
LoadConfigInfoH
LoadConfigInfo6@rules_img//img/private/providers:load_config_info.bzl,
*
nameA unique name for this target. �
�
daemon�Container daemon to use for loading the image.

Available options:
- **`auto`** (default): Uses the global default setting (usually `docker`)
- **`containerd`**: Loads directly into containerd namespace. Supports multi-platform images
  and incremental loading.
- **`docker`**: Loads via Docker daemon. When Docker uses containerd storage (23.0+),
  loads directly into containerd. Otherwise falls back to `docker image load` command which
  is slower and limited to single-platform images.
- **`podman`**: Loads via Podman daemon using `podman image load` command. Similar to Docker
  fallback mode, this is slower than containerd and limited to single-platform images.
- **`containerization`**: Loads via Apple's Containerization framework using `container image load`.
  Reads a unified OCI+Docker tar from stdin.
- **`tar`**: Does not load into any daemon. Instead, streams the unified OCI+Docker tar to stdout.
  Useful for piping to other tools or saving to a file.
- **`generic`**: Loads via a custom container runtime. The loader will invoke the command
  specified in the `LOADER_BINARY` environment variable with `image load` subcommands. For example,
  if `LOADER_BINARY=nerdctl`, it will run `nerdctl image load`.
  Requires `LOADER_BINARY` to be set at runtime.

The best performance is achieved with:
- Direct containerd access (daemon = "containerd")
- Docker 23.0+ with containerd storage enabled and accessible containerd socket2"auto"J"auto"J"docker"J"containerd"J"podman"J"containerization"J"tar"J	"generic"�
�
registry�Registry component of the image name to load.

Optional. When set, `repository` must also be set, and each entry in
`tag` / `tag_list` / `tag_file` is treated as a bare tag: the loaded image name
is reconstructed as `{registry}/{repository}:{tag}` (mirroring `image_push`).
May include a port (e.g. `docker.mycompany.tld:1234`).

When omitted but `repository` is set, the global
`--@rules_img//img/settings:destination_registry` flag is used as a fallback
(again mirroring `image_push`).

When omitted together with `repository`, the tags are used verbatim as full
image references, preserving the `rules_oci`-compatible behavior. In this mode
the `destination_registry` fallback does not apply.

Cannot be used together with `destination_file`, which names both components in
a file instead.

Whichever way the name is put together, it is then used as written: it never
goes through Docker's reference normalization (which would add `index.docker.io`
and the `library/` namespace), and a name that is not a valid image reference
fails the build.

Subject to [template expansion](/docs/templating.md).2""�
�

repository�Repository component of the image name to load.

Optional. Must be set together with `registry` (see `registry` for details).

Subject to [template expansion](/docs/templating.md).2""�
�
tag�Tag to apply when loading the image.

Optional - if omitted, the image is loaded without a name.

When `registry`/`repository` are set, this is a bare tag (e.g. `latest`);
otherwise it is a full image reference (e.g. `my-app:latest`) - a reference
written without a tag (e.g. `my-app`) is loaded as `my-app:latest`.

Subject to [template expansion](/docs/templating.md).2""�
�
tag_list�List of tags to apply when loading the image.

Useful for applying multiple tags in a single load:

```python
tag_list = ["latest", "v1.0.0", "stable"]
```

Cannot be used together with `tag`. Can be combined with `tag_file` to merge tags from both sources.
Each tag is subject to [template expansion](/docs/templating.md).2[]�
�
tag_file�File containing newline-delimited tags to apply when loading the image.

The file should contain one tag per line. Empty lines are ignored. Tags from this file
are merged with tags specified via `tag` or `tag_list` attributes.

Example file content:
```
latest
v1.0.0
stable
```

Can be combined with `tag` or `tag_list` to merge tags from multiple sources.
Each tag is subject to [template expansion](/docs/templating.md).2None�
�
destination_file�File containing the registry and repository as `{registry}/{repository}`.

An alternative to the `registry` / `repository` attributes for cases where the
destination is only known at build time (e.g. written by another rule). The file
should contain a single line with the registry and repository separated by the
first `/`. For example: `gcr.io/my-project/my-app`.

The content is read as a literal string without Go template expansion. Trailing
newlines and whitespace are stripped.

Setting it puts the load target in the split form, exactly as if `registry` and
`repository` had been set: each entry in `tag` / `tag_list` / `tag_file` is a
bare tag and the loaded image name is `{registry}/{repository}:{tag}`.

Cannot be used together with `registry` or `repository` attributes.2None�
�
strategy�Strategy for handling image layers during load.

Available strategies:
- **`auto`** (default): Uses the global default load strategy
- **`eager`**: Downloads all layers during the build phase. Ensures all layers are
  available locally before running the load command.
- **`lazy`**: Downloads layers only when needed during the load operation. More
  efficient for large images where some layers might already exist in the daemon.2"auto"J"auto"J"eager"J"lazy"�
�
build_settings�Build settings for template expansion.

Maps template variable names to string_flag targets. These values can be used in
tag attributes using `{{.VARIABLE_NAME}}` syntax (Go template).

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"J"auto"J"force"J
"disabled"�
�
tracks_content�When True, the template expansion action depends on the image digest.

A template string built from a volatile stamp value (e.g. `{{.BUILD_TIMESTAMP}}`) normally
freezes on the first build, because Bazel excludes the volatile workspace-status
file from the action cache key. With this enabled, the image descriptor becomes
an input to the tag-expansion action, so the tag re-stamps whenever the image
content (digest) changes, while unchanged content keeps the cached tag.

The digest is exposed to the `tag` templates as `{{.digest}}`. Referencing the
digest in the tag is optional: the re-stamp behavior applies whether or not the
tag contains it.2False�Public API for loading container images into a daemon.

The `image_load` rule creates an executable target that loads container images into a local daemon (containerd, Docker, or Podman).

## Example

```python
load("@rules_img//img:image.bzl", "image_manifest")
load("@rules_img//img:load.bzl", "image_load")
load("@rules_img//img:layer.bzl", "image_layer")

# Create a simple layer
image_layer(
    name = "app_layer",
    srcs = {
        "/app/hello.txt": "hello.txt",
    },
)

# Build an image
image_manifest(
    name = "my_image",
    base = "@alpine",
    layers = [":app_layer"],
)

# Preferred: the same registry/repository/tag split as image_push. The loaded
# image name is reconstructed as "my-registry.example.com/my-app:latest".
image_load(
    name = "load",
    image = ":my_image",
    registry = "my-registry.example.com",
    repository = "my-app",
    tag = "latest",
)

# The rules_oci-compatible form still works: when loading into a daemon the image
# name is just a string, so a single fully-qualified tag (with no
# registry/repository) is used verbatim.
image_load(
    name = "load_legacy",
    image = ":my_image",
    tag = "my-app:latest",
)

# Load with multiple full-reference tags
image_load(
    name = "load_multi",
    image = ":my_image",
    tag_list = ["my-app:latest", "my-app:v1.0.0"],
)

# A registry that includes a port works like any other registry.
image_load(
    name = "load_with_port",
    image = ":my_image",
    registry = "docker.mycompany.tld:1234",
    repository = "my-app",
    tag = "latest",
)
```

Splitting the name into `registry` / `repository` / `tag` is optional and does
not change what a local daemon sees; it just keeps the load target aligned with
a matching `image_push`, making it easy to push the same image to a registry
later.

Then run:
```bash
# Load the image into your local daemon
bazel run //:load
```

## Image names

The loaded image name is exactly the name you configure. `rules_img` does not
apply Docker's reference normalization: nothing is prepended to the name, and
the `library/` namespace of Docker Hub official images is never added, so
`tag = "my-app:latest"` loads an image literally called `my-app:latest`. The one
thing filled in is the tag: a reference written without one is loaded as
`:latest`, because an untagged name is not something `docker load` accepts. A
name that cannot be a valid image reference fails the build rather than being
silently rewritten.

Note that a short name like `my-app:latest` is not a fully-qualified reference.
Tools that insist on one — most notably `docker` with the containerd image
store, which hides images whose name is not canonical — need a name that
includes a registry, e.g. `docker.io/library/my-app:latest` or the
`registry`/`repository` split above.

## Platform Selection

When running the load target, you can use the `--platform` flag to filter which platforms to load from multi-platform images:

```bash
# Load all platforms (default)
bazel run //path/to:load_target

# Load only linux/amd64
bazel run //path/to:load_target -- --platform linux/amd64
```

**Note**: Docker daemon only supports loading a single platform at a time. If multiple platforms are specified with Docker, an error will be returned.�A
"
	rules_imgimgmulti_deploy.bzl�Amulti_deploy�Deploys multiple container images in a single coordinated command.

Use `push_specs` and `load_specs` on your image targets to attach deployment
configuration directly, then reference the images in `operations`:

```python
load("@rules_img//img:image.bzl", "image_manifest")
load("@rules_img//img:push.bzl", "image_push_spec")
load("@rules_img//img:multi_deploy.bzl", "multi_deploy")

image_push_spec(
    name = "push_spec",
    registry = "gcr.io",
    repository = "my-project/{{.image_target_name}}",
    tag = "latest",
)

image_manifest(
    name = "frontend",
    base = "@distroless_cc",
    layers = [":frontend_layer"],
    push_specs = [":push_spec"],
)

image_manifest(
    name = "backend",
    base = "@distroless_cc",
    layers = [":backend_layer"],
    push_specs = [":push_spec"],
)

multi_deploy(
    name = "deploy_all",
    operations = [
        ":frontend",
        ":backend",
    ],
)
```

Alternatively, standalone `image_push` or `image_load` targets that already
provide `DeployInfo` can be used directly in `operations`, as can custom
targets that provide `MultipleDeployInfo` to contribute several deploy
operations at once.

`multi_deploy` has no push at build time of its own; it deploys at `bazel run`
time. When `push_at_build_time` is enabled, the `image_push` targets (or images
with `push_specs`) referenced here already push at build time on their own —
`multi_deploy` does not push them a second time.

Runtime usage:
```bash
bazel run //path/to:deploy_all
```"�5
� 
multi_deploy�Deploys multiple container images in a single coordinated command.

Use `push_specs` and `load_specs` on your image targets to attach deployment
configuration directly, then reference the images in `operations`:

```python
load("@rules_img//img:image.bzl", "image_manifest")
load("@rules_img//img:push.bzl", "image_push_spec")
load("@rules_img//img:multi_deploy.bzl", "multi_deploy")

image_push_spec(
    name = "push_spec",
    registry = "gcr.io",
    repository = "my-project/{{.image_target_name}}",
    tag = "latest",
)

image_manifest(
    name = "frontend",
    base = "@distroless_cc",
    layers = [":frontend_layer"],
    push_specs = [":push_spec"],
)

image_manifest(
    name = "backend",
    base = "@distroless_cc",
    layers = [":backend_layer"],
    push_specs = [":push_spec"],
)

multi_deploy(
    name = "deploy_all",
    operations = [
        ":frontend",
        ":backend",
    ],
)
```

Alternatively, standalone `image_push` or `image_load` targets that already
provide `DeployInfo` can be used directly in `operations`, as can custom
targets that provide `MultipleDeployInfo` to contribute several deploy
operations at once.

`multi_deploy` has no push at build time of its own; it deploys at `bazel run`
time. When `push_at_build_time` is enabled, the `image_push` targets (or images
with `push_specs`) referenced here already push at build time on their own —
`multi_deploy` does not push them a second time.

Runtime usage:
```bash
bazel run //path/to:deploy_all
```*
nameA unique name for this target. �

operations�List of operations to deploy together.

Each operation must provide DeployInfo (typically from image_push, image_load,
image_manifest with push_specs/load_specs, or image_index with push_specs/load_specs)
or MultipleDeployInfo (whose `infos` are expanded in place).
All operations will be merged and executed in the order specified.

A MultipleDeployInfo with no `infos` is allowed and results in a no-op instead of an error. *M

DeployInfo?

DeployInfo1@rules_img//img/private/providers:deploy_info.bzl*f
MultipleDeployInfoP
MultipleDeployInfo:@rules_img//img/private/providers:multiple_deploy_info.bzl*]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl*T
ImageIndexInfoB
ImageIndexInfo0@rules_img//img/private/providers:index_info.bzl�
push_strategy�Push strategy to use for all push operations in the deployment.

See [push strategies documentation](/docs/push-strategies.md) for detailed information.2"auto"J"auto"J"eager"J"lazy"J"cas_registry"J"bes"�
load_strategy�Load strategy to use for all load operations in the deployment.

Available strategies:
- **`auto`** (default): Uses the global default load strategy
- **`eager`**: Downloads all layers during the build phase
- **`lazy`**: Downloads layers only when needed during the load operation2"auto"J"auto"J"eager"J"lazy"�
deploy_operations�Which kinds of deploy operations to perform.

Acts as a filter when assembling the final deploy manifest from all `operations`:

- `"push"`: include push operations (and their associated registry tag operations).
- `"load"`: include load operations.

Defaults to `["push", "load"]`, performing every operation contributed by the
`operations` targets. Narrow it when your images carry both `push_specs` and
`load_specs` but a particular deployment should only push or only load -- for
example, `["push"]` to push without loading, or `["load"]` to load without pushing.2["push", "load"]�
tool_cfg�Configuration of the deployer executable platform.

Available options:
- **`host`** (default): Deployer executable matches the host platform.
- **`target`**: Deployer executable matches the target platform(s) specified via `--platforms`.2"host"J"host"J"target"�
deploy_tool�Optional label of a deploy tool target providing `DeployToolInfo` (created with `img_deploy_tool` from `@rules_img//img:deploy_tool.bzl`). When set, overrides `tool_cfg`.*Z
DeployToolInfoH
DeployToolInfo6@rules_img//img/private/providers:deploy_tool_info.bzl2None"8
multi_deploy(@rules_img//img/private:multi_deploy.bzl8,
*
nameA unique name for this target. �
�

operations�List of operations to deploy together.

Each operation must provide DeployInfo (typically from image_push, image_load,
image_manifest with push_specs/load_specs, or image_index with push_specs/load_specs)
or MultipleDeployInfo (whose `infos` are expanded in place).
All operations will be merged and executed in the order specified.

A MultipleDeployInfo with no `infos` is allowed and results in a no-op instead of an error. *M

DeployInfo?

DeployInfo1@rules_img//img/private/providers:deploy_info.bzl*f
MultipleDeployInfoP
MultipleDeployInfo:@rules_img//img/private/providers:multiple_deploy_info.bzl*]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl*T
ImageIndexInfoB
ImageIndexInfo0@rules_img//img/private/providers:index_info.bzl�
�
push_strategy�Push strategy to use for all push operations in the deployment.

See [push strategies documentation](/docs/push-strategies.md) for detailed information.2"auto"J"auto"J"eager"J"lazy"J"cas_registry"J"bes"�
�
load_strategy�Load strategy to use for all load operations in the deployment.

Available strategies:
- **`auto`** (default): Uses the global default load strategy
- **`eager`**: Downloads all layers during the build phase
- **`lazy`**: Downloads layers only when needed during the load operation2"auto"J"auto"J"eager"J"lazy"�
�
deploy_operations�Which kinds of deploy operations to perform.

Acts as a filter when assembling the final deploy manifest from all `operations`:

- `"push"`: include push operations (and their associated registry tag operations).
- `"load"`: include load operations.

Defaults to `["push", "load"]`, performing every operation contributed by the
`operations` targets. Narrow it when your images carry both `push_specs` and
`load_specs` but a particular deployment should only push or only load -- for
example, `["push"]` to push without loading, or `["load"]` to load without pushing.2["push", "load"]�
�
tool_cfg�Configuration of the deployer executable platform.

Available options:
- **`host`** (default): Deployer executable matches the host platform.
- **`target`**: Deployer executable matches the target platform(s) specified via `--platforms`.2"host"J"host"J"target"�
�
deploy_tool�Optional label of a deploy tool target providing `DeployToolInfo` (created with `img_deploy_tool` from `@rules_img//img:deploy_tool.bzl`). When set, overrides `tool_cfg`.*Z
DeployToolInfoH
DeployToolInfo6@rules_img//img/private/providers:deploy_tool_info.bzl2None1Public API for container image multi deploy rule.��

	rules_imgimgoras.bzl�*oras_file_layer�Creates an ORAS-compatible layer from a single file.

This macro wraps `layer_from_file` and adds standard ORAS annotations so the
resulting layer can be pushed to and pulled from OCI registries using ORAS
tooling. The `org.opencontainers.image.title` annotation is automatically
set to the base name of the source file (or overridden via the `title` attr).

Two modes are supported via the `kind` attribute:

- `"file"` (default): The source file is used as an opaque blob.
- `"directory"`: The source file is treated as a tar archive. ORAS clients
  will unpack it on pull. The `io.deis.oras.content.unpack` and
  `io.deis.oras.content.digest` annotations are set automatically.

Example:

```python
load("@rules_img//img:oras.bzl", "oras_file_layer")

# Push a single file as an ORAS artifact
oras_file_layer(
    name = "readme_layer",
    src = "README.md",
    media_type = "text/plain",
)

# Push a tar archive that ORAS clients will unpack
oras_file_layer(
    name = "docs_layer",
    src = ":docs.tar.gz",
    kind = "directory",
)
```Z�"
�
oras_file_layer�Creates an ORAS-compatible layer from a single file.

This macro wraps `layer_from_file` and adds standard ORAS annotations so the
resulting layer can be pushed to and pulled from OCI registries using ORAS
tooling. The `org.opencontainers.image.title` annotation is automatically
set to the base name of the source file (or overridden via the `title` attr).

Two modes are supported via the `kind` attribute:

- `"file"` (default): The source file is used as an opaque blob.
- `"directory"`: The source file is treated as a tar archive. ORAS clients
  will unpack it on pull. The `io.deis.oras.content.unpack` and
  `io.deis.oras.content.digest` annotations are set automatically.

Example:

```python
load("@rules_img//img:oras.bzl", "oras_file_layer")

# Push a single file as an ORAS artifact
oras_file_layer(
    name = "readme_layer",
    src = "README.md",
    media_type = "text/plain",
)

# Push a tar archive that ORAS clients will unpack
oras_file_layer(
    name = "docs_layer",
    src = ":docs.tar.gz",
    kind = "directory",
)
```�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@�
titleyOptional override for org.opencontainers.image.title. If left empty, the title is derived from the base name of the blob.2""8�
kind|The kind of layer. "file" interprets the layer as-is, "directory" interprets the layer blob as a tar file containing a tree.2"file"8J"file"J"directory"S
annotations<Annotations to add to the layer metadata as key-value pairs.
2{}8
expect_failure2None@ 
transitive_configs2None8@
deprecation2None8@
tags2None8@
testonly2None8@
features2None@
compatible_with2None8@
restricted_to2None8@
package_metadata2None8@
aspect_hints2None@P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@
exec_properties
2None@"
exec_compatible_with2None8@(
exec_group_compatible_with2None8@Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@+
src The file to use as a layer blob. h

media_typeRLayer media type. Defaults to "application/vnd.oci.image.layer.v1.tar" if not set.2None">
oras_file_layer+@rules_img//img/private:oras_file_layer.bzl�
�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �
�

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@�
�
titleyOptional override for org.opencontainers.image.title. If left empty, the title is derived from the base name of the blob.2""8�
�
kind|The kind of layer. "file" interprets the layer as-is, "directory" interprets the layer blob as a tar file containing a tree.2"file"8J"file"J"directory"U
S
annotations<Annotations to add to the layer metadata as key-value pairs.
2{}8

expect_failure2None@"
 
transitive_configs2None8@

deprecation2None8@

tags2None8@

testonly2None8@

features2None@

compatible_with2None8@

restricted_to2None8@ 

package_metadata2None8@

aspect_hints2None@R
P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@

exec_properties
2None@$
"
exec_compatible_with2None8@*
(
exec_group_compatible_with2None8@\
Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@-
+
src The file to use as a layer blob. j
h

media_typeRLayer media type. Defaults to "application/vnd.oci.image.layer.v1.tar" if not set.2None��
oras_layer�Creates an ORAS-compatible layer from files and directories.

This macro wraps `image_layer` and adds standard ORAS annotations so the
resulting layer can be pushed to and pulled from OCI registries using ORAS
tooling:

- `org.opencontainers.image.title` is set to the `title` attribute (defaults
  to the target name).
- `io.deis.oras.content.unpack` is set to `"true"` so ORAS clients unpack the
  layer on pull.
- `io.deis.oras.content.digest` is automatically derived from the layer's diff
  ID after the tar is produced.

Example:

```python
load("@rules_img//img:oras.bzl", "oras_layer")

# Package application files as an ORAS artifact
oras_layer(
    name = "app_layer",
    srcs = {
        "/app/bin/server": "//cmd/server",
        "/app/config.json": ":config",
    },
)
```Z��
�Z

oras_layer�Creates an ORAS-compatible layer from files and directories.

This macro wraps `image_layer` and adds standard ORAS annotations so the
resulting layer can be pushed to and pulled from OCI registries using ORAS
tooling:

- `org.opencontainers.image.title` is set to the `title` attribute (defaults
  to the target name).
- `io.deis.oras.content.unpack` is set to `"true"` so ORAS clients unpack the
  layer on pull.
- `io.deis.oras.content.digest` is automatically derived from the layer's diff
  ID after the tar is produced.

Example:

```python
load("@rules_img//img:oras.bzl", "oras_layer")

# Package application files as an ORAS artifact
oras_layer(
    name = "app_layer",
    srcs = {
        "/app/bin/server": "//cmd/server",
        "/app/config.json": ":config",
    },
)
```�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@}
titlelOptional value for org.opencontainers.image.title. If left empty, the title is derived from the target name.2""8S
annotations<Annotations to add to the layer metadata as key-value pairs.
2{}8�
compress\Compression algorithm to use. If set to 'auto', uses the global default compression setting.2"gzip"J"auto"J"gzip"J"zstd"�
create_parent_directories�Whether to automatically create parent directory entries in the tar file for all files.
If set to 'auto', uses the global default create_parent_directories setting.
When enabled, parent directories will be created automatically for all files in the layer.2	"enabled"J"auto"J	"enabled"J
"disabled"
expect_failure2None@ 
transitive_configs2None8@
deprecation2None8@
tags2None8@
testonly2None8@
features2None@
compatible_with2None8@
restricted_to2None8@
package_metadata2None8@
aspect_hints2None@P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@
exec_properties
2None@"
exec_compatible_with2None8@(
exec_group_compatible_with2None8@Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@�
srcs�Files to include in the layer. Keys are paths in the image (e.g., "/app/bin/server"),
values are labels to files or executables.

When a value is an executable, the executable is placed at the path key and its runfiles tree is
included (unless include_runfiles is set to False). Any additional default outputs of the target
(the rest of `DefaultInfo.files` beyond the executable) are also copied, each placed at the same
location relative to the executable that it has in the source tree. Outputs that live above the
executable need a path key deep enough to hold them; `extra_default_outputs` decides what happens
to the ones that don't fit (by default they are dropped).

When a value is a non-executable target that produces more than one default output, the path key is
treated as a directory and the outputs are placed inside it according to `multi_file_layout`. A path
key that ends with "/" is always treated as a directory, even when the target produces exactly one
output.2None
symlinkskSymlinks to create in the layer. Keys are symlink paths in the image,
values are the targets they point to.
2None�
multi_file_layout�How to place a non-executable src that produces MORE THAN ONE default output.

- `"package_relative"` (default): treat the path key as a directory and place each file inside it,
  preserving its path relative to the producing target's package.
- `"flatten"`: place each file directly in the directory by basename (restores the older behavior).

A src that produces a single output is placed exactly at its path key, regardless of this
setting. To opt out of that shortcut, end the path key with "/": it then always denotes a
directory, and a single output is laid out inside it just like multiple outputs would be.2NoneJ"package_relative"J	"flatten"�
default_metadata�JSON-encoded default metadata to apply to all files in the layer.
Can include fields like mode, uid, gid, uname, gname, mtime, and pax_records.
Applies to regular files (including tree contents) and symlinks. Generated
directories inherit only mtime; use file_metadata for directory modes or ownership.2None�
file_metadata�Per-file metadata overrides as a dict mapping file paths to JSON-encoded metadata.
The path should match the path in the image, including paths inside directory inputs.
Directory paths should omit the trailing slash.
Metadata specified here overrides any defaults from default_metadata.
2None�
history�Overrides the `created_by` history entry recorded for this layer.

By default the layer records one entry, "bazel build <label>", so two layers
with identical contents but different labels have different config digests.
`history = []` records no history entry, so identical contents give identical
config digests regardless of label. A single-element list is recorded verbatim.
The img tool records at most one history entry per layer, so longer lists are
rejected.2None�
format�Container format of the layer blob, orthogonal to `compress`.

'tar' writes an OCI tar changeset. 'erofs' writes a mountable EROFS filesystem image. 'ext4' and 'fat32' write an
ext4 or FAT32 filesystem image, 'iso9660' an ISO 9660 image (with the Rock Ridge, Joliet and UDF extensions and
El Torito boot entries as options), 'cpio' a cpio archive in the newc format (an initramfs). If set to 'auto', uses the global default
--@rules_img//img/settings:layer_format setting.

An EROFS layer is a filesystem, not a changeset. See docs/erofs-layers.md before using it.

See docs/filesystems.md for how the formats compare.2NoneJ"auto"J"tar"J"erofs"J"ext4"J"fat32"J	"iso9660"J"cpio"�
format_config�Options of the filesystem image the layer is written as: an `ext4_config` target
for `format = "ext4"`, a `fat32_config` target for `format = "fat32"`, an `iso9660_config` target for `format = "iso9660"`,
a `cpio_config` target for `format = "cpio"`, or an `erofs_config`
target for `format = "erofs"`.

Without it, every option of the format is left at its default. A config for a
format other than the layer's own is a configuration error, since it would
silently have no effect.*\
Ext4ConfigInfoJ
Ext4ConfigInfo8@rules_img//img/private/providers:format_config_info.bzl*^
Fat32ConfigInfoK
Fat32ConfigInfo8@rules_img//img/private/providers:format_config_info.bzl*b
Iso9660ConfigInfoM
Iso9660ConfigInfo8@rules_img//img/private/providers:format_config_info.bzl*\
CpioConfigInfoJ
CpioConfigInfo8@rules_img//img/private/providers:format_config_info.bzl*^
ErofsConfigInfoK
ErofsConfigInfo8@rules_img//img/private/providers:format_config_info.bzl2None�
estargz�Whether to use estargz format. If set to 'auto', uses the global default estargz setting.
When enabled, the layer will be optimized for lazy pulling and will be compatible with the estargz format.2NoneJ"auto"J	"enabled"J
"disabled"�
zstd_chunked�Whether to use the zstd:chunked format. If set to 'auto', uses the global default zstd_chunked setting.
When enabled, the layer is written with content-defined chunks and a table of contents, so
compatible runtimes (podman, CRI-O) can fetch and deduplicate individual chunks.
Requires zstd compression and cannot be combined with estargz.2NoneJ"auto"J	"enabled"J
"disabled"�
soci�Whether to emit a SOCI ztoc (table of contents) for this layer. If set to 'auto',
uses the global default //img/settings:soci setting. When enabled and the layer is
gzip-compressed, a ztoc is produced in the layer action and recorded on the
SingleLayerInfo provider, so images that build a SOCI Index Manifest v2 can reuse
it instead of regenerating it. Non-gzip layers never emit a ztoc.2NoneJ"auto"J	"enabled"J
"disabled"�
tree_artifact_handling�How to handle duplicate tree artifacts (directories) in the layer.
If set to 'full', each tree artifact is stored at its intended path (no deduplication).
If set to 'deduplicate_symlink', duplicate tree artifacts are replaced with symlinks to the first occurrence.
If set to 'auto', uses the global default from --@rules_img//img/settings:layer_tree_artifact_handling.
When file metadata is configured, trees are stored in full so path-specific metadata
is preserved. Regular files with identical contents and metadata still deduplicate.2NoneJ"auto"J"full"J"deduplicate_symlink"�
include_runfiles�Whether to include runfiles for executable targets.
When True (default), executables in srcs will include their runfiles tree.
When False, only the executable file itself is included, without runfiles.

Either way, any additional default outputs of the target (the rest of `DefaultInfo.files`
beyond the executable) are copied into the layer, placed relative to the executable,
as configured by `extra_default_outputs`.2None�
extra_default_outputs�How to handle an executable's additional default outputs (the rest of `DefaultInfo.files`
beyond the executable itself).

Those files are placed at the same offset relative to the executable that they have in the
source tree, so a file that lives above the executable's directory needs a path in the image
that is deep enough to place it. This setting decides what happens when it isn't:

- `"best_effort"` (default): place every additional default output that fits, and silently
  drop the ones that would land above the image root. This is what wrapper rules such as
  bazel-lib's `transition_binary` need, where the executable is a symlink in a sibling
  directory of the real outputs.
- `"drop"`: never place additional default outputs. Only the executable itself (and its
  runfiles, if `include_runfiles` is True) is included.
- `"strict"`: place every additional default output, and fail the build if any of them
  would land above the image root.2NoneJ"best_effort"J"drop"J"strict"�
annotations_file�File containing annotations for the layer, as JSON or newline-delimited text.

The file is parsed in one of the following formats, auto-detected from its contents:

- JSON object with string values: `{"key": "value"}`
- JSON object with list values: `{"key": ["value1", "value2"]}` (the last value wins)
- JSON array of `KEY=VALUE` strings: `["key=value"]`
- newline-delimited `KEY=VALUE` text (one per line; blank lines and `#` comments are ignored)

Values in JSON objects are used verbatim, so they can encode arbitrary strings including
values that contain `=`, spaces, or newlines. The `KEY=VALUE` forms (JSON array and text)
split on the first `=` and trim surrounding whitespace from the key and value.

Annotations from this file are merged with annotations specified via the `annotations`
attribute, which take precedence for matching keys.

Example file content:
```
version=1.0.0
build.date=2024-01-15
source.url=https://github.com/...
```2None�

media_typejOverride the layer media type. By default, the media type is auto-detected from the compression algorithm.2None"4

oras_layer&@rules_img//img/private:oras_layer.bzl�
�
name�A unique name for this macro instance. Normally, this is also the name for the macro's main or only target. The names of any other targets that this macro might create will be this name with a string suffix. �
�

visibility�The visibility to be passed to this macro's exported targets. It always implicitly includes the location where this macro is instantiated, so this attribute only needs to be explicitly set if you want the macro's targets to be additionally visible somewhere else.8@
}
titlelOptional value for org.opencontainers.image.title. If left empty, the title is derived from the target name.2""8U
S
annotations<Annotations to add to the layer metadata as key-value pairs.
2{}8�
�
compress\Compression algorithm to use. If set to 'auto', uses the global default compression setting.2"gzip"J"auto"J"gzip"J"zstd"�
�
create_parent_directories�Whether to automatically create parent directory entries in the tar file for all files.
If set to 'auto', uses the global default create_parent_directories setting.
When enabled, parent directories will be created automatically for all files in the layer.2	"enabled"J"auto"J	"enabled"J
"disabled"

expect_failure2None@"
 
transitive_configs2None8@

deprecation2None8@

tags2None8@

testonly2None8@

features2None@

compatible_with2None8@

restricted_to2None8@ 

package_metadata2None8@

aspect_hints2None@R
P

toolchains*8
TemplateVariableInfo 
TemplateVariableInfo<native>2None@

exec_properties
2None@$
"
exec_compatible_with2None8@*
(
exec_group_compatible_with2None8@\
Z
target_compatible_with*6
ConstraintValueInfo
ConstraintValueInfo<native>2None@�
�
srcs�Files to include in the layer. Keys are paths in the image (e.g., "/app/bin/server"),
values are labels to files or executables.

When a value is an executable, the executable is placed at the path key and its runfiles tree is
included (unless include_runfiles is set to False). Any additional default outputs of the target
(the rest of `DefaultInfo.files` beyond the executable) are also copied, each placed at the same
location relative to the executable that it has in the source tree. Outputs that live above the
executable need a path key deep enough to hold them; `extra_default_outputs` decides what happens
to the ones that don't fit (by default they are dropped).

When a value is a non-executable target that produces more than one default output, the path key is
treated as a directory and the outputs are placed inside it according to `multi_file_layout`. A path
key that ends with "/" is always treated as a directory, even when the target produces exactly one
output.2None�

symlinkskSymlinks to create in the layer. Keys are symlink paths in the image,
values are the targets they point to.
2None�
�
multi_file_layout�How to place a non-executable src that produces MORE THAN ONE default output.

- `"package_relative"` (default): treat the path key as a directory and place each file inside it,
  preserving its path relative to the producing target's package.
- `"flatten"`: place each file directly in the directory by basename (restores the older behavior).

A src that produces a single output is placed exactly at its path key, regardless of this
setting. To opt out of that shortcut, end the path key with "/": it then always denotes a
directory, and a single output is laid out inside it just like multiple outputs would be.2NoneJ"package_relative"J	"flatten"�
�
default_metadata�JSON-encoded default metadata to apply to all files in the layer.
Can include fields like mode, uid, gid, uname, gname, mtime, and pax_records.
Applies to regular files (including tree contents) and symlinks. Generated
directories inherit only mtime; use file_metadata for directory modes or ownership.2None�
�
file_metadata�Per-file metadata overrides as a dict mapping file paths to JSON-encoded metadata.
The path should match the path in the image, including paths inside directory inputs.
Directory paths should omit the trailing slash.
Metadata specified here overrides any defaults from default_metadata.
2None�
�
history�Overrides the `created_by` history entry recorded for this layer.

By default the layer records one entry, "bazel build <label>", so two layers
with identical contents but different labels have different config digests.
`history = []` records no history entry, so identical contents give identical
config digests regardless of label. A single-element list is recorded verbatim.
The img tool records at most one history entry per layer, so longer lists are
rejected.2None�
�
format�Container format of the layer blob, orthogonal to `compress`.

'tar' writes an OCI tar changeset. 'erofs' writes a mountable EROFS filesystem image. 'ext4' and 'fat32' write an
ext4 or FAT32 filesystem image, 'iso9660' an ISO 9660 image (with the Rock Ridge, Joliet and UDF extensions and
El Torito boot entries as options), 'cpio' a cpio archive in the newc format (an initramfs). If set to 'auto', uses the global default
--@rules_img//img/settings:layer_format setting.

An EROFS layer is a filesystem, not a changeset. See docs/erofs-layers.md before using it.

See docs/filesystems.md for how the formats compare.2NoneJ"auto"J"tar"J"erofs"J"ext4"J"fat32"J	"iso9660"J"cpio"�
�
format_config�Options of the filesystem image the layer is written as: an `ext4_config` target
for `format = "ext4"`, a `fat32_config` target for `format = "fat32"`, an `iso9660_config` target for `format = "iso9660"`,
a `cpio_config` target for `format = "cpio"`, or an `erofs_config`
target for `format = "erofs"`.

Without it, every option of the format is left at its default. A config for a
format other than the layer's own is a configuration error, since it would
silently have no effect.*\
Ext4ConfigInfoJ
Ext4ConfigInfo8@rules_img//img/private/providers:format_config_info.bzl*^
Fat32ConfigInfoK
Fat32ConfigInfo8@rules_img//img/private/providers:format_config_info.bzl*b
Iso9660ConfigInfoM
Iso9660ConfigInfo8@rules_img//img/private/providers:format_config_info.bzl*\
CpioConfigInfoJ
CpioConfigInfo8@rules_img//img/private/providers:format_config_info.bzl*^
ErofsConfigInfoK
ErofsConfigInfo8@rules_img//img/private/providers:format_config_info.bzl2None�
�
estargz�Whether to use estargz format. If set to 'auto', uses the global default estargz setting.
When enabled, the layer will be optimized for lazy pulling and will be compatible with the estargz format.2NoneJ"auto"J	"enabled"J
"disabled"�
�
zstd_chunked�Whether to use the zstd:chunked format. If set to 'auto', uses the global default zstd_chunked setting.
When enabled, the layer is written with content-defined chunks and a table of contents, so
compatible runtimes (podman, CRI-O) can fetch and deduplicate individual chunks.
Requires zstd compression and cannot be combined with estargz.2NoneJ"auto"J	"enabled"J
"disabled"�
�
soci�Whether to emit a SOCI ztoc (table of contents) for this layer. If set to 'auto',
uses the global default //img/settings:soci setting. When enabled and the layer is
gzip-compressed, a ztoc is produced in the layer action and recorded on the
SingleLayerInfo provider, so images that build a SOCI Index Manifest v2 can reuse
it instead of regenerating it. Non-gzip layers never emit a ztoc.2NoneJ"auto"J	"enabled"J
"disabled"�
�
tree_artifact_handling�How to handle duplicate tree artifacts (directories) in the layer.
If set to 'full', each tree artifact is stored at its intended path (no deduplication).
If set to 'deduplicate_symlink', duplicate tree artifacts are replaced with symlinks to the first occurrence.
If set to 'auto', uses the global default from --@rules_img//img/settings:layer_tree_artifact_handling.
When file metadata is configured, trees are stored in full so path-specific metadata
is preserved. Regular files with identical contents and metadata still deduplicate.2NoneJ"auto"J"full"J"deduplicate_symlink"�
�
include_runfiles�Whether to include runfiles for executable targets.
When True (default), executables in srcs will include their runfiles tree.
When False, only the executable file itself is included, without runfiles.

Either way, any additional default outputs of the target (the rest of `DefaultInfo.files`
beyond the executable) are copied into the layer, placed relative to the executable,
as configured by `extra_default_outputs`.2None�
�
extra_default_outputs�How to handle an executable's additional default outputs (the rest of `DefaultInfo.files`
beyond the executable itself).

Those files are placed at the same offset relative to the executable that they have in the
source tree, so a file that lives above the executable's directory needs a path in the image
that is deep enough to place it. This setting decides what happens when it isn't:

- `"best_effort"` (default): place every additional default output that fits, and silently
  drop the ones that would land above the image root. This is what wrapper rules such as
  bazel-lib's `transition_binary` need, where the executable is a symlink in a sibling
  directory of the real outputs.
- `"drop"`: never place additional default outputs. Only the executable itself (and its
  runfiles, if `include_runfiles` is True) is included.
- `"strict"`: place every additional default output, and fail the build if any of them
  would land above the image root.2NoneJ"best_effort"J"drop"J"strict"�
�
annotations_file�File containing annotations for the layer, as JSON or newline-delimited text.

The file is parsed in one of the following formats, auto-detected from its contents:

- JSON object with string values: `{"key": "value"}`
- JSON object with list values: `{"key": ["value1", "value2"]}` (the last value wins)
- JSON array of `KEY=VALUE` strings: `["key=value"]`
- newline-delimited `KEY=VALUE` text (one per line; blank lines and `#` comments are ignored)

Values in JSON objects are used verbatim, so they can encode arbitrary strings including
values that contain `=`, spaces, or newlines. The `KEY=VALUE` forms (JSON array and text)
split on the first `=` and trim surrounding whitespace from the key and value.

Annotations from this file are merged with annotations specified via the `annotations`
attribute, which take precedence for matching keys.

Example file content:
```
version=1.0.0
build.date=2024-01-15
source.url=https://github.com/...
```2None�
�

media_typejOverride the layer media type. By default, the media type is auto-detected from the compression algorithm.2None$Public API for container oras rules.�c

	rules_imgimgpull.bzl�cpull�Pulls a container image from a registry using shallow pulling.

This repository rule implements shallow pulling - it only downloads the image manifest
and config, not the actual layer blobs. The layers are downloaded on-demand during
push operations or when explicitly needed. This significantly reduces bandwidth usage
and speeds up builds, especially for large base images.

Example usage in MODULE.bazel:
```starlark
pull = use_repo_rule("@rules_img//img:pull.bzl", "pull")

pull(
    name = "ubuntu",
    digest = "sha256:1e622c5f073b4f6bfad6632f2616c7f59ef256e96fe78bf6a595d1dc4376ac02",
    registry = "index.docker.io",
    repository = "library/ubuntu",
    tag = "24.04",
)
```

The `digest` parameter is recommended for reproducible builds. If omitted, the rule
will resolve the tag to a digest at fetch time and print a warning.

By default, all child manifests of a multi-platform image index are downloaded. Use the
`platforms` attribute to restrict the pull to the platforms you build for.R�[
�1
pull�Pulls a container image from a registry using shallow pulling.

This repository rule implements shallow pulling - it only downloads the image manifest
and config, not the actual layer blobs. The layers are downloaded on-demand during
push operations or when explicitly needed. This significantly reduces bandwidth usage
and speeds up builds, especially for large base images.

Example usage in MODULE.bazel:
```starlark
pull = use_repo_rule("@rules_img//img:pull.bzl", "pull")

pull(
    name = "ubuntu",
    digest = "sha256:1e622c5f073b4f6bfad6632f2616c7f59ef256e96fe78bf6a595d1dc4376ac02",
    registry = "index.docker.io",
    repository = "library/ubuntu",
    tag = "24.04",
)
```

The `digest` parameter is recommended for reproducible builds. If omitted, the rule
will resolve the tag to a digest at fetch time and print a warning.

By default, all child manifests of a multi-platform image index are downloaded. Use the
`platforms` attribute to restrict the pull to the platforms you build for..
name"A unique name for this repository. �
registry�Primary registry to pull from (e.g., "index.docker.io", "gcr.io").

If not specified, defaults to Docker Hub. Can be overridden by entries in registries list.2""�

registries�List of mirror registries to try in order.

These registries will be tried in order before the primary registry. Useful for
corporate environments with registry mirrors or air-gapped setups.2[]�

repository�The image repository within the registry (e.g., "library/ubuntu", "my-project/my-image").

For Docker Hub, official images use "library/" prefix (e.g., "library/ubuntu"). �
tag�The image tag to pull (e.g., "latest", "24.04", "v1.2.3").

While required, it's recommended to also specify a digest for reproducible builds.2""�
digest�The image digest for reproducible pulls (e.g., "sha256:abc123...").

When specified, the image is pulled by digest instead of tag, ensuring reproducible
builds. The digest must be a full SHA256 digest starting with "sha256:".2""�
	platforms�Platforms to download from a multi-platform image index.

Each entry is an `"os/architecture"` or `"os/architecture/variant"` string
(e.g. `["linux/amd64", "linux/arm64"]`). Platforms are normalized before they are compared,
so `"linux/arm64"` also matches an index entry declaring `arm64` with variant `v8`. An entry
that names no variant matches every variant of that OS/architecture, so adding this
attribute never changes which child manifest a build ends up using - it only drops the
platforms you did not list. Name a variant (`"linux/amd64/v3"`) to select just that one.

If omitted (the default), every child manifest of the index is downloaded. Since a registry
counts each child manifest as a separate pull, restricting the list to the platforms you
actually build for can cut a cold fetch of a typical multi-arch base image from tens of
requests to a handful. Attestation manifests (which buildkit publishes with the platform
`unknown/unknown`) are dropped unless `"unknown/unknown"` is listed explicitly.

Fetching fails if a requested platform has no matching manifest in the index. The attribute
has no effect when pulling a single-platform image (the digest refers to that manifest, so
there is nothing to skip).

**Note:** the index blob is stored verbatim, so it keeps listing every platform while only
the selected children are available locally. A filtered image is meant to be used as a base
image; pushing or loading its unmodified index is not supported.2[]�
layer_handling�Strategy for handling image layers.

This attribute controls when and how layer data is fetched from the registry.

**Available strategies:**

* **`shallow`** (default): Layer data is fetched only if needed during push operations,
  but is not available during the build. This is the most efficient option for images
  that are only used as base images for pushing.

* **`eager`**: Layer data is fetched in the repository rule and is always available.
  This ensures layers are accessible in build actions but is inefficient as all layers
  are downloaded regardless of whether they're needed. Use this for base images that
  need to be read or inspected during the build.

* **`lazy`**: Layer data is downloaded in a build action when requested. This provides
  access to layers during builds while avoiding unnecessary downloads, but requires
  network access during the build phase. **EXPERIMENTAL:** Use at your own risk.2	"shallow"J	"shallow"J"eager"J"lazy"�

downloader�The tool to use for downloading manifests and blobs.

**Available options:**

* **`img_tool`** (default): Uses the `img` tool for all downloads.

* **`bazel`**: Uses Bazel's native HTTP capabilities for downloading manifests and blobs.2
"img_tool"J
"img_tool"J"bazel"�
credential_helper�Credential helper to use for registry authentication when this repository rule runs the pull tool.

If omitted, the pull tool inherits `$IMG_CREDENTIAL_HELPER` (or `$IMG_CREDENTIAL_HELPER_OCI_REGISTRY`, which takes precedence) when present.2""�
docker_config_path�Path to Docker-compatible registry authentication config.

If omitted, the pull tool inherits `$REGISTRY_AUTH_FILE` when present.2""�
timeout�Maximum duration in seconds of each download performed while fetching this repository.

**Only takes effect when `downloader` is `img_tool`**, since it is applied to the `img` tool
invocations this rule runs. Bazel's own downloader cannot be given a timeout from a repository
rule, so this attribute is ignored when `downloader` is `bazel` (scale Bazel's built-in HTTP
timeouts with `--http_timeout_scaling` instead).

Defaults to `0`, which leaves the timeout unset, so Bazel's default for executions in
repository rules (600 seconds) applies.20�
unsafe_allow_tag_without_digest�Allow pulling by tag without specifying a digest.

**WARNING:** This is not recommended for reproducible builds as tags can be moved
to point to different image versions. Only use this when you're managing reproducibility
through other means (e.g., content-based tags).

When enabled, the rule will resolve the tag to a digest at fetch time and use that
digest, but will not fail if no digest is explicitly provided.2False*9
pull1@rules_img//img/private/repository_rules:pull.bzl0
.
name"A unique name for this repository. �
�
registry�Primary registry to pull from (e.g., "index.docker.io", "gcr.io").

If not specified, defaults to Docker Hub. Can be overridden by entries in registries list.2""�
�

registries�List of mirror registries to try in order.

These registries will be tried in order before the primary registry. Useful for
corporate environments with registry mirrors or air-gapped setups.2[]�
�

repository�The image repository within the registry (e.g., "library/ubuntu", "my-project/my-image").

For Docker Hub, official images use "library/" prefix (e.g., "library/ubuntu"). �
�
tag�The image tag to pull (e.g., "latest", "24.04", "v1.2.3").

While required, it's recommended to also specify a digest for reproducible builds.2""�
�
digest�The image digest for reproducible pulls (e.g., "sha256:abc123...").

When specified, the image is pulled by digest instead of tag, ensuring reproducible
builds. The digest must be a full SHA256 digest starting with "sha256:".2""�
�
	platforms�Platforms to download from a multi-platform image index.

Each entry is an `"os/architecture"` or `"os/architecture/variant"` string
(e.g. `["linux/amd64", "linux/arm64"]`). Platforms are normalized before they are compared,
so `"linux/arm64"` also matches an index entry declaring `arm64` with variant `v8`. An entry
that names no variant matches every variant of that OS/architecture, so adding this
attribute never changes which child manifest a build ends up using - it only drops the
platforms you did not list. Name a variant (`"linux/amd64/v3"`) to select just that one.

If omitted (the default), every child manifest of the index is downloaded. Since a registry
counts each child manifest as a separate pull, restricting the list to the platforms you
actually build for can cut a cold fetch of a typical multi-arch base image from tens of
requests to a handful. Attestation manifests (which buildkit publishes with the platform
`unknown/unknown`) are dropped unless `"unknown/unknown"` is listed explicitly.

Fetching fails if a requested platform has no matching manifest in the index. The attribute
has no effect when pulling a single-platform image (the digest refers to that manifest, so
there is nothing to skip).

**Note:** the index blob is stored verbatim, so it keeps listing every platform while only
the selected children are available locally. A filtered image is meant to be used as a base
image; pushing or loading its unmodified index is not supported.2[]�
�
layer_handling�Strategy for handling image layers.

This attribute controls when and how layer data is fetched from the registry.

**Available strategies:**

* **`shallow`** (default): Layer data is fetched only if needed during push operations,
  but is not available during the build. This is the most efficient option for images
  that are only used as base images for pushing.

* **`eager`**: Layer data is fetched in the repository rule and is always available.
  This ensures layers are accessible in build actions but is inefficient as all layers
  are downloaded regardless of whether they're needed. Use this for base images that
  need to be read or inspected during the build.

* **`lazy`**: Layer data is downloaded in a build action when requested. This provides
  access to layers during builds while avoiding unnecessary downloads, but requires
  network access during the build phase. **EXPERIMENTAL:** Use at your own risk.2	"shallow"J	"shallow"J"eager"J"lazy"�
�

downloader�The tool to use for downloading manifests and blobs.

**Available options:**

* **`img_tool`** (default): Uses the `img` tool for all downloads.

* **`bazel`**: Uses Bazel's native HTTP capabilities for downloading manifests and blobs.2
"img_tool"J
"img_tool"J"bazel"�
�
credential_helper�Credential helper to use for registry authentication when this repository rule runs the pull tool.

If omitted, the pull tool inherits `$IMG_CREDENTIAL_HELPER` (or `$IMG_CREDENTIAL_HELPER_OCI_REGISTRY`, which takes precedence) when present.2""�
�
docker_config_path�Path to Docker-compatible registry authentication config.

If omitted, the pull tool inherits `$REGISTRY_AUTH_FILE` when present.2""�
�
timeout�Maximum duration in seconds of each download performed while fetching this repository.

**Only takes effect when `downloader` is `img_tool`**, since it is applied to the `img` tool
invocations this rule runs. Bazel's own downloader cannot be given a timeout from a repository
rule, so this attribute is ignored when `downloader` is `bazel` (scale Bazel's built-in HTTP
timeouts with `--http_timeout_scaling` instead).

Defaults to `0`, which leaves the timeout unset, so Bazel's default for executions in
repository rules (600 seconds) applies.20�
�
unsafe_allow_tag_without_digest�Allow pulling by tag without specifying a digest.

**WARNING:** This is not recommended for reproducible builds as tags can be moved
to point to different image versions. Only use this when you're managing reproducibility
through other means (e.g., content-based tags).

When enabled, the rule will resolve the tag to a digest at fetch time and use that
digest, but will not fail if no digest is explicitly provided.2False-Public API for pulling base container images.��

	rules_imgimgpush.bzl��
image_push�Pushes container images to a registry.

This rule creates an executable target that uploads OCI images to container registries.
It supports multiple push strategies optimized for different use cases, from simple
uploads to advanced content-addressable storage integration.

Key features:
- **Multiple push strategies**: Choose between eager, lazy, CAS-based, or BES-integrated pushing
- **Template expansion**: Dynamic registry, repository, and tag values using build settings
- **Stamping support**: Include build information in image tags
- **Incremental uploads**: Skip blobs that already exist in the registry

The rule produces an executable that can be run with `bazel run`.

Example:

```python
load("@rules_img//img:push.bzl", "image_push")

# Simple push to Docker Hub
image_push(
    name = "push_app",
    image = ":my_app",
    registry = "index.docker.io",
    repository = "myorg/myapp",
    tag = "latest",
)

# Push multi-platform image with multiple tags
image_push(
    name = "push_multiarch",
    image = ":my_app_index",  # References an image_index
    registry = "gcr.io",
    repository = "my-project/my-app",
    tag_list = ["latest", "v1.0.0"],
)

# Dynamic push with build settings
image_push(
    name = "push_dynamic",
    image = ":my_app",
    registry = "{{.REGISTRY}}",
    repository = "{{.PROJECT}}/my-app",
    tag = "{{.VERSION}}",
    build_settings = {
        "REGISTRY": "//settings:registry",
        "PROJECT": "//settings:project",
        "VERSION": "//settings:version",
    },
)

# Push with stamping for unique tags
image_push(
    name = "push_stamped",
    image = ":my_app",
    registry = "index.docker.io",
    repository = "myorg/myapp",
    tag = "latest-{{.BUILD_TIMESTAMP}}",
    stamp = "force",
)

# Digest-only push (no tag)
image_push(
    name = "push_by_digest",
    image = ":my_app",
    registry = "gcr.io",
    repository = "my-project/my-app",
    # No tag specified - will push by digest only
)

# Push using a destination file (instead of registry/repository attributes)
image_push(
    name = "push_from_file",
    image = ":my_app",
    destination_file = ":push_destination.txt",
    tag = "latest",
)
```

Push strategies:
- **`eager`**: Materializes all layers next to push binary. Simple, correct, but may be inefficient.
- **`lazy`**: Layers are not stored locally. Missing layers are streamed from Bazel's remote cache.
- **`cas_registry`**: Uses content-addressable storage for extreme efficiency. Requires
  CAS-enabled infrastructure.
- **`bes`**: Image is pushed as side-effect of Build Event Stream upload. No "bazel run" command needed.
  Requires Build Event Service integration.

See [push strategies documentation](/docs/push-strategies.md) for detailed comparisons.

Push at build time:

When the `push_at_build_time` setting is enabled, an `image_push` target also
uploads its image content to the registry *during the build* (via `PushImage`
actions), so the image is present without a separate `bazel run`. See
[push at build time](/docs/push-strategies.md#push-at-build-time).

Runtime usage:
```bash
# Push to registry
bazel run //path/to:push_app

# The push command will output the image digest
```"��
ɚ

image_push�Pushes container images to a registry.

This rule creates an executable target that uploads OCI images to container registries.
It supports multiple push strategies optimized for different use cases, from simple
uploads to advanced content-addressable storage integration.

Key features:
- **Multiple push strategies**: Choose between eager, lazy, CAS-based, or BES-integrated pushing
- **Template expansion**: Dynamic registry, repository, and tag values using build settings
- **Stamping support**: Include build information in image tags
- **Incremental uploads**: Skip blobs that already exist in the registry

The rule produces an executable that can be run with `bazel run`.

Example:

```python
load("@rules_img//img:push.bzl", "image_push")

# Simple push to Docker Hub
image_push(
    name = "push_app",
    image = ":my_app",
    registry = "index.docker.io",
    repository = "myorg/myapp",
    tag = "latest",
)

# Push multi-platform image with multiple tags
image_push(
    name = "push_multiarch",
    image = ":my_app_index",  # References an image_index
    registry = "gcr.io",
    repository = "my-project/my-app",
    tag_list = ["latest", "v1.0.0"],
)

# Dynamic push with build settings
image_push(
    name = "push_dynamic",
    image = ":my_app",
    registry = "{{.REGISTRY}}",
    repository = "{{.PROJECT}}/my-app",
    tag = "{{.VERSION}}",
    build_settings = {
        "REGISTRY": "//settings:registry",
        "PROJECT": "//settings:project",
        "VERSION": "//settings:version",
    },
)

# Push with stamping for unique tags
image_push(
    name = "push_stamped",
    image = ":my_app",
    registry = "index.docker.io",
    repository = "myorg/myapp",
    tag = "latest-{{.BUILD_TIMESTAMP}}",
    stamp = "force",
)

# Digest-only push (no tag)
image_push(
    name = "push_by_digest",
    image = ":my_app",
    registry = "gcr.io",
    repository = "my-project/my-app",
    # No tag specified - will push by digest only
)

# Push using a destination file (instead of registry/repository attributes)
image_push(
    name = "push_from_file",
    image = ":my_app",
    destination_file = ":push_destination.txt",
    tag = "latest",
)
```

Push strategies:
- **`eager`**: Materializes all layers next to push binary. Simple, correct, but may be inefficient.
- **`lazy`**: Layers are not stored locally. Missing layers are streamed from Bazel's remote cache.
- **`cas_registry`**: Uses content-addressable storage for extreme efficiency. Requires
  CAS-enabled infrastructure.
- **`bes`**: Image is pushed as side-effect of Build Event Stream upload. No "bazel run" command needed.
  Requires Build Event Service integration.

See [push strategies documentation](/docs/push-strategies.md) for detailed comparisons.

Push at build time:

When the `push_at_build_time` setting is enabled, an `image_push` target also
uploads its image content to the registry *during the build* (via `PushImage`
actions), so the image is present without a separate `bazel run`. See
[push at build time](/docs/push-strategies.md#push-at-build-time).

Runtime usage:
```bash
# Push to registry
bazel run //path/to:push_app

# The push command will output the image digest
```*
nameA unique name for this target. �
registry�Registry URL to push the image to.

Common registries:
- Docker Hub: `index.docker.io`
- Google Container Registry: `gcr.io` or `us.gcr.io`
- GitHub Container Registry: `ghcr.io`
- Amazon ECR: `123456789.dkr.ecr.us-east-1.amazonaws.com`

Subject to [template expansion](/docs/templating.md).2""o

repository[Repository path within the registry.

Subject to [template expansion](/docs/templating.md).2""�
tag�Tag to apply to the pushed image.

Optional - if omitted, the image is pushed by digest only.

Subject to [template expansion](/docs/templating.md).2""�
tag_list�List of tags to apply to the pushed image.

Useful for applying multiple tags in a single push:

```python
tag_list = ["latest", "v1.0.0", "stable"]
```

Cannot be used together with `tag`. Can be combined with `tag_file` to merge tags from both sources.
Each tag is subject to [template expansion](/docs/templating.md).2[]�

manifest_tags�
Per-platform tag templates for multi-platform (`image_index`) pushes.

Only valid when `image` provides `ImageIndexInfo`. For each entry in this list, the
deploy command produces one tag per child manifest in the index by expanding the
entry against the platform descriptor of that manifest.

Available template variables (lowercase):

- `{{.os}}` — platform OS (e.g. `linux`)
- `{{.architecture}}`, `{{.arch}}`, `{{.cpu}}` — architecture (e.g. `amd64`, `arm64`)
- `{{.variant}}` — architecture variant (e.g. `v8`), if set

The tags in `tag` / `tag_list` / `tag_file` continue to point at the index as a
whole; `manifest_tags` complement those by publishing additional tags that each
resolve to a single child manifest.

Example:

```python
image_push(
    name = "push_multiarch",
    image = ":my_app_index",
    registry = "gcr.io",
    repository = "my-project/my-app",
    tag_list = ["latest", "v1.0.0"],
    manifest_tags = [
        "latest-{{.os}}-{{.architecture}}",
        "v1.0.0-{{.os}}-{{.architecture}}",
    ],
)
```

Templates are expanded at build time per child manifest, so `build_settings`
and stamping variables are available (and override any platform variable of
the same name). The expanded tags are emitted as `registry_tag` operations
in the deploy manifest, so non-CLI strategies like `bes` can honor them.2[]�
tag_file�File containing newline-delimited tags to apply to the pushed image.

The file should contain one tag per line. Empty lines are ignored. Tags from this file
are merged with tags specified via `tag` or `tag_list` attributes.

Example file content:
```
latest
v1.0.0
stable
```

Can be combined with `tag` or `tag_list` to merge tags from multiple sources.
Each tag is subject to [template expansion](/docs/templating.md).2None�
destination_file�File containing the push destination as `{registry}/{repository}`.

The file should contain a single line with the registry and repository separated by
the first `/`. For example: `gcr.io/my-project/my-app`.

The content is read as a literal string without Go template expansion. Trailing
newlines and whitespace are stripped.

Cannot be used together with `registry` or `repository` attributes.2None�
	referrers�Additional manifests or indexes to push as referrers to the main image.

Each referrer is pushed to the same registry and repository as the main image,
but without tags (referrers are discovered via the OCI referrers API by digest).

Each target must provide ImageManifestInfo or ImageIndexInfo and must have its
`subject` field set to reference the main image being pushed.

Example:
```python
image_push(
    name = "push",
    image = ":my_app",
    referrers = [
        ":sbom_manifest",
        ":signature_manifest",
    ],
    registry = "ghcr.io",
    repository = "myorg/myapp",
    tag = "latest",
)
```*]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl*T
ImageIndexInfoB
ImageIndexInfo0@rules_img//img/private/providers:index_info.bzl2[]�
cross_mount_fromCAn image_push target whose layers may be cross-mounted during push.*M

DeployInfo?

DeployInfo1@rules_img//img/private/providers:deploy_info.bzl2None�
strategynPush strategy to use.

See [push strategies documentation](/docs/push-strategies.md) for detailed information.2"auto"J"auto"J"eager"J"lazy"J"cas_registry"J"bes"�
build_settings�Build settings for template expansion.

Maps template variable names to string_flag targets. These values can be used in
registry, repository, and tag attributes using `{{.VARIABLE_NAME}}` syntax (Go template).

Example:
```python
build_settings = {
    "REGISTRY": "//settings:docker_registry",
    "VERSION": "//settings:app_version",
}
```

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"J"auto"J"force"J
"disabled"�
tracks_content�When True, the template expansion action depends on the image digest.

A template string built from a volatile stamp value (e.g. `{{.BUILD_TIMESTAMP}}`) normally
freezes on the first build, because Bazel excludes the volatile workspace-status
file from the action cache key. With this enabled, the image descriptor becomes
an input to the tag-expansion action, so the tag re-stamps whenever the image
content (digest) changes, while unchanged content keeps the cached tag.

The digest is exposed to the `registry`, `repository`, and `tag` templates
as `{{.digest}}`. Referencing the digest in the tag is optional: the re-stamp
behavior applies whether or not the tag contains it.2False�
sign�Whether `img deploy` signs this image after pushing.

- **`auto`** (default): defer to the global `--@rules_img//img/settings:sign` flag.
- **`enabled`**: always sign; a signing failure (or missing `sign_setting`) fails the deploy.
- **`best_effort`**: sign if possible; failures are warnings and do not fail the deploy.
- **`disabled`**: never sign.

The signing plugin is selected by `sign_setting` (or the global
`//img/settings:sign_setting`). Signatures are attached as OCI referrers.2"auto"J"auto"J	"enabled"J
"disabled"J"best_effort"�
sign_setting�A `signing_config` target selecting how this image is signed.

Overrides the global `--@rules_img//img/settings:sign_setting`. Only consulted
when signing is enabled (see `sign`).*c
SigningConfigInfoN
SigningConfigInfo9@rules_img//img/private/providers:signing_config_info.bzl2None�
push_at_build_time�Whether image content is pushed to the registry *during the build*.

Push at build time wires extra `PushImage` build actions (one per blob, plus a
manifest push unless the content is `blobs`) that upload directly to the registry.
Their outputs go into the `push_at_build_time` output group and, unless
`--@rules_img//img/settings:push_at_build_time_output_group` says otherwise, are
also wired as a Bazel validation action. See
[push at build time](/docs/push-strategies.md#push-at-build-time).

- **`auto`** (default): defer to the global `--@rules_img//img/settings:push_at_build_time` flag.
- **`enabled`**: always push at build time; a push failure fails the build.
- **`best_effort`**: push at build time, but a push failure is a warning and does not fail the build.
- **`disabled`**: never push at build time.

When `disabled`, blob cross-mounting via `push_at_build_time_blob_repository` is
also not recorded in the deploy manifest, so a later `bazel run` deploy does not
try to cross-mount from a staging repository nothing was pushed to.2"auto"J"auto"J
"disabled"J"best_effort"J	"enabled"�
push_at_build_time_content�What the push-at-build-time actions upload.

- **`auto`** (default): defer to the global `--@rules_img//img/settings:push_at_build_time_content` flag.
- **`blobs`**: push only the layer blobs and the config blob. Manifests/tags are
  written afterwards by `image_push` / `multi_deploy`.
- **`blobs_and_manifests`**: push the blobs plus the config and manifest(s), but
  only by digest: no tag is written at build time, so tagging stays with
  `image_push` / `multi_deploy`.
- **`all`**: push the blobs plus the config and manifest(s)/tags, so the image is
  fully present in the registry (and tagged) when the build finishes.

Only consulted when push at build time is active (see `push_at_build_time`).2"auto"J"auto"J"blobs"J"blobs_and_manifests"J"all"�
"push_at_build_time_blob_repository�Staging repository for build-time blob uploads and cross-mounting.

When non-empty, every image blob (all layers and the config) is pushed to this
repository (a "staging" repository within the destination registry) and
cross-mounted from there when the manifest is pushed to its real repository.

Left at its sentinel default, this defers to the global
`--@rules_img//img/settings:push_at_build_time_blob_repository` flag. Set it to a
string to override per target, or to `""` to force "no staging repository" even
when the global flag is set.

Only takes effect when push at build time is active (see `push_at_build_time`):
if push at build time is `disabled` for this target, no cross-mount source is
recorded in the deploy manifest even when this is set.2"<use global setting>"�
&push_at_build_time_manifest_repository�Repository the build-time manifest push writes manifest(s)/config to.

When non-empty and `push_at_build_time_content` pushes manifests
(`blobs_and_manifests` or `all`), the build-time manifest push uploads the
manifest(s)/index (and, directly, the config) to this repository instead of the
image's real repository. This only redirects where manifests are written at build
time; it does **not** change where
layer blobs are cross-mounted from (that is `push_at_build_time_blob_repository`).

Left at its sentinel default, this defers to the global
`--@rules_img//img/settings:push_at_build_time_manifest_repository` flag. Set it
to a string to override per target, or to `""` to force the image's real
repository even when the global flag is set.2"<use global setting>"�
forbid_layer_push�Whether `img deploy` is forbidden from uploading layer blob bytes.

When `enabled`, a `bazel run` deploy of this push may only cross-mount layers
server-side or skip layers already present; an actual layer upload fails loudly.
Use it together with push at build time (which uploads the layer blobs) so a
deploy that would re-upload them is caught instead of silently succeeding.

- **`auto`** (default): defer to the global `--@rules_img//img/settings:forbid_layer_push` flag.
- **`enabled`**: forbid layer blob uploads.
- **`disabled`**: allow layer blob uploads.2"auto"J"auto"J
"disabled"J	"enabled"�
deduplicated_push�Whether `img deploy` uploads a blob several repositories need only once.

When `enabled`, the deploy first asks the registry which manifests it already
holds, then uploads each remaining layer that more than one destination repository
needs to just one of them — the first alphabetically — and cross-mounts it into the
others. Meant for registries that keep a separate blob store per repository name,
where pushing several images that share their layers otherwise uploads every shared
layer once per repository. See
[deduplicated push](/docs/push-strategies.md#deduplicated-push).

**`enabled` only works on a registry that supports cross-repository blob mounting.**
A push that opted in fails loudly where mounting is refused, rather than silently
uploading the blob into every repository. See the
[registry support matrix](/docs/registry-support.md).

- **`auto`** (default): defer to the global `--@rules_img//img/settings:deduplicated_push` flag.
- **`enabled`**: deduplicate blob uploads, and fail the push if a layer this deploy
  uploaded to a home repository cannot be cross-mounted from there.
- **`best_effort`**: deduplicate blob uploads, but upload a layer's bytes the ordinary
  way if the registry refuses to mount it (and treat a failed upload to a home
  repository as a warning). The deduplication is attempted without the deploy
  depending on it, which is what makes it usable on a registry you have not probed.
- **`disabled`**: push each manifest independently.

The setting travels with this push operation, so a deploy that merges several of
them (`multi_deploy`, or an image with several `push_specs`) can mix the two: the
operations that opted in are planned together and cross-mount between each other,
while the rest are pushed exactly as they would be with the setting off.2"auto"J"auto"J
"disabled"J"best_effort"J	"enabled"�
!deduplicated_push_blob_repository�Repository the deduplicated push uploads this target's shared blobs to.

When non-empty, every blob the deduplicated push shares between repositories is
uploaded to this repository (within the destination registry) and cross-mounted from
there. It takes precedence over every home repository the deploy would have picked
itself — including a repository the registry already serves the blob from — so that
shared blobs all end up in one place: one repository to retain and clean up, and one
repository a credential has to be able to read for the mounts to work. The cost is
that blobs which were mountable for free are uploaded there.

Left at its sentinel default, this defers to the global
`--@rules_img//img/settings:deduplicated_push_blob_repository` flag. Set it to a
string to override per target, or to `""` to force "no pinned repository" even when
the global flag is set.

Only consulted when deduplicated push is active (see `deduplicated_push`).2"<use global setting>"�	
deduplicated_push_content�What the deduplicated push writes to a shared blob's home repository.

- **`auto`** (default): defer to the global `--@rules_img//img/settings:deduplicated_push_content` flag.
- **`blobs`**: upload the shared blob to its home repository and nothing else.
- **`blobs_and_artificial_manifests`**: additionally upload a config blob and create a
  manifest referencing the blob and that config in the home repository, before the blob
  counts as available to the repositories that share it. For registries that only expose
  a blob to other repositories once a manifest references it: with the manifest in place
  the blob is served to every repository the caller may read, so the manifest push finds
  it there and uploads nothing — with or without a cross-mount.

The artificial manifest is a real single-layer image manifest (the layer descriptor is
the blob's own and the config records the layer's diff id), pushed by digest and
untagged. Note that a registry policy which deletes untagged manifests can undo the
blob's visibility along with it.

Only consulted when deduplicated push is active (see `deduplicated_push`).2"auto"J"auto"J"blobs"J "blobs_and_artificial_manifests"�
"push_at_build_time_exec_properties�Execution properties for the `PushImage` build-time push actions.

Forwarded verbatim as the `execution_requirements` of every `PushImage` action
emitted for this target. Defaults to `{"requires-network": "1"}` because the push
actions talk to the registry (and are therefore non-hermetic). Override it to add
or replace execution properties, for example to route the actions to a specific
remote execution pool. Setting it to `{}` removes the `requires-network` marker.

Only consulted when push at build time is active (see `push_at_build_time`).
27{"requires-network": "1", "supports-path-mapping": "1"}O
imageBImage to push. Should provide ImageManifestInfo or ImageIndexInfo. �
tool_cfg�Configuration of the pusher executable platform.

Available options:
- **`host`** (default): Pusher executable matches the host platform.
- **`target`**: Pusher executable matches the target platform(s) specified via `--platforms`.2"host"J"host"J"target"�
deploy_tool�Optional label of a deploy tool target providing `DeployToolInfo` (created with `img_deploy_tool` from `@rules_img//img:deploy_tool.bzl`). When set, overrides `tool_cfg`.*Z
DeployToolInfoH
DeployToolInfo6@rules_img//img/private/providers:deploy_tool_info.bzl2None".

image_push @rules_img//img/private:push.bzl8,
*
nameA unique name for this target. �
�
registry�Registry URL to push the image to.

Common registries:
- Docker Hub: `index.docker.io`
- Google Container Registry: `gcr.io` or `us.gcr.io`
- GitHub Container Registry: `ghcr.io`
- Amazon ECR: `123456789.dkr.ecr.us-east-1.amazonaws.com`

Subject to [template expansion](/docs/templating.md).2""q
o

repository[Repository path within the registry.

Subject to [template expansion](/docs/templating.md).2""�
�
tag�Tag to apply to the pushed image.

Optional - if omitted, the image is pushed by digest only.

Subject to [template expansion](/docs/templating.md).2""�
�
tag_list�List of tags to apply to the pushed image.

Useful for applying multiple tags in a single push:

```python
tag_list = ["latest", "v1.0.0", "stable"]
```

Cannot be used together with `tag`. Can be combined with `tag_file` to merge tags from both sources.
Each tag is subject to [template expansion](/docs/templating.md).2[]�

�

manifest_tags�
Per-platform tag templates for multi-platform (`image_index`) pushes.

Only valid when `image` provides `ImageIndexInfo`. For each entry in this list, the
deploy command produces one tag per child manifest in the index by expanding the
entry against the platform descriptor of that manifest.

Available template variables (lowercase):

- `{{.os}}` — platform OS (e.g. `linux`)
- `{{.architecture}}`, `{{.arch}}`, `{{.cpu}}` — architecture (e.g. `amd64`, `arm64`)
- `{{.variant}}` — architecture variant (e.g. `v8`), if set

The tags in `tag` / `tag_list` / `tag_file` continue to point at the index as a
whole; `manifest_tags` complement those by publishing additional tags that each
resolve to a single child manifest.

Example:

```python
image_push(
    name = "push_multiarch",
    image = ":my_app_index",
    registry = "gcr.io",
    repository = "my-project/my-app",
    tag_list = ["latest", "v1.0.0"],
    manifest_tags = [
        "latest-{{.os}}-{{.architecture}}",
        "v1.0.0-{{.os}}-{{.architecture}}",
    ],
)
```

Templates are expanded at build time per child manifest, so `build_settings`
and stamping variables are available (and override any platform variable of
the same name). The expanded tags are emitted as `registry_tag` operations
in the deploy manifest, so non-CLI strategies like `bes` can honor them.2[]�
�
tag_file�File containing newline-delimited tags to apply to the pushed image.

The file should contain one tag per line. Empty lines are ignored. Tags from this file
are merged with tags specified via `tag` or `tag_list` attributes.

Example file content:
```
latest
v1.0.0
stable
```

Can be combined with `tag` or `tag_list` to merge tags from multiple sources.
Each tag is subject to [template expansion](/docs/templating.md).2None�
�
destination_file�File containing the push destination as `{registry}/{repository}`.

The file should contain a single line with the registry and repository separated by
the first `/`. For example: `gcr.io/my-project/my-app`.

The content is read as a literal string without Go template expansion. Trailing
newlines and whitespace are stripped.

Cannot be used together with `registry` or `repository` attributes.2None�
�
	referrers�Additional manifests or indexes to push as referrers to the main image.

Each referrer is pushed to the same registry and repository as the main image,
but without tags (referrers are discovered via the OCI referrers API by digest).

Each target must provide ImageManifestInfo or ImageIndexInfo and must have its
`subject` field set to reference the main image being pushed.

Example:
```python
image_push(
    name = "push",
    image = ":my_app",
    referrers = [
        ":sbom_manifest",
        ":signature_manifest",
    ],
    registry = "ghcr.io",
    repository = "myorg/myapp",
    tag = "latest",
)
```*]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl*T
ImageIndexInfoB
ImageIndexInfo0@rules_img//img/private/providers:index_info.bzl2[]�
�
cross_mount_fromCAn image_push target whose layers may be cross-mounted during push.*M

DeployInfo?

DeployInfo1@rules_img//img/private/providers:deploy_info.bzl2None�
�
strategynPush strategy to use.

See [push strategies documentation](/docs/push-strategies.md) for detailed information.2"auto"J"auto"J"eager"J"lazy"J"cas_registry"J"bes"�
�
build_settings�Build settings for template expansion.

Maps template variable names to string_flag targets. These values can be used in
registry, repository, and tag attributes using `{{.VARIABLE_NAME}}` syntax (Go template).

Example:
```python
build_settings = {
    "REGISTRY": "//settings:docker_registry",
    "VERSION": "//settings:app_version",
}
```

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"J"auto"J"force"J
"disabled"�
�
tracks_content�When True, the template expansion action depends on the image digest.

A template string built from a volatile stamp value (e.g. `{{.BUILD_TIMESTAMP}}`) normally
freezes on the first build, because Bazel excludes the volatile workspace-status
file from the action cache key. With this enabled, the image descriptor becomes
an input to the tag-expansion action, so the tag re-stamps whenever the image
content (digest) changes, while unchanged content keeps the cached tag.

The digest is exposed to the `registry`, `repository`, and `tag` templates
as `{{.digest}}`. Referencing the digest in the tag is optional: the re-stamp
behavior applies whether or not the tag contains it.2False�
�
sign�Whether `img deploy` signs this image after pushing.

- **`auto`** (default): defer to the global `--@rules_img//img/settings:sign` flag.
- **`enabled`**: always sign; a signing failure (or missing `sign_setting`) fails the deploy.
- **`best_effort`**: sign if possible; failures are warnings and do not fail the deploy.
- **`disabled`**: never sign.

The signing plugin is selected by `sign_setting` (or the global
`//img/settings:sign_setting`). Signatures are attached as OCI referrers.2"auto"J"auto"J	"enabled"J
"disabled"J"best_effort"�
�
sign_setting�A `signing_config` target selecting how this image is signed.

Overrides the global `--@rules_img//img/settings:sign_setting`. Only consulted
when signing is enabled (see `sign`).*c
SigningConfigInfoN
SigningConfigInfo9@rules_img//img/private/providers:signing_config_info.bzl2None�
�
push_at_build_time�Whether image content is pushed to the registry *during the build*.

Push at build time wires extra `PushImage` build actions (one per blob, plus a
manifest push unless the content is `blobs`) that upload directly to the registry.
Their outputs go into the `push_at_build_time` output group and, unless
`--@rules_img//img/settings:push_at_build_time_output_group` says otherwise, are
also wired as a Bazel validation action. See
[push at build time](/docs/push-strategies.md#push-at-build-time).

- **`auto`** (default): defer to the global `--@rules_img//img/settings:push_at_build_time` flag.
- **`enabled`**: always push at build time; a push failure fails the build.
- **`best_effort`**: push at build time, but a push failure is a warning and does not fail the build.
- **`disabled`**: never push at build time.

When `disabled`, blob cross-mounting via `push_at_build_time_blob_repository` is
also not recorded in the deploy manifest, so a later `bazel run` deploy does not
try to cross-mount from a staging repository nothing was pushed to.2"auto"J"auto"J
"disabled"J"best_effort"J	"enabled"�
�
push_at_build_time_content�What the push-at-build-time actions upload.

- **`auto`** (default): defer to the global `--@rules_img//img/settings:push_at_build_time_content` flag.
- **`blobs`**: push only the layer blobs and the config blob. Manifests/tags are
  written afterwards by `image_push` / `multi_deploy`.
- **`blobs_and_manifests`**: push the blobs plus the config and manifest(s), but
  only by digest: no tag is written at build time, so tagging stays with
  `image_push` / `multi_deploy`.
- **`all`**: push the blobs plus the config and manifest(s)/tags, so the image is
  fully present in the registry (and tagged) when the build finishes.

Only consulted when push at build time is active (see `push_at_build_time`).2"auto"J"auto"J"blobs"J"blobs_and_manifests"J"all"�
�
"push_at_build_time_blob_repository�Staging repository for build-time blob uploads and cross-mounting.

When non-empty, every image blob (all layers and the config) is pushed to this
repository (a "staging" repository within the destination registry) and
cross-mounted from there when the manifest is pushed to its real repository.

Left at its sentinel default, this defers to the global
`--@rules_img//img/settings:push_at_build_time_blob_repository` flag. Set it to a
string to override per target, or to `""` to force "no staging repository" even
when the global flag is set.

Only takes effect when push at build time is active (see `push_at_build_time`):
if push at build time is `disabled` for this target, no cross-mount source is
recorded in the deploy manifest even when this is set.2"<use global setting>"�
�
&push_at_build_time_manifest_repository�Repository the build-time manifest push writes manifest(s)/config to.

When non-empty and `push_at_build_time_content` pushes manifests
(`blobs_and_manifests` or `all`), the build-time manifest push uploads the
manifest(s)/index (and, directly, the config) to this repository instead of the
image's real repository. This only redirects where manifests are written at build
time; it does **not** change where
layer blobs are cross-mounted from (that is `push_at_build_time_blob_repository`).

Left at its sentinel default, this defers to the global
`--@rules_img//img/settings:push_at_build_time_manifest_repository` flag. Set it
to a string to override per target, or to `""` to force the image's real
repository even when the global flag is set.2"<use global setting>"�
�
forbid_layer_push�Whether `img deploy` is forbidden from uploading layer blob bytes.

When `enabled`, a `bazel run` deploy of this push may only cross-mount layers
server-side or skip layers already present; an actual layer upload fails loudly.
Use it together with push at build time (which uploads the layer blobs) so a
deploy that would re-upload them is caught instead of silently succeeding.

- **`auto`** (default): defer to the global `--@rules_img//img/settings:forbid_layer_push` flag.
- **`enabled`**: forbid layer blob uploads.
- **`disabled`**: allow layer blob uploads.2"auto"J"auto"J
"disabled"J	"enabled"�
�
deduplicated_push�Whether `img deploy` uploads a blob several repositories need only once.

When `enabled`, the deploy first asks the registry which manifests it already
holds, then uploads each remaining layer that more than one destination repository
needs to just one of them — the first alphabetically — and cross-mounts it into the
others. Meant for registries that keep a separate blob store per repository name,
where pushing several images that share their layers otherwise uploads every shared
layer once per repository. See
[deduplicated push](/docs/push-strategies.md#deduplicated-push).

**`enabled` only works on a registry that supports cross-repository blob mounting.**
A push that opted in fails loudly where mounting is refused, rather than silently
uploading the blob into every repository. See the
[registry support matrix](/docs/registry-support.md).

- **`auto`** (default): defer to the global `--@rules_img//img/settings:deduplicated_push` flag.
- **`enabled`**: deduplicate blob uploads, and fail the push if a layer this deploy
  uploaded to a home repository cannot be cross-mounted from there.
- **`best_effort`**: deduplicate blob uploads, but upload a layer's bytes the ordinary
  way if the registry refuses to mount it (and treat a failed upload to a home
  repository as a warning). The deduplication is attempted without the deploy
  depending on it, which is what makes it usable on a registry you have not probed.
- **`disabled`**: push each manifest independently.

The setting travels with this push operation, so a deploy that merges several of
them (`multi_deploy`, or an image with several `push_specs`) can mix the two: the
operations that opted in are planned together and cross-mount between each other,
while the rest are pushed exactly as they would be with the setting off.2"auto"J"auto"J
"disabled"J"best_effort"J	"enabled"�
�
!deduplicated_push_blob_repository�Repository the deduplicated push uploads this target's shared blobs to.

When non-empty, every blob the deduplicated push shares between repositories is
uploaded to this repository (within the destination registry) and cross-mounted from
there. It takes precedence over every home repository the deploy would have picked
itself — including a repository the registry already serves the blob from — so that
shared blobs all end up in one place: one repository to retain and clean up, and one
repository a credential has to be able to read for the mounts to work. The cost is
that blobs which were mountable for free are uploaded there.

Left at its sentinel default, this defers to the global
`--@rules_img//img/settings:deduplicated_push_blob_repository` flag. Set it to a
string to override per target, or to `""` to force "no pinned repository" even when
the global flag is set.

Only consulted when deduplicated push is active (see `deduplicated_push`).2"<use global setting>"�	
�	
deduplicated_push_content�What the deduplicated push writes to a shared blob's home repository.

- **`auto`** (default): defer to the global `--@rules_img//img/settings:deduplicated_push_content` flag.
- **`blobs`**: upload the shared blob to its home repository and nothing else.
- **`blobs_and_artificial_manifests`**: additionally upload a config blob and create a
  manifest referencing the blob and that config in the home repository, before the blob
  counts as available to the repositories that share it. For registries that only expose
  a blob to other repositories once a manifest references it: with the manifest in place
  the blob is served to every repository the caller may read, so the manifest push finds
  it there and uploads nothing — with or without a cross-mount.

The artificial manifest is a real single-layer image manifest (the layer descriptor is
the blob's own and the config records the layer's diff id), pushed by digest and
untagged. Note that a registry policy which deletes untagged manifests can undo the
blob's visibility along with it.

Only consulted when deduplicated push is active (see `deduplicated_push`).2"auto"J"auto"J"blobs"J "blobs_and_artificial_manifests"�
�
"push_at_build_time_exec_properties�Execution properties for the `PushImage` build-time push actions.

Forwarded verbatim as the `execution_requirements` of every `PushImage` action
emitted for this target. Defaults to `{"requires-network": "1"}` because the push
actions talk to the registry (and are therefore non-hermetic). Override it to add
or replace execution properties, for example to route the actions to a specific
remote execution pool. Setting it to `{}` removes the `requires-network` marker.

Only consulted when push at build time is active (see `push_at_build_time`).
27{"requires-network": "1", "supports-path-mapping": "1"}Q
O
imageBImage to push. Should provide ImageManifestInfo or ImageIndexInfo. �
�
tool_cfg�Configuration of the pusher executable platform.

Available options:
- **`host`** (default): Pusher executable matches the host platform.
- **`target`**: Pusher executable matches the target platform(s) specified via `--platforms`.2"host"J"host"J"target"�
�
deploy_tool�Optional label of a deploy tool target providing `DeployToolInfo` (created with `img_deploy_tool` from `@rules_img//img:deploy_tool.bzl`). When set, overrides `tool_cfg`.*Z
DeployToolInfoH
DeployToolInfo6@rules_img//img/private/providers:deploy_tool_info.bzl2None��image_push_spec�Defines push configuration for container images without referencing a specific image.

This rule captures registry, repository, tag, and strategy settings that can be
attached to `image_manifest` or `image_index` targets via their `push_specs`
attribute. Template strings using Go template syntax (`{{.VAR}}`) are accepted
but not expanded — expansion happens when the deployment is consumed by the
image rule.
Note that the template strings `{{.image_target_package}}` and `{{.image_target_name}}` are especially useful here.

This enables an inverted dependency pattern: instead of `image_push` depending
on the image, the image itself carries its deployment configuration, making it
directly usable with `multi_deploy`.

Example:

```python
load("@rules_img//img:push.bzl", "image_push_spec")

image_push_spec(
    name = "push_config",
    registry = "gcr.io",
    repository = "my-project/{{.image_target_package}}/{{.image_target_name}}",
    tag = "{{.VERSION}}",
    build_settings = {
        "VERSION": "//settings:version",
    },
    stamp = "force",
)

# Attach to an image:
image_manifest(
    name = "my_app_a",
    base = "@distroless_cc",
    layers = [":app_layer"],
    push_specs = [":push_config"],
)

# Attach to another image:
image_manifest(
    name = "my_app_b",
    base = "@distroless_cc",
    layers = [":app_layer"],
    push_specs = [":push_config"],
)

# Now usable directly in multi_deploy:
multi_deploy(
    name = "deploy",
    operations = [
        ":my_app_a",
        ":my_app_b",
    ],
)
```"��
��
image_push_spec�Defines push configuration for container images without referencing a specific image.

This rule captures registry, repository, tag, and strategy settings that can be
attached to `image_manifest` or `image_index` targets via their `push_specs`
attribute. Template strings using Go template syntax (`{{.VAR}}`) are accepted
but not expanded — expansion happens when the deployment is consumed by the
image rule.
Note that the template strings `{{.image_target_package}}` and `{{.image_target_name}}` are especially useful here.

This enables an inverted dependency pattern: instead of `image_push` depending
on the image, the image itself carries its deployment configuration, making it
directly usable with `multi_deploy`.

Example:

```python
load("@rules_img//img:push.bzl", "image_push_spec")

image_push_spec(
    name = "push_config",
    registry = "gcr.io",
    repository = "my-project/{{.image_target_package}}/{{.image_target_name}}",
    tag = "{{.VERSION}}",
    build_settings = {
        "VERSION": "//settings:version",
    },
    stamp = "force",
)

# Attach to an image:
image_manifest(
    name = "my_app_a",
    base = "@distroless_cc",
    layers = [":app_layer"],
    push_specs = [":push_config"],
)

# Attach to another image:
image_manifest(
    name = "my_app_b",
    base = "@distroless_cc",
    layers = [":app_layer"],
    push_specs = [":push_config"],
)

# Now usable directly in multi_deploy:
multi_deploy(
    name = "deploy",
    operations = [
        ":my_app_a",
        ":my_app_b",
    ],
)
```*
nameA unique name for this target. �
registry�Registry URL to push the image to.

Common registries:
- Docker Hub: `index.docker.io`
- Google Container Registry: `gcr.io` or `us.gcr.io`
- GitHub Container Registry: `ghcr.io`
- Amazon ECR: `123456789.dkr.ecr.us-east-1.amazonaws.com`

Subject to [template expansion](/docs/templating.md).2""o

repository[Repository path within the registry.

Subject to [template expansion](/docs/templating.md).2""�
tag�Tag to apply to the pushed image.

Optional - if omitted, the image is pushed by digest only.

Subject to [template expansion](/docs/templating.md).2""�
tag_list�List of tags to apply to the pushed image.

Useful for applying multiple tags in a single push:

```python
tag_list = ["latest", "v1.0.0", "stable"]
```

Cannot be used together with `tag`. Can be combined with `tag_file` to merge tags from both sources.
Each tag is subject to [template expansion](/docs/templating.md).2[]�

manifest_tags�
Per-platform tag templates for multi-platform (`image_index`) pushes.

Only valid when `image` provides `ImageIndexInfo`. For each entry in this list, the
deploy command produces one tag per child manifest in the index by expanding the
entry against the platform descriptor of that manifest.

Available template variables (lowercase):

- `{{.os}}` — platform OS (e.g. `linux`)
- `{{.architecture}}`, `{{.arch}}`, `{{.cpu}}` — architecture (e.g. `amd64`, `arm64`)
- `{{.variant}}` — architecture variant (e.g. `v8`), if set

The tags in `tag` / `tag_list` / `tag_file` continue to point at the index as a
whole; `manifest_tags` complement those by publishing additional tags that each
resolve to a single child manifest.

Example:

```python
image_push(
    name = "push_multiarch",
    image = ":my_app_index",
    registry = "gcr.io",
    repository = "my-project/my-app",
    tag_list = ["latest", "v1.0.0"],
    manifest_tags = [
        "latest-{{.os}}-{{.architecture}}",
        "v1.0.0-{{.os}}-{{.architecture}}",
    ],
)
```

Templates are expanded at build time per child manifest, so `build_settings`
and stamping variables are available (and override any platform variable of
the same name). The expanded tags are emitted as `registry_tag` operations
in the deploy manifest, so non-CLI strategies like `bes` can honor them.2[]�
tag_file�File containing newline-delimited tags to apply to the pushed image.

The file should contain one tag per line. Empty lines are ignored. Tags from this file
are merged with tags specified via `tag` or `tag_list` attributes.

Example file content:
```
latest
v1.0.0
stable
```

Can be combined with `tag` or `tag_list` to merge tags from multiple sources.
Each tag is subject to [template expansion](/docs/templating.md).2None�
destination_file�File containing the push destination as `{registry}/{repository}`.

The file should contain a single line with the registry and repository separated by
the first `/`. For example: `gcr.io/my-project/my-app`.

The content is read as a literal string without Go template expansion. Trailing
newlines and whitespace are stripped.

Cannot be used together with `registry` or `repository` attributes.2None�
	referrers�Additional manifests or indexes to push as referrers to the main image.

Each referrer is pushed to the same registry and repository as the main image,
but without tags (referrers are discovered via the OCI referrers API by digest).

Each target must provide ImageManifestInfo or ImageIndexInfo and must have its
`subject` field set to reference the main image being pushed.

Example:
```python
image_push(
    name = "push",
    image = ":my_app",
    referrers = [
        ":sbom_manifest",
        ":signature_manifest",
    ],
    registry = "ghcr.io",
    repository = "myorg/myapp",
    tag = "latest",
)
```*]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl*T
ImageIndexInfoB
ImageIndexInfo0@rules_img//img/private/providers:index_info.bzl2[]�
cross_mount_fromCAn image_push target whose layers may be cross-mounted during push.*M

DeployInfo?

DeployInfo1@rules_img//img/private/providers:deploy_info.bzl2None�
strategynPush strategy to use.

See [push strategies documentation](/docs/push-strategies.md) for detailed information.2"auto"J"auto"J"eager"J"lazy"J"cas_registry"J"bes"�
build_settings�Build settings for template expansion.

Maps template variable names to string_flag targets. These values can be used in
registry, repository, and tag attributes using `{{.VARIABLE_NAME}}` syntax (Go template).

Example:
```python
build_settings = {
    "REGISTRY": "//settings:docker_registry",
    "VERSION": "//settings:app_version",
}
```

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"J"auto"J"force"J
"disabled"�
tracks_content�When True, the template expansion action depends on the image digest.

A template string built from a volatile stamp value (e.g. `{{.BUILD_TIMESTAMP}}`) normally
freezes on the first build, because Bazel excludes the volatile workspace-status
file from the action cache key. With this enabled, the image descriptor becomes
an input to the tag-expansion action, so the tag re-stamps whenever the image
content (digest) changes, while unchanged content keeps the cached tag.

The digest is exposed to the `registry`, `repository`, and `tag` templates
as `{{.digest}}`. Referencing the digest in the tag is optional: the re-stamp
behavior applies whether or not the tag contains it.2False�
sign�Whether `img deploy` signs this image after pushing.

- **`auto`** (default): defer to the global `--@rules_img//img/settings:sign` flag.
- **`enabled`**: always sign; a signing failure (or missing `sign_setting`) fails the deploy.
- **`best_effort`**: sign if possible; failures are warnings and do not fail the deploy.
- **`disabled`**: never sign.

The signing plugin is selected by `sign_setting` (or the global
`//img/settings:sign_setting`). Signatures are attached as OCI referrers.2"auto"J"auto"J	"enabled"J
"disabled"J"best_effort"�
sign_setting�A `signing_config` target selecting how this image is signed.

Overrides the global `--@rules_img//img/settings:sign_setting`. Only consulted
when signing is enabled (see `sign`).*c
SigningConfigInfoN
SigningConfigInfo9@rules_img//img/private/providers:signing_config_info.bzl2None�
push_at_build_time�Whether image content is pushed to the registry *during the build*.

Push at build time wires extra `PushImage` build actions (one per blob, plus a
manifest push unless the content is `blobs`) that upload directly to the registry.
Their outputs go into the `push_at_build_time` output group and, unless
`--@rules_img//img/settings:push_at_build_time_output_group` says otherwise, are
also wired as a Bazel validation action. See
[push at build time](/docs/push-strategies.md#push-at-build-time).

- **`auto`** (default): defer to the global `--@rules_img//img/settings:push_at_build_time` flag.
- **`enabled`**: always push at build time; a push failure fails the build.
- **`best_effort`**: push at build time, but a push failure is a warning and does not fail the build.
- **`disabled`**: never push at build time.

When `disabled`, blob cross-mounting via `push_at_build_time_blob_repository` is
also not recorded in the deploy manifest, so a later `bazel run` deploy does not
try to cross-mount from a staging repository nothing was pushed to.2"auto"J"auto"J
"disabled"J"best_effort"J	"enabled"�
push_at_build_time_content�What the push-at-build-time actions upload.

- **`auto`** (default): defer to the global `--@rules_img//img/settings:push_at_build_time_content` flag.
- **`blobs`**: push only the layer blobs and the config blob. Manifests/tags are
  written afterwards by `image_push` / `multi_deploy`.
- **`blobs_and_manifests`**: push the blobs plus the config and manifest(s), but
  only by digest: no tag is written at build time, so tagging stays with
  `image_push` / `multi_deploy`.
- **`all`**: push the blobs plus the config and manifest(s)/tags, so the image is
  fully present in the registry (and tagged) when the build finishes.

Only consulted when push at build time is active (see `push_at_build_time`).2"auto"J"auto"J"blobs"J"blobs_and_manifests"J"all"�
"push_at_build_time_blob_repository�Staging repository for build-time blob uploads and cross-mounting.

When non-empty, every image blob (all layers and the config) is pushed to this
repository (a "staging" repository within the destination registry) and
cross-mounted from there when the manifest is pushed to its real repository.

Left at its sentinel default, this defers to the global
`--@rules_img//img/settings:push_at_build_time_blob_repository` flag. Set it to a
string to override per target, or to `""` to force "no staging repository" even
when the global flag is set.

Only takes effect when push at build time is active (see `push_at_build_time`):
if push at build time is `disabled` for this target, no cross-mount source is
recorded in the deploy manifest even when this is set.2"<use global setting>"�
&push_at_build_time_manifest_repository�Repository the build-time manifest push writes manifest(s)/config to.

When non-empty and `push_at_build_time_content` pushes manifests
(`blobs_and_manifests` or `all`), the build-time manifest push uploads the
manifest(s)/index (and, directly, the config) to this repository instead of the
image's real repository. This only redirects where manifests are written at build
time; it does **not** change where
layer blobs are cross-mounted from (that is `push_at_build_time_blob_repository`).

Left at its sentinel default, this defers to the global
`--@rules_img//img/settings:push_at_build_time_manifest_repository` flag. Set it
to a string to override per target, or to `""` to force the image's real
repository even when the global flag is set.2"<use global setting>"�
forbid_layer_push�Whether `img deploy` is forbidden from uploading layer blob bytes.

When `enabled`, a `bazel run` deploy of this push may only cross-mount layers
server-side or skip layers already present; an actual layer upload fails loudly.
Use it together with push at build time (which uploads the layer blobs) so a
deploy that would re-upload them is caught instead of silently succeeding.

- **`auto`** (default): defer to the global `--@rules_img//img/settings:forbid_layer_push` flag.
- **`enabled`**: forbid layer blob uploads.
- **`disabled`**: allow layer blob uploads.2"auto"J"auto"J
"disabled"J	"enabled"�
deduplicated_push�Whether `img deploy` uploads a blob several repositories need only once.

When `enabled`, the deploy first asks the registry which manifests it already
holds, then uploads each remaining layer that more than one destination repository
needs to just one of them — the first alphabetically — and cross-mounts it into the
others. Meant for registries that keep a separate blob store per repository name,
where pushing several images that share their layers otherwise uploads every shared
layer once per repository. See
[deduplicated push](/docs/push-strategies.md#deduplicated-push).

**`enabled` only works on a registry that supports cross-repository blob mounting.**
A push that opted in fails loudly where mounting is refused, rather than silently
uploading the blob into every repository. See the
[registry support matrix](/docs/registry-support.md).

- **`auto`** (default): defer to the global `--@rules_img//img/settings:deduplicated_push` flag.
- **`enabled`**: deduplicate blob uploads, and fail the push if a layer this deploy
  uploaded to a home repository cannot be cross-mounted from there.
- **`best_effort`**: deduplicate blob uploads, but upload a layer's bytes the ordinary
  way if the registry refuses to mount it (and treat a failed upload to a home
  repository as a warning). The deduplication is attempted without the deploy
  depending on it, which is what makes it usable on a registry you have not probed.
- **`disabled`**: push each manifest independently.

The setting travels with this push operation, so a deploy that merges several of
them (`multi_deploy`, or an image with several `push_specs`) can mix the two: the
operations that opted in are planned together and cross-mount between each other,
while the rest are pushed exactly as they would be with the setting off.2"auto"J"auto"J
"disabled"J"best_effort"J	"enabled"�
!deduplicated_push_blob_repository�Repository the deduplicated push uploads this target's shared blobs to.

When non-empty, every blob the deduplicated push shares between repositories is
uploaded to this repository (within the destination registry) and cross-mounted from
there. It takes precedence over every home repository the deploy would have picked
itself — including a repository the registry already serves the blob from — so that
shared blobs all end up in one place: one repository to retain and clean up, and one
repository a credential has to be able to read for the mounts to work. The cost is
that blobs which were mountable for free are uploaded there.

Left at its sentinel default, this defers to the global
`--@rules_img//img/settings:deduplicated_push_blob_repository` flag. Set it to a
string to override per target, or to `""` to force "no pinned repository" even when
the global flag is set.

Only consulted when deduplicated push is active (see `deduplicated_push`).2"<use global setting>"�	
deduplicated_push_content�What the deduplicated push writes to a shared blob's home repository.

- **`auto`** (default): defer to the global `--@rules_img//img/settings:deduplicated_push_content` flag.
- **`blobs`**: upload the shared blob to its home repository and nothing else.
- **`blobs_and_artificial_manifests`**: additionally upload a config blob and create a
  manifest referencing the blob and that config in the home repository, before the blob
  counts as available to the repositories that share it. For registries that only expose
  a blob to other repositories once a manifest references it: with the manifest in place
  the blob is served to every repository the caller may read, so the manifest push finds
  it there and uploads nothing — with or without a cross-mount.

The artificial manifest is a real single-layer image manifest (the layer descriptor is
the blob's own and the config records the layer's diff id), pushed by digest and
untagged. Note that a registry policy which deletes untagged manifests can undo the
blob's visibility along with it.

Only consulted when deduplicated push is active (see `deduplicated_push`).2"auto"J"auto"J"blobs"J "blobs_and_artificial_manifests"�
"push_at_build_time_exec_properties�Execution properties for the `PushImage` build-time push actions.

Forwarded verbatim as the `execution_requirements` of every `PushImage` action
emitted for this target. Defaults to `{"requires-network": "1"}` because the push
actions talk to the registry (and are therefore non-hermetic). Override it to add
or replace execution properties, for example to route the actions to a specific
remote execution pool. Setting it to `{}` removes the `requires-network` marker.

Only consulted when push at build time is active (see `push_at_build_time`).
27{"requires-network": "1", "supports-path-mapping": "1"}"8
image_push_spec%@rules_img//img/private:push_spec.bzl*Z
PushConfigInfoH
PushConfigInfo6@rules_img//img/private/providers:push_config_info.bzl,
*
nameA unique name for this target. �
�
registry�Registry URL to push the image to.

Common registries:
- Docker Hub: `index.docker.io`
- Google Container Registry: `gcr.io` or `us.gcr.io`
- GitHub Container Registry: `ghcr.io`
- Amazon ECR: `123456789.dkr.ecr.us-east-1.amazonaws.com`

Subject to [template expansion](/docs/templating.md).2""q
o

repository[Repository path within the registry.

Subject to [template expansion](/docs/templating.md).2""�
�
tag�Tag to apply to the pushed image.

Optional - if omitted, the image is pushed by digest only.

Subject to [template expansion](/docs/templating.md).2""�
�
tag_list�List of tags to apply to the pushed image.

Useful for applying multiple tags in a single push:

```python
tag_list = ["latest", "v1.0.0", "stable"]
```

Cannot be used together with `tag`. Can be combined with `tag_file` to merge tags from both sources.
Each tag is subject to [template expansion](/docs/templating.md).2[]�

�

manifest_tags�
Per-platform tag templates for multi-platform (`image_index`) pushes.

Only valid when `image` provides `ImageIndexInfo`. For each entry in this list, the
deploy command produces one tag per child manifest in the index by expanding the
entry against the platform descriptor of that manifest.

Available template variables (lowercase):

- `{{.os}}` — platform OS (e.g. `linux`)
- `{{.architecture}}`, `{{.arch}}`, `{{.cpu}}` — architecture (e.g. `amd64`, `arm64`)
- `{{.variant}}` — architecture variant (e.g. `v8`), if set

The tags in `tag` / `tag_list` / `tag_file` continue to point at the index as a
whole; `manifest_tags` complement those by publishing additional tags that each
resolve to a single child manifest.

Example:

```python
image_push(
    name = "push_multiarch",
    image = ":my_app_index",
    registry = "gcr.io",
    repository = "my-project/my-app",
    tag_list = ["latest", "v1.0.0"],
    manifest_tags = [
        "latest-{{.os}}-{{.architecture}}",
        "v1.0.0-{{.os}}-{{.architecture}}",
    ],
)
```

Templates are expanded at build time per child manifest, so `build_settings`
and stamping variables are available (and override any platform variable of
the same name). The expanded tags are emitted as `registry_tag` operations
in the deploy manifest, so non-CLI strategies like `bes` can honor them.2[]�
�
tag_file�File containing newline-delimited tags to apply to the pushed image.

The file should contain one tag per line. Empty lines are ignored. Tags from this file
are merged with tags specified via `tag` or `tag_list` attributes.

Example file content:
```
latest
v1.0.0
stable
```

Can be combined with `tag` or `tag_list` to merge tags from multiple sources.
Each tag is subject to [template expansion](/docs/templating.md).2None�
�
destination_file�File containing the push destination as `{registry}/{repository}`.

The file should contain a single line with the registry and repository separated by
the first `/`. For example: `gcr.io/my-project/my-app`.

The content is read as a literal string without Go template expansion. Trailing
newlines and whitespace are stripped.

Cannot be used together with `registry` or `repository` attributes.2None�
�
	referrers�Additional manifests or indexes to push as referrers to the main image.

Each referrer is pushed to the same registry and repository as the main image,
but without tags (referrers are discovered via the OCI referrers API by digest).

Each target must provide ImageManifestInfo or ImageIndexInfo and must have its
`subject` field set to reference the main image being pushed.

Example:
```python
image_push(
    name = "push",
    image = ":my_app",
    referrers = [
        ":sbom_manifest",
        ":signature_manifest",
    ],
    registry = "ghcr.io",
    repository = "myorg/myapp",
    tag = "latest",
)
```*]
ImageManifestInfoH
ImageManifestInfo3@rules_img//img/private/providers:manifest_info.bzl*T
ImageIndexInfoB
ImageIndexInfo0@rules_img//img/private/providers:index_info.bzl2[]�
�
cross_mount_fromCAn image_push target whose layers may be cross-mounted during push.*M

DeployInfo?

DeployInfo1@rules_img//img/private/providers:deploy_info.bzl2None�
�
strategynPush strategy to use.

See [push strategies documentation](/docs/push-strategies.md) for detailed information.2"auto"J"auto"J"eager"J"lazy"J"cas_registry"J"bes"�
�
build_settings�Build settings for template expansion.

Maps template variable names to string_flag targets. These values can be used in
registry, repository, and tag attributes using `{{.VARIABLE_NAME}}` syntax (Go template).

Example:
```python
build_settings = {
    "REGISTRY": "//settings:docker_registry",
    "VERSION": "//settings:app_version",
}
```

See [template expansion](/docs/templating.md) for more details.*P
BuildSettingInfo<
BuildSettingInfo(@bazel_skylib//rules:common_settings.bzl2{}�
�
stamp�Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.2"auto"J"auto"J"force"J
"disabled"�
�
tracks_content�When True, the template expansion action depends on the image digest.

A template string built from a volatile stamp value (e.g. `{{.BUILD_TIMESTAMP}}`) normally
freezes on the first build, because Bazel excludes the volatile workspace-status
file from the action cache key. With this enabled, the image descriptor becomes
an input to the tag-expansion action, so the tag re-stamps whenever the image
content (digest) changes, while unchanged content keeps the cached tag.

The digest is exposed to the `registry`, `repository`, and `tag` templates
as `{{.digest}}`. Referencing the digest in the tag is optional: the re-stamp
behavior applies whether or not the tag contains it.2False�
�
sign�Whether `img deploy` signs this image after pushing.

- **`auto`** (default): defer to the global `--@rules_img//img/settings:sign` flag.
- **`enabled`**: always sign; a signing failure (or missing `sign_setting`) fails the deploy.
- **`best_effort`**: sign if possible; failures are warnings and do not fail the deploy.
- **`disabled`**: never sign.

The signing plugin is selected by `sign_setting` (or the global
`//img/settings:sign_setting`). Signatures are attached as OCI referrers.2"auto"J"auto"J	"enabled"J
"disabled"J"best_effort"�
�
sign_setting�A `signing_config` target selecting how this image is signed.

Overrides the global `--@rules_img//img/settings:sign_setting`. Only consulted
when signing is enabled (see `sign`).*c
SigningConfigInfoN
SigningConfigInfo9@rules_img//img/private/providers:signing_config_info.bzl2None�
�
push_at_build_time�Whether image content is pushed to the registry *during the build*.

Push at build time wires extra `PushImage` build actions (one per blob, plus a
manifest push unless the content is `blobs`) that upload directly to the registry.
Their outputs go into the `push_at_build_time` output group and, unless
`--@rules_img//img/settings:push_at_build_time_output_group` says otherwise, are
also wired as a Bazel validation action. See
[push at build time](/docs/push-strategies.md#push-at-build-time).

- **`auto`** (default): defer to the global `--@rules_img//img/settings:push_at_build_time` flag.
- **`enabled`**: always push at build time; a push failure fails the build.
- **`best_effort`**: push at build time, but a push failure is a warning and does not fail the build.
- **`disabled`**: never push at build time.

When `disabled`, blob cross-mounting via `push_at_build_time_blob_repository` is
also not recorded in the deploy manifest, so a later `bazel run` deploy does not
try to cross-mount from a staging repository nothing was pushed to.2"auto"J"auto"J
"disabled"J"best_effort"J	"enabled"�
�
push_at_build_time_content�What the push-at-build-time actions upload.

- **`auto`** (default): defer to the global `--@rules_img//img/settings:push_at_build_time_content` flag.
- **`blobs`**: push only the layer blobs and the config blob. Manifests/tags are
  written afterwards by `image_push` / `multi_deploy`.
- **`blobs_and_manifests`**: push the blobs plus the config and manifest(s), but
  only by digest: no tag is written at build time, so tagging stays with
  `image_push` / `multi_deploy`.
- **`all`**: push the blobs plus the config and manifest(s)/tags, so the image is
  fully present in the registry (and tagged) when the build finishes.

Only consulted when push at build time is active (see `push_at_build_time`).2"auto"J"auto"J"blobs"J"blobs_and_manifests"J"all"�
�
"push_at_build_time_blob_repository�Staging repository for build-time blob uploads and cross-mounting.

When non-empty, every image blob (all layers and the config) is pushed to this
repository (a "staging" repository within the destination registry) and
cross-mounted from there when the manifest is pushed to its real repository.

Left at its sentinel default, this defers to the global
`--@rules_img//img/settings:push_at_build_time_blob_repository` flag. Set it to a
string to override per target, or to `""` to force "no staging repository" even
when the global flag is set.

Only takes effect when push at build time is active (see `push_at_build_time`):
if push at build time is `disabled` for this target, no cross-mount source is
recorded in the deploy manifest even when this is set.2"<use global setting>"�
�
&push_at_build_time_manifest_repository�Repository the build-time manifest push writes manifest(s)/config to.

When non-empty and `push_at_build_time_content` pushes manifests
(`blobs_and_manifests` or `all`), the build-time manifest push uploads the
manifest(s)/index (and, directly, the config) to this repository instead of the
image's real repository. This only redirects where manifests are written at build
time; it does **not** change where
layer blobs are cross-mounted from (that is `push_at_build_time_blob_repository`).

Left at its sentinel default, this defers to the global
`--@rules_img//img/settings:push_at_build_time_manifest_repository` flag. Set it
to a string to override per target, or to `""` to force the image's real
repository even when the global flag is set.2"<use global setting>"�
�
forbid_layer_push�Whether `img deploy` is forbidden from uploading layer blob bytes.

When `enabled`, a `bazel run` deploy of this push may only cross-mount layers
server-side or skip layers already present; an actual layer upload fails loudly.
Use it together with push at build time (which uploads the layer blobs) so a
deploy that would re-upload them is caught instead of silently succeeding.

- **`auto`** (default): defer to the global `--@rules_img//img/settings:forbid_layer_push` flag.
- **`enabled`**: forbid layer blob uploads.
- **`disabled`**: allow layer blob uploads.2"auto"J"auto"J
"disabled"J	"enabled"�
�
deduplicated_push�Whether `img deploy` uploads a blob several repositories need only once.

When `enabled`, the deploy first asks the registry which manifests it already
holds, then uploads each remaining layer that more than one destination repository
needs to just one of them — the first alphabetically — and cross-mounts it into the
others. Meant for registries that keep a separate blob store per repository name,
where pushing several images that share their layers otherwise uploads every shared
layer once per repository. See
[deduplicated push](/docs/push-strategies.md#deduplicated-push).

**`enabled` only works on a registry that supports cross-repository blob mounting.**
A push that opted in fails loudly where mounting is refused, rather than silently
uploading the blob into every repository. See the
[registry support matrix](/docs/registry-support.md).

- **`auto`** (default): defer to the global `--@rules_img//img/settings:deduplicated_push` flag.
- **`enabled`**: deduplicate blob uploads, and fail the push if a layer this deploy
  uploaded to a home repository cannot be cross-mounted from there.
- **`best_effort`**: deduplicate blob uploads, but upload a layer's bytes the ordinary
  way if the registry refuses to mount it (and treat a failed upload to a home
  repository as a warning). The deduplication is attempted without the deploy
  depending on it, which is what makes it usable on a registry you have not probed.
- **`disabled`**: push each manifest independently.

The setting travels with this push operation, so a deploy that merges several of
them (`multi_deploy`, or an image with several `push_specs`) can mix the two: the
operations that opted in are planned together and cross-mount between each other,
while the rest are pushed exactly as they would be with the setting off.2"auto"J"auto"J
"disabled"J"best_effort"J	"enabled"�
�
!deduplicated_push_blob_repository�Repository the deduplicated push uploads this target's shared blobs to.

When non-empty, every blob the deduplicated push shares between repositories is
uploaded to this repository (within the destination registry) and cross-mounted from
there. It takes precedence over every home repository the deploy would have picked
itself — including a repository the registry already serves the blob from — so that
shared blobs all end up in one place: one repository to retain and clean up, and one
repository a credential has to be able to read for the mounts to work. The cost is
that blobs which were mountable for free are uploaded there.

Left at its sentinel default, this defers to the global
`--@rules_img//img/settings:deduplicated_push_blob_repository` flag. Set it to a
string to override per target, or to `""` to force "no pinned repository" even when
the global flag is set.

Only consulted when deduplicated push is active (see `deduplicated_push`).2"<use global setting>"�	
�	
deduplicated_push_content�What the deduplicated push writes to a shared blob's home repository.

- **`auto`** (default): defer to the global `--@rules_img//img/settings:deduplicated_push_content` flag.
- **`blobs`**: upload the shared blob to its home repository and nothing else.
- **`blobs_and_artificial_manifests`**: additionally upload a config blob and create a
  manifest referencing the blob and that config in the home repository, before the blob
  counts as available to the repositories that share it. For registries that only expose
  a blob to other repositories once a manifest references it: with the manifest in place
  the blob is served to every repository the caller may read, so the manifest push finds
  it there and uploads nothing — with or without a cross-mount.

The artificial manifest is a real single-layer image manifest (the layer descriptor is
the blob's own and the config records the layer's diff id), pushed by digest and
untagged. Note that a registry policy which deletes untagged manifests can undo the
blob's visibility along with it.

Only consulted when deduplicated push is active (see `deduplicated_push`).2"auto"J"auto"J"blobs"J "blobs_and_artificial_manifests"�
�
"push_at_build_time_exec_properties�Execution properties for the `PushImage` build-time push actions.

Forwarded verbatim as the `execution_requirements` of every `PushImage` action
emitted for this target. Defaults to `{"requires-network": "1"}` because the push
actions talk to the registry (and are therefore non-hermetic). Override it to add
or replace execution properties, for example to route the actions to a specific
remote execution pool. Setting it to `{}` removes the `requires-network` marker.

Only consulted when push at build time is active (see `push_at_build_time`).
27{"requires-network": "1", "supports-path-mapping": "1"}*Public API for container image push rules.�%

	rules_imgimgsigning.bzl�#signing_config�
Describes how `img deploy` signs images by invoking a signer plugin.

`img deploy` runs the plugin as `<tool> sign-oci-artifact [args...]`, writes the
JSON descriptor of the artifact to sign to the plugin's stdin, and expects an OCI
image layout tar (the signature artifact) on stdout. The signature is then
pushed to the image's repository as an OCI referrer. `img` itself performs no
cryptography; all signing logic lives in the plugin.

The plugin is referenced either as a Bazel executable (`tool`, shipped in the
push binary's runfiles) or as a host-installed command (`tool_command`, resolved
on `$PATH` at deploy time). Secrets and signing hardware are provided by the
environment `bazel run` executes in — never by Bazel.

Example:

```python
load("@rules_img//img:signing.bzl", "signing_config")

# Use a Bazel-built plugin.
signing_config(
    name = "notary",
    tool = "@rules_img//img/signer:notation",
    args = ["--key", "release"],
)

# Use a host-installed tool.
signing_config(
    name = "corp",
    tool_command = "corp-signer",
    args = ["--profile", "prod"],
)
```

Referenced globally via `--@rules_img//img/settings:sign_setting=//path:notary`,
or per target via the `sign_setting` attribute of `image_push`/`image_push_spec`.
Signing is enabled with the `sign` attribute or the `//img/settings:sign` flag."�
�
signing_config�
Describes how `img deploy` signs images by invoking a signer plugin.

`img deploy` runs the plugin as `<tool> sign-oci-artifact [args...]`, writes the
JSON descriptor of the artifact to sign to the plugin's stdin, and expects an OCI
image layout tar (the signature artifact) on stdout. The signature is then
pushed to the image's repository as an OCI referrer. `img` itself performs no
cryptography; all signing logic lives in the plugin.

The plugin is referenced either as a Bazel executable (`tool`, shipped in the
push binary's runfiles) or as a host-installed command (`tool_command`, resolved
on `$PATH` at deploy time). Secrets and signing hardware are provided by the
environment `bazel run` executes in — never by Bazel.

Example:

```python
load("@rules_img//img:signing.bzl", "signing_config")

# Use a Bazel-built plugin.
signing_config(
    name = "notary",
    tool = "@rules_img//img/signer:notation",
    args = ["--key", "release"],
)

# Use a host-installed tool.
signing_config(
    name = "corp",
    tool_command = "corp-signer",
    args = ["--profile", "prod"],
)
```

Referenced globally via `--@rules_img//img/settings:sign_setting=//path:notary`,
or per target via the `sign_setting` attribute of `image_push`/`image_push_spec`.
Signing is enabled with the `sign` attribute or the `//img/settings:sign` flag.*
nameA unique name for this target. �
tool�A Bazel executable implementing the `sign-oci-artifact` protocol. Shipped in the push binary's runfiles. Mutually exclusive with `tool_command`.2None�
tool_commandqName or path of a host-installed signer tool, resolved on `$PATH` at deploy time. Mutually exclusive with `tool`.2""V
argsHArguments passed to the plugin after the `sign-oci-artifact` subcommand.2[]�
envAdditional (non-secret) environment variables set for the plugin. Secrets should come from the deploy-time environment instead.
2{}�
targets�Default set of descriptors to sign: any of "roots" (the pushed root, the default), "child_manifests" (each child of an index), and "referrers" (referrer artifacts such as SBOMs). Overridable at deploy time via `--sign_targets`.2	["roots"]"<
signing_config*@rules_img//img/private:signing_config.bzl*c
SigningConfigInfoN
SigningConfigInfo9@rules_img//img/private/providers:signing_config_info.bzl,
*
nameA unique name for this target. �
�
tool�A Bazel executable implementing the `sign-oci-artifact` protocol. Shipped in the push binary's runfiles. Mutually exclusive with `tool_command`.2None�
�
tool_commandqName or path of a host-installed signer tool, resolved on `$PATH` at deploy time. Mutually exclusive with `tool`.2""X
V
argsHArguments passed to the plugin after the `sign-oci-artifact` subcommand.2[]�
�
envAdditional (non-secret) environment variables set for the plugin. Secrets should come from the deploy-time environment instead.
2{}�
�
targets�Default set of descriptors to sign: any of "roots" (the pushed root, the default), "child_manifests" (each child of an index), and "referrers" (referrer artifacts such as SBOMs). Overridable at deploy time via `--sign_targets`.2	["roots"]�Public API for container image signing configuration.

See the `signing_config` rule for how `img deploy` signs images by delegating to
external signer plugins.�I

	rules_imgimgtest.bzl�image_structure_test�Validates a container image's structure using its config JSON and mtree.

`image_structure_test` is a lightweight, hermetic analogue of
[container-structure-test](https://github.com/GoogleContainerTools/container-structure-test):
it accepts the same YAML/JSON config files, but validates the image using only its
image config JSON and its mtree filesystem listing -- it never materializes the
layer blobs into the test. Because of that, checks that require a running container
or file contents are not supported and cause a clear failure (so a migrated config
tells you exactly what won't port):

- **Supported** (`metadataTest`): env / envVars, labels, entrypoint, cmd,
  exposedPorts, volumes, workdir, user -- validated against the image config JSON.
- **Supported** (`fileExistenceTests`): path, shouldExist, permissions, uid, gid,
  isExecutableBy -- validated against the image mtree.
- **Rejected**: `commandTests` (require running the container), `fileContentTests`
  (require file bytes), `licenseTests` (require scanning a running container).

The `image` may be a rules_img `image_manifest` or `image_index`, a target that
exposes prebuilt `mtree` and `oci_image_config` output groups (paired positionally
in sorted order), or an OCI image layout directory (a tree artifact, e.g. a
rules_oci `oci_image`). For a multi-platform `image_index`, every config is
validated against each single-platform image.

Example:

```python
load("@rules_img//img:test.bzl", "image_structure_test")

image_structure_test(
    name = "hello_test",
    configs = ["testdata/hello.yaml"],
    image = ":hello",
)
```"�
�
image_structure_test�Validates a container image's structure using its config JSON and mtree.

`image_structure_test` is a lightweight, hermetic analogue of
[container-structure-test](https://github.com/GoogleContainerTools/container-structure-test):
it accepts the same YAML/JSON config files, but validates the image using only its
image config JSON and its mtree filesystem listing -- it never materializes the
layer blobs into the test. Because of that, checks that require a running container
or file contents are not supported and cause a clear failure (so a migrated config
tells you exactly what won't port):

- **Supported** (`metadataTest`): env / envVars, labels, entrypoint, cmd,
  exposedPorts, volumes, workdir, user -- validated against the image config JSON.
- **Supported** (`fileExistenceTests`): path, shouldExist, permissions, uid, gid,
  isExecutableBy -- validated against the image mtree.
- **Rejected**: `commandTests` (require running the container), `fileContentTests`
  (require file bytes), `licenseTests` (require scanning a running container).

The `image` may be a rules_img `image_manifest` or `image_index`, a target that
exposes prebuilt `mtree` and `oci_image_config` output groups (paired positionally
in sorted order), or an OCI image layout directory (a tree artifact, e.g. a
rules_oci `oci_image`). For a multi-platform `image_index`, every config is
validated against each single-platform image.

Example:

```python
load("@rules_img//img:test.bzl", "image_structure_test")

image_structure_test(
    name = "hello_test",
    configs = ["testdata/hello.yaml"],
    image = ":hello",
)
```*
nameA unique name for this target. �
image�Image to validate: a rules_img image_manifest/image_index, a target exposing `mtree` + `oci_image_config` output groups, or an OCI image layout directory (rules_oci). D
configs5container-structure-test config files (YAML or JSON). "H
image_structure_test0@rules_img//img/private:image_structure_test.bzl08,
*
nameA unique name for this target. �
�
image�Image to validate: a rules_img image_manifest/image_index, a target exposing `mtree` + `oci_image_config` output groups, or an OCI image layout directory (rules_oci). F
D
configs5container-structure-test config files (YAML or JSON). �)image_size_test�Budgets the wasted and duplicated bytes an image ships across its layers.

`image_size_test` replays the image's per-layer mtrees in layer order -- the
test itself never reads a layer blob -- and fails when a budget is exceeded:

- **Wasted bytes** (`max_wasted_bytes`): file bytes shipped in a layer that a
  later layer shadows with an overwrite, a whiteout (`.wh.<name>`), or an
  opaque whiteout (`.wh..wh..opq`). They are pulled with every image but are
  unreachable in the final filesystem.
- **Duplicated bytes** (`max_duplicated_bytes`): identical file content (by
  `sha256digest`) live at multiple paths, counted once per extra copy. A
  hardlink group ships its content once however many names point at it, and
  symlinks carry no file bytes, so neither inflates the count.

Both are counted in uncompressed tar entry sizes, so they are larger than the
compressed bytes a registry reports for the same layers. At least one budget
must be set. On failure the test lists the largest offenders, each attributed to
the layer that wrote the bytes and the layer that shadowed them (with the
producing target where the layer history records it).

The `image` must be a rules_img `image_manifest` or `image_index`; for an
index, every single-platform child image is checked.

Every layer must expose its filesystem content, otherwise the test fails with an
"incomplete layer metadata" error rather than silently passing on a subset of
the image. In particular a base image pulled with the default
`layer_handling = "shallow"` never fetches its layer blobs, so it has no mtree
to replay: pull it with `layer_handling = "eager"` to make an image on top of it
measurable.

Example:

```python
load("@rules_img//img:test.bzl", "image_size_test")

image_size_test(
    name = "app_size_test",
    image = ":app",
    max_wasted_bytes = "10MiB",
)
```"�
�
image_size_test�Budgets the wasted and duplicated bytes an image ships across its layers.

`image_size_test` replays the image's per-layer mtrees in layer order -- the
test itself never reads a layer blob -- and fails when a budget is exceeded:

- **Wasted bytes** (`max_wasted_bytes`): file bytes shipped in a layer that a
  later layer shadows with an overwrite, a whiteout (`.wh.<name>`), or an
  opaque whiteout (`.wh..wh..opq`). They are pulled with every image but are
  unreachable in the final filesystem.
- **Duplicated bytes** (`max_duplicated_bytes`): identical file content (by
  `sha256digest`) live at multiple paths, counted once per extra copy. A
  hardlink group ships its content once however many names point at it, and
  symlinks carry no file bytes, so neither inflates the count.

Both are counted in uncompressed tar entry sizes, so they are larger than the
compressed bytes a registry reports for the same layers. At least one budget
must be set. On failure the test lists the largest offenders, each attributed to
the layer that wrote the bytes and the layer that shadowed them (with the
producing target where the layer history records it).

The `image` must be a rules_img `image_manifest` or `image_index`; for an
index, every single-platform child image is checked.

Every layer must expose its filesystem content, otherwise the test fails with an
"incomplete layer metadata" error rather than silently passing on a subset of
the image. In particular a base image pulled with the default
`layer_handling = "shallow"` never fetches its layer blobs, so it has no mtree
to replay: pull it with `layer_handling = "eager"` to make an image on top of it
measurable.

Example:

```python
load("@rules_img//img:test.bzl", "image_size_test")

image_size_test(
    name = "app_size_test",
    image = ":app",
    max_wasted_bytes = "10MiB",
)
```*
nameA unique name for this target. G
image:Image to check: a rules_img image_manifest or image_index. �
max_wasted_bytes�Budget for wasted bytes (shipped file bytes shadowed by a later layer).

A byte count, optionally with a `KiB`/`MiB`/`GiB`/`TiB` suffix (e.g. `"10000000"`,
`"512MiB"`). Empty (the default) leaves wasted bytes unchecked; the measured
value is still reported.2""�
max_duplicated_bytes�Budget for duplicated bytes (identical file content live at multiple paths, counted once per extra copy).

A byte count, optionally with a `KiB`/`MiB`/`GiB`/`TiB` suffix (e.g. `"10000000"`,
`"512MiB"`). Empty (the default) leaves duplicated bytes unchecked; the measured
value is still reported.2""">
image_size_test+@rules_img//img/private:image_size_test.bzl08,
*
nameA unique name for this target. I
G
image:Image to check: a rules_img image_manifest or image_index. �
�
max_wasted_bytes�Budget for wasted bytes (shipped file bytes shadowed by a later layer).

A byte count, optionally with a `KiB`/`MiB`/`GiB`/`TiB` suffix (e.g. `"10000000"`,
`"512MiB"`). Empty (the default) leaves wasted bytes unchecked; the measured
value is still reported.2""�
�
max_duplicated_bytes�Budget for duplicated bytes (identical file content live at multiple paths, counted once per extra copy).

A byte count, optionally with a `KiB`/`MiB`/`GiB`/`TiB` suffix (e.g. `"10000000"`,
`"512MiB"`). Empty (the default) leaves duplicated bytes unchecked; the measured
value is still reported.2""�Public API for testing container images.

```python
load("@rules_img//img:test.bzl", "image_size_test", "image_structure_test")
``` 