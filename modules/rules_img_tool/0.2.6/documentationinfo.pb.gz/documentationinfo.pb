�
&
rules_img_toolgo_proto_library.bzl*�ModuleInfo request error: invalid argument: Traceback (most recent call last):
	File "external/rules_img_tool/go_proto_library.bzl", line 31, column 23, in <toplevel>
		go_proto_library_rule = macro(
Error in macro: in call to macro(), parameter 'inherit_attrs' got value of type 'RuleDefinitionIdentifier', want 'rule, macro, string, or NoneType' 