�~
!
rules_itestprivate	itest.bzl�Ditest_service�An itest_service is a binary that is intended to run for the duration of the integration test. Examples include databases, HTTP/RPC servers, queue consumers, external service mocks, etc.

All [common binary attributes](https://bazel.build/reference/be/common-definitions#common-attributes-binaries) are supported including `args`."�A
�"
itest_service�An itest_service is a binary that is intended to run for the duration of the integration test. Examples include databases, HTTP/RPC servers, queue consumers, external service mocks, etc.

All [common binary attributes](https://bazel.build/reference/be/common-definitions#common-attributes-binaries) are supported including `args`.*
nameA unique name for this target. �
autoassign_port�If true, the service manager will pick a free port and assign it to the service.
The port will be interpolated into `$${PORT}` in the service's `http_health_check_address` and `args`.
It will also be exported under the target's fully qualified label in the service-port mapping.

The assigned ports for all services are available for substitution in `http_health_check_address` and `args` (in case one service needs the address for another one.)
For example, the following substitution: `args = ["-client-addr", "127.0.0.1:$${@@//label/for:service}"]`

The service-port mapping is a JSON string -> int map propagated through the `ASSIGNED_PORTS` env var.
For example, a port can be retrieved with the following JS code:
`JSON.parse(process.env["ASSIGNED_PORTS"])["@@//label/for:service"]`.

Alternately, the env will also contain the location of a binary that can return the port, for contexts without a readily-accessible JSON parser.
For example, the following Bash command:
`PORT=$($GET_ASSIGNED_PORT_BIN @@//label/for:service)`2False
data2[]�
deps�Services/tasks that must be started before this service/task can be started. Can be `itest_service`, `itest_task`, or `itest_service_group`.*
_ServiceGroupInfo2[]u
envhThe service manager will merge these variables into the environment when spawning the underlying binary.
2{}$
exeThe binary target to run. �
health_check�If set, the service manager will execute this binary to check if the service came up in a healthy state.
This check will be retried until it exits with a 0 exit code. When used in conjunction with autoassigned ports, use
one of the methods described in `autoassign_port` to locate the service.2None�
health_check_args�Arguments to pass to the health_check binary. The various defined ports will be substituted prior to being given to the health_check binary.2[]�
health_check_interval�The duration between each health check. The syntax is based on common time duration with a number, followed by the time unit. For example, `200ms`, `1s`, `2m`, `3h`, `4d`.2"200ms"�
health_check_timeout�The timeout to wait for the health check. The syntax is based on common time duration with a number, followed by the time unit. For example, `200ms`, `1s`, `2m`, `3h`, `4d`. If empty or not set, the health check will not have a timeout.2""�
hot_reloadable�If set to True, the service manager will propagate ibazel's reload notification over stdin instead of restarting the service.
See the ruleset docstring for more info on using ibazel2False�
http_health_check_address�If set, the service manager will send an HTTP request to this address to check if the service came up in a healthy state.
This check will be retried until it returns a 200 HTTP code. When used in conjunction with autoassigned ports, `$${@@//label/for:service:port_name}` can be used in the address.
Example: `http_health_check_address = "http://127.0.0.1:$${@@//label/for:service:port_name}",`2""�
named_ports�For each element of the list, the service manager will pick a free port and assign it to the service.
The port's fully-qualified name is the service's fully-qualified label and the port name, separated by a colon.
For example, a port assigned with `named_ports = ["http_port"]` will be assigned a fully-qualified name of `@@//label/for:service:http_port`.

Named ports are accessible through the service-port mapping. For more details, see `autoassign_port`.2[]�
so_reuseport_aware�If set, the service manager will not release the autoassigned port. The service binary must use SO_REUSEPORT when binding it.
This reduces the possibility of port collisions when running many service_tests in parallel, or when code binds port 0 without being
aware of the port assignment mechanism.

Must only be set when `autoassign_port` is enabled or `named_ports` are used.2False"1
itest_service @@rules_itest//private:itest.bzl
��,
*
nameA unique name for this target. �
�
autoassign_port�If true, the service manager will pick a free port and assign it to the service.
The port will be interpolated into `$${PORT}` in the service's `http_health_check_address` and `args`.
It will also be exported under the target's fully qualified label in the service-port mapping.

The assigned ports for all services are available for substitution in `http_health_check_address` and `args` (in case one service needs the address for another one.)
For example, the following substitution: `args = ["-client-addr", "127.0.0.1:$${@@//label/for:service}"]`

The service-port mapping is a JSON string -> int map propagated through the `ASSIGNED_PORTS` env var.
For example, a port can be retrieved with the following JS code:
`JSON.parse(process.env["ASSIGNED_PORTS"])["@@//label/for:service"]`.

Alternately, the env will also contain the location of a binary that can return the port, for contexts without a readily-accessible JSON parser.
For example, the following Bash command:
`PORT=$($GET_ASSIGNED_PORT_BIN @@//label/for:service)`2False

data2[]�
�
deps�Services/tasks that must be started before this service/task can be started. Can be `itest_service`, `itest_task`, or `itest_service_group`.*
_ServiceGroupInfo2[]w
u
envhThe service manager will merge these variables into the environment when spawning the underlying binary.
2{}&
$
exeThe binary target to run. �
�
health_check�If set, the service manager will execute this binary to check if the service came up in a healthy state.
This check will be retried until it exits with a 0 exit code. When used in conjunction with autoassigned ports, use
one of the methods described in `autoassign_port` to locate the service.2None�
�
health_check_args�Arguments to pass to the health_check binary. The various defined ports will be substituted prior to being given to the health_check binary.2[]�
�
health_check_interval�The duration between each health check. The syntax is based on common time duration with a number, followed by the time unit. For example, `200ms`, `1s`, `2m`, `3h`, `4d`.2"200ms"�
�
health_check_timeout�The timeout to wait for the health check. The syntax is based on common time duration with a number, followed by the time unit. For example, `200ms`, `1s`, `2m`, `3h`, `4d`. If empty or not set, the health check will not have a timeout.2""�
�
hot_reloadable�If set to True, the service manager will propagate ibazel's reload notification over stdin instead of restarting the service.
See the ruleset docstring for more info on using ibazel2False�
�
http_health_check_address�If set, the service manager will send an HTTP request to this address to check if the service came up in a healthy state.
This check will be retried until it returns a 200 HTTP code. When used in conjunction with autoassigned ports, `$${@@//label/for:service:port_name}` can be used in the address.
Example: `http_health_check_address = "http://127.0.0.1:$${@@//label/for:service:port_name}",`2""�
�
named_ports�For each element of the list, the service manager will pick a free port and assign it to the service.
The port's fully-qualified name is the service's fully-qualified label and the port name, separated by a colon.
For example, a port assigned with `named_ports = ["http_port"]` will be assigned a fully-qualified name of `@@//label/for:service:http_port`.

Named ports are accessible through the service-port mapping. For more details, see `autoassign_port`.2[]�
�
so_reuseport_aware�If set, the service manager will not release the autoassigned port. The service binary must use SO_REUSEPORT when binding it.
This reduces the possibility of port collisions when running many service_tests in parallel, or when code binds port 0 without being
aware of the port assignment mechanism.

Must only be set when `autoassign_port` is enabled or `named_ports` are used.2False�	itest_service_group�A service group is a collection of services/tasks.

It serves as a convenient way for a downstream target to depend on multiple services with a single label, without
forcing the services within the group to define a specific startup ordering with their `deps`.

It can bring up multiple services with a single `bazel run` command, which is useful for creating dev environments."�
�
itest_service_group�A service group is a collection of services/tasks.

It serves as a convenient way for a downstream target to depend on multiple services with a single label, without
forcing the services within the group to define a specific startup ordering with their `deps`.

It can bring up multiple services with a single `bazel run` command, which is useful for creating dev environments.*
nameA unique name for this target. �
serviceshServices/tasks that comprise this group. Can be `itest_service`, `itest_task`, or `itest_service_group`.*
_ServiceGroupInfo2[]"7
itest_service_group @@rules_itest//private:itest.bzl
��,
*
nameA unique name for this target. �
�
serviceshServices/tasks that comprise this group. Can be `itest_service`, `itest_task`, or `itest_service_group`.*
_ServiceGroupInfo2[]�
itest_task�A task is a one-shot execution of a binary that is intended to run as part of the itest scenario creation.
Examples include: filesystem setup, dynamic config file generation (especially if it depends on ports), DB migrations or seed data creation.

All [common binary attributes](https://bazel.build/reference/be/common-definitions#common-attributes-binaries) are supported including `args`."�	
�

itest_task�A task is a one-shot execution of a binary that is intended to run as part of the itest scenario creation.
Examples include: filesystem setup, dynamic config file generation (especially if it depends on ports), DB migrations or seed data creation.

All [common binary attributes](https://bazel.build/reference/be/common-definitions#common-attributes-binaries) are supported including `args`.*
nameA unique name for this target. 
data2[]�
deps�Services/tasks that must be started before this service/task can be started. Can be `itest_service`, `itest_task`, or `itest_service_group`.*
_ServiceGroupInfo2[]u
envhThe service manager will merge these variables into the environment when spawning the underlying binary.
2{}$
exeThe binary target to run. ".

itest_task @@rules_itest//private:itest.bzl
��,
*
nameA unique name for this target. 

data2[]�
�
deps�Services/tasks that must be started before this service/task can be started. Can be `itest_service`, `itest_task`, or `itest_service_group`.*
_ServiceGroupInfo2[]w
u
envhThe service manager will merge these variables into the environment when spawning the underlying binary.
2{}&
$
exeThe binary target to run. �service_test�Brings up a set of services/tasks and runs a test target against them.

This can be used to customize which services a particular test needs while being able to bring them up in an easy and consistent way.

Example usage:
```
go_test(
    name = "_example_test_no_services",
    srcs = [..],
    tags = ["manual"],
)

service_test(
    name = "example_test",
    test = ":_example_test_no_services",
    services = [
        "//services/mysql",
        ...
    ],
)
```

Typically this would be wrapped into a macro.

All [common binary attributes](https://bazel.build/reference/be/common-definitions#common-attributes-binaries) are supported including `args`."�
�	
service_test�Brings up a set of services/tasks and runs a test target against them.

This can be used to customize which services a particular test needs while being able to bring them up in an easy and consistent way.

Example usage:
```
go_test(
    name = "_example_test_no_services",
    srcs = [..],
    tags = ["manual"],
)

service_test(
    name = "example_test",
    test = ":_example_test_no_services",
    services = [
        "//services/mysql",
        ...
    ],
)
```

Typically this would be wrapped into a macro.

All [common binary attributes](https://bazel.build/reference/be/common-definitions#common-attributes-binaries) are supported including `args`.*
nameA unique name for this target. 
data2[]u
envhThe service manager will merge these variables into the environment when spawning the underlying binary.
2{}�
serviceshServices/tasks that comprise this group. Can be `itest_service`, `itest_task`, or `itest_service_group`.*
_ServiceGroupInfo2[]o
test_The underlying test target to execute once the services have been brought up and healthchecked.2None"0
service_test @@rules_itest//private:itest.bzl
��,
*
nameA unique name for this target. 

data2[]w
u
envhThe service manager will merge these variables into the environment when spawning the underlying binary.
2{}�
�
serviceshServices/tasks that comprise this group. Can be `itest_service`, `itest_task`, or `itest_service_group`.*
_ServiceGroupInfo2[]q
o
test_The underlying test target to execute once the services have been brought up and healthchecked.2None}
//lib:paths.bzlrh
"
aspect_bazel_liblib	paths.bzl4
to_rlocation_pathto_rlocation_path
&+&<
&&>�
//rules:common_settings.bzlrn
*
bazel_skylibrulescommon_settings.bzl2
BuildSettingInfoBuildSettingInfo
'3'C
''E�
# Rules for running services in integration tests.

This ruleset supports [ibazel](https://github.com/bazelbuild/bazel-watcher) when using `bazel run`.
As a UX optimization, the service manager is able to restart only the modified services, instead of all services,
when it receives the reload notification from ibazel. This capability depends on a cache-busting input, so it is hidden
behind an an extra CLI flag, like so:
```
.bazelrc

build:enable-reload --@rules_itest//:enable_per_service_reload
fetch:enable-reload --@rules_itest//:enable_per_service_reload
query:enable-reload --@rules_itest//:enable_per_service_reload
```

`ibazel run --config enable-reload //path/to:target`

In addition, if the `hot_reloadable` attribute is set on an `itest_service`, the service manager will
forward the ibazel hot-reload notification over stdin instead of restarting the service.

# Service control

The service manager exposes a HTTP server on `http://127.0.0.1:{SVCCTL_PORT}`. It can be used to
start / stop services during a test run. There are currently 5 API endpoints available.
All of them are GET requests:

1. `/v0/healthcheck?service={label}`: Returns 200 if the service is healthy, 503 otherwise.
2. `/v0/start?service={label}`: Starts the service if it is not already running.
3. `/v0/kill?service={label}[&signal={signal}]`: Send kill signal to the service if it is running.
   You can optionally specify the signal to send to the service (valid values: SIGTERM and SIGKILL).
4. `/v0/wait?service={label}`: Wait for the service to exit and returns the exit code in the body.
5. `/v0/port?service={label}`: Returns the assigned port for the given label. May be a named port.

In `bazel run` mode, the service manager will write the value of `SVCCTL_PORT` to `/tmp/svcctl_port`.
This can be used in conjunction with the `/v0/port` API to let other tools interact with the managed services.
�

rules_itest	itest.bzl�service_test�Brings up a set of services/tasks and runs a test target against them.

This can be used to customize which services a particular test needs while being able to bring them up in an easy and consistent way.

Example usage:
```
go_test(
    name = "_example_test_no_services",
    srcs = [..],
    tags = ["manual"],
)

service_test(
    name = "example_test",
    test = ":_example_test_no_services",
    services = [
        "//services/mysql",
        ...
    ],
)
```

Typically this would be wrapped into a macro.

All [common binary attributes](https://bazel.build/reference/be/common-definitions#common-attributes-binaries) are supported including `args`."�
�
service_test�Brings up a set of services/tasks and runs a test target against them.

This can be used to customize which services a particular test needs while being able to bring them up in an easy and consistent way.

Example usage:
```
go_test(
    name = "_example_test_no_services",
    srcs = [..],
    tags = ["manual"],
)

service_test(
    name = "example_test",
    test = ":_example_test_no_services",
    services = [
        "//services/mysql",
        ...
    ],
)
```

Typically this would be wrapped into a macro.

All [common binary attributes](https://bazel.build/reference/be/common-definitions#common-attributes-binaries) are supported including `args`.*
nameA unique name for this target. 
data2[]u
envhThe service manager will merge these variables into the environment when spawning the underlying binary.
2{}�
port_aliases�Port aliases allow you to 're-export' another service's port as belonging to this service group.
This can be used to create abstractions (such as an itest_service combined with an itest_task) but not leak
their implementation through how client code accesses port names.
2{}�
serviceshServices/tasks that comprise this group. Can be `itest_service`, `itest_task`, or `itest_service_group`.*
_ServiceGroupInfo2[]o
test_The underlying test target to execute once the services have been brought up and healthchecked.2None")
service_test@@rules_itest//:itest.bzl
��,
*
nameA unique name for this target. 

data2[]w
u
envhThe service manager will merge these variables into the environment when spawning the underlying binary.
2{}�
�
port_aliases�Port aliases allow you to 're-export' another service's port as belonging to this service group.
This can be used to create abstractions (such as an itest_service combined with an itest_task) but not leak
their implementation through how client code accesses port names.
2{}�
�
serviceshServices/tasks that comprise this group. Can be `itest_service`, `itest_task`, or `itest_service_group`.*
_ServiceGroupInfo2[]q
o
test_The underlying test target to execute once the services have been brought up and healthchecked.2None�itest_service*�
u
itest_service

name (
tags[](
hygienicTrue(

kwargs(2*
itest_service@@rules_itest//:itest.bzl
"_hygiene_test*_itest_service2_itest_service2_hygiene_test�itest_service_group*�
�
itest_service_group

name (
tags[](
hygienicTrue(

kwargs(20
itest_service_group@@rules_itest//:itest.bzl
"_hygiene_test*_itest_service_group2_hygiene_test2_itest_service_group�
itest_task*�
o

itest_task

name (
tags[](
hygienicTrue(

kwargs(2'

itest_task@@rules_itest//:itest.bzl
%%"_hygiene_test*_itest_task2_hygiene_test2_itest_task�
//private:itest.bzlr�
!
rules_itestprivate	itest.bzl-
itest_service_itest_service
9
itest_service_group_itest_service_group
'

itest_task_itest_task
+
service_test_service_test

	1Rules for running services in integration tests.  