�
:
	rules_jnijni/private/extensionsdownload_jdk_deps.bzl�download_jdk_depsJs
c
download_jdk_deps"N
download_jdk_deps9@@rules_jni//jni/private/extensions:download_jdk_deps.bzl
55i
//lib:modules.bzlrR
 
bazel_skyliblibmodules.bzl 
modulesmodules
)0
2�
//jni/private:repositories.bzlr^
*
	rules_jnijni/privaterepositories.bzl"
jdk_depsjdk_deps
3;
=�

D
	rules_jnijni/private/tools/libjvm_stubcurrent_java_runtime.bzl�current_java_runtime"�
�
current_java_runtime*
nameA unique name for this target. "[
current_java_runtimeC@@rules_jni//jni/private/tools/libjvm_stub:current_java_runtime.bzl
QQ,
*
nameA unique name for this target. �rlocation_path*�
�
rlocation_path	
ctx (

short_path (2U
rlocation_pathC@@rules_jni//jni/private/tools/libjvm_stub:current_java_runtime.bzl
a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.�
//tools/cpp:toolchain_utils.bzlru
-
bazel_tools	tools/cpptoolchain_utils.bzl6
find_cpp_toolchainfind_cpp_toolchain
6H
Jy
//cc/common:cc_common.bzlrZ
$
rules_cc	cc/commoncc_common.bzl$
	cc_common	cc_common
-6
8o
//cc/common:cc_info.bzlrR
"
rules_cc	cc/commoncc_info.bzl
CcInfoCcInfo
+1
3�	$CURRENT_JAVA_RUNTIME_HEADER_TEMPLATE�#ifndef RULES_JNI_LIBJVM_STUB_CURRENT_JAVA_RUNTIME_H
#define RULES_JNI_LIBJVM_STUB_CURRENT_JAVA_RUNTIME_H
#define RULES_JNI_JAVA_EXECUTABLE_RLOCATION "{}"
#endif
j��#ifndef RULES_JNI_LIBJVM_STUB_CURRENT_JAVA_RUNTIME_H
#define RULES_JNI_LIBJVM_STUB_CURRENT_JAVA_RUNTIME_H
#define RULES_JNI_JAVA_EXECUTABLE_RLOCATION "{}"
#endif
�
B
	rules_jnijni/private/tools/libjvm_stubcurrent_repository.bzlW	RULES_JNI_REPOSITORY_DEFINERULES_JNI_REPOSITORY=\"\"jRULES_JNI_REPOSITORY=\"\"��
,
	rules_jnijni/privatecc_jni_library.bzl��cc_jni_library�A native library that can be loaded by a Java application at runtime.

Add this target to the `native_libs` of a [`java_jni_library`](#java_jni_library).

The native libraries are exposed as Java resources, which are placed in a Java package determined from the Bazel
package of this target according to the
[Maven standard directory layout](https://maven.apache.org/guides/introduction/introduction-to-the-standard-directory-layout.html).
If the library should be included in the `com/example` subdirectory of a deploy JAR, which corresponds to the Java
package `com.example`, place it under one of the following Bazel package structures:
* `**/src/*/native/com/example` (preferred)
* `**/src/*/resources/com/example`
* `**/src/*/java/com/example`
* `**/java/com/example`

*Note:* Building a native library for multiple platforms by setting the `platforms` attribute to a non-empty list of
platforms requires either remote execution or cross-compilation toolchains for the target platforms. As both require
a more sophisticated Bazel setup, the following simpler process can be helpful for smaller or open-source projects:

1. Leave the `platforms` attribute empty or unspecified.
2. Build the deploy JAR of the Java library or application with all native libraries included separately for each
   target platform, for example using a CI platform.
3. Manually (outside Bazel) merge the deploy JARs. The `.class` files will be identical and can thus safely be
   replaced, but the resulting JAR will include all versions of the native library and the correct version will be
   loaded at runtime.

An example of such a CI workflow can be found [here](https://github.com/CodeIntelligenceTesting/jazzer/blob/d1835d6fa2ebfb7b2661cfaaa8acb8bbf42bb486/.github/workflows/release.yml).



<p>It produces an executable binary.</p>

<br/>The <code>name</code> of the target should be the same as the name of the
source file that is the main entry point of the application (minus the extension).
For example, if your entry point is in <code>main.cc</code>, then your name should
be <code>main</code>.

<h4>Implicit output targets</h4>
<ul>
<li><code><var>name</var>.stripped</code> (only built if explicitly requested): A stripped
  version of the binary. <code>strip -g</code> is run on the binary to remove debug
  symbols.  Additional strip options can be provided on the command line using
  <code>--stripopt=-foo</code>.</li>
<li><code><var>name</var>.dwp</code> (only built if explicitly requested): If
  <a href="https://gcc.gnu.org/wiki/DebugFission">Fission</a> is enabled: a debug
  information package file suitable for debugging remotely deployed binaries. Else: an
  empty file.</li>
</ul>
"�
Ж
cc_jni_library�A native library that can be loaded by a Java application at runtime.

Add this target to the `native_libs` of a [`java_jni_library`](#java_jni_library).

The native libraries are exposed as Java resources, which are placed in a Java package determined from the Bazel
package of this target according to the
[Maven standard directory layout](https://maven.apache.org/guides/introduction/introduction-to-the-standard-directory-layout.html).
If the library should be included in the `com/example` subdirectory of a deploy JAR, which corresponds to the Java
package `com.example`, place it under one of the following Bazel package structures:
* `**/src/*/native/com/example` (preferred)
* `**/src/*/resources/com/example`
* `**/src/*/java/com/example`
* `**/java/com/example`

*Note:* Building a native library for multiple platforms by setting the `platforms` attribute to a non-empty list of
platforms requires either remote execution or cross-compilation toolchains for the target platforms. As both require
a more sophisticated Bazel setup, the following simpler process can be helpful for smaller or open-source projects:

1. Leave the `platforms` attribute empty or unspecified.
2. Build the deploy JAR of the Java library or application with all native libraries included separately for each
   target platform, for example using a CI platform.
3. Manually (outside Bazel) merge the deploy JARs. The `.class` files will be identical and can thus safely be
   replaced, but the resulting JAR will include all versions of the native library and the correct version will be
   loaded at runtime.

An example of such a CI workflow can be found [here](https://github.com/CodeIntelligenceTesting/jazzer/blob/d1835d6fa2ebfb7b2661cfaaa8acb8bbf42bb486/.github/workflows/release.yml).



<p>It produces an executable binary.</p>

<br/>The <code>name</code> of the target should be the same as the name of the
source file that is the main entry point of the application (minus the extension).
For example, if your entry point is in <code>main.cc</code>, then your name should
be <code>main</code>.

<h4>Implicit output targets</h4>
<ul>
<li><code><var>name</var>.stripped</code> (only built if explicitly requested): A stripped
  version of the binary. <code>strip -g</code> is run on the binary to remove debug
  symbols.  Additional strip options can be provided on the command line using
  <code>--stripopt=-foo</code>.</li>
<li><code><var>name</var>.dwp</code> (only built if explicitly requested): If
  <a href="https://gcc.gnu.org/wiki/DebugFission">Fission</a> is enabled: a debug
  information package file suitable for debugging remotely deployed binaries. Else: an
  empty file.</li>
</ul>
*
nameA unique name for this target. �
additional_linker_inputs�
Dependencies that are only made available to the C++ linker command.
<p>
  Unlike <code>deps</code>, which is conceptually made for both compilation and
  linking dependencies, <code>additional_linker_inputs</code> is specifically
  made for only the latter, and signals a dependency that is required only for
  linking (for example, files that are referenced in <code>linkopts</code>).
</p>
<p>
  For example, compiled Windows .res files can be provided here to be embedded in
  the binary target.
</p>
2[]�
	conlyopts�
Add these options to the C compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
2[]�
copts�
Add these options to the C/C++ compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
<p>
  Each string in this attribute is added in the given order to <code>COPTS</code> before
  compiling the binary target. The flags take effect only for compiling this target, not
  its dependencies, so be careful about header files included elsewhere.
  All paths should be relative to the workspace, not to the current package.
  This attribute should not be needed outside of <code>third_party</code>.
</p>
<p>
  If the package declares the <a href="${link package.features}">feature</a>
  <code>no_copts_tokenization</code>, Bourne shell tokenization applies only to strings
  that consist of a single "Make" variable.
</p>
2[]�
cxxopts�
Add these options to the C++ compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
2[]�
data�
The list of files needed by this library at runtime.

See general comments about <code>data</code>
at <a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>If a <code>data</code> is the name of a generated file, then this
   <code>cc_library</code> rule automatically depends on the generating
   rule.
</p>
<p>If a <code>data</code> is a rule name, then this
   <code>cc_library</code> rule automatically depends on that rule,
   and that rule's <code>outs</code> are automatically added to
   this <code>cc_library</code>'s data files.
</p>
<p>Your C++ code can access these data files like so:</p>
<pre><code class="lang-starlark">
  const std::string path = devtools_build::GetDataDependencyFilepath(
      "my/test/data/file");
</code></pre>
2[]�
defines�
List of defines to add to the compile line of this and all dependent targets.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
Each string, which must consist of a single Bourne shell token,
is prepended with <code>-D</code> and added to the compile command line to this target,
as well as to every rule that depends on it. Be very careful, since this may have
far-reaching effects -- the defines are added to every target that depends on
this target.  When in doubt, add define values to
<a href="#cc_binary.local_defines"><code>local_defines</code></a> instead.
2[]�
deps�
The list of other libraries to be linked in to the binary target.
<p>These can be <code>cc_library</code> or <code>objc_library</code>
targets.</p>

It is also allowed to
put linker scripts (.lds) into deps, and reference them in
<a href="#cc_binary.linkopts"><code>linkopts</code></a>,
but please consider
<a href="#cc_binary.additional_linker_inputs"><code>additional_linker_inputs</code></a>
for that use case.
*
CcInfo2[]�
dynamic_deps�
These are other <code>cc_shared_library</code> dependencies the current target depends on.

<p>
The <code>cc_shared_library</code> implementation will use the list of
<code>dynamic_deps</code> (transitively, i.e. also the <code>dynamic_deps</code> of the
current target's <code>dynamic_deps</code>) to decide which <code>cc_libraries</code> in
the transitive <code>deps</code> should not be linked in because they are already provided
by a different <code>cc_shared_library</code>.
*
CcSharedLibraryInfo2[]
env
2{}&

hdrs_checkDeprecated, no-op.2""�
includes�
List of include dirs to be added to the compile line.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution.
Each string is prepended with the package path and passed to the C++ toolchain for
expansion via the "include_paths" CROSSTOOL feature. A toolchain running on a POSIX system
with typical feature definitions will produce
<code>-isystem path_to_package/include_entry</code>.
This should only be used for third-party libraries that
do not conform to the Google style of writing #include statements.
Unlike <a href="#cc_binary.copts">COPTS</a>, these flags are added for this rule
and every rule that depends on it. (Note: not the rules it depends upon!) Be
very careful, since this may have far-reaching effects.  When in doubt, add
"-I" flags to <a href="#cc_binary.copts">COPTS</a> instead.
<p>
The added <code>include</code> paths will include generated files as well as
files in the source tree.
</p>
2[]
licenses2[]�
link_extra_lib�
Control linking of extra libraries.
<p>
    By default, C++ binaries are linked against <code>@bazel_tools//tools/cpp:link_extra_lib</code>,
    which by default depends on the label flag <code>@bazel_tools//tools/cpp:link_extra_libs</code>.
    Without setting the flag, this library is empty by default. Setting the label flag
    allows linking optional dependencies, such as overrides for weak symbols, interceptors
    for shared library functions, or special runtime libraries (for malloc replacements,
    prefer <code>malloc</code> or <code>--custom_malloc</code>). Setting this attribute to
    <code>None</code> disables this behaviour.
</p>
*
CcInfo2&@bazel_tools//tools/cpp:link_extra_lib�
linkopts�
Add these flags to the C++ linker command.
Subject to <a href="make-variables.html">"Make" variable</a> substitution,
<a href="common-definitions.html#sh-tokenization">
Bourne shell tokenization</a> and
<a href="common-definitions.html#label-expansion">label expansion</a>.
Each string in this attribute is added to <code>LINKOPTS</code> before
linking the binary target.
<p>
    Each element of this list that does not start with <code>$</code> or <code>-</code> is
    assumed to be the label of a target in <code>deps</code>. The
    list of files generated by that target is appended to the linker
    options.  An error is reported if the label is invalid, or is
    not declared in <code>deps</code>.
</p>
2[]�

linkshared�
Create a shared library.
To enable this attribute, include <code>linkshared=True</code> in your rule. By default
this option is off.
<p>
  The presence of this flag means that linking occurs with the <code>-shared</code> flag
  to <code>gcc</code>, and the resulting shared library is suitable for loading into for
  example a Java program. However, for build purposes it will never be linked into the
  dependent binary, as it is assumed that shared libraries built with a
  <a href="#cc_binary">cc_binary</a> rule are only loaded manually by other programs, so
  it should not be considered a substitute for the <a href="#cc_library">cc_library</a>
  rule. For sake of scalability we recommend avoiding this approach altogether and
  simply letting <code>java_library</code> depend on <code>cc_library</code> rules
  instead.
</p>
<p>
  If you specify both <code>linkopts=['-static']</code> and <code>linkshared=True</code>,
  you get a single completely self-contained unit. If you specify both
  <code>linkstatic=True</code> and <code>linkshared=True</code>, you get a single, mostly
  self-contained unit.
</p>
2False�

linkstatic�
For <a href="${link cc_binary}"><code>cc_binary</code></a> and
<a href="${link cc_test}"><code>cc_test</code></a>: link the binary in static
mode. For <code>cc_library.link_static</code>: see below.
<p>By default this option is on for <code>cc_binary</code> and off for the rest.</p>
<p>
  If enabled and this is a binary or test, this option tells the build tool to link in
  <code>.a</code>'s instead of <code>.so</code>'s for user libraries whenever possible.
  System libraries such as libc (but <i>not</i> the C/C++ runtime libraries,
  see below) are still linked dynamically, as are libraries for which
  there is no static library. So the resulting executable will still be dynamically
  linked, hence only <i>mostly</i> static.
</p>
<p>
There are really three different ways to link an executable:
</p>
<ul>
<li> STATIC with fully_static_link feature, in which everything is linked statically;
  e.g. "<code>gcc -static foo.o libbar.a libbaz.a -lm</code>".<br/>
  This mode is enabled by specifying <code>fully_static_link</code> in the
  <a href="${link common-definitions#features}"><code>features</code></a> attribute.</li>
<li> STATIC, in which all user libraries are linked statically (if a static
  version is available), but where system libraries (excluding C/C++ runtime libraries)
  are linked dynamically, e.g. "<code>gcc foo.o libfoo.a libbaz.a -lm</code>".<br/>
  This mode is enabled by specifying <code>linkstatic=True</code>.</li>
<li> DYNAMIC, in which all libraries are linked dynamically (if a dynamic version is
  available), e.g. "<code>gcc foo.o libfoo.so libbaz.so -lm</code>".<br/>
  This mode is enabled by specifying <code>linkstatic=False</code>.</li>
</ul>
<p>
If the <code>linkstatic</code> attribute or <code>fully_static_link</code> in
<code>features</code> is used outside of <code>//third_party</code>
please include a comment near the rule to explain why.
</p>
<p>
The <code>linkstatic</code> attribute has a different meaning if used on a
<a href="${link cc_library}"><code>cc_library()</code></a> rule.
For a C++ library, <code>linkstatic=True</code> indicates that only
static linking is allowed, so no <code>.so</code> will be produced. linkstatic=False does
not prevent static libraries from being created. The attribute is meant to control the
creation of dynamic libraries.
</p>
<p>
There should be very little code built with <code>linkstatic=False</code> in production.
If <code>linkstatic=False</code>, then the build tool will create symlinks to
depended-upon shared libraries in the <code>*.runfiles</code> area.
</p>
2True�
local_defines�
List of defines to add to the compile line.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
Each string, which must consist of a single Bourne shell token,
is prepended with <code>-D</code> and added to the compile command line for this target,
but not to its dependents. Unlike <code>defines</code>, the defines are only added to the
compile command line for this target.
2[]�
malloc�
Override the default dependency on malloc.
<p>
  By default, C++ binaries are linked against <code>//tools/cpp:malloc</code>,
  which is an empty library so the binary ends up using libc malloc.
  This label must refer to a <code>cc_library</code>. If compilation is for a non-C++
  rule, this option has no effect. The value of this attribute is ignored if
  <code>linkshared=True</code> is specified.
</p>
*
CcInfo2@bazel_tools//tools/cpp:malloc�
module_interfaces�
The list of files are regarded as C++20 Modules Interface.

<p>
C++ Standard has no restriction about module interface file extension
<ul>
<li>Clang use cppm </li>
<li>GCC can use any source file extension </li>
<li>MSVC use ixx </li>
</ul>
</p>
<p>The use is guarded by the flag
<code>--experimental_cpp_modules</code>.</p>
2[]�
nocopts�
Remove matching options from the C++ compilation command.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution.
The value of this attribute is interpreted as a regular expression.
Any preexisting <code>COPTS</code> that match this regular expression
(including values explicitly specified in the rule's <a
href="#cc_binary.copts">copts</a> attribute)
will be removed from <code>COPTS</code> for purposes of compiling this rule.
This attribute should not be needed or used
outside of <code>third_party</code>.  The values are not preprocessed
in any way other than the "Make" variable substitution.
2""
reexport_deps2[]�
srcs�
The list of C and C++ files that are processed to create the library target.
These are C/C++ source and header files, either non-generated (normal source
code) or generated.
<p>All <code>.cc</code>, <code>.c</code>, and <code>.cpp</code> files will
   be compiled. These might be generated files: if a named file is in
   the <code>outs</code> of some other rule, this <code>cc_library</code>
   will automatically depend on that other rule.
</p>
<p>Pure assembler files (.s, .asm) are not preprocessed and are typically built using
the assembler. Preprocessed assembly files (.S) are preprocessed and are typically built
using the C/C++ compiler.
</p>
<p>A <code>.h</code> file will not be compiled, but will be available for
   inclusion by sources in this rule. Both <code>.cc</code> and
   <code>.h</code> files can directly include headers listed in
   these <code>srcs</code> or in the <code>hdrs</code> of this rule or any
   rule listed in the <code>deps</code> argument.
</p>
<p>All <code>#include</code>d files must be mentioned in the
   <code>hdrs</code> attribute of this or referenced <code>cc_library</code>
   rules, or they should be listed in <code>srcs</code> if they are private
   to this library. See <a href="#hdrs">"Header inclusion checking"</a> for
   a more detailed description.
</p>
<p><code>.so</code>, <code>.lo</code>, and <code>.a</code> files are
   pre-compiled files. Your library might have these as
   <code>srcs</code> if it uses third-party code for which we don't
   have source code.
</p>
<p>If the <code>srcs</code> attribute includes the label of another rule,
   <code>cc_library</code> will use the output files of that rule as source files to
   compile. This is useful for one-off generation of source code (for more than occasional
   use, it's better to implement a Starlark rule class and use the <code>cc_common</code>
   API)
</p>
<p>
  Permitted <code>srcs</code> file types:
</p>
<ul>
<li>C and C++ source files: <code>.c</code>, <code>.cc</code>, <code>.cpp</code>,
  <code>.cxx</code>, <code>.c++</code>, <code>.C</code></li>
<li>C and C++ header files: <code>.h</code>, <code>.hh</code>, <code>.hpp</code>,
  <code>.hxx</code>, <code>.inc</code>, <code>.inl</code>, <code>.H</code></li>
<li>Assembler with C preprocessor: <code>.S</code></li>
<li>Archive: <code>.a</code>, <code>.pic.a</code></li>
<li>"Always link" library: <code>.lo</code>, <code>.pic.lo</code></li>
<li>Shared library, versioned or unversioned: <code>.so</code>,
  <code>.so.<i>version</i></code></li>
<li>Object file: <code>.o</code>, <code>.pic.o</code></li>
</ul>

<p>
  ... and any rules that produce those files (e.g. <code>cc_embed_data</code>).
  Different extensions denote different programming languages in
  accordance with gcc convention.
</p>
2[]�
stamp�
Whether to encode build information into the binary. Possible values:
<ul>
<li>
  <code>stamp = 1</code>: Always stamp the build information into the binary, even in
  <a href="${link user-manual#flag--stamp}"><code>--nostamp</code></a> builds. <b>This
  setting should be avoided</b>, since it potentially kills remote caching for the
  binary and any downstream actions that depend on it.
</li>
<li>
  <code>stamp = 0</code>: Always replace build information by constant values. This
  gives good build result caching.
</li>
<li>
  <code>stamp = -1</code>: Embedding of build information is controlled by the
  <a href="${link user-manual#flag--stamp}"><code>--[no]stamp</code></a> flag.
</li>
</ul>
<p>Stamped binaries are <em>not</em> rebuilt unless their dependencies change.</p>
2-1�
win_def_file�
The Windows DEF file to be passed to linker.
<p>This attribute should only be used when Windows is the target platform.
It can be used to <a href="https://msdn.microsoft.com/en-us/library/d91k01sh.aspx">
export symbols</a> during linking a shared library.</p>
2None
��,
*
nameA unique name for this target. �
�
additional_linker_inputs�
Dependencies that are only made available to the C++ linker command.
<p>
  Unlike <code>deps</code>, which is conceptually made for both compilation and
  linking dependencies, <code>additional_linker_inputs</code> is specifically
  made for only the latter, and signals a dependency that is required only for
  linking (for example, files that are referenced in <code>linkopts</code>).
</p>
<p>
  For example, compiled Windows .res files can be provided here to be embedded in
  the binary target.
</p>
2[]�
�
	conlyopts�
Add these options to the C compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
2[]�
�
copts�
Add these options to the C/C++ compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
<p>
  Each string in this attribute is added in the given order to <code>COPTS</code> before
  compiling the binary target. The flags take effect only for compiling this target, not
  its dependencies, so be careful about header files included elsewhere.
  All paths should be relative to the workspace, not to the current package.
  This attribute should not be needed outside of <code>third_party</code>.
</p>
<p>
  If the package declares the <a href="${link package.features}">feature</a>
  <code>no_copts_tokenization</code>, Bourne shell tokenization applies only to strings
  that consist of a single "Make" variable.
</p>
2[]�
�
cxxopts�
Add these options to the C++ compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
2[]�
�
data�
The list of files needed by this library at runtime.

See general comments about <code>data</code>
at <a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>If a <code>data</code> is the name of a generated file, then this
   <code>cc_library</code> rule automatically depends on the generating
   rule.
</p>
<p>If a <code>data</code> is a rule name, then this
   <code>cc_library</code> rule automatically depends on that rule,
   and that rule's <code>outs</code> are automatically added to
   this <code>cc_library</code>'s data files.
</p>
<p>Your C++ code can access these data files like so:</p>
<pre><code class="lang-starlark">
  const std::string path = devtools_build::GetDataDependencyFilepath(
      "my/test/data/file");
</code></pre>
2[]�
�
defines�
List of defines to add to the compile line of this and all dependent targets.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
Each string, which must consist of a single Bourne shell token,
is prepended with <code>-D</code> and added to the compile command line to this target,
as well as to every rule that depends on it. Be very careful, since this may have
far-reaching effects -- the defines are added to every target that depends on
this target.  When in doubt, add define values to
<a href="#cc_binary.local_defines"><code>local_defines</code></a> instead.
2[]�
�
deps�
The list of other libraries to be linked in to the binary target.
<p>These can be <code>cc_library</code> or <code>objc_library</code>
targets.</p>

It is also allowed to
put linker scripts (.lds) into deps, and reference them in
<a href="#cc_binary.linkopts"><code>linkopts</code></a>,
but please consider
<a href="#cc_binary.additional_linker_inputs"><code>additional_linker_inputs</code></a>
for that use case.
*
CcInfo2[]�
�
dynamic_deps�
These are other <code>cc_shared_library</code> dependencies the current target depends on.

<p>
The <code>cc_shared_library</code> implementation will use the list of
<code>dynamic_deps</code> (transitively, i.e. also the <code>dynamic_deps</code> of the
current target's <code>dynamic_deps</code>) to decide which <code>cc_libraries</code> in
the transitive <code>deps</code> should not be linked in because they are already provided
by a different <code>cc_shared_library</code>.
*
CcSharedLibraryInfo2[]

env
2{}(
&

hdrs_checkDeprecated, no-op.2""�
�
includes�
List of include dirs to be added to the compile line.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution.
Each string is prepended with the package path and passed to the C++ toolchain for
expansion via the "include_paths" CROSSTOOL feature. A toolchain running on a POSIX system
with typical feature definitions will produce
<code>-isystem path_to_package/include_entry</code>.
This should only be used for third-party libraries that
do not conform to the Google style of writing #include statements.
Unlike <a href="#cc_binary.copts">COPTS</a>, these flags are added for this rule
and every rule that depends on it. (Note: not the rules it depends upon!) Be
very careful, since this may have far-reaching effects.  When in doubt, add
"-I" flags to <a href="#cc_binary.copts">COPTS</a> instead.
<p>
The added <code>include</code> paths will include generated files as well as
files in the source tree.
</p>
2[]

licenses2[]�
�
link_extra_lib�
Control linking of extra libraries.
<p>
    By default, C++ binaries are linked against <code>@bazel_tools//tools/cpp:link_extra_lib</code>,
    which by default depends on the label flag <code>@bazel_tools//tools/cpp:link_extra_libs</code>.
    Without setting the flag, this library is empty by default. Setting the label flag
    allows linking optional dependencies, such as overrides for weak symbols, interceptors
    for shared library functions, or special runtime libraries (for malloc replacements,
    prefer <code>malloc</code> or <code>--custom_malloc</code>). Setting this attribute to
    <code>None</code> disables this behaviour.
</p>
*
CcInfo2&@bazel_tools//tools/cpp:link_extra_lib�
�
linkopts�
Add these flags to the C++ linker command.
Subject to <a href="make-variables.html">"Make" variable</a> substitution,
<a href="common-definitions.html#sh-tokenization">
Bourne shell tokenization</a> and
<a href="common-definitions.html#label-expansion">label expansion</a>.
Each string in this attribute is added to <code>LINKOPTS</code> before
linking the binary target.
<p>
    Each element of this list that does not start with <code>$</code> or <code>-</code> is
    assumed to be the label of a target in <code>deps</code>. The
    list of files generated by that target is appended to the linker
    options.  An error is reported if the label is invalid, or is
    not declared in <code>deps</code>.
</p>
2[]�
�

linkshared�
Create a shared library.
To enable this attribute, include <code>linkshared=True</code> in your rule. By default
this option is off.
<p>
  The presence of this flag means that linking occurs with the <code>-shared</code> flag
  to <code>gcc</code>, and the resulting shared library is suitable for loading into for
  example a Java program. However, for build purposes it will never be linked into the
  dependent binary, as it is assumed that shared libraries built with a
  <a href="#cc_binary">cc_binary</a> rule are only loaded manually by other programs, so
  it should not be considered a substitute for the <a href="#cc_library">cc_library</a>
  rule. For sake of scalability we recommend avoiding this approach altogether and
  simply letting <code>java_library</code> depend on <code>cc_library</code> rules
  instead.
</p>
<p>
  If you specify both <code>linkopts=['-static']</code> and <code>linkshared=True</code>,
  you get a single completely self-contained unit. If you specify both
  <code>linkstatic=True</code> and <code>linkshared=True</code>, you get a single, mostly
  self-contained unit.
</p>
2False�
�

linkstatic�
For <a href="${link cc_binary}"><code>cc_binary</code></a> and
<a href="${link cc_test}"><code>cc_test</code></a>: link the binary in static
mode. For <code>cc_library.link_static</code>: see below.
<p>By default this option is on for <code>cc_binary</code> and off for the rest.</p>
<p>
  If enabled and this is a binary or test, this option tells the build tool to link in
  <code>.a</code>'s instead of <code>.so</code>'s for user libraries whenever possible.
  System libraries such as libc (but <i>not</i> the C/C++ runtime libraries,
  see below) are still linked dynamically, as are libraries for which
  there is no static library. So the resulting executable will still be dynamically
  linked, hence only <i>mostly</i> static.
</p>
<p>
There are really three different ways to link an executable:
</p>
<ul>
<li> STATIC with fully_static_link feature, in which everything is linked statically;
  e.g. "<code>gcc -static foo.o libbar.a libbaz.a -lm</code>".<br/>
  This mode is enabled by specifying <code>fully_static_link</code> in the
  <a href="${link common-definitions#features}"><code>features</code></a> attribute.</li>
<li> STATIC, in which all user libraries are linked statically (if a static
  version is available), but where system libraries (excluding C/C++ runtime libraries)
  are linked dynamically, e.g. "<code>gcc foo.o libfoo.a libbaz.a -lm</code>".<br/>
  This mode is enabled by specifying <code>linkstatic=True</code>.</li>
<li> DYNAMIC, in which all libraries are linked dynamically (if a dynamic version is
  available), e.g. "<code>gcc foo.o libfoo.so libbaz.so -lm</code>".<br/>
  This mode is enabled by specifying <code>linkstatic=False</code>.</li>
</ul>
<p>
If the <code>linkstatic</code> attribute or <code>fully_static_link</code> in
<code>features</code> is used outside of <code>//third_party</code>
please include a comment near the rule to explain why.
</p>
<p>
The <code>linkstatic</code> attribute has a different meaning if used on a
<a href="${link cc_library}"><code>cc_library()</code></a> rule.
For a C++ library, <code>linkstatic=True</code> indicates that only
static linking is allowed, so no <code>.so</code> will be produced. linkstatic=False does
not prevent static libraries from being created. The attribute is meant to control the
creation of dynamic libraries.
</p>
<p>
There should be very little code built with <code>linkstatic=False</code> in production.
If <code>linkstatic=False</code>, then the build tool will create symlinks to
depended-upon shared libraries in the <code>*.runfiles</code> area.
</p>
2True�
�
local_defines�
List of defines to add to the compile line.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
Each string, which must consist of a single Bourne shell token,
is prepended with <code>-D</code> and added to the compile command line for this target,
but not to its dependents. Unlike <code>defines</code>, the defines are only added to the
compile command line for this target.
2[]�
�
malloc�
Override the default dependency on malloc.
<p>
  By default, C++ binaries are linked against <code>//tools/cpp:malloc</code>,
  which is an empty library so the binary ends up using libc malloc.
  This label must refer to a <code>cc_library</code>. If compilation is for a non-C++
  rule, this option has no effect. The value of this attribute is ignored if
  <code>linkshared=True</code> is specified.
</p>
*
CcInfo2@bazel_tools//tools/cpp:malloc�
�
module_interfaces�
The list of files are regarded as C++20 Modules Interface.

<p>
C++ Standard has no restriction about module interface file extension
<ul>
<li>Clang use cppm </li>
<li>GCC can use any source file extension </li>
<li>MSVC use ixx </li>
</ul>
</p>
<p>The use is guarded by the flag
<code>--experimental_cpp_modules</code>.</p>
2[]�
�
nocopts�
Remove matching options from the C++ compilation command.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution.
The value of this attribute is interpreted as a regular expression.
Any preexisting <code>COPTS</code> that match this regular expression
(including values explicitly specified in the rule's <a
href="#cc_binary.copts">copts</a> attribute)
will be removed from <code>COPTS</code> for purposes of compiling this rule.
This attribute should not be needed or used
outside of <code>third_party</code>.  The values are not preprocessed
in any way other than the "Make" variable substitution.
2""

reexport_deps2[]�
�
srcs�
The list of C and C++ files that are processed to create the library target.
These are C/C++ source and header files, either non-generated (normal source
code) or generated.
<p>All <code>.cc</code>, <code>.c</code>, and <code>.cpp</code> files will
   be compiled. These might be generated files: if a named file is in
   the <code>outs</code> of some other rule, this <code>cc_library</code>
   will automatically depend on that other rule.
</p>
<p>Pure assembler files (.s, .asm) are not preprocessed and are typically built using
the assembler. Preprocessed assembly files (.S) are preprocessed and are typically built
using the C/C++ compiler.
</p>
<p>A <code>.h</code> file will not be compiled, but will be available for
   inclusion by sources in this rule. Both <code>.cc</code> and
   <code>.h</code> files can directly include headers listed in
   these <code>srcs</code> or in the <code>hdrs</code> of this rule or any
   rule listed in the <code>deps</code> argument.
</p>
<p>All <code>#include</code>d files must be mentioned in the
   <code>hdrs</code> attribute of this or referenced <code>cc_library</code>
   rules, or they should be listed in <code>srcs</code> if they are private
   to this library. See <a href="#hdrs">"Header inclusion checking"</a> for
   a more detailed description.
</p>
<p><code>.so</code>, <code>.lo</code>, and <code>.a</code> files are
   pre-compiled files. Your library might have these as
   <code>srcs</code> if it uses third-party code for which we don't
   have source code.
</p>
<p>If the <code>srcs</code> attribute includes the label of another rule,
   <code>cc_library</code> will use the output files of that rule as source files to
   compile. This is useful for one-off generation of source code (for more than occasional
   use, it's better to implement a Starlark rule class and use the <code>cc_common</code>
   API)
</p>
<p>
  Permitted <code>srcs</code> file types:
</p>
<ul>
<li>C and C++ source files: <code>.c</code>, <code>.cc</code>, <code>.cpp</code>,
  <code>.cxx</code>, <code>.c++</code>, <code>.C</code></li>
<li>C and C++ header files: <code>.h</code>, <code>.hh</code>, <code>.hpp</code>,
  <code>.hxx</code>, <code>.inc</code>, <code>.inl</code>, <code>.H</code></li>
<li>Assembler with C preprocessor: <code>.S</code></li>
<li>Archive: <code>.a</code>, <code>.pic.a</code></li>
<li>"Always link" library: <code>.lo</code>, <code>.pic.lo</code></li>
<li>Shared library, versioned or unversioned: <code>.so</code>,
  <code>.so.<i>version</i></code></li>
<li>Object file: <code>.o</code>, <code>.pic.o</code></li>
</ul>

<p>
  ... and any rules that produce those files (e.g. <code>cc_embed_data</code>).
  Different extensions denote different programming languages in
  accordance with gcc convention.
</p>
2[]�
�
stamp�
Whether to encode build information into the binary. Possible values:
<ul>
<li>
  <code>stamp = 1</code>: Always stamp the build information into the binary, even in
  <a href="${link user-manual#flag--stamp}"><code>--nostamp</code></a> builds. <b>This
  setting should be avoided</b>, since it potentially kills remote caching for the
  binary and any downstream actions that depend on it.
</li>
<li>
  <code>stamp = 0</code>: Always replace build information by constant values. This
  gives good build result caching.
</li>
<li>
  <code>stamp = -1</code>: Embedding of build information is controlled by the
  <a href="${link user-manual#flag--stamp}"><code>--[no]stamp</code></a> flag.
</li>
</ul>
<p>Stamped binaries are <em>not</em> rebuilt unless their dependencies change.</p>
2-1�
�
win_def_file�
The Windows DEF file to be passed to linker.
<p>This attribute should only be used when Windows is the target platform.
It can be used to <a href="https://msdn.microsoft.com/en-us/library/d91k01sh.aspx">
export symbols</a> during linking a shared library.</p>
2None�SinglePlatformArtifactInfo2�
�
SinglePlatformArtifactInfo
cpu(Undocumented)
file(Undocumented)
os(Undocumented)
platform(Undocumented)"I
SinglePlatformArtifactInfo+@@rules_jni//jni/private:cc_jni_library.bzl
&&

cpu(Undocumented)

file(Undocumented)

os(Undocumented)

platform(Undocumented)k
//cc:cc_binary.bzlrS

rules_cccccc_binary.bzl$
	cc_binary	cc_binary
&/
1}
//java:java_library.bzlr`
$

rules_javajavajava_library.bzl*
java_libraryjava_library
-9
;�
//jni/private:os_cpu_utils.bzlr�
*
	rules_jnijni/privateos_cpu_utils.bzl4
SELECT_TARGET_CPUSELECT_TARGET_CPU
3D2
SELECT_TARGET_OSSELECT_TARGET_OS
HX
Z�
//jni/private:transitions.bzlr
)
	rules_jnijni/privatetransitions.bzlD
multi_platform_transitionmulti_platform_transition
2K
M�
$
	rules_jnijni/private
common.bzl�merge_cc_infos"�
�
merge_cc_infos*
nameA unique name for this target. 
deps*
CcInfo2[]"5
merge_cc_infos#@@rules_jni//jni/private:common.bzl
**,
*
nameA unique name for this target. 

deps*
CcInfo2[]�merge_java_infos"�
�
merge_java_infos*
nameA unique name for this target. 
deps*

JavaInfo2[]"7
merge_java_infos#@@rules_jni//jni/private:common.bzl
>>,
*
nameA unique name for this target. 

deps*

JavaInfo2[]�java_identifier*l
U
java_identifier

name (26
java_identifier#@@rules_jni//jni/private:common.bzl
[[2_hash�jni_escaped_identifier*�
c
jni_escaped_identifier

name (2=
jni_escaped_identifier#@@rules_jni//jni/private:common.bzl
aa2java_identifier�make_root_relative*~
n
make_root_relative

path (
packageNone(29
make_root_relative#@@rules_jni//jni/private:common.bzl
HHy
//cc/common:cc_common.bzlrZ
$
rules_cc	cc/commoncc_common.bzl$
	cc_common	cc_common
-6
8o
//cc/common:cc_info.bzlrR
"
rules_cc	cc/commoncc_info.bzl
CcInfoCcInfo
+1
3�
//java/common:java_common.bzlrd
*

rules_javajava/commonjava_common.bzl(
java_commonjava_common
3>
@}
//java/common:java_info.bzlr\
(

rules_javajava/commonjava_info.bzl"
JavaInfoJavaInfo
19
;̬
.
	rules_jnijni/privatejava_jni_library.bzl��java_jni_library�A Java library that bundles one or more native libraries created with [`cc_jni_library`](#cc_jni_library).

To load a native library referenced in the `native_libs` argument, use the static methods of the
[`RulesJni`](https://fmeum.github.io/rules_jni_javadocs/com/github/fmeum/rules_jni/RulesJni.html) class, which is
accessible for `srcs` of this target due to an implicit dependency on
[`@fmeum_rules_jni//jni/tools/native_loader`](targets.md#native_loader). These methods automatically choose the
correct version of the library for the current OS and CPU architecture, if available.

The native libraries referenced in the `native_libs` argument are added as resources and are thus included in the
deploy JARs of any [`java_binary`](https://docs.bazel.build/versions/main/be/java.html#java_binary) depending on
this target.

### Implicit output targets

- `<name>.hdrs`: The auto-generated JNI headers for this library.

  This target can be added to the `deps` of a
  [`cc_library`](https://docs.bazel.build/versions/main/be/c-cpp.html#cc_library) or
  [`cc_jni_library`](#cc_jni_library). See [`jni_headers`](#jni_headers) for a more detailed description of the
  underlying rule.



<p>This rule compiles and links sources into a <code>.jar</code> file.</p>

<h4>Implicit outputs</h4>
<ul>
  <li><code>lib<var>name</var>.jar</code>: A Java archive containing the class files.</li>
  <li><code>lib<var>name</var>-src.jar</code>: An archive containing the sources ("source
    jar").</li>
</ul>
"��
�T
java_jni_library�A Java library that bundles one or more native libraries created with [`cc_jni_library`](#cc_jni_library).

To load a native library referenced in the `native_libs` argument, use the static methods of the
[`RulesJni`](https://fmeum.github.io/rules_jni_javadocs/com/github/fmeum/rules_jni/RulesJni.html) class, which is
accessible for `srcs` of this target due to an implicit dependency on
[`@fmeum_rules_jni//jni/tools/native_loader`](targets.md#native_loader). These methods automatically choose the
correct version of the library for the current OS and CPU architecture, if available.

The native libraries referenced in the `native_libs` argument are added as resources and are thus included in the
deploy JARs of any [`java_binary`](https://docs.bazel.build/versions/main/be/java.html#java_binary) depending on
this target.

### Implicit output targets

- `<name>.hdrs`: The auto-generated JNI headers for this library.

  This target can be added to the `deps` of a
  [`cc_library`](https://docs.bazel.build/versions/main/be/c-cpp.html#cc_library) or
  [`cc_jni_library`](#cc_jni_library). See [`jni_headers`](#jni_headers) for a more detailed description of the
  underlying rule.



<p>This rule compiles and links sources into a <code>.jar</code> file.</p>

<h4>Implicit outputs</h4>
<ul>
  <li><code>lib<var>name</var>.jar</code>: A Java archive containing the class files.</li>
  <li><code>lib<var>name</var>-src.jar</code>: An archive containing the sources ("source
    jar").</li>
</ul>
*
nameA unique name for this target. �
add_exports�
Allow this library to access the given <code>module</code> or <code>package</code>.
<p>
This corresponds to the javac and JVM --add-exports= flags.
2[]�
	add_opens�
Allow this library to reflectively access the given <code>module</code> or
<code>package</code>.
<p>
This corresponds to the javac and JVM --add-opens= flags.
2[]I
bootclasspathRestricted API, do not use!*
BootClassPathInfo2None�
data�
The list of files needed by this library at runtime.
See general comments about <code>data</code> at
<a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>
  When building a <code>java_library</code>, Bazel doesn't put these files anywhere; if the
  <code>data</code> files are generated files then Bazel generates them. When building a
  test that depends on this <code>java_library</code> Bazel copies or links the
  <code>data</code> files into the runfiles area.
</p>
2[]�
deps�
The list of libraries to link into this library.
See general comments about <code>deps</code> at
<a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>
  The jars built by <code>java_library</code> rules listed in <code>deps</code> will be on
  the compile-time classpath of this rule. Furthermore the transitive closure of their
  <code>deps</code>, <code>runtime_deps</code> and <code>exports</code> will be on the
  runtime classpath.
</p>
<p>
  By contrast, targets in the <code>data</code> attribute are included in the runfiles but
  on neither the compile-time nor runtime classpath.
</p>
*
CcInfo*

JavaInfo2[]�
exported_plugins�
The list of <code><a href="#${link java_plugin}">java_plugin</a></code>s (e.g. annotation
processors) to export to libraries that directly depend on this library.
<p>
  The specified list of <code>java_plugin</code>s will be applied to any library which
  directly depends on this library, just as if that library had explicitly declared these
  labels in <code><a href="${link java_library.plugins}">plugins</a></code>.
</p>
*
JavaPluginInfo2[]�
exports�
Exported libraries.
<p>
  Listing rules here will make them available to parent rules, as if the parents explicitly
  depended on these rules. This is not true for regular (non-exported) <code>deps</code>.
</p>
<p>
  Summary: a rule <i>X</i> can access the code in <i>Y</i> if there exists a dependency
  path between them that begins with a <code>deps</code> edge followed by zero or more
  <code>exports</code> edges. Let's see some examples to illustrate this.
</p>
<p>
  Assume <i>A</i> depends on <i>B</i> and <i>B</i> depends on <i>C</i>. In this case
  C is a <em>transitive</em> dependency of A, so changing C's sources and rebuilding A will
  correctly rebuild everything. However A will not be able to use classes in C. To allow
  that, either A has to declare C in its <code>deps</code>, or B can make it easier for A
  (and anything that may depend on A) by declaring C in its (B's) <code>exports</code>
  attribute.
</p>
<p>
  The closure of exported libraries is available to all direct parent rules. Take a slightly
  different example: A depends on B, B depends on C and D, and also exports C but not D.
  Now A has access to C but not to D. Now, if C and D exported some libraries, C' and D'
  respectively, A could only access C' but not D'.
</p>
<p>
  Important: an exported rule is not a regular dependency. Sticking to the previous example,
  if B exports C and wants to also use C, it has to also list it in its own
  <code>deps</code>.
</p>
*

JavaInfo*
CcInfo2[]:
javabuilder_jvm_flagsRestricted API, do not use!2[]�
	javacopts�
Extra compiler options for this library.
Subject to <a href="make-variables.html">"Make variable"</a> substitution and
<a href="common-definitions.html#sh-tokenization">Bourne shell tokenization</a>.
<p>These compiler options are passed to javac after the global compiler options.</p>
2[]
licenses2[]�
	neverlink�
Whether this library should only be used for compilation and not at runtime.
Useful if the library will be provided by the runtime environment during execution. Examples
of such libraries are the IDE APIs for IDE plug-ins or <code>tools.jar</code> for anything
running on a standard JDK.
<p>
  Note that <code>neverlink = True</code> does not prevent the compiler from inlining material
  from this library into compilation targets that depend on it, as permitted by the Java
  Language Specification (e.g., <code>static final</code> constants of <code>String</code>
  or of primitive types). The preferred use case is therefore when the runtime library is
  identical to the compilation library.
</p>
<p>
  If the runtime library differs from the compilation library then you must ensure that it
  differs only in places that the JLS forbids compilers to inline (and that must hold for
  all future versions of the JLS).
</p>
2False�
plugins�
Java compiler plugins to run at compile-time.
Every <code>java_plugin</code> specified in this attribute will be run whenever this rule
is built. A library may also inherit plugins from dependencies that use
<code><a href="#java_library.exported_plugins">exported_plugins</a></code>. Resources
generated by the plugin will be included in the resulting jar of this rule.
*
JavaPluginInfo2[]�
proguard_specs�
Files to be used as Proguard specification.
These will describe the set of specifications to be used by Proguard. If specified,
they will be added to any <code>android_binary</code> target depending on this library.

The files included here must only have idempotent rules, namely -dontnote, -dontwarn,
assumenosideeffects, and rules that start with -keep. Other options can only appear in
<code>android_binary</code>'s proguard_specs, to ensure non-tautological merges.
2[]�
resource_strip_prefix�
The path prefix to strip from Java resources.
<p>
If specified, this path prefix is stripped from every file in the <code>resources</code>
attribute. It is an error for a resource file not to be under this directory. If not
specified (the default), the path of resource file is determined according to the same
logic as the Java package of source files. For example, a source file at
<code>stuff/java/foo/bar/a.txt</code> will be located at <code>foo/bar/a.txt</code>.
</p>
2""�
	resources�
A list of data files to include in a Java jar.
<p>
Resources may be source files or generated files.
</p>

<p>
If resources are specified, they will be bundled in the jar along with the usual
<code>.class</code> files produced by compilation. The location of the resources inside
of the jar file is determined by the project structure. Bazel first looks for Maven's
<a href="https://maven.apache.org/guides/introduction/introduction-to-the-standard-directory-layout.html">standard directory layout</a>,
(a "src" directory followed by a "resources" directory grandchild). If that is not
found, Bazel then looks for the topmost directory named "java" or "javatests" (so, for
example, if a resource is at <code>&lt;workspace root&gt;/x/java/y/java/z</code>, the
path of the resource will be <code>y/java/z</code>. This heuristic cannot be overridden,
however, the <code>resource_strip_prefix</code> attribute can be used to specify a
specific alternative directory for resource files.
2[]�
runtime_deps�
Libraries to make available to the final binary or test at runtime only.
Like ordinary <code>deps</code>, these will appear on the runtime classpath, but unlike
them, not on the compile-time classpath. Dependencies needed only at runtime should be
listed here. Dependency-analysis tools should ignore targets that appear in both
<code>runtime_deps</code> and <code>deps</code>.
*
CcInfo*

JavaInfo2[]�

srcs�

The list of source files that are processed to create the target.
This attribute is almost always required; see exceptions below.
<p>
Source files of type <code>.java</code> are compiled. In case of generated
<code>.java</code> files it is generally advisable to put the generating rule's name
here instead of the name of the file itself. This not only improves readability but
makes the rule more resilient to future changes: if the generating rule generates
different files in the future, you only need to fix one place: the <code>outs</code> of
the generating rule. You should not list the generating rule in <code>deps</code>
because it is a no-op.
</p>
<p>
Source files of type <code>.srcjar</code> are unpacked and compiled. (This is useful if
you need to generate a set of <code>.java</code> files with a genrule.)
</p>
<p>
Rules: if the rule (typically <code>genrule</code> or <code>filegroup</code>) generates
any of the files listed above, they will be used the same way as described for source
files.
</p>
<p>
Source files of type <code>.properties</code> are treated as resources.
</p>

<p>All other files are ignored, as long as there is at least one file of a
file type described above. Otherwise an error is raised.</p>

<p>
This argument is almost always required, except if you specify the <code>runtime_deps</code> argument.
</p>
2[]
,
*
nameA unique name for this target. �
�
add_exports�
Allow this library to access the given <code>module</code> or <code>package</code>.
<p>
This corresponds to the javac and JVM --add-exports= flags.
2[]�
�
	add_opens�
Allow this library to reflectively access the given <code>module</code> or
<code>package</code>.
<p>
This corresponds to the javac and JVM --add-opens= flags.
2[]K
I
bootclasspathRestricted API, do not use!*
BootClassPathInfo2None�
�
data�
The list of files needed by this library at runtime.
See general comments about <code>data</code> at
<a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>
  When building a <code>java_library</code>, Bazel doesn't put these files anywhere; if the
  <code>data</code> files are generated files then Bazel generates them. When building a
  test that depends on this <code>java_library</code> Bazel copies or links the
  <code>data</code> files into the runfiles area.
</p>
2[]�
�
deps�
The list of libraries to link into this library.
See general comments about <code>deps</code> at
<a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>
  The jars built by <code>java_library</code> rules listed in <code>deps</code> will be on
  the compile-time classpath of this rule. Furthermore the transitive closure of their
  <code>deps</code>, <code>runtime_deps</code> and <code>exports</code> will be on the
  runtime classpath.
</p>
<p>
  By contrast, targets in the <code>data</code> attribute are included in the runfiles but
  on neither the compile-time nor runtime classpath.
</p>
*
CcInfo*

JavaInfo2[]�
�
exported_plugins�
The list of <code><a href="#${link java_plugin}">java_plugin</a></code>s (e.g. annotation
processors) to export to libraries that directly depend on this library.
<p>
  The specified list of <code>java_plugin</code>s will be applied to any library which
  directly depends on this library, just as if that library had explicitly declared these
  labels in <code><a href="${link java_library.plugins}">plugins</a></code>.
</p>
*
JavaPluginInfo2[]�
�
exports�
Exported libraries.
<p>
  Listing rules here will make them available to parent rules, as if the parents explicitly
  depended on these rules. This is not true for regular (non-exported) <code>deps</code>.
</p>
<p>
  Summary: a rule <i>X</i> can access the code in <i>Y</i> if there exists a dependency
  path between them that begins with a <code>deps</code> edge followed by zero or more
  <code>exports</code> edges. Let's see some examples to illustrate this.
</p>
<p>
  Assume <i>A</i> depends on <i>B</i> and <i>B</i> depends on <i>C</i>. In this case
  C is a <em>transitive</em> dependency of A, so changing C's sources and rebuilding A will
  correctly rebuild everything. However A will not be able to use classes in C. To allow
  that, either A has to declare C in its <code>deps</code>, or B can make it easier for A
  (and anything that may depend on A) by declaring C in its (B's) <code>exports</code>
  attribute.
</p>
<p>
  The closure of exported libraries is available to all direct parent rules. Take a slightly
  different example: A depends on B, B depends on C and D, and also exports C but not D.
  Now A has access to C but not to D. Now, if C and D exported some libraries, C' and D'
  respectively, A could only access C' but not D'.
</p>
<p>
  Important: an exported rule is not a regular dependency. Sticking to the previous example,
  if B exports C and wants to also use C, it has to also list it in its own
  <code>deps</code>.
</p>
*

JavaInfo*
CcInfo2[]<
:
javabuilder_jvm_flagsRestricted API, do not use!2[]�
�
	javacopts�
Extra compiler options for this library.
Subject to <a href="make-variables.html">"Make variable"</a> substitution and
<a href="common-definitions.html#sh-tokenization">Bourne shell tokenization</a>.
<p>These compiler options are passed to javac after the global compiler options.</p>
2[]

licenses2[]�
�
	neverlink�
Whether this library should only be used for compilation and not at runtime.
Useful if the library will be provided by the runtime environment during execution. Examples
of such libraries are the IDE APIs for IDE plug-ins or <code>tools.jar</code> for anything
running on a standard JDK.
<p>
  Note that <code>neverlink = True</code> does not prevent the compiler from inlining material
  from this library into compilation targets that depend on it, as permitted by the Java
  Language Specification (e.g., <code>static final</code> constants of <code>String</code>
  or of primitive types). The preferred use case is therefore when the runtime library is
  identical to the compilation library.
</p>
<p>
  If the runtime library differs from the compilation library then you must ensure that it
  differs only in places that the JLS forbids compilers to inline (and that must hold for
  all future versions of the JLS).
</p>
2False�
�
plugins�
Java compiler plugins to run at compile-time.
Every <code>java_plugin</code> specified in this attribute will be run whenever this rule
is built. A library may also inherit plugins from dependencies that use
<code><a href="#java_library.exported_plugins">exported_plugins</a></code>. Resources
generated by the plugin will be included in the resulting jar of this rule.
*
JavaPluginInfo2[]�
�
proguard_specs�
Files to be used as Proguard specification.
These will describe the set of specifications to be used by Proguard. If specified,
they will be added to any <code>android_binary</code> target depending on this library.

The files included here must only have idempotent rules, namely -dontnote, -dontwarn,
assumenosideeffects, and rules that start with -keep. Other options can only appear in
<code>android_binary</code>'s proguard_specs, to ensure non-tautological merges.
2[]�
�
resource_strip_prefix�
The path prefix to strip from Java resources.
<p>
If specified, this path prefix is stripped from every file in the <code>resources</code>
attribute. It is an error for a resource file not to be under this directory. If not
specified (the default), the path of resource file is determined according to the same
logic as the Java package of source files. For example, a source file at
<code>stuff/java/foo/bar/a.txt</code> will be located at <code>foo/bar/a.txt</code>.
</p>
2""�
�
	resources�
A list of data files to include in a Java jar.
<p>
Resources may be source files or generated files.
</p>

<p>
If resources are specified, they will be bundled in the jar along with the usual
<code>.class</code> files produced by compilation. The location of the resources inside
of the jar file is determined by the project structure. Bazel first looks for Maven's
<a href="https://maven.apache.org/guides/introduction/introduction-to-the-standard-directory-layout.html">standard directory layout</a>,
(a "src" directory followed by a "resources" directory grandchild). If that is not
found, Bazel then looks for the topmost directory named "java" or "javatests" (so, for
example, if a resource is at <code>&lt;workspace root&gt;/x/java/y/java/z</code>, the
path of the resource will be <code>y/java/z</code>. This heuristic cannot be overridden,
however, the <code>resource_strip_prefix</code> attribute can be used to specify a
specific alternative directory for resource files.
2[]�
�
runtime_deps�
Libraries to make available to the final binary or test at runtime only.
Like ordinary <code>deps</code>, these will appear on the runtime classpath, but unlike
them, not on the compile-time classpath. Dependencies needed only at runtime should be
listed here. Dependency-analysis tools should ignore targets that appear in both
<code>runtime_deps</code> and <code>deps</code>.
*
CcInfo*

JavaInfo2[]�

�

srcs�

The list of source files that are processed to create the target.
This attribute is almost always required; see exceptions below.
<p>
Source files of type <code>.java</code> are compiled. In case of generated
<code>.java</code> files it is generally advisable to put the generating rule's name
here instead of the name of the file itself. This not only improves readability but
makes the rule more resilient to future changes: if the generating rule generates
different files in the future, you only need to fix one place: the <code>outs</code> of
the generating rule. You should not list the generating rule in <code>deps</code>
because it is a no-op.
</p>
<p>
Source files of type <code>.srcjar</code> are unpacked and compiled. (This is useful if
you need to generate a set of <code>.java</code> files with a genrule.)
</p>
<p>
Rules: if the rule (typically <code>genrule</code> or <code>filegroup</code>) generates
any of the files listed above, they will be used the same way as described for source
files.
</p>
<p>
Source files of type <code>.properties</code> are treated as resources.
</p>

<p>All other files are ignored, as long as there is at least one file of a
file type described above. Otherwise an error is raised.</p>

<p>
This argument is almost always required, except if you specify the <code>runtime_deps</code> argument.
</p>
2[]}
//java:java_library.bzlr`
$

rules_javajavajava_library.bzl*
java_libraryjava_library
-9
;�
//jni/private:common.bzlrh
$
	rules_jnijni/private
common.bzl2
merge_java_infosmerge_java_infos
-=
?�
//jni/private:jni_headers.bzlrc
)
	rules_jnijni/privatejni_headers.bzl(
jni_headersjni_headers
2=
?�
)
	rules_jnijni/privatejni_headers.bzl�jni_headers�
Generates the native headers for a `java_library` and exposes it to `cc_*` rules.

For every Java class `com.example.Foo` in the `java_library` target specified by `lib` that contains at least one
function marked with `native` or constant annotated with `@Native`, the include directory exported by this rule will
contain a file `com_example_Foo.h` that provides the C/C++ interface for this class. Consuming `cc_*` rules should have
this rule added to their `deps` and can then access such a header file via:

```c
#include "com_example_Foo.h"
```

This rule also directly exports the JNI header, which can be included via:

```c
#include <jni.h>
```

*Example:*

```starlark
load("@fmeum_rules_jni//jni:defs.bzl", "jni_headers")

java_library(
    name = "os_utils",
    ...
)

jni_headers(
    name = "os_utils_hdrs",
    lib = ":os_utils",
)

cc_library(
    name = "os_utils_impl",
    ...
    deps = [":os_utils_hdrs"],
)
```
"�

�
jni_headers�
Generates the native headers for a `java_library` and exposes it to `cc_*` rules.

For every Java class `com.example.Foo` in the `java_library` target specified by `lib` that contains at least one
function marked with `native` or constant annotated with `@Native`, the include directory exported by this rule will
contain a file `com_example_Foo.h` that provides the C/C++ interface for this class. Consuming `cc_*` rules should have
this rule added to their `deps` and can then access such a header file via:

```c
#include "com_example_Foo.h"
```

This rule also directly exports the JNI header, which can be included via:

```c
#include <jni.h>
```

*Example:*

```starlark
load("@fmeum_rules_jni//jni:defs.bzl", "jni_headers")

java_library(
    name = "os_utils",
    ...
)

jni_headers(
    name = "os_utils_hdrs",
    lib = ":os_utils",
)

cc_library(
    name = "os_utils_impl",
    ...
    deps = [":os_utils_hdrs"],
)
```
*
nameA unique name for this target. Z
libCThe Java library for which native header files should be generated. *

JavaInfo"7
jni_headers(@@rules_jni//jni/private:jni_headers.bzl
KK,
*
nameA unique name for this target. \
Z
libCThe Java library for which native header files should be generated. *

JavaInfo�
//tools/cpp:toolchain_utils.bzlru
-
bazel_tools	tools/cpptoolchain_utils.bzl6
find_cpp_toolchainfind_cpp_toolchain
6H
Jy
//cc/common:cc_common.bzlrZ
$
rules_cc	cc/commoncc_common.bzl$
	cc_common	cc_common
-6
8o
//cc/common:cc_info.bzlrR
"
rules_cc	cc/commoncc_info.bzl
CcInfoCcInfo
+1
3}
//java/common:java_info.bzlr\
(

rules_javajava/commonjava_info.bzl"
JavaInfoJavaInfo
19
;�
//jni/private:transitions.bzlr�
)
	rules_jnijni/privatetransitions.bzln
.return_to_original_target_platforms_transition.return_to_original_target_platforms_transition
2`
b�
*
	rules_jnijni/privateos_cpu_utils.bzlW	CPUSjM2K
	aarch64
arm
mips64
ppc
	riscv64
s390x
x86_32
x86_64J	OSESj@2>
	freebsd
linux
macos
	openbsd
	windows
	android)	SELECT_TARGET_CPUaarch64j	aarch64(	SELECT_TARGET_OSfreebsdj	freebsd�
*
	rules_jnijni/privaterepositories.bzl_jdk_deps*Q
A
jdk_deps25
jdk_deps)@@rules_jni//jni/private:repositories.bzl
�	rules_jni_dependencies�Adds all external repositories required for rules_jni.

This should be called from a `WORKSPACE` file after the declaration of `fmeum_rules_jni` itself.

Currently, rules_jni depends on:

* [bazel_skylib](https://github.com/bazelbuild/bazel-skylib)
* [platforms](https://github.com/bazelbuild/platforms)
* [rules_license](https://github.com/bazelbuild/rules_license)
* individual files of the [OpenJDK](https://github.com/openjdk/jdk)

It also requires rules_cc 0.0.17 or later and rules_java 8.6.0 or later, which must be supplied by
the end user.*�
�
rules_jni_dependencies�Adds all external repositories required for rules_jni.

This should be called from a `WORKSPACE` file after the declaration of `fmeum_rules_jni` itself.

Currently, rules_jni depends on:

* [bazel_skylib](https://github.com/bazelbuild/bazel-skylib)
* [platforms](https://github.com/bazelbuild/platforms)
* [rules_license](https://github.com/bazelbuild/rules_license)
* individual files of the [OpenJDK](https://github.com/openjdk/jdk)

It also requires rules_cc 0.0.17 or later and rules_java 8.6.0 or later, which must be supplied by
the end user.2C
rules_jni_dependencies)@@rules_jni//jni/private:repositories.bzl
22�
 //tools/build_defs/repo:http.bzlr�
.
bazel_toolstools/build_defs/repohttp.bzl*
http_archivehttp_archive
7C$
	http_file	http_file
GP
R�
!//tools/build_defs/repo:utils.bzlr]
/
bazel_toolstools/build_defs/repo	utils.bzl
maybemaybe
8=
?+
)
	rules_jnijni/privatetransitions.bzl��
$
	rules_jnijnicc_jni_library.bzl��cc_jni_library�A native library that can be loaded by a Java application at runtime.

Add this target to the `native_libs` of a [`java_jni_library`](#java_jni_library).

The native libraries are exposed as Java resources, which are placed in a Java package determined from the Bazel
package of this target according to the
[Maven standard directory layout](https://maven.apache.org/guides/introduction/introduction-to-the-standard-directory-layout.html).
If the library should be included in the `com/example` subdirectory of a deploy JAR, which corresponds to the Java
package `com.example`, place it under one of the following Bazel package structures:
* `**/src/*/native/com/example` (preferred)
* `**/src/*/resources/com/example`
* `**/src/*/java/com/example`
* `**/java/com/example`

*Note:* Building a native library for multiple platforms by setting the `platforms` attribute to a non-empty list of
platforms requires either remote execution or cross-compilation toolchains for the target platforms. As both require
a more sophisticated Bazel setup, the following simpler process can be helpful for smaller or open-source projects:

1. Leave the `platforms` attribute empty or unspecified.
2. Build the deploy JAR of the Java library or application with all native libraries included separately for each
   target platform, for example using a CI platform.
3. Manually (outside Bazel) merge the deploy JARs. The `.class` files will be identical and can thus safely be
   replaced, but the resulting JAR will include all versions of the native library and the correct version will be
   loaded at runtime.

An example of such a CI workflow can be found [here](https://github.com/CodeIntelligenceTesting/jazzer/blob/d1835d6fa2ebfb7b2661cfaaa8acb8bbf42bb486/.github/workflows/release.yml).



<p>It produces an executable binary.</p>

<br/>The <code>name</code> of the target should be the same as the name of the
source file that is the main entry point of the application (minus the extension).
For example, if your entry point is in <code>main.cc</code>, then your name should
be <code>main</code>.

<h4>Implicit output targets</h4>
<ul>
<li><code><var>name</var>.stripped</code> (only built if explicitly requested): A stripped
  version of the binary. <code>strip -g</code> is run on the binary to remove debug
  symbols.  Additional strip options can be provided on the command line using
  <code>--stripopt=-foo</code>.</li>
<li><code><var>name</var>.dwp</code> (only built if explicitly requested): If
  <a href="https://gcc.gnu.org/wiki/DebugFission">Fission</a> is enabled: a debug
  information package file suitable for debugging remotely deployed binaries. Else: an
  empty file.</li>
</ul>
"�
Ж
cc_jni_library�A native library that can be loaded by a Java application at runtime.

Add this target to the `native_libs` of a [`java_jni_library`](#java_jni_library).

The native libraries are exposed as Java resources, which are placed in a Java package determined from the Bazel
package of this target according to the
[Maven standard directory layout](https://maven.apache.org/guides/introduction/introduction-to-the-standard-directory-layout.html).
If the library should be included in the `com/example` subdirectory of a deploy JAR, which corresponds to the Java
package `com.example`, place it under one of the following Bazel package structures:
* `**/src/*/native/com/example` (preferred)
* `**/src/*/resources/com/example`
* `**/src/*/java/com/example`
* `**/java/com/example`

*Note:* Building a native library for multiple platforms by setting the `platforms` attribute to a non-empty list of
platforms requires either remote execution or cross-compilation toolchains for the target platforms. As both require
a more sophisticated Bazel setup, the following simpler process can be helpful for smaller or open-source projects:

1. Leave the `platforms` attribute empty or unspecified.
2. Build the deploy JAR of the Java library or application with all native libraries included separately for each
   target platform, for example using a CI platform.
3. Manually (outside Bazel) merge the deploy JARs. The `.class` files will be identical and can thus safely be
   replaced, but the resulting JAR will include all versions of the native library and the correct version will be
   loaded at runtime.

An example of such a CI workflow can be found [here](https://github.com/CodeIntelligenceTesting/jazzer/blob/d1835d6fa2ebfb7b2661cfaaa8acb8bbf42bb486/.github/workflows/release.yml).



<p>It produces an executable binary.</p>

<br/>The <code>name</code> of the target should be the same as the name of the
source file that is the main entry point of the application (minus the extension).
For example, if your entry point is in <code>main.cc</code>, then your name should
be <code>main</code>.

<h4>Implicit output targets</h4>
<ul>
<li><code><var>name</var>.stripped</code> (only built if explicitly requested): A stripped
  version of the binary. <code>strip -g</code> is run on the binary to remove debug
  symbols.  Additional strip options can be provided on the command line using
  <code>--stripopt=-foo</code>.</li>
<li><code><var>name</var>.dwp</code> (only built if explicitly requested): If
  <a href="https://gcc.gnu.org/wiki/DebugFission">Fission</a> is enabled: a debug
  information package file suitable for debugging remotely deployed binaries. Else: an
  empty file.</li>
</ul>
*
nameA unique name for this target. �
additional_linker_inputs�
Dependencies that are only made available to the C++ linker command.
<p>
  Unlike <code>deps</code>, which is conceptually made for both compilation and
  linking dependencies, <code>additional_linker_inputs</code> is specifically
  made for only the latter, and signals a dependency that is required only for
  linking (for example, files that are referenced in <code>linkopts</code>).
</p>
<p>
  For example, compiled Windows .res files can be provided here to be embedded in
  the binary target.
</p>
2[]�
	conlyopts�
Add these options to the C compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
2[]�
copts�
Add these options to the C/C++ compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
<p>
  Each string in this attribute is added in the given order to <code>COPTS</code> before
  compiling the binary target. The flags take effect only for compiling this target, not
  its dependencies, so be careful about header files included elsewhere.
  All paths should be relative to the workspace, not to the current package.
  This attribute should not be needed outside of <code>third_party</code>.
</p>
<p>
  If the package declares the <a href="${link package.features}">feature</a>
  <code>no_copts_tokenization</code>, Bourne shell tokenization applies only to strings
  that consist of a single "Make" variable.
</p>
2[]�
cxxopts�
Add these options to the C++ compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
2[]�
data�
The list of files needed by this library at runtime.

See general comments about <code>data</code>
at <a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>If a <code>data</code> is the name of a generated file, then this
   <code>cc_library</code> rule automatically depends on the generating
   rule.
</p>
<p>If a <code>data</code> is a rule name, then this
   <code>cc_library</code> rule automatically depends on that rule,
   and that rule's <code>outs</code> are automatically added to
   this <code>cc_library</code>'s data files.
</p>
<p>Your C++ code can access these data files like so:</p>
<pre><code class="lang-starlark">
  const std::string path = devtools_build::GetDataDependencyFilepath(
      "my/test/data/file");
</code></pre>
2[]�
defines�
List of defines to add to the compile line of this and all dependent targets.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
Each string, which must consist of a single Bourne shell token,
is prepended with <code>-D</code> and added to the compile command line to this target,
as well as to every rule that depends on it. Be very careful, since this may have
far-reaching effects -- the defines are added to every target that depends on
this target.  When in doubt, add define values to
<a href="#cc_binary.local_defines"><code>local_defines</code></a> instead.
2[]�
deps�
The list of other libraries to be linked in to the binary target.
<p>These can be <code>cc_library</code> or <code>objc_library</code>
targets.</p>

It is also allowed to
put linker scripts (.lds) into deps, and reference them in
<a href="#cc_binary.linkopts"><code>linkopts</code></a>,
but please consider
<a href="#cc_binary.additional_linker_inputs"><code>additional_linker_inputs</code></a>
for that use case.
*
CcInfo2[]�
dynamic_deps�
These are other <code>cc_shared_library</code> dependencies the current target depends on.

<p>
The <code>cc_shared_library</code> implementation will use the list of
<code>dynamic_deps</code> (transitively, i.e. also the <code>dynamic_deps</code> of the
current target's <code>dynamic_deps</code>) to decide which <code>cc_libraries</code> in
the transitive <code>deps</code> should not be linked in because they are already provided
by a different <code>cc_shared_library</code>.
*
CcSharedLibraryInfo2[]
env
2{}&

hdrs_checkDeprecated, no-op.2""�
includes�
List of include dirs to be added to the compile line.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution.
Each string is prepended with the package path and passed to the C++ toolchain for
expansion via the "include_paths" CROSSTOOL feature. A toolchain running on a POSIX system
with typical feature definitions will produce
<code>-isystem path_to_package/include_entry</code>.
This should only be used for third-party libraries that
do not conform to the Google style of writing #include statements.
Unlike <a href="#cc_binary.copts">COPTS</a>, these flags are added for this rule
and every rule that depends on it. (Note: not the rules it depends upon!) Be
very careful, since this may have far-reaching effects.  When in doubt, add
"-I" flags to <a href="#cc_binary.copts">COPTS</a> instead.
<p>
The added <code>include</code> paths will include generated files as well as
files in the source tree.
</p>
2[]
licenses2[]�
link_extra_lib�
Control linking of extra libraries.
<p>
    By default, C++ binaries are linked against <code>@bazel_tools//tools/cpp:link_extra_lib</code>,
    which by default depends on the label flag <code>@bazel_tools//tools/cpp:link_extra_libs</code>.
    Without setting the flag, this library is empty by default. Setting the label flag
    allows linking optional dependencies, such as overrides for weak symbols, interceptors
    for shared library functions, or special runtime libraries (for malloc replacements,
    prefer <code>malloc</code> or <code>--custom_malloc</code>). Setting this attribute to
    <code>None</code> disables this behaviour.
</p>
*
CcInfo2&@bazel_tools//tools/cpp:link_extra_lib�
linkopts�
Add these flags to the C++ linker command.
Subject to <a href="make-variables.html">"Make" variable</a> substitution,
<a href="common-definitions.html#sh-tokenization">
Bourne shell tokenization</a> and
<a href="common-definitions.html#label-expansion">label expansion</a>.
Each string in this attribute is added to <code>LINKOPTS</code> before
linking the binary target.
<p>
    Each element of this list that does not start with <code>$</code> or <code>-</code> is
    assumed to be the label of a target in <code>deps</code>. The
    list of files generated by that target is appended to the linker
    options.  An error is reported if the label is invalid, or is
    not declared in <code>deps</code>.
</p>
2[]�

linkshared�
Create a shared library.
To enable this attribute, include <code>linkshared=True</code> in your rule. By default
this option is off.
<p>
  The presence of this flag means that linking occurs with the <code>-shared</code> flag
  to <code>gcc</code>, and the resulting shared library is suitable for loading into for
  example a Java program. However, for build purposes it will never be linked into the
  dependent binary, as it is assumed that shared libraries built with a
  <a href="#cc_binary">cc_binary</a> rule are only loaded manually by other programs, so
  it should not be considered a substitute for the <a href="#cc_library">cc_library</a>
  rule. For sake of scalability we recommend avoiding this approach altogether and
  simply letting <code>java_library</code> depend on <code>cc_library</code> rules
  instead.
</p>
<p>
  If you specify both <code>linkopts=['-static']</code> and <code>linkshared=True</code>,
  you get a single completely self-contained unit. If you specify both
  <code>linkstatic=True</code> and <code>linkshared=True</code>, you get a single, mostly
  self-contained unit.
</p>
2False�

linkstatic�
For <a href="${link cc_binary}"><code>cc_binary</code></a> and
<a href="${link cc_test}"><code>cc_test</code></a>: link the binary in static
mode. For <code>cc_library.link_static</code>: see below.
<p>By default this option is on for <code>cc_binary</code> and off for the rest.</p>
<p>
  If enabled and this is a binary or test, this option tells the build tool to link in
  <code>.a</code>'s instead of <code>.so</code>'s for user libraries whenever possible.
  System libraries such as libc (but <i>not</i> the C/C++ runtime libraries,
  see below) are still linked dynamically, as are libraries for which
  there is no static library. So the resulting executable will still be dynamically
  linked, hence only <i>mostly</i> static.
</p>
<p>
There are really three different ways to link an executable:
</p>
<ul>
<li> STATIC with fully_static_link feature, in which everything is linked statically;
  e.g. "<code>gcc -static foo.o libbar.a libbaz.a -lm</code>".<br/>
  This mode is enabled by specifying <code>fully_static_link</code> in the
  <a href="${link common-definitions#features}"><code>features</code></a> attribute.</li>
<li> STATIC, in which all user libraries are linked statically (if a static
  version is available), but where system libraries (excluding C/C++ runtime libraries)
  are linked dynamically, e.g. "<code>gcc foo.o libfoo.a libbaz.a -lm</code>".<br/>
  This mode is enabled by specifying <code>linkstatic=True</code>.</li>
<li> DYNAMIC, in which all libraries are linked dynamically (if a dynamic version is
  available), e.g. "<code>gcc foo.o libfoo.so libbaz.so -lm</code>".<br/>
  This mode is enabled by specifying <code>linkstatic=False</code>.</li>
</ul>
<p>
If the <code>linkstatic</code> attribute or <code>fully_static_link</code> in
<code>features</code> is used outside of <code>//third_party</code>
please include a comment near the rule to explain why.
</p>
<p>
The <code>linkstatic</code> attribute has a different meaning if used on a
<a href="${link cc_library}"><code>cc_library()</code></a> rule.
For a C++ library, <code>linkstatic=True</code> indicates that only
static linking is allowed, so no <code>.so</code> will be produced. linkstatic=False does
not prevent static libraries from being created. The attribute is meant to control the
creation of dynamic libraries.
</p>
<p>
There should be very little code built with <code>linkstatic=False</code> in production.
If <code>linkstatic=False</code>, then the build tool will create symlinks to
depended-upon shared libraries in the <code>*.runfiles</code> area.
</p>
2True�
local_defines�
List of defines to add to the compile line.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
Each string, which must consist of a single Bourne shell token,
is prepended with <code>-D</code> and added to the compile command line for this target,
but not to its dependents. Unlike <code>defines</code>, the defines are only added to the
compile command line for this target.
2[]�
malloc�
Override the default dependency on malloc.
<p>
  By default, C++ binaries are linked against <code>//tools/cpp:malloc</code>,
  which is an empty library so the binary ends up using libc malloc.
  This label must refer to a <code>cc_library</code>. If compilation is for a non-C++
  rule, this option has no effect. The value of this attribute is ignored if
  <code>linkshared=True</code> is specified.
</p>
*
CcInfo2@bazel_tools//tools/cpp:malloc�
module_interfaces�
The list of files are regarded as C++20 Modules Interface.

<p>
C++ Standard has no restriction about module interface file extension
<ul>
<li>Clang use cppm </li>
<li>GCC can use any source file extension </li>
<li>MSVC use ixx </li>
</ul>
</p>
<p>The use is guarded by the flag
<code>--experimental_cpp_modules</code>.</p>
2[]�
nocopts�
Remove matching options from the C++ compilation command.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution.
The value of this attribute is interpreted as a regular expression.
Any preexisting <code>COPTS</code> that match this regular expression
(including values explicitly specified in the rule's <a
href="#cc_binary.copts">copts</a> attribute)
will be removed from <code>COPTS</code> for purposes of compiling this rule.
This attribute should not be needed or used
outside of <code>third_party</code>.  The values are not preprocessed
in any way other than the "Make" variable substitution.
2""
reexport_deps2[]�
srcs�
The list of C and C++ files that are processed to create the library target.
These are C/C++ source and header files, either non-generated (normal source
code) or generated.
<p>All <code>.cc</code>, <code>.c</code>, and <code>.cpp</code> files will
   be compiled. These might be generated files: if a named file is in
   the <code>outs</code> of some other rule, this <code>cc_library</code>
   will automatically depend on that other rule.
</p>
<p>Pure assembler files (.s, .asm) are not preprocessed and are typically built using
the assembler. Preprocessed assembly files (.S) are preprocessed and are typically built
using the C/C++ compiler.
</p>
<p>A <code>.h</code> file will not be compiled, but will be available for
   inclusion by sources in this rule. Both <code>.cc</code> and
   <code>.h</code> files can directly include headers listed in
   these <code>srcs</code> or in the <code>hdrs</code> of this rule or any
   rule listed in the <code>deps</code> argument.
</p>
<p>All <code>#include</code>d files must be mentioned in the
   <code>hdrs</code> attribute of this or referenced <code>cc_library</code>
   rules, or they should be listed in <code>srcs</code> if they are private
   to this library. See <a href="#hdrs">"Header inclusion checking"</a> for
   a more detailed description.
</p>
<p><code>.so</code>, <code>.lo</code>, and <code>.a</code> files are
   pre-compiled files. Your library might have these as
   <code>srcs</code> if it uses third-party code for which we don't
   have source code.
</p>
<p>If the <code>srcs</code> attribute includes the label of another rule,
   <code>cc_library</code> will use the output files of that rule as source files to
   compile. This is useful for one-off generation of source code (for more than occasional
   use, it's better to implement a Starlark rule class and use the <code>cc_common</code>
   API)
</p>
<p>
  Permitted <code>srcs</code> file types:
</p>
<ul>
<li>C and C++ source files: <code>.c</code>, <code>.cc</code>, <code>.cpp</code>,
  <code>.cxx</code>, <code>.c++</code>, <code>.C</code></li>
<li>C and C++ header files: <code>.h</code>, <code>.hh</code>, <code>.hpp</code>,
  <code>.hxx</code>, <code>.inc</code>, <code>.inl</code>, <code>.H</code></li>
<li>Assembler with C preprocessor: <code>.S</code></li>
<li>Archive: <code>.a</code>, <code>.pic.a</code></li>
<li>"Always link" library: <code>.lo</code>, <code>.pic.lo</code></li>
<li>Shared library, versioned or unversioned: <code>.so</code>,
  <code>.so.<i>version</i></code></li>
<li>Object file: <code>.o</code>, <code>.pic.o</code></li>
</ul>

<p>
  ... and any rules that produce those files (e.g. <code>cc_embed_data</code>).
  Different extensions denote different programming languages in
  accordance with gcc convention.
</p>
2[]�
stamp�
Whether to encode build information into the binary. Possible values:
<ul>
<li>
  <code>stamp = 1</code>: Always stamp the build information into the binary, even in
  <a href="${link user-manual#flag--stamp}"><code>--nostamp</code></a> builds. <b>This
  setting should be avoided</b>, since it potentially kills remote caching for the
  binary and any downstream actions that depend on it.
</li>
<li>
  <code>stamp = 0</code>: Always replace build information by constant values. This
  gives good build result caching.
</li>
<li>
  <code>stamp = -1</code>: Embedding of build information is controlled by the
  <a href="${link user-manual#flag--stamp}"><code>--[no]stamp</code></a> flag.
</li>
</ul>
<p>Stamped binaries are <em>not</em> rebuilt unless their dependencies change.</p>
2-1�
win_def_file�
The Windows DEF file to be passed to linker.
<p>This attribute should only be used when Windows is the target platform.
It can be used to <a href="https://msdn.microsoft.com/en-us/library/d91k01sh.aspx">
export symbols</a> during linking a shared library.</p>
2None
��,
*
nameA unique name for this target. �
�
additional_linker_inputs�
Dependencies that are only made available to the C++ linker command.
<p>
  Unlike <code>deps</code>, which is conceptually made for both compilation and
  linking dependencies, <code>additional_linker_inputs</code> is specifically
  made for only the latter, and signals a dependency that is required only for
  linking (for example, files that are referenced in <code>linkopts</code>).
</p>
<p>
  For example, compiled Windows .res files can be provided here to be embedded in
  the binary target.
</p>
2[]�
�
	conlyopts�
Add these options to the C compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
2[]�
�
copts�
Add these options to the C/C++ compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
<p>
  Each string in this attribute is added in the given order to <code>COPTS</code> before
  compiling the binary target. The flags take effect only for compiling this target, not
  its dependencies, so be careful about header files included elsewhere.
  All paths should be relative to the workspace, not to the current package.
  This attribute should not be needed outside of <code>third_party</code>.
</p>
<p>
  If the package declares the <a href="${link package.features}">feature</a>
  <code>no_copts_tokenization</code>, Bourne shell tokenization applies only to strings
  that consist of a single "Make" variable.
</p>
2[]�
�
cxxopts�
Add these options to the C++ compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
2[]�
�
data�
The list of files needed by this library at runtime.

See general comments about <code>data</code>
at <a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>If a <code>data</code> is the name of a generated file, then this
   <code>cc_library</code> rule automatically depends on the generating
   rule.
</p>
<p>If a <code>data</code> is a rule name, then this
   <code>cc_library</code> rule automatically depends on that rule,
   and that rule's <code>outs</code> are automatically added to
   this <code>cc_library</code>'s data files.
</p>
<p>Your C++ code can access these data files like so:</p>
<pre><code class="lang-starlark">
  const std::string path = devtools_build::GetDataDependencyFilepath(
      "my/test/data/file");
</code></pre>
2[]�
�
defines�
List of defines to add to the compile line of this and all dependent targets.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
Each string, which must consist of a single Bourne shell token,
is prepended with <code>-D</code> and added to the compile command line to this target,
as well as to every rule that depends on it. Be very careful, since this may have
far-reaching effects -- the defines are added to every target that depends on
this target.  When in doubt, add define values to
<a href="#cc_binary.local_defines"><code>local_defines</code></a> instead.
2[]�
�
deps�
The list of other libraries to be linked in to the binary target.
<p>These can be <code>cc_library</code> or <code>objc_library</code>
targets.</p>

It is also allowed to
put linker scripts (.lds) into deps, and reference them in
<a href="#cc_binary.linkopts"><code>linkopts</code></a>,
but please consider
<a href="#cc_binary.additional_linker_inputs"><code>additional_linker_inputs</code></a>
for that use case.
*
CcInfo2[]�
�
dynamic_deps�
These are other <code>cc_shared_library</code> dependencies the current target depends on.

<p>
The <code>cc_shared_library</code> implementation will use the list of
<code>dynamic_deps</code> (transitively, i.e. also the <code>dynamic_deps</code> of the
current target's <code>dynamic_deps</code>) to decide which <code>cc_libraries</code> in
the transitive <code>deps</code> should not be linked in because they are already provided
by a different <code>cc_shared_library</code>.
*
CcSharedLibraryInfo2[]

env
2{}(
&

hdrs_checkDeprecated, no-op.2""�
�
includes�
List of include dirs to be added to the compile line.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution.
Each string is prepended with the package path and passed to the C++ toolchain for
expansion via the "include_paths" CROSSTOOL feature. A toolchain running on a POSIX system
with typical feature definitions will produce
<code>-isystem path_to_package/include_entry</code>.
This should only be used for third-party libraries that
do not conform to the Google style of writing #include statements.
Unlike <a href="#cc_binary.copts">COPTS</a>, these flags are added for this rule
and every rule that depends on it. (Note: not the rules it depends upon!) Be
very careful, since this may have far-reaching effects.  When in doubt, add
"-I" flags to <a href="#cc_binary.copts">COPTS</a> instead.
<p>
The added <code>include</code> paths will include generated files as well as
files in the source tree.
</p>
2[]

licenses2[]�
�
link_extra_lib�
Control linking of extra libraries.
<p>
    By default, C++ binaries are linked against <code>@bazel_tools//tools/cpp:link_extra_lib</code>,
    which by default depends on the label flag <code>@bazel_tools//tools/cpp:link_extra_libs</code>.
    Without setting the flag, this library is empty by default. Setting the label flag
    allows linking optional dependencies, such as overrides for weak symbols, interceptors
    for shared library functions, or special runtime libraries (for malloc replacements,
    prefer <code>malloc</code> or <code>--custom_malloc</code>). Setting this attribute to
    <code>None</code> disables this behaviour.
</p>
*
CcInfo2&@bazel_tools//tools/cpp:link_extra_lib�
�
linkopts�
Add these flags to the C++ linker command.
Subject to <a href="make-variables.html">"Make" variable</a> substitution,
<a href="common-definitions.html#sh-tokenization">
Bourne shell tokenization</a> and
<a href="common-definitions.html#label-expansion">label expansion</a>.
Each string in this attribute is added to <code>LINKOPTS</code> before
linking the binary target.
<p>
    Each element of this list that does not start with <code>$</code> or <code>-</code> is
    assumed to be the label of a target in <code>deps</code>. The
    list of files generated by that target is appended to the linker
    options.  An error is reported if the label is invalid, or is
    not declared in <code>deps</code>.
</p>
2[]�
�

linkshared�
Create a shared library.
To enable this attribute, include <code>linkshared=True</code> in your rule. By default
this option is off.
<p>
  The presence of this flag means that linking occurs with the <code>-shared</code> flag
  to <code>gcc</code>, and the resulting shared library is suitable for loading into for
  example a Java program. However, for build purposes it will never be linked into the
  dependent binary, as it is assumed that shared libraries built with a
  <a href="#cc_binary">cc_binary</a> rule are only loaded manually by other programs, so
  it should not be considered a substitute for the <a href="#cc_library">cc_library</a>
  rule. For sake of scalability we recommend avoiding this approach altogether and
  simply letting <code>java_library</code> depend on <code>cc_library</code> rules
  instead.
</p>
<p>
  If you specify both <code>linkopts=['-static']</code> and <code>linkshared=True</code>,
  you get a single completely self-contained unit. If you specify both
  <code>linkstatic=True</code> and <code>linkshared=True</code>, you get a single, mostly
  self-contained unit.
</p>
2False�
�

linkstatic�
For <a href="${link cc_binary}"><code>cc_binary</code></a> and
<a href="${link cc_test}"><code>cc_test</code></a>: link the binary in static
mode. For <code>cc_library.link_static</code>: see below.
<p>By default this option is on for <code>cc_binary</code> and off for the rest.</p>
<p>
  If enabled and this is a binary or test, this option tells the build tool to link in
  <code>.a</code>'s instead of <code>.so</code>'s for user libraries whenever possible.
  System libraries such as libc (but <i>not</i> the C/C++ runtime libraries,
  see below) are still linked dynamically, as are libraries for which
  there is no static library. So the resulting executable will still be dynamically
  linked, hence only <i>mostly</i> static.
</p>
<p>
There are really three different ways to link an executable:
</p>
<ul>
<li> STATIC with fully_static_link feature, in which everything is linked statically;
  e.g. "<code>gcc -static foo.o libbar.a libbaz.a -lm</code>".<br/>
  This mode is enabled by specifying <code>fully_static_link</code> in the
  <a href="${link common-definitions#features}"><code>features</code></a> attribute.</li>
<li> STATIC, in which all user libraries are linked statically (if a static
  version is available), but where system libraries (excluding C/C++ runtime libraries)
  are linked dynamically, e.g. "<code>gcc foo.o libfoo.a libbaz.a -lm</code>".<br/>
  This mode is enabled by specifying <code>linkstatic=True</code>.</li>
<li> DYNAMIC, in which all libraries are linked dynamically (if a dynamic version is
  available), e.g. "<code>gcc foo.o libfoo.so libbaz.so -lm</code>".<br/>
  This mode is enabled by specifying <code>linkstatic=False</code>.</li>
</ul>
<p>
If the <code>linkstatic</code> attribute or <code>fully_static_link</code> in
<code>features</code> is used outside of <code>//third_party</code>
please include a comment near the rule to explain why.
</p>
<p>
The <code>linkstatic</code> attribute has a different meaning if used on a
<a href="${link cc_library}"><code>cc_library()</code></a> rule.
For a C++ library, <code>linkstatic=True</code> indicates that only
static linking is allowed, so no <code>.so</code> will be produced. linkstatic=False does
not prevent static libraries from being created. The attribute is meant to control the
creation of dynamic libraries.
</p>
<p>
There should be very little code built with <code>linkstatic=False</code> in production.
If <code>linkstatic=False</code>, then the build tool will create symlinks to
depended-upon shared libraries in the <code>*.runfiles</code> area.
</p>
2True�
�
local_defines�
List of defines to add to the compile line.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
Each string, which must consist of a single Bourne shell token,
is prepended with <code>-D</code> and added to the compile command line for this target,
but not to its dependents. Unlike <code>defines</code>, the defines are only added to the
compile command line for this target.
2[]�
�
malloc�
Override the default dependency on malloc.
<p>
  By default, C++ binaries are linked against <code>//tools/cpp:malloc</code>,
  which is an empty library so the binary ends up using libc malloc.
  This label must refer to a <code>cc_library</code>. If compilation is for a non-C++
  rule, this option has no effect. The value of this attribute is ignored if
  <code>linkshared=True</code> is specified.
</p>
*
CcInfo2@bazel_tools//tools/cpp:malloc�
�
module_interfaces�
The list of files are regarded as C++20 Modules Interface.

<p>
C++ Standard has no restriction about module interface file extension
<ul>
<li>Clang use cppm </li>
<li>GCC can use any source file extension </li>
<li>MSVC use ixx </li>
</ul>
</p>
<p>The use is guarded by the flag
<code>--experimental_cpp_modules</code>.</p>
2[]�
�
nocopts�
Remove matching options from the C++ compilation command.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution.
The value of this attribute is interpreted as a regular expression.
Any preexisting <code>COPTS</code> that match this regular expression
(including values explicitly specified in the rule's <a
href="#cc_binary.copts">copts</a> attribute)
will be removed from <code>COPTS</code> for purposes of compiling this rule.
This attribute should not be needed or used
outside of <code>third_party</code>.  The values are not preprocessed
in any way other than the "Make" variable substitution.
2""

reexport_deps2[]�
�
srcs�
The list of C and C++ files that are processed to create the library target.
These are C/C++ source and header files, either non-generated (normal source
code) or generated.
<p>All <code>.cc</code>, <code>.c</code>, and <code>.cpp</code> files will
   be compiled. These might be generated files: if a named file is in
   the <code>outs</code> of some other rule, this <code>cc_library</code>
   will automatically depend on that other rule.
</p>
<p>Pure assembler files (.s, .asm) are not preprocessed and are typically built using
the assembler. Preprocessed assembly files (.S) are preprocessed and are typically built
using the C/C++ compiler.
</p>
<p>A <code>.h</code> file will not be compiled, but will be available for
   inclusion by sources in this rule. Both <code>.cc</code> and
   <code>.h</code> files can directly include headers listed in
   these <code>srcs</code> or in the <code>hdrs</code> of this rule or any
   rule listed in the <code>deps</code> argument.
</p>
<p>All <code>#include</code>d files must be mentioned in the
   <code>hdrs</code> attribute of this or referenced <code>cc_library</code>
   rules, or they should be listed in <code>srcs</code> if they are private
   to this library. See <a href="#hdrs">"Header inclusion checking"</a> for
   a more detailed description.
</p>
<p><code>.so</code>, <code>.lo</code>, and <code>.a</code> files are
   pre-compiled files. Your library might have these as
   <code>srcs</code> if it uses third-party code for which we don't
   have source code.
</p>
<p>If the <code>srcs</code> attribute includes the label of another rule,
   <code>cc_library</code> will use the output files of that rule as source files to
   compile. This is useful for one-off generation of source code (for more than occasional
   use, it's better to implement a Starlark rule class and use the <code>cc_common</code>
   API)
</p>
<p>
  Permitted <code>srcs</code> file types:
</p>
<ul>
<li>C and C++ source files: <code>.c</code>, <code>.cc</code>, <code>.cpp</code>,
  <code>.cxx</code>, <code>.c++</code>, <code>.C</code></li>
<li>C and C++ header files: <code>.h</code>, <code>.hh</code>, <code>.hpp</code>,
  <code>.hxx</code>, <code>.inc</code>, <code>.inl</code>, <code>.H</code></li>
<li>Assembler with C preprocessor: <code>.S</code></li>
<li>Archive: <code>.a</code>, <code>.pic.a</code></li>
<li>"Always link" library: <code>.lo</code>, <code>.pic.lo</code></li>
<li>Shared library, versioned or unversioned: <code>.so</code>,
  <code>.so.<i>version</i></code></li>
<li>Object file: <code>.o</code>, <code>.pic.o</code></li>
</ul>

<p>
  ... and any rules that produce those files (e.g. <code>cc_embed_data</code>).
  Different extensions denote different programming languages in
  accordance with gcc convention.
</p>
2[]�
�
stamp�
Whether to encode build information into the binary. Possible values:
<ul>
<li>
  <code>stamp = 1</code>: Always stamp the build information into the binary, even in
  <a href="${link user-manual#flag--stamp}"><code>--nostamp</code></a> builds. <b>This
  setting should be avoided</b>, since it potentially kills remote caching for the
  binary and any downstream actions that depend on it.
</li>
<li>
  <code>stamp = 0</code>: Always replace build information by constant values. This
  gives good build result caching.
</li>
<li>
  <code>stamp = -1</code>: Embedding of build information is controlled by the
  <a href="${link user-manual#flag--stamp}"><code>--[no]stamp</code></a> flag.
</li>
</ul>
<p>Stamped binaries are <em>not</em> rebuilt unless their dependencies change.</p>
2-1�
�
win_def_file�
The Windows DEF file to be passed to linker.
<p>This attribute should only be used when Windows is the target platform.
It can be used to <a href="https://msdn.microsoft.com/en-us/library/d91k01sh.aspx">
export symbols</a> during linking a shared library.</p>
2None�
 //jni/private:cc_jni_library.bzlrm
,
	rules_jnijni/privatecc_jni_library.bzl/
cc_jni_library_cc_jni_library
4C
W��

	rules_jnijnidefs.bzl�jni_headers�
Generates the native headers for a `java_library` and exposes it to `cc_*` rules.

For every Java class `com.example.Foo` in the `java_library` target specified by `lib` that contains at least one
function marked with `native` or constant annotated with `@Native`, the include directory exported by this rule will
contain a file `com_example_Foo.h` that provides the C/C++ interface for this class. Consuming `cc_*` rules should have
this rule added to their `deps` and can then access such a header file via:

```c
#include "com_example_Foo.h"
```

This rule also directly exports the JNI header, which can be included via:

```c
#include <jni.h>
```

*Example:*

```starlark
load("@fmeum_rules_jni//jni:defs.bzl", "jni_headers")

java_library(
    name = "os_utils",
    ...
)

jni_headers(
    name = "os_utils_hdrs",
    lib = ":os_utils",
)

cc_library(
    name = "os_utils_impl",
    ...
    deps = [":os_utils_hdrs"],
)
```
"�

�
jni_headers�
Generates the native headers for a `java_library` and exposes it to `cc_*` rules.

For every Java class `com.example.Foo` in the `java_library` target specified by `lib` that contains at least one
function marked with `native` or constant annotated with `@Native`, the include directory exported by this rule will
contain a file `com_example_Foo.h` that provides the C/C++ interface for this class. Consuming `cc_*` rules should have
this rule added to their `deps` and can then access such a header file via:

```c
#include "com_example_Foo.h"
```

This rule also directly exports the JNI header, which can be included via:

```c
#include <jni.h>
```

*Example:*

```starlark
load("@fmeum_rules_jni//jni:defs.bzl", "jni_headers")

java_library(
    name = "os_utils",
    ...
)

jni_headers(
    name = "os_utils_hdrs",
    lib = ":os_utils",
)

cc_library(
    name = "os_utils_impl",
    ...
    deps = [":os_utils_hdrs"],
)
```
*
nameA unique name for this target. Z
libCThe Java library for which native header files should be generated. *

JavaInfo"(
jni_headers@@rules_jni//jni:defs.bzl
KK,
*
nameA unique name for this target. \
Z
libCThe Java library for which native header files should be generated. *

JavaInfo��cc_jni_library�A native library that can be loaded by a Java application at runtime.

Add this target to the `native_libs` of a [`java_jni_library`](#java_jni_library).

The native libraries are exposed as Java resources, which are placed in a Java package determined from the Bazel
package of this target according to the
[Maven standard directory layout](https://maven.apache.org/guides/introduction/introduction-to-the-standard-directory-layout.html).
If the library should be included in the `com/example` subdirectory of a deploy JAR, which corresponds to the Java
package `com.example`, place it under one of the following Bazel package structures:
* `**/src/*/native/com/example` (preferred)
* `**/src/*/resources/com/example`
* `**/src/*/java/com/example`
* `**/java/com/example`

*Note:* Building a native library for multiple platforms by setting the `platforms` attribute to a non-empty list of
platforms requires either remote execution or cross-compilation toolchains for the target platforms. As both require
a more sophisticated Bazel setup, the following simpler process can be helpful for smaller or open-source projects:

1. Leave the `platforms` attribute empty or unspecified.
2. Build the deploy JAR of the Java library or application with all native libraries included separately for each
   target platform, for example using a CI platform.
3. Manually (outside Bazel) merge the deploy JARs. The `.class` files will be identical and can thus safely be
   replaced, but the resulting JAR will include all versions of the native library and the correct version will be
   loaded at runtime.

An example of such a CI workflow can be found [here](https://github.com/CodeIntelligenceTesting/jazzer/blob/d1835d6fa2ebfb7b2661cfaaa8acb8bbf42bb486/.github/workflows/release.yml).



<p>It produces an executable binary.</p>

<br/>The <code>name</code> of the target should be the same as the name of the
source file that is the main entry point of the application (minus the extension).
For example, if your entry point is in <code>main.cc</code>, then your name should
be <code>main</code>.

<h4>Implicit output targets</h4>
<ul>
<li><code><var>name</var>.stripped</code> (only built if explicitly requested): A stripped
  version of the binary. <code>strip -g</code> is run on the binary to remove debug
  symbols.  Additional strip options can be provided on the command line using
  <code>--stripopt=-foo</code>.</li>
<li><code><var>name</var>.dwp</code> (only built if explicitly requested): If
  <a href="https://gcc.gnu.org/wiki/DebugFission">Fission</a> is enabled: a debug
  information package file suitable for debugging remotely deployed binaries. Else: an
  empty file.</li>
</ul>
"�
Ж
cc_jni_library�A native library that can be loaded by a Java application at runtime.

Add this target to the `native_libs` of a [`java_jni_library`](#java_jni_library).

The native libraries are exposed as Java resources, which are placed in a Java package determined from the Bazel
package of this target according to the
[Maven standard directory layout](https://maven.apache.org/guides/introduction/introduction-to-the-standard-directory-layout.html).
If the library should be included in the `com/example` subdirectory of a deploy JAR, which corresponds to the Java
package `com.example`, place it under one of the following Bazel package structures:
* `**/src/*/native/com/example` (preferred)
* `**/src/*/resources/com/example`
* `**/src/*/java/com/example`
* `**/java/com/example`

*Note:* Building a native library for multiple platforms by setting the `platforms` attribute to a non-empty list of
platforms requires either remote execution or cross-compilation toolchains for the target platforms. As both require
a more sophisticated Bazel setup, the following simpler process can be helpful for smaller or open-source projects:

1. Leave the `platforms` attribute empty or unspecified.
2. Build the deploy JAR of the Java library or application with all native libraries included separately for each
   target platform, for example using a CI platform.
3. Manually (outside Bazel) merge the deploy JARs. The `.class` files will be identical and can thus safely be
   replaced, but the resulting JAR will include all versions of the native library and the correct version will be
   loaded at runtime.

An example of such a CI workflow can be found [here](https://github.com/CodeIntelligenceTesting/jazzer/blob/d1835d6fa2ebfb7b2661cfaaa8acb8bbf42bb486/.github/workflows/release.yml).



<p>It produces an executable binary.</p>

<br/>The <code>name</code> of the target should be the same as the name of the
source file that is the main entry point of the application (minus the extension).
For example, if your entry point is in <code>main.cc</code>, then your name should
be <code>main</code>.

<h4>Implicit output targets</h4>
<ul>
<li><code><var>name</var>.stripped</code> (only built if explicitly requested): A stripped
  version of the binary. <code>strip -g</code> is run on the binary to remove debug
  symbols.  Additional strip options can be provided on the command line using
  <code>--stripopt=-foo</code>.</li>
<li><code><var>name</var>.dwp</code> (only built if explicitly requested): If
  <a href="https://gcc.gnu.org/wiki/DebugFission">Fission</a> is enabled: a debug
  information package file suitable for debugging remotely deployed binaries. Else: an
  empty file.</li>
</ul>
*
nameA unique name for this target. �
additional_linker_inputs�
Dependencies that are only made available to the C++ linker command.
<p>
  Unlike <code>deps</code>, which is conceptually made for both compilation and
  linking dependencies, <code>additional_linker_inputs</code> is specifically
  made for only the latter, and signals a dependency that is required only for
  linking (for example, files that are referenced in <code>linkopts</code>).
</p>
<p>
  For example, compiled Windows .res files can be provided here to be embedded in
  the binary target.
</p>
2[]�
	conlyopts�
Add these options to the C compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
2[]�
copts�
Add these options to the C/C++ compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
<p>
  Each string in this attribute is added in the given order to <code>COPTS</code> before
  compiling the binary target. The flags take effect only for compiling this target, not
  its dependencies, so be careful about header files included elsewhere.
  All paths should be relative to the workspace, not to the current package.
  This attribute should not be needed outside of <code>third_party</code>.
</p>
<p>
  If the package declares the <a href="${link package.features}">feature</a>
  <code>no_copts_tokenization</code>, Bourne shell tokenization applies only to strings
  that consist of a single "Make" variable.
</p>
2[]�
cxxopts�
Add these options to the C++ compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
2[]�
data�
The list of files needed by this library at runtime.

See general comments about <code>data</code>
at <a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>If a <code>data</code> is the name of a generated file, then this
   <code>cc_library</code> rule automatically depends on the generating
   rule.
</p>
<p>If a <code>data</code> is a rule name, then this
   <code>cc_library</code> rule automatically depends on that rule,
   and that rule's <code>outs</code> are automatically added to
   this <code>cc_library</code>'s data files.
</p>
<p>Your C++ code can access these data files like so:</p>
<pre><code class="lang-starlark">
  const std::string path = devtools_build::GetDataDependencyFilepath(
      "my/test/data/file");
</code></pre>
2[]�
defines�
List of defines to add to the compile line of this and all dependent targets.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
Each string, which must consist of a single Bourne shell token,
is prepended with <code>-D</code> and added to the compile command line to this target,
as well as to every rule that depends on it. Be very careful, since this may have
far-reaching effects -- the defines are added to every target that depends on
this target.  When in doubt, add define values to
<a href="#cc_binary.local_defines"><code>local_defines</code></a> instead.
2[]�
deps�
The list of other libraries to be linked in to the binary target.
<p>These can be <code>cc_library</code> or <code>objc_library</code>
targets.</p>

It is also allowed to
put linker scripts (.lds) into deps, and reference them in
<a href="#cc_binary.linkopts"><code>linkopts</code></a>,
but please consider
<a href="#cc_binary.additional_linker_inputs"><code>additional_linker_inputs</code></a>
for that use case.
*
CcInfo2[]�
dynamic_deps�
These are other <code>cc_shared_library</code> dependencies the current target depends on.

<p>
The <code>cc_shared_library</code> implementation will use the list of
<code>dynamic_deps</code> (transitively, i.e. also the <code>dynamic_deps</code> of the
current target's <code>dynamic_deps</code>) to decide which <code>cc_libraries</code> in
the transitive <code>deps</code> should not be linked in because they are already provided
by a different <code>cc_shared_library</code>.
*
CcSharedLibraryInfo2[]
env
2{}&

hdrs_checkDeprecated, no-op.2""�
includes�
List of include dirs to be added to the compile line.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution.
Each string is prepended with the package path and passed to the C++ toolchain for
expansion via the "include_paths" CROSSTOOL feature. A toolchain running on a POSIX system
with typical feature definitions will produce
<code>-isystem path_to_package/include_entry</code>.
This should only be used for third-party libraries that
do not conform to the Google style of writing #include statements.
Unlike <a href="#cc_binary.copts">COPTS</a>, these flags are added for this rule
and every rule that depends on it. (Note: not the rules it depends upon!) Be
very careful, since this may have far-reaching effects.  When in doubt, add
"-I" flags to <a href="#cc_binary.copts">COPTS</a> instead.
<p>
The added <code>include</code> paths will include generated files as well as
files in the source tree.
</p>
2[]
licenses2[]�
link_extra_lib�
Control linking of extra libraries.
<p>
    By default, C++ binaries are linked against <code>@bazel_tools//tools/cpp:link_extra_lib</code>,
    which by default depends on the label flag <code>@bazel_tools//tools/cpp:link_extra_libs</code>.
    Without setting the flag, this library is empty by default. Setting the label flag
    allows linking optional dependencies, such as overrides for weak symbols, interceptors
    for shared library functions, or special runtime libraries (for malloc replacements,
    prefer <code>malloc</code> or <code>--custom_malloc</code>). Setting this attribute to
    <code>None</code> disables this behaviour.
</p>
*
CcInfo2&@bazel_tools//tools/cpp:link_extra_lib�
linkopts�
Add these flags to the C++ linker command.
Subject to <a href="make-variables.html">"Make" variable</a> substitution,
<a href="common-definitions.html#sh-tokenization">
Bourne shell tokenization</a> and
<a href="common-definitions.html#label-expansion">label expansion</a>.
Each string in this attribute is added to <code>LINKOPTS</code> before
linking the binary target.
<p>
    Each element of this list that does not start with <code>$</code> or <code>-</code> is
    assumed to be the label of a target in <code>deps</code>. The
    list of files generated by that target is appended to the linker
    options.  An error is reported if the label is invalid, or is
    not declared in <code>deps</code>.
</p>
2[]�

linkshared�
Create a shared library.
To enable this attribute, include <code>linkshared=True</code> in your rule. By default
this option is off.
<p>
  The presence of this flag means that linking occurs with the <code>-shared</code> flag
  to <code>gcc</code>, and the resulting shared library is suitable for loading into for
  example a Java program. However, for build purposes it will never be linked into the
  dependent binary, as it is assumed that shared libraries built with a
  <a href="#cc_binary">cc_binary</a> rule are only loaded manually by other programs, so
  it should not be considered a substitute for the <a href="#cc_library">cc_library</a>
  rule. For sake of scalability we recommend avoiding this approach altogether and
  simply letting <code>java_library</code> depend on <code>cc_library</code> rules
  instead.
</p>
<p>
  If you specify both <code>linkopts=['-static']</code> and <code>linkshared=True</code>,
  you get a single completely self-contained unit. If you specify both
  <code>linkstatic=True</code> and <code>linkshared=True</code>, you get a single, mostly
  self-contained unit.
</p>
2False�

linkstatic�
For <a href="${link cc_binary}"><code>cc_binary</code></a> and
<a href="${link cc_test}"><code>cc_test</code></a>: link the binary in static
mode. For <code>cc_library.link_static</code>: see below.
<p>By default this option is on for <code>cc_binary</code> and off for the rest.</p>
<p>
  If enabled and this is a binary or test, this option tells the build tool to link in
  <code>.a</code>'s instead of <code>.so</code>'s for user libraries whenever possible.
  System libraries such as libc (but <i>not</i> the C/C++ runtime libraries,
  see below) are still linked dynamically, as are libraries for which
  there is no static library. So the resulting executable will still be dynamically
  linked, hence only <i>mostly</i> static.
</p>
<p>
There are really three different ways to link an executable:
</p>
<ul>
<li> STATIC with fully_static_link feature, in which everything is linked statically;
  e.g. "<code>gcc -static foo.o libbar.a libbaz.a -lm</code>".<br/>
  This mode is enabled by specifying <code>fully_static_link</code> in the
  <a href="${link common-definitions#features}"><code>features</code></a> attribute.</li>
<li> STATIC, in which all user libraries are linked statically (if a static
  version is available), but where system libraries (excluding C/C++ runtime libraries)
  are linked dynamically, e.g. "<code>gcc foo.o libfoo.a libbaz.a -lm</code>".<br/>
  This mode is enabled by specifying <code>linkstatic=True</code>.</li>
<li> DYNAMIC, in which all libraries are linked dynamically (if a dynamic version is
  available), e.g. "<code>gcc foo.o libfoo.so libbaz.so -lm</code>".<br/>
  This mode is enabled by specifying <code>linkstatic=False</code>.</li>
</ul>
<p>
If the <code>linkstatic</code> attribute or <code>fully_static_link</code> in
<code>features</code> is used outside of <code>//third_party</code>
please include a comment near the rule to explain why.
</p>
<p>
The <code>linkstatic</code> attribute has a different meaning if used on a
<a href="${link cc_library}"><code>cc_library()</code></a> rule.
For a C++ library, <code>linkstatic=True</code> indicates that only
static linking is allowed, so no <code>.so</code> will be produced. linkstatic=False does
not prevent static libraries from being created. The attribute is meant to control the
creation of dynamic libraries.
</p>
<p>
There should be very little code built with <code>linkstatic=False</code> in production.
If <code>linkstatic=False</code>, then the build tool will create symlinks to
depended-upon shared libraries in the <code>*.runfiles</code> area.
</p>
2True�
local_defines�
List of defines to add to the compile line.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
Each string, which must consist of a single Bourne shell token,
is prepended with <code>-D</code> and added to the compile command line for this target,
but not to its dependents. Unlike <code>defines</code>, the defines are only added to the
compile command line for this target.
2[]�
malloc�
Override the default dependency on malloc.
<p>
  By default, C++ binaries are linked against <code>//tools/cpp:malloc</code>,
  which is an empty library so the binary ends up using libc malloc.
  This label must refer to a <code>cc_library</code>. If compilation is for a non-C++
  rule, this option has no effect. The value of this attribute is ignored if
  <code>linkshared=True</code> is specified.
</p>
*
CcInfo2@bazel_tools//tools/cpp:malloc�
module_interfaces�
The list of files are regarded as C++20 Modules Interface.

<p>
C++ Standard has no restriction about module interface file extension
<ul>
<li>Clang use cppm </li>
<li>GCC can use any source file extension </li>
<li>MSVC use ixx </li>
</ul>
</p>
<p>The use is guarded by the flag
<code>--experimental_cpp_modules</code>.</p>
2[]�
nocopts�
Remove matching options from the C++ compilation command.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution.
The value of this attribute is interpreted as a regular expression.
Any preexisting <code>COPTS</code> that match this regular expression
(including values explicitly specified in the rule's <a
href="#cc_binary.copts">copts</a> attribute)
will be removed from <code>COPTS</code> for purposes of compiling this rule.
This attribute should not be needed or used
outside of <code>third_party</code>.  The values are not preprocessed
in any way other than the "Make" variable substitution.
2""
reexport_deps2[]�
srcs�
The list of C and C++ files that are processed to create the library target.
These are C/C++ source and header files, either non-generated (normal source
code) or generated.
<p>All <code>.cc</code>, <code>.c</code>, and <code>.cpp</code> files will
   be compiled. These might be generated files: if a named file is in
   the <code>outs</code> of some other rule, this <code>cc_library</code>
   will automatically depend on that other rule.
</p>
<p>Pure assembler files (.s, .asm) are not preprocessed and are typically built using
the assembler. Preprocessed assembly files (.S) are preprocessed and are typically built
using the C/C++ compiler.
</p>
<p>A <code>.h</code> file will not be compiled, but will be available for
   inclusion by sources in this rule. Both <code>.cc</code> and
   <code>.h</code> files can directly include headers listed in
   these <code>srcs</code> or in the <code>hdrs</code> of this rule or any
   rule listed in the <code>deps</code> argument.
</p>
<p>All <code>#include</code>d files must be mentioned in the
   <code>hdrs</code> attribute of this or referenced <code>cc_library</code>
   rules, or they should be listed in <code>srcs</code> if they are private
   to this library. See <a href="#hdrs">"Header inclusion checking"</a> for
   a more detailed description.
</p>
<p><code>.so</code>, <code>.lo</code>, and <code>.a</code> files are
   pre-compiled files. Your library might have these as
   <code>srcs</code> if it uses third-party code for which we don't
   have source code.
</p>
<p>If the <code>srcs</code> attribute includes the label of another rule,
   <code>cc_library</code> will use the output files of that rule as source files to
   compile. This is useful for one-off generation of source code (for more than occasional
   use, it's better to implement a Starlark rule class and use the <code>cc_common</code>
   API)
</p>
<p>
  Permitted <code>srcs</code> file types:
</p>
<ul>
<li>C and C++ source files: <code>.c</code>, <code>.cc</code>, <code>.cpp</code>,
  <code>.cxx</code>, <code>.c++</code>, <code>.C</code></li>
<li>C and C++ header files: <code>.h</code>, <code>.hh</code>, <code>.hpp</code>,
  <code>.hxx</code>, <code>.inc</code>, <code>.inl</code>, <code>.H</code></li>
<li>Assembler with C preprocessor: <code>.S</code></li>
<li>Archive: <code>.a</code>, <code>.pic.a</code></li>
<li>"Always link" library: <code>.lo</code>, <code>.pic.lo</code></li>
<li>Shared library, versioned or unversioned: <code>.so</code>,
  <code>.so.<i>version</i></code></li>
<li>Object file: <code>.o</code>, <code>.pic.o</code></li>
</ul>

<p>
  ... and any rules that produce those files (e.g. <code>cc_embed_data</code>).
  Different extensions denote different programming languages in
  accordance with gcc convention.
</p>
2[]�
stamp�
Whether to encode build information into the binary. Possible values:
<ul>
<li>
  <code>stamp = 1</code>: Always stamp the build information into the binary, even in
  <a href="${link user-manual#flag--stamp}"><code>--nostamp</code></a> builds. <b>This
  setting should be avoided</b>, since it potentially kills remote caching for the
  binary and any downstream actions that depend on it.
</li>
<li>
  <code>stamp = 0</code>: Always replace build information by constant values. This
  gives good build result caching.
</li>
<li>
  <code>stamp = -1</code>: Embedding of build information is controlled by the
  <a href="${link user-manual#flag--stamp}"><code>--[no]stamp</code></a> flag.
</li>
</ul>
<p>Stamped binaries are <em>not</em> rebuilt unless their dependencies change.</p>
2-1�
win_def_file�
The Windows DEF file to be passed to linker.
<p>This attribute should only be used when Windows is the target platform.
It can be used to <a href="https://msdn.microsoft.com/en-us/library/d91k01sh.aspx">
export symbols</a> during linking a shared library.</p>
2None
��,
*
nameA unique name for this target. �
�
additional_linker_inputs�
Dependencies that are only made available to the C++ linker command.
<p>
  Unlike <code>deps</code>, which is conceptually made for both compilation and
  linking dependencies, <code>additional_linker_inputs</code> is specifically
  made for only the latter, and signals a dependency that is required only for
  linking (for example, files that are referenced in <code>linkopts</code>).
</p>
<p>
  For example, compiled Windows .res files can be provided here to be embedded in
  the binary target.
</p>
2[]�
�
	conlyopts�
Add these options to the C compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
2[]�
�
copts�
Add these options to the C/C++ compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
<p>
  Each string in this attribute is added in the given order to <code>COPTS</code> before
  compiling the binary target. The flags take effect only for compiling this target, not
  its dependencies, so be careful about header files included elsewhere.
  All paths should be relative to the workspace, not to the current package.
  This attribute should not be needed outside of <code>third_party</code>.
</p>
<p>
  If the package declares the <a href="${link package.features}">feature</a>
  <code>no_copts_tokenization</code>, Bourne shell tokenization applies only to strings
  that consist of a single "Make" variable.
</p>
2[]�
�
cxxopts�
Add these options to the C++ compilation command.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
2[]�
�
data�
The list of files needed by this library at runtime.

See general comments about <code>data</code>
at <a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>If a <code>data</code> is the name of a generated file, then this
   <code>cc_library</code> rule automatically depends on the generating
   rule.
</p>
<p>If a <code>data</code> is a rule name, then this
   <code>cc_library</code> rule automatically depends on that rule,
   and that rule's <code>outs</code> are automatically added to
   this <code>cc_library</code>'s data files.
</p>
<p>Your C++ code can access these data files like so:</p>
<pre><code class="lang-starlark">
  const std::string path = devtools_build::GetDataDependencyFilepath(
      "my/test/data/file");
</code></pre>
2[]�
�
defines�
List of defines to add to the compile line of this and all dependent targets.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
Each string, which must consist of a single Bourne shell token,
is prepended with <code>-D</code> and added to the compile command line to this target,
as well as to every rule that depends on it. Be very careful, since this may have
far-reaching effects -- the defines are added to every target that depends on
this target.  When in doubt, add define values to
<a href="#cc_binary.local_defines"><code>local_defines</code></a> instead.
2[]�
�
deps�
The list of other libraries to be linked in to the binary target.
<p>These can be <code>cc_library</code> or <code>objc_library</code>
targets.</p>

It is also allowed to
put linker scripts (.lds) into deps, and reference them in
<a href="#cc_binary.linkopts"><code>linkopts</code></a>,
but please consider
<a href="#cc_binary.additional_linker_inputs"><code>additional_linker_inputs</code></a>
for that use case.
*
CcInfo2[]�
�
dynamic_deps�
These are other <code>cc_shared_library</code> dependencies the current target depends on.

<p>
The <code>cc_shared_library</code> implementation will use the list of
<code>dynamic_deps</code> (transitively, i.e. also the <code>dynamic_deps</code> of the
current target's <code>dynamic_deps</code>) to decide which <code>cc_libraries</code> in
the transitive <code>deps</code> should not be linked in because they are already provided
by a different <code>cc_shared_library</code>.
*
CcSharedLibraryInfo2[]

env
2{}(
&

hdrs_checkDeprecated, no-op.2""�
�
includes�
List of include dirs to be added to the compile line.
Subject to <a href="${link make-variables}">"Make variable"</a> substitution.
Each string is prepended with the package path and passed to the C++ toolchain for
expansion via the "include_paths" CROSSTOOL feature. A toolchain running on a POSIX system
with typical feature definitions will produce
<code>-isystem path_to_package/include_entry</code>.
This should only be used for third-party libraries that
do not conform to the Google style of writing #include statements.
Unlike <a href="#cc_binary.copts">COPTS</a>, these flags are added for this rule
and every rule that depends on it. (Note: not the rules it depends upon!) Be
very careful, since this may have far-reaching effects.  When in doubt, add
"-I" flags to <a href="#cc_binary.copts">COPTS</a> instead.
<p>
The added <code>include</code> paths will include generated files as well as
files in the source tree.
</p>
2[]

licenses2[]�
�
link_extra_lib�
Control linking of extra libraries.
<p>
    By default, C++ binaries are linked against <code>@bazel_tools//tools/cpp:link_extra_lib</code>,
    which by default depends on the label flag <code>@bazel_tools//tools/cpp:link_extra_libs</code>.
    Without setting the flag, this library is empty by default. Setting the label flag
    allows linking optional dependencies, such as overrides for weak symbols, interceptors
    for shared library functions, or special runtime libraries (for malloc replacements,
    prefer <code>malloc</code> or <code>--custom_malloc</code>). Setting this attribute to
    <code>None</code> disables this behaviour.
</p>
*
CcInfo2&@bazel_tools//tools/cpp:link_extra_lib�
�
linkopts�
Add these flags to the C++ linker command.
Subject to <a href="make-variables.html">"Make" variable</a> substitution,
<a href="common-definitions.html#sh-tokenization">
Bourne shell tokenization</a> and
<a href="common-definitions.html#label-expansion">label expansion</a>.
Each string in this attribute is added to <code>LINKOPTS</code> before
linking the binary target.
<p>
    Each element of this list that does not start with <code>$</code> or <code>-</code> is
    assumed to be the label of a target in <code>deps</code>. The
    list of files generated by that target is appended to the linker
    options.  An error is reported if the label is invalid, or is
    not declared in <code>deps</code>.
</p>
2[]�
�

linkshared�
Create a shared library.
To enable this attribute, include <code>linkshared=True</code> in your rule. By default
this option is off.
<p>
  The presence of this flag means that linking occurs with the <code>-shared</code> flag
  to <code>gcc</code>, and the resulting shared library is suitable for loading into for
  example a Java program. However, for build purposes it will never be linked into the
  dependent binary, as it is assumed that shared libraries built with a
  <a href="#cc_binary">cc_binary</a> rule are only loaded manually by other programs, so
  it should not be considered a substitute for the <a href="#cc_library">cc_library</a>
  rule. For sake of scalability we recommend avoiding this approach altogether and
  simply letting <code>java_library</code> depend on <code>cc_library</code> rules
  instead.
</p>
<p>
  If you specify both <code>linkopts=['-static']</code> and <code>linkshared=True</code>,
  you get a single completely self-contained unit. If you specify both
  <code>linkstatic=True</code> and <code>linkshared=True</code>, you get a single, mostly
  self-contained unit.
</p>
2False�
�

linkstatic�
For <a href="${link cc_binary}"><code>cc_binary</code></a> and
<a href="${link cc_test}"><code>cc_test</code></a>: link the binary in static
mode. For <code>cc_library.link_static</code>: see below.
<p>By default this option is on for <code>cc_binary</code> and off for the rest.</p>
<p>
  If enabled and this is a binary or test, this option tells the build tool to link in
  <code>.a</code>'s instead of <code>.so</code>'s for user libraries whenever possible.
  System libraries such as libc (but <i>not</i> the C/C++ runtime libraries,
  see below) are still linked dynamically, as are libraries for which
  there is no static library. So the resulting executable will still be dynamically
  linked, hence only <i>mostly</i> static.
</p>
<p>
There are really three different ways to link an executable:
</p>
<ul>
<li> STATIC with fully_static_link feature, in which everything is linked statically;
  e.g. "<code>gcc -static foo.o libbar.a libbaz.a -lm</code>".<br/>
  This mode is enabled by specifying <code>fully_static_link</code> in the
  <a href="${link common-definitions#features}"><code>features</code></a> attribute.</li>
<li> STATIC, in which all user libraries are linked statically (if a static
  version is available), but where system libraries (excluding C/C++ runtime libraries)
  are linked dynamically, e.g. "<code>gcc foo.o libfoo.a libbaz.a -lm</code>".<br/>
  This mode is enabled by specifying <code>linkstatic=True</code>.</li>
<li> DYNAMIC, in which all libraries are linked dynamically (if a dynamic version is
  available), e.g. "<code>gcc foo.o libfoo.so libbaz.so -lm</code>".<br/>
  This mode is enabled by specifying <code>linkstatic=False</code>.</li>
</ul>
<p>
If the <code>linkstatic</code> attribute or <code>fully_static_link</code> in
<code>features</code> is used outside of <code>//third_party</code>
please include a comment near the rule to explain why.
</p>
<p>
The <code>linkstatic</code> attribute has a different meaning if used on a
<a href="${link cc_library}"><code>cc_library()</code></a> rule.
For a C++ library, <code>linkstatic=True</code> indicates that only
static linking is allowed, so no <code>.so</code> will be produced. linkstatic=False does
not prevent static libraries from being created. The attribute is meant to control the
creation of dynamic libraries.
</p>
<p>
There should be very little code built with <code>linkstatic=False</code> in production.
If <code>linkstatic=False</code>, then the build tool will create symlinks to
depended-upon shared libraries in the <code>*.runfiles</code> area.
</p>
2True�
�
local_defines�
List of defines to add to the compile line.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution and
<a href="${link common-definitions#sh-tokenization}">Bourne shell tokenization</a>.
Each string, which must consist of a single Bourne shell token,
is prepended with <code>-D</code> and added to the compile command line for this target,
but not to its dependents. Unlike <code>defines</code>, the defines are only added to the
compile command line for this target.
2[]�
�
malloc�
Override the default dependency on malloc.
<p>
  By default, C++ binaries are linked against <code>//tools/cpp:malloc</code>,
  which is an empty library so the binary ends up using libc malloc.
  This label must refer to a <code>cc_library</code>. If compilation is for a non-C++
  rule, this option has no effect. The value of this attribute is ignored if
  <code>linkshared=True</code> is specified.
</p>
*
CcInfo2@bazel_tools//tools/cpp:malloc�
�
module_interfaces�
The list of files are regarded as C++20 Modules Interface.

<p>
C++ Standard has no restriction about module interface file extension
<ul>
<li>Clang use cppm </li>
<li>GCC can use any source file extension </li>
<li>MSVC use ixx </li>
</ul>
</p>
<p>The use is guarded by the flag
<code>--experimental_cpp_modules</code>.</p>
2[]�
�
nocopts�
Remove matching options from the C++ compilation command.
Subject to <a href="${link make-variables}">"Make" variable</a> substitution.
The value of this attribute is interpreted as a regular expression.
Any preexisting <code>COPTS</code> that match this regular expression
(including values explicitly specified in the rule's <a
href="#cc_binary.copts">copts</a> attribute)
will be removed from <code>COPTS</code> for purposes of compiling this rule.
This attribute should not be needed or used
outside of <code>third_party</code>.  The values are not preprocessed
in any way other than the "Make" variable substitution.
2""

reexport_deps2[]�
�
srcs�
The list of C and C++ files that are processed to create the library target.
These are C/C++ source and header files, either non-generated (normal source
code) or generated.
<p>All <code>.cc</code>, <code>.c</code>, and <code>.cpp</code> files will
   be compiled. These might be generated files: if a named file is in
   the <code>outs</code> of some other rule, this <code>cc_library</code>
   will automatically depend on that other rule.
</p>
<p>Pure assembler files (.s, .asm) are not preprocessed and are typically built using
the assembler. Preprocessed assembly files (.S) are preprocessed and are typically built
using the C/C++ compiler.
</p>
<p>A <code>.h</code> file will not be compiled, but will be available for
   inclusion by sources in this rule. Both <code>.cc</code> and
   <code>.h</code> files can directly include headers listed in
   these <code>srcs</code> or in the <code>hdrs</code> of this rule or any
   rule listed in the <code>deps</code> argument.
</p>
<p>All <code>#include</code>d files must be mentioned in the
   <code>hdrs</code> attribute of this or referenced <code>cc_library</code>
   rules, or they should be listed in <code>srcs</code> if they are private
   to this library. See <a href="#hdrs">"Header inclusion checking"</a> for
   a more detailed description.
</p>
<p><code>.so</code>, <code>.lo</code>, and <code>.a</code> files are
   pre-compiled files. Your library might have these as
   <code>srcs</code> if it uses third-party code for which we don't
   have source code.
</p>
<p>If the <code>srcs</code> attribute includes the label of another rule,
   <code>cc_library</code> will use the output files of that rule as source files to
   compile. This is useful for one-off generation of source code (for more than occasional
   use, it's better to implement a Starlark rule class and use the <code>cc_common</code>
   API)
</p>
<p>
  Permitted <code>srcs</code> file types:
</p>
<ul>
<li>C and C++ source files: <code>.c</code>, <code>.cc</code>, <code>.cpp</code>,
  <code>.cxx</code>, <code>.c++</code>, <code>.C</code></li>
<li>C and C++ header files: <code>.h</code>, <code>.hh</code>, <code>.hpp</code>,
  <code>.hxx</code>, <code>.inc</code>, <code>.inl</code>, <code>.H</code></li>
<li>Assembler with C preprocessor: <code>.S</code></li>
<li>Archive: <code>.a</code>, <code>.pic.a</code></li>
<li>"Always link" library: <code>.lo</code>, <code>.pic.lo</code></li>
<li>Shared library, versioned or unversioned: <code>.so</code>,
  <code>.so.<i>version</i></code></li>
<li>Object file: <code>.o</code>, <code>.pic.o</code></li>
</ul>

<p>
  ... and any rules that produce those files (e.g. <code>cc_embed_data</code>).
  Different extensions denote different programming languages in
  accordance with gcc convention.
</p>
2[]�
�
stamp�
Whether to encode build information into the binary. Possible values:
<ul>
<li>
  <code>stamp = 1</code>: Always stamp the build information into the binary, even in
  <a href="${link user-manual#flag--stamp}"><code>--nostamp</code></a> builds. <b>This
  setting should be avoided</b>, since it potentially kills remote caching for the
  binary and any downstream actions that depend on it.
</li>
<li>
  <code>stamp = 0</code>: Always replace build information by constant values. This
  gives good build result caching.
</li>
<li>
  <code>stamp = -1</code>: Embedding of build information is controlled by the
  <a href="${link user-manual#flag--stamp}"><code>--[no]stamp</code></a> flag.
</li>
</ul>
<p>Stamped binaries are <em>not</em> rebuilt unless their dependencies change.</p>
2-1�
�
win_def_file�
The Windows DEF file to be passed to linker.
<p>This attribute should only be used when Windows is the target platform.
It can be used to <a href="https://msdn.microsoft.com/en-us/library/d91k01sh.aspx">
export symbols</a> during linking a shared library.</p>
2None��java_jni_library�A Java library that bundles one or more native libraries created with [`cc_jni_library`](#cc_jni_library).

To load a native library referenced in the `native_libs` argument, use the static methods of the
[`RulesJni`](https://fmeum.github.io/rules_jni_javadocs/com/github/fmeum/rules_jni/RulesJni.html) class, which is
accessible for `srcs` of this target due to an implicit dependency on
[`@fmeum_rules_jni//jni/tools/native_loader`](targets.md#native_loader). These methods automatically choose the
correct version of the library for the current OS and CPU architecture, if available.

The native libraries referenced in the `native_libs` argument are added as resources and are thus included in the
deploy JARs of any [`java_binary`](https://docs.bazel.build/versions/main/be/java.html#java_binary) depending on
this target.

### Implicit output targets

- `<name>.hdrs`: The auto-generated JNI headers for this library.

  This target can be added to the `deps` of a
  [`cc_library`](https://docs.bazel.build/versions/main/be/c-cpp.html#cc_library) or
  [`cc_jni_library`](#cc_jni_library). See [`jni_headers`](#jni_headers) for a more detailed description of the
  underlying rule.



<p>This rule compiles and links sources into a <code>.jar</code> file.</p>

<h4>Implicit outputs</h4>
<ul>
  <li><code>lib<var>name</var>.jar</code>: A Java archive containing the class files.</li>
  <li><code>lib<var>name</var>-src.jar</code>: An archive containing the sources ("source
    jar").</li>
</ul>
"��
�T
java_jni_library�A Java library that bundles one or more native libraries created with [`cc_jni_library`](#cc_jni_library).

To load a native library referenced in the `native_libs` argument, use the static methods of the
[`RulesJni`](https://fmeum.github.io/rules_jni_javadocs/com/github/fmeum/rules_jni/RulesJni.html) class, which is
accessible for `srcs` of this target due to an implicit dependency on
[`@fmeum_rules_jni//jni/tools/native_loader`](targets.md#native_loader). These methods automatically choose the
correct version of the library for the current OS and CPU architecture, if available.

The native libraries referenced in the `native_libs` argument are added as resources and are thus included in the
deploy JARs of any [`java_binary`](https://docs.bazel.build/versions/main/be/java.html#java_binary) depending on
this target.

### Implicit output targets

- `<name>.hdrs`: The auto-generated JNI headers for this library.

  This target can be added to the `deps` of a
  [`cc_library`](https://docs.bazel.build/versions/main/be/c-cpp.html#cc_library) or
  [`cc_jni_library`](#cc_jni_library). See [`jni_headers`](#jni_headers) for a more detailed description of the
  underlying rule.



<p>This rule compiles and links sources into a <code>.jar</code> file.</p>

<h4>Implicit outputs</h4>
<ul>
  <li><code>lib<var>name</var>.jar</code>: A Java archive containing the class files.</li>
  <li><code>lib<var>name</var>-src.jar</code>: An archive containing the sources ("source
    jar").</li>
</ul>
*
nameA unique name for this target. �
add_exports�
Allow this library to access the given <code>module</code> or <code>package</code>.
<p>
This corresponds to the javac and JVM --add-exports= flags.
2[]�
	add_opens�
Allow this library to reflectively access the given <code>module</code> or
<code>package</code>.
<p>
This corresponds to the javac and JVM --add-opens= flags.
2[]I
bootclasspathRestricted API, do not use!*
BootClassPathInfo2None�
data�
The list of files needed by this library at runtime.
See general comments about <code>data</code> at
<a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>
  When building a <code>java_library</code>, Bazel doesn't put these files anywhere; if the
  <code>data</code> files are generated files then Bazel generates them. When building a
  test that depends on this <code>java_library</code> Bazel copies or links the
  <code>data</code> files into the runfiles area.
</p>
2[]�
deps�
The list of libraries to link into this library.
See general comments about <code>deps</code> at
<a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>
  The jars built by <code>java_library</code> rules listed in <code>deps</code> will be on
  the compile-time classpath of this rule. Furthermore the transitive closure of their
  <code>deps</code>, <code>runtime_deps</code> and <code>exports</code> will be on the
  runtime classpath.
</p>
<p>
  By contrast, targets in the <code>data</code> attribute are included in the runfiles but
  on neither the compile-time nor runtime classpath.
</p>
*
CcInfo*

JavaInfo2[]�
exported_plugins�
The list of <code><a href="#${link java_plugin}">java_plugin</a></code>s (e.g. annotation
processors) to export to libraries that directly depend on this library.
<p>
  The specified list of <code>java_plugin</code>s will be applied to any library which
  directly depends on this library, just as if that library had explicitly declared these
  labels in <code><a href="${link java_library.plugins}">plugins</a></code>.
</p>
*
JavaPluginInfo2[]�
exports�
Exported libraries.
<p>
  Listing rules here will make them available to parent rules, as if the parents explicitly
  depended on these rules. This is not true for regular (non-exported) <code>deps</code>.
</p>
<p>
  Summary: a rule <i>X</i> can access the code in <i>Y</i> if there exists a dependency
  path between them that begins with a <code>deps</code> edge followed by zero or more
  <code>exports</code> edges. Let's see some examples to illustrate this.
</p>
<p>
  Assume <i>A</i> depends on <i>B</i> and <i>B</i> depends on <i>C</i>. In this case
  C is a <em>transitive</em> dependency of A, so changing C's sources and rebuilding A will
  correctly rebuild everything. However A will not be able to use classes in C. To allow
  that, either A has to declare C in its <code>deps</code>, or B can make it easier for A
  (and anything that may depend on A) by declaring C in its (B's) <code>exports</code>
  attribute.
</p>
<p>
  The closure of exported libraries is available to all direct parent rules. Take a slightly
  different example: A depends on B, B depends on C and D, and also exports C but not D.
  Now A has access to C but not to D. Now, if C and D exported some libraries, C' and D'
  respectively, A could only access C' but not D'.
</p>
<p>
  Important: an exported rule is not a regular dependency. Sticking to the previous example,
  if B exports C and wants to also use C, it has to also list it in its own
  <code>deps</code>.
</p>
*

JavaInfo*
CcInfo2[]:
javabuilder_jvm_flagsRestricted API, do not use!2[]�
	javacopts�
Extra compiler options for this library.
Subject to <a href="make-variables.html">"Make variable"</a> substitution and
<a href="common-definitions.html#sh-tokenization">Bourne shell tokenization</a>.
<p>These compiler options are passed to javac after the global compiler options.</p>
2[]
licenses2[]�
	neverlink�
Whether this library should only be used for compilation and not at runtime.
Useful if the library will be provided by the runtime environment during execution. Examples
of such libraries are the IDE APIs for IDE plug-ins or <code>tools.jar</code> for anything
running on a standard JDK.
<p>
  Note that <code>neverlink = True</code> does not prevent the compiler from inlining material
  from this library into compilation targets that depend on it, as permitted by the Java
  Language Specification (e.g., <code>static final</code> constants of <code>String</code>
  or of primitive types). The preferred use case is therefore when the runtime library is
  identical to the compilation library.
</p>
<p>
  If the runtime library differs from the compilation library then you must ensure that it
  differs only in places that the JLS forbids compilers to inline (and that must hold for
  all future versions of the JLS).
</p>
2False�
plugins�
Java compiler plugins to run at compile-time.
Every <code>java_plugin</code> specified in this attribute will be run whenever this rule
is built. A library may also inherit plugins from dependencies that use
<code><a href="#java_library.exported_plugins">exported_plugins</a></code>. Resources
generated by the plugin will be included in the resulting jar of this rule.
*
JavaPluginInfo2[]�
proguard_specs�
Files to be used as Proguard specification.
These will describe the set of specifications to be used by Proguard. If specified,
they will be added to any <code>android_binary</code> target depending on this library.

The files included here must only have idempotent rules, namely -dontnote, -dontwarn,
assumenosideeffects, and rules that start with -keep. Other options can only appear in
<code>android_binary</code>'s proguard_specs, to ensure non-tautological merges.
2[]�
resource_strip_prefix�
The path prefix to strip from Java resources.
<p>
If specified, this path prefix is stripped from every file in the <code>resources</code>
attribute. It is an error for a resource file not to be under this directory. If not
specified (the default), the path of resource file is determined according to the same
logic as the Java package of source files. For example, a source file at
<code>stuff/java/foo/bar/a.txt</code> will be located at <code>foo/bar/a.txt</code>.
</p>
2""�
	resources�
A list of data files to include in a Java jar.
<p>
Resources may be source files or generated files.
</p>

<p>
If resources are specified, they will be bundled in the jar along with the usual
<code>.class</code> files produced by compilation. The location of the resources inside
of the jar file is determined by the project structure. Bazel first looks for Maven's
<a href="https://maven.apache.org/guides/introduction/introduction-to-the-standard-directory-layout.html">standard directory layout</a>,
(a "src" directory followed by a "resources" directory grandchild). If that is not
found, Bazel then looks for the topmost directory named "java" or "javatests" (so, for
example, if a resource is at <code>&lt;workspace root&gt;/x/java/y/java/z</code>, the
path of the resource will be <code>y/java/z</code>. This heuristic cannot be overridden,
however, the <code>resource_strip_prefix</code> attribute can be used to specify a
specific alternative directory for resource files.
2[]�
runtime_deps�
Libraries to make available to the final binary or test at runtime only.
Like ordinary <code>deps</code>, these will appear on the runtime classpath, but unlike
them, not on the compile-time classpath. Dependencies needed only at runtime should be
listed here. Dependency-analysis tools should ignore targets that appear in both
<code>runtime_deps</code> and <code>deps</code>.
*
CcInfo*

JavaInfo2[]�

srcs�

The list of source files that are processed to create the target.
This attribute is almost always required; see exceptions below.
<p>
Source files of type <code>.java</code> are compiled. In case of generated
<code>.java</code> files it is generally advisable to put the generating rule's name
here instead of the name of the file itself. This not only improves readability but
makes the rule more resilient to future changes: if the generating rule generates
different files in the future, you only need to fix one place: the <code>outs</code> of
the generating rule. You should not list the generating rule in <code>deps</code>
because it is a no-op.
</p>
<p>
Source files of type <code>.srcjar</code> are unpacked and compiled. (This is useful if
you need to generate a set of <code>.java</code> files with a genrule.)
</p>
<p>
Rules: if the rule (typically <code>genrule</code> or <code>filegroup</code>) generates
any of the files listed above, they will be used the same way as described for source
files.
</p>
<p>
Source files of type <code>.properties</code> are treated as resources.
</p>

<p>All other files are ignored, as long as there is at least one file of a
file type described above. Otherwise an error is raised.</p>

<p>
This argument is almost always required, except if you specify the <code>runtime_deps</code> argument.
</p>
2[]
,
*
nameA unique name for this target. �
�
add_exports�
Allow this library to access the given <code>module</code> or <code>package</code>.
<p>
This corresponds to the javac and JVM --add-exports= flags.
2[]�
�
	add_opens�
Allow this library to reflectively access the given <code>module</code> or
<code>package</code>.
<p>
This corresponds to the javac and JVM --add-opens= flags.
2[]K
I
bootclasspathRestricted API, do not use!*
BootClassPathInfo2None�
�
data�
The list of files needed by this library at runtime.
See general comments about <code>data</code> at
<a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>
  When building a <code>java_library</code>, Bazel doesn't put these files anywhere; if the
  <code>data</code> files are generated files then Bazel generates them. When building a
  test that depends on this <code>java_library</code> Bazel copies or links the
  <code>data</code> files into the runfiles area.
</p>
2[]�
�
deps�
The list of libraries to link into this library.
See general comments about <code>deps</code> at
<a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>
  The jars built by <code>java_library</code> rules listed in <code>deps</code> will be on
  the compile-time classpath of this rule. Furthermore the transitive closure of their
  <code>deps</code>, <code>runtime_deps</code> and <code>exports</code> will be on the
  runtime classpath.
</p>
<p>
  By contrast, targets in the <code>data</code> attribute are included in the runfiles but
  on neither the compile-time nor runtime classpath.
</p>
*
CcInfo*

JavaInfo2[]�
�
exported_plugins�
The list of <code><a href="#${link java_plugin}">java_plugin</a></code>s (e.g. annotation
processors) to export to libraries that directly depend on this library.
<p>
  The specified list of <code>java_plugin</code>s will be applied to any library which
  directly depends on this library, just as if that library had explicitly declared these
  labels in <code><a href="${link java_library.plugins}">plugins</a></code>.
</p>
*
JavaPluginInfo2[]�
�
exports�
Exported libraries.
<p>
  Listing rules here will make them available to parent rules, as if the parents explicitly
  depended on these rules. This is not true for regular (non-exported) <code>deps</code>.
</p>
<p>
  Summary: a rule <i>X</i> can access the code in <i>Y</i> if there exists a dependency
  path between them that begins with a <code>deps</code> edge followed by zero or more
  <code>exports</code> edges. Let's see some examples to illustrate this.
</p>
<p>
  Assume <i>A</i> depends on <i>B</i> and <i>B</i> depends on <i>C</i>. In this case
  C is a <em>transitive</em> dependency of A, so changing C's sources and rebuilding A will
  correctly rebuild everything. However A will not be able to use classes in C. To allow
  that, either A has to declare C in its <code>deps</code>, or B can make it easier for A
  (and anything that may depend on A) by declaring C in its (B's) <code>exports</code>
  attribute.
</p>
<p>
  The closure of exported libraries is available to all direct parent rules. Take a slightly
  different example: A depends on B, B depends on C and D, and also exports C but not D.
  Now A has access to C but not to D. Now, if C and D exported some libraries, C' and D'
  respectively, A could only access C' but not D'.
</p>
<p>
  Important: an exported rule is not a regular dependency. Sticking to the previous example,
  if B exports C and wants to also use C, it has to also list it in its own
  <code>deps</code>.
</p>
*

JavaInfo*
CcInfo2[]<
:
javabuilder_jvm_flagsRestricted API, do not use!2[]�
�
	javacopts�
Extra compiler options for this library.
Subject to <a href="make-variables.html">"Make variable"</a> substitution and
<a href="common-definitions.html#sh-tokenization">Bourne shell tokenization</a>.
<p>These compiler options are passed to javac after the global compiler options.</p>
2[]

licenses2[]�
�
	neverlink�
Whether this library should only be used for compilation and not at runtime.
Useful if the library will be provided by the runtime environment during execution. Examples
of such libraries are the IDE APIs for IDE plug-ins or <code>tools.jar</code> for anything
running on a standard JDK.
<p>
  Note that <code>neverlink = True</code> does not prevent the compiler from inlining material
  from this library into compilation targets that depend on it, as permitted by the Java
  Language Specification (e.g., <code>static final</code> constants of <code>String</code>
  or of primitive types). The preferred use case is therefore when the runtime library is
  identical to the compilation library.
</p>
<p>
  If the runtime library differs from the compilation library then you must ensure that it
  differs only in places that the JLS forbids compilers to inline (and that must hold for
  all future versions of the JLS).
</p>
2False�
�
plugins�
Java compiler plugins to run at compile-time.
Every <code>java_plugin</code> specified in this attribute will be run whenever this rule
is built. A library may also inherit plugins from dependencies that use
<code><a href="#java_library.exported_plugins">exported_plugins</a></code>. Resources
generated by the plugin will be included in the resulting jar of this rule.
*
JavaPluginInfo2[]�
�
proguard_specs�
Files to be used as Proguard specification.
These will describe the set of specifications to be used by Proguard. If specified,
they will be added to any <code>android_binary</code> target depending on this library.

The files included here must only have idempotent rules, namely -dontnote, -dontwarn,
assumenosideeffects, and rules that start with -keep. Other options can only appear in
<code>android_binary</code>'s proguard_specs, to ensure non-tautological merges.
2[]�
�
resource_strip_prefix�
The path prefix to strip from Java resources.
<p>
If specified, this path prefix is stripped from every file in the <code>resources</code>
attribute. It is an error for a resource file not to be under this directory. If not
specified (the default), the path of resource file is determined according to the same
logic as the Java package of source files. For example, a source file at
<code>stuff/java/foo/bar/a.txt</code> will be located at <code>foo/bar/a.txt</code>.
</p>
2""�
�
	resources�
A list of data files to include in a Java jar.
<p>
Resources may be source files or generated files.
</p>

<p>
If resources are specified, they will be bundled in the jar along with the usual
<code>.class</code> files produced by compilation. The location of the resources inside
of the jar file is determined by the project structure. Bazel first looks for Maven's
<a href="https://maven.apache.org/guides/introduction/introduction-to-the-standard-directory-layout.html">standard directory layout</a>,
(a "src" directory followed by a "resources" directory grandchild). If that is not
found, Bazel then looks for the topmost directory named "java" or "javatests" (so, for
example, if a resource is at <code>&lt;workspace root&gt;/x/java/y/java/z</code>, the
path of the resource will be <code>y/java/z</code>. This heuristic cannot be overridden,
however, the <code>resource_strip_prefix</code> attribute can be used to specify a
specific alternative directory for resource files.
2[]�
�
runtime_deps�
Libraries to make available to the final binary or test at runtime only.
Like ordinary <code>deps</code>, these will appear on the runtime classpath, but unlike
them, not on the compile-time classpath. Dependencies needed only at runtime should be
listed here. Dependency-analysis tools should ignore targets that appear in both
<code>runtime_deps</code> and <code>deps</code>.
*
CcInfo*

JavaInfo2[]�

�

srcs�

The list of source files that are processed to create the target.
This attribute is almost always required; see exceptions below.
<p>
Source files of type <code>.java</code> are compiled. In case of generated
<code>.java</code> files it is generally advisable to put the generating rule's name
here instead of the name of the file itself. This not only improves readability but
makes the rule more resilient to future changes: if the generating rule generates
different files in the future, you only need to fix one place: the <code>outs</code> of
the generating rule. You should not list the generating rule in <code>deps</code>
because it is a no-op.
</p>
<p>
Source files of type <code>.srcjar</code> are unpacked and compiled. (This is useful if
you need to generate a set of <code>.java</code> files with a genrule.)
</p>
<p>
Rules: if the rule (typically <code>genrule</code> or <code>filegroup</code>) generates
any of the files listed above, they will be used the same way as described for source
files.
</p>
<p>
Source files of type <code>.properties</code> are treated as resources.
</p>

<p>All other files are ignored, as long as there is at least one file of a
file type described above. Otherwise an error is raised.</p>

<p>
This argument is almost always required, except if you specify the <code>runtime_deps</code> argument.
</p>
2[]�
//jni:cc_jni_library.bzlre
$
	rules_jnijnicc_jni_library.bzl/
cc_jni_library_cc_jni_library
,;
O�
//jni:java_jni_library.bzlrk
&
	rules_jnijnijava_jni_library.bzl3
java_jni_library_java_jni_library
.?
Uw
//jni:jni_headers.bzlr\
!
	rules_jnijnijni_headers.bzl)
jni_headers_jni_headers
)5
FѪ
&
	rules_jnijnijava_jni_library.bzl��java_jni_library�A Java library that bundles one or more native libraries created with [`cc_jni_library`](#cc_jni_library).

To load a native library referenced in the `native_libs` argument, use the static methods of the
[`RulesJni`](https://fmeum.github.io/rules_jni_javadocs/com/github/fmeum/rules_jni/RulesJni.html) class, which is
accessible for `srcs` of this target due to an implicit dependency on
[`@fmeum_rules_jni//jni/tools/native_loader`](targets.md#native_loader). These methods automatically choose the
correct version of the library for the current OS and CPU architecture, if available.

The native libraries referenced in the `native_libs` argument are added as resources and are thus included in the
deploy JARs of any [`java_binary`](https://docs.bazel.build/versions/main/be/java.html#java_binary) depending on
this target.

### Implicit output targets

- `<name>.hdrs`: The auto-generated JNI headers for this library.

  This target can be added to the `deps` of a
  [`cc_library`](https://docs.bazel.build/versions/main/be/c-cpp.html#cc_library) or
  [`cc_jni_library`](#cc_jni_library). See [`jni_headers`](#jni_headers) for a more detailed description of the
  underlying rule.



<p>This rule compiles and links sources into a <code>.jar</code> file.</p>

<h4>Implicit outputs</h4>
<ul>
  <li><code>lib<var>name</var>.jar</code>: A Java archive containing the class files.</li>
  <li><code>lib<var>name</var>-src.jar</code>: An archive containing the sources ("source
    jar").</li>
</ul>
"��
�T
java_jni_library�A Java library that bundles one or more native libraries created with [`cc_jni_library`](#cc_jni_library).

To load a native library referenced in the `native_libs` argument, use the static methods of the
[`RulesJni`](https://fmeum.github.io/rules_jni_javadocs/com/github/fmeum/rules_jni/RulesJni.html) class, which is
accessible for `srcs` of this target due to an implicit dependency on
[`@fmeum_rules_jni//jni/tools/native_loader`](targets.md#native_loader). These methods automatically choose the
correct version of the library for the current OS and CPU architecture, if available.

The native libraries referenced in the `native_libs` argument are added as resources and are thus included in the
deploy JARs of any [`java_binary`](https://docs.bazel.build/versions/main/be/java.html#java_binary) depending on
this target.

### Implicit output targets

- `<name>.hdrs`: The auto-generated JNI headers for this library.

  This target can be added to the `deps` of a
  [`cc_library`](https://docs.bazel.build/versions/main/be/c-cpp.html#cc_library) or
  [`cc_jni_library`](#cc_jni_library). See [`jni_headers`](#jni_headers) for a more detailed description of the
  underlying rule.



<p>This rule compiles and links sources into a <code>.jar</code> file.</p>

<h4>Implicit outputs</h4>
<ul>
  <li><code>lib<var>name</var>.jar</code>: A Java archive containing the class files.</li>
  <li><code>lib<var>name</var>-src.jar</code>: An archive containing the sources ("source
    jar").</li>
</ul>
*
nameA unique name for this target. �
add_exports�
Allow this library to access the given <code>module</code> or <code>package</code>.
<p>
This corresponds to the javac and JVM --add-exports= flags.
2[]�
	add_opens�
Allow this library to reflectively access the given <code>module</code> or
<code>package</code>.
<p>
This corresponds to the javac and JVM --add-opens= flags.
2[]I
bootclasspathRestricted API, do not use!*
BootClassPathInfo2None�
data�
The list of files needed by this library at runtime.
See general comments about <code>data</code> at
<a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>
  When building a <code>java_library</code>, Bazel doesn't put these files anywhere; if the
  <code>data</code> files are generated files then Bazel generates them. When building a
  test that depends on this <code>java_library</code> Bazel copies or links the
  <code>data</code> files into the runfiles area.
</p>
2[]�
deps�
The list of libraries to link into this library.
See general comments about <code>deps</code> at
<a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>
  The jars built by <code>java_library</code> rules listed in <code>deps</code> will be on
  the compile-time classpath of this rule. Furthermore the transitive closure of their
  <code>deps</code>, <code>runtime_deps</code> and <code>exports</code> will be on the
  runtime classpath.
</p>
<p>
  By contrast, targets in the <code>data</code> attribute are included in the runfiles but
  on neither the compile-time nor runtime classpath.
</p>
*
CcInfo*

JavaInfo2[]�
exported_plugins�
The list of <code><a href="#${link java_plugin}">java_plugin</a></code>s (e.g. annotation
processors) to export to libraries that directly depend on this library.
<p>
  The specified list of <code>java_plugin</code>s will be applied to any library which
  directly depends on this library, just as if that library had explicitly declared these
  labels in <code><a href="${link java_library.plugins}">plugins</a></code>.
</p>
*
JavaPluginInfo2[]�
exports�
Exported libraries.
<p>
  Listing rules here will make them available to parent rules, as if the parents explicitly
  depended on these rules. This is not true for regular (non-exported) <code>deps</code>.
</p>
<p>
  Summary: a rule <i>X</i> can access the code in <i>Y</i> if there exists a dependency
  path between them that begins with a <code>deps</code> edge followed by zero or more
  <code>exports</code> edges. Let's see some examples to illustrate this.
</p>
<p>
  Assume <i>A</i> depends on <i>B</i> and <i>B</i> depends on <i>C</i>. In this case
  C is a <em>transitive</em> dependency of A, so changing C's sources and rebuilding A will
  correctly rebuild everything. However A will not be able to use classes in C. To allow
  that, either A has to declare C in its <code>deps</code>, or B can make it easier for A
  (and anything that may depend on A) by declaring C in its (B's) <code>exports</code>
  attribute.
</p>
<p>
  The closure of exported libraries is available to all direct parent rules. Take a slightly
  different example: A depends on B, B depends on C and D, and also exports C but not D.
  Now A has access to C but not to D. Now, if C and D exported some libraries, C' and D'
  respectively, A could only access C' but not D'.
</p>
<p>
  Important: an exported rule is not a regular dependency. Sticking to the previous example,
  if B exports C and wants to also use C, it has to also list it in its own
  <code>deps</code>.
</p>
*

JavaInfo*
CcInfo2[]:
javabuilder_jvm_flagsRestricted API, do not use!2[]�
	javacopts�
Extra compiler options for this library.
Subject to <a href="make-variables.html">"Make variable"</a> substitution and
<a href="common-definitions.html#sh-tokenization">Bourne shell tokenization</a>.
<p>These compiler options are passed to javac after the global compiler options.</p>
2[]
licenses2[]�
	neverlink�
Whether this library should only be used for compilation and not at runtime.
Useful if the library will be provided by the runtime environment during execution. Examples
of such libraries are the IDE APIs for IDE plug-ins or <code>tools.jar</code> for anything
running on a standard JDK.
<p>
  Note that <code>neverlink = True</code> does not prevent the compiler from inlining material
  from this library into compilation targets that depend on it, as permitted by the Java
  Language Specification (e.g., <code>static final</code> constants of <code>String</code>
  or of primitive types). The preferred use case is therefore when the runtime library is
  identical to the compilation library.
</p>
<p>
  If the runtime library differs from the compilation library then you must ensure that it
  differs only in places that the JLS forbids compilers to inline (and that must hold for
  all future versions of the JLS).
</p>
2False�
plugins�
Java compiler plugins to run at compile-time.
Every <code>java_plugin</code> specified in this attribute will be run whenever this rule
is built. A library may also inherit plugins from dependencies that use
<code><a href="#java_library.exported_plugins">exported_plugins</a></code>. Resources
generated by the plugin will be included in the resulting jar of this rule.
*
JavaPluginInfo2[]�
proguard_specs�
Files to be used as Proguard specification.
These will describe the set of specifications to be used by Proguard. If specified,
they will be added to any <code>android_binary</code> target depending on this library.

The files included here must only have idempotent rules, namely -dontnote, -dontwarn,
assumenosideeffects, and rules that start with -keep. Other options can only appear in
<code>android_binary</code>'s proguard_specs, to ensure non-tautological merges.
2[]�
resource_strip_prefix�
The path prefix to strip from Java resources.
<p>
If specified, this path prefix is stripped from every file in the <code>resources</code>
attribute. It is an error for a resource file not to be under this directory. If not
specified (the default), the path of resource file is determined according to the same
logic as the Java package of source files. For example, a source file at
<code>stuff/java/foo/bar/a.txt</code> will be located at <code>foo/bar/a.txt</code>.
</p>
2""�
	resources�
A list of data files to include in a Java jar.
<p>
Resources may be source files or generated files.
</p>

<p>
If resources are specified, they will be bundled in the jar along with the usual
<code>.class</code> files produced by compilation. The location of the resources inside
of the jar file is determined by the project structure. Bazel first looks for Maven's
<a href="https://maven.apache.org/guides/introduction/introduction-to-the-standard-directory-layout.html">standard directory layout</a>,
(a "src" directory followed by a "resources" directory grandchild). If that is not
found, Bazel then looks for the topmost directory named "java" or "javatests" (so, for
example, if a resource is at <code>&lt;workspace root&gt;/x/java/y/java/z</code>, the
path of the resource will be <code>y/java/z</code>. This heuristic cannot be overridden,
however, the <code>resource_strip_prefix</code> attribute can be used to specify a
specific alternative directory for resource files.
2[]�
runtime_deps�
Libraries to make available to the final binary or test at runtime only.
Like ordinary <code>deps</code>, these will appear on the runtime classpath, but unlike
them, not on the compile-time classpath. Dependencies needed only at runtime should be
listed here. Dependency-analysis tools should ignore targets that appear in both
<code>runtime_deps</code> and <code>deps</code>.
*
CcInfo*

JavaInfo2[]�

srcs�

The list of source files that are processed to create the target.
This attribute is almost always required; see exceptions below.
<p>
Source files of type <code>.java</code> are compiled. In case of generated
<code>.java</code> files it is generally advisable to put the generating rule's name
here instead of the name of the file itself. This not only improves readability but
makes the rule more resilient to future changes: if the generating rule generates
different files in the future, you only need to fix one place: the <code>outs</code> of
the generating rule. You should not list the generating rule in <code>deps</code>
because it is a no-op.
</p>
<p>
Source files of type <code>.srcjar</code> are unpacked and compiled. (This is useful if
you need to generate a set of <code>.java</code> files with a genrule.)
</p>
<p>
Rules: if the rule (typically <code>genrule</code> or <code>filegroup</code>) generates
any of the files listed above, they will be used the same way as described for source
files.
</p>
<p>
Source files of type <code>.properties</code> are treated as resources.
</p>

<p>All other files are ignored, as long as there is at least one file of a
file type described above. Otherwise an error is raised.</p>

<p>
This argument is almost always required, except if you specify the <code>runtime_deps</code> argument.
</p>
2[]
,
*
nameA unique name for this target. �
�
add_exports�
Allow this library to access the given <code>module</code> or <code>package</code>.
<p>
This corresponds to the javac and JVM --add-exports= flags.
2[]�
�
	add_opens�
Allow this library to reflectively access the given <code>module</code> or
<code>package</code>.
<p>
This corresponds to the javac and JVM --add-opens= flags.
2[]K
I
bootclasspathRestricted API, do not use!*
BootClassPathInfo2None�
�
data�
The list of files needed by this library at runtime.
See general comments about <code>data</code> at
<a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>
  When building a <code>java_library</code>, Bazel doesn't put these files anywhere; if the
  <code>data</code> files are generated files then Bazel generates them. When building a
  test that depends on this <code>java_library</code> Bazel copies or links the
  <code>data</code> files into the runfiles area.
</p>
2[]�
�
deps�
The list of libraries to link into this library.
See general comments about <code>deps</code> at
<a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>
  The jars built by <code>java_library</code> rules listed in <code>deps</code> will be on
  the compile-time classpath of this rule. Furthermore the transitive closure of their
  <code>deps</code>, <code>runtime_deps</code> and <code>exports</code> will be on the
  runtime classpath.
</p>
<p>
  By contrast, targets in the <code>data</code> attribute are included in the runfiles but
  on neither the compile-time nor runtime classpath.
</p>
*
CcInfo*

JavaInfo2[]�
�
exported_plugins�
The list of <code><a href="#${link java_plugin}">java_plugin</a></code>s (e.g. annotation
processors) to export to libraries that directly depend on this library.
<p>
  The specified list of <code>java_plugin</code>s will be applied to any library which
  directly depends on this library, just as if that library had explicitly declared these
  labels in <code><a href="${link java_library.plugins}">plugins</a></code>.
</p>
*
JavaPluginInfo2[]�
�
exports�
Exported libraries.
<p>
  Listing rules here will make them available to parent rules, as if the parents explicitly
  depended on these rules. This is not true for regular (non-exported) <code>deps</code>.
</p>
<p>
  Summary: a rule <i>X</i> can access the code in <i>Y</i> if there exists a dependency
  path between them that begins with a <code>deps</code> edge followed by zero or more
  <code>exports</code> edges. Let's see some examples to illustrate this.
</p>
<p>
  Assume <i>A</i> depends on <i>B</i> and <i>B</i> depends on <i>C</i>. In this case
  C is a <em>transitive</em> dependency of A, so changing C's sources and rebuilding A will
  correctly rebuild everything. However A will not be able to use classes in C. To allow
  that, either A has to declare C in its <code>deps</code>, or B can make it easier for A
  (and anything that may depend on A) by declaring C in its (B's) <code>exports</code>
  attribute.
</p>
<p>
  The closure of exported libraries is available to all direct parent rules. Take a slightly
  different example: A depends on B, B depends on C and D, and also exports C but not D.
  Now A has access to C but not to D. Now, if C and D exported some libraries, C' and D'
  respectively, A could only access C' but not D'.
</p>
<p>
  Important: an exported rule is not a regular dependency. Sticking to the previous example,
  if B exports C and wants to also use C, it has to also list it in its own
  <code>deps</code>.
</p>
*

JavaInfo*
CcInfo2[]<
:
javabuilder_jvm_flagsRestricted API, do not use!2[]�
�
	javacopts�
Extra compiler options for this library.
Subject to <a href="make-variables.html">"Make variable"</a> substitution and
<a href="common-definitions.html#sh-tokenization">Bourne shell tokenization</a>.
<p>These compiler options are passed to javac after the global compiler options.</p>
2[]

licenses2[]�
�
	neverlink�
Whether this library should only be used for compilation and not at runtime.
Useful if the library will be provided by the runtime environment during execution. Examples
of such libraries are the IDE APIs for IDE plug-ins or <code>tools.jar</code> for anything
running on a standard JDK.
<p>
  Note that <code>neverlink = True</code> does not prevent the compiler from inlining material
  from this library into compilation targets that depend on it, as permitted by the Java
  Language Specification (e.g., <code>static final</code> constants of <code>String</code>
  or of primitive types). The preferred use case is therefore when the runtime library is
  identical to the compilation library.
</p>
<p>
  If the runtime library differs from the compilation library then you must ensure that it
  differs only in places that the JLS forbids compilers to inline (and that must hold for
  all future versions of the JLS).
</p>
2False�
�
plugins�
Java compiler plugins to run at compile-time.
Every <code>java_plugin</code> specified in this attribute will be run whenever this rule
is built. A library may also inherit plugins from dependencies that use
<code><a href="#java_library.exported_plugins">exported_plugins</a></code>. Resources
generated by the plugin will be included in the resulting jar of this rule.
*
JavaPluginInfo2[]�
�
proguard_specs�
Files to be used as Proguard specification.
These will describe the set of specifications to be used by Proguard. If specified,
they will be added to any <code>android_binary</code> target depending on this library.

The files included here must only have idempotent rules, namely -dontnote, -dontwarn,
assumenosideeffects, and rules that start with -keep. Other options can only appear in
<code>android_binary</code>'s proguard_specs, to ensure non-tautological merges.
2[]�
�
resource_strip_prefix�
The path prefix to strip from Java resources.
<p>
If specified, this path prefix is stripped from every file in the <code>resources</code>
attribute. It is an error for a resource file not to be under this directory. If not
specified (the default), the path of resource file is determined according to the same
logic as the Java package of source files. For example, a source file at
<code>stuff/java/foo/bar/a.txt</code> will be located at <code>foo/bar/a.txt</code>.
</p>
2""�
�
	resources�
A list of data files to include in a Java jar.
<p>
Resources may be source files or generated files.
</p>

<p>
If resources are specified, they will be bundled in the jar along with the usual
<code>.class</code> files produced by compilation. The location of the resources inside
of the jar file is determined by the project structure. Bazel first looks for Maven's
<a href="https://maven.apache.org/guides/introduction/introduction-to-the-standard-directory-layout.html">standard directory layout</a>,
(a "src" directory followed by a "resources" directory grandchild). If that is not
found, Bazel then looks for the topmost directory named "java" or "javatests" (so, for
example, if a resource is at <code>&lt;workspace root&gt;/x/java/y/java/z</code>, the
path of the resource will be <code>y/java/z</code>. This heuristic cannot be overridden,
however, the <code>resource_strip_prefix</code> attribute can be used to specify a
specific alternative directory for resource files.
2[]�
�
runtime_deps�
Libraries to make available to the final binary or test at runtime only.
Like ordinary <code>deps</code>, these will appear on the runtime classpath, but unlike
them, not on the compile-time classpath. Dependencies needed only at runtime should be
listed here. Dependency-analysis tools should ignore targets that appear in both
<code>runtime_deps</code> and <code>deps</code>.
*
CcInfo*

JavaInfo2[]�

�

srcs�

The list of source files that are processed to create the target.
This attribute is almost always required; see exceptions below.
<p>
Source files of type <code>.java</code> are compiled. In case of generated
<code>.java</code> files it is generally advisable to put the generating rule's name
here instead of the name of the file itself. This not only improves readability but
makes the rule more resilient to future changes: if the generating rule generates
different files in the future, you only need to fix one place: the <code>outs</code> of
the generating rule. You should not list the generating rule in <code>deps</code>
because it is a no-op.
</p>
<p>
Source files of type <code>.srcjar</code> are unpacked and compiled. (This is useful if
you need to generate a set of <code>.java</code> files with a genrule.)
</p>
<p>
Rules: if the rule (typically <code>genrule</code> or <code>filegroup</code>) generates
any of the files listed above, they will be used the same way as described for source
files.
</p>
<p>
Source files of type <code>.properties</code> are treated as resources.
</p>

<p>All other files are ignored, as long as there is at least one file of a
file type described above. Otherwise an error is raised.</p>

<p>
This argument is almost always required, except if you specify the <code>runtime_deps</code> argument.
</p>
2[]�
"//jni/private:java_jni_library.bzlrs
.
	rules_jnijni/privatejava_jni_library.bzl3
java_jni_library_java_jni_library
6G
]�
!
	rules_jnijnijni_headers.bzl�jni_headers�
Generates the native headers for a `java_library` and exposes it to `cc_*` rules.

For every Java class `com.example.Foo` in the `java_library` target specified by `lib` that contains at least one
function marked with `native` or constant annotated with `@Native`, the include directory exported by this rule will
contain a file `com_example_Foo.h` that provides the C/C++ interface for this class. Consuming `cc_*` rules should have
this rule added to their `deps` and can then access such a header file via:

```c
#include "com_example_Foo.h"
```

This rule also directly exports the JNI header, which can be included via:

```c
#include <jni.h>
```

*Example:*

```starlark
load("@fmeum_rules_jni//jni:defs.bzl", "jni_headers")

java_library(
    name = "os_utils",
    ...
)

jni_headers(
    name = "os_utils_hdrs",
    lib = ":os_utils",
)

cc_library(
    name = "os_utils_impl",
    ...
    deps = [":os_utils_hdrs"],
)
```
"�

�
jni_headers�
Generates the native headers for a `java_library` and exposes it to `cc_*` rules.

For every Java class `com.example.Foo` in the `java_library` target specified by `lib` that contains at least one
function marked with `native` or constant annotated with `@Native`, the include directory exported by this rule will
contain a file `com_example_Foo.h` that provides the C/C++ interface for this class. Consuming `cc_*` rules should have
this rule added to their `deps` and can then access such a header file via:

```c
#include "com_example_Foo.h"
```

This rule also directly exports the JNI header, which can be included via:

```c
#include <jni.h>
```

*Example:*

```starlark
load("@fmeum_rules_jni//jni:defs.bzl", "jni_headers")

java_library(
    name = "os_utils",
    ...
)

jni_headers(
    name = "os_utils_hdrs",
    lib = ":os_utils",
)

cc_library(
    name = "os_utils_impl",
    ...
    deps = [":os_utils_hdrs"],
)
```
*
nameA unique name for this target. Z
libCThe Java library for which native header files should be generated. *

JavaInfo"/
jni_headers @@rules_jni//jni:jni_headers.bzl
KK,
*
nameA unique name for this target. \
Z
libCThe Java library for which native header files should be generated. *

JavaInfo�
//jni/private:jni_headers.bzlrd
)
	rules_jnijni/privatejni_headers.bzl)
jni_headers_jni_headers
1=
N�
"
	rules_jnijnirepositories.bzl�	rules_jni_dependencies�Adds all external repositories required for rules_jni.

This should be called from a `WORKSPACE` file after the declaration of `fmeum_rules_jni` itself.

Currently, rules_jni depends on:

* [bazel_skylib](https://github.com/bazelbuild/bazel-skylib)
* [platforms](https://github.com/bazelbuild/platforms)
* [rules_license](https://github.com/bazelbuild/rules_license)
* individual files of the [OpenJDK](https://github.com/openjdk/jdk)

It also requires rules_cc 0.0.17 or later and rules_java 8.6.0 or later, which must be supplied by
the end user.*�
�
rules_jni_dependencies�Adds all external repositories required for rules_jni.

This should be called from a `WORKSPACE` file after the declaration of `fmeum_rules_jni` itself.

Currently, rules_jni depends on:

* [bazel_skylib](https://github.com/bazelbuild/bazel-skylib)
* [platforms](https://github.com/bazelbuild/platforms)
* [rules_license](https://github.com/bazelbuild/rules_license)
* individual files of the [OpenJDK](https://github.com/openjdk/jdk)

It also requires rules_cc 0.0.17 or later and rules_java 8.6.0 or later, which must be supplied by
the end user.2C
rules_jni_dependencies)@@rules_jni//jni/private:repositories.bzl
22�
//jni/private:repositories.bzlr{
*
	rules_jnijni/privaterepositories.bzl?
rules_jni_dependencies_rules_jni_dependencies
2I
e 