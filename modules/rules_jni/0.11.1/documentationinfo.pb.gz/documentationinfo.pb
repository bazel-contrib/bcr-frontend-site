�
:
	rules_jnijni/private/extensionsdownload_jdk_deps.bzl�download_jdk_depsJs
c
download_jdk_deps"N
download_jdk_deps9@@rules_jni//jni/private/extensions:download_jdk_deps.bzl
55i
//lib:modules.bzlrR
 
bazel_skyliblibmodules.bzl 
modulesmodules
)0
2�
//jni/private:repositories.bzlr^
*
	rules_jnijni/privaterepositories.bzl"
jdk_depsjdk_deps
3;
=�

D
	rules_jnijni/private/tools/libjvm_stubcurrent_java_runtime.bzl�current_java_runtime"�
�
current_java_runtime*
nameA unique name for this target. "[
current_java_runtimeC@@rules_jni//jni/private/tools/libjvm_stub:current_java_runtime.bzl
QQ,
*
nameA unique name for this target. �rlocation_path*�
�
rlocation_path	
ctx (

short_path (2U
rlocation_pathC@@rules_jni//jni/private/tools/libjvm_stub:current_java_runtime.bzl
a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.�
//tools/cpp:toolchain_utils.bzlru
-
bazel_tools	tools/cpptoolchain_utils.bzl6
find_cpp_toolchainfind_cpp_toolchain
6H
Jy
//cc/common:cc_common.bzlrZ
$
rules_cc	cc/commoncc_common.bzl$
	cc_common	cc_common
-6
8o
//cc/common:cc_info.bzlrR
"
rules_cc	cc/commoncc_info.bzl
CcInfoCcInfo
+1
3�	$CURRENT_JAVA_RUNTIME_HEADER_TEMPLATE�#ifndef RULES_JNI_LIBJVM_STUB_CURRENT_JAVA_RUNTIME_H
#define RULES_JNI_LIBJVM_STUB_CURRENT_JAVA_RUNTIME_H
#define RULES_JNI_JAVA_EXECUTABLE_RLOCATION "{}"
#endif
j��#ifndef RULES_JNI_LIBJVM_STUB_CURRENT_JAVA_RUNTIME_H
#define RULES_JNI_LIBJVM_STUB_CURRENT_JAVA_RUNTIME_H
#define RULES_JNI_JAVA_EXECUTABLE_RLOCATION "{}"
#endif
�
B
	rules_jnijni/private/tools/libjvm_stubcurrent_repository.bzlW	RULES_JNI_REPOSITORY_DEFINERULES_JNI_REPOSITORY=\"\"jRULES_JNI_REPOSITORY=\"\"�)
,
	rules_jnijni/privatecc_jni_library.bzl�!cc_jni_library�A native library that can be loaded by a Java application at runtime.

Add this target to the `native_libs` of a [`java_jni_library`](#java_jni_library).

The native libraries are exposed as Java resources, which are placed in a Java package determined from the Bazel
package of this target according to the
[Maven standard directory layout](https://maven.apache.org/guides/introduction/introduction-to-the-standard-directory-layout.html).
If the library should be included in the `com/example` subdirectory of a deploy JAR, which corresponds to the Java
package `com.example`, place it under one of the following Bazel package structures:
* `**/src/*/native/com/example` (preferred)
* `**/src/*/resources/com/example`
* `**/src/*/java/com/example`
* `**/java/com/example`

*Note:* Building a native library for multiple platforms by setting the `platforms` attribute to a non-empty list of
platforms requires either remote execution or cross-compilation toolchains for the target platforms. As both require
a more sophisticated Bazel setup, the following simpler process can be helpful for smaller or open-source projects:

1. Leave the `platforms` attribute empty or unspecified.
2. Build the deploy JAR of the Java library or application with all native libraries included separately for each
   target platform, for example using a CI platform.
3. Manually (outside Bazel) merge the deploy JARs. The `.class` files will be identical and can thus safely be
   replaced, but the resulting JAR will include all versions of the native library and the correct version will be
   loaded at runtime.

An example of such a CI workflow can be found [here](https://github.com/CodeIntelligenceTesting/jazzer/blob/d1835d6fa2ebfb7b2661cfaaa8acb8bbf42bb486/.github/workflows/release.yml).
*�
�
cc_jni_library*
nameA unique name for this target. (�
	platforms�A list of [`platform`s](https://docs.bazel.build/versions/main/be/platform.html#platform) for which
this native library should be built. If the list is empty (the default), the library is only built for the
current target platform.[](�
cc_binary_args�Any arguments to a
[`cc_library`](https://docs.bazel.build/versions/main/be/c-cpp.html#cc_library), except for:
`linkshared` (always `True`), `linkstatic` (always `True`), `data` (runfiles are not supported)(�A native library that can be loaded by a Java application at runtime.

Add this target to the `native_libs` of a [`java_jni_library`](#java_jni_library).

The native libraries are exposed as Java resources, which are placed in a Java package determined from the Bazel
package of this target according to the
[Maven standard directory layout](https://maven.apache.org/guides/introduction/introduction-to-the-standard-directory-layout.html).
If the library should be included in the `com/example` subdirectory of a deploy JAR, which corresponds to the Java
package `com.example`, place it under one of the following Bazel package structures:
* `**/src/*/native/com/example` (preferred)
* `**/src/*/resources/com/example`
* `**/src/*/java/com/example`
* `**/java/com/example`

*Note:* Building a native library for multiple platforms by setting the `platforms` attribute to a non-empty list of
platforms requires either remote execution or cross-compilation toolchains for the target platforms. As both require
a more sophisticated Bazel setup, the following simpler process can be helpful for smaller or open-source projects:

1. Leave the `platforms` attribute empty or unspecified.
2. Build the deploy JAR of the Java library or application with all native libraries included separately for each
   target platform, for example using a CI platform.
3. Manually (outside Bazel) merge the deploy JARs. The `.class` files will be identical and can thus safely be
   replaced, but the resulting JAR will include all versions of the native library and the correct version will be
   loaded at runtime.

An example of such a CI workflow can be found [here](https://github.com/CodeIntelligenceTesting/jazzer/blob/d1835d6fa2ebfb7b2661cfaaa8acb8bbf42bb486/.github/workflows/release.yml).
2=
cc_jni_library+@@rules_jni//jni/private:cc_jni_library.bzl
��"_single_platform_artifact"_multi_platform_artifact"java_library*	cc_binary*	cc_binary*	cc_binary2java_library�SinglePlatformArtifactInfo2�
�
SinglePlatformArtifactInfo
cpu(Undocumented)
file(Undocumented)
os(Undocumented)
platform(Undocumented)"I
SinglePlatformArtifactInfo+@@rules_jni//jni/private:cc_jni_library.bzl
&&

cpu(Undocumented)

file(Undocumented)

os(Undocumented)

platform(Undocumented)k
//cc:cc_binary.bzlrS

rules_cccccc_binary.bzl$
	cc_binary	cc_binary
&/
1}
//java:java_library.bzlr`
$

rules_javajavajava_library.bzl*
java_libraryjava_library
-9
;�
//jni/private:os_cpu_utils.bzlr�
*
	rules_jnijni/privateos_cpu_utils.bzl4
SELECT_TARGET_CPUSELECT_TARGET_CPU
3D2
SELECT_TARGET_OSSELECT_TARGET_OS
HX
Z�
//jni/private:transitions.bzlr
)
	rules_jnijni/privatetransitions.bzlD
multi_platform_transitionmulti_platform_transition
2K
M�
$
	rules_jnijni/private
common.bzl�merge_cc_infos"�
�
merge_cc_infos*
nameA unique name for this target. 
deps*
CcInfo2[]"5
merge_cc_infos#@@rules_jni//jni/private:common.bzl
**,
*
nameA unique name for this target. 

deps*
CcInfo2[]�merge_java_infos"�
�
merge_java_infos*
nameA unique name for this target. 
deps*

JavaInfo2[]"7
merge_java_infos#@@rules_jni//jni/private:common.bzl
>>,
*
nameA unique name for this target. 

deps*

JavaInfo2[]�java_identifier*l
U
java_identifier

name (26
java_identifier#@@rules_jni//jni/private:common.bzl
[[2_hash�jni_escaped_identifier*�
c
jni_escaped_identifier

name (2=
jni_escaped_identifier#@@rules_jni//jni/private:common.bzl
aa2java_identifier�make_root_relative*~
n
make_root_relative

path (
packageNone(29
make_root_relative#@@rules_jni//jni/private:common.bzl
HHy
//cc/common:cc_common.bzlrZ
$
rules_cc	cc/commoncc_common.bzl$
	cc_common	cc_common
-6
8o
//cc/common:cc_info.bzlrR
"
rules_cc	cc/commoncc_info.bzl
CcInfoCcInfo
+1
3�
//java/common:java_common.bzlrd
*

rules_javajava/commonjava_common.bzl(
java_commonjava_common
3>
@}
//java/common:java_info.bzlr\
(

rules_javajava/commonjava_info.bzl"
JavaInfoJavaInfo
19
;̬
.
	rules_jnijni/privatejava_jni_library.bzl��java_jni_library�A Java library that bundles one or more native libraries created with [`cc_jni_library`](#cc_jni_library).

To load a native library referenced in the `native_libs` argument, use the static methods of the
[`RulesJni`](https://fmeum.github.io/rules_jni_javadocs/com/github/fmeum/rules_jni/RulesJni.html) class, which is
accessible for `srcs` of this target due to an implicit dependency on
[`@fmeum_rules_jni//jni/tools/native_loader`](targets.md#native_loader). These methods automatically choose the
correct version of the library for the current OS and CPU architecture, if available.

The native libraries referenced in the `native_libs` argument are added as resources and are thus included in the
deploy JARs of any [`java_binary`](https://docs.bazel.build/versions/main/be/java.html#java_binary) depending on
this target.

### Implicit output targets

- `<name>.hdrs`: The auto-generated JNI headers for this library.

  This target can be added to the `deps` of a
  [`cc_library`](https://docs.bazel.build/versions/main/be/c-cpp.html#cc_library) or
  [`cc_jni_library`](#cc_jni_library). See [`jni_headers`](#jni_headers) for a more detailed description of the
  underlying rule.



<p>This rule compiles and links sources into a <code>.jar</code> file.</p>

<h4>Implicit outputs</h4>
<ul>
  <li><code>lib<var>name</var>.jar</code>: A Java archive containing the class files.</li>
  <li><code>lib<var>name</var>-src.jar</code>: An archive containing the sources ("source
    jar").</li>
</ul>
"��
�T
java_jni_library�A Java library that bundles one or more native libraries created with [`cc_jni_library`](#cc_jni_library).

To load a native library referenced in the `native_libs` argument, use the static methods of the
[`RulesJni`](https://fmeum.github.io/rules_jni_javadocs/com/github/fmeum/rules_jni/RulesJni.html) class, which is
accessible for `srcs` of this target due to an implicit dependency on
[`@fmeum_rules_jni//jni/tools/native_loader`](targets.md#native_loader). These methods automatically choose the
correct version of the library for the current OS and CPU architecture, if available.

The native libraries referenced in the `native_libs` argument are added as resources and are thus included in the
deploy JARs of any [`java_binary`](https://docs.bazel.build/versions/main/be/java.html#java_binary) depending on
this target.

### Implicit output targets

- `<name>.hdrs`: The auto-generated JNI headers for this library.

  This target can be added to the `deps` of a
  [`cc_library`](https://docs.bazel.build/versions/main/be/c-cpp.html#cc_library) or
  [`cc_jni_library`](#cc_jni_library). See [`jni_headers`](#jni_headers) for a more detailed description of the
  underlying rule.



<p>This rule compiles and links sources into a <code>.jar</code> file.</p>

<h4>Implicit outputs</h4>
<ul>
  <li><code>lib<var>name</var>.jar</code>: A Java archive containing the class files.</li>
  <li><code>lib<var>name</var>-src.jar</code>: An archive containing the sources ("source
    jar").</li>
</ul>
*
nameA unique name for this target. �
add_exports�
Allow this library to access the given <code>module</code> or <code>package</code>.
<p>
This corresponds to the javac and JVM --add-exports= flags.
2[]�
	add_opens�
Allow this library to reflectively access the given <code>module</code> or
<code>package</code>.
<p>
This corresponds to the javac and JVM --add-opens= flags.
2[]I
bootclasspathRestricted API, do not use!*
BootClassPathInfo2None�
data�
The list of files needed by this library at runtime.
See general comments about <code>data</code> at
<a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>
  When building a <code>java_library</code>, Bazel doesn't put these files anywhere; if the
  <code>data</code> files are generated files then Bazel generates them. When building a
  test that depends on this <code>java_library</code> Bazel copies or links the
  <code>data</code> files into the runfiles area.
</p>
2[]�
deps�
The list of libraries to link into this library.
See general comments about <code>deps</code> at
<a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>
  The jars built by <code>java_library</code> rules listed in <code>deps</code> will be on
  the compile-time classpath of this rule. Furthermore the transitive closure of their
  <code>deps</code>, <code>runtime_deps</code> and <code>exports</code> will be on the
  runtime classpath.
</p>
<p>
  By contrast, targets in the <code>data</code> attribute are included in the runfiles but
  on neither the compile-time nor runtime classpath.
</p>
*
CcInfo*

JavaInfo2[]�
exported_plugins�
The list of <code><a href="#${link java_plugin}">java_plugin</a></code>s (e.g. annotation
processors) to export to libraries that directly depend on this library.
<p>
  The specified list of <code>java_plugin</code>s will be applied to any library which
  directly depends on this library, just as if that library had explicitly declared these
  labels in <code><a href="${link java_library.plugins}">plugins</a></code>.
</p>
*
JavaPluginInfo2[]�
exports�
Exported libraries.
<p>
  Listing rules here will make them available to parent rules, as if the parents explicitly
  depended on these rules. This is not true for regular (non-exported) <code>deps</code>.
</p>
<p>
  Summary: a rule <i>X</i> can access the code in <i>Y</i> if there exists a dependency
  path between them that begins with a <code>deps</code> edge followed by zero or more
  <code>exports</code> edges. Let's see some examples to illustrate this.
</p>
<p>
  Assume <i>A</i> depends on <i>B</i> and <i>B</i> depends on <i>C</i>. In this case
  C is a <em>transitive</em> dependency of A, so changing C's sources and rebuilding A will
  correctly rebuild everything. However A will not be able to use classes in C. To allow
  that, either A has to declare C in its <code>deps</code>, or B can make it easier for A
  (and anything that may depend on A) by declaring C in its (B's) <code>exports</code>
  attribute.
</p>
<p>
  The closure of exported libraries is available to all direct parent rules. Take a slightly
  different example: A depends on B, B depends on C and D, and also exports C but not D.
  Now A has access to C but not to D. Now, if C and D exported some libraries, C' and D'
  respectively, A could only access C' but not D'.
</p>
<p>
  Important: an exported rule is not a regular dependency. Sticking to the previous example,
  if B exports C and wants to also use C, it has to also list it in its own
  <code>deps</code>.
</p>
*

JavaInfo*
CcInfo2[]:
javabuilder_jvm_flagsRestricted API, do not use!2[]�
	javacopts�
Extra compiler options for this library.
Subject to <a href="make-variables.html">"Make variable"</a> substitution and
<a href="common-definitions.html#sh-tokenization">Bourne shell tokenization</a>.
<p>These compiler options are passed to javac after the global compiler options.</p>
2[]
licenses2[]�
	neverlink�
Whether this library should only be used for compilation and not at runtime.
Useful if the library will be provided by the runtime environment during execution. Examples
of such libraries are the IDE APIs for IDE plug-ins or <code>tools.jar</code> for anything
running on a standard JDK.
<p>
  Note that <code>neverlink = True</code> does not prevent the compiler from inlining material
  from this library into compilation targets that depend on it, as permitted by the Java
  Language Specification (e.g., <code>static final</code> constants of <code>String</code>
  or of primitive types). The preferred use case is therefore when the runtime library is
  identical to the compilation library.
</p>
<p>
  If the runtime library differs from the compilation library then you must ensure that it
  differs only in places that the JLS forbids compilers to inline (and that must hold for
  all future versions of the JLS).
</p>
2False�
plugins�
Java compiler plugins to run at compile-time.
Every <code>java_plugin</code> specified in this attribute will be run whenever this rule
is built. A library may also inherit plugins from dependencies that use
<code><a href="#java_library.exported_plugins">exported_plugins</a></code>. Resources
generated by the plugin will be included in the resulting jar of this rule.
*
JavaPluginInfo2[]�
proguard_specs�
Files to be used as Proguard specification.
These will describe the set of specifications to be used by Proguard. If specified,
they will be added to any <code>android_binary</code> target depending on this library.

The files included here must only have idempotent rules, namely -dontnote, -dontwarn,
assumenosideeffects, and rules that start with -keep. Other options can only appear in
<code>android_binary</code>'s proguard_specs, to ensure non-tautological merges.
2[]�
resource_strip_prefix�
The path prefix to strip from Java resources.
<p>
If specified, this path prefix is stripped from every file in the <code>resources</code>
attribute. It is an error for a resource file not to be under this directory. If not
specified (the default), the path of resource file is determined according to the same
logic as the Java package of source files. For example, a source file at
<code>stuff/java/foo/bar/a.txt</code> will be located at <code>foo/bar/a.txt</code>.
</p>
2""�
	resources�
A list of data files to include in a Java jar.
<p>
Resources may be source files or generated files.
</p>

<p>
If resources are specified, they will be bundled in the jar along with the usual
<code>.class</code> files produced by compilation. The location of the resources inside
of the jar file is determined by the project structure. Bazel first looks for Maven's
<a href="https://maven.apache.org/guides/introduction/introduction-to-the-standard-directory-layout.html">standard directory layout</a>,
(a "src" directory followed by a "resources" directory grandchild). If that is not
found, Bazel then looks for the topmost directory named "java" or "javatests" (so, for
example, if a resource is at <code>&lt;workspace root&gt;/x/java/y/java/z</code>, the
path of the resource will be <code>y/java/z</code>. This heuristic cannot be overridden,
however, the <code>resource_strip_prefix</code> attribute can be used to specify a
specific alternative directory for resource files.
2[]�
runtime_deps�
Libraries to make available to the final binary or test at runtime only.
Like ordinary <code>deps</code>, these will appear on the runtime classpath, but unlike
them, not on the compile-time classpath. Dependencies needed only at runtime should be
listed here. Dependency-analysis tools should ignore targets that appear in both
<code>runtime_deps</code> and <code>deps</code>.
*
CcInfo*

JavaInfo2[]�

srcs�

The list of source files that are processed to create the target.
This attribute is almost always required; see exceptions below.
<p>
Source files of type <code>.java</code> are compiled. In case of generated
<code>.java</code> files it is generally advisable to put the generating rule's name
here instead of the name of the file itself. This not only improves readability but
makes the rule more resilient to future changes: if the generating rule generates
different files in the future, you only need to fix one place: the <code>outs</code> of
the generating rule. You should not list the generating rule in <code>deps</code>
because it is a no-op.
</p>
<p>
Source files of type <code>.srcjar</code> are unpacked and compiled. (This is useful if
you need to generate a set of <code>.java</code> files with a genrule.)
</p>
<p>
Rules: if the rule (typically <code>genrule</code> or <code>filegroup</code>) generates
any of the files listed above, they will be used the same way as described for source
files.
</p>
<p>
Source files of type <code>.properties</code> are treated as resources.
</p>

<p>All other files are ignored, as long as there is at least one file of a
file type described above. Otherwise an error is raised.</p>

<p>
This argument is almost always required, except if you specify the <code>runtime_deps</code> argument.
</p>
2[]
,
*
nameA unique name for this target. �
�
add_exports�
Allow this library to access the given <code>module</code> or <code>package</code>.
<p>
This corresponds to the javac and JVM --add-exports= flags.
2[]�
�
	add_opens�
Allow this library to reflectively access the given <code>module</code> or
<code>package</code>.
<p>
This corresponds to the javac and JVM --add-opens= flags.
2[]K
I
bootclasspathRestricted API, do not use!*
BootClassPathInfo2None�
�
data�
The list of files needed by this library at runtime.
See general comments about <code>data</code> at
<a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>
  When building a <code>java_library</code>, Bazel doesn't put these files anywhere; if the
  <code>data</code> files are generated files then Bazel generates them. When building a
  test that depends on this <code>java_library</code> Bazel copies or links the
  <code>data</code> files into the runfiles area.
</p>
2[]�
�
deps�
The list of libraries to link into this library.
See general comments about <code>deps</code> at
<a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>
  The jars built by <code>java_library</code> rules listed in <code>deps</code> will be on
  the compile-time classpath of this rule. Furthermore the transitive closure of their
  <code>deps</code>, <code>runtime_deps</code> and <code>exports</code> will be on the
  runtime classpath.
</p>
<p>
  By contrast, targets in the <code>data</code> attribute are included in the runfiles but
  on neither the compile-time nor runtime classpath.
</p>
*
CcInfo*

JavaInfo2[]�
�
exported_plugins�
The list of <code><a href="#${link java_plugin}">java_plugin</a></code>s (e.g. annotation
processors) to export to libraries that directly depend on this library.
<p>
  The specified list of <code>java_plugin</code>s will be applied to any library which
  directly depends on this library, just as if that library had explicitly declared these
  labels in <code><a href="${link java_library.plugins}">plugins</a></code>.
</p>
*
JavaPluginInfo2[]�
�
exports�
Exported libraries.
<p>
  Listing rules here will make them available to parent rules, as if the parents explicitly
  depended on these rules. This is not true for regular (non-exported) <code>deps</code>.
</p>
<p>
  Summary: a rule <i>X</i> can access the code in <i>Y</i> if there exists a dependency
  path between them that begins with a <code>deps</code> edge followed by zero or more
  <code>exports</code> edges. Let's see some examples to illustrate this.
</p>
<p>
  Assume <i>A</i> depends on <i>B</i> and <i>B</i> depends on <i>C</i>. In this case
  C is a <em>transitive</em> dependency of A, so changing C's sources and rebuilding A will
  correctly rebuild everything. However A will not be able to use classes in C. To allow
  that, either A has to declare C in its <code>deps</code>, or B can make it easier for A
  (and anything that may depend on A) by declaring C in its (B's) <code>exports</code>
  attribute.
</p>
<p>
  The closure of exported libraries is available to all direct parent rules. Take a slightly
  different example: A depends on B, B depends on C and D, and also exports C but not D.
  Now A has access to C but not to D. Now, if C and D exported some libraries, C' and D'
  respectively, A could only access C' but not D'.
</p>
<p>
  Important: an exported rule is not a regular dependency. Sticking to the previous example,
  if B exports C and wants to also use C, it has to also list it in its own
  <code>deps</code>.
</p>
*

JavaInfo*
CcInfo2[]<
:
javabuilder_jvm_flagsRestricted API, do not use!2[]�
�
	javacopts�
Extra compiler options for this library.
Subject to <a href="make-variables.html">"Make variable"</a> substitution and
<a href="common-definitions.html#sh-tokenization">Bourne shell tokenization</a>.
<p>These compiler options are passed to javac after the global compiler options.</p>
2[]

licenses2[]�
�
	neverlink�
Whether this library should only be used for compilation and not at runtime.
Useful if the library will be provided by the runtime environment during execution. Examples
of such libraries are the IDE APIs for IDE plug-ins or <code>tools.jar</code> for anything
running on a standard JDK.
<p>
  Note that <code>neverlink = True</code> does not prevent the compiler from inlining material
  from this library into compilation targets that depend on it, as permitted by the Java
  Language Specification (e.g., <code>static final</code> constants of <code>String</code>
  or of primitive types). The preferred use case is therefore when the runtime library is
  identical to the compilation library.
</p>
<p>
  If the runtime library differs from the compilation library then you must ensure that it
  differs only in places that the JLS forbids compilers to inline (and that must hold for
  all future versions of the JLS).
</p>
2False�
�
plugins�
Java compiler plugins to run at compile-time.
Every <code>java_plugin</code> specified in this attribute will be run whenever this rule
is built. A library may also inherit plugins from dependencies that use
<code><a href="#java_library.exported_plugins">exported_plugins</a></code>. Resources
generated by the plugin will be included in the resulting jar of this rule.
*
JavaPluginInfo2[]�
�
proguard_specs�
Files to be used as Proguard specification.
These will describe the set of specifications to be used by Proguard. If specified,
they will be added to any <code>android_binary</code> target depending on this library.

The files included here must only have idempotent rules, namely -dontnote, -dontwarn,
assumenosideeffects, and rules that start with -keep. Other options can only appear in
<code>android_binary</code>'s proguard_specs, to ensure non-tautological merges.
2[]�
�
resource_strip_prefix�
The path prefix to strip from Java resources.
<p>
If specified, this path prefix is stripped from every file in the <code>resources</code>
attribute. It is an error for a resource file not to be under this directory. If not
specified (the default), the path of resource file is determined according to the same
logic as the Java package of source files. For example, a source file at
<code>stuff/java/foo/bar/a.txt</code> will be located at <code>foo/bar/a.txt</code>.
</p>
2""�
�
	resources�
A list of data files to include in a Java jar.
<p>
Resources may be source files or generated files.
</p>

<p>
If resources are specified, they will be bundled in the jar along with the usual
<code>.class</code> files produced by compilation. The location of the resources inside
of the jar file is determined by the project structure. Bazel first looks for Maven's
<a href="https://maven.apache.org/guides/introduction/introduction-to-the-standard-directory-layout.html">standard directory layout</a>,
(a "src" directory followed by a "resources" directory grandchild). If that is not
found, Bazel then looks for the topmost directory named "java" or "javatests" (so, for
example, if a resource is at <code>&lt;workspace root&gt;/x/java/y/java/z</code>, the
path of the resource will be <code>y/java/z</code>. This heuristic cannot be overridden,
however, the <code>resource_strip_prefix</code> attribute can be used to specify a
specific alternative directory for resource files.
2[]�
�
runtime_deps�
Libraries to make available to the final binary or test at runtime only.
Like ordinary <code>deps</code>, these will appear on the runtime classpath, but unlike
them, not on the compile-time classpath. Dependencies needed only at runtime should be
listed here. Dependency-analysis tools should ignore targets that appear in both
<code>runtime_deps</code> and <code>deps</code>.
*
CcInfo*

JavaInfo2[]�

�

srcs�

The list of source files that are processed to create the target.
This attribute is almost always required; see exceptions below.
<p>
Source files of type <code>.java</code> are compiled. In case of generated
<code>.java</code> files it is generally advisable to put the generating rule's name
here instead of the name of the file itself. This not only improves readability but
makes the rule more resilient to future changes: if the generating rule generates
different files in the future, you only need to fix one place: the <code>outs</code> of
the generating rule. You should not list the generating rule in <code>deps</code>
because it is a no-op.
</p>
<p>
Source files of type <code>.srcjar</code> are unpacked and compiled. (This is useful if
you need to generate a set of <code>.java</code> files with a genrule.)
</p>
<p>
Rules: if the rule (typically <code>genrule</code> or <code>filegroup</code>) generates
any of the files listed above, they will be used the same way as described for source
files.
</p>
<p>
Source files of type <code>.properties</code> are treated as resources.
</p>

<p>All other files are ignored, as long as there is at least one file of a
file type described above. Otherwise an error is raised.</p>

<p>
This argument is almost always required, except if you specify the <code>runtime_deps</code> argument.
</p>
2[]}
//java:java_library.bzlr`
$

rules_javajavajava_library.bzl*
java_libraryjava_library
-9
;�
//jni/private:common.bzlrh
$
	rules_jnijni/private
common.bzl2
merge_java_infosmerge_java_infos
-=
?�
//jni/private:jni_headers.bzlrc
)
	rules_jnijni/privatejni_headers.bzl(
jni_headersjni_headers
2=
?�
)
	rules_jnijni/privatejni_headers.bzl�jni_headers�
Generates the native headers for a `java_library` and exposes it to `cc_*` rules.

For every Java class `com.example.Foo` in the `java_library` target specified by `lib` that contains at least one
function marked with `native` or constant annotated with `@Native`, the include directory exported by this rule will
contain a file `com_example_Foo.h` that provides the C/C++ interface for this class. Consuming `cc_*` rules should have
this rule added to their `deps` and can then access such a header file via:

```c
#include "com_example_Foo.h"
```

This rule also directly exports the JNI header, which can be included via:

```c
#include <jni.h>
```

*Example:*

```starlark
load("@fmeum_rules_jni//jni:defs.bzl", "jni_headers")

java_library(
    name = "os_utils",
    ...
)

jni_headers(
    name = "os_utils_hdrs",
    lib = ":os_utils",
)

cc_library(
    name = "os_utils_impl",
    ...
    deps = [":os_utils_hdrs"],
)
```
"�

�
jni_headers�
Generates the native headers for a `java_library` and exposes it to `cc_*` rules.

For every Java class `com.example.Foo` in the `java_library` target specified by `lib` that contains at least one
function marked with `native` or constant annotated with `@Native`, the include directory exported by this rule will
contain a file `com_example_Foo.h` that provides the C/C++ interface for this class. Consuming `cc_*` rules should have
this rule added to their `deps` and can then access such a header file via:

```c
#include "com_example_Foo.h"
```

This rule also directly exports the JNI header, which can be included via:

```c
#include <jni.h>
```

*Example:*

```starlark
load("@fmeum_rules_jni//jni:defs.bzl", "jni_headers")

java_library(
    name = "os_utils",
    ...
)

jni_headers(
    name = "os_utils_hdrs",
    lib = ":os_utils",
)

cc_library(
    name = "os_utils_impl",
    ...
    deps = [":os_utils_hdrs"],
)
```
*
nameA unique name for this target. Z
libCThe Java library for which native header files should be generated. *

JavaInfo"7
jni_headers(@@rules_jni//jni/private:jni_headers.bzl
KK,
*
nameA unique name for this target. \
Z
libCThe Java library for which native header files should be generated. *

JavaInfo�
//tools/cpp:toolchain_utils.bzlru
-
bazel_tools	tools/cpptoolchain_utils.bzl6
find_cpp_toolchainfind_cpp_toolchain
6H
Jy
//cc/common:cc_common.bzlrZ
$
rules_cc	cc/commoncc_common.bzl$
	cc_common	cc_common
-6
8o
//cc/common:cc_info.bzlrR
"
rules_cc	cc/commoncc_info.bzl
CcInfoCcInfo
+1
3}
//java/common:java_info.bzlr\
(

rules_javajava/commonjava_info.bzl"
JavaInfoJavaInfo
19
;�
//jni/private:transitions.bzlr�
)
	rules_jnijni/privatetransitions.bzln
.return_to_original_target_platforms_transition.return_to_original_target_platforms_transition
2`
b�
*
	rules_jnijni/privateos_cpu_utils.bzl(	SELECT_TARGET_OSfreebsdj	freebsdW	CPUSjM2K
	aarch64
arm
mips64
ppc
	riscv64
s390x
x86_32
x86_64J	OSESj@2>
	freebsd
linux
macos
	openbsd
	windows
	android)	SELECT_TARGET_CPUaarch64j	aarch64�
*
	rules_jnijni/privaterepositories.bzl_jdk_deps*Q
A
jdk_deps25
jdk_deps)@@rules_jni//jni/private:repositories.bzl
�	rules_jni_dependencies�Adds all external repositories required for rules_jni.

This should be called from a `WORKSPACE` file after the declaration of `fmeum_rules_jni` itself.

Currently, rules_jni depends on:

* [bazel_skylib](https://github.com/bazelbuild/bazel-skylib)
* [platforms](https://github.com/bazelbuild/platforms)
* [rules_license](https://github.com/bazelbuild/rules_license)
* individual files of the [OpenJDK](https://github.com/openjdk/jdk)

It also requires rules_cc 0.0.17 or later and rules_java 8.6.0 or later, which must be supplied by
the end user.*�
�
rules_jni_dependencies�Adds all external repositories required for rules_jni.

This should be called from a `WORKSPACE` file after the declaration of `fmeum_rules_jni` itself.

Currently, rules_jni depends on:

* [bazel_skylib](https://github.com/bazelbuild/bazel-skylib)
* [platforms](https://github.com/bazelbuild/platforms)
* [rules_license](https://github.com/bazelbuild/rules_license)
* individual files of the [OpenJDK](https://github.com/openjdk/jdk)

It also requires rules_cc 0.0.17 or later and rules_java 8.6.0 or later, which must be supplied by
the end user.2C
rules_jni_dependencies)@@rules_jni//jni/private:repositories.bzl
22�
 //tools/build_defs/repo:http.bzlr�
.
bazel_toolstools/build_defs/repohttp.bzl*
http_archivehttp_archive
7C$
	http_file	http_file
GP
R�
!//tools/build_defs/repo:utils.bzlr]
/
bazel_toolstools/build_defs/repo	utils.bzl
maybemaybe
8=
?+
)
	rules_jnijni/privatetransitions.bzl�#
$
	rules_jnijnicc_jni_library.bzl�!cc_jni_library�A native library that can be loaded by a Java application at runtime.

Add this target to the `native_libs` of a [`java_jni_library`](#java_jni_library).

The native libraries are exposed as Java resources, which are placed in a Java package determined from the Bazel
package of this target according to the
[Maven standard directory layout](https://maven.apache.org/guides/introduction/introduction-to-the-standard-directory-layout.html).
If the library should be included in the `com/example` subdirectory of a deploy JAR, which corresponds to the Java
package `com.example`, place it under one of the following Bazel package structures:
* `**/src/*/native/com/example` (preferred)
* `**/src/*/resources/com/example`
* `**/src/*/java/com/example`
* `**/java/com/example`

*Note:* Building a native library for multiple platforms by setting the `platforms` attribute to a non-empty list of
platforms requires either remote execution or cross-compilation toolchains for the target platforms. As both require
a more sophisticated Bazel setup, the following simpler process can be helpful for smaller or open-source projects:

1. Leave the `platforms` attribute empty or unspecified.
2. Build the deploy JAR of the Java library or application with all native libraries included separately for each
   target platform, for example using a CI platform.
3. Manually (outside Bazel) merge the deploy JARs. The `.class` files will be identical and can thus safely be
   replaced, but the resulting JAR will include all versions of the native library and the correct version will be
   loaded at runtime.

An example of such a CI workflow can be found [here](https://github.com/CodeIntelligenceTesting/jazzer/blob/d1835d6fa2ebfb7b2661cfaaa8acb8bbf42bb486/.github/workflows/release.yml).
*�
�
cc_jni_library*
nameA unique name for this target. (�
	platforms�A list of [`platform`s](https://docs.bazel.build/versions/main/be/platform.html#platform) for which
this native library should be built. If the list is empty (the default), the library is only built for the
current target platform.[](�
cc_binary_args�Any arguments to a
[`cc_library`](https://docs.bazel.build/versions/main/be/c-cpp.html#cc_library), except for:
`linkshared` (always `True`), `linkstatic` (always `True`), `data` (runfiles are not supported)(�A native library that can be loaded by a Java application at runtime.

Add this target to the `native_libs` of a [`java_jni_library`](#java_jni_library).

The native libraries are exposed as Java resources, which are placed in a Java package determined from the Bazel
package of this target according to the
[Maven standard directory layout](https://maven.apache.org/guides/introduction/introduction-to-the-standard-directory-layout.html).
If the library should be included in the `com/example` subdirectory of a deploy JAR, which corresponds to the Java
package `com.example`, place it under one of the following Bazel package structures:
* `**/src/*/native/com/example` (preferred)
* `**/src/*/resources/com/example`
* `**/src/*/java/com/example`
* `**/java/com/example`

*Note:* Building a native library for multiple platforms by setting the `platforms` attribute to a non-empty list of
platforms requires either remote execution or cross-compilation toolchains for the target platforms. As both require
a more sophisticated Bazel setup, the following simpler process can be helpful for smaller or open-source projects:

1. Leave the `platforms` attribute empty or unspecified.
2. Build the deploy JAR of the Java library or application with all native libraries included separately for each
   target platform, for example using a CI platform.
3. Manually (outside Bazel) merge the deploy JARs. The `.class` files will be identical and can thus safely be
   replaced, but the resulting JAR will include all versions of the native library and the correct version will be
   loaded at runtime.

An example of such a CI workflow can be found [here](https://github.com/CodeIntelligenceTesting/jazzer/blob/d1835d6fa2ebfb7b2661cfaaa8acb8bbf42bb486/.github/workflows/release.yml).
2=
cc_jni_library+@@rules_jni//jni/private:cc_jni_library.bzl
��"_single_platform_artifact"_multi_platform_artifact"java_library*	cc_binary*	cc_binary*	cc_binary2java_library�
 //jni/private:cc_jni_library.bzlrm
,
	rules_jnijni/privatecc_jni_library.bzl/
cc_jni_library_cc_jni_library
4C
W��

	rules_jnijnidefs.bzl�jni_headers�
Generates the native headers for a `java_library` and exposes it to `cc_*` rules.

For every Java class `com.example.Foo` in the `java_library` target specified by `lib` that contains at least one
function marked with `native` or constant annotated with `@Native`, the include directory exported by this rule will
contain a file `com_example_Foo.h` that provides the C/C++ interface for this class. Consuming `cc_*` rules should have
this rule added to their `deps` and can then access such a header file via:

```c
#include "com_example_Foo.h"
```

This rule also directly exports the JNI header, which can be included via:

```c
#include <jni.h>
```

*Example:*

```starlark
load("@fmeum_rules_jni//jni:defs.bzl", "jni_headers")

java_library(
    name = "os_utils",
    ...
)

jni_headers(
    name = "os_utils_hdrs",
    lib = ":os_utils",
)

cc_library(
    name = "os_utils_impl",
    ...
    deps = [":os_utils_hdrs"],
)
```
"�

�
jni_headers�
Generates the native headers for a `java_library` and exposes it to `cc_*` rules.

For every Java class `com.example.Foo` in the `java_library` target specified by `lib` that contains at least one
function marked with `native` or constant annotated with `@Native`, the include directory exported by this rule will
contain a file `com_example_Foo.h` that provides the C/C++ interface for this class. Consuming `cc_*` rules should have
this rule added to their `deps` and can then access such a header file via:

```c
#include "com_example_Foo.h"
```

This rule also directly exports the JNI header, which can be included via:

```c
#include <jni.h>
```

*Example:*

```starlark
load("@fmeum_rules_jni//jni:defs.bzl", "jni_headers")

java_library(
    name = "os_utils",
    ...
)

jni_headers(
    name = "os_utils_hdrs",
    lib = ":os_utils",
)

cc_library(
    name = "os_utils_impl",
    ...
    deps = [":os_utils_hdrs"],
)
```
*
nameA unique name for this target. Z
libCThe Java library for which native header files should be generated. *

JavaInfo"(
jni_headers@@rules_jni//jni:defs.bzl
KK,
*
nameA unique name for this target. \
Z
libCThe Java library for which native header files should be generated. *

JavaInfo��java_jni_library�A Java library that bundles one or more native libraries created with [`cc_jni_library`](#cc_jni_library).

To load a native library referenced in the `native_libs` argument, use the static methods of the
[`RulesJni`](https://fmeum.github.io/rules_jni_javadocs/com/github/fmeum/rules_jni/RulesJni.html) class, which is
accessible for `srcs` of this target due to an implicit dependency on
[`@fmeum_rules_jni//jni/tools/native_loader`](targets.md#native_loader). These methods automatically choose the
correct version of the library for the current OS and CPU architecture, if available.

The native libraries referenced in the `native_libs` argument are added as resources and are thus included in the
deploy JARs of any [`java_binary`](https://docs.bazel.build/versions/main/be/java.html#java_binary) depending on
this target.

### Implicit output targets

- `<name>.hdrs`: The auto-generated JNI headers for this library.

  This target can be added to the `deps` of a
  [`cc_library`](https://docs.bazel.build/versions/main/be/c-cpp.html#cc_library) or
  [`cc_jni_library`](#cc_jni_library). See [`jni_headers`](#jni_headers) for a more detailed description of the
  underlying rule.



<p>This rule compiles and links sources into a <code>.jar</code> file.</p>

<h4>Implicit outputs</h4>
<ul>
  <li><code>lib<var>name</var>.jar</code>: A Java archive containing the class files.</li>
  <li><code>lib<var>name</var>-src.jar</code>: An archive containing the sources ("source
    jar").</li>
</ul>
"��
�T
java_jni_library�A Java library that bundles one or more native libraries created with [`cc_jni_library`](#cc_jni_library).

To load a native library referenced in the `native_libs` argument, use the static methods of the
[`RulesJni`](https://fmeum.github.io/rules_jni_javadocs/com/github/fmeum/rules_jni/RulesJni.html) class, which is
accessible for `srcs` of this target due to an implicit dependency on
[`@fmeum_rules_jni//jni/tools/native_loader`](targets.md#native_loader). These methods automatically choose the
correct version of the library for the current OS and CPU architecture, if available.

The native libraries referenced in the `native_libs` argument are added as resources and are thus included in the
deploy JARs of any [`java_binary`](https://docs.bazel.build/versions/main/be/java.html#java_binary) depending on
this target.

### Implicit output targets

- `<name>.hdrs`: The auto-generated JNI headers for this library.

  This target can be added to the `deps` of a
  [`cc_library`](https://docs.bazel.build/versions/main/be/c-cpp.html#cc_library) or
  [`cc_jni_library`](#cc_jni_library). See [`jni_headers`](#jni_headers) for a more detailed description of the
  underlying rule.



<p>This rule compiles and links sources into a <code>.jar</code> file.</p>

<h4>Implicit outputs</h4>
<ul>
  <li><code>lib<var>name</var>.jar</code>: A Java archive containing the class files.</li>
  <li><code>lib<var>name</var>-src.jar</code>: An archive containing the sources ("source
    jar").</li>
</ul>
*
nameA unique name for this target. �
add_exports�
Allow this library to access the given <code>module</code> or <code>package</code>.
<p>
This corresponds to the javac and JVM --add-exports= flags.
2[]�
	add_opens�
Allow this library to reflectively access the given <code>module</code> or
<code>package</code>.
<p>
This corresponds to the javac and JVM --add-opens= flags.
2[]I
bootclasspathRestricted API, do not use!*
BootClassPathInfo2None�
data�
The list of files needed by this library at runtime.
See general comments about <code>data</code> at
<a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>
  When building a <code>java_library</code>, Bazel doesn't put these files anywhere; if the
  <code>data</code> files are generated files then Bazel generates them. When building a
  test that depends on this <code>java_library</code> Bazel copies or links the
  <code>data</code> files into the runfiles area.
</p>
2[]�
deps�
The list of libraries to link into this library.
See general comments about <code>deps</code> at
<a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>
  The jars built by <code>java_library</code> rules listed in <code>deps</code> will be on
  the compile-time classpath of this rule. Furthermore the transitive closure of their
  <code>deps</code>, <code>runtime_deps</code> and <code>exports</code> will be on the
  runtime classpath.
</p>
<p>
  By contrast, targets in the <code>data</code> attribute are included in the runfiles but
  on neither the compile-time nor runtime classpath.
</p>
*
CcInfo*

JavaInfo2[]�
exported_plugins�
The list of <code><a href="#${link java_plugin}">java_plugin</a></code>s (e.g. annotation
processors) to export to libraries that directly depend on this library.
<p>
  The specified list of <code>java_plugin</code>s will be applied to any library which
  directly depends on this library, just as if that library had explicitly declared these
  labels in <code><a href="${link java_library.plugins}">plugins</a></code>.
</p>
*
JavaPluginInfo2[]�
exports�
Exported libraries.
<p>
  Listing rules here will make them available to parent rules, as if the parents explicitly
  depended on these rules. This is not true for regular (non-exported) <code>deps</code>.
</p>
<p>
  Summary: a rule <i>X</i> can access the code in <i>Y</i> if there exists a dependency
  path between them that begins with a <code>deps</code> edge followed by zero or more
  <code>exports</code> edges. Let's see some examples to illustrate this.
</p>
<p>
  Assume <i>A</i> depends on <i>B</i> and <i>B</i> depends on <i>C</i>. In this case
  C is a <em>transitive</em> dependency of A, so changing C's sources and rebuilding A will
  correctly rebuild everything. However A will not be able to use classes in C. To allow
  that, either A has to declare C in its <code>deps</code>, or B can make it easier for A
  (and anything that may depend on A) by declaring C in its (B's) <code>exports</code>
  attribute.
</p>
<p>
  The closure of exported libraries is available to all direct parent rules. Take a slightly
  different example: A depends on B, B depends on C and D, and also exports C but not D.
  Now A has access to C but not to D. Now, if C and D exported some libraries, C' and D'
  respectively, A could only access C' but not D'.
</p>
<p>
  Important: an exported rule is not a regular dependency. Sticking to the previous example,
  if B exports C and wants to also use C, it has to also list it in its own
  <code>deps</code>.
</p>
*

JavaInfo*
CcInfo2[]:
javabuilder_jvm_flagsRestricted API, do not use!2[]�
	javacopts�
Extra compiler options for this library.
Subject to <a href="make-variables.html">"Make variable"</a> substitution and
<a href="common-definitions.html#sh-tokenization">Bourne shell tokenization</a>.
<p>These compiler options are passed to javac after the global compiler options.</p>
2[]
licenses2[]�
	neverlink�
Whether this library should only be used for compilation and not at runtime.
Useful if the library will be provided by the runtime environment during execution. Examples
of such libraries are the IDE APIs for IDE plug-ins or <code>tools.jar</code> for anything
running on a standard JDK.
<p>
  Note that <code>neverlink = True</code> does not prevent the compiler from inlining material
  from this library into compilation targets that depend on it, as permitted by the Java
  Language Specification (e.g., <code>static final</code> constants of <code>String</code>
  or of primitive types). The preferred use case is therefore when the runtime library is
  identical to the compilation library.
</p>
<p>
  If the runtime library differs from the compilation library then you must ensure that it
  differs only in places that the JLS forbids compilers to inline (and that must hold for
  all future versions of the JLS).
</p>
2False�
plugins�
Java compiler plugins to run at compile-time.
Every <code>java_plugin</code> specified in this attribute will be run whenever this rule
is built. A library may also inherit plugins from dependencies that use
<code><a href="#java_library.exported_plugins">exported_plugins</a></code>. Resources
generated by the plugin will be included in the resulting jar of this rule.
*
JavaPluginInfo2[]�
proguard_specs�
Files to be used as Proguard specification.
These will describe the set of specifications to be used by Proguard. If specified,
they will be added to any <code>android_binary</code> target depending on this library.

The files included here must only have idempotent rules, namely -dontnote, -dontwarn,
assumenosideeffects, and rules that start with -keep. Other options can only appear in
<code>android_binary</code>'s proguard_specs, to ensure non-tautological merges.
2[]�
resource_strip_prefix�
The path prefix to strip from Java resources.
<p>
If specified, this path prefix is stripped from every file in the <code>resources</code>
attribute. It is an error for a resource file not to be under this directory. If not
specified (the default), the path of resource file is determined according to the same
logic as the Java package of source files. For example, a source file at
<code>stuff/java/foo/bar/a.txt</code> will be located at <code>foo/bar/a.txt</code>.
</p>
2""�
	resources�
A list of data files to include in a Java jar.
<p>
Resources may be source files or generated files.
</p>

<p>
If resources are specified, they will be bundled in the jar along with the usual
<code>.class</code> files produced by compilation. The location of the resources inside
of the jar file is determined by the project structure. Bazel first looks for Maven's
<a href="https://maven.apache.org/guides/introduction/introduction-to-the-standard-directory-layout.html">standard directory layout</a>,
(a "src" directory followed by a "resources" directory grandchild). If that is not
found, Bazel then looks for the topmost directory named "java" or "javatests" (so, for
example, if a resource is at <code>&lt;workspace root&gt;/x/java/y/java/z</code>, the
path of the resource will be <code>y/java/z</code>. This heuristic cannot be overridden,
however, the <code>resource_strip_prefix</code> attribute can be used to specify a
specific alternative directory for resource files.
2[]�
runtime_deps�
Libraries to make available to the final binary or test at runtime only.
Like ordinary <code>deps</code>, these will appear on the runtime classpath, but unlike
them, not on the compile-time classpath. Dependencies needed only at runtime should be
listed here. Dependency-analysis tools should ignore targets that appear in both
<code>runtime_deps</code> and <code>deps</code>.
*
CcInfo*

JavaInfo2[]�

srcs�

The list of source files that are processed to create the target.
This attribute is almost always required; see exceptions below.
<p>
Source files of type <code>.java</code> are compiled. In case of generated
<code>.java</code> files it is generally advisable to put the generating rule's name
here instead of the name of the file itself. This not only improves readability but
makes the rule more resilient to future changes: if the generating rule generates
different files in the future, you only need to fix one place: the <code>outs</code> of
the generating rule. You should not list the generating rule in <code>deps</code>
because it is a no-op.
</p>
<p>
Source files of type <code>.srcjar</code> are unpacked and compiled. (This is useful if
you need to generate a set of <code>.java</code> files with a genrule.)
</p>
<p>
Rules: if the rule (typically <code>genrule</code> or <code>filegroup</code>) generates
any of the files listed above, they will be used the same way as described for source
files.
</p>
<p>
Source files of type <code>.properties</code> are treated as resources.
</p>

<p>All other files are ignored, as long as there is at least one file of a
file type described above. Otherwise an error is raised.</p>

<p>
This argument is almost always required, except if you specify the <code>runtime_deps</code> argument.
</p>
2[]
,
*
nameA unique name for this target. �
�
add_exports�
Allow this library to access the given <code>module</code> or <code>package</code>.
<p>
This corresponds to the javac and JVM --add-exports= flags.
2[]�
�
	add_opens�
Allow this library to reflectively access the given <code>module</code> or
<code>package</code>.
<p>
This corresponds to the javac and JVM --add-opens= flags.
2[]K
I
bootclasspathRestricted API, do not use!*
BootClassPathInfo2None�
�
data�
The list of files needed by this library at runtime.
See general comments about <code>data</code> at
<a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>
  When building a <code>java_library</code>, Bazel doesn't put these files anywhere; if the
  <code>data</code> files are generated files then Bazel generates them. When building a
  test that depends on this <code>java_library</code> Bazel copies or links the
  <code>data</code> files into the runfiles area.
</p>
2[]�
�
deps�
The list of libraries to link into this library.
See general comments about <code>deps</code> at
<a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>
  The jars built by <code>java_library</code> rules listed in <code>deps</code> will be on
  the compile-time classpath of this rule. Furthermore the transitive closure of their
  <code>deps</code>, <code>runtime_deps</code> and <code>exports</code> will be on the
  runtime classpath.
</p>
<p>
  By contrast, targets in the <code>data</code> attribute are included in the runfiles but
  on neither the compile-time nor runtime classpath.
</p>
*
CcInfo*

JavaInfo2[]�
�
exported_plugins�
The list of <code><a href="#${link java_plugin}">java_plugin</a></code>s (e.g. annotation
processors) to export to libraries that directly depend on this library.
<p>
  The specified list of <code>java_plugin</code>s will be applied to any library which
  directly depends on this library, just as if that library had explicitly declared these
  labels in <code><a href="${link java_library.plugins}">plugins</a></code>.
</p>
*
JavaPluginInfo2[]�
�
exports�
Exported libraries.
<p>
  Listing rules here will make them available to parent rules, as if the parents explicitly
  depended on these rules. This is not true for regular (non-exported) <code>deps</code>.
</p>
<p>
  Summary: a rule <i>X</i> can access the code in <i>Y</i> if there exists a dependency
  path between them that begins with a <code>deps</code> edge followed by zero or more
  <code>exports</code> edges. Let's see some examples to illustrate this.
</p>
<p>
  Assume <i>A</i> depends on <i>B</i> and <i>B</i> depends on <i>C</i>. In this case
  C is a <em>transitive</em> dependency of A, so changing C's sources and rebuilding A will
  correctly rebuild everything. However A will not be able to use classes in C. To allow
  that, either A has to declare C in its <code>deps</code>, or B can make it easier for A
  (and anything that may depend on A) by declaring C in its (B's) <code>exports</code>
  attribute.
</p>
<p>
  The closure of exported libraries is available to all direct parent rules. Take a slightly
  different example: A depends on B, B depends on C and D, and also exports C but not D.
  Now A has access to C but not to D. Now, if C and D exported some libraries, C' and D'
  respectively, A could only access C' but not D'.
</p>
<p>
  Important: an exported rule is not a regular dependency. Sticking to the previous example,
  if B exports C and wants to also use C, it has to also list it in its own
  <code>deps</code>.
</p>
*

JavaInfo*
CcInfo2[]<
:
javabuilder_jvm_flagsRestricted API, do not use!2[]�
�
	javacopts�
Extra compiler options for this library.
Subject to <a href="make-variables.html">"Make variable"</a> substitution and
<a href="common-definitions.html#sh-tokenization">Bourne shell tokenization</a>.
<p>These compiler options are passed to javac after the global compiler options.</p>
2[]

licenses2[]�
�
	neverlink�
Whether this library should only be used for compilation and not at runtime.
Useful if the library will be provided by the runtime environment during execution. Examples
of such libraries are the IDE APIs for IDE plug-ins or <code>tools.jar</code> for anything
running on a standard JDK.
<p>
  Note that <code>neverlink = True</code> does not prevent the compiler from inlining material
  from this library into compilation targets that depend on it, as permitted by the Java
  Language Specification (e.g., <code>static final</code> constants of <code>String</code>
  or of primitive types). The preferred use case is therefore when the runtime library is
  identical to the compilation library.
</p>
<p>
  If the runtime library differs from the compilation library then you must ensure that it
  differs only in places that the JLS forbids compilers to inline (and that must hold for
  all future versions of the JLS).
</p>
2False�
�
plugins�
Java compiler plugins to run at compile-time.
Every <code>java_plugin</code> specified in this attribute will be run whenever this rule
is built. A library may also inherit plugins from dependencies that use
<code><a href="#java_library.exported_plugins">exported_plugins</a></code>. Resources
generated by the plugin will be included in the resulting jar of this rule.
*
JavaPluginInfo2[]�
�
proguard_specs�
Files to be used as Proguard specification.
These will describe the set of specifications to be used by Proguard. If specified,
they will be added to any <code>android_binary</code> target depending on this library.

The files included here must only have idempotent rules, namely -dontnote, -dontwarn,
assumenosideeffects, and rules that start with -keep. Other options can only appear in
<code>android_binary</code>'s proguard_specs, to ensure non-tautological merges.
2[]�
�
resource_strip_prefix�
The path prefix to strip from Java resources.
<p>
If specified, this path prefix is stripped from every file in the <code>resources</code>
attribute. It is an error for a resource file not to be under this directory. If not
specified (the default), the path of resource file is determined according to the same
logic as the Java package of source files. For example, a source file at
<code>stuff/java/foo/bar/a.txt</code> will be located at <code>foo/bar/a.txt</code>.
</p>
2""�
�
	resources�
A list of data files to include in a Java jar.
<p>
Resources may be source files or generated files.
</p>

<p>
If resources are specified, they will be bundled in the jar along with the usual
<code>.class</code> files produced by compilation. The location of the resources inside
of the jar file is determined by the project structure. Bazel first looks for Maven's
<a href="https://maven.apache.org/guides/introduction/introduction-to-the-standard-directory-layout.html">standard directory layout</a>,
(a "src" directory followed by a "resources" directory grandchild). If that is not
found, Bazel then looks for the topmost directory named "java" or "javatests" (so, for
example, if a resource is at <code>&lt;workspace root&gt;/x/java/y/java/z</code>, the
path of the resource will be <code>y/java/z</code>. This heuristic cannot be overridden,
however, the <code>resource_strip_prefix</code> attribute can be used to specify a
specific alternative directory for resource files.
2[]�
�
runtime_deps�
Libraries to make available to the final binary or test at runtime only.
Like ordinary <code>deps</code>, these will appear on the runtime classpath, but unlike
them, not on the compile-time classpath. Dependencies needed only at runtime should be
listed here. Dependency-analysis tools should ignore targets that appear in both
<code>runtime_deps</code> and <code>deps</code>.
*
CcInfo*

JavaInfo2[]�

�

srcs�

The list of source files that are processed to create the target.
This attribute is almost always required; see exceptions below.
<p>
Source files of type <code>.java</code> are compiled. In case of generated
<code>.java</code> files it is generally advisable to put the generating rule's name
here instead of the name of the file itself. This not only improves readability but
makes the rule more resilient to future changes: if the generating rule generates
different files in the future, you only need to fix one place: the <code>outs</code> of
the generating rule. You should not list the generating rule in <code>deps</code>
because it is a no-op.
</p>
<p>
Source files of type <code>.srcjar</code> are unpacked and compiled. (This is useful if
you need to generate a set of <code>.java</code> files with a genrule.)
</p>
<p>
Rules: if the rule (typically <code>genrule</code> or <code>filegroup</code>) generates
any of the files listed above, they will be used the same way as described for source
files.
</p>
<p>
Source files of type <code>.properties</code> are treated as resources.
</p>

<p>All other files are ignored, as long as there is at least one file of a
file type described above. Otherwise an error is raised.</p>

<p>
This argument is almost always required, except if you specify the <code>runtime_deps</code> argument.
</p>
2[]�!cc_jni_library�A native library that can be loaded by a Java application at runtime.

Add this target to the `native_libs` of a [`java_jni_library`](#java_jni_library).

The native libraries are exposed as Java resources, which are placed in a Java package determined from the Bazel
package of this target according to the
[Maven standard directory layout](https://maven.apache.org/guides/introduction/introduction-to-the-standard-directory-layout.html).
If the library should be included in the `com/example` subdirectory of a deploy JAR, which corresponds to the Java
package `com.example`, place it under one of the following Bazel package structures:
* `**/src/*/native/com/example` (preferred)
* `**/src/*/resources/com/example`
* `**/src/*/java/com/example`
* `**/java/com/example`

*Note:* Building a native library for multiple platforms by setting the `platforms` attribute to a non-empty list of
platforms requires either remote execution or cross-compilation toolchains for the target platforms. As both require
a more sophisticated Bazel setup, the following simpler process can be helpful for smaller or open-source projects:

1. Leave the `platforms` attribute empty or unspecified.
2. Build the deploy JAR of the Java library or application with all native libraries included separately for each
   target platform, for example using a CI platform.
3. Manually (outside Bazel) merge the deploy JARs. The `.class` files will be identical and can thus safely be
   replaced, but the resulting JAR will include all versions of the native library and the correct version will be
   loaded at runtime.

An example of such a CI workflow can be found [here](https://github.com/CodeIntelligenceTesting/jazzer/blob/d1835d6fa2ebfb7b2661cfaaa8acb8bbf42bb486/.github/workflows/release.yml).
*�
�
cc_jni_library*
nameA unique name for this target. (�
	platforms�A list of [`platform`s](https://docs.bazel.build/versions/main/be/platform.html#platform) for which
this native library should be built. If the list is empty (the default), the library is only built for the
current target platform.[](�
cc_binary_args�Any arguments to a
[`cc_library`](https://docs.bazel.build/versions/main/be/c-cpp.html#cc_library), except for:
`linkshared` (always `True`), `linkstatic` (always `True`), `data` (runfiles are not supported)(�A native library that can be loaded by a Java application at runtime.

Add this target to the `native_libs` of a [`java_jni_library`](#java_jni_library).

The native libraries are exposed as Java resources, which are placed in a Java package determined from the Bazel
package of this target according to the
[Maven standard directory layout](https://maven.apache.org/guides/introduction/introduction-to-the-standard-directory-layout.html).
If the library should be included in the `com/example` subdirectory of a deploy JAR, which corresponds to the Java
package `com.example`, place it under one of the following Bazel package structures:
* `**/src/*/native/com/example` (preferred)
* `**/src/*/resources/com/example`
* `**/src/*/java/com/example`
* `**/java/com/example`

*Note:* Building a native library for multiple platforms by setting the `platforms` attribute to a non-empty list of
platforms requires either remote execution or cross-compilation toolchains for the target platforms. As both require
a more sophisticated Bazel setup, the following simpler process can be helpful for smaller or open-source projects:

1. Leave the `platforms` attribute empty or unspecified.
2. Build the deploy JAR of the Java library or application with all native libraries included separately for each
   target platform, for example using a CI platform.
3. Manually (outside Bazel) merge the deploy JARs. The `.class` files will be identical and can thus safely be
   replaced, but the resulting JAR will include all versions of the native library and the correct version will be
   loaded at runtime.

An example of such a CI workflow can be found [here](https://github.com/CodeIntelligenceTesting/jazzer/blob/d1835d6fa2ebfb7b2661cfaaa8acb8bbf42bb486/.github/workflows/release.yml).
2=
cc_jni_library+@@rules_jni//jni/private:cc_jni_library.bzl
��"_single_platform_artifact"_multi_platform_artifact"java_library*	cc_binary*	cc_binary*	cc_binary2java_library�
//jni:cc_jni_library.bzlre
$
	rules_jnijnicc_jni_library.bzl/
cc_jni_library_cc_jni_library
,;
O�
//jni:java_jni_library.bzlrk
&
	rules_jnijnijava_jni_library.bzl3
java_jni_library_java_jni_library
.?
Uw
//jni:jni_headers.bzlr\
!
	rules_jnijnijni_headers.bzl)
jni_headers_jni_headers
)5
FѪ
&
	rules_jnijnijava_jni_library.bzl��java_jni_library�A Java library that bundles one or more native libraries created with [`cc_jni_library`](#cc_jni_library).

To load a native library referenced in the `native_libs` argument, use the static methods of the
[`RulesJni`](https://fmeum.github.io/rules_jni_javadocs/com/github/fmeum/rules_jni/RulesJni.html) class, which is
accessible for `srcs` of this target due to an implicit dependency on
[`@fmeum_rules_jni//jni/tools/native_loader`](targets.md#native_loader). These methods automatically choose the
correct version of the library for the current OS and CPU architecture, if available.

The native libraries referenced in the `native_libs` argument are added as resources and are thus included in the
deploy JARs of any [`java_binary`](https://docs.bazel.build/versions/main/be/java.html#java_binary) depending on
this target.

### Implicit output targets

- `<name>.hdrs`: The auto-generated JNI headers for this library.

  This target can be added to the `deps` of a
  [`cc_library`](https://docs.bazel.build/versions/main/be/c-cpp.html#cc_library) or
  [`cc_jni_library`](#cc_jni_library). See [`jni_headers`](#jni_headers) for a more detailed description of the
  underlying rule.



<p>This rule compiles and links sources into a <code>.jar</code> file.</p>

<h4>Implicit outputs</h4>
<ul>
  <li><code>lib<var>name</var>.jar</code>: A Java archive containing the class files.</li>
  <li><code>lib<var>name</var>-src.jar</code>: An archive containing the sources ("source
    jar").</li>
</ul>
"��
�T
java_jni_library�A Java library that bundles one or more native libraries created with [`cc_jni_library`](#cc_jni_library).

To load a native library referenced in the `native_libs` argument, use the static methods of the
[`RulesJni`](https://fmeum.github.io/rules_jni_javadocs/com/github/fmeum/rules_jni/RulesJni.html) class, which is
accessible for `srcs` of this target due to an implicit dependency on
[`@fmeum_rules_jni//jni/tools/native_loader`](targets.md#native_loader). These methods automatically choose the
correct version of the library for the current OS and CPU architecture, if available.

The native libraries referenced in the `native_libs` argument are added as resources and are thus included in the
deploy JARs of any [`java_binary`](https://docs.bazel.build/versions/main/be/java.html#java_binary) depending on
this target.

### Implicit output targets

- `<name>.hdrs`: The auto-generated JNI headers for this library.

  This target can be added to the `deps` of a
  [`cc_library`](https://docs.bazel.build/versions/main/be/c-cpp.html#cc_library) or
  [`cc_jni_library`](#cc_jni_library). See [`jni_headers`](#jni_headers) for a more detailed description of the
  underlying rule.



<p>This rule compiles and links sources into a <code>.jar</code> file.</p>

<h4>Implicit outputs</h4>
<ul>
  <li><code>lib<var>name</var>.jar</code>: A Java archive containing the class files.</li>
  <li><code>lib<var>name</var>-src.jar</code>: An archive containing the sources ("source
    jar").</li>
</ul>
*
nameA unique name for this target. �
add_exports�
Allow this library to access the given <code>module</code> or <code>package</code>.
<p>
This corresponds to the javac and JVM --add-exports= flags.
2[]�
	add_opens�
Allow this library to reflectively access the given <code>module</code> or
<code>package</code>.
<p>
This corresponds to the javac and JVM --add-opens= flags.
2[]I
bootclasspathRestricted API, do not use!*
BootClassPathInfo2None�
data�
The list of files needed by this library at runtime.
See general comments about <code>data</code> at
<a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>
  When building a <code>java_library</code>, Bazel doesn't put these files anywhere; if the
  <code>data</code> files are generated files then Bazel generates them. When building a
  test that depends on this <code>java_library</code> Bazel copies or links the
  <code>data</code> files into the runfiles area.
</p>
2[]�
deps�
The list of libraries to link into this library.
See general comments about <code>deps</code> at
<a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>
  The jars built by <code>java_library</code> rules listed in <code>deps</code> will be on
  the compile-time classpath of this rule. Furthermore the transitive closure of their
  <code>deps</code>, <code>runtime_deps</code> and <code>exports</code> will be on the
  runtime classpath.
</p>
<p>
  By contrast, targets in the <code>data</code> attribute are included in the runfiles but
  on neither the compile-time nor runtime classpath.
</p>
*
CcInfo*

JavaInfo2[]�
exported_plugins�
The list of <code><a href="#${link java_plugin}">java_plugin</a></code>s (e.g. annotation
processors) to export to libraries that directly depend on this library.
<p>
  The specified list of <code>java_plugin</code>s will be applied to any library which
  directly depends on this library, just as if that library had explicitly declared these
  labels in <code><a href="${link java_library.plugins}">plugins</a></code>.
</p>
*
JavaPluginInfo2[]�
exports�
Exported libraries.
<p>
  Listing rules here will make them available to parent rules, as if the parents explicitly
  depended on these rules. This is not true for regular (non-exported) <code>deps</code>.
</p>
<p>
  Summary: a rule <i>X</i> can access the code in <i>Y</i> if there exists a dependency
  path between them that begins with a <code>deps</code> edge followed by zero or more
  <code>exports</code> edges. Let's see some examples to illustrate this.
</p>
<p>
  Assume <i>A</i> depends on <i>B</i> and <i>B</i> depends on <i>C</i>. In this case
  C is a <em>transitive</em> dependency of A, so changing C's sources and rebuilding A will
  correctly rebuild everything. However A will not be able to use classes in C. To allow
  that, either A has to declare C in its <code>deps</code>, or B can make it easier for A
  (and anything that may depend on A) by declaring C in its (B's) <code>exports</code>
  attribute.
</p>
<p>
  The closure of exported libraries is available to all direct parent rules. Take a slightly
  different example: A depends on B, B depends on C and D, and also exports C but not D.
  Now A has access to C but not to D. Now, if C and D exported some libraries, C' and D'
  respectively, A could only access C' but not D'.
</p>
<p>
  Important: an exported rule is not a regular dependency. Sticking to the previous example,
  if B exports C and wants to also use C, it has to also list it in its own
  <code>deps</code>.
</p>
*

JavaInfo*
CcInfo2[]:
javabuilder_jvm_flagsRestricted API, do not use!2[]�
	javacopts�
Extra compiler options for this library.
Subject to <a href="make-variables.html">"Make variable"</a> substitution and
<a href="common-definitions.html#sh-tokenization">Bourne shell tokenization</a>.
<p>These compiler options are passed to javac after the global compiler options.</p>
2[]
licenses2[]�
	neverlink�
Whether this library should only be used for compilation and not at runtime.
Useful if the library will be provided by the runtime environment during execution. Examples
of such libraries are the IDE APIs for IDE plug-ins or <code>tools.jar</code> for anything
running on a standard JDK.
<p>
  Note that <code>neverlink = True</code> does not prevent the compiler from inlining material
  from this library into compilation targets that depend on it, as permitted by the Java
  Language Specification (e.g., <code>static final</code> constants of <code>String</code>
  or of primitive types). The preferred use case is therefore when the runtime library is
  identical to the compilation library.
</p>
<p>
  If the runtime library differs from the compilation library then you must ensure that it
  differs only in places that the JLS forbids compilers to inline (and that must hold for
  all future versions of the JLS).
</p>
2False�
plugins�
Java compiler plugins to run at compile-time.
Every <code>java_plugin</code> specified in this attribute will be run whenever this rule
is built. A library may also inherit plugins from dependencies that use
<code><a href="#java_library.exported_plugins">exported_plugins</a></code>. Resources
generated by the plugin will be included in the resulting jar of this rule.
*
JavaPluginInfo2[]�
proguard_specs�
Files to be used as Proguard specification.
These will describe the set of specifications to be used by Proguard. If specified,
they will be added to any <code>android_binary</code> target depending on this library.

The files included here must only have idempotent rules, namely -dontnote, -dontwarn,
assumenosideeffects, and rules that start with -keep. Other options can only appear in
<code>android_binary</code>'s proguard_specs, to ensure non-tautological merges.
2[]�
resource_strip_prefix�
The path prefix to strip from Java resources.
<p>
If specified, this path prefix is stripped from every file in the <code>resources</code>
attribute. It is an error for a resource file not to be under this directory. If not
specified (the default), the path of resource file is determined according to the same
logic as the Java package of source files. For example, a source file at
<code>stuff/java/foo/bar/a.txt</code> will be located at <code>foo/bar/a.txt</code>.
</p>
2""�
	resources�
A list of data files to include in a Java jar.
<p>
Resources may be source files or generated files.
</p>

<p>
If resources are specified, they will be bundled in the jar along with the usual
<code>.class</code> files produced by compilation. The location of the resources inside
of the jar file is determined by the project structure. Bazel first looks for Maven's
<a href="https://maven.apache.org/guides/introduction/introduction-to-the-standard-directory-layout.html">standard directory layout</a>,
(a "src" directory followed by a "resources" directory grandchild). If that is not
found, Bazel then looks for the topmost directory named "java" or "javatests" (so, for
example, if a resource is at <code>&lt;workspace root&gt;/x/java/y/java/z</code>, the
path of the resource will be <code>y/java/z</code>. This heuristic cannot be overridden,
however, the <code>resource_strip_prefix</code> attribute can be used to specify a
specific alternative directory for resource files.
2[]�
runtime_deps�
Libraries to make available to the final binary or test at runtime only.
Like ordinary <code>deps</code>, these will appear on the runtime classpath, but unlike
them, not on the compile-time classpath. Dependencies needed only at runtime should be
listed here. Dependency-analysis tools should ignore targets that appear in both
<code>runtime_deps</code> and <code>deps</code>.
*
CcInfo*

JavaInfo2[]�

srcs�

The list of source files that are processed to create the target.
This attribute is almost always required; see exceptions below.
<p>
Source files of type <code>.java</code> are compiled. In case of generated
<code>.java</code> files it is generally advisable to put the generating rule's name
here instead of the name of the file itself. This not only improves readability but
makes the rule more resilient to future changes: if the generating rule generates
different files in the future, you only need to fix one place: the <code>outs</code> of
the generating rule. You should not list the generating rule in <code>deps</code>
because it is a no-op.
</p>
<p>
Source files of type <code>.srcjar</code> are unpacked and compiled. (This is useful if
you need to generate a set of <code>.java</code> files with a genrule.)
</p>
<p>
Rules: if the rule (typically <code>genrule</code> or <code>filegroup</code>) generates
any of the files listed above, they will be used the same way as described for source
files.
</p>
<p>
Source files of type <code>.properties</code> are treated as resources.
</p>

<p>All other files are ignored, as long as there is at least one file of a
file type described above. Otherwise an error is raised.</p>

<p>
This argument is almost always required, except if you specify the <code>runtime_deps</code> argument.
</p>
2[]
,
*
nameA unique name for this target. �
�
add_exports�
Allow this library to access the given <code>module</code> or <code>package</code>.
<p>
This corresponds to the javac and JVM --add-exports= flags.
2[]�
�
	add_opens�
Allow this library to reflectively access the given <code>module</code> or
<code>package</code>.
<p>
This corresponds to the javac and JVM --add-opens= flags.
2[]K
I
bootclasspathRestricted API, do not use!*
BootClassPathInfo2None�
�
data�
The list of files needed by this library at runtime.
See general comments about <code>data</code> at
<a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>
  When building a <code>java_library</code>, Bazel doesn't put these files anywhere; if the
  <code>data</code> files are generated files then Bazel generates them. When building a
  test that depends on this <code>java_library</code> Bazel copies or links the
  <code>data</code> files into the runfiles area.
</p>
2[]�
�
deps�
The list of libraries to link into this library.
See general comments about <code>deps</code> at
<a href="${link common-definitions#typical-attributes}">Typical attributes defined by
most build rules</a>.
<p>
  The jars built by <code>java_library</code> rules listed in <code>deps</code> will be on
  the compile-time classpath of this rule. Furthermore the transitive closure of their
  <code>deps</code>, <code>runtime_deps</code> and <code>exports</code> will be on the
  runtime classpath.
</p>
<p>
  By contrast, targets in the <code>data</code> attribute are included in the runfiles but
  on neither the compile-time nor runtime classpath.
</p>
*
CcInfo*

JavaInfo2[]�
�
exported_plugins�
The list of <code><a href="#${link java_plugin}">java_plugin</a></code>s (e.g. annotation
processors) to export to libraries that directly depend on this library.
<p>
  The specified list of <code>java_plugin</code>s will be applied to any library which
  directly depends on this library, just as if that library had explicitly declared these
  labels in <code><a href="${link java_library.plugins}">plugins</a></code>.
</p>
*
JavaPluginInfo2[]�
�
exports�
Exported libraries.
<p>
  Listing rules here will make them available to parent rules, as if the parents explicitly
  depended on these rules. This is not true for regular (non-exported) <code>deps</code>.
</p>
<p>
  Summary: a rule <i>X</i> can access the code in <i>Y</i> if there exists a dependency
  path between them that begins with a <code>deps</code> edge followed by zero or more
  <code>exports</code> edges. Let's see some examples to illustrate this.
</p>
<p>
  Assume <i>A</i> depends on <i>B</i> and <i>B</i> depends on <i>C</i>. In this case
  C is a <em>transitive</em> dependency of A, so changing C's sources and rebuilding A will
  correctly rebuild everything. However A will not be able to use classes in C. To allow
  that, either A has to declare C in its <code>deps</code>, or B can make it easier for A
  (and anything that may depend on A) by declaring C in its (B's) <code>exports</code>
  attribute.
</p>
<p>
  The closure of exported libraries is available to all direct parent rules. Take a slightly
  different example: A depends on B, B depends on C and D, and also exports C but not D.
  Now A has access to C but not to D. Now, if C and D exported some libraries, C' and D'
  respectively, A could only access C' but not D'.
</p>
<p>
  Important: an exported rule is not a regular dependency. Sticking to the previous example,
  if B exports C and wants to also use C, it has to also list it in its own
  <code>deps</code>.
</p>
*

JavaInfo*
CcInfo2[]<
:
javabuilder_jvm_flagsRestricted API, do not use!2[]�
�
	javacopts�
Extra compiler options for this library.
Subject to <a href="make-variables.html">"Make variable"</a> substitution and
<a href="common-definitions.html#sh-tokenization">Bourne shell tokenization</a>.
<p>These compiler options are passed to javac after the global compiler options.</p>
2[]

licenses2[]�
�
	neverlink�
Whether this library should only be used for compilation and not at runtime.
Useful if the library will be provided by the runtime environment during execution. Examples
of such libraries are the IDE APIs for IDE plug-ins or <code>tools.jar</code> for anything
running on a standard JDK.
<p>
  Note that <code>neverlink = True</code> does not prevent the compiler from inlining material
  from this library into compilation targets that depend on it, as permitted by the Java
  Language Specification (e.g., <code>static final</code> constants of <code>String</code>
  or of primitive types). The preferred use case is therefore when the runtime library is
  identical to the compilation library.
</p>
<p>
  If the runtime library differs from the compilation library then you must ensure that it
  differs only in places that the JLS forbids compilers to inline (and that must hold for
  all future versions of the JLS).
</p>
2False�
�
plugins�
Java compiler plugins to run at compile-time.
Every <code>java_plugin</code> specified in this attribute will be run whenever this rule
is built. A library may also inherit plugins from dependencies that use
<code><a href="#java_library.exported_plugins">exported_plugins</a></code>. Resources
generated by the plugin will be included in the resulting jar of this rule.
*
JavaPluginInfo2[]�
�
proguard_specs�
Files to be used as Proguard specification.
These will describe the set of specifications to be used by Proguard. If specified,
they will be added to any <code>android_binary</code> target depending on this library.

The files included here must only have idempotent rules, namely -dontnote, -dontwarn,
assumenosideeffects, and rules that start with -keep. Other options can only appear in
<code>android_binary</code>'s proguard_specs, to ensure non-tautological merges.
2[]�
�
resource_strip_prefix�
The path prefix to strip from Java resources.
<p>
If specified, this path prefix is stripped from every file in the <code>resources</code>
attribute. It is an error for a resource file not to be under this directory. If not
specified (the default), the path of resource file is determined according to the same
logic as the Java package of source files. For example, a source file at
<code>stuff/java/foo/bar/a.txt</code> will be located at <code>foo/bar/a.txt</code>.
</p>
2""�
�
	resources�
A list of data files to include in a Java jar.
<p>
Resources may be source files or generated files.
</p>

<p>
If resources are specified, they will be bundled in the jar along with the usual
<code>.class</code> files produced by compilation. The location of the resources inside
of the jar file is determined by the project structure. Bazel first looks for Maven's
<a href="https://maven.apache.org/guides/introduction/introduction-to-the-standard-directory-layout.html">standard directory layout</a>,
(a "src" directory followed by a "resources" directory grandchild). If that is not
found, Bazel then looks for the topmost directory named "java" or "javatests" (so, for
example, if a resource is at <code>&lt;workspace root&gt;/x/java/y/java/z</code>, the
path of the resource will be <code>y/java/z</code>. This heuristic cannot be overridden,
however, the <code>resource_strip_prefix</code> attribute can be used to specify a
specific alternative directory for resource files.
2[]�
�
runtime_deps�
Libraries to make available to the final binary or test at runtime only.
Like ordinary <code>deps</code>, these will appear on the runtime classpath, but unlike
them, not on the compile-time classpath. Dependencies needed only at runtime should be
listed here. Dependency-analysis tools should ignore targets that appear in both
<code>runtime_deps</code> and <code>deps</code>.
*
CcInfo*

JavaInfo2[]�

�

srcs�

The list of source files that are processed to create the target.
This attribute is almost always required; see exceptions below.
<p>
Source files of type <code>.java</code> are compiled. In case of generated
<code>.java</code> files it is generally advisable to put the generating rule's name
here instead of the name of the file itself. This not only improves readability but
makes the rule more resilient to future changes: if the generating rule generates
different files in the future, you only need to fix one place: the <code>outs</code> of
the generating rule. You should not list the generating rule in <code>deps</code>
because it is a no-op.
</p>
<p>
Source files of type <code>.srcjar</code> are unpacked and compiled. (This is useful if
you need to generate a set of <code>.java</code> files with a genrule.)
</p>
<p>
Rules: if the rule (typically <code>genrule</code> or <code>filegroup</code>) generates
any of the files listed above, they will be used the same way as described for source
files.
</p>
<p>
Source files of type <code>.properties</code> are treated as resources.
</p>

<p>All other files are ignored, as long as there is at least one file of a
file type described above. Otherwise an error is raised.</p>

<p>
This argument is almost always required, except if you specify the <code>runtime_deps</code> argument.
</p>
2[]�
"//jni/private:java_jni_library.bzlrs
.
	rules_jnijni/privatejava_jni_library.bzl3
java_jni_library_java_jni_library
6G
]�
!
	rules_jnijnijni_headers.bzl�jni_headers�
Generates the native headers for a `java_library` and exposes it to `cc_*` rules.

For every Java class `com.example.Foo` in the `java_library` target specified by `lib` that contains at least one
function marked with `native` or constant annotated with `@Native`, the include directory exported by this rule will
contain a file `com_example_Foo.h` that provides the C/C++ interface for this class. Consuming `cc_*` rules should have
this rule added to their `deps` and can then access such a header file via:

```c
#include "com_example_Foo.h"
```

This rule also directly exports the JNI header, which can be included via:

```c
#include <jni.h>
```

*Example:*

```starlark
load("@fmeum_rules_jni//jni:defs.bzl", "jni_headers")

java_library(
    name = "os_utils",
    ...
)

jni_headers(
    name = "os_utils_hdrs",
    lib = ":os_utils",
)

cc_library(
    name = "os_utils_impl",
    ...
    deps = [":os_utils_hdrs"],
)
```
"�

�
jni_headers�
Generates the native headers for a `java_library` and exposes it to `cc_*` rules.

For every Java class `com.example.Foo` in the `java_library` target specified by `lib` that contains at least one
function marked with `native` or constant annotated with `@Native`, the include directory exported by this rule will
contain a file `com_example_Foo.h` that provides the C/C++ interface for this class. Consuming `cc_*` rules should have
this rule added to their `deps` and can then access such a header file via:

```c
#include "com_example_Foo.h"
```

This rule also directly exports the JNI header, which can be included via:

```c
#include <jni.h>
```

*Example:*

```starlark
load("@fmeum_rules_jni//jni:defs.bzl", "jni_headers")

java_library(
    name = "os_utils",
    ...
)

jni_headers(
    name = "os_utils_hdrs",
    lib = ":os_utils",
)

cc_library(
    name = "os_utils_impl",
    ...
    deps = [":os_utils_hdrs"],
)
```
*
nameA unique name for this target. Z
libCThe Java library for which native header files should be generated. *

JavaInfo"/
jni_headers @@rules_jni//jni:jni_headers.bzl
KK,
*
nameA unique name for this target. \
Z
libCThe Java library for which native header files should be generated. *

JavaInfo�
//jni/private:jni_headers.bzlrd
)
	rules_jnijni/privatejni_headers.bzl)
jni_headers_jni_headers
1=
N�
"
	rules_jnijnirepositories.bzl�	rules_jni_dependencies�Adds all external repositories required for rules_jni.

This should be called from a `WORKSPACE` file after the declaration of `fmeum_rules_jni` itself.

Currently, rules_jni depends on:

* [bazel_skylib](https://github.com/bazelbuild/bazel-skylib)
* [platforms](https://github.com/bazelbuild/platforms)
* [rules_license](https://github.com/bazelbuild/rules_license)
* individual files of the [OpenJDK](https://github.com/openjdk/jdk)

It also requires rules_cc 0.0.17 or later and rules_java 8.6.0 or later, which must be supplied by
the end user.*�
�
rules_jni_dependencies�Adds all external repositories required for rules_jni.

This should be called from a `WORKSPACE` file after the declaration of `fmeum_rules_jni` itself.

Currently, rules_jni depends on:

* [bazel_skylib](https://github.com/bazelbuild/bazel-skylib)
* [platforms](https://github.com/bazelbuild/platforms)
* [rules_license](https://github.com/bazelbuild/rules_license)
* individual files of the [OpenJDK](https://github.com/openjdk/jdk)

It also requires rules_cc 0.0.17 or later and rules_java 8.6.0 or later, which must be supplied by
the end user.2C
rules_jni_dependencies)@@rules_jni//jni/private:repositories.bzl
22�
//jni/private:repositories.bzlr{
*
	rules_jnijni/privaterepositories.bzl?
rules_jni_dependencies_rules_jni_dependencies
2I
e 