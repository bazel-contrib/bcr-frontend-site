��
%
rules_jsonnetjsonnetjsonnet.bzl�jsonnet_library�Creates a logical set of Jsonnet files.

Example:
  Suppose you have the following directory structure:

  ```
  [workspace]/
      MODULE.bazel
      configs/
          BUILD
          backend.jsonnet
          frontend.jsonnet
  ```

  You can use the `jsonnet_library` rule to build a collection of `.jsonnet`
  files that can be imported by other `.jsonnet` files as dependencies:

  `configs/BUILD`:

  ```python
  load("@rules_jsonnet//jsonnet:jsonnet.bzl", "jsonnet_library")

  jsonnet_library(
      name = "configs",
      srcs = [
          "backend.jsonnet",
          "frontend.jsonnet",
      ],
  )
  ```
"�

�
jsonnet_library�Creates a logical set of Jsonnet files.

Example:
  Suppose you have the following directory structure:

  ```
  [workspace]/
      MODULE.bazel
      configs/
          BUILD
          backend.jsonnet
          frontend.jsonnet
  ```

  You can use the `jsonnet_library` rule to build a collection of `.jsonnet`
  files that can be imported by other `.jsonnet` files as dependencies:

  `configs/BUILD`:

  ```python
  load("@rules_jsonnet//jsonnet:jsonnet.bzl", "jsonnet_library")

  jsonnet_library(
      name = "configs",
      srcs = [
          "backend.jsonnet",
          "frontend.jsonnet",
      ],
  )
  ```
*
nameA unique name for this target. 
data2[]b
deps>List of targets that are required by the `srcs` Jsonnet files.*
JsonnetLibraryInfo2[]R
importsAList of import `-J` flags to be passed to the `jsonnet` compiler.2[]J
srcs<List of `.jsonnet` files that comprises this Jsonnet library2[]"7
jsonnet_library$@@rules_jsonnet//jsonnet:jsonnet.bzl
��,
*
nameA unique name for this target. 

data2[]d
b
deps>List of targets that are required by the `srcs` Jsonnet files.*
JsonnetLibraryInfo2[]T
R
importsAList of import `-J` flags to be passed to the `jsonnet` compiler.2[]L
J
srcs<List of `.jsonnet` files that comprises this Jsonnet library2[]�Pjsonnet_to_json�Compiles Jsonnet code to JSON.

Example:
  ### Example

  Suppose you have the following directory structure:

  ```
  [workspace]/
      MODULE.bazel
      workflows/
          BUILD
          workflow.libsonnet
          wordcount.jsonnet
          intersection.jsonnet
  ```

  Say that `workflow.libsonnet` is a base configuration library for a workflow
  scheduling system and `wordcount.jsonnet` and `intersection.jsonnet` both
  import `workflow.libsonnet` to define workflows for performing a wordcount and
  intersection of two files, respectively.

  First, create a `jsonnet_library` target with `workflow.libsonnet`:

  `workflows/BUILD`:

  ```python
  load("@rules_jsonnet//jsonnet:jsonnet.bzl", "jsonnet_library")

  jsonnet_library(
      name = "workflow",
      srcs = ["workflow.libsonnet"],
  )
  ```

  To compile `wordcount.jsonnet` and `intersection.jsonnet` to JSON, define two
  `jsonnet_to_json` targets:

  ```python
  jsonnet_to_json(
      name = "wordcount",
      src = "wordcount.jsonnet",
      outs = ["wordcount.json"],
      deps = [":workflow"],
  )

  jsonnet_to_json(
      name = "intersection",
      src = "intersection.jsonnet",
      outs = ["intersection.json"],
      deps = [":workflow"],
  )
  ```

  ### Example: Multiple output files

  To use Jsonnet's [multiple output files][multiple-output-files], suppose you
  add a file `shell-workflows.jsonnet` that imports `wordcount.jsonnet` and
  `intersection.jsonnet`:

  `workflows/shell-workflows.jsonnet`:

  ```
  local wordcount = import "workflows/wordcount.jsonnet";
  local intersection = import "workflows/intersection.jsonnet";

  {
    "wordcount-workflow.json": wordcount,
    "intersection-workflow.json": intersection,
  }
  ```

  To compile `shell-workflows.jsonnet` into the two JSON files,
  `wordcount-workflow.json` and `intersection-workflow.json`, first create a
  `jsonnet_library` target containing the two files that
  `shell-workflows.jsonnet` depends on:

  ```python
  jsonnet_library(
      name = "shell-workflows-lib",
      srcs = [
          "wordcount.jsonnet",
          "intersection.jsonnet",
      ],
      deps = [":workflow"],
  )
  ```

  Then, create a `jsonnet_to_json` target and set `outs` to the list of output
  files to indicate that multiple output JSON files are generated:

  ```python
  jsonnet_to_json(
      name = "shell-workflows",
      src = "shell-workflows.jsonnet",
      deps = [":shell-workflows-lib"],
      outs = [
          "wordcount-workflow.json",
          "intersection-workflow.json",
      ],
  )
  ```

  [multiple-output-files]: https://jsonnet.org/learning/getting_started.html#multi
"�;
�(
jsonnet_to_json�Compiles Jsonnet code to JSON.

Example:
  ### Example

  Suppose you have the following directory structure:

  ```
  [workspace]/
      MODULE.bazel
      workflows/
          BUILD
          workflow.libsonnet
          wordcount.jsonnet
          intersection.jsonnet
  ```

  Say that `workflow.libsonnet` is a base configuration library for a workflow
  scheduling system and `wordcount.jsonnet` and `intersection.jsonnet` both
  import `workflow.libsonnet` to define workflows for performing a wordcount and
  intersection of two files, respectively.

  First, create a `jsonnet_library` target with `workflow.libsonnet`:

  `workflows/BUILD`:

  ```python
  load("@rules_jsonnet//jsonnet:jsonnet.bzl", "jsonnet_library")

  jsonnet_library(
      name = "workflow",
      srcs = ["workflow.libsonnet"],
  )
  ```

  To compile `wordcount.jsonnet` and `intersection.jsonnet` to JSON, define two
  `jsonnet_to_json` targets:

  ```python
  jsonnet_to_json(
      name = "wordcount",
      src = "wordcount.jsonnet",
      outs = ["wordcount.json"],
      deps = [":workflow"],
  )

  jsonnet_to_json(
      name = "intersection",
      src = "intersection.jsonnet",
      outs = ["intersection.json"],
      deps = [":workflow"],
  )
  ```

  ### Example: Multiple output files

  To use Jsonnet's [multiple output files][multiple-output-files], suppose you
  add a file `shell-workflows.jsonnet` that imports `wordcount.jsonnet` and
  `intersection.jsonnet`:

  `workflows/shell-workflows.jsonnet`:

  ```
  local wordcount = import "workflows/wordcount.jsonnet";
  local intersection = import "workflows/intersection.jsonnet";

  {
    "wordcount-workflow.json": wordcount,
    "intersection-workflow.json": intersection,
  }
  ```

  To compile `shell-workflows.jsonnet` into the two JSON files,
  `wordcount-workflow.json` and `intersection-workflow.json`, first create a
  `jsonnet_library` target containing the two files that
  `shell-workflows.jsonnet` depends on:

  ```python
  jsonnet_library(
      name = "shell-workflows-lib",
      srcs = [
          "wordcount.jsonnet",
          "intersection.jsonnet",
      ],
      deps = [":workflow"],
  )
  ```

  Then, create a `jsonnet_to_json` target and set `outs` to the list of output
  files to indicate that multiple output JSON files are generated:

  ```python
  jsonnet_to_json(
      name = "shell-workflows",
      src = "shell-workflows.jsonnet",
      deps = [":shell-workflows-lib"],
      outs = [
          "wordcount-workflow.json",
          "intersection-workflow.json",
      ],
  )
  ```

  [multiple-output-files]: https://jsonnet.org/learning/getting_started.html#multi
*
nameA unique name for this target. /
	code_varsDeprecated (use 'ext_code').
2{}
data2[]b
deps>List of targets that are required by the `srcs` Jsonnet files.*
JsonnetLibraryInfo2[]
ext_code
2{}
ext_code_envs2[]
ext_code_file_vars2[]
ext_code_files2[]
ext_str_envs2[]
ext_str_file_vars2[]
ext_str_files2[]
ext_strs
2{}�

extra_args�Additional command line arguments for the Jsonnet interpreter.

For example, setting this argument to `["--string"]` causes the interpreter to
manifest the output file(s) as plain text instead of JSON.
2[]R
importsAList of import `-J` flags to be passed to the `jsonnet` compiler.2[]�
multiple_outputs�Set to `True` to explicitly enable multiple file output via the `jsonnet -m` flag.

This is used for the case where multiple file output is used but only for
generating a single output file. For example:

```
local foo = import "foo.jsonnet";

{
    "foo.json": foo,
}
```

This attribute is incompatible with `out_dir`.
2False�
out_dir�Name of the directory where output files are stored.

If the names of output files are not known up front, this option can be
used to write all output files to a single directory artifact. Files in
this directory cannot be referenced individually.

This attribute is incompatible with `outs` and `multiple_outputs`.
2""�
outs�Names of the output `.json` files to be generated by this rule.

If you are generating only a single JSON file and are not using jsonnet
multiple output files, then this attribute should only contain the file
name of the JSON file you are generating.

If you are generating multiple JSON files using jsonnet multiple file output
(`jsonnet -m`), then list the file names of all the JSON files to be
generated. The file names specified here must match the file names
specified in your `src` Jsonnet file.

For the case where multiple file output is used but only for generating one
output file, set the `multiple_outputs` attribute to 1 to explicitly enable
the `-m` flag for multiple file output.

This attribute is incompatible with `out_dir`.
6
src'The `.jsonnet` file to convert to JSON.2None

stamp_keys2[]
tla_code
2{}
tla_code_envs2[]
tla_code_files	2{}
tla_str_envs2[]
tla_str_files	2{}
tla_strs
2{}*
varsDeprecated (use 'ext_strs').
2{}
yaml_stream2False"7
jsonnet_to_json$@@rules_jsonnet//jsonnet:jsonnet.bzl
��,
*
nameA unique name for this target. 1
/
	code_varsDeprecated (use 'ext_code').
2{}

data2[]d
b
deps>List of targets that are required by the `srcs` Jsonnet files.*
JsonnetLibraryInfo2[]

ext_code
2{}

ext_code_envs2[]

ext_code_file_vars2[]

ext_code_files2[]

ext_str_envs2[]

ext_str_file_vars2[]

ext_str_files2[]

ext_strs
2{}�
�

extra_args�Additional command line arguments for the Jsonnet interpreter.

For example, setting this argument to `["--string"]` causes the interpreter to
manifest the output file(s) as plain text instead of JSON.
2[]T
R
importsAList of import `-J` flags to be passed to the `jsonnet` compiler.2[]�
�
multiple_outputs�Set to `True` to explicitly enable multiple file output via the `jsonnet -m` flag.

This is used for the case where multiple file output is used but only for
generating a single output file. For example:

```
local foo = import "foo.jsonnet";

{
    "foo.json": foo,
}
```

This attribute is incompatible with `out_dir`.
2False�
�
out_dir�Name of the directory where output files are stored.

If the names of output files are not known up front, this option can be
used to write all output files to a single directory artifact. Files in
this directory cannot be referenced individually.

This attribute is incompatible with `outs` and `multiple_outputs`.
2""�
�
outs�Names of the output `.json` files to be generated by this rule.

If you are generating only a single JSON file and are not using jsonnet
multiple output files, then this attribute should only contain the file
name of the JSON file you are generating.

If you are generating multiple JSON files using jsonnet multiple file output
(`jsonnet -m`), then list the file names of all the JSON files to be
generated. The file names specified here must match the file names
specified in your `src` Jsonnet file.

For the case where multiple file output is used but only for generating one
output file, set the `multiple_outputs` attribute to 1 to explicitly enable
the `-m` flag for multiple file output.

This attribute is incompatible with `out_dir`.
8
6
src'The `.jsonnet` file to convert to JSON.2None


stamp_keys2[]

tla_code
2{}

tla_code_envs2[]

tla_code_files	2{}

tla_str_envs2[]

tla_str_files	2{}

tla_strs
2{},
*
varsDeprecated (use 'ext_strs').
2{}

yaml_stream2False�?jsonnet_to_json_test�Compiles Jsonnet code to JSON and checks the output.

Example:
  Suppose you have the following directory structure:

  ```
  [workspace]/
      MODULE.bazel
      config/
          BUILD
          base_config.libsonnet
          test_config.jsonnet
          test_config.json
  ```

  Suppose that `base_config.libsonnet` is a library Jsonnet file, containing the
  base configuration for a service. Suppose that `test_config.jsonnet` is a test
  configuration file that is used to test `base_config.jsonnet`, and
  `test_config.json` is the expected JSON output from compiling
  `test_config.jsonnet`.

  The `jsonnet_to_json_test` rule can be used to verify that compiling a Jsonnet
  file produces the expected JSON output. Simply define a `jsonnet_to_json_test`
  target and provide the input test Jsonnet file and the `golden` file containing
  the expected JSON output:

  `config/BUILD`:

  ```python
  load(
      "@rules_jsonnet//jsonnet:jsonnet.bzl",
      "jsonnet_library",
      "jsonnet_to_json_test",
  )

  jsonnet_library(
      name = "base_config",
      srcs = ["base_config.libsonnet"],
  )

  jsonnet_to_json_test(
      name = "test_config_test",
      src = "test_config",
      deps = [":base_config"],
      golden = "test_config.json",
  )
  ```

  To run the test: `bazel test //config:test_config_test`

  ### Example: Negative tests

  Suppose you have the following directory structure:

  ```
  [workspace]/
      MODULE.bazel
      config/
          BUILD
          base_config.libsonnet
          invalid_config.jsonnet
          invalid_config.output
  ```

  Suppose that `invalid_config.jsonnet` is a Jsonnet file used to verify that
  an invalid config triggers an assertion in `base_config.jsonnet`, and
  `invalid_config.output` is the expected error output.

  The `jsonnet_to_json_test` rule can be used to verify that compiling a Jsonnet
  file results in an expected error code and error output. Simply define a
  `jsonnet_to_json_test` target and provide the input test Jsonnet file, the
  expected error code in the `error` attribute, and the `golden` file containing
  the expected error output:

  `config/BUILD`:

  ```python
  load(
      "@rules_jsonnet//jsonnet:jsonnet.bzl",
      "jsonnet_library",
      "jsonnet_to_json_test",
  )

  jsonnet_library(
      name = "base_config",
      srcs = ["base_config.libsonnet"],
  )

  jsonnet_to_json_test(
      name = "invalid_config_test",
      src = "invalid_config",
      deps = [":base_config"],
      golden = "invalid_config.output",
      error = 1,
  )
  ```

  To run the test: `bazel test //config:invalid_config_test`
"�*
�
jsonnet_to_json_test�Compiles Jsonnet code to JSON and checks the output.

Example:
  Suppose you have the following directory structure:

  ```
  [workspace]/
      MODULE.bazel
      config/
          BUILD
          base_config.libsonnet
          test_config.jsonnet
          test_config.json
  ```

  Suppose that `base_config.libsonnet` is a library Jsonnet file, containing the
  base configuration for a service. Suppose that `test_config.jsonnet` is a test
  configuration file that is used to test `base_config.jsonnet`, and
  `test_config.json` is the expected JSON output from compiling
  `test_config.jsonnet`.

  The `jsonnet_to_json_test` rule can be used to verify that compiling a Jsonnet
  file produces the expected JSON output. Simply define a `jsonnet_to_json_test`
  target and provide the input test Jsonnet file and the `golden` file containing
  the expected JSON output:

  `config/BUILD`:

  ```python
  load(
      "@rules_jsonnet//jsonnet:jsonnet.bzl",
      "jsonnet_library",
      "jsonnet_to_json_test",
  )

  jsonnet_library(
      name = "base_config",
      srcs = ["base_config.libsonnet"],
  )

  jsonnet_to_json_test(
      name = "test_config_test",
      src = "test_config",
      deps = [":base_config"],
      golden = "test_config.json",
  )
  ```

  To run the test: `bazel test //config:test_config_test`

  ### Example: Negative tests

  Suppose you have the following directory structure:

  ```
  [workspace]/
      MODULE.bazel
      config/
          BUILD
          base_config.libsonnet
          invalid_config.jsonnet
          invalid_config.output
  ```

  Suppose that `invalid_config.jsonnet` is a Jsonnet file used to verify that
  an invalid config triggers an assertion in `base_config.jsonnet`, and
  `invalid_config.output` is the expected error output.

  The `jsonnet_to_json_test` rule can be used to verify that compiling a Jsonnet
  file results in an expected error code and error output. Simply define a
  `jsonnet_to_json_test` target and provide the input test Jsonnet file, the
  expected error code in the `error` attribute, and the `golden` file containing
  the expected error output:

  `config/BUILD`:

  ```python
  load(
      "@rules_jsonnet//jsonnet:jsonnet.bzl",
      "jsonnet_library",
      "jsonnet_to_json_test",
  )

  jsonnet_library(
      name = "base_config",
      srcs = ["base_config.libsonnet"],
  )

  jsonnet_to_json_test(
      name = "invalid_config_test",
      src = "invalid_config",
      deps = [":base_config"],
      golden = "invalid_config.output",
      error = 1,
  )
  ```

  To run the test: `bazel test //config:invalid_config_test`
*
nameA unique name for this target. 
canonicalize_golden2True/
	code_varsDeprecated (use 'ext_code').
2{}
data2[]b
deps>List of targets that are required by the `srcs` Jsonnet files.*
JsonnetLibraryInfo2[]F
error8The expected error code from running `jsonnet` on `src`.20
ext_code
2{}
ext_code_envs2[]
ext_code_file_vars2[]
ext_code_files2[]
ext_str_envs2[]
ext_str_file_vars2[]
ext_str_files2[]
ext_strs
2{}�

extra_args�Additional command line arguments for the Jsonnet interpreter.

For example, setting this argument to `["--string"]` causes the interpreter to
manifest the output file(s) as plain text instead of JSON.
2[]z
goldenhThe expected (combined stdout and stderr) output to compare to the output of running `jsonnet` on `src`.2NoneR
importsAList of import `-J` flags to be passed to the `jsonnet` compiler.2[]
output_file_contents2Trueo
regex]Set to 1 if `golden` contains a regex used to match the output of running `jsonnet` on `src`.2False6
src'The `.jsonnet` file to convert to JSON.2None

stamp_keys2[]
tla_code
2{}
tla_code_envs2[]
tla_code_files	2{}
tla_str_envs2[]
tla_str_files	2{}
tla_strs
2{}*
varsDeprecated (use 'ext_strs').
2{}
yaml_stream2False"<
jsonnet_to_json_test$@@rules_jsonnet//jsonnet:jsonnet.bzl
��,
*
nameA unique name for this target. 

canonicalize_golden2True1
/
	code_varsDeprecated (use 'ext_code').
2{}

data2[]d
b
deps>List of targets that are required by the `srcs` Jsonnet files.*
JsonnetLibraryInfo2[]H
F
error8The expected error code from running `jsonnet` on `src`.20

ext_code
2{}

ext_code_envs2[]

ext_code_file_vars2[]

ext_code_files2[]

ext_str_envs2[]

ext_str_file_vars2[]

ext_str_files2[]

ext_strs
2{}�
�

extra_args�Additional command line arguments for the Jsonnet interpreter.

For example, setting this argument to `["--string"]` causes the interpreter to
manifest the output file(s) as plain text instead of JSON.
2[]|
z
goldenhThe expected (combined stdout and stderr) output to compare to the output of running `jsonnet` on `src`.2NoneT
R
importsAList of import `-J` flags to be passed to the `jsonnet` compiler.2[] 

output_file_contents2Trueq
o
regex]Set to 1 if `golden` contains a regex used to match the output of running `jsonnet` on `src`.2False8
6
src'The `.jsonnet` file to convert to JSON.2None


stamp_keys2[]

tla_code
2{}

tla_code_envs2[]

tla_code_files	2{}

tla_str_envs2[]

tla_str_files	2{}

tla_strs
2{},
*
varsDeprecated (use 'ext_strs').
2{}

yaml_stream2FalsexJsonnetLibraryInfo2`
P
JsonnetLibraryInfo":
JsonnetLibraryInfo$@@rules_jsonnet//jsonnet:jsonnet.bzl
LLa
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.a
//lib:shell.bzlrL

bazel_skyliblib	shell.bzl
shellshell
',
.ܫ
"
rules_jsonnetjsonnetdocs.bzl�jsonnet_library�Creates a logical set of Jsonnet files.

Example:
  Suppose you have the following directory structure:

  ```
  [workspace]/
      MODULE.bazel
      configs/
          BUILD
          backend.jsonnet
          frontend.jsonnet
  ```

  You can use the `jsonnet_library` rule to build a collection of `.jsonnet`
  files that can be imported by other `.jsonnet` files as dependencies:

  `configs/BUILD`:

  ```python
  load("@rules_jsonnet//jsonnet:jsonnet.bzl", "jsonnet_library")

  jsonnet_library(
      name = "configs",
      srcs = [
          "backend.jsonnet",
          "frontend.jsonnet",
      ],
  )
  ```
"�

�
jsonnet_library�Creates a logical set of Jsonnet files.

Example:
  Suppose you have the following directory structure:

  ```
  [workspace]/
      MODULE.bazel
      configs/
          BUILD
          backend.jsonnet
          frontend.jsonnet
  ```

  You can use the `jsonnet_library` rule to build a collection of `.jsonnet`
  files that can be imported by other `.jsonnet` files as dependencies:

  `configs/BUILD`:

  ```python
  load("@rules_jsonnet//jsonnet:jsonnet.bzl", "jsonnet_library")

  jsonnet_library(
      name = "configs",
      srcs = [
          "backend.jsonnet",
          "frontend.jsonnet",
      ],
  )
  ```
*
nameA unique name for this target. 
data2[]b
deps>List of targets that are required by the `srcs` Jsonnet files.*
JsonnetLibraryInfo2[]R
importsAList of import `-J` flags to be passed to the `jsonnet` compiler.2[]J
srcs<List of `.jsonnet` files that comprises this Jsonnet library2[]"4
jsonnet_library!@@rules_jsonnet//jsonnet:docs.bzl
��,
*
nameA unique name for this target. 

data2[]d
b
deps>List of targets that are required by the `srcs` Jsonnet files.*
JsonnetLibraryInfo2[]T
R
importsAList of import `-J` flags to be passed to the `jsonnet` compiler.2[]L
J
srcs<List of `.jsonnet` files that comprises this Jsonnet library2[]�Pjsonnet_to_json�Compiles Jsonnet code to JSON.

Example:
  ### Example

  Suppose you have the following directory structure:

  ```
  [workspace]/
      MODULE.bazel
      workflows/
          BUILD
          workflow.libsonnet
          wordcount.jsonnet
          intersection.jsonnet
  ```

  Say that `workflow.libsonnet` is a base configuration library for a workflow
  scheduling system and `wordcount.jsonnet` and `intersection.jsonnet` both
  import `workflow.libsonnet` to define workflows for performing a wordcount and
  intersection of two files, respectively.

  First, create a `jsonnet_library` target with `workflow.libsonnet`:

  `workflows/BUILD`:

  ```python
  load("@rules_jsonnet//jsonnet:jsonnet.bzl", "jsonnet_library")

  jsonnet_library(
      name = "workflow",
      srcs = ["workflow.libsonnet"],
  )
  ```

  To compile `wordcount.jsonnet` and `intersection.jsonnet` to JSON, define two
  `jsonnet_to_json` targets:

  ```python
  jsonnet_to_json(
      name = "wordcount",
      src = "wordcount.jsonnet",
      outs = ["wordcount.json"],
      deps = [":workflow"],
  )

  jsonnet_to_json(
      name = "intersection",
      src = "intersection.jsonnet",
      outs = ["intersection.json"],
      deps = [":workflow"],
  )
  ```

  ### Example: Multiple output files

  To use Jsonnet's [multiple output files][multiple-output-files], suppose you
  add a file `shell-workflows.jsonnet` that imports `wordcount.jsonnet` and
  `intersection.jsonnet`:

  `workflows/shell-workflows.jsonnet`:

  ```
  local wordcount = import "workflows/wordcount.jsonnet";
  local intersection = import "workflows/intersection.jsonnet";

  {
    "wordcount-workflow.json": wordcount,
    "intersection-workflow.json": intersection,
  }
  ```

  To compile `shell-workflows.jsonnet` into the two JSON files,
  `wordcount-workflow.json` and `intersection-workflow.json`, first create a
  `jsonnet_library` target containing the two files that
  `shell-workflows.jsonnet` depends on:

  ```python
  jsonnet_library(
      name = "shell-workflows-lib",
      srcs = [
          "wordcount.jsonnet",
          "intersection.jsonnet",
      ],
      deps = [":workflow"],
  )
  ```

  Then, create a `jsonnet_to_json` target and set `outs` to the list of output
  files to indicate that multiple output JSON files are generated:

  ```python
  jsonnet_to_json(
      name = "shell-workflows",
      src = "shell-workflows.jsonnet",
      deps = [":shell-workflows-lib"],
      outs = [
          "wordcount-workflow.json",
          "intersection-workflow.json",
      ],
  )
  ```

  [multiple-output-files]: https://jsonnet.org/learning/getting_started.html#multi
"�;
�(
jsonnet_to_json�Compiles Jsonnet code to JSON.

Example:
  ### Example

  Suppose you have the following directory structure:

  ```
  [workspace]/
      MODULE.bazel
      workflows/
          BUILD
          workflow.libsonnet
          wordcount.jsonnet
          intersection.jsonnet
  ```

  Say that `workflow.libsonnet` is a base configuration library for a workflow
  scheduling system and `wordcount.jsonnet` and `intersection.jsonnet` both
  import `workflow.libsonnet` to define workflows for performing a wordcount and
  intersection of two files, respectively.

  First, create a `jsonnet_library` target with `workflow.libsonnet`:

  `workflows/BUILD`:

  ```python
  load("@rules_jsonnet//jsonnet:jsonnet.bzl", "jsonnet_library")

  jsonnet_library(
      name = "workflow",
      srcs = ["workflow.libsonnet"],
  )
  ```

  To compile `wordcount.jsonnet` and `intersection.jsonnet` to JSON, define two
  `jsonnet_to_json` targets:

  ```python
  jsonnet_to_json(
      name = "wordcount",
      src = "wordcount.jsonnet",
      outs = ["wordcount.json"],
      deps = [":workflow"],
  )

  jsonnet_to_json(
      name = "intersection",
      src = "intersection.jsonnet",
      outs = ["intersection.json"],
      deps = [":workflow"],
  )
  ```

  ### Example: Multiple output files

  To use Jsonnet's [multiple output files][multiple-output-files], suppose you
  add a file `shell-workflows.jsonnet` that imports `wordcount.jsonnet` and
  `intersection.jsonnet`:

  `workflows/shell-workflows.jsonnet`:

  ```
  local wordcount = import "workflows/wordcount.jsonnet";
  local intersection = import "workflows/intersection.jsonnet";

  {
    "wordcount-workflow.json": wordcount,
    "intersection-workflow.json": intersection,
  }
  ```

  To compile `shell-workflows.jsonnet` into the two JSON files,
  `wordcount-workflow.json` and `intersection-workflow.json`, first create a
  `jsonnet_library` target containing the two files that
  `shell-workflows.jsonnet` depends on:

  ```python
  jsonnet_library(
      name = "shell-workflows-lib",
      srcs = [
          "wordcount.jsonnet",
          "intersection.jsonnet",
      ],
      deps = [":workflow"],
  )
  ```

  Then, create a `jsonnet_to_json` target and set `outs` to the list of output
  files to indicate that multiple output JSON files are generated:

  ```python
  jsonnet_to_json(
      name = "shell-workflows",
      src = "shell-workflows.jsonnet",
      deps = [":shell-workflows-lib"],
      outs = [
          "wordcount-workflow.json",
          "intersection-workflow.json",
      ],
  )
  ```

  [multiple-output-files]: https://jsonnet.org/learning/getting_started.html#multi
*
nameA unique name for this target. /
	code_varsDeprecated (use 'ext_code').
2{}
data2[]b
deps>List of targets that are required by the `srcs` Jsonnet files.*
JsonnetLibraryInfo2[]
ext_code
2{}
ext_code_envs2[]
ext_code_file_vars2[]
ext_code_files2[]
ext_str_envs2[]
ext_str_file_vars2[]
ext_str_files2[]
ext_strs
2{}�

extra_args�Additional command line arguments for the Jsonnet interpreter.

For example, setting this argument to `["--string"]` causes the interpreter to
manifest the output file(s) as plain text instead of JSON.
2[]R
importsAList of import `-J` flags to be passed to the `jsonnet` compiler.2[]�
multiple_outputs�Set to `True` to explicitly enable multiple file output via the `jsonnet -m` flag.

This is used for the case where multiple file output is used but only for
generating a single output file. For example:

```
local foo = import "foo.jsonnet";

{
    "foo.json": foo,
}
```

This attribute is incompatible with `out_dir`.
2False�
out_dir�Name of the directory where output files are stored.

If the names of output files are not known up front, this option can be
used to write all output files to a single directory artifact. Files in
this directory cannot be referenced individually.

This attribute is incompatible with `outs` and `multiple_outputs`.
2""�
outs�Names of the output `.json` files to be generated by this rule.

If you are generating only a single JSON file and are not using jsonnet
multiple output files, then this attribute should only contain the file
name of the JSON file you are generating.

If you are generating multiple JSON files using jsonnet multiple file output
(`jsonnet -m`), then list the file names of all the JSON files to be
generated. The file names specified here must match the file names
specified in your `src` Jsonnet file.

For the case where multiple file output is used but only for generating one
output file, set the `multiple_outputs` attribute to 1 to explicitly enable
the `-m` flag for multiple file output.

This attribute is incompatible with `out_dir`.
6
src'The `.jsonnet` file to convert to JSON.2None

stamp_keys2[]
tla_code
2{}
tla_code_envs2[]
tla_code_files	2{}
tla_str_envs2[]
tla_str_files	2{}
tla_strs
2{}*
varsDeprecated (use 'ext_strs').
2{}
yaml_stream2False"4
jsonnet_to_json!@@rules_jsonnet//jsonnet:docs.bzl
��,
*
nameA unique name for this target. 1
/
	code_varsDeprecated (use 'ext_code').
2{}

data2[]d
b
deps>List of targets that are required by the `srcs` Jsonnet files.*
JsonnetLibraryInfo2[]

ext_code
2{}

ext_code_envs2[]

ext_code_file_vars2[]

ext_code_files2[]

ext_str_envs2[]

ext_str_file_vars2[]

ext_str_files2[]

ext_strs
2{}�
�

extra_args�Additional command line arguments for the Jsonnet interpreter.

For example, setting this argument to `["--string"]` causes the interpreter to
manifest the output file(s) as plain text instead of JSON.
2[]T
R
importsAList of import `-J` flags to be passed to the `jsonnet` compiler.2[]�
�
multiple_outputs�Set to `True` to explicitly enable multiple file output via the `jsonnet -m` flag.

This is used for the case where multiple file output is used but only for
generating a single output file. For example:

```
local foo = import "foo.jsonnet";

{
    "foo.json": foo,
}
```

This attribute is incompatible with `out_dir`.
2False�
�
out_dir�Name of the directory where output files are stored.

If the names of output files are not known up front, this option can be
used to write all output files to a single directory artifact. Files in
this directory cannot be referenced individually.

This attribute is incompatible with `outs` and `multiple_outputs`.
2""�
�
outs�Names of the output `.json` files to be generated by this rule.

If you are generating only a single JSON file and are not using jsonnet
multiple output files, then this attribute should only contain the file
name of the JSON file you are generating.

If you are generating multiple JSON files using jsonnet multiple file output
(`jsonnet -m`), then list the file names of all the JSON files to be
generated. The file names specified here must match the file names
specified in your `src` Jsonnet file.

For the case where multiple file output is used but only for generating one
output file, set the `multiple_outputs` attribute to 1 to explicitly enable
the `-m` flag for multiple file output.

This attribute is incompatible with `out_dir`.
8
6
src'The `.jsonnet` file to convert to JSON.2None


stamp_keys2[]

tla_code
2{}

tla_code_envs2[]

tla_code_files	2{}

tla_str_envs2[]

tla_str_files	2{}

tla_strs
2{},
*
varsDeprecated (use 'ext_strs').
2{}

yaml_stream2False�?jsonnet_to_json_test�Compiles Jsonnet code to JSON and checks the output.

Example:
  Suppose you have the following directory structure:

  ```
  [workspace]/
      MODULE.bazel
      config/
          BUILD
          base_config.libsonnet
          test_config.jsonnet
          test_config.json
  ```

  Suppose that `base_config.libsonnet` is a library Jsonnet file, containing the
  base configuration for a service. Suppose that `test_config.jsonnet` is a test
  configuration file that is used to test `base_config.jsonnet`, and
  `test_config.json` is the expected JSON output from compiling
  `test_config.jsonnet`.

  The `jsonnet_to_json_test` rule can be used to verify that compiling a Jsonnet
  file produces the expected JSON output. Simply define a `jsonnet_to_json_test`
  target and provide the input test Jsonnet file and the `golden` file containing
  the expected JSON output:

  `config/BUILD`:

  ```python
  load(
      "@rules_jsonnet//jsonnet:jsonnet.bzl",
      "jsonnet_library",
      "jsonnet_to_json_test",
  )

  jsonnet_library(
      name = "base_config",
      srcs = ["base_config.libsonnet"],
  )

  jsonnet_to_json_test(
      name = "test_config_test",
      src = "test_config",
      deps = [":base_config"],
      golden = "test_config.json",
  )
  ```

  To run the test: `bazel test //config:test_config_test`

  ### Example: Negative tests

  Suppose you have the following directory structure:

  ```
  [workspace]/
      MODULE.bazel
      config/
          BUILD
          base_config.libsonnet
          invalid_config.jsonnet
          invalid_config.output
  ```

  Suppose that `invalid_config.jsonnet` is a Jsonnet file used to verify that
  an invalid config triggers an assertion in `base_config.jsonnet`, and
  `invalid_config.output` is the expected error output.

  The `jsonnet_to_json_test` rule can be used to verify that compiling a Jsonnet
  file results in an expected error code and error output. Simply define a
  `jsonnet_to_json_test` target and provide the input test Jsonnet file, the
  expected error code in the `error` attribute, and the `golden` file containing
  the expected error output:

  `config/BUILD`:

  ```python
  load(
      "@rules_jsonnet//jsonnet:jsonnet.bzl",
      "jsonnet_library",
      "jsonnet_to_json_test",
  )

  jsonnet_library(
      name = "base_config",
      srcs = ["base_config.libsonnet"],
  )

  jsonnet_to_json_test(
      name = "invalid_config_test",
      src = "invalid_config",
      deps = [":base_config"],
      golden = "invalid_config.output",
      error = 1,
  )
  ```

  To run the test: `bazel test //config:invalid_config_test`
"�*
�
jsonnet_to_json_test�Compiles Jsonnet code to JSON and checks the output.

Example:
  Suppose you have the following directory structure:

  ```
  [workspace]/
      MODULE.bazel
      config/
          BUILD
          base_config.libsonnet
          test_config.jsonnet
          test_config.json
  ```

  Suppose that `base_config.libsonnet` is a library Jsonnet file, containing the
  base configuration for a service. Suppose that `test_config.jsonnet` is a test
  configuration file that is used to test `base_config.jsonnet`, and
  `test_config.json` is the expected JSON output from compiling
  `test_config.jsonnet`.

  The `jsonnet_to_json_test` rule can be used to verify that compiling a Jsonnet
  file produces the expected JSON output. Simply define a `jsonnet_to_json_test`
  target and provide the input test Jsonnet file and the `golden` file containing
  the expected JSON output:

  `config/BUILD`:

  ```python
  load(
      "@rules_jsonnet//jsonnet:jsonnet.bzl",
      "jsonnet_library",
      "jsonnet_to_json_test",
  )

  jsonnet_library(
      name = "base_config",
      srcs = ["base_config.libsonnet"],
  )

  jsonnet_to_json_test(
      name = "test_config_test",
      src = "test_config",
      deps = [":base_config"],
      golden = "test_config.json",
  )
  ```

  To run the test: `bazel test //config:test_config_test`

  ### Example: Negative tests

  Suppose you have the following directory structure:

  ```
  [workspace]/
      MODULE.bazel
      config/
          BUILD
          base_config.libsonnet
          invalid_config.jsonnet
          invalid_config.output
  ```

  Suppose that `invalid_config.jsonnet` is a Jsonnet file used to verify that
  an invalid config triggers an assertion in `base_config.jsonnet`, and
  `invalid_config.output` is the expected error output.

  The `jsonnet_to_json_test` rule can be used to verify that compiling a Jsonnet
  file results in an expected error code and error output. Simply define a
  `jsonnet_to_json_test` target and provide the input test Jsonnet file, the
  expected error code in the `error` attribute, and the `golden` file containing
  the expected error output:

  `config/BUILD`:

  ```python
  load(
      "@rules_jsonnet//jsonnet:jsonnet.bzl",
      "jsonnet_library",
      "jsonnet_to_json_test",
  )

  jsonnet_library(
      name = "base_config",
      srcs = ["base_config.libsonnet"],
  )

  jsonnet_to_json_test(
      name = "invalid_config_test",
      src = "invalid_config",
      deps = [":base_config"],
      golden = "invalid_config.output",
      error = 1,
  )
  ```

  To run the test: `bazel test //config:invalid_config_test`
*
nameA unique name for this target. 
canonicalize_golden2True/
	code_varsDeprecated (use 'ext_code').
2{}
data2[]b
deps>List of targets that are required by the `srcs` Jsonnet files.*
JsonnetLibraryInfo2[]F
error8The expected error code from running `jsonnet` on `src`.20
ext_code
2{}
ext_code_envs2[]
ext_code_file_vars2[]
ext_code_files2[]
ext_str_envs2[]
ext_str_file_vars2[]
ext_str_files2[]
ext_strs
2{}�

extra_args�Additional command line arguments for the Jsonnet interpreter.

For example, setting this argument to `["--string"]` causes the interpreter to
manifest the output file(s) as plain text instead of JSON.
2[]z
goldenhThe expected (combined stdout and stderr) output to compare to the output of running `jsonnet` on `src`.2NoneR
importsAList of import `-J` flags to be passed to the `jsonnet` compiler.2[]
output_file_contents2Trueo
regex]Set to 1 if `golden` contains a regex used to match the output of running `jsonnet` on `src`.2False6
src'The `.jsonnet` file to convert to JSON.2None

stamp_keys2[]
tla_code
2{}
tla_code_envs2[]
tla_code_files	2{}
tla_str_envs2[]
tla_str_files	2{}
tla_strs
2{}*
varsDeprecated (use 'ext_strs').
2{}
yaml_stream2False"9
jsonnet_to_json_test!@@rules_jsonnet//jsonnet:docs.bzl
��,
*
nameA unique name for this target. 

canonicalize_golden2True1
/
	code_varsDeprecated (use 'ext_code').
2{}

data2[]d
b
deps>List of targets that are required by the `srcs` Jsonnet files.*
JsonnetLibraryInfo2[]H
F
error8The expected error code from running `jsonnet` on `src`.20

ext_code
2{}

ext_code_envs2[]

ext_code_file_vars2[]

ext_code_files2[]

ext_str_envs2[]

ext_str_file_vars2[]

ext_str_files2[]

ext_strs
2{}�
�

extra_args�Additional command line arguments for the Jsonnet interpreter.

For example, setting this argument to `["--string"]` causes the interpreter to
manifest the output file(s) as plain text instead of JSON.
2[]|
z
goldenhThe expected (combined stdout and stderr) output to compare to the output of running `jsonnet` on `src`.2NoneT
R
importsAList of import `-J` flags to be passed to the `jsonnet` compiler.2[] 

output_file_contents2Trueq
o
regex]Set to 1 if `golden` contains a regex used to match the output of running `jsonnet` on `src`.2False8
6
src'The `.jsonnet` file to convert to JSON.2None


stamp_keys2[]

tla_code
2{}

tla_code_envs2[]

tla_code_files	2{}

tla_str_envs2[]

tla_str_files	2{}

tla_strs
2{},
*
varsDeprecated (use 'ext_strs').
2{}

yaml_stream2False�jsonnet_toolchain!The Jsonnet compiler information."�
�
jsonnet_toolchain!The Jsonnet compiler information.*
nameA unique name for this target. 
compiler2Noneh
create_directory_flagsJThe flags passed to the Jsonnet compiler when a directory must be created. n
manifest_file_supportQIf the Jsonnet compiler supports writing the output filenames to a manifest file. "6
jsonnet_toolchain!@@rules_jsonnet//jsonnet:docs.bzl
,
*
nameA unique name for this target. 

compiler2Nonej
h
create_directory_flagsJThe flags passed to the Jsonnet compiler when a directory must be created. p
n
manifest_file_supportQIf the Jsonnet compiler supports writing the output filenames to a manifest file. �
//jsonnet:jsonnet.bzlr�
%
rules_jsonnetjsonnetjsonnet.bzl1
jsonnet_library_jsonnet_library
1
jsonnet_to_json_jsonnet_to_json
;
jsonnet_to_json_test_jsonnet_to_json_test

�
//jsonnet:toolchain.bzlrn
'
rules_jsonnetjsonnettoolchain.bzl5
jsonnet_toolchain_jsonnet_toolchain
/A
X�# Jsonnet Rules

These are build rules for working with [Jsonnet][jsonnet] files with Bazel.

[jsonnet]: https://jsonnet.org/

## Setup

To use the Jsonnet rules as part of your Bazel project, please follow the
instructions on [the releases page](https://github.com/bazelbuild/rules_jsonnet/releases).
�
(
rules_jsonnetjsonnetextensions.bzl�jsonnetJ�
W
jsonnet
compiler
name2"""2
jsonnet'@@rules_jsonnet//jsonnet:extensions.bzl
((*

compiler
name2""

name2""�
'
rules_jsonnetjsonnettoolchain.bzl�jsonnet_toolchain!The Jsonnet compiler information."�
�
jsonnet_toolchain!The Jsonnet compiler information.*
nameA unique name for this target. 
compiler2Noneh
create_directory_flagsJThe flags passed to the Jsonnet compiler when a directory must be created. n
manifest_file_supportQIf the Jsonnet compiler supports writing the output filenames to a manifest file. ";
jsonnet_toolchain&@@rules_jsonnet//jsonnet:toolchain.bzl
,
*
nameA unique name for this target. 

compiler2Nonej
h
create_directory_flagsJThe flags passed to the Jsonnet compiler when a directory must be created. p
n
manifest_file_supportQIf the Jsonnet compiler supports writing the output filenames to a manifest file. �JsonnetToolchainInfoJsonnet toolchain provider2�
�
JsonnetToolchainInfoJsonnet toolchain provider,
compiler The file to the Jsonnet compilerF
create_directory_flags,The flags to pass when creating a directory.j
manifest_file_supportQIf the Jsonnet compiler supports writing the output filenames to a manifest file.">
JsonnetToolchainInfo&@@rules_jsonnet//jsonnet:toolchain.bzl
  .
,
compiler The file to the Jsonnet compilerH
F
create_directory_flags,The flags to pass when creating a directory.l
j
manifest_file_supportQIf the Jsonnet compiler supports writing the output filenames to a manifest file. 