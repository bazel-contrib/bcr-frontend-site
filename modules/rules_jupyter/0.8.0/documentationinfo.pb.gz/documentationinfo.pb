ȡ
-
rules_jupyterjupyter/privatejupyter.bzl�"jupyter_lab�Launches a Jupyter Lab server for interactive notebook development.

This rule creates an executable target that, when run via `bazel run`, starts a Jupyter Lab
server with the notebook's dependencies available in the virtualenv. By default, when a user
opens the printed URL in their browser, all notebook cells are automatically executed â exactly
as if the user clicked "Run All Cells" in Lab's Run menu.

Example:

```python
jupyter_notebook(
    name = "my_notebook",
    src = "notebook.py",
    deps = ["@pip_deps//polars"],
)

jupyter_lab(
    name = "my_lab",
    notebook = ":my_notebook",
)
```

Then run: `bazel run :my_lab`
"�
�
jupyter_lab�Launches a Jupyter Lab server for interactive notebook development.

This rule creates an executable target that, when run via `bazel run`, starts a Jupyter Lab
server with the notebook's dependencies available in the virtualenv. By default, when a user
opens the printed URL in their browser, all notebook cells are automatically executed â exactly
as if the user clicked "Run All Cells" in Lab's Run menu.

Example:

```python
jupyter_notebook(
    name = "my_notebook",
    src = "notebook.py",
    deps = ["@pip_deps//polars"],
)

jupyter_lab(
    name = "my_lab",
    notebook = ":my_notebook",
)
```

Then run: `bazel run :my_lab`
*
nameA unique name for this target. �
app_settings�A JupyterLab `overrides.json` file providing default settings. Keys are `@jupyterlab/<extension>:<plugin>` and values are settings objects.2//jupyter:lab_app_settings�
cwd_mode�The working directory mode for notebook execution. If not specified, uses the toolchain's `default_cwd`. `execution_root` sets the working directory to Bazel's execution root, while `notebook_root` sets it to the notebook's parent directory.2""s
dataeAdditional data files required by the notebook (e.g., input data files, images, configuration files).2[]�
envxEnvironment variables to set when launching the server. Values support location expansion (e.g., `$(location :target)`).
2{}i
env_inheritTSpecifies additional environment variables to inherit from the external environment.2[]�
execute�Whether to automatically execute all notebook cells when the user opens the notebook in their browser. When True, Lab triggers 'Run All Cells' as soon as the notebook loads. Can be overridden at runtime with `-- --no-execute`.2Truej
notebook;The notebook to serve. Must be a `jupyter_notebook` target. *
JupyterNotebookInfo
PyInfo�
run_mode�Controls where the notebook is served from. `runfiles` (default) copies the notebook to a temp directory with symlinked data dependencies. `source` serves the notebook directly from the source tree for in-place editing with unrestricted file access; requires a `.ipynb` source.2
"runfiles"";
jupyter_lab,@@rules_jupyter//jupyter/private:jupyter.bzl
��,
*
nameA unique name for this target. �
�
app_settings�A JupyterLab `overrides.json` file providing default settings. Keys are `@jupyterlab/<extension>:<plugin>` and values are settings objects.2//jupyter:lab_app_settings�
�
cwd_mode�The working directory mode for notebook execution. If not specified, uses the toolchain's `default_cwd`. `execution_root` sets the working directory to Bazel's execution root, while `notebook_root` sets it to the notebook's parent directory.2""u
s
dataeAdditional data files required by the notebook (e.g., input data files, images, configuration files).2[]�
�
envxEnvironment variables to set when launching the server. Values support location expansion (e.g., `$(location :target)`).
2{}k
i
env_inheritTSpecifies additional environment variables to inherit from the external environment.2[]�
�
execute�Whether to automatically execute all notebook cells when the user opens the notebook in their browser. When True, Lab triggers 'Run All Cells' as soon as the notebook loads. Can be overridden at runtime with `-- --no-execute`.2Truel
j
notebook;The notebook to serve. Must be a `jupyter_notebook` target. *
JupyterNotebookInfo
PyInfo�
�
run_mode�Controls where the notebook is served from. `runfiles` (default) copies the notebook to a temp directory with symlinked data dependencies. `source` serves the notebook directly from the source tree for in-place editing with unrestricted file access; requires a `.ipynb` source.2
"runfiles"�jupyter_notebook�Compiles a Jupyter notebook from source and prepares it for execution.

This rule processes notebook source files and converts them to the standard `.ipynb` format.
If the source is a script in [Jupytext](https://jupytext.readthedocs.io/en/latest/) format
(e.g. a `.py`, `.jl` or `.rs` file with `# %%` / `// %%` cell markers), it will be converted
to `.ipynb` format. If the source is already a `.ipynb` file, it is used directly.

The kernel a notebook runs with is selected by name. Kernels defined with `jupyter_kernelspec`
and registered on the `jupyter_toolchain` are used when their name matches; otherwise the kernel
must be discoverable from the toolchain's Jupyter Python environment (e.g. `python3`).

Example:

```python
jupyter_notebook(
    name = "my_notebook",
    src = "notebook.py",  # or "notebook.ipynb"
    kernel = "python3",   # optional
    deps = ["@pip_deps//polars"],
    data = ["data.csv"],
)
```
"�
�
jupyter_notebook�Compiles a Jupyter notebook from source and prepares it for execution.

This rule processes notebook source files and converts them to the standard `.ipynb` format.
If the source is a script in [Jupytext](https://jupytext.readthedocs.io/en/latest/) format
(e.g. a `.py`, `.jl` or `.rs` file with `# %%` / `// %%` cell markers), it will be converted
to `.ipynb` format. If the source is already a `.ipynb` file, it is used directly.

The kernel a notebook runs with is selected by name. Kernels defined with `jupyter_kernelspec`
and registered on the `jupyter_toolchain` are used when their name matches; otherwise the kernel
must be discoverable from the toolchain's Jupyter Python environment (e.g. `python3`).

Example:

```python
jupyter_notebook(
    name = "my_notebook",
    src = "notebook.py",  # or "notebook.ipynb"
    kernel = "python3",   # optional
    deps = ["@pip_deps//polars"],
    data = ["data.csv"],
)
```
*
nameA unique name for this target. s
dataeAdditional data files required by the notebook (e.g., input data files, images, configuration files).2[]�
depslPython dependencies required by the notebook. These are typically Python packages needed for code execution.*
PyInfo2[]�
kernel�The name of the Jupyter kernel to use for executing the notebook (e.g., `python3`, `rust`). Matches `jupyter_kernelspec.kernel_name` of the kernels registered on the toolchain. If not specified, the default kernel from the toolchain is used.2""�
src�The notebook source file. Can be either a `.ipynb` file or a script in [Jupytext](https://jupytext.readthedocs.io/en/latest/) format (e.g. `.py`, `.jl`, `.rs` with `# %%` or `// %%` cell markers). "@
jupyter_notebook,@@rules_jupyter//jupyter/private:jupyter.bzl
��,
*
nameA unique name for this target. u
s
dataeAdditional data files required by the notebook (e.g., input data files, images, configuration files).2[]�
�
depslPython dependencies required by the notebook. These are typically Python packages needed for code execution.*
PyInfo2[]�
�
kernel�The name of the Jupyter kernel to use for executing the notebook (e.g., `python3`, `rust`). Matches `jupyter_kernelspec.kernel_name` of the kernels registered on the toolchain. If not specified, the default kernel from the toolchain is used.2""�
�
src�The notebook source file. Can be either a `.ipynb` file or a script in [Jupytext](https://jupytext.readthedocs.io/en/latest/) format (e.g. `.py`, `.jl`, `.rs` with `# %%` or `// %%` cell markers). �$jupyter_notebook_binary�An executable rule that runs a Jupyter notebook and optionally generates reports.

Unlike `jupyter_notebook_test`, this rule creates an executable target for use with `bazel run`.
Outputs (executed notebook and reports) are written to a configurable output directory, defaulting
to the caller's working directory (`BUILD_WORKING_DIRECTORY`).

Example:

```python
jupyter_notebook(
    name = "my_notebook",
    src = "notebook.py",
    deps = ["@pip_deps//polars"],
)

jupyter_notebook_binary(
    name = "run_notebook",
    notebook = ":my_notebook",
    reports = ["html"],
)
```

Then run: `bazel run :run_notebook` or `bazel run :run_notebook -- --my-flag value`
"�
�
jupyter_notebook_binary�An executable rule that runs a Jupyter notebook and optionally generates reports.

Unlike `jupyter_notebook_test`, this rule creates an executable target for use with `bazel run`.
Outputs (executed notebook and reports) are written to a configurable output directory, defaulting
to the caller's working directory (`BUILD_WORKING_DIRECTORY`).

Example:

```python
jupyter_notebook(
    name = "my_notebook",
    src = "notebook.py",
    deps = ["@pip_deps//polars"],
)

jupyter_notebook_binary(
    name = "run_notebook",
    notebook = ":my_notebook",
    reports = ["html"],
)
```

Then run: `bazel run :run_notebook` or `bazel run :run_notebook -- --my-flag value`
*
nameA unique name for this target. �
cwd_mode�The working directory mode for notebook execution. If not specified, uses the toolchain's `default_cwd`. `execution_root` sets the working directory to the workspace root, while `notebook_root` sets it to the notebook's parent directory. This affects how relative paths in the notebook are resolved.2""s
dataeAdditional data files required by the notebook (e.g., input data files, images, configuration files).2[]�
envzEnvironment variables to set when executing the notebook. Values support location expansion (e.g., `$(location :target)`).
2{}i
env_inheritTSpecifies additional environment variables to inherit from the external environment.2[]}
exporter_argsfTraitlets-style flags forwarded to nbconvert exporters (e.g. ``--WebPDFExporter.exclude_input=true``).2[]l
notebook=The notebook to execute. Must be a `jupyter_notebook` target. *
JupyterNotebookInfo
PyInfo�
out_dir�Directory to write output files to. If not specified, outputs are written to a subdirectory named after the target under the caller's working directory (e.g., `bazel run :run_notebook` writes to `./run_notebook/`). Absolute paths (e.g., `/tmp`) are used as-is; relative paths are resolved against the caller's working directory.2""�
reports�List of report types to generate after successful notebook execution. Valid values: `html`, `latex`, `markdown` (requires `jupyter_toolchain.pandoc`), `pdf` (requires `jupyter_toolchain.latex_engine`), `rst`, `webpdf` (requires `jupyter_toolchain.playwright_browsers_dir`).2[]"G
jupyter_notebook_binary,@@rules_jupyter//jupyter/private:jupyter.bzl
��,
*
nameA unique name for this target. �
�
cwd_mode�The working directory mode for notebook execution. If not specified, uses the toolchain's `default_cwd`. `execution_root` sets the working directory to the workspace root, while `notebook_root` sets it to the notebook's parent directory. This affects how relative paths in the notebook are resolved.2""u
s
dataeAdditional data files required by the notebook (e.g., input data files, images, configuration files).2[]�
�
envzEnvironment variables to set when executing the notebook. Values support location expansion (e.g., `$(location :target)`).
2{}k
i
env_inheritTSpecifies additional environment variables to inherit from the external environment.2[]
}
exporter_argsfTraitlets-style flags forwarded to nbconvert exporters (e.g. ``--WebPDFExporter.exclude_input=true``).2[]n
l
notebook=The notebook to execute. Must be a `jupyter_notebook` target. *
JupyterNotebookInfo
PyInfo�
�
out_dir�Directory to write output files to. If not specified, outputs are written to a subdirectory named after the target under the caller's working directory (e.g., `bazel run :run_notebook` writes to `./run_notebook/`). Absolute paths (e.g., `/tmp`) are used as-is; relative paths are resolved against the caller's working directory.2""�
�
reports�List of report types to generate after successful notebook execution. Valid values: `html`, `latex`, `markdown` (requires `jupyter_toolchain.pandoc`), `pdf` (requires `jupyter_toolchain.latex_engine`), `rst`, `webpdf` (requires `jupyter_toolchain.playwright_browsers_dir`).2[]�jupyter_notebook_test�A test rule that executes a Jupyter notebook and optionally generates reports. The test fails if any notebook cell raises an error."�
�

jupyter_notebook_test�A test rule that executes a Jupyter notebook and optionally generates reports. The test fails if any notebook cell raises an error.*
nameA unique name for this target. z
cwd_modehThe working directory mode for notebook execution. If not specified, uses the toolchain's `default_cwd`.2""s
dataeAdditional data files required by the notebook (e.g., input data files, images, configuration files).2[]�
envxEnvironment variables to set when executing the notebook. Values support location expansion (e.g., $(location :target)).
2{}�
env_inherit~Specifies additional environment variables to inherit from the external environment when the test is executed by `bazel test`.2[]}
exporter_argsfTraitlets-style flags forwarded to nbconvert exporters (e.g. ``--WebPDFExporter.exclude_input=true``).2[]s
notebookDThe notebook to execute and test. Must be a jupyter_notebook target. *
JupyterNotebookInfo
PyInfo�
reports�List of report types to generate after successful notebook execution. Valid values: `html`, `latex`, `markdown` (requires `jupyter_toolchain.pandoc`), `pdf` (requires `jupyter_toolchain.latex_engine`), `rst`, `webpdf` (requires `jupyter_toolchain.playwright_browsers_dir`).2
["webpdf"]"E
jupyter_notebook_test,@@rules_jupyter//jupyter/private:jupyter.bzl
��,
*
nameA unique name for this target. |
z
cwd_modehThe working directory mode for notebook execution. If not specified, uses the toolchain's `default_cwd`.2""u
s
dataeAdditional data files required by the notebook (e.g., input data files, images, configuration files).2[]�
�
envxEnvironment variables to set when executing the notebook. Values support location expansion (e.g., $(location :target)).
2{}�
�
env_inherit~Specifies additional environment variables to inherit from the external environment when the test is executed by `bazel test`.2[]
}
exporter_argsfTraitlets-style flags forwarded to nbconvert exporters (e.g. ``--WebPDFExporter.exclude_input=true``).2[]u
s
notebookDThe notebook to execute and test. Must be a jupyter_notebook target. *
JupyterNotebookInfo
PyInfo�
�
reports�List of report types to generate after successful notebook execution. Valid values: `html`, `latex`, `markdown` (requires `jupyter_toolchain.pandoc`), `pdf` (requires `jupyter_toolchain.latex_engine`), `rst`, `webpdf` (requires `jupyter_toolchain.playwright_browsers_dir`).2
["webpdf"]�!jupyter_reportoExecutes a Jupyter notebook and generates reports in various formats (HTML, Markdown, LaTeX, PDF, RST, WebPDF)."� 
�
jupyter_reportoExecutes a Jupyter notebook and generates reports in various formats (HTML, Markdown, LaTeX, PDF, RST, WebPDF).*
nameA unique name for this target. R
argsDAdditional command-line arguments to pass to the notebook execution.2[]x
cwd_modefThe working directory mode for notebook execution. If not specified, uses the `jupyter_toolchain.cwd`.2""s
dataeAdditional data files required by the notebook (e.g., input data files, images, configuration files).2[]�
envzEnvironment variables to set when executing the notebook. Values support location expansion (e.g., `$(location :target)`).
2{}}
exporter_argsfTraitlets-style flags forwarded to nbconvert exporters (e.g. ``--WebPDFExporter.exclude_input=true``).2[]x
notebookIThe notebook to execute and convert. Must be a `jupyter_notebook` target. *
JupyterNotebookInfo
PyInfoj
out_html\Output path for an HTML report. If specified, the notebook will be converted to HTML format.>
out_html_template_typeTemplate type for HTML output.2""l
	out_latex]Output path for a LaTeX report. If specified, the notebook will be converted to LaTeX format.q
out_latex_template_typePDocument layout for LaTeX output. `article` (the nbconvert default) or `report`.2""�
out_markdown�Output path for a Markdown report. If specified, the notebook will be converted to Markdown format. Requires `jupyter_toolchain.pandoc`.�
out_notebookwOutput path for the executed notebook (`.ipynb` file with cell outputs). If not specified, a default name is generated.�
out_pdf�Output path for a PDF report generated via LaTeX. Requires `jupyter_toolchain.latex_engine`. For a browser rendered PDF that does not need LaTeX see `out_webpdf`.s
out_rstfOutput path for a reStructuredText report. If specified, the notebook will be converted to RST format.�

out_webpdf�Output path for a WebPDF report (generated via Playwright/Chromium). If specified, the notebook will be converted to PDF format using headless browser rendering. Requires `jupyter_toolchain.playwright_browsers_dir`.">
jupyter_report,@@rules_jupyter//jupyter/private:jupyter.bzl
��,
*
nameA unique name for this target. T
R
argsDAdditional command-line arguments to pass to the notebook execution.2[]z
x
cwd_modefThe working directory mode for notebook execution. If not specified, uses the `jupyter_toolchain.cwd`.2""u
s
dataeAdditional data files required by the notebook (e.g., input data files, images, configuration files).2[]�
�
envzEnvironment variables to set when executing the notebook. Values support location expansion (e.g., `$(location :target)`).
2{}
}
exporter_argsfTraitlets-style flags forwarded to nbconvert exporters (e.g. ``--WebPDFExporter.exclude_input=true``).2[]z
x
notebookIThe notebook to execute and convert. Must be a `jupyter_notebook` target. *
JupyterNotebookInfo
PyInfol
j
out_html\Output path for an HTML report. If specified, the notebook will be converted to HTML format.@
>
out_html_template_typeTemplate type for HTML output.2""n
l
	out_latex]Output path for a LaTeX report. If specified, the notebook will be converted to LaTeX format.s
q
out_latex_template_typePDocument layout for LaTeX output. `article` (the nbconvert default) or `report`.2""�
�
out_markdown�Output path for a Markdown report. If specified, the notebook will be converted to Markdown format. Requires `jupyter_toolchain.pandoc`.�
�
out_notebookwOutput path for the executed notebook (`.ipynb` file with cell outputs). If not specified, a default name is generated.�
�
out_pdf�Output path for a PDF report generated via LaTeX. Requires `jupyter_toolchain.latex_engine`. For a browser rendered PDF that does not need LaTeX see `out_webpdf`.u
s
out_rstfOutput path for a reStructuredText report. If specified, the notebook will be converted to RST format.�
�

out_webpdf�Output path for a WebPDF report (generated via Playwright/Chromium). If specified, the notebook will be converted to PDF format using headless browser rendering. Requires `jupyter_toolchain.playwright_browsers_dir`.�
 //jupyter/private:kernelspec.bzlrn
0
rules_jupyterjupyter/privatekernelspec.bzl,
rlocationpathrlocationpath
9F
H�
//jupyter/private:providers.bzlry
/
rules_jupyterjupyter/privateproviders.bzl8
JupyterNotebookInfoJupyterNotebookInfo
8K
M�
(//jupyter/private:rules_venv_aspects.bzlr|
8
rules_jupyterjupyter/privaterules_venv_aspects.bzl2
aspects_provideraspects_provider
AQ
S�
//jupyter/private:toolchain.bzlro
/
rules_jupyterjupyter/privatetoolchain.bzl.
TOOLCHAIN_TYPETOOLCHAIN_TYPE
8F
Hk
//python:py_info.bzlrQ
!

rules_venvpythonpy_info.bzl
PyInfoPyInfo
*0
2
//python/venv:defs.bzlrc
#

rules_venvpython/venvdefs.bzl.
py_venv_commonpy_venv_common
,:
<# Jupyter rules�;
0
rules_jupyterjupyter/privatekernelspec.bzl�7jupyter_kernelspec�
Defines a [Jupyter kernel](https://jupyter-client.readthedocs.io/en/latest/kernels.html) that notebooks can be executed with.

The rule is language agnostic. It describes how to launch a kernel process in the same way a
`kernel.json` file does, but with files tracked by Bazel. Kernels are attached to a
`jupyter_toolchain` via its `kernels` attribute and selected by notebooks using
`jupyter_notebook.kernel` (or `jupyter_toolchain.kernel` for a default).

File references in `argv` and `env` use `$(rlocationpath ...)` expansion over the targets in
`data`. The rules resolve them to real paths wherever the notebook is executed (build actions,
tests, `bazel run` and Jupyter Lab). Jupyter's own `{connection_file}` placeholder and `${VAR}`
environment substitution continue to work.

Example:

```python
jupyter_kernelspec(
    name = "julia",
    display_name = "Julia",
    language = "julia",
    argv = [
        "$(rlocationpath :ijulia_kernel)",
        "{connection_file}",
    ],
    data = [":ijulia_kernel"],
    # A file containing `empty!(ARGS); append!(ARGS, {args})`.
    args_template = "args_template.jl",
)

jupyter_toolchain(
    name = "jupyter_toolchain",
    kernels = [":julia"],
    ...
)

jupyter_notebook(
    name = "notebook",
    src = "notebook.jl",
    kernel = "julia",
)
```
"�,
�
jupyter_kernelspec�
Defines a [Jupyter kernel](https://jupyter-client.readthedocs.io/en/latest/kernels.html) that notebooks can be executed with.

The rule is language agnostic. It describes how to launch a kernel process in the same way a
`kernel.json` file does, but with files tracked by Bazel. Kernels are attached to a
`jupyter_toolchain` via its `kernels` attribute and selected by notebooks using
`jupyter_notebook.kernel` (or `jupyter_toolchain.kernel` for a default).

File references in `argv` and `env` use `$(rlocationpath ...)` expansion over the targets in
`data`. The rules resolve them to real paths wherever the notebook is executed (build actions,
tests, `bazel run` and Jupyter Lab). Jupyter's own `{connection_file}` placeholder and `${VAR}`
environment substitution continue to work.

Example:

```python
jupyter_kernelspec(
    name = "julia",
    display_name = "Julia",
    language = "julia",
    argv = [
        "$(rlocationpath :ijulia_kernel)",
        "{connection_file}",
    ],
    data = [":ijulia_kernel"],
    # A file containing `empty!(ARGS); append!(ARGS, {args})`.
    args_template = "args_template.jl",
)

jupyter_toolchain(
    name = "jupyter_toolchain",
    kernels = [":julia"],
    ...
)

jupyter_notebook(
    name = "notebook",
    src = "notebook.jl",
    kernel = "julia",
)
```
*
nameA unique name for this target. �
args_template�A file holding a code cell template used to forward `args` of `jupyter_notebook_test`, `jupyter_notebook_binary`, `jupyter_report` and `jupyter_lab` to the notebook. The cell is prepended to the notebook before execution. The only placeholder is `{args}`, replaced by a JSON array of the arguments (e.g. a file containing `empty!(ARGS); append!(ARGS, {args})` for Julia); other braces are left as they are. When unset, notebooks using this kernel cannot be given `args`.2None�
argv�The command used to launch the kernel. Supports `$(rlocationpath ...)` expansion for targets in `data` and `path_tools` as well as Jupyter's `{connection_file}` placeholder. �
data~Files and executables required by the kernel at runtime. These are the targets available for `$(rlocationpath ...)` expansion.2[]W
display_nameAThe human readable name of the kernel. Defaults to `kernel_name`.2""�
env�Environment variables for the kernel process. Values support `$(rlocationpath ...)` expansion and Jupyter's `${VAR}` substitution with the environment of the process launching the kernel.
2{}�
interrupt_mode�How the kernel is interrupted. `signal` sends `SIGINT`, `message` sends an `interrupt_request`. Defaults to Jupyter's default (`signal`).2""�
kernel_nameuThe name of the kernel as referenced by `jupyter_notebook.kernel` and notebook metadata. Defaults to the target name.2""�
language�The language of the kernel (e.g. `python`, `julia`, `rust`). Recorded in notebook metadata and used by exporters for syntax highlighting. �

path_tools�Executables whose parent directories are prepended to `PATH` for the kernel process. Useful for kernels that shell out to compilers or interpreters. Each target must provide exactly one file.2[]�
	transport�The ZeroMQ transport used to talk to the kernel. Defaults to `ipc` on Unix, which avoids port collisions between notebooks Bazel runs in parallel, and `tcp` on Windows. Kernels whose ZeroMQ lacks IPC support (e.g. prebuilt `evcxr_jupyter` binaries) must set `tcp`.2"""E
jupyter_kernelspec/@@rules_jupyter//jupyter/private:kernelspec.bzl
kk,
*
nameA unique name for this target. �
�
args_template�A file holding a code cell template used to forward `args` of `jupyter_notebook_test`, `jupyter_notebook_binary`, `jupyter_report` and `jupyter_lab` to the notebook. The cell is prepended to the notebook before execution. The only placeholder is `{args}`, replaced by a JSON array of the arguments (e.g. a file containing `empty!(ARGS); append!(ARGS, {args})` for Julia); other braces are left as they are. When unset, notebooks using this kernel cannot be given `args`.2None�
�
argv�The command used to launch the kernel. Supports `$(rlocationpath ...)` expansion for targets in `data` and `path_tools` as well as Jupyter's `{connection_file}` placeholder. �
�
data~Files and executables required by the kernel at runtime. These are the targets available for `$(rlocationpath ...)` expansion.2[]Y
W
display_nameAThe human readable name of the kernel. Defaults to `kernel_name`.2""�
�
env�Environment variables for the kernel process. Values support `$(rlocationpath ...)` expansion and Jupyter's `${VAR}` substitution with the environment of the process launching the kernel.
2{}�
�
interrupt_mode�How the kernel is interrupted. `signal` sends `SIGINT`, `message` sends an `interrupt_request`. Defaults to Jupyter's default (`signal`).2""�
�
kernel_nameuThe name of the kernel as referenced by `jupyter_notebook.kernel` and notebook metadata. Defaults to the target name.2""�
�
language�The language of the kernel (e.g. `python`, `julia`, `rust`). Recorded in notebook metadata and used by exporters for syntax highlighting. �
�

path_tools�Executables whose parent directories are prepended to `PATH` for the kernel process. Useful for kernels that shell out to compilers or interpreters. Each target must provide exactly one file.2[]�
�
	transport�The ZeroMQ transport used to talk to the kernel. Defaults to `ipc` on Unix, which avoids port collisions between notebooks Bazel runs in parallel, and `tcp` on Windows. Kernels whose ZeroMQ lacks IPC support (e.g. prebuilt `evcxr_jupyter` binaries) must set `tcp`.2""�rlocationpath$Compute the rlocationpath of a file.*�
�
rlocationpath
file	The file. (L
workspace_name6The name of the main workspace (`ctx.workspace_name`). ($Compute the rlocationpath of a file."%
#str: The runfiles path of the file.2@
rlocationpath/@@rules_jupyter//jupyter/private:kernelspec.bzl
�
//jupyter/private:providers.bzlr}
/
rules_jupyterjupyter/privateproviders.bzl<
JupyterKernelspecInfoJupyterKernelspecInfo
8M
Ojupyter_kernelspec�
,
rules_jupyterjupyter/private
pandoc.bzl�pandoc_archive*�
�
pandoc_archive

name (
platform (	
url (
	integrity (
strip_prefix (2=
pandoc_archive+@@rules_jupyter//jupyter/private:pandoc.bzl
??2http_archive�pandoc_alias_repository�Creates a platform-aware alias repository for Pandoc binaries. Selects the appropriate Pandoc binary based on the target platform.R�
�
pandoc_alias_repository�Creates a platform-aware alias repository for Pandoc binaries. Selects the appropriate Pandoc binary based on the target platform..
name"A unique name for this repository. �
binaries�Mapping of Pandoc archive repository labels to platform identifiers. Used to select the correct Pandoc binary for the target platform.	 �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 *F
pandoc_alias_repository+@@rules_jupyter//jupyter/private:pandoc.bzl
4*4*0
.
name"A unique name for this repository. �
�
binaries�Mapping of Pandoc archive repository labels to platform identifiers. Used to select the correct Pandoc binary for the target platform.	 �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
 //tools/build_defs/repo:http.bzlrj
.
bazel_toolstools/build_defs/repohttp.bzl*
http_archivehttp_archive
7C
E�
%//jupyter/private:pandoc_versions.bzlrx
5
rules_jupyterjupyter/privatepandoc_versions.bzl1
PANDOC_VERSIONS_PANDOC_VERSIONS
=M
b*	DEFAULT_PANDOC_VERSION3.8.2j3.8.2Rules for fetching Pandoc�
5
rules_jupyterjupyter/privatepandoc_versions.bzl{Pandoc Versions

A mapping of platform to integrity of the archive for said platform for each version of Pandoc available.
�!
/
rules_jupyterjupyter/privateproviders.bzl�JupyterKernelspecInfoIProvider describing a Jupyter kernel that notebooks can be executed with.2�
�
JupyterKernelspecInfoIProvider describing a Jupyter kernel that notebooks can be executed with.�
args_templatezFile: A code cell template used to forward notebook `args` to the kernel, or `None` when the kernel does not support args.o
argvgList[str]: The kernel launch command. File references are rlocationpaths which are resolved at runtime.4
display_name$str: The human readable kernel name.H
envADict[str, str]: Environment variables set for the kernel process.C
files:Depset[File]: All files required by the kernel at runtime.u
interrupt_modecstr: The Jupyter interrupt mode (`signal` or `message`) or an empty string for the Jupyter default.\
kernel_nameMstr: The kernel name used by `jupyter_notebook.kernel` and notebook metadata.M
languageAstr: The language of the kernel (e.g. `python`, `julia`, `rust`).�

path_tools�List[str]: rlocationpaths of the `path_tools` executables. The directory of each resolved file is prepended to `PATH` for the kernel process.n

rlocations`Dict[str, File]: Every file referenced by `argv`, `env` or `path_tools`, keyed by rlocationpath.1
runfiles%runfiles: The runfiles of the kernel.d
spec\File: A json file describing the kernelspec, consumed by the rules_jupyter process wrappers.�
tools{List[FilesToRunProvider]: Executables used by the kernel. Passed as tools to build actions so their runfiles are available.�
	transportsstr: The ZeroMQ transport (`ipc` or `tcp`) used to talk to the kernel, or an empty string for the platform default."G
JupyterKernelspecInfo.@@rules_jupyter//jupyter/private:providers.bzl
!!�
�
args_templatezFile: A code cell template used to forward notebook `args` to the kernel, or `None` when the kernel does not support args.q
o
argvgList[str]: The kernel launch command. File references are rlocationpaths which are resolved at runtime.6
4
display_name$str: The human readable kernel name.J
H
envADict[str, str]: Environment variables set for the kernel process.E
C
files:Depset[File]: All files required by the kernel at runtime.w
u
interrupt_modecstr: The Jupyter interrupt mode (`signal` or `message`) or an empty string for the Jupyter default.^
\
kernel_nameMstr: The kernel name used by `jupyter_notebook.kernel` and notebook metadata.O
M
languageAstr: The language of the kernel (e.g. `python`, `julia`, `rust`).�
�

path_tools�List[str]: rlocationpaths of the `path_tools` executables. The directory of each resolved file is prepended to `PATH` for the kernel process.p
n

rlocations`Dict[str, File]: Every file referenced by `argv`, `env` or `path_tools`, keyed by rlocationpath.3
1
runfiles%runfiles: The runfiles of the kernel.f
d
spec\File: A json file describing the kernelspec, consumed by the rules_jupyter process wrappers.�
�
tools{List[FilesToRunProvider]: Executables used by the kernel. Passed as tools to build actions so their runfiles are available.�
�
	transportsstr: The ZeroMQ transport (`ipc` or `tcp`) used to talk to the kernel, or an empty string for the platform default.�JupyterNotebookInfo;Provider that carries information about a Jupyter notebook.2�
�
JupyterNotebookInfo;Provider that carries information about a Jupyter notebook.f
data^Depset[file]: Additional data files required by the notebook (e.g., input data files, images).j
kernel`str: The name of the Jupyter kernel to use for executing the notebook (e.g., 'python3', 'rust').4
notebook(File: The notebook file (.ipynb format).\
srcUFile: The original source file (.py or .ipynb) provided to the jupyter_notebook rule."E
JupyterNotebookInfo.@@rules_jupyter//jupyter/private:providers.bzl
h
f
data^Depset[file]: Additional data files required by the notebook (e.g., input data files, images).l
j
kernel`str: The name of the Jupyter kernel to use for executing the notebook (e.g., 'python3', 'rust').6
4
notebook(File: The notebook file (.ipynb format).^
\
srcUFile: The original source file (.py or .ipynb) provided to the jupyter_notebook rule.	Providers�
8
rules_jupyterjupyter/privaterules_venv_aspects.bzl�aspects_provider1Construct a provider to power rules_venv aspects.*�
�
aspects_provider-
ctx"The current rule's context object. (#
srcThe notebook source file (1Construct a provider to power rules_venv aspects.",
*Provider: A unique provider for rules_venv2K
aspects_provider7@@rules_jupyter//jupyter/private:rules_venv_aspects.bzl
�PySourcesInfo1A container for info on a lintable python target.2�
�
PySourcesInfo1A container for info on a lintable python target.�
first_party_modules�depset[str]: Top-level workspace path segments contributed by this target
and its transitive Python dependencies. Includes segments derived from
`.py` / `.pyi` sources and from compiled Python extension outputs
(`.so`, `.pyd`, `.dylib`).N
importsCdepset[str]: The values of `PyInfo.imports` for the current target..
srcs&depset[File]: All direct source files."H
PySourcesInfo7@@rules_jupyter//jupyter/private:rules_venv_aspects.bzl
�
�
first_party_modules�depset[str]: Top-level workspace path segments contributed by this target
and its transitive Python dependencies. Includes segments derived from
`.py` / `.pyi` sources and from compiled Python extension outputs
(`.so`, `.pyd`, `.dylib`).P
N
importsCdepset[str]: The values of `PyInfo.imports` for the current target.0
.
srcs&depset[File]: All direct source files.�
 //python/private:target_srcs.bzlrl
-

rules_venvpython/privatetarget_srcs.bzl-
PySourcesInfo_PySourcesInfo
5C
V1Utilities for interacting with rules_venv aspects�E
/
rules_jupyterjupyter/privatetoolchain.bzl�current_jupyter_toolchainiA convenience rule that provides access to the Jupyter Python package from the current Jupyter toolchain."�
�
current_jupyter_toolchainiA convenience rule that provides access to the Jupyter Python package from the current Jupyter toolchain.*
nameA unique name for this target. "K
current_jupyter_toolchain.@@rules_jupyter//jupyter/private:toolchain.bzl
�!�!,
*
nameA unique name for this target. �current_jupytext_toolchainjA convenience rule that provides access to the Jupytext Python package from the current Jupyter toolchain."�
�
current_jupytext_toolchainjA convenience rule that provides access to the Jupytext Python package from the current Jupyter toolchain.*
nameA unique name for this target. "L
current_jupytext_toolchain.@@rules_jupyter//jupyter/private:toolchain.bzl
�"�",
*
nameA unique name for this target. �;jupyter_toolchain�	Defines a Jupyter toolchain that provides Jupyter, Jupytext, Pandoc, Playwright browser, LaTeX support and
additional kernels.

Kernels for languages other than Python are defined with `jupyter_kernelspec` and attached via `kernels`.
A single toolchain can serve notebooks of many languages; each notebook selects a kernel by name with
`jupyter_notebook.kernel`. Kernels not listed here (such as `python3` from `ipykernel`) are expected to be
discoverable from the `jupyter` Python environment.

LaTeX (used for `pdf` reports) is optional. The [texlive](https://registry.bazel.build/modules/texlive)
module from the Bazel Central Registry provides everything required:

```python
jupyter_toolchain(
    name = "jupyter_toolchain",
    jupyter = "@pip_deps//jupyter",
    jupytext = "@pip_deps//jupytext",
    pandoc = "@pandoc",
    latex_engine = "@texlive//texk/web2c:pdftex",
    latex_format = "@texlive//:pdflatex_fmt",
    latex_texmf_cnf = "@texlive-texmf//:web2c/texmf.cnf",
    latex_data = [
        "@texlive//:texmf/fonts",
        "@texlive//:texmf/tex_inputs",
        "@texlive//:texmf/web2c_data",
    ],
    bibtex = "@texlive//texk/bibtex-x:bibtex8",
)
```
"�1
�
jupyter_toolchain�	Defines a Jupyter toolchain that provides Jupyter, Jupytext, Pandoc, Playwright browser, LaTeX support and
additional kernels.

Kernels for languages other than Python are defined with `jupyter_kernelspec` and attached via `kernels`.
A single toolchain can serve notebooks of many languages; each notebook selects a kernel by name with
`jupyter_notebook.kernel`. Kernels not listed here (such as `python3` from `ipykernel`) are expected to be
discoverable from the `jupyter` Python environment.

LaTeX (used for `pdf` reports) is optional. The [texlive](https://registry.bazel.build/modules/texlive)
module from the Bazel Central Registry provides everything required:

```python
jupyter_toolchain(
    name = "jupyter_toolchain",
    jupyter = "@pip_deps//jupyter",
    jupytext = "@pip_deps//jupytext",
    pandoc = "@pandoc",
    latex_engine = "@texlive//texk/web2c:pdftex",
    latex_format = "@texlive//:pdflatex_fmt",
    latex_texmf_cnf = "@texlive-texmf//:web2c/texmf.cnf",
    latex_data = [
        "@texlive//:texmf/fonts",
        "@texlive//:texmf/tex_inputs",
        "@texlive//:texmf/web2c_data",
    ],
    bibtex = "@texlive//texk/bibtex-x:bibtex8",
)
```
*
nameA unique name for this target. �
bibtex�An optional BibTeX executable (e.g. `@texlive//texk/bibtex-x:bibtex8`). When unset, the bibliography pass of PDF generation is skipped.2None�
cwd_mode�The default working directory mode for notebook execution. This value is used when `cwd_mode` is not specified in `jupyter_report` or `jupyter_notebook_test` rules. `workspace_root` sets the working directory to the workspace root, while `notebook_root` sets it to the notebook's parent directory. This affects how relative paths in notebooks are resolved.2"execution_root"�
exporter_args�Default traitlets-style flags forwarded to nbconvert exporters for all rules using this toolchain (e.g. ``--WebPDFExporter.exclude_input=true``). Per-rule ``exporter_args`` are appended after these defaults, allowing overrides.2[]^
jupyterEThe Jupyter Python package providing notebook execution capabilities. *
PyInfo�
jupytext�The [Jupytext](https://jupytext.readthedocs.io/en/latest/) Python package for converting between notebook formats (e.g., .py to .ipynb). *
PyInfo}
kernelmDefault kernel name to use for notebook execution if not specified in the notebook (e.g., 'python3', 'rust').2""�
kernels�`jupyter_kernelspec` targets made available to notebooks using this toolchain. A kernel is only added to the inputs of a notebook when the notebook selects it by name via `jupyter_notebook.kernel` or `kernel`.*
JupyterKernelspecInfo2[]�

latex_data�texmf trees (fonts, macro packages, `web2c` configuration) required by `latex_engine` at runtime. These files are only added to actions and runfiles that produce PDF output.2[]�
latex_engine�A TeX engine executable used for `pdf` reports (e.g. `@texlive//texk/web2c:pdftex`). Requires `latex_format` and `latex_texmf_cnf`.2None�
latex_format~A precompiled LaTeX format file for `latex_engine` (e.g. `@texlive//:pdflatex_fmt`). The engine is invoked with `-fmt=<stem>`.2None�
latex_texmf_cnf�The `web2c/texmf.cnf` file of the texmf tree (e.g. `@texlive-texmf//:web2c/texmf.cnf`). Its directory becomes `TEXMFCNF` and its parent becomes `TEXMF`.2Nonet
pandocbThe Pandoc executable for converting notebooks to various output formats (HTML, LaTeX, PDF, etc.).2None^
playwright_browsers_dir;A directory containing the results of `playwright install`.2None{
playwright_ld_library_dirVA directory of shared libraries to prepend to LD_LIBRARY_PATH when launching browsers.2None"C
jupyter_toolchain.@@rules_jupyter//jupyter/private:toolchain.bzl
vv,
*
nameA unique name for this target. �
�
bibtex�An optional BibTeX executable (e.g. `@texlive//texk/bibtex-x:bibtex8`). When unset, the bibliography pass of PDF generation is skipped.2None�
�
cwd_mode�The default working directory mode for notebook execution. This value is used when `cwd_mode` is not specified in `jupyter_report` or `jupyter_notebook_test` rules. `workspace_root` sets the working directory to the workspace root, while `notebook_root` sets it to the notebook's parent directory. This affects how relative paths in notebooks are resolved.2"execution_root"�
�
exporter_args�Default traitlets-style flags forwarded to nbconvert exporters for all rules using this toolchain (e.g. ``--WebPDFExporter.exclude_input=true``). Per-rule ``exporter_args`` are appended after these defaults, allowing overrides.2[]`
^
jupyterEThe Jupyter Python package providing notebook execution capabilities. *
PyInfo�
�
jupytext�The [Jupytext](https://jupytext.readthedocs.io/en/latest/) Python package for converting between notebook formats (e.g., .py to .ipynb). *
PyInfo
}
kernelmDefault kernel name to use for notebook execution if not specified in the notebook (e.g., 'python3', 'rust').2""�
�
kernels�`jupyter_kernelspec` targets made available to notebooks using this toolchain. A kernel is only added to the inputs of a notebook when the notebook selects it by name via `jupyter_notebook.kernel` or `kernel`.*
JupyterKernelspecInfo2[]�
�

latex_data�texmf trees (fonts, macro packages, `web2c` configuration) required by `latex_engine` at runtime. These files are only added to actions and runfiles that produce PDF output.2[]�
�
latex_engine�A TeX engine executable used for `pdf` reports (e.g. `@texlive//texk/web2c:pdftex`). Requires `latex_format` and `latex_texmf_cnf`.2None�
�
latex_format~A precompiled LaTeX format file for `latex_engine` (e.g. `@texlive//:pdflatex_fmt`). The engine is invoked with `-fmt=<stem>`.2None�
�
latex_texmf_cnf�The `web2c/texmf.cnf` file of the texmf tree (e.g. `@texlive-texmf//:web2c/texmf.cnf`). Its directory becomes `TEXMFCNF` and its parent becomes `TEXMF`.2Nonev
t
pandocbThe Pandoc executable for converting notebooks to various output formats (HTML, LaTeX, PDF, etc.).2None`
^
playwright_browsers_dir;A directory containing the results of `playwright install`.2None}
{
playwright_ld_library_dirVA directory of shared libraries to prepend to LD_LIBRARY_PATH when launching browsers.2None�
//jupyter/private:providers.bzlr}
/
rules_jupyterjupyter/privateproviders.bzl<
JupyterKernelspecInfoJupyterKernelspecInfo
8M
Ok
//python:py_info.bzlrQ
!

rules_venvpythonpy_info.bzl
PyInfoPyInfo
*0
2L	TOOLCHAIN_TYPE@@//jupyter:toolchain_typej@@//jupyter:toolchain_typeJupyter toolchain̙
"
rules_jupyterjupyterdefs.bzl�7jupyter_kernelspec�
Defines a [Jupyter kernel](https://jupyter-client.readthedocs.io/en/latest/kernels.html) that notebooks can be executed with.

The rule is language agnostic. It describes how to launch a kernel process in the same way a
`kernel.json` file does, but with files tracked by Bazel. Kernels are attached to a
`jupyter_toolchain` via its `kernels` attribute and selected by notebooks using
`jupyter_notebook.kernel` (or `jupyter_toolchain.kernel` for a default).

File references in `argv` and `env` use `$(rlocationpath ...)` expansion over the targets in
`data`. The rules resolve them to real paths wherever the notebook is executed (build actions,
tests, `bazel run` and Jupyter Lab). Jupyter's own `{connection_file}` placeholder and `${VAR}`
environment substitution continue to work.

Example:

```python
jupyter_kernelspec(
    name = "julia",
    display_name = "Julia",
    language = "julia",
    argv = [
        "$(rlocationpath :ijulia_kernel)",
        "{connection_file}",
    ],
    data = [":ijulia_kernel"],
    # A file containing `empty!(ARGS); append!(ARGS, {args})`.
    args_template = "args_template.jl",
)

jupyter_toolchain(
    name = "jupyter_toolchain",
    kernels = [":julia"],
    ...
)

jupyter_notebook(
    name = "notebook",
    src = "notebook.jl",
    kernel = "julia",
)
```
"�,
�
jupyter_kernelspec�
Defines a [Jupyter kernel](https://jupyter-client.readthedocs.io/en/latest/kernels.html) that notebooks can be executed with.

The rule is language agnostic. It describes how to launch a kernel process in the same way a
`kernel.json` file does, but with files tracked by Bazel. Kernels are attached to a
`jupyter_toolchain` via its `kernels` attribute and selected by notebooks using
`jupyter_notebook.kernel` (or `jupyter_toolchain.kernel` for a default).

File references in `argv` and `env` use `$(rlocationpath ...)` expansion over the targets in
`data`. The rules resolve them to real paths wherever the notebook is executed (build actions,
tests, `bazel run` and Jupyter Lab). Jupyter's own `{connection_file}` placeholder and `${VAR}`
environment substitution continue to work.

Example:

```python
jupyter_kernelspec(
    name = "julia",
    display_name = "Julia",
    language = "julia",
    argv = [
        "$(rlocationpath :ijulia_kernel)",
        "{connection_file}",
    ],
    data = [":ijulia_kernel"],
    # A file containing `empty!(ARGS); append!(ARGS, {args})`.
    args_template = "args_template.jl",
)

jupyter_toolchain(
    name = "jupyter_toolchain",
    kernels = [":julia"],
    ...
)

jupyter_notebook(
    name = "notebook",
    src = "notebook.jl",
    kernel = "julia",
)
```
*
nameA unique name for this target. �
args_template�A file holding a code cell template used to forward `args` of `jupyter_notebook_test`, `jupyter_notebook_binary`, `jupyter_report` and `jupyter_lab` to the notebook. The cell is prepended to the notebook before execution. The only placeholder is `{args}`, replaced by a JSON array of the arguments (e.g. a file containing `empty!(ARGS); append!(ARGS, {args})` for Julia); other braces are left as they are. When unset, notebooks using this kernel cannot be given `args`.2None�
argv�The command used to launch the kernel. Supports `$(rlocationpath ...)` expansion for targets in `data` and `path_tools` as well as Jupyter's `{connection_file}` placeholder. �
data~Files and executables required by the kernel at runtime. These are the targets available for `$(rlocationpath ...)` expansion.2[]W
display_nameAThe human readable name of the kernel. Defaults to `kernel_name`.2""�
env�Environment variables for the kernel process. Values support `$(rlocationpath ...)` expansion and Jupyter's `${VAR}` substitution with the environment of the process launching the kernel.
2{}�
interrupt_mode�How the kernel is interrupted. `signal` sends `SIGINT`, `message` sends an `interrupt_request`. Defaults to Jupyter's default (`signal`).2""�
kernel_nameuThe name of the kernel as referenced by `jupyter_notebook.kernel` and notebook metadata. Defaults to the target name.2""�
language�The language of the kernel (e.g. `python`, `julia`, `rust`). Recorded in notebook metadata and used by exporters for syntax highlighting. �

path_tools�Executables whose parent directories are prepended to `PATH` for the kernel process. Useful for kernels that shell out to compilers or interpreters. Each target must provide exactly one file.2[]�
	transport�The ZeroMQ transport used to talk to the kernel. Defaults to `ipc` on Unix, which avoids port collisions between notebooks Bazel runs in parallel, and `tcp` on Windows. Kernels whose ZeroMQ lacks IPC support (e.g. prebuilt `evcxr_jupyter` binaries) must set `tcp`.2"""7
jupyter_kernelspec!@@rules_jupyter//jupyter:defs.bzl
kk,
*
nameA unique name for this target. �
�
args_template�A file holding a code cell template used to forward `args` of `jupyter_notebook_test`, `jupyter_notebook_binary`, `jupyter_report` and `jupyter_lab` to the notebook. The cell is prepended to the notebook before execution. The only placeholder is `{args}`, replaced by a JSON array of the arguments (e.g. a file containing `empty!(ARGS); append!(ARGS, {args})` for Julia); other braces are left as they are. When unset, notebooks using this kernel cannot be given `args`.2None�
�
argv�The command used to launch the kernel. Supports `$(rlocationpath ...)` expansion for targets in `data` and `path_tools` as well as Jupyter's `{connection_file}` placeholder. �
�
data~Files and executables required by the kernel at runtime. These are the targets available for `$(rlocationpath ...)` expansion.2[]Y
W
display_nameAThe human readable name of the kernel. Defaults to `kernel_name`.2""�
�
env�Environment variables for the kernel process. Values support `$(rlocationpath ...)` expansion and Jupyter's `${VAR}` substitution with the environment of the process launching the kernel.
2{}�
�
interrupt_mode�How the kernel is interrupted. `signal` sends `SIGINT`, `message` sends an `interrupt_request`. Defaults to Jupyter's default (`signal`).2""�
�
kernel_nameuThe name of the kernel as referenced by `jupyter_notebook.kernel` and notebook metadata. Defaults to the target name.2""�
�
language�The language of the kernel (e.g. `python`, `julia`, `rust`). Recorded in notebook metadata and used by exporters for syntax highlighting. �
�

path_tools�Executables whose parent directories are prepended to `PATH` for the kernel process. Useful for kernels that shell out to compilers or interpreters. Each target must provide exactly one file.2[]�
�
	transport�The ZeroMQ transport used to talk to the kernel. Defaults to `ipc` on Unix, which avoids port collisions between notebooks Bazel runs in parallel, and `tcp` on Windows. Kernels whose ZeroMQ lacks IPC support (e.g. prebuilt `evcxr_jupyter` binaries) must set `tcp`.2""�"jupyter_lab�Launches a Jupyter Lab server for interactive notebook development.

This rule creates an executable target that, when run via `bazel run`, starts a Jupyter Lab
server with the notebook's dependencies available in the virtualenv. By default, when a user
opens the printed URL in their browser, all notebook cells are automatically executed â exactly
as if the user clicked "Run All Cells" in Lab's Run menu.

Example:

```python
jupyter_notebook(
    name = "my_notebook",
    src = "notebook.py",
    deps = ["@pip_deps//polars"],
)

jupyter_lab(
    name = "my_lab",
    notebook = ":my_notebook",
)
```

Then run: `bazel run :my_lab`
"�
�
jupyter_lab�Launches a Jupyter Lab server for interactive notebook development.

This rule creates an executable target that, when run via `bazel run`, starts a Jupyter Lab
server with the notebook's dependencies available in the virtualenv. By default, when a user
opens the printed URL in their browser, all notebook cells are automatically executed â exactly
as if the user clicked "Run All Cells" in Lab's Run menu.

Example:

```python
jupyter_notebook(
    name = "my_notebook",
    src = "notebook.py",
    deps = ["@pip_deps//polars"],
)

jupyter_lab(
    name = "my_lab",
    notebook = ":my_notebook",
)
```

Then run: `bazel run :my_lab`
*
nameA unique name for this target. �
app_settings�A JupyterLab `overrides.json` file providing default settings. Keys are `@jupyterlab/<extension>:<plugin>` and values are settings objects.2//jupyter:lab_app_settings�
cwd_mode�The working directory mode for notebook execution. If not specified, uses the toolchain's `default_cwd`. `execution_root` sets the working directory to Bazel's execution root, while `notebook_root` sets it to the notebook's parent directory.2""s
dataeAdditional data files required by the notebook (e.g., input data files, images, configuration files).2[]�
envxEnvironment variables to set when launching the server. Values support location expansion (e.g., `$(location :target)`).
2{}i
env_inheritTSpecifies additional environment variables to inherit from the external environment.2[]�
execute�Whether to automatically execute all notebook cells when the user opens the notebook in their browser. When True, Lab triggers 'Run All Cells' as soon as the notebook loads. Can be overridden at runtime with `-- --no-execute`.2Truej
notebook;The notebook to serve. Must be a `jupyter_notebook` target. *
JupyterNotebookInfo
PyInfo�
run_mode�Controls where the notebook is served from. `runfiles` (default) copies the notebook to a temp directory with symlinked data dependencies. `source` serves the notebook directly from the source tree for in-place editing with unrestricted file access; requires a `.ipynb` source.2
"runfiles""0
jupyter_lab!@@rules_jupyter//jupyter:defs.bzl
��,
*
nameA unique name for this target. �
�
app_settings�A JupyterLab `overrides.json` file providing default settings. Keys are `@jupyterlab/<extension>:<plugin>` and values are settings objects.2//jupyter:lab_app_settings�
�
cwd_mode�The working directory mode for notebook execution. If not specified, uses the toolchain's `default_cwd`. `execution_root` sets the working directory to Bazel's execution root, while `notebook_root` sets it to the notebook's parent directory.2""u
s
dataeAdditional data files required by the notebook (e.g., input data files, images, configuration files).2[]�
�
envxEnvironment variables to set when launching the server. Values support location expansion (e.g., `$(location :target)`).
2{}k
i
env_inheritTSpecifies additional environment variables to inherit from the external environment.2[]�
�
execute�Whether to automatically execute all notebook cells when the user opens the notebook in their browser. When True, Lab triggers 'Run All Cells' as soon as the notebook loads. Can be overridden at runtime with `-- --no-execute`.2Truel
j
notebook;The notebook to serve. Must be a `jupyter_notebook` target. *
JupyterNotebookInfo
PyInfo�
�
run_mode�Controls where the notebook is served from. `runfiles` (default) copies the notebook to a temp directory with symlinked data dependencies. `source` serves the notebook directly from the source tree for in-place editing with unrestricted file access; requires a `.ipynb` source.2
"runfiles"�jupyter_notebook�Compiles a Jupyter notebook from source and prepares it for execution.

This rule processes notebook source files and converts them to the standard `.ipynb` format.
If the source is a script in [Jupytext](https://jupytext.readthedocs.io/en/latest/) format
(e.g. a `.py`, `.jl` or `.rs` file with `# %%` / `// %%` cell markers), it will be converted
to `.ipynb` format. If the source is already a `.ipynb` file, it is used directly.

The kernel a notebook runs with is selected by name. Kernels defined with `jupyter_kernelspec`
and registered on the `jupyter_toolchain` are used when their name matches; otherwise the kernel
must be discoverable from the toolchain's Jupyter Python environment (e.g. `python3`).

Example:

```python
jupyter_notebook(
    name = "my_notebook",
    src = "notebook.py",  # or "notebook.ipynb"
    kernel = "python3",   # optional
    deps = ["@pip_deps//polars"],
    data = ["data.csv"],
)
```
"�
�
jupyter_notebook�Compiles a Jupyter notebook from source and prepares it for execution.

This rule processes notebook source files and converts them to the standard `.ipynb` format.
If the source is a script in [Jupytext](https://jupytext.readthedocs.io/en/latest/) format
(e.g. a `.py`, `.jl` or `.rs` file with `# %%` / `// %%` cell markers), it will be converted
to `.ipynb` format. If the source is already a `.ipynb` file, it is used directly.

The kernel a notebook runs with is selected by name. Kernels defined with `jupyter_kernelspec`
and registered on the `jupyter_toolchain` are used when their name matches; otherwise the kernel
must be discoverable from the toolchain's Jupyter Python environment (e.g. `python3`).

Example:

```python
jupyter_notebook(
    name = "my_notebook",
    src = "notebook.py",  # or "notebook.ipynb"
    kernel = "python3",   # optional
    deps = ["@pip_deps//polars"],
    data = ["data.csv"],
)
```
*
nameA unique name for this target. s
dataeAdditional data files required by the notebook (e.g., input data files, images, configuration files).2[]�
depslPython dependencies required by the notebook. These are typically Python packages needed for code execution.*
PyInfo2[]�
kernel�The name of the Jupyter kernel to use for executing the notebook (e.g., `python3`, `rust`). Matches `jupyter_kernelspec.kernel_name` of the kernels registered on the toolchain. If not specified, the default kernel from the toolchain is used.2""�
src�The notebook source file. Can be either a `.ipynb` file or a script in [Jupytext](https://jupytext.readthedocs.io/en/latest/) format (e.g. `.py`, `.jl`, `.rs` with `# %%` or `// %%` cell markers). "5
jupyter_notebook!@@rules_jupyter//jupyter:defs.bzl
��,
*
nameA unique name for this target. u
s
dataeAdditional data files required by the notebook (e.g., input data files, images, configuration files).2[]�
�
depslPython dependencies required by the notebook. These are typically Python packages needed for code execution.*
PyInfo2[]�
�
kernel�The name of the Jupyter kernel to use for executing the notebook (e.g., `python3`, `rust`). Matches `jupyter_kernelspec.kernel_name` of the kernels registered on the toolchain. If not specified, the default kernel from the toolchain is used.2""�
�
src�The notebook source file. Can be either a `.ipynb` file or a script in [Jupytext](https://jupytext.readthedocs.io/en/latest/) format (e.g. `.py`, `.jl`, `.rs` with `# %%` or `// %%` cell markers). �$jupyter_notebook_binary�An executable rule that runs a Jupyter notebook and optionally generates reports.

Unlike `jupyter_notebook_test`, this rule creates an executable target for use with `bazel run`.
Outputs (executed notebook and reports) are written to a configurable output directory, defaulting
to the caller's working directory (`BUILD_WORKING_DIRECTORY`).

Example:

```python
jupyter_notebook(
    name = "my_notebook",
    src = "notebook.py",
    deps = ["@pip_deps//polars"],
)

jupyter_notebook_binary(
    name = "run_notebook",
    notebook = ":my_notebook",
    reports = ["html"],
)
```

Then run: `bazel run :run_notebook` or `bazel run :run_notebook -- --my-flag value`
"�
�
jupyter_notebook_binary�An executable rule that runs a Jupyter notebook and optionally generates reports.

Unlike `jupyter_notebook_test`, this rule creates an executable target for use with `bazel run`.
Outputs (executed notebook and reports) are written to a configurable output directory, defaulting
to the caller's working directory (`BUILD_WORKING_DIRECTORY`).

Example:

```python
jupyter_notebook(
    name = "my_notebook",
    src = "notebook.py",
    deps = ["@pip_deps//polars"],
)

jupyter_notebook_binary(
    name = "run_notebook",
    notebook = ":my_notebook",
    reports = ["html"],
)
```

Then run: `bazel run :run_notebook` or `bazel run :run_notebook -- --my-flag value`
*
nameA unique name for this target. �
cwd_mode�The working directory mode for notebook execution. If not specified, uses the toolchain's `default_cwd`. `execution_root` sets the working directory to the workspace root, while `notebook_root` sets it to the notebook's parent directory. This affects how relative paths in the notebook are resolved.2""s
dataeAdditional data files required by the notebook (e.g., input data files, images, configuration files).2[]�
envzEnvironment variables to set when executing the notebook. Values support location expansion (e.g., `$(location :target)`).
2{}i
env_inheritTSpecifies additional environment variables to inherit from the external environment.2[]}
exporter_argsfTraitlets-style flags forwarded to nbconvert exporters (e.g. ``--WebPDFExporter.exclude_input=true``).2[]l
notebook=The notebook to execute. Must be a `jupyter_notebook` target. *
JupyterNotebookInfo
PyInfo�
out_dir�Directory to write output files to. If not specified, outputs are written to a subdirectory named after the target under the caller's working directory (e.g., `bazel run :run_notebook` writes to `./run_notebook/`). Absolute paths (e.g., `/tmp`) are used as-is; relative paths are resolved against the caller's working directory.2""�
reports�List of report types to generate after successful notebook execution. Valid values: `html`, `latex`, `markdown` (requires `jupyter_toolchain.pandoc`), `pdf` (requires `jupyter_toolchain.latex_engine`), `rst`, `webpdf` (requires `jupyter_toolchain.playwright_browsers_dir`).2[]"<
jupyter_notebook_binary!@@rules_jupyter//jupyter:defs.bzl
��,
*
nameA unique name for this target. �
�
cwd_mode�The working directory mode for notebook execution. If not specified, uses the toolchain's `default_cwd`. `execution_root` sets the working directory to the workspace root, while `notebook_root` sets it to the notebook's parent directory. This affects how relative paths in the notebook are resolved.2""u
s
dataeAdditional data files required by the notebook (e.g., input data files, images, configuration files).2[]�
�
envzEnvironment variables to set when executing the notebook. Values support location expansion (e.g., `$(location :target)`).
2{}k
i
env_inheritTSpecifies additional environment variables to inherit from the external environment.2[]
}
exporter_argsfTraitlets-style flags forwarded to nbconvert exporters (e.g. ``--WebPDFExporter.exclude_input=true``).2[]n
l
notebook=The notebook to execute. Must be a `jupyter_notebook` target. *
JupyterNotebookInfo
PyInfo�
�
out_dir�Directory to write output files to. If not specified, outputs are written to a subdirectory named after the target under the caller's working directory (e.g., `bazel run :run_notebook` writes to `./run_notebook/`). Absolute paths (e.g., `/tmp`) are used as-is; relative paths are resolved against the caller's working directory.2""�
�
reports�List of report types to generate after successful notebook execution. Valid values: `html`, `latex`, `markdown` (requires `jupyter_toolchain.pandoc`), `pdf` (requires `jupyter_toolchain.latex_engine`), `rst`, `webpdf` (requires `jupyter_toolchain.playwright_browsers_dir`).2[]�!jupyter_reportoExecutes a Jupyter notebook and generates reports in various formats (HTML, Markdown, LaTeX, PDF, RST, WebPDF)."� 
�
jupyter_reportoExecutes a Jupyter notebook and generates reports in various formats (HTML, Markdown, LaTeX, PDF, RST, WebPDF).*
nameA unique name for this target. R
argsDAdditional command-line arguments to pass to the notebook execution.2[]x
cwd_modefThe working directory mode for notebook execution. If not specified, uses the `jupyter_toolchain.cwd`.2""s
dataeAdditional data files required by the notebook (e.g., input data files, images, configuration files).2[]�
envzEnvironment variables to set when executing the notebook. Values support location expansion (e.g., `$(location :target)`).
2{}}
exporter_argsfTraitlets-style flags forwarded to nbconvert exporters (e.g. ``--WebPDFExporter.exclude_input=true``).2[]x
notebookIThe notebook to execute and convert. Must be a `jupyter_notebook` target. *
JupyterNotebookInfo
PyInfoj
out_html\Output path for an HTML report. If specified, the notebook will be converted to HTML format.>
out_html_template_typeTemplate type for HTML output.2""l
	out_latex]Output path for a LaTeX report. If specified, the notebook will be converted to LaTeX format.q
out_latex_template_typePDocument layout for LaTeX output. `article` (the nbconvert default) or `report`.2""�
out_markdown�Output path for a Markdown report. If specified, the notebook will be converted to Markdown format. Requires `jupyter_toolchain.pandoc`.�
out_notebookwOutput path for the executed notebook (`.ipynb` file with cell outputs). If not specified, a default name is generated.�
out_pdf�Output path for a PDF report generated via LaTeX. Requires `jupyter_toolchain.latex_engine`. For a browser rendered PDF that does not need LaTeX see `out_webpdf`.s
out_rstfOutput path for a reStructuredText report. If specified, the notebook will be converted to RST format.�

out_webpdf�Output path for a WebPDF report (generated via Playwright/Chromium). If specified, the notebook will be converted to PDF format using headless browser rendering. Requires `jupyter_toolchain.playwright_browsers_dir`."3
jupyter_report!@@rules_jupyter//jupyter:defs.bzl
��,
*
nameA unique name for this target. T
R
argsDAdditional command-line arguments to pass to the notebook execution.2[]z
x
cwd_modefThe working directory mode for notebook execution. If not specified, uses the `jupyter_toolchain.cwd`.2""u
s
dataeAdditional data files required by the notebook (e.g., input data files, images, configuration files).2[]�
�
envzEnvironment variables to set when executing the notebook. Values support location expansion (e.g., `$(location :target)`).
2{}
}
exporter_argsfTraitlets-style flags forwarded to nbconvert exporters (e.g. ``--WebPDFExporter.exclude_input=true``).2[]z
x
notebookIThe notebook to execute and convert. Must be a `jupyter_notebook` target. *
JupyterNotebookInfo
PyInfol
j
out_html\Output path for an HTML report. If specified, the notebook will be converted to HTML format.@
>
out_html_template_typeTemplate type for HTML output.2""n
l
	out_latex]Output path for a LaTeX report. If specified, the notebook will be converted to LaTeX format.s
q
out_latex_template_typePDocument layout for LaTeX output. `article` (the nbconvert default) or `report`.2""�
�
out_markdown�Output path for a Markdown report. If specified, the notebook will be converted to Markdown format. Requires `jupyter_toolchain.pandoc`.�
�
out_notebookwOutput path for the executed notebook (`.ipynb` file with cell outputs). If not specified, a default name is generated.�
�
out_pdf�Output path for a PDF report generated via LaTeX. Requires `jupyter_toolchain.latex_engine`. For a browser rendered PDF that does not need LaTeX see `out_webpdf`.u
s
out_rstfOutput path for a reStructuredText report. If specified, the notebook will be converted to RST format.�
�

out_webpdf�Output path for a WebPDF report (generated via Playwright/Chromium). If specified, the notebook will be converted to PDF format using headless browser rendering. Requires `jupyter_toolchain.playwright_browsers_dir`.�;jupyter_toolchain�	Defines a Jupyter toolchain that provides Jupyter, Jupytext, Pandoc, Playwright browser, LaTeX support and
additional kernels.

Kernels for languages other than Python are defined with `jupyter_kernelspec` and attached via `kernels`.
A single toolchain can serve notebooks of many languages; each notebook selects a kernel by name with
`jupyter_notebook.kernel`. Kernels not listed here (such as `python3` from `ipykernel`) are expected to be
discoverable from the `jupyter` Python environment.

LaTeX (used for `pdf` reports) is optional. The [texlive](https://registry.bazel.build/modules/texlive)
module from the Bazel Central Registry provides everything required:

```python
jupyter_toolchain(
    name = "jupyter_toolchain",
    jupyter = "@pip_deps//jupyter",
    jupytext = "@pip_deps//jupytext",
    pandoc = "@pandoc",
    latex_engine = "@texlive//texk/web2c:pdftex",
    latex_format = "@texlive//:pdflatex_fmt",
    latex_texmf_cnf = "@texlive-texmf//:web2c/texmf.cnf",
    latex_data = [
        "@texlive//:texmf/fonts",
        "@texlive//:texmf/tex_inputs",
        "@texlive//:texmf/web2c_data",
    ],
    bibtex = "@texlive//texk/bibtex-x:bibtex8",
)
```
"�1
�
jupyter_toolchain�	Defines a Jupyter toolchain that provides Jupyter, Jupytext, Pandoc, Playwright browser, LaTeX support and
additional kernels.

Kernels for languages other than Python are defined with `jupyter_kernelspec` and attached via `kernels`.
A single toolchain can serve notebooks of many languages; each notebook selects a kernel by name with
`jupyter_notebook.kernel`. Kernels not listed here (such as `python3` from `ipykernel`) are expected to be
discoverable from the `jupyter` Python environment.

LaTeX (used for `pdf` reports) is optional. The [texlive](https://registry.bazel.build/modules/texlive)
module from the Bazel Central Registry provides everything required:

```python
jupyter_toolchain(
    name = "jupyter_toolchain",
    jupyter = "@pip_deps//jupyter",
    jupytext = "@pip_deps//jupytext",
    pandoc = "@pandoc",
    latex_engine = "@texlive//texk/web2c:pdftex",
    latex_format = "@texlive//:pdflatex_fmt",
    latex_texmf_cnf = "@texlive-texmf//:web2c/texmf.cnf",
    latex_data = [
        "@texlive//:texmf/fonts",
        "@texlive//:texmf/tex_inputs",
        "@texlive//:texmf/web2c_data",
    ],
    bibtex = "@texlive//texk/bibtex-x:bibtex8",
)
```
*
nameA unique name for this target. �
bibtex�An optional BibTeX executable (e.g. `@texlive//texk/bibtex-x:bibtex8`). When unset, the bibliography pass of PDF generation is skipped.2None�
cwd_mode�The default working directory mode for notebook execution. This value is used when `cwd_mode` is not specified in `jupyter_report` or `jupyter_notebook_test` rules. `workspace_root` sets the working directory to the workspace root, while `notebook_root` sets it to the notebook's parent directory. This affects how relative paths in notebooks are resolved.2"execution_root"�
exporter_args�Default traitlets-style flags forwarded to nbconvert exporters for all rules using this toolchain (e.g. ``--WebPDFExporter.exclude_input=true``). Per-rule ``exporter_args`` are appended after these defaults, allowing overrides.2[]^
jupyterEThe Jupyter Python package providing notebook execution capabilities. *
PyInfo�
jupytext�The [Jupytext](https://jupytext.readthedocs.io/en/latest/) Python package for converting between notebook formats (e.g., .py to .ipynb). *
PyInfo}
kernelmDefault kernel name to use for notebook execution if not specified in the notebook (e.g., 'python3', 'rust').2""�
kernels�`jupyter_kernelspec` targets made available to notebooks using this toolchain. A kernel is only added to the inputs of a notebook when the notebook selects it by name via `jupyter_notebook.kernel` or `kernel`.*
JupyterKernelspecInfo2[]�

latex_data�texmf trees (fonts, macro packages, `web2c` configuration) required by `latex_engine` at runtime. These files are only added to actions and runfiles that produce PDF output.2[]�
latex_engine�A TeX engine executable used for `pdf` reports (e.g. `@texlive//texk/web2c:pdftex`). Requires `latex_format` and `latex_texmf_cnf`.2None�
latex_format~A precompiled LaTeX format file for `latex_engine` (e.g. `@texlive//:pdflatex_fmt`). The engine is invoked with `-fmt=<stem>`.2None�
latex_texmf_cnf�The `web2c/texmf.cnf` file of the texmf tree (e.g. `@texlive-texmf//:web2c/texmf.cnf`). Its directory becomes `TEXMFCNF` and its parent becomes `TEXMF`.2Nonet
pandocbThe Pandoc executable for converting notebooks to various output formats (HTML, LaTeX, PDF, etc.).2None^
playwright_browsers_dir;A directory containing the results of `playwright install`.2None{
playwright_ld_library_dirVA directory of shared libraries to prepend to LD_LIBRARY_PATH when launching browsers.2None"6
jupyter_toolchain!@@rules_jupyter//jupyter:defs.bzl
vv,
*
nameA unique name for this target. �
�
bibtex�An optional BibTeX executable (e.g. `@texlive//texk/bibtex-x:bibtex8`). When unset, the bibliography pass of PDF generation is skipped.2None�
�
cwd_mode�The default working directory mode for notebook execution. This value is used when `cwd_mode` is not specified in `jupyter_report` or `jupyter_notebook_test` rules. `workspace_root` sets the working directory to the workspace root, while `notebook_root` sets it to the notebook's parent directory. This affects how relative paths in notebooks are resolved.2"execution_root"�
�
exporter_args�Default traitlets-style flags forwarded to nbconvert exporters for all rules using this toolchain (e.g. ``--WebPDFExporter.exclude_input=true``). Per-rule ``exporter_args`` are appended after these defaults, allowing overrides.2[]`
^
jupyterEThe Jupyter Python package providing notebook execution capabilities. *
PyInfo�
�
jupytext�The [Jupytext](https://jupytext.readthedocs.io/en/latest/) Python package for converting between notebook formats (e.g., .py to .ipynb). *
PyInfo
}
kernelmDefault kernel name to use for notebook execution if not specified in the notebook (e.g., 'python3', 'rust').2""�
�
kernels�`jupyter_kernelspec` targets made available to notebooks using this toolchain. A kernel is only added to the inputs of a notebook when the notebook selects it by name via `jupyter_notebook.kernel` or `kernel`.*
JupyterKernelspecInfo2[]�
�

latex_data�texmf trees (fonts, macro packages, `web2c` configuration) required by `latex_engine` at runtime. These files are only added to actions and runfiles that produce PDF output.2[]�
�
latex_engine�A TeX engine executable used for `pdf` reports (e.g. `@texlive//texk/web2c:pdftex`). Requires `latex_format` and `latex_texmf_cnf`.2None�
�
latex_format~A precompiled LaTeX format file for `latex_engine` (e.g. `@texlive//:pdflatex_fmt`). The engine is invoked with `-fmt=<stem>`.2None�
�
latex_texmf_cnf�The `web2c/texmf.cnf` file of the texmf tree (e.g. `@texlive-texmf//:web2c/texmf.cnf`). Its directory becomes `TEXMFCNF` and its parent becomes `TEXMF`.2Nonev
t
pandocbThe Pandoc executable for converting notebooks to various output formats (HTML, LaTeX, PDF, etc.).2None`
^
playwright_browsers_dir;A directory containing the results of `playwright install`.2None}
{
playwright_ld_library_dirVA directory of shared libraries to prepend to LD_LIBRARY_PATH when launching browsers.2None�JupyterKernelspecInfoIProvider describing a Jupyter kernel that notebooks can be executed with.2�
�
JupyterKernelspecInfoIProvider describing a Jupyter kernel that notebooks can be executed with.�
args_templatezFile: A code cell template used to forward notebook `args` to the kernel, or `None` when the kernel does not support args.o
argvgList[str]: The kernel launch command. File references are rlocationpaths which are resolved at runtime.4
display_name$str: The human readable kernel name.H
envADict[str, str]: Environment variables set for the kernel process.C
files:Depset[File]: All files required by the kernel at runtime.u
interrupt_modecstr: The Jupyter interrupt mode (`signal` or `message`) or an empty string for the Jupyter default.\
kernel_nameMstr: The kernel name used by `jupyter_notebook.kernel` and notebook metadata.M
languageAstr: The language of the kernel (e.g. `python`, `julia`, `rust`).�

path_tools�List[str]: rlocationpaths of the `path_tools` executables. The directory of each resolved file is prepended to `PATH` for the kernel process.n

rlocations`Dict[str, File]: Every file referenced by `argv`, `env` or `path_tools`, keyed by rlocationpath.1
runfiles%runfiles: The runfiles of the kernel.d
spec\File: A json file describing the kernelspec, consumed by the rules_jupyter process wrappers.�
tools{List[FilesToRunProvider]: Executables used by the kernel. Passed as tools to build actions so their runfiles are available.�
	transportsstr: The ZeroMQ transport (`ipc` or `tcp`) used to talk to the kernel, or an empty string for the platform default.":
JupyterKernelspecInfo!@@rules_jupyter//jupyter:defs.bzl
!!�
�
args_templatezFile: A code cell template used to forward notebook `args` to the kernel, or `None` when the kernel does not support args.q
o
argvgList[str]: The kernel launch command. File references are rlocationpaths which are resolved at runtime.6
4
display_name$str: The human readable kernel name.J
H
envADict[str, str]: Environment variables set for the kernel process.E
C
files:Depset[File]: All files required by the kernel at runtime.w
u
interrupt_modecstr: The Jupyter interrupt mode (`signal` or `message`) or an empty string for the Jupyter default.^
\
kernel_nameMstr: The kernel name used by `jupyter_notebook.kernel` and notebook metadata.O
M
languageAstr: The language of the kernel (e.g. `python`, `julia`, `rust`).�
�

path_tools�List[str]: rlocationpaths of the `path_tools` executables. The directory of each resolved file is prepended to `PATH` for the kernel process.p
n

rlocations`Dict[str, File]: Every file referenced by `argv`, `env` or `path_tools`, keyed by rlocationpath.3
1
runfiles%runfiles: The runfiles of the kernel.f
d
spec\File: A json file describing the kernelspec, consumed by the rules_jupyter process wrappers.�
�
tools{List[FilesToRunProvider]: Executables used by the kernel. Passed as tools to build actions so their runfiles are available.�
�
	transportsstr: The ZeroMQ transport (`ipc` or `tcp`) used to talk to the kernel, or an empty string for the platform default.�
 //jupyter:jupyter_kernelspec.bzlr�
0
rules_jupyterjupyterjupyter_kernelspec.bzl=
JupyterKernelspecInfo_JupyterKernelspecInfo
7
jupyter_kernelspec_jupyter_kernelspec

�
//jupyter:jupyter_lab.bzlrd
)
rules_jupyterjupyterjupyter_lab.bzl)
jupyter_lab_jupyter_lab



�
//jupyter:jupyter_notebook.bzlrs
.
rules_jupyterjupyterjupyter_notebook.bzl3
jupyter_notebook_jupyter_notebook

�
%//jupyter:jupyter_notebook_binary.bzlr�
5
rules_jupyterjupyterjupyter_notebook_binary.bzlA
jupyter_notebook_binary_jupyter_notebook_binary

�
#//jupyter:jupyter_notebook_test.bzlr�
3
rules_jupyterjupyterjupyter_notebook_test.bzl=
jupyter_notebook_test_jupyter_notebook_test

�
//jupyter:jupyter_report.bzlrm
,
rules_jupyterjupyterjupyter_report.bzl/
jupyter_report_jupyter_report

�
//jupyter:jupyter_toolchain.bzlrv
/
rules_jupyterjupyterjupyter_toolchain.bzl5
jupyter_toolchain_jupyter_toolchain

# Jupyter rules�
(
rules_jupyterjupyterextensions.bzl�	jupyterJupyter dependencies.J�
�
jupyterJupyter dependencies.�
pandocrTag class for configuring Pandoc in the Jupyter module extension. Use this to specify which Pandoc version to use.{
nameoName of the Pandoc repository to create. This name can be referenced in use_repo() to access the Pandoc binary. �
versionpPandoc version to use. Must be one of the versions available in PANDOC_VERSIONS. Defaults to the latest version.2"3.8.2""2
jupyter'@@rules_jupyter//jupyter:extensions.bzl
VV�
�
pandocrTag class for configuring Pandoc in the Jupyter module extension. Use this to specify which Pandoc version to use.{
nameoName of the Pandoc repository to create. This name can be referenced in use_repo() to access the Pandoc binary. �
versionpPandoc version to use. Must be one of the versions available in PANDOC_VERSIONS. Defaults to the latest version.2"3.8.2"}
{
nameoName of the Pandoc repository to create. This name can be referenced in use_repo() to access the Pandoc binary. �
�
versionpPandoc version to use. Must be one of the versions available in PANDOC_VERSIONS. Defaults to the latest version.2"3.8.2"�
playwright Playwright browser dependencies.J�

�

playwright Playwright browser dependencies.�
	toolchain"Playwright toolchain configurationC
name Name of the toolchain repository2"playwright_toolchains"�
version�Playwright version (e.g., '1.57.0'). Browser versions will be auto-selected based on this. Mutually exclusive with `version_from_requirements`.2""�
version_from_requirementstA python `requirements.txt` file used for parsing the desired `playwright` version. Mutually exclusive with version.2None"5

playwright'@@rules_jupyter//jupyter:extensions.bzl
���
�
	toolchain"Playwright toolchain configurationC
name Name of the toolchain repository2"playwright_toolchains"�
version�Playwright version (e.g., '1.57.0'). Browser versions will be auto-selected based on this. Mutually exclusive with `version_from_requirements`.2""�
version_from_requirementstA python `requirements.txt` file used for parsing the desired `playwright` version. Mutually exclusive with version.2NoneE
C
name Name of the toolchain repository2"playwright_toolchains"�
�
version�Playwright version (e.g., '1.57.0'). Browser versions will be auto-selected based on this. Mutually exclusive with `version_from_requirements`.2""�
�
version_from_requirementstA python `requirements.txt` file used for parsing the desired `playwright` version. Mutually exclusive with version.2None�
//jupyter/private:pandoc.bzlr�
,
rules_jupyterjupyter/private
pandoc.bzl>
DEFAULT_PANDOC_VERSIONDEFAULT_PANDOC_VERSION
0
PANDOC_VERSIONSPANDOC_VERSIONS
@
pandoc_alias_repositorypandoc_alias_repository
.
pandoc_archivepandoc_archive

	�
#//playwright/private:extensions.bzlrl
3
rules_jupyterplaywright/privateextensions.bzl'

playwright_playwright

# Jupyter bzlmod extensions�S
0
rules_jupyterjupyterjupyter_kernelspec.bzl�7jupyter_kernelspec�
Defines a [Jupyter kernel](https://jupyter-client.readthedocs.io/en/latest/kernels.html) that notebooks can be executed with.

The rule is language agnostic. It describes how to launch a kernel process in the same way a
`kernel.json` file does, but with files tracked by Bazel. Kernels are attached to a
`jupyter_toolchain` via its `kernels` attribute and selected by notebooks using
`jupyter_notebook.kernel` (or `jupyter_toolchain.kernel` for a default).

File references in `argv` and `env` use `$(rlocationpath ...)` expansion over the targets in
`data`. The rules resolve them to real paths wherever the notebook is executed (build actions,
tests, `bazel run` and Jupyter Lab). Jupyter's own `{connection_file}` placeholder and `${VAR}`
environment substitution continue to work.

Example:

```python
jupyter_kernelspec(
    name = "julia",
    display_name = "Julia",
    language = "julia",
    argv = [
        "$(rlocationpath :ijulia_kernel)",
        "{connection_file}",
    ],
    data = [":ijulia_kernel"],
    # A file containing `empty!(ARGS); append!(ARGS, {args})`.
    args_template = "args_template.jl",
)

jupyter_toolchain(
    name = "jupyter_toolchain",
    kernels = [":julia"],
    ...
)

jupyter_notebook(
    name = "notebook",
    src = "notebook.jl",
    kernel = "julia",
)
```
"�,
�
jupyter_kernelspec�
Defines a [Jupyter kernel](https://jupyter-client.readthedocs.io/en/latest/kernels.html) that notebooks can be executed with.

The rule is language agnostic. It describes how to launch a kernel process in the same way a
`kernel.json` file does, but with files tracked by Bazel. Kernels are attached to a
`jupyter_toolchain` via its `kernels` attribute and selected by notebooks using
`jupyter_notebook.kernel` (or `jupyter_toolchain.kernel` for a default).

File references in `argv` and `env` use `$(rlocationpath ...)` expansion over the targets in
`data`. The rules resolve them to real paths wherever the notebook is executed (build actions,
tests, `bazel run` and Jupyter Lab). Jupyter's own `{connection_file}` placeholder and `${VAR}`
environment substitution continue to work.

Example:

```python
jupyter_kernelspec(
    name = "julia",
    display_name = "Julia",
    language = "julia",
    argv = [
        "$(rlocationpath :ijulia_kernel)",
        "{connection_file}",
    ],
    data = [":ijulia_kernel"],
    # A file containing `empty!(ARGS); append!(ARGS, {args})`.
    args_template = "args_template.jl",
)

jupyter_toolchain(
    name = "jupyter_toolchain",
    kernels = [":julia"],
    ...
)

jupyter_notebook(
    name = "notebook",
    src = "notebook.jl",
    kernel = "julia",
)
```
*
nameA unique name for this target. �
args_template�A file holding a code cell template used to forward `args` of `jupyter_notebook_test`, `jupyter_notebook_binary`, `jupyter_report` and `jupyter_lab` to the notebook. The cell is prepended to the notebook before execution. The only placeholder is `{args}`, replaced by a JSON array of the arguments (e.g. a file containing `empty!(ARGS); append!(ARGS, {args})` for Julia); other braces are left as they are. When unset, notebooks using this kernel cannot be given `args`.2None�
argv�The command used to launch the kernel. Supports `$(rlocationpath ...)` expansion for targets in `data` and `path_tools` as well as Jupyter's `{connection_file}` placeholder. �
data~Files and executables required by the kernel at runtime. These are the targets available for `$(rlocationpath ...)` expansion.2[]W
display_nameAThe human readable name of the kernel. Defaults to `kernel_name`.2""�
env�Environment variables for the kernel process. Values support `$(rlocationpath ...)` expansion and Jupyter's `${VAR}` substitution with the environment of the process launching the kernel.
2{}�
interrupt_mode�How the kernel is interrupted. `signal` sends `SIGINT`, `message` sends an `interrupt_request`. Defaults to Jupyter's default (`signal`).2""�
kernel_nameuThe name of the kernel as referenced by `jupyter_notebook.kernel` and notebook metadata. Defaults to the target name.2""�
language�The language of the kernel (e.g. `python`, `julia`, `rust`). Recorded in notebook metadata and used by exporters for syntax highlighting. �

path_tools�Executables whose parent directories are prepended to `PATH` for the kernel process. Useful for kernels that shell out to compilers or interpreters. Each target must provide exactly one file.2[]�
	transport�The ZeroMQ transport used to talk to the kernel. Defaults to `ipc` on Unix, which avoids port collisions between notebooks Bazel runs in parallel, and `tcp` on Windows. Kernels whose ZeroMQ lacks IPC support (e.g. prebuilt `evcxr_jupyter` binaries) must set `tcp`.2"""E
jupyter_kernelspec/@@rules_jupyter//jupyter:jupyter_kernelspec.bzl
kk,
*
nameA unique name for this target. �
�
args_template�A file holding a code cell template used to forward `args` of `jupyter_notebook_test`, `jupyter_notebook_binary`, `jupyter_report` and `jupyter_lab` to the notebook. The cell is prepended to the notebook before execution. The only placeholder is `{args}`, replaced by a JSON array of the arguments (e.g. a file containing `empty!(ARGS); append!(ARGS, {args})` for Julia); other braces are left as they are. When unset, notebooks using this kernel cannot be given `args`.2None�
�
argv�The command used to launch the kernel. Supports `$(rlocationpath ...)` expansion for targets in `data` and `path_tools` as well as Jupyter's `{connection_file}` placeholder. �
�
data~Files and executables required by the kernel at runtime. These are the targets available for `$(rlocationpath ...)` expansion.2[]Y
W
display_nameAThe human readable name of the kernel. Defaults to `kernel_name`.2""�
�
env�Environment variables for the kernel process. Values support `$(rlocationpath ...)` expansion and Jupyter's `${VAR}` substitution with the environment of the process launching the kernel.
2{}�
�
interrupt_mode�How the kernel is interrupted. `signal` sends `SIGINT`, `message` sends an `interrupt_request`. Defaults to Jupyter's default (`signal`).2""�
�
kernel_nameuThe name of the kernel as referenced by `jupyter_notebook.kernel` and notebook metadata. Defaults to the target name.2""�
�
language�The language of the kernel (e.g. `python`, `julia`, `rust`). Recorded in notebook metadata and used by exporters for syntax highlighting. �
�

path_tools�Executables whose parent directories are prepended to `PATH` for the kernel process. Useful for kernels that shell out to compilers or interpreters. Each target must provide exactly one file.2[]�
�
	transport�The ZeroMQ transport used to talk to the kernel. Defaults to `ipc` on Unix, which avoids port collisions between notebooks Bazel runs in parallel, and `tcp` on Windows. Kernels whose ZeroMQ lacks IPC support (e.g. prebuilt `evcxr_jupyter` binaries) must set `tcp`.2""�JupyterKernelspecInfoIProvider describing a Jupyter kernel that notebooks can be executed with.2�
�
JupyterKernelspecInfoIProvider describing a Jupyter kernel that notebooks can be executed with.�
args_templatezFile: A code cell template used to forward notebook `args` to the kernel, or `None` when the kernel does not support args.o
argvgList[str]: The kernel launch command. File references are rlocationpaths which are resolved at runtime.4
display_name$str: The human readable kernel name.H
envADict[str, str]: Environment variables set for the kernel process.C
files:Depset[File]: All files required by the kernel at runtime.u
interrupt_modecstr: The Jupyter interrupt mode (`signal` or `message`) or an empty string for the Jupyter default.\
kernel_nameMstr: The kernel name used by `jupyter_notebook.kernel` and notebook metadata.M
languageAstr: The language of the kernel (e.g. `python`, `julia`, `rust`).�

path_tools�List[str]: rlocationpaths of the `path_tools` executables. The directory of each resolved file is prepended to `PATH` for the kernel process.n

rlocations`Dict[str, File]: Every file referenced by `argv`, `env` or `path_tools`, keyed by rlocationpath.1
runfiles%runfiles: The runfiles of the kernel.d
spec\File: A json file describing the kernelspec, consumed by the rules_jupyter process wrappers.�
tools{List[FilesToRunProvider]: Executables used by the kernel. Passed as tools to build actions so their runfiles are available.�
	transportsstr: The ZeroMQ transport (`ipc` or `tcp`) used to talk to the kernel, or an empty string for the platform default."H
JupyterKernelspecInfo/@@rules_jupyter//jupyter:jupyter_kernelspec.bzl
!!�
�
args_templatezFile: A code cell template used to forward notebook `args` to the kernel, or `None` when the kernel does not support args.q
o
argvgList[str]: The kernel launch command. File references are rlocationpaths which are resolved at runtime.6
4
display_name$str: The human readable kernel name.J
H
envADict[str, str]: Environment variables set for the kernel process.E
C
files:Depset[File]: All files required by the kernel at runtime.w
u
interrupt_modecstr: The Jupyter interrupt mode (`signal` or `message`) or an empty string for the Jupyter default.^
\
kernel_nameMstr: The kernel name used by `jupyter_notebook.kernel` and notebook metadata.O
M
languageAstr: The language of the kernel (e.g. `python`, `julia`, `rust`).�
�

path_tools�List[str]: rlocationpaths of the `path_tools` executables. The directory of each resolved file is prepended to `PATH` for the kernel process.p
n

rlocations`Dict[str, File]: Every file referenced by `argv`, `env` or `path_tools`, keyed by rlocationpath.3
1
runfiles%runfiles: The runfiles of the kernel.f
d
spec\File: A json file describing the kernelspec, consumed by the rules_jupyter process wrappers.�
�
tools{List[FilesToRunProvider]: Executables used by the kernel. Passed as tools to build actions so their runfiles are available.�
�
	transportsstr: The ZeroMQ transport (`ipc` or `tcp`) used to talk to the kernel, or an empty string for the platform default.�
 //jupyter/private:kernelspec.bzlry
0
rules_jupyterjupyter/privatekernelspec.bzl7
jupyter_kernelspec_jupyter_kernelspec

�
//jupyter/private:providers.bzlr~
/
rules_jupyterjupyter/privateproviders.bzl=
JupyterKernelspecInfo_JupyterKernelspecInfo
		

# jupyter_kernelspec�$
)
rules_jupyterjupyterjupyter_lab.bzl�"jupyter_lab�Launches a Jupyter Lab server for interactive notebook development.

This rule creates an executable target that, when run via `bazel run`, starts a Jupyter Lab
server with the notebook's dependencies available in the virtualenv. By default, when a user
opens the printed URL in their browser, all notebook cells are automatically executed â exactly
as if the user clicked "Run All Cells" in Lab's Run menu.

Example:

```python
jupyter_notebook(
    name = "my_notebook",
    src = "notebook.py",
    deps = ["@pip_deps//polars"],
)

jupyter_lab(
    name = "my_lab",
    notebook = ":my_notebook",
)
```

Then run: `bazel run :my_lab`
"�
�
jupyter_lab�Launches a Jupyter Lab server for interactive notebook development.

This rule creates an executable target that, when run via `bazel run`, starts a Jupyter Lab
server with the notebook's dependencies available in the virtualenv. By default, when a user
opens the printed URL in their browser, all notebook cells are automatically executed â exactly
as if the user clicked "Run All Cells" in Lab's Run menu.

Example:

```python
jupyter_notebook(
    name = "my_notebook",
    src = "notebook.py",
    deps = ["@pip_deps//polars"],
)

jupyter_lab(
    name = "my_lab",
    notebook = ":my_notebook",
)
```

Then run: `bazel run :my_lab`
*
nameA unique name for this target. �
app_settings�A JupyterLab `overrides.json` file providing default settings. Keys are `@jupyterlab/<extension>:<plugin>` and values are settings objects.2//jupyter:lab_app_settings�
cwd_mode�The working directory mode for notebook execution. If not specified, uses the toolchain's `default_cwd`. `execution_root` sets the working directory to Bazel's execution root, while `notebook_root` sets it to the notebook's parent directory.2""s
dataeAdditional data files required by the notebook (e.g., input data files, images, configuration files).2[]�
envxEnvironment variables to set when launching the server. Values support location expansion (e.g., `$(location :target)`).
2{}i
env_inheritTSpecifies additional environment variables to inherit from the external environment.2[]�
execute�Whether to automatically execute all notebook cells when the user opens the notebook in their browser. When True, Lab triggers 'Run All Cells' as soon as the notebook loads. Can be overridden at runtime with `-- --no-execute`.2Truej
notebook;The notebook to serve. Must be a `jupyter_notebook` target. *
JupyterNotebookInfo
PyInfo�
run_mode�Controls where the notebook is served from. `runfiles` (default) copies the notebook to a temp directory with symlinked data dependencies. `source` serves the notebook directly from the source tree for in-place editing with unrestricted file access; requires a `.ipynb` source.2
"runfiles""7
jupyter_lab(@@rules_jupyter//jupyter:jupyter_lab.bzl
��,
*
nameA unique name for this target. �
�
app_settings�A JupyterLab `overrides.json` file providing default settings. Keys are `@jupyterlab/<extension>:<plugin>` and values are settings objects.2//jupyter:lab_app_settings�
�
cwd_mode�The working directory mode for notebook execution. If not specified, uses the toolchain's `default_cwd`. `execution_root` sets the working directory to Bazel's execution root, while `notebook_root` sets it to the notebook's parent directory.2""u
s
dataeAdditional data files required by the notebook (e.g., input data files, images, configuration files).2[]�
�
envxEnvironment variables to set when launching the server. Values support location expansion (e.g., `$(location :target)`).
2{}k
i
env_inheritTSpecifies additional environment variables to inherit from the external environment.2[]�
�
execute�Whether to automatically execute all notebook cells when the user opens the notebook in their browser. When True, Lab triggers 'Run All Cells' as soon as the notebook loads. Can be overridden at runtime with `-- --no-execute`.2Truel
j
notebook;The notebook to serve. Must be a `jupyter_notebook` target. *
JupyterNotebookInfo
PyInfo�
�
run_mode�Controls where the notebook is served from. `runfiles` (default) copies the notebook to a temp directory with symlinked data dependencies. `source` serves the notebook directly from the source tree for in-place editing with unrestricted file access; requires a `.ipynb` source.2
"runfiles"�
//jupyter/private:jupyter.bzlrh
-
rules_jupyterjupyter/privatejupyter.bzl)
jupyter_lab_jupyter_lab

# jupyter_lab�
.
rules_jupyterjupyterjupyter_notebook.bzl�jupyter_notebook�Compiles a Jupyter notebook from source and prepares it for execution.

This rule processes notebook source files and converts them to the standard `.ipynb` format.
If the source is a script in [Jupytext](https://jupytext.readthedocs.io/en/latest/) format
(e.g. a `.py`, `.jl` or `.rs` file with `# %%` / `// %%` cell markers), it will be converted
to `.ipynb` format. If the source is already a `.ipynb` file, it is used directly.

The kernel a notebook runs with is selected by name. Kernels defined with `jupyter_kernelspec`
and registered on the `jupyter_toolchain` are used when their name matches; otherwise the kernel
must be discoverable from the toolchain's Jupyter Python environment (e.g. `python3`).

Example:

```python
jupyter_notebook(
    name = "my_notebook",
    src = "notebook.py",  # or "notebook.ipynb"
    kernel = "python3",   # optional
    deps = ["@pip_deps//polars"],
    data = ["data.csv"],
)
```
"�
�
jupyter_notebook�Compiles a Jupyter notebook from source and prepares it for execution.

This rule processes notebook source files and converts them to the standard `.ipynb` format.
If the source is a script in [Jupytext](https://jupytext.readthedocs.io/en/latest/) format
(e.g. a `.py`, `.jl` or `.rs` file with `# %%` / `// %%` cell markers), it will be converted
to `.ipynb` format. If the source is already a `.ipynb` file, it is used directly.

The kernel a notebook runs with is selected by name. Kernels defined with `jupyter_kernelspec`
and registered on the `jupyter_toolchain` are used when their name matches; otherwise the kernel
must be discoverable from the toolchain's Jupyter Python environment (e.g. `python3`).

Example:

```python
jupyter_notebook(
    name = "my_notebook",
    src = "notebook.py",  # or "notebook.ipynb"
    kernel = "python3",   # optional
    deps = ["@pip_deps//polars"],
    data = ["data.csv"],
)
```
*
nameA unique name for this target. s
dataeAdditional data files required by the notebook (e.g., input data files, images, configuration files).2[]�
depslPython dependencies required by the notebook. These are typically Python packages needed for code execution.*
PyInfo2[]�
kernel�The name of the Jupyter kernel to use for executing the notebook (e.g., `python3`, `rust`). Matches `jupyter_kernelspec.kernel_name` of the kernels registered on the toolchain. If not specified, the default kernel from the toolchain is used.2""�
src�The notebook source file. Can be either a `.ipynb` file or a script in [Jupytext](https://jupytext.readthedocs.io/en/latest/) format (e.g. `.py`, `.jl`, `.rs` with `# %%` or `// %%` cell markers). "A
jupyter_notebook-@@rules_jupyter//jupyter:jupyter_notebook.bzl
��,
*
nameA unique name for this target. u
s
dataeAdditional data files required by the notebook (e.g., input data files, images, configuration files).2[]�
�
depslPython dependencies required by the notebook. These are typically Python packages needed for code execution.*
PyInfo2[]�
�
kernel�The name of the Jupyter kernel to use for executing the notebook (e.g., `python3`, `rust`). Matches `jupyter_kernelspec.kernel_name` of the kernels registered on the toolchain. If not specified, the default kernel from the toolchain is used.2""�
�
src�The notebook source file. Can be either a `.ipynb` file or a script in [Jupytext](https://jupytext.readthedocs.io/en/latest/) format (e.g. `.py`, `.jl`, `.rs` with `# %%` or `// %%` cell markers). �
//jupyter/private:jupyter.bzlrr
-
rules_jupyterjupyter/privatejupyter.bzl3
jupyter_notebook_jupyter_notebook

# jupyter_notebook�&
5
rules_jupyterjupyterjupyter_notebook_binary.bzl�$jupyter_notebook_binary�An executable rule that runs a Jupyter notebook and optionally generates reports.

Unlike `jupyter_notebook_test`, this rule creates an executable target for use with `bazel run`.
Outputs (executed notebook and reports) are written to a configurable output directory, defaulting
to the caller's working directory (`BUILD_WORKING_DIRECTORY`).

Example:

```python
jupyter_notebook(
    name = "my_notebook",
    src = "notebook.py",
    deps = ["@pip_deps//polars"],
)

jupyter_notebook_binary(
    name = "run_notebook",
    notebook = ":my_notebook",
    reports = ["html"],
)
```

Then run: `bazel run :run_notebook` or `bazel run :run_notebook -- --my-flag value`
"�
�
jupyter_notebook_binary�An executable rule that runs a Jupyter notebook and optionally generates reports.

Unlike `jupyter_notebook_test`, this rule creates an executable target for use with `bazel run`.
Outputs (executed notebook and reports) are written to a configurable output directory, defaulting
to the caller's working directory (`BUILD_WORKING_DIRECTORY`).

Example:

```python
jupyter_notebook(
    name = "my_notebook",
    src = "notebook.py",
    deps = ["@pip_deps//polars"],
)

jupyter_notebook_binary(
    name = "run_notebook",
    notebook = ":my_notebook",
    reports = ["html"],
)
```

Then run: `bazel run :run_notebook` or `bazel run :run_notebook -- --my-flag value`
*
nameA unique name for this target. �
cwd_mode�The working directory mode for notebook execution. If not specified, uses the toolchain's `default_cwd`. `execution_root` sets the working directory to the workspace root, while `notebook_root` sets it to the notebook's parent directory. This affects how relative paths in the notebook are resolved.2""s
dataeAdditional data files required by the notebook (e.g., input data files, images, configuration files).2[]�
envzEnvironment variables to set when executing the notebook. Values support location expansion (e.g., `$(location :target)`).
2{}i
env_inheritTSpecifies additional environment variables to inherit from the external environment.2[]}
exporter_argsfTraitlets-style flags forwarded to nbconvert exporters (e.g. ``--WebPDFExporter.exclude_input=true``).2[]l
notebook=The notebook to execute. Must be a `jupyter_notebook` target. *
JupyterNotebookInfo
PyInfo�
out_dir�Directory to write output files to. If not specified, outputs are written to a subdirectory named after the target under the caller's working directory (e.g., `bazel run :run_notebook` writes to `./run_notebook/`). Absolute paths (e.g., `/tmp`) are used as-is; relative paths are resolved against the caller's working directory.2""�
reports�List of report types to generate after successful notebook execution. Valid values: `html`, `latex`, `markdown` (requires `jupyter_toolchain.pandoc`), `pdf` (requires `jupyter_toolchain.latex_engine`), `rst`, `webpdf` (requires `jupyter_toolchain.playwright_browsers_dir`).2[]"O
jupyter_notebook_binary4@@rules_jupyter//jupyter:jupyter_notebook_binary.bzl
��,
*
nameA unique name for this target. �
�
cwd_mode�The working directory mode for notebook execution. If not specified, uses the toolchain's `default_cwd`. `execution_root` sets the working directory to the workspace root, while `notebook_root` sets it to the notebook's parent directory. This affects how relative paths in the notebook are resolved.2""u
s
dataeAdditional data files required by the notebook (e.g., input data files, images, configuration files).2[]�
�
envzEnvironment variables to set when executing the notebook. Values support location expansion (e.g., `$(location :target)`).
2{}k
i
env_inheritTSpecifies additional environment variables to inherit from the external environment.2[]
}
exporter_argsfTraitlets-style flags forwarded to nbconvert exporters (e.g. ``--WebPDFExporter.exclude_input=true``).2[]n
l
notebook=The notebook to execute. Must be a `jupyter_notebook` target. *
JupyterNotebookInfo
PyInfo�
�
out_dir�Directory to write output files to. If not specified, outputs are written to a subdirectory named after the target under the caller's working directory (e.g., `bazel run :run_notebook` writes to `./run_notebook/`). Absolute paths (e.g., `/tmp`) are used as-is; relative paths are resolved against the caller's working directory.2""�
�
reports�List of report types to generate after successful notebook execution. Valid values: `html`, `latex`, `markdown` (requires `jupyter_toolchain.pandoc`), `pdf` (requires `jupyter_toolchain.latex_engine`), `rst`, `webpdf` (requires `jupyter_toolchain.playwright_browsers_dir`).2[]�
//jupyter/private:jupyter.bzlr�
-
rules_jupyterjupyter/privatejupyter.bzlA
jupyter_notebook_binary_jupyter_notebook_binary

# jupyter_notebook_binary�#
,
rules_jupyterjupyterjupyter_report.bzl�!jupyter_reportoExecutes a Jupyter notebook and generates reports in various formats (HTML, Markdown, LaTeX, PDF, RST, WebPDF)."� 
�
jupyter_reportoExecutes a Jupyter notebook and generates reports in various formats (HTML, Markdown, LaTeX, PDF, RST, WebPDF).*
nameA unique name for this target. R
argsDAdditional command-line arguments to pass to the notebook execution.2[]x
cwd_modefThe working directory mode for notebook execution. If not specified, uses the `jupyter_toolchain.cwd`.2""s
dataeAdditional data files required by the notebook (e.g., input data files, images, configuration files).2[]�
envzEnvironment variables to set when executing the notebook. Values support location expansion (e.g., `$(location :target)`).
2{}}
exporter_argsfTraitlets-style flags forwarded to nbconvert exporters (e.g. ``--WebPDFExporter.exclude_input=true``).2[]x
notebookIThe notebook to execute and convert. Must be a `jupyter_notebook` target. *
JupyterNotebookInfo
PyInfoj
out_html\Output path for an HTML report. If specified, the notebook will be converted to HTML format.>
out_html_template_typeTemplate type for HTML output.2""l
	out_latex]Output path for a LaTeX report. If specified, the notebook will be converted to LaTeX format.q
out_latex_template_typePDocument layout for LaTeX output. `article` (the nbconvert default) or `report`.2""�
out_markdown�Output path for a Markdown report. If specified, the notebook will be converted to Markdown format. Requires `jupyter_toolchain.pandoc`.�
out_notebookwOutput path for the executed notebook (`.ipynb` file with cell outputs). If not specified, a default name is generated.�
out_pdf�Output path for a PDF report generated via LaTeX. Requires `jupyter_toolchain.latex_engine`. For a browser rendered PDF that does not need LaTeX see `out_webpdf`.s
out_rstfOutput path for a reStructuredText report. If specified, the notebook will be converted to RST format.�

out_webpdf�Output path for a WebPDF report (generated via Playwright/Chromium). If specified, the notebook will be converted to PDF format using headless browser rendering. Requires `jupyter_toolchain.playwright_browsers_dir`."=
jupyter_report+@@rules_jupyter//jupyter:jupyter_report.bzl
��,
*
nameA unique name for this target. T
R
argsDAdditional command-line arguments to pass to the notebook execution.2[]z
x
cwd_modefThe working directory mode for notebook execution. If not specified, uses the `jupyter_toolchain.cwd`.2""u
s
dataeAdditional data files required by the notebook (e.g., input data files, images, configuration files).2[]�
�
envzEnvironment variables to set when executing the notebook. Values support location expansion (e.g., `$(location :target)`).
2{}
}
exporter_argsfTraitlets-style flags forwarded to nbconvert exporters (e.g. ``--WebPDFExporter.exclude_input=true``).2[]z
x
notebookIThe notebook to execute and convert. Must be a `jupyter_notebook` target. *
JupyterNotebookInfo
PyInfol
j
out_html\Output path for an HTML report. If specified, the notebook will be converted to HTML format.@
>
out_html_template_typeTemplate type for HTML output.2""n
l
	out_latex]Output path for a LaTeX report. If specified, the notebook will be converted to LaTeX format.s
q
out_latex_template_typePDocument layout for LaTeX output. `article` (the nbconvert default) or `report`.2""�
�
out_markdown�Output path for a Markdown report. If specified, the notebook will be converted to Markdown format. Requires `jupyter_toolchain.pandoc`.�
�
out_notebookwOutput path for the executed notebook (`.ipynb` file with cell outputs). If not specified, a default name is generated.�
�
out_pdf�Output path for a PDF report generated via LaTeX. Requires `jupyter_toolchain.latex_engine`. For a browser rendered PDF that does not need LaTeX see `out_webpdf`.u
s
out_rstfOutput path for a reStructuredText report. If specified, the notebook will be converted to RST format.�
�

out_webpdf�Output path for a WebPDF report (generated via Playwright/Chromium). If specified, the notebook will be converted to PDF format using headless browser rendering. Requires `jupyter_toolchain.playwright_browsers_dir`.�
//jupyter/private:jupyter.bzlrn
-
rules_jupyterjupyter/privatejupyter.bzl/
jupyter_report_jupyter_report

# jupyter_report�<
/
rules_jupyterjupyterjupyter_toolchain.bzl�;jupyter_toolchain�	Defines a Jupyter toolchain that provides Jupyter, Jupytext, Pandoc, Playwright browser, LaTeX support and
additional kernels.

Kernels for languages other than Python are defined with `jupyter_kernelspec` and attached via `kernels`.
A single toolchain can serve notebooks of many languages; each notebook selects a kernel by name with
`jupyter_notebook.kernel`. Kernels not listed here (such as `python3` from `ipykernel`) are expected to be
discoverable from the `jupyter` Python environment.

LaTeX (used for `pdf` reports) is optional. The [texlive](https://registry.bazel.build/modules/texlive)
module from the Bazel Central Registry provides everything required:

```python
jupyter_toolchain(
    name = "jupyter_toolchain",
    jupyter = "@pip_deps//jupyter",
    jupytext = "@pip_deps//jupytext",
    pandoc = "@pandoc",
    latex_engine = "@texlive//texk/web2c:pdftex",
    latex_format = "@texlive//:pdflatex_fmt",
    latex_texmf_cnf = "@texlive-texmf//:web2c/texmf.cnf",
    latex_data = [
        "@texlive//:texmf/fonts",
        "@texlive//:texmf/tex_inputs",
        "@texlive//:texmf/web2c_data",
    ],
    bibtex = "@texlive//texk/bibtex-x:bibtex8",
)
```
"�1
�
jupyter_toolchain�	Defines a Jupyter toolchain that provides Jupyter, Jupytext, Pandoc, Playwright browser, LaTeX support and
additional kernels.

Kernels for languages other than Python are defined with `jupyter_kernelspec` and attached via `kernels`.
A single toolchain can serve notebooks of many languages; each notebook selects a kernel by name with
`jupyter_notebook.kernel`. Kernels not listed here (such as `python3` from `ipykernel`) are expected to be
discoverable from the `jupyter` Python environment.

LaTeX (used for `pdf` reports) is optional. The [texlive](https://registry.bazel.build/modules/texlive)
module from the Bazel Central Registry provides everything required:

```python
jupyter_toolchain(
    name = "jupyter_toolchain",
    jupyter = "@pip_deps//jupyter",
    jupytext = "@pip_deps//jupytext",
    pandoc = "@pandoc",
    latex_engine = "@texlive//texk/web2c:pdftex",
    latex_format = "@texlive//:pdflatex_fmt",
    latex_texmf_cnf = "@texlive-texmf//:web2c/texmf.cnf",
    latex_data = [
        "@texlive//:texmf/fonts",
        "@texlive//:texmf/tex_inputs",
        "@texlive//:texmf/web2c_data",
    ],
    bibtex = "@texlive//texk/bibtex-x:bibtex8",
)
```
*
nameA unique name for this target. �
bibtex�An optional BibTeX executable (e.g. `@texlive//texk/bibtex-x:bibtex8`). When unset, the bibliography pass of PDF generation is skipped.2None�
cwd_mode�The default working directory mode for notebook execution. This value is used when `cwd_mode` is not specified in `jupyter_report` or `jupyter_notebook_test` rules. `workspace_root` sets the working directory to the workspace root, while `notebook_root` sets it to the notebook's parent directory. This affects how relative paths in notebooks are resolved.2"execution_root"�
exporter_args�Default traitlets-style flags forwarded to nbconvert exporters for all rules using this toolchain (e.g. ``--WebPDFExporter.exclude_input=true``). Per-rule ``exporter_args`` are appended after these defaults, allowing overrides.2[]^
jupyterEThe Jupyter Python package providing notebook execution capabilities. *
PyInfo�
jupytext�The [Jupytext](https://jupytext.readthedocs.io/en/latest/) Python package for converting between notebook formats (e.g., .py to .ipynb). *
PyInfo}
kernelmDefault kernel name to use for notebook execution if not specified in the notebook (e.g., 'python3', 'rust').2""�
kernels�`jupyter_kernelspec` targets made available to notebooks using this toolchain. A kernel is only added to the inputs of a notebook when the notebook selects it by name via `jupyter_notebook.kernel` or `kernel`.*
JupyterKernelspecInfo2[]�

latex_data�texmf trees (fonts, macro packages, `web2c` configuration) required by `latex_engine` at runtime. These files are only added to actions and runfiles that produce PDF output.2[]�
latex_engine�A TeX engine executable used for `pdf` reports (e.g. `@texlive//texk/web2c:pdftex`). Requires `latex_format` and `latex_texmf_cnf`.2None�
latex_format~A precompiled LaTeX format file for `latex_engine` (e.g. `@texlive//:pdflatex_fmt`). The engine is invoked with `-fmt=<stem>`.2None�
latex_texmf_cnf�The `web2c/texmf.cnf` file of the texmf tree (e.g. `@texlive-texmf//:web2c/texmf.cnf`). Its directory becomes `TEXMFCNF` and its parent becomes `TEXMF`.2Nonet
pandocbThe Pandoc executable for converting notebooks to various output formats (HTML, LaTeX, PDF, etc.).2None^
playwright_browsers_dir;A directory containing the results of `playwright install`.2None{
playwright_ld_library_dirVA directory of shared libraries to prepend to LD_LIBRARY_PATH when launching browsers.2None"C
jupyter_toolchain.@@rules_jupyter//jupyter:jupyter_toolchain.bzl
vv,
*
nameA unique name for this target. �
�
bibtex�An optional BibTeX executable (e.g. `@texlive//texk/bibtex-x:bibtex8`). When unset, the bibliography pass of PDF generation is skipped.2None�
�
cwd_mode�The default working directory mode for notebook execution. This value is used when `cwd_mode` is not specified in `jupyter_report` or `jupyter_notebook_test` rules. `workspace_root` sets the working directory to the workspace root, while `notebook_root` sets it to the notebook's parent directory. This affects how relative paths in notebooks are resolved.2"execution_root"�
�
exporter_args�Default traitlets-style flags forwarded to nbconvert exporters for all rules using this toolchain (e.g. ``--WebPDFExporter.exclude_input=true``). Per-rule ``exporter_args`` are appended after these defaults, allowing overrides.2[]`
^
jupyterEThe Jupyter Python package providing notebook execution capabilities. *
PyInfo�
�
jupytext�The [Jupytext](https://jupytext.readthedocs.io/en/latest/) Python package for converting between notebook formats (e.g., .py to .ipynb). *
PyInfo
}
kernelmDefault kernel name to use for notebook execution if not specified in the notebook (e.g., 'python3', 'rust').2""�
�
kernels�`jupyter_kernelspec` targets made available to notebooks using this toolchain. A kernel is only added to the inputs of a notebook when the notebook selects it by name via `jupyter_notebook.kernel` or `kernel`.*
JupyterKernelspecInfo2[]�
�

latex_data�texmf trees (fonts, macro packages, `web2c` configuration) required by `latex_engine` at runtime. These files are only added to actions and runfiles that produce PDF output.2[]�
�
latex_engine�A TeX engine executable used for `pdf` reports (e.g. `@texlive//texk/web2c:pdftex`). Requires `latex_format` and `latex_texmf_cnf`.2None�
�
latex_format~A precompiled LaTeX format file for `latex_engine` (e.g. `@texlive//:pdflatex_fmt`). The engine is invoked with `-fmt=<stem>`.2None�
�
latex_texmf_cnf�The `web2c/texmf.cnf` file of the texmf tree (e.g. `@texlive-texmf//:web2c/texmf.cnf`). Its directory becomes `TEXMFCNF` and its parent becomes `TEXMF`.2Nonev
t
pandocbThe Pandoc executable for converting notebooks to various output formats (HTML, LaTeX, PDF, etc.).2None`
^
playwright_browsers_dir;A directory containing the results of `playwright install`.2None}
{
playwright_ld_library_dirVA directory of shared libraries to prepend to LD_LIBRARY_PATH when launching browsers.2None�
//jupyter/private:toolchain.bzlrv
/
rules_jupyterjupyter/privatetoolchain.bzl5
jupyter_toolchain_jupyter_toolchain

# jupyter_toolchain�
?
rules_jupyterplaywright/ld_library_pathld_library_dir.bzl�playwright_ld_library_dirnCollects .so files from debian archive dependencies into a single flat directory suitable for LD_LIBRARY_PATH."�
�
playwright_ld_library_dirnCollects .so files from debian archive dependencies into a single flat directory suitable for LD_LIBRARY_PATH.*
nameA unique name for this target. I
deps=Debian archive filegroup targets containing shared libraries. "[
playwright_ld_library_dir>@@rules_jupyter//playwright/ld_library_path:ld_library_dir.bzl
!!,
*
nameA unique name for this target. K
I
deps=Debian archive filegroup targets containing shared libraries. �$playwright_ld_library_dir_repositorynCreates a repository with a playwright_ld_library_dir target that collects .so files from debian archive deps.R�
�
$playwright_ld_library_dir_repositorynCreates a repository with a playwright_ld_library_dir target that collects .so files from debian archive deps..
name"A unique name for this repository. _
depsSLabel strings of debian_archive filegroup targets to collect shared libraries from. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 *f
$playwright_ld_library_dir_repository>@@rules_jupyter//playwright/ld_library_path:ld_library_dir.bzl
A7A70
.
name"A unique name for this repository. a
_
depsSLabel strings of debian_archive filegroup targets to collect shared libraries from. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 ZRule to collect shared libraries from debian archive dependencies into a single directory.�
M
rules_jupyterplaywright/private/tests"requirements_parser_test_suite.bzl�parse_empty_requirements_test"�
�
parse_empty_requirements_test*
nameA unique name for this target. "m
parse_empty_requirements_testL@@rules_jupyter//playwright/private/tests:requirements_parser_test_suite.bzl
��,
*
nameA unique name for this target. �&parse_requirements_complex_format_test"�
�
&parse_requirements_complex_format_test*
nameA unique name for this target. "v
&parse_requirements_complex_format_testL@@rules_jupyter//playwright/private/tests:requirements_parser_test_suite.bzl
��,
*
nameA unique name for this target. �1parse_requirements_different_version_formats_test"�
�
1parse_requirements_different_version_formats_test*
nameA unique name for this target. "�
1parse_requirements_different_version_formats_testL@@rules_jupyter//playwright/private/tests:requirements_parser_test_suite.bzl
��,
*
nameA unique name for this target. �+parse_requirements_multiple_playwright_test"�
�
+parse_requirements_multiple_playwright_test*
nameA unique name for this target. "{
+parse_requirements_multiple_playwright_testL@@rules_jupyter//playwright/private/tests:requirements_parser_test_suite.bzl
��,
*
nameA unique name for this target. �%parse_requirements_no_playwright_test"�
�
%parse_requirements_no_playwright_test*
nameA unique name for this target. "u
%parse_requirements_no_playwright_testL@@rules_jupyter//playwright/private/tests:requirements_parser_test_suite.bzl
��,
*
nameA unique name for this target. �%parse_requirements_with_comments_test"�
�
%parse_requirements_with_comments_test*
nameA unique name for this target. "u
%parse_requirements_with_comments_testL@@rules_jupyter//playwright/private/tests:requirements_parser_test_suite.bzl
��,
*
nameA unique name for this target. �)parse_requirements_with_continuation_test"�
�
)parse_requirements_with_continuation_test*
nameA unique name for this target. "y
)parse_requirements_with_continuation_testL@@rules_jupyter//playwright/private/tests:requirements_parser_test_suite.bzl
��,
*
nameA unique name for this target. �'parse_requirements_with_whitespace_test"�
�
'parse_requirements_with_whitespace_test*
nameA unique name for this target. "w
'parse_requirements_with_whitespace_testL@@rules_jupyter//playwright/private/tests:requirements_parser_test_suite.bzl
��,
*
nameA unique name for this target. �parse_simple_requirements_test"�
�
parse_simple_requirements_test*
nameA unique name for this target. "n
parse_simple_requirements_testL@@rules_jupyter//playwright/private/tests:requirements_parser_test_suite.bzl
��,
*
nameA unique name for this target. �requirements_parser_test_suite4Create the test suite for requirements parser tests.*�
�
requirements_parser_test_suite&
nameThe name of the test suite (4Create the test suite for requirements parser tests.2n
requirements_parser_test_suiteL@@rules_jupyter//playwright/private/tests:requirements_parser_test_suite.bzl
��"parse_simple_requirements_test"%parse_requirements_with_comments_test")parse_requirements_with_continuation_test"%parse_requirements_no_playwright_test"parse_empty_requirements_test"+parse_requirements_multiple_playwright_test"'parse_requirements_with_whitespace_test"1parse_requirements_different_version_formats_test"&parse_requirements_complex_format_test2native.test_suite�
//lib:unittest.bzlrw
!
bazel_skyliblibunittest.bzl 
assertsasserts
*1"
unittestunittest
5=
?�
,//playwright/private:requirements_parser.bzlr�
<
rules_jupyterplaywright/privaterequirements_parser.bzlf
*parse_playwright_version_from_requirements*parse_playwright_version_from_requirements
Eo
q*Unit tests for the requirements.txt parser�
9
rules_jupyterplaywright/privatebrowser_versions.bzl�Browser Versions for Playwright

A mapping of Playwright version to browser name to browser revision.
This is used to automatically select browser versions based on Playwright version.
�"
1
rules_jupyterplaywright/privatebrowsers.bzl�chromium_archive6Create an http_archive for a Chromium browser archive.*�
�
chromium_archive
nameRepository name (#
platformPlatform identifier (
urlsArchive URLs ('
	integrityArchive integrity hash (7
strip_prefix#Strip prefix for archive extraction (6Create an http_archive for a Chromium browser archive.2D
chromium_archive0@@rules_jupyter//playwright/private:browsers.bzl
��2http_archive�chromium_headless_shell_archiveECreate an http_archive for a Chromium headless-shell browser archive.*�
�
chromium_headless_shell_archive

name (
platform (

urls (
	integrity (
strip_prefix (ECreate an http_archive for a Chromium headless-shell browser archive.2S
chromium_headless_shell_archive0@@rules_jupyter//playwright/private:browsers.bzl
��2http_archive�ffmpeg_archive-Create an http_archive for an FFmpeg archive.*�
�
ffmpeg_archive

name (
platform (

urls (
	integrity (
strip_prefix (-Create an http_archive for an FFmpeg archive.2B
ffmpeg_archive0@@rules_jupyter//playwright/private:browsers.bzl
��2http_archive�firefox_archive5Create an http_archive for a Firefox browser archive.*�
�
firefox_archive

name (
platform (

urls (
	integrity (
strip_prefix (5Create an http_archive for a Firefox browser archive.2C
firefox_archive0@@rules_jupyter//playwright/private:browsers.bzl
��2http_archive�webkit_archive4Create an http_archive for a WebKit browser archive.*�
�
webkit_archive

name (
platform (

urls (
	integrity (
strip_prefix (4Create an http_archive for a WebKit browser archive.2B
webkit_archive0@@rules_jupyter//playwright/private:browsers.bzl
��2http_archive�
browser_alias_repository0Alias repository for Playwright browser archivesR�

�
browser_alias_repository0Alias repository for Playwright browser archives.
name"A unique name for this repository. D
binaries4Mapping of repository labels to platform identifiers	 �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 *L
browser_alias_repository0@@rules_jupyter//playwright/private:browsers.bzl
�+�+0
.
name"A unique name for this repository. F
D
binaries4Mapping of repository labels to platform identifiers	 �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
 //tools/build_defs/repo:http.bzlrj
.
bazel_toolstools/build_defs/repohttp.bzl*
http_archivehttp_archive
7C
E�
9//playwright/private:chromium_headless_shell_versions.bzlr�
I
rules_jupyterplaywright/private$chromium_headless_shell_versions.bzlS
 CHROMIUM_HEADLESS_SHELL_VERSIONS!_CHROMIUM_HEADLESS_SHELL_VERSIONS
Qr
��
*//playwright/private:chromium_versions.bzlr�
:
rules_jupyterplaywright/privatechromium_versions.bzl5
CHROMIUM_VERSIONS_CHROMIUM_VERSIONS
BT
k�
(//playwright/private:ffmpeg_versions.bzlr{
8
rules_jupyterplaywright/privateffmpeg_versions.bzl1
FFMPEG_VERSIONS_FFMPEG_VERSIONS
@P
e�
)//playwright/private:firefox_versions.bzlr~
9
rules_jupyterplaywright/privatefirefox_versions.bzl3
FIREFOX_VERSIONS_FIREFOX_VERSIONS
AR
h�
(//playwright/private:webkit_versions.bzlr{
8
rules_jupyterplaywright/privatewebkit_versions.bzl1
WEBKIT_VERSIONS_WEBKIT_VERSIONS
@P
e.Rules for fetching Playwright browser archives�
I
rules_jupyterplaywright/private$chromium_headless_shell_versions.bzl�Chromium Headless Shell Versions for Playwright

A mapping of browser revision to platform to integrity of the archive for said platform.
Each revision key maps to platform-specific download information.
�
:
rules_jupyterplaywright/privatechromium_versions.bzl�Chromium Versions for Playwright

A mapping of browser revision to platform to integrity of the archive for said platform.
Each revision key maps to platform-specific download information.
�3
3
rules_jupyterplaywright/privateextensions.bzl�playwright_toolchain_repositoryKCreates a repository with playwright_toolchain rule for a specific platformR�
�
playwright_toolchain_repositoryKCreates a repository with playwright_toolchain rule for a specific platform.
name"A unique name for this repository. N
chromium:Label to the Chromium browser filegroup for this platform.2Nonel
chromium_headless_shellILabel to the Chromium headless-shell browser filegroup for this platform.2None�
chromium_headless_shell_versionwVersion string for the Chromium headless-shell browser (e.g., "1200"). Required if chromium_headless_shell is provided.2""s
chromium_versionYVersion string for the Chromium browser (e.g., "1200"). Required if chromium is provided.2""B
ffmpeg0Label to the FFmpeg filegroup for this platform.2Nonea
ffmpeg_versionIVersion string for FFmpeg (e.g., "1011"). Required if ffmpeg is provided.2""L
firefox9Label to the Firefox browser filegroup for this platform.2Nonep
firefox_versionWVersion string for the Firefox browser (e.g., "1497"). Required if firefox is provided.2""l
ld_library_dirRLabel to the ld_library_dir target providing shared libraries for LD_LIBRARY_PATH.2None^
platformNPlatform identifier (e.g., "linux-x86_64", "macos-aarch64", "windows-x86_64"). E
playwright_version+Playwright version string (e.g., "1.57.0"). �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 J
webkit8Label to the WebKit browser filegroup for this platform.2Nonem
webkit_versionUVersion string for the WebKit browser (e.g., "2227"). Required if webkit is provided.2""*U
playwright_toolchain_repository2@@rules_jupyter//playwright/private:extensions.bzl
�2�20
.
name"A unique name for this repository. P
N
chromium:Label to the Chromium browser filegroup for this platform.2Nonen
l
chromium_headless_shellILabel to the Chromium headless-shell browser filegroup for this platform.2None�
�
chromium_headless_shell_versionwVersion string for the Chromium headless-shell browser (e.g., "1200"). Required if chromium_headless_shell is provided.2""u
s
chromium_versionYVersion string for the Chromium browser (e.g., "1200"). Required if chromium is provided.2""D
B
ffmpeg0Label to the FFmpeg filegroup for this platform.2Nonec
a
ffmpeg_versionIVersion string for FFmpeg (e.g., "1011"). Required if ffmpeg is provided.2""N
L
firefox9Label to the Firefox browser filegroup for this platform.2Noner
p
firefox_versionWVersion string for the Firefox browser (e.g., "1497"). Required if firefox is provided.2""n
l
ld_library_dirRLabel to the ld_library_dir target providing shared libraries for LD_LIBRARY_PATH.2None`
^
platformNPlatform identifier (e.g., "linux-x86_64", "macos-aarch64", "windows-x86_64"). G
E
playwright_version+Playwright version string (e.g., "1.57.0"). �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 L
J
webkit8Label to the WebKit browser filegroup for this platform.2Noneo
m
webkit_versionUVersion string for the WebKit browser (e.g., "2227"). Required if webkit is provided.2""�
playwright Playwright browser dependencies.J�
�

playwright Playwright browser dependencies.�
	toolchain"Playwright toolchain configurationC
name Name of the toolchain repository2"playwright_toolchains"�
version�Playwright version (e.g., '1.57.0'). Browser versions will be auto-selected based on this. Mutually exclusive with `version_from_requirements`.2""�
version_from_requirementstA python `requirements.txt` file used for parsing the desired `playwright` version. Mutually exclusive with version.2None"@

playwright2@@rules_jupyter//playwright/private:extensions.bzl
���
�
	toolchain"Playwright toolchain configurationC
name Name of the toolchain repository2"playwright_toolchains"�
version�Playwright version (e.g., '1.57.0'). Browser versions will be auto-selected based on this. Mutually exclusive with `version_from_requirements`.2""�
version_from_requirementstA python `requirements.txt` file used for parsing the desired `playwright` version. Mutually exclusive with version.2NoneE
C
name Name of the toolchain repository2"playwright_toolchains"�
�
version�Playwright version (e.g., '1.57.0'). Browser versions will be auto-selected based on this. Mutually exclusive with `version_from_requirements`.2""�
�
version_from_requirementstA python `requirements.txt` file used for parsing the desired `playwright` version. Mutually exclusive with version.2None�
)//playwright/private:browser_versions.bzlr~
9
rules_jupyterplaywright/privatebrowser_versions.bzl3
BROWSER_VERSIONS_BROWSER_VERSIONS

�
!//playwright/private:browsers.bzlr�
1
rules_jupyterplaywright/privatebrowsers.bzlR
 CHROMIUM_HEADLESS_SHELL_VERSIONS CHROMIUM_HEADLESS_SHELL_VERSIONS
		&4
CHROMIUM_VERSIONSCHROMIUM_VERSIONS


0
FFMPEG_VERSIONSFFMPEG_VERSIONS
2
FIREFOX_VERSIONSFIREFOX_VERSIONS
0
WEBKIT_VERSIONSWEBKIT_VERSIONS
2
chromium_archivechromium_archive
P
chromium_headless_shell_archivechromium_headless_shell_archive
%.
ffmpeg_archiveffmpeg_archive
0
firefox_archivefirefox_archive
.
webkit_archivewebkit_archive

�
,//playwright/private:requirements_parser.bzlr�
<
rules_jupyterplaywright/privaterequirements_parser.bzlo
*parse_playwright_version_from_requirements3_parse_playwright_version_from_requirements_content
8
Playwright bzlmod extension�
8
rules_jupyterplaywright/privateffmpeg_versions.bzl�Ffmpeg Versions for Playwright

A mapping of browser revision to platform to integrity of the archive for said platform.
Each revision key maps to platform-specific download information.
�
9
rules_jupyterplaywright/privatefirefox_versions.bzl�Firefox Versions for Playwright

A mapping of browser revision to platform to integrity of the archive for said platform.
Each revision key maps to platform-specific download information.
�
3
rules_jupyterplaywright/privateplaywright.bzl�)current_playwright_toolchain_browsers_dir�Provides access to the browsers directory from the current Playwright toolchain. The browsers directory contains all installed browser binaries in a structure compatible with PLAYWRIGHT_BROWSERS_PATH."�
�
)current_playwright_toolchain_browsers_dir�Provides access to the browsers directory from the current Playwright toolchain. The browsers directory contains all installed browser binaries in a structure compatible with PLAYWRIGHT_BROWSERS_PATH.*
nameA unique name for this target. "_
)current_playwright_toolchain_browsers_dir2@@rules_jupyter//playwright/private:playwright.bzl
�1�1,
*
nameA unique name for this target. �+current_playwright_toolchain_ld_library_dirfProvides access to the LD_LIBRARY_PATH directory from the current Playwright toolchain, if configured."�
�
+current_playwright_toolchain_ld_library_dirfProvides access to the LD_LIBRARY_PATH directory from the current Playwright toolchain, if configured.*
nameA unique name for this target. "a
+current_playwright_toolchain_ld_library_dir2@@rules_jupyter//playwright/private:playwright.bzl
�3�3,
*
nameA unique name for this target. �playwright_toolchain/Playwright toolchain providing browser archives"�
�
playwright_toolchain/Playwright toolchain providing browser archives*
nameA unique name for this target. .
chromiumChromium browser filegroup2NoneL
chromium_headless_shell)Chromium headless-shell browser filegroup2NoneQ
chromium_headless_shell_version(Chromium headless-shell browser revision2""3
chromium_versionChromium browser revision2"""
ffmpegFFmpeg filegroup2None'
ffmpeg_versionFFmpeg revision2"",
firefoxFirefox browser filegroup2None1
firefox_versionFirefox browser revision2""j
ld_library_dirPDirectory of shared libraries to add to LD_LIBRARY_PATH when launching browsers.2None!
versionPlaywright version *
webkitWebKit browser filegroup2None/
webkit_versionWebKit browser revision2"""J
playwright_toolchain2@@rules_jupyter//playwright/private:playwright.bzl
��,
*
nameA unique name for this target. 0
.
chromiumChromium browser filegroup2NoneN
L
chromium_headless_shell)Chromium headless-shell browser filegroup2NoneS
Q
chromium_headless_shell_version(Chromium headless-shell browser revision2""5
3
chromium_versionChromium browser revision2""$
"
ffmpegFFmpeg filegroup2None)
'
ffmpeg_versionFFmpeg revision2"".
,
firefoxFirefox browser filegroup2None3
1
firefox_versionFirefox browser revision2""l
j
ld_library_dirPDirectory of shared libraries to add to LD_LIBRARY_PATH when launching browsers.2None#
!
versionPlaywright version ,
*
webkitWebKit browser filegroup2None1
/
webkit_versionWebKit browser revision2""�playwright_install_action#Creates a PlaywrightInstall action.*�
�
playwright_install_action=
ctx2Rule context (must have ctx.executable._installer) (9

output_dir'Output directory for installed browsers (3
playwright_versionPlaywright version string (T
browsersDDict mapping browser type to (filegroup_label, version_string) tuple (#Creates a PlaywrightInstall action."
The output directory artifact2O
playwright_install_action2@@rules_jupyter//playwright/private:playwright.bzl
*Rules for Playwright toolchain and actions�
<
rules_jupyterplaywright/privaterequirements_parser.bzl�*parse_playwright_version_from_requirements>Parse playwright version from a requirements.txt file content.*�
�
*parse_playwright_version_from_requirements:
content+String content of the requirements.txt file (>Parse playwright version from a requirements.txt file content."6
4Version string (e.g., "1.57.0") or None if not found2i
*parse_playwright_version_from_requirements;@@rules_jupyter//playwright/private:requirements_parser.bzl
EParser for extracting Playwright version from requirements.txt files.�
8
rules_jupyterplaywright/privatewebkit_versions.bzl�Webkit Versions for Playwright

A mapping of browser revision to platform to integrity of the archive for said platform.
Each revision key maps to platform-specific download information.
�g
1
rules_jupytertools/debiandebian_archive.bzl�download_and_extract$Download and extract debian archives*�
�
download_and_extract:
repository_ctx$The repository rule's context object (8
urls,A list of URLs to download the archive from. (.
sha256 The sha256 value of the archive. (=

add_prefix)A prefix to add to the extracted content.""(C
strip_prefix-A prefix to strip form the extracted content.""('
authSee `debian_archive.auth`{}(7
canonical_id!See `debian_archive.canonical_id`""(1
	integritySee `debian_archive.integrity`""($Download and extract debian archives"9
7dict: The result of repository_ctx.download_and_extract2H
download_and_extract0@@rules_jupyter//tools/debian:debian_archive.bzl
�]debian_archive�Downloads a Bazel repository as a debian archive file, decompresses it,
and makes its targets available for binding.

Unpacking runs unprivileged, so setuid bits and ownership are not kept.
R�\
�.
debian_archive�Downloads a Bazel repository as a debian archive file, decompresses it,
and makes its targets available for binding.

Unpacking runs unprivileged, so setuid bits and ownership are not kept.
.
name"A unique name for this repository. �

add_prefix�Destination directory relative to the repository directory.
The archive will be unpacked into this directory, after applying `strip_prefix`
(if any) to the file paths within the archive. For example, file
`foo-1.2.3/src/foo.h` will be unpacked to `bar/src/foo.h` if `add_prefix = "bar"`
and `strip_prefix = "foo-1.2.3"`.2""�
auth_patterns�An optional dict mapping host names to custom authorization patterns.
If a URL's host name is present in this dict the value will be used as a pattern when
generating the authorization header for the http request. This enables the use of custom
authorization schemes used in a lot of common cloud storage providers.
The pattern currently supports 2 tokens: <code>&lt;login&gt;</code> and
<code>&lt;password&gt;</code>, which are replaced with their equivalent value
in the netrc file for the same host name. After formatting, the result is set
as the value for the <code>Authorization</code> field of the HTTP request.
Example attribute and netrc for a http download to an oauth2 enabled API using a bearer token:
<pre>
auth_patterns = {
    "storage.cloudprovider.com": "Bearer &lt;password&gt;"
}
</pre>
netrc:
<pre>
machine storage.cloudprovider.com
        password RANDOM-TOKEN
</pre>
The final HTTP request would have the following header:
<pre>
Authorization: Bearer RANDOM-TOKEN
</pre>

2{}�

build_file�The file to use as the BUILD file for this repository.This attribute is an absolute label (use '@//' for the main repo). The file does not need to be named BUILD, but can be (something like BUILD.new-repo-name may work well for distinguishing it from the repository's actual BUILD files. Either build_file or build_file_content can be specified, but not both.2None�
build_file_content{The content for the BUILD file for this repository. Either build_file or build_file_content can be specified, but not both.2""�
canonical_id�A canonical id of the archive downloaded.
If specified and non-empty, bazel will not take the archive from cache,
unless it was added to the cache by a request with the same canonical id.
2""�
	integrity�Expected checksum in Subresource Integrity format of the file downloaded.
This must match the checksum of the file downloaded. _It is a security risk
to omit the checksum as remote files can change._ At best omitting this
field will make your build non-hermetic. It is optional to make development
easier but either this attribute or `sha256` should be set before shipping.2""D
netrc5Location of the .netrc file to use for authentication2""�

patch_args�The arguments given to the patch tool. Defaults to -p0, however -p1 will usually be needed for patches generated by git. If multiple -p arguments are specified, the last one will take effect.If arguments other than -p are specified, Bazel will fall back to use patch command line tool instead of the Bazel-native patch implementation. When falling back to patch command line tool and patch_tool attribute is not specified, `patch` will be used. This only affects patch files in the `patches` attribute.2["-p0"]e

patch_cmdsQSequence of Bash commands to be applied on Linux/Macos after patches are applied.2[]�
patch_cmds_win�Sequence of Powershell commands to be applied on Windows after patches are applied. If this attribute is not set, patch_cmds will be executed on Windows, which requires Bash binary to exist.2[]�

patch_tool�The patch(1) utility to use. If this is specified, Bazel will use the specified patch tool instead of the Bazel-native patch implementation.2""�
patches�A list of files that are to be applied as patches after extracting the archive. By default, it uses the Bazel-native patch implementation which doesn't support fuzz match and binary patch, but Bazel will fall back to use patch command line tool if `patch_tool` attribute is specified or there are arguments other than `-p` in `patch_args` attribute.2[]�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
sha256�The expected SHA-256 of the file downloaded.
This must match the SHA-256 of the file downloaded. _It is a security risk
to omit the SHA-256 as remote files can change._ At best omitting this
field will make your build non-hermetic. It is optional to make development
easier but either this attribute or `integrity` should be set before shipping.2""K
strip_prefix5A directory prefix to strip from the extracted files.2""�
typewThe archive type of the downloaded file.
By default, the archive type is determined from the file extension of the
URL.2""�
urls�A list of URLs to a file that will be made available to Bazel.
Each entry must be a file, http or https URL. Redirections are followed.
Authentication is not supported.
URLs are tried in order until one succeeds, so you should list local mirrors first.
If all downloads fail, the rule will fail. �
workspace_file�The file to use as the `WORKSPACE` file for this repository. Either `workspace_file` or `workspace_file_content` can be specified, or neither, but not both.2None�
workspace_file_content�The content for the WORKSPACE file for this repository. Either `workspace_file` or `workspace_file_content` can be specified, or neither, but not both.2""*B
debian_archive0@@rules_jupyter//tools/debian:debian_archive.bzl
�!�!0
.
name"A unique name for this repository. �
�

add_prefix�Destination directory relative to the repository directory.
The archive will be unpacked into this directory, after applying `strip_prefix`
(if any) to the file paths within the archive. For example, file
`foo-1.2.3/src/foo.h` will be unpacked to `bar/src/foo.h` if `add_prefix = "bar"`
and `strip_prefix = "foo-1.2.3"`.2""�
�
auth_patterns�An optional dict mapping host names to custom authorization patterns.
If a URL's host name is present in this dict the value will be used as a pattern when
generating the authorization header for the http request. This enables the use of custom
authorization schemes used in a lot of common cloud storage providers.
The pattern currently supports 2 tokens: <code>&lt;login&gt;</code> and
<code>&lt;password&gt;</code>, which are replaced with their equivalent value
in the netrc file for the same host name. After formatting, the result is set
as the value for the <code>Authorization</code> field of the HTTP request.
Example attribute and netrc for a http download to an oauth2 enabled API using a bearer token:
<pre>
auth_patterns = {
    "storage.cloudprovider.com": "Bearer &lt;password&gt;"
}
</pre>
netrc:
<pre>
machine storage.cloudprovider.com
        password RANDOM-TOKEN
</pre>
The final HTTP request would have the following header:
<pre>
Authorization: Bearer RANDOM-TOKEN
</pre>

2{}�
�

build_file�The file to use as the BUILD file for this repository.This attribute is an absolute label (use '@//' for the main repo). The file does not need to be named BUILD, but can be (something like BUILD.new-repo-name may work well for distinguishing it from the repository's actual BUILD files. Either build_file or build_file_content can be specified, but not both.2None�
�
build_file_content{The content for the BUILD file for this repository. Either build_file or build_file_content can be specified, but not both.2""�
�
canonical_id�A canonical id of the archive downloaded.
If specified and non-empty, bazel will not take the archive from cache,
unless it was added to the cache by a request with the same canonical id.
2""�
�
	integrity�Expected checksum in Subresource Integrity format of the file downloaded.
This must match the checksum of the file downloaded. _It is a security risk
to omit the checksum as remote files can change._ At best omitting this
field will make your build non-hermetic. It is optional to make development
easier but either this attribute or `sha256` should be set before shipping.2""F
D
netrc5Location of the .netrc file to use for authentication2""�
�

patch_args�The arguments given to the patch tool. Defaults to -p0, however -p1 will usually be needed for patches generated by git. If multiple -p arguments are specified, the last one will take effect.If arguments other than -p are specified, Bazel will fall back to use patch command line tool instead of the Bazel-native patch implementation. When falling back to patch command line tool and patch_tool attribute is not specified, `patch` will be used. This only affects patch files in the `patches` attribute.2["-p0"]g
e

patch_cmdsQSequence of Bash commands to be applied on Linux/Macos after patches are applied.2[]�
�
patch_cmds_win�Sequence of Powershell commands to be applied on Windows after patches are applied. If this attribute is not set, patch_cmds will be executed on Windows, which requires Bash binary to exist.2[]�
�

patch_tool�The patch(1) utility to use. If this is specified, Bazel will use the specified patch tool instead of the Bazel-native patch implementation.2""�
�
patches�A list of files that are to be applied as patches after extracting the archive. By default, it uses the Bazel-native patch implementation which doesn't support fuzz match and binary patch, but Bazel will fall back to use patch command line tool if `patch_tool` attribute is specified or there are arguments other than `-p` in `patch_args` attribute.2[]�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
�
sha256�The expected SHA-256 of the file downloaded.
This must match the SHA-256 of the file downloaded. _It is a security risk
to omit the SHA-256 as remote files can change._ At best omitting this
field will make your build non-hermetic. It is optional to make development
easier but either this attribute or `integrity` should be set before shipping.2""M
K
strip_prefix5A directory prefix to strip from the extracted files.2""�
�
typewThe archive type of the downloaded file.
By default, the archive type is determined from the file extension of the
URL.2""�
�
urls�A list of URLs to a file that will be made available to Bazel.
Each entry must be a file, http or https URL. Redirections are followed.
Authentication is not supported.
URLs are tried in order until one succeeds, so you should list local mirrors first.
If all downloads fail, the rule will fail. �
�
workspace_file�The file to use as the `WORKSPACE` file for this repository. Either `workspace_file` or `workspace_file_content` can be specified, or neither, but not both.2None�
�
workspace_file_content�The content for the WORKSPACE file for this repository. Either `workspace_file` or `workspace_file_content` can be specified, or neither, but not both.2""�
!//tools/build_defs/repo:utils.bzlr�
/
bazel_toolstools/build_defs/repo	utils.bzl
patchpatch
&

read_netrc
read_netrc
0
read_user_netrcread_user_netrc
*
update_attrsupdate_attrs
$
	use_netrc	use_netrc
		@
workspace_and_buildfileworkspace_and_buildfile



ERules for downloading and extracting `.deb` archives for use in BazelR

rules_jupyterversion.bzl	VERSION0.8.0j0.8.0rules_jupyter version 