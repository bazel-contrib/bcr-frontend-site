��
.
rules_kubectlkubectl/privatelauncher.bzl�kubectl_launcher�Wrap a `kubectl` toolchain's binary for `bazel run`.

The executable produced changes to `BUILD_WORKING_DIRECTORY` (the directory
`bazel run` was invoked from) before starting `kubectl`, so relative paths in
arguments such as `-f ./deploy.yaml` resolve the way they would for a locally
installed `kubectl`. Arguments, environment and exit status pass through
unchanged.

The launcher finds `kubectl` through runfiles: the rlocationpath exposed by
the toolchain's `KUBECTL_RLOCATIONPATH` make variable is linked into the
binary, so it also works when another binary or test executes it directly.


This builds an executable from a set of source files,
        which must all be in the `main` package. You can run the binary with
        `bazel run`, or you can build it with `bazel build` and run it directly.<br><br>
        ***Note:*** `name` should be the same as the desired name of the generated binary.<br><br>
        **Providers:**
        <ul>
          <li>[GoArchive]</li>
        </ul>
"�
�E
kubectl_launcher�Wrap a `kubectl` toolchain's binary for `bazel run`.

The executable produced changes to `BUILD_WORKING_DIRECTORY` (the directory
`bazel run` was invoked from) before starting `kubectl`, so relative paths in
arguments such as `-f ./deploy.yaml` resolve the way they would for a locally
installed `kubectl`. Arguments, environment and exit status pass through
unchanged.

The launcher finds `kubectl` through runfiles: the rlocationpath exposed by
the toolchain's `KUBECTL_RLOCATIONPATH` make variable is linked into the
binary, so it also works when another binary or test executes it directly.


This builds an executable from a set of source files,
        which must all be in the `main` package. You can run the binary with
        `bazel run`, or you can build it with `bazel build` and run it directly.<br><br>
        ***Note:*** `name` should be the same as the desired name of the generated binary.<br><br>
        **Providers:**
        <ul>
          <li>[GoArchive]</li>
        </ul>
*
nameA unique name for this target. �
basenamewThe basename of this binary. The binary
basename may also be platform-dependent: on Windows, we add an .exe extension.
2""�
cdeps�The list of other libraries that the c code depends on.
This can be anything that would be allowed in [cc_library deps]
Only valid if `cgo` = `True`.
2[]�
cgo�If `True`, the package may contain [cgo] code, and `srcs` may contain
C, C++, Objective-C, and Objective-C++ files and non-Go assembly files.
When cgo is enabled, these files will be compiled with the C/C++ toolchain
and included in the package. Note that this attribute does not force cgo
to be enabled. Cgo is enabled for non-cross-compiling builds when a C/C++
toolchain is configured.
2False�
	clinkopts�List of flags to add to the C link command.
Subject to ["Make variable"] substitution and [Bourne shell tokenization].
Only valid if `cgo` = `True`.
2[]�
copts�List of flags to add to the C compilation command.
Subject to ["Make variable"] substitution and [Bourne shell tokenization].
Only valid if `cgo` = `True`.
2[]�
cppopts�List of flags to add to the C/C++ preprocessor command.
Subject to ["Make variable"] substitution and [Bourne shell tokenization].
Only valid if `cgo` = `True`.
2[]�
cxxopts�List of flags to add to the C++ compilation command.
Subject to ["Make variable"] substitution and [Bourne shell tokenization].
Only valid if `cgo` = `True`.
2[]�
data�List of files needed by this rule at run-time. This may include data files
needed or other programs that may be executed. The [bazel] package may be
used to locate run files; they may appear in different places depending on the
operating system and environment. See [data dependencies] for more
information on data files.
2[]�
deps�List of Go libraries this package imports directly.
These may be `go_library` rules or compatible rules with the [GoInfo] provider.
*
GoInfo2[]�
embed�List of Go libraries whose sources should be compiled together with this
binary's sources. Labels listed here must name `go_library`,
`go_proto_library`, or other compatible targets with the [GoInfo] provider.
Embedded libraries must all have the same `importpath`,
which must match the `importpath` for this `go_binary` if one is
specified. At most one embedded library may have `cgo = True`, and the
embedding binary may not also have `cgo = True`. See [Embedding] for
more information.
*
GoInfo2[]�
	embedsrcs�The list of files that may be embedded into the compiled package using
`//go:embed` directives. All files must be in the same logical directory
or a subdirectory as source files. All source files containing `//go:embed`
directives must be in the same logical directory. It's okay to mix static and
generated source files and static and generated embeddable files.
2[]�
env�Environment variables to set when the binary is executed with bazel run.
The values (but not keys) are subject to
[location expansion](https://docs.bazel.build/versions/main/skylark/macros.html) but not full
[make variable expansion](https://docs.bazel.build/versions/main/be/make-variables.html).

2{}�
	gc_goopts�List of flags to add to the Go compilation command when using the gc compiler.
Subject to ["Make variable"] substitution and [Bourne shell tokenization].
2[]�
gc_linkopts�List of flags to add to the Go link command when using the gc compiler.
Subject to ["Make variable"] substitution and [Bourne shell tokenization].
2[]�
goarch�Forces a binary to be cross-compiled for a specific architecture. It's usually
better to control this on the command line with `--platforms`.

This disables cgo by default, since a cross-compiling C/C++ toolchain is
rarely available. To force cgo, set `pure` = `off`.

See [Cross compilation] for more information.
2"auto"�
goos�Forces a binary to be cross-compiled for a specific operating system. It's
usually better to control this on the command line with `--platforms`.

This disables cgo by default, since a cross-compiling C/C++ toolchain is
rarely available. To force cgo, set `pure` = `off`.

See [Cross compilation] for more information.
2"auto"v
gotagsfEnables a list of build tags when evaluating [build constraints]. Useful for
conditional compilation.
2[]�

importpath�The import path of this binary. Binaries can't actually be imported, but this
may be used by [go_path] and other tools to report the location of source
files. This may be inferred from embedded libraries.
2""�
linkmode�Determines how the binary should be built and linked. This accepts some of
the same values as `go build -buildmode` and works the same way.
<br><br>
<ul>
<li>`auto` (default): Controlled by `//go/config:linkmode`, which defaults to `normal`.</li>
<li>`normal`: Builds a normal executable with position-dependent code.</li>
<li>`pie`: Builds a position-independent executable.</li>
<li>`plugin`: Builds a shared library that can be loaded as a Go plugin. Only supported on platforms that support plugins.</li>
<li>`c-shared`: Builds a shared library that can be linked into a C program.</li>
<li>`c-archive`: Builds an archive that can be linked into a C program.</li>
</ul>
2"auto"�
msan�Controls whether code is instrumented for memory sanitization. May be one of
`on`, `off`, or `auto`. Not available when cgo is
disabled. In most cases, it's better to control this on the command line with
`--@io_bazel_rules_go//go/config:msan`. See [mode attributes], specifically
[msan].
2"auto"�
out�Sets the output filename for the generated executable. When set, `go_binary`
will write this file without mode-specific directory prefixes, without
linkmode-specific prefixes like "lib", and without platform-specific suffixes
like ".exe". Note that without a mode-specific directory prefix, the
output file (but not its dependencies) will be invalidated in Bazel's cache
when changing configurations.
2""�

pgoprofile�Provides a pprof file to be used for profile guided optimization when compiling go targets.
A pprof file can also be provided via `--@io_bazel_rules_go//go/config:pgoprofile=<label of a pprof file>`.
Profile guided optimization is only supported on go 1.20+.
See https://go.dev/doc/pgo for more information.
2//go/config:empty�
pure�Controls whether cgo source code and dependencies are compiled and linked,
similar to setting `CGO_ENABLED`. May be one of `on`, `off`,
or `auto`. If `auto`, pure mode is enabled when no C/C++
toolchain is configured or when cross-compiling. It's usually better to
control this on the command line with
`--@io_bazel_rules_go//go/config:pure`. See [mode attributes], specifically
[pure].
2"auto"�
race�Controls whether code is instrumented for race detection. May be one of
`on`, `off`, or `auto`. Not available when cgo is
disabled. In most cases, it's better to control this on the command line with
`--@io_bazel_rules_go//go/config:race`. See [mode attributes], specifically
[race].
2"auto"�
srcs�The list of Go source files that are compiled to create the package.
Only `.go`, `.s`, and `.syso` files are permitted, unless the `cgo`
attribute is set, in which case,
`.c .cc .cpp .cxx .h .hh .hpp .hxx .inc .m .mm`
files are also permitted. Files may be filtered at build time
using Go [build constraints].
2[]�
static�Controls whether a binary is statically linked. May be one of `on`,
`off`, or `auto`. Not available on all platforms or in all
modes. It's usually better to control this on the command line with
`--@io_bazel_rules_go//go/config:static`. See [mode attributes],
specifically [static].
2"auto"{
x_defskMap of defines to add to the go link command.
See [Defines and stamping] for examples of how to use these.

2{}
,
*
nameA unique name for this target. �
�
basenamewThe basename of this binary. The binary
basename may also be platform-dependent: on Windows, we add an .exe extension.
2""�
�
cdeps�The list of other libraries that the c code depends on.
This can be anything that would be allowed in [cc_library deps]
Only valid if `cgo` = `True`.
2[]�
�
cgo�If `True`, the package may contain [cgo] code, and `srcs` may contain
C, C++, Objective-C, and Objective-C++ files and non-Go assembly files.
When cgo is enabled, these files will be compiled with the C/C++ toolchain
and included in the package. Note that this attribute does not force cgo
to be enabled. Cgo is enabled for non-cross-compiling builds when a C/C++
toolchain is configured.
2False�
�
	clinkopts�List of flags to add to the C link command.
Subject to ["Make variable"] substitution and [Bourne shell tokenization].
Only valid if `cgo` = `True`.
2[]�
�
copts�List of flags to add to the C compilation command.
Subject to ["Make variable"] substitution and [Bourne shell tokenization].
Only valid if `cgo` = `True`.
2[]�
�
cppopts�List of flags to add to the C/C++ preprocessor command.
Subject to ["Make variable"] substitution and [Bourne shell tokenization].
Only valid if `cgo` = `True`.
2[]�
�
cxxopts�List of flags to add to the C++ compilation command.
Subject to ["Make variable"] substitution and [Bourne shell tokenization].
Only valid if `cgo` = `True`.
2[]�
�
data�List of files needed by this rule at run-time. This may include data files
needed or other programs that may be executed. The [bazel] package may be
used to locate run files; they may appear in different places depending on the
operating system and environment. See [data dependencies] for more
information on data files.
2[]�
�
deps�List of Go libraries this package imports directly.
These may be `go_library` rules or compatible rules with the [GoInfo] provider.
*
GoInfo2[]�
�
embed�List of Go libraries whose sources should be compiled together with this
binary's sources. Labels listed here must name `go_library`,
`go_proto_library`, or other compatible targets with the [GoInfo] provider.
Embedded libraries must all have the same `importpath`,
which must match the `importpath` for this `go_binary` if one is
specified. At most one embedded library may have `cgo = True`, and the
embedding binary may not also have `cgo = True`. See [Embedding] for
more information.
*
GoInfo2[]�
�
	embedsrcs�The list of files that may be embedded into the compiled package using
`//go:embed` directives. All files must be in the same logical directory
or a subdirectory as source files. All source files containing `//go:embed`
directives must be in the same logical directory. It's okay to mix static and
generated source files and static and generated embeddable files.
2[]�
�
env�Environment variables to set when the binary is executed with bazel run.
The values (but not keys) are subject to
[location expansion](https://docs.bazel.build/versions/main/skylark/macros.html) but not full
[make variable expansion](https://docs.bazel.build/versions/main/be/make-variables.html).

2{}�
�
	gc_goopts�List of flags to add to the Go compilation command when using the gc compiler.
Subject to ["Make variable"] substitution and [Bourne shell tokenization].
2[]�
�
gc_linkopts�List of flags to add to the Go link command when using the gc compiler.
Subject to ["Make variable"] substitution and [Bourne shell tokenization].
2[]�
�
goarch�Forces a binary to be cross-compiled for a specific architecture. It's usually
better to control this on the command line with `--platforms`.

This disables cgo by default, since a cross-compiling C/C++ toolchain is
rarely available. To force cgo, set `pure` = `off`.

See [Cross compilation] for more information.
2"auto"�
�
goos�Forces a binary to be cross-compiled for a specific operating system. It's
usually better to control this on the command line with `--platforms`.

This disables cgo by default, since a cross-compiling C/C++ toolchain is
rarely available. To force cgo, set `pure` = `off`.

See [Cross compilation] for more information.
2"auto"x
v
gotagsfEnables a list of build tags when evaluating [build constraints]. Useful for
conditional compilation.
2[]�
�

importpath�The import path of this binary. Binaries can't actually be imported, but this
may be used by [go_path] and other tools to report the location of source
files. This may be inferred from embedded libraries.
2""�
�
linkmode�Determines how the binary should be built and linked. This accepts some of
the same values as `go build -buildmode` and works the same way.
<br><br>
<ul>
<li>`auto` (default): Controlled by `//go/config:linkmode`, which defaults to `normal`.</li>
<li>`normal`: Builds a normal executable with position-dependent code.</li>
<li>`pie`: Builds a position-independent executable.</li>
<li>`plugin`: Builds a shared library that can be loaded as a Go plugin. Only supported on platforms that support plugins.</li>
<li>`c-shared`: Builds a shared library that can be linked into a C program.</li>
<li>`c-archive`: Builds an archive that can be linked into a C program.</li>
</ul>
2"auto"�
�
msan�Controls whether code is instrumented for memory sanitization. May be one of
`on`, `off`, or `auto`. Not available when cgo is
disabled. In most cases, it's better to control this on the command line with
`--@io_bazel_rules_go//go/config:msan`. See [mode attributes], specifically
[msan].
2"auto"�
�
out�Sets the output filename for the generated executable. When set, `go_binary`
will write this file without mode-specific directory prefixes, without
linkmode-specific prefixes like "lib", and without platform-specific suffixes
like ".exe". Note that without a mode-specific directory prefix, the
output file (but not its dependencies) will be invalidated in Bazel's cache
when changing configurations.
2""�
�

pgoprofile�Provides a pprof file to be used for profile guided optimization when compiling go targets.
A pprof file can also be provided via `--@io_bazel_rules_go//go/config:pgoprofile=<label of a pprof file>`.
Profile guided optimization is only supported on go 1.20+.
See https://go.dev/doc/pgo for more information.
2//go/config:empty�
�
pure�Controls whether cgo source code and dependencies are compiled and linked,
similar to setting `CGO_ENABLED`. May be one of `on`, `off`,
or `auto`. If `auto`, pure mode is enabled when no C/C++
toolchain is configured or when cross-compiling. It's usually better to
control this on the command line with
`--@io_bazel_rules_go//go/config:pure`. See [mode attributes], specifically
[pure].
2"auto"�
�
race�Controls whether code is instrumented for race detection. May be one of
`on`, `off`, or `auto`. Not available when cgo is
disabled. In most cases, it's better to control this on the command line with
`--@io_bazel_rules_go//go/config:race`. See [mode attributes], specifically
[race].
2"auto"�
�
srcs�The list of Go source files that are compiled to create the package.
Only `.go`, `.s`, and `.syso` files are permitted, unless the `cgo`
attribute is set, in which case,
`.c .cc .cpp .cxx .h .hh .hpp .hxx .inc .m .mm`
files are also permitted. Files may be filtered at build time
using Go [build constraints].
2[]�
�
static�Controls whether a binary is statically linked. May be one of `on`,
`off`, or `auto`. Not available on all platforms or in all
modes. It's usually better to control this on the command line with
`--@io_bazel_rules_go//go/config:static`. See [mode attributes],
specifically [static].
2"auto"}
{
x_defskMap of defines to add to the go link command.
See [Defines and stamping] for examples of how to use these.

2{}_
//go:def.bzlrM

rules_gogodef.bzl$
	go_binary	go_binary
 )
+kubectl launcher rule� 
2
rules_kubectlkubectl/privaterepositories.bzl�host_platformKReturn the `{os}-{arch}` platform name of the host, as used in `PLATFORMS`.*�
�
host_platform-
repository_ctxThe repository context. (KReturn the `{os}-{arch}` platform name of the host, as used in `PLATFORMS`."
str: e.g. `linux-amd64`.2B
host_platform1@@rules_kubectl//kubectl/private:repositories.bzl
�kubectl_host_repository�Creates a repository with a short name (`@kubectl` by default) exposing the host platform's kubectl as `//:kubectl`, behind a launcher suited to `bazel run`.
R�
�
kubectl_host_repository�Creates a repository with a short name (`@kubectl` by default) exposing the host platform's kubectl as `//:kubectl`, behind a launcher suited to `bazel run`.
.
name"A unique name for this repository. v
binary_repo_prefix\Prefix of the per-platform binary repositories. The host repo name is `{prefix}{os}_{arch}`. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 ?
version0The version of kubectl the repository points at. *L
kubectl_host_repository1@@rules_kubectl//kubectl/private:repositories.bzl
**0
.
name"A unique name for this repository. x
v
binary_repo_prefix\Prefix of the per-platform binary repositories. The host repo name is `{prefix}{os}_{arch}`. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 A
?
version0The version of kubectl the repository points at. �kubectl_toolchains_repository~Generates the toolchain hub: a `kubectl_toolchain` and a `toolchain` per platform, so they can all be registered with `:all`.
R�
�
kubectl_toolchains_repository~Generates the toolchain hub: a `kubectl_toolchain` and a `toolchain` per platform, so they can all be registered with `:all`.
.
name"A unique name for this repository. H
binaries8The label of the kubectl binary for each toolchain name.
 T
exec_compatible_with8Execution platform constraints, keyed by toolchain name. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 W
versionHThe kubectl version the binaries were built from, without a leading `v`. *R
kubectl_toolchains_repository1@@rules_kubectl//kubectl/private:repositories.bzl
J0J00
.
name"A unique name for this repository. J
H
binaries8The label of the kubectl binary for each toolchain name.
 V
T
exec_compatible_with8Execution platform constraints, keyed by toolchain name. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 Y
W
versionHThe kubectl version the binaries were built from, without a leading `v`. kubectl repository rules�
/
rules_kubectlkubectl/privatetoolchain.bzl�kubectl_toolchain�A kubectl toolchain.

Rules consume it through `@rules_kubectl//kubectl:toolchain_type`:

```python
def _impl(ctx):
    toolchain = ctx.toolchains["@rules_kubectl//kubectl:toolchain_type"]
    ctx.actions.run(
        executable = toolchain.kubectl,
        ...
    )
```

The `ToolchainInfo` carries `kubectl` (the binary `File`) and `version` (a string, possibly empty).

`@rules_kubectl//kubectl:current_toolchain` exposes the binary through two make variables: `KUBECTL` is its execpath, for use in actions, and `KUBECTL_RLOCATIONPATH` is its rlocationpath, for looking it up in runfiles.

```python
genrule(
    name = "pods",
    outs = ["pods.txt"],
    cmd = "$(KUBECTL) version --client > $@",
    toolchains = ["@rules_kubectl//kubectl:current_toolchain"],
)

sh_test(
    name = "pods_test",
    srcs = ["pods_test.sh"],
    data = ["@rules_kubectl//kubectl:current_toolchain"],
    env = {"KUBECTL": "$(KUBECTL_RLOCATIONPATH)"},
    toolchains = ["@rules_kubectl//kubectl:current_toolchain"],
)
```
"�
�	
kubectl_toolchain�A kubectl toolchain.

Rules consume it through `@rules_kubectl//kubectl:toolchain_type`:

```python
def _impl(ctx):
    toolchain = ctx.toolchains["@rules_kubectl//kubectl:toolchain_type"]
    ctx.actions.run(
        executable = toolchain.kubectl,
        ...
    )
```

The `ToolchainInfo` carries `kubectl` (the binary `File`) and `version` (a string, possibly empty).

`@rules_kubectl//kubectl:current_toolchain` exposes the binary through two make variables: `KUBECTL` is its execpath, for use in actions, and `KUBECTL_RLOCATIONPATH` is its rlocationpath, for looking it up in runfiles.

```python
genrule(
    name = "pods",
    outs = ["pods.txt"],
    cmd = "$(KUBECTL) version --client > $@",
    toolchains = ["@rules_kubectl//kubectl:current_toolchain"],
)

sh_test(
    name = "pods_test",
    srcs = ["pods_test.sh"],
    data = ["@rules_kubectl//kubectl:current_toolchain"],
    env = {"KUBECTL": "$(KUBECTL_RLOCATIONPATH)"},
    toolchains = ["@rules_kubectl//kubectl:current_toolchain"],
)
```
*
nameA unique name for this target.  
kubectlA kubectl binary. P
version?The version of `kubectl`, without a leading `v`. Informational.2"""C
kubectl_toolchain.@@rules_kubectl//kubectl/private:toolchain.bzl
,
*
nameA unique name for this target. "
 
kubectlA kubectl binary. R
P
version?The version of `kubectl`, without a leading `v`. Informational.2""�kubectl_toolchain_alias�Exposes a concrete toolchain which is the result of Bazel resolving the
kubectl toolchain for the execution or target platform.
Workaround for https://github.com/bazelbuild/bazel/issues/14009
"�
�
kubectl_toolchain_alias�Exposes a concrete toolchain which is the result of Bazel resolving the
kubectl toolchain for the execution or target platform.
Workaround for https://github.com/bazelbuild/bazel/issues/14009
*
nameA unique name for this target. "I
kubectl_toolchain_alias.@@rules_kubectl//kubectl/private:toolchain.bzl
\\,
*
nameA unique name for this target. kubectl toolchain rules�
.
rules_kubectlkubectl/privateversions.bzl�kubectl_urls.Return the download URLs for a kubectl binary.*�
�
kubectl_urls:
version+The kubectl version, without a leading `v`. (%
platformA key of `PLATFORMS`. (.Return the download URLs for a kubectl binary."
list: URLs to try in order.2=
kubectl_urls-@@rules_kubectl//kubectl/private:versions.bzl
  %	DEFAULT_VERSION1.37.1j1.37.1Z	URL_TEMPLATESjG2E
CAhttps://dl.k8s.io/release/v{version}/bin/{os}/{arch}/kubectl{ext}(Constants for accessing kubectl binaries�
"
rules_kubectlkubectldefs.bzl�kubectl_toolchain�A kubectl toolchain.

Rules consume it through `@rules_kubectl//kubectl:toolchain_type`:

```python
def _impl(ctx):
    toolchain = ctx.toolchains["@rules_kubectl//kubectl:toolchain_type"]
    ctx.actions.run(
        executable = toolchain.kubectl,
        ...
    )
```

The `ToolchainInfo` carries `kubectl` (the binary `File`) and `version` (a string, possibly empty).

`@rules_kubectl//kubectl:current_toolchain` exposes the binary through two make variables: `KUBECTL` is its execpath, for use in actions, and `KUBECTL_RLOCATIONPATH` is its rlocationpath, for looking it up in runfiles.

```python
genrule(
    name = "pods",
    outs = ["pods.txt"],
    cmd = "$(KUBECTL) version --client > $@",
    toolchains = ["@rules_kubectl//kubectl:current_toolchain"],
)

sh_test(
    name = "pods_test",
    srcs = ["pods_test.sh"],
    data = ["@rules_kubectl//kubectl:current_toolchain"],
    env = {"KUBECTL": "$(KUBECTL_RLOCATIONPATH)"},
    toolchains = ["@rules_kubectl//kubectl:current_toolchain"],
)
```
"�
�	
kubectl_toolchain�A kubectl toolchain.

Rules consume it through `@rules_kubectl//kubectl:toolchain_type`:

```python
def _impl(ctx):
    toolchain = ctx.toolchains["@rules_kubectl//kubectl:toolchain_type"]
    ctx.actions.run(
        executable = toolchain.kubectl,
        ...
    )
```

The `ToolchainInfo` carries `kubectl` (the binary `File`) and `version` (a string, possibly empty).

`@rules_kubectl//kubectl:current_toolchain` exposes the binary through two make variables: `KUBECTL` is its execpath, for use in actions, and `KUBECTL_RLOCATIONPATH` is its rlocationpath, for looking it up in runfiles.

```python
genrule(
    name = "pods",
    outs = ["pods.txt"],
    cmd = "$(KUBECTL) version --client > $@",
    toolchains = ["@rules_kubectl//kubectl:current_toolchain"],
)

sh_test(
    name = "pods_test",
    srcs = ["pods_test.sh"],
    data = ["@rules_kubectl//kubectl:current_toolchain"],
    env = {"KUBECTL": "$(KUBECTL_RLOCATIONPATH)"},
    toolchains = ["@rules_kubectl//kubectl:current_toolchain"],
)
```
*
nameA unique name for this target.  
kubectlA kubectl binary. P
version?The version of `kubectl`, without a leading `v`. Informational.2"""6
kubectl_toolchain!@@rules_kubectl//kubectl:defs.bzl
,
*
nameA unique name for this target. "
 
kubectlA kubectl binary. R
P
version?The version of `kubectl`, without a leading `v`. Informational.2""�
//kubectl/private:toolchain.bzlrv
/
rules_kubectlkubectl/privatetoolchain.bzl5
kubectl_toolchain_kubectl_toolchain
7I
`�# rules_kubectl

Bazel rules for a hermetic `kubectl`.

- `@kubectl//:kubectl` runs the host platform's binary from the directory
  `bazel run` was invoked in.
- `@rules_kubectl//kubectl:toolchain_type` is the toolchain type rules consume to run
  `kubectl` in an action.
- `@rules_kubectl//kubectl:current_toolchain` exposes the resolved binary to
  `genrule` and friends as the `KUBECTL` (execpath) and `KUBECTL_RLOCATIONPATH`
  (rlocationpath) make variables.
�%
(
rules_kubectlkubectlextensions.bzl�kubectl(Module extension for fetching `kubectl`.J�
�
kubectl(Module extension for fetching `kubectl`.�
	toolchain�Fetch `kubectl` and register toolchains for it.

Each tag creates a host repository (default `@kubectl`) exposing the host platform's binary as `@{name}//:kubectl`. That target runs `kubectl` from the directory `bazel run` was invoked in, so relative paths such as `-f ./deploy.yaml` resolve as they would for a locally installed `kubectl`.

```python
kubectl = use_extension("@rules_kubectl//kubectl:extensions.bzl", "kubectl")
kubectl.toolchain()
use_repo(kubectl, "kubectl")
```

```bash
bazel run @kubectl -- get pods --namespace my-namespace
bazel run @kubectl -- apply -f ./deploy/configmap.yaml
```

`rules_kubectl` registers the toolchains itself; the root module does not need a `register_toolchains` call. The registered toolchains serve the version requested by the root module's first `toolchain` tag (or the default when the root module has none).

### Versions

`rules_kubectl` ships checksums for a single default version. Requesting any other version makes the extension download the upstream `.sha256` files for that release while it is evaluated. On Bazel 8.5 and newer the digests are then stored as facts in `MODULE.bazel.lock`, so the lookup only happens once per version and airgapped builds work from the lockfile. Older Bazel versions repeat the lookup whenever the extension is re-evaluated.

```python
kubectl.toolchain(version = "1.36.5")
```

Several versions can live side by side by giving each tag its own repository name. Only the first tag in the root module decides which version the registered toolchains serve:

```python
kubectl.toolchain()
kubectl.toolchain(name = "kubectl_legacy", version = "1.35.6")
use_repo(kubectl, "kubectl", "kubectl_legacy")
```
5
name The name of the host repository.2	"kubectl"N
version7The version of kubectl to fetch, without a leading `v`.2"1.37.1""2
kubectl'@@rules_kubectl//kubectl:extensions.bzl
���
�
	toolchain�Fetch `kubectl` and register toolchains for it.

Each tag creates a host repository (default `@kubectl`) exposing the host platform's binary as `@{name}//:kubectl`. That target runs `kubectl` from the directory `bazel run` was invoked in, so relative paths such as `-f ./deploy.yaml` resolve as they would for a locally installed `kubectl`.

```python
kubectl = use_extension("@rules_kubectl//kubectl:extensions.bzl", "kubectl")
kubectl.toolchain()
use_repo(kubectl, "kubectl")
```

```bash
bazel run @kubectl -- get pods --namespace my-namespace
bazel run @kubectl -- apply -f ./deploy/configmap.yaml
```

`rules_kubectl` registers the toolchains itself; the root module does not need a `register_toolchains` call. The registered toolchains serve the version requested by the root module's first `toolchain` tag (or the default when the root module has none).

### Versions

`rules_kubectl` ships checksums for a single default version. Requesting any other version makes the extension download the upstream `.sha256` files for that release while it is evaluated. On Bazel 8.5 and newer the digests are then stored as facts in `MODULE.bazel.lock`, so the lookup only happens once per version and airgapped builds work from the lockfile. Older Bazel versions repeat the lookup whenever the extension is re-evaluated.

```python
kubectl.toolchain(version = "1.36.5")
```

Several versions can live side by side by giving each tag its own repository name. Only the first tag in the root module decides which version the registered toolchains serve:

```python
kubectl.toolchain()
kubectl.toolchain(name = "kubectl_legacy", version = "1.35.6")
use_repo(kubectl, "kubectl", "kubectl_legacy")
```
5
name The name of the host repository.2	"kubectl"N
version7The version of kubectl to fetch, without a leading `v`.2"1.37.1"7
5
name The name of the host repository.2	"kubectl"P
N
version7The version of kubectl to fetch, without a leading `v`.2"1.37.1"�
 //tools/build_defs/repo:http.bzlrd
.
bazel_toolstools/build_defs/repohttp.bzl$
	http_file	http_file
7@
B�
"//kubectl/private:repositories.bzlr�
2
rules_kubectlkubectl/privaterepositories.bzl@
kubectl_host_repositorykubectl_host_repository
L
kubectl_toolchains_repositorykubectl_toolchains_repository
#
�
//kubectl/private:versions.bzlr�
.
rules_kubectlkubectl/privateversions.bzl0
DEFAULT_VERSIONDEFAULT_VERSION
$
	PLATFORMS	PLATFORMS
"
VERSIONSVERSIONS
*
kubectl_urlskubectl_urls

	 # Bzlmod extension for `kubectl`l

rules_kubectlversion.bzl	VERSION0.1.0j0.1.0/Version info for the `rules_kubectl` repository 