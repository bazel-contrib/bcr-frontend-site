�!
4
rules_kubectlkubectl/privatekubectl_binary.bzl�kubectl_binary�An executable that runs `kubectl` with a fixed set of arguments.

The target is meant for `bazel run`. Anything passed after `--` is appended     to `args`, and `kubectl` starts in the directory `bazel run` was invoked     from, so relative paths on the command line resolve the way they would for     a locally installed `kubectl`.

Files Bazel knows about are referenced with `$(rlocationpath <label>)` in     `args` and `env`. The launcher resolves them through runfiles at run time,     which means the executable also works when another binary or test runs it.

```python
load("@rules_kubectl//kubectl:defs.bzl", "kubectl_binary")

kubectl_binary(
    name = "apply",
    args = [
        "apply",
        "--filename=$(rlocationpath :manifests)",
    ],
    data = [":manifests"],
)

kubectl_binary(
    name = "staging_pods",
    args = ["get", "pods"],
    data = ["staging.kubeconfig"],
    env = {"KUBECONFIG": "$(rlocationpath staging.kubeconfig)"},
)
```

```bash
bazel run //deploy:apply -- --namespace my-namespace
```

`kubectl` accepts flags ahead of the verb, so `args` can fix the file a     command operates on while leaving the verb to the caller. Only positional     arguments have to follow the verb:

```python
kubectl_binary(
    name = "kubectl",
    args = ["--filename=$(rlocationpath :manifests)"],
    data = [":manifests"],
)
```

```bash
bazel run //deploy:kubectl -- diff
bazel run //deploy:kubectl -- apply --server-side
```

Nothing about clusters, contexts or namespaces is decided here; that is     left to the arguments and the environment.


Writes the launcher configuration for a `kubectl_binary`."�
�
kubectl_binary�An executable that runs `kubectl` with a fixed set of arguments.

The target is meant for `bazel run`. Anything passed after `--` is appended     to `args`, and `kubectl` starts in the directory `bazel run` was invoked     from, so relative paths on the command line resolve the way they would for     a locally installed `kubectl`.

Files Bazel knows about are referenced with `$(rlocationpath <label>)` in     `args` and `env`. The launcher resolves them through runfiles at run time,     which means the executable also works when another binary or test runs it.

```python
load("@rules_kubectl//kubectl:defs.bzl", "kubectl_binary")

kubectl_binary(
    name = "apply",
    args = [
        "apply",
        "--filename=$(rlocationpath :manifests)",
    ],
    data = [":manifests"],
)

kubectl_binary(
    name = "staging_pods",
    args = ["get", "pods"],
    data = ["staging.kubeconfig"],
    env = {"KUBECONFIG": "$(rlocationpath staging.kubeconfig)"},
)
```

```bash
bazel run //deploy:apply -- --namespace my-namespace
```

`kubectl` accepts flags ahead of the verb, so `args` can fix the file a     command operates on while leaving the verb to the caller. Only positional     arguments have to follow the verb:

```python
kubectl_binary(
    name = "kubectl",
    args = ["--filename=$(rlocationpath :manifests)"],
    data = [":manifests"],
)
```

```bash
bazel run //deploy:kubectl -- diff
bazel run //deploy:kubectl -- apply --server-side
```

Nothing about clusters, contexts or namespaces is decided here; that is     left to the arguments and the environment.


Writes the launcher configuration for a `kubectl_binary`.*
nameA unique name for this target. 2
	argumentsArguments to pass to `kubectl`.2[]7
data)Files available to `kubectl` at run time.2[]@
environment+Environment variables to set for `kubectl`.
2{}J
kubectl7A kubectl binary. Defaults to the resolved toolchain's.2None"M
_kubectl_binary_config3@@rules_kubectl//kubectl/private:kubectl_binary.bzl
ii,
*
nameA unique name for this target. 4
2
	argumentsArguments to pass to `kubectl`.2[]9
7
data)Files available to `kubectl` at run time.2[]B
@
environment+Environment variables to set for `kubectl`.
2{}L
J
kubectl7A kubectl binary. Defaults to the resolved toolchain's.2None_
//go:def.bzlrM

rules_gogodef.bzl$
	go_binary	go_binary
 )
+�
//kubectl/private:runfiles.bzlrl
.
rules_kubectlkubectl/privaterunfiles.bzl,
rlocationpathrlocationpath
7D
Fkubectl_binary� 
2
rules_kubectlkubectl/privaterepositories.bzl�host_platformKReturn the `{os}-{arch}` platform name of the host, as used in `PLATFORMS`.*�
�
host_platform-
repository_ctxThe repository context. (KReturn the `{os}-{arch}` platform name of the host, as used in `PLATFORMS`."
str: e.g. `linux-amd64`.2B
host_platform1@@rules_kubectl//kubectl/private:repositories.bzl
�kubectl_host_repository�Creates a repository with a short name (`@kubectl` by default) exposing the host platform's kubectl as `//:kubectl`, behind a launcher suited to `bazel run`.
R�
�
kubectl_host_repository�Creates a repository with a short name (`@kubectl` by default) exposing the host platform's kubectl as `//:kubectl`, behind a launcher suited to `bazel run`.
.
name"A unique name for this repository. v
binary_repo_prefix\Prefix of the per-platform binary repositories. The host repo name is `{prefix}{os}_{arch}`. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 ?
version0The version of kubectl the repository points at. *L
kubectl_host_repository1@@rules_kubectl//kubectl/private:repositories.bzl
~*~*0
.
name"A unique name for this repository. x
v
binary_repo_prefix\Prefix of the per-platform binary repositories. The host repo name is `{prefix}{os}_{arch}`. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 A
?
version0The version of kubectl the repository points at. �kubectl_toolchains_repository~Generates the toolchain hub: a `kubectl_toolchain` and a `toolchain` per platform, so they can all be registered with `:all`.
R�
�
kubectl_toolchains_repository~Generates the toolchain hub: a `kubectl_toolchain` and a `toolchain` per platform, so they can all be registered with `:all`.
.
name"A unique name for this repository. H
binaries8The label of the kubectl binary for each toolchain name.
 T
exec_compatible_with8Execution platform constraints, keyed by toolchain name. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 W
versionHThe kubectl version the binaries were built from, without a leading `v`. *R
kubectl_toolchains_repository1@@rules_kubectl//kubectl/private:repositories.bzl
J0J00
.
name"A unique name for this repository. J
H
binaries8The label of the kubectl binary for each toolchain name.
 V
T
exec_compatible_with8Execution platform constraints, keyed by toolchain name. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 Y
W
versionHThe kubectl version the binaries were built from, without a leading `v`. kubectl repository rules�
.
rules_kubectlkubectl/privaterunfiles.bzl�rlocationpath@Return the runfiles path of `file`, as `$(rlocationpath)` would.*�
�
rlocationpath
fileThe file to locate. (+
workspace_name`ctx.workspace_name`. (@Return the runfiles path of `file`, as `$(rlocationpath)` would."<
:str: The path to pass to a runfiles library's `Rlocation`.2>
rlocationpath-@@rules_kubectl//kubectl/private:runfiles.bzl
Runfiles helpers�
/
rules_kubectlkubectl/privatetoolchain.bzl�kubectl_toolchain�A kubectl toolchain.

Rules consume it through `@rules_kubectl//kubectl:toolchain_type`:

```python
def _impl(ctx):
    toolchain = ctx.toolchains["@rules_kubectl//kubectl:toolchain_type"]
    ctx.actions.run(
        executable = toolchain.kubectl,
        ...
    )
```

The `ToolchainInfo` carries `kubectl` (the binary `File`) and `version` (a string, possibly empty).

`@rules_kubectl//kubectl:current_toolchain` exposes the binary through two make variables: `KUBECTL` is its execpath, for use in actions, and `KUBECTL_RLOCATIONPATH` is its rlocationpath, for looking it up in runfiles.

```python
genrule(
    name = "pods",
    outs = ["pods.txt"],
    cmd = "$(KUBECTL) version --client > $@",
    toolchains = ["@rules_kubectl//kubectl:current_toolchain"],
)

sh_test(
    name = "pods_test",
    srcs = ["pods_test.sh"],
    data = ["@rules_kubectl//kubectl:current_toolchain"],
    env = {"KUBECTL": "$(KUBECTL_RLOCATIONPATH)"},
    toolchains = ["@rules_kubectl//kubectl:current_toolchain"],
)
```
"�
�	
kubectl_toolchain�A kubectl toolchain.

Rules consume it through `@rules_kubectl//kubectl:toolchain_type`:

```python
def _impl(ctx):
    toolchain = ctx.toolchains["@rules_kubectl//kubectl:toolchain_type"]
    ctx.actions.run(
        executable = toolchain.kubectl,
        ...
    )
```

The `ToolchainInfo` carries `kubectl` (the binary `File`) and `version` (a string, possibly empty).

`@rules_kubectl//kubectl:current_toolchain` exposes the binary through two make variables: `KUBECTL` is its execpath, for use in actions, and `KUBECTL_RLOCATIONPATH` is its rlocationpath, for looking it up in runfiles.

```python
genrule(
    name = "pods",
    outs = ["pods.txt"],
    cmd = "$(KUBECTL) version --client > $@",
    toolchains = ["@rules_kubectl//kubectl:current_toolchain"],
)

sh_test(
    name = "pods_test",
    srcs = ["pods_test.sh"],
    data = ["@rules_kubectl//kubectl:current_toolchain"],
    env = {"KUBECTL": "$(KUBECTL_RLOCATIONPATH)"},
    toolchains = ["@rules_kubectl//kubectl:current_toolchain"],
)
```
*
nameA unique name for this target.  
kubectlA kubectl binary. P
version?The version of `kubectl`, without a leading `v`. Informational.2"""C
kubectl_toolchain.@@rules_kubectl//kubectl/private:toolchain.bzl
,
*
nameA unique name for this target. "
 
kubectlA kubectl binary. R
P
version?The version of `kubectl`, without a leading `v`. Informational.2""�kubectl_toolchain_alias�Exposes a concrete toolchain which is the result of Bazel resolving the
kubectl toolchain for the execution or target platform.
Workaround for https://github.com/bazelbuild/bazel/issues/14009
"�
�
kubectl_toolchain_alias�Exposes a concrete toolchain which is the result of Bazel resolving the
kubectl toolchain for the execution or target platform.
Workaround for https://github.com/bazelbuild/bazel/issues/14009
*
nameA unique name for this target. "I
kubectl_toolchain_alias.@@rules_kubectl//kubectl/private:toolchain.bzl
XX,
*
nameA unique name for this target. �
//kubectl/private:runfiles.bzlrl
.
rules_kubectlkubectl/privaterunfiles.bzl,
rlocationpathrlocationpath
7D
Fkubectl toolchain rules�
.
rules_kubectlkubectl/privateversions.bzl�kubectl_urls.Return the download URLs for a kubectl binary.*�
�
kubectl_urls:
version+The kubectl version, without a leading `v`. (%
platformA key of `PLATFORMS`. (.Return the download URLs for a kubectl binary."
list: URLs to try in order.2=
kubectl_urls-@@rules_kubectl//kubectl/private:versions.bzl
  %	DEFAULT_VERSION1.37.1j1.37.1Z	URL_TEMPLATESjG2E
CAhttps://dl.k8s.io/release/v{version}/bin/{os}/{arch}/kubectl{ext}(Constants for accessing kubectl binaries�9
"
rules_kubectlkubectldefs.bzl�kubectl_toolchain�A kubectl toolchain.

Rules consume it through `@rules_kubectl//kubectl:toolchain_type`:

```python
def _impl(ctx):
    toolchain = ctx.toolchains["@rules_kubectl//kubectl:toolchain_type"]
    ctx.actions.run(
        executable = toolchain.kubectl,
        ...
    )
```

The `ToolchainInfo` carries `kubectl` (the binary `File`) and `version` (a string, possibly empty).

`@rules_kubectl//kubectl:current_toolchain` exposes the binary through two make variables: `KUBECTL` is its execpath, for use in actions, and `KUBECTL_RLOCATIONPATH` is its rlocationpath, for looking it up in runfiles.

```python
genrule(
    name = "pods",
    outs = ["pods.txt"],
    cmd = "$(KUBECTL) version --client > $@",
    toolchains = ["@rules_kubectl//kubectl:current_toolchain"],
)

sh_test(
    name = "pods_test",
    srcs = ["pods_test.sh"],
    data = ["@rules_kubectl//kubectl:current_toolchain"],
    env = {"KUBECTL": "$(KUBECTL_RLOCATIONPATH)"},
    toolchains = ["@rules_kubectl//kubectl:current_toolchain"],
)
```
"�
�	
kubectl_toolchain�A kubectl toolchain.

Rules consume it through `@rules_kubectl//kubectl:toolchain_type`:

```python
def _impl(ctx):
    toolchain = ctx.toolchains["@rules_kubectl//kubectl:toolchain_type"]
    ctx.actions.run(
        executable = toolchain.kubectl,
        ...
    )
```

The `ToolchainInfo` carries `kubectl` (the binary `File`) and `version` (a string, possibly empty).

`@rules_kubectl//kubectl:current_toolchain` exposes the binary through two make variables: `KUBECTL` is its execpath, for use in actions, and `KUBECTL_RLOCATIONPATH` is its rlocationpath, for looking it up in runfiles.

```python
genrule(
    name = "pods",
    outs = ["pods.txt"],
    cmd = "$(KUBECTL) version --client > $@",
    toolchains = ["@rules_kubectl//kubectl:current_toolchain"],
)

sh_test(
    name = "pods_test",
    srcs = ["pods_test.sh"],
    data = ["@rules_kubectl//kubectl:current_toolchain"],
    env = {"KUBECTL": "$(KUBECTL_RLOCATIONPATH)"},
    toolchains = ["@rules_kubectl//kubectl:current_toolchain"],
)
```
*
nameA unique name for this target.  
kubectlA kubectl binary. P
version?The version of `kubectl`, without a leading `v`. Informational.2"""6
kubectl_toolchain!@@rules_kubectl//kubectl:defs.bzl
,
*
nameA unique name for this target. "
 
kubectlA kubectl binary. R
P
version?The version of `kubectl`, without a leading `v`. Informational.2""�kubectl_binary�An executable that runs `kubectl` with a fixed set of arguments.

The target is meant for `bazel run`. Anything passed after `--` is appended     to `args`, and `kubectl` starts in the directory `bazel run` was invoked     from, so relative paths on the command line resolve the way they would for     a locally installed `kubectl`.

Files Bazel knows about are referenced with `$(rlocationpath <label>)` in     `args` and `env`. The launcher resolves them through runfiles at run time,     which means the executable also works when another binary or test runs it.

```python
load("@rules_kubectl//kubectl:defs.bzl", "kubectl_binary")

kubectl_binary(
    name = "apply",
    args = [
        "apply",
        "--filename=$(rlocationpath :manifests)",
    ],
    data = [":manifests"],
)

kubectl_binary(
    name = "staging_pods",
    args = ["get", "pods"],
    data = ["staging.kubeconfig"],
    env = {"KUBECONFIG": "$(rlocationpath staging.kubeconfig)"},
)
```

```bash
bazel run //deploy:apply -- --namespace my-namespace
```

`kubectl` accepts flags ahead of the verb, so `args` can fix the file a     command operates on while leaving the verb to the caller. Only positional     arguments have to follow the verb:

```python
kubectl_binary(
    name = "kubectl",
    args = ["--filename=$(rlocationpath :manifests)"],
    data = [":manifests"],
)
```

```bash
bazel run //deploy:kubectl -- diff
bazel run //deploy:kubectl -- apply --server-side
```

Nothing about clusters, contexts or namespaces is decided here; that is     left to the arguments and the environment.


Writes the launcher configuration for a `kubectl_binary`."�
�
kubectl_binary�An executable that runs `kubectl` with a fixed set of arguments.

The target is meant for `bazel run`. Anything passed after `--` is appended     to `args`, and `kubectl` starts in the directory `bazel run` was invoked     from, so relative paths on the command line resolve the way they would for     a locally installed `kubectl`.

Files Bazel knows about are referenced with `$(rlocationpath <label>)` in     `args` and `env`. The launcher resolves them through runfiles at run time,     which means the executable also works when another binary or test runs it.

```python
load("@rules_kubectl//kubectl:defs.bzl", "kubectl_binary")

kubectl_binary(
    name = "apply",
    args = [
        "apply",
        "--filename=$(rlocationpath :manifests)",
    ],
    data = [":manifests"],
)

kubectl_binary(
    name = "staging_pods",
    args = ["get", "pods"],
    data = ["staging.kubeconfig"],
    env = {"KUBECONFIG": "$(rlocationpath staging.kubeconfig)"},
)
```

```bash
bazel run //deploy:apply -- --namespace my-namespace
```

`kubectl` accepts flags ahead of the verb, so `args` can fix the file a     command operates on while leaving the verb to the caller. Only positional     arguments have to follow the verb:

```python
kubectl_binary(
    name = "kubectl",
    args = ["--filename=$(rlocationpath :manifests)"],
    data = [":manifests"],
)
```

```bash
bazel run //deploy:kubectl -- diff
bazel run //deploy:kubectl -- apply --server-side
```

Nothing about clusters, contexts or namespaces is decided here; that is     left to the arguments and the environment.


Writes the launcher configuration for a `kubectl_binary`.*
nameA unique name for this target. 2
	argumentsArguments to pass to `kubectl`.2[]7
data)Files available to `kubectl` at run time.2[]@
environment+Environment variables to set for `kubectl`.
2{}J
kubectl7A kubectl binary. Defaults to the resolved toolchain's.2None
ii,
*
nameA unique name for this target. 4
2
	argumentsArguments to pass to `kubectl`.2[]9
7
data)Files available to `kubectl` at run time.2[]B
@
environment+Environment variables to set for `kubectl`.
2{}L
J
kubectl7A kubectl binary. Defaults to the resolved toolchain's.2None�
$//kubectl/private:kubectl_binary.bzlru
4
rules_kubectlkubectl/privatekubectl_binary.bzl/
kubectl_binary_kubectl_binary
<K
_�
//kubectl/private:toolchain.bzlrv
/
rules_kubectlkubectl/privatetoolchain.bzl5
kubectl_toolchain_kubectl_toolchain
7I
`�# rules_kubectl

Bazel rules for a hermetic `kubectl`.

- `@kubectl//:kubectl` runs the host platform's binary from the directory
  `bazel run` was invoked in.
- `kubectl_binary` does the same for a fixed `kubectl` invocation, with
  Bazel-generated files wired into its arguments and environment.
- `@rules_kubectl//kubectl:toolchain_type` is the toolchain type rules consume to run
  `kubectl` in an action.
- `@rules_kubectl//kubectl:current_toolchain` exposes the resolved binary to
  `genrule` and friends as the `KUBECTL` (execpath) and `KUBECTL_RLOCATIONPATH`
  (rlocationpath) make variables.
�%
(
rules_kubectlkubectlextensions.bzl�kubectl(Module extension for fetching `kubectl`.J�
�
kubectl(Module extension for fetching `kubectl`.�
	toolchain�Fetch `kubectl` and register toolchains for it.

Each tag creates a host repository (default `@kubectl`) exposing the host platform's binary as `@{name}//:kubectl`. That target runs `kubectl` from the directory `bazel run` was invoked in, so relative paths such as `-f ./deploy.yaml` resolve as they would for a locally installed `kubectl`.

```python
kubectl = use_extension("@rules_kubectl//kubectl:extensions.bzl", "kubectl")
kubectl.toolchain()
use_repo(kubectl, "kubectl")
```

```bash
bazel run @kubectl -- get pods --namespace my-namespace
bazel run @kubectl -- apply -f ./deploy/configmap.yaml
```

`rules_kubectl` registers the toolchains itself; the root module does not need a `register_toolchains` call. The registered toolchains serve the version requested by the root module's first `toolchain` tag (or the default when the root module has none).

### Versions

`rules_kubectl` ships checksums for a single default version. Requesting any other version makes the extension download the upstream `.sha256` files for that release while it is evaluated. On Bazel 8.5 and newer the digests are then stored as facts in `MODULE.bazel.lock`, so the lookup only happens once per version and airgapped builds work from the lockfile. Older Bazel versions repeat the lookup whenever the extension is re-evaluated.

```python
kubectl.toolchain(version = "1.36.5")
```

Several versions can live side by side by giving each tag its own repository name. Only the first tag in the root module decides which version the registered toolchains serve:

```python
kubectl.toolchain()
kubectl.toolchain(name = "kubectl_legacy", version = "1.35.6")
use_repo(kubectl, "kubectl", "kubectl_legacy")
```
5
name The name of the host repository.2	"kubectl"N
version7The version of kubectl to fetch, without a leading `v`.2"1.37.1""2
kubectl'@@rules_kubectl//kubectl:extensions.bzl
���
�
	toolchain�Fetch `kubectl` and register toolchains for it.

Each tag creates a host repository (default `@kubectl`) exposing the host platform's binary as `@{name}//:kubectl`. That target runs `kubectl` from the directory `bazel run` was invoked in, so relative paths such as `-f ./deploy.yaml` resolve as they would for a locally installed `kubectl`.

```python
kubectl = use_extension("@rules_kubectl//kubectl:extensions.bzl", "kubectl")
kubectl.toolchain()
use_repo(kubectl, "kubectl")
```

```bash
bazel run @kubectl -- get pods --namespace my-namespace
bazel run @kubectl -- apply -f ./deploy/configmap.yaml
```

`rules_kubectl` registers the toolchains itself; the root module does not need a `register_toolchains` call. The registered toolchains serve the version requested by the root module's first `toolchain` tag (or the default when the root module has none).

### Versions

`rules_kubectl` ships checksums for a single default version. Requesting any other version makes the extension download the upstream `.sha256` files for that release while it is evaluated. On Bazel 8.5 and newer the digests are then stored as facts in `MODULE.bazel.lock`, so the lookup only happens once per version and airgapped builds work from the lockfile. Older Bazel versions repeat the lookup whenever the extension is re-evaluated.

```python
kubectl.toolchain(version = "1.36.5")
```

Several versions can live side by side by giving each tag its own repository name. Only the first tag in the root module decides which version the registered toolchains serve:

```python
kubectl.toolchain()
kubectl.toolchain(name = "kubectl_legacy", version = "1.35.6")
use_repo(kubectl, "kubectl", "kubectl_legacy")
```
5
name The name of the host repository.2	"kubectl"N
version7The version of kubectl to fetch, without a leading `v`.2"1.37.1"7
5
name The name of the host repository.2	"kubectl"P
N
version7The version of kubectl to fetch, without a leading `v`.2"1.37.1"�
 //tools/build_defs/repo:http.bzlrd
.
bazel_toolstools/build_defs/repohttp.bzl$
	http_file	http_file
7@
B�
"//kubectl/private:repositories.bzlr�
2
rules_kubectlkubectl/privaterepositories.bzl@
kubectl_host_repositorykubectl_host_repository
L
kubectl_toolchains_repositorykubectl_toolchains_repository
#
�
//kubectl/private:versions.bzlr�
.
rules_kubectlkubectl/privateversions.bzl0
DEFAULT_VERSIONDEFAULT_VERSION
$
	PLATFORMS	PLATFORMS
"
VERSIONSVERSIONS
*
kubectl_urlskubectl_urls

	 # Bzlmod extension for `kubectl`l

rules_kubectlversion.bzl	VERSION0.3.0j0.3.0/Version info for the `rules_kubectl` repository 