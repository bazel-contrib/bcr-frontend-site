�
#
rules_latexlatexproviders.bzl�	LatexInfo:Information about a LaTeX source set or compiled document.2�
�
	LatexInfo:Information about a LaTeX source set or compiled document.�
srcs�depset[File]: transitive set of LaTeX source files (.tex, .sty, .cls, .bib, images, etc.) that documents depending on this target need to see.�
search_paths�depset[string]: directories (relative to the Bazel execroot) that downstream tectonic invocations should add to TEXINPUTS/BIBINPUTS/BSTINPUTS.�
offline_strategy�string: which offline-mode strategy the target resolved to. One of "user_cache" (explicit `cache = "..."` attr), "bundle" (toolchain-level tectonic.bundle()), or "implicit" (implicit populate-cache pipeline). Set only by `latex_document`; other rules that provide `LatexInfo` (`latex_library`, `latex_pkg`) leave it as the empty string. Consumed by `latex_live` to decide whether to interpose a persistent serve-time cache snapshot via the `//latex:_serve_cache_override` build setting.".
	LatexInfo!@rules_latex//latex:providers.bzl�
�
srcs�depset[File]: transitive set of LaTeX source files (.tex, .sty, .cls, .bib, images, etc.) that documents depending on this target need to see.�
�
search_paths�depset[string]: directories (relative to the Bazel execroot) that downstream tectonic invocations should add to TEXINPUTS/BIBINPUTS/BSTINPUTS.�
�
offline_strategy�string: which offline-mode strategy the target resolved to. One of "user_cache" (explicit `cache = "..."` attr), "bundle" (toolchain-level tectonic.bundle()), or "implicit" (implicit populate-cache pipeline). Set only by `latex_document`; other rules that provide `LatexInfo` (`latex_library`, `latex_pkg`) leave it as the empty string. Consumed by `latex_live` to decide whether to interpose a persistent serve-time cache snapshot via the `//latex:_serve_cache_override` build setting.�LatexDocumentInfo�Compile-time inputs of a `latex_document` target. Exposed so live-preview rules can drive their own parallel tectonic invocations (in particular, a serve-startup cache prime) without re-introspecting the document's attributes.2�	
�
LatexDocumentInfo�Compile-time inputs of a `latex_document` target. Exposed so live-preview rules can drive their own parallel tectonic invocations (in particular, a serve-startup cache prime) without re-introspecting the document's attributes.4
main,File: the main .tex file passed to tectonic.B
tectonic6File: the tectonic binary resolved from the toolchain.A
biber8File or None: the biber binary, if biber = True was set.>
use_system_biber*bool: True when biber_strategy = "system".>
	pkg_files1list[(File, string)]: explicit staging overrides.C
populate_tool2File: the tools/tectonic_populate_cache.py script.L
staging_lib=File: the tools/staging.py library imported by populate_tool."6
LatexDocumentInfo!@rules_latex//latex:providers.bzl6
4
main,File: the main .tex file passed to tectonic.D
B
tectonic6File: the tectonic binary resolved from the toolchain.C
A
biber8File or None: the biber binary, if biber = True was set.@
>
use_system_biber*bool: True when biber_strategy = "system".@
>
	pkg_files1list[(File, string)]: explicit staging overrides.E
C
populate_tool2File: the tools/tectonic_populate_cache.py script.N
L
staging_lib=File: the tools/staging.py library imported by populate_tool.�Providers exposed by rules_latex.

`LatexInfo` propagates the transitive set of LaTeX source files that a target
contributes, plus any options that downstream documents should inherit.

`LatexDocumentInfo` carries the compile-time inputs (main file, biber binary,
pkg_files overrides) of a `latex_document` target, so consumers like
`latex_live` can drive a parallel cache-priming invocation without
re-introspecting attributes.�
latexproviders.bzl�	LatexInfo:Information about a LaTeX source set or compiled document.2�
�
	LatexInfo:Information about a LaTeX source set or compiled document.�
srcs�depset[File]: transitive set of LaTeX source files (.tex, .sty, .cls, .bib, images, etc.) that documents depending on this target need to see.�
search_paths�depset[string]: directories (relative to the Bazel execroot) that downstream tectonic invocations should add to TEXINPUTS/BIBINPUTS/BSTINPUTS.�
offline_strategy�string: which offline-mode strategy the target resolved to. One of "user_cache" (explicit `cache = "..."` attr), "bundle" (toolchain-level tectonic.bundle()), or "implicit" (implicit populate-cache pipeline). Set only by `latex_document`; other rules that provide `LatexInfo` (`latex_library`, `latex_pkg`) leave it as the empty string. Consumed by `latex_live` to decide whether to interpose a persistent serve-time cache snapshot via the `//latex:_serve_cache_override` build setting.""
	LatexInfo//latex:providers.bzl�
�
srcs�depset[File]: transitive set of LaTeX source files (.tex, .sty, .cls, .bib, images, etc.) that documents depending on this target need to see.�
�
search_paths�depset[string]: directories (relative to the Bazel execroot) that downstream tectonic invocations should add to TEXINPUTS/BIBINPUTS/BSTINPUTS.�
�
offline_strategy�string: which offline-mode strategy the target resolved to. One of "user_cache" (explicit `cache = "..."` attr), "bundle" (toolchain-level tectonic.bundle()), or "implicit" (implicit populate-cache pipeline). Set only by `latex_document`; other rules that provide `LatexInfo` (`latex_library`, `latex_pkg`) leave it as the empty string. Consumed by `latex_live` to decide whether to interpose a persistent serve-time cache snapshot via the `//latex:_serve_cache_override` build setting.�LatexDocumentInfo�Compile-time inputs of a `latex_document` target. Exposed so live-preview rules can drive their own parallel tectonic invocations (in particular, a serve-startup cache prime) without re-introspecting the document's attributes.2�	
�
LatexDocumentInfo�Compile-time inputs of a `latex_document` target. Exposed so live-preview rules can drive their own parallel tectonic invocations (in particular, a serve-startup cache prime) without re-introspecting the document's attributes.4
main,File: the main .tex file passed to tectonic.B
tectonic6File: the tectonic binary resolved from the toolchain.A
biber8File or None: the biber binary, if biber = True was set.>
use_system_biber*bool: True when biber_strategy = "system".>
	pkg_files1list[(File, string)]: explicit staging overrides.C
populate_tool2File: the tools/tectonic_populate_cache.py script.L
staging_lib=File: the tools/staging.py library imported by populate_tool."*
LatexDocumentInfo//latex:providers.bzl6
4
main,File: the main .tex file passed to tectonic.D
B
tectonic6File: the tectonic binary resolved from the toolchain.C
A
biber8File or None: the biber binary, if biber = True was set.@
>
use_system_biber*bool: True when biber_strategy = "system".@
>
	pkg_files1list[(File, string)]: explicit staging overrides.E
C
populate_tool2File: the tools/tectonic_populate_cache.py script.N
L
staging_lib=File: the tools/staging.py library imported by populate_tool.�Providers exposed by rules_latex.

`LatexInfo` propagates the transitive set of LaTeX source files that a target
contributes, plus any options that downstream documents should inherit.

`LatexDocumentInfo` carries the compile-time inputs (main file, biber binary,
pkg_files overrides) of a `latex_document` target, so consumers like
`latex_live` can drive a parallel cache-priming invocation without
re-introspecting attributes.׷

rules_latexlatexdefs.bzl�latex_cache_snapshot9Bazel-run target that captures a tectonic cache snapshot."�
�
latex_cache_snapshot9Bazel-run target that captures a tectonic cache snapshot.*
nameA unique name for this target. S
mainGThe top-level .tex file passed to tectonic. Must also appear in `srcs`. �
srcs�All LaTeX source files needed to compile the document online. The cache snapshot will contain whatever tectonic decides to fetch for this compile, so make sure this list is realistic. w
deps,Other targets that contribute LaTeX sources.*;
	LatexInfo.
	LatexInfo!@rules_latex//latex:providers.bzl2[]X
outputJDestination path for the snapshot tarball, relative to the workspace root. �
biber�If True, prime the cache with biber on PATH so the resulting snapshot contains bibliography-related files. Required when consumers compile biblatex documents against this snapshot.2False�
ctan_packages�Names of CTAN packages to download and include in the cache snapshot. Each entry is a CTAN package name (e.g. 'fancyhdr'). Packages are downloaded from CTAN mirrors in TDS format during the snapshot generation.2[]�
	pkg_files�Map of label-of-input -> staged-relative-path. Overrides the auto-staging path for the listed inputs, letting you place a file anywhere under main.tex's work directory. Typical use: stage a cross-package `.bib` file as a sibling of main.tex so `\addbibresource{refs.bib}` works without `..` (which tectonic refuses to hand to external tools).	2{}"L
latex_cache_snapshot4@rules_latex//latex/private:latex_cache_snapshot.bzl8,
*
nameA unique name for this target. U
S
mainGThe top-level .tex file passed to tectonic. Must also appear in `srcs`. �
�
srcs�All LaTeX source files needed to compile the document online. The cache snapshot will contain whatever tectonic decides to fetch for this compile, so make sure this list is realistic. y
w
deps,Other targets that contribute LaTeX sources.*;
	LatexInfo.
	LatexInfo!@rules_latex//latex:providers.bzl2[]Z
X
outputJDestination path for the snapshot tarball, relative to the workspace root. �
�
biber�If True, prime the cache with biber on PATH so the resulting snapshot contains bibliography-related files. Required when consumers compile biblatex documents against this snapshot.2False�
�
ctan_packages�Names of CTAN packages to download and include in the cache snapshot. Each entry is a CTAN package name (e.g. 'fancyhdr'). Packages are downloaded from CTAN mirrors in TDS format during the snapshot generation.2[]�
�
	pkg_files�Map of label-of-input -> staged-relative-path. Overrides the auto-staging path for the listed inputs, letting you place a file anywhere under main.tex's work directory. Typical use: stage a cross-package `.bib` file as a sibling of main.tex so `\addbibresource{refs.bib}` works without `..` (which tectonic refuses to hand to external tools).	2{}�9latex_document,Compiles a LaTeX source tree using tectonic."�9
�
latex_document,Compiles a LaTeX source tree using tectonic.*
nameA unique name for this target. S
mainGThe top-level .tex file passed to tectonic. Must also appear in `srcs`. x
srcslAll LaTeX source files (.tex, .sty, .cls, .bib, images, etc.) that the document compilation might reference. �
depsWOther targets that contribute LaTeX sources (typically `latex_library` or `latex_pkg`).*;
	LatexInfo.
	LatexInfo!@rules_latex//latex:providers.bzl2[]K
outfmt8Output format. Passed to `tectonic -X compile --outfmt`.2"pdf"�
reproducible�When True, run tectonic in deterministic mode and set SOURCE_DATE_EPOCH=0, producing byte-identical output across runs given identical inputs. Off by default to keep PDF metadata (creation date) reflecting the actual build time. Mutually exclusive with `synctex`.2False�
synctex�When True, tectonic is invoked with --synctex and the resulting `<name>.synctex.gz` is exposed as an additional output (also surfaced via the `synctex` OutputGroup). Consumed by `latex_live` for reverse-sync lookups (PDF click -> copy `<file>:<line>` to the clipboard; the browser can't drive your editor, so the click doesn't *jump*) and forward-sync (editor -> PDF jump, via `POST /sync/forward`). Mutually exclusive with `reproducible` because tectonic's deterministic mode disables SyncTeX output.2False�
cache�Optional cache snapshot tarball (typically produced by `latex_cache_snapshot` and checked into the repository). When set, the action extracts the snapshot into the compile-time `TECTONIC_CACHE_DIR` and runs with `--only-cached`, giving a fully offline, hermetic build without pulling the full ~3 GB tectonic bundle or running an online prime. Takes precedence over the toolchain-level `tectonic.bundle()` and over the implicit cache pipeline.2None�
ctan_packages�Names of CTAN packages to fetch and make available to the document. Each entry is a CTAN package name (e.g. 'fancyhdr'). Packages are downloaded from CTAN mirrors in TDS format during the cache population step and bundled into the offline cache. Requires the implicit cache pipeline (default) or a cache snapshot generated with matching `ctan_packages`. Not supported when `tectonic.bundle()` is active (the toolchain-level bundle does not support on-demand CTAN package fetching).2[]�
biber�Enable biber bibliography processing. When True, tectonic can shell out to a `biber` binary at compile time, resolving `\\addbibresource`/`\\bibliography` directives via biblatex. The binary comes from the rules_latex toolchain by default; set `biber_strategy = "system"` to use a system install instead.2False�
biber_strategy�Which biber binary to use when `biber = True`. `"toolchain"` (default) uses the rules_latex-vendored biber 2.17; fails at analysis time on platforms without an upstream prebuilt (currently linux/aarch64). `"system"` propagates $PATH so a system-installed biber is found; less hermetic, intended as an escape hatch.2"toolchain"�
	pkg_files�Override the staged path of specific inputs. Map of label -> relative path under main.tex's work directory. The default main-rooted staging layout puts each src at a sensible place automatically; use `pkg_files` when the default would force you to write a long or `..`-containing path in main.tex. The classic case is a cross-package bib file: declare `pkg_files = {"//lib/refs:refs.bib": "refs.bib"}` and then write `\\addbibresource{refs.bib}` in main.tex.	2{}�
tectonic_argskExtra command-line arguments passed to tectonic. Use sparingly; prefer rule-level attributes when possible.2[]"@
latex_document.@rules_latex//latex/private:latex_document.bzl,
*
nameA unique name for this target. U
S
mainGThe top-level .tex file passed to tectonic. Must also appear in `srcs`. z
x
srcslAll LaTeX source files (.tex, .sty, .cls, .bib, images, etc.) that the document compilation might reference. �
�
depsWOther targets that contribute LaTeX sources (typically `latex_library` or `latex_pkg`).*;
	LatexInfo.
	LatexInfo!@rules_latex//latex:providers.bzl2[]M
K
outfmt8Output format. Passed to `tectonic -X compile --outfmt`.2"pdf"�
�
reproducible�When True, run tectonic in deterministic mode and set SOURCE_DATE_EPOCH=0, producing byte-identical output across runs given identical inputs. Off by default to keep PDF metadata (creation date) reflecting the actual build time. Mutually exclusive with `synctex`.2False�
�
synctex�When True, tectonic is invoked with --synctex and the resulting `<name>.synctex.gz` is exposed as an additional output (also surfaced via the `synctex` OutputGroup). Consumed by `latex_live` for reverse-sync lookups (PDF click -> copy `<file>:<line>` to the clipboard; the browser can't drive your editor, so the click doesn't *jump*) and forward-sync (editor -> PDF jump, via `POST /sync/forward`). Mutually exclusive with `reproducible` because tectonic's deterministic mode disables SyncTeX output.2False�
�
cache�Optional cache snapshot tarball (typically produced by `latex_cache_snapshot` and checked into the repository). When set, the action extracts the snapshot into the compile-time `TECTONIC_CACHE_DIR` and runs with `--only-cached`, giving a fully offline, hermetic build without pulling the full ~3 GB tectonic bundle or running an online prime. Takes precedence over the toolchain-level `tectonic.bundle()` and over the implicit cache pipeline.2None�
�
ctan_packages�Names of CTAN packages to fetch and make available to the document. Each entry is a CTAN package name (e.g. 'fancyhdr'). Packages are downloaded from CTAN mirrors in TDS format during the cache population step and bundled into the offline cache. Requires the implicit cache pipeline (default) or a cache snapshot generated with matching `ctan_packages`. Not supported when `tectonic.bundle()` is active (the toolchain-level bundle does not support on-demand CTAN package fetching).2[]�
�
biber�Enable biber bibliography processing. When True, tectonic can shell out to a `biber` binary at compile time, resolving `\\addbibresource`/`\\bibliography` directives via biblatex. The binary comes from the rules_latex toolchain by default; set `biber_strategy = "system"` to use a system install instead.2False�
�
biber_strategy�Which biber binary to use when `biber = True`. `"toolchain"` (default) uses the rules_latex-vendored biber 2.17; fails at analysis time on platforms without an upstream prebuilt (currently linux/aarch64). `"system"` propagates $PATH so a system-installed biber is found; less hermetic, intended as an escape hatch.2"toolchain"�
�
	pkg_files�Override the staged path of specific inputs. Map of label -> relative path under main.tex's work directory. The default main-rooted staging layout puts each src at a sensible place automatically; use `pkg_files` when the default would force you to write a long or `..`-containing path in main.tex. The classic case is a cross-package bib file: declare `pkg_files = {"//lib/refs:refs.bib": "refs.bib"}` and then write `\\addbibresource{refs.bib}` in main.tex.	2{}�
�
tectonic_argskExtra command-line arguments passed to tectonic. Use sparingly; prefer rule-level attributes when possible.2[]�latex_library,A reusable collection of LaTeX source files."�
�
latex_library,A reusable collection of LaTeX source files.*
nameA unique name for this target. M
srcsALaTeX source files (.tex/.sty/.cls/etc.) exposed by this library. �
deps@Other latex_library / latex_pkg targets this library depends on.*;
	LatexInfo.
	LatexInfo!@rules_latex//latex:providers.bzl2[]">
latex_library-@rules_latex//latex/private:latex_library.bzl*;
	LatexInfo.
	LatexInfo!@rules_latex//latex:providers.bzl,
*
nameA unique name for this target. O
M
srcsALaTeX source files (.tex/.sty/.cls/etc.) exposed by this library. �
�
deps@Other latex_library / latex_pkg targets this library depends on.*;
	LatexInfo.
	LatexInfo!@rules_latex//latex:providers.bzl2[]�	latex_pkgFA bundle of resource files (images, bib, fonts) consumed by documents."�
�
	latex_pkgFA bundle of resource files (images, bib, fonts) consumed by documents.*
nameA unique name for this target. 3
srcs'Resource files exposed by this package. "6
	latex_pkg)@rules_latex//latex/private:latex_pkg.bzl*;
	LatexInfo.
	LatexInfo!@rules_latex//latex:providers.bzl,
*
nameA unique name for this target. 5
3
srcs'Resource files exposed by this package. �)
latex_live7Browser-based live-preview server for a latex_document."�(
�

latex_live7Browser-based live-preview server for a latex_document.*
nameA unique name for this target. �
documentJThe latex_document (or any rule providing LatexInfo) to watch and rebuild. *;
	LatexInfo.
	LatexInfo!@rules_latex//latex:providers.bzlH
port8TCP port to bind the preview server to (localhost-only).28765�
poll_interval_ms�How often the watcher checks for source-file changes, in milliseconds. The watcher is a polling loop (no third-party `watchdog`/inotify dependency), so this is the amortised cost of one stat() per watched file per interval. 80 ms keeps perceived save-to-preview latency under 100 ms while staying cheap. Independent of `debounce_ms`: the poll interval is how fast we *notice* a change; the debounce window is how long we *wait* after a change before triggering a build.280�
open_on_start�If True, open the preview in the system default web browser once the server starts. The plain http URL is always printed regardless, so you can open it however you prefer.2False�
debounce_ms�How many milliseconds of source-idle to require after a detected change before triggering a rebuild. Coalesces bursts of writes (e.g. format-on-save then user-save, or editors that write multiple files near-simultaneously) into a single build. Set to 0 to disable debouncing (rebuild on every poll-detected change; reproduces pre-v0.3.3 behaviour). The default of 250 ms is invisible to the user because the build itself takes longer than the debounce window.2250�
debounce_max_ms�Safety net for the debouncer: never wait more than this many milliseconds before firing a build, even if changes keep arriving. Without this cap, a user typing continuously into an editor with fast-autosave-on-every-keystroke would never see a rebuild. 1500 ms matches the upper bound where a user typically expects 'okay, something should happen now'.21500�

serve_fast�Opt-in latency optimisation (default False). When True, the watcher replays the compiled action's invocation directly via tectonic_compile.py on each content edit instead of shelling out to `bazel build`, skipping Bazel analysis + sandbox setup (~50% of warm-rebuild latency). The first build, and any fast build that hits a missing cached resource, still go through `bazel build`, so the canonical build path is never bypassed for anything but content recompiles. Requires the watched target to be a real latex_document. The compile runs un-sandboxed but stages only the document's declared inputs, so it stays consistent with `bazel build` / CI. See DESIGN.md Â§4.7.4.2False"8

latex_live*@rules_latex//latex/private:latex_live.bzl8,
*
nameA unique name for this target. �
�
documentJThe latex_document (or any rule providing LatexInfo) to watch and rebuild. *;
	LatexInfo.
	LatexInfo!@rules_latex//latex:providers.bzlJ
H
port8TCP port to bind the preview server to (localhost-only).28765�
�
poll_interval_ms�How often the watcher checks for source-file changes, in milliseconds. The watcher is a polling loop (no third-party `watchdog`/inotify dependency), so this is the amortised cost of one stat() per watched file per interval. 80 ms keeps perceived save-to-preview latency under 100 ms while staying cheap. Independent of `debounce_ms`: the poll interval is how fast we *notice* a change; the debounce window is how long we *wait* after a change before triggering a build.280�
�
open_on_start�If True, open the preview in the system default web browser once the server starts. The plain http URL is always printed regardless, so you can open it however you prefer.2False�
�
debounce_ms�How many milliseconds of source-idle to require after a detected change before triggering a rebuild. Coalesces bursts of writes (e.g. format-on-save then user-save, or editors that write multiple files near-simultaneously) into a single build. Set to 0 to disable debouncing (rebuild on every poll-detected change; reproduces pre-v0.3.3 behaviour). The default of 250 ms is invisible to the user because the build itself takes longer than the debounce window.2250�
�
debounce_max_ms�Safety net for the debouncer: never wait more than this many milliseconds before firing a build, even if changes keep arriving. Without this cap, a user typing continuously into an editor with fast-autosave-on-every-keystroke would never see a rebuild. 1500 ms matches the upper bound where a user typically expects 'okay, something should happen now'.21500�
�

serve_fast�Opt-in latency optimisation (default False). When True, the watcher replays the compiled action's invocation directly via tectonic_compile.py on each content edit instead of shelling out to `bazel build`, skipping Bazel analysis + sandbox setup (~50% of warm-rebuild latency). The first build, and any fast build that hits a missing cached resource, still go through `bazel build`, so the canonical build path is never bypassed for anything but content recompiles. Requires the watched target to be a real latex_document. The compile runs un-sandboxed but stages only the document's declared inputs, so it stays consistent with `bazel build` / CI. See DESIGN.md Â§4.7.4.2False�"
latex_test;Compiles a LaTeX document and asserts on the resulting log."�"
�

latex_test;Compiles a LaTeX document and asserts on the resulting log.*
nameA unique name for this target. S
mainGThe top-level .tex file passed to tectonic. Must also appear in `srcs`. B
srcs6All LaTeX source files needed to compile the document. �
depsWOther targets that contribute LaTeX sources (typically `latex_library` or `latex_pkg`).*;
	LatexInfo.
	LatexInfo!@rules_latex//latex:providers.bzl2[]@
outfmt-Output format. Passed to tectonic's --outfmt.2"pdf"�
cache�Optional cache snapshot tarball (typically produced by `latex_cache_snapshot`). When set, the test extracts the snapshot and runs tectonic with `--only-cached`, giving a fully offline test that doesn't need internet to run. Takes precedence over the toolchain-level bundle.2None�
biber�Enable biber bibliography processing for the test compile, mirroring the same-named attribute on latex_document. When True, the toolchain biber binary is staged onto PATH so tectonic's biblatex subprocess can resolve it.2False�
biber_strategy�Which biber binary to use when `biber = True`. `"toolchain"` (default) uses the rules_latex-vendored biber; `"system"` uses whatever biber is on $PATH when the test runs.2"toolchain"�
ctan_packages�Names of CTAN packages to fetch and make available to the document. Each entry is a CTAN package name (e.g. 'fancyhdr'). Packages are downloaded from CTAN mirrors in TDS format during the test's inline cache population step.2[]m
	pkg_filesZSame semantics as `latex_document.pkg_files`. Override the staged path of specific inputs.	2{}�
forbidden_patterns�Substrings whose presence in the tectonic log file fails the test. Appended to a sensible default list (LaTeX Error, Undefined control sequence, Emergency stop, Fatal error). Set `forbidden_patterns_replace = True` to discard the defaults entirely.2[]w
forbidden_patterns_replacePIf True, `forbidden_patterns` replaces the default list instead of extending it.2False�
required_patterns�Substrings that MUST appear in the tectonic log file. Useful for asserting a particular package was loaded or a specific shipout happened.2[]"8

latex_test*@rules_latex//latex/private:latex_test.bzl08,
*
nameA unique name for this target. U
S
mainGThe top-level .tex file passed to tectonic. Must also appear in `srcs`. D
B
srcs6All LaTeX source files needed to compile the document. �
�
depsWOther targets that contribute LaTeX sources (typically `latex_library` or `latex_pkg`).*;
	LatexInfo.
	LatexInfo!@rules_latex//latex:providers.bzl2[]B
@
outfmt-Output format. Passed to tectonic's --outfmt.2"pdf"�
�
cache�Optional cache snapshot tarball (typically produced by `latex_cache_snapshot`). When set, the test extracts the snapshot and runs tectonic with `--only-cached`, giving a fully offline test that doesn't need internet to run. Takes precedence over the toolchain-level bundle.2None�
�
biber�Enable biber bibliography processing for the test compile, mirroring the same-named attribute on latex_document. When True, the toolchain biber binary is staged onto PATH so tectonic's biblatex subprocess can resolve it.2False�
�
biber_strategy�Which biber binary to use when `biber = True`. `"toolchain"` (default) uses the rules_latex-vendored biber; `"system"` uses whatever biber is on $PATH when the test runs.2"toolchain"�
�
ctan_packages�Names of CTAN packages to fetch and make available to the document. Each entry is a CTAN package name (e.g. 'fancyhdr'). Packages are downloaded from CTAN mirrors in TDS format during the test's inline cache population step.2[]o
m
	pkg_filesZSame semantics as `latex_document.pkg_files`. Override the staged path of specific inputs.	2{}�
�
forbidden_patterns�Substrings whose presence in the tectonic log file fails the test. Appended to a sensible default list (LaTeX Error, Undefined control sequence, Emergency stop, Fatal error). Set `forbidden_patterns_replace = True` to discard the defaults entirely.2[]y
w
forbidden_patterns_replacePIf True, `forbidden_patterns` replaces the default list instead of extending it.2False�
�
required_patterns�Substrings that MUST appear in the tectonic log file. Useful for asserting a particular package was loaded or a specific shipout happened.2[]�	LatexInfo:Information about a LaTeX source set or compiled document.2�
�
	LatexInfo:Information about a LaTeX source set or compiled document.�
srcs�depset[File]: transitive set of LaTeX source files (.tex, .sty, .cls, .bib, images, etc.) that documents depending on this target need to see.�
search_paths�depset[string]: directories (relative to the Bazel execroot) that downstream tectonic invocations should add to TEXINPUTS/BIBINPUTS/BSTINPUTS.�
offline_strategy�string: which offline-mode strategy the target resolved to. One of "user_cache" (explicit `cache = "..."` attr), "bundle" (toolchain-level tectonic.bundle()), or "implicit" (implicit populate-cache pipeline). Set only by `latex_document`; other rules that provide `LatexInfo` (`latex_library`, `latex_pkg`) leave it as the empty string. Consumed by `latex_live` to decide whether to interpose a persistent serve-time cache snapshot via the `//latex:_serve_cache_override` build setting.".
	LatexInfo!@rules_latex//latex:providers.bzl�
�
srcs�depset[File]: transitive set of LaTeX source files (.tex, .sty, .cls, .bib, images, etc.) that documents depending on this target need to see.�
�
search_paths�depset[string]: directories (relative to the Bazel execroot) that downstream tectonic invocations should add to TEXINPUTS/BIBINPUTS/BSTINPUTS.�
�
offline_strategy�string: which offline-mode strategy the target resolved to. One of "user_cache" (explicit `cache = "..."` attr), "bundle" (toolchain-level tectonic.bundle()), or "implicit" (implicit populate-cache pipeline). Set only by `latex_document`; other rules that provide `LatexInfo` (`latex_library`, `latex_pkg`) leave it as the empty string. Consumed by `latex_live` to decide whether to interpose a persistent serve-time cache snapshot via the `//latex:_serve_cache_override` build setting.�Public API for rules_latex.

Load symbols from here:

    load("@rules_latex//latex:defs.bzl",
         "latex_document", "latex_library", "latex_pkg",
         "latex_test", "latex_cache_snapshot",
         "latex_live")�
latexdefs.bzl�latex_cache_snapshot9Bazel-run target that captures a tectonic cache snapshot."�
�
latex_cache_snapshot9Bazel-run target that captures a tectonic cache snapshot.*
nameA unique name for this target. S
mainGThe top-level .tex file passed to tectonic. Must also appear in `srcs`. �
srcs�All LaTeX source files needed to compile the document online. The cache snapshot will contain whatever tectonic decides to fetch for this compile, so make sure this list is realistic. k
deps,Other targets that contribute LaTeX sources.*/
	LatexInfo"
	LatexInfo//latex:providers.bzl2[]X
outputJDestination path for the snapshot tarball, relative to the workspace root. �
biber�If True, prime the cache with biber on PATH so the resulting snapshot contains bibliography-related files. Required when consumers compile biblatex documents against this snapshot.2False�
ctan_packages�Names of CTAN packages to download and include in the cache snapshot. Each entry is a CTAN package name (e.g. 'fancyhdr'). Packages are downloaded from CTAN mirrors in TDS format during the snapshot generation.2[]�
	pkg_files�Map of label-of-input -> staged-relative-path. Overrides the auto-staging path for the listed inputs, letting you place a file anywhere under main.tex's work directory. Typical use: stage a cross-package `.bib` file as a sibling of main.tex so `\addbibresource{refs.bib}` works without `..` (which tectonic refuses to hand to external tools).	2{}"@
latex_cache_snapshot(//latex/private:latex_cache_snapshot.bzl8,
*
nameA unique name for this target. U
S
mainGThe top-level .tex file passed to tectonic. Must also appear in `srcs`. �
�
srcs�All LaTeX source files needed to compile the document online. The cache snapshot will contain whatever tectonic decides to fetch for this compile, so make sure this list is realistic. m
k
deps,Other targets that contribute LaTeX sources.*/
	LatexInfo"
	LatexInfo//latex:providers.bzl2[]Z
X
outputJDestination path for the snapshot tarball, relative to the workspace root. �
�
biber�If True, prime the cache with biber on PATH so the resulting snapshot contains bibliography-related files. Required when consumers compile biblatex documents against this snapshot.2False�
�
ctan_packages�Names of CTAN packages to download and include in the cache snapshot. Each entry is a CTAN package name (e.g. 'fancyhdr'). Packages are downloaded from CTAN mirrors in TDS format during the snapshot generation.2[]�
�
	pkg_files�Map of label-of-input -> staged-relative-path. Overrides the auto-staging path for the listed inputs, letting you place a file anywhere under main.tex's work directory. Typical use: stage a cross-package `.bib` file as a sibling of main.tex so `\addbibresource{refs.bib}` works without `..` (which tectonic refuses to hand to external tools).	2{}�9latex_document,Compiles a LaTeX source tree using tectonic."�8
�
latex_document,Compiles a LaTeX source tree using tectonic.*
nameA unique name for this target. S
mainGThe top-level .tex file passed to tectonic. Must also appear in `srcs`. x
srcslAll LaTeX source files (.tex, .sty, .cls, .bib, images, etc.) that the document compilation might reference. �
depsWOther targets that contribute LaTeX sources (typically `latex_library` or `latex_pkg`).*/
	LatexInfo"
	LatexInfo//latex:providers.bzl2[]K
outfmt8Output format. Passed to `tectonic -X compile --outfmt`.2"pdf"�
reproducible�When True, run tectonic in deterministic mode and set SOURCE_DATE_EPOCH=0, producing byte-identical output across runs given identical inputs. Off by default to keep PDF metadata (creation date) reflecting the actual build time. Mutually exclusive with `synctex`.2False�
synctex�When True, tectonic is invoked with --synctex and the resulting `<name>.synctex.gz` is exposed as an additional output (also surfaced via the `synctex` OutputGroup). Consumed by `latex_live` for reverse-sync lookups (PDF click -> copy `<file>:<line>` to the clipboard; the browser can't drive your editor, so the click doesn't *jump*) and forward-sync (editor -> PDF jump, via `POST /sync/forward`). Mutually exclusive with `reproducible` because tectonic's deterministic mode disables SyncTeX output.2False�
cache�Optional cache snapshot tarball (typically produced by `latex_cache_snapshot` and checked into the repository). When set, the action extracts the snapshot into the compile-time `TECTONIC_CACHE_DIR` and runs with `--only-cached`, giving a fully offline, hermetic build without pulling the full ~3 GB tectonic bundle or running an online prime. Takes precedence over the toolchain-level `tectonic.bundle()` and over the implicit cache pipeline.2None�
ctan_packages�Names of CTAN packages to fetch and make available to the document. Each entry is a CTAN package name (e.g. 'fancyhdr'). Packages are downloaded from CTAN mirrors in TDS format during the cache population step and bundled into the offline cache. Requires the implicit cache pipeline (default) or a cache snapshot generated with matching `ctan_packages`. Not supported when `tectonic.bundle()` is active (the toolchain-level bundle does not support on-demand CTAN package fetching).2[]�
biber�Enable biber bibliography processing. When True, tectonic can shell out to a `biber` binary at compile time, resolving `\\addbibresource`/`\\bibliography` directives via biblatex. The binary comes from the rules_latex toolchain by default; set `biber_strategy = "system"` to use a system install instead.2False�
biber_strategy�Which biber binary to use when `biber = True`. `"toolchain"` (default) uses the rules_latex-vendored biber 2.17; fails at analysis time on platforms without an upstream prebuilt (currently linux/aarch64). `"system"` propagates $PATH so a system-installed biber is found; less hermetic, intended as an escape hatch.2"toolchain"�
	pkg_files�Override the staged path of specific inputs. Map of label -> relative path under main.tex's work directory. The default main-rooted staging layout puts each src at a sensible place automatically; use `pkg_files` when the default would force you to write a long or `..`-containing path in main.tex. The classic case is a cross-package bib file: declare `pkg_files = {"//lib/refs:refs.bib": "refs.bib"}` and then write `\\addbibresource{refs.bib}` in main.tex.	2{}�
tectonic_argskExtra command-line arguments passed to tectonic. Use sparingly; prefer rule-level attributes when possible.2[]"4
latex_document"//latex/private:latex_document.bzl,
*
nameA unique name for this target. U
S
mainGThe top-level .tex file passed to tectonic. Must also appear in `srcs`. z
x
srcslAll LaTeX source files (.tex, .sty, .cls, .bib, images, etc.) that the document compilation might reference. �
�
depsWOther targets that contribute LaTeX sources (typically `latex_library` or `latex_pkg`).*/
	LatexInfo"
	LatexInfo//latex:providers.bzl2[]M
K
outfmt8Output format. Passed to `tectonic -X compile --outfmt`.2"pdf"�
�
reproducible�When True, run tectonic in deterministic mode and set SOURCE_DATE_EPOCH=0, producing byte-identical output across runs given identical inputs. Off by default to keep PDF metadata (creation date) reflecting the actual build time. Mutually exclusive with `synctex`.2False�
�
synctex�When True, tectonic is invoked with --synctex and the resulting `<name>.synctex.gz` is exposed as an additional output (also surfaced via the `synctex` OutputGroup). Consumed by `latex_live` for reverse-sync lookups (PDF click -> copy `<file>:<line>` to the clipboard; the browser can't drive your editor, so the click doesn't *jump*) and forward-sync (editor -> PDF jump, via `POST /sync/forward`). Mutually exclusive with `reproducible` because tectonic's deterministic mode disables SyncTeX output.2False�
�
cache�Optional cache snapshot tarball (typically produced by `latex_cache_snapshot` and checked into the repository). When set, the action extracts the snapshot into the compile-time `TECTONIC_CACHE_DIR` and runs with `--only-cached`, giving a fully offline, hermetic build without pulling the full ~3 GB tectonic bundle or running an online prime. Takes precedence over the toolchain-level `tectonic.bundle()` and over the implicit cache pipeline.2None�
�
ctan_packages�Names of CTAN packages to fetch and make available to the document. Each entry is a CTAN package name (e.g. 'fancyhdr'). Packages are downloaded from CTAN mirrors in TDS format during the cache population step and bundled into the offline cache. Requires the implicit cache pipeline (default) or a cache snapshot generated with matching `ctan_packages`. Not supported when `tectonic.bundle()` is active (the toolchain-level bundle does not support on-demand CTAN package fetching).2[]�
�
biber�Enable biber bibliography processing. When True, tectonic can shell out to a `biber` binary at compile time, resolving `\\addbibresource`/`\\bibliography` directives via biblatex. The binary comes from the rules_latex toolchain by default; set `biber_strategy = "system"` to use a system install instead.2False�
�
biber_strategy�Which biber binary to use when `biber = True`. `"toolchain"` (default) uses the rules_latex-vendored biber 2.17; fails at analysis time on platforms without an upstream prebuilt (currently linux/aarch64). `"system"` propagates $PATH so a system-installed biber is found; less hermetic, intended as an escape hatch.2"toolchain"�
�
	pkg_files�Override the staged path of specific inputs. Map of label -> relative path under main.tex's work directory. The default main-rooted staging layout puts each src at a sensible place automatically; use `pkg_files` when the default would force you to write a long or `..`-containing path in main.tex. The classic case is a cross-package bib file: declare `pkg_files = {"//lib/refs:refs.bib": "refs.bib"}` and then write `\\addbibresource{refs.bib}` in main.tex.	2{}�
�
tectonic_argskExtra command-line arguments passed to tectonic. Use sparingly; prefer rule-level attributes when possible.2[]�latex_library,A reusable collection of LaTeX source files."�
�
latex_library,A reusable collection of LaTeX source files.*
nameA unique name for this target. M
srcsALaTeX source files (.tex/.sty/.cls/etc.) exposed by this library. 
deps@Other latex_library / latex_pkg targets this library depends on.*/
	LatexInfo"
	LatexInfo//latex:providers.bzl2[]"2
latex_library!//latex/private:latex_library.bzl*/
	LatexInfo"
	LatexInfo//latex:providers.bzl,
*
nameA unique name for this target. O
M
srcsALaTeX source files (.tex/.sty/.cls/etc.) exposed by this library. �

deps@Other latex_library / latex_pkg targets this library depends on.*/
	LatexInfo"
	LatexInfo//latex:providers.bzl2[]�	latex_pkgFA bundle of resource files (images, bib, fonts) consumed by documents."�
�
	latex_pkgFA bundle of resource files (images, bib, fonts) consumed by documents.*
nameA unique name for this target. 3
srcs'Resource files exposed by this package. "*
	latex_pkg//latex/private:latex_pkg.bzl*/
	LatexInfo"
	LatexInfo//latex:providers.bzl,
*
nameA unique name for this target. 5
3
srcs'Resource files exposed by this package. �)
latex_live7Browser-based live-preview server for a latex_document."�(
�

latex_live7Browser-based live-preview server for a latex_document.*
nameA unique name for this target. �
documentJThe latex_document (or any rule providing LatexInfo) to watch and rebuild. */
	LatexInfo"
	LatexInfo//latex:providers.bzlH
port8TCP port to bind the preview server to (localhost-only).28765�
poll_interval_ms�How often the watcher checks for source-file changes, in milliseconds. The watcher is a polling loop (no third-party `watchdog`/inotify dependency), so this is the amortised cost of one stat() per watched file per interval. 80 ms keeps perceived save-to-preview latency under 100 ms while staying cheap. Independent of `debounce_ms`: the poll interval is how fast we *notice* a change; the debounce window is how long we *wait* after a change before triggering a build.280�
open_on_start�If True, open the preview in the system default web browser once the server starts. The plain http URL is always printed regardless, so you can open it however you prefer.2False�
debounce_ms�How many milliseconds of source-idle to require after a detected change before triggering a rebuild. Coalesces bursts of writes (e.g. format-on-save then user-save, or editors that write multiple files near-simultaneously) into a single build. Set to 0 to disable debouncing (rebuild on every poll-detected change; reproduces pre-v0.3.3 behaviour). The default of 250 ms is invisible to the user because the build itself takes longer than the debounce window.2250�
debounce_max_ms�Safety net for the debouncer: never wait more than this many milliseconds before firing a build, even if changes keep arriving. Without this cap, a user typing continuously into an editor with fast-autosave-on-every-keystroke would never see a rebuild. 1500 ms matches the upper bound where a user typically expects 'okay, something should happen now'.21500�

serve_fast�Opt-in latency optimisation (default False). When True, the watcher replays the compiled action's invocation directly via tectonic_compile.py on each content edit instead of shelling out to `bazel build`, skipping Bazel analysis + sandbox setup (~50% of warm-rebuild latency). The first build, and any fast build that hits a missing cached resource, still go through `bazel build`, so the canonical build path is never bypassed for anything but content recompiles. Requires the watched target to be a real latex_document. The compile runs un-sandboxed but stages only the document's declared inputs, so it stays consistent with `bazel build` / CI. See DESIGN.md Â§4.7.4.2False",

latex_live//latex/private:latex_live.bzl8,
*
nameA unique name for this target. �
�
documentJThe latex_document (or any rule providing LatexInfo) to watch and rebuild. */
	LatexInfo"
	LatexInfo//latex:providers.bzlJ
H
port8TCP port to bind the preview server to (localhost-only).28765�
�
poll_interval_ms�How often the watcher checks for source-file changes, in milliseconds. The watcher is a polling loop (no third-party `watchdog`/inotify dependency), so this is the amortised cost of one stat() per watched file per interval. 80 ms keeps perceived save-to-preview latency under 100 ms while staying cheap. Independent of `debounce_ms`: the poll interval is how fast we *notice* a change; the debounce window is how long we *wait* after a change before triggering a build.280�
�
open_on_start�If True, open the preview in the system default web browser once the server starts. The plain http URL is always printed regardless, so you can open it however you prefer.2False�
�
debounce_ms�How many milliseconds of source-idle to require after a detected change before triggering a rebuild. Coalesces bursts of writes (e.g. format-on-save then user-save, or editors that write multiple files near-simultaneously) into a single build. Set to 0 to disable debouncing (rebuild on every poll-detected change; reproduces pre-v0.3.3 behaviour). The default of 250 ms is invisible to the user because the build itself takes longer than the debounce window.2250�
�
debounce_max_ms�Safety net for the debouncer: never wait more than this many milliseconds before firing a build, even if changes keep arriving. Without this cap, a user typing continuously into an editor with fast-autosave-on-every-keystroke would never see a rebuild. 1500 ms matches the upper bound where a user typically expects 'okay, something should happen now'.21500�
�

serve_fast�Opt-in latency optimisation (default False). When True, the watcher replays the compiled action's invocation directly via tectonic_compile.py on each content edit instead of shelling out to `bazel build`, skipping Bazel analysis + sandbox setup (~50% of warm-rebuild latency). The first build, and any fast build that hits a missing cached resource, still go through `bazel build`, so the canonical build path is never bypassed for anything but content recompiles. Requires the watched target to be a real latex_document. The compile runs un-sandboxed but stages only the document's declared inputs, so it stays consistent with `bazel build` / CI. See DESIGN.md Â§4.7.4.2False�"
latex_test;Compiles a LaTeX document and asserts on the resulting log."�!
�

latex_test;Compiles a LaTeX document and asserts on the resulting log.*
nameA unique name for this target. S
mainGThe top-level .tex file passed to tectonic. Must also appear in `srcs`. B
srcs6All LaTeX source files needed to compile the document. �
depsWOther targets that contribute LaTeX sources (typically `latex_library` or `latex_pkg`).*/
	LatexInfo"
	LatexInfo//latex:providers.bzl2[]@
outfmt-Output format. Passed to tectonic's --outfmt.2"pdf"�
cache�Optional cache snapshot tarball (typically produced by `latex_cache_snapshot`). When set, the test extracts the snapshot and runs tectonic with `--only-cached`, giving a fully offline test that doesn't need internet to run. Takes precedence over the toolchain-level bundle.2None�
biber�Enable biber bibliography processing for the test compile, mirroring the same-named attribute on latex_document. When True, the toolchain biber binary is staged onto PATH so tectonic's biblatex subprocess can resolve it.2False�
biber_strategy�Which biber binary to use when `biber = True`. `"toolchain"` (default) uses the rules_latex-vendored biber; `"system"` uses whatever biber is on $PATH when the test runs.2"toolchain"�
ctan_packages�Names of CTAN packages to fetch and make available to the document. Each entry is a CTAN package name (e.g. 'fancyhdr'). Packages are downloaded from CTAN mirrors in TDS format during the test's inline cache population step.2[]m
	pkg_filesZSame semantics as `latex_document.pkg_files`. Override the staged path of specific inputs.	2{}�
forbidden_patterns�Substrings whose presence in the tectonic log file fails the test. Appended to a sensible default list (LaTeX Error, Undefined control sequence, Emergency stop, Fatal error). Set `forbidden_patterns_replace = True` to discard the defaults entirely.2[]w
forbidden_patterns_replacePIf True, `forbidden_patterns` replaces the default list instead of extending it.2False�
required_patterns�Substrings that MUST appear in the tectonic log file. Useful for asserting a particular package was loaded or a specific shipout happened.2[]",

latex_test//latex/private:latex_test.bzl08,
*
nameA unique name for this target. U
S
mainGThe top-level .tex file passed to tectonic. Must also appear in `srcs`. D
B
srcs6All LaTeX source files needed to compile the document. �
�
depsWOther targets that contribute LaTeX sources (typically `latex_library` or `latex_pkg`).*/
	LatexInfo"
	LatexInfo//latex:providers.bzl2[]B
@
outfmt-Output format. Passed to tectonic's --outfmt.2"pdf"�
�
cache�Optional cache snapshot tarball (typically produced by `latex_cache_snapshot`). When set, the test extracts the snapshot and runs tectonic with `--only-cached`, giving a fully offline test that doesn't need internet to run. Takes precedence over the toolchain-level bundle.2None�
�
biber�Enable biber bibliography processing for the test compile, mirroring the same-named attribute on latex_document. When True, the toolchain biber binary is staged onto PATH so tectonic's biblatex subprocess can resolve it.2False�
�
biber_strategy�Which biber binary to use when `biber = True`. `"toolchain"` (default) uses the rules_latex-vendored biber; `"system"` uses whatever biber is on $PATH when the test runs.2"toolchain"�
�
ctan_packages�Names of CTAN packages to fetch and make available to the document. Each entry is a CTAN package name (e.g. 'fancyhdr'). Packages are downloaded from CTAN mirrors in TDS format during the test's inline cache population step.2[]o
m
	pkg_filesZSame semantics as `latex_document.pkg_files`. Override the staged path of specific inputs.	2{}�
�
forbidden_patterns�Substrings whose presence in the tectonic log file fails the test. Appended to a sensible default list (LaTeX Error, Undefined control sequence, Emergency stop, Fatal error). Set `forbidden_patterns_replace = True` to discard the defaults entirely.2[]y
w
forbidden_patterns_replacePIf True, `forbidden_patterns` replaces the default list instead of extending it.2False�
�
required_patterns�Substrings that MUST appear in the tectonic log file. Useful for asserting a particular package was loaded or a specific shipout happened.2[]�	LatexInfo:Information about a LaTeX source set or compiled document.2�
�
	LatexInfo:Information about a LaTeX source set or compiled document.�
srcs�depset[File]: transitive set of LaTeX source files (.tex, .sty, .cls, .bib, images, etc.) that documents depending on this target need to see.�
search_paths�depset[string]: directories (relative to the Bazel execroot) that downstream tectonic invocations should add to TEXINPUTS/BIBINPUTS/BSTINPUTS.�
offline_strategy�string: which offline-mode strategy the target resolved to. One of "user_cache" (explicit `cache = "..."` attr), "bundle" (toolchain-level tectonic.bundle()), or "implicit" (implicit populate-cache pipeline). Set only by `latex_document`; other rules that provide `LatexInfo` (`latex_library`, `latex_pkg`) leave it as the empty string. Consumed by `latex_live` to decide whether to interpose a persistent serve-time cache snapshot via the `//latex:_serve_cache_override` build setting.""
	LatexInfo//latex:providers.bzl�
�
srcs�depset[File]: transitive set of LaTeX source files (.tex, .sty, .cls, .bib, images, etc.) that documents depending on this target need to see.�
�
search_paths�depset[string]: directories (relative to the Bazel execroot) that downstream tectonic invocations should add to TEXINPUTS/BIBINPUTS/BSTINPUTS.�
�
offline_strategy�string: which offline-mode strategy the target resolved to. One of "user_cache" (explicit `cache = "..."` attr), "bundle" (toolchain-level tectonic.bundle()), or "implicit" (implicit populate-cache pipeline). Set only by `latex_document`; other rules that provide `LatexInfo` (`latex_library`, `latex_pkg`) leave it as the empty string. Consumed by `latex_live` to decide whether to interpose a persistent serve-time cache snapshot via the `//latex:_serve_cache_override` build setting.�Public API for rules_latex.

Load symbols from here:

    load("@rules_latex//latex:defs.bzl",
         "latex_document", "latex_library", "latex_pkg",
         "latex_test", "latex_cache_snapshot",
         "latex_live")�
-
rules_latexlatex/toolchaintoolchain.bzl�	latex_toolchain)Defines a tectonic-based LaTeX toolchain."�	
�
latex_toolchain)Defines a tectonic-based LaTeX toolchain.*
nameA unique name for this target. (
tectonicThe tectonic executable. �
bundle�Optional offline package bundle (.tar). When set, the toolchain runs tectonic with `--bundle` pointed at this file, making compilation fully hermetic.2None�
biber�Optional biber executable. When set, latex_document actions invoked with `biber = True` make this binary available on PATH so tectonic can shell out to it for bibliography processing. Vendored for every supported platform (biber 2.21).2None">
latex_toolchain+@rules_latex//latex/toolchain:toolchain.bzl,
*
nameA unique name for this target. *
(
tectonicThe tectonic executable. �
�
bundle�Optional offline package bundle (.tar). When set, the toolchain runs tectonic with `--bundle` pointed at this file, making compilation fully hermetic.2None�
�
biber�Optional biber executable. When set, latex_document actions invoked with `biber = True` make this binary available on PATH so tectonic can shell out to it for bibliography processing. Vendored for every supported platform (biber 2.21).2None�LatexToolchainInfoResolved tectonic toolchain.2�
�
LatexToolchainInfoResolved tectonic toolchain.*
tectonicFile: the tectonic executable.W
bundleMFile|None: an offline package bundle, or None for online (default) operation.w
bibernFile|None: a biber executable for bibliography processing, or None if biber isn't available for this platform."A
LatexToolchainInfo+@rules_latex//latex/toolchain:toolchain.bzl,
*
tectonicFile: the tectonic executable.Y
W
bundleMFile|None: an offline package bundle, or None for online (default) operation.y
w
bibernFile|None: a biber executable for bibliography processing, or None if biber isn't available for this platform.�The `latex_toolchain` rule.

A `latex_toolchain` packages everything an action needs to invoke tectonic:
the binary itself, optionally a pre-fetched package bundle, and optionally
a biber binary for bibliography processing.

Toolchains of this type are registered automatically by the `tectonic` module
extension defined in `//latex/toolchain:extensions.bzl`.�
 latex/toolchaintoolchain.bzl�	latex_toolchain)Defines a tectonic-based LaTeX toolchain."�	
�
latex_toolchain)Defines a tectonic-based LaTeX toolchain.*
nameA unique name for this target. (
tectonicThe tectonic executable. �
bundle�Optional offline package bundle (.tar). When set, the toolchain runs tectonic with `--bundle` pointed at this file, making compilation fully hermetic.2None�
biber�Optional biber executable. When set, latex_document actions invoked with `biber = True` make this binary available on PATH so tectonic can shell out to it for bibliography processing. Vendored for every supported platform (biber 2.21).2None"2
latex_toolchain//latex/toolchain:toolchain.bzl,
*
nameA unique name for this target. *
(
tectonicThe tectonic executable. �
�
bundle�Optional offline package bundle (.tar). When set, the toolchain runs tectonic with `--bundle` pointed at this file, making compilation fully hermetic.2None�
�
biber�Optional biber executable. When set, latex_document actions invoked with `biber = True` make this binary available on PATH so tectonic can shell out to it for bibliography processing. Vendored for every supported platform (biber 2.21).2None�LatexToolchainInfoResolved tectonic toolchain.2�
�
LatexToolchainInfoResolved tectonic toolchain.*
tectonicFile: the tectonic executable.W
bundleMFile|None: an offline package bundle, or None for online (default) operation.w
bibernFile|None: a biber executable for bibliography processing, or None if biber isn't available for this platform."5
LatexToolchainInfo//latex/toolchain:toolchain.bzl,
*
tectonicFile: the tectonic executable.Y
W
bundleMFile|None: an offline package bundle, or None for online (default) operation.y
w
bibernFile|None: a biber executable for bibliography processing, or None if biber isn't available for this platform.�The `latex_toolchain` rule.

A `latex_toolchain` packages everything an action needs to invoke tectonic:
the binary itself, optionally a pre-fetched package bundle, and optionally
a biber binary for bibliography processing.

Toolchains of this type are registered automatically by the `tectonic` module
extension defined in `//latex/toolchain:extensions.bzl`. 