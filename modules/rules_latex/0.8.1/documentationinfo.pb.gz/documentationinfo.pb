�	
/
rules_latexlatex/privateaction_schema.bzl'	RULES_LATEX_ACTION_SCHEMAv2jv2�	Rule output-schema version used as a cache-busting input.

Bazel's action cache key is computed from the action's inputs,
command line, and environment â *not* from the set of declared
outputs. So if a `latex_document` (or any rule) gains a new
declared output, an existing cache entry from before the change
can satisfy the new action even though the cached blob is missing
the new output. We've been bitten by this once: the synctex case
(commit `0d4639c`, papered over with a manual cache-bust suffix;
the real symptom was fixed by `1978f5d`).

The defensive fix is to bake a *schema version* into the action's
env. Bumping this constant forces every cache key derived from it
to change, which invalidates any pre-existing entries that were
keyed off the old output schema. So when a rule changes its
declared-output set, bump the version here as well.

Forgotten bumps are caught by
`tests/starlark:action_schema_canary_test`: it snapshots the
declared output set of a canonical `latex_document` configuration
and fails when the snapshot drifts. The failure message points
the developer back here.

DESIGN.md Â§5 item 10 for the historical context.
�
0
rules_latexlatex/privatebiber_versions.bzl�biber_download_url8Build the GitHub release URL for a mirrored biber asset.*�
�
biber_download_url
asset (

mirror_tagNone(8Build the GitHub release URL for a mirrored biber asset.2E
biber_download_url/@@rules_latex//latex/private:biber_versions.bzl
FF>	BIBER_MIRROR_TAGbiber-mirror-v2.21jbiber-mirror-v2.21	BIBER_VERSION2.21j2.21�
Pinned biber release artifacts.

Biber is the bibliography processor that LaTeX documents using the
`biblatex` package rely on. Tectonic shells out to biber as an
external tool â we provide the binary as a Bazel-resolved toolchain
attribute so users don't have to maintain a system biber install or
worry about CI parity.

## Why biber 2.21

Biber and biblatex are tightly version-coupled through a "control
file format" number: biblatex writes a `.bcf` control file in the
format it knows and biber refuses one whose format it doesn't
recognise. The pinned package bundle (`texlive2026`, hosted on R2 â
see `bundles.bzl`) ships biblatex 3.21, which writes control file
v3.11; biber 2.21 is the matching reader. (Historically rules_latex
pinned biber 2.17 to match the frozen 2022 bundle's biblatex 3.17 /
v3.8, with an opt-in `modern_biblatex` overlay for 3.21; the TL2026
bundle ships 3.21 natively, so the split â and the old 2.17 pin â is
gone. See DESIGN.md Â§4.10.)

## Mirror

The upstream `biblatex-biber` project distributes prebuilt binaries
via SourceForge (no version-pinned URLs) plus, for linux/aarch64,
CTAN's `biber-linux-aarch64` package. We mirror the tarballs to a
GitHub release on rules_latex (`biber-mirror-v<version>`) so the URLs
are stable and the SHAs match indefinitely.
�#
)
rules_latexlatex/privatebundles.bzl�DEFAULT_BUNDLE�
Pinned tectonic package bundle.

Tectonic resolves `\usepackage{...}` directives at compile time by fetching
files from a "package bundle" that mirrors a subset of TeX Live.

`rules_latex` pins its own bundle: **`texlive2026`**, a freshly-built
TeX Live 2026 bundle in the `.ttb` (formatspec-v1) format â per-file gzip
plus an internal offset index, so it's HTTP-range-addressable (tectonic
fetches only the files a document needs). We host it on Cloudflare R2 at
`rules-latex.ndl.au` (zero egress, durable), with the `.ttb.index.gz`
sidecar alongside for the web-fetch path. The pinned tectonic 0.16.9
reads this `.ttb` directly (verified in CI).

Why we host our own: upstream `tectonic-texlive-bundles` was archived in
October 2024 with no bundle newer than 2022, and tectonic's relay still
serves the frozen `tlextras-2022.0r0` (biblatex 3.17). Building + hosting
TL2026 ourselves keeps packages current and removes the third-party CDN
dependency. See `DESIGN.md` Â§4.4 (network policy) and Â§4.10 (the
bundle-staleness rationale and the rebuild procedure).

A root module can still repoint the full-bundle download at a different
mirror via `tectonic.bundle(url = ..., sha256 = ...)` â see `DESIGN.md`
Â§4.4 "Self-hosting the bundle".

To refresh: rebuild the bundle (DESIGN.md Â§4.10), upload the new
`.ttb` + `.ttb.index.gz` to R2, and bump `url`/`sha256`/`version` below.
z�
DEFAULT_BUNDLE
!!�
Pinned tectonic package bundle.

Tectonic resolves `\usepackage{...}` directives at compile time by fetching
files from a "package bundle" that mirrors a subset of TeX Live.

`rules_latex` pins its own bundle: **`texlive2026`**, a freshly-built
TeX Live 2026 bundle in the `.ttb` (formatspec-v1) format â per-file gzip
plus an internal offset index, so it's HTTP-range-addressable (tectonic
fetches only the files a document needs). We host it on Cloudflare R2 at
`rules-latex.ndl.au` (zero egress, durable), with the `.ttb.index.gz`
sidecar alongside for the web-fetch path. The pinned tectonic 0.16.9
reads this `.ttb` directly (verified in CI).

Why we host our own: upstream `tectonic-texlive-bundles` was archived in
October 2024 with no bundle newer than 2022, and tectonic's relay still
serves the frozen `tlextras-2022.0r0` (biblatex 3.17). Building + hosting
TL2026 ourselves keeps packages current and removes the third-party CDN
dependency. See `DESIGN.md` Â§4.4 (network policy) and Â§4.10 (the
bundle-staleness rationale and the rebuild procedure).

A root module can still repoint the full-bundle download at a different
mirror via `tectonic.bundle(url = ..., sha256 = ...)` â see `DESIGN.md`
Â§4.4 "Self-hosting the bundle".

To refresh: rebuild the bundle (DESIGN.md Â§4.10), upload the new
`.ttb` + `.ttb.index.gz` to R2, and bump `url`/`sha256`/`version` below.
"/
version
"""DEFAULT_BUNDLE.version"'
url
##"DEFAULT_BUNDLE.url"-
sha256
$$"DEFAULT_BUNDLE.sha256"-
format
%%"DEFAULT_BUNDLE.format*(@@rules_latex//latex/private:bundles.bzl�
Pinned tectonic package bundle.

Tectonic resolves `\usepackage{...}` directives at compile time by fetching
files from a "package bundle" that mirrors a subset of TeX Live.

`rules_latex` pins its own bundle: **`texlive2026`**, a freshly-built
TeX Live 2026 bundle in the `.ttb` (formatspec-v1) format â per-file gzip
plus an internal offset index, so it's HTTP-range-addressable (tectonic
fetches only the files a document needs). We host it on Cloudflare R2 at
`rules-latex.ndl.au` (zero egress, durable), with the `.ttb.index.gz`
sidecar alongside for the web-fetch path. The pinned tectonic 0.16.9
reads this `.ttb` directly (verified in CI).

Why we host our own: upstream `tectonic-texlive-bundles` was archived in
October 2024 with no bundle newer than 2022, and tectonic's relay still
serves the frozen `tlextras-2022.0r0` (biblatex 3.17). Building + hosting
TL2026 ourselves keeps packages current and removes the third-party CDN
dependency. See `DESIGN.md` Â§4.4 (network policy) and Â§4.10 (the
bundle-staleness rationale and the rebuild procedure).

A root module can still repoint the full-bundle download at a different
mirror via `tectonic.bundle(url = ..., sha256 = ...)` â see `DESIGN.md`
Â§4.4 "Self-hosting the bundle".

To refresh: rebuild the bundle (DESIGN.md Â§4.10), upload the new
`.ttb` + `.ttb.index.gz` to R2, and bump `url`/`sha256`/`version` below.
�%
6
rules_latexlatex/privatelatex_cache_snapshot.bzl�latex_cache_snapshot9Bazel-run target that captures a tectonic cache snapshot."�
�
latex_cache_snapshot9Bazel-run target that captures a tectonic cache snapshot.*
nameA unique name for this target. �
biber�If True, prime the cache with biber on PATH so the resulting snapshot contains bibliography-related files. Required when consumers compile biblatex documents against this snapshot.2FalseS
	ctan_lock>Optional version-1 JSON lock of CTAN URLs and SHA-256 digests.2None�
ctan_packages�Names of CTAN packages to download and include in the cache snapshot. Each entry is a CTAN package name (e.g. 'fancyhdr'). Packages are downloaded from CTAN mirrors in TDS format during the snapshot generation.2[]G
deps,Other targets that contribute LaTeX sources.*
	LatexInfo2[]S
mainGThe top-level .tex file passed to tectonic. Must also appear in `srcs`. X
outputJDestination path for the snapshot tarball, relative to the workspace root. �
	pkg_files�Map of label-of-input -> staged-relative-path. Overrides the auto-staging path for the listed inputs, letting you place a file anywhere under main.tex's work directory. Typical use: stage a cross-package `.bib` file as a sibling of main.tex so `\addbibresource{refs.bib}` works without `..` (which tectonic refuses to hand to external tools).	2{}�
srcs�All LaTeX source files needed to compile the document online. The cache snapshot will contain whatever tectonic decides to fetch for this compile, so make sure this list is realistic. "M
latex_cache_snapshot5@@rules_latex//latex/private:latex_cache_snapshot.bzl
��,
*
nameA unique name for this target. �
�
biber�If True, prime the cache with biber on PATH so the resulting snapshot contains bibliography-related files. Required when consumers compile biblatex documents against this snapshot.2FalseU
S
	ctan_lock>Optional version-1 JSON lock of CTAN URLs and SHA-256 digests.2None�
�
ctan_packages�Names of CTAN packages to download and include in the cache snapshot. Each entry is a CTAN package name (e.g. 'fancyhdr'). Packages are downloaded from CTAN mirrors in TDS format during the snapshot generation.2[]I
G
deps,Other targets that contribute LaTeX sources.*
	LatexInfo2[]U
S
mainGThe top-level .tex file passed to tectonic. Must also appear in `srcs`. Z
X
outputJDestination path for the snapshot tarball, relative to the workspace root. �
�
	pkg_files�Map of label-of-input -> staged-relative-path. Overrides the auto-staging path for the listed inputs, letting you place a file anywhere under main.tex's work directory. Typical use: stage a cross-package `.bib` file as a sibling of main.tex so `\addbibresource{refs.bib}` works without `..` (which tectonic refuses to hand to external tools).	2{}�
�
srcs�All LaTeX source files needed to compile the document online. The cache snapshot will contain whatever tectonic decides to fetch for this compile, so make sure this list is realistic. a
//lib:shell.bzlrL

bazel_skyliblib	shell.bzl
shellshell
''',
''.t
//latex:providers.bzlrY
#
rules_latexlatexproviders.bzl$
	LatexInfo	LatexInfo
(,(5
((7�
//latex/private:bundles.bzlri
)
rules_latexlatex/privatebundles.bzl.
DEFAULT_BUNDLEDEFAULT_BUNDLE
)2)@
))B�
#//latex/private:resolved_inputs.bzlrq
1
rules_latexlatex/privateresolved_inputs.bzl.
resolve_inputsresolve_inputs
*:*H
**J�The `latex_cache_snapshot` rule.

`latex_cache_snapshot` produces a small, content-addressed snapshot of
the tectonic cache needed to compile a given document, suitable for
checking into the repository and consuming via `latex_document(cache =
...)`.

Typical workflow:

    latex_document(
        name = "cv",
        main = "cv.tex",
        srcs = ["cv.tex"],
    )

    latex_cache_snapshot(
        name = "cv_cache",
        main = "cv.tex",
        srcs = ["cv.tex"],
        output = "cv_cache.tar.gz",
    )

Then, once, with internet access:

    $ bazel run //:cv_cache

This compiles `cv.tex` once in online mode, captures the resulting
~tens-of-MB tectonic cache, and writes `cv_cache.tar.gz` into the
source tree. After committing the snapshot, `latex_document(cache =
":cv_cache.tar.gz")` builds the document fully offline using only the
snapshot â no internet, no 1.78 GiB full bundle.

The rule is *not* a normal build action because it inherently needs
network access on first invocation and a writable source-tree
destination. It's a developer command, run on demand, much like
`cargo vendor` or `pip-compile`.
�W
0
rules_latexlatex/privatelatex_document.bzl�=latex_document,Compiles a LaTeX source tree using tectonic."�=
�
latex_document,Compiles a LaTeX source tree using tectonic.*
nameA unique name for this target. �
biber�Enable biber bibliography processing. When True, tectonic can shell out to a `biber` binary at compile time, resolving `\\addbibresource`/`\\bibliography` directives via biblatex. The binary comes from the rules_latex toolchain by default; set `biber_strategy = "system"` to use a system install instead.2False�
biber_strategy�Which biber binary to use when `biber = True`. `"toolchain"` (default) uses the rules_latex-vendored biber 2.21, matched to the bundle's biblatex 3.21, on every supported platform. A custom or unsupported toolchain without biber fails at analysis time. `"system"` propagates $PATH so a system-installed biber is found; less hermetic, intended as an escape hatch.2"toolchain"�
cache�Optional cache snapshot tarball (typically produced by `latex_cache_snapshot` and checked into the repository). When set, the action extracts the snapshot into the compile-time `TECTONIC_CACHE_DIR` and runs with `--only-cached`, giving a fully offline, hermetic build without pulling the full ~1.78 GiB tectonic bundle or running an online prime. Takes precedence over the toolchain-level `tectonic.bundle()` and over the implicit cache pipeline.2None�
	ctan_lock�Optional version-1 JSON lock with exact URL and SHA-256 for each CTAN package. Also locks automatically resolved transitive packages; undeclared names are not fetched.2None�
ctan_packages�Names of CTAN packages to fetch and make available to the document. Each entry is a CTAN package name (e.g. 'fancyhdr'). Packages are downloaded from CTAN mirrors in TDS format during the cache population step and bundled into the offline cache. Requires the implicit cache pipeline (default) or a cache snapshot generated with matching `ctan_packages`. Not supported when `tectonic.bundle()` is active (the toolchain-level bundle does not support on-demand CTAN package fetching).2[]r
depsWOther targets that contribute LaTeX sources (typically `latex_library` or `latex_pkg`).*
	LatexInfo2[]S
mainGThe top-level .tex file passed to tectonic. Must also appear in `srcs`. �
outfmtpSingle-file output format: pdf, xdv, or aux. HTML is unsupported because Tectonic can emit multiple HTML assets.2"pdf"�
	pkg_files�Override the staged path of specific inputs. Map of label -> relative path under main.tex's work directory. The default main-rooted staging layout puts each src at a sensible place automatically; use `pkg_files` when the default would force you to write a long or `..`-containing path in main.tex. The classic case is a cross-package bib file: declare `pkg_files = {"//lib/refs:refs.bib": "refs.bib"}` and then write `\\addbibresource{refs.bib}` in main.tex.	2{}�
reproducible�When True, run tectonic in deterministic mode and set SOURCE_DATE_EPOCH=0, producing byte-identical output across runs given identical inputs. Off by default to keep PDF metadata (creation date) reflecting the actual build time. Mutually exclusive with `synctex`.2Falsex
srcslAll LaTeX source files (.tex, .sty, .cls, .bib, images, etc.) that the document compilation might reference. �
synctex�When True, tectonic is invoked with --synctex and the resulting `<name>.synctex.gz` is exposed as an additional output (also surfaced via the `synctex` OutputGroup). Consumed by `latex_live` for reverse-sync lookups (PDF click -> copy `<file>:<line>` to the clipboard; the browser can't drive your editor, so the click doesn't *jump*) and forward-sync (editor -> PDF jump, via `POST /sync/forward`). Mutually exclusive with `reproducible` because tectonic's deterministic mode disables SyncTeX output.2False�
tectonic_argskExtra command-line arguments passed to tectonic. Use sparingly; prefer rule-level attributes when possible.2[]"A
latex_document/@@rules_latex//latex/private:latex_document.bzl
��,
*
nameA unique name for this target. �
�
biber�Enable biber bibliography processing. When True, tectonic can shell out to a `biber` binary at compile time, resolving `\\addbibresource`/`\\bibliography` directives via biblatex. The binary comes from the rules_latex toolchain by default; set `biber_strategy = "system"` to use a system install instead.2False�
�
biber_strategy�Which biber binary to use when `biber = True`. `"toolchain"` (default) uses the rules_latex-vendored biber 2.21, matched to the bundle's biblatex 3.21, on every supported platform. A custom or unsupported toolchain without biber fails at analysis time. `"system"` propagates $PATH so a system-installed biber is found; less hermetic, intended as an escape hatch.2"toolchain"�
�
cache�Optional cache snapshot tarball (typically produced by `latex_cache_snapshot` and checked into the repository). When set, the action extracts the snapshot into the compile-time `TECTONIC_CACHE_DIR` and runs with `--only-cached`, giving a fully offline, hermetic build without pulling the full ~1.78 GiB tectonic bundle or running an online prime. Takes precedence over the toolchain-level `tectonic.bundle()` and over the implicit cache pipeline.2None�
�
	ctan_lock�Optional version-1 JSON lock with exact URL and SHA-256 for each CTAN package. Also locks automatically resolved transitive packages; undeclared names are not fetched.2None�
�
ctan_packages�Names of CTAN packages to fetch and make available to the document. Each entry is a CTAN package name (e.g. 'fancyhdr'). Packages are downloaded from CTAN mirrors in TDS format during the cache population step and bundled into the offline cache. Requires the implicit cache pipeline (default) or a cache snapshot generated with matching `ctan_packages`. Not supported when `tectonic.bundle()` is active (the toolchain-level bundle does not support on-demand CTAN package fetching).2[]t
r
depsWOther targets that contribute LaTeX sources (typically `latex_library` or `latex_pkg`).*
	LatexInfo2[]U
S
mainGThe top-level .tex file passed to tectonic. Must also appear in `srcs`. �
�
outfmtpSingle-file output format: pdf, xdv, or aux. HTML is unsupported because Tectonic can emit multiple HTML assets.2"pdf"�
�
	pkg_files�Override the staged path of specific inputs. Map of label -> relative path under main.tex's work directory. The default main-rooted staging layout puts each src at a sensible place automatically; use `pkg_files` when the default would force you to write a long or `..`-containing path in main.tex. The classic case is a cross-package bib file: declare `pkg_files = {"//lib/refs:refs.bib": "refs.bib"}` and then write `\\addbibresource{refs.bib}` in main.tex.	2{}�
�
reproducible�When True, run tectonic in deterministic mode and set SOURCE_DATE_EPOCH=0, producing byte-identical output across runs given identical inputs. Off by default to keep PDF metadata (creation date) reflecting the actual build time. Mutually exclusive with `synctex`.2Falsez
x
srcslAll LaTeX source files (.tex, .sty, .cls, .bib, images, etc.) that the document compilation might reference. �
�
synctex�When True, tectonic is invoked with --synctex and the resulting `<name>.synctex.gz` is exposed as an additional output (also surfaced via the `synctex` OutputGroup). Consumed by `latex_live` for reverse-sync lookups (PDF click -> copy `<file>:<line>` to the clipboard; the browser can't drive your editor, so the click doesn't *jump*) and forward-sync (editor -> PDF jump, via `POST /sync/forward`). Mutually exclusive with `reproducible` because tectonic's deterministic mode disables SyncTeX output.2False�
�
tectonic_argskExtra command-line arguments passed to tectonic. Use sparingly; prefer rule-level attributes when possible.2[]�
//rules:common_settings.bzlrn
*
bazel_skylibrulescommon_settings.bzl2
BuildSettingInfoBuildSettingInfo
636C
66E�
//latex:providers.bzlr�
#
rules_latexlatexproviders.bzl4
LatexDocumentInfoLatexDocumentInfo
7,7=$
	LatexInfo	LatexInfo
7A7J
77L�
!//latex/private:action_schema.bzlr�
/
rules_latexlatex/privateaction_schema.bzlD
RULES_LATEX_ACTION_SCHEMARULES_LATEX_ACTION_SCHEMA
888Q
88S�
//latex/private:bundles.bzlri
)
rules_latexlatex/privatebundles.bzl.
DEFAULT_BUNDLEDEFAULT_BUNDLE
929@
99B�
#//latex/private:resolved_inputs.bzlrq
1
rules_latexlatex/privateresolved_inputs.bzl.
resolve_inputsresolve_inputs
:::H
::J�The `latex_document` rule.

Compiles a LaTeX source tree into a PDF (or other tectonic-supported format)
using the resolved tectonic toolchain. The rule transitively collects sources
from any `deps` that provide LatexInfo (i.e. `latex_library` / `latex_pkg`).

Three offline-mode strategies, in priority order:

1. `cache = "<file>.tar.gz"` â extract a user-supplied cache snapshot
   into the tectonic cache before compile, run --only-cached. Fully
   offline, fully reproducible, snapshot is checked-in.
2. Toolchain-level `tectonic.bundle()` â pass --bundle <pinned-1.78-GiB-file>
   --only-cached. Fully offline, snapshot is fetched once via
   a Bazel repository rule.
3. **Implicit pipeline** (new in v0.2): when neither (1) nor (2) is set,
   the rule synthesises a PopulateCache action that runs tectonic ONCE
   in online mode and captures the resulting cache directory as a
   tar.gz. That tarball is then an input to TectonicCompile, which
   runs with --only-cached. Bazel's action cache means the
   PopulateCache result is reused across builds and shared via the
   remote cache; any source or configuration change that affects the
   action key triggers a re-run.

### Staging contract (v0.3+)

Both PopulateCache and TectonicCompile stage sources into a work
directory using a **main-rooted layout** before invoking tectonic.
Concretely:

* main.tex lands at `<work>/<main.basename>`.
* Sources under main's package land at the same relative path,
  rooted at the work directory.
* Cross-package sources land under their workspace-relative path
  (e.g. `study/llb/lib/references/refs.bib` from a sibling package).
* The `pkg_files` attribute lets users override placement of any
  specific input, e.g. to stage a cross-package bib file as a sibling
  of main.tex.

Tectonic runs with cwd set to the work directory, so paths in
main.tex like `\input{sections/foo}` or `\graphicspath{{./images/}}`
resolve as the author would expect.

### `biber` modes

* `biber = False` (default) â no bibliography processor available.
* `biber = True` â use the rules_latex-vendored biber from the
  toolchain. The default toolchain provides biber on every supported
  platform; custom or unsupported toolchains must provide their own.
* `biber_strategy = "system"` â escape hatch: propagate $PATH into
  the action so a system-installed biber is found. Less hermetic;
  intended for air-gapped or unsupported-platform builds.
�
/
rules_latexlatex/privatelatex_library.bzl�latex_library,A reusable collection of LaTeX source files."�
�
latex_library,A reusable collection of LaTeX source files.*
nameA unique name for this target. [
deps@Other latex_library / latex_pkg targets this library depends on.*
	LatexInfo2[]M
srcsALaTeX source files (.tex/.sty/.cls/etc.) exposed by this library. "?
latex_library.@@rules_latex//latex/private:latex_library.bzl
&&,
*
nameA unique name for this target. ]
[
deps@Other latex_library / latex_pkg targets this library depends on.*
	LatexInfo2[]O
M
srcsALaTeX source files (.tex/.sty/.cls/etc.) exposed by this library. t
//latex:providers.bzlrY
#
rules_latexlatexproviders.bzl$
	LatexInfo	LatexInfo
	,	5
		7�The `latex_library` rule.

A `latex_library` is a logical grouping of related LaTeX sources (style files,
class files, shared preamble, helper macros) that one or more
`latex_document`s depend on. It produces no PDF output; it simply propagates
its sources via `LatexInfo` for downstream rules to assemble.
�=
,
rules_latexlatex/privatelatex_live.bzl�(
latex_live7Browser-based live-preview server for a latex_document."�(
�

latex_live7Browser-based live-preview server for a latex_document.*
nameA unique name for this target. �
debounce_max_ms�Safety net for the debouncer: never wait more than this many milliseconds before firing a build, even if changes keep arriving. Without this cap, a user typing continuously into an editor with fast-autosave-on-every-keystroke would never see a rebuild. 1500 ms matches the upper bound where a user typically expects 'okay, something should happen now'.21500�
debounce_ms�How many milliseconds of source-idle to require after a detected change before triggering a rebuild. Coalesces bursts of writes (e.g. format-on-save then user-save, or editors that write multiple files near-simultaneously) into a single build. Set to 0 to disable debouncing (rebuild on every poll-detected change; reproduces pre-v0.3.3 behaviour). The default of 250 ms is invisible to the user because the build itself takes longer than the debounce window.2250g
documentJThe latex_document (or any rule providing LatexInfo) to watch and rebuild. *
	LatexInfo�
open_on_start�If True, open the preview in the system default web browser once the server starts. The plain http URL is always printed regardless, so you can open it however you prefer.2False�
poll_interval_ms�How often the watcher checks for source-file changes, in milliseconds. The watcher is a polling loop (no third-party `watchdog`/inotify dependency), so this is the amortised cost of one stat() per watched file per interval. 80 ms keeps perceived save-to-preview latency under 100 ms while staying cheap. Independent of `debounce_ms`: the poll interval is how fast we *notice* a change; the debounce window is how long we *wait* after a change before triggering a build.280H
port8TCP port to bind the preview server to (localhost-only).28765�

serve_fast�Opt-in latency optimisation (default False). When True, the watcher replays the compiled action's invocation directly via tectonic_compile.py on each content edit instead of shelling out to `bazel build`, skipping Bazel analysis + sandbox setup (~50% of warm-rebuild latency). The first build, and any fast build that hits a missing cached resource, still go through `bazel build`, so the canonical build path is never bypassed for anything but content recompiles. Requires the watched target to be a real latex_document. The compile runs un-sandboxed but stages only the document's declared inputs, so it stays consistent with `bazel build` / CI. See DESIGN.md Â§4.7.4.2False"9

latex_live+@@rules_latex//latex/private:latex_live.bzl
��,
*
nameA unique name for this target. �
�
debounce_max_ms�Safety net for the debouncer: never wait more than this many milliseconds before firing a build, even if changes keep arriving. Without this cap, a user typing continuously into an editor with fast-autosave-on-every-keystroke would never see a rebuild. 1500 ms matches the upper bound where a user typically expects 'okay, something should happen now'.21500�
�
debounce_ms�How many milliseconds of source-idle to require after a detected change before triggering a rebuild. Coalesces bursts of writes (e.g. format-on-save then user-save, or editors that write multiple files near-simultaneously) into a single build. Set to 0 to disable debouncing (rebuild on every poll-detected change; reproduces pre-v0.3.3 behaviour). The default of 250 ms is invisible to the user because the build itself takes longer than the debounce window.2250i
g
documentJThe latex_document (or any rule providing LatexInfo) to watch and rebuild. *
	LatexInfo�
�
open_on_start�If True, open the preview in the system default web browser once the server starts. The plain http URL is always printed regardless, so you can open it however you prefer.2False�
�
poll_interval_ms�How often the watcher checks for source-file changes, in milliseconds. The watcher is a polling loop (no third-party `watchdog`/inotify dependency), so this is the amortised cost of one stat() per watched file per interval. 80 ms keeps perceived save-to-preview latency under 100 ms while staying cheap. Independent of `debounce_ms`: the poll interval is how fast we *notice* a change; the debounce window is how long we *wait* after a change before triggering a build.280J
H
port8TCP port to bind the preview server to (localhost-only).28765�
�

serve_fast�Opt-in latency optimisation (default False). When True, the watcher replays the compiled action's invocation directly via tectonic_compile.py on each content edit instead of shelling out to `bazel build`, skipping Bazel analysis + sandbox setup (~50% of warm-rebuild latency). The first build, and any fast build that hits a missing cached resource, still go through `bazel build`, so the canonical build path is never bypassed for anything but content recompiles. Requires the watched target to be a real latex_document. The compile runs un-sandboxed but stages only the document's declared inputs, so it stays consistent with `bazel build` / CI. See DESIGN.md Â§4.7.4.2Falsea
//lib:shell.bzlrL

bazel_skyliblib	shell.bzl
shellshell
9'9,
99.�
//latex:providers.bzlr�
#
rules_latexlatexproviders.bzl4
LatexDocumentInfoLatexDocumentInfo
:,:=$
	LatexInfo	LatexInfo
:A:J
::L�The `latex_live` rule.

`latex_live` is the live-preview rule. It runs a small HTTP
server on localhost, watches the document's transitive sources,
rebuilds through Bazel (or the opt-in content-only fast path), and
pushes changed PDF chunks to the connected browser tab over WebSocket
(with SSE as fallback). The PDF is rendered via PDF.js, with scroll
position, zoom level, and current page preserved across reloads
so editing doesn't bounce you back to page 1.

Typical usage:

    latex_document(name = "cv", main = "cv.tex", srcs = [...], cache = "cv_cache.tar.gz")

    latex_live(
        name = "cv_live",
        document = ":cv",
    )

Then:

    $ bazel run //:cv_live
    serving live preview at http://127.0.0.1:8765/

Open the URL in your browser; edit the source; watch the PDF update.

Design notes:

* No third-party Python runtime packages. The server runs under the pinned
  Python 3.13 toolchain, uses a small stdlib RFC 6455 implementation for the
  preferred WebSocket transport, and retains Server-Sent Events as a fallback.

* PDF.js is vendored: the pinned pdfjs-dist tarball lives in
  `@rules_latex_pdfjs` (materialised by the `pdfjs` module extension)
  and is served at `/_pdfjs/pdf.mjs` and `/_pdfjs/pdf.worker.mjs` by
  the running server. No CDN dependency at preview time.

* The default rebuild path shells out to `bazel build`, so live mode and CI
  use the same toolchain, sandbox, and cache. `serve_fast = True` opts ordinary
  content edits into a direct compile replay with Bazel fallback. See
  `DESIGN.md` Â§4.7.

* Implicit-pipeline serve acceleration. When the served document
  takes the implicit-cache pipeline (no `cache=`, no toolchain
  bundle), the serve script primes a persistent cache snapshot
  under `$BUILD_WORKSPACE_DIRECTORY/.cache/rules_latex/<doc>/` on
  startup and passes it to every `bazel build` via the private
  `//latex:_serve_cache_override` flag. This sidesteps Bazel's
  action-cache invalidation on source-content changes, turning what
  would otherwise be a 30-90 s per-edit online re-prime into a 2-3
  s offline compile. The cache is auto-refreshed on missing-resource
  build failures. See `tools/serve_cache.py` for the cache-manager
  logic, and `//latex:_serve_cache_override` for the rule-side
  wiring.
�
+
rules_latexlatex/privatelatex_pkg.bzl�	latex_pkgFA bundle of resource files (images, bib, fonts) consumed by documents."�
�
	latex_pkgFA bundle of resource files (images, bib, fonts) consumed by documents.*
nameA unique name for this target. 3
srcs'Resource files exposed by this package. "7
	latex_pkg*@@rules_latex//latex/private:latex_pkg.bzl
,
*
nameA unique name for this target. 5
3
srcs'Resource files exposed by this package. t
//latex:providers.bzlrY
#
rules_latexlatexproviders.bzl$
	LatexInfo	LatexInfo
,5
7�The `latex_pkg` rule.

`latex_pkg` is conceptually a leaf bundle of resources â typically images,
fonts, bibliographies, or other data files â that documents may need to
reference but that aren't themselves LaTeX source. It is functionally similar
to `latex_library` but is intended to make the distinction visible at the
call site:

    latex_library(name = "macros", srcs = ["preamble.tex", "mymacros.sty"])
    latex_pkg(name = "figures", srcs = glob(["figures/*.png"]))
�
0
rules_latexlatex/privatepdfjs_versions.bzl�	PDFJS_TARBALL�Pinned PDF.js distribution.

PDF.js is the JavaScript runtime that `latex_live` uses to render
the preview PDF in the browser. We vendor it via a repository rule
(rather than letting the browser hit cdn.jsdelivr.net at page-load
time) so the live-preview flow works air-gapped and so the version is
content-addressed at build time, matching the rest of the rule set.

To update: bump `PDFJS_VERSION`, download the new
`pdfjs-dist-<version>.tgz` from registry.npmjs.org, compute its
sha256, and bump the hash below.
z�
PDFJS_TARBALL
�Pinned PDF.js distribution.

PDF.js is the JavaScript runtime that `latex_live` uses to render
the preview PDF in the browser. We vendor it via a repository rule
(rather than letting the browser hit cdn.jsdelivr.net at page-load
time) so the live-preview flow works air-gapped and so the version is
content-addressed at build time, matching the rest of the rule set.

To update: bump `PDFJS_VERSION`, download the new
`pdfjs-dist-<version>.tgz` from registry.npmjs.org, compute its
sha256, and bump the hash below.
"&
url
"PDFJS_TARBALL.url",
sha256
"PDFJS_TARBALL.sha256*/@@rules_latex//latex/private:pdfjs_versions.bzl%	PDFJS_VERSION5.4.149j	5.4.149�Pinned PDF.js distribution.

PDF.js is the JavaScript runtime that `latex_live` uses to render
the preview PDF in the browser. We vendor it via a repository rule
(rather than letting the browser hit cdn.jsdelivr.net at page-load
time) so the live-preview flow works air-gapped and so the version is
content-addressed at build time, matching the rest of the rule set.

To update: bump `PDFJS_VERSION`, download the new
`pdfjs-dist-<version>.tgz` from registry.npmjs.org, compute its
sha256, and bump the hash below.
�
1
rules_latexlatex/privateresolved_inputs.bzl�resolve_inputs�Resolve inputs once for document, test, and snapshot consumers.

Each consumer still chooses its own cache, biber, output, and execution
policy.
*�
�
resolve_inputsL
ctxAthe rule context with main, srcs, deps, and pkg_files attributes. (�Resolve inputs once for document, test, and snapshot consumers.

Each consumer still chooses its own cache, biber, output, and execution
policy.
"`
^A struct with `main`, a transitive `srcs` depset, and
`(File, staged_path)` `pkg_files` pairs.2B
resolve_inputs0@@rules_latex//latex/private:resolved_inputs.bzl
t
//latex:providers.bzlrY
#
rules_latexlatexproviders.bzl$
	LatexInfo	LatexInfo
,5
7;The common source and staging inputs of a LaTeX invocation.�
*
rules_latexlatex/privateversions.bzl�tectonic_download_url;Build the GitHub release download URL for a tectonic asset.*�
�
tectonic_download_url
asset (
version"0.16.9"(;Build the GitHub release download URL for a tectonic asset.2B
tectonic_download_url)@@rules_latex//latex/private:versions.bzl
++&	TECTONIC_VERSION0.16.9j0.16.9�Pinned tectonic release artifacts.

To update: bump TECTONIC_VERSION, regenerate the SHA256 hashes by downloading
each artifact and running `sha256sum`, and update this file. The integrity
hashes are baked in so that `bazel build` is reproducible and offline once
the repository cache is warm.
�
-
rules_latexlatex/toolchaintoolchain.bzl�
latex_toolchain)Defines a tectonic-based LaTeX toolchain."�	
�
latex_toolchain)Defines a tectonic-based LaTeX toolchain.*
nameA unique name for this target. �
biber�Optional biber executable. When set, latex_document actions invoked with `biber = True` make this binary available on PATH so tectonic can shell out to it for bibliography processing. Vendored for every supported platform (biber 2.21).2None�
bundle�Optional fully downloaded package bundle (.ttb or legacy .tar). When set, the toolchain runs tectonic with `--bundle` pointed at this file, making compilation fully hermetic.2None(
tectonicThe tectonic executable. "?
latex_toolchain,@@rules_latex//latex/toolchain:toolchain.bzl
((,
*
nameA unique name for this target. �
�
biber�Optional biber executable. When set, latex_document actions invoked with `biber = True` make this binary available on PATH so tectonic can shell out to it for bibliography processing. Vendored for every supported platform (biber 2.21).2None�
�
bundle�Optional fully downloaded package bundle (.ttb or legacy .tar). When set, the toolchain runs tectonic with `--bundle` pointed at this file, making compilation fully hermetic.2None*
(
tectonicThe tectonic executable. �
LatexToolchainInfoResolved tectonic toolchain.2�	
�
LatexToolchainInfoResolved tectonic toolchain.*
tectonicFile: the tectonic executable.G
tectonic_tool6FilesToRunProvider: executable plus its runtime files.;
tectonic_runfiles&Runfiles: runtime files for launchers.s
bundleiFile|None: a fully downloaded offline package bundle, or None for range-fetched/implicit-cache operation.w
bibernFile|None: a biber executable for bibliography processing, or None if biber isn't available for this platform.D

biber_tool6FilesToRunProvider|None: biber plus its runtime files.C
biber_runfiles1Runfiles|None: runtime files for biber launchers."B
LatexToolchainInfo,@@rules_latex//latex/toolchain:toolchain.bzl
,
*
tectonicFile: the tectonic executable.I
G
tectonic_tool6FilesToRunProvider: executable plus its runtime files.=
;
tectonic_runfiles&Runfiles: runtime files for launchers.u
s
bundleiFile|None: a fully downloaded offline package bundle, or None for range-fetched/implicit-cache operation.y
w
bibernFile|None: a biber executable for bibliography processing, or None if biber isn't available for this platform.F
D

biber_tool6FilesToRunProvider|None: biber plus its runtime files.E
C
biber_runfiles1Runfiles|None: runtime files for biber launchers.�The `latex_toolchain` rule.

A `latex_toolchain` packages everything an action needs to invoke tectonic:
the binary itself, optionally a pre-fetched package bundle, and optionally
a biber binary for bibliography processing.

Toolchains of this type are registered automatically by the `tectonic` module
extension defined in `//latex/toolchain:extensions.bzl`.
�
.
rules_latexlatex/toolchainextensions.bzl�	tectonicJ�	
�
tectonic
	toolchain�
bundleq
formataOptional bundle file extension (ttb/tar) for an overridden bundle; defaults to the pinned format.2""K
sha256;SHA-256 of the bundle at `url`. Required when `url` is set.2""n
urlaOverride URL for the bundle (root module only). Requires `sha256`. Defaults to the pinned bundle.2""A
version0Optional version label for an overridden bundle.2"""9
tectonic-@@rules_latex//latex/toolchain:extensions.bzl
��

	toolchain�
�
bundleq
formataOptional bundle file extension (ttb/tar) for an overridden bundle; defaults to the pinned format.2""K
sha256;SHA-256 of the bundle at `url`. Required when `url` is set.2""n
urlaOverride URL for the bundle (root module only). Requires `sha256`. Defaults to the pinned bundle.2""A
version0Optional version label for an overridden bundle.2""s
q
formataOptional bundle file extension (ttb/tar) for an overridden bundle; defaults to the pinned format.2""M
K
sha256;SHA-256 of the bundle at `url`. Required when `url` is set.2""p
n
urlaOverride URL for the bundle (root module only). Requires `sha256`. Defaults to the pinned bundle.2""C
A
version0Optional version label for an overridden bundle.2""�
"//latex/private:biber_versions.bzlrp
0
rules_latexlatex/privatebiber_versions.bzl.
BIBER_RELEASESBIBER_RELEASES

�
//latex/private:bundles.bzlri
)
rules_latexlatex/privatebundles.bzl.
DEFAULT_BUNDLEDEFAULT_BUNDLE

�
"//latex/toolchain:repositories.bzlr�
0
rules_latexlatex/toolchainrepositories.bzl2
biber_repositorybiber_repository
F
tectonic_bundle_repositorytectonic_bundle_repository
   8
tectonic_repositorytectonic_repository
!!
"�The `tectonic` module extension.

A consumer's MODULE.bazel does:

    tectonic = use_extension("@rules_latex//latex/toolchain:extensions.bzl", "tectonic")
    tectonic.toolchain()
    use_repo(tectonic, "rules_latex_tectonic_toolchains")
    register_toolchains("@rules_latex_tectonic_toolchains//:all")

For fully-hermetic, offline-capable builds, also opt into the pinned
package bundle (downloaded once and passed via `--bundle`):

    tectonic.bundle()

This produces a hub repo named `rules_latex_tectonic_toolchains` that
registers a `toolchain()` for every supported platform, plus one leaf repo
per platform that holds the downloaded tectonic binary, plus (when
`tectonic.bundle()` is requested) a single repo with the pinned bundle.
�/
0
rules_latexlatex/toolchainrepositories.bzl�	biber_repository3Downloads a platform-specific biber binary release.R�	
�
biber_repository3Downloads a platform-specific biber binary release..
name"A unique name for this repository. 	
cpu 
os �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 *C
biber_repository/@@rules_latex//latex/toolchain:repositories.bzl
�#�#0
.
name"A unique name for this repository. 
	
cpu 


os �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �tectonic_bundle_repositoryBDownloads the pinned (or root-overridden) tectonic package bundle.R�
�
tectonic_bundle_repositoryBDownloads the pinned (or root-overridden) tectonic package bundle..
name"A unique name for this repository. R
formatBBundle file extension (ttb/tar); empty uses DEFAULT_BUNDLE.format.2""�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 H
sha2568SHA-256 of the bundle; empty uses DEFAULT_BUNDLE.sha256.2""B
url5Bundle URL; empty uses the pinned DEFAULT_BUNDLE.url.2""<
version+Informational version label for the bundle.2""*M
tectonic_bundle_repository/@@rules_latex//latex/toolchain:repositories.bzl
w-w-0
.
name"A unique name for this repository. T
R
formatBBundle file extension (ttb/tar); empty uses DEFAULT_BUNDLE.format.2""�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 J
H
sha2568SHA-256 of the bundle; empty uses DEFAULT_BUNDLE.sha256.2""D
B
url5Bundle URL; empty uses the pinned DEFAULT_BUNDLE.url.2"">
<
version+Informational version label for the bundle.2""�tectonic_repository6Downloads a platform-specific tectonic binary release.R�
�
tectonic_repository6Downloads a platform-specific tectonic binary release..
name"A unique name for this repository. �

biber_repo�Optional name of a biber_repository whose `:biber` target should be wired into the generated latex_toolchain. Empty when no biber binary is available for this platform.2""�
bundle_repo�Optional name of a tectonic_bundle_repository whose `:bundle` target should be wired into the generated latex_toolchain. Leave empty for online mode.2""	
cpu 
os �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 *F
tectonic_repository/@@rules_latex//latex/toolchain:repositories.bzl
F&F&0
.
name"A unique name for this repository. �
�

biber_repo�Optional name of a biber_repository whose `:biber` target should be wired into the generated latex_toolchain. Empty when no biber binary is available for this platform.2""�
�
bundle_repo�Optional name of a tectonic_bundle_repository whose `:bundle` target should be wired into the generated latex_toolchain. Leave empty for online mode.2""
	
cpu 


os �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
"//latex/private:biber_versions.bzlr�
0
rules_latexlatex/privatebiber_versions.bzl.
BIBER_RELEASESBIBER_RELEASES
6
biber_download_urlbiber_download_url

	�
//latex/private:bundles.bzlri
)
rules_latexlatex/privatebundles.bzl.
DEFAULT_BUNDLEDEFAULT_BUNDLE

�
//latex/private:versions.bzlr�
*
rules_latexlatex/privateversions.bzl4
TECTONIC_RELEASESTECTONIC_RELEASES
2
TECTONIC_VERSIONTECTONIC_VERSION
<
tectonic_download_urltectonic_download_url

�Repository rules that download tectonic and biber binaries.

These are invoked by the `tectonic` module extension (see extensions.bzl) to
materialise one repository per (os, cpu) platform pair, plus an optional
bundle repository when `tectonic.bundle()` is requested and a biber
toolchain per platform that has an upstream binary.
�
(
rules_latex	latex/webextensions.bzl�pdfjs=Provides @rules_latex_pdfjs, the bundled PDF.js distribution.J�
x
pdfjs=Provides @rules_latex_pdfjs, the bundled PDF.js distribution."0
pdfjs'@@rules_latex//latex/web:extensions.bzl
�
//latex/web:repositories.bzlrn
*
rules_latex	latex/webrepositories.bzl2
pdfjs_repositorypdfjs_repository
3C
E�The `pdfjs` module extension.

Materialises the `@rules_latex_pdfjs` repository that holds the pinned
PDF.js distribution used by `latex_live`. Consumers' MODULE.bazel
does:

    pdfjs = use_extension("@rules_latex//latex/web:extensions.bzl", "pdfjs")
    use_repo(pdfjs, "rules_latex_pdfjs")

There's nothing user-tunable on the extension yet â the version is
pinned in `//latex/private:pdfjs_versions.bzl`. A future
`pdfjs.version(name = ...)` tag could let consumers bump it
independently of a rules_latex release if they need a newer PDF.js
release before we cut one.
�
*
rules_latex	latex/webrepositories.bzl�
pdfjs_repository�Downloads the pinned pdfjs-dist tarball from the npm registry and exposes pdf.mjs / pdf.worker.mjs at the repo root. Pinned version: 5.4.149.R�	
�
pdfjs_repository�Downloads the pinned pdfjs-dist tarball from the npm registry and exposes pdf.mjs / pdf.worker.mjs at the repo root. Pinned version: 5.4.149..
name"A unique name for this repository. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 *=
pdfjs_repository)@@rules_latex//latex/web:repositories.bzl
;#;#0
.
name"A unique name for this repository. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
"//latex/private:pdfjs_versions.bzlr�
0
rules_latexlatex/privatepdfjs_versions.bzl,
PDFJS_TARBALLPDFJS_TARBALL
,
PDFJS_VERSIONPDFJS_VERSION

<Repository rule that fetches the pinned PDF.js distribution.��

rules_latexlatexdefs.bzl�latex_cache_snapshot9Bazel-run target that captures a tectonic cache snapshot."�
�
latex_cache_snapshot9Bazel-run target that captures a tectonic cache snapshot.*
nameA unique name for this target. �
biber�If True, prime the cache with biber on PATH so the resulting snapshot contains bibliography-related files. Required when consumers compile biblatex documents against this snapshot.2FalseS
	ctan_lock>Optional version-1 JSON lock of CTAN URLs and SHA-256 digests.2None�
ctan_packages�Names of CTAN packages to download and include in the cache snapshot. Each entry is a CTAN package name (e.g. 'fancyhdr'). Packages are downloaded from CTAN mirrors in TDS format during the snapshot generation.2[]G
deps,Other targets that contribute LaTeX sources.*
	LatexInfo2[]S
mainGThe top-level .tex file passed to tectonic. Must also appear in `srcs`. X
outputJDestination path for the snapshot tarball, relative to the workspace root. �
	pkg_files�Map of label-of-input -> staged-relative-path. Overrides the auto-staging path for the listed inputs, letting you place a file anywhere under main.tex's work directory. Typical use: stage a cross-package `.bib` file as a sibling of main.tex so `\addbibresource{refs.bib}` works without `..` (which tectonic refuses to hand to external tools).	2{}�
srcs�All LaTeX source files needed to compile the document online. The cache snapshot will contain whatever tectonic decides to fetch for this compile, so make sure this list is realistic. "5
latex_cache_snapshot@@rules_latex//latex:defs.bzl
��,
*
nameA unique name for this target. �
�
biber�If True, prime the cache with biber on PATH so the resulting snapshot contains bibliography-related files. Required when consumers compile biblatex documents against this snapshot.2FalseU
S
	ctan_lock>Optional version-1 JSON lock of CTAN URLs and SHA-256 digests.2None�
�
ctan_packages�Names of CTAN packages to download and include in the cache snapshot. Each entry is a CTAN package name (e.g. 'fancyhdr'). Packages are downloaded from CTAN mirrors in TDS format during the snapshot generation.2[]I
G
deps,Other targets that contribute LaTeX sources.*
	LatexInfo2[]U
S
mainGThe top-level .tex file passed to tectonic. Must also appear in `srcs`. Z
X
outputJDestination path for the snapshot tarball, relative to the workspace root. �
�
	pkg_files�Map of label-of-input -> staged-relative-path. Overrides the auto-staging path for the listed inputs, letting you place a file anywhere under main.tex's work directory. Typical use: stage a cross-package `.bib` file as a sibling of main.tex so `\addbibresource{refs.bib}` works without `..` (which tectonic refuses to hand to external tools).	2{}�
�
srcs�All LaTeX source files needed to compile the document online. The cache snapshot will contain whatever tectonic decides to fetch for this compile, so make sure this list is realistic. �=latex_document,Compiles a LaTeX source tree using tectonic."�=
�
latex_document,Compiles a LaTeX source tree using tectonic.*
nameA unique name for this target. �
biber�Enable biber bibliography processing. When True, tectonic can shell out to a `biber` binary at compile time, resolving `\\addbibresource`/`\\bibliography` directives via biblatex. The binary comes from the rules_latex toolchain by default; set `biber_strategy = "system"` to use a system install instead.2False�
biber_strategy�Which biber binary to use when `biber = True`. `"toolchain"` (default) uses the rules_latex-vendored biber 2.21, matched to the bundle's biblatex 3.21, on every supported platform. A custom or unsupported toolchain without biber fails at analysis time. `"system"` propagates $PATH so a system-installed biber is found; less hermetic, intended as an escape hatch.2"toolchain"�
cache�Optional cache snapshot tarball (typically produced by `latex_cache_snapshot` and checked into the repository). When set, the action extracts the snapshot into the compile-time `TECTONIC_CACHE_DIR` and runs with `--only-cached`, giving a fully offline, hermetic build without pulling the full ~1.78 GiB tectonic bundle or running an online prime. Takes precedence over the toolchain-level `tectonic.bundle()` and over the implicit cache pipeline.2None�
	ctan_lock�Optional version-1 JSON lock with exact URL and SHA-256 for each CTAN package. Also locks automatically resolved transitive packages; undeclared names are not fetched.2None�
ctan_packages�Names of CTAN packages to fetch and make available to the document. Each entry is a CTAN package name (e.g. 'fancyhdr'). Packages are downloaded from CTAN mirrors in TDS format during the cache population step and bundled into the offline cache. Requires the implicit cache pipeline (default) or a cache snapshot generated with matching `ctan_packages`. Not supported when `tectonic.bundle()` is active (the toolchain-level bundle does not support on-demand CTAN package fetching).2[]r
depsWOther targets that contribute LaTeX sources (typically `latex_library` or `latex_pkg`).*
	LatexInfo2[]S
mainGThe top-level .tex file passed to tectonic. Must also appear in `srcs`. �
outfmtpSingle-file output format: pdf, xdv, or aux. HTML is unsupported because Tectonic can emit multiple HTML assets.2"pdf"�
	pkg_files�Override the staged path of specific inputs. Map of label -> relative path under main.tex's work directory. The default main-rooted staging layout puts each src at a sensible place automatically; use `pkg_files` when the default would force you to write a long or `..`-containing path in main.tex. The classic case is a cross-package bib file: declare `pkg_files = {"//lib/refs:refs.bib": "refs.bib"}` and then write `\\addbibresource{refs.bib}` in main.tex.	2{}�
reproducible�When True, run tectonic in deterministic mode and set SOURCE_DATE_EPOCH=0, producing byte-identical output across runs given identical inputs. Off by default to keep PDF metadata (creation date) reflecting the actual build time. Mutually exclusive with `synctex`.2Falsex
srcslAll LaTeX source files (.tex, .sty, .cls, .bib, images, etc.) that the document compilation might reference. �
synctex�When True, tectonic is invoked with --synctex and the resulting `<name>.synctex.gz` is exposed as an additional output (also surfaced via the `synctex` OutputGroup). Consumed by `latex_live` for reverse-sync lookups (PDF click -> copy `<file>:<line>` to the clipboard; the browser can't drive your editor, so the click doesn't *jump*) and forward-sync (editor -> PDF jump, via `POST /sync/forward`). Mutually exclusive with `reproducible` because tectonic's deterministic mode disables SyncTeX output.2False�
tectonic_argskExtra command-line arguments passed to tectonic. Use sparingly; prefer rule-level attributes when possible.2[]"/
latex_document@@rules_latex//latex:defs.bzl
��,
*
nameA unique name for this target. �
�
biber�Enable biber bibliography processing. When True, tectonic can shell out to a `biber` binary at compile time, resolving `\\addbibresource`/`\\bibliography` directives via biblatex. The binary comes from the rules_latex toolchain by default; set `biber_strategy = "system"` to use a system install instead.2False�
�
biber_strategy�Which biber binary to use when `biber = True`. `"toolchain"` (default) uses the rules_latex-vendored biber 2.21, matched to the bundle's biblatex 3.21, on every supported platform. A custom or unsupported toolchain without biber fails at analysis time. `"system"` propagates $PATH so a system-installed biber is found; less hermetic, intended as an escape hatch.2"toolchain"�
�
cache�Optional cache snapshot tarball (typically produced by `latex_cache_snapshot` and checked into the repository). When set, the action extracts the snapshot into the compile-time `TECTONIC_CACHE_DIR` and runs with `--only-cached`, giving a fully offline, hermetic build without pulling the full ~1.78 GiB tectonic bundle or running an online prime. Takes precedence over the toolchain-level `tectonic.bundle()` and over the implicit cache pipeline.2None�
�
	ctan_lock�Optional version-1 JSON lock with exact URL and SHA-256 for each CTAN package. Also locks automatically resolved transitive packages; undeclared names are not fetched.2None�
�
ctan_packages�Names of CTAN packages to fetch and make available to the document. Each entry is a CTAN package name (e.g. 'fancyhdr'). Packages are downloaded from CTAN mirrors in TDS format during the cache population step and bundled into the offline cache. Requires the implicit cache pipeline (default) or a cache snapshot generated with matching `ctan_packages`. Not supported when `tectonic.bundle()` is active (the toolchain-level bundle does not support on-demand CTAN package fetching).2[]t
r
depsWOther targets that contribute LaTeX sources (typically `latex_library` or `latex_pkg`).*
	LatexInfo2[]U
S
mainGThe top-level .tex file passed to tectonic. Must also appear in `srcs`. �
�
outfmtpSingle-file output format: pdf, xdv, or aux. HTML is unsupported because Tectonic can emit multiple HTML assets.2"pdf"�
�
	pkg_files�Override the staged path of specific inputs. Map of label -> relative path under main.tex's work directory. The default main-rooted staging layout puts each src at a sensible place automatically; use `pkg_files` when the default would force you to write a long or `..`-containing path in main.tex. The classic case is a cross-package bib file: declare `pkg_files = {"//lib/refs:refs.bib": "refs.bib"}` and then write `\\addbibresource{refs.bib}` in main.tex.	2{}�
�
reproducible�When True, run tectonic in deterministic mode and set SOURCE_DATE_EPOCH=0, producing byte-identical output across runs given identical inputs. Off by default to keep PDF metadata (creation date) reflecting the actual build time. Mutually exclusive with `synctex`.2Falsez
x
srcslAll LaTeX source files (.tex, .sty, .cls, .bib, images, etc.) that the document compilation might reference. �
�
synctex�When True, tectonic is invoked with --synctex and the resulting `<name>.synctex.gz` is exposed as an additional output (also surfaced via the `synctex` OutputGroup). Consumed by `latex_live` for reverse-sync lookups (PDF click -> copy `<file>:<line>` to the clipboard; the browser can't drive your editor, so the click doesn't *jump*) and forward-sync (editor -> PDF jump, via `POST /sync/forward`). Mutually exclusive with `reproducible` because tectonic's deterministic mode disables SyncTeX output.2False�
�
tectonic_argskExtra command-line arguments passed to tectonic. Use sparingly; prefer rule-level attributes when possible.2[]�latex_library,A reusable collection of LaTeX source files."�
�
latex_library,A reusable collection of LaTeX source files.*
nameA unique name for this target. [
deps@Other latex_library / latex_pkg targets this library depends on.*
	LatexInfo2[]M
srcsALaTeX source files (.tex/.sty/.cls/etc.) exposed by this library. ".
latex_library@@rules_latex//latex:defs.bzl
&&,
*
nameA unique name for this target. ]
[
deps@Other latex_library / latex_pkg targets this library depends on.*
	LatexInfo2[]O
M
srcsALaTeX source files (.tex/.sty/.cls/etc.) exposed by this library. �(
latex_live7Browser-based live-preview server for a latex_document."�(
�

latex_live7Browser-based live-preview server for a latex_document.*
nameA unique name for this target. �
debounce_max_ms�Safety net for the debouncer: never wait more than this many milliseconds before firing a build, even if changes keep arriving. Without this cap, a user typing continuously into an editor with fast-autosave-on-every-keystroke would never see a rebuild. 1500 ms matches the upper bound where a user typically expects 'okay, something should happen now'.21500�
debounce_ms�How many milliseconds of source-idle to require after a detected change before triggering a rebuild. Coalesces bursts of writes (e.g. format-on-save then user-save, or editors that write multiple files near-simultaneously) into a single build. Set to 0 to disable debouncing (rebuild on every poll-detected change; reproduces pre-v0.3.3 behaviour). The default of 250 ms is invisible to the user because the build itself takes longer than the debounce window.2250g
documentJThe latex_document (or any rule providing LatexInfo) to watch and rebuild. *
	LatexInfo�
open_on_start�If True, open the preview in the system default web browser once the server starts. The plain http URL is always printed regardless, so you can open it however you prefer.2False�
poll_interval_ms�How often the watcher checks for source-file changes, in milliseconds. The watcher is a polling loop (no third-party `watchdog`/inotify dependency), so this is the amortised cost of one stat() per watched file per interval. 80 ms keeps perceived save-to-preview latency under 100 ms while staying cheap. Independent of `debounce_ms`: the poll interval is how fast we *notice* a change; the debounce window is how long we *wait* after a change before triggering a build.280H
port8TCP port to bind the preview server to (localhost-only).28765�

serve_fast�Opt-in latency optimisation (default False). When True, the watcher replays the compiled action's invocation directly via tectonic_compile.py on each content edit instead of shelling out to `bazel build`, skipping Bazel analysis + sandbox setup (~50% of warm-rebuild latency). The first build, and any fast build that hits a missing cached resource, still go through `bazel build`, so the canonical build path is never bypassed for anything but content recompiles. Requires the watched target to be a real latex_document. The compile runs un-sandboxed but stages only the document's declared inputs, so it stays consistent with `bazel build` / CI. See DESIGN.md Â§4.7.4.2False"+

latex_live@@rules_latex//latex:defs.bzl
��,
*
nameA unique name for this target. �
�
debounce_max_ms�Safety net for the debouncer: never wait more than this many milliseconds before firing a build, even if changes keep arriving. Without this cap, a user typing continuously into an editor with fast-autosave-on-every-keystroke would never see a rebuild. 1500 ms matches the upper bound where a user typically expects 'okay, something should happen now'.21500�
�
debounce_ms�How many milliseconds of source-idle to require after a detected change before triggering a rebuild. Coalesces bursts of writes (e.g. format-on-save then user-save, or editors that write multiple files near-simultaneously) into a single build. Set to 0 to disable debouncing (rebuild on every poll-detected change; reproduces pre-v0.3.3 behaviour). The default of 250 ms is invisible to the user because the build itself takes longer than the debounce window.2250i
g
documentJThe latex_document (or any rule providing LatexInfo) to watch and rebuild. *
	LatexInfo�
�
open_on_start�If True, open the preview in the system default web browser once the server starts. The plain http URL is always printed regardless, so you can open it however you prefer.2False�
�
poll_interval_ms�How often the watcher checks for source-file changes, in milliseconds. The watcher is a polling loop (no third-party `watchdog`/inotify dependency), so this is the amortised cost of one stat() per watched file per interval. 80 ms keeps perceived save-to-preview latency under 100 ms while staying cheap. Independent of `debounce_ms`: the poll interval is how fast we *notice* a change; the debounce window is how long we *wait* after a change before triggering a build.280J
H
port8TCP port to bind the preview server to (localhost-only).28765�
�

serve_fast�Opt-in latency optimisation (default False). When True, the watcher replays the compiled action's invocation directly via tectonic_compile.py on each content edit instead of shelling out to `bazel build`, skipping Bazel analysis + sandbox setup (~50% of warm-rebuild latency). The first build, and any fast build that hits a missing cached resource, still go through `bazel build`, so the canonical build path is never bypassed for anything but content recompiles. Requires the watched target to be a real latex_document. The compile runs un-sandboxed but stages only the document's declared inputs, so it stays consistent with `bazel build` / CI. See DESIGN.md Â§4.7.4.2False�	latex_pkgFA bundle of resource files (images, bib, fonts) consumed by documents."�
�
	latex_pkgFA bundle of resource files (images, bib, fonts) consumed by documents.*
nameA unique name for this target. 3
srcs'Resource files exposed by this package. "*
	latex_pkg@@rules_latex//latex:defs.bzl
,
*
nameA unique name for this target. 5
3
srcs'Resource files exposed by this package. �	LatexInfo:Information about a LaTeX source set or compiled document.2�
�
	LatexInfo:Information about a LaTeX source set or compiled document.�
srcs�depset[File]: transitive set of LaTeX source files (.tex, .sty, .cls, .bib, images, etc.) that documents depending on this target need to see.�
search_paths�depset[string]: retained for provider compatibility. Document compilation does not read this field or set TEXINPUTS/BIBINPUTS/BSTINPUTS; it stages source files by path instead. Use pkg_files to override a staged path.�
offline_strategy�string: which offline-mode strategy the target resolved to. One of "user_cache" (explicit `cache = "..."` attr), "bundle" (toolchain-level tectonic.bundle()), or "implicit" (implicit populate-cache pipeline). Set only by `latex_document`; other rules that provide `LatexInfo` (`latex_library`, `latex_pkg`) leave it as the empty string. Consumed by `latex_live` to decide whether to interpose a persistent serve-time cache snapshot via the `//latex:_serve_cache_override` build setting."*
	LatexInfo@@rules_latex//latex:defs.bzl
�
�
srcs�depset[File]: transitive set of LaTeX source files (.tex, .sty, .cls, .bib, images, etc.) that documents depending on this target need to see.�
�
search_paths�depset[string]: retained for provider compatibility. Document compilation does not read this field or set TEXINPUTS/BIBINPUTS/BSTINPUTS; it stages source files by path instead. Use pkg_files to override a staged path.�
�
offline_strategy�string: which offline-mode strategy the target resolved to. One of "user_cache" (explicit `cache = "..."` attr), "bundle" (toolchain-level tectonic.bundle()), or "implicit" (implicit populate-cache pipeline). Set only by `latex_document`; other rules that provide `LatexInfo` (`latex_library`, `latex_pkg`) leave it as the empty string. Consumed by `latex_live` to decide whether to interpose a persistent serve-time cache snapshot via the `//latex:_serve_cache_override` build setting.u
//latex:providers.bzlrZ
#
rules_latexlatexproviders.bzl%
	LatexInfo
_LatexInfo

�
(//latex/private:latex_cache_snapshot.bzlr�
6
rules_latexlatex/privatelatex_cache_snapshot.bzl;
latex_cache_snapshot_latex_cache_snapshot

�
"//latex/private:latex_document.bzlrq
0
rules_latexlatex/privatelatex_document.bzl/
latex_document_latex_document

�
!//latex/private:latex_library.bzlrn
/
rules_latexlatex/privatelatex_library.bzl-
latex_library_latex_library

�
//latex/private:latex_live.bzlre
,
rules_latexlatex/privatelatex_live.bzl'

latex_live_latex_live

�
//latex/private:latex_pkg.bzlrb
+
rules_latexlatex/privatelatex_pkg.bzl%
	latex_pkg
_latex_pkg
!!
"�
//latex/private:latex_test.bzlre
,
rules_latexlatex/privatelatex_test.bzl'

latex_test_latex_test
%%
#&�Public API for rules_latex.

Load symbols from here:

    load("@rules_latex//latex:defs.bzl",
         "latex_document", "latex_library", "latex_pkg",
         "latex_test", "latex_cache_snapshot",
         "latex_live")
�&
#
rules_latexlatexproviders.bzl�LatexDocumentInfo�Compile-time inputs of a `latex_document` target. Exposed so live-preview rules can drive their own parallel tectonic invocations (in particular, a serve-startup cache prime) without re-introspecting the document's attributes.2�
�	
LatexDocumentInfo�Compile-time inputs of a `latex_document` target. Exposed so live-preview rules can drive their own parallel tectonic invocations (in particular, a serve-startup cache prime) without re-introspecting the document's attributes.4
main,File: the main .tex file passed to tectonic.B
tectonic6File: the tectonic binary resolved from the toolchain.H
tectonic_runfiles3Runfiles: runtime files of the tectonic executable.A
biber8File or None: the biber binary, if biber = True was set.G
biber_runfiles5Runfiles or None: runtime files of biber, if enabled.>
use_system_biber*bool: True when biber_strategy = "system".>
	pkg_files1list[(File, string)]: explicit staging overrides.C
populate_tool2File: the tools/tectonic_populate_cache.py script.L
staging_lib=File: the tools/staging.py library imported by populate_tool.H

bundle_url:string: pinned bundle identity used by the implicit prime.G
ctan_packages6list[string]: CTAN packages requested by the document.H
	ctan_lock;File or None: exact URL and SHA-256 lock for CTAN packages.P
bundle_manifest=File: the pinned bundle package manifest for CTAN resolution."7
LatexDocumentInfo"@@rules_latex//latex:providers.bzl
&&6
4
main,File: the main .tex file passed to tectonic.D
B
tectonic6File: the tectonic binary resolved from the toolchain.J
H
tectonic_runfiles3Runfiles: runtime files of the tectonic executable.C
A
biber8File or None: the biber binary, if biber = True was set.I
G
biber_runfiles5Runfiles or None: runtime files of biber, if enabled.@
>
use_system_biber*bool: True when biber_strategy = "system".@
>
	pkg_files1list[(File, string)]: explicit staging overrides.E
C
populate_tool2File: the tools/tectonic_populate_cache.py script.N
L
staging_lib=File: the tools/staging.py library imported by populate_tool.J
H

bundle_url:string: pinned bundle identity used by the implicit prime.I
G
ctan_packages6list[string]: CTAN packages requested by the document.J
H
	ctan_lock;File or None: exact URL and SHA-256 lock for CTAN packages.R
P
bundle_manifest=File: the pinned bundle package manifest for CTAN resolution.�	LatexInfo:Information about a LaTeX source set or compiled document.2�
�
	LatexInfo:Information about a LaTeX source set or compiled document.�
srcs�depset[File]: transitive set of LaTeX source files (.tex, .sty, .cls, .bib, images, etc.) that documents depending on this target need to see.�
search_paths�depset[string]: retained for provider compatibility. Document compilation does not read this field or set TEXINPUTS/BIBINPUTS/BSTINPUTS; it stages source files by path instead. Use pkg_files to override a staged path.�
offline_strategy�string: which offline-mode strategy the target resolved to. One of "user_cache" (explicit `cache = "..."` attr), "bundle" (toolchain-level tectonic.bundle()), or "implicit" (implicit populate-cache pipeline). Set only by `latex_document`; other rules that provide `LatexInfo` (`latex_library`, `latex_pkg`) leave it as the empty string. Consumed by `latex_live` to decide whether to interpose a persistent serve-time cache snapshot via the `//latex:_serve_cache_override` build setting."/
	LatexInfo"@@rules_latex//latex:providers.bzl
�
�
srcs�depset[File]: transitive set of LaTeX source files (.tex, .sty, .cls, .bib, images, etc.) that documents depending on this target need to see.�
�
search_paths�depset[string]: retained for provider compatibility. Document compilation does not read this field or set TEXINPUTS/BIBINPUTS/BSTINPUTS; it stages source files by path instead. Use pkg_files to override a staged path.�
�
offline_strategy�string: which offline-mode strategy the target resolved to. One of "user_cache" (explicit `cache = "..."` attr), "bundle" (toolchain-level tectonic.bundle()), or "implicit" (implicit populate-cache pipeline). Set only by `latex_document`; other rules that provide `LatexInfo` (`latex_library`, `latex_pkg`) leave it as the empty string. Consumed by `latex_live` to decide whether to interpose a persistent serve-time cache snapshot via the `//latex:_serve_cache_override` build setting.�Providers exposed by rules_latex.

`LatexInfo` propagates the transitive set of LaTeX source files that a target
contributes. Document actions stage those files into the work directory.

`LatexDocumentInfo` carries the compile-time inputs (main file, biber binary,
pkg_files overrides) of a `latex_document` target, so consumers like
`latex_live` can drive a parallel cache-priming invocation without
re-introspecting attributes.
 