�

misecwd.bzl�cwd�An executable that runs its `tool` with the working directory set
to `$PWD` (Bazel's client working directory). Exposed publicly by
`//mise:cwd.bzl`; see there for details."�
�
cwd�An executable that runs its `tool` with the working directory set
to `$PWD` (Bazel's client working directory). Exposed publicly by
`//mise:cwd.bzl`; see there for details.*
nameA unique name for this target. H
tool<The wrapped tool executable (typically a hub `tool` target). "
cwd//mise/private:cwd.bzl8,
*
nameA unique name for this target. J
H
tool<The wrapped tool executable (typically a hub `tool` target). �Mise execution rule that runs a tool from Bazel's client working directory.

`cwd` wraps an executable tool target (typically a hub `tool` such as
`@mise//tools/ruff:tool`) into an executable wrapper that `exec`s the tool with
its working directory set to `$PWD` — the directory from which Bazel was
invoked — so the tool processes the user's files instead of Bazel's execroot or
runfiles directory. The wrapper locates the tool next to itself first, then
through `$RUNFILES_DIR` / `$RUNFILES_MANIFEST_FILE`, and finally through the
workspace-relative short path; it fails with a clear message if none of these
resolves. See `//mise/private:run_in` for the shared implementation.�%
miseextensions.bzl�$mise�Exposes tools from a `mise.lock` as Bazel targets.

Declare at least one `hub` tag reading a `mise.lock`, `use_repo` the resulting
hub, and register `@<hub_name>//toolchains:all`. Optionally declare
`conda_env` tags to install several conda tools into one shared prefix.
Tools (and environments) resolve through toolchain selection, so the same
label picks the right binary for the execution platform.J� 
�
mise�Exposes tools from a `mise.lock` as Bazel targets.

Declare at least one `hub` tag reading a `mise.lock`, `use_repo` the resulting
hub, and register `@<hub_name>//toolchains:all`. Optionally declare
`conda_env` tags to install several conda tools into one shared prefix.
Tools (and environments) resolve through toolchain selection, so the same
label picks the right binary for the execution platform.�
	conda_env�Declares a merged conda environment exposed as a tool of its own.

Several conda tools (e.g. `conda:postgresql` plus `conda:pgvector`) are
installed into one shared conda prefix instead of one prefix per tool, which is
required when a package can only use files of the same prefix (PostgreSQL
extensions). The resulting tool is keyed `conda_env_<name>` with the same
targets as any other tool. Environments are attached to the `hub` tags in this
extension whose `lockfile` labels match, and every member tool must resolve in
that lockfile.O
nameCName of the environment; the tool is exposed as `conda_env_<name>`. G
lockfile7The `mise.lock` file used to resolve the `tools` specs. �
tools�Mise tool names with an optional `@version` suffix (e.g.
`conda:postgresql@18.4`), matching the tool names used in `mise.toml`.
Omitting `@version` requires the lockfile to pin exactly one version of that
tool. All members must use the `conda:` backend; other backends cannot share a
prefix. �
hub�Reads a `mise.lock` and exposes its tools through a hub repository.

Several `hub` tags (from this or other modules) declaring the same `hub_name`
feed a single hub: every lockfile is parsed and its tools are merged there.
Tools become `@<hub_name>//tools/<sanitized name>:tool` targets plus `:cwd` and
`:workspace_root` wrappers, and `@<hub_name>//toolchains:all` must be
registered for toolchain resolution.L
hub_name6Name of the hub repository to create (default `mise`).2"mise"<
lockfile,The `mise.lock` file to parse (single file). "//mise:extensions.bzl�
�
	conda_env�Declares a merged conda environment exposed as a tool of its own.

Several conda tools (e.g. `conda:postgresql` plus `conda:pgvector`) are
installed into one shared conda prefix instead of one prefix per tool, which is
required when a package can only use files of the same prefix (PostgreSQL
extensions). The resulting tool is keyed `conda_env_<name>` with the same
targets as any other tool. Environments are attached to the `hub` tags in this
extension whose `lockfile` labels match, and every member tool must resolve in
that lockfile.O
nameCName of the environment; the tool is exposed as `conda_env_<name>`. G
lockfile7The `mise.lock` file used to resolve the `tools` specs. �
tools�Mise tool names with an optional `@version` suffix (e.g.
`conda:postgresql@18.4`), matching the tool names used in `mise.toml`.
Omitting `@version` requires the lockfile to pin exactly one version of that
tool. All members must use the `conda:` backend; other backends cannot share a
prefix. Q
O
nameCName of the environment; the tool is exposed as `conda_env_<name>`. I
G
lockfile7The `mise.lock` file used to resolve the `tools` specs. �
�
tools�Mise tool names with an optional `@version` suffix (e.g.
`conda:postgresql@18.4`), matching the tool names used in `mise.toml`.
Omitting `@version` requires the lockfile to pin exactly one version of that
tool. All members must use the `conda:` backend; other backends cannot share a
prefix. �
�
hub�Reads a `mise.lock` and exposes its tools through a hub repository.

Several `hub` tags (from this or other modules) declaring the same `hub_name`
feed a single hub: every lockfile is parsed and its tools are merged there.
Tools become `@<hub_name>//tools/<sanitized name>:tool` targets plus `:cwd` and
`:workspace_root` wrappers, and `@<hub_name>//toolchains:all` must be
registered for toolchain resolution.L
hub_name6Name of the hub repository to create (default `mise`).2"mise"<
lockfile,The `mise.lock` file to parse (single file). N
L
hub_name6Name of the hub repository to create (default `mise`).2"mise">
<
lockfile,The `mise.lock` file to parse (single file). �Extensions for bzlmod.

Provides the `mise` module extension for parsing `mise.lock` and exposing the
locked tools as Bazel repositories, toolchains, and executable targets.�
misehub.bzl�
bzlmod_hub�Creates per-platform tool repos and the toolchain hub for bzlmod.

Also creates one `tool_repo` per (tool, os, cpu) binary, named
`{name}.{tool}.{os}_{cpu}`. Call this from a module extension; use
`workspace_hub()` for WORKSPACE mode.
*�
�

bzlmod_hub5
name)The name of the hub repository to create. (8
	lockfiles'Labels of the mise.lock files to parse. (/

module_ctxThe module extension context. (�
envsyConda environments to build from the parsed tools, as dicts with
`name` and `tools` keys. Each becomes a tool of its own.None(�Creates per-platform tool repos and the toolchain hub for bzlmod.

Also creates one `tool_repo` per (tool, os, cpu) binary, named
`{name}.{tool}.{os}_{cpu}`. Call this from a module extension; use
`workspace_hub()` for WORKSPACE mode.
2

bzlmod_hub//mise:hub.bzl7
5
name)The name of the hub repository to create. (:
8
	lockfiles'Labels of the mise.lock files to parse. (1
/

module_ctxThe module extension context. (�
�
envsyConda environments to build from the parsed tools, as dicts with
`name` and `tools` keys. Each becomes a tool of its own.None(�workspace_hub�Creates the toolchain hub for WORKSPACE mode.

Per-platform tool repos are created by calling `register_tools()`
from `@<hub>//:tools.bzl` after this (the hub repo itself contains no
binaries). For bzlmod mode use `bzlmod_hub()` instead.
*�
�
workspace_hub5
name)The name of the hub repository to create. (8
	lockfiles'Labels of the mise.lock files to parse. (�
envsyConda environments to build from the parsed tools, as dicts with
`name` and `tools` keys. Each becomes a tool of its own.None(�Creates the toolchain hub for WORKSPACE mode.

Per-platform tool repos are created by calling `register_tools()`
from `@<hub>//:tools.bzl` after this (the hub repo itself contains no
binaries). For bzlmod mode use `bzlmod_hub()` instead.
2
workspace_hub//mise:hub.bzl7
5
name)The name of the hub repository to create. (:
8
	lockfiles'Labels of the mise.lock files to parse. (�
�
envsyConda environments to build from the parsed tools, as dicts with
`name` and `tools` keys. Each becomes a tool of its own.None(�	tool_repoR�
w
	tool_repo.
name"A unique name for this repository. 
	tool_name 
binary *
	tool_repo//mise:hub.bzl0
.
name"A unique name for this repository. 

	tool_name 

binary �Mise hub and per-platform tool repositories.

`bzlmod_hub()` (bzlmod mode) and `workspace_hub()` (WORKSPACE mode) create the
toolchain hub: public entry points that parse the lockfiles, fetch every binary
with `tool_repo`, and generate the hub's `toolchain_info`/`tool`/`cwd`/... code.
Users should not call `tool_repo` or `_mise_hub` directly; they are driven by
the extension and by `register_tools()`.�
miseworkspace_root.bzl�workspace_root�An executable that runs its `tool` with the working directory set
to `$BUILD_WORKSPACE_DIRECTORY` (the workspace root). Exposed publicly by
`//mise:workspace_root.bzl`; see there for details."�
�
workspace_root�An executable that runs its `tool` with the working directory set
to `$BUILD_WORKSPACE_DIRECTORY` (the workspace root). Exposed publicly by
`//mise:workspace_root.bzl`; see there for details.*
nameA unique name for this target. H
tool<The wrapped tool executable (typically a hub `tool` target). "3
workspace_root!//mise/private:workspace_root.bzl8,
*
nameA unique name for this target. J
H
tool<The wrapped tool executable (typically a hub `tool` target). �Mise execution rule that runs a tool from the workspace root.

`workspace_root` wraps an executable tool target (typically a hub `tool` such
as `@mise//tools/ruff:tool`) into an executable wrapper that `exec`s the tool
with its working directory set to `$BUILD_WORKSPACE_DIRECTORY` — the workspace
root — so the tool sees the whole workspace regardless of where Bazel was
invoked from. The wrapper locates the tool next to itself first, then through
`$RUNFILES_DIR` / `$RUNFILES_MANIFEST_FILE`, and finally through the
workspace-relative short path; it fails with a clear message if none of these
resolves. See `//mise/private:run_in` for the shared implementation. 