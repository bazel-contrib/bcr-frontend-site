�
)
rules_multiruninternalconstants.bzl�update_attrs Conditionally update attributes.*�
�
update_attrs#
attrsAttributes dictionary. (%
cfgThe command configuration. (`
	allowlistOOptional allow list label that will be applied to the configuration transition. ( Conditionally update attributes." 
Updated attributes dictionary.28
update_attrs(@@rules_multirun//internal:constants.bzl
�CommandInfo2Information about commands used by their multirun.2�
�
CommandInfo2Information about commands used by their multirun.
description(Undocumented)"7
CommandInfo(@@rules_multirun//internal:constants.bzl


description(Undocumented)�	RUNFILES_PREFIX�#!/bin/bash

# --- begin runfiles.bash initialization v2 ---
# Copy-pasted from the Bazel Bash runfiles library v2.
set -uo pipefail; f=bazel_tools/tools/bash/runfiles/runfiles.bash
source "${RUNFILES_DIR:-/dev/null}/$f" 2>/dev/null || \
 source "$(grep -sm1 "^$f " "${RUNFILES_MANIFEST_FILE:-/dev/null}" | cut -f2- -d' ')" 2>/dev/null || \
 source "$0.runfiles/$f" 2>/dev/null || \
 source "$(grep -sm1 "^$f " "$0.runfiles_manifest" | cut -f2- -d' ')" 2>/dev/null || \
 source "$(grep -sm1 "^$f " "$0.exe.runfiles_manifest" | cut -f2- -d' ')" 2>/dev/null || \
 { echo>&2 "ERROR: cannot find $f"; exit 1; }; f=; set -e
# --- end runfiles.bash initialization v2 ---

# Export RUNFILES_* envvars (and a couple more) for subprocesses.
runfiles_export_envvars

j��#!/bin/bash

# --- begin runfiles.bash initialization v2 ---
# Copy-pasted from the Bazel Bash runfiles library v2.
set -uo pipefail; f=bazel_tools/tools/bash/runfiles/runfiles.bash
source "${RUNFILES_DIR:-/dev/null}/$f" 2>/dev/null || \
 source "$(grep -sm1 "^$f " "${RUNFILES_MANIFEST_FILE:-/dev/null}" | cut -f2- -d' ')" 2>/dev/null || \
 source "$0.runfiles/$f" 2>/dev/null || \
 source "$(grep -sm1 "^$f " "$0.runfiles_manifest" | cut -f2- -d' ')" 2>/dev/null || \
 source "$(grep -sm1 "^$f " "$0.exe.runfiles_manifest" | cut -f2- -d' ')" 2>/dev/null || \
 { echo>&2 "ERROR: cannot find $f"; exit 1; }; f=; set -e
# --- end runfiles.bash initialization v2 ---

# Export RUNFILES_* envvars (and a couple more) for subprocesses.
runfiles_export_envvars

4Internal constants shared between multiple bzl files�6

rules_multiruncommand.bzl�command�A command is a wrapper rule for some other target that can be run like a
command line tool. You can customize the command to run with specific arguments
or environment variables you would like to be passed. Then you can compose
multiple commands into a multirun rule to run them in a single bazel
invocation, and in parallel if desired.

```bzl
load("@rules_multirun//:defs.bzl", "multirun", "command")

sh_binary(
    name = "some_linter",
    ...
)

py_binary(
    name = "some_other_linter",
    ...
)

command(
    name = "lint-something",
    command = ":some_linter",
    arguments = ["check"], # Optional arguments passed directly to the tool
)

command(
    name = "lint-something-else",
    command = ":some_other_linter",
    environment = {"CHECK": "true"}, # Optional environment variables set when invoking the command
    data = ["..."] # Optional runtime data dependencies
)
```
"�
�
command�A command is a wrapper rule for some other target that can be run like a
command line tool. You can customize the command to run with specific arguments
or environment variables you would like to be passed. Then you can compose
multiple commands into a multirun rule to run them in a single bazel
invocation, and in parallel if desired.

```bzl
load("@rules_multirun//:defs.bzl", "multirun", "command")

sh_binary(
    name = "some_linter",
    ...
)

py_binary(
    name = "some_other_linter",
    ...
)

command(
    name = "lint-something",
    command = ":some_linter",
    arguments = ["check"], # Optional arguments passed directly to the tool
)

command(
    name = "lint-something-else",
    command = ":some_other_linter",
    environment = {"CHECK": "true"}, # Optional environment variables set when invoking the command
    data = ["..."] # Optional runtime data dependencies
)
```
*
nameA unique name for this target. �
	arguments�List of command line arguments. Subject to $(location) expansion. See https://docs.bazel.build/versions/master/skylark/lib/ctx.html#expand_location2[]
commandTarget to run �
data�The list of files needed by this command at runtime. See general comments about `data` at https://docs.bazel.build/versions/master/be/common-definitions.html#common-attributes2[]M
description8A string describing the command printed during multiruns2""�
environment�Dictionary of environment variables. Subject to $(location) expansion. See https://docs.bazel.build/versions/master/skylark/lib/ctx.html#expand_location
2{}")
command@@rules_multirun//:command.bzl
{{,
*
nameA unique name for this target. �
�
	arguments�List of command line arguments. Subject to $(location) expansion. See https://docs.bazel.build/versions/master/skylark/lib/ctx.html#expand_location2[]

commandTarget to run �
�
data�The list of files needed by this command at runtime. See general comments about `data` at https://docs.bazel.build/versions/master/be/common-definitions.html#common-attributes2[]O
M
description8A string describing the command printed during multiruns2""�
�
environment�Dictionary of environment variables. Subject to $(location) expansion. See https://docs.bazel.build/versions/master/skylark/lib/ctx.html#expand_location
2{}�command_force_opt�A command that forces the compilation mode of the dependent targets to opt. This can be useful if your tools have improved performance if built with optimizations. See the documentation for command for more examples. If you'd like to always use this variation you can import this directly and rename it for convenience like:

```bzl
load("@rules_multirun//:defs.bzl", "multirun", command = "command_force_opt")
```
"�
�	
command_force_opt�A command that forces the compilation mode of the dependent targets to opt. This can be useful if your tools have improved performance if built with optimizations. See the documentation for command for more examples. If you'd like to always use this variation you can import this directly and rename it for convenience like:

```bzl
load("@rules_multirun//:defs.bzl", "multirun", command = "command_force_opt")
```
*
nameA unique name for this target. �
	arguments�List of command line arguments. Subject to $(location) expansion. See https://docs.bazel.build/versions/master/skylark/lib/ctx.html#expand_location2[]
commandTarget to run �
data�The list of files needed by this command at runtime. See general comments about `data` at https://docs.bazel.build/versions/master/be/common-definitions.html#common-attributes2[]M
description8A string describing the command printed during multiruns2""�
environment�Dictionary of environment variables. Subject to $(location) expansion. See https://docs.bazel.build/versions/master/skylark/lib/ctx.html#expand_location
2{}"3
command_force_opt@@rules_multirun//:command.bzl
{{,
*
nameA unique name for this target. �
�
	arguments�List of command line arguments. Subject to $(location) expansion. See https://docs.bazel.build/versions/master/skylark/lib/ctx.html#expand_location2[]

commandTarget to run �
�
data�The list of files needed by this command at runtime. See general comments about `data` at https://docs.bazel.build/versions/master/be/common-definitions.html#common-attributes2[]O
M
description8A string describing the command printed during multiruns2""�
�
environment�Dictionary of environment variables. Subject to $(location) expansion. See https://docs.bazel.build/versions/master/skylark/lib/ctx.html#expand_location
2{}�command_with_transition�Create a command rule with a transition to the given configuration.

This is useful if you have a project-specific configuration that you want
to apply to all of your commands. See also multirun_with_transition.
*�
�
command_with_transition<
cfg1The transition to force on the dependent targets. (n
	allowlistYThe transition allowlist to use for the given cfg. Not necessary in newer bazel versions.None(�
doc|The documentation to use for the rule. Only necessary if you're generating documentation with stardoc for your custom rules.None(�Create a command rule with a transition to the given configuration.

This is useful if you have a project-specific configuration that you want
to apply to all of your commands. See also multirun_with_transition.
29
command_with_transition@@rules_multirun//:command.bzl
UUa
//lib:shell.bzlrL

bazel_skyliblib	shell.bzl
shellshell
',
.�
//internal:constants.bzlr�
)
rules_multiruninternalconstants.bzl(
CommandInfoCommandInfo
		0
RUNFILES_PREFIXRUNFILES_PREFIX


*
update_attrsupdate_attrs

a
This is a simple rule for defining a runnable command that can be used in a
multirun definition
�_

rules_multirundefs.bzl�command�A command is a wrapper rule for some other target that can be run like a
command line tool. You can customize the command to run with specific arguments
or environment variables you would like to be passed. Then you can compose
multiple commands into a multirun rule to run them in a single bazel
invocation, and in parallel if desired.

```bzl
load("@rules_multirun//:defs.bzl", "multirun", "command")

sh_binary(
    name = "some_linter",
    ...
)

py_binary(
    name = "some_other_linter",
    ...
)

command(
    name = "lint-something",
    command = ":some_linter",
    arguments = ["check"], # Optional arguments passed directly to the tool
)

command(
    name = "lint-something-else",
    command = ":some_other_linter",
    environment = {"CHECK": "true"}, # Optional environment variables set when invoking the command
    data = ["..."] # Optional runtime data dependencies
)
```
"�
�
command�A command is a wrapper rule for some other target that can be run like a
command line tool. You can customize the command to run with specific arguments
or environment variables you would like to be passed. Then you can compose
multiple commands into a multirun rule to run them in a single bazel
invocation, and in parallel if desired.

```bzl
load("@rules_multirun//:defs.bzl", "multirun", "command")

sh_binary(
    name = "some_linter",
    ...
)

py_binary(
    name = "some_other_linter",
    ...
)

command(
    name = "lint-something",
    command = ":some_linter",
    arguments = ["check"], # Optional arguments passed directly to the tool
)

command(
    name = "lint-something-else",
    command = ":some_other_linter",
    environment = {"CHECK": "true"}, # Optional environment variables set when invoking the command
    data = ["..."] # Optional runtime data dependencies
)
```
*
nameA unique name for this target. �
	arguments�List of command line arguments. Subject to $(location) expansion. See https://docs.bazel.build/versions/master/skylark/lib/ctx.html#expand_location2[]
commandTarget to run �
data�The list of files needed by this command at runtime. See general comments about `data` at https://docs.bazel.build/versions/master/be/common-definitions.html#common-attributes2[]M
description8A string describing the command printed during multiruns2""�
environment�Dictionary of environment variables. Subject to $(location) expansion. See https://docs.bazel.build/versions/master/skylark/lib/ctx.html#expand_location
2{}"&
command@@rules_multirun//:defs.bzl
{{,
*
nameA unique name for this target. �
�
	arguments�List of command line arguments. Subject to $(location) expansion. See https://docs.bazel.build/versions/master/skylark/lib/ctx.html#expand_location2[]

commandTarget to run �
�
data�The list of files needed by this command at runtime. See general comments about `data` at https://docs.bazel.build/versions/master/be/common-definitions.html#common-attributes2[]O
M
description8A string describing the command printed during multiruns2""�
�
environment�Dictionary of environment variables. Subject to $(location) expansion. See https://docs.bazel.build/versions/master/skylark/lib/ctx.html#expand_location
2{}�command_force_opt�A command that forces the compilation mode of the dependent targets to opt. This can be useful if your tools have improved performance if built with optimizations. See the documentation for command for more examples. If you'd like to always use this variation you can import this directly and rename it for convenience like:

```bzl
load("@rules_multirun//:defs.bzl", "multirun", command = "command_force_opt")
```
"�
�	
command_force_opt�A command that forces the compilation mode of the dependent targets to opt. This can be useful if your tools have improved performance if built with optimizations. See the documentation for command for more examples. If you'd like to always use this variation you can import this directly and rename it for convenience like:

```bzl
load("@rules_multirun//:defs.bzl", "multirun", command = "command_force_opt")
```
*
nameA unique name for this target. �
	arguments�List of command line arguments. Subject to $(location) expansion. See https://docs.bazel.build/versions/master/skylark/lib/ctx.html#expand_location2[]
commandTarget to run �
data�The list of files needed by this command at runtime. See general comments about `data` at https://docs.bazel.build/versions/master/be/common-definitions.html#common-attributes2[]M
description8A string describing the command printed during multiruns2""�
environment�Dictionary of environment variables. Subject to $(location) expansion. See https://docs.bazel.build/versions/master/skylark/lib/ctx.html#expand_location
2{}"0
command_force_opt@@rules_multirun//:defs.bzl
{{,
*
nameA unique name for this target. �
�
	arguments�List of command line arguments. Subject to $(location) expansion. See https://docs.bazel.build/versions/master/skylark/lib/ctx.html#expand_location2[]

commandTarget to run �
�
data�The list of files needed by this command at runtime. See general comments about `data` at https://docs.bazel.build/versions/master/be/common-definitions.html#common-attributes2[]O
M
description8A string describing the command printed during multiruns2""�
�
environment�Dictionary of environment variables. Subject to $(location) expansion. See https://docs.bazel.build/versions/master/skylark/lib/ctx.html#expand_location
2{}�!multirun�
A multirun composes multiple command rules in order to run them in a single
bazel invocation, optionally in parallel. This can have a major performance
improvement both in build time and run time depending on your tools.

```bzl
load("@rules_multirun//:defs.bzl", "command", "multirun")
load("@rules_python//python:defs.bzl", "py_binary")

sh_binary(
    name = "some_linter",
    ...
)

py_binary(
    name = "some_other_linter",
    ...
)

command(
    name = "lint-something",
    command = ":some_linter",
    arguments = ["check"], # Optional arguments passed directly to the tool
)

command(
    name = "lint-something-else",
    command = ":some_other_linter",
    environment = {"CHECK": "true"}, # Optional environment variables set when invoking the command
    data = ["..."] # Optional runtime data dependencies
)

multirun(
    name = "lint",
    commands = [
        "lint-something",
        "lint-something-else",
    ],
    jobs = 0, # Set to 0 to run in parallel, defaults to sequential
)
```

With this configuration you can `bazel run :lint` and it will run both both
linters in parallel. If you would like to run them serially you can omit the `jobs` attribute.

NOTE: If your commands change files in the workspace you might want to prefer
sequential execution to avoid race conditions when changing the same file from
multiple tools.
"�
�
multirun�
A multirun composes multiple command rules in order to run them in a single
bazel invocation, optionally in parallel. This can have a major performance
improvement both in build time and run time depending on your tools.

```bzl
load("@rules_multirun//:defs.bzl", "command", "multirun")
load("@rules_python//python:defs.bzl", "py_binary")

sh_binary(
    name = "some_linter",
    ...
)

py_binary(
    name = "some_other_linter",
    ...
)

command(
    name = "lint-something",
    command = ":some_linter",
    arguments = ["check"], # Optional arguments passed directly to the tool
)

command(
    name = "lint-something-else",
    command = ":some_other_linter",
    environment = {"CHECK": "true"}, # Optional environment variables set when invoking the command
    data = ["..."] # Optional runtime data dependencies
)

multirun(
    name = "lint",
    commands = [
        "lint-something",
        "lint-something-else",
    ],
    jobs = 0, # Set to 0 to run in parallel, defaults to sequential
)
```

With this configuration you can `bazel run :lint` and it will run both both
linters in parallel. If you would like to run them serially you can omit the `jobs` attribute.

NOTE: If your commands change files in the workspace you might want to prefer
sequential execution to avoid race conditions when changing the same file from
multiple tools.
*
nameA unique name for this target. �
buffer_outputlBuffer the output of the commands and print it after each command has finished. Only for parallel execution.2False 
commandsTargets to run2[]�
data�The list of files needed by the commands at runtime. See general comments about `data` at https://docs.bazel.build/versions/master/be/common-definitions.html#common-attributes2[]�
jobs�The expected concurrency of targets to be executed. Default is set to 1 which means sequential execution. Setting to 0 means that there is no limit concurrency.21W

keep_going@Keep going after a command fails. Only for sequential execution.2FalseK
print_command2Print what command is being run before running it.2True"'
multirun@@rules_multirun//:defs.bzl
��,
*
nameA unique name for this target. �
�
buffer_outputlBuffer the output of the commands and print it after each command has finished. Only for parallel execution.2False"
 
commandsTargets to run2[]�
�
data�The list of files needed by the commands at runtime. See general comments about `data` at https://docs.bazel.build/versions/master/be/common-definitions.html#common-attributes2[]�
�
jobs�The expected concurrency of targets to be executed. Default is set to 1 which means sequential execution. Setting to 0 means that there is no limit concurrency.21Y
W

keep_going@Keep going after a command fails. Only for sequential execution.2FalseM
K
print_command2Print what command is being run before running it.2True�command_with_transition�Create a command rule with a transition to the given configuration.

This is useful if you have a project-specific configuration that you want
to apply to all of your commands. See also multirun_with_transition.
*�
�
command_with_transition<
cfg1The transition to force on the dependent targets. (n
	allowlistYThe transition allowlist to use for the given cfg. Not necessary in newer bazel versions.None(�
doc|The documentation to use for the rule. Only necessary if you're generating documentation with stardoc for your custom rules.None(�Create a command rule with a transition to the given configuration.

This is useful if you have a project-specific configuration that you want
to apply to all of your commands. See also multirun_with_transition.
29
command_with_transition@@rules_multirun//:command.bzl
UU�multirun_with_transition�Creates a multirun rule which transitions all commands to the given configuration.

This is useful if you have a project-specific configuration that you want
to apply to all of your commands. See also command_with_transition.
*�
�
multirun_with_transition=
cfg2The transition to force on the dependent commands. (n
	allowlistYThe transition allowlist to use for the given cfg. Not necessary in newer bazel versions.None(�Creates a multirun rule which transitions all commands to the given configuration.

This is useful if you have a project-specific configuration that you want
to apply to all of your commands. See also command_with_transition.
2;
multirun_with_transition@@rules_multirun//:multirun.bzl
���
:command.bzlr�

rules_multiruncommand.bzl!
command_command
'/5
command_force_opt_command_force_opt
=OA
command_with_transition_command_with_transition
g
��
:multirun.bzlr�

rules_multirunmultirun.bzl#
multirun	_multirun
(1C
multirun_with_transition_multirun_with_transition
@Y
w�
These rules provide a simple interface for running multiple commands,
optionally in parallel, with a single bazel run invocation. This is especially
useful for running multiple linters or formatters with a single command.
�,

rules_multirunmultirun.bzl�!multirun�
A multirun composes multiple command rules in order to run them in a single
bazel invocation, optionally in parallel. This can have a major performance
improvement both in build time and run time depending on your tools.

```bzl
load("@rules_multirun//:defs.bzl", "command", "multirun")
load("@rules_python//python:defs.bzl", "py_binary")

sh_binary(
    name = "some_linter",
    ...
)

py_binary(
    name = "some_other_linter",
    ...
)

command(
    name = "lint-something",
    command = ":some_linter",
    arguments = ["check"], # Optional arguments passed directly to the tool
)

command(
    name = "lint-something-else",
    command = ":some_other_linter",
    environment = {"CHECK": "true"}, # Optional environment variables set when invoking the command
    data = ["..."] # Optional runtime data dependencies
)

multirun(
    name = "lint",
    commands = [
        "lint-something",
        "lint-something-else",
    ],
    jobs = 0, # Set to 0 to run in parallel, defaults to sequential
)
```

With this configuration you can `bazel run :lint` and it will run both both
linters in parallel. If you would like to run them serially you can omit the `jobs` attribute.

NOTE: If your commands change files in the workspace you might want to prefer
sequential execution to avoid race conditions when changing the same file from
multiple tools.
"�
�
multirun�
A multirun composes multiple command rules in order to run them in a single
bazel invocation, optionally in parallel. This can have a major performance
improvement both in build time and run time depending on your tools.

```bzl
load("@rules_multirun//:defs.bzl", "command", "multirun")
load("@rules_python//python:defs.bzl", "py_binary")

sh_binary(
    name = "some_linter",
    ...
)

py_binary(
    name = "some_other_linter",
    ...
)

command(
    name = "lint-something",
    command = ":some_linter",
    arguments = ["check"], # Optional arguments passed directly to the tool
)

command(
    name = "lint-something-else",
    command = ":some_other_linter",
    environment = {"CHECK": "true"}, # Optional environment variables set when invoking the command
    data = ["..."] # Optional runtime data dependencies
)

multirun(
    name = "lint",
    commands = [
        "lint-something",
        "lint-something-else",
    ],
    jobs = 0, # Set to 0 to run in parallel, defaults to sequential
)
```

With this configuration you can `bazel run :lint` and it will run both both
linters in parallel. If you would like to run them serially you can omit the `jobs` attribute.

NOTE: If your commands change files in the workspace you might want to prefer
sequential execution to avoid race conditions when changing the same file from
multiple tools.
*
nameA unique name for this target. �
buffer_outputlBuffer the output of the commands and print it after each command has finished. Only for parallel execution.2False 
commandsTargets to run2[]�
data�The list of files needed by the commands at runtime. See general comments about `data` at https://docs.bazel.build/versions/master/be/common-definitions.html#common-attributes2[]�
jobs�The expected concurrency of targets to be executed. Default is set to 1 which means sequential execution. Setting to 0 means that there is no limit concurrency.21W

keep_going@Keep going after a command fails. Only for sequential execution.2FalseK
print_command2Print what command is being run before running it.2True"+
multirun@@rules_multirun//:multirun.bzl
��,
*
nameA unique name for this target. �
�
buffer_outputlBuffer the output of the commands and print it after each command has finished. Only for parallel execution.2False"
 
commandsTargets to run2[]�
�
data�The list of files needed by the commands at runtime. See general comments about `data` at https://docs.bazel.build/versions/master/be/common-definitions.html#common-attributes2[]�
�
jobs�The expected concurrency of targets to be executed. Default is set to 1 which means sequential execution. Setting to 0 means that there is no limit concurrency.21Y
W

keep_going@Keep going after a command fails. Only for sequential execution.2FalseM
K
print_command2Print what command is being run before running it.2True�multirun_with_transition�Creates a multirun rule which transitions all commands to the given configuration.

This is useful if you have a project-specific configuration that you want
to apply to all of your commands. See also command_with_transition.
*�
�
multirun_with_transition=
cfg2The transition to force on the dependent commands. (n
	allowlistYThe transition allowlist to use for the given cfg. Not necessary in newer bazel versions.None(�Creates a multirun rule which transitions all commands to the given configuration.

This is useful if you have a project-specific configuration that you want
to apply to all of your commands. See also command_with_transition.
2;
multirun_with_transition@@rules_multirun//:multirun.bzl
��a
//lib:shell.bzlrL

bazel_skyliblib	shell.bzl
shellshell
',
.�
//internal:constants.bzlr�
)
rules_multiruninternalconstants.bzl(
CommandInfoCommandInfo


0
RUNFILES_PREFIXRUNFILES_PREFIX
*
update_attrsupdate_attrs

�
Multirun is a rule for running multiple commands in a single invocation. This
can be very useful for something like running multiple linters or formatters
in a single invocation.
 