��
-
rules_nixpkgs_core
extensionspackage.bzl��nix_pkgJ��
�E
nix_pkg�
default{Import a globally unified Nix package from the default nixpkgs repository. May not be used on an isolated module extension.
attrsThe attribute path of the package to import. The attribute path is a sequence of attribute names separated by dots. �
attr�Configure and import a Nix package by attribute path. Overrides default imports of this package. May only be used on an isolated module extension or in the root module or rules_nixpkgs_core.�
name�Configure and import the package under this name instead of the attribute path. Other modules must pass this name to the `default` tag to refer to this package.2""�
attr�The attribute path of the package to configure and import. The attribute path is a sequence of attribute names separated by dots. �	

build_file�	The file to use as the `BUILD` file for the external workspace generated for this package.

Its contents are copied into the file `BUILD` in root of the nix output folder. The Label does not need to be named `BUILD`, but can be.

For common use cases we provide filegroups that expose certain files as targets:

<dl>
  <dt><code>:bin</code></dt>
  <dd>Everything in the <code>bin/</code> directory.</dd>
  <dt><code>:lib</code></dt>
  <dd>All <code>.so</code>, <code>.dylib</code> and <code>.a</code> files that can be found in subdirectories of <code>lib/</code>.</dd>
  <dt><code>:include</code></dt>
  <dd>All <code>.h</code>, <code>.hh</code>, <code>.hpp</code> and <code>.hxx</code> files that can be found in subdirectories of <code>include/</code>.</dd>
</dl>

If you need different files from the nix package, you can reference them like this:
```
package(default_visibility = [ "//visibility:public" ])
filegroup(
    name = "our-docs",
    srcs = glob(["share/doc/ourpackage/**/*"]),
)
```
See the bazel documentation of [`filegroup`](https://docs.bazel.build/versions/master/be/general.html#filegroup) and [`glob`](https://docs.bazel.build/versions/master/be/functions.html#glob).
Specify at most one of `build_file` or `build_file_content`.
2None�
build_file_content�Like `build_file`, but a string of the contents instead of a file name.
Specify at most one of `build_file` or `build_file_content`.
2""p
nixopts_Extra flags to pass when calling Nix. Note, this does not currently support location expansion.2[]�
repopThe Nix repository to use.
Equivalent to `repos = {"nixpkgs": repo}`.
Specify at most one of `repo` or `repos`.
2None�
repos�The Nix repositories to use. The dictionary values represent the names of the
`NIX_PATH` entries. For example, `repositories = { "@somerepo" : "myrepo" }`
would replace all instances of `<myrepo>` in the Nix code by the path to the
Nix repository `@somerepo`. You can provide multiple `NIX_PATH` entry names for a single repository as a colon (`:`) separated string. See the [relevant section in the nix
manual](https://nixos.org/manual/nix/stable/command-ref/env-common.html#env-NIX_PATH) for more information.
Specify at most one of `repo` or `repos`.
	2{}�
file�Configure and import a Nix package from a file. Overrides default imports of this package. May only be used on an isolated module extension or in the root module or rules_nixpkgs_core.�
name�Configure and import the package under this name instead of the attribute path. Other modules must pass this name to the `default` tag to refer to this package.2""�
attr�The attribute path of the package to configure and import. The attribute path is a sequence of attribute names separated by dots. �	

build_file�	The file to use as the `BUILD` file for the external workspace generated for this package.

Its contents are copied into the file `BUILD` in root of the nix output folder. The Label does not need to be named `BUILD`, but can be.

For common use cases we provide filegroups that expose certain files as targets:

<dl>
  <dt><code>:bin</code></dt>
  <dd>Everything in the <code>bin/</code> directory.</dd>
  <dt><code>:lib</code></dt>
  <dd>All <code>.so</code>, <code>.dylib</code> and <code>.a</code> files that can be found in subdirectories of <code>lib/</code>.</dd>
  <dt><code>:include</code></dt>
  <dd>All <code>.h</code>, <code>.hh</code>, <code>.hpp</code> and <code>.hxx</code> files that can be found in subdirectories of <code>include/</code>.</dd>
</dl>

If you need different files from the nix package, you can reference them like this:
```
package(default_visibility = [ "//visibility:public" ])
filegroup(
    name = "our-docs",
    srcs = glob(["share/doc/ourpackage/**/*"]),
)
```
See the bazel documentation of [`filegroup`](https://docs.bazel.build/versions/master/be/general.html#filegroup) and [`glob`](https://docs.bazel.build/versions/master/be/functions.html#glob).
Specify at most one of `build_file` or `build_file_content`.
2None�
build_file_content�Like `build_file`, but a string of the contents instead of a file name.
Specify at most one of `build_file` or `build_file_content`.
2""3
file'The file containing the Nix expression. 8
	file_deps%Files required by the Nix expression.2[]p
nixopts_Extra flags to pass when calling Nix. Note, this does not currently support location expansion.2[]�
repopThe Nix repository to use.
Equivalent to `repos = {"nixpkgs": repo}`.
Specify at most one of `repo` or `repos`.
2None�
repos�The Nix repositories to use. The dictionary values represent the names of the
`NIX_PATH` entries. For example, `repositories = { "@somerepo" : "myrepo" }`
would replace all instances of `<myrepo>` in the Nix code by the path to the
Nix repository `@somerepo`. You can provide multiple `NIX_PATH` entry names for a single repository as a colon (`:`) separated string. See the [relevant section in the nix
manual](https://nixos.org/manual/nix/stable/command-ref/env-common.html#env-NIX_PATH) for more information.
Specify at most one of `repo` or `repos`.
	2{}�
expr�Configure and import a Nix package from a Nix expression. Overrides default imports of this package. May only be used on an isolated module extension or in the root module or rules_nixpkgs_core.�
name�Configure and import the package under this name instead of the attribute path. Other modules must pass this name to the `default` tag to refer to this package.2""�
attr�The attribute path of the package to configure and import. The attribute path is a sequence of attribute names separated by dots. �	

build_file�	The file to use as the `BUILD` file for the external workspace generated for this package.

Its contents are copied into the file `BUILD` in root of the nix output folder. The Label does not need to be named `BUILD`, but can be.

For common use cases we provide filegroups that expose certain files as targets:

<dl>
  <dt><code>:bin</code></dt>
  <dd>Everything in the <code>bin/</code> directory.</dd>
  <dt><code>:lib</code></dt>
  <dd>All <code>.so</code>, <code>.dylib</code> and <code>.a</code> files that can be found in subdirectories of <code>lib/</code>.</dd>
  <dt><code>:include</code></dt>
  <dd>All <code>.h</code>, <code>.hh</code>, <code>.hpp</code> and <code>.hxx</code> files that can be found in subdirectories of <code>include/</code>.</dd>
</dl>

If you need different files from the nix package, you can reference them like this:
```
package(default_visibility = [ "//visibility:public" ])
filegroup(
    name = "our-docs",
    srcs = glob(["share/doc/ourpackage/**/*"]),
)
```
See the bazel documentation of [`filegroup`](https://docs.bazel.build/versions/master/be/general.html#filegroup) and [`glob`](https://docs.bazel.build/versions/master/be/functions.html#glob).
Specify at most one of `build_file` or `build_file_content`.
2None�
build_file_content�Like `build_file`, but a string of the contents instead of a file name.
Specify at most one of `build_file` or `build_file_content`.
2""
exprThe Nix expression. 8
	file_deps%Files required by the Nix expression.2[]p
nixopts_Extra flags to pass when calling Nix. Note, this does not currently support location expansion.2[]�
repopThe Nix repository to use.
Equivalent to `repos = {"nixpkgs": repo}`.
Specify at most one of `repo` or `repos`.
2None�
repos�The Nix repositories to use. The dictionary values represent the names of the
`NIX_PATH` entries. For example, `repositories = { "@somerepo" : "myrepo" }`
would replace all instances of `<myrepo>` in the Nix code by the path to the
Nix repository `@somerepo`. You can provide multiple `NIX_PATH` entry names for a single repository as a colon (`:`) separated string. See the [relevant section in the nix
manual](https://nixos.org/manual/nix/stable/command-ref/env-common.html#env-NIX_PATH) for more information.
Specify at most one of `repo` or `repos`.
	2{}"7
nix_pkg,@@rules_nixpkgs_core//extensions:package.bzl
���
�
default{Import a globally unified Nix package from the default nixpkgs repository. May not be used on an isolated module extension.
attrsThe attribute path of the package to import. The attribute path is a sequence of attribute names separated by dots. �

attrsThe attribute path of the package to import. The attribute path is a sequence of attribute names separated by dots. �*
�
attr�Configure and import a Nix package by attribute path. Overrides default imports of this package. May only be used on an isolated module extension or in the root module or rules_nixpkgs_core.�
name�Configure and import the package under this name instead of the attribute path. Other modules must pass this name to the `default` tag to refer to this package.2""�
attr�The attribute path of the package to configure and import. The attribute path is a sequence of attribute names separated by dots. �	

build_file�	The file to use as the `BUILD` file for the external workspace generated for this package.

Its contents are copied into the file `BUILD` in root of the nix output folder. The Label does not need to be named `BUILD`, but can be.

For common use cases we provide filegroups that expose certain files as targets:

<dl>
  <dt><code>:bin</code></dt>
  <dd>Everything in the <code>bin/</code> directory.</dd>
  <dt><code>:lib</code></dt>
  <dd>All <code>.so</code>, <code>.dylib</code> and <code>.a</code> files that can be found in subdirectories of <code>lib/</code>.</dd>
  <dt><code>:include</code></dt>
  <dd>All <code>.h</code>, <code>.hh</code>, <code>.hpp</code> and <code>.hxx</code> files that can be found in subdirectories of <code>include/</code>.</dd>
</dl>

If you need different files from the nix package, you can reference them like this:
```
package(default_visibility = [ "//visibility:public" ])
filegroup(
    name = "our-docs",
    srcs = glob(["share/doc/ourpackage/**/*"]),
)
```
See the bazel documentation of [`filegroup`](https://docs.bazel.build/versions/master/be/general.html#filegroup) and [`glob`](https://docs.bazel.build/versions/master/be/functions.html#glob).
Specify at most one of `build_file` or `build_file_content`.
2None�
build_file_content�Like `build_file`, but a string of the contents instead of a file name.
Specify at most one of `build_file` or `build_file_content`.
2""p
nixopts_Extra flags to pass when calling Nix. Note, this does not currently support location expansion.2[]�
repopThe Nix repository to use.
Equivalent to `repos = {"nixpkgs": repo}`.
Specify at most one of `repo` or `repos`.
2None�
repos�The Nix repositories to use. The dictionary values represent the names of the
`NIX_PATH` entries. For example, `repositories = { "@somerepo" : "myrepo" }`
would replace all instances of `<myrepo>` in the Nix code by the path to the
Nix repository `@somerepo`. You can provide multiple `NIX_PATH` entry names for a single repository as a colon (`:`) separated string. See the [relevant section in the nix
manual](https://nixos.org/manual/nix/stable/command-ref/env-common.html#env-NIX_PATH) for more information.
Specify at most one of `repo` or `repos`.
	2{}�
�
name�Configure and import the package under this name instead of the attribute path. Other modules must pass this name to the `default` tag to refer to this package.2""�
�
attr�The attribute path of the package to configure and import. The attribute path is a sequence of attribute names separated by dots. �	
�	

build_file�	The file to use as the `BUILD` file for the external workspace generated for this package.

Its contents are copied into the file `BUILD` in root of the nix output folder. The Label does not need to be named `BUILD`, but can be.

For common use cases we provide filegroups that expose certain files as targets:

<dl>
  <dt><code>:bin</code></dt>
  <dd>Everything in the <code>bin/</code> directory.</dd>
  <dt><code>:lib</code></dt>
  <dd>All <code>.so</code>, <code>.dylib</code> and <code>.a</code> files that can be found in subdirectories of <code>lib/</code>.</dd>
  <dt><code>:include</code></dt>
  <dd>All <code>.h</code>, <code>.hh</code>, <code>.hpp</code> and <code>.hxx</code> files that can be found in subdirectories of <code>include/</code>.</dd>
</dl>

If you need different files from the nix package, you can reference them like this:
```
package(default_visibility = [ "//visibility:public" ])
filegroup(
    name = "our-docs",
    srcs = glob(["share/doc/ourpackage/**/*"]),
)
```
See the bazel documentation of [`filegroup`](https://docs.bazel.build/versions/master/be/general.html#filegroup) and [`glob`](https://docs.bazel.build/versions/master/be/functions.html#glob).
Specify at most one of `build_file` or `build_file_content`.
2None�
�
build_file_content�Like `build_file`, but a string of the contents instead of a file name.
Specify at most one of `build_file` or `build_file_content`.
2""r
p
nixopts_Extra flags to pass when calling Nix. Note, this does not currently support location expansion.2[]�
�
repopThe Nix repository to use.
Equivalent to `repos = {"nixpkgs": repo}`.
Specify at most one of `repo` or `repos`.
2None�
�
repos�The Nix repositories to use. The dictionary values represent the names of the
`NIX_PATH` entries. For example, `repositories = { "@somerepo" : "myrepo" }`
would replace all instances of `<myrepo>` in the Nix code by the path to the
Nix repository `@somerepo`. You can provide multiple `NIX_PATH` entry names for a single repository as a colon (`:`) separated string. See the [relevant section in the nix
manual](https://nixos.org/manual/nix/stable/command-ref/env-common.html#env-NIX_PATH) for more information.
Specify at most one of `repo` or `repos`.
	2{}�+
�
file�Configure and import a Nix package from a file. Overrides default imports of this package. May only be used on an isolated module extension or in the root module or rules_nixpkgs_core.�
name�Configure and import the package under this name instead of the attribute path. Other modules must pass this name to the `default` tag to refer to this package.2""�
attr�The attribute path of the package to configure and import. The attribute path is a sequence of attribute names separated by dots. �	

build_file�	The file to use as the `BUILD` file for the external workspace generated for this package.

Its contents are copied into the file `BUILD` in root of the nix output folder. The Label does not need to be named `BUILD`, but can be.

For common use cases we provide filegroups that expose certain files as targets:

<dl>
  <dt><code>:bin</code></dt>
  <dd>Everything in the <code>bin/</code> directory.</dd>
  <dt><code>:lib</code></dt>
  <dd>All <code>.so</code>, <code>.dylib</code> and <code>.a</code> files that can be found in subdirectories of <code>lib/</code>.</dd>
  <dt><code>:include</code></dt>
  <dd>All <code>.h</code>, <code>.hh</code>, <code>.hpp</code> and <code>.hxx</code> files that can be found in subdirectories of <code>include/</code>.</dd>
</dl>

If you need different files from the nix package, you can reference them like this:
```
package(default_visibility = [ "//visibility:public" ])
filegroup(
    name = "our-docs",
    srcs = glob(["share/doc/ourpackage/**/*"]),
)
```
See the bazel documentation of [`filegroup`](https://docs.bazel.build/versions/master/be/general.html#filegroup) and [`glob`](https://docs.bazel.build/versions/master/be/functions.html#glob).
Specify at most one of `build_file` or `build_file_content`.
2None�
build_file_content�Like `build_file`, but a string of the contents instead of a file name.
Specify at most one of `build_file` or `build_file_content`.
2""3
file'The file containing the Nix expression. 8
	file_deps%Files required by the Nix expression.2[]p
nixopts_Extra flags to pass when calling Nix. Note, this does not currently support location expansion.2[]�
repopThe Nix repository to use.
Equivalent to `repos = {"nixpkgs": repo}`.
Specify at most one of `repo` or `repos`.
2None�
repos�The Nix repositories to use. The dictionary values represent the names of the
`NIX_PATH` entries. For example, `repositories = { "@somerepo" : "myrepo" }`
would replace all instances of `<myrepo>` in the Nix code by the path to the
Nix repository `@somerepo`. You can provide multiple `NIX_PATH` entry names for a single repository as a colon (`:`) separated string. See the [relevant section in the nix
manual](https://nixos.org/manual/nix/stable/command-ref/env-common.html#env-NIX_PATH) for more information.
Specify at most one of `repo` or `repos`.
	2{}�
�
name�Configure and import the package under this name instead of the attribute path. Other modules must pass this name to the `default` tag to refer to this package.2""�
�
attr�The attribute path of the package to configure and import. The attribute path is a sequence of attribute names separated by dots. �	
�	

build_file�	The file to use as the `BUILD` file for the external workspace generated for this package.

Its contents are copied into the file `BUILD` in root of the nix output folder. The Label does not need to be named `BUILD`, but can be.

For common use cases we provide filegroups that expose certain files as targets:

<dl>
  <dt><code>:bin</code></dt>
  <dd>Everything in the <code>bin/</code> directory.</dd>
  <dt><code>:lib</code></dt>
  <dd>All <code>.so</code>, <code>.dylib</code> and <code>.a</code> files that can be found in subdirectories of <code>lib/</code>.</dd>
  <dt><code>:include</code></dt>
  <dd>All <code>.h</code>, <code>.hh</code>, <code>.hpp</code> and <code>.hxx</code> files that can be found in subdirectories of <code>include/</code>.</dd>
</dl>

If you need different files from the nix package, you can reference them like this:
```
package(default_visibility = [ "//visibility:public" ])
filegroup(
    name = "our-docs",
    srcs = glob(["share/doc/ourpackage/**/*"]),
)
```
See the bazel documentation of [`filegroup`](https://docs.bazel.build/versions/master/be/general.html#filegroup) and [`glob`](https://docs.bazel.build/versions/master/be/functions.html#glob).
Specify at most one of `build_file` or `build_file_content`.
2None�
�
build_file_content�Like `build_file`, but a string of the contents instead of a file name.
Specify at most one of `build_file` or `build_file_content`.
2""5
3
file'The file containing the Nix expression. :
8
	file_deps%Files required by the Nix expression.2[]r
p
nixopts_Extra flags to pass when calling Nix. Note, this does not currently support location expansion.2[]�
�
repopThe Nix repository to use.
Equivalent to `repos = {"nixpkgs": repo}`.
Specify at most one of `repo` or `repos`.
2None�
�
repos�The Nix repositories to use. The dictionary values represent the names of the
`NIX_PATH` entries. For example, `repositories = { "@somerepo" : "myrepo" }`
would replace all instances of `<myrepo>` in the Nix code by the path to the
Nix repository `@somerepo`. You can provide multiple `NIX_PATH` entry names for a single repository as a colon (`:`) separated string. See the [relevant section in the nix
manual](https://nixos.org/manual/nix/stable/command-ref/env-common.html#env-NIX_PATH) for more information.
Specify at most one of `repo` or `repos`.
	2{}�+
�
expr�Configure and import a Nix package from a Nix expression. Overrides default imports of this package. May only be used on an isolated module extension or in the root module or rules_nixpkgs_core.�
name�Configure and import the package under this name instead of the attribute path. Other modules must pass this name to the `default` tag to refer to this package.2""�
attr�The attribute path of the package to configure and import. The attribute path is a sequence of attribute names separated by dots. �	

build_file�	The file to use as the `BUILD` file for the external workspace generated for this package.

Its contents are copied into the file `BUILD` in root of the nix output folder. The Label does not need to be named `BUILD`, but can be.

For common use cases we provide filegroups that expose certain files as targets:

<dl>
  <dt><code>:bin</code></dt>
  <dd>Everything in the <code>bin/</code> directory.</dd>
  <dt><code>:lib</code></dt>
  <dd>All <code>.so</code>, <code>.dylib</code> and <code>.a</code> files that can be found in subdirectories of <code>lib/</code>.</dd>
  <dt><code>:include</code></dt>
  <dd>All <code>.h</code>, <code>.hh</code>, <code>.hpp</code> and <code>.hxx</code> files that can be found in subdirectories of <code>include/</code>.</dd>
</dl>

If you need different files from the nix package, you can reference them like this:
```
package(default_visibility = [ "//visibility:public" ])
filegroup(
    name = "our-docs",
    srcs = glob(["share/doc/ourpackage/**/*"]),
)
```
See the bazel documentation of [`filegroup`](https://docs.bazel.build/versions/master/be/general.html#filegroup) and [`glob`](https://docs.bazel.build/versions/master/be/functions.html#glob).
Specify at most one of `build_file` or `build_file_content`.
2None�
build_file_content�Like `build_file`, but a string of the contents instead of a file name.
Specify at most one of `build_file` or `build_file_content`.
2""
exprThe Nix expression. 8
	file_deps%Files required by the Nix expression.2[]p
nixopts_Extra flags to pass when calling Nix. Note, this does not currently support location expansion.2[]�
repopThe Nix repository to use.
Equivalent to `repos = {"nixpkgs": repo}`.
Specify at most one of `repo` or `repos`.
2None�
repos�The Nix repositories to use. The dictionary values represent the names of the
`NIX_PATH` entries. For example, `repositories = { "@somerepo" : "myrepo" }`
would replace all instances of `<myrepo>` in the Nix code by the path to the
Nix repository `@somerepo`. You can provide multiple `NIX_PATH` entry names for a single repository as a colon (`:`) separated string. See the [relevant section in the nix
manual](https://nixos.org/manual/nix/stable/command-ref/env-common.html#env-NIX_PATH) for more information.
Specify at most one of `repo` or `repos`.
	2{}�
�
name�Configure and import the package under this name instead of the attribute path. Other modules must pass this name to the `default` tag to refer to this package.2""�
�
attr�The attribute path of the package to configure and import. The attribute path is a sequence of attribute names separated by dots. �	
�	

build_file�	The file to use as the `BUILD` file for the external workspace generated for this package.

Its contents are copied into the file `BUILD` in root of the nix output folder. The Label does not need to be named `BUILD`, but can be.

For common use cases we provide filegroups that expose certain files as targets:

<dl>
  <dt><code>:bin</code></dt>
  <dd>Everything in the <code>bin/</code> directory.</dd>
  <dt><code>:lib</code></dt>
  <dd>All <code>.so</code>, <code>.dylib</code> and <code>.a</code> files that can be found in subdirectories of <code>lib/</code>.</dd>
  <dt><code>:include</code></dt>
  <dd>All <code>.h</code>, <code>.hh</code>, <code>.hpp</code> and <code>.hxx</code> files that can be found in subdirectories of <code>include/</code>.</dd>
</dl>

If you need different files from the nix package, you can reference them like this:
```
package(default_visibility = [ "//visibility:public" ])
filegroup(
    name = "our-docs",
    srcs = glob(["share/doc/ourpackage/**/*"]),
)
```
See the bazel documentation of [`filegroup`](https://docs.bazel.build/versions/master/be/general.html#filegroup) and [`glob`](https://docs.bazel.build/versions/master/be/functions.html#glob).
Specify at most one of `build_file` or `build_file_content`.
2None�
�
build_file_content�Like `build_file`, but a string of the contents instead of a file name.
Specify at most one of `build_file` or `build_file_content`.
2""!

exprThe Nix expression. :
8
	file_deps%Files required by the Nix expression.2[]r
p
nixopts_Extra flags to pass when calling Nix. Note, this does not currently support location expansion.2[]�
�
repopThe Nix repository to use.
Equivalent to `repos = {"nixpkgs": repo}`.
Specify at most one of `repo` or `repos`.
2None�
�
repos�The Nix repositories to use. The dictionary values represent the names of the
`NIX_PATH` entries. For example, `repositories = { "@somerepo" : "myrepo" }`
would replace all instances of `<myrepo>` in the Nix code by the path to the
Nix repository `@somerepo`. You can provide multiple `NIX_PATH` entry names for a single repository as a colon (`:`) separated string. See the [relevant section in the nix
manual](https://nixos.org/manual/nix/stable/command-ref/env-common.html#env-NIX_PATH) for more information.
Specify at most one of `repo` or `repos`.
	2{}a
//lib:dicts.bzlrL

bazel_skyliblib	dicts.bzl
dictsdicts
',
.]
//lib:sets.bzlrI

bazel_skyliblibsets.bzl
setssets
&*
,u
:nixpkgs.bzlrc
!
rules_nixpkgs_corenixpkgs.bzl0
nixpkgs_packagenixpkgs_package
,;
=&Defines the nix_pkg module extension.
�O
0
rules_nixpkgs_core
extensionsrepository.bzl�Knix_repoJ�K
�
nix_repo�
defaultZDepend on this global default repository. May not be used on an isolated module extension./
name#Use this global default repository. �

github�Import a Nix repository from Github. May only be used on an isolated module extension or in the root module or rules_nixpkgs_core.d
nameXA unique name for this repository. The name must be unique within the requesting module. M
commit=The Git commit to download. Specify one of `tag` or `commit`.2""�
	integrity�Expected checksum in Subresource Integrity format of the file downloaded. This must match the checksum of the file downloaded. _It is a security risk to omit the checksum as remote files can change._ At best omitting this field will make your build non-hermetic. It is optional to make development easier but either this attribute or `sha256` should be set before shipping.2""A
org/The GitHub organization hosting the repository.2"NixOS"7
repo"The name of the GitHub repository.2	"nixpkgs"�
sha256�The expected SHA-256 of the file downloaded. This must match the SHA-256 of the file downloaded. _It is a security risk to omit the SHA-256 as remote files can change._ At best omitting this field will make your build non-hermetic. It is optional to make development easier but either this attribute or `integrity` should be set before shipping.2""G
tag:The Git tag to download. Specify one of `tag` or `commit`.2""�	
http�Import a Nix repository from an HTTP URL. May only be used on an isolated module extension or in the root module or rules_nixpkgs_core.d
nameXA unique name for this repository. The name must be unique within the requesting module. �
	integrity�Expected checksum in Subresource Integrity format of the file downloaded. This must match the checksum of the file downloaded. _It is a security risk to omit the checksum as remote files can change._ At best omitting this field will make your build non-hermetic. It is optional to make development easier but either this attribute or `sha256` should be set before shipping.2""�
sha256�The expected SHA-256 of the file downloaded. This must match the SHA-256 of the file downloaded. _It is a security risk to omit the SHA-256 as remote files can change._ At best omitting this field will make your build non-hermetic. It is optional to make development easier but either this attribute or `integrity` should be set before shipping.2""K
strip_prefix5A directory prefix to strip from the extracted files.2""B
url5URL to download from. Specify one of `url` or `urls`.2""L
urls>List of URLs to download from. Specify one of `url` or `urls`.2[]�
file�Import a Nix repository from a local file. May only be used on an isolated module extension or in the root module or rules_nixpkgs_core.d
nameXA unique name for this repository. The name must be unique within the requesting module. 3
file'The file containing the Nix expression. @
	file_deps-List of files required by the Nix expression.2[]�
expr�Import a Nix repository from a Nix expression. May only be used on an isolated module extension or in the root module or rules_nixpkgs_core.d
nameXA unique name for this repository. The name must be unique within the requesting module. 
exprThe Nix expression. @
	file_deps-List of files required by the Nix expression.2[]";
nix_repo/@@rules_nixpkgs_core//extensions:repository.bzl
���
�
defaultZDepend on this global default repository. May not be used on an isolated module extension./
name#Use this global default repository. 1
/
name#Use this global default repository. �
�

github�Import a Nix repository from Github. May only be used on an isolated module extension or in the root module or rules_nixpkgs_core.d
nameXA unique name for this repository. The name must be unique within the requesting module. M
commit=The Git commit to download. Specify one of `tag` or `commit`.2""�
	integrity�Expected checksum in Subresource Integrity format of the file downloaded. This must match the checksum of the file downloaded. _It is a security risk to omit the checksum as remote files can change._ At best omitting this field will make your build non-hermetic. It is optional to make development easier but either this attribute or `sha256` should be set before shipping.2""A
org/The GitHub organization hosting the repository.2"NixOS"7
repo"The name of the GitHub repository.2	"nixpkgs"�
sha256�The expected SHA-256 of the file downloaded. This must match the SHA-256 of the file downloaded. _It is a security risk to omit the SHA-256 as remote files can change._ At best omitting this field will make your build non-hermetic. It is optional to make development easier but either this attribute or `integrity` should be set before shipping.2""G
tag:The Git tag to download. Specify one of `tag` or `commit`.2""f
d
nameXA unique name for this repository. The name must be unique within the requesting module. O
M
commit=The Git commit to download. Specify one of `tag` or `commit`.2""�
�
	integrity�Expected checksum in Subresource Integrity format of the file downloaded. This must match the checksum of the file downloaded. _It is a security risk to omit the checksum as remote files can change._ At best omitting this field will make your build non-hermetic. It is optional to make development easier but either this attribute or `sha256` should be set before shipping.2""C
A
org/The GitHub organization hosting the repository.2"NixOS"9
7
repo"The name of the GitHub repository.2	"nixpkgs"�
�
sha256�The expected SHA-256 of the file downloaded. This must match the SHA-256 of the file downloaded. _It is a security risk to omit the SHA-256 as remote files can change._ At best omitting this field will make your build non-hermetic. It is optional to make development easier but either this attribute or `integrity` should be set before shipping.2""I
G
tag:The Git tag to download. Specify one of `tag` or `commit`.2""�
�	
http�Import a Nix repository from an HTTP URL. May only be used on an isolated module extension or in the root module or rules_nixpkgs_core.d
nameXA unique name for this repository. The name must be unique within the requesting module. �
	integrity�Expected checksum in Subresource Integrity format of the file downloaded. This must match the checksum of the file downloaded. _It is a security risk to omit the checksum as remote files can change._ At best omitting this field will make your build non-hermetic. It is optional to make development easier but either this attribute or `sha256` should be set before shipping.2""�
sha256�The expected SHA-256 of the file downloaded. This must match the SHA-256 of the file downloaded. _It is a security risk to omit the SHA-256 as remote files can change._ At best omitting this field will make your build non-hermetic. It is optional to make development easier but either this attribute or `integrity` should be set before shipping.2""K
strip_prefix5A directory prefix to strip from the extracted files.2""B
url5URL to download from. Specify one of `url` or `urls`.2""L
urls>List of URLs to download from. Specify one of `url` or `urls`.2[]f
d
nameXA unique name for this repository. The name must be unique within the requesting module. �
�
	integrity�Expected checksum in Subresource Integrity format of the file downloaded. This must match the checksum of the file downloaded. _It is a security risk to omit the checksum as remote files can change._ At best omitting this field will make your build non-hermetic. It is optional to make development easier but either this attribute or `sha256` should be set before shipping.2""�
�
sha256�The expected SHA-256 of the file downloaded. This must match the SHA-256 of the file downloaded. _It is a security risk to omit the SHA-256 as remote files can change._ At best omitting this field will make your build non-hermetic. It is optional to make development easier but either this attribute or `integrity` should be set before shipping.2""M
K
strip_prefix5A directory prefix to strip from the extracted files.2""D
B
url5URL to download from. Specify one of `url` or `urls`.2""N
L
urls>List of URLs to download from. Specify one of `url` or `urls`.2[]�
�
file�Import a Nix repository from a local file. May only be used on an isolated module extension or in the root module or rules_nixpkgs_core.d
nameXA unique name for this repository. The name must be unique within the requesting module. 3
file'The file containing the Nix expression. @
	file_deps-List of files required by the Nix expression.2[]f
d
nameXA unique name for this repository. The name must be unique within the requesting module. 5
3
file'The file containing the Nix expression. B
@
	file_deps-List of files required by the Nix expression.2[]�
�
expr�Import a Nix repository from a Nix expression. May only be used on an isolated module extension or in the root module or rules_nixpkgs_core.d
nameXA unique name for this repository. The name must be unique within the requesting module. 
exprThe Nix expression. @
	file_deps-List of files required by the Nix expression.2[]f
d
nameXA unique name for this repository. The name must be unique within the requesting module. !

exprThe Nix expression. B
@
	file_deps-List of files required by the Nix expression.2[]a
//lib:dicts.bzlrL

bazel_skyliblib	dicts.bzl
dictsdicts
',
.]
//lib:sets.bzlrI

bazel_skyliblibsets.bzl
setssets
&*
,�
:nixpkgs.bzlr�
!
rules_nixpkgs_corenixpkgs.bzl@
nixpkgs_http_repositorynixpkgs_http_repository
,CB
nixpkgs_local_repositorynixpkgs_local_repository
G_
a'Defines the nix_repo module extension.
�n
!
rules_nixpkgs_corenixpkgs.bzl�nixpkgs_flake_package�Make the content of a local Nix Flake package available in the Bazel workspace.

**IMPORTANT NOTE**: Calling `nix build` copies the entirety of the Nix Flake
into the Nix Store.  When using the `path:` syntax, this means the directory
containing `flake.nix` and any subdirectories.  Without specifying `path:`
Nix may infer that the flake is the Git repository and copy the entire thing.
As a consequence, you may want to isolate your flake from the rest of the
repository to minimize the amount of unnecessary data that gets copied into
the Nix Store whenever the flake is rebuilt.
*�
�
nixpkgs_flake_package.
name"A unique name for this repository. (B
nix_flake_file,Label to `flake.nix` that will be evaluated. (V
nix_flake_lock_file;Label to `flake.lock` that corresponds to `nix_flake_file`. (P
nix_flake_file_deps3Additional dependencies of `nix_flake_file` if any.[](k
packageXNix Flake package to make available.  The default package will be used if not specified.None(�

build_file�The file to use as the BUILD file for this repository. See [`nixpkgs_package`](#nixpkgs_package-build_file) for more information.None(�
build_file_content�Like `build_file`, but a string of the contents instead of a file name. See [`nixpkgs_package`](#nixpkgs_package-build_file_content) for more information.""(~
nixoptsmExtra flags to pass when calling Nix. See [`nixpkgs_package`](#nixpkgs_package-nixopts) for more information.[](@
quiet.Whether to hide the output of the Nix command.False(�
fail_not_supported�If set to `True` (default) this rule will fail on platforms which do not support Nix (e.g. Windows). If set to `False` calling this rule will succeed but no output will be generated.True(�
legacy_path_syntax�If set to True (not default), the Nix Flake invocation will directly call `nix build <path>` instead of `nix build path:<path>` which may involve copying the entirety of the Git repo into the Nix Store instead of just the path and its children.False("
kwargsCommon rule arguments.(�Make the content of a local Nix Flake package available in the Bazel workspace.

**IMPORTANT NOTE**: Calling `nix build` copies the entirety of the Nix Flake
into the Nix Store.  When using the `path:` syntax, this means the directory
containing `flake.nix` and any subdirectories.  Without specifying `path:`
Nix may infer that the flake is the Git repository and copy the entire thing.
As a consequence, you may want to isolate your flake from the rest of the
repository to minimize the amount of unnecessary data that gets copied into
the Nix Store whenever the flake is rebuilt.
2;
nixpkgs_flake_package"@@rules_nixpkgs_core//:nixpkgs.bzl
��*_nixpkgs_flake_package�nixpkgs_git_repositoryBName a specific revision of Nixpkgs on GitHub or a local checkout.*�
�
nixpkgs_git_repository6
name*String

A unique name for this repository. (Y
revisionIString

Git commit hash or tag identifying the version of Nixpkgs to use. (�
remote�String

The URI of the remote Git repository. This must be a HTTP URL. There is
currently no support for authentication. Defaults to [upstream
nixpkgs](https://github.com/NixOS/nixpkgs).""https://github.com/NixOS/nixpkgs"(T
sha256BString

The SHA256 used to verify the integrity of the repository.None(N
kwargsBAdditional arguments to forward to the underlying repository rule.(BName a specific revision of Nixpkgs on GitHub or a local checkout.2<
nixpkgs_git_repository"@@rules_nixpkgs_core//:nixpkgs.bzl
��*_nixpkgs_http_repository2_nixpkgs_http_repository�nixpkgs_http_repository(Download a Nixpkgs repository over HTTP.*�
�
nixpkgs_http_repository6
name*String

A unique name for this repository. (�
url�String

A URL to download the repository from.

This must be a file, http or https URL. Redirections are followed.

More flexibility can be achieved by the urls parameter that allows
to specify alternative URLs to fetch from.None(�
urls�List of String

A list of URLs to download the repository from.

Each entry must be a file, http or https URL. Redirections are followed.

URLs are tried in order until one succeeds, so you should list local mirrors first.
If all downloads fail, the rule will fail.None(�
auth�Dict of String

An optional dict mapping host names to custom authorization patterns.

If a URL's host name is present in this dict the value will be used as a pattern when
generating the authorization header for the http request. This enables the use of custom
authorization schemes used in a lot of common cloud storage providers.

The pattern currently supports 2 tokens: <code>&lt;login&gt;</code> and
<code>&lt;password&gt;</code>, which are replaced with their equivalent value
in the netrc file for the same host name. After formatting, the result is set
as the value for the <code>Authorization</code> field of the HTTP request.

Example attribute and netrc for a http download to an oauth2 enabled API using a bearer token:

<pre>
auth_patterns = {
    "storage.cloudprovider.com": "Bearer &lt;password&gt;"
}
</pre>

netrc:

<pre>
machine storage.cloudprovider.com
        password RANDOM-TOKEN
</pre>

The final HTTP request would have the following header:

<pre>
Authorization: Bearer RANDOM-TOKEN
</pre>None(�
strip_prefix�String

A directory prefix to strip from the extracted files.

Many archives contain a top-level directory that contains all of the useful
files in archive. This field can be used to strip it from all of the
extracted files.

For example, suppose you are using `nixpkgs-22.11.zip`, which contains
the directory `nixpkgs-22.11/` under which there is the `default.nix`
file and the `pkgs/` directory. Specify `strip_prefix =
"nixpkgs-22.11"` to use the `nixpkgs-22.11` directory as your top-level
directory.

Note that if there are files outside of this directory, they will be
discarded and inaccessible (e.g., a top-level license file). This includes
files/directories that start with the prefix but are not in the directory
(e.g., `nixpkgs-22.11.release-notes`). If the specified prefix does not
match a directory in the archive, Bazel will return an error.None(�
	integrity�String

Expected checksum in Subresource Integrity format of the file downloaded.

This must match the checksum of the file downloaded. _It is a security risk
to omit the checksum as remote files can change._ At best omitting this
field will make your build non-hermetic. It is optional to make development
easier but either this attribute or `sha256` should be set before shipping.None(�
sha256�String
The expected SHA-256 of the file downloaded.

This must match the SHA-256 of the file downloaded. _It is a security risk
to omit the SHA-256 as remote files can change._ At best omitting this
field will make your build non-hermetic. It is optional to make development
easier but should be set before shipping.None(N
kwargsBAdditional arguments to forward to the underlying repository rule.((Download a Nixpkgs repository over HTTP.2=
nixpkgs_http_repository"@@rules_nixpkgs_core//:nixpkgs.bzl
ee*_nixpkgs_http_repository2_nixpkgs_http_repository�nixpkgs_local_repository�Create an external repository representing the content of Nixpkgs.

Based on a Nix expression stored locally or provided inline. One of
`nix_file` or `nix_file_content` must be provided.
*�
�
nixpkgs_local_repository6
name*String

A unique name for this repository. (P
nix_file<Label

A file containing an expression for a Nix derivation.None(K
nix_file_deps2List of labels

Dependencies of `nix_file` if any.None(G
nix_file_content+String

An expression for a Nix derivation.None(m
nix_flake_lock_fileNString

A flake lock file that can be used on the provided nixpkgs repository.None(N
kwargsBAdditional arguments to forward to the underlying repository rule.(�Create an external repository representing the content of Nixpkgs.

Based on a Nix expression stored locally or provided inline. One of
`nix_file` or `nix_file_content` must be provided.
2>
nixpkgs_local_repository"@@rules_nixpkgs_core//:nixpkgs.bzl
��*_nixpkgs_local_repository2_nixpkgs_local_repository�nixpkgs_package�Make the content of a Nixpkgs package available in the Bazel workspace.

If `repositories` is not specified, you must provide a nixpkgs clone in `nix_file` or `nix_file_content`.
*�
�
nixpkgs_package.
name"A unique name for this repository. (�
attribute_path�Select an attribute from the top-level Nix expression being evaluated. The attribute path is a sequence of attribute names separated by dots.""(I
nix_file5A file containing an expression for a Nix derivation.None(9
nix_file_deps"Dependencies of `nix_file` if any.[](=
nix_file_content#An expression for a Nix derivation.""({

repositoryeA repository label identifying which Nixpkgs to use. Equivalent to `repositories = { "nixpkgs": ...}`None(�
repositories�A dictionary mapping `NIX_PATH` entries to repository labels.

Setting it to
```
repositories = { "myrepo" : "//:myrepo" }
```
for example would replace all instances of `<myrepo>` in the called nix code by the path to the target `"//:myrepo"`. See the [relevant section in the nix manual](https://nixos.org/nix/manual/#env-NIX_PATH) for more information.

Specify one of `repository` or `repositories`.{}(�	

build_file�	The file to use as the BUILD file for this repository.

Its contents are copied into the file `BUILD` in root of the nix output folder. The Label does not need to be named `BUILD`, but can be.

For common use cases we provide filegroups that expose certain files as targets:

<dl>
  <dt><code>:bin</code></dt>
  <dd>Everything in the <code>bin/</code> directory.</dd>
  <dt><code>:lib</code></dt>
  <dd>All <code>.so</code>, <code>.dylib</code> and <code>.a</code> files that can be found in subdirectories of <code>lib/</code>.</dd>
  <dt><code>:include</code></dt>
  <dd>All <code>.h</code>, <code>.hh</code>, <code>.hpp</code> and <code>.hxx</code> files that can be found in subdirectories of <code>include/</code>.</dd>
</dl>

If you need different files from the nix package, you can reference them like this:
```
package(default_visibility = [ "//visibility:public" ])
filegroup(
    name = "our-docs",
    srcs = glob(["share/doc/ourpackage/**/*"]),
)
```
See the bazel documentation of [`filegroup`](https://docs.bazel.build/versions/master/be/general.html#filegroup) and [`glob`](https://docs.bazel.build/versions/master/be/functions.html#glob).None(c
build_file_contentGLike `build_file`, but a string of the contents instead of a file name.""(�
nixopts�Extra flags to pass when calling Nix.

Subject to location expansion, any instance of `$(location LABEL)` will be replaced by the path to the file referenced by `LABEL` relative to the workspace root.

Note, labels to external workspaces will resolve to paths that contain `~` characters if the Bazel flag `--enable_bzlmod` is true. Nix does not support `~` characters in path literals at the time of writing, see [#7742](https://github.com/NixOS/nix/issues/7742). Meaning, the result of location expansion may not form a valid Nix path literal. Use `./$${"$(location @for//:example)"}` to work around this limitation if you need to pass a path argument via `--arg`, or pass the resulting path as a string value using `--argstr` and combine it with an additional `--arg workspace_root ./.` argument using `workspace_root + ("/" + path_str)`.[](@
quiet.Whether to hide the output of the Nix command.False(�
fail_not_supported�If set to `True` (default) this rule will fail on platforms which do not support Nix (e.g. Windows). If set to `False` calling this rule will succeed but no output will be generated.True(

kwargs(�Make the content of a Nixpkgs package available in the Bazel workspace.

If `repositories` is not specified, you must provide a nixpkgs clone in `nix_file` or `nix_file_content`.
25
nixpkgs_package"@@rules_nixpkgs_core//:nixpkgs.bzl
��*_nixpkgs_package�
	:util.bzlr�

rules_nixpkgs_coreutil.bzl
cpcp
%%0
executable_pathexecutable_path
&&0
execute_or_failexecute_or_fail
''0
expand_locationexpand_location
((B
external_repository_rootexternal_repository_root
)),
find_childrenfind_children
**<
is_supported_platformis_supported_platform
++
#,�<!-- Edit the docstring in `core/nixpkgs.bzl` and run `bazel run @rules_nixpkgs_docs//:update-readme` to change this repository's `README.md`. -->

# Nixpkgs rules for Bazel

[![Continuous integration](https://github.com/tweag/rules_nixpkgs/actions/workflows/workflow.yaml/badge.svg?event=schedule)](https://github.com/tweag/rules_nixpkgs/actions/workflows/workflow.yaml)

Use [Nix][nix] and the [Nixpkgs][nixpkgs] package set to import
external dependencies (like system packages) into [Bazel][bazel]
hermetically. If the version of any dependency changes, Bazel will
correctly rebuild targets, and only those targets that use the
external dependencies that changed.

Links:
* [Nix + Bazel = fully reproducible, incremental
  builds][blog-bazel-nix] (blog post)
* [Nix + Bazel][youtube-bazel-nix] (lightning talk)

[nix]: https://nixos.org/nix
[nixpkgs]: https://github.com/NixOS/nixpkgs
[bazel]: https://bazel.build
[blog-bazel-nix]: https://www.tweag.io/posts/2018-03-15-bazel-nix.html
[youtube-bazel-nix]: https://www.youtube.com/watch?v=7-K_RmDasEg&t=2030s

See [examples](/examples/toolchains) for how to use `rules_nixpkgs` with different toolchains.

## Rules

* [nixpkgs_git_repository](#nixpkgs_git_repository)
* [nixpkgs_http_repository](#nixpkgs_http_repository)
* [nixpkgs_local_repository](#nixpkgs_local_repository)
* [nixpkgs_package](#nixpkgs_package)
* [nixpkgs_flake_package](#nixpkgs_flake_package)
�

rules_nixpkgs_coreutil.bzl*�ModuleInfo request error: invalid argument: Traceback (most recent call last):
	File "external/rules_nixpkgs_core/util.bzl", line 3, column 55, in <toplevel>
		load("@bazel_tools//tools/cpp:lib_cc_configure.bzl", "get_cpu_value")
Error: file '@bazel_tools//tools/cpp:lib_cc_configure.bzl' does not contain symbol 'get_cpu_value' 