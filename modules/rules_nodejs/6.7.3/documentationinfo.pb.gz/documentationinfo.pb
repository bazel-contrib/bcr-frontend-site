�
nodejsproviders.bzl�UserBuildSettingInfo2x
k
UserBuildSettingInfo
value"J
UserBuildSettingInfo2//nodejs/private/providers:user_build_settings.bzl	

value�StampSettingInfo2�

StampSettingInfo$
valueWhether stamping is enabled"E
StampSettingInfo1//nodejs/private/providers:stamp_setting_info.bzl&
$
valueWhether stamping is enabled_Public providers, aspects and helpers that are shipped in the built-in rules_nodejs repository.�J
nodejsrepositories.bzl�8nodejs_repositories�To be run in user's WORKSPACE to install rules_nodejs dependencies.

This rule sets up node, npm, and npx. The versions of these tools can be specified in one of three ways

### Simplest Usage

Specify no explicit versions. This will download and use the latest Node.js that was available when the
version of rules_nodejs you're using was released.

### Forced version(s)

You can select the version of Node.js to download & use by specifying it when you call node_repositories,
using a value that matches a known version (see the default values)

### Using a custom version

You can pass in a custom list of Node.js repositories and URLs for node_repositories to use.

#### Custom Node.js versions

To specify custom Node.js versions, use the `node_repositories` attribute

```python
nodejs_repositories(
    node_repositories = {
        "10.10.0-darwin_amd64": ("node-v10.10.0-darwin-x64.tar.gz", "node-v10.10.0-darwin-x64", "00b7a8426e076e9bf9d12ba2d571312e833fe962c70afafd10ad3682fdeeaa5e"),
        "10.10.0-linux_amd64": ("node-v10.10.0-linux-x64.tar.xz", "node-v10.10.0-linux-x64", "686d2c7b7698097e67bcd68edc3d6b5d28d81f62436c7cf9e7779d134ec262a9"),
        "10.10.0-windows_amd64": ("node-v10.10.0-win-x64.zip", "node-v10.10.0-win-x64", "70c46e6451798be9d052b700ce5dadccb75cf917f6bf0d6ed54344c856830cfb"),
    },
)
```

These can be mapped to a custom download URL, using `node_urls`

```python
nodejs_repositories(
    node_version = "10.10.0",
    node_repositories = {"10.10.0-darwin_amd64": ("node-v10.10.0-darwin-x64.tar.gz", "node-v10.10.0-darwin-x64", "00b7a8426e076e9bf9d12ba2d571312e833fe962c70afafd10ad3682fdeeaa5e")},
    node_urls = ["https://mycorpproxy/mirror/node/v{version}/{filename}"],
)
```

A Mac client will try to download node from `https://mycorpproxy/mirror/node/v10.10.0/node-v10.10.0-darwin-x64.tar.gz`
and expect that file to have sha256sum `00b7a8426e076e9bf9d12ba2d571312e833fe962c70afafd10ad3682fdeeaa5e`

See the [the repositories documentation](repositories.html) for how to use the resulting repositories.

### Using a custom node.js.

To avoid downloads, you can check in a vendored node.js binary or can build one from source.
See [toolchains](./toolchains.md).
*�&
�
nodejs_repositories-
name#Unique name for the repository rule �
node_download_authpAuth to use for all url requests.

Example: { "type": "basic", "login": "<UserName>", "password": "<Password>" }{}�
node_repositories�Custom list of node repositories to use

A dictionary mapping Node.js versions to sets of hosts and their corresponding (filename, strip_prefix, sha256) tuples.
You should list a node binary for every platform users have, likely Mac, Windows, and Linux.

By default, if this attribute has no items, we'll use a list of all public Node.js releases.{}�
	node_urls�List of URLs to use to download Node.js.

Each entry is a template for downloading a node distribution.

The `{version}` parameter is substituted with the `node_version` attribute,
and `{filename}` with the matching entry from the `node_repositories` attribute.1["https://nodejs.org/dist/v{version}/{filename}"]E
node_version*The specific version of Node.js to install	"22.22.0"�
node_version_from_nvmrc�The .nvmrc file containing the version of Node.js to use.

If set then the version found in the .nvmrc file is used instead of the one specified by node_version.None�
include_headerspSet headers field in NodeInfo provided by this toolchain.

This setting creates a dependency on a c++ toolchain.False
kwargsAdditional parameters�To be run in user's WORKSPACE to install rules_nodejs dependencies.

This rule sets up node, npm, and npx. The versions of these tools can be specified in one of three ways

### Simplest Usage

Specify no explicit versions. This will download and use the latest Node.js that was available when the
version of rules_nodejs you're using was released.

### Forced version(s)

You can select the version of Node.js to download & use by specifying it when you call node_repositories,
using a value that matches a known version (see the default values)

### Using a custom version

You can pass in a custom list of Node.js repositories and URLs for node_repositories to use.

#### Custom Node.js versions

To specify custom Node.js versions, use the `node_repositories` attribute

```python
nodejs_repositories(
    node_repositories = {
        "10.10.0-darwin_amd64": ("node-v10.10.0-darwin-x64.tar.gz", "node-v10.10.0-darwin-x64", "00b7a8426e076e9bf9d12ba2d571312e833fe962c70afafd10ad3682fdeeaa5e"),
        "10.10.0-linux_amd64": ("node-v10.10.0-linux-x64.tar.xz", "node-v10.10.0-linux-x64", "686d2c7b7698097e67bcd68edc3d6b5d28d81f62436c7cf9e7779d134ec262a9"),
        "10.10.0-windows_amd64": ("node-v10.10.0-win-x64.zip", "node-v10.10.0-win-x64", "70c46e6451798be9d052b700ce5dadccb75cf917f6bf0d6ed54344c856830cfb"),
    },
)
```

These can be mapped to a custom download URL, using `node_urls`

```python
nodejs_repositories(
    node_version = "10.10.0",
    node_repositories = {"10.10.0-darwin_amd64": ("node-v10.10.0-darwin-x64.tar.gz", "node-v10.10.0-darwin-x64", "00b7a8426e076e9bf9d12ba2d571312e833fe962c70afafd10ad3682fdeeaa5e")},
    node_urls = ["https://mycorpproxy/mirror/node/v{version}/{filename}"],
)
```

A Mac client will try to download node from `https://mycorpproxy/mirror/node/v10.10.0/node-v10.10.0-darwin-x64.tar.gz`
and expect that file to have sha256sum `00b7a8426e076e9bf9d12ba2d571312e833fe962c70afafd10ad3682fdeeaa5e`

See the [the repositories documentation](repositories.html) for how to use the resulting repositories.

### Using a custom node.js.

To avoid downloads, you can check in a vendored node.js binary or can build one from source.
See [toolchains](./toolchains.md).
20
nodejs_repositories//nodejs:repositories.bzl/
-
name#Unique name for the repository rule �
�
node_download_authpAuth to use for all url requests.

Example: { "type": "basic", "login": "<UserName>", "password": "<Password>" }{}�
�
node_repositories�Custom list of node repositories to use

A dictionary mapping Node.js versions to sets of hosts and their corresponding (filename, strip_prefix, sha256) tuples.
You should list a node binary for every platform users have, likely Mac, Windows, and Linux.

By default, if this attribute has no items, we'll use a list of all public Node.js releases.{}�
�
	node_urls�List of URLs to use to download Node.js.

Each entry is a template for downloading a node distribution.

The `{version}` parameter is substituted with the `node_version` attribute,
and `{filename}` with the matching entry from the `node_repositories` attribute.1["https://nodejs.org/dist/v{version}/{filename}"]G
E
node_version*The specific version of Node.js to install	"22.22.0"�
�
node_version_from_nvmrc�The .nvmrc file containing the version of Node.js to use.

If set then the version found in the .nvmrc file is used instead of the one specified by node_version.None�
�
include_headerspSet headers field in NodeInfo provided by this toolchain.

This setting creates a dependency on a c++ toolchain.False!

kwargsAdditional parameters�node_repositories,Deprecated. Use nodejs_repositories instead.*�
�
node_repositories<
kwargs2Parameters to forward to nodejs_repositories rule.,Deprecated. Use nodejs_repositories instead.2.
node_repositories//nodejs:repositories.bzl>
<
kwargs2Parameters to forward to nodejs_repositories rule.�nodejs_register_toolchains�Convenience macro for users which does typical setup.

- create a repository for each built-in platform like "node16_linux_amd64" -
  this repository is lazily fetched when node is needed for that platform.
- create a convenience repository for the host platform like "node16_host"
- create a repository exposing toolchains for each platform like "node16_platforms"
- register a toolchain pointing at each platform

Users can avoid this macro and do these steps themselves, if they want more control.
*�	
�
nodejs_register_toolchains@
name.base name for all created repos, like "node16""nodejs"�
register�whether to call Bazel register_toolchains on the created toolchains.
Should be True when used from a WORKSPACE file, and False used from bzlmod
which has its own toolchain registration syntax.True1
kwargs'passed to each nodejs_repositories call�Convenience macro for users which does typical setup.

- create a repository for each built-in platform like "node16_linux_amd64" -
  this repository is lazily fetched when node is needed for that platform.
- create a convenience repository for the host platform like "node16_host"
- create a repository exposing toolchains for each platform like "node16_platforms"
- register a toolchain pointing at each platform

Users can avoid this macro and do these steps themselves, if they want more control.
27
nodejs_register_toolchains//nodejs:repositories.bzlB
@
name.base name for all created repos, like "node16""nodejs"�
�
register�whether to call Bazel register_toolchains on the created toolchains.
Should be True when used from a WORKSPACE file, and False used from bzlmod
which has its own toolchain registration syntax.True3
1
kwargs'passed to each nodejs_repositories calltrules_nodejs_dependencies*U
S
rules_nodejs_dependencies26
rules_nodejs_dependencies//nodejs:repositories.bzl+Rules to be called from the users WORKSPACE 