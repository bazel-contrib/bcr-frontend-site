�"
nodejsextensions.bzl�nodeJ�
�

node�

	toolchain8
name$Base name for generated repositories2"nodejs"?
node_version"Version of the Node.js interpreter2	"22.23.1"�
node_version_from_nvmrc�The .nvmrc file containing the version of Node.js to use.

This is recommended to ensure Bazel uses the same Node.js version as non-Bazel tooling.
If set then the version found in the .nvmrc file is used instead of the one specified by node_version.2None�
include_headers�Set headers field in NodeInfo provided by this toolchain.

Required to compile native code into a Node.js binary.
This setting creates a dependency on a c++ toolchain.2False�
	node_urls�List of URLs to use to download Node.js.

Each entry is a template for downloading a node distribution.

The `{version}` parameter is substituted with the `node_version` attribute,
and `{filename}` with the matching entry from the `node_repositories` attribute.21["https://nodejs.org/dist/v{version}/{filename}"]�
node_repositories�Custom list of node repositories to use

A dictionary mapping Node.js versions to sets of hosts and their corresponding (filename, strip_prefix, sha256) tuples.
You should list a node binary for every platform users have, likely Mac, Windows, and Linux.

By default, if this attribute has no items, we'll use a list of all public Node.js releases.2{}"//nodejs:extensions.bzl�
�

	toolchain8
name$Base name for generated repositories2"nodejs"?
node_version"Version of the Node.js interpreter2	"22.23.1"�
node_version_from_nvmrc�The .nvmrc file containing the version of Node.js to use.

This is recommended to ensure Bazel uses the same Node.js version as non-Bazel tooling.
If set then the version found in the .nvmrc file is used instead of the one specified by node_version.2None�
include_headers�Set headers field in NodeInfo provided by this toolchain.

Required to compile native code into a Node.js binary.
This setting creates a dependency on a c++ toolchain.2False�
	node_urls�List of URLs to use to download Node.js.

Each entry is a template for downloading a node distribution.

The `{version}` parameter is substituted with the `node_version` attribute,
and `{filename}` with the matching entry from the `node_repositories` attribute.21["https://nodejs.org/dist/v{version}/{filename}"]�
node_repositories�Custom list of node repositories to use

A dictionary mapping Node.js versions to sets of hosts and their corresponding (filename, strip_prefix, sha256) tuples.
You should list a node binary for every platform users have, likely Mac, Windows, and Linux.

By default, if this attribute has no items, we'll use a list of all public Node.js releases.2{}:
8
name$Base name for generated repositories2"nodejs"A
?
node_version"Version of the Node.js interpreter2	"22.23.1"�
�
node_version_from_nvmrc�The .nvmrc file containing the version of Node.js to use.

This is recommended to ensure Bazel uses the same Node.js version as non-Bazel tooling.
If set then the version found in the .nvmrc file is used instead of the one specified by node_version.2None�
�
include_headers�Set headers field in NodeInfo provided by this toolchain.

Required to compile native code into a Node.js binary.
This setting creates a dependency on a c++ toolchain.2False�
�
	node_urls�List of URLs to use to download Node.js.

Each entry is a template for downloading a node distribution.

The `{version}` parameter is substituted with the `node_version` attribute,
and `{filename}` with the matching entry from the `node_repositories` attribute.21["https://nodejs.org/dist/v{version}/{filename}"]�
�
node_repositories�Custom list of node repositories to use

A dictionary mapping Node.js versions to sets of hosts and their corresponding (filename, strip_prefix, sha256) tuples.
You should list a node binary for every platform users have, likely Mac, Windows, and Linux.

By default, if this attribute has no items, we'll use a list of all public Node.js releases.2{}�Module extensions for nodejs toolchain registration in MODULE.bazel

Example usage, assuming a `.nvmrc` file is present in the same directory as the `MODULE.bazel` file:

```starlark
node = use_extension("@rules_nodejs//nodejs:extensions.bzl", "node")
node.toolchain(node_version_from_nvmrc = "//:.nvmrc")
use_repo(node, "nodejs_toolchains")
```�
nodejsproviders.bzl�UserBuildSettingInfo2x
k
UserBuildSettingInfo
value"J
UserBuildSettingInfo2//nodejs/private/providers:user_build_settings.bzl	

value�StampSettingInfo2�

StampSettingInfo$
valueWhether stamping is enabled"E
StampSettingInfo1//nodejs/private/providers:stamp_setting_info.bzl&
$
valueWhether stamping is enabled_Public providers, aspects and helpers that are shipped in the built-in rules_nodejs repository.�J
nodejsrepositories.bzl�8nodejs_repositories�To be run in user's WORKSPACE to install rules_nodejs dependencies.

This rule sets up node, npm, and npx. The versions of these tools can be specified in one of three ways

### Simplest Usage

Specify no explicit versions. This will download and use the latest Node.js that was available when the
version of rules_nodejs you're using was released.

### Forced version(s)

You can select the version of Node.js to download & use by specifying it when you call node_repositories,
using a value that matches a known version (see the default values)

### Using a custom version

You can pass in a custom list of Node.js repositories and URLs for node_repositories to use.

#### Custom Node.js versions

To specify custom Node.js versions, use the `node_repositories` attribute

```python
nodejs_repositories(
    node_repositories = {
        "10.10.0-darwin_amd64": ("node-v10.10.0-darwin-x64.tar.gz", "node-v10.10.0-darwin-x64", "00b7a8426e076e9bf9d12ba2d571312e833fe962c70afafd10ad3682fdeeaa5e"),
        "10.10.0-linux_amd64": ("node-v10.10.0-linux-x64.tar.xz", "node-v10.10.0-linux-x64", "686d2c7b7698097e67bcd68edc3d6b5d28d81f62436c7cf9e7779d134ec262a9"),
        "10.10.0-windows_amd64": ("node-v10.10.0-win-x64.zip", "node-v10.10.0-win-x64", "70c46e6451798be9d052b700ce5dadccb75cf917f6bf0d6ed54344c856830cfb"),
    },
)
```

These can be mapped to a custom download URL, using `node_urls`

```python
nodejs_repositories(
    node_version = "10.10.0",
    node_repositories = {"10.10.0-darwin_amd64": ("node-v10.10.0-darwin-x64.tar.gz", "node-v10.10.0-darwin-x64", "00b7a8426e076e9bf9d12ba2d571312e833fe962c70afafd10ad3682fdeeaa5e")},
    node_urls = ["https://mycorpproxy/mirror/node/v{version}/{filename}"],
)
```

A Mac client will try to download node from `https://mycorpproxy/mirror/node/v10.10.0/node-v10.10.0-darwin-x64.tar.gz`
and expect that file to have sha256sum `00b7a8426e076e9bf9d12ba2d571312e833fe962c70afafd10ad3682fdeeaa5e`

See the [the repositories documentation](repositories.html) for how to use the resulting repositories.

### Using a custom node.js.

To avoid downloads, you can check in a vendored node.js binary or can build one from source.
See [toolchains](./toolchains.md).
*�'
�
nodejs_repositories/
name#Unique name for the repository rule (�
node_download_authpAuth to use for all url requests.

Example: { "type": "basic", "login": "<UserName>", "password": "<Password>" }{}(�
node_repositories�Custom list of node repositories to use

A dictionary mapping Node.js versions to sets of hosts and their corresponding (filename, strip_prefix, sha256) tuples.
You should list a node binary for every platform users have, likely Mac, Windows, and Linux.

By default, if this attribute has no items, we'll use a list of all public Node.js releases.{}(�
	node_urls�List of URLs to use to download Node.js.

Each entry is a template for downloading a node distribution.

The `{version}` parameter is substituted with the `node_version` attribute,
and `{filename}` with the matching entry from the `node_repositories` attribute.1["https://nodejs.org/dist/v{version}/{filename}"](G
node_version*The specific version of Node.js to install	"22.23.1"(�
node_version_from_nvmrc�The .nvmrc file containing the version of Node.js to use.

If set then the version found in the .nvmrc file is used instead of the one specified by node_version.None(�
include_headerspSet headers field in NodeInfo provided by this toolchain.

This setting creates a dependency on a c++ toolchain.False(!
kwargsAdditional parameters(�To be run in user's WORKSPACE to install rules_nodejs dependencies.

This rule sets up node, npm, and npx. The versions of these tools can be specified in one of three ways

### Simplest Usage

Specify no explicit versions. This will download and use the latest Node.js that was available when the
version of rules_nodejs you're using was released.

### Forced version(s)

You can select the version of Node.js to download & use by specifying it when you call node_repositories,
using a value that matches a known version (see the default values)

### Using a custom version

You can pass in a custom list of Node.js repositories and URLs for node_repositories to use.

#### Custom Node.js versions

To specify custom Node.js versions, use the `node_repositories` attribute

```python
nodejs_repositories(
    node_repositories = {
        "10.10.0-darwin_amd64": ("node-v10.10.0-darwin-x64.tar.gz", "node-v10.10.0-darwin-x64", "00b7a8426e076e9bf9d12ba2d571312e833fe962c70afafd10ad3682fdeeaa5e"),
        "10.10.0-linux_amd64": ("node-v10.10.0-linux-x64.tar.xz", "node-v10.10.0-linux-x64", "686d2c7b7698097e67bcd68edc3d6b5d28d81f62436c7cf9e7779d134ec262a9"),
        "10.10.0-windows_amd64": ("node-v10.10.0-win-x64.zip", "node-v10.10.0-win-x64", "70c46e6451798be9d052b700ce5dadccb75cf917f6bf0d6ed54344c856830cfb"),
    },
)
```

These can be mapped to a custom download URL, using `node_urls`

```python
nodejs_repositories(
    node_version = "10.10.0",
    node_repositories = {"10.10.0-darwin_amd64": ("node-v10.10.0-darwin-x64.tar.gz", "node-v10.10.0-darwin-x64", "00b7a8426e076e9bf9d12ba2d571312e833fe962c70afafd10ad3682fdeeaa5e")},
    node_urls = ["https://mycorpproxy/mirror/node/v{version}/{filename}"],
)
```

A Mac client will try to download node from `https://mycorpproxy/mirror/node/v10.10.0/node-v10.10.0-darwin-x64.tar.gz`
and expect that file to have sha256sum `00b7a8426e076e9bf9d12ba2d571312e833fe962c70afafd10ad3682fdeeaa5e`

See the [the repositories documentation](repositories.html) for how to use the resulting repositories.

### Using a custom node.js.

To avoid downloads, you can check in a vendored node.js binary or can build one from source.
See [toolchains](./toolchains.md).
20
nodejs_repositories//nodejs:repositories.bzl1
/
name#Unique name for the repository rule (�
�
node_download_authpAuth to use for all url requests.

Example: { "type": "basic", "login": "<UserName>", "password": "<Password>" }{}(�
�
node_repositories�Custom list of node repositories to use

A dictionary mapping Node.js versions to sets of hosts and their corresponding (filename, strip_prefix, sha256) tuples.
You should list a node binary for every platform users have, likely Mac, Windows, and Linux.

By default, if this attribute has no items, we'll use a list of all public Node.js releases.{}(�
�
	node_urls�List of URLs to use to download Node.js.

Each entry is a template for downloading a node distribution.

The `{version}` parameter is substituted with the `node_version` attribute,
and `{filename}` with the matching entry from the `node_repositories` attribute.1["https://nodejs.org/dist/v{version}/{filename}"](I
G
node_version*The specific version of Node.js to install	"22.23.1"(�
�
node_version_from_nvmrc�The .nvmrc file containing the version of Node.js to use.

If set then the version found in the .nvmrc file is used instead of the one specified by node_version.None(�
�
include_headerspSet headers field in NodeInfo provided by this toolchain.

This setting creates a dependency on a c++ toolchain.False(#
!
kwargsAdditional parameters(�node_repositories,Deprecated. Use nodejs_repositories instead.*�
�
node_repositories>
kwargs2Parameters to forward to nodejs_repositories rule.(,Deprecated. Use nodejs_repositories instead.2.
node_repositories//nodejs:repositories.bzl@
>
kwargs2Parameters to forward to nodejs_repositories rule.(�nodejs_register_toolchains�Convenience macro for users which does typical setup.

- create a repository for each built-in platform like "node16_linux_amd64" -
  this repository is lazily fetched when node is needed for that platform.
- create a convenience repository for the host platform like "node16_host"
- create a repository exposing toolchains for each platform like "node16_platforms"
- register a toolchain pointing at each platform

Users can avoid this macro and do these steps themselves, if they want more control.
*�	
�
nodejs_register_toolchainsB
name.base name for all created repos, like "node16""nodejs"(�
register�whether to call Bazel register_toolchains on the created toolchains.
Should be True when used from a WORKSPACE file, and False used from bzlmod
which has its own toolchain registration syntax.True(3
kwargs'passed to each nodejs_repositories call(�Convenience macro for users which does typical setup.

- create a repository for each built-in platform like "node16_linux_amd64" -
  this repository is lazily fetched when node is needed for that platform.
- create a convenience repository for the host platform like "node16_host"
- create a repository exposing toolchains for each platform like "node16_platforms"
- register a toolchain pointing at each platform

Users can avoid this macro and do these steps themselves, if they want more control.
27
nodejs_register_toolchains//nodejs:repositories.bzlD
B
name.base name for all created repos, like "node16""nodejs"(�
�
register�whether to call Bazel register_toolchains on the created toolchains.
Should be True when used from a WORKSPACE file, and False used from bzlmod
which has its own toolchain registration syntax.True(5
3
kwargs'passed to each nodejs_repositories call(trules_nodejs_dependencies*U
S
rules_nodejs_dependencies26
rules_nodejs_dependencies//nodejs:repositories.bzl+Rules to be called from the users WORKSPACE�E
nodejstoolchain.bzl�#nodejs_toolchain�Defines a node toolchain for a platform.

You can use this to refer to a vendored nodejs binary in your repository,
or even to compile nodejs from sources using rules_foreign_cc or other rules.

First, in a BUILD.bazel file, create a nodejs_toolchain definition:

```starlark
load("@rules_nodejs//nodejs:toolchain.bzl", "nodejs_toolchain")

nodejs_toolchain(
    name = "toolchain",
    node = "//some/path/bin/node",
)
```

Next, declare which execution platforms or target platforms the toolchain should be selected for
based on constraints. A separate toolchain type is used for runtime target platform selection.

```starlark
toolchain(
    name = "my_nodejs",
    exec_compatible_with = [
        "@platforms//os:linux",
        "@platforms//cpu:x86_64",
    ],
    toolchain = ":toolchain",
    toolchain_type = "@rules_nodejs//nodejs:toolchain_type",
)
toolchain(
    name = "my_nodejs_runtime",
    target_compatible_with = [
        "@platforms//os:linux",
        "@platforms//cpu:x86_64",
    ],
    toolchain = ":toolchain",
    toolchain_type = "@rules_nodejs//nodejs:runtime_toolchain_type",
)
```

See https://bazel.build/extending/toolchains#toolchain-resolution for more information on toolchain
resolution.

Finally in your `WORKSPACE`, register it with `register_toolchains("//:my_nodejs")`

For usage see https://docs.bazel.build/versions/main/toolchains.html#defining-toolchains.
You can use the `--toolchain_resolution_debug` flag to `bazel` to help diagnose which toolchain is selected.
*�
�
nodejs_toolchain'
nameUnique name for this target ("
nodeNode.js executableNone(�
	node_path�Path to Node.js executable file

This is typically an absolute path to a non-hermetic Node.js executable.

Only one of `node` and `node_path` may be set.""()
npmNpm JavaScript entry pointNone(�
npm_path�Path to npm JavaScript entry point.

This is typically an absolute path to a non-hermetic npm installation.

Only one of `npm` and `npm_path` may be set.""(�
npm_srcsxAdditional source files required to run npm.

Not necessary if specifying `npm_path` to a non-hermetic npm installation.[](D
headers1cc_library that contains the Node/v8 header filesNone(!
kwargsAdditional parameters(�Defines a node toolchain for a platform.

You can use this to refer to a vendored nodejs binary in your repository,
or even to compile nodejs from sources using rules_foreign_cc or other rules.

First, in a BUILD.bazel file, create a nodejs_toolchain definition:

```starlark
load("@rules_nodejs//nodejs:toolchain.bzl", "nodejs_toolchain")

nodejs_toolchain(
    name = "toolchain",
    node = "//some/path/bin/node",
)
```

Next, declare which execution platforms or target platforms the toolchain should be selected for
based on constraints. A separate toolchain type is used for runtime target platform selection.

```starlark
toolchain(
    name = "my_nodejs",
    exec_compatible_with = [
        "@platforms//os:linux",
        "@platforms//cpu:x86_64",
    ],
    toolchain = ":toolchain",
    toolchain_type = "@rules_nodejs//nodejs:toolchain_type",
)
toolchain(
    name = "my_nodejs_runtime",
    target_compatible_with = [
        "@platforms//os:linux",
        "@platforms//cpu:x86_64",
    ],
    toolchain = ":toolchain",
    toolchain_type = "@rules_nodejs//nodejs:runtime_toolchain_type",
)
```

See https://bazel.build/extending/toolchains#toolchain-resolution for more information on toolchain
resolution.

Finally in your `WORKSPACE`, register it with `register_toolchains("//:my_nodejs")`

For usage see https://docs.bazel.build/versions/main/toolchains.html#defining-toolchains.
You can use the `--toolchain_resolution_debug` flag to `bazel` to help diagnose which toolchain is selected.
2*
nodejs_toolchain//nodejs:toolchain.bzl)
'
nameUnique name for this target ($
"
nodeNode.js executableNone(�
�
	node_path�Path to Node.js executable file

This is typically an absolute path to a non-hermetic Node.js executable.

Only one of `node` and `node_path` may be set.""(+
)
npmNpm JavaScript entry pointNone(�
�
npm_path�Path to npm JavaScript entry point.

This is typically an absolute path to a non-hermetic npm installation.

Only one of `npm` and `npm_path` may be set.""(�
�
npm_srcsxAdditional source files required to run npm.

Not necessary if specifying `npm_path` to a non-hermetic npm installation.[](F
D
headers1cc_library that contains the Node/v8 header filesNone(#
!
kwargsAdditional parameters(�node_toolchain)Deprecated. Use nodejs_toolchain instead.*�
�
node_toolchain;
kwargs/Parameters to forward to nodejs_toolchain rule.()Deprecated. Use nodejs_toolchain instead.2(
node_toolchain//nodejs:toolchain.bzl=
;
kwargs/Parameters to forward to nodejs_toolchain rule.(�NodeInfo0Information about how to invoke Node.js and npm.2�
�
NodeInfo0Information about how to invoke Node.js and npm.>
node6Node.js executable

If set, node_path will not be set.}
	node_pathpPath to Node.js executable; typically an absolute path to a non-hermetic Node.js.

If set, node will not be set.
npmxNpm JavaScript entry point File

For backward compability, if set then npm_path will be set to the runfiles path of npm.�
npm_path�Path to npm JavaScript entry point; typically an absolute path to a non-hermetic Node.js.

For backward compability, npm_path is set to the runfiles path of npm if npm is set.:
npm_sources+Additional source files required to run npm�
headers�Optional.
(struct) Information about the header files, with fields:
  * providers_map: a dict of string to provider instances. The key should be
    a fully qualified name (e.g. `@rules_foo//bar:baz.bzl#MyInfo`) of the
    provider to uniquely identify its type.

    The following keys are always present:
      * CcInfo: the CcInfo provider instance for the headers.
      * DefaultInfo: the DefaultInfo provider instance for the headers.

    A map is used to allow additional providers from the originating headers
    target (typically a `cc_library`) to be propagated to consumers (directly
    exposing a Target object can cause memory issues and is an anti-pattern).

    When consuming this map, it's suggested to use `providers_map.values()` to
    return all providers; or copy the map and filter out or replace keys as
    appropriate. Note that any keys begining with `_` (underscore) are
    considered private and should be forward along as-is (this better allows
    e.g. `:current_node_cc_headers` to act as the underlying headers target it
    represents).V
target_tool_pathB(DEPRECATED) Path to Node.js executable for backward compatibilityF

tool_files8(DEPRECATED) Alias for [node] for backward compatibility9
	npm_files,(DEPRECATED) Alias for npm_sources.to_list()""
NodeInfo//nodejs:toolchain.bzl@
>
node6Node.js executable

If set, node_path will not be set.
}
	node_pathpPath to Node.js executable; typically an absolute path to a non-hermetic Node.js.

If set, node will not be set.�

npmxNpm JavaScript entry point File

For backward compability, if set then npm_path will be set to the runfiles path of npm.�
�
npm_path�Path to npm JavaScript entry point; typically an absolute path to a non-hermetic Node.js.

For backward compability, npm_path is set to the runfiles path of npm if npm is set.<
:
npm_sources+Additional source files required to run npm�
�
headers�Optional.
(struct) Information about the header files, with fields:
  * providers_map: a dict of string to provider instances. The key should be
    a fully qualified name (e.g. `@rules_foo//bar:baz.bzl#MyInfo`) of the
    provider to uniquely identify its type.

    The following keys are always present:
      * CcInfo: the CcInfo provider instance for the headers.
      * DefaultInfo: the DefaultInfo provider instance for the headers.

    A map is used to allow additional providers from the originating headers
    target (typically a `cc_library`) to be propagated to consumers (directly
    exposing a Target object can cause memory issues and is an anti-pattern).

    When consuming this map, it's suggested to use `providers_map.values()` to
    return all providers; or copy the map and filter out or replace keys as
    appropriate. Note that any keys begining with `_` (underscore) are
    considered private and should be forward along as-is (this better allows
    e.g. `:current_node_cc_headers` to act as the underlying headers target it
    represents).X
V
target_tool_pathB(DEPRECATED) Path to Node.js executable for backward compatibilityH
F

tool_files8(DEPRECATED) Alias for [node] for backward compatibility;
9
	npm_files,(DEPRECATED) Alias for npm_sources.to_list()/This module implements the node toolchain rule. 