��
nsisdefs.bzl�nsis_directory�Represents a directory that will be created when installing. This should only
be utilized for system directories that need to be created with administrator
privileges and then accessed by a non-administrator user."�
�
nsis_directory�Represents a directory that will be created when installing. This should only
be utilized for system directories that need to be created with administrator
privileges and then accessed by a non-administrator user.*
nameA unique name for this target. ;
path/The path that the directory will be located at. �
grants�A dictionary of SID that will be granted permissions to the permissions they
will receive. For details of syntax please review the icacls documentation:
https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/icacls
2{}u
grants_remove^A list of SID to remove existing grants from.

This will always run before grants are applied.2[]�
denials�A dictionary of SID that will be denied permissions to the permissions they
will be denied. For details of syntax please review the icacls documentation:
https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/icacls
2{}x
denials_remove`A list of SID to remove existing denials from.

This will always run before denials are applied.2[]|
integrity_levelTThe integrity level of the directory. Must be one of: l - low, m - medium, h - high.2""J"l"J"m"J"h"`
"integrity_level_inheritance_rights4Inheritance rights to apply with the integrity level2""�
substitutions�A dictionary of OLD SIDS to NEW SIDs that will replace them.

This will run before all other SID based permissions are evaluated.
2{}H
	recursive3Whether or not to apply the permissions recrsively.2True")
nsis_directory//nsis/private:defs.bzl,
*
nameA unique name for this target. =
;
path/The path that the directory will be located at. �
�
grants�A dictionary of SID that will be granted permissions to the permissions they
will receive. For details of syntax please review the icacls documentation:
https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/icacls
2{}w
u
grants_remove^A list of SID to remove existing grants from.

This will always run before grants are applied.2[]�
�
denials�A dictionary of SID that will be denied permissions to the permissions they
will be denied. For details of syntax please review the icacls documentation:
https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/icacls
2{}z
x
denials_remove`A list of SID to remove existing denials from.

This will always run before denials are applied.2[]~
|
integrity_levelTThe integrity level of the directory. Must be one of: l - low, m - medium, h - high.2""J"l"J"m"J"h"b
`
"integrity_level_inheritance_rights4Inheritance rights to apply with the integrity level2""�
�
substitutions�A dictionary of OLD SIDS to NEW SIDs that will replace them.

This will run before all other SID based permissions are evaluated.
2{}J
H
	recursive3Whether or not to apply the permissions recrsively.2Trueɘnsis_installer+Builds a windows installer .exe using NSIS."��
�K
nsis_installer+Builds a windows installer .exe using NSIS.*
nameA unique name for this target. �
id�The unique identifier for this product. This should be the same across all
versions, names, and install locations of the product. It will be used to
identify the product inside the windows registry. ?
product0The display name of the software being packaged. F
product_path2The path safe name of the software being packaged. F
vendor6The display name of the vendor providing the software.2""�
vendor_path�The optional path to use below the root by default. E.g. Company\Department\{{.ProductPath}}.
This will default to the provided vendor field.2""D
description/The description of the software being packaged.2""@
	copyright-The copyright of the software being packaged.2""B
license_file*The license file to use for the installer.2None>
version&The numeric version for the installer.2	"0.0.0.0"�
install_root�The root path to install the software into. Defaults to NSIS's built in
$PROGRAMFILES64 (or $PROGRAMFILES if 32bit) when installed as admin. When
installed as a user, defaults to $LOCALAPPDATA\Programs.

The final $INSTDIR for the software will be one of
- {{.InstallRoot}}\{{.VendorPath}}\{{.ProductPath}}.
- {{.InstallRoot}}\{{.ProductPath}}.2""N
install_path8Overrides vendor_path\product_path with a specific path.2""�
execution_levelmSet the execution level for the installer.

admin: Install software as admin.
user: Install software as user.2"admin"J"admin"J"user"j

compressor9Set the compressor to be used for building the installer.2"lzma"J"lzma"J"zlib"J"bzip2"\
compressor_dictsize@Set the compressor dict size for the lzma compression algorithm.282
icon"The icon to use for the installer.2NoneB
header_image*The image to use for the installer header.2NoneR

menu_image<The image to use for the welcome and finish installer pages.2Nonet
install_categories<The possible install types to use when selecting components.2["Full", "Typical", "Minimal"]J
defines9A list of additional defines to include in the installer.
2{}H
testable3Enable test-ID based isolation for installer tests.2False�
	log_level�The installer's runtime logging level. `none` disables logging; otherwise
messages at the given level and above are written to the details view and,
when attached to a console, to stdout.2"info"J"none"J"debug"J"info"J"warn"J"error"�

components7The list of components and component groups to install.*A
NsisComponentInfo,
NsisComponentInfo//nsis/private:defs.bzl*K
NsisComponentGroupInfo1
NsisComponentGroupInfo//nsis/private:defs.bzl2[]�
options_pagesHOptions pages that are always shown, at the position each page declares.*H
NsisOptionsPageInfo1
NsisOptionsPageInfo//nsis/private:options.bzl2[]�
shortcuts_enabled_defaultiWhether the Shortcuts page's master toggle is on by default. The user's choice is persisted for upgrades.2True\
shortcuts_start_menu_default4Whether Start Menu shortcuts are created by default.2TrueW
shortcuts_desktop_default1Whether Desktop shortcuts are created by default.2False�
start_menu_folderuThe default Start Menu folder, relative to the Programs folder. Defaults to `<vendor_path or vendor>\<product_path>`.2""J
stamp_defaults2A list of default values to use when not stamping.
2{}�
outfile{The outfile to create. Defaults to '{{.Vendor}} {{.Product}} Setup.exe', or '{{.Product}} Setup.exe' when no vendor is set.2""�
uninstaller_namefThe name of the uninstaller file to create in the installation directory. Defaults to 'Uninstall.exe'.2"Uninstall.exe"f
arch,The architecture to build the installer for.2"x86_64"J"x86_64"J"x86_32"J"arm64"J"arm32"�
allow_32bit_on_64bit�Whether to allow a 32bit installer to run on the 64bit OS of the same
instruction set: x86_32 on x86_64 and arm32 on arm64. Cross-ISA hosts (x86 on
arm, arm on x86) are always rejected.2True�
	post_init�Provide a .nsh file that defines a `PostInit` macro that takes no arguments.

This will be included and called after .onInit logic has completed.
The script should properly handle the stack and not overwrite values.

This file will additionally be run through the template engine meaning that
all the fields of the installer rule are available via the go template expression
`{{ (ds "in").CamelCaseName }}` with the exception of `Srcs` which is split into
`Components` and `ComponentGroups`. An additional `ComponentDependencies` key is
available which is a list of:
```jsonc
{
    "Component": "", // <component label name>
    "Dependencies": [], // flattened list of dependency tag names
    "Dependants": [], // flattened list of dependant tag names
    // calculated list of components that should have their reference count
    // decremented when the Component is deselected.
    "RemoveRefs": []
}
```

For details about the component or component group data structure, see the
`nsis_component` and `nsis_component_group` rule documentation.2None�
pre_init�Provide a .nsh file that defines a `PreInit` macro that takes no arguments.

This will be included and called before .onInit logic is executed.
The script should properly handle the stack and not overwrite values.

For more details see `post_init`.2None�
post_uninit�Provide a .nsh file that defines a `PostUnInit` macro that takes no arguments.

This will be included and called after un.onInit logic is executed.
The script should properly handle the stack and not overwrite values.

For more details see `post_init`.2None�

pre_uninit�Provide a .nsh file that defines a `PreUnInit` macro that takes no arguments.

This will be included and called before un.onInit logic is executed.
The script should properly handle the stack and not overwrite values.

For more details see `post_init`.2None�
pluginsKAdditional NSIS plugins (nsis_plugin targets) made available to the script.*>
NsisPluginInfo,
NsisPluginInfo//nsis/private:plugins.bzl2[]�
signing_tool�Which signer to use, or "auto" (the default) to select one per file: from the rule that builds it where that is known, and otherwise from its extension. Note that "auto" requires every signing toolchain to be registered whenever an input is a directory artifact, because a tree's contents are not known until the action runs. Individual files require only the signers they actually select (plus cosign for forced detached signatures). Registered toolchains are still analyzed even when unused.2"auto"J"osslsigncode"J
"codesign"J"cosign"J"jarsigner"J"auto"�
signing_detached_signatures�Which sources get the `.sig` and `.bundle.json` files a detached signature consists of. "auto" (the default) gives them to the sources no native signer claims, since a detached signature is the only kind they can have, and leaves natively signed artifacts to carry their signature embedded. "always" gives every source both, so the outputs of this target stop depending on what its sources are called, at the cost of a cosign invocation per file and a second signature to distribute keys and verification instructions for; it requires a certificate. "never" emits neither, leaving only the signatures native signers embed and copying through anything that has no native signer.2"auto"J"auto"J"always"J"never"�
signing_certificate�The `certificate` target holding the signing material. Without one, files are copied through unsigned, which keeps builds working for contributors who have no key.*Y
SigningCertificateInfo?
SigningCertificateInfo%@rules_signing//signing:providers.bzl2None�
signing_timestamp_url�Timestamp authority to countersign with. Empty (the default) does not timestamp, so signing makes no network call and no third party is told when you build. Set to "default" for the well-known authority of the signer in use (Apple's for codesign, DigiCert's for osslsigncode and jarsigner), or to the URL of a specific server. Note that without a timestamp a signature stops validating once the signing certificate expires, so released artifacts usually want one. Ignored by cosign.2""�
signing_transparency_log�Rekor transparency log to publish cosign signatures to. Empty (the default) publishes nothing, so signing stays offline and no hash of your build output leaves the machine. Set to "default" to opt in to the public Sigstore instance, or to the URL of a specific instance (such as a private Rekor deployment). Enabling this makes every signing action a network call.2""B
signing_description%Signature description when supported.2""2
signing_urlPublisher URL when supported.2""<
signing_optionscodesign --options values.2["runtime"]
signing_entitlements2None�
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.2-1J1J0J-1")
nsis_installer//nsis/private:defs.bzl,
*
nameA unique name for this target. �
�
id�The unique identifier for this product. This should be the same across all
versions, names, and install locations of the product. It will be used to
identify the product inside the windows registry. A
?
product0The display name of the software being packaged. H
F
product_path2The path safe name of the software being packaged. H
F
vendor6The display name of the vendor providing the software.2""�
�
vendor_path�The optional path to use below the root by default. E.g. Company\Department\{{.ProductPath}}.
This will default to the provided vendor field.2""F
D
description/The description of the software being packaged.2""B
@
	copyright-The copyright of the software being packaged.2""D
B
license_file*The license file to use for the installer.2None@
>
version&The numeric version for the installer.2	"0.0.0.0"�
�
install_root�The root path to install the software into. Defaults to NSIS's built in
$PROGRAMFILES64 (or $PROGRAMFILES if 32bit) when installed as admin. When
installed as a user, defaults to $LOCALAPPDATA\Programs.

The final $INSTDIR for the software will be one of
- {{.InstallRoot}}\{{.VendorPath}}\{{.ProductPath}}.
- {{.InstallRoot}}\{{.ProductPath}}.2""P
N
install_path8Overrides vendor_path\product_path with a specific path.2""�
�
execution_levelmSet the execution level for the installer.

admin: Install software as admin.
user: Install software as user.2"admin"J"admin"J"user"l
j

compressor9Set the compressor to be used for building the installer.2"lzma"J"lzma"J"zlib"J"bzip2"^
\
compressor_dictsize@Set the compressor dict size for the lzma compression algorithm.284
2
icon"The icon to use for the installer.2NoneD
B
header_image*The image to use for the installer header.2NoneT
R

menu_image<The image to use for the welcome and finish installer pages.2Nonev
t
install_categories<The possible install types to use when selecting components.2["Full", "Typical", "Minimal"]L
J
defines9A list of additional defines to include in the installer.
2{}J
H
testable3Enable test-ID based isolation for installer tests.2False�
�
	log_level�The installer's runtime logging level. `none` disables logging; otherwise
messages at the given level and above are written to the details view and,
when attached to a console, to stdout.2"info"J"none"J"debug"J"info"J"warn"J"error"�
�

components7The list of components and component groups to install.*A
NsisComponentInfo,
NsisComponentInfo//nsis/private:defs.bzl*K
NsisComponentGroupInfo1
NsisComponentGroupInfo//nsis/private:defs.bzl2[]�
�
options_pagesHOptions pages that are always shown, at the position each page declares.*H
NsisOptionsPageInfo1
NsisOptionsPageInfo//nsis/private:options.bzl2[]�
�
shortcuts_enabled_defaultiWhether the Shortcuts page's master toggle is on by default. The user's choice is persisted for upgrades.2True^
\
shortcuts_start_menu_default4Whether Start Menu shortcuts are created by default.2TrueY
W
shortcuts_desktop_default1Whether Desktop shortcuts are created by default.2False�
�
start_menu_folderuThe default Start Menu folder, relative to the Programs folder. Defaults to `<vendor_path or vendor>\<product_path>`.2""L
J
stamp_defaults2A list of default values to use when not stamping.
2{}�
�
outfile{The outfile to create. Defaults to '{{.Vendor}} {{.Product}} Setup.exe', or '{{.Product}} Setup.exe' when no vendor is set.2""�
�
uninstaller_namefThe name of the uninstaller file to create in the installation directory. Defaults to 'Uninstall.exe'.2"Uninstall.exe"h
f
arch,The architecture to build the installer for.2"x86_64"J"x86_64"J"x86_32"J"arm64"J"arm32"�
�
allow_32bit_on_64bit�Whether to allow a 32bit installer to run on the 64bit OS of the same
instruction set: x86_32 on x86_64 and arm32 on arm64. Cross-ISA hosts (x86 on
arm, arm on x86) are always rejected.2True�
�
	post_init�Provide a .nsh file that defines a `PostInit` macro that takes no arguments.

This will be included and called after .onInit logic has completed.
The script should properly handle the stack and not overwrite values.

This file will additionally be run through the template engine meaning that
all the fields of the installer rule are available via the go template expression
`{{ (ds "in").CamelCaseName }}` with the exception of `Srcs` which is split into
`Components` and `ComponentGroups`. An additional `ComponentDependencies` key is
available which is a list of:
```jsonc
{
    "Component": "", // <component label name>
    "Dependencies": [], // flattened list of dependency tag names
    "Dependants": [], // flattened list of dependant tag names
    // calculated list of components that should have their reference count
    // decremented when the Component is deselected.
    "RemoveRefs": []
}
```

For details about the component or component group data structure, see the
`nsis_component` and `nsis_component_group` rule documentation.2None�
�
pre_init�Provide a .nsh file that defines a `PreInit` macro that takes no arguments.

This will be included and called before .onInit logic is executed.
The script should properly handle the stack and not overwrite values.

For more details see `post_init`.2None�
�
post_uninit�Provide a .nsh file that defines a `PostUnInit` macro that takes no arguments.

This will be included and called after un.onInit logic is executed.
The script should properly handle the stack and not overwrite values.

For more details see `post_init`.2None�
�

pre_uninit�Provide a .nsh file that defines a `PreUnInit` macro that takes no arguments.

This will be included and called before un.onInit logic is executed.
The script should properly handle the stack and not overwrite values.

For more details see `post_init`.2None�
�
pluginsKAdditional NSIS plugins (nsis_plugin targets) made available to the script.*>
NsisPluginInfo,
NsisPluginInfo//nsis/private:plugins.bzl2[]�
�
signing_tool�Which signer to use, or "auto" (the default) to select one per file: from the rule that builds it where that is known, and otherwise from its extension. Note that "auto" requires every signing toolchain to be registered whenever an input is a directory artifact, because a tree's contents are not known until the action runs. Individual files require only the signers they actually select (plus cosign for forced detached signatures). Registered toolchains are still analyzed even when unused.2"auto"J"osslsigncode"J
"codesign"J"cosign"J"jarsigner"J"auto"�
�
signing_detached_signatures�Which sources get the `.sig` and `.bundle.json` files a detached signature consists of. "auto" (the default) gives them to the sources no native signer claims, since a detached signature is the only kind they can have, and leaves natively signed artifacts to carry their signature embedded. "always" gives every source both, so the outputs of this target stop depending on what its sources are called, at the cost of a cosign invocation per file and a second signature to distribute keys and verification instructions for; it requires a certificate. "never" emits neither, leaving only the signatures native signers embed and copying through anything that has no native signer.2"auto"J"auto"J"always"J"never"�
�
signing_certificate�The `certificate` target holding the signing material. Without one, files are copied through unsigned, which keeps builds working for contributors who have no key.*Y
SigningCertificateInfo?
SigningCertificateInfo%@rules_signing//signing:providers.bzl2None�
�
signing_timestamp_url�Timestamp authority to countersign with. Empty (the default) does not timestamp, so signing makes no network call and no third party is told when you build. Set to "default" for the well-known authority of the signer in use (Apple's for codesign, DigiCert's for osslsigncode and jarsigner), or to the URL of a specific server. Note that without a timestamp a signature stops validating once the signing certificate expires, so released artifacts usually want one. Ignored by cosign.2""�
�
signing_transparency_log�Rekor transparency log to publish cosign signatures to. Empty (the default) publishes nothing, so signing stays offline and no hash of your build output leaves the machine. Set to "default" to opt in to the public Sigstore instance, or to the URL of a specific instance (such as a private Rekor deployment). Enabling this makes every signing action a network call.2""D
B
signing_description%Signature description when supported.2""4
2
signing_urlPublisher URL when supported.2"">
<
signing_optionscodesign --options values.2["runtime"] 

signing_entitlements2None�
�
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.2-1J1J0J-1�rnsis_component$Represents a NSIS installer section."�q
�8
nsis_component$Represents a NSIS installer section.*
nameA unique name for this target. _
	directoryLThe sub directory path under $INSTDIR where the component will be installed.2""�
add_to_path�Adds the folder the component installs into (`$INSTDIR` plus `directory`) to
the `PATH` environment variable, and removes it again on uninstall. The machine
`PATH` is changed when the installer runs as admin, the current user's otherwise.
`PATH` is edited in place by the EnVar plugin and never copied into an NSIS
string, which would truncate it at `NSIS_MAX_STRLEN`.2FalseG
service3Whether the component represents a windows service.2False�
service_executable�The executable of the service. Required if service is True. The referenced target need not itself be a Bazel "executable" rule - a `sign()` output, for instance, works fine here too - it just has to produce the single file that is the service's binary.2NoneJ
service_args4Command line args to pass to the service executable.2[]�
service_start_type�Defines the start type to pass into sc.exe start field.

auto: The service will start on system start.
demand: The service will be started manually.
disabled: The service will not be started.2"auto"J"auto"J"demand"J
"disabled"[
service_dependencies=Defines the list of windows services this service depends on.2[]F
description1The description of the component being installed.2""�
selection_mode�Defines how the component shows up in the UI when selecting.

hidden: The component will always be installed and is hidden from the user.
required: The component is visible to the user, but will always be selected.
default: The component is optional but will be selected by default.
optional: The component is optional but will be deselected by default.2
"required"J"hidden"J	"default"J
"required"J
"optional"l
display_nameVThe display name for the component. Defaults to the rule name converted to Title Case.2""�
install_categories^The list of install types that the component will be included in.
Default: ["Full", "Typical"]2["Full", "Typical"]h
srcs2The sources to install as apart of this component.*&
DefaultInfo
DefaultInfo<native>2[]q
dirs A list of directories to create.*A
NsisDirectoryInfo,
NsisDirectoryInfo//nsis/private:defs.bzl2[]�
dependencies�A list of components this one depends on.

NOTE: This is only for deciding what gets installed. This does not create a
strict install order. Components should be able to be installed in any order.*A
NsisComponentInfo,
NsisComponentInfo//nsis/private:defs.bzl2[]�
options_pagesaOptions pages shown when this component is selected. They must use position = "after_components".*H
NsisOptionsPageInfo1
NsisOptionsPageInfo//nsis/private:options.bzl2[]�
	shortcuts�`nsis_shortcut` targets for files this component installs. They are created
after the installation, if the user (or the command line) allows it, and only
when the component was installed.*D
NsisShortcutInfo0
NsisShortcutInfo//nsis/private:shortcuts.bzl2[]�
eventlogQWhether the installer should setup windows event log logging for the application.*K
NsisEventLogSourceInfo1
NsisEventLogSourceInfo//nsis/private:defs.bzl2None�
post_install�Provide a .nsh file that defines a `PostInstall_<bazel name>` macro that takes
one argument OUTPATH

This will be included and called after the component's install logic has completed.
The script should properly handle the stack and not overwrite values.

This file will be run through the go template engine prior to use in the installer.
To get component details from the template engine, use data source
`component_<bazel name>`.
Example:
```
{{ (ds "component_<bazel name>").InstallCategories }}
```

Like the installer, component fields are available via their CamelCaseName.

Notes:
- InstallCategories will be a single string value with the calculated install category numbers to be used with nsis's SectionIn
- DisabledByDefault is available as a bool field
- Required is available as a bool field
- IsHidden is available as a bool field
- CreateDirectories is available as a list of nsis_directory rules (same CamelCaseName field access works).
- Files is a list of {Name,Source} with Name being the output file name and source the bazel path to access the file from.
- Directories is a list of source paths that are directories
- TreeFiles is a list of the paths of files inside the directory sources, relative to the install folder.
- TreeDirectories is a list of the paths of subdirectories inside the directory sources, relative to the install folder, deepest first.
- Shortcuts is a list of {Name, LinkName, Target, TargetRelative, Arguments, Description, Icon, IconRelative, IconIndex, StartMenu, Desktop, Path, StartMenuSubfolder, LocationPath}.
  Shortcuts are created after all `post_install` hooks have run, so the links do not exist yet in a hook.
- HasShortcuts is available as a bool field.
- AddToPath is available as a bool field.
- HasEventLog is available as a bool field.
- EventLog is available as a nsis_eventlog_source rule (same CamelCaseName field access).

Option values from `nsis_options_page`s are available in all hooks through
`${Option_Get} <page> <key> $var`, also in uninstall hooks (from the persisted copy). Values from
pages attached to a component are only meaningful when that component is installed.2None�
pre_install�Provide a .nsh file that defines a `PreInstall_<bazel name>` macro that takes
one argument OUTPATH

This will be included and called before the component's install logic has started.
The script should properly handle the stack and not overwrite values.

For more details see `post_install`.2None�
post_uninstall�Provide a .nsh file that defines a `PostUninstall_<bazel name>` macro that takes
one argument OUTPATH

This will be included and called after the component's uninstall logic has finished.
The script should properly handle the stack and not overwrite values.

For more details see `post_install`.2None�
pre_uninstall�Provide a .nsh file that defines a `PreUninstall_<bazel name>` macro that takes
one argument OUTPATH

This will be included and called before the component's uninstall logic starts.
The script should properly handle the stack and not overwrite values.

For more details see `post_install`.2None�
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.2-1J1J0J-1")
nsis_component//nsis/private:defs.bzl,
*
nameA unique name for this target. a
_
	directoryLThe sub directory path under $INSTDIR where the component will be installed.2""�
�
add_to_path�Adds the folder the component installs into (`$INSTDIR` plus `directory`) to
the `PATH` environment variable, and removes it again on uninstall. The machine
`PATH` is changed when the installer runs as admin, the current user's otherwise.
`PATH` is edited in place by the EnVar plugin and never copied into an NSIS
string, which would truncate it at `NSIS_MAX_STRLEN`.2FalseI
G
service3Whether the component represents a windows service.2False�
�
service_executable�The executable of the service. Required if service is True. The referenced target need not itself be a Bazel "executable" rule - a `sign()` output, for instance, works fine here too - it just has to produce the single file that is the service's binary.2NoneL
J
service_args4Command line args to pass to the service executable.2[]�
�
service_start_type�Defines the start type to pass into sc.exe start field.

auto: The service will start on system start.
demand: The service will be started manually.
disabled: The service will not be started.2"auto"J"auto"J"demand"J
"disabled"]
[
service_dependencies=Defines the list of windows services this service depends on.2[]H
F
description1The description of the component being installed.2""�
�
selection_mode�Defines how the component shows up in the UI when selecting.

hidden: The component will always be installed and is hidden from the user.
required: The component is visible to the user, but will always be selected.
default: The component is optional but will be selected by default.
optional: The component is optional but will be deselected by default.2
"required"J"hidden"J	"default"J
"required"J
"optional"n
l
display_nameVThe display name for the component. Defaults to the rule name converted to Title Case.2""�
�
install_categories^The list of install types that the component will be included in.
Default: ["Full", "Typical"]2["Full", "Typical"]j
h
srcs2The sources to install as apart of this component.*&
DefaultInfo
DefaultInfo<native>2[]s
q
dirs A list of directories to create.*A
NsisDirectoryInfo,
NsisDirectoryInfo//nsis/private:defs.bzl2[]�
�
dependencies�A list of components this one depends on.

NOTE: This is only for deciding what gets installed. This does not create a
strict install order. Components should be able to be installed in any order.*A
NsisComponentInfo,
NsisComponentInfo//nsis/private:defs.bzl2[]�
�
options_pagesaOptions pages shown when this component is selected. They must use position = "after_components".*H
NsisOptionsPageInfo1
NsisOptionsPageInfo//nsis/private:options.bzl2[]�
�
	shortcuts�`nsis_shortcut` targets for files this component installs. They are created
after the installation, if the user (or the command line) allows it, and only
when the component was installed.*D
NsisShortcutInfo0
NsisShortcutInfo//nsis/private:shortcuts.bzl2[]�
�
eventlogQWhether the installer should setup windows event log logging for the application.*K
NsisEventLogSourceInfo1
NsisEventLogSourceInfo//nsis/private:defs.bzl2None�
�
post_install�Provide a .nsh file that defines a `PostInstall_<bazel name>` macro that takes
one argument OUTPATH

This will be included and called after the component's install logic has completed.
The script should properly handle the stack and not overwrite values.

This file will be run through the go template engine prior to use in the installer.
To get component details from the template engine, use data source
`component_<bazel name>`.
Example:
```
{{ (ds "component_<bazel name>").InstallCategories }}
```

Like the installer, component fields are available via their CamelCaseName.

Notes:
- InstallCategories will be a single string value with the calculated install category numbers to be used with nsis's SectionIn
- DisabledByDefault is available as a bool field
- Required is available as a bool field
- IsHidden is available as a bool field
- CreateDirectories is available as a list of nsis_directory rules (same CamelCaseName field access works).
- Files is a list of {Name,Source} with Name being the output file name and source the bazel path to access the file from.
- Directories is a list of source paths that are directories
- TreeFiles is a list of the paths of files inside the directory sources, relative to the install folder.
- TreeDirectories is a list of the paths of subdirectories inside the directory sources, relative to the install folder, deepest first.
- Shortcuts is a list of {Name, LinkName, Target, TargetRelative, Arguments, Description, Icon, IconRelative, IconIndex, StartMenu, Desktop, Path, StartMenuSubfolder, LocationPath}.
  Shortcuts are created after all `post_install` hooks have run, so the links do not exist yet in a hook.
- HasShortcuts is available as a bool field.
- AddToPath is available as a bool field.
- HasEventLog is available as a bool field.
- EventLog is available as a nsis_eventlog_source rule (same CamelCaseName field access).

Option values from `nsis_options_page`s are available in all hooks through
`${Option_Get} <page> <key> $var`, also in uninstall hooks (from the persisted copy). Values from
pages attached to a component are only meaningful when that component is installed.2None�
�
pre_install�Provide a .nsh file that defines a `PreInstall_<bazel name>` macro that takes
one argument OUTPATH

This will be included and called before the component's install logic has started.
The script should properly handle the stack and not overwrite values.

For more details see `post_install`.2None�
�
post_uninstall�Provide a .nsh file that defines a `PostUninstall_<bazel name>` macro that takes
one argument OUTPATH

This will be included and called after the component's uninstall logic has finished.
The script should properly handle the stack and not overwrite values.

For more details see `post_install`.2None�
�
pre_uninstall�Provide a .nsh file that defines a `PreUninstall_<bazel name>` macro that takes
one argument OUTPATH

This will be included and called before the component's uninstall logic starts.
The script should properly handle the stack and not overwrite values.

For more details see `post_install`.2None�
�
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.2-1J1J0J-1�
nsis_component_group:Represents a section group inside of a NSIS section group."�

�
nsis_component_group:Represents a section group inside of a NSIS section group.*
nameA unique name for this target. 2
descriptionThe description of the group.2""G
expanded3Whether the group is expanded by default in the UI.2True@
bold0Whether the group name font is bolded in the UI.2Trueh
display_nameRThe display name for the group. Defaults to the rule name converted to Title Case.2""�

componentsEThe list of components or component groups to be apart of this group. *A
NsisComponentInfo,
NsisComponentInfo//nsis/private:defs.bzl*K
NsisComponentGroupInfo1
NsisComponentGroupInfo//nsis/private:defs.bzl"/
nsis_component_group//nsis/private:defs.bzl,
*
nameA unique name for this target. 4
2
descriptionThe description of the group.2""I
G
expanded3Whether the group is expanded by default in the UI.2TrueB
@
bold0Whether the group name font is bolded in the UI.2Truej
h
display_nameRThe display name for the group. Defaults to the rule name converted to Title Case.2""�
�

componentsEThe list of components or component groups to be apart of this group. *A
NsisComponentInfo,
NsisComponentInfo//nsis/private:defs.bzl*K
NsisComponentGroupInfo1
NsisComponentGroupInfo//nsis/private:defs.bzl�nsis_eventlog_source9Defines an event log source to be installed and utilized,"�
�
nsis_eventlog_source9Defines an event log source to be installed and utilized,*
nameA unique name for this target. 5
keyThe event log key to utilize.2"Application"(
sourceThe source name to utilize w
supported_types=The supported event types. error, warning, and/or information2#["error", "warning", "information"]�
event_message_filesIDefines the values that will go into the EventMessageFile registry subkey2+["%SystemRoot%\\System32\\EventCreate.exe"]l
category_message_filesLDefines the values that will go into the CategoryMessageFile registry subkey2[]n
parameter_message_filesMDefines the values that will go into the ParameterMessageFile registry subkey2[]"/
nsis_eventlog_source//nsis/private:defs.bzl,
*
nameA unique name for this target. 7
5
keyThe event log key to utilize.2"Application"*
(
sourceThe source name to utilize y
w
supported_types=The supported event types. error, warning, and/or information2#["error", "warning", "information"]�
�
event_message_filesIDefines the values that will go into the EventMessageFile registry subkey2+["%SystemRoot%\\System32\\EventCreate.exe"]n
l
category_message_filesLDefines the values that will go into the CategoryMessageFile registry subkey2[]p
n
parameter_message_filesMDefines the values that will go into the ParameterMessageFile registry subkey2[]�2nsis_option�A single installer option, shown as one control on an `nsis_options_page`.

The value is available to install and uninstall hooks through
`${Option_Get} <page> <key> $var`, can be set from the command line with
`/O:<page>.<key>=<value>`, and is persisted for the uninstaller and upgrades
unless `persist = "no"`."�/
�
nsis_option�A single installer option, shown as one control on an `nsis_options_page`.

The value is available to install and uninstall hooks through
`${Option_Get} <page> <key> $var`, can be set from the command line with
`/O:<page>.<key>=<value>`, and is persisted for the uninstaller and upgrades
unless `persist = "no"`.*
nameA unique name for this target. H
key;The option key, [a-z][a-z0-9_]*. Defaults to the rule name.2""�
control�The control kind, which determines the backing data type: `checkbox` (bool),
`number` (int), `text` (string), `password` (secret string, never persisted),
`radio` and `droplist` (one of `choices`), `richedit` (multi-line text, stored
on one line with `\n` and `\\` escapes), `file_request` and `dir_request`
(absolute paths with a Browse button), `combobox` (text with suggested
`choices`), `listbox` and `sorted_listbox` (one of `choices`, or a `|` separated
list with `multi_select`), `date` (YYYY-MM-DD), `ip_address` (IPv4) and
`net_address` (see `address_types`).2"text"J
"checkbox"J"number"J"text"J
"password"J
"richedit"J"file_request"J"dir_request"J"radio"J
"droplist"J
"combobox"J	"listbox"J"sorted_listbox"J"date"J"ip_address"J"net_address"I

label_text5The UI text. Defaults to the rule name in Title Case.2""7
description"Help text shown under the control.2""�
default�The default value in the canonical form of the backing type. String types may
reference NSIS variables such as `$DOCUMENTS`. When empty: unchecked, the
number closest to 0 within min/max, an empty string, or the first choice.2""n
requiredYWhether the value must be non-empty (not for number, checkbox, radio, droplist and date).2False�

enabled_bySA checkbox option on the same page; this control is disabled while it is unchecked.*>
NsisOptionInfo,
NsisOptionInfo//nsis/private:options.bzl2None�
persistVauto: persisted, except passwords. yes: always. no: never. password + yes is an error.2"auto"J"auto"J"yes"J"no"w
choicesfThe valid values of radio, droplist, listbox and sorted_listbox controls; the suggestions of combobox.2[]>
multi_select%List controls: select several values.2False�
number_type;Integer type of a number control. Defaults to signed int32.2"int32"J"int8"J"uint8"J"int16"J"uint16"J"int32"J"uint32"J"int64"J"uint64"v
defaultsdListbox and sorted_listbox with multi_select: the initially selected choices (instead of `default`).2[]L
min?Lower bound of number (integer) and date (YYYY-MM-DD) controls.2""L
max?Upper bound of number (integer) and date (YYYY-MM-DD) controls.2""8

max_length%Maximum text length, 0 for unlimited.20b
linesTHeight of richedit, listbox and sorted_listbox in text lines, 0 for the default (4).20T
filterDfile_request: dialog filter, e.g. `Executables|*.exe|All files|*.*`.2""K
save:file_request: use a save dialog (the file need not exist).2FalseF

must_exist/file_request, dir_request: the path must exist.2False�
address_types|net_address: any of `ipv4`, `ipv6`, `dns` (at least one) plus `with_port` and `with_prefix`. Empty means ipv4, ipv6 and dns.2[]")
nsis_option//nsis/private:options.bzl,
*
nameA unique name for this target. J
H
key;The option key, [a-z][a-z0-9_]*. Defaults to the rule name.2""�
�
control�The control kind, which determines the backing data type: `checkbox` (bool),
`number` (int), `text` (string), `password` (secret string, never persisted),
`radio` and `droplist` (one of `choices`), `richedit` (multi-line text, stored
on one line with `\n` and `\\` escapes), `file_request` and `dir_request`
(absolute paths with a Browse button), `combobox` (text with suggested
`choices`), `listbox` and `sorted_listbox` (one of `choices`, or a `|` separated
list with `multi_select`), `date` (YYYY-MM-DD), `ip_address` (IPv4) and
`net_address` (see `address_types`).2"text"J
"checkbox"J"number"J"text"J
"password"J
"richedit"J"file_request"J"dir_request"J"radio"J
"droplist"J
"combobox"J	"listbox"J"sorted_listbox"J"date"J"ip_address"J"net_address"K
I

label_text5The UI text. Defaults to the rule name in Title Case.2""9
7
description"Help text shown under the control.2""�
�
default�The default value in the canonical form of the backing type. String types may
reference NSIS variables such as `$DOCUMENTS`. When empty: unchecked, the
number closest to 0 within min/max, an empty string, or the first choice.2""p
n
requiredYWhether the value must be non-empty (not for number, checkbox, radio, droplist and date).2False�
�

enabled_bySA checkbox option on the same page; this control is disabled while it is unchecked.*>
NsisOptionInfo,
NsisOptionInfo//nsis/private:options.bzl2None�
�
persistVauto: persisted, except passwords. yes: always. no: never. password + yes is an error.2"auto"J"auto"J"yes"J"no"y
w
choicesfThe valid values of radio, droplist, listbox and sorted_listbox controls; the suggestions of combobox.2[]@
>
multi_select%List controls: select several values.2False�
�
number_type;Integer type of a number control. Defaults to signed int32.2"int32"J"int8"J"uint8"J"int16"J"uint16"J"int32"J"uint32"J"int64"J"uint64"x
v
defaultsdListbox and sorted_listbox with multi_select: the initially selected choices (instead of `default`).2[]N
L
min?Lower bound of number (integer) and date (YYYY-MM-DD) controls.2""N
L
max?Upper bound of number (integer) and date (YYYY-MM-DD) controls.2"":
8

max_length%Maximum text length, 0 for unlimited.20d
b
linesTHeight of richedit, listbox and sorted_listbox in text lines, 0 for the default (4).20V
T
filterDfile_request: dialog filter, e.g. `Executables|*.exe|All files|*.*`.2""M
K
save:file_request: use a save dialog (the file need not exist).2FalseH
F

must_exist/file_request, dir_request: the path must exist.2False�
�
address_types|net_address: any of `ipv4`, `ipv6`, `dns` (at least one) plus `with_port` and `with_prefix`. Empty means ipv4, ipv6 and dns.2[]�nsis_option_group[A group box around several `nsis_option`s on a page. Groups do not nest and carry no value."�
�
nsis_option_group[A group box around several `nsis_option`s on a page. Groups do not nest and carry no value.*
nameA unique name for this target. S

label_text?The group box caption. Defaults to the rule name in Title Case.2""{
options,The options inside the group, top to bottom. *>
NsisOptionInfo,
NsisOptionInfo//nsis/private:options.bzl�

enabled_byVA checkbox option on the same page; the whole group is disabled while it is unchecked.*>
NsisOptionInfo,
NsisOptionInfo//nsis/private:options.bzl2None"/
nsis_option_group//nsis/private:options.bzl,
*
nameA unique name for this target. U
S

label_text?The group box caption. Defaults to the rule name in Title Case.2""}
{
options,The options inside the group, top to bottom. *>
NsisOptionInfo,
NsisOptionInfo//nsis/private:options.bzl�
�

enabled_byVA checkbox option on the same page; the whole group is disabled while it is unchecked.*>
NsisOptionInfo,
NsisOptionInfo//nsis/private:options.bzl2None�nsis_options_page�An installer page showing options. Attach it with `nsis_installer.options_pages`
(always shown) or `nsis_component.options_pages` (shown when the component is
selected, only at `position = "after_components"`)."�
�
nsis_options_page�An installer page showing options. Attach it with `nsis_installer.options_pages`
(always shown) or `nsis_component.options_pages` (shown when the component is
selected, only at `position = "after_components"`).*
nameA unique name for this target. G
title8The page title. Defaults to the rule name in Title Case.2""$
subtitleThe page subtitle.2"";
text-An optional paragraph at the top of the page.2""�
options-The options and option groups, top to bottom.*>
NsisOptionInfo,
NsisOptionInfo//nsis/private:options.bzl*H
NsisOptionGroupInfo1
NsisOptionGroupInfo//nsis/private:options.bzl2[]�
positionKWhere the page is placed. All positions are before the files are installed.2"after_components"J"after_welcome"J"after_license"J"after_directory"J"after_components"=
order/Tie-break within a position, then by rule name.20"/
nsis_options_page//nsis/private:options.bzl,
*
nameA unique name for this target. I
G
title8The page title. Defaults to the rule name in Title Case.2""&
$
subtitleThe page subtitle.2""=
;
text-An optional paragraph at the top of the page.2""�
�
options-The options and option groups, top to bottom.*>
NsisOptionInfo,
NsisOptionInfo//nsis/private:options.bzl*H
NsisOptionGroupInfo1
NsisOptionGroupInfo//nsis/private:options.bzl2[]�
�
positionKWhere the page is placed. All positions are before the files are installed.2"after_components"J"after_welcome"J"after_license"J"after_directory"J"after_components"?
=
order/Tie-break within a position, then by rule name.20�#nsis_shortcut�A shortcut (.lnk) to a file that an `nsis_component` installs.

List it in the component's `shortcuts`. The shortcuts are created after the
installation finished, on the installer's internal Shortcuts page (or silently,
driven by `/O:shortcuts.<key>=<value>`), only for components that were
installed, and removed again by the uninstaller if they still point into the
installation directory. The shortcut's "Start in" folder is the target's folder."� 
�
nsis_shortcut�A shortcut (.lnk) to a file that an `nsis_component` installs.

List it in the component's `shortcuts`. The shortcuts are created after the
installation finished, on the installer's internal Shortcuts page (or silently,
driven by `/O:shortcuts.<key>=<value>`), only for components that were
installed, and removed again by the uninstaller if they still point into the
installation directory. The shortcut's "Start in" folder is the target's folder.*
nameA unique name for this target. �
target�The file the shortcut points at. It must be one of the `srcs` (or the
`service_executable`) of the component that lists the shortcut. When it is a
directory (tree artifact), set `target_subpath`. �
target_subpath�Required when `target` is a directory and forbidden otherwise: the relative
path of the file inside that directory. `/` and `\` are both accepted; no
absolute paths and no `.` or `..` segments.2""r
display_name\The shortcut's name, shown as `<display_name>.lnk`. Defaults to the rule name in Title Case.2""6
description!The shortcut's comment (tooltip).2""V
	argumentsCCommand line arguments. Arguments with spaces or quotes are quoted.2[]�
icon�Optional file the icon is taken from (an .ico, or an executable and an
`icon_index`). It follows the rules of `target`: it must be installed by the
same component, and a directory needs `icon_subpath`. Defaults to the icon of
the target.2None8
icon_subpath"Like `target_subpath`, for `icon`.2""c

icon_indexPThe index of the icon in the icon file (or in the target when no `icon` is set).20�
	locations�Where to create the shortcut: any of `start_menu`, `desktop` and `path`. The
first two follow the user's choices on the Shortcuts page; `path` is only
governed by the page's master toggle.2["start_menu", "desktop"]q
start_menu_subfolderSA folder below the Start Menu folder the user chose, for the `start_menu` location.2""�
location_path�The absolute folder for the `path` location (required exactly when `locations`
contains it). A drive path, a UNC path, or a path starting with one of the
NSIS shell constants `$INSTDIR`, `$SMSTARTUP`, `$APPDATA`, ... which resolve
for the installer's shell context.2"""-
nsis_shortcut//nsis/private:shortcuts.bzl,
*
nameA unique name for this target. �
�
target�The file the shortcut points at. It must be one of the `srcs` (or the
`service_executable`) of the component that lists the shortcut. When it is a
directory (tree artifact), set `target_subpath`. �
�
target_subpath�Required when `target` is a directory and forbidden otherwise: the relative
path of the file inside that directory. `/` and `\` are both accepted; no
absolute paths and no `.` or `..` segments.2""t
r
display_name\The shortcut's name, shown as `<display_name>.lnk`. Defaults to the rule name in Title Case.2""8
6
description!The shortcut's comment (tooltip).2""X
V
	argumentsCCommand line arguments. Arguments with spaces or quotes are quoted.2[]�
�
icon�Optional file the icon is taken from (an .ico, or an executable and an
`icon_index`). It follows the rules of `target`: it must be installed by the
same component, and a directory needs `icon_subpath`. Defaults to the icon of
the target.2None:
8
icon_subpath"Like `target_subpath`, for `icon`.2""e
c

icon_indexPThe index of the icon in the icon file (or in the target when no `icon` is set).20�
�
	locations�Where to create the shortcut: any of `start_menu`, `desktop` and `path`. The
first two follow the user's choices on the Shortcuts page; `path` is only
governed by the page's master toggle.2["start_menu", "desktop"]s
q
start_menu_subfolderSA folder below the Start Menu folder the user chose, for the `start_menu` location.2""�
�
location_path�The absolute folder for the `path` location (required exactly when `locations`
contains it). A drive path, a UNC path, or a path starting with one of the
NSIS shell constants `$INSTDIR`, `$SMSTARTUP`, `$APPDATA`, ... which resolve
for the installer's shell context.2""�	nsis_plugin�Declares a prebuilt NSIS plugin.

Each DLL must be named `<plugin_name>.dll`, because makensis derives the
command prefix from the file name."�
�
nsis_plugin�Declares a prebuilt NSIS plugin.

Each DLL must be named `<plugin_name>.dll`, because makensis derives the
command prefix from the file name.*
nameA unique name for this target. b
plugin_nameMThe name scripts use, as in `plugin_name::Func`. Defaults to the target name.2""-
x86_unicodeThe x86-unicode build.2None1
amd64_unicodeThe amd64-unicode build.2None=
includes+Headers made available with !addincludedir.2[]Q
licenseBThe license file, collected in the `plugin_licenses` output group. ")
nsis_plugin//nsis/private:plugins.bzl,
*
nameA unique name for this target. d
b
plugin_nameMThe name scripts use, as in `plugin_name::Func`. Defaults to the target name.2""/
-
x86_unicodeThe x86-unicode build.2None3
1
amd64_unicodeThe amd64-unicode build.2None?
=
includes+Headers made available with !addincludedir.2[]S
Q
licenseBThe license file, collected in the `plugin_licenses` output group. �NsisOptionInfoFA single installer option, rendered as one control on an options page.2�
�	
NsisOptionInfoFA single installer option, rendered as one control on an options page.4
label+The Bazel label of the option, as a string.
nameThe rule name..
key'The option key, unique within its page.
controlThe control kind.4
type,The backing data type of the option's value."
textThe label shown in the UI.5
description&The help text shown under the control.)
defaultThe default in canonical form.0
required$Whether the value must be non-empty.Z

enabled_byLThe Bazel label (string) of the checkbox option enabling this one, or empty.4
persist)The effective persistence: True or False..
choices#The valid values for enum controls.>
multi_select.Whether a list control selects several values.'
min Canonical lower bound, or empty.'
max Canonical upper bound, or empty.3

max_length%Maximum text length, 0 for unlimited.9
lines0Control height in text lines, 0 for the default.
filterFile dialog filter.1
save)Whether the file dialog is a save dialog.(

must_existWhether a path must exist.0
address_typesAccepted network address types.I
	net_flags<The NET_STRING_* mask of the accepted network address types.",
NsisOptionInfo//nsis/private:options.bzl6
4
label+The Bazel label of the option, as a string.

nameThe rule name.0
.
key'The option key, unique within its page.

controlThe control kind.6
4
type,The backing data type of the option's value.$
"
textThe label shown in the UI.7
5
description&The help text shown under the control.+
)
defaultThe default in canonical form.2
0
required$Whether the value must be non-empty.\
Z

enabled_byLThe Bazel label (string) of the checkbox option enabling this one, or empty.6
4
persist)The effective persistence: True or False.0
.
choices#The valid values for enum controls.@
>
multi_select.Whether a list control selects several values.)
'
min Canonical lower bound, or empty.)
'
max Canonical upper bound, or empty.5
3

max_length%Maximum text length, 0 for unlimited.;
9
lines0Control height in text lines, 0 for the default.

filterFile dialog filter.3
1
save)Whether the file dialog is a save dialog.*
(

must_existWhether a path must exist.2
0
address_typesAccepted network address types.K
I
	net_flags<The NET_STRING_* mask of the accepted network address types.�NsisOptionGroupInfo#A group box around several options.2�
�
NsisOptionGroupInfo#A group box around several options.3
label*The Bazel label of the group, as a string.
nameThe rule name.
textThe group box caption.[

enabled_byMThe Bazel label (string) of the checkbox option enabling the group, or empty.E
options:The NsisOptionInfo of every option in the group, in order."1
NsisOptionGroupInfo//nsis/private:options.bzl5
3
label*The Bazel label of the group, as a string.

nameThe rule name. 

textThe group box caption.]
[

enabled_byMThe Bazel label (string) of the checkbox option enabling the group, or empty.G
E
options:The NsisOptionInfo of every option in the group, in order.�NsisOptionsPageInfo5An options page with its validated, laid out content.2�
�
NsisOptionsPageInfo5An options page with its validated, laid out content.2
label)The Bazel label of the page, as a string.
nameThe page id.6
position*Where the page is placed in the installer.@
ds:The page data source entry, without the owning components."1
NsisOptionsPageInfo//nsis/private:options.bzl4
2
label)The Bazel label of the page, as a string.

nameThe page id.8
6
position*Where the page is placed in the installer.B
@
ds:The page data source entry, without the owning components.�NsisShortcutInfo.A shortcut to a file installed by a component.2�
�
NsisShortcutInfo.A shortcut to a file installed by a component.6
label-The Bazel label of the shortcut, as a string.
nameThe rule name.?
	link_name2The shortcut file name without the .lnk extension.L
targetBThe File the shortcut points at (a file, or a directory artifact).J
target_subpath8The file inside a directory target, with `\` separators.G
icon?The File providing the icon, or None for the target's own icon.F
icon_subpath6The file inside a directory icon, with `\` separators.

icon_indexThe icon index.8
	arguments+The command line arguments, already quoted.&
descriptionThe shortcut's comment.7

start_menu)Whether a Start Menu shortcut is created.1
desktop&Whether a Desktop shortcut is created.7
path/Whether a shortcut is created in location_path.F
start_menu_subfolder.The Start Menu subfolder, with `\` separators.4
location_path#The folder for the `path` location.U

validationGA depset of files of the actions validating the shortcut at build time."0
NsisShortcutInfo//nsis/private:shortcuts.bzl8
6
label-The Bazel label of the shortcut, as a string.

nameThe rule name.A
?
	link_name2The shortcut file name without the .lnk extension.N
L
targetBThe File the shortcut points at (a file, or a directory artifact).L
J
target_subpath8The file inside a directory target, with `\` separators.I
G
icon?The File providing the icon, or None for the target's own icon.H
F
icon_subpath6The file inside a directory icon, with `\` separators.


icon_indexThe icon index.:
8
	arguments+The command line arguments, already quoted.(
&
descriptionThe shortcut's comment.9
7

start_menu)Whether a Start Menu shortcut is created.3
1
desktop&Whether a Desktop shortcut is created.9
7
path/Whether a shortcut is created in location_path.H
F
start_menu_subfolder.The Start Menu subfolder, with `\` separators.6
4
location_path#The folder for the `path` location.W
U

validationGA depset of files of the actions validating the shortcut at build time.�NsisPluginInfoAn NSIS plugin.2�
�
NsisPluginInfoAn NSIS plugin.=
name5The plugin name scripts use, as in plugin_name::Func.2
dlls*dict[str, File] keyed by NSIS target name.<
includes0list[File] of headers added with !addincludedir.
licenseFile: the license.",
NsisPluginInfo//nsis/private:plugins.bzl?
=
name5The plugin name scripts use, as in plugin_name::Func.4
2
dlls*dict[str, File] keyed by NSIS target name.>
<
includes0list[File] of headers added with !addincludedir.

licenseFile: the license.�Public definitions for NSIS installers

Contains the public rulesets for creating installers using NSIS.

Definitions outside this file are subject to change without notice.�
nsisextensions.bzl�nsisOModule extension that provides NSIS (makensis) tool and toolchain repositories.J�
�
nsisOModule extension that provides NSIS (makensis) tool and toolchain repositories.�

executable4Declares an NSIS toolchain to download and register.{
nameiPrefix for the generated repos `<name>_tool` and `<name>_toolchains`; only the root module may change it.2"nsis"A
version,The version of NSIS to use. Supported: 3.11.2"3.11""//nsis/private:extensions.bzl�
�

executable4Declares an NSIS toolchain to download and register.{
nameiPrefix for the generated repos `<name>_tool` and `<name>_toolchains`; only the root module may change it.2"nsis"A
version,The version of NSIS to use. Supported: 3.11.2"3.11"}
{
nameiPrefix for the generated repos `<name>_tool` and `<name>_toolchains`; only the root module may change it.2"nsis"C
A
version,The version of NSIS to use. Supported: 3.11.2"3.11"�
nsisrepositories.bzl�nsis_plugin_archive�Downloads an NSIS plugin archive and declares `@<name>//:plugin`.

The archive must have the usual layout: `Plugins/x86-unicode/<plugin_name>.dll`,
`Plugins/amd64-unicode` or `Plugins/x64-unicode` for the 64-bit build, and
headers in `Include/`. With `source_dir`, the DLLs are instead compiled from the
C sources in that folder, after `patches` are applied. For other layouts, use
http_archive with a build_file_content that calls nsis_plugin.R�
�	
nsis_plugin_archive�Downloads an NSIS plugin archive and declares `@<name>//:plugin`.

The archive must have the usual layout: `Plugins/x86-unicode/<plugin_name>.dll`,
`Plugins/amd64-unicode` or `Plugins/x64-unicode` for the 64-bit build, and
headers in `Include/`. With `source_dir`, the DLLs are instead compiled from the
C sources in that folder, after `patches` are applied. For other layouts, use
http_archive with a build_file_content that calls nsis_plugin..
name"A unique name for this repository. A
plugin_name.The name scripts use, as in plugin_name::Func. 

urls 
sha256 
strip_prefix2"";
license,Path of the license file inside the archive. P
patches?Patches applied after extraction, relative to the archive root.2[]X
patch_stripDLeading path components stripped from the file names in the patches.21�

source_dir�Folder with the plugin's C sources. When set, both Unicode DLLs are compiled from its .c files with Zig, without a C runtime, instead of taken from the archive.2""O
copts@Compiler flags for a source build, including -DNAME definitions.2[]*.
nsis_plugin_archive//nsis:repositories.bzl0
.
name"A unique name for this repository. C
A
plugin_name.The name scripts use, as in plugin_name::Func. 


urls 

sha256 

strip_prefix2""=
;
license,Path of the license file inside the archive. R
P
patches?Patches applied after extraction, relative to the archive root.2[]Z
X
patch_stripDLeading path components stripped from the file names in the patches.21�
�

source_dir�Folder with the plugin's C sources. When set, both Unicode DLLs are compiled from its .c files with Zig, without a C runtime, instead of taken from the archive.2""Q
O
copts@Compiler flags for a source build, including -DNAME definitions.2[]+Repository rules for fetching NSIS plugins.�
nsistoolchain.bzl�nsis_toolchain/Defines an NSIS Bazel toolchain implementation."�
�
nsis_toolchain/Defines an NSIS Bazel toolchain implementation.*
nameA unique name for this target. $
makensismakensis executable. 2

nsis_filesAll NSIS distribution files.2None*
nsis_dirThe directory for NSISDIR. i

args_styleFThe possible type of argument prefix. Slash for win and dash for unix. J"slash"J"dash"W

path_style2The style of path that things should be output as. J	"windows"J"unix""1
nsis_toolchain//nsis/toolchain:toolchains.bzl,
*
nameA unique name for this target. &
$
makensismakensis executable. 4
2

nsis_filesAll NSIS distribution files.2None,
*
nsis_dirThe directory for NSISDIR. k
i

args_styleFThe possible type of argument prefix. Slash for win and dash for unix. J"slash"J"dash"Y
W

path_style2The style of path that things should be output as. J	"windows"J"unix" 