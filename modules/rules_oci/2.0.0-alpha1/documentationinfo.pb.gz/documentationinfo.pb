�
'
	rules_ocicosign/private
attest.bzl�cosign_attest�Attest an oci_image using cosign binary at a remote registry.

```starlark
oci_image(
    name = "image"
)

cosign_attest(
    name = "attest_spdx",
    type = "spdx"
    predicate = "image.sbom.spdx.json",
    repository = "index.docker.io/org/image"
)
```

`repository` attribute can be overridden using the `--repository` flag.

```starlark
oci_image(
    name = "image"
)

cosign_attest(
    name = "attest_spdx",
    type = "spdx"
    attestment = "image.sbom.spdx.json",
    repository = "index.docker.io/org/image"
)
```

via `bazel run :attest_spdx -- --repository=index.docker.io/org/test`
"�
�
cosign_attest�Attest an oci_image using cosign binary at a remote registry.

```starlark
oci_image(
    name = "image"
)

cosign_attest(
    name = "attest_spdx",
    type = "spdx"
    predicate = "image.sbom.spdx.json",
    repository = "index.docker.io/org/image"
)
```

`repository` attribute can be overridden using the `--repository` flag.

```starlark
oci_image(
    name = "image"
)

cosign_attest(
    name = "attest_spdx",
    type = "spdx"
    attestment = "image.sbom.spdx.json",
    repository = "index.docker.io/org/image"
)
```

via `bazel run :attest_spdx -- --repository=index.docker.io/org/test`
*
nameA unique name for this target. "
imageLabel to an oci_image a
	predicatePLabel to the predicate file. Only files are allowed. eg: sbom.spdx, in-toto.json �

repositoryzRepository URL where the image will be signed at, e.g.: `index.docker.io/<user>/image`.
Digests and tags are not allowed.
 [
typeOType of predicate. Acceptable values are (slsaprovenance|link|spdx|vuln|custom) "7
cosign_attest&@@rules_oci//cosign/private:attest.bzl
SS,
*
nameA unique name for this target. $
"
imageLabel to an oci_image c
a
	predicatePLabel to the predicate file. Only files are allowed. eg: sbom.spdx, in-toto.json �
�

repositoryzRepository URL where the image will be signed at, e.g.: `index.docker.io/<user>/image`.
Digests and tags are not allowed.
 ]
[
typeOType of predicate. Acceptable values are (slsaprovenance|link|spdx|vuln|custom) &Implementation details for attest rule�
%
	rules_ocicosign/privatesign.bzl�cosign_sign�Sign an oci_image using cosign binary at a remote registry.

It signs the image by its digest determined beforehand.

```starlark
oci_image(
    name = "image"
)

cosign_sign(
    name = "sign",
    image = ":image",
    repository = "index.docker.io/org/image"
)
```

`repository` attribute can be overridden using the `--repository` flag.

```starlark
oci_image(
    name = "image"
)

cosign_sign(
    name = "sign",
    image = ":image",
    repository = "index.docker.io/org/image"
)
```

run `bazel run :sign -- --repository=index.docker.io/org/test`
"�
�
cosign_sign�Sign an oci_image using cosign binary at a remote registry.

It signs the image by its digest determined beforehand.

```starlark
oci_image(
    name = "image"
)

cosign_sign(
    name = "sign",
    image = ":image",
    repository = "index.docker.io/org/image"
)
```

`repository` attribute can be overridden using the `--repository` flag.

```starlark
oci_image(
    name = "image"
)

cosign_sign(
    name = "sign",
    image = ":image",
    repository = "index.docker.io/org/image"
)
```

run `bazel run :sign -- --repository=index.docker.io/org/test`
*
nameA unique name for this target. "
imageLabel to an oci_image �

repositoryzRepository URL where the image will be signed at, e.g.: `index.docker.io/<user>/image`.
Digests and tags are not allowed.
 "3
cosign_sign$@@rules_oci//cosign/private:sign.bzl
GG,
*
nameA unique name for this target. $
"
imageLabel to an oci_image �
�

repositoryzRepository URL where the image will be signed at, e.g.: `index.docker.io/<user>/image`.
Digests and tags are not allowed.
 $Implementation details for sign ruleb
)
	rules_ocicosign/privateversions.bzl5Mirrored versions/integrity hashes of cosign binaries� 

	rules_ocicosigndefs.bzl�cosign_attest�Attest an oci_image using cosign binary at a remote registry.

```starlark
oci_image(
    name = "image"
)

cosign_attest(
    name = "attest_spdx",
    type = "spdx"
    predicate = "image.sbom.spdx.json",
    repository = "index.docker.io/org/image"
)
```

`repository` attribute can be overridden using the `--repository` flag.

```starlark
oci_image(
    name = "image"
)

cosign_attest(
    name = "attest_spdx",
    type = "spdx"
    attestment = "image.sbom.spdx.json",
    repository = "index.docker.io/org/image"
)
```

via `bazel run :attest_spdx -- --repository=index.docker.io/org/test`
"�
�
cosign_attest�Attest an oci_image using cosign binary at a remote registry.

```starlark
oci_image(
    name = "image"
)

cosign_attest(
    name = "attest_spdx",
    type = "spdx"
    predicate = "image.sbom.spdx.json",
    repository = "index.docker.io/org/image"
)
```

`repository` attribute can be overridden using the `--repository` flag.

```starlark
oci_image(
    name = "image"
)

cosign_attest(
    name = "attest_spdx",
    type = "spdx"
    attestment = "image.sbom.spdx.json",
    repository = "index.docker.io/org/image"
)
```

via `bazel run :attest_spdx -- --repository=index.docker.io/org/test`
*
nameA unique name for this target. "
imageLabel to an oci_image a
	predicatePLabel to the predicate file. Only files are allowed. eg: sbom.spdx, in-toto.json �

repositoryzRepository URL where the image will be signed at, e.g.: `index.docker.io/<user>/image`.
Digests and tags are not allowed.
 [
typeOType of predicate. Acceptable values are (slsaprovenance|link|spdx|vuln|custom) "-
cosign_attest@@rules_oci//cosign:defs.bzl
SS,
*
nameA unique name for this target. $
"
imageLabel to an oci_image c
a
	predicatePLabel to the predicate file. Only files are allowed. eg: sbom.spdx, in-toto.json �
�

repositoryzRepository URL where the image will be signed at, e.g.: `index.docker.io/<user>/image`.
Digests and tags are not allowed.
 ]
[
typeOType of predicate. Acceptable values are (slsaprovenance|link|spdx|vuln|custom) �cosign_sign�Sign an oci_image using cosign binary at a remote registry.

It signs the image by its digest determined beforehand.

```starlark
oci_image(
    name = "image"
)

cosign_sign(
    name = "sign",
    image = ":image",
    repository = "index.docker.io/org/image"
)
```

`repository` attribute can be overridden using the `--repository` flag.

```starlark
oci_image(
    name = "image"
)

cosign_sign(
    name = "sign",
    image = ":image",
    repository = "index.docker.io/org/image"
)
```

run `bazel run :sign -- --repository=index.docker.io/org/test`
"�
�
cosign_sign�Sign an oci_image using cosign binary at a remote registry.

It signs the image by its digest determined beforehand.

```starlark
oci_image(
    name = "image"
)

cosign_sign(
    name = "sign",
    image = ":image",
    repository = "index.docker.io/org/image"
)
```

`repository` attribute can be overridden using the `--repository` flag.

```starlark
oci_image(
    name = "image"
)

cosign_sign(
    name = "sign",
    image = ":image",
    repository = "index.docker.io/org/image"
)
```

run `bazel run :sign -- --repository=index.docker.io/org/test`
*
nameA unique name for this target. "
imageLabel to an oci_image �

repositoryzRepository URL where the image will be signed at, e.g.: `index.docker.io/<user>/image`.
Digests and tags are not allowed.
 "+
cosign_sign@@rules_oci//cosign:defs.bzl
GG,
*
nameA unique name for this target. $
"
imageLabel to an oci_image �
�

repositoryzRepository URL where the image will be signed at, e.g.: `index.docker.io/<user>/image`.
Digests and tags are not allowed.
 �
//cosign/private:attest.bzlrf
'
	rules_ocicosign/private
attest.bzl-
cosign_attest_cosign_attest
/=
P
//cosign/private:sign.bzlr`
%
	rules_ocicosign/privatesign.bzl)
cosign_sign_cosign_sign
-9
J
Public API�
%
	rules_ocicosignrepositories.bzl�cosign_register_toolchains�Convenience macro for users which does typical setup.

- create a repository for each built-in platform like "cosign_linux_amd64" -
  this repository is lazily fetched when node is needed for that platform.
- create a repository exposing toolchains for each platform like "oci_platforms"
- register a toolchain pointing at each platform
Users can avoid this macro and do these steps themselves, if they want more control.*�
�
cosign_register_toolchains>
name2base name for cosign repository, like "oci_cosign" (�Convenience macro for users which does typical setup.

- create a repository for each built-in platform like "cosign_linux_amd64" -
  this repository is lazily fetched when node is needed for that platform.
- create a repository exposing toolchains for each platform like "oci_platforms"
- register a toolchain pointing at each platform
Users can avoid this macro and do these steps themselves, if they want more control.2B
cosign_register_toolchains$@@rules_oci//cosign:repositories.bzl
))�	cosign_repositories0Fetch external tools needed for cosign toolchainR�	
�
cosign_repositories0Fetch external tools needed for cosign toolchain.
name"A unique name for this repository. 
cosign_version 
platform �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 *;
cosign_repositories$@@rules_oci//cosign:repositories.bzl
&&0
.
name"A unique name for this repository. 

cosign_version 

platform �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
//cosign/private:versions.bzlrk
)
	rules_ocicosign/privateversions.bzl0
COSIGN_VERSIONSCOSIGN_VERSIONS
2A
C�
!//oci/private:toolchains_repo.bzlr�
-
	rules_ocioci/privatetoolchains_repo.bzl$
	PLATFORMS	PLATFORMS
6?0
toolchains_repotoolchains_repo
CR
T�	COSIGN_BUILD_TMPL�# Generated by container/repositories.bzl
load("@rules_oci//cosign:toolchain.bzl", "cosign_toolchain")
cosign_toolchain(
    name = "cosign_toolchain", 
    cosign = "cosign"
)
j��# Generated by container/repositories.bzl
load("@rules_oci//cosign:toolchain.bzl", "cosign_toolchain")
cosign_toolchain(
    name = "cosign_toolchain", 
    cosign = "cosign"
)
$Repository rules for fetching cosign�
"
	rules_ocicosigntoolchain.bzl�cosign_toolchainwDefines a cosign toolchain.

For usage see https://docs.bazel.build/versions/main/toolchains.html#defining-toolchains.
"�
�
cosign_toolchainwDefines a cosign toolchain.

For usage see https://docs.bazel.build/versions/main/toolchains.html#defining-toolchains.
*
nameA unique name for this target. Y
cosignKA hermetically downloaded cosign executable target for the target platform. "5
cosign_toolchain!@@rules_oci//cosign:toolchain.bzl
%%,
*
nameA unique name for this target. [
Y
cosignKA hermetically downloaded cosign executable target for the target platform. �
CosignInfo6Information about how to invoke the cosign executable.2�
�

CosignInfo6Information about how to invoke the cosign executable."
binaryExecutable cosign binary"/

CosignInfo!@@rules_oci//cosign:toolchain.bzl
$
"
binaryExecutable cosign binary:This module implements the cosign-specific toolchain rule.�
#
	rules_ocioci/private	authn.bzli
//lib:base64.bzlrS
#
aspect_bazel_liblib
base64.bzl
base64base64
,2
4y
//lib:repo_utils.bzlr_
'
aspect_bazel_liblibrepo_utils.bzl&

repo_utils
repo_utils
0:
<j
//oci/private:util.bzlrN
"
	rules_ocioci/privateutil.bzl
utilutil
+/
1�	NO_CONFIG_FOUND_ERROR�Could not find the `$HOME/.docker/config.json` and `$XDG_RUNTIME_DIR/containers/auth.json` file

Running one of `podman login`, `docker login`, `crane login` may help.
j��Could not find the `$HOME/.docker/config.json` and `$XDG_RUNTIME_DIR/containers/auth.json` file

Running one of `podman login`, `docker login`, `crane login` may help.
Rrepository rule that locates the .docker/config.json or containers/auth.json file.�
&
	rules_ocioci/privatedownload.bzli
//lib:base64.bzlrS
#
aspect_bazel_liblib
base64.bzl
base64base64
,2
4m
//lib:versions.bzlrU
!
bazel_skyliblibversions.bzl"
versionsversions
*2
4j
//oci/private:util.bzlrN
"
	rules_ocioci/privateutil.bzl
utilutil
+/
1Downloader functions �A
#
	rules_ocioci/private	image.bzl�?	oci_image�Build an OCI compatible container image.

Note, most users should use the wrapper macro instead of this rule directly.
See [oci_image](#oci_image).

It takes number of tar files as layers to create image filesystem.
For incrementality, use more fine-grained tar files to build up the filesystem,
and choose an order so that less-frequently changed files appear earlier in the list.

```starlark
oci_image(
    # do not sort
    tars = [
        "rootfs.tar",
        "appfs.tar",
        "libc6.tar",
        "passwd.tar",
    ]
)
```

To base an oci_image on another oci_image, the `base` attribute can be used.

```starlark
oci_image(
    base = "//sys:base",
    tars = [
        "appfs.tar"
    ]
)
```

To combine `env` with environment variables from the `base`, bash style variable syntax can be used.

```starlark
oci_image(
    name = "base",
    env = {"PATH": "/usr/bin"}
)

oci_image(
    name = "app",
    base = ":base",
    env = {"PATH": "/usr/local/bin:$PATH"}
)
```
"�7
�
	oci_image�Build an OCI compatible container image.

Note, most users should use the wrapper macro instead of this rule directly.
See [oci_image](#oci_image).

It takes number of tar files as layers to create image filesystem.
For incrementality, use more fine-grained tar files to build up the filesystem,
and choose an order so that less-frequently changed files appear earlier in the list.

```starlark
oci_image(
    # do not sort
    tars = [
        "rootfs.tar",
        "appfs.tar",
        "libc6.tar",
        "passwd.tar",
    ]
)
```

To base an oci_image on another oci_image, the `base` attribute can be used.

```starlark
oci_image(
    base = "//sys:base",
    tars = [
        "appfs.tar"
    ]
)
```

To combine `env` with environment variables from the `base`, bash style variable syntax can be used.

```starlark
oci_image(
    name = "base",
    env = {"PATH": "/usr/bin"}
)

oci_image(
    name = "app",
    base = ":base",
    env = {"PATH": "/usr/local/bin:$PATH"}
)
```
*
nameA unique name for this target. s
annotations\A file containing a dictionary of annotations. Each line should be in the form `name=value`.2None�
architecture�The CPU architecture which the binaries in this image are built to run on. eg: `arm64`, `arm`, `amd64`, `s390x`. See $GOARCH documentation for possible values: https://go.dev/doc/install/source#environment2""@
base0Label to an oci_image target to use as the base.2None�
cmd�A file containing a comma separated list to be used as the `command & args` of the container. These values act as defaults and may be replaced by any specified when creating a container.2None�

entrypoint�A file containing a comma separated list to be used as the `entrypoint` to execute when the container starts. These values act as defaults and may be replaced by an entrypoint specified when creating a container.2None�
env�A file containing the default values for the environment variables of the container. These values act as defaults and are merged with any specified when creating a container. Entries replace the base environment variables if any of the entries has conflicting keys.
To merge entries with keys specified in the base, `${KEY}` or `$KEY` syntax may be used.
2None�
exposed_portszA file containing a comma separated list of exposed ports. (e.g. 2000/tcp, 3000/udp or 4000. No protocol defaults to tcp).2Nonei
labelsWA file containing a dictionary of labels. Each line should be in the form `name=value`.2None�
os�The name of the operating system which the image is built to run on. eg: `linux`, `windows`. See $GOOS documentation for possible values: https://go.dev/doc/install/source#environment2""�
tars�List of tar files to add to the image as layers.
Do not sort this list; the order is preserved in the resulting image.
Less-frequently changed files belong in lower layers to reduce the network bandwidth required to pull and push.

The authors recommend [dive](https://github.com/wagoodman/dive) to explore the layering of the resulting image.
2[]�
user�
The `username` or `UID` which is a platform-specific structure that allows specific control over which user the process run as.
This acts as a default value to use when the value is not specified when creating a container.
For Linux based systems, all of the following are valid: `user`, `uid`, `user:group`, `uid:gid`, `uid:group`, `user:gid`.
If `group/gid` is not specified, the default group and supplementary groups of the given `user/uid` in `/etc/passwd` from the container are applied.
2""�
variant�The variant of the specified CPU architecture. eg: `v6`, `v7`, `v8`. See: https://github.com/opencontainers/image-spec/blob/main/image-index.md#platform-variants for more.2""�
workdir�Sets the current working directory of the `entrypoint` process in the container. This value acts as a default and may be replaced by a working directory specified when creating a container.2"""/
	oci_image"@@rules_oci//oci/private:image.bzl
��,
*
nameA unique name for this target. u
s
annotations\A file containing a dictionary of annotations. Each line should be in the form `name=value`.2None�
�
architecture�The CPU architecture which the binaries in this image are built to run on. eg: `arm64`, `arm`, `amd64`, `s390x`. See $GOARCH documentation for possible values: https://go.dev/doc/install/source#environment2""B
@
base0Label to an oci_image target to use as the base.2None�
�
cmd�A file containing a comma separated list to be used as the `command & args` of the container. These values act as defaults and may be replaced by any specified when creating a container.2None�
�

entrypoint�A file containing a comma separated list to be used as the `entrypoint` to execute when the container starts. These values act as defaults and may be replaced by an entrypoint specified when creating a container.2None�
�
env�A file containing the default values for the environment variables of the container. These values act as defaults and are merged with any specified when creating a container. Entries replace the base environment variables if any of the entries has conflicting keys.
To merge entries with keys specified in the base, `${KEY}` or `$KEY` syntax may be used.
2None�
�
exposed_portszA file containing a comma separated list of exposed ports. (e.g. 2000/tcp, 3000/udp or 4000. No protocol defaults to tcp).2Nonek
i
labelsWA file containing a dictionary of labels. Each line should be in the form `name=value`.2None�
�
os�The name of the operating system which the image is built to run on. eg: `linux`, `windows`. See $GOOS documentation for possible values: https://go.dev/doc/install/source#environment2""�
�
tars�List of tar files to add to the image as layers.
Do not sort this list; the order is preserved in the resulting image.
Less-frequently changed files belong in lower layers to reduce the network bandwidth required to pull and push.

The authors recommend [dive](https://github.com/wagoodman/dive) to explore the layering of the resulting image.
2[]�
�
user�
The `username` or `UID` which is a platform-specific structure that allows specific control over which user the process run as.
This acts as a default value to use when the value is not specified when creating a container.
For Linux based systems, all of the following are valid: `user`, `uid`, `user:group`, `uid:gid`, `uid:group`, `user:gid`.
If `group/gid` is not specified, the default group and supplementary groups of the given `user/uid` in `/etc/passwd` from the container are applied.
2""�
�
variant�The variant of the specified CPU architecture. eg: `v6`, `v7`, `v8`. See: https://github.com/opencontainers/image-spec/blob/main/image-index.md#platform-variants for more.2""�
�
workdir�Sets the current working directory of the `entrypoint` process in the container. This value acts as a default and may be replaced by a working directory specified when creating a container.2""q
:features.bzlr^

bazel_featuresfeatures.bzl.
bazel_featuresbazel_features
)7
9j
//oci/private:util.bzlrN
"
	rules_ocioci/privateutil.bzl
utilutil
+/
1%Implementation details for image rule�

)
	rules_ocioci/privateimage_index.bzl�	oci_image_index�Build a multi-architecture OCI compatible container image.

It takes number of `oci_image`s  to create a fat multi-architecture image.

Requires `wc` and either `sha256sum` or `shasum` to be installed on the execution machine.

```starlark
oci_image(
    name = "app_linux_amd64"
)

oci_image(
    name = "app_linux_arm64"
)

oci_image_index(
    name = "app",
    images = [
        ":app_linux_amd64",
        ":app_linux_arm64"
    ]
)
```
"�
�
oci_image_index�Build a multi-architecture OCI compatible container image.

It takes number of `oci_image`s  to create a fat multi-architecture image.

Requires `wc` and either `sha256sum` or `shasum` to be installed on the execution machine.

```starlark
oci_image(
    name = "app_linux_amd64"
)

oci_image(
    name = "app_linux_arm64"
)

oci_image_index(
    name = "app",
    images = [
        ":app_linux_amd64",
        ":app_linux_arm64"
    ]
)
```
*
nameA unique name for this target. 2
images$List of labels to oci_image targets. ";
oci_image_index(@@rules_oci//oci/private:image_index.bzl
LL,
*
nameA unique name for this target. 4
2
images$List of labels to oci_image targets. /Implementation details for oci_image_index rule�9
"
	rules_ocioci/privatepull.bzl�	oci_aliasR�
�
	oci_alias.
name"A unique name for this repository. �
bzlmod_repositorywFor error reporting. When called from a module extension, provides the original name of the repository prior to mapping2""5
config#Label to a .docker/config.json file2Nonex
config_pathaDeprecated. Use DOCKER_CONFIG environment variable or config attribute instead. TODO(2.0): remove2None8

identifier&The digest or tag of the manifest file v
platformbIf set, the alias will simply map to that (single) image, regardless of the target platform's cpu.2None�
	platformsmIf set, the alias will map the target platform's cpu to the corresponding image, or fail if no image matches.	2{}U
registryERemote registry host to pull from, e.g. `gcr.io` or `index.docker.io` �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 K

repository9Image path beneath the registry, e.g. `distroless/static` b
reproducibleJSet to False to silence the warning about reproducibility when using `tag`2TrueM
scheme8scheme portion of the URL for fetching from the registry2"https"
target_name2"""DOCKER_CONFIG"REGISTRY_AUTH_FILE"XDG_RUNTIME_DIR"HOME*.
	oci_alias!@@rules_oci//oci/private:pull.bzl
��0
.
name"A unique name for this repository. �
�
bzlmod_repositorywFor error reporting. When called from a module extension, provides the original name of the repository prior to mapping2""7
5
config#Label to a .docker/config.json file2Nonez
x
config_pathaDeprecated. Use DOCKER_CONFIG environment variable or config attribute instead. TODO(2.0): remove2None:
8

identifier&The digest or tag of the manifest file x
v
platformbIf set, the alias will simply map to that (single) image, regardless of the target platform's cpu.2None�
�
	platformsmIf set, the alias will map the target platform's cpu to the corresponding image, or fail if no image matches.	2{}W
U
registryERemote registry host to pull from, e.g. `gcr.io` or `index.docker.io` �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 M
K

repository9Image path beneath the registry, e.g. `distroless/static` d
b
reproducibleJSet to False to silence the warning about reproducibility when using `tag`2TrueO
M
scheme8scheme portion of the URL for fetching from the registry2"https"

target_name2""�oci_pullR�
�	
oci_pull.
name"A unique name for this repository. 5
config#Label to a .docker/config.json file2Nonex
config_pathaDeprecated. Use DOCKER_CONFIG environment variable or config attribute instead. TODO(2.0): remove2None8

identifier&The digest or tag of the manifest file N
platform<A single platform in `os/arch` format, for multi-arch images2""U
registryERemote registry host to pull from, e.g. `gcr.io` or `index.docker.io` �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 K

repository9Image path beneath the registry, e.g. `distroless/static` M
scheme8scheme portion of the URL for fetching from the registry2"https"@
target_name-Name given for the image target, e.g. 'image' "DOCKER_CONFIG"REGISTRY_AUTH_FILE"XDG_RUNTIME_DIR"HOME*-
oci_pull!@@rules_oci//oci/private:pull.bzl
��0
.
name"A unique name for this repository. 7
5
config#Label to a .docker/config.json file2Nonez
x
config_pathaDeprecated. Use DOCKER_CONFIG environment variable or config attribute instead. TODO(2.0): remove2None:
8

identifier&The digest or tag of the manifest file P
N
platform<A single platform in `os/arch` format, for multi-arch images2""W
U
registryERemote registry host to pull from, e.g. `gcr.io` or `index.docker.io` �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 M
K

repository9Image path beneath the registry, e.g. `distroless/static` O
M
scheme8scheme portion of the URL for fetching from the registry2"https"B
@
target_name-Name given for the image target, e.g. 'image' a
//lib:dicts.bzlrL

bazel_skyliblib	dicts.bzl
dictsdicts
',
.m
//lib:versions.bzlrU
!
bazel_skyliblibversions.bzl"
versionsversions
*2
4n
//oci/private:authn.bzlrQ
#
	rules_ocioci/private	authn.bzl
authnauthn
,1
3j
//oci/private:util.bzlrN
"
	rules_ocioci/privateutil.bzl
utilutil
+/
1�	OCI_MEDIA_TYPE_OR_AUTHN_ERROR�Unable to retrieve the image manifest. This could be due to authentication problems or an attempt to fetch an image with OCI image media types.
See: https://github.com/bazel-contrib/rules_oci/blob/main/docs/pull.md#authentication-using-credential-helpers
j��Unable to retrieve the image manifest. This could be due to authentication problems or an attempt to fetch an image with OCI image media types.
See: https://github.com/bazel-contrib/rules_oci/blob/main/docs/pull.md#authentication-using-credential-helpers
�	$OCI_MEDIA_TYPE_OR_AUTHN_ERROR_BAZEL7UUnable to retrieve the image manifest. This could be due to authentication problems.
jWUUnable to retrieve the image manifest. This could be due to authentication problems.
�	SCHEMA1_ERROR�The registry sent a manifest with schemaVersion=1. 
This commonly occurs when fetching from a registry that needs the Docker-Distribution-API-Version header to be set.
See: https://github.com/bazel-contrib/rules_oci/blob/main/docs/pull.md#authentication-using-credential-helpers
j��The registry sent a manifest with schemaVersion=1. 
This commonly occurs when fetching from a registry that needs the Docker-Distribution-API-Version header to be set.
See: https://github.com/bazel-contrib/rules_oci/blob/main/docs/pull.md#authentication-using-credential-helpers
4Implementation details for oci_pull repository rules�4
"
	rules_ocioci/privatepush.bzl�2oci_push�Push an oci_image or oci_image_index to a remote registry.

Internal rule used by the [oci_push macro](/docs/push.md#oci_push).
Most users should use the macro.

Authorization
=============

By default, oci_push uses the standard authorization config file located on the host where `oci_push` is running.
Therefore the following documentation may be consulted:

- https://docs.docker.com/engine/reference/commandline/login/
- https://docs.podman.io/en/latest/markdown/podman-login.1.html
- https://github.com/google/go-containerregistry/blob/main/cmd/crane/doc/crane_auth_login.md

Behavior
========

Pushing and tagging are performed sequentially which MAY lead to non-atomic pushes if one the following events occur;

- Remote registry rejects a tag due to various reasons. eg: forbidden characters, existing tags
- Remote registry closes the connection during the tagging
- Local network outages

In order to avoid incomplete pushes oci_push will push the image by its digest and then apply the `remote_tags` sequentially at
the remote registry.

Any failure during pushing or tagging will be reported with non-zero exit code and cause remaining steps to be skipped.

Usage
=====

When running the pusher, you can pass flags to `bazel run`.

1. Override `repository` by passing the `-r|--repository` flag.

e.g. `bazel run //myimage:push -- --repository index.docker.io/<ORG>/image`

2. Supply tags in addition to `remote_tags` by passing the `-t|--tag` flag.

e.g. `bazel run //myimage:push -- --tag latest`

Examples
========

Push an oci_image to docker registry with 'latest' tag

```starlark
oci_image(name = "image")

oci_push(
    name = "push",
    image = ":image",
    repository = "index.docker.io/<ORG>/image",
    remote_tags = ["latest"]
)
```

Push a multi-architecture image to github container registry with a semver tag

```starlark
load("@aspect_bazel_lib//lib:expand_template.bzl", "expand_template_rule")

oci_image(name = "app_linux_arm64")

oci_image(name = "app_linux_amd64")

oci_image(name = "app_windows_amd64")

oci_image_index(
    name = "app_image",
    images = [
        ":app_linux_arm64",
        ":app_linux_amd64",
        ":app_windows_amd64",
    ]
)

# Use the value of --embed_label under --stamp, otherwise use a deterministic constant
# value to ensure cache hits for actions that depend on this.
expand_template(
    name = "stamped",
    out = "_stamped.tags.txt",
    template = ["0.0.0"],
    stamp_substitutions = {"0.0.0": "{{BUILD_EMBED_LABEL}}"},
)

oci_push(
    name = "push",
    image = ":app_image",
    repository = "ghcr.io/<OWNER>/image",
    remote_tags = ":stamped",
)
```
"�
�
oci_push�Push an oci_image or oci_image_index to a remote registry.

Internal rule used by the [oci_push macro](/docs/push.md#oci_push).
Most users should use the macro.

Authorization
=============

By default, oci_push uses the standard authorization config file located on the host where `oci_push` is running.
Therefore the following documentation may be consulted:

- https://docs.docker.com/engine/reference/commandline/login/
- https://docs.podman.io/en/latest/markdown/podman-login.1.html
- https://github.com/google/go-containerregistry/blob/main/cmd/crane/doc/crane_auth_login.md

Behavior
========

Pushing and tagging are performed sequentially which MAY lead to non-atomic pushes if one the following events occur;

- Remote registry rejects a tag due to various reasons. eg: forbidden characters, existing tags
- Remote registry closes the connection during the tagging
- Local network outages

In order to avoid incomplete pushes oci_push will push the image by its digest and then apply the `remote_tags` sequentially at
the remote registry.

Any failure during pushing or tagging will be reported with non-zero exit code and cause remaining steps to be skipped.

Usage
=====

When running the pusher, you can pass flags to `bazel run`.

1. Override `repository` by passing the `-r|--repository` flag.

e.g. `bazel run //myimage:push -- --repository index.docker.io/<ORG>/image`

2. Supply tags in addition to `remote_tags` by passing the `-t|--tag` flag.

e.g. `bazel run //myimage:push -- --tag latest`

Examples
========

Push an oci_image to docker registry with 'latest' tag

```starlark
oci_image(name = "image")

oci_push(
    name = "push",
    image = ":image",
    repository = "index.docker.io/<ORG>/image",
    remote_tags = ["latest"]
)
```

Push a multi-architecture image to github container registry with a semver tag

```starlark
load("@aspect_bazel_lib//lib:expand_template.bzl", "expand_template_rule")

oci_image(name = "app_linux_arm64")

oci_image(name = "app_linux_amd64")

oci_image(name = "app_windows_amd64")

oci_image_index(
    name = "app_image",
    images = [
        ":app_linux_arm64",
        ":app_linux_amd64",
        ":app_windows_amd64",
    ]
)

# Use the value of --embed_label under --stamp, otherwise use a deterministic constant
# value to ensure cache hits for actions that depend on this.
expand_template(
    name = "stamped",
    out = "_stamped.tags.txt",
    template = ["0.0.0"],
    stamp_substitutions = {"0.0.0": "{{BUILD_EMBED_LABEL}}"},
)

oci_push(
    name = "push",
    image = ":app_image",
    repository = "ghcr.io/<OWNER>/image",
    remote_tags = ":stamped",
)
```
*
nameA unique name for this target. 5
image(Label to an oci_image or oci_image_index �
remote_tags�a .txt file containing tags, one per line.
These are passed to [`crane tag`](
https://github.com/google/go-containerregistry/blob/main/cmd/crane/doc/crane_tag.md)
2None�

repositoryzRepository URL where the image will be signed at, e.g.: `index.docker.io/<user>/image`.
Digests and tags are not allowed.
2""�
repository_fileiThe same as 'repository' but in a file. This allows pushing to different repositories based on stamping.
2None"-
oci_push!@@rules_oci//oci/private:push.bzl
��,
*
nameA unique name for this target. 7
5
image(Label to an oci_image or oci_image_index �
�
remote_tags�a .txt file containing tags, one per line.
These are passed to [`crane tag`](
https://github.com/google/go-containerregistry/blob/main/cmd/crane/doc/crane_tag.md)
2None�
�

repositoryzRepository URL where the image will be signed at, e.g.: `index.docker.io/<user>/image`.
Digests and tags are not allowed.
2""�
�
repository_fileiThe same as 'repository' but in a file. This allows pushing to different repositories based on stamping.
2Nonej
//oci/private:util.bzlrN
"
	rules_ocioci/privateutil.bzl
utilutil
+/
1(Implementation details for the push rule�0
%
	rules_ocioci/privatetarball.bzl�oci_tarball�Creates tarball from OCI layouts that can be loaded into docker daemon without needing to publish the image first.

Passing anything other than oci_image to the image attribute will lead to build time errors.

### Outputs

The default output is an mtree specification file.
This is because producing the tarball in `bazel build` is expensive, and should typically not be an input to any other build actions,
so producing it only creates unnecessary load on the action cache.

If needed, the `tarball` output group allows you to depend on the tar output from another rule.

On the command line, `bazel build //path/to:my_tarball --output_groups=tarball`

or in a BUILD file:

```starlark
oci_tarball(
    name = "my_tarball",
    ...
)
filegroup(
    name = "my_tarball.tar",
    srcs = [":my_tarball"],
    output_group = "tarball",
)
```
"�
�
oci_tarball�Creates tarball from OCI layouts that can be loaded into docker daemon without needing to publish the image first.

Passing anything other than oci_image to the image attribute will lead to build time errors.

### Outputs

The default output is an mtree specification file.
This is because producing the tarball in `bazel build` is expensive, and should typically not be an input to any other build actions,
so producing it only creates unnecessary load on the action cache.

If needed, the `tarball` output group allows you to depend on the tar output from another rule.

On the command line, `bazel build //path/to:my_tarball --output_groups=tarball`

or in a BUILD file:

```starlark
oci_tarball(
    name = "my_tarball",
    ...
)
filegroup(
    name = "my_tarball.tar",
    srcs = [":my_tarball"],
    output_group = "tarball",
)
```
*
nameA unique name for this target. �
format�Format of image to generate. Options are: docker, oci. Currently, when the input image is an image_index, only oci is supported, and when the input image is an image, only docker is supported. Conversions between formats may be supported in the future.2"docker"Q
imageDLabel of a directory containing an OCI layout, typically `oci_image` �
loader�Alternative target for a container cli tool that will be
used to load the image into the local engine when using `bazel run` on this oci_tarball.

By default, we look for `docker` or `podman` on the PATH, and run the `load` command.

> Note that rules_docker has an "incremental loader" which is faster than oci_tarball by design.
> Something similar can be done for oci_tarball. 
> See [loader.sh](/examples/incremental_loader/loader.sh) and explanation about [how](/examples/incremental_loader/README.md) it works.

See the _run_template attribute for the script that calls this loader tool.
2None<
	repo_tags+a file containing repo_tags, one per line.
 "3
oci_tarball$@@rules_oci//oci/private:tarball.bzl
��,
*
nameA unique name for this target. �
�
format�Format of image to generate. Options are: docker, oci. Currently, when the input image is an image_index, only oci is supported, and when the input image is an image, only docker is supported. Conversions between formats may be supported in the future.2"docker"S
Q
imageDLabel of a directory containing an OCI layout, typically `oci_image` �
�
loader�Alternative target for a container cli tool that will be
used to load the image into the local engine when using `bazel run` on this oci_tarball.

By default, we look for `docker` or `podman` on the PATH, and run the `load` command.

> Note that rules_docker has an "incremental loader" which is faster than oci_tarball by design.
> Something similar can be done for oci_tarball. 
> See [loader.sh](/examples/incremental_loader/loader.sh) and explanation about [how](/examples/incremental_loader/README.md) it works.

See the _run_template attribute for the script that calls this loader tool.
2None>
<
	repo_tags+a file containing repo_tags, one per line.
 j
//oci/private:util.bzlrN
"
	rules_ocioci/privateutil.bzl
utilutil
+/
1�	doc�Creates tarball from OCI layouts that can be loaded into docker daemon without needing to publish the image first.

Passing anything other than oci_image to the image attribute will lead to build time errors.

### Outputs

The default output is an mtree specification file.
This is because producing the tarball in `bazel build` is expensive, and should typically not be an input to any other build actions,
so producing it only creates unnecessary load on the action cache.

If needed, the `tarball` output group allows you to depend on the tar output from another rule.

On the command line, `bazel build //path/to:my_tarball --output_groups=tarball`

or in a BUILD file:

```starlark
oci_tarball(
    name = "my_tarball",
    ...
)
filegroup(
    name = "my_tarball.tar",
    srcs = [":my_tarball"],
    output_group = "tarball",
)
```
j��Creates tarball from OCI layouts that can be loaded into docker daemon without needing to publish the image first.

Passing anything other than oci_image to the image attribute will lead to build time errors.

### Outputs

The default output is an mtree specification file.
This is because producing the tarball in `bazel build` is expensive, and should typically not be an input to any other build actions,
so producing it only creates unnecessary load on the action cache.

If needed, the `tarball` output group allows you to depend on the tar output from another rule.

On the command line, `bazel build //path/to:my_tarball --output_groups=tarball`

or in a BUILD file:

```starlark
oci_tarball(
    name = "my_tarball",
    ...
)
filegroup(
    name = "my_tarball.tar",
    srcs = [":my_tarball"],
    output_group = "tarball",
)
```
�Create a tarball from oci_image that can be loaded by runtimes such as podman and docker.
Intended for use with `bazel run`.

For example, given an `:image` target, you could write

```
oci_tarball(
    name = "tarball",
    image = ":image",
    repo_tags = ["my-repository:latest"],
)
```

and then run it in a container like so:

```
bazel run :tarball
docker run --rm my-repository:latest
```
�'
-
	rules_ocioci/privatetoolchains_repo.bzl�toolchains_repolCreates a repository with toolchain definitions for all known platforms which can be registered or selected.R�
�
toolchains_repolCreates a repository with toolchain definitions for all known platforms which can be registered or selected..
name"A unique name for this repository. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
	toolchainrLabel of the toolchain with {platform} left as placeholder. example; @container_crane_{platform}//:crane_toolchain2""X
toolchain_type@Label of the toolchain_type. example; //oci:crane_toolchain_type2""*?
toolchains_repo,@@rules_oci//oci/private:toolchains_repo.bzl
�"�"0
.
name"A unique name for this repository. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
�
	toolchainrLabel of the toolchain with {platform} left as placeholder. example; @container_crane_{platform}//:crane_toolchain2""Z
X
toolchain_type@Label of the toolchain_type. example; //oci:crane_toolchain_type2""�	TOOLCHAIN_TMPL�toolchain(
    name = "{platform}_toolchain",
    exec_compatible_with = {compatible_with},
    toolchain = "{toolchain}",
    toolchain_type = "{toolchain_type}",
)
j��toolchain(
    name = "{platform}_toolchain",
    exec_compatible_with = {compatible_with},
    toolchain = "{toolchain}",
    toolchain_type = "{toolchain_type}",
)
�	BUILD_HEADER_TMPL�# Generated by toolchains_repo.bzl
#
# These can be registered in the workspace file or passed to --extra_toolchains flag.
# By default all of these toolchains are registered by the oci_register_toolchains macro
# so you don't normally need to interact with these targets.

load(":defs.bzl", "resolved_toolchain")

resolved_toolchain(name = "current_toolchain", visibility = ["//visibility:public"])
j��# Generated by toolchains_repo.bzl
#
# These can be registered in the workspace file or passed to --extra_toolchains flag.
# By default all of these toolchains are registered by the oci_register_toolchains macro
# so you don't normally need to interact with these targets.

load(":defs.bzl", "resolved_toolchain")

resolved_toolchain(name = "current_toolchain", visibility = ["//visibility:public"])
�		DEFS_TMPL�# Generated by toolchains_repo.bzl for {toolchain_type}
load("@bazel_skylib//lib:structs.bzl", "structs")

# Forward all the providers
def _resolved_toolchain_impl(ctx):
    toolchain_info = ctx.toolchains["{toolchain_type}"]
    return [toolchain_info] + structs.to_dict(toolchain_info).values()

# Copied from java_toolchain_alias
# https://cs.opensource.google/bazel/bazel/+/master:tools/jdk/java_toolchain_alias.bzl
resolved_toolchain = rule(
    implementation = _resolved_toolchain_impl,
    toolchains = ["{toolchain_type}"],
)
j��# Generated by toolchains_repo.bzl for {toolchain_type}
load("@bazel_skylib//lib:structs.bzl", "structs")

# Forward all the providers
def _resolved_toolchain_impl(ctx):
    toolchain_info = ctx.toolchains["{toolchain_type}"]
    return [toolchain_info] + structs.to_dict(toolchain_info).values()

# Copied from java_toolchain_alias
# https://cs.opensource.google/bazel/bazel/+/master:tools/jdk/java_toolchain_alias.bzl
resolved_toolchain = rule(
    implementation = _resolved_toolchain_impl,
    toolchains = ["{toolchain_type}"],
)
�Create a repository to hold the toolchains

This follows guidance here:
https://docs.bazel.build/versions/main/skylark/deploying.html#registering-toolchains
"
Note that in order to resolve toolchains in the analysis phase
Bazel needs to analyze all toolchain targets that are registered.
Bazel will not need to analyze all targets referenced by toolchain.toolchain attribute.
If in order to register toolchains you need to perform complex computation in the repository,
consider splitting the repository with toolchain targets
from the repository with <LANG>_toolchain targets.
Former will be always fetched,
and the latter will only be fetched when user actually needs to build <LANG> code.
"
The "complex computation" in our case is simply downloading large artifacts.
This guidance tells us how to avoid that: we put the toolchain targets in the alias repository
with only the toolchain attribute pointing into the platform-specific repositories.
�
"
	rules_ocioci/privateutil.bzla
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.m
//lib:versions.bzlrU
!
bazel_skyliblibversions.bzl"
versionsversions
*2
4	Utilities@
&
	rules_ocioci/privateversions.bzlMirror of release info��

	rules_ociocidefs.bzl�	oci_image_index�Build a multi-architecture OCI compatible container image.

It takes number of `oci_image`s  to create a fat multi-architecture image.

Requires `wc` and either `sha256sum` or `shasum` to be installed on the execution machine.

```starlark
oci_image(
    name = "app_linux_amd64"
)

oci_image(
    name = "app_linux_arm64"
)

oci_image_index(
    name = "app",
    images = [
        ":app_linux_amd64",
        ":app_linux_arm64"
    ]
)
```
"�
�
oci_image_index�Build a multi-architecture OCI compatible container image.

It takes number of `oci_image`s  to create a fat multi-architecture image.

Requires `wc` and either `sha256sum` or `shasum` to be installed on the execution machine.

```starlark
oci_image(
    name = "app_linux_amd64"
)

oci_image(
    name = "app_linux_arm64"
)

oci_image_index(
    name = "app",
    images = [
        ":app_linux_amd64",
        ":app_linux_arm64"
    ]
)
```
*
nameA unique name for this target. 2
images$List of labels to oci_image targets. ",
oci_image_index@@rules_oci//oci:defs.bzl
LL,
*
nameA unique name for this target. 4
2
images$List of labels to oci_image targets. �?oci_image_rule�Build an OCI compatible container image.

Note, most users should use the wrapper macro instead of this rule directly.
See [oci_image](#oci_image).

It takes number of tar files as layers to create image filesystem.
For incrementality, use more fine-grained tar files to build up the filesystem,
and choose an order so that less-frequently changed files appear earlier in the list.

```starlark
oci_image(
    # do not sort
    tars = [
        "rootfs.tar",
        "appfs.tar",
        "libc6.tar",
        "passwd.tar",
    ]
)
```

To base an oci_image on another oci_image, the `base` attribute can be used.

```starlark
oci_image(
    base = "//sys:base",
    tars = [
        "appfs.tar"
    ]
)
```

To combine `env` with environment variables from the `base`, bash style variable syntax can be used.

```starlark
oci_image(
    name = "base",
    env = {"PATH": "/usr/bin"}
)

oci_image(
    name = "app",
    base = ":base",
    env = {"PATH": "/usr/local/bin:$PATH"}
)
```
"�7
�
oci_image_rule�Build an OCI compatible container image.

Note, most users should use the wrapper macro instead of this rule directly.
See [oci_image](#oci_image).

It takes number of tar files as layers to create image filesystem.
For incrementality, use more fine-grained tar files to build up the filesystem,
and choose an order so that less-frequently changed files appear earlier in the list.

```starlark
oci_image(
    # do not sort
    tars = [
        "rootfs.tar",
        "appfs.tar",
        "libc6.tar",
        "passwd.tar",
    ]
)
```

To base an oci_image on another oci_image, the `base` attribute can be used.

```starlark
oci_image(
    base = "//sys:base",
    tars = [
        "appfs.tar"
    ]
)
```

To combine `env` with environment variables from the `base`, bash style variable syntax can be used.

```starlark
oci_image(
    name = "base",
    env = {"PATH": "/usr/bin"}
)

oci_image(
    name = "app",
    base = ":base",
    env = {"PATH": "/usr/local/bin:$PATH"}
)
```
*
nameA unique name for this target. s
annotations\A file containing a dictionary of annotations. Each line should be in the form `name=value`.2None�
architecture�The CPU architecture which the binaries in this image are built to run on. eg: `arm64`, `arm`, `amd64`, `s390x`. See $GOARCH documentation for possible values: https://go.dev/doc/install/source#environment2""@
base0Label to an oci_image target to use as the base.2None�
cmd�A file containing a comma separated list to be used as the `command & args` of the container. These values act as defaults and may be replaced by any specified when creating a container.2None�

entrypoint�A file containing a comma separated list to be used as the `entrypoint` to execute when the container starts. These values act as defaults and may be replaced by an entrypoint specified when creating a container.2None�
env�A file containing the default values for the environment variables of the container. These values act as defaults and are merged with any specified when creating a container. Entries replace the base environment variables if any of the entries has conflicting keys.
To merge entries with keys specified in the base, `${KEY}` or `$KEY` syntax may be used.
2None�
exposed_portszA file containing a comma separated list of exposed ports. (e.g. 2000/tcp, 3000/udp or 4000. No protocol defaults to tcp).2Nonei
labelsWA file containing a dictionary of labels. Each line should be in the form `name=value`.2None�
os�The name of the operating system which the image is built to run on. eg: `linux`, `windows`. See $GOOS documentation for possible values: https://go.dev/doc/install/source#environment2""�
tars�List of tar files to add to the image as layers.
Do not sort this list; the order is preserved in the resulting image.
Less-frequently changed files belong in lower layers to reduce the network bandwidth required to pull and push.

The authors recommend [dive](https://github.com/wagoodman/dive) to explore the layering of the resulting image.
2[]�
user�
The `username` or `UID` which is a platform-specific structure that allows specific control over which user the process run as.
This acts as a default value to use when the value is not specified when creating a container.
For Linux based systems, all of the following are valid: `user`, `uid`, `user:group`, `uid:gid`, `uid:group`, `user:gid`.
If `group/gid` is not specified, the default group and supplementary groups of the given `user/uid` in `/etc/passwd` from the container are applied.
2""�
variant�The variant of the specified CPU architecture. eg: `v6`, `v7`, `v8`. See: https://github.com/opencontainers/image-spec/blob/main/image-index.md#platform-variants for more.2""�
workdir�Sets the current working directory of the `entrypoint` process in the container. This value acts as a default and may be replaced by a working directory specified when creating a container.2"""+
oci_image_rule@@rules_oci//oci:defs.bzl
��,
*
nameA unique name for this target. u
s
annotations\A file containing a dictionary of annotations. Each line should be in the form `name=value`.2None�
�
architecture�The CPU architecture which the binaries in this image are built to run on. eg: `arm64`, `arm`, `amd64`, `s390x`. See $GOARCH documentation for possible values: https://go.dev/doc/install/source#environment2""B
@
base0Label to an oci_image target to use as the base.2None�
�
cmd�A file containing a comma separated list to be used as the `command & args` of the container. These values act as defaults and may be replaced by any specified when creating a container.2None�
�

entrypoint�A file containing a comma separated list to be used as the `entrypoint` to execute when the container starts. These values act as defaults and may be replaced by an entrypoint specified when creating a container.2None�
�
env�A file containing the default values for the environment variables of the container. These values act as defaults and are merged with any specified when creating a container. Entries replace the base environment variables if any of the entries has conflicting keys.
To merge entries with keys specified in the base, `${KEY}` or `$KEY` syntax may be used.
2None�
�
exposed_portszA file containing a comma separated list of exposed ports. (e.g. 2000/tcp, 3000/udp or 4000. No protocol defaults to tcp).2Nonek
i
labelsWA file containing a dictionary of labels. Each line should be in the form `name=value`.2None�
�
os�The name of the operating system which the image is built to run on. eg: `linux`, `windows`. See $GOOS documentation for possible values: https://go.dev/doc/install/source#environment2""�
�
tars�List of tar files to add to the image as layers.
Do not sort this list; the order is preserved in the resulting image.
Less-frequently changed files belong in lower layers to reduce the network bandwidth required to pull and push.

The authors recommend [dive](https://github.com/wagoodman/dive) to explore the layering of the resulting image.
2[]�
�
user�
The `username` or `UID` which is a platform-specific structure that allows specific control over which user the process run as.
This acts as a default value to use when the value is not specified when creating a container.
For Linux based systems, all of the following are valid: `user`, `uid`, `user:group`, `uid:gid`, `uid:group`, `user:gid`.
If `group/gid` is not specified, the default group and supplementary groups of the given `user/uid` in `/etc/passwd` from the container are applied.
2""�
�
variant�The variant of the specified CPU architecture. eg: `v6`, `v7`, `v8`. See: https://github.com/opencontainers/image-spec/blob/main/image-index.md#platform-variants for more.2""�
�
workdir�Sets the current working directory of the `entrypoint` process in the container. This value acts as a default and may be replaced by a working directory specified when creating a container.2""�3oci_push_rule�Push an oci_image or oci_image_index to a remote registry.

Internal rule used by the [oci_push macro](/docs/push.md#oci_push).
Most users should use the macro.

Authorization
=============

By default, oci_push uses the standard authorization config file located on the host where `oci_push` is running.
Therefore the following documentation may be consulted:

- https://docs.docker.com/engine/reference/commandline/login/
- https://docs.podman.io/en/latest/markdown/podman-login.1.html
- https://github.com/google/go-containerregistry/blob/main/cmd/crane/doc/crane_auth_login.md

Behavior
========

Pushing and tagging are performed sequentially which MAY lead to non-atomic pushes if one the following events occur;

- Remote registry rejects a tag due to various reasons. eg: forbidden characters, existing tags
- Remote registry closes the connection during the tagging
- Local network outages

In order to avoid incomplete pushes oci_push will push the image by its digest and then apply the `remote_tags` sequentially at
the remote registry.

Any failure during pushing or tagging will be reported with non-zero exit code and cause remaining steps to be skipped.

Usage
=====

When running the pusher, you can pass flags to `bazel run`.

1. Override `repository` by passing the `-r|--repository` flag.

e.g. `bazel run //myimage:push -- --repository index.docker.io/<ORG>/image`

2. Supply tags in addition to `remote_tags` by passing the `-t|--tag` flag.

e.g. `bazel run //myimage:push -- --tag latest`

Examples
========

Push an oci_image to docker registry with 'latest' tag

```starlark
oci_image(name = "image")

oci_push(
    name = "push",
    image = ":image",
    repository = "index.docker.io/<ORG>/image",
    remote_tags = ["latest"]
)
```

Push a multi-architecture image to github container registry with a semver tag

```starlark
load("@aspect_bazel_lib//lib:expand_template.bzl", "expand_template_rule")

oci_image(name = "app_linux_arm64")

oci_image(name = "app_linux_amd64")

oci_image(name = "app_windows_amd64")

oci_image_index(
    name = "app_image",
    images = [
        ":app_linux_arm64",
        ":app_linux_amd64",
        ":app_windows_amd64",
    ]
)

# Use the value of --embed_label under --stamp, otherwise use a deterministic constant
# value to ensure cache hits for actions that depend on this.
expand_template(
    name = "stamped",
    out = "_stamped.tags.txt",
    template = ["0.0.0"],
    stamp_substitutions = {"0.0.0": "{{BUILD_EMBED_LABEL}}"},
)

oci_push(
    name = "push",
    image = ":app_image",
    repository = "ghcr.io/<OWNER>/image",
    remote_tags = ":stamped",
)
```
"�
�
oci_push_rule�Push an oci_image or oci_image_index to a remote registry.

Internal rule used by the [oci_push macro](/docs/push.md#oci_push).
Most users should use the macro.

Authorization
=============

By default, oci_push uses the standard authorization config file located on the host where `oci_push` is running.
Therefore the following documentation may be consulted:

- https://docs.docker.com/engine/reference/commandline/login/
- https://docs.podman.io/en/latest/markdown/podman-login.1.html
- https://github.com/google/go-containerregistry/blob/main/cmd/crane/doc/crane_auth_login.md

Behavior
========

Pushing and tagging are performed sequentially which MAY lead to non-atomic pushes if one the following events occur;

- Remote registry rejects a tag due to various reasons. eg: forbidden characters, existing tags
- Remote registry closes the connection during the tagging
- Local network outages

In order to avoid incomplete pushes oci_push will push the image by its digest and then apply the `remote_tags` sequentially at
the remote registry.

Any failure during pushing or tagging will be reported with non-zero exit code and cause remaining steps to be skipped.

Usage
=====

When running the pusher, you can pass flags to `bazel run`.

1. Override `repository` by passing the `-r|--repository` flag.

e.g. `bazel run //myimage:push -- --repository index.docker.io/<ORG>/image`

2. Supply tags in addition to `remote_tags` by passing the `-t|--tag` flag.

e.g. `bazel run //myimage:push -- --tag latest`

Examples
========

Push an oci_image to docker registry with 'latest' tag

```starlark
oci_image(name = "image")

oci_push(
    name = "push",
    image = ":image",
    repository = "index.docker.io/<ORG>/image",
    remote_tags = ["latest"]
)
```

Push a multi-architecture image to github container registry with a semver tag

```starlark
load("@aspect_bazel_lib//lib:expand_template.bzl", "expand_template_rule")

oci_image(name = "app_linux_arm64")

oci_image(name = "app_linux_amd64")

oci_image(name = "app_windows_amd64")

oci_image_index(
    name = "app_image",
    images = [
        ":app_linux_arm64",
        ":app_linux_amd64",
        ":app_windows_amd64",
    ]
)

# Use the value of --embed_label under --stamp, otherwise use a deterministic constant
# value to ensure cache hits for actions that depend on this.
expand_template(
    name = "stamped",
    out = "_stamped.tags.txt",
    template = ["0.0.0"],
    stamp_substitutions = {"0.0.0": "{{BUILD_EMBED_LABEL}}"},
)

oci_push(
    name = "push",
    image = ":app_image",
    repository = "ghcr.io/<OWNER>/image",
    remote_tags = ":stamped",
)
```
*
nameA unique name for this target. 5
image(Label to an oci_image or oci_image_index �
remote_tags�a .txt file containing tags, one per line.
These are passed to [`crane tag`](
https://github.com/google/go-containerregistry/blob/main/cmd/crane/doc/crane_tag.md)
2None�

repositoryzRepository URL where the image will be signed at, e.g.: `index.docker.io/<user>/image`.
Digests and tags are not allowed.
2""�
repository_fileiThe same as 'repository' but in a file. This allows pushing to different repositories based on stamping.
2None"*
oci_push_rule@@rules_oci//oci:defs.bzl
��,
*
nameA unique name for this target. 7
5
image(Label to an oci_image or oci_image_index �
�
remote_tags�a .txt file containing tags, one per line.
These are passed to [`crane tag`](
https://github.com/google/go-containerregistry/blob/main/cmd/crane/doc/crane_tag.md)
2None�
�

repositoryzRepository URL where the image will be signed at, e.g.: `index.docker.io/<user>/image`.
Digests and tags are not allowed.
2""�
�
repository_fileiThe same as 'repository' but in a file. This allows pushing to different repositories based on stamping.
2None�oci_tarball_rule�Creates tarball from OCI layouts that can be loaded into docker daemon without needing to publish the image first.

Passing anything other than oci_image to the image attribute will lead to build time errors.

### Outputs

The default output is an mtree specification file.
This is because producing the tarball in `bazel build` is expensive, and should typically not be an input to any other build actions,
so producing it only creates unnecessary load on the action cache.

If needed, the `tarball` output group allows you to depend on the tar output from another rule.

On the command line, `bazel build //path/to:my_tarball --output_groups=tarball`

or in a BUILD file:

```starlark
oci_tarball(
    name = "my_tarball",
    ...
)
filegroup(
    name = "my_tarball.tar",
    srcs = [":my_tarball"],
    output_group = "tarball",
)
```
"�
�
oci_tarball_rule�Creates tarball from OCI layouts that can be loaded into docker daemon without needing to publish the image first.

Passing anything other than oci_image to the image attribute will lead to build time errors.

### Outputs

The default output is an mtree specification file.
This is because producing the tarball in `bazel build` is expensive, and should typically not be an input to any other build actions,
so producing it only creates unnecessary load on the action cache.

If needed, the `tarball` output group allows you to depend on the tar output from another rule.

On the command line, `bazel build //path/to:my_tarball --output_groups=tarball`

or in a BUILD file:

```starlark
oci_tarball(
    name = "my_tarball",
    ...
)
filegroup(
    name = "my_tarball.tar",
    srcs = [":my_tarball"],
    output_group = "tarball",
)
```
*
nameA unique name for this target. �
format�Format of image to generate. Options are: docker, oci. Currently, when the input image is an image_index, only oci is supported, and when the input image is an image, only docker is supported. Conversions between formats may be supported in the future.2"docker"Q
imageDLabel of a directory containing an OCI layout, typically `oci_image` �
loader�Alternative target for a container cli tool that will be
used to load the image into the local engine when using `bazel run` on this oci_tarball.

By default, we look for `docker` or `podman` on the PATH, and run the `load` command.

> Note that rules_docker has an "incremental loader" which is faster than oci_tarball by design.
> Something similar can be done for oci_tarball. 
> See [loader.sh](/examples/incremental_loader/loader.sh) and explanation about [how](/examples/incremental_loader/README.md) it works.

See the _run_template attribute for the script that calls this loader tool.
2None<
	repo_tags+a file containing repo_tags, one per line.
 "-
oci_tarball_rule@@rules_oci//oci:defs.bzl
��,
*
nameA unique name for this target. �
�
format�Format of image to generate. Options are: docker, oci. Currently, when the input image is an image_index, only oci is supported, and when the input image is an image, only docker is supported. Conversions between formats may be supported in the future.2"docker"S
Q
imageDLabel of a directory containing an OCI layout, typically `oci_image` �
�
loader�Alternative target for a container cli tool that will be
used to load the image into the local engine when using `bazel run` on this oci_tarball.

By default, we look for `docker` or `podman` on the PATH, and run the `load` command.

> Note that rules_docker has an "incremental loader" which is faster than oci_tarball by design.
> Something similar can be done for oci_tarball. 
> See [loader.sh](/examples/incremental_loader/loader.sh) and explanation about [how](/examples/incremental_loader/README.md) it works.

See the _run_template attribute for the script that calls this loader tool.
2None>
<
	repo_tags+a file containing repo_tags, one per line.
 �L	oci_image�Macro wrapper around [oci_image_rule](#oci_image_rule).

Allows labels and annotations to be provided as a dictionary, in addition to a text file.
See https://github.com/opencontainers/image-spec/blob/main/annotations.md

Label/annotation/env can by configured using either dict(key->value) or a file that contains key=value pairs
(one per line). The file can be preprocessed using (e.g. using `jq`) to supply external (potentially not
deterministic) information when running with `--stamp` flag.  See the example in
[/examples/labels/BUILD.bazel](https://github.com/bazel-contrib/rules_oci/blob/main/examples/labels/BUILD.bazel).

Produces a target `[name].digest`, whose default output is a file containing the sha256 digest of the resulting image.
This is similar to the same-named target created by rules_docker's `container_image` macro.


Build an OCI compatible container image.

Note, most users should use the wrapper macro instead of this rule directly.
See [oci_image](#oci_image).

It takes number of tar files as layers to create image filesystem.
For incrementality, use more fine-grained tar files to build up the filesystem,
and choose an order so that less-frequently changed files appear earlier in the list.

```starlark
oci_image(
    # do not sort
    tars = [
        "rootfs.tar",
        "appfs.tar",
        "libc6.tar",
        "passwd.tar",
    ]
)
```

To base an oci_image on another oci_image, the `base` attribute can be used.

```starlark
oci_image(
    base = "//sys:base",
    tars = [
        "appfs.tar"
    ]
)
```

To combine `env` with environment variables from the `base`, bash style variable syntax can be used.

```starlark
oci_image(
    name = "base",
    env = {"PATH": "/usr/bin"}
)

oci_image(
    name = "app",
    base = ":base",
    env = {"PATH": "/usr/local/bin:$PATH"}
)
```
"�>
�&
	oci_image�Macro wrapper around [oci_image_rule](#oci_image_rule).

Allows labels and annotations to be provided as a dictionary, in addition to a text file.
See https://github.com/opencontainers/image-spec/blob/main/annotations.md

Label/annotation/env can by configured using either dict(key->value) or a file that contains key=value pairs
(one per line). The file can be preprocessed using (e.g. using `jq`) to supply external (potentially not
deterministic) information when running with `--stamp` flag.  See the example in
[/examples/labels/BUILD.bazel](https://github.com/bazel-contrib/rules_oci/blob/main/examples/labels/BUILD.bazel).

Produces a target `[name].digest`, whose default output is a file containing the sha256 digest of the resulting image.
This is similar to the same-named target created by rules_docker's `container_image` macro.


Build an OCI compatible container image.

Note, most users should use the wrapper macro instead of this rule directly.
See [oci_image](#oci_image).

It takes number of tar files as layers to create image filesystem.
For incrementality, use more fine-grained tar files to build up the filesystem,
and choose an order so that less-frequently changed files appear earlier in the list.

```starlark
oci_image(
    # do not sort
    tars = [
        "rootfs.tar",
        "appfs.tar",
        "libc6.tar",
        "passwd.tar",
    ]
)
```

To base an oci_image on another oci_image, the `base` attribute can be used.

```starlark
oci_image(
    base = "//sys:base",
    tars = [
        "appfs.tar"
    ]
)
```

To combine `env` with environment variables from the `base`, bash style variable syntax can be used.

```starlark
oci_image(
    name = "base",
    env = {"PATH": "/usr/bin"}
)

oci_image(
    name = "app",
    base = ":base",
    env = {"PATH": "/usr/local/bin:$PATH"}
)
```
*
nameA unique name for this target. s
annotations\A file containing a dictionary of annotations. Each line should be in the form `name=value`.2None�
architecture�The CPU architecture which the binaries in this image are built to run on. eg: `arm64`, `arm`, `amd64`, `s390x`. See $GOARCH documentation for possible values: https://go.dev/doc/install/source#environment2""@
base0Label to an oci_image target to use as the base.2None�
cmd�A file containing a comma separated list to be used as the `command & args` of the container. These values act as defaults and may be replaced by any specified when creating a container.2None�

entrypoint�A file containing a comma separated list to be used as the `entrypoint` to execute when the container starts. These values act as defaults and may be replaced by an entrypoint specified when creating a container.2None�
env�A file containing the default values for the environment variables of the container. These values act as defaults and are merged with any specified when creating a container. Entries replace the base environment variables if any of the entries has conflicting keys.
To merge entries with keys specified in the base, `${KEY}` or `$KEY` syntax may be used.
2None�
exposed_portszA file containing a comma separated list of exposed ports. (e.g. 2000/tcp, 3000/udp or 4000. No protocol defaults to tcp).2Nonei
labelsWA file containing a dictionary of labels. Each line should be in the form `name=value`.2None�
os�The name of the operating system which the image is built to run on. eg: `linux`, `windows`. See $GOOS documentation for possible values: https://go.dev/doc/install/source#environment2""�
tars�List of tar files to add to the image as layers.
Do not sort this list; the order is preserved in the resulting image.
Less-frequently changed files belong in lower layers to reduce the network bandwidth required to pull and push.

The authors recommend [dive](https://github.com/wagoodman/dive) to explore the layering of the resulting image.
2[]�
user�
The `username` or `UID` which is a platform-specific structure that allows specific control over which user the process run as.
This acts as a default value to use when the value is not specified when creating a container.
For Linux based systems, all of the following are valid: `user`, `uid`, `user:group`, `uid:gid`, `uid:group`, `user:gid`.
If `group/gid` is not specified, the default group and supplementary groups of the given `user/uid` in `/etc/passwd` from the container are applied.
2""�
variant�The variant of the specified CPU architecture. eg: `v6`, `v7`, `v8`. See: https://github.com/opencontainers/image-spec/blob/main/image-index.md#platform-variants for more.2""�
workdir�Sets the current working directory of the `entrypoint` process in the container. This value acts as a default and may be replaced by a working directory specified when creating a container.2"""+
oci_image_rule@@rules_oci//oci:defs.bzl
,
*
nameA unique name for this target. u
s
annotations\A file containing a dictionary of annotations. Each line should be in the form `name=value`.2None�
�
architecture�The CPU architecture which the binaries in this image are built to run on. eg: `arm64`, `arm`, `amd64`, `s390x`. See $GOARCH documentation for possible values: https://go.dev/doc/install/source#environment2""B
@
base0Label to an oci_image target to use as the base.2None�
�
cmd�A file containing a comma separated list to be used as the `command & args` of the container. These values act as defaults and may be replaced by any specified when creating a container.2None�
�

entrypoint�A file containing a comma separated list to be used as the `entrypoint` to execute when the container starts. These values act as defaults and may be replaced by an entrypoint specified when creating a container.2None�
�
env�A file containing the default values for the environment variables of the container. These values act as defaults and are merged with any specified when creating a container. Entries replace the base environment variables if any of the entries has conflicting keys.
To merge entries with keys specified in the base, `${KEY}` or `$KEY` syntax may be used.
2None�
�
exposed_portszA file containing a comma separated list of exposed ports. (e.g. 2000/tcp, 3000/udp or 4000. No protocol defaults to tcp).2Nonek
i
labelsWA file containing a dictionary of labels. Each line should be in the form `name=value`.2None�
�
os�The name of the operating system which the image is built to run on. eg: `linux`, `windows`. See $GOOS documentation for possible values: https://go.dev/doc/install/source#environment2""�
�
tars�List of tar files to add to the image as layers.
Do not sort this list; the order is preserved in the resulting image.
Less-frequently changed files belong in lower layers to reduce the network bandwidth required to pull and push.

The authors recommend [dive](https://github.com/wagoodman/dive) to explore the layering of the resulting image.
2[]�
�
user�
The `username` or `UID` which is a platform-specific structure that allows specific control over which user the process run as.
This acts as a default value to use when the value is not specified when creating a container.
For Linux based systems, all of the following are valid: `user`, `uid`, `user:group`, `uid:gid`, `uid:group`, `user:gid`.
If `group/gid` is not specified, the default group and supplementary groups of the given `user/uid` in `/etc/passwd` from the container are applied.
2""�
�
variant�The variant of the specified CPU architecture. eg: `v6`, `v7`, `v8`. See: https://github.com/opencontainers/image-spec/blob/main/image-index.md#platform-variants for more.2""�
�
workdir�Sets the current working directory of the `entrypoint` process in the container. This value acts as a default and may be replaced by a working directory specified when creating a container.2""�5oci_push�Macro wrapper around [oci_push_rule](#oci_push_rule).

Allows the remote_tags attribute to be a list of strings in addition to a text file.


Push an oci_image or oci_image_index to a remote registry.

Internal rule used by the [oci_push macro](/docs/push.md#oci_push).
Most users should use the macro.

Authorization
=============

By default, oci_push uses the standard authorization config file located on the host where `oci_push` is running.
Therefore the following documentation may be consulted:

- https://docs.docker.com/engine/reference/commandline/login/
- https://docs.podman.io/en/latest/markdown/podman-login.1.html
- https://github.com/google/go-containerregistry/blob/main/cmd/crane/doc/crane_auth_login.md

Behavior
========

Pushing and tagging are performed sequentially which MAY lead to non-atomic pushes if one the following events occur;

- Remote registry rejects a tag due to various reasons. eg: forbidden characters, existing tags
- Remote registry closes the connection during the tagging
- Local network outages

In order to avoid incomplete pushes oci_push will push the image by its digest and then apply the `remote_tags` sequentially at
the remote registry.

Any failure during pushing or tagging will be reported with non-zero exit code and cause remaining steps to be skipped.

Usage
=====

When running the pusher, you can pass flags to `bazel run`.

1. Override `repository` by passing the `-r|--repository` flag.

e.g. `bazel run //myimage:push -- --repository index.docker.io/<ORG>/image`

2. Supply tags in addition to `remote_tags` by passing the `-t|--tag` flag.

e.g. `bazel run //myimage:push -- --tag latest`

Examples
========

Push an oci_image to docker registry with 'latest' tag

```starlark
oci_image(name = "image")

oci_push(
    name = "push",
    image = ":image",
    repository = "index.docker.io/<ORG>/image",
    remote_tags = ["latest"]
)
```

Push a multi-architecture image to github container registry with a semver tag

```starlark
load("@aspect_bazel_lib//lib:expand_template.bzl", "expand_template_rule")

oci_image(name = "app_linux_arm64")

oci_image(name = "app_linux_amd64")

oci_image(name = "app_windows_amd64")

oci_image_index(
    name = "app_image",
    images = [
        ":app_linux_arm64",
        ":app_linux_amd64",
        ":app_windows_amd64",
    ]
)

# Use the value of --embed_label under --stamp, otherwise use a deterministic constant
# value to ensure cache hits for actions that depend on this.
expand_template(
    name = "stamped",
    out = "_stamped.tags.txt",
    template = ["0.0.0"],
    stamp_substitutions = {"0.0.0": "{{BUILD_EMBED_LABEL}}"},
)

oci_push(
    name = "push",
    image = ":app_image",
    repository = "ghcr.io/<OWNER>/image",
    remote_tags = ":stamped",
)
```
"�
�
oci_push�Macro wrapper around [oci_push_rule](#oci_push_rule).

Allows the remote_tags attribute to be a list of strings in addition to a text file.


Push an oci_image or oci_image_index to a remote registry.

Internal rule used by the [oci_push macro](/docs/push.md#oci_push).
Most users should use the macro.

Authorization
=============

By default, oci_push uses the standard authorization config file located on the host where `oci_push` is running.
Therefore the following documentation may be consulted:

- https://docs.docker.com/engine/reference/commandline/login/
- https://docs.podman.io/en/latest/markdown/podman-login.1.html
- https://github.com/google/go-containerregistry/blob/main/cmd/crane/doc/crane_auth_login.md

Behavior
========

Pushing and tagging are performed sequentially which MAY lead to non-atomic pushes if one the following events occur;

- Remote registry rejects a tag due to various reasons. eg: forbidden characters, existing tags
- Remote registry closes the connection during the tagging
- Local network outages

In order to avoid incomplete pushes oci_push will push the image by its digest and then apply the `remote_tags` sequentially at
the remote registry.

Any failure during pushing or tagging will be reported with non-zero exit code and cause remaining steps to be skipped.

Usage
=====

When running the pusher, you can pass flags to `bazel run`.

1. Override `repository` by passing the `-r|--repository` flag.

e.g. `bazel run //myimage:push -- --repository index.docker.io/<ORG>/image`

2. Supply tags in addition to `remote_tags` by passing the `-t|--tag` flag.

e.g. `bazel run //myimage:push -- --tag latest`

Examples
========

Push an oci_image to docker registry with 'latest' tag

```starlark
oci_image(name = "image")

oci_push(
    name = "push",
    image = ":image",
    repository = "index.docker.io/<ORG>/image",
    remote_tags = ["latest"]
)
```

Push a multi-architecture image to github container registry with a semver tag

```starlark
load("@aspect_bazel_lib//lib:expand_template.bzl", "expand_template_rule")

oci_image(name = "app_linux_arm64")

oci_image(name = "app_linux_amd64")

oci_image(name = "app_windows_amd64")

oci_image_index(
    name = "app_image",
    images = [
        ":app_linux_arm64",
        ":app_linux_amd64",
        ":app_windows_amd64",
    ]
)

# Use the value of --embed_label under --stamp, otherwise use a deterministic constant
# value to ensure cache hits for actions that depend on this.
expand_template(
    name = "stamped",
    out = "_stamped.tags.txt",
    template = ["0.0.0"],
    stamp_substitutions = {"0.0.0": "{{BUILD_EMBED_LABEL}}"},
)

oci_push(
    name = "push",
    image = ":app_image",
    repository = "ghcr.io/<OWNER>/image",
    remote_tags = ":stamped",
)
```
*
nameA unique name for this target. 5
image(Label to an oci_image or oci_image_index �
remote_tags�a .txt file containing tags, one per line.
These are passed to [`crane tag`](
https://github.com/google/go-containerregistry/blob/main/cmd/crane/doc/crane_tag.md)
2None�

repositoryzRepository URL where the image will be signed at, e.g.: `index.docker.io/<user>/image`.
Digests and tags are not allowed.
2""�
repository_fileiThe same as 'repository' but in a file. This allows pushing to different repositories based on stamping.
2None"*
oci_push_rule@@rules_oci//oci:defs.bzl
��,
*
nameA unique name for this target. 7
5
image(Label to an oci_image or oci_image_index �
�
remote_tags�a .txt file containing tags, one per line.
These are passed to [`crane tag`](
https://github.com/google/go-containerregistry/blob/main/cmd/crane/doc/crane_tag.md)
2None�
�

repositoryzRepository URL where the image will be signed at, e.g.: `index.docker.io/<user>/image`.
Digests and tags are not allowed.
2""�
�
repository_fileiThe same as 'repository' but in a file. This allows pushing to different repositories based on stamping.
2None�!oci_tarball�Macro wrapper around [oci_tarball_rule](#oci_tarball_rule).

Allows the repo_tags attribute to be a list of strings in addition to a text file.


Creates tarball from OCI layouts that can be loaded into docker daemon without needing to publish the image first.

Passing anything other than oci_image to the image attribute will lead to build time errors.

### Outputs

The default output is an mtree specification file.
This is because producing the tarball in `bazel build` is expensive, and should typically not be an input to any other build actions,
so producing it only creates unnecessary load on the action cache.

If needed, the `tarball` output group allows you to depend on the tar output from another rule.

On the command line, `bazel build //path/to:my_tarball --output_groups=tarball`

or in a BUILD file:

```starlark
oci_tarball(
    name = "my_tarball",
    ...
)
filegroup(
    name = "my_tarball.tar",
    srcs = [":my_tarball"],
    output_group = "tarball",
)
```
"�
�
oci_tarball�Macro wrapper around [oci_tarball_rule](#oci_tarball_rule).

Allows the repo_tags attribute to be a list of strings in addition to a text file.


Creates tarball from OCI layouts that can be loaded into docker daemon without needing to publish the image first.

Passing anything other than oci_image to the image attribute will lead to build time errors.

### Outputs

The default output is an mtree specification file.
This is because producing the tarball in `bazel build` is expensive, and should typically not be an input to any other build actions,
so producing it only creates unnecessary load on the action cache.

If needed, the `tarball` output group allows you to depend on the tar output from another rule.

On the command line, `bazel build //path/to:my_tarball --output_groups=tarball`

or in a BUILD file:

```starlark
oci_tarball(
    name = "my_tarball",
    ...
)
filegroup(
    name = "my_tarball.tar",
    srcs = [":my_tarball"],
    output_group = "tarball",
)
```
*
nameA unique name for this target. �
format�Format of image to generate. Options are: docker, oci. Currently, when the input image is an image_index, only oci is supported, and when the input image is an image, only docker is supported. Conversions between formats may be supported in the future.2"docker"Q
imageDLabel of a directory containing an OCI layout, typically `oci_image` �
loader�Alternative target for a container cli tool that will be
used to load the image into the local engine when using `bazel run` on this oci_tarball.

By default, we look for `docker` or `podman` on the PATH, and run the `load` command.

> Note that rules_docker has an "incremental loader" which is faster than oci_tarball by design.
> Something similar can be done for oci_tarball. 
> See [loader.sh](/examples/incremental_loader/loader.sh) and explanation about [how](/examples/incremental_loader/README.md) it works.

See the _run_template attribute for the script that calls this loader tool.
2None<
	repo_tags+a file containing repo_tags, one per line.
 "-
oci_tarball_rule@@rules_oci//oci:defs.bzl
��,
*
nameA unique name for this target. �
�
format�Format of image to generate. Options are: docker, oci. Currently, when the input image is an image_index, only oci is supported, and when the input image is an image, only docker is supported. Conversions between formats may be supported in the future.2"docker"S
Q
imageDLabel of a directory containing an OCI layout, typically `oci_image` �
�
loader�Alternative target for a container cli tool that will be
used to load the image into the local engine when using `bazel run` on this oci_tarball.

By default, we look for `docker` or `podman` on the PATH, and run the `load` command.

> Note that rules_docker has an "incremental loader" which is faster than oci_tarball by design.
> Something similar can be done for oci_tarball. 
> See [loader.sh](/examples/incremental_loader/loader.sh) and explanation about [how](/examples/incremental_loader/README.md) it works.

See the _run_template attribute for the script that calls this loader tool.
2None>
<
	repo_tags+a file containing repo_tags, one per line.
 u
//lib:copy_file.bzlr\
&
aspect_bazel_liblibcopy_file.bzl$
	copy_file	copy_file
	/	8
		:�
//lib:directory_path.bzlrk
+
aspect_bazel_liblibdirectory_path.bzl.
directory_pathdirectory_path

4
B


DY
//lib:jq.bzlrG

aspect_bazel_liblibjq.bzl
jqjq
(*
,�
//lib:utils.bzlr�
"
aspect_bazel_liblib	utils.bzlR
 propagate_common_rule_attributes propagate_common_rule_attributes
+K
Ma
//lib:types.bzlrL

bazel_skyliblib	types.bzl
typestypes
',
.y
//rules:write_file.bzlr]
%
bazel_skylibruleswrite_file.bzl&

write_file
write_file
.8
:w
//oci/private:image.bzlrZ
#
	rules_ocioci/private	image.bzl%
	oci_image
_oci_image
+5
D�
//oci/private:image_index.bzlrl
)
	rules_ocioci/privateimage_index.bzl1
oci_image_index_oci_image_index
1A
Vs
//oci/private:push.bzlrW
"
	rules_ocioci/privatepush.bzl#
oci_push	_oci_push
*3
A
//oci/private:tarball.bzlr`
%
	rules_ocioci/privatetarball.bzl)
oci_tarball_oci_tarball
-9
Jw
To load these rules, add this to the top of your `BUILD` file:

```starlark
load("@rules_oci//oci:defs.bzl", ...)
```
�
"
	rules_ociocidependencies.bzlvhttp_archive*d
M
http_archive

kwargs(21
http_archive!@@rules_oci//oci:dependencies.bzl


*maybe�rules_oci_dependencies*e
U
rules_oci_dependencies2;
rules_oci_dependencies!@@rules_oci//oci:dependencies.bzl
�
 //tools/build_defs/repo:http.bzlrk
.
bazel_toolstools/build_defs/repohttp.bzl+
http_archive_http_archive
6C
U�
!//tools/build_defs/repo:utils.bzlr]
/
bazel_toolstools/build_defs/repo	utils.bzl
maybemaybe
8=
?�Declare runtime dependencies

These are needed for local dev, and users must install them as well.
See https://docs.bazel.build/versions/main/skylark/deploying.html#dependencies
�
 
	rules_ociociextensions.bzl�ociJ�
�
oci�
pull.
name Name of the generated repository2""5
config#Label to a .docker/config.json file2None�
digestzthe digest string, starting with "sha256:", "sha512:", etc.
            If omitted, instructions for pinning are provided.2""P
imageAthe remote image without a tag, such as gcr.io/bazel-public/bazel2""�
	platforms�for multi-architecture images, a dictionary of the platforms it supports
            This creates a separate external repository for each platform, avoiding fetching layers.2[]c
reproducibleKSet to False to silence the warning about reproducibility when using `tag`.2True�
tag�a tag to choose an image from the registry.
            Exactly one of `tag` and `digest` must be set.
            Since tags are mutable, this is not reproducible, so a warning is printed.2""�

toolchains�
name�Base name for generated repositories, allowing more than one set of toolchains to be registered.
Overriding the default is only permitted in the root module.
2"oci""&
oci@@rules_oci//oci:extensions.bzl
AA�
�
pull.
name Name of the generated repository2""5
config#Label to a .docker/config.json file2None~
digestnthe digest string, starting with "sha256:", "sha512:", etc.
If omitted, instructions for pinning are provided.2""P
imageAthe remote image without a tag, such as gcr.io/bazel-public/bazel2""�
	platforms�for multi-architecture images, a dictionary of the platforms it supports
This creates a separate external repository for each platform, avoiding fetching layers.2[]c
reproducibleKSet to False to silence the warning about reproducibility when using `tag`.2True�
tag�a tag to choose an image from the registry.
Exactly one of `tag` and `digest` must be set.
Since tags are mutable, this is not reproducible, so a warning is printed.2""0
.
name Name of the generated repository2""7
5
config#Label to a .docker/config.json file2None�
~
digestnthe digest string, starting with "sha256:", "sha512:", etc.
If omitted, instructions for pinning are provided.2""R
P
imageAthe remote image without a tag, such as gcr.io/bazel-public/bazel2""�
�
	platforms�for multi-architecture images, a dictionary of the platforms it supports
This creates a separate external repository for each platform, avoiding fetching layers.2[]e
c
reproducibleKSet to False to silence the warning about reproducibility when using `tag`.2True�
�
tag�a tag to choose an image from the registry.
Exactly one of `tag` and `digest` must be set.
Since tags are mutable, this is not reproducible, so a warning is printed.2""�
�

toolchains�
name�Base name for generated repositories, allowing more than one set of toolchains to be registered.
Overriding the default is only permitted in the root module.
2"oci"�
�
name�Base name for generated repositories, allowing more than one set of toolchains to be registered.
Overriding the default is only permitted in the root module.
2"oci"b
//oci:pull.bzlrN

	rules_ociocipull.bzl"
oci_pulloci_pull
#+
-�
//oci:repositories.bzlrt
"
	rules_ociocirepositories.bzl@
oci_register_toolchainsoci_register_toolchains
+B
Dextensions for bzlmod�/

	rules_ociocipull.bzl�oci_pull�Repository macro to fetch image manifest data from a remote docker registry.

To use the resulting image, you can use the `@wkspc` shorthand label, for example
if `name = "distroless_base"`, then you can just use `base = "@distroless_base"`
in rules like `oci_image`.

> This shorthand syntax is broken on the command-line prior to Bazel 6.2.
> See https://github.com/bazelbuild/bazel/issues/4385
*�
�
oci_pull0
name$repository with this name is created (�
image�the remote image, such as `gcr.io/bazel-public/bazel`.
A tag can be suffixed with a colon, like `debian:latest`,
and a digest can be suffixed with an at-sign, like
`debian@sha256:e822570981e13a6ef1efcf31870726fbd62e72d9abfdcf405a9d8f566e8d7028`.

Exactly one of image or {registry,repository} should be set.None(

repositoryithe image path beneath the registry, such as `distroless/static`.
When set, registry must be set as well.None(z
registryfthe remote registry domain, such as `gcr.io` or `docker.io`.
When set, repository must be set as well.None(�
	platforms�a list of the platforms the image supports. Mandatory for multi-architecture
images. Optional for single-architecture images, which expect a one-element list.
This creates a separate external repository for each platform, avoiding fetching layers,
and an alias that validates the presence of an image matching the target platform's cpu.None(�
digestnthe digest string, starting with "sha256:", "sha512:", etc.
If omitted, instructions for pinning are provided.None(�
tag�a tag to choose an image from the registry.
Exactly one of `tag` and `digest` must be set.
Since tags are mutable, this is not reproducible, so a warning is printed.None(c
reproducibleKSet to False to silence the warning about reproducibility when using `tag`.True(R
	is_bzlmod<whether the oci_pull is being called from a module extensionFalse(8
config&Label to a `.docker/config.json` file.None(`
config_pathIDeprecated. use `config` attribute or DOCKER_CONFIG environment variable.None(�Repository macro to fetch image manifest data from a remote docker registry.

To use the resulting image, you can use the `@wkspc` shorthand label, for example
if `name = "distroless_base"`, then you can just use `base = "@distroless_base"`
in rules like `oci_image`.

> This shorthand syntax is broken on the command-line prior to Bazel 6.2.
> See https://github.com/bazelbuild/bazel/issues/4385
2%
oci_pull@@rules_oci//oci:pull.bzl
jj2	oci_alias�
//oci/private:pull.bzlr}
"
	rules_ocioci/privatepull.bzl$
	oci_alias	oci_alias
Y+Y4#
oci_pull	_oci_pull
Y7Y@
YYNj
//oci/private:util.bzlrN
"
	rules_ocioci/privateutil.bzl
utilutil
Z+Z/
ZZ1�A repository rule to pull image layers using Bazel's downloader.

Typical usage in `WORKSPACE.bazel`:

```starlark
load("@rules_oci//oci:pull.bzl", "oci_pull")

# A single-arch base image
oci_pull(
    name = "distroless_java",
    digest = "sha256:161a1d97d592b3f1919801578c3a47c8e932071168a96267698f4b669c24c76d",
    image = "gcr.io/distroless/java17",
    platforms = ["linux/amd64"],  # Optional
)

# A multi-arch base image
oci_pull(
    name = "distroless_static",
    digest = "sha256:c3c3d0230d487c0ad3a0d87ad03ee02ea2ff0b3dcce91ca06a1019e07de05f12",
    image = "gcr.io/distroless/static",
    platforms = [
        "linux/amd64",
        "linux/arm64",
    ],
)
```

Now you can refer to these as a base layer in `BUILD.bazel`.
The target is named the same as the external repo, so you can use a short label syntax:

```
oci_image(
    name = "app",
    base = "@distroless_static",
    ...
)
```

## Configuration

Docker specifies a standard location where registry credentials are stored:
<https://docs.docker.com/engine/reference/commandline/cli/#configuration-files>

We search for this file in several locations, following the logic at
https://github.com/google/go-containerregistry/tree/main/pkg/authn#tldr-for-consumers-of-this-package.

Set `--repo_env=DOCKER_CONFIG=/some/other/directory` to cause `oci_pull` to look for
`config.json` in this directory instead.

Finally, some less-common use cases are afforded with environment variables `XDG_RUNTIME_DIR` and `REGISTRY_AUTH_FILE`.
See the implementation of `_get_auth_file_path` in `/oci/private/auth_config_locator.bzl` for the complete reference.


## Authentication using credential helpers

By default oci_pull try to mimic `docker pull` authentication mechanism to allow users simply use `docker login` for authentication.

However, this doesn't always work due to some limitations of Bazel where response headers can't be read, which prevents us from
performing `WWW-Authenticate` challenges, as we don't know which endpoint to hit to complete the challenge. To workaround this
we keep a map of known registries that require us to perform www-auth challenge to acquire a temporary token for authentication.


Fortunately, Bazel supports running external programs to authenticate http requests using the `--credential_helper` command line flag.
When the credential helper flag passed, Bazel will call the external program before sending the request to allow additional headers to be set.

An example of this

.bazelrc
```
common --credential_helper=public.ecr.aws=%workspace%/tools/auth.sh
```

tools/auth.sh
```bash
input=$(cat)
uri=$(jq -r ".uri" <<< $input)
host="$(echo $uri | awk -F[/:] '{print $4}')"
curl -fsSL https://$host/token | jq '{headers:{"Authorization": [("Bearer " + .token)]}}'
```

This tells bazel to run `%workspace%/tools/auth.sh` for any request sent to `public.ecr.aws` and add additional headers that may have been
printed to `stdout` by the external program.

For more information about the credential helpers checkout the [documentation](https://github.com/bazelbuild/proposals/blob/main/designs/2022-06-07-bazel-credential-helpers.md).

See the [examples/credential_helper](/examples/credential_helper/auth.sh) directory for an example of how this work.
�+
"
	rules_ociocirepositories.bzl�	oci_register_toolchains�Convenience macro for users which does typical setup.

- create a repository for each built-in platform like "container_linux_amd64" -
  this repository is lazily fetched when node is needed for that platform.
- create a repository exposing toolchains for each platform like "container_platforms"
- register a toolchain pointing at each platform
Users can avoid this macro and do these steps themselves, if they want more control.*�
�
oci_register_toolchains7
name+base name for all created repos, like "oci" (�
register�whether to call through to native.register_toolchains.
Should be True for WORKSPACE users, but false when used under bzlmod extensionTrue(�Convenience macro for users which does typical setup.

- create a repository for each built-in platform like "container_linux_amd64" -
  this repository is lazily fetched when node is needed for that platform.
- create a repository exposing toolchains for each platform like "container_platforms"
- register a toolchain pointing at each platform
Users can avoid this macro and do these steps themselves, if they want more control.2<
oci_register_toolchains!@@rules_oci//oci:repositories.bzl
[[�	crane_repositories/Fetch external tools needed for crane toolchainR�	
�
crane_repositories/Fetch external tools needed for crane toolchain.
name"A unique name for this repository. 
crane_version 
platform �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 *7
crane_repositories!@@rules_oci//oci:repositories.bzl
.%.%0
.
name"A unique name for this repository. 

crane_version 

platform �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �	regctl_repositories0Fetch external tools needed for regctl toolchainR�
�
regctl_repositories0Fetch external tools needed for regctl toolchain.
name"A unique name for this repository. 
platform �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 *8
regctl_repositories!@@rules_oci//oci:repositories.bzl
R&R&0
.
name"A unique name for this repository. 

platform �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
//lib:repositories.bzlr�
)
aspect_bazel_liblibrepositories.bzl\
%register_copy_to_directory_toolchains%register_copy_to_directory_toolchains
+L
register_coreutils_toolchainsregister_coreutils_toolchains
#>
register_jq_toolchainsregister_jq_toolchains
@
register_tar_toolchainsregister_tar_toolchains
B
register_zstd_toolchainsregister_zstd_toolchains
		

s
	:deps.bzlrd

bazel_featuresdeps.bzl8
bazel_features_depsbazel_features_deps
%8
:�
!//oci/private:toolchains_repo.bzlr�
-
	rules_ocioci/privatetoolchains_repo.bzl$
	PLATFORMS	PLATFORMS
6?0
toolchains_repotoolchains_repo
CR
T�
//oci/private:versions.bzlr�
&
	rules_ocioci/privateversions.bzl.
CRANE_VERSIONSCRANE_VERSIONS
/=0
REGCTL_VERSIONSREGCTL_VERSIONS
AP
R�	CRANE_BUILD_TMPL�# Generated by oci/repositories.bzl
load("@rules_oci//oci:toolchain.bzl", "crane_toolchain")

crane_toolchain(
    name = "crane_toolchain", 
    crane = "{binary}",
    version = "{version}"
)
j��# Generated by oci/repositories.bzl
load("@rules_oci//oci:toolchain.bzl", "crane_toolchain")

crane_toolchain(
    name = "crane_toolchain", 
    crane = "{binary}",
    version = "{version}"
)
�	REGCTL_BUILD_TMPL�# Generated by container/repositories.bzl
load("@rules_oci//oci:toolchain.bzl", "regctl_toolchain")
regctl_toolchain(
    name = "regctl_toolchain", 
    regctl = "regctl{ext}",
)
j��# Generated by container/repositories.bzl
load("@rules_oci//oci:toolchain.bzl", "regctl_toolchain")
regctl_toolchain(
    name = "regctl_toolchain", 
    regctl = "regctl{ext}",
)
$	REGCTL_VERSIONv0.6.0jv0.6.0,Repository rules for fetching external tools�

	rules_ociocitoolchain.bzl�crane_toolchainkDefines a crane toolchain. See: https://docs.bazel.build/versions/main/toolchains.html#defining-toolchains."�
�
crane_toolchainkDefines a crane toolchain. See: https://docs.bazel.build/versions/main/toolchains.html#defining-toolchains.*
nameA unique name for this target. Q
craneDA hermetically downloaded executable target for the target platform. *
versionVersion of the crane binary "1
crane_toolchain@@rules_oci//oci:toolchain.bzl
##,
*
nameA unique name for this target. S
Q
craneDA hermetically downloaded executable target for the target platform. ,
*
versionVersion of the crane binary �regctl_toolchainlDefines a regctl toolchain. See: https://docs.bazel.build/versions/main/toolchains.html#defining-toolchains."�
�
regctl_toolchainlDefines a regctl toolchain. See: https://docs.bazel.build/versions/main/toolchains.html#defining-toolchains.*
nameA unique name for this target. R
regctlDA hermetically downloaded executable target for the target platform. "2
regctl_toolchain@@rules_oci//oci:toolchain.bzl
PP,
*
nameA unique name for this target. T
R
regctlDA hermetically downloaded executable target for the target platform. �	CraneInfo5Information about how to invoke the crane executable.2�
�
	CraneInfo5Information about how to invoke the crane executable.!
binaryExecutable crane binary
versionCrane version"+
	CraneInfo@@rules_oci//oci:toolchain.bzl
#
!
binaryExecutable crane binary

versionCrane version�
RegCtlInfo6Information about how to invoke the regctl executable.2�
�

RegCtlInfo6Information about how to invoke the regctl executable."
binaryExecutable regctl binary",

RegCtlInfo@@rules_oci//oci:toolchain.bzl
22$
"
binaryExecutable regctl binary<This module implements the language-specific toolchain rule.�

	rules_oci	fetch.bzl�fetch_imagesFetch external images*^
N
fetch_imagesFetch external images2'
fetch_images@@rules_oci//:fetch.bzl


�
 //tools/build_defs/repo:http.bzlrj
.
bazel_toolstools/build_defs/repohttp.bzl*
http_archivehttp_archive
7C
Eb
//oci:pull.bzlrN

	rules_ociocipull.bzl"
oci_pulloci_pull
#+
-�External fetches for OCI base images.

This file is similar to how bazel_gazelle can manage go_repository calls
by writing them to a generated macro in a .bzl file.
�

	rules_ociinternal_deps.bzlthttp_archive*b
K
http_archive

kwargs(2/
http_archive@@rules_oci//:internal_deps.bzl


*maybe�rules_oci_internal_deps'Fetch deps needed for local development*�
~
rules_oci_internal_deps'Fetch deps needed for local development2:
rules_oci_internal_deps@@rules_oci//:internal_deps.bzl
�
 //tools/build_defs/repo:http.bzlrk
.
bazel_toolstools/build_defs/repohttp.bzl+
http_archive_http_archive
6C
U�
!//tools/build_defs/repo:utils.bzlr]
/
bazel_toolstools/build_defs/repo	utils.bzl
maybemaybe
8=
?�Our "development" dependencies

Users should *not* need to install these. If users see a load()
statement from these, that's a bug in our distribution.
 