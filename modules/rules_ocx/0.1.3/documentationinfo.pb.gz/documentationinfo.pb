�
&
	rules_ocxocx/privatedownload.bzl�ocx_download�Downloads a pinned ocx CLI release for the host platform.

The release row (URL + sha256) comes from the vendored `dist.json` snapshot
of `https://setup.ocx.sh/dist.json`. Corporate mirrors: set
`OCX_INSTALL_DIST_URL` to fetch a mirrored manifest instead, and/or
`OCX_INSTALL_MIRROR_URL` to rewrite the artifact download to
`<mirror>/<tag>/<filename>`. The manifest sha256 is enforced either way.R�
�	
ocx_download�Downloads a pinned ocx CLI release for the host platform.

The release row (URL + sha256) comes from the vendored `dist.json` snapshot
of `https://setup.ocx.sh/dist.json`. Corporate mirrors: set
`OCX_INSTALL_DIST_URL` to fetch a mirrored manifest instead, and/or
`OCX_INSTALL_MIRROR_URL` to rewrite the artifact download to
`<mirror>/<tag>/<filename>`. The manifest sha256 is enforced either way..
name"A unique name for this repository. T
dist_manifest/Release manifest snapshot (dist.json schema 1).2//dist:dist.json�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
triple�Escape hatch: exact release target triple, e.g. 'x86_64-unknown-linux-gnu' to prefer the glibc build. Defaults to host detection (Linux maps to musl).2""<
version-Exact ocx version to download, e.g. '0.3.10'. *5
ocx_download%@@rules_ocx//ocx/private:download.bzl
660
.
name"A unique name for this repository. V
T
dist_manifest/Release manifest snapshot (dist.json schema 1).2//dist:dist.json�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
�
triple�Escape hatch: exact release target triple, e.g. 'x86_64-unknown-linux-gnu' to prefer the glibc build. Defaults to host detection (Linux maps to musl).2"">
<
version-Exact ocx version to download, e.g. '0.3.10'. �
//ocx/private:manifest.bzlr�
&
	rules_ocxocx/privatemanifest.bzl*
archive_typearchive_type
/;*
artifact_urlartifact_url
?K.
select_releaseselect_release
O]
_~
//ocx/private:platforms.bzlr]
'
	rules_ocxocx/privateplatforms.bzl$
	host_info	host_info
09
;�Repository rule bootstrapping the pinned ocx CLI binary.

Downloads the release archive listed in the vendored dist.json snapshot
(sha256-enforced), honoring the same corporate-mirror knobs as the
setup.ocx.sh installer. Binary-only placement â never runs `ocx self setup`.
�
&
	rules_ocxocx/privatemanifest.bzl�archive_type�Maps a release filename to the explicit download_and_extract type.

ocx releases ship .zip (windows), .tar.gz (>= 0.4.3), and .tar.xz (older).
*�
�
archive_typeR
filenameBrelease row filename, e.g. "ocx-x86_64-unknown-linux-musl.tar.gz". (�Maps a release filename to the explicit download_and_extract type.

ocx releases ship .zip (windows), .tar.gz (>= 0.4.3), and .tar.xz (older).
"@
>Archive type string for repository_ctx.download_and_extract().25
archive_type%@@rules_ocx//ocx/private:manifest.bzl
�artifact_url�Resolves the download URL for a release row, honoring a mirror.

Mirrors relocate artifacts but never alter them: the caller must keep
enforcing row["sha256"]. Rewrite matches the setup.ocx.sh installer:
`<mirror>/<tag>/<filename>`.
*�
�
artifact_url/
row$a release row from select_release(). (>

mirror_url,value of OCX_INSTALL_MIRROR_URL, or None/"". (�Resolves the download URL for a release row, honoring a mirror.

Mirrors relocate artifacts but never alter them: the caller must keep
enforcing row["sha256"]. Rewrite matches the setup.ocx.sh installer:
`<mirror>/<tag>/<filename>`.
"
URL string.25
artifact_url%@@rules_ocx//ocx/private:manifest.bzl
00�select_release>Finds the manifest row for an exact version and target triple.*�
�
select_release)
manifestdecoded dist.json object. (0
version!exact ocx version, e.g. "0.3.10". (I
target;cargo-dist target triple, e.g. "x86_64-unknown-linux-musl". (>Finds the manifest row for an exact version and target triple.""
 The matching release row (dict).27
select_release%@@rules_ocx//ocx/private:manifest.bzl
�Pure helpers over the setup.ocx.sh dist.json release manifest.

Manifest schema (flat rows, schema 1):
    {"schema": 1, "latest": {...}, "releases": [
        {"version", "channel", "tag", "target", "filename", "sha256", "url"}, ...]}
�N
%
	rules_ocxocx/privatepackage.bzl�
pinned_ref=Applies the per-platform manifest pin for `platform`, if any.*�
�

pinned_refI
package:the fallback reference 'registry/repo[:tag][@sha256:…]'. (=
pins1{ocx platform key: 'sha256:…' manifest digest}. (@
platform0the ocx platform key this repository provisions. (=Applies the per-platform manifest pin for `platform`, if any."
the reference to install.22

pinned_ref$@@rules_ocx//ocx/private:package.bzl
;;�resolve_platforms�Validates aliases and maps each declared platform to its slug + real platform.

Every `aliases` key must be a declared platform; its value is the real ocx
platform sent to `-p`. Two declared platforms reducing to the same slug is an
error (they would collide on repo/config_setting names).
*�
�
resolve_platforms:
name.the ocx.package tag name (for error messages). (3
	platforms"the declared target platform keys. (G
aliases8{declared platform key: real ocx platform sent to `-p`}. (�Validates aliases and maps each declared platform to its slug + real platform.

Every `aliases` key must be a declared platform; its value is the real ocx
platform sent to `-p`. Two declared platforms reducing to the same slug is an
error (they would collide on repo/config_setting names).
"K
Istruct(error = "" | message, platforms = {slug: struct(declared, real)}).29
resolve_platforms$@@rules_ocx//ocx/private:package.bzl
MM�ocx_package_hub�Multi-platform hub for an ocx.package() with `platforms`.

`//:content` (or, with `bins`, each named launcher) select()s the
per-platform package repo matching the target platform â combine with a
platform transition to fetch foreign-platform tools (e.g. for container
images).R�
�
ocx_package_hub�Multi-platform hub for an ocx.package() with `platforms`.

`//:content` (or, with `bins`, each named launcher) select()s the
per-platform package repo matching the target platform â combine with a
platform transition to fetch foreign-platform tools (e.g. for container
images)..
name"A unique name for this repository. G
bins9Lazy mode: launcher names to alias instead of //:content.2[]r
platform_reals\repo slug -> real ocx platform, the source of each config_setting's Bazel constraint_values.
 R
platform_repos<repo slug -> apparent name of the per-platform package repo.
 �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 *7
ocx_package_hub$@@rules_ocx//ocx/private:package.bzl
�"�"0
.
name"A unique name for this repository. I
G
bins9Lazy mode: launcher names to alias instead of //:content.2[]t
r
platform_reals\repo slug -> real ocx platform, the source of each config_setting's Bazel constraint_values.
 T
R
platform_repos<repo slug -> apparent name of the per-platform package repo.
 �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �)ocx_package_repo�Provisions a single OCX package from an OCI registry.

`//:content` is the package tree; every executable reachable through the
package environment becomes a runnable target `//:<name>` (host-platform
repos only). For reproducibility, commit an index snapshot and reference it
via `index` (tags then resolve frozen from the snapshot), or pin
per-platform manifest digests via `pins` â plain floating tags resolve at
fetch time and log the resolved digest.

With `bins`, provisioning is lazy: nothing is installed at fetch time, and
each named executable becomes a launcher re-entering `ocx package exec` â
content materializes on first execution and never becomes a Bazel action
input (`//:content` is not available in lazy mode).R�#
�
ocx_package_repo�Provisions a single OCX package from an OCI registry.

`//:content` is the package tree; every executable reachable through the
package environment becomes a runnable target `//:<name>` (host-platform
repos only). For reproducibility, commit an index snapshot and reference it
via `index` (tags then resolve frozen from the snapshot), or pin
per-platform manifest digests via `pins` â plain floating tags resolve at
fetch time and log the resolved digest.

With `bins`, provisioning is lazy: nothing is installed at fetch time, and
each named executable becomes a launcher re-entering `ocx package exec` â
content materializes on first execution and never becomes a Bazel action
input (`//:content` is not available in lazy mode)..
name"A unique name for this repository. �
bins�Lazy provisioning: names of the executables to expose (not validated at fetch time). When set, nothing is installed during the fetch â each name becomes a launcher re-entering `ocx package exec`, keyed on the digest-pinned reference. Requires a digest-pinned identity (`pins` or '@sha256:'); incompatible with isolated_home and index.2[]�
index�Committed ocx index snapshot directory (created with `ocx --index <dir> index update <package>`). When set, tag resolution is frozen to the snapshot (`--index --frozen`): floating tags become reproducible until the snapshot is refreshed.2Noneh
isolated_homeNKeep the ocx store inside this repository instead of the shared user OCX_HOME.2False4
ocxThe pinned ocx CLI binary.2@ocx_tool//:ocxQ
packageBFully-qualified identifier: 'registry/repo[:tag][@sha256:â¦]'. w
pinsiocx platform key -> 'sha256:â¦' manifest digest overriding the digest of `package` for that platform.
2{}Z
platformHocx platform key ('linux/amd64', â¦) to provision for; empty = host.2""�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
resolved_platform�Real ocx platform sent to `-p` â lets a declared `platform` be aliased to a different real one (variant/feature build). Empty = derive from `platform`. Runnable-target gating compares its os/arch prefix to the host; `pins` still key on `platform`.2""*8
ocx_package_repo$@@rules_ocx//ocx/private:package.bzl
�#�#0
.
name"A unique name for this repository. �
�
bins�Lazy provisioning: names of the executables to expose (not validated at fetch time). When set, nothing is installed during the fetch â each name becomes a launcher re-entering `ocx package exec`, keyed on the digest-pinned reference. Requires a digest-pinned identity (`pins` or '@sha256:'); incompatible with isolated_home and index.2[]�
�
index�Committed ocx index snapshot directory (created with `ocx --index <dir> index update <package>`). When set, tag resolution is frozen to the snapshot (`--index --frozen`): floating tags become reproducible until the snapshot is refreshed.2Nonej
h
isolated_homeNKeep the ocx store inside this repository instead of the shared user OCX_HOME.2False6
4
ocxThe pinned ocx CLI binary.2@ocx_tool//:ocxS
Q
packageBFully-qualified identifier: 'registry/repo[:tag][@sha256:â¦]'. y
w
pinsiocx platform key -> 'sha256:â¦' manifest digest overriding the digest of `package` for that platform.
2{}\
Z
platformHocx platform key ('linux/amd64', â¦) to provision for; empty = host.2""�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
�
resolved_platform�Real ocx platform sent to `-p` â lets a declared `platform` be aliased to a different real one (variant/feature build). Empty = derive from `platform`. Runnable-target gating compares its os/arch prefix to the host; `pins` still key on `platform`.2""�
//ocx/private:platforms.bzlr�
'
	rules_ocxocx/privateplatforms.bzl$
	host_info	host_info
09B
ocx_platform_constraintsocx_platform_constraints
=U 
os_archos_arch
Y`
slugslug
dh
j�
//ocx/private:repo_utils.bzlr�
(
	rules_ocxocx/privaterepo_utils.bzl(
decode_jsondecode_json
*
make_ocx_envmake_ocx_env
 
ocx_binocx_bin
.
render_env_bzlrender_env_bzl
>
render_launchers_buildrender_launchers_build
:
render_lazy_launcherrender_lazy_launcher
.
rlocation_pathrlocation_path
 
run_ocxrun_ocx
$
	scan_bins	scan_bins
0
write_launcherswrite_launchers

	�Package-tier repository rules: provision a single OCI package via the ocx
CLI (`package install` â `package which` â `package env`), plus the
multi-platform hub that select()s between per-platform repos.�
'
	rules_ocxocx/privateplatforms.bzl�	host_info�Maps a host OS name and arch to ocx release and platform identifiers.

Linux maps to the musl triple: the ocx musl builds are static, run on any
libc, and are the same binaries ocx's own OCI publishing uses — so no
libc detection is needed.
*�
�
	host_infoP
os_nameA`repository_ctx.os.name`, e.g. "linux", "mac os x", "windows 10". (>
arch2`repository_ctx.os.arch`, e.g. "amd64", "aarch64". (�Maps a host OS name and arch to ocx release and platform identifiers.

Linux maps to the musl triple: the ocx musl builds are static, run on any
libc, and are the same binaries ocx's own OCI publishing uses — so no
libc detection is needed.
"�
�struct with fields:
triple: cargo-dist target triple of the ocx release artifact.
ocx_platform: ocx "os/arch" key for `-p` / ocx.lock.
is_windows: bool.
exe_ext: "" or ".exe".23
	host_info&@@rules_ocx//ocx/private:platforms.bzl
GG�ocx_platform_constraints�Bazel constraint labels for the os/arch prefix of an ocx platform key.

'linux/arm64+libc.musl' -> ['@platforms//os:linux', '@platforms//cpu:aarch64'].
For toolchain authors composing exec_compatible_with; also the hub's source
of config_setting constraint_values. Fails on an unmappable os/arch.
*�
�
ocx_platform_constraintsH
platform8an ocx platform key ('os/arch[/variant][+feature,...]'). (�Bazel constraint labels for the os/arch prefix of an ocx platform key.

'linux/arm64+libc.musl' -> ['@platforms//os:linux', '@platforms//cpu:aarch64'].
For toolchain authors composing exec_compatible_with; also the hub's source
of config_setting constraint_values. Fails on an unmappable os/arch.
".
,[os_constraint_label, cpu_constraint_label].2B
ocx_platform_constraints&@@rules_ocx//ocx/private:platforms.bzl
**�os_archJThe 'os/arch' prefix of a platform key (drops '/variant' and '+features').*�
�
os_arch
platform (JThe 'os/arch' prefix of a platform key (drops '/variant' and '+features').21
os_arch&@@rules_ocx//ocx/private:platforms.bzl
&&�slug�Bazel-name-safe slug of an ocx platform key.

Lowercases, maps every non-[a-z0-9] run to a single '_', strips leading/
trailing '_'. 'linux/arm64+libc.musl' -> 'linux_arm64_libc_musl'.*�
�
slug
platform (�Bazel-name-safe slug of an ocx platform key.

Lowercases, maps every non-[a-z0-9] run to a single '_', strips leading/
trailing '_'. 'linux/arm64+libc.musl' -> 'linux_arm64_libc_musl'.2.
slug&@@rules_ocx//ocx/private:platforms.bzl
�Host platform detection and ocx platform-key mappings.

Pure functions on (os name, arch) strings so they are unit-testable; the
repository rules pass `repository_ctx.os.name` / `.arch` in.
�4
%
	rules_ocxocx/privateproject.bzl�-ocx_project_repo�	Provisions the toolchain declared in a workspace ocx.toml/ocx.lock.

Fails when the lockfile is stale or missing (fix with `ocx lock`). Every
executable reachable through the composed environment's `path` entries
becomes a runnable target `//:<name>`; the raw environment is loadable from
`//:env.bzl` (`OCX_ENV`, `OCX_HOME`).

With `bins`, provisioning is lazy: nothing is pulled at fetch time, and each
named executable becomes a launcher that re-enters `ocx run` â content
materializes on first execution and never becomes a Bazel action input, so
fully remote-cached builds download no tool content at all.

`groups` scopes both the pull and the composed environment. Omitted, ocx's
defaults apply: every group is pulled, but only the default `[tools]` table
is composed into launchers â name groups explicitly (or use the reserved
`all`) to expose their executables.

`platform` composes a foreign platform's environment from the same
ocx.lock: that platform's leaves are pulled into the store and `env.bzl`
holds their absolute store paths (sysroots, target libraries, container
image content). Foreign repos expose no runnable launchers â the binaries
do not run on this host.R�#
�
ocx_project_repo�	Provisions the toolchain declared in a workspace ocx.toml/ocx.lock.

Fails when the lockfile is stale or missing (fix with `ocx lock`). Every
executable reachable through the composed environment's `path` entries
becomes a runnable target `//:<name>`; the raw environment is loadable from
`//:env.bzl` (`OCX_ENV`, `OCX_HOME`).

With `bins`, provisioning is lazy: nothing is pulled at fetch time, and each
named executable becomes a launcher that re-enters `ocx run` â content
materializes on first execution and never becomes a Bazel action input, so
fully remote-cached builds download no tool content at all.

`groups` scopes both the pull and the composed environment. Omitted, ocx's
defaults apply: every group is pulled, but only the default `[tools]` table
is composed into launchers â name groups explicitly (or use the reserved
`all`) to expose their executables.

`platform` composes a foreign platform's environment from the same
ocx.lock: that platform's leaves are pulled into the store and `env.bzl`
holds their absolute store paths (sysroots, target libraries, container
image content). Foreign repos expose no runnable launchers â the binaries
do not run on this host..
name"A unique name for this repository. �
bins�Lazy provisioning: names of the executables to expose (not validated at fetch time). When set, nothing is pulled during the fetch â each name becomes a launcher re-entering `ocx run`, and actions key on the lockfile (a runfile) instead of tool content. Incompatible with isolated_home.2[]�
groups�ocx.toml groups to provision (comma-joined into `-g` for `ocx pull`, `ocx env`, and lazy `ocx run`). Reserved names: 'default' = the top-level [tools] table, 'all' = default + every declared group.2[]h
isolated_homeNKeep the ocx store inside this repository instead of the shared user OCX_HOME.2False4
ocxThe pinned ocx CLI binary.2@ocx_tool//:ocxO
ocx_lock?The ocx.lock next to ocx_toml; watched so lock changes refetch. =
ocx_toml-The project ocx.toml declaring the toolchain. �
platform�ocx platform key ('linux/arm64', â¦) to compose for; empty = host. A foreign platform pulls that platform's leaves from the same ocx.lock and exposes env.bzl only (no runnable launchers). Incompatible with bins â lazy launchers already resolve the executing host at run time.2""�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 *8
ocx_project_repo$@@rules_ocx//ocx/private:project.bzl
�#�#0
.
name"A unique name for this repository. �
�
bins�Lazy provisioning: names of the executables to expose (not validated at fetch time). When set, nothing is pulled during the fetch â each name becomes a launcher re-entering `ocx run`, and actions key on the lockfile (a runfile) instead of tool content. Incompatible with isolated_home.2[]�
�
groups�ocx.toml groups to provision (comma-joined into `-g` for `ocx pull`, `ocx env`, and lazy `ocx run`). Reserved names: 'default' = the top-level [tools] table, 'all' = default + every declared group.2[]j
h
isolated_homeNKeep the ocx store inside this repository instead of the shared user OCX_HOME.2False6
4
ocxThe pinned ocx CLI binary.2@ocx_tool//:ocxQ
O
ocx_lock?The ocx.lock next to ocx_toml; watched so lock changes refetch. ?
=
ocx_toml-The project ocx.toml declaring the toolchain. �
�
platform�ocx platform key ('linux/arm64', â¦) to compose for; empty = host. A foreign platform pulls that platform's leaves from the same ocx.lock and exposes env.bzl only (no runnable launchers). Incompatible with bins â lazy launchers already resolve the executing host at run time.2""�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 ~
//ocx/private:platforms.bzlr]
'
	rules_ocxocx/privateplatforms.bzl$
	host_info	host_info
	0	9
		;�
//ocx/private:repo_utils.bzlr�
(
	rules_ocxocx/privaterepo_utils.bzl(
decode_jsondecode_json
*
make_ocx_envmake_ocx_env
 
ocx_binocx_bin
.
render_env_bzlrender_env_bzl
>
render_launchers_buildrender_launchers_build
:
render_lazy_launcherrender_lazy_launcher
.
rlocation_pathrlocation_path
 
run_ocxrun_ocx
$
	scan_bins	scan_bins
0
write_launcherswrite_launchers


�Project-tier repository rule: provision the workspace toolchain from
ocx.toml + ocx.lock via the ocx CLI (`lock --check` â `pull` â `env`), or â
with `bins` â lazily via launchers that re-enter `ocx run` at execution
time.�<
(
	rules_ocxocx/privaterepo_utils.bzl�decode_json=json.decode with an error message naming the failing command.*�
�
decode_json
stdout (

what (=json.decode with an error message naming the failing command.26
decode_json'@@rules_ocx//ocx/private:repo_utils.bzl
pp�list_executables;Lists executable file names in a directory (non-recursive).*�
�
list_executables
ctxrepository_ctx. (0
	directoryabsolute directory path string. (m

is_windows[host flag; on Windows executables are picked by extension,
elsewhere by the executable bit. (;Lists executable file names in a directory (non-recursive)."%
#list of basenames, directory order.2;
list_executables'@@rules_ocx//ocx/private:repo_utils.bzl
vv�make_ocx_envBAssembles the environment for ocx invocations from this repo rule.*�
�
make_ocx_env
ctxrepository_ctx. (l
isolated_homeWif True, keep the ocx store inside this repository
instead of the shared user OCX_HOME. (BAssembles the environment for ocx invocations from this repo rule."J
Hstruct(env = dict for repository_ctx.execute, home = resolved OCX_HOME).27
make_ocx_env'@@rules_ocx//ocx/private:repo_utils.bzl
  �ocx_bin�Resolves the ocx binary path from the rule's `ocx` label attribute.

On Windows the executable lives next to the stable `ocx` file as
`ocx.exe`; prefer it when present.
*�
�
ocx_bin3
ctx(repository_ctx with an `ocx` label attr. (�Resolves the ocx binary path from the rule's `ocx` label attribute.

On Windows the executable lives next to the stable `ocx` file as
`ocx.exe`; prefer it when present.
"*
(path object of the executable to invoke.22
ocx_bin'@@rules_ocx//ocx/private:repo_utils.bzl
@@�render_env_bzldRenders the generated repo's env.bzl.

JSON round-trip keeps escaping correct for arbitrary values.
*�
�
render_env_bzl*
entriesenv entries from `ocx env`. (
homeresolved OCX_HOME. (dRenders the generated repo's env.bzl.

JSON round-trip keeps escaping correct for arbitrary values.
"
env.bzl content string.29
render_env_bzl'@@rules_ocx//ocx/private:repo_utils.bzl
���render_launcher�Renders a launcher script applying the ocx env and exec-ing a tool.

`path` entries prepend to the invoking environment; `constant` entries
replace. OCX_HOME and OCX_BINARY_PIN are baked so ocx entrypoint
launchers re-enter the pinned ocx against the right store.
*�
�
render_launcher;
entries,env entries [{"key", "value", "type"}, ...]. (6
target(absolute path of the executable to exec. (
homeresolved OCX_HOME. (2
ocx'absolute path of the pinned ocx binary. (2

is_windows render .bat instead of POSIX sh. (�Renders a launcher script applying the ocx env and exec-ing a tool.

`path` entries prepend to the invoking environment; `constant` entries
replace. OCX_HOME and OCX_BINARY_PIN are baked so ocx entrypoint
launchers re-enter the pinned ocx against the right store.
"
script content string.2:
render_launcher'@@rules_ocx//ocx/private:repo_utils.bzl
���render_launchers_buildERenders a generated BUILD file exposing one runnable target per tool.*�
�
render_launchers_build:
bins.list of struct(name, target) from scan_bins(). (L

is_windows:host flag (launcher extension and native_binary out name). (:
extra+additional BUILD content appended verbatim.""(�
data�label strings attached as runfiles to every launcher (lazy
launchers carry the ocx binary and project files this way, making
them action inputs).[](ERenders a generated BUILD file exposing one runnable target per tool."
BUILD file content string.2A
render_launchers_build'@@rules_ocx//ocx/private:repo_utils.bzl
���	render_lazy_launcher�Renders a lazy launcher: ocx is re-entered at execution time.

No store paths are baked in — the wrapped ocx command auto-installs
missing content on first use, so the action key is the script text plus
its runfiles, never the tool content itself. POSIX scripts locate their
inputs through the runfiles library, keeping the text identical across
machines (portable remote-cache keys).
*�
�
render_lazy_launcherr
commandcpre-quoted argv fragments; POSIX fragments may use
`$(rlocation …)` — the preamble provides it. (�

is_windows�render .bat instead of POSIX sh. Windows launchers bake
absolute paths (no Batch runfiles library), so their action keys
are machine-local. (�Renders a lazy launcher: ocx is re-entered at execution time.

No store paths are baked in — the wrapped ocx command auto-installs
missing content on first use, so the action key is the script text plus
its runfiles, never the tool content itself. POSIX scripts locate their
inputs through the runfiles library, keeping the text identical across
machines (portable remote-cache keys).
"
script content string.2?
render_lazy_launcher'@@rules_ocx//ocx/private:repo_utils.bzl
���rlocation_pathFRunfiles-lookup key ('<canonical repo>/<package>/<name>') for a label.*�
�
rlocation_pathD
label7a resolved Label (e.g. the value of a label attribute). (FRunfiles-lookup key ('<canonical repo>/<package>/<name>') for a label.">
<the key accepted by the Bash runfiles library's `rlocation`.29
rlocation_path'@@rules_ocx//ocx/private:repo_utils.bzl
���run_ocx:Runs the ocx CLI, mapping failures to actionable messages.*�
�
run_ocx
ctxrepository_ctx. ()
binarypath of the ocx executable. ("
argsargv after the binary. (6
env+environment dict (from make_ocx_env().env). (;
what/short human description used in error messages. (H
hints9{exit_code: extra hint} overriding the sysexits defaults.{}(�
retries�extra attempts after a failure. Repo rules fetch in
parallel, and concurrent `ocx package install` calls of the same
package can race on store symlink creation (ocx TOCTOU); the
store is idempotent, so a retry converges.0(:Runs the ocx CLI, mapping failures to actionable messages."
stdout string.22
run_ocx'@@rules_ocx//ocx/private:repo_utils.bzl
PP�	scan_bins�Discovers runnable tools from the `path`-typed env entries.

Mirrors ocx PATH semantics: entries in declaration order, first name
wins. Windows binaries are keyed by their extension-less name.
*�
�
	scan_bins
ctxrepository_ctx. (J
entries;env entries [{"key", "value", "type"}, ...] from `ocx env`. (

is_windows
host flag. (�Discovers runnable tools from the `path`-typed env entries.

Mirrors ocx PATH semantics: entries in declaration order, first name
wins. Windows binaries are keyed by their extension-less name.
"l
jlist of struct(name, target) in discovery order, where target is the
absolute path of the real executable.24
	scan_bins'@@rules_ocx//ocx/private:repo_utils.bzl
���write_launchers1Writes launcher scripts for all discovered tools.*�
�
write_launchers
ctxrepository_ctx. (:
bins.list of struct(name, target) from scan_bins(). (5
entries&env entries applied by every launcher. (
homeresolved OCX_HOME. (9
ocx.absolute path string of the pinned ocx binary. (

is_windows
host flag. (1Writes launcher scripts for all discovered tools.2:
write_launchers'@@rules_ocx//ocx/private:repo_utils.bzl
���	OCX_PASSTHROUGH_ENVj�2�
OCX_MIRRORS
OCX_INSECURE_REGISTRIES
OCX_OFFLINE

OCX_FROZEN

OCX_REMOTE

OCX_JOBS
	OCX_INDEX
OCX_DEFAULT_REGISTRY�Shared plumbing for repository rules that shell out to the ocx CLI.

Everything that can be a pure function of plain values (launcher rendering,
env-file rendering) is one, so tests/ can cover it without a repository_ctx.
�
&
	rules_ocxocx/privateversions.bzl'	DEFAULT_OCX_VERSION0.4.3j0.4.3�Pinned default ocx CLI version.

The ocx CLI declares no stability for its command-line surface across
versions; rules_ocx therefore pins an exact version and is tested against
exactly that version. Bump deliberately, together with dist/dist.json.
�

	rules_ocxocxdefs.bzl�ocx_platform_constraints�Bazel constraint labels for the os/arch prefix of an ocx platform key.

'linux/arm64+libc.musl' -> ['@platforms//os:linux', '@platforms//cpu:aarch64'].
For toolchain authors composing exec_compatible_with; also the hub's source
of config_setting constraint_values. Fails on an unmappable os/arch.
*�
�
ocx_platform_constraintsH
platform8an ocx platform key ('os/arch[/variant][+feature,...]'). (�Bazel constraint labels for the os/arch prefix of an ocx platform key.

'linux/arm64+libc.musl' -> ['@platforms//os:linux', '@platforms//cpu:aarch64'].
For toolchain authors composing exec_compatible_with; also the hub's source
of config_setting constraint_values. Fails on an unmappable os/arch.
".
,[os_constraint_label, cpu_constraint_label].2B
ocx_platform_constraints&@@rules_ocx//ocx/private:platforms.bzl
**�ocx_download�Downloads a pinned ocx CLI release for the host platform.

The release row (URL + sha256) comes from the vendored `dist.json` snapshot
of `https://setup.ocx.sh/dist.json`. Corporate mirrors: set
`OCX_INSTALL_DIST_URL` to fetch a mirrored manifest instead, and/or
`OCX_INSTALL_MIRROR_URL` to rewrite the artifact download to
`<mirror>/<tag>/<filename>`. The manifest sha256 is enforced either way.R�
�	
ocx_download�Downloads a pinned ocx CLI release for the host platform.

The release row (URL + sha256) comes from the vendored `dist.json` snapshot
of `https://setup.ocx.sh/dist.json`. Corporate mirrors: set
`OCX_INSTALL_DIST_URL` to fetch a mirrored manifest instead, and/or
`OCX_INSTALL_MIRROR_URL` to rewrite the artifact download to
`<mirror>/<tag>/<filename>`. The manifest sha256 is enforced either way..
name"A unique name for this repository. T
dist_manifest/Release manifest snapshot (dist.json schema 1).2//dist:dist.json�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
triple�Escape hatch: exact release target triple, e.g. 'x86_64-unknown-linux-gnu' to prefer the glibc build. Defaults to host detection (Linux maps to musl).2""<
version-Exact ocx version to download, e.g. '0.3.10'. *)
ocx_download@@rules_ocx//ocx:defs.bzl
660
.
name"A unique name for this repository. V
T
dist_manifest/Release manifest snapshot (dist.json schema 1).2//dist:dist.json�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
�
triple�Escape hatch: exact release target triple, e.g. 'x86_64-unknown-linux-gnu' to prefer the glibc build. Defaults to host detection (Linux maps to musl).2"">
<
version-Exact ocx version to download, e.g. '0.3.10'. �ocx_package_hub�Multi-platform hub for an ocx.package() with `platforms`.

`//:content` (or, with `bins`, each named launcher) select()s the
per-platform package repo matching the target platform â combine with a
platform transition to fetch foreign-platform tools (e.g. for container
images).R�
�
ocx_package_hub�Multi-platform hub for an ocx.package() with `platforms`.

`//:content` (or, with `bins`, each named launcher) select()s the
per-platform package repo matching the target platform â combine with a
platform transition to fetch foreign-platform tools (e.g. for container
images)..
name"A unique name for this repository. G
bins9Lazy mode: launcher names to alias instead of //:content.2[]r
platform_reals\repo slug -> real ocx platform, the source of each config_setting's Bazel constraint_values.
 R
platform_repos<repo slug -> apparent name of the per-platform package repo.
 �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 *,
ocx_package_hub@@rules_ocx//ocx:defs.bzl
�"�"0
.
name"A unique name for this repository. I
G
bins9Lazy mode: launcher names to alias instead of //:content.2[]t
r
platform_reals\repo slug -> real ocx platform, the source of each config_setting's Bazel constraint_values.
 T
R
platform_repos<repo slug -> apparent name of the per-platform package repo.
 �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �)ocx_package_repo�Provisions a single OCX package from an OCI registry.

`//:content` is the package tree; every executable reachable through the
package environment becomes a runnable target `//:<name>` (host-platform
repos only). For reproducibility, commit an index snapshot and reference it
via `index` (tags then resolve frozen from the snapshot), or pin
per-platform manifest digests via `pins` â plain floating tags resolve at
fetch time and log the resolved digest.

With `bins`, provisioning is lazy: nothing is installed at fetch time, and
each named executable becomes a launcher re-entering `ocx package exec` â
content materializes on first execution and never becomes a Bazel action
input (`//:content` is not available in lazy mode).R�#
�
ocx_package_repo�Provisions a single OCX package from an OCI registry.

`//:content` is the package tree; every executable reachable through the
package environment becomes a runnable target `//:<name>` (host-platform
repos only). For reproducibility, commit an index snapshot and reference it
via `index` (tags then resolve frozen from the snapshot), or pin
per-platform manifest digests via `pins` â plain floating tags resolve at
fetch time and log the resolved digest.

With `bins`, provisioning is lazy: nothing is installed at fetch time, and
each named executable becomes a launcher re-entering `ocx package exec` â
content materializes on first execution and never becomes a Bazel action
input (`//:content` is not available in lazy mode)..
name"A unique name for this repository. �
bins�Lazy provisioning: names of the executables to expose (not validated at fetch time). When set, nothing is installed during the fetch â each name becomes a launcher re-entering `ocx package exec`, keyed on the digest-pinned reference. Requires a digest-pinned identity (`pins` or '@sha256:'); incompatible with isolated_home and index.2[]�
index�Committed ocx index snapshot directory (created with `ocx --index <dir> index update <package>`). When set, tag resolution is frozen to the snapshot (`--index --frozen`): floating tags become reproducible until the snapshot is refreshed.2Noneh
isolated_homeNKeep the ocx store inside this repository instead of the shared user OCX_HOME.2False4
ocxThe pinned ocx CLI binary.2@ocx_tool//:ocxQ
packageBFully-qualified identifier: 'registry/repo[:tag][@sha256:â¦]'. w
pinsiocx platform key -> 'sha256:â¦' manifest digest overriding the digest of `package` for that platform.
2{}Z
platformHocx platform key ('linux/amd64', â¦) to provision for; empty = host.2""�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
resolved_platform�Real ocx platform sent to `-p` â lets a declared `platform` be aliased to a different real one (variant/feature build). Empty = derive from `platform`. Runnable-target gating compares its os/arch prefix to the host; `pins` still key on `platform`.2""*-
ocx_package_repo@@rules_ocx//ocx:defs.bzl
�#�#0
.
name"A unique name for this repository. �
�
bins�Lazy provisioning: names of the executables to expose (not validated at fetch time). When set, nothing is installed during the fetch â each name becomes a launcher re-entering `ocx package exec`, keyed on the digest-pinned reference. Requires a digest-pinned identity (`pins` or '@sha256:'); incompatible with isolated_home and index.2[]�
�
index�Committed ocx index snapshot directory (created with `ocx --index <dir> index update <package>`). When set, tag resolution is frozen to the snapshot (`--index --frozen`): floating tags become reproducible until the snapshot is refreshed.2Nonej
h
isolated_homeNKeep the ocx store inside this repository instead of the shared user OCX_HOME.2False6
4
ocxThe pinned ocx CLI binary.2@ocx_tool//:ocxS
Q
packageBFully-qualified identifier: 'registry/repo[:tag][@sha256:â¦]'. y
w
pinsiocx platform key -> 'sha256:â¦' manifest digest overriding the digest of `package` for that platform.
2{}\
Z
platformHocx platform key ('linux/amd64', â¦) to provision for; empty = host.2""�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
�
resolved_platform�Real ocx platform sent to `-p` â lets a declared `platform` be aliased to a different real one (variant/feature build). Empty = derive from `platform`. Runnable-target gating compares its os/arch prefix to the host; `pins` still key on `platform`.2""�-ocx_project_repo�	Provisions the toolchain declared in a workspace ocx.toml/ocx.lock.

Fails when the lockfile is stale or missing (fix with `ocx lock`). Every
executable reachable through the composed environment's `path` entries
becomes a runnable target `//:<name>`; the raw environment is loadable from
`//:env.bzl` (`OCX_ENV`, `OCX_HOME`).

With `bins`, provisioning is lazy: nothing is pulled at fetch time, and each
named executable becomes a launcher that re-enters `ocx run` â content
materializes on first execution and never becomes a Bazel action input, so
fully remote-cached builds download no tool content at all.

`groups` scopes both the pull and the composed environment. Omitted, ocx's
defaults apply: every group is pulled, but only the default `[tools]` table
is composed into launchers â name groups explicitly (or use the reserved
`all`) to expose their executables.

`platform` composes a foreign platform's environment from the same
ocx.lock: that platform's leaves are pulled into the store and `env.bzl`
holds their absolute store paths (sysroots, target libraries, container
image content). Foreign repos expose no runnable launchers â the binaries
do not run on this host.R�#
�
ocx_project_repo�	Provisions the toolchain declared in a workspace ocx.toml/ocx.lock.

Fails when the lockfile is stale or missing (fix with `ocx lock`). Every
executable reachable through the composed environment's `path` entries
becomes a runnable target `//:<name>`; the raw environment is loadable from
`//:env.bzl` (`OCX_ENV`, `OCX_HOME`).

With `bins`, provisioning is lazy: nothing is pulled at fetch time, and each
named executable becomes a launcher that re-enters `ocx run` â content
materializes on first execution and never becomes a Bazel action input, so
fully remote-cached builds download no tool content at all.

`groups` scopes both the pull and the composed environment. Omitted, ocx's
defaults apply: every group is pulled, but only the default `[tools]` table
is composed into launchers â name groups explicitly (or use the reserved
`all`) to expose their executables.

`platform` composes a foreign platform's environment from the same
ocx.lock: that platform's leaves are pulled into the store and `env.bzl`
holds their absolute store paths (sysroots, target libraries, container
image content). Foreign repos expose no runnable launchers â the binaries
do not run on this host..
name"A unique name for this repository. �
bins�Lazy provisioning: names of the executables to expose (not validated at fetch time). When set, nothing is pulled during the fetch â each name becomes a launcher re-entering `ocx run`, and actions key on the lockfile (a runfile) instead of tool content. Incompatible with isolated_home.2[]�
groups�ocx.toml groups to provision (comma-joined into `-g` for `ocx pull`, `ocx env`, and lazy `ocx run`). Reserved names: 'default' = the top-level [tools] table, 'all' = default + every declared group.2[]h
isolated_homeNKeep the ocx store inside this repository instead of the shared user OCX_HOME.2False4
ocxThe pinned ocx CLI binary.2@ocx_tool//:ocxO
ocx_lock?The ocx.lock next to ocx_toml; watched so lock changes refetch. =
ocx_toml-The project ocx.toml declaring the toolchain. �
platform�ocx platform key ('linux/arm64', â¦) to compose for; empty = host. A foreign platform pulls that platform's leaves from the same ocx.lock and exposes env.bzl only (no runnable launchers). Incompatible with bins â lazy launchers already resolve the executing host at run time.2""�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 *-
ocx_project_repo@@rules_ocx//ocx:defs.bzl
�#�#0
.
name"A unique name for this repository. �
�
bins�Lazy provisioning: names of the executables to expose (not validated at fetch time). When set, nothing is pulled during the fetch â each name becomes a launcher re-entering `ocx run`, and actions key on the lockfile (a runfile) instead of tool content. Incompatible with isolated_home.2[]�
�
groups�ocx.toml groups to provision (comma-joined into `-g` for `ocx pull`, `ocx env`, and lazy `ocx run`). Reserved names: 'default' = the top-level [tools] table, 'all' = default + every declared group.2[]j
h
isolated_homeNKeep the ocx store inside this repository instead of the shared user OCX_HOME.2False6
4
ocxThe pinned ocx CLI binary.2@ocx_tool//:ocxQ
O
ocx_lock?The ocx.lock next to ocx_toml; watched so lock changes refetch. ?
=
ocx_toml-The project ocx.toml declaring the toolchain. �
�
platform�ocx platform key ('linux/arm64', â¦) to compose for; empty = host. A foreign platform pulls that platform's leaves from the same ocx.lock and exposes env.bzl only (no runnable launchers). Incompatible with bins â lazy launchers already resolve the executing host at run time.2""�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
//ocx/private:download.bzlrc
&
	rules_ocxocx/privatedownload.bzl+
ocx_download_ocx_download
.;
M�
//ocx/private:package.bzlr�
%
	rules_ocxocx/privatepackage.bzl1
ocx_package_hub_ocx_package_hub
-=3
ocx_package_repo_ocx_package_repo
Sd
z�
//ocx/private:platforms.bzlr|
'
	rules_ocxocx/privateplatforms.bzlC
ocx_platform_constraints_ocx_platform_constraints
/H
f�
//ocx/private:project.bzlrj
%
	rules_ocxocx/privateproject.bzl3
ocx_project_repo_ocx_project_repo
->
T�Public API of rules_ocx.

Most consumers only need the `ocx` module extension
(`@rules_ocx//ocx:extensions.bzl`). The repository rules are re-exported
here for power users composing their own extensions on top of the same
CLI-backed provisioning.
�\
 
	rules_ocxocxextensions.bzl�Tocx�Provisions tools through the OCX package manager.

Always creates `@ocx_tool` (the pinned ocx CLI). `ocx.project()` provisions
a workspace toolchain from ocx.toml/ocx.lock; `ocx.package()` provisions
individual OCI packages. See the tag class docs for details.J�R
�
ocx�Provisions tools through the OCX package manager.

Always creates `@ocx_tool` (the pinned ocx CLI). `ocx.project()` provisions
a workspace toolchain from ocx.toml/ocx.lock; `ocx.package()` provisions
individual OCI packages. See the tag class docs for details.�
download?Overrides the ocx CLI bootstrap. Root module only; at most one.f
dist_manifestAdist.json release manifest snapshot to resolve the download from.2//dist:dist.jsonG
triple7Exact release target triple, overriding host detection.2""]
versionLExact ocx version (default: the version pinned with this rules_ocx release).2""�
package5Provisions a single OCX package from an OCI registry.P
nameDName of the generated repository (hub name when `platforms` is set). �
bins�Lazy provisioning: names of the executables to expose. When set, nothing is installed at fetch time â each name becomes a launcher re-entering `ocx package exec`, materializing the package on first execution. Requires a digest-pinned identity (`pins` or '@sha256:'); `//:content` is not available in lazy mode.2[]�
index�Committed ocx index snapshot directory (created with `ocx --index <dir> index update <package>`, refreshed the same way). When set, tag resolution is frozen to the snapshot â floating tags like ':latest' become reproducible until the snapshot is refreshed.2None_
isolated_homeEUse a repository-local ocx store instead of the shared user OCX_HOME.2False�
package�Fully-qualified identifier: 'registry/repo[:tag][@sha256:â¦]'. Freeze tag resolution with `index`, or pin per-platform manifest digests with `pins`. �
pins�Per-platform manifest pins: ocx platform key -> 'sha256:â¦' digest of that platform's manifest (as reported by `ocx package install -p <platform>`). The matching platform installs 'registry/repo@<digest>'; unpinned platforms fall back to `package`.
2{}�
platform_aliases�Optional declared-platform -> real-platform remap. Each key must appear in `platforms`; its value is the canonical ocx platform actually sent to `-p` and used to derive the hub's Bazel constraints. Everything Bazel-facing â repo suffix, `pins` lookup, config_setting, use_repo name â still keys on the declared platform; undeclared platforms are sent as-is. Example: {'linux/arm64': 'linux/arm64+libc.musl'} provisions a musl arm64 build under the plain 'linux/arm64' target.
2{}�
	platforms�ocx platform keys ('linux/amd64', â¦) to provision in addition to the host: creates '<name>_<slug>' repos plus a '<name>' hub whose //:content select()s by target platform. Empty = host only.2[]�
projectNProvisions the toolchain of a workspace ocx.toml + ocx.lock. Root module only.-
name!Name of the generated repository. �
bins�Lazy provisioning: names of the executables to expose. When set, nothing is pulled at fetch time â each name becomes a launcher re-entering `ocx run`, materializing the toolchain on first execution. Actions key on the lockfile, so fully remote-cached builds download no tool content.2[]�
groups�ocx.toml groups to provision (scopes both the pull and the composed environment). Reserved names: 'default' = the top-level [tools] table, 'all' = default + every group.2[]_
isolated_homeEUse a repository-local ocx store instead of the shared user OCX_HOME.2False@
ocx_lock0The committed ocx.lock (watched; edits refetch). %
ocx_tomlThe project ocx.toml. �
platform�ocx platform key ('linux/arm64', â¦) to compose for; empty = host. A foreign platform pulls that platform's leaves from the same ocx.lock and exposes env.bzl only (no runnable launchers). Incompatible with bins.2"""&
ocx@@rules_ocx//ocx:extensions.bzl
���
�
download?Overrides the ocx CLI bootstrap. Root module only; at most one.f
dist_manifestAdist.json release manifest snapshot to resolve the download from.2//dist:dist.jsonG
triple7Exact release target triple, overriding host detection.2""]
versionLExact ocx version (default: the version pinned with this rules_ocx release).2""h
f
dist_manifestAdist.json release manifest snapshot to resolve the download from.2//dist:dist.jsonI
G
triple7Exact release target triple, overriding host detection.2""_
]
versionLExact ocx version (default: the version pinned with this rules_ocx release).2""�
�
package5Provisions a single OCX package from an OCI registry.P
nameDName of the generated repository (hub name when `platforms` is set). �
bins�Lazy provisioning: names of the executables to expose. When set, nothing is installed at fetch time â each name becomes a launcher re-entering `ocx package exec`, materializing the package on first execution. Requires a digest-pinned identity (`pins` or '@sha256:'); `//:content` is not available in lazy mode.2[]�
index�Committed ocx index snapshot directory (created with `ocx --index <dir> index update <package>`, refreshed the same way). When set, tag resolution is frozen to the snapshot â floating tags like ':latest' become reproducible until the snapshot is refreshed.2None_
isolated_homeEUse a repository-local ocx store instead of the shared user OCX_HOME.2False�
package�Fully-qualified identifier: 'registry/repo[:tag][@sha256:â¦]'. Freeze tag resolution with `index`, or pin per-platform manifest digests with `pins`. �
pins�Per-platform manifest pins: ocx platform key -> 'sha256:â¦' digest of that platform's manifest (as reported by `ocx package install -p <platform>`). The matching platform installs 'registry/repo@<digest>'; unpinned platforms fall back to `package`.
2{}�
platform_aliases�Optional declared-platform -> real-platform remap. Each key must appear in `platforms`; its value is the canonical ocx platform actually sent to `-p` and used to derive the hub's Bazel constraints. Everything Bazel-facing â repo suffix, `pins` lookup, config_setting, use_repo name â still keys on the declared platform; undeclared platforms are sent as-is. Example: {'linux/arm64': 'linux/arm64+libc.musl'} provisions a musl arm64 build under the plain 'linux/arm64' target.
2{}�
	platforms�ocx platform keys ('linux/amd64', â¦) to provision in addition to the host: creates '<name>_<slug>' repos plus a '<name>' hub whose //:content select()s by target platform. Empty = host only.2[]R
P
nameDName of the generated repository (hub name when `platforms` is set). �
�
bins�Lazy provisioning: names of the executables to expose. When set, nothing is installed at fetch time â each name becomes a launcher re-entering `ocx package exec`, materializing the package on first execution. Requires a digest-pinned identity (`pins` or '@sha256:'); `//:content` is not available in lazy mode.2[]�
�
index�Committed ocx index snapshot directory (created with `ocx --index <dir> index update <package>`, refreshed the same way). When set, tag resolution is frozen to the snapshot â floating tags like ':latest' become reproducible until the snapshot is refreshed.2Nonea
_
isolated_homeEUse a repository-local ocx store instead of the shared user OCX_HOME.2False�
�
package�Fully-qualified identifier: 'registry/repo[:tag][@sha256:â¦]'. Freeze tag resolution with `index`, or pin per-platform manifest digests with `pins`. �
�
pins�Per-platform manifest pins: ocx platform key -> 'sha256:â¦' digest of that platform's manifest (as reported by `ocx package install -p <platform>`). The matching platform installs 'registry/repo@<digest>'; unpinned platforms fall back to `package`.
2{}�
�
platform_aliases�Optional declared-platform -> real-platform remap. Each key must appear in `platforms`; its value is the canonical ocx platform actually sent to `-p` and used to derive the hub's Bazel constraints. Everything Bazel-facing â repo suffix, `pins` lookup, config_setting, use_repo name â still keys on the declared platform; undeclared platforms are sent as-is. Example: {'linux/arm64': 'linux/arm64+libc.musl'} provisions a musl arm64 build under the plain 'linux/arm64' target.
2{}�
�
	platforms�ocx platform keys ('linux/amd64', â¦) to provision in addition to the host: creates '<name>_<slug>' repos plus a '<name>' hub whose //:content select()s by target platform. Empty = host only.2[]�
�
projectNProvisions the toolchain of a workspace ocx.toml + ocx.lock. Root module only.-
name!Name of the generated repository. �
bins�Lazy provisioning: names of the executables to expose. When set, nothing is pulled at fetch time â each name becomes a launcher re-entering `ocx run`, materializing the toolchain on first execution. Actions key on the lockfile, so fully remote-cached builds download no tool content.2[]�
groups�ocx.toml groups to provision (scopes both the pull and the composed environment). Reserved names: 'default' = the top-level [tools] table, 'all' = default + every group.2[]_
isolated_homeEUse a repository-local ocx store instead of the shared user OCX_HOME.2False@
ocx_lock0The committed ocx.lock (watched; edits refetch). %
ocx_tomlThe project ocx.toml. �
platform�ocx platform key ('linux/arm64', â¦) to compose for; empty = host. A foreign platform pulls that platform's leaves from the same ocx.lock and exposes env.bzl only (no runnable launchers). Incompatible with bins.2""/
-
name!Name of the generated repository. �
�
bins�Lazy provisioning: names of the executables to expose. When set, nothing is pulled at fetch time â each name becomes a launcher re-entering `ocx run`, materializing the toolchain on first execution. Actions key on the lockfile, so fully remote-cached builds download no tool content.2[]�
�
groups�ocx.toml groups to provision (scopes both the pull and the composed environment). Reserved names: 'default' = the top-level [tools] table, 'all' = default + every group.2[]a
_
isolated_homeEUse a repository-local ocx store instead of the shared user OCX_HOME.2FalseB
@
ocx_lock0The committed ocx.lock (watched; edits refetch). '
%
ocx_tomlThe project ocx.toml. �
�
platform�ocx platform key ('linux/arm64', â¦) to compose for; empty = host. A foreign platform pulls that platform's leaves from the same ocx.lock and exposes env.bzl only (no runnable launchers). Incompatible with bins.2""�
//ocx/private:download.bzlrb
&
	rules_ocxocx/privatedownload.bzl*
ocx_downloadocx_download
/;
=�
//ocx/private:package.bzlr�
%
	rules_ocxocx/privatepackage.bzl0
ocx_package_hubocx_package_hub
.=2
ocx_package_repoocx_package_repo
AQ4
resolve_platformsresolve_platforms
Uf
h�
//ocx/private:project.bzlri
%
	rules_ocxocx/privateproject.bzl2
ocx_project_repoocx_project_repo
.>
@�
//ocx/private:versions.bzlrp
&
	rules_ocxocx/privateversions.bzl8
DEFAULT_OCX_VERSIONDEFAULT_OCX_VERSION
/B
D�The `ocx` module extension.

Bootstraps the pinned ocx CLI (`@ocx_tool`) and declares repositories that
provision tools through it. The implementation is a pure function of the
tags â all host detection and environment access happens inside the
repository rules â so the extension is marked reproducible and stays out of
MODULE.bazel.lock.
 