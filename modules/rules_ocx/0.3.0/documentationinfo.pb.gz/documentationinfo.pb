�
&
	rules_ocxocx/privatedownload.bzl�ocx_download�Downloads a pinned ocx CLI release for the host platform.

The release row (URL + sha256) comes from the vendored `dist.json` snapshot
of `https://setup.ocx.sh/dist.json`. Corporate mirrors: set
`OCX_INSTALL_DIST_URL` to fetch a mirrored manifest instead, and/or
`OCX_INSTALL_MIRROR_URL` to rewrite the artifact download to
`<mirror>/<tag>/<filename>`. The manifest sha256 is enforced either way.R�
�	
ocx_download�Downloads a pinned ocx CLI release for the host platform.

The release row (URL + sha256) comes from the vendored `dist.json` snapshot
of `https://setup.ocx.sh/dist.json`. Corporate mirrors: set
`OCX_INSTALL_DIST_URL` to fetch a mirrored manifest instead, and/or
`OCX_INSTALL_MIRROR_URL` to rewrite the artifact download to
`<mirror>/<tag>/<filename>`. The manifest sha256 is enforced either way..
name"A unique name for this repository. T
dist_manifest/Release manifest snapshot (dist.json schema 1).2//dist:dist.json�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
triple�Escape hatch: exact release target triple, e.g. 'x86_64-unknown-linux-gnu' to prefer the glibc build. Defaults to host detection (Linux maps to musl).2""<
version-Exact ocx version to download, e.g. '0.3.10'. *5
ocx_download%@@rules_ocx//ocx/private:download.bzl
880
.
name"A unique name for this repository. V
T
dist_manifest/Release manifest snapshot (dist.json schema 1).2//dist:dist.json�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
�
triple�Escape hatch: exact release target triple, e.g. 'x86_64-unknown-linux-gnu' to prefer the glibc build. Defaults to host detection (Linux maps to musl).2"">
<
version-Exact ocx version to download, e.g. '0.3.10'. �
//ocx/private:manifest.bzlr�
&
	rules_ocxocx/privatemanifest.bzl*
archive_typearchive_type
/;*
artifact_urlartifact_url
?K.
select_releaseselect_release
O]
_~
//ocx/private:platforms.bzlr]
'
	rules_ocxocx/privateplatforms.bzl$
	host_info	host_info
09
;�Repository rule bootstrapping the pinned ocx CLI binary.

Downloads the release archive listed in the vendored dist.json snapshot
(sha256-enforced), honoring the same corporate-mirror knobs as the
setup.ocx.sh installer. Binary-only placement â never runs `ocx self setup`.
�
&
	rules_ocxocx/privatemanifest.bzl�archive_type�Maps a release filename to the explicit download_and_extract type.

ocx releases ship .zip (windows), .tar.gz (>= 0.4.3), and .tar.xz (older).
*�
�
archive_typeR
filenameBrelease row filename, e.g. "ocx-x86_64-unknown-linux-musl.tar.gz". (�Maps a release filename to the explicit download_and_extract type.

ocx releases ship .zip (windows), .tar.gz (>= 0.4.3), and .tar.xz (older).
"@
>Archive type string for repository_ctx.download_and_extract().25
archive_type%@@rules_ocx//ocx/private:manifest.bzl
!!�artifact_url�Resolves the download URL for a release row, honoring a mirror.

Mirrors relocate artifacts but never alter them: the caller must keep
enforcing row["sha256"]. Rewrite matches the setup.ocx.sh installer:
`<mirror>/<tag>/<filename>`.
*�
�
artifact_url/
row$a release row from select_release(). (>

mirror_url,value of OCX_INSTALL_MIRROR_URL, or None/"". (�Resolves the download URL for a release row, honoring a mirror.

Mirrors relocate artifacts but never alter them: the caller must keep
enforcing row["sha256"]. Rewrite matches the setup.ocx.sh installer:
`<mirror>/<tag>/<filename>`.
"
URL string.25
artifact_url%@@rules_ocx//ocx/private:manifest.bzl
22�select_release>Finds the manifest row for an exact version and target triple.*�
�
select_release)
manifestdecoded dist.json object. (0
version!exact ocx version, e.g. "0.3.10". (I
target;cargo-dist target triple, e.g. "x86_64-unknown-linux-musl". (>Finds the manifest row for an exact version and target triple.""
 The matching release row (dict).27
select_release%@@rules_ocx//ocx/private:manifest.bzl
�Pure helpers over the setup.ocx.sh dist.json release manifest.

Manifest schema (flat rows, schema 1):
    {"schema": 1, "latest": {...}, "releases": [
        {"version", "channel", "tag", "target", "filename", "sha256", "url"}, ...]}
�i
%
	rules_ocxocx/privatepackage.bzl�
pinned_ref=Applies the per-platform manifest pin for `platform`, if any.*�
�

pinned_refI
package:the fallback reference 'registry/repo[:tag][@sha256:…]'. (=
pins1{ocx platform key: 'sha256:…' manifest digest}. (@
platform0the ocx platform key this repository provisions. (=Applies the per-platform manifest pin for `platform`, if any."
the reference to install.22

pinned_ref$@@rules_ocx//ocx/private:package.bzl
TT�resolve_platforms�Validates aliases and maps each declared platform to its slug + real platform.

Every `aliases` key must be a declared platform; its value is the real ocx
platform sent to `-p`. Two declared platforms reducing to the same slug is an
error (they would collide on repo/config_setting names).
*�
�
resolve_platforms:
name.the ocx.package tag name (for error messages). (3
	platforms"the declared target platform keys. (G
aliases8{declared platform key: real ocx platform sent to `-p`}. (�Validates aliases and maps each declared platform to its slug + real platform.

Every `aliases` key must be a declared platform; its value is the real ocx
platform sent to `-p`. Two declared platforms reducing to the same slug is an
error (they would collide on repo/config_setting names).
"K
Istruct(error = "" | message, platforms = {slug: struct(declared, real)}).29
resolve_platforms$@@rules_ocx//ocx/private:package.bzl
ff�ocx_package_hub�Multi-platform hub for an ocx.package() with `platforms`.

`//:content` (or, with `bins`, each named launcher) select()s the
per-platform package repo matching the target platform â combine with a
platform transition to fetch foreign-platform tools (e.g. for container
images).R�
�
ocx_package_hub�Multi-platform hub for an ocx.package() with `platforms`.

`//:content` (or, with `bins`, each named launcher) select()s the
per-platform package repo matching the target platform â combine with a
platform transition to fetch foreign-platform tools (e.g. for container
images)..
name"A unique name for this repository. G
bins9Lazy mode: launcher names to alias instead of //:content.2[]r
platform_reals\repo slug -> real ocx platform, the source of each config_setting's Bazel constraint_values.
 R
platform_repos<repo slug -> apparent name of the per-platform package repo.
 �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 *7
ocx_package_hub$@@rules_ocx//ocx/private:package.bzl
�"�"0
.
name"A unique name for this repository. I
G
bins9Lazy mode: launcher names to alias instead of //:content.2[]t
r
platform_reals\repo slug -> real ocx platform, the source of each config_setting's Bazel constraint_values.
 T
R
platform_repos<repo slug -> apparent name of the per-platform package repo.
 �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �Bocx_package_repo�Provisions a single OCX package from an OCI registry.

`//:content` is the package tree; every executable the package declares as
its public surface (`ocx package inspect --closure`) becomes a runnable
target `//:<name>` (host-platform repos only). A package shipping no
complete `binaries` metadata falls back to scanning the composed PATH, which
also exposes its private executables â `//:env.bzl`'s `OCX_SCANNED_PACKAGES`
names the packages that forced it. For reproducibility, commit an index
snapshot and reference it
via `index` (tags then resolve frozen from the snapshot), or pin
per-platform manifest digests via `pins` â plain floating tags resolve at
fetch time and log the resolved digest.

With `bins`, provisioning is lazy: nothing is installed at fetch time, and
each named executable becomes a launcher re-entering `ocx package exec` â
content materializes on first execution and never becomes a Bazel action
input (`//:content` is not available in lazy mode).R�:
�!
ocx_package_repo�Provisions a single OCX package from an OCI registry.

`//:content` is the package tree; every executable the package declares as
its public surface (`ocx package inspect --closure`) becomes a runnable
target `//:<name>` (host-platform repos only). A package shipping no
complete `binaries` metadata falls back to scanning the composed PATH, which
also exposes its private executables â `//:env.bzl`'s `OCX_SCANNED_PACKAGES`
names the packages that forced it. For reproducibility, commit an index
snapshot and reference it
via `index` (tags then resolve frozen from the snapshot), or pin
per-platform manifest digests via `pins` â plain floating tags resolve at
fetch time and log the resolved digest.

With `bins`, provisioning is lazy: nothing is installed at fetch time, and
each named executable becomes a launcher re-entering `ocx package exec` â
content materializes on first execution and never becomes a Bazel action
input (`//:content` is not available in lazy mode)..
name"A unique name for this repository. �
bins�Lazy provisioning: names of the executables to expose (not validated at fetch time). When set, nothing is installed during the fetch â each name becomes a launcher re-entering `ocx package exec`, keyed on the digest-pinned reference. Requires a digest-pinned identity (`pins` or '@sha256:'); incompatible with isolated_home and index.2[]�
config�An ocx site config.toml (mirrors, registries, [patches]) layered over the host's discovered config â not the project ocx.toml. Sets OCX_CONFIG for every invocation, overriding an ambient one, and the file is watched. Combine with no_config for a hermetic configuration. With `bins` it is copied into the repository and uploaded as an input with every action â keep credentials out of it.2None�
index�Committed ocx index snapshot directory (created with `ocx --index <dir> index update <package>`). When set, tag resolution is frozen to the snapshot (`--index --frozen`): floating tags become reproducible until the snapshot is refreshed.2Noneh
isolated_homeNKeep the ocx store inside this repository instead of the shared user OCX_HOME.2False�
	no_config�Ignore the host's discovered config tiers (/etc, the user config, $OCX_HOME/config.toml) and the managed-config snapshot â sets OCX_NO_CONFIG=1, and blanks an ambient OCX_CONFIG, OCX_PATCHES and OCX_PATCH_SNAPSHOT, which OCX_NO_CONFIG alone does not prune. The `config` and `patch_snapshot` attrs still apply. Use this when a corporate managed config must not reach the build; it also opts out of the exit-78 gate a required-but-unsynced managed config raises.2False4
ocxThe pinned ocx CLI binary.2@ocx_tool//:ocxQ
packageBFully-qualified identifier: 'registry/repo[:tag][@sha256:â¦]'. �
patch_snapshot�A committed patches.snapshot.json (written by `ocx patch freeze` next to ocx.lock) freezing the digests of the patch companions composed onto this environment. Sets OCX_PATCH_SNAPSHOT. `ocx lock --check` does not cover companions â without a frozen snapshot they resolve at fetch time. With `bins` it is copied into the repository and uploaded as an input with every action â keep credentials out of it.2Nonew
pinsiocx platform key -> 'sha256:â¦' manifest digest overriding the digest of `package` for that platform.
2{}Z
platformHocx platform key ('linux/amd64', â¦) to provision for; empty = host.2""�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
resolved_platform�Real ocx platform sent to `-p` â lets a declared `platform` be aliased to a different real one (variant/feature build). Empty = derive from `platform`. Runnable-target gating compares its os/arch prefix to the host; `pins` still key on `platform`.2""*8
ocx_package_repo$@@rules_ocx//ocx/private:package.bzl
�#�#0
.
name"A unique name for this repository. �
�
bins�Lazy provisioning: names of the executables to expose (not validated at fetch time). When set, nothing is installed during the fetch â each name becomes a launcher re-entering `ocx package exec`, keyed on the digest-pinned reference. Requires a digest-pinned identity (`pins` or '@sha256:'); incompatible with isolated_home and index.2[]�
�
config�An ocx site config.toml (mirrors, registries, [patches]) layered over the host's discovered config â not the project ocx.toml. Sets OCX_CONFIG for every invocation, overriding an ambient one, and the file is watched. Combine with no_config for a hermetic configuration. With `bins` it is copied into the repository and uploaded as an input with every action â keep credentials out of it.2None�
�
index�Committed ocx index snapshot directory (created with `ocx --index <dir> index update <package>`). When set, tag resolution is frozen to the snapshot (`--index --frozen`): floating tags become reproducible until the snapshot is refreshed.2Nonej
h
isolated_homeNKeep the ocx store inside this repository instead of the shared user OCX_HOME.2False�
�
	no_config�Ignore the host's discovered config tiers (/etc, the user config, $OCX_HOME/config.toml) and the managed-config snapshot â sets OCX_NO_CONFIG=1, and blanks an ambient OCX_CONFIG, OCX_PATCHES and OCX_PATCH_SNAPSHOT, which OCX_NO_CONFIG alone does not prune. The `config` and `patch_snapshot` attrs still apply. Use this when a corporate managed config must not reach the build; it also opts out of the exit-78 gate a required-but-unsynced managed config raises.2False6
4
ocxThe pinned ocx CLI binary.2@ocx_tool//:ocxS
Q
packageBFully-qualified identifier: 'registry/repo[:tag][@sha256:â¦]'. �
�
patch_snapshot�A committed patches.snapshot.json (written by `ocx patch freeze` next to ocx.lock) freezing the digests of the patch companions composed onto this environment. Sets OCX_PATCH_SNAPSHOT. `ocx lock --check` does not cover companions â without a frozen snapshot they resolve at fetch time. With `bins` it is copied into the repository and uploaded as an input with every action â keep credentials out of it.2Noney
w
pinsiocx platform key -> 'sha256:â¦' manifest digest overriding the digest of `package` for that platform.
2{}\
Z
platformHocx platform key ('linux/amd64', â¦) to provision for; empty = host.2""�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
�
resolved_platform�Real ocx platform sent to `-p` â lets a declared `platform` be aliased to a different real one (variant/feature build). Empty = derive from `platform`. Runnable-target gating compares its os/arch prefix to the host; `pins` still key on `platform`.2""�
//ocx/private:platforms.bzlr�
'
	rules_ocxocx/privateplatforms.bzl$
	host_info	host_info
09B
ocx_platform_constraintsocx_platform_constraints
=U 
os_archos_arch
Y`
slugslug
dh
j�
//ocx/private:repo_utils.bzlr�
(
	rules_ocxocx/privaterepo_utils.bzl*
CONFIG_ATTRSCONFIG_ATTRS
0
EAGER_LAZY_MODEEAGER_LAZY_MODE
$
	bat_value	bat_value
0
check_bin_namescheck_bin_names
(
decode_jsondecode_json
,
discover_binsdiscover_bins
2
is_absolute_pathis_absolute_path
*
make_ocx_envmake_ocx_env
 
ocx_binocx_bin
.
render_env_bzlrender_env_bzl
>
render_launchers_buildrender_launchers_build
:
render_lazy_launcherrender_lazy_launcher
.
rlocation_pathrlocation_path
 
run_ocxrun_ocx
"
sh_quotesh_quote
4
stage_lazy_configstage_lazy_config
0
write_launcherswrite_launchers

	�Package-tier repository rules: provision a single OCI package via the ocx
CLI (`package install` â `package which` â `package env`), plus the
multi-platform hub that select()s between per-platform repos.�
'
	rules_ocxocx/privateplatforms.bzl�	host_info�Maps a host OS name and arch to ocx release and platform identifiers.

Linux maps to the musl triple: the ocx musl builds are static, run on any
libc, and are the same binaries ocx's own OCI publishing uses — so no
libc detection is needed.
*�
�
	host_infoP
os_nameA`repository_ctx.os.name`, e.g. "linux", "mac os x", "windows 10". (>
arch2`repository_ctx.os.arch`, e.g. "amd64", "aarch64". (�Maps a host OS name and arch to ocx release and platform identifiers.

Linux maps to the musl triple: the ocx musl builds are static, run on any
libc, and are the same binaries ocx's own OCI publishing uses — so no
libc detection is needed.
"�
�struct with fields:
triple: cargo-dist target triple of the ocx release artifact.
ocx_platform: ocx "os/arch" key for `-p` / ocx.lock.
is_windows: bool.
exe_ext: "" or ".exe".23
	host_info&@@rules_ocx//ocx/private:platforms.bzl
II�ocx_platform_constraints�Bazel constraint labels for the os/arch prefix of an ocx platform key.

'linux/arm64+libc.musl' -> ['@platforms//os:linux', '@platforms//cpu:aarch64'].
For toolchain authors composing exec_compatible_with; also the hub's source
of config_setting constraint_values. Fails on an unmappable os/arch.
*�
�
ocx_platform_constraintsH
platform8an ocx platform key ('os/arch[/variant][+feature,...]'). (�Bazel constraint labels for the os/arch prefix of an ocx platform key.

'linux/arm64+libc.musl' -> ['@platforms//os:linux', '@platforms//cpu:aarch64'].
For toolchain authors composing exec_compatible_with; also the hub's source
of config_setting constraint_values. Fails on an unmappable os/arch.
".
,[os_constraint_label, cpu_constraint_label].2B
ocx_platform_constraints&@@rules_ocx//ocx/private:platforms.bzl
,,�os_archJThe 'os/arch' prefix of a platform key (drops '/variant' and '+features').*�
�
os_arch
platform (JThe 'os/arch' prefix of a platform key (drops '/variant' and '+features').21
os_arch&@@rules_ocx//ocx/private:platforms.bzl
((�slug�Bazel-name-safe slug of an ocx platform key.

Lowercases, maps every non-[a-z0-9] run to a single '_', strips leading/
trailing '_'. 'linux/arm64+libc.musl' -> 'linux_arm64_libc_musl'.*�
�
slug
platform (�Bazel-name-safe slug of an ocx platform key.

Lowercases, maps every non-[a-z0-9] run to a single '_', strips leading/
trailing '_'. 'linux/arm64+libc.musl' -> 'linux_arm64_libc_musl'.2.
slug&@@rules_ocx//ocx/private:platforms.bzl
�Host platform detection and ocx platform-key mappings.

Pure functions on (os name, arch) strings so they are unit-testable; the
repository rules pass `repository_ctx.os.name` / `.arch` in.
�O
%
	rules_ocxocx/privateproject.bzl�Focx_project_repo�Provisions the toolchain declared in a workspace ocx.toml/ocx.lock.

Fails when the lockfile is stale or missing (fix with `ocx lock`). Every
executable the toolchain's packages declare as their public surface
(`ocx inspect --closure`) becomes a runnable target `//:<name>`; a package
shipping no complete `binaries` metadata falls back to scanning the composed
PATH, which also exposes its private executables â `//:env.bzl`'s
`OCX_SCANNED_PACKAGES` names the packages that forced it. The raw
environment is loadable from the same file (`OCX_ENV`, `OCX_HOME`).

With `bins`, provisioning is lazy: nothing is pulled at fetch time, and each
named executable becomes a launcher that re-enters `ocx run` â content
materializes on first execution and never becomes a Bazel action input, so
fully remote-cached builds download no tool content at all.

`groups` scopes both the pull and the composed environment. Omitted, ocx's
defaults apply: every group is pulled, but only the default `[tools]` table
is composed into launchers â name groups explicitly (or use the reserved
`all`) to expose their executables.

`platform` composes a foreign platform's environment from the same
ocx.lock: that platform's leaves are pulled into the store and `env.bzl`
holds their absolute store paths (sysroots, target libraries, container
image content). Foreign repos expose no runnable launchers â the binaries
do not run on this host.R�:
�#
ocx_project_repo�Provisions the toolchain declared in a workspace ocx.toml/ocx.lock.

Fails when the lockfile is stale or missing (fix with `ocx lock`). Every
executable the toolchain's packages declare as their public surface
(`ocx inspect --closure`) becomes a runnable target `//:<name>`; a package
shipping no complete `binaries` metadata falls back to scanning the composed
PATH, which also exposes its private executables â `//:env.bzl`'s
`OCX_SCANNED_PACKAGES` names the packages that forced it. The raw
environment is loadable from the same file (`OCX_ENV`, `OCX_HOME`).

With `bins`, provisioning is lazy: nothing is pulled at fetch time, and each
named executable becomes a launcher that re-enters `ocx run` â content
materializes on first execution and never becomes a Bazel action input, so
fully remote-cached builds download no tool content at all.

`groups` scopes both the pull and the composed environment. Omitted, ocx's
defaults apply: every group is pulled, but only the default `[tools]` table
is composed into launchers â name groups explicitly (or use the reserved
`all`) to expose their executables.

`platform` composes a foreign platform's environment from the same
ocx.lock: that platform's leaves are pulled into the store and `env.bzl`
holds their absolute store paths (sysroots, target libraries, container
image content). Foreign repos expose no runnable launchers â the binaries
do not run on this host..
name"A unique name for this repository. �
bins�Lazy provisioning: names of the executables to expose (not validated at fetch time). When set, nothing is pulled during the fetch â each name becomes a launcher re-entering `ocx run`, and actions key on the lockfile (a runfile) instead of tool content. Incompatible with isolated_home.2[]�
config�An ocx site config.toml (mirrors, registries, [patches]) layered over the host's discovered config â not the project ocx.toml. Sets OCX_CONFIG for every invocation, overriding an ambient one, and the file is watched. Combine with no_config for a hermetic configuration. With `bins` it is copied into the repository and uploaded as an input with every action â keep credentials out of it.2None�
groups�ocx.toml groups to provision (comma-joined into `-g` for `ocx pull`, `ocx env`, and lazy `ocx run`). Reserved names: 'default' = the top-level [tools] table, 'all' = default + every declared group.2[]h
isolated_homeNKeep the ocx store inside this repository instead of the shared user OCX_HOME.2False�
	no_config�Ignore the host's discovered config tiers (/etc, the user config, $OCX_HOME/config.toml) and the managed-config snapshot â sets OCX_NO_CONFIG=1, and blanks an ambient OCX_CONFIG, OCX_PATCHES and OCX_PATCH_SNAPSHOT, which OCX_NO_CONFIG alone does not prune. The `config` and `patch_snapshot` attrs still apply. Use this when a corporate managed config must not reach the build; it also opts out of the exit-78 gate a required-but-unsynced managed config raises.2False4
ocxThe pinned ocx CLI binary.2@ocx_tool//:ocxO
ocx_lock?The ocx.lock next to ocx_toml; watched so lock changes refetch. =
ocx_toml-The project ocx.toml declaring the toolchain. �
patch_snapshot�A committed patches.snapshot.json (written by `ocx patch freeze` next to ocx.lock) freezing the digests of the patch companions composed onto this environment. Sets OCX_PATCH_SNAPSHOT. `ocx lock --check` does not cover companions â without a frozen snapshot they resolve at fetch time. With `bins` it is copied into the repository and uploaded as an input with every action â keep credentials out of it.2None�
platform�ocx platform key ('linux/arm64', â¦) to compose for; empty = host. A foreign platform pulls that platform's leaves from the same ocx.lock and exposes env.bzl only (no runnable launchers). Incompatible with bins â lazy launchers already resolve the executing host at run time.2""�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 *8
ocx_project_repo$@@rules_ocx//ocx/private:project.bzl
�#�#0
.
name"A unique name for this repository. �
�
bins�Lazy provisioning: names of the executables to expose (not validated at fetch time). When set, nothing is pulled during the fetch â each name becomes a launcher re-entering `ocx run`, and actions key on the lockfile (a runfile) instead of tool content. Incompatible with isolated_home.2[]�
�
config�An ocx site config.toml (mirrors, registries, [patches]) layered over the host's discovered config â not the project ocx.toml. Sets OCX_CONFIG for every invocation, overriding an ambient one, and the file is watched. Combine with no_config for a hermetic configuration. With `bins` it is copied into the repository and uploaded as an input with every action â keep credentials out of it.2None�
�
groups�ocx.toml groups to provision (comma-joined into `-g` for `ocx pull`, `ocx env`, and lazy `ocx run`). Reserved names: 'default' = the top-level [tools] table, 'all' = default + every declared group.2[]j
h
isolated_homeNKeep the ocx store inside this repository instead of the shared user OCX_HOME.2False�
�
	no_config�Ignore the host's discovered config tiers (/etc, the user config, $OCX_HOME/config.toml) and the managed-config snapshot â sets OCX_NO_CONFIG=1, and blanks an ambient OCX_CONFIG, OCX_PATCHES and OCX_PATCH_SNAPSHOT, which OCX_NO_CONFIG alone does not prune. The `config` and `patch_snapshot` attrs still apply. Use this when a corporate managed config must not reach the build; it also opts out of the exit-78 gate a required-but-unsynced managed config raises.2False6
4
ocxThe pinned ocx CLI binary.2@ocx_tool//:ocxQ
O
ocx_lock?The ocx.lock next to ocx_toml; watched so lock changes refetch. ?
=
ocx_toml-The project ocx.toml declaring the toolchain. �
�
patch_snapshot�A committed patches.snapshot.json (written by `ocx patch freeze` next to ocx.lock) freezing the digests of the patch companions composed onto this environment. Sets OCX_PATCH_SNAPSHOT. `ocx lock --check` does not cover companions â without a frozen snapshot they resolve at fetch time. With `bins` it is copied into the repository and uploaded as an input with every action â keep credentials out of it.2None�
�
platform�ocx platform key ('linux/arm64', â¦) to compose for; empty = host. A foreign platform pulls that platform's leaves from the same ocx.lock and exposes env.bzl only (no runnable launchers). Incompatible with bins â lazy launchers already resolve the executing host at run time.2""�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 ~
//ocx/private:platforms.bzlr]
'
	rules_ocxocx/privateplatforms.bzl$
	host_info	host_info
	0	9
		;�
//ocx/private:repo_utils.bzlr�
(
	rules_ocxocx/privaterepo_utils.bzl*
CONFIG_ATTRSCONFIG_ATTRS
0
EAGER_LAZY_MODEEAGER_LAZY_MODE
$
	bat_value	bat_value
0
check_bin_namescheck_bin_names
(
decode_jsondecode_json
,
discover_binsdiscover_bins
*
make_ocx_envmake_ocx_env
 
ocx_binocx_bin
.
render_env_bzlrender_env_bzl
>
render_launchers_buildrender_launchers_build
:
render_lazy_launcherrender_lazy_launcher
.
rlocation_pathrlocation_path
 
run_ocxrun_ocx
"
sh_quotesh_quote
4
stage_lazy_configstage_lazy_config
0
write_launcherswrite_launchers


�Project-tier repository rule: provision the workspace toolchain from
ocx.toml + ocx.lock via the ocx CLI (`lock --check` â `pull` â `env`), or â
with `bins` â lazily via launchers that re-enter `ocx run` at execution
time.��
(
	rules_ocxocx/privaterepo_utils.bzl�	ambient_config_paths�The host config files ocx would load, in ocx precedence order.

Bazel cannot invalidate on a file it never reads, so the repository rules
watch every tier — including the ones that do not exist yet, since
`repository_ctx.watch()` registers absence too and creating the file
refetches. Pure function of plain values so tests can cover it.
*�
�
ambient_config_paths

is_windows
host flag. (<
is_macos,host flag (different user-config directory). (M
envB{var: value} for XDG_CONFIG_HOME, HOME and APPDATA; "" when unset. (�
home�the resolved OCX_HOME, or "" to drop the OCX_HOME-rooted tiers
(isolated_home puts them inside the repo being fetched, which
cannot be watched). (�The host config files ocx would load, in ocx precedence order.

Bazel cannot invalidate on a file it never reads, so the repository rules
watch every tier — including the ones that do not exist yet, since
`repository_ctx.watch()` registers absence too and creating the file
refetches. Pure function of plain values so tests can cover it.
"9
7list of absolute path strings, lowest precedence first.2?
ambient_config_paths'@@rules_ocx//ocx/private:repo_utils.bzl
���append_unique�`existing` with `value` folded onto the back, deduped on the separator.

Replays ocx's `utility::list::append_unique`: wrap `existing` in the
separator, delete every `separator + value + separator` occurrence to a
fixpoint, strip the wrapper, then append `value` at the back. Removing
*every* occurrence rather than the first is what keeps the fold idempotent
when the value already appears twice.

An empty `value` is a no-op — on an empty `existing` too, which is where a
list entry deliberately differs from a path one: appending nothing must not
bring the variable into existence.

Elements are opaque. Nothing is tokenized or trimmed: list element grammar
belongs to the consuming tool, never to ocx and never to rules_ocx.
*�
�
append_unique<
existing,the value folded so far; "" when nothing is. ((
valuethe contribution to append. (1
	separator the fold separator, never empty. (�`existing` with `value` folded onto the back, deduped on the separator.

Replays ocx's `utility::list::append_unique`: wrap `existing` in the
separator, delete every `separator + value + separator` occurrence to a
fixpoint, strip the wrapper, then append `value` at the back. Removing
*every* occurrence rather than the first is what keeps the fold idempotent
when the value already appears twice.

An empty `value` is a no-op — on an empty `existing` too, which is where a
list entry deliberately differs from a path one: appending nothing must not
bring the variable into existence.

Elements are opaque. Nothing is tokenized or trimmed: list element grammar
belongs to the consuming tool, never to ocx and never to rules_ocx.
"
the folded string.28
append_unique'@@rules_ocx//ocx/private:repo_utils.bzl
���	bat_value�A value safe inside a Batch `set "KEY=VALUE"`, or None if there is none.

`%` opens a variable expansion and `%%` is its literal spelling in a batch
file. A literal `"` closes the quoted region and has no in-place escape,
so such a value cannot be rendered at all.
*�
�
	bat_value
valuearbitrary string. (�A value safe inside a Batch `set "KEY=VALUE"`, or None if there is none.

`%` opens a variable expansion and `%%` is its literal spelling in a batch
file. A literal `"` closes the quoted region and has no in-place escape,
so such a value cannot be rendered at all.
"?
=the escaped value, or None when it cannot be rendered safely.24
	bat_value'@@rules_ocx//ocx/private:repo_utils.bzl
���check_bin_names�fail()s on a declared `bins` entry that cannot be rendered safely.

The lazy tiers render launchers straight from the `bins` attr, never
through discover_bins() — so the charset guard has to be applied here too.
A discovered name is dropped and recorded, but a name written into
`bins = [...]` was asked for by an ocx.package()/ocx.project() caller (any
module in the graph, not only the root), so dropping it would silently
produce a missing target instead of an answer.
*�
�
check_bin_names#
namesthe `bins` attr value. (�fail()s on a declared `bins` entry that cannot be rendered safely.

The lazy tiers render launchers straight from the `bins` attr, never
through discover_bins() — so the charset guard has to be applied here too.
A discovered name is dropped and recorded, but a name written into
`bins = [...]` was asked for by an ocx.package()/ocx.project() caller (any
module in the graph, not only the root), so dropping it would silently
produce a missing target instead of an answer.
2:
check_bin_names'@@rules_ocx//ocx/private:repo_utils.bzl
���#closure_packages�Validates and returns the `packages` list of an `inspect --closure` report.

Decodes `stdout` itself via decode_json(stdout, what), then validates the
result — one error vocabulary for the one command that produced it,
whether it failed by not being JSON or by being JSON of the wrong shape.

`InspectReport` always serializes its top-level `packages` key, and it is
an array — but a guard that only holds for today's shape is not a guard,
so the container is checked too: a report that is not an object, has no
`packages`, or whose `packages` is anything but a list fails here rather
than tracebacking out of a raw index (iterating an object would walk its
*keys*, and a string entry then has no `.get`).

What ocx omits conditionally is each entry's `closure`: `--closure` walks
the closure only for a resolved (`Manifest`/`Resolved`) body, so a binding
that came back as unresolved `candidates` — an ambiguous tag, or an
`ocx inspect` binding projected straight off ocx.lock with no single
artifact to walk — carries no `closure` at all. Each entry is therefore
checked too: it must be an object with an `identifier`, and its
`closure.surface.interface` must carry `binaries_complete` and the two
lists `binaries` and `entrypoints` — every key declared_bins() indexes
off a *package* entry, in the type it indexes it as. `SurfaceOut` always
serializes both arrays, so a missing `entrypoints` is shape drift, not an
empty claim. What is not guarded is `name` inside their elements: both
are `BinaryAttribution`, whose `name` is a non-`Option` `String`, so it
is always serialized, and a drift there would still traceback.
The fail() names DEFAULT_OCX_VERSION per invariant 4:
this is a shape drift between the pinned ocx and what rules_ocx parses,
not a mapped sysexit.

`install`/`which` reports never reach this function — their top-level
shape is `{"<raw>": {...}}`, not this report's `{"packages": [...],
...}` — so they play no part in the drift this guards against.
*�
�
closure_packagesL
stdout>raw stdout of an `ocx [package] inspect --closure` invocation. (�
what�the command string (e.g. "ocx inspect --closure"), passed to
decode_json() and reused in the fail() message — the same
convention decode_json() and project.bzl already use. Not
run_ocx()'s `what` (a human description like "reading the
declared tool surface of …"), which never reaches this function. (�Validates and returns the `packages` list of an `inspect --closure` report.

Decodes `stdout` itself via decode_json(stdout, what), then validates the
result — one error vocabulary for the one command that produced it,
whether it failed by not being JSON or by being JSON of the wrong shape.

`InspectReport` always serializes its top-level `packages` key, and it is
an array — but a guard that only holds for today's shape is not a guard,
so the container is checked too: a report that is not an object, has no
`packages`, or whose `packages` is anything but a list fails here rather
than tracebacking out of a raw index (iterating an object would walk its
*keys*, and a string entry then has no `.get`).

What ocx omits conditionally is each entry's `closure`: `--closure` walks
the closure only for a resolved (`Manifest`/`Resolved`) body, so a binding
that came back as unresolved `candidates` — an ambiguous tag, or an
`ocx inspect` binding projected straight off ocx.lock with no single
artifact to walk — carries no `closure` at all. Each entry is therefore
checked too: it must be an object with an `identifier`, and its
`closure.surface.interface` must carry `binaries_complete` and the two
lists `binaries` and `entrypoints` — every key declared_bins() indexes
off a *package* entry, in the type it indexes it as. `SurfaceOut` always
serializes both arrays, so a missing `entrypoints` is shape drift, not an
empty claim. What is not guarded is `name` inside their elements: both
are `BinaryAttribution`, whose `name` is a non-`Option` `String`, so it
is always serialized, and a drift there would still traceback.
The fail() names DEFAULT_OCX_VERSION per invariant 4:
this is a shape drift between the pinned ocx and what rules_ocx parses,
not a mapped sysexit.

`install`/`which` reports never reach this function — their top-level
shape is `{"<raw>": {...}}`, not this report's `{"packages": [...],
...}` — so they play no part in the drift this guards against.
" 
the validated `packages` list.2;
closure_packages'@@rules_ocx//ocx/private:repo_utils.bzl
���declared_bins�The public executable names an `inspect --closure` report claims.

`interface` is the surface a consumer sees on PATH; `private` holds the
package's internal executables, which never become targets.

A package's command surface is the *union* of `entrypoints` and
`binaries` — two parallel `BinaryAttribution` arrays that may claim the
same name (that overlap is the point: the generated `entrypoints/`
launcher shadows the raw `bin/` file). The union is deduped by name;
order here only sets target declaration order. *Which file* a name
resolves to is decided entirely by path_dirs()' search precedence in
resolve_bins() — the closure-wide surface flattens every admitted node,
so no concatenation order could mirror the composed PATH anyway.

`incomplete` is driven by `binaries_complete` alone: the flag covers only
`binaries`, and there is no entrypoints equivalent because the entrypoint
map keys are always authoritative.
*�
�
declared_binsS
packagesCthe `packages` list of an `ocx [package] inspect --closure`
report. (�The public executable names an `inspect --closure` report claims.

`interface` is the surface a consumer sees on PATH; `private` holds the
package's internal executables, which never become targets.

A package's command surface is the *union* of `entrypoints` and
`binaries` — two parallel `BinaryAttribution` arrays that may claim the
same name (that overlap is the point: the generated `entrypoints/`
launcher shadows the raw `bin/` file). The union is deduped by name;
order here only sets target declaration order. *Which file* a name
resolves to is decided entirely by path_dirs()' search precedence in
resolve_bins() — the closure-wide surface flattens every admitted node,
so no concatenation order could mirror the composed PATH anyway.

`incomplete` is driven by `binaries_complete` alone: the flag covers only
`binaries`, and there is no entrypoints equivalent because the entrypoint
map keys are always authoritative.
"�
�struct(names, incomplete): `names` in declaration order, deduped on
first occurrence (a name is one target however many surface entries
claim it — this picks a name string, not a PATH slot), `incomplete` the
identifiers of packages whose `binaries` claim is not complete. A
non-empty `incomplete` makes `names` a subset of what is really on
PATH, so the caller must fall back to scan_bins().28
declared_bins'@@rules_ocx//ocx/private:repo_utils.bzl
���decode_json=json.decode with an error message naming the failing command.*�
�
decode_json
stdout (

what (=json.decode with an error message naming the failing command.26
decode_json'@@rules_ocx//ocx/private:repo_utils.bzl
���discover_bins�Runnable tools for a fetched repo: the declared surface, else a PATH scan.

The fallback is not warned about per fetch — the metadata belongs to a
third-party package, so per-fetch noise is unactionable. It is recorded
instead: `scanned` names the packages that forced it, and the caller
renders it into the repo's env.bzl, where it stays inspectable.

Both discovery paths converge here, so this is also where names are
checked against valid_bin_name() — one guard covering every renderer
downstream. A rejected name is dropped rather than fatal: failing the
fetch would let one third-party package's metadata break an unrelated
consumer's build. It is recorded the same way `scanned` is.
*�

�

discover_bins
ctxrepository_ctx. (+
stdoutraw `inspect --closure` JSON. (�
what�the command that produced `stdout` — 'ocx inspect --closure' at
the project tier, 'ocx package inspect --closure' at the package
tier — reused verbatim in the shape-drift fail(). (*
entriesenv entries from `ocx env`. (

is_windows
host flag. (�Runnable tools for a fetched repo: the declared surface, else a PATH scan.

The fallback is not warned about per fetch — the metadata belongs to a
third-party package, so per-fetch noise is unactionable. It is recorded
instead: `scanned` names the packages that forced it, and the caller
renders it into the repo's env.bzl, where it stays inspectable.

Both discovery paths converge here, so this is also where names are
checked against valid_bin_name() — one guard covering every renderer
downstream. A rejected name is dropped rather than fatal: failing the
fetch would let one third-party package's metadata break an unrelated
consumer's build. It is recorded the same way `scanned` is.
"�
�struct(bins = [struct(name, target)], scanned = identifiers of the
packages whose incomplete metadata forced the PATH scan, rejected =
names dropped as unrenderable).28
discover_bins'@@rules_ocx//ocx/private:repo_utils.bzl
���
fold_listsBFolds the `list` entries of one env report into one value per key.*�
�

fold_lists�
entriestenv entries [{"key", "value", "type", "separator"?}, ...] that
already passed valid_env_key(), in declaration order. (BFolds the `list` entries of one env report into one value per key."e
c{key: struct(value, separator)} in first-declaration order, keys whose
fold came out empty omitted.25

fold_lists'@@rules_ocx//ocx/private:repo_utils.bzl
���is_absolute_path�Whether `path` is absolute for the given host.

POSIX: a leading `/`. Windows: two leading separators (`\\server\share`
or its forward-slash spelling `//server/share`, both UNC), or a drive
letter followed by `:` and a slash or backslash — a single leading
backslash alone is drive-relative, not absolute. Pure function of plain
values, so tests can cover it without a repository_ctx.

Closes only the relative-path case: `repository_ctx.watch()` also
rejects the broader class "path under the working directory", which this
predicate does not detect — an absolute OCX_HOME inside the workspace
still fails that check, which is why isolated_home passes "" instead of
a path rather than leaning on this predicate.
*�
�
is_absolute_path 
pathpath string to test. (

is_windows
host flag. (�Whether `path` is absolute for the given host.

POSIX: a leading `/`. Windows: two leading separators (`\\server\share`
or its forward-slash spelling `//server/share`, both UNC), or a drive
letter followed by `:` and a slash or backslash — a single leading
backslash alone is drive-relative, not absolute. Pure function of plain
values, so tests can cover it without a repository_ctx.

Closes only the relative-path case: `repository_ctx.watch()` also
rejects the broader class "path under the working directory", which this
predicate does not detect — an absolute OCX_HOME inside the workspace
still fails that check, which is why isolated_home passes "" instead of
a path rather than leaning on this predicate.
"
bool.2;
is_absolute_path'@@rules_ocx//ocx/private:repo_utils.bzl
���list_executables;Lists executable file names in a directory (non-recursive).*�
�
list_executables
ctxrepository_ctx. (0
	directoryabsolute directory path string. (m

is_windows[host flag; on Windows executables are picked by extension,
elsewhere by the executable bit. (;Lists executable file names in a directory (non-recursive)."%
#list of basenames, directory order.2;
list_executables'@@rules_ocx//ocx/private:repo_utils.bzl
���make_ocx_env�Assembles the environment for ocx invocations from this repo rule.

Also registers the host's ambient config tiers as watched inputs, so a
site config edit — including an `ocx config update` refreshing the managed
snapshot — refetches the repos that consumed it.
*�
�
make_ocx_envP
ctxErepository_ctx with `config`, `no_config` and `patch_snapshot` attrs. (
hosthost_info() struct. (l
isolated_homeWif True, keep the ocx store inside this repository
instead of the shared user OCX_HOME. (�Assembles the environment for ocx invocations from this repo rule.

Also registers the host's ambient config tiers as watched inputs, so a
site config edit — including an `ocx config update` refreshing the managed
snapshot — refetches the repos that consumed it.
"J
Hstruct(env = dict for repository_ctx.execute, home = resolved OCX_HOME).27
make_ocx_env'@@rules_ocx//ocx/private:repo_utils.bzl
���ocx_bin�Resolves the ocx binary path from the rule's `ocx` label attribute.

On Windows the executable lives next to the stable `ocx` file as
`ocx.exe`; prefer it when present.
*�
�
ocx_bin3
ctx(repository_ctx with an `ocx` label attr. (�Resolves the ocx binary path from the rule's `ocx` label attribute.

On Windows the executable lives next to the stable `ocx` file as
`ocx.exe`; prefer it when present.
"*
(path object of the executable to invoke.22
ocx_bin'@@rules_ocx//ocx/private:repo_utils.bzl
���	path_dirs�	The executable search path an `ocx env` report composes.

`path`-typed entries carry every colon-list a package contributes, not
just PATH: LD_LIBRARY_PATH, MANPATH and PKG_CONFIG_PATH have the same
type and name directories holding libraries and man pages, so searching
them for tools invents targets from whatever happens to be executable
there. Only PATH answers "where do this environment's commands live".

The key is compared case-insensitively: ocx serializes it verbatim from
package metadata, and a package declaring `Path` would otherwise
contribute nothing and silently yield zero discovered bins.

The result is **reversed**: an ocx consumer applies entries by prepending
each one in list order (move-to-front), so the last declared PATH entry
ends up first in the resolved PATH. Reversing here, combined with the
first-hit-wins scans in resolve_bins()/scan_bins(), reproduces
move-to-front exactly. Forward order would let `bin/` shadow the
`entrypoints/` entry ocx deliberately pushes last.

An empty value is dropped, as ocx's move_to_front drops it — joined
verbatim it would probe `"/" + name` here and put an empty PATH element
(the action's CWD) into launchers.
*�
�
	path_dirsJ
entries;env entries [{"key", "value", "type"}, ...] from `ocx env`. (�	The executable search path an `ocx env` report composes.

`path`-typed entries carry every colon-list a package contributes, not
just PATH: LD_LIBRARY_PATH, MANPATH and PKG_CONFIG_PATH have the same
type and name directories holding libraries and man pages, so searching
them for tools invents targets from whatever happens to be executable
there. Only PATH answers "where do this environment's commands live".

The key is compared case-insensitively: ocx serializes it verbatim from
package metadata, and a package declaring `Path` would otherwise
contribute nothing and silently yield zero discovered bins.

The result is **reversed**: an ocx consumer applies entries by prepending
each one in list order (move-to-front), so the last declared PATH entry
ends up first in the resolved PATH. Reversing here, combined with the
first-hit-wins scans in resolve_bins()/scan_bins(), reproduces
move-to-front exactly. Forward order would let `bin/` shadow the
`entrypoints/` entry ocx deliberately pushes last.

An empty value is dropped, as ocx's move_to_front drops it — joined
verbatim it would probe `"/" + name` here and put an empty PATH element
(the action's CWD) into launchers.
"`
^list of directory path strings, in search-precedence order (the
reverse of declaration order).24
	path_dirs'@@rules_ocx//ocx/private:repo_utils.bzl
���render_env_bzldRenders the generated repo's env.bzl.

JSON round-trip keeps escaping correct for arbitrary values.
*�
�
render_env_bzl*
entriesenv entries from `ocx env`. (
homeresolved OCX_HOME. (}
scannedlidentifiers of packages whose incomplete `binaries` metadata
forced the PATH scan (discover_bins().scanned).[](P
rejected>tool names dropped as unrenderable (discover_bins().rejected).[](dRenders the generated repo's env.bzl.

JSON round-trip keeps escaping correct for arbitrary values.
"
env.bzl content string.29
render_env_bzl'@@rules_ocx//ocx/private:repo_utils.bzl
�	�	�render_launcher�Renders a launcher script applying the ocx env and exec-ing a tool.

`path` entries prepend to the invoking environment, `constant` entries
replace, and `list` entries append behind it — the three `ModifierKind`s
ocx serializes. An unrecognized `type` is shape drift and fails: folding it
into a constant would silently *replace* an environment ocx would have
extended. OCX_HOME and OCX_BINARY_PIN are baked so ocx entrypoint
launchers re-enter the pinned ocx against the right store.

A `list` key is emitted as a conditional: ocx's fold appends behind the
ambient value and yields the bare value when there is none, so a launcher
that always joined would leave a leading separator on an unset key. The
declared contributions are folded against each other here; the ambient
value is not deduped against them, exactly as the `path` line does not
dedupe against the invoking `PATH`.

An ocx consumer applies each `path` entry by prepending it with
move-to-front dedup, so the *last* entry for a key ends up first. The
single value baked here is therefore the reverse of declaration order,
deduped keeping the first occurrence in that reversed order, empty
values dropped — the same string move-to-front produces for the
one-directory-per-entry values ocx emits (an empty value joined verbatim
would be an empty PATH element: the action's CWD).

Every value here is publisher-controlled: `ocx env` serializes keys and
values straight out of package metadata, and even the exec target is a
declared name joined onto a PATH directory that same metadata contributed.
So keys are validated and dropped when unusable, and values are quoted —
losslessly on POSIX, and on Windows by the one escape `set "K=V"` has.
*�
�
render_launcherI
entries:env entries [{"key", "value", "type", "separator"?}, ...]. (6
target(absolute path of the executable to exec. (
homeresolved OCX_HOME. (2
ocx'absolute path of the pinned ocx binary. (2

is_windows render .bat instead of POSIX sh. (�Renders a launcher script applying the ocx env and exec-ing a tool.

`path` entries prepend to the invoking environment, `constant` entries
replace, and `list` entries append behind it — the three `ModifierKind`s
ocx serializes. An unrecognized `type` is shape drift and fails: folding it
into a constant would silently *replace* an environment ocx would have
extended. OCX_HOME and OCX_BINARY_PIN are baked so ocx entrypoint
launchers re-enter the pinned ocx against the right store.

A `list` key is emitted as a conditional: ocx's fold appends behind the
ambient value and yields the bare value when there is none, so a launcher
that always joined would leave a leading separator on an unset key. The
declared contributions are folded against each other here; the ambient
value is not deduped against them, exactly as the `path` line does not
dedupe against the invoking `PATH`.

An ocx consumer applies each `path` entry by prepending it with
move-to-front dedup, so the *last* entry for a key ends up first. The
single value baked here is therefore the reverse of declaration order,
deduped keeping the first occurrence in that reversed order, empty
values dropped — the same string move-to-front produces for the
one-directory-per-entry values ocx emits (an empty value joined verbatim
would be an empty PATH element: the action's CWD).

Every value here is publisher-controlled: `ocx env` serializes keys and
values straight out of package metadata, and even the exec target is a
declared name joined onto a PATH directory that same metadata contributed.
So keys are validated and dropped when unusable, and values are quoted —
losslessly on POSIX, and on Windows by the one escape `set "K=V"` has.
"
script content string.2:
render_launcher'@@rules_ocx//ocx/private:repo_utils.bzl
���render_launchers_buildERenders a generated BUILD file exposing one runnable target per tool.*�
�
render_launchers_build:
bins.list of struct(name, target) from scan_bins(). (L

is_windows:host flag (launcher extension and native_binary out name). (:
extra+additional BUILD content appended verbatim.""(�
data�label strings attached as runfiles to every launcher (lazy
launchers carry the ocx binary and project files this way, making
them action inputs).[](ERenders a generated BUILD file exposing one runnable target per tool."
BUILD file content string.2A
render_launchers_build'@@rules_ocx//ocx/private:repo_utils.bzl
�	�	�render_lazy_launcher�Renders a lazy launcher: ocx is re-entered at execution time.

No store paths are baked in — the wrapped ocx command auto-installs
missing content on first use, so the action key is the script text plus
its runfiles, never the tool content itself. POSIX scripts locate their
inputs through the runfiles library, keeping the text identical across
machines (portable remote-cache keys).

OCX_PROJECT and OCX_GLOBAL are neutralized first: every command rendered
here passes an explicit `--project` (or a digest-pinned reference), and
ocx refuses to combine either ambient value with one — so an inherited
OCX_GLOBAL would fail the action with a raw ocx usage error. The fetch
path neutralizes the same pair via _OCX_NEUTRALIZED_ENV, with the same
values: OCX_GLOBAL is a BooleanString, so "0" and not "" (which ocx logs
as an invalid boolean on every launcher-run tool).
*�
�
render_lazy_launcherr
commandcpre-quoted argv fragments; POSIX fragments may use
`$(rlocation …)` — the preamble provides it. (�

is_windows�render .bat instead of POSIX sh. Windows launchers bake
absolute paths (no Batch runfiles library), so their action keys
are machine-local. (�
exports�env vars set before the command, in insertion order (stable
action keys). POSIX values may use `$(rlocation …)` too — the
template quotes them.{}(�Renders a lazy launcher: ocx is re-entered at execution time.

No store paths are baked in — the wrapped ocx command auto-installs
missing content on first use, so the action key is the script text plus
its runfiles, never the tool content itself. POSIX scripts locate their
inputs through the runfiles library, keeping the text identical across
machines (portable remote-cache keys).

OCX_PROJECT and OCX_GLOBAL are neutralized first: every command rendered
here passes an explicit `--project` (or a digest-pinned reference), and
ocx refuses to combine either ambient value with one — so an inherited
OCX_GLOBAL would fail the action with a raw ocx usage error. The fetch
path neutralizes the same pair via _OCX_NEUTRALIZED_ENV, with the same
values: OCX_GLOBAL is a BooleanString, so "0" and not "" (which ocx logs
as an invalid boolean on every launcher-run tool).
"
script content string.2?
render_lazy_launcher'@@rules_ocx//ocx/private:repo_utils.bzl
���resolve_bins�Locates each declared executable on the composed PATH.

A declared binary is a name, not a path, so the concrete file is found the
way a shell would: first PATH directory holding it wins. A claimed name
that no directory holds is dropped — the claim is publisher-declared and
unverified.
*�
�
resolve_bins
ctxrepository_ctx. (v
namesideclared executable names; order only orders the result —
resolution precedence comes from path_dirs(). (J
entries;env entries [{"key", "value", "type"}, ...] from `ocx env`. (D

is_windows2host flag; Windows executables carry an extension. (�Locates each declared executable on the composed PATH.

A declared binary is a name, not a path, so the concrete file is found the
way a shell would: first PATH directory holding it wins. A claimed name
that no directory holds is dropped — the claim is publisher-declared and
unverified.
"A
?list of struct(name, target) where target is the absolute path.27
resolve_bins'@@rules_ocx//ocx/private:repo_utils.bzl
���rlocation_pathFRunfiles-lookup key ('<canonical repo>/<package>/<name>') for a label.*�
�
rlocation_pathD
label7a resolved Label (e.g. the value of a label attribute). (FRunfiles-lookup key ('<canonical repo>/<package>/<name>') for a label.">
<the key accepted by the Bash runfiles library's `rlocation`.29
rlocation_path'@@rules_ocx//ocx/private:repo_utils.bzl
���run_ocx:Runs the ocx CLI, mapping failures to actionable messages.*�
�
run_ocx
ctxrepository_ctx. ()
binarypath of the ocx executable. ("
argsargv after the binary. (6
env+environment dict (from make_ocx_env().env). (;
what/short human description used in error messages. (G

is_windows5host flag (from host_info()); Windows has no `sleep`. (H
hints9{exit_code: extra hint} overriding the sysexits defaults.{}(�
retries�extra attempts after a *transient* failure (_RETRYABLE — any
other sysexit is settled on the first answer and fails at once).
Repo rules fetch in parallel, and concurrent `ocx package install`
calls of the same package can race on store symlink creation (ocx
TOCTOU); the store is idempotent, so a retry converges. A sysexit
75 is retried regardless — it is ocx's own "transient, retry me",
raised when the registry times out or reports capacity exceeded.
Attempts are spaced by a linear backoff.0(:Runs the ocx CLI, mapping failures to actionable messages."
stdout string.22
run_ocx'@@rules_ocx//ocx/private:repo_utils.bzl
���	scan_bins�Discovers runnable tools by scanning the composed PATH.

The fallback for packages that declare no complete `binaries` metadata.
Mirrors ocx PATH semantics: path_dirs() hands back search-precedence
order (declaration order reversed, because ocx prepends each entry), and
the first name found wins. Windows binaries are keyed by their
extension-less name.
*�
�
	scan_bins
ctxrepository_ctx. (J
entries;env entries [{"key", "value", "type"}, ...] from `ocx env`. (

is_windows
host flag. (�Discovers runnable tools by scanning the composed PATH.

The fallback for packages that declare no complete `binaries` metadata.
Mirrors ocx PATH semantics: path_dirs() hands back search-precedence
order (declaration order reversed, because ocx prepends each entry), and
the first name found wins. Windows binaries are keyed by their
extension-less name.
"l
jlist of struct(name, target) in discovery order, where target is the
absolute path of the real executable.24
	scan_bins'@@rules_ocx//ocx/private:repo_utils.bzl
���sh_quote�A POSIX shell word that expands to exactly `value`.

Single quotes suppress every expansion; the only character they cannot
carry is `'` itself, spelled by closing, escaping and reopening.
*�
�
sh_quote
valuearbitrary string. (�A POSIX shell word that expands to exactly `value`.

Single quotes suppress every expansion; the only character they cannot
carry is `'` itself, spelled by closing, escaping and reopening.
"(
&the quoted word, including its quotes.23
sh_quote'@@rules_ocx//ocx/private:repo_utils.bzl
���	stage_lazy_config�Stages the config attrs into the repo for lazy launchers to re-export.

A lazy launcher re-enters ocx at action time with ambient environment
only, so fetch-time configuration would never reach it. Copying the files
into the repo makes them runfiles — action inputs, so an edit re-keys the
actions — and `ctx.read` registers the watch that refetches the repo.
*�
�
stage_lazy_configP
ctxErepository_ctx with `config`, `no_config` and `patch_snapshot` attrs. (h

is_windowsVhost flag; Windows launchers bake absolute paths, POSIX
ones resolve through runfiles. (�Stages the config attrs into the repo for lazy launchers to re-export.

A lazy launcher re-enters ocx at action time with ambient environment
only, so fetch-time configuration would never reach it. Copying the files
into the repo makes them runfiles — action inputs, so an edit re-keys the
actions — and `ctx.read` registers the watch that refetches the repo.
"p
nstruct(exports = {env var: value} for render_lazy_launcher,
data = label strings to attach to every launcher).2<
stage_lazy_config'@@rules_ocx//ocx/private:repo_utils.bzl
���truthy�Whether an ocx-style boolean string env value is true.

Mirrors ocx's `BooleanString` set, case-insensitively; `None` (unset) is
false. An unrecognized value (neither the truthy set nor one of ocx's
falsy strings) is not an error on this path: `env::flag()` logs "has
invalid boolean value" and falls back to the flag's default, which is
false for every flag read here — the same warning `_OCX_NEUTRALIZED_ENV`
above avoids by passing "0" rather than "". Returning False therefore
matches what ocx itself does with the value, which still reaches the real
invocation. (`InvalidBooleanString` (exit 65) is the config-file path,
not the env one.)
*�
�
truthy'
valuestring env value, or None. (�Whether an ocx-style boolean string env value is true.

Mirrors ocx's `BooleanString` set, case-insensitively; `None` (unset) is
false. An unrecognized value (neither the truthy set nor one of ocx's
falsy strings) is not an error on this path: `env::flag()` logs "has
invalid boolean value" and falls back to the flag's default, which is
false for every flag read here — the same warning `_OCX_NEUTRALIZED_ENV`
above avoids by passing "0" rather than "". Returning False therefore
matches what ocx itself does with the value, which still reaches the real
invocation. (`InvalidBooleanString` (exit 65) is the config-file path,
not the env one.)
"
bool.21
truthy'@@rules_ocx//ocx/private:repo_utils.bzl
���valid_bin_name�Whether a discovered tool name is safe to render verbatim.

The name reaches three sinks unescaped — `native_binary(name = "…")` in a
generated BUILD file, a launcher's shell text, and the `launchers/<name>`
path written for it — so one charset covers all three. A leading `-` is
refused because the name is also passed as an argv word (`ocx run -- …`),
and `.`/`..` because it is a path component, though both are made of
admitted characters.
*�
�
valid_bin_name4
name(the declared or scanned executable name. (�Whether a discovered tool name is safe to render verbatim.

The name reaches three sinks unescaped — `native_binary(name = "…")` in a
generated BUILD file, a launcher's shell text, and the `launchers/<name>`
path written for it — so one charset covers all three. A leading `-` is
refused because the name is also passed as an argv word (`ocx run -- …`),
and `.`/`..` because it is a path component, though both are made of
admitted characters.
"
bool.29
valid_bin_name'@@rules_ocx//ocx/private:repo_utils.bzl
���valid_env_key�Whether an `ocx env` entry key is a usable environment variable name.

`ocx` serializes the key verbatim from package metadata; anything outside
the POSIX portable set has no safe `export`/`set` spelling at all.
*�
�
valid_env_key
keythe entry's `key`. (�Whether an `ocx env` entry key is a usable environment variable name.

`ocx` serializes the key verbatim from package metadata; anything outside
the POSIX portable set has no safe `export`/`set` spelling at all.
"
bool.28
valid_env_key'@@rules_ocx//ocx/private:repo_utils.bzl
���write_launchers1Writes launcher scripts for all discovered tools.*�
�
write_launchers
ctxrepository_ctx. (:
bins.list of struct(name, target) from scan_bins(). (5
entries&env entries applied by every launcher. (
homeresolved OCX_HOME. (9
ocx.absolute path string of the pinned ocx binary. (

is_windows
host flag. (1Writes launcher scripts for all discovered tools.2:
write_launchers'@@rules_ocx//ocx/private:repo_utils.bzl
�	�	�	UNKNOWN_MODIFIER_MSG�rules_ocx: ocx env reported modifier type '{}' for '{}' â the pinned ocx CLI and rules_ocx disagree on the report shape. Move DEFAULT_OCX_VERSION (ocx/private/versions.bzl) to an ocx release this rules_ocx parses, or upgrade rules_ocx.j��rules_ocx: ocx env reported modifier type '{}' for '{}' â the pinned ocx CLI and rules_ocx disagree on the report shape. Move DEFAULT_OCX_VERSION (ocx/private/versions.bzl) to an ocx release this rules_ocx parses, or upgrade rules_ocx./	EAGER_LAZY_MODEj2
--lazy-mode
never�	OCX_PASSTHROUGH_ENVj�2�
OCX_MIRRORS
OCX_INSECURE_REGISTRIES
OCX_OFFLINE

OCX_FROZEN

OCX_REMOTE

OCX_JOBS
	OCX_INDEX
OCX_DEFAULT_REGISTRY

OCX_CONFIG
OCX_NO_CONFIG
OCX_MANAGED_CONFIG
OCX_ALLOW_YANKED
OCX_PATCHES
OCX_PATCH_SNAPSHOT�Shared plumbing for repository rules that shell out to the ocx CLI.

Everything that can be a pure function of plain values (launcher rendering,
env-file rendering) is one, so tests/ can cover it without a repository_ctx.
�
&
	rules_ocxocx/privateversions.bzl'	DEFAULT_OCX_VERSION0.5.8j0.5.8�Pinned default ocx CLI version.

The ocx CLI declares no stability for its command-line surface across
versions; rules_ocx therefore pins an exact version and is tested against
exactly that version. Bump deliberately, together with dist/dist.json.
��

	rules_ocxocxdefs.bzl�ocx_platform_constraints�Bazel constraint labels for the os/arch prefix of an ocx platform key.

'linux/arm64+libc.musl' -> ['@platforms//os:linux', '@platforms//cpu:aarch64'].
For toolchain authors composing exec_compatible_with; also the hub's source
of config_setting constraint_values. Fails on an unmappable os/arch.
*�
�
ocx_platform_constraintsH
platform8an ocx platform key ('os/arch[/variant][+feature,...]'). (�Bazel constraint labels for the os/arch prefix of an ocx platform key.

'linux/arm64+libc.musl' -> ['@platforms//os:linux', '@platforms//cpu:aarch64'].
For toolchain authors composing exec_compatible_with; also the hub's source
of config_setting constraint_values. Fails on an unmappable os/arch.
".
,[os_constraint_label, cpu_constraint_label].2B
ocx_platform_constraints&@@rules_ocx//ocx/private:platforms.bzl
,,�ocx_download�Downloads a pinned ocx CLI release for the host platform.

The release row (URL + sha256) comes from the vendored `dist.json` snapshot
of `https://setup.ocx.sh/dist.json`. Corporate mirrors: set
`OCX_INSTALL_DIST_URL` to fetch a mirrored manifest instead, and/or
`OCX_INSTALL_MIRROR_URL` to rewrite the artifact download to
`<mirror>/<tag>/<filename>`. The manifest sha256 is enforced either way.R�
�	
ocx_download�Downloads a pinned ocx CLI release for the host platform.

The release row (URL + sha256) comes from the vendored `dist.json` snapshot
of `https://setup.ocx.sh/dist.json`. Corporate mirrors: set
`OCX_INSTALL_DIST_URL` to fetch a mirrored manifest instead, and/or
`OCX_INSTALL_MIRROR_URL` to rewrite the artifact download to
`<mirror>/<tag>/<filename>`. The manifest sha256 is enforced either way..
name"A unique name for this repository. T
dist_manifest/Release manifest snapshot (dist.json schema 1).2//dist:dist.json�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
triple�Escape hatch: exact release target triple, e.g. 'x86_64-unknown-linux-gnu' to prefer the glibc build. Defaults to host detection (Linux maps to musl).2""<
version-Exact ocx version to download, e.g. '0.3.10'. *)
ocx_download@@rules_ocx//ocx:defs.bzl
880
.
name"A unique name for this repository. V
T
dist_manifest/Release manifest snapshot (dist.json schema 1).2//dist:dist.json�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
�
triple�Escape hatch: exact release target triple, e.g. 'x86_64-unknown-linux-gnu' to prefer the glibc build. Defaults to host detection (Linux maps to musl).2"">
<
version-Exact ocx version to download, e.g. '0.3.10'. �ocx_package_hub�Multi-platform hub for an ocx.package() with `platforms`.

`//:content` (or, with `bins`, each named launcher) select()s the
per-platform package repo matching the target platform â combine with a
platform transition to fetch foreign-platform tools (e.g. for container
images).R�
�
ocx_package_hub�Multi-platform hub for an ocx.package() with `platforms`.

`//:content` (or, with `bins`, each named launcher) select()s the
per-platform package repo matching the target platform â combine with a
platform transition to fetch foreign-platform tools (e.g. for container
images)..
name"A unique name for this repository. G
bins9Lazy mode: launcher names to alias instead of //:content.2[]r
platform_reals\repo slug -> real ocx platform, the source of each config_setting's Bazel constraint_values.
 R
platform_repos<repo slug -> apparent name of the per-platform package repo.
 �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 *,
ocx_package_hub@@rules_ocx//ocx:defs.bzl
�"�"0
.
name"A unique name for this repository. I
G
bins9Lazy mode: launcher names to alias instead of //:content.2[]t
r
platform_reals\repo slug -> real ocx platform, the source of each config_setting's Bazel constraint_values.
 T
R
platform_repos<repo slug -> apparent name of the per-platform package repo.
 �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �Bocx_package_repo�Provisions a single OCX package from an OCI registry.

`//:content` is the package tree; every executable the package declares as
its public surface (`ocx package inspect --closure`) becomes a runnable
target `//:<name>` (host-platform repos only). A package shipping no
complete `binaries` metadata falls back to scanning the composed PATH, which
also exposes its private executables â `//:env.bzl`'s `OCX_SCANNED_PACKAGES`
names the packages that forced it. For reproducibility, commit an index
snapshot and reference it
via `index` (tags then resolve frozen from the snapshot), or pin
per-platform manifest digests via `pins` â plain floating tags resolve at
fetch time and log the resolved digest.

With `bins`, provisioning is lazy: nothing is installed at fetch time, and
each named executable becomes a launcher re-entering `ocx package exec` â
content materializes on first execution and never becomes a Bazel action
input (`//:content` is not available in lazy mode).R�:
�!
ocx_package_repo�Provisions a single OCX package from an OCI registry.

`//:content` is the package tree; every executable the package declares as
its public surface (`ocx package inspect --closure`) becomes a runnable
target `//:<name>` (host-platform repos only). A package shipping no
complete `binaries` metadata falls back to scanning the composed PATH, which
also exposes its private executables â `//:env.bzl`'s `OCX_SCANNED_PACKAGES`
names the packages that forced it. For reproducibility, commit an index
snapshot and reference it
via `index` (tags then resolve frozen from the snapshot), or pin
per-platform manifest digests via `pins` â plain floating tags resolve at
fetch time and log the resolved digest.

With `bins`, provisioning is lazy: nothing is installed at fetch time, and
each named executable becomes a launcher re-entering `ocx package exec` â
content materializes on first execution and never becomes a Bazel action
input (`//:content` is not available in lazy mode)..
name"A unique name for this repository. �
bins�Lazy provisioning: names of the executables to expose (not validated at fetch time). When set, nothing is installed during the fetch â each name becomes a launcher re-entering `ocx package exec`, keyed on the digest-pinned reference. Requires a digest-pinned identity (`pins` or '@sha256:'); incompatible with isolated_home and index.2[]�
config�An ocx site config.toml (mirrors, registries, [patches]) layered over the host's discovered config â not the project ocx.toml. Sets OCX_CONFIG for every invocation, overriding an ambient one, and the file is watched. Combine with no_config for a hermetic configuration. With `bins` it is copied into the repository and uploaded as an input with every action â keep credentials out of it.2None�
index�Committed ocx index snapshot directory (created with `ocx --index <dir> index update <package>`). When set, tag resolution is frozen to the snapshot (`--index --frozen`): floating tags become reproducible until the snapshot is refreshed.2Noneh
isolated_homeNKeep the ocx store inside this repository instead of the shared user OCX_HOME.2False�
	no_config�Ignore the host's discovered config tiers (/etc, the user config, $OCX_HOME/config.toml) and the managed-config snapshot â sets OCX_NO_CONFIG=1, and blanks an ambient OCX_CONFIG, OCX_PATCHES and OCX_PATCH_SNAPSHOT, which OCX_NO_CONFIG alone does not prune. The `config` and `patch_snapshot` attrs still apply. Use this when a corporate managed config must not reach the build; it also opts out of the exit-78 gate a required-but-unsynced managed config raises.2False4
ocxThe pinned ocx CLI binary.2@ocx_tool//:ocxQ
packageBFully-qualified identifier: 'registry/repo[:tag][@sha256:â¦]'. �
patch_snapshot�A committed patches.snapshot.json (written by `ocx patch freeze` next to ocx.lock) freezing the digests of the patch companions composed onto this environment. Sets OCX_PATCH_SNAPSHOT. `ocx lock --check` does not cover companions â without a frozen snapshot they resolve at fetch time. With `bins` it is copied into the repository and uploaded as an input with every action â keep credentials out of it.2Nonew
pinsiocx platform key -> 'sha256:â¦' manifest digest overriding the digest of `package` for that platform.
2{}Z
platformHocx platform key ('linux/amd64', â¦) to provision for; empty = host.2""�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
resolved_platform�Real ocx platform sent to `-p` â lets a declared `platform` be aliased to a different real one (variant/feature build). Empty = derive from `platform`. Runnable-target gating compares its os/arch prefix to the host; `pins` still key on `platform`.2""*-
ocx_package_repo@@rules_ocx//ocx:defs.bzl
�#�#0
.
name"A unique name for this repository. �
�
bins�Lazy provisioning: names of the executables to expose (not validated at fetch time). When set, nothing is installed during the fetch â each name becomes a launcher re-entering `ocx package exec`, keyed on the digest-pinned reference. Requires a digest-pinned identity (`pins` or '@sha256:'); incompatible with isolated_home and index.2[]�
�
config�An ocx site config.toml (mirrors, registries, [patches]) layered over the host's discovered config â not the project ocx.toml. Sets OCX_CONFIG for every invocation, overriding an ambient one, and the file is watched. Combine with no_config for a hermetic configuration. With `bins` it is copied into the repository and uploaded as an input with every action â keep credentials out of it.2None�
�
index�Committed ocx index snapshot directory (created with `ocx --index <dir> index update <package>`). When set, tag resolution is frozen to the snapshot (`--index --frozen`): floating tags become reproducible until the snapshot is refreshed.2Nonej
h
isolated_homeNKeep the ocx store inside this repository instead of the shared user OCX_HOME.2False�
�
	no_config�Ignore the host's discovered config tiers (/etc, the user config, $OCX_HOME/config.toml) and the managed-config snapshot â sets OCX_NO_CONFIG=1, and blanks an ambient OCX_CONFIG, OCX_PATCHES and OCX_PATCH_SNAPSHOT, which OCX_NO_CONFIG alone does not prune. The `config` and `patch_snapshot` attrs still apply. Use this when a corporate managed config must not reach the build; it also opts out of the exit-78 gate a required-but-unsynced managed config raises.2False6
4
ocxThe pinned ocx CLI binary.2@ocx_tool//:ocxS
Q
packageBFully-qualified identifier: 'registry/repo[:tag][@sha256:â¦]'. �
�
patch_snapshot�A committed patches.snapshot.json (written by `ocx patch freeze` next to ocx.lock) freezing the digests of the patch companions composed onto this environment. Sets OCX_PATCH_SNAPSHOT. `ocx lock --check` does not cover companions â without a frozen snapshot they resolve at fetch time. With `bins` it is copied into the repository and uploaded as an input with every action â keep credentials out of it.2Noney
w
pinsiocx platform key -> 'sha256:â¦' manifest digest overriding the digest of `package` for that platform.
2{}\
Z
platformHocx platform key ('linux/amd64', â¦) to provision for; empty = host.2""�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
�
resolved_platform�Real ocx platform sent to `-p` â lets a declared `platform` be aliased to a different real one (variant/feature build). Empty = derive from `platform`. Runnable-target gating compares its os/arch prefix to the host; `pins` still key on `platform`.2""�Eocx_project_repo�Provisions the toolchain declared in a workspace ocx.toml/ocx.lock.

Fails when the lockfile is stale or missing (fix with `ocx lock`). Every
executable the toolchain's packages declare as their public surface
(`ocx inspect --closure`) becomes a runnable target `//:<name>`; a package
shipping no complete `binaries` metadata falls back to scanning the composed
PATH, which also exposes its private executables â `//:env.bzl`'s
`OCX_SCANNED_PACKAGES` names the packages that forced it. The raw
environment is loadable from the same file (`OCX_ENV`, `OCX_HOME`).

With `bins`, provisioning is lazy: nothing is pulled at fetch time, and each
named executable becomes a launcher that re-enters `ocx run` â content
materializes on first execution and never becomes a Bazel action input, so
fully remote-cached builds download no tool content at all.

`groups` scopes both the pull and the composed environment. Omitted, ocx's
defaults apply: every group is pulled, but only the default `[tools]` table
is composed into launchers â name groups explicitly (or use the reserved
`all`) to expose their executables.

`platform` composes a foreign platform's environment from the same
ocx.lock: that platform's leaves are pulled into the store and `env.bzl`
holds their absolute store paths (sysroots, target libraries, container
image content). Foreign repos expose no runnable launchers â the binaries
do not run on this host.R�:
�"
ocx_project_repo�Provisions the toolchain declared in a workspace ocx.toml/ocx.lock.

Fails when the lockfile is stale or missing (fix with `ocx lock`). Every
executable the toolchain's packages declare as their public surface
(`ocx inspect --closure`) becomes a runnable target `//:<name>`; a package
shipping no complete `binaries` metadata falls back to scanning the composed
PATH, which also exposes its private executables â `//:env.bzl`'s
`OCX_SCANNED_PACKAGES` names the packages that forced it. The raw
environment is loadable from the same file (`OCX_ENV`, `OCX_HOME`).

With `bins`, provisioning is lazy: nothing is pulled at fetch time, and each
named executable becomes a launcher that re-enters `ocx run` â content
materializes on first execution and never becomes a Bazel action input, so
fully remote-cached builds download no tool content at all.

`groups` scopes both the pull and the composed environment. Omitted, ocx's
defaults apply: every group is pulled, but only the default `[tools]` table
is composed into launchers â name groups explicitly (or use the reserved
`all`) to expose their executables.

`platform` composes a foreign platform's environment from the same
ocx.lock: that platform's leaves are pulled into the store and `env.bzl`
holds their absolute store paths (sysroots, target libraries, container
image content). Foreign repos expose no runnable launchers â the binaries
do not run on this host..
name"A unique name for this repository. �
bins�Lazy provisioning: names of the executables to expose (not validated at fetch time). When set, nothing is pulled during the fetch â each name becomes a launcher re-entering `ocx run`, and actions key on the lockfile (a runfile) instead of tool content. Incompatible with isolated_home.2[]�
config�An ocx site config.toml (mirrors, registries, [patches]) layered over the host's discovered config â not the project ocx.toml. Sets OCX_CONFIG for every invocation, overriding an ambient one, and the file is watched. Combine with no_config for a hermetic configuration. With `bins` it is copied into the repository and uploaded as an input with every action â keep credentials out of it.2None�
groups�ocx.toml groups to provision (comma-joined into `-g` for `ocx pull`, `ocx env`, and lazy `ocx run`). Reserved names: 'default' = the top-level [tools] table, 'all' = default + every declared group.2[]h
isolated_homeNKeep the ocx store inside this repository instead of the shared user OCX_HOME.2False�
	no_config�Ignore the host's discovered config tiers (/etc, the user config, $OCX_HOME/config.toml) and the managed-config snapshot â sets OCX_NO_CONFIG=1, and blanks an ambient OCX_CONFIG, OCX_PATCHES and OCX_PATCH_SNAPSHOT, which OCX_NO_CONFIG alone does not prune. The `config` and `patch_snapshot` attrs still apply. Use this when a corporate managed config must not reach the build; it also opts out of the exit-78 gate a required-but-unsynced managed config raises.2False4
ocxThe pinned ocx CLI binary.2@ocx_tool//:ocxO
ocx_lock?The ocx.lock next to ocx_toml; watched so lock changes refetch. =
ocx_toml-The project ocx.toml declaring the toolchain. �
patch_snapshot�A committed patches.snapshot.json (written by `ocx patch freeze` next to ocx.lock) freezing the digests of the patch companions composed onto this environment. Sets OCX_PATCH_SNAPSHOT. `ocx lock --check` does not cover companions â without a frozen snapshot they resolve at fetch time. With `bins` it is copied into the repository and uploaded as an input with every action â keep credentials out of it.2None�
platform�ocx platform key ('linux/arm64', â¦) to compose for; empty = host. A foreign platform pulls that platform's leaves from the same ocx.lock and exposes env.bzl only (no runnable launchers). Incompatible with bins â lazy launchers already resolve the executing host at run time.2""�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 *-
ocx_project_repo@@rules_ocx//ocx:defs.bzl
�#�#0
.
name"A unique name for this repository. �
�
bins�Lazy provisioning: names of the executables to expose (not validated at fetch time). When set, nothing is pulled during the fetch â each name becomes a launcher re-entering `ocx run`, and actions key on the lockfile (a runfile) instead of tool content. Incompatible with isolated_home.2[]�
�
config�An ocx site config.toml (mirrors, registries, [patches]) layered over the host's discovered config â not the project ocx.toml. Sets OCX_CONFIG for every invocation, overriding an ambient one, and the file is watched. Combine with no_config for a hermetic configuration. With `bins` it is copied into the repository and uploaded as an input with every action â keep credentials out of it.2None�
�
groups�ocx.toml groups to provision (comma-joined into `-g` for `ocx pull`, `ocx env`, and lazy `ocx run`). Reserved names: 'default' = the top-level [tools] table, 'all' = default + every declared group.2[]j
h
isolated_homeNKeep the ocx store inside this repository instead of the shared user OCX_HOME.2False�
�
	no_config�Ignore the host's discovered config tiers (/etc, the user config, $OCX_HOME/config.toml) and the managed-config snapshot â sets OCX_NO_CONFIG=1, and blanks an ambient OCX_CONFIG, OCX_PATCHES and OCX_PATCH_SNAPSHOT, which OCX_NO_CONFIG alone does not prune. The `config` and `patch_snapshot` attrs still apply. Use this when a corporate managed config must not reach the build; it also opts out of the exit-78 gate a required-but-unsynced managed config raises.2False6
4
ocxThe pinned ocx CLI binary.2@ocx_tool//:ocxQ
O
ocx_lock?The ocx.lock next to ocx_toml; watched so lock changes refetch. ?
=
ocx_toml-The project ocx.toml declaring the toolchain. �
�
patch_snapshot�A committed patches.snapshot.json (written by `ocx patch freeze` next to ocx.lock) freezing the digests of the patch companions composed onto this environment. Sets OCX_PATCH_SNAPSHOT. `ocx lock --check` does not cover companions â without a frozen snapshot they resolve at fetch time. With `bins` it is copied into the repository and uploaded as an input with every action â keep credentials out of it.2None�
�
platform�ocx platform key ('linux/arm64', â¦) to compose for; empty = host. A foreign platform pulls that platform's leaves from the same ocx.lock and exposes env.bzl only (no runnable launchers). Incompatible with bins â lazy launchers already resolve the executing host at run time.2""�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
//ocx/private:download.bzlrc
&
	rules_ocxocx/privatedownload.bzl+
ocx_download_ocx_download
.;
M�
//ocx/private:package.bzlr�
%
	rules_ocxocx/privatepackage.bzl1
ocx_package_hub_ocx_package_hub
-=3
ocx_package_repo_ocx_package_repo
Sd
z�
//ocx/private:platforms.bzlr|
'
	rules_ocxocx/privateplatforms.bzlC
ocx_platform_constraints_ocx_platform_constraints
/H
f�
//ocx/private:project.bzlrj
%
	rules_ocxocx/privateproject.bzl3
ocx_project_repo_ocx_project_repo
->
T�Public API of rules_ocx.

Most consumers only need the `ocx` module extension
(`@rules_ocx//ocx:extensions.bzl`). The repository rules are re-exported
here for power users composing their own extensions on top of the same
CLI-backed provisioning.
��
 
	rules_ocxocxextensions.bzl��ocx�Provisions tools through the OCX package manager.

Always creates `@ocx_tool` (the pinned ocx CLI). `ocx.project()` provisions
a workspace toolchain from ocx.toml/ocx.lock; `ocx.package()` provisions
individual OCI packages. See the tag class docs for details.J�
�8
ocx�Provisions tools through the OCX package manager.

Always creates `@ocx_tool` (the pinned ocx CLI). `ocx.project()` provisions
a workspace toolchain from ocx.toml/ocx.lock; `ocx.package()` provisions
individual OCI packages. See the tag class docs for details.�
download?Overrides the ocx CLI bootstrap. Root module only; at most one.f
dist_manifestAdist.json release manifest snapshot to resolve the download from.2//dist:dist.jsonG
triple7Exact release target triple, overriding host detection.2""]
versionLExact ocx version (default: the version pinned with this rules_ocx release).2""�
package5Provisions a single OCX package from an OCI registry.P
nameDName of the generated repository (hub name when `platforms` is set). �
bins�Lazy provisioning: names of the executables to expose. Nothing is installed at fetch time â each name becomes a launcher re-entering `ocx package exec`, materializing the package on first execution, and no host config tier is watched because the launcher resolves configuration live on each run. Requires a digest-pinned identity (`pins` or '@sha256:'); `//:content` is unavailable in lazy mode, and `index` is incompatible because a snapshot resolves at fetch time only.2[]�
config�An ocx site config.toml (mirrors, registries, [patches]) layered over the host's discovered config â not the project ocx.toml; sets OCX_CONFIG for every invocation, overriding an ambient one, and is watched. Combine with no_config for a hermetic configuration; with `bins` it is copied into the repo and uploaded with every action â keep credentials out of it.2None�
index�Committed ocx index snapshot directory (created with `ocx --index <dir> index update <package>`, refreshed the same way). When set, tag resolution is frozen to the snapshot â floating tags like ':latest' become reproducible until the snapshot is refreshed.2None�
isolated_home�Reach for it when this build must neither touch nor be touched by the host store: uses a repository-local ocx store instead of the shared user OCX_HOME, at the cost of a full per-repository download (nothing shared with your shell, direnv, other repos or CI) and the $OCX_HOME-rooted config tiers no longer being watched. Incompatible with bins: a lazy launcher must resolve the store on whatever machine executes it.2False�
	no_config�Reach for it when a corporate managed config must not reach the build: ignores the host's discovered tiers (/etc, the user config, $OCX_HOME/config.toml) and the managed-config snapshot, and opts out of the exit-78 gate a required-but-unsynced managed config raises. Sets OCX_NO_CONFIG=1 and additionally blanks an ambient OCX_CONFIG, OCX_PATCHES and OCX_PATCH_SNAPSHOT, which OCX_NO_CONFIG alone does not prune; the `config` and `patch_snapshot` attrs still apply.2False�
package�Fully-qualified identifier: 'registry/repo[:tag][@sha256:â¦]'. Freeze tag resolution with `index`, or pin per-platform manifest digests with `pins`. �
patch_snapshot�A committed patches.snapshot.json (`ocx patch freeze`, written next to ocx.lock) pinning the digests of the patch companions composed onto this environment; sets OCX_PATCH_SNAPSHOT. `ocx lock --check` does not cover companions, so without it they resolve at fetch time; with `bins` it is copied into the repo and uploaded with every action â keep credentials out of it.2None�
pins�Per-platform manifest pins: ocx platform key -> 'sha256:â¦' digest of that platform's manifest (as reported by `ocx package install -p <platform>`). The matching platform installs 'registry/repo@<digest>'; unpinned platforms fall back to `package`.
2{}�
platform_aliases�Optional declared-platform -> real-platform remap. Each key must appear in `platforms`; its value is the canonical ocx platform actually sent to `-p` and used to derive the hub's Bazel constraints. Everything Bazel-facing â repo suffix, `pins` lookup, config_setting, use_repo name â still keys on the declared platform; undeclared platforms are sent as-is. Example: {'linux/arm64': 'linux/arm64+libc.musl'} provisions a musl arm64 build under the plain 'linux/arm64' target.
2{}�
	platforms�ocx platform keys ('linux/amd64', â¦) to provision in addition to the host: creates '<name>_<slug>' repos plus a '<name>' hub whose //:content select()s by target platform. Empty = host only.2[]�
projectNProvisions the toolchain of a workspace ocx.toml + ocx.lock. Root module only.-
name!Name of the generated repository. �
bins�Lazy provisioning: names of the executables to expose. When set, nothing is pulled at fetch time â each name becomes a launcher re-entering `ocx run`, materializing the toolchain on first execution. Actions key on the lockfile, so fully remote-cached builds download no tool content.2[]�
config�An ocx site config.toml (mirrors, registries, [patches]) layered over the host's discovered config â not the project ocx.toml; sets OCX_CONFIG for every invocation, overriding an ambient one, and is watched. Combine with no_config for a hermetic configuration; with `bins` it is copied into the repo and uploaded with every action â keep credentials out of it.2None�
groups�ocx.toml groups to provision (scopes both the pull and the composed environment). Reserved names: 'default' = the top-level [tools] table, 'all' = default + every group.2[]�
isolated_home�Reach for it when this build must neither touch nor be touched by the host store: uses a repository-local ocx store instead of the shared user OCX_HOME, at the cost of a full per-repository download (nothing shared with your shell, direnv, other repos or CI) and the $OCX_HOME-rooted config tiers no longer being watched. Incompatible with bins: a lazy launcher must resolve the store on whatever machine executes it.2False�
	no_config�Reach for it when a corporate managed config must not reach the build: ignores the host's discovered tiers (/etc, the user config, $OCX_HOME/config.toml) and the managed-config snapshot, and opts out of the exit-78 gate a required-but-unsynced managed config raises. Sets OCX_NO_CONFIG=1 and additionally blanks an ambient OCX_CONFIG, OCX_PATCHES and OCX_PATCH_SNAPSHOT, which OCX_NO_CONFIG alone does not prune; the `config` and `patch_snapshot` attrs still apply.2False@
ocx_lock0The committed ocx.lock (watched; edits refetch). %
ocx_tomlThe project ocx.toml. �
patch_snapshot�A committed patches.snapshot.json (`ocx patch freeze`, written next to ocx.lock) pinning the digests of the patch companions composed onto this environment; sets OCX_PATCH_SNAPSHOT. `ocx lock --check` does not cover companions, so without it they resolve at fetch time; with `bins` it is copied into the repo and uploaded with every action â keep credentials out of it.2None�
platform�ocx platform key ('linux/arm64', â¦) to compose for; empty = host. A foreign platform pulls that platform's leaves from the same ocx.lock and exposes env.bzl only (no runnable launchers). Incompatible with bins.2"""&
ocx@@rules_ocx//ocx:extensions.bzl
���
�
download?Overrides the ocx CLI bootstrap. Root module only; at most one.f
dist_manifestAdist.json release manifest snapshot to resolve the download from.2//dist:dist.jsonG
triple7Exact release target triple, overriding host detection.2""]
versionLExact ocx version (default: the version pinned with this rules_ocx release).2""h
f
dist_manifestAdist.json release manifest snapshot to resolve the download from.2//dist:dist.jsonI
G
triple7Exact release target triple, overriding host detection.2""_
]
versionLExact ocx version (default: the version pinned with this rules_ocx release).2""�;
�
package5Provisions a single OCX package from an OCI registry.P
nameDName of the generated repository (hub name when `platforms` is set). �
bins�Lazy provisioning: names of the executables to expose. Nothing is installed at fetch time â each name becomes a launcher re-entering `ocx package exec`, materializing the package on first execution, and no host config tier is watched because the launcher resolves configuration live on each run. Requires a digest-pinned identity (`pins` or '@sha256:'); `//:content` is unavailable in lazy mode, and `index` is incompatible because a snapshot resolves at fetch time only.2[]�
config�An ocx site config.toml (mirrors, registries, [patches]) layered over the host's discovered config â not the project ocx.toml; sets OCX_CONFIG for every invocation, overriding an ambient one, and is watched. Combine with no_config for a hermetic configuration; with `bins` it is copied into the repo and uploaded with every action â keep credentials out of it.2None�
index�Committed ocx index snapshot directory (created with `ocx --index <dir> index update <package>`, refreshed the same way). When set, tag resolution is frozen to the snapshot â floating tags like ':latest' become reproducible until the snapshot is refreshed.2None�
isolated_home�Reach for it when this build must neither touch nor be touched by the host store: uses a repository-local ocx store instead of the shared user OCX_HOME, at the cost of a full per-repository download (nothing shared with your shell, direnv, other repos or CI) and the $OCX_HOME-rooted config tiers no longer being watched. Incompatible with bins: a lazy launcher must resolve the store on whatever machine executes it.2False�
	no_config�Reach for it when a corporate managed config must not reach the build: ignores the host's discovered tiers (/etc, the user config, $OCX_HOME/config.toml) and the managed-config snapshot, and opts out of the exit-78 gate a required-but-unsynced managed config raises. Sets OCX_NO_CONFIG=1 and additionally blanks an ambient OCX_CONFIG, OCX_PATCHES and OCX_PATCH_SNAPSHOT, which OCX_NO_CONFIG alone does not prune; the `config` and `patch_snapshot` attrs still apply.2False�
package�Fully-qualified identifier: 'registry/repo[:tag][@sha256:â¦]'. Freeze tag resolution with `index`, or pin per-platform manifest digests with `pins`. �
patch_snapshot�A committed patches.snapshot.json (`ocx patch freeze`, written next to ocx.lock) pinning the digests of the patch companions composed onto this environment; sets OCX_PATCH_SNAPSHOT. `ocx lock --check` does not cover companions, so without it they resolve at fetch time; with `bins` it is copied into the repo and uploaded with every action â keep credentials out of it.2None�
pins�Per-platform manifest pins: ocx platform key -> 'sha256:â¦' digest of that platform's manifest (as reported by `ocx package install -p <platform>`). The matching platform installs 'registry/repo@<digest>'; unpinned platforms fall back to `package`.
2{}�
platform_aliases�Optional declared-platform -> real-platform remap. Each key must appear in `platforms`; its value is the canonical ocx platform actually sent to `-p` and used to derive the hub's Bazel constraints. Everything Bazel-facing â repo suffix, `pins` lookup, config_setting, use_repo name â still keys on the declared platform; undeclared platforms are sent as-is. Example: {'linux/arm64': 'linux/arm64+libc.musl'} provisions a musl arm64 build under the plain 'linux/arm64' target.
2{}�
	platforms�ocx platform keys ('linux/amd64', â¦) to provision in addition to the host: creates '<name>_<slug>' repos plus a '<name>' hub whose //:content select()s by target platform. Empty = host only.2[]R
P
nameDName of the generated repository (hub name when `platforms` is set). �
�
bins�Lazy provisioning: names of the executables to expose. Nothing is installed at fetch time â each name becomes a launcher re-entering `ocx package exec`, materializing the package on first execution, and no host config tier is watched because the launcher resolves configuration live on each run. Requires a digest-pinned identity (`pins` or '@sha256:'); `//:content` is unavailable in lazy mode, and `index` is incompatible because a snapshot resolves at fetch time only.2[]�
�
config�An ocx site config.toml (mirrors, registries, [patches]) layered over the host's discovered config â not the project ocx.toml; sets OCX_CONFIG for every invocation, overriding an ambient one, and is watched. Combine with no_config for a hermetic configuration; with `bins` it is copied into the repo and uploaded with every action â keep credentials out of it.2None�
�
index�Committed ocx index snapshot directory (created with `ocx --index <dir> index update <package>`, refreshed the same way). When set, tag resolution is frozen to the snapshot â floating tags like ':latest' become reproducible until the snapshot is refreshed.2None�
�
isolated_home�Reach for it when this build must neither touch nor be touched by the host store: uses a repository-local ocx store instead of the shared user OCX_HOME, at the cost of a full per-repository download (nothing shared with your shell, direnv, other repos or CI) and the $OCX_HOME-rooted config tiers no longer being watched. Incompatible with bins: a lazy launcher must resolve the store on whatever machine executes it.2False�
�
	no_config�Reach for it when a corporate managed config must not reach the build: ignores the host's discovered tiers (/etc, the user config, $OCX_HOME/config.toml) and the managed-config snapshot, and opts out of the exit-78 gate a required-but-unsynced managed config raises. Sets OCX_NO_CONFIG=1 and additionally blanks an ambient OCX_CONFIG, OCX_PATCHES and OCX_PATCH_SNAPSHOT, which OCX_NO_CONFIG alone does not prune; the `config` and `patch_snapshot` attrs still apply.2False�
�
package�Fully-qualified identifier: 'registry/repo[:tag][@sha256:â¦]'. Freeze tag resolution with `index`, or pin per-platform manifest digests with `pins`. �
�
patch_snapshot�A committed patches.snapshot.json (`ocx patch freeze`, written next to ocx.lock) pinning the digests of the patch companions composed onto this environment; sets OCX_PATCH_SNAPSHOT. `ocx lock --check` does not cover companions, so without it they resolve at fetch time; with `bins` it is copied into the repo and uploaded with every action â keep credentials out of it.2None�
�
pins�Per-platform manifest pins: ocx platform key -> 'sha256:â¦' digest of that platform's manifest (as reported by `ocx package install -p <platform>`). The matching platform installs 'registry/repo@<digest>'; unpinned platforms fall back to `package`.
2{}�
�
platform_aliases�Optional declared-platform -> real-platform remap. Each key must appear in `platforms`; its value is the canonical ocx platform actually sent to `-p` and used to derive the hub's Bazel constraints. Everything Bazel-facing â repo suffix, `pins` lookup, config_setting, use_repo name â still keys on the declared platform; undeclared platforms are sent as-is. Example: {'linux/arm64': 'linux/arm64+libc.musl'} provisions a musl arm64 build under the plain 'linux/arm64' target.
2{}�
�
	platforms�ocx platform keys ('linux/amd64', â¦) to provision in addition to the host: creates '<name>_<slug>' repos plus a '<name>' hub whose //:content select()s by target platform. Empty = host only.2[]�)
�
projectNProvisions the toolchain of a workspace ocx.toml + ocx.lock. Root module only.-
name!Name of the generated repository. �
bins�Lazy provisioning: names of the executables to expose. When set, nothing is pulled at fetch time â each name becomes a launcher re-entering `ocx run`, materializing the toolchain on first execution. Actions key on the lockfile, so fully remote-cached builds download no tool content.2[]�
config�An ocx site config.toml (mirrors, registries, [patches]) layered over the host's discovered config â not the project ocx.toml; sets OCX_CONFIG for every invocation, overriding an ambient one, and is watched. Combine with no_config for a hermetic configuration; with `bins` it is copied into the repo and uploaded with every action â keep credentials out of it.2None�
groups�ocx.toml groups to provision (scopes both the pull and the composed environment). Reserved names: 'default' = the top-level [tools] table, 'all' = default + every group.2[]�
isolated_home�Reach for it when this build must neither touch nor be touched by the host store: uses a repository-local ocx store instead of the shared user OCX_HOME, at the cost of a full per-repository download (nothing shared with your shell, direnv, other repos or CI) and the $OCX_HOME-rooted config tiers no longer being watched. Incompatible with bins: a lazy launcher must resolve the store on whatever machine executes it.2False�
	no_config�Reach for it when a corporate managed config must not reach the build: ignores the host's discovered tiers (/etc, the user config, $OCX_HOME/config.toml) and the managed-config snapshot, and opts out of the exit-78 gate a required-but-unsynced managed config raises. Sets OCX_NO_CONFIG=1 and additionally blanks an ambient OCX_CONFIG, OCX_PATCHES and OCX_PATCH_SNAPSHOT, which OCX_NO_CONFIG alone does not prune; the `config` and `patch_snapshot` attrs still apply.2False@
ocx_lock0The committed ocx.lock (watched; edits refetch). %
ocx_tomlThe project ocx.toml. �
patch_snapshot�A committed patches.snapshot.json (`ocx patch freeze`, written next to ocx.lock) pinning the digests of the patch companions composed onto this environment; sets OCX_PATCH_SNAPSHOT. `ocx lock --check` does not cover companions, so without it they resolve at fetch time; with `bins` it is copied into the repo and uploaded with every action â keep credentials out of it.2None�
platform�ocx platform key ('linux/arm64', â¦) to compose for; empty = host. A foreign platform pulls that platform's leaves from the same ocx.lock and exposes env.bzl only (no runnable launchers). Incompatible with bins.2""/
-
name!Name of the generated repository. �
�
bins�Lazy provisioning: names of the executables to expose. When set, nothing is pulled at fetch time â each name becomes a launcher re-entering `ocx run`, materializing the toolchain on first execution. Actions key on the lockfile, so fully remote-cached builds download no tool content.2[]�
�
config�An ocx site config.toml (mirrors, registries, [patches]) layered over the host's discovered config â not the project ocx.toml; sets OCX_CONFIG for every invocation, overriding an ambient one, and is watched. Combine with no_config for a hermetic configuration; with `bins` it is copied into the repo and uploaded with every action â keep credentials out of it.2None�
�
groups�ocx.toml groups to provision (scopes both the pull and the composed environment). Reserved names: 'default' = the top-level [tools] table, 'all' = default + every group.2[]�
�
isolated_home�Reach for it when this build must neither touch nor be touched by the host store: uses a repository-local ocx store instead of the shared user OCX_HOME, at the cost of a full per-repository download (nothing shared with your shell, direnv, other repos or CI) and the $OCX_HOME-rooted config tiers no longer being watched. Incompatible with bins: a lazy launcher must resolve the store on whatever machine executes it.2False�
�
	no_config�Reach for it when a corporate managed config must not reach the build: ignores the host's discovered tiers (/etc, the user config, $OCX_HOME/config.toml) and the managed-config snapshot, and opts out of the exit-78 gate a required-but-unsynced managed config raises. Sets OCX_NO_CONFIG=1 and additionally blanks an ambient OCX_CONFIG, OCX_PATCHES and OCX_PATCH_SNAPSHOT, which OCX_NO_CONFIG alone does not prune; the `config` and `patch_snapshot` attrs still apply.2FalseB
@
ocx_lock0The committed ocx.lock (watched; edits refetch). '
%
ocx_tomlThe project ocx.toml. �
�
patch_snapshot�A committed patches.snapshot.json (`ocx patch freeze`, written next to ocx.lock) pinning the digests of the patch companions composed onto this environment; sets OCX_PATCH_SNAPSHOT. `ocx lock --check` does not cover companions, so without it they resolve at fetch time; with `bins` it is copied into the repo and uploaded with every action â keep credentials out of it.2None�
�
platform�ocx platform key ('linux/arm64', â¦) to compose for; empty = host. A foreign platform pulls that platform's leaves from the same ocx.lock and exposes env.bzl only (no runnable launchers). Incompatible with bins.2""�
//ocx/private:download.bzlrb
&
	rules_ocxocx/privatedownload.bzl*
ocx_downloadocx_download
/;
=�
//ocx/private:package.bzlr�
%
	rules_ocxocx/privatepackage.bzl0
ocx_package_hubocx_package_hub
.=2
ocx_package_repoocx_package_repo
AQ4
resolve_platformsresolve_platforms
Uf
h�
//ocx/private:project.bzlri
%
	rules_ocxocx/privateproject.bzl2
ocx_project_repoocx_project_repo
.>
@�
//ocx/private:versions.bzlrp
&
	rules_ocxocx/privateversions.bzl8
DEFAULT_OCX_VERSIONDEFAULT_OCX_VERSION
/B
D�The `ocx` module extension.

Bootstraps the pinned ocx CLI (`@ocx_tool`) and declares repositories that
provision tools through it. The implementation is a pure function of the
tags â all host detection and environment access happens inside the
repository rules â so the extension is marked reproducible and stays out of
MODULE.bazel.lock.
 