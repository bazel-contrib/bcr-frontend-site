�
6
rules_powershellpowershell/privatepowershell.bzl�pwsh_librarysThe main use for this rule is to aggregate together a logical
"library" consisting of related scripts and modules.
"�
�
pwsh_librarysThe main use for this rule is to aggregate together a logical
"library" consisting of related scripts and modules.
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]�
deps�The list of "library" targets to be aggregated into this target. See general comments about deps at Typical attributes defined by most build rules.

This attribute should be used to list other `pwsh_library` rules that provide interpreted program source code depended on by the code in srcs. The files provided by these rules will be present among the runfiles of this target.
*

PwshInfo2[]O
srcsAThe list of source files that are processed to create the target.2[]"E
pwsh_library5@@rules_powershell//powershell/private:powershell.bzl
[[,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]�
�
deps�The list of "library" targets to be aggregated into this target. See general comments about deps at Typical attributes defined by most build rules.

This attribute should be used to list other `pwsh_library` rules that provide interpreted program source code depended on by the code in srcs. The files provided by these rules will be present among the runfiles of this target.
*

PwshInfo2[]Q
O
srcsAThe list of source files that are processed to create the target.2[]�PwshInfo A provider for Powershell rules.2�
�
PwshInfo A provider for Powershell rules.w
importslDepset[str]: The rlocationpaths of all transitive module files (.psm1, .psd1) used to set up `PSModulePath`.V
srcsNDepset[File]: The source files directly associated with the powershell target.h
transitive_srcsUDepset[File]: The source files of this target and all of its transitive dependencies."A
PwshInfo5@@rules_powershell//powershell/private:powershell.bzl
y
w
importslDepset[str]: The rlocationpaths of all transitive module files (.psm1, .psd1) used to set up `PSModulePath`.X
V
srcsNDepset[File]: The source files directly associated with the powershell target.j
h
transitive_srcsUDepset[File]: The source files of this target and all of its transitive dependencies.�
//powershell/private:utils.bzlro
1
rules_powershellpowershell/private	utils.bzl,
rlocationpathrlocationpath
:G
IPowershell rules�1
;
rules_powershellpowershell/privatepwsh_executable.bzl�pwsh_binary�The `pwsh_binary` rule is used to declare executable powershell scripts.
(`pwsh_binary` is a misnomer: its outputs aren't necessarily binaries.) This rule ensures
that all dependencies are built, and appear in the `runfiles` area at execution time.
We recommend that you name your `pwsh_binary()` rules after the name of the script minus
the extension (e.g. `.ps1`); the rule name and the file name must be distinct.

The script runs with the same semantics as `pwsh -File`: `param()` blocks receive the
command line arguments, `exit N` sets the process exit code, and an uncaught terminating
error exits with code 1.

For a simple Powershell script with no dependencies and some data files:

```python
pwsh_binary(
    name = "foo",
    srcs = ["foo.ps1"],
    data = glob(["datafiles/*.txt"]),
)
```
"�
�
pwsh_binary�The `pwsh_binary` rule is used to declare executable powershell scripts.
(`pwsh_binary` is a misnomer: its outputs aren't necessarily binaries.) This rule ensures
that all dependencies are built, and appear in the `runfiles` area at execution time.
We recommend that you name your `pwsh_binary()` rules after the name of the script minus
the extension (e.g. `.ps1`); the rule name and the file name must be distinct.

The script runs with the same semantics as `pwsh -File`: `param()` blocks receive the
command line arguments, `exit N` sets the process exit code, and an uncaught terminating
error exits with code 1.

For a simple Powershell script with no dependencies and some data files:

```python
pwsh_binary(
    name = "foo",
    srcs = ["foo.ps1"],
    data = glob(["datafiles/*.txt"]),
)
```
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]�
deps�The list of "library" targets to be aggregated into this target. See general comments about deps at Typical attributes defined by most build rules.

This attribute should be used to list other `pwsh_library` rules that provide interpreted program source code depended on by the code in srcs. The files provided by these rules will be present among the runfiles of this target.
*

PwshInfo2[]i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}V
srcsHThe list of source (.ps1) files that are processed to create the target.2[]"I
pwsh_binary:@@rules_powershell//powershell/private:pwsh_executable.bzl
��,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]�
�
deps�The list of "library" targets to be aggregated into this target. See general comments about deps at Typical attributes defined by most build rules.

This attribute should be used to list other `pwsh_library` rules that provide interpreted program source code depended on by the code in srcs. The files provided by these rules will be present among the runfiles of this target.
*

PwshInfo2[]k
i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}X
V
srcsHThe list of source (.ps1) files that are processed to create the target.2[]�	pwsh_test�A `pwsh_test` rule creates a test written as a Powershell script.

```python
pwsh_test(
    name = "foo_integration_test",
    size = "small",
    srcs = ["foo_integration_test.ps1"],
    deps = [":foo_lib"],
    data = glob(["testdata/*.txt"]),
)
```
"�
�	
	pwsh_test�A `pwsh_test` rule creates a test written as a Powershell script.

```python
pwsh_test(
    name = "foo_integration_test",
    size = "small",
    srcs = ["foo_integration_test.ps1"],
    deps = [":foo_lib"],
    data = glob(["testdata/*.txt"]),
)
```
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]�
deps�The list of "library" targets to be aggregated into this target. See general comments about deps at Typical attributes defined by most build rules.

This attribute should be used to list other `pwsh_library` rules that provide interpreted program source code depended on by the code in srcs. The files provided by these rules will be present among the runfiles of this target.
*

PwshInfo2[]i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}�
env_inherit~Specifies additional environment variables to inherit from the external environment when the test is executed by `bazel test`.2[]V
srcsHThe list of source (.ps1) files that are processed to create the target.2[]"G
	pwsh_test:@@rules_powershell//powershell/private:pwsh_executable.bzl
��,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]�
�
deps�The list of "library" targets to be aggregated into this target. See general comments about deps at Typical attributes defined by most build rules.

This attribute should be used to list other `pwsh_library` rules that provide interpreted program source code depended on by the code in srcs. The files provided by these rules will be present among the runfiles of this target.
*

PwshInfo2[]k
i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}�
�
env_inherit~Specifies additional environment variables to inherit from the external environment when the test is executed by `bazel test`.2[]X
V
srcsHThe list of source (.ps1) files that are processed to create the target.2[]�
#//powershell/private:powershell.bzlr�
6
rules_powershellpowershell/privatepowershell.bzl*
COMMON_ATTRSCOMMON_ATTRS
?K:
EXECUTABLE_SRCS_ATTREXECUTABLE_SRCS_ATTR
Oc"
PwshInfoPwshInfo
go
q�
"//powershell/private:toolchain.bzlru
5
rules_powershellpowershell/privatetoolchain.bzl.
TOOLCHAIN_TYPETOOLCHAIN_TYPE
>L
N�
//powershell/private:utils.bzlro
1
rules_powershellpowershell/private	utils.bzl,
rlocationpathrlocationpath
:G
IPowershell rules�
5
rules_powershellpowershell/privatetoolchain.bzl�current_pwsh_toolchain:Access the `pwsh_toolchain` for the current configuration."�
�
current_pwsh_toolchain:Access the `pwsh_toolchain` for the current configuration.*
nameA unique name for this target. "N
current_pwsh_toolchain4@@rules_powershell//powershell/private:toolchain.bzl
ss,
*
nameA unique name for this target. �pwsh_toolchain�
A toolchain for providing Powershell to Bazel rules.

Example:

```python
load("@rules_powershell//powershell:pwsh_toolchain.bzl", "pwsh_toolchain")

filegroup(
    name = "powershell_bin",
    srcs = ["powershell/pwsh"],
    # Note that additional runfiles associated with a hermetic archive
    # of powershell should be associated with the target passed to the
    # `pwsh` attribute. The executable itself must carry the executable
    # bit; the upstream unix archives do not set it.
    data = glob(["powershell/**"]),
)

pwsh_toolchain(
    name = "pwsh_toolchain",
    pwsh = ":powershell_bin",
    visibility = ["//visibility:public"],
)
```

For users looking to use a system install of Powershell, a shell/batch script
should be added that points to the system install.

Example of a non-hermetic toolchain:

`pwsh.sh`
```bash
#!/usr/bin/env bash
set -euo pipefail
exec /usr/bin/pwsh "$@"
```

`pwsh.bat`
```batch
@ECHO OFF
"C:\Program Files\PowerShell\7\pwsh.exe" %*
exit /b %ERRORLEVEL%
```

```python
load("@rules_powershell//powershell:pwsh_toolchain.bzl", "pwsh_toolchain")

filegroup(
    name = "powershell_bin",
    srcs = select({
        "@platforms//os:windows": ["pwsh.bat"],
        "//conditions:default": ["pwsh.sh"],
    }),
)

pwsh_toolchain(
    name = "pwsh_toolchain",
    pwsh = ":powershell_bin",
    visibility = ["//visibility:public"],
)
```
"�
�
pwsh_toolchain�
A toolchain for providing Powershell to Bazel rules.

Example:

```python
load("@rules_powershell//powershell:pwsh_toolchain.bzl", "pwsh_toolchain")

filegroup(
    name = "powershell_bin",
    srcs = ["powershell/pwsh"],
    # Note that additional runfiles associated with a hermetic archive
    # of powershell should be associated with the target passed to the
    # `pwsh` attribute. The executable itself must carry the executable
    # bit; the upstream unix archives do not set it.
    data = glob(["powershell/**"]),
)

pwsh_toolchain(
    name = "pwsh_toolchain",
    pwsh = ":powershell_bin",
    visibility = ["//visibility:public"],
)
```

For users looking to use a system install of Powershell, a shell/batch script
should be added that points to the system install.

Example of a non-hermetic toolchain:

`pwsh.sh`
```bash
#!/usr/bin/env bash
set -euo pipefail
exec /usr/bin/pwsh "$@"
```

`pwsh.bat`
```batch
@ECHO OFF
"C:\Program Files\PowerShell\7\pwsh.exe" %*
exit /b %ERRORLEVEL%
```

```python
load("@rules_powershell//powershell:pwsh_toolchain.bzl", "pwsh_toolchain")

filegroup(
    name = "powershell_bin",
    srcs = select({
        "@platforms//os:windows": ["pwsh.bat"],
        "//conditions:default": ["pwsh.sh"],
    }),
)

pwsh_toolchain(
    name = "pwsh_toolchain",
    pwsh = ":powershell_bin",
    visibility = ["//visibility:public"],
)
```
*
nameA unique name for this target. &
pwshThe Powershell executable. "F
pwsh_toolchain4@@rules_powershell//powershell/private:toolchain.bzl
,
*
nameA unique name for this target. (
&
pwshThe Powershell executable. �
//powershell/private:utils.bzlro
1
rules_powershellpowershell/private	utils.bzl,
rlocationpathrlocationpath
:G
IR	TOOLCHAIN_TYPE@@//powershell:toolchain_typej@@//powershell:toolchain_typePowershell toolchain�
:
rules_powershellpowershell/privatetoolchain_repo.bzl*�ModuleInfo request error: invalid argument: Traceback (most recent call last):
	File "external/rules_powershell/powershell/private/toolchain_repo.bzl", line 55, column 44, in <toplevel>
		_BAZEL_MAJOR_VERSION = _bazel_major_version()
	File "external/rules_powershell/powershell/private/toolchain_repo.bzl", line 50, column 20, in _bazel_major_version
		major = version.split(".")[0]
Error: 'build.stack.devtools.build.constellate.fakebuildapi.FakeStarlarkNativeModuleApi$2' value has no field or method 'split'�	
1
rules_powershellpowershell/private	utils.bzl�pwsh_entrypoint7Generates the entrypoint for `pwsh_*` executable rules."�
�
pwsh_entrypoint7Generates the entrypoint for `pwsh_*` executable rules.*
nameA unique name for this target. .

entrypointThe entrypoint template.2None"C
pwsh_entrypoint0@@rules_powershell//powershell/private:utils.bzl
��,
*
nameA unique name for this target. 0
.

entrypointThe entrypoint template.2None�rlocationpath4Compute the runfiles path (rlocationpath) of a file.*�
�
rlocationpath%
ctxThe rule's context object. (-
file!The file to compute the path for. (4Compute the runfiles path (rlocationpath) of a file."8
6str: The rlocationpath, e.g. `_main/path/to/file.ps1`.2A
rlocationpath0@@rules_powershell//powershell/private:utils.bzl
�BashRunfilesInfo4The provider for the `_bash_runfiles_finder` aspect.2�
�
BashRunfilesInfo4The provider for the `_bash_runfiles_finder` aspect.,
file$File: The bash runfiles source file."D
BashRunfilesInfo0@@rules_powershell//powershell/private:utils.bzl
.
,
file$File: The bash runfiles source file.Powershell utilities�
4
rules_powershellpowershell/privateversions.bzl�Powershell Versions

A mapping of platform to integrity of the archive for said platform for each version of Powershell available.
�1
(
rules_powershell
powershelldefs.bzl�pwsh_binary�The `pwsh_binary` rule is used to declare executable powershell scripts.
(`pwsh_binary` is a misnomer: its outputs aren't necessarily binaries.) This rule ensures
that all dependencies are built, and appear in the `runfiles` area at execution time.
We recommend that you name your `pwsh_binary()` rules after the name of the script minus
the extension (e.g. `.ps1`); the rule name and the file name must be distinct.

The script runs with the same semantics as `pwsh -File`: `param()` blocks receive the
command line arguments, `exit N` sets the process exit code, and an uncaught terminating
error exits with code 1.

For a simple Powershell script with no dependencies and some data files:

```python
pwsh_binary(
    name = "foo",
    srcs = ["foo.ps1"],
    data = glob(["datafiles/*.txt"]),
)
```
"�
�
pwsh_binary�The `pwsh_binary` rule is used to declare executable powershell scripts.
(`pwsh_binary` is a misnomer: its outputs aren't necessarily binaries.) This rule ensures
that all dependencies are built, and appear in the `runfiles` area at execution time.
We recommend that you name your `pwsh_binary()` rules after the name of the script minus
the extension (e.g. `.ps1`); the rule name and the file name must be distinct.

The script runs with the same semantics as `pwsh -File`: `param()` blocks receive the
command line arguments, `exit N` sets the process exit code, and an uncaught terminating
error exits with code 1.

For a simple Powershell script with no dependencies and some data files:

```python
pwsh_binary(
    name = "foo",
    srcs = ["foo.ps1"],
    data = glob(["datafiles/*.txt"]),
)
```
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]�
deps�The list of "library" targets to be aggregated into this target. See general comments about deps at Typical attributes defined by most build rules.

This attribute should be used to list other `pwsh_library` rules that provide interpreted program source code depended on by the code in srcs. The files provided by these rules will be present among the runfiles of this target.
*

PwshInfo2[]i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}V
srcsHThe list of source (.ps1) files that are processed to create the target.2[]"6
pwsh_binary'@@rules_powershell//powershell:defs.bzl
��,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]�
�
deps�The list of "library" targets to be aggregated into this target. See general comments about deps at Typical attributes defined by most build rules.

This attribute should be used to list other `pwsh_library` rules that provide interpreted program source code depended on by the code in srcs. The files provided by these rules will be present among the runfiles of this target.
*

PwshInfo2[]k
i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}X
V
srcsHThe list of source (.ps1) files that are processed to create the target.2[]�pwsh_librarysThe main use for this rule is to aggregate together a logical
"library" consisting of related scripts and modules.
"�
�
pwsh_librarysThe main use for this rule is to aggregate together a logical
"library" consisting of related scripts and modules.
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]�
deps�The list of "library" targets to be aggregated into this target. See general comments about deps at Typical attributes defined by most build rules.

This attribute should be used to list other `pwsh_library` rules that provide interpreted program source code depended on by the code in srcs. The files provided by these rules will be present among the runfiles of this target.
*

PwshInfo2[]O
srcsAThe list of source files that are processed to create the target.2[]"7
pwsh_library'@@rules_powershell//powershell:defs.bzl
[[,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]�
�
deps�The list of "library" targets to be aggregated into this target. See general comments about deps at Typical attributes defined by most build rules.

This attribute should be used to list other `pwsh_library` rules that provide interpreted program source code depended on by the code in srcs. The files provided by these rules will be present among the runfiles of this target.
*

PwshInfo2[]Q
O
srcsAThe list of source files that are processed to create the target.2[]�PwshInfo A provider for Powershell rules.2�
�
PwshInfo A provider for Powershell rules.w
importslDepset[str]: The rlocationpaths of all transitive module files (.psm1, .psd1) used to set up `PSModulePath`.V
srcsNDepset[File]: The source files directly associated with the powershell target.h
transitive_srcsUDepset[File]: The source files of this target and all of its transitive dependencies."3
PwshInfo'@@rules_powershell//powershell:defs.bzl
y
w
importslDepset[str]: The rlocationpaths of all transitive module files (.psm1, .psd1) used to set up `PSModulePath`.X
V
srcsNDepset[File]: The source files directly associated with the powershell target.j
h
transitive_srcsUDepset[File]: The source files of this target and all of its transitive dependencies.�
//powershell:pwsh_binary.bzlrj
/
rules_powershell
powershellpwsh_binary.bzl)
pwsh_binary_pwsh_binary
7C
T�
//powershell:pwsh_info.bzlrb
-
rules_powershell
powershellpwsh_info.bzl#
PwshInfo	_PwshInfo
5>
L�
//powershell:pwsh_library.bzlrm
0
rules_powershell
powershellpwsh_library.bzl+
pwsh_library_pwsh_library
8E
W�
//powershell:pwsh_test.bzlrd
-
rules_powershell
powershellpwsh_test.bzl%
	pwsh_test
_pwsh_test
5?
N# Powershell rules�
.
rules_powershell
powershellextensions.bzl*�ModuleInfo request error: invalid argument: Traceback (most recent call last):
	File "external/rules_powershell/powershell/private/toolchain_repo.bzl", line 55, column 44, in <toplevel>
		_BAZEL_MAJOR_VERSION = _bazel_major_version()
	File "external/rules_powershell/powershell/private/toolchain_repo.bzl", line 50, column 20, in _bazel_major_version
		major = version.split(".")[0]
Error: 'build.stack.devtools.build.constellate.fakebuildapi.FakeStarlarkNativeModuleApi$2' value has no field or method 'split'�
/
rules_powershell
powershellpwsh_binary.bzl�pwsh_binary�The `pwsh_binary` rule is used to declare executable powershell scripts.
(`pwsh_binary` is a misnomer: its outputs aren't necessarily binaries.) This rule ensures
that all dependencies are built, and appear in the `runfiles` area at execution time.
We recommend that you name your `pwsh_binary()` rules after the name of the script minus
the extension (e.g. `.ps1`); the rule name and the file name must be distinct.

The script runs with the same semantics as `pwsh -File`: `param()` blocks receive the
command line arguments, `exit N` sets the process exit code, and an uncaught terminating
error exits with code 1.

For a simple Powershell script with no dependencies and some data files:

```python
pwsh_binary(
    name = "foo",
    srcs = ["foo.ps1"],
    data = glob(["datafiles/*.txt"]),
)
```
"�
�
pwsh_binary�The `pwsh_binary` rule is used to declare executable powershell scripts.
(`pwsh_binary` is a misnomer: its outputs aren't necessarily binaries.) This rule ensures
that all dependencies are built, and appear in the `runfiles` area at execution time.
We recommend that you name your `pwsh_binary()` rules after the name of the script minus
the extension (e.g. `.ps1`); the rule name and the file name must be distinct.

The script runs with the same semantics as `pwsh -File`: `param()` blocks receive the
command line arguments, `exit N` sets the process exit code, and an uncaught terminating
error exits with code 1.

For a simple Powershell script with no dependencies and some data files:

```python
pwsh_binary(
    name = "foo",
    srcs = ["foo.ps1"],
    data = glob(["datafiles/*.txt"]),
)
```
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]�
deps�The list of "library" targets to be aggregated into this target. See general comments about deps at Typical attributes defined by most build rules.

This attribute should be used to list other `pwsh_library` rules that provide interpreted program source code depended on by the code in srcs. The files provided by these rules will be present among the runfiles of this target.
*

PwshInfo2[]i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}V
srcsHThe list of source (.ps1) files that are processed to create the target.2[]"=
pwsh_binary.@@rules_powershell//powershell:pwsh_binary.bzl
��,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]�
�
deps�The list of "library" targets to be aggregated into this target. See general comments about deps at Typical attributes defined by most build rules.

This attribute should be used to list other `pwsh_library` rules that provide interpreted program source code depended on by the code in srcs. The files provided by these rules will be present among the runfiles of this target.
*

PwshInfo2[]k
i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}X
V
srcsHThe list of source (.ps1) files that are processed to create the target.2[]�
(//powershell/private:pwsh_executable.bzlrv
;
rules_powershellpowershell/privatepwsh_executable.bzl)
pwsh_binary_pwsh_binary
CO
`pwsh_binary�
-
rules_powershell
powershellpwsh_info.bzl�PwshInfo A provider for Powershell rules.2�
�
PwshInfo A provider for Powershell rules.w
importslDepset[str]: The rlocationpaths of all transitive module files (.psm1, .psd1) used to set up `PSModulePath`.V
srcsNDepset[File]: The source files directly associated with the powershell target.h
transitive_srcsUDepset[File]: The source files of this target and all of its transitive dependencies."8
PwshInfo,@@rules_powershell//powershell:pwsh_info.bzl
y
w
importslDepset[str]: The rlocationpaths of all transitive module files (.psm1, .psd1) used to set up `PSModulePath`.X
V
srcsNDepset[File]: The source files directly associated with the powershell target.j
h
transitive_srcsUDepset[File]: The source files of this target and all of its transitive dependencies.�
#//powershell/private:powershell.bzlrk
6
rules_powershellpowershell/privatepowershell.bzl#
PwshInfo	_PwshInfo
>G
UPwshInfo�
0
rules_powershell
powershellpwsh_library.bzl�pwsh_librarysThe main use for this rule is to aggregate together a logical
"library" consisting of related scripts and modules.
"�
�
pwsh_librarysThe main use for this rule is to aggregate together a logical
"library" consisting of related scripts and modules.
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]�
deps�The list of "library" targets to be aggregated into this target. See general comments about deps at Typical attributes defined by most build rules.

This attribute should be used to list other `pwsh_library` rules that provide interpreted program source code depended on by the code in srcs. The files provided by these rules will be present among the runfiles of this target.
*

PwshInfo2[]O
srcsAThe list of source files that are processed to create the target.2[]"?
pwsh_library/@@rules_powershell//powershell:pwsh_library.bzl
[[,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]�
�
deps�The list of "library" targets to be aggregated into this target. See general comments about deps at Typical attributes defined by most build rules.

This attribute should be used to list other `pwsh_library` rules that provide interpreted program source code depended on by the code in srcs. The files provided by these rules will be present among the runfiles of this target.
*

PwshInfo2[]Q
O
srcsAThe list of source files that are processed to create the target.2[]�
#//powershell/private:powershell.bzlrs
6
rules_powershellpowershell/privatepowershell.bzl+
pwsh_library_pwsh_library
>K
]pwsh_library�
2
rules_powershell
powershellpwsh_toolchain.bzl�pwsh_toolchain�
A toolchain for providing Powershell to Bazel rules.

Example:

```python
load("@rules_powershell//powershell:pwsh_toolchain.bzl", "pwsh_toolchain")

filegroup(
    name = "powershell_bin",
    srcs = ["powershell/pwsh"],
    # Note that additional runfiles associated with a hermetic archive
    # of powershell should be associated with the target passed to the
    # `pwsh` attribute. The executable itself must carry the executable
    # bit; the upstream unix archives do not set it.
    data = glob(["powershell/**"]),
)

pwsh_toolchain(
    name = "pwsh_toolchain",
    pwsh = ":powershell_bin",
    visibility = ["//visibility:public"],
)
```

For users looking to use a system install of Powershell, a shell/batch script
should be added that points to the system install.

Example of a non-hermetic toolchain:

`pwsh.sh`
```bash
#!/usr/bin/env bash
set -euo pipefail
exec /usr/bin/pwsh "$@"
```

`pwsh.bat`
```batch
@ECHO OFF
"C:\Program Files\PowerShell\7\pwsh.exe" %*
exit /b %ERRORLEVEL%
```

```python
load("@rules_powershell//powershell:pwsh_toolchain.bzl", "pwsh_toolchain")

filegroup(
    name = "powershell_bin",
    srcs = select({
        "@platforms//os:windows": ["pwsh.bat"],
        "//conditions:default": ["pwsh.sh"],
    }),
)

pwsh_toolchain(
    name = "pwsh_toolchain",
    pwsh = ":powershell_bin",
    visibility = ["//visibility:public"],
)
```
"�
�
pwsh_toolchain�
A toolchain for providing Powershell to Bazel rules.

Example:

```python
load("@rules_powershell//powershell:pwsh_toolchain.bzl", "pwsh_toolchain")

filegroup(
    name = "powershell_bin",
    srcs = ["powershell/pwsh"],
    # Note that additional runfiles associated with a hermetic archive
    # of powershell should be associated with the target passed to the
    # `pwsh` attribute. The executable itself must carry the executable
    # bit; the upstream unix archives do not set it.
    data = glob(["powershell/**"]),
)

pwsh_toolchain(
    name = "pwsh_toolchain",
    pwsh = ":powershell_bin",
    visibility = ["//visibility:public"],
)
```

For users looking to use a system install of Powershell, a shell/batch script
should be added that points to the system install.

Example of a non-hermetic toolchain:

`pwsh.sh`
```bash
#!/usr/bin/env bash
set -euo pipefail
exec /usr/bin/pwsh "$@"
```

`pwsh.bat`
```batch
@ECHO OFF
"C:\Program Files\PowerShell\7\pwsh.exe" %*
exit /b %ERRORLEVEL%
```

```python
load("@rules_powershell//powershell:pwsh_toolchain.bzl", "pwsh_toolchain")

filegroup(
    name = "powershell_bin",
    srcs = select({
        "@platforms//os:windows": ["pwsh.bat"],
        "//conditions:default": ["pwsh.sh"],
    }),
)

pwsh_toolchain(
    name = "pwsh_toolchain",
    pwsh = ":powershell_bin",
    visibility = ["//visibility:public"],
)
```
*
nameA unique name for this target. &
pwshThe Powershell executable. "C
pwsh_toolchain1@@rules_powershell//powershell:pwsh_toolchain.bzl
,
*
nameA unique name for this target. (
&
pwshThe Powershell executable. �
"//powershell/private:toolchain.bzlrv
5
rules_powershellpowershell/privatetoolchain.bzl/
pwsh_toolchain_pwsh_toolchain

pwsh_toolchainX

rules_powershellversion.bzl	VERSION0.3.1j0.3.1rules_powershell version 