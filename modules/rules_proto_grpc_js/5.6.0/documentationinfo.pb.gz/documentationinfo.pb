Ɋ

rules_proto_grpc_jsdefs.bzl�js_grpc_compile"�
�
js_grpc_compile*
nameA unique name for this target. M
extra_plugins6List of extra protoc plugins to use during compilation2[]a
extra_protoc_argsFA list of extra args to pass directly to protoc, not as plugin options2[]k
extra_protoc_filesOList of labels that provide extra files to be available during protoc execution2[]�
options�Extra options to pass to plugins, as a dict of plugin label -> list of strings. The key * can be used exclusively to apply to all plugins �
output_mode�The output mode for the target. PREFIXED (the default) will output to a directory named by the target within the current package root, NO_PREFIX will output files directly to the current package, NO_PREFIX_FLAT will ouput directly to the current package without mirroring the package tree. Using NO_PREFIX may lead to conflicting writes2
"PREFIXED"R
prefix_path=Path to prefix to the generated files in the output directory2""t
protosYList of labels that provide the ProtoInfo provider (such as proto_library from @protobuf) *
	ProtoInfo�
verbose�The verbosity level. Supported values and results are 0: Show nothing, 1: Show command, 2: Show command and sandbox after running protoc, 3: Show command and sandbox before and after running protoc, 4. Show env, command, expected outputs and sandbox before and after running protoc20"3
js_grpc_compile @@rules_proto_grpc_js//:defs.bzl
,
*
nameA unique name for this target. O
M
extra_plugins6List of extra protoc plugins to use during compilation2[]c
a
extra_protoc_argsFA list of extra args to pass directly to protoc, not as plugin options2[]m
k
extra_protoc_filesOList of labels that provide extra files to be available during protoc execution2[]�
�
options�Extra options to pass to plugins, as a dict of plugin label -> list of strings. The key * can be used exclusively to apply to all plugins �
�
output_mode�The output mode for the target. PREFIXED (the default) will output to a directory named by the target within the current package root, NO_PREFIX will output files directly to the current package, NO_PREFIX_FLAT will ouput directly to the current package without mirroring the package tree. Using NO_PREFIX may lead to conflicting writes2
"PREFIXED"T
R
prefix_path=Path to prefix to the generated files in the output directory2""v
t
protosYList of labels that provide the ProtoInfo provider (such as proto_library from @protobuf) *
	ProtoInfo�
�
verbose�The verbosity level. Supported values and results are 0: Show nothing, 1: Show command, 2: Show command and sandbox after running protoc, 3: Show command and sandbox before and after running protoc, 4. Show env, command, expected outputs and sandbox before and after running protoc20�js_grpc_web_compile"�
�
js_grpc_web_compile*
nameA unique name for this target. M
extra_plugins6List of extra protoc plugins to use during compilation2[]a
extra_protoc_argsFA list of extra args to pass directly to protoc, not as plugin options2[]k
extra_protoc_filesOList of labels that provide extra files to be available during protoc execution2[]�
options�Extra options to pass to plugins, as a dict of plugin label -> list of strings. The key * can be used exclusively to apply to all plugins �
output_mode�The output mode for the target. PREFIXED (the default) will output to a directory named by the target within the current package root, NO_PREFIX will output files directly to the current package, NO_PREFIX_FLAT will ouput directly to the current package without mirroring the package tree. Using NO_PREFIX may lead to conflicting writes2
"PREFIXED"R
prefix_path=Path to prefix to the generated files in the output directory2""t
protosYList of labels that provide the ProtoInfo provider (such as proto_library from @protobuf) *
	ProtoInfo�
verbose�The verbosity level. Supported values and results are 0: Show nothing, 1: Show command, 2: Show command and sandbox after running protoc, 3: Show command and sandbox before and after running protoc, 4. Show env, command, expected outputs and sandbox before and after running protoc20"7
js_grpc_web_compile @@rules_proto_grpc_js//:defs.bzl
,
*
nameA unique name for this target. O
M
extra_plugins6List of extra protoc plugins to use during compilation2[]c
a
extra_protoc_argsFA list of extra args to pass directly to protoc, not as plugin options2[]m
k
extra_protoc_filesOList of labels that provide extra files to be available during protoc execution2[]�
�
options�Extra options to pass to plugins, as a dict of plugin label -> list of strings. The key * can be used exclusively to apply to all plugins �
�
output_mode�The output mode for the target. PREFIXED (the default) will output to a directory named by the target within the current package root, NO_PREFIX will output files directly to the current package, NO_PREFIX_FLAT will ouput directly to the current package without mirroring the package tree. Using NO_PREFIX may lead to conflicting writes2
"PREFIXED"T
R
prefix_path=Path to prefix to the generated files in the output directory2""v
t
protosYList of labels that provide the ProtoInfo provider (such as proto_library from @protobuf) *
	ProtoInfo�
�
verbose�The verbosity level. Supported values and results are 0: Show nothing, 1: Show command, 2: Show command and sandbox after running protoc, 3: Show command and sandbox before and after running protoc, 4. Show env, command, expected outputs and sandbox before and after running protoc20�js_proto_compile"�
�
js_proto_compile*
nameA unique name for this target. M
extra_plugins6List of extra protoc plugins to use during compilation2[]a
extra_protoc_argsFA list of extra args to pass directly to protoc, not as plugin options2[]k
extra_protoc_filesOList of labels that provide extra files to be available during protoc execution2[]�
options�Extra options to pass to plugins, as a dict of plugin label -> list of strings. The key * can be used exclusively to apply to all plugins �
output_mode�The output mode for the target. PREFIXED (the default) will output to a directory named by the target within the current package root, NO_PREFIX will output files directly to the current package, NO_PREFIX_FLAT will ouput directly to the current package without mirroring the package tree. Using NO_PREFIX may lead to conflicting writes2
"PREFIXED"R
prefix_path=Path to prefix to the generated files in the output directory2""t
protosYList of labels that provide the ProtoInfo provider (such as proto_library from @protobuf) *
	ProtoInfo�
verbose�The verbosity level. Supported values and results are 0: Show nothing, 1: Show command, 2: Show command and sandbox after running protoc, 3: Show command and sandbox before and after running protoc, 4. Show env, command, expected outputs and sandbox before and after running protoc20"4
js_proto_compile @@rules_proto_grpc_js//:defs.bzl
,
*
nameA unique name for this target. O
M
extra_plugins6List of extra protoc plugins to use during compilation2[]c
a
extra_protoc_argsFA list of extra args to pass directly to protoc, not as plugin options2[]m
k
extra_protoc_filesOList of labels that provide extra files to be available during protoc execution2[]�
�
options�Extra options to pass to plugins, as a dict of plugin label -> list of strings. The key * can be used exclusively to apply to all plugins �
�
output_mode�The output mode for the target. PREFIXED (the default) will output to a directory named by the target within the current package root, NO_PREFIX will output files directly to the current package, NO_PREFIX_FLAT will ouput directly to the current package without mirroring the package tree. Using NO_PREFIX may lead to conflicting writes2
"PREFIXED"T
R
prefix_path=Path to prefix to the generated files in the output directory2""v
t
protosYList of labels that provide the ProtoInfo provider (such as proto_library from @protobuf) *
	ProtoInfo�
�
verbose�The verbosity level. Supported values and results are 0: Show nothing, 1: Show command, 2: Show command and sandbox after running protoc, 3: Show command and sandbox before and after running protoc, 4. Show env, command, expected outputs and sandbox before and after running protoc20�js_grpc_library"�
�
js_grpc_library*
nameA unique name for this target. M
extra_plugins6List of extra protoc plugins to use during compilation2[]a
extra_protoc_argsFA list of extra args to pass directly to protoc, not as plugin options2[]k
extra_protoc_filesOList of labels that provide extra files to be available during protoc execution2[]�
options�Extra options to pass to plugins, as a dict of plugin label -> list of strings. The key * can be used exclusively to apply to all plugins �
output_mode�The output mode for the target. PREFIXED (the default) will output to a directory named by the target within the current package root, NO_PREFIX will output files directly to the current package, NO_PREFIX_FLAT will ouput directly to the current package without mirroring the package tree. Using NO_PREFIX may lead to conflicting writes2
"PREFIXED"R
prefix_path=Path to prefix to the generated files in the output directory2""t
protosYList of labels that provide the ProtoInfo provider (such as proto_library from @protobuf) *
	ProtoInfo�
verbose�The verbosity level. Supported values and results are 0: Show nothing, 1: Show command, 2: Show command and sandbox after running protoc, 3: Show command and sandbox before and after running protoc, 4. Show env, command, expected outputs and sandbox before and after running protoc20"3
js_grpc_compile @@rules_proto_grpc_js//:defs.bzl
,
*
nameA unique name for this target. O
M
extra_plugins6List of extra protoc plugins to use during compilation2[]c
a
extra_protoc_argsFA list of extra args to pass directly to protoc, not as plugin options2[]m
k
extra_protoc_filesOList of labels that provide extra files to be available during protoc execution2[]�
�
options�Extra options to pass to plugins, as a dict of plugin label -> list of strings. The key * can be used exclusively to apply to all plugins �
�
output_mode�The output mode for the target. PREFIXED (the default) will output to a directory named by the target within the current package root, NO_PREFIX will output files directly to the current package, NO_PREFIX_FLAT will ouput directly to the current package without mirroring the package tree. Using NO_PREFIX may lead to conflicting writes2
"PREFIXED"T
R
prefix_path=Path to prefix to the generated files in the output directory2""v
t
protosYList of labels that provide the ProtoInfo provider (such as proto_library from @protobuf) *
	ProtoInfo�
�
verbose�The verbosity level. Supported values and results are 0: Show nothing, 1: Show command, 2: Show command and sandbox after running protoc, 3: Show command and sandbox before and after running protoc, 4. Show env, command, expected outputs and sandbox before and after running protoc20�Ujs_grpc_web_library�A library of JavaScript sources. Provides JsInfo, the primary provider used in rules_js
and derivative rule sets.

Declaration files are handled separately from sources since they are generally not needed at
runtime and build rules, such as ts_project, are optimal in their build graph if they only depend
on types from `deps` since these they don't need the JavaScript source files from deps to
typecheck.

Linked npm dependences are also handled separately from sources since not all rules require them and it
is optimal for these rules to not depend on them in the build graph.

NB: `js_library` copies all source files to the output tree before providing them in JsInfo. See
https://github.com/aspect-build/rules_js/tree/dbb5af0d2a9a2bb50e4cf4a96dbc582b27567155/docs#javascript
for more context on why we do this."�N
�*
js_grpc_web_library�A library of JavaScript sources. Provides JsInfo, the primary provider used in rules_js
and derivative rule sets.

Declaration files are handled separately from sources since they are generally not needed at
runtime and build rules, such as ts_project, are optimal in their build graph if they only depend
on types from `deps` since these they don't need the JavaScript source files from deps to
typecheck.

Linked npm dependences are also handled separately from sources since not all rules require them and it
is optimal for these rules to not depend on them in the build graph.

NB: `js_library` copies all source files to the output tree before providing them in JsInfo. See
https://github.com/aspect-build/rules_js/tree/dbb5af0d2a9a2bb50e4cf4a96dbc582b27567155/docs#javascript
for more context on why we do this.*
nameA unique name for this target. �
copy_data_to_binfWhen True, `data` files are copied to the Bazel output tree before being passed as inputs to runfiles.2True�
data�Runtime dependencies to include in binaries/tests that depend on this target.

The transitive npm dependencies, transitive sources, default outputs and runfiles of targets in the `data` attribute
are added to the runfiles of this target. They should appear in the '*.runfiles' area of any executable which has
a runtime dependency on this target.

If this list contains linked npm packages, npm package store targets or other targets that provide
`JsInfo`, `NpmPackageStoreInfo` providers are gathered from `JsInfo`. This is done directly from
the `npm_package_store_infos` field of these. For linked npm package targets, the underlying
`npm_package_store` target(s) that back the links are used. Gathered `NpmPackageStoreInfo`
providers are propagated to the direct dependencies of downstream linked targets.

NB: Linked npm package targets that are "dev" dependencies do not forward their underlying
`npm_package_store` target(s) through `npm_package_store_infos` and will therefore not be
propagated to the direct dependencies of downstream linked targets. npm packages
that come in from `npm_translate_lock` are considered "dev" dependencies if they are have
`dev: true` set in the pnpm lock file. This should be all packages that are only listed as
"devDependencies" in all `package.json` files within the pnpm workspace. This behavior is
intentional to mimic how `devDependencies` work in published npm packages.

2[]�
deps�Dependencies of this target.

This may include other js_library targets or other targets that provide JsInfo

The transitive npm dependencies, transitive sources & runfiles of targets in the `deps` attribute are added to the
runfiles of this target. They should appear in the '*.runfiles' area of any executable which is output by or has a
runtime dependency on this target.

If this list contains linked npm packages, npm package store targets or other targets that provide
`JsInfo`, `NpmPackageStoreInfo` providers are gathered from `JsInfo`. This is done directly from
the `npm_package_store_infos` field of these. For linked npm package targets, the underlying
`npm_package_store` target(s) that back the links are used. Gathered `NpmPackageStoreInfo`
providers are propagated to the direct dependencies of downstream linked targets.

NB: Linked npm package targets that are "dev" dependencies do not forward their underlying
`npm_package_store` target(s) through `npm_package_store_infos` and will therefore not be
propagated to the direct dependencies of downstream linked targets. npm packages
that come in from `npm_translate_lock` are considered "dev" dependencies if they are have
`dev: true` set in the pnpm lock file. This should be all packages that are only listed as
"devDependencies" in all `package.json` files within the pnpm workspace. This behavior is
intentional to mimic how `devDependencies` work in published npm packages.

*
JsInfo2[]�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
srcs�Source files that are included in this library.

This includes all your checked-in code and any generated source files.

The transitive npm dependencies, transitive sources & runfiles of targets in the `srcs` attribute are added to the
runfiles of this target. They should appear in the '*.runfiles' area of any executable which is output by or has a
runtime dependency on this target.

Source files that are JSON files, declaration files or directory artifacts will be automatically provided as
"types" available to downstream rules for type checking. To explicitly provide source files as "types"
available to downstream rules for type checking that do not match these criteria, move those files to the `types`
attribute instead.
2[]�
types�Same as `srcs` except all files are also provided as "types" available to downstream rules for type checking.

For example, a js_library with only `.js` files that are intended to be imported as `.js` files by downstream type checking
rules such as `ts_project` would list those files in `types`:

```
js_library(
    name = "js_lib",
    types = ["index.js"],
)
```
2[]
,
*
nameA unique name for this target. �
�
copy_data_to_binfWhen True, `data` files are copied to the Bazel output tree before being passed as inputs to runfiles.2True�
�
data�Runtime dependencies to include in binaries/tests that depend on this target.

The transitive npm dependencies, transitive sources, default outputs and runfiles of targets in the `data` attribute
are added to the runfiles of this target. They should appear in the '*.runfiles' area of any executable which has
a runtime dependency on this target.

If this list contains linked npm packages, npm package store targets or other targets that provide
`JsInfo`, `NpmPackageStoreInfo` providers are gathered from `JsInfo`. This is done directly from
the `npm_package_store_infos` field of these. For linked npm package targets, the underlying
`npm_package_store` target(s) that back the links are used. Gathered `NpmPackageStoreInfo`
providers are propagated to the direct dependencies of downstream linked targets.

NB: Linked npm package targets that are "dev" dependencies do not forward their underlying
`npm_package_store` target(s) through `npm_package_store_infos` and will therefore not be
propagated to the direct dependencies of downstream linked targets. npm packages
that come in from `npm_translate_lock` are considered "dev" dependencies if they are have
`dev: true` set in the pnpm lock file. This should be all packages that are only listed as
"devDependencies" in all `package.json` files within the pnpm workspace. This behavior is
intentional to mimic how `devDependencies` work in published npm packages.

2[]�
�
deps�Dependencies of this target.

This may include other js_library targets or other targets that provide JsInfo

The transitive npm dependencies, transitive sources & runfiles of targets in the `deps` attribute are added to the
runfiles of this target. They should appear in the '*.runfiles' area of any executable which is output by or has a
runtime dependency on this target.

If this list contains linked npm packages, npm package store targets or other targets that provide
`JsInfo`, `NpmPackageStoreInfo` providers are gathered from `JsInfo`. This is done directly from
the `npm_package_store_infos` field of these. For linked npm package targets, the underlying
`npm_package_store` target(s) that back the links are used. Gathered `NpmPackageStoreInfo`
providers are propagated to the direct dependencies of downstream linked targets.

NB: Linked npm package targets that are "dev" dependencies do not forward their underlying
`npm_package_store` target(s) through `npm_package_store_infos` and will therefore not be
propagated to the direct dependencies of downstream linked targets. npm packages
that come in from `npm_translate_lock` are considered "dev" dependencies if they are have
`dev: true` set in the pnpm lock file. This should be all packages that are only listed as
"devDependencies" in all `package.json` files within the pnpm workspace. This behavior is
intentional to mimic how `devDependencies` work in published npm packages.

*
JsInfo2[]�
�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
�
srcs�Source files that are included in this library.

This includes all your checked-in code and any generated source files.

The transitive npm dependencies, transitive sources & runfiles of targets in the `srcs` attribute are added to the
runfiles of this target. They should appear in the '*.runfiles' area of any executable which is output by or has a
runtime dependency on this target.

Source files that are JSON files, declaration files or directory artifacts will be automatically provided as
"types" available to downstream rules for type checking. To explicitly provide source files as "types"
available to downstream rules for type checking that do not match these criteria, move those files to the `types`
attribute instead.
2[]�
�
types�Same as `srcs` except all files are also provided as "types" available to downstream rules for type checking.

For example, a js_library with only `.js` files that are intended to be imported as `.js` files by downstream type checking
rules such as `ts_project` would list those files in `types`:

```
js_library(
    name = "js_lib",
    types = ["index.js"],
)
```
2[]�Ujs_proto_library�A library of JavaScript sources. Provides JsInfo, the primary provider used in rules_js
and derivative rule sets.

Declaration files are handled separately from sources since they are generally not needed at
runtime and build rules, such as ts_project, are optimal in their build graph if they only depend
on types from `deps` since these they don't need the JavaScript source files from deps to
typecheck.

Linked npm dependences are also handled separately from sources since not all rules require them and it
is optimal for these rules to not depend on them in the build graph.

NB: `js_library` copies all source files to the output tree before providing them in JsInfo. See
https://github.com/aspect-build/rules_js/tree/dbb5af0d2a9a2bb50e4cf4a96dbc582b27567155/docs#javascript
for more context on why we do this."�N
�*
js_proto_library�A library of JavaScript sources. Provides JsInfo, the primary provider used in rules_js
and derivative rule sets.

Declaration files are handled separately from sources since they are generally not needed at
runtime and build rules, such as ts_project, are optimal in their build graph if they only depend
on types from `deps` since these they don't need the JavaScript source files from deps to
typecheck.

Linked npm dependences are also handled separately from sources since not all rules require them and it
is optimal for these rules to not depend on them in the build graph.

NB: `js_library` copies all source files to the output tree before providing them in JsInfo. See
https://github.com/aspect-build/rules_js/tree/dbb5af0d2a9a2bb50e4cf4a96dbc582b27567155/docs#javascript
for more context on why we do this.*
nameA unique name for this target. �
copy_data_to_binfWhen True, `data` files are copied to the Bazel output tree before being passed as inputs to runfiles.2True�
data�Runtime dependencies to include in binaries/tests that depend on this target.

The transitive npm dependencies, transitive sources, default outputs and runfiles of targets in the `data` attribute
are added to the runfiles of this target. They should appear in the '*.runfiles' area of any executable which has
a runtime dependency on this target.

If this list contains linked npm packages, npm package store targets or other targets that provide
`JsInfo`, `NpmPackageStoreInfo` providers are gathered from `JsInfo`. This is done directly from
the `npm_package_store_infos` field of these. For linked npm package targets, the underlying
`npm_package_store` target(s) that back the links are used. Gathered `NpmPackageStoreInfo`
providers are propagated to the direct dependencies of downstream linked targets.

NB: Linked npm package targets that are "dev" dependencies do not forward their underlying
`npm_package_store` target(s) through `npm_package_store_infos` and will therefore not be
propagated to the direct dependencies of downstream linked targets. npm packages
that come in from `npm_translate_lock` are considered "dev" dependencies if they are have
`dev: true` set in the pnpm lock file. This should be all packages that are only listed as
"devDependencies" in all `package.json` files within the pnpm workspace. This behavior is
intentional to mimic how `devDependencies` work in published npm packages.

2[]�
deps�Dependencies of this target.

This may include other js_library targets or other targets that provide JsInfo

The transitive npm dependencies, transitive sources & runfiles of targets in the `deps` attribute are added to the
runfiles of this target. They should appear in the '*.runfiles' area of any executable which is output by or has a
runtime dependency on this target.

If this list contains linked npm packages, npm package store targets or other targets that provide
`JsInfo`, `NpmPackageStoreInfo` providers are gathered from `JsInfo`. This is done directly from
the `npm_package_store_infos` field of these. For linked npm package targets, the underlying
`npm_package_store` target(s) that back the links are used. Gathered `NpmPackageStoreInfo`
providers are propagated to the direct dependencies of downstream linked targets.

NB: Linked npm package targets that are "dev" dependencies do not forward their underlying
`npm_package_store` target(s) through `npm_package_store_infos` and will therefore not be
propagated to the direct dependencies of downstream linked targets. npm packages
that come in from `npm_translate_lock` are considered "dev" dependencies if they are have
`dev: true` set in the pnpm lock file. This should be all packages that are only listed as
"devDependencies" in all `package.json` files within the pnpm workspace. This behavior is
intentional to mimic how `devDependencies` work in published npm packages.

*
JsInfo2[]�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
srcs�Source files that are included in this library.

This includes all your checked-in code and any generated source files.

The transitive npm dependencies, transitive sources & runfiles of targets in the `srcs` attribute are added to the
runfiles of this target. They should appear in the '*.runfiles' area of any executable which is output by or has a
runtime dependency on this target.

Source files that are JSON files, declaration files or directory artifacts will be automatically provided as
"types" available to downstream rules for type checking. To explicitly provide source files as "types"
available to downstream rules for type checking that do not match these criteria, move those files to the `types`
attribute instead.
2[]�
types�Same as `srcs` except all files are also provided as "types" available to downstream rules for type checking.

For example, a js_library with only `.js` files that are intended to be imported as `.js` files by downstream type checking
rules such as `ts_project` would list those files in `types`:

```
js_library(
    name = "js_lib",
    types = ["index.js"],
)
```
2[]
,
*
nameA unique name for this target. �
�
copy_data_to_binfWhen True, `data` files are copied to the Bazel output tree before being passed as inputs to runfiles.2True�
�
data�Runtime dependencies to include in binaries/tests that depend on this target.

The transitive npm dependencies, transitive sources, default outputs and runfiles of targets in the `data` attribute
are added to the runfiles of this target. They should appear in the '*.runfiles' area of any executable which has
a runtime dependency on this target.

If this list contains linked npm packages, npm package store targets or other targets that provide
`JsInfo`, `NpmPackageStoreInfo` providers are gathered from `JsInfo`. This is done directly from
the `npm_package_store_infos` field of these. For linked npm package targets, the underlying
`npm_package_store` target(s) that back the links are used. Gathered `NpmPackageStoreInfo`
providers are propagated to the direct dependencies of downstream linked targets.

NB: Linked npm package targets that are "dev" dependencies do not forward their underlying
`npm_package_store` target(s) through `npm_package_store_infos` and will therefore not be
propagated to the direct dependencies of downstream linked targets. npm packages
that come in from `npm_translate_lock` are considered "dev" dependencies if they are have
`dev: true` set in the pnpm lock file. This should be all packages that are only listed as
"devDependencies" in all `package.json` files within the pnpm workspace. This behavior is
intentional to mimic how `devDependencies` work in published npm packages.

2[]�
�
deps�Dependencies of this target.

This may include other js_library targets or other targets that provide JsInfo

The transitive npm dependencies, transitive sources & runfiles of targets in the `deps` attribute are added to the
runfiles of this target. They should appear in the '*.runfiles' area of any executable which is output by or has a
runtime dependency on this target.

If this list contains linked npm packages, npm package store targets or other targets that provide
`JsInfo`, `NpmPackageStoreInfo` providers are gathered from `JsInfo`. This is done directly from
the `npm_package_store_infos` field of these. For linked npm package targets, the underlying
`npm_package_store` target(s) that back the links are used. Gathered `NpmPackageStoreInfo`
providers are propagated to the direct dependencies of downstream linked targets.

NB: Linked npm package targets that are "dev" dependencies do not forward their underlying
`npm_package_store` target(s) through `npm_package_store_infos` and will therefore not be
propagated to the direct dependencies of downstream linked targets. npm packages
that come in from `npm_translate_lock` are considered "dev" dependencies if they are have
`dev: true` set in the pnpm lock file. This should be all packages that are only listed as
"devDependencies" in all `package.json` files within the pnpm workspace. This behavior is
intentional to mimic how `devDependencies` work in published npm packages.

*
JsInfo2[]�
�
no_copy_to_bin�List of files to not copy to the Bazel output tree when `copy_data_to_bin` is True.

This is useful for exceptional cases where a `copy_to_bin` is not possible or not suitable for an input
file such as a file in an external repository. In most cases, this option is not needed.
See `copy_data_to_bin` docstring for more info.
2[]�
�
srcs�Source files that are included in this library.

This includes all your checked-in code and any generated source files.

The transitive npm dependencies, transitive sources & runfiles of targets in the `srcs` attribute are added to the
runfiles of this target. They should appear in the '*.runfiles' area of any executable which is output by or has a
runtime dependency on this target.

Source files that are JSON files, declaration files or directory artifacts will be automatically provided as
"types" available to downstream rules for type checking. To explicitly provide source files as "types"
available to downstream rules for type checking that do not match these criteria, move those files to the `types`
attribute instead.
2[]�
�
types�Same as `srcs` except all files are also provided as "types" available to downstream rules for type checking.

For example, a js_library with only `.js` files that are intended to be imported as `.js` files by downstream type checking
rules such as `ts_project` would list those files in `types`:

```
js_library(
    name = "js_lib",
    types = ["index.js"],
)
```
2[]�
:js_grpc_compile.bzlrm
*
rules_proto_grpc_jsjs_grpc_compile.bzl1
js_grpc_compile_js_grpc_compile
4D
Y�
:js_grpc_library.bzlrm
*
rules_proto_grpc_jsjs_grpc_library.bzl1
js_grpc_library_js_grpc_library
4D
Y�
:js_grpc_web_compile.bzlry
.
rules_proto_grpc_jsjs_grpc_web_compile.bzl9
js_grpc_web_compile_js_grpc_web_compile
8L
e�
:js_grpc_web_library.bzlry
.
rules_proto_grpc_jsjs_grpc_web_library.bzl9
js_grpc_web_library_js_grpc_web_library
8L
e�
:js_proto_compile.bzlrp
+
rules_proto_grpc_jsjs_proto_compile.bzl3
js_proto_compile_js_proto_compile
5F
\�
:js_proto_library.bzlrp
+
rules_proto_grpc_jsjs_proto_library.bzl3
js_proto_library_js_proto_library
5F
\js protobuf and grpc rules.�
*
rules_proto_grpc_jsjs_grpc_compile.bzl�js_grpc_compile"�
�
js_grpc_compile*
nameA unique name for this target. M
extra_plugins6List of extra protoc plugins to use during compilation2[]a
extra_protoc_argsFA list of extra args to pass directly to protoc, not as plugin options2[]k
extra_protoc_filesOList of labels that provide extra files to be available during protoc execution2[]�
options�Extra options to pass to plugins, as a dict of plugin label -> list of strings. The key * can be used exclusively to apply to all plugins �
output_mode�The output mode for the target. PREFIXED (the default) will output to a directory named by the target within the current package root, NO_PREFIX will output files directly to the current package, NO_PREFIX_FLAT will ouput directly to the current package without mirroring the package tree. Using NO_PREFIX may lead to conflicting writes2
"PREFIXED"R
prefix_path=Path to prefix to the generated files in the output directory2""t
protosYList of labels that provide the ProtoInfo provider (such as proto_library from @protobuf) *
	ProtoInfo�
verbose�The verbosity level. Supported values and results are 0: Show nothing, 1: Show command, 2: Show command and sandbox after running protoc, 3: Show command and sandbox before and after running protoc, 4. Show env, command, expected outputs and sandbox before and after running protoc20">
js_grpc_compile+@@rules_proto_grpc_js//:js_grpc_compile.bzl
,
*
nameA unique name for this target. O
M
extra_plugins6List of extra protoc plugins to use during compilation2[]c
a
extra_protoc_argsFA list of extra args to pass directly to protoc, not as plugin options2[]m
k
extra_protoc_filesOList of labels that provide extra files to be available during protoc execution2[]�
�
options�Extra options to pass to plugins, as a dict of plugin label -> list of strings. The key * can be used exclusively to apply to all plugins �
�
output_mode�The output mode for the target. PREFIXED (the default) will output to a directory named by the target within the current package root, NO_PREFIX will output files directly to the current package, NO_PREFIX_FLAT will ouput directly to the current package without mirroring the package tree. Using NO_PREFIX may lead to conflicting writes2
"PREFIXED"T
R
prefix_path=Path to prefix to the generated files in the output directory2""v
t
protosYList of labels that provide the ProtoInfo provider (such as proto_library from @protobuf) *
	ProtoInfo�
�
verbose�The verbosity level. Supported values and results are 0: Show nothing, 1: Show command, 2: Show command and sandbox after running protoc, 3: Show command and sandbox before and after running protoc, 4. Show env, command, expected outputs and sandbox before and after running protoc20�
	:defs.bzlr�

rules_proto_grpcdefs.bzl0
ProtoPluginInfoProtoPluginInfo
8
proto_compile_attrsproto_compile_attrs
6
proto_compile_implproto_compile_impl
B
proto_compile_toolchainsproto_compile_toolchains

	(Generated definition of js_grpc_compile.�
*
rules_proto_grpc_jsjs_grpc_library.bzl�js_grpc_library"�
�

js_grpc_library*
nameA unique name for this target. M
extra_plugins6List of extra protoc plugins to use during compilation2[]a
extra_protoc_argsFA list of extra args to pass directly to protoc, not as plugin options2[]k
extra_protoc_filesOList of labels that provide extra files to be available during protoc execution2[]�
options�Extra options to pass to plugins, as a dict of plugin label -> list of strings. The key * can be used exclusively to apply to all plugins �
output_mode�The output mode for the target. PREFIXED (the default) will output to a directory named by the target within the current package root, NO_PREFIX will output files directly to the current package, NO_PREFIX_FLAT will ouput directly to the current package without mirroring the package tree. Using NO_PREFIX may lead to conflicting writes2
"PREFIXED"R
prefix_path=Path to prefix to the generated files in the output directory2""t
protosYList of labels that provide the ProtoInfo provider (such as proto_library from @protobuf) *
	ProtoInfo�
verbose�The verbosity level. Supported values and results are 0: Show nothing, 1: Show command, 2: Show command and sandbox after running protoc, 3: Show command and sandbox before and after running protoc, 4. Show env, command, expected outputs and sandbox before and after running protoc20
,
*
nameA unique name for this target. O
M
extra_plugins6List of extra protoc plugins to use during compilation2[]c
a
extra_protoc_argsFA list of extra args to pass directly to protoc, not as plugin options2[]m
k
extra_protoc_filesOList of labels that provide extra files to be available during protoc execution2[]�
�
options�Extra options to pass to plugins, as a dict of plugin label -> list of strings. The key * can be used exclusively to apply to all plugins �
�
output_mode�The output mode for the target. PREFIXED (the default) will output to a directory named by the target within the current package root, NO_PREFIX will output files directly to the current package, NO_PREFIX_FLAT will ouput directly to the current package without mirroring the package tree. Using NO_PREFIX may lead to conflicting writes2
"PREFIXED"T
R
prefix_path=Path to prefix to the generated files in the output directory2""v
t
protosYList of labels that provide the ProtoInfo provider (such as proto_library from @protobuf) *
	ProtoInfo�
�
verbose�The verbosity level. Supported values and results are 0: Show nothing, 1: Show command, 2: Show command and sandbox after running protoc, 3: Show command and sandbox before and after running protoc, 4. Show env, command, expected outputs and sandbox before and after running protoc20j
//js:defs.bzlrW

aspect_rules_jsjsdefs.bzl&

js_library
js_library
(2
4�
	:defs.bzlr�

rules_proto_grpcdefs.bzlL
bazel_build_rule_common_attrsbazel_build_rule_common_attrs
'D8
proto_compile_attrsproto_compile_attrs
H[
]�
:js_grpc_compile.bzlrl
*
rules_proto_grpc_jsjs_grpc_compile.bzl0
js_grpc_compilejs_grpc_compile
5D
FU		GRPC_DEPSjF2D
//:node_modules/@grpc/grpc-js
!//:node_modules/google-protobuf(Generated definition of js_grpc_library.�
.
rules_proto_grpc_jsjs_grpc_web_compile.bzl�js_grpc_web_compile"�
�
js_grpc_web_compile*
nameA unique name for this target. M
extra_plugins6List of extra protoc plugins to use during compilation2[]a
extra_protoc_argsFA list of extra args to pass directly to protoc, not as plugin options2[]k
extra_protoc_filesOList of labels that provide extra files to be available during protoc execution2[]�
options�Extra options to pass to plugins, as a dict of plugin label -> list of strings. The key * can be used exclusively to apply to all plugins �
output_mode�The output mode for the target. PREFIXED (the default) will output to a directory named by the target within the current package root, NO_PREFIX will output files directly to the current package, NO_PREFIX_FLAT will ouput directly to the current package without mirroring the package tree. Using NO_PREFIX may lead to conflicting writes2
"PREFIXED"R
prefix_path=Path to prefix to the generated files in the output directory2""t
protosYList of labels that provide the ProtoInfo provider (such as proto_library from @protobuf) *
	ProtoInfo�
verbose�The verbosity level. Supported values and results are 0: Show nothing, 1: Show command, 2: Show command and sandbox after running protoc, 3: Show command and sandbox before and after running protoc, 4. Show env, command, expected outputs and sandbox before and after running protoc20"F
js_grpc_web_compile/@@rules_proto_grpc_js//:js_grpc_web_compile.bzl
,
*
nameA unique name for this target. O
M
extra_plugins6List of extra protoc plugins to use during compilation2[]c
a
extra_protoc_argsFA list of extra args to pass directly to protoc, not as plugin options2[]m
k
extra_protoc_filesOList of labels that provide extra files to be available during protoc execution2[]�
�
options�Extra options to pass to plugins, as a dict of plugin label -> list of strings. The key * can be used exclusively to apply to all plugins �
�
output_mode�The output mode for the target. PREFIXED (the default) will output to a directory named by the target within the current package root, NO_PREFIX will output files directly to the current package, NO_PREFIX_FLAT will ouput directly to the current package without mirroring the package tree. Using NO_PREFIX may lead to conflicting writes2
"PREFIXED"T
R
prefix_path=Path to prefix to the generated files in the output directory2""v
t
protosYList of labels that provide the ProtoInfo provider (such as proto_library from @protobuf) *
	ProtoInfo�
�
verbose�The verbosity level. Supported values and results are 0: Show nothing, 1: Show command, 2: Show command and sandbox after running protoc, 3: Show command and sandbox before and after running protoc, 4. Show env, command, expected outputs and sandbox before and after running protoc20�
	:defs.bzlr�

rules_proto_grpcdefs.bzl0
ProtoPluginInfoProtoPluginInfo
8
proto_compile_attrsproto_compile_attrs
6
proto_compile_implproto_compile_impl
B
proto_compile_toolchainsproto_compile_toolchains

	,Generated definition of js_grpc_web_compile.�
.
rules_proto_grpc_jsjs_grpc_web_library.bzl�js_grpc_web_library"�
�

js_grpc_web_library*
nameA unique name for this target. M
extra_plugins6List of extra protoc plugins to use during compilation2[]a
extra_protoc_argsFA list of extra args to pass directly to protoc, not as plugin options2[]k
extra_protoc_filesOList of labels that provide extra files to be available during protoc execution2[]�
options�Extra options to pass to plugins, as a dict of plugin label -> list of strings. The key * can be used exclusively to apply to all plugins �
output_mode�The output mode for the target. PREFIXED (the default) will output to a directory named by the target within the current package root, NO_PREFIX will output files directly to the current package, NO_PREFIX_FLAT will ouput directly to the current package without mirroring the package tree. Using NO_PREFIX may lead to conflicting writes2
"PREFIXED"R
prefix_path=Path to prefix to the generated files in the output directory2""t
protosYList of labels that provide the ProtoInfo provider (such as proto_library from @protobuf) *
	ProtoInfo�
verbose�The verbosity level. Supported values and results are 0: Show nothing, 1: Show command, 2: Show command and sandbox after running protoc, 3: Show command and sandbox before and after running protoc, 4. Show env, command, expected outputs and sandbox before and after running protoc20
,
*
nameA unique name for this target. O
M
extra_plugins6List of extra protoc plugins to use during compilation2[]c
a
extra_protoc_argsFA list of extra args to pass directly to protoc, not as plugin options2[]m
k
extra_protoc_filesOList of labels that provide extra files to be available during protoc execution2[]�
�
options�Extra options to pass to plugins, as a dict of plugin label -> list of strings. The key * can be used exclusively to apply to all plugins �
�
output_mode�The output mode for the target. PREFIXED (the default) will output to a directory named by the target within the current package root, NO_PREFIX will output files directly to the current package, NO_PREFIX_FLAT will ouput directly to the current package without mirroring the package tree. Using NO_PREFIX may lead to conflicting writes2
"PREFIXED"T
R
prefix_path=Path to prefix to the generated files in the output directory2""v
t
protosYList of labels that provide the ProtoInfo provider (such as proto_library from @protobuf) *
	ProtoInfo�
�
verbose�The verbosity level. Supported values and results are 0: Show nothing, 1: Show command, 2: Show command and sandbox after running protoc, 3: Show command and sandbox before and after running protoc, 4. Show env, command, expected outputs and sandbox before and after running protoc20j
//js:defs.bzlrW

aspect_rules_jsjsdefs.bzl&

js_library
js_library
(2
4�
	:defs.bzlr�

rules_proto_grpcdefs.bzlL
bazel_build_rule_common_attrsbazel_build_rule_common_attrs
'D8
proto_compile_attrsproto_compile_attrs
H[
]�
:js_grpc_web_compile.bzlrx
.
rules_proto_grpc_jsjs_grpc_web_compile.bzl8
js_grpc_web_compilejs_grpc_web_compile
9L
NP		GRPC_DEPSjA2?
!//:node_modules/google-protobuf
//:node_modules/grpc-web,Generated definition of js_grpc_web_library.�
+
rules_proto_grpc_jsjs_proto_compile.bzl�js_proto_compile"�
�
js_proto_compile*
nameA unique name for this target. M
extra_plugins6List of extra protoc plugins to use during compilation2[]a
extra_protoc_argsFA list of extra args to pass directly to protoc, not as plugin options2[]k
extra_protoc_filesOList of labels that provide extra files to be available during protoc execution2[]�
options�Extra options to pass to plugins, as a dict of plugin label -> list of strings. The key * can be used exclusively to apply to all plugins �
output_mode�The output mode for the target. PREFIXED (the default) will output to a directory named by the target within the current package root, NO_PREFIX will output files directly to the current package, NO_PREFIX_FLAT will ouput directly to the current package without mirroring the package tree. Using NO_PREFIX may lead to conflicting writes2
"PREFIXED"R
prefix_path=Path to prefix to the generated files in the output directory2""t
protosYList of labels that provide the ProtoInfo provider (such as proto_library from @protobuf) *
	ProtoInfo�
verbose�The verbosity level. Supported values and results are 0: Show nothing, 1: Show command, 2: Show command and sandbox after running protoc, 3: Show command and sandbox before and after running protoc, 4. Show env, command, expected outputs and sandbox before and after running protoc20"@
js_proto_compile,@@rules_proto_grpc_js//:js_proto_compile.bzl
,
*
nameA unique name for this target. O
M
extra_plugins6List of extra protoc plugins to use during compilation2[]c
a
extra_protoc_argsFA list of extra args to pass directly to protoc, not as plugin options2[]m
k
extra_protoc_filesOList of labels that provide extra files to be available during protoc execution2[]�
�
options�Extra options to pass to plugins, as a dict of plugin label -> list of strings. The key * can be used exclusively to apply to all plugins �
�
output_mode�The output mode for the target. PREFIXED (the default) will output to a directory named by the target within the current package root, NO_PREFIX will output files directly to the current package, NO_PREFIX_FLAT will ouput directly to the current package without mirroring the package tree. Using NO_PREFIX may lead to conflicting writes2
"PREFIXED"T
R
prefix_path=Path to prefix to the generated files in the output directory2""v
t
protosYList of labels that provide the ProtoInfo provider (such as proto_library from @protobuf) *
	ProtoInfo�
�
verbose�The verbosity level. Supported values and results are 0: Show nothing, 1: Show command, 2: Show command and sandbox after running protoc, 3: Show command and sandbox before and after running protoc, 4. Show env, command, expected outputs and sandbox before and after running protoc20�
	:defs.bzlr�

rules_proto_grpcdefs.bzl0
ProtoPluginInfoProtoPluginInfo
8
proto_compile_attrsproto_compile_attrs
6
proto_compile_implproto_compile_impl
B
proto_compile_toolchainsproto_compile_toolchains

	)Generated definition of js_proto_compile.�
+
rules_proto_grpc_jsjs_proto_library.bzl�js_proto_library"�
�

js_proto_library*
nameA unique name for this target. M
extra_plugins6List of extra protoc plugins to use during compilation2[]a
extra_protoc_argsFA list of extra args to pass directly to protoc, not as plugin options2[]k
extra_protoc_filesOList of labels that provide extra files to be available during protoc execution2[]�
options�Extra options to pass to plugins, as a dict of plugin label -> list of strings. The key * can be used exclusively to apply to all plugins �
output_mode�The output mode for the target. PREFIXED (the default) will output to a directory named by the target within the current package root, NO_PREFIX will output files directly to the current package, NO_PREFIX_FLAT will ouput directly to the current package without mirroring the package tree. Using NO_PREFIX may lead to conflicting writes2
"PREFIXED"R
prefix_path=Path to prefix to the generated files in the output directory2""t
protosYList of labels that provide the ProtoInfo provider (such as proto_library from @protobuf) *
	ProtoInfo�
verbose�The verbosity level. Supported values and results are 0: Show nothing, 1: Show command, 2: Show command and sandbox after running protoc, 3: Show command and sandbox before and after running protoc, 4. Show env, command, expected outputs and sandbox before and after running protoc20
,
*
nameA unique name for this target. O
M
extra_plugins6List of extra protoc plugins to use during compilation2[]c
a
extra_protoc_argsFA list of extra args to pass directly to protoc, not as plugin options2[]m
k
extra_protoc_filesOList of labels that provide extra files to be available during protoc execution2[]�
�
options�Extra options to pass to plugins, as a dict of plugin label -> list of strings. The key * can be used exclusively to apply to all plugins �
�
output_mode�The output mode for the target. PREFIXED (the default) will output to a directory named by the target within the current package root, NO_PREFIX will output files directly to the current package, NO_PREFIX_FLAT will ouput directly to the current package without mirroring the package tree. Using NO_PREFIX may lead to conflicting writes2
"PREFIXED"T
R
prefix_path=Path to prefix to the generated files in the output directory2""v
t
protosYList of labels that provide the ProtoInfo provider (such as proto_library from @protobuf) *
	ProtoInfo�
�
verbose�The verbosity level. Supported values and results are 0: Show nothing, 1: Show command, 2: Show command and sandbox after running protoc, 3: Show command and sandbox before and after running protoc, 4. Show env, command, expected outputs and sandbox before and after running protoc20j
//js:defs.bzlrW

aspect_rules_jsjsdefs.bzl&

js_library
js_library
(2
4�
	:defs.bzlr�

rules_proto_grpcdefs.bzlL
bazel_build_rule_common_attrsbazel_build_rule_common_attrs
'D8
proto_compile_attrsproto_compile_attrs
H[
]�
:js_proto_compile.bzlro
+
rules_proto_grpc_jsjs_proto_compile.bzl2
js_proto_compilejs_proto_compile
6F
H5	
PROTO_DEPSj%2#
!//:node_modules/google-protobuf)Generated definition of js_proto_library.�
,
rules_proto_grpc_jsmodule_extensions.bzl{download_pluginsJe
U
download_plugins"A
download_plugins-@@rules_proto_grpc_js//:module_extensions.bzl
8$8$�
 //tools/build_defs/repo:http.bzlr�
.
bazel_toolstools/build_defs/repohttp.bzl*
http_archivehttp_archive
7C$
	http_file	http_file
GP
R+Module extensions for this language module. 