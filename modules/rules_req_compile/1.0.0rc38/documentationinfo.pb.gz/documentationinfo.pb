�[
+
rules_req_compile
extensions
python.bzl�Xrequirements�Module extension providing parsing of Python requirements files into
a hub repository containing an interface to a repository for
each requirement listed in the file.J�V
� 
requirements�Module extension providing parsing of Python requirements files into
a hub repository containing an interface to a repository for
each requirement listed in the file.�
package_annotation9A tag representing a annotation editing a Python package.e
additive_build_fileFThe label of a `BUILD` file to add to the generated one for a pacakge.2None`
additive_build_file_content;Raw text to add to the generated `BUILD` file of a package.2""�
copy_executables�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl](https://github.com/bazelbuild/bazel-skylib/blob/1.7.1/docs/copy_file_doc.md). Targets generated here will also be flagged as executable.
2{}�

copy_files�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl](https://github.com/bazelbuild/bazel-skylib/blob/1.7.1/docs/copy_file_doc.md).
2{}�
	copy_srcs�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl](https://github.com/bazelbuild/bazel-skylib/blob/1.7.1/docs/copy_file_doc.md). The output files are added to the `py_library.srcs` attribute.
2{}b
dataTA list of labels to add as `data` dependencies to the generated `py_library` target.2[]q
data_exclude_globVA list of exclude glob patterns to add as `data` to the generated `py_library` target.2[]b
depsTA list of labels to add as `data` dependencies to the generated `py_library` target.2[]m
deps_excludesVA list of exclude glob patterns to add as `data` to the generated `py_library` target.2[]B
package3The name of the package the annotations applies to. =
patches,A list of patch files to apply to the wheel.2[]b
srcs_exclude_globGA list of labels to add as `srcs` to the generated `py_library` target.2[]�
parse�"Parse a lock file into a hub repo.

A hub repo is a single repository that can be pulled into a
module via `use_repo` and contains all of the Python wheel repos
specified by the requirements files.

Aliases are added at the top-level package of the hub repo to each
package it contains, using a normalized name of the Python project.

```python
requirements = use_extension("@rules_req_compile//extensions:python.bzl", "requirements")
requirements.parse(
    name = "pip_deps",
    requirements_locks = {
        "//3rdparty:requirements.linux.txt": "@platforms//os:linux",
        "//3rdparty:requirements.macos.txt": "@platforms//os:macos",
        "//3rdparty:requirements.windows.txt": "@platforms//os:windows",
    },
)
use_repo(requirements, "pip_deps")
```

This example was a multi-platform set of solutions, pulled into a single
hub repository named "pip_deps".
1
name%Name of the hub repository to create. f
interpreter_linux_aarch64AOptional Linux arm64 Python interpreter binary to use for sdists.2Nonee
interpreter_linux_x86_64AOptional Linux amd64 Python interpreter binary to use for sdists.2Noned
interpreter_macos_aarch64?Optional MacOS ARM Python interpreter binary to use for sdists.2Nonef
interpreter_macos_x86_64BOptional MacOS x86_64 Python interpreter binary to use for sdists.2None`
interpreter_windowsAOptional Windows x64 Python interpreter binary to use for sdists.2None�
override_module_repos�Mapping of module name to list of repos that should be overridden by this hub. The repos
must be those that are expected to be created by this module extension.

The overridden hub will attempt to map all of its requirements to the root module's hub, meaning
the root module hub must be a superset of the overridden hub.

This attribute is intended to have the root module coordinate all Python packages such
that Python libraries from dependencies can be safely imported into the same interpreter.
Do not override repos for libraries that will never be mixed. To inject Python dependencies
for use in most child modules, a custom toolchain type is most appropriate. N
requirements_lock1A single lockfile for a single platform solution.2NoneT
requirements_locks8A dictionary mapping platform to requirement lock files.	2{}":
requirements*@@rules_req_compile//extensions:python.bzl
� � �
�
package_annotation9A tag representing a annotation editing a Python package.e
additive_build_fileFThe label of a `BUILD` file to add to the generated one for a pacakge.2None`
additive_build_file_content;Raw text to add to the generated `BUILD` file of a package.2""�
copy_executables�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl](https://github.com/bazelbuild/bazel-skylib/blob/1.7.1/docs/copy_file_doc.md). Targets generated here will also be flagged as executable.
2{}�

copy_files�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl](https://github.com/bazelbuild/bazel-skylib/blob/1.7.1/docs/copy_file_doc.md).
2{}�
	copy_srcs�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl](https://github.com/bazelbuild/bazel-skylib/blob/1.7.1/docs/copy_file_doc.md). The output files are added to the `py_library.srcs` attribute.
2{}b
dataTA list of labels to add as `data` dependencies to the generated `py_library` target.2[]q
data_exclude_globVA list of exclude glob patterns to add as `data` to the generated `py_library` target.2[]b
depsTA list of labels to add as `data` dependencies to the generated `py_library` target.2[]m
deps_excludesVA list of exclude glob patterns to add as `data` to the generated `py_library` target.2[]B
package3The name of the package the annotations applies to. =
patches,A list of patch files to apply to the wheel.2[]b
srcs_exclude_globGA list of labels to add as `srcs` to the generated `py_library` target.2[]g
e
additive_build_fileFThe label of a `BUILD` file to add to the generated one for a pacakge.2Noneb
`
additive_build_file_content;Raw text to add to the generated `BUILD` file of a package.2""�
�
copy_executables�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl](https://github.com/bazelbuild/bazel-skylib/blob/1.7.1/docs/copy_file_doc.md). Targets generated here will also be flagged as executable.
2{}�
�

copy_files�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl](https://github.com/bazelbuild/bazel-skylib/blob/1.7.1/docs/copy_file_doc.md).
2{}�
�
	copy_srcs�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl](https://github.com/bazelbuild/bazel-skylib/blob/1.7.1/docs/copy_file_doc.md). The output files are added to the `py_library.srcs` attribute.
2{}d
b
dataTA list of labels to add as `data` dependencies to the generated `py_library` target.2[]s
q
data_exclude_globVA list of exclude glob patterns to add as `data` to the generated `py_library` target.2[]d
b
depsTA list of labels to add as `data` dependencies to the generated `py_library` target.2[]o
m
deps_excludesVA list of exclude glob patterns to add as `data` to the generated `py_library` target.2[]D
B
package3The name of the package the annotations applies to. ?
=
patches,A list of patch files to apply to the wheel.2[]d
b
srcs_exclude_globGA list of labels to add as `srcs` to the generated `py_library` target.2[]�
�
parse�"Parse a lock file into a hub repo.

A hub repo is a single repository that can be pulled into a
module via `use_repo` and contains all of the Python wheel repos
specified by the requirements files.

Aliases are added at the top-level package of the hub repo to each
package it contains, using a normalized name of the Python project.

```python
requirements = use_extension("@rules_req_compile//extensions:python.bzl", "requirements")
requirements.parse(
    name = "pip_deps",
    requirements_locks = {
        "//3rdparty:requirements.linux.txt": "@platforms//os:linux",
        "//3rdparty:requirements.macos.txt": "@platforms//os:macos",
        "//3rdparty:requirements.windows.txt": "@platforms//os:windows",
    },
)
use_repo(requirements, "pip_deps")
```

This example was a multi-platform set of solutions, pulled into a single
hub repository named "pip_deps".
1
name%Name of the hub repository to create. f
interpreter_linux_aarch64AOptional Linux arm64 Python interpreter binary to use for sdists.2Nonee
interpreter_linux_x86_64AOptional Linux amd64 Python interpreter binary to use for sdists.2Noned
interpreter_macos_aarch64?Optional MacOS ARM Python interpreter binary to use for sdists.2Nonef
interpreter_macos_x86_64BOptional MacOS x86_64 Python interpreter binary to use for sdists.2None`
interpreter_windowsAOptional Windows x64 Python interpreter binary to use for sdists.2None�
override_module_repos�Mapping of module name to list of repos that should be overridden by this hub. The repos
must be those that are expected to be created by this module extension.

The overridden hub will attempt to map all of its requirements to the root module's hub, meaning
the root module hub must be a superset of the overridden hub.

This attribute is intended to have the root module coordinate all Python packages such
that Python libraries from dependencies can be safely imported into the same interpreter.
Do not override repos for libraries that will never be mixed. To inject Python dependencies
for use in most child modules, a custom toolchain type is most appropriate. N
requirements_lock1A single lockfile for a single platform solution.2NoneT
requirements_locks8A dictionary mapping platform to requirement lock files.	2{}3
1
name%Name of the hub repository to create. h
f
interpreter_linux_aarch64AOptional Linux arm64 Python interpreter binary to use for sdists.2Noneg
e
interpreter_linux_x86_64AOptional Linux amd64 Python interpreter binary to use for sdists.2Nonef
d
interpreter_macos_aarch64?Optional MacOS ARM Python interpreter binary to use for sdists.2Noneh
f
interpreter_macos_x86_64BOptional MacOS x86_64 Python interpreter binary to use for sdists.2Noneb
`
interpreter_windowsAOptional Windows x64 Python interpreter binary to use for sdists.2None�
�
override_module_repos�Mapping of module name to list of repos that should be overridden by this hub. The repos
must be those that are expected to be created by this module extension.

The overridden hub will attempt to map all of its requirements to the root module's hub, meaning
the root module hub must be a superset of the overridden hub.

This attribute is intended to have the root module coordinate all Python packages such
that Python libraries from dependencies can be safely imported into the same interpreter.
Do not override repos for libraries that will never be mixed. To inject Python dependencies
for use in most child modules, a custom toolchain type is most appropriate. P
N
requirements_lock1A single lockfile for a single platform solution.2NoneV
T
requirements_locks8A dictionary mapping platform to requirement lock files.	2{}w
	:defs.bzlrh

rules_req_compiledefs.bzl9
py_package_annotationpackage_annotation

�
//private:reqs_repo.bzlr�
+
rules_req_compileprivatereqs_repo.bzl6
create_spoke_reposcreate_spoke_repos
		B
parse_requirements_locksparse_requirements_locks


F
py_requirements_repositorypy_requirements_repository
 
%Python requirements module extension.�
I
rules_req_compileprivate/tests/annotationsannotations_test_deps.bzl�!req_compile_test_annotations_deps*�
�
!req_compile_test_annotations_deps2m
!req_compile_test_annotations_depsH@@rules_req_compile//private/tests/annotations:annotations_test_deps.bzl
�
!//tools/build_defs/repo:utils.bzlr]
/
bazel_toolstools/build_defs/repo	utils.bzl
maybemaybe
8=
?�
	:defs.bzlr�

rules_req_compiledefs.bzlF
py_requirements_repositorypy_requirements_repository
 9
py_package_annotationpackage_annotation

6Test dependencies for the annotations integration test�
P
rules_req_compileprivate/tests/cross_platformcross_platform_test_utils.bzl�fake_cc_config"�
�
fake_cc_config*
nameA unique name for this target. "a
fake_cc_configO@@rules_req_compile//private/tests/cross_platform:cross_platform_test_utils.bzl
OO,
*
nameA unique name for this target. �	"platform_transitioned_output_groupPA rule for accessing files in a target's `OutputGroupInfo` through a transition."�
�
"platform_transitioned_output_groupPA rule for accessing files in a target's `OutputGroupInfo` through a transition.*
nameA unique name for this target. �
extra_toolchains{[extra_toolchains](https://bazel.build/reference/command-line-reference#flag--extra_toolchains) to apply in the transition.2[]:
output_group&The `OutputGroupInfo` field to access. \
platformHThe label to a [Bazel platform](https://bazel.build/extending/platforms)2None'
targetThe target to transition. "u
"platform_transitioned_output_groupO@@rules_req_compile//private/tests/cross_platform:cross_platform_test_utils.bzl
(*(*,
*
nameA unique name for this target. �
�
extra_toolchains{[extra_toolchains](https://bazel.build/reference/command-line-reference#flag--extra_toolchains) to apply in the transition.2[]<
:
output_group&The `OutputGroupInfo` field to access. ^
\
platformHThe label to a [Bazel platform](https://bazel.build/extending/platforms)2None)
'
targetThe target to transition. y
//cc/common:cc_common.bzlrZ
$
rules_cc	cc/commoncc_common.bzl$
	cc_common	cc_common
-6
8RBazel rules for testing cross-platform apabilities of req-compile repository rules�Z
<
rules_req_compileprivate/tests/find_linksextension.bzl�Xrequirements�Module extension providing parsing of Python requirements files into
a hub repository containing an interface to a repository for
each requirement listed in the file.J�V
� 
requirements�Module extension providing parsing of Python requirements files into
a hub repository containing an interface to a repository for
each requirement listed in the file.�
package_annotation9A tag representing a annotation editing a Python package.e
additive_build_fileFThe label of a `BUILD` file to add to the generated one for a pacakge.2None`
additive_build_file_content;Raw text to add to the generated `BUILD` file of a package.2""�
copy_executables�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl](https://github.com/bazelbuild/bazel-skylib/blob/1.7.1/docs/copy_file_doc.md). Targets generated here will also be flagged as executable.
2{}�

copy_files�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl](https://github.com/bazelbuild/bazel-skylib/blob/1.7.1/docs/copy_file_doc.md).
2{}�
	copy_srcs�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl](https://github.com/bazelbuild/bazel-skylib/blob/1.7.1/docs/copy_file_doc.md). The output files are added to the `py_library.srcs` attribute.
2{}b
dataTA list of labels to add as `data` dependencies to the generated `py_library` target.2[]q
data_exclude_globVA list of exclude glob patterns to add as `data` to the generated `py_library` target.2[]b
depsTA list of labels to add as `data` dependencies to the generated `py_library` target.2[]m
deps_excludesVA list of exclude glob patterns to add as `data` to the generated `py_library` target.2[]B
package3The name of the package the annotations applies to. =
patches,A list of patch files to apply to the wheel.2[]b
srcs_exclude_globGA list of labels to add as `srcs` to the generated `py_library` target.2[]�
parse�"Parse a lock file into a hub repo.

A hub repo is a single repository that can be pulled into a
module via `use_repo` and contains all of the Python wheel repos
specified by the requirements files.

Aliases are added at the top-level package of the hub repo to each
package it contains, using a normalized name of the Python project.

```python
requirements = use_extension("@rules_req_compile//extensions:python.bzl", "requirements")
requirements.parse(
    name = "pip_deps",
    requirements_locks = {
        "//3rdparty:requirements.linux.txt": "@platforms//os:linux",
        "//3rdparty:requirements.macos.txt": "@platforms//os:macos",
        "//3rdparty:requirements.windows.txt": "@platforms//os:windows",
    },
)
use_repo(requirements, "pip_deps")
```

This example was a multi-platform set of solutions, pulled into a single
hub repository named "pip_deps".
1
name%Name of the hub repository to create. f
interpreter_linux_aarch64AOptional Linux arm64 Python interpreter binary to use for sdists.2Nonee
interpreter_linux_x86_64AOptional Linux amd64 Python interpreter binary to use for sdists.2Noned
interpreter_macos_aarch64?Optional MacOS ARM Python interpreter binary to use for sdists.2Nonef
interpreter_macos_x86_64BOptional MacOS x86_64 Python interpreter binary to use for sdists.2None`
interpreter_windowsAOptional Windows x64 Python interpreter binary to use for sdists.2None�
override_module_repos�Mapping of module name to list of repos that should be overridden by this hub. The repos
must be those that are expected to be created by this module extension.

The overridden hub will attempt to map all of its requirements to the root module's hub, meaning
the root module hub must be a superset of the overridden hub.

This attribute is intended to have the root module coordinate all Python packages such
that Python libraries from dependencies can be safely imported into the same interpreter.
Do not override repos for libraries that will never be mixed. To inject Python dependencies
for use in most child modules, a custom toolchain type is most appropriate. N
requirements_lock1A single lockfile for a single platform solution.2NoneT
requirements_locks8A dictionary mapping platform to requirement lock files.	2{}"K
requirements;@@rules_req_compile//private/tests/find_links:extension.bzl
� � �
�
package_annotation9A tag representing a annotation editing a Python package.e
additive_build_fileFThe label of a `BUILD` file to add to the generated one for a pacakge.2None`
additive_build_file_content;Raw text to add to the generated `BUILD` file of a package.2""�
copy_executables�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl](https://github.com/bazelbuild/bazel-skylib/blob/1.7.1/docs/copy_file_doc.md). Targets generated here will also be flagged as executable.
2{}�

copy_files�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl](https://github.com/bazelbuild/bazel-skylib/blob/1.7.1/docs/copy_file_doc.md).
2{}�
	copy_srcs�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl](https://github.com/bazelbuild/bazel-skylib/blob/1.7.1/docs/copy_file_doc.md). The output files are added to the `py_library.srcs` attribute.
2{}b
dataTA list of labels to add as `data` dependencies to the generated `py_library` target.2[]q
data_exclude_globVA list of exclude glob patterns to add as `data` to the generated `py_library` target.2[]b
depsTA list of labels to add as `data` dependencies to the generated `py_library` target.2[]m
deps_excludesVA list of exclude glob patterns to add as `data` to the generated `py_library` target.2[]B
package3The name of the package the annotations applies to. =
patches,A list of patch files to apply to the wheel.2[]b
srcs_exclude_globGA list of labels to add as `srcs` to the generated `py_library` target.2[]g
e
additive_build_fileFThe label of a `BUILD` file to add to the generated one for a pacakge.2Noneb
`
additive_build_file_content;Raw text to add to the generated `BUILD` file of a package.2""�
�
copy_executables�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl](https://github.com/bazelbuild/bazel-skylib/blob/1.7.1/docs/copy_file_doc.md). Targets generated here will also be flagged as executable.
2{}�
�

copy_files�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl](https://github.com/bazelbuild/bazel-skylib/blob/1.7.1/docs/copy_file_doc.md).
2{}�
�
	copy_srcs�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl](https://github.com/bazelbuild/bazel-skylib/blob/1.7.1/docs/copy_file_doc.md). The output files are added to the `py_library.srcs` attribute.
2{}d
b
dataTA list of labels to add as `data` dependencies to the generated `py_library` target.2[]s
q
data_exclude_globVA list of exclude glob patterns to add as `data` to the generated `py_library` target.2[]d
b
depsTA list of labels to add as `data` dependencies to the generated `py_library` target.2[]o
m
deps_excludesVA list of exclude glob patterns to add as `data` to the generated `py_library` target.2[]D
B
package3The name of the package the annotations applies to. ?
=
patches,A list of patch files to apply to the wheel.2[]d
b
srcs_exclude_globGA list of labels to add as `srcs` to the generated `py_library` target.2[]�
�
parse�"Parse a lock file into a hub repo.

A hub repo is a single repository that can be pulled into a
module via `use_repo` and contains all of the Python wheel repos
specified by the requirements files.

Aliases are added at the top-level package of the hub repo to each
package it contains, using a normalized name of the Python project.

```python
requirements = use_extension("@rules_req_compile//extensions:python.bzl", "requirements")
requirements.parse(
    name = "pip_deps",
    requirements_locks = {
        "//3rdparty:requirements.linux.txt": "@platforms//os:linux",
        "//3rdparty:requirements.macos.txt": "@platforms//os:macos",
        "//3rdparty:requirements.windows.txt": "@platforms//os:windows",
    },
)
use_repo(requirements, "pip_deps")
```

This example was a multi-platform set of solutions, pulled into a single
hub repository named "pip_deps".
1
name%Name of the hub repository to create. f
interpreter_linux_aarch64AOptional Linux arm64 Python interpreter binary to use for sdists.2Nonee
interpreter_linux_x86_64AOptional Linux amd64 Python interpreter binary to use for sdists.2Noned
interpreter_macos_aarch64?Optional MacOS ARM Python interpreter binary to use for sdists.2Nonef
interpreter_macos_x86_64BOptional MacOS x86_64 Python interpreter binary to use for sdists.2None`
interpreter_windowsAOptional Windows x64 Python interpreter binary to use for sdists.2None�
override_module_repos�Mapping of module name to list of repos that should be overridden by this hub. The repos
must be those that are expected to be created by this module extension.

The overridden hub will attempt to map all of its requirements to the root module's hub, meaning
the root module hub must be a superset of the overridden hub.

This attribute is intended to have the root module coordinate all Python packages such
that Python libraries from dependencies can be safely imported into the same interpreter.
Do not override repos for libraries that will never be mixed. To inject Python dependencies
for use in most child modules, a custom toolchain type is most appropriate. N
requirements_lock1A single lockfile for a single platform solution.2NoneT
requirements_locks8A dictionary mapping platform to requirement lock files.	2{}3
1
name%Name of the hub repository to create. h
f
interpreter_linux_aarch64AOptional Linux arm64 Python interpreter binary to use for sdists.2Noneg
e
interpreter_linux_x86_64AOptional Linux amd64 Python interpreter binary to use for sdists.2Nonef
d
interpreter_macos_aarch64?Optional MacOS ARM Python interpreter binary to use for sdists.2Noneh
f
interpreter_macos_x86_64BOptional MacOS x86_64 Python interpreter binary to use for sdists.2Noneb
`
interpreter_windowsAOptional Windows x64 Python interpreter binary to use for sdists.2None�
�
override_module_repos�Mapping of module name to list of repos that should be overridden by this hub. The repos
must be those that are expected to be created by this module extension.

The overridden hub will attempt to map all of its requirements to the root module's hub, meaning
the root module hub must be a superset of the overridden hub.

This attribute is intended to have the root module coordinate all Python packages such
that Python libraries from dependencies can be safely imported into the same interpreter.
Do not override repos for libraries that will never be mixed. To inject Python dependencies
for use in most child modules, a custom toolchain type is most appropriate. P
N
requirements_lock1A single lockfile for a single platform solution.2NoneV
T
requirements_locks8A dictionary mapping platform to requirement lock files.	2{}�
//extensions:python.bzlrh
+
rules_req_compile
extensions
python.bzl+
requirements_requirements
3@
RgRe-export the parse extension under a different name so we don't
create a cirular dep tree during test.�
G
rules_req_compileprivate/tests/find_linksfind_links_test_repo.bzl�find_links_test_repositoryBA repository rule for the req-compile find_links integration test.R�
�
find_links_test_repositoryBA repository rule for the req-compile find_links integration test..
name"A unique name for this repository. 5

build_file#The BUILD file to use for the repo. Q
pyspark_wheel_data7The path to a data file produced by `sdist_repository`. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 2
requirements_inThe `requirements.in` file. 4
requirements_txtThe `requirements.txt` file. 3
wheeldir#The name of the wheeldir directory. *d
find_links_test_repositoryF@@rules_req_compile//private/tests/find_links:find_links_test_repo.bzl
.-.-0
.
name"A unique name for this repository. 7
5

build_file#The BUILD file to use for the repo. S
Q
pyspark_wheel_data7The path to a data file produced by `sdist_repository`. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 4
2
requirements_inThe `requirements.in` file. 6
4
requirements_txtThe `requirements.txt` file. 5
3
wheeldir#The name of the wheeldir directory. �
//private:whl_repo.bzlrl
*
rules_req_compileprivatewhl_repo.bzl0
load_sdist_dataload_sdist_data
3B
DBA repository rule for the req-compile find_links integration test.�
S
rules_req_compileprivate/tests/pip_parse_compatpip_parse_compat_test_deps.bzl�pip_parse_compat_test_deps*�
�
pip_parse_compat_test_deps2p
pip_parse_compat_test_depsR@@rules_req_compile//private/tests/pip_parse_compat:pip_parse_compat_test_deps.bzl
�
!//tools/build_defs/repo:utils.bzlr]
/
bazel_toolstools/build_defs/repo	utils.bzl
maybemaybe
8=
?�
	:defs.bzlru

rules_req_compiledefs.bzlF
py_requirements_repositorypy_requirements_repository
(B
D5Test dependencies for `pip_parse` compatibility tests�
[
rules_req_compileprivate/tests/pip_parse_compat&pip_parse_compat_test_deps_install.bzl�"pip_parse_compat_test_deps_install*�
�
"pip_parse_compat_test_deps_install2�
"pip_parse_compat_test_deps_installZ@@rules_req_compile//private/tests/pip_parse_compat:pip_parse_compat_test_deps_install.bzl
�
:requirements.bzlr�
@
,req_compile_test_pip_parse_compat_multi_platrequirements.bzlF
install_deps(pip_parse_compat_multi_plat_repositories
-
�
:requirements.bzlr�
A
-req_compile_test_pip_parse_compat_single_platrequirements.bzlG
install_deps)pip_parse_compat_single_plat_repositories
		.

5Test dependencies for `pip_parse` compatibility tests�
F
rules_req_compileprivate/tests/unitparse_lockfile_test_suite.bzl�parse_lockfile_test"�
�
parse_lockfile_test*
nameA unique name for this target. ;
content,The text content of a requirements lock file <
expected,A json encoded string of parsed requirements o
mock_lockfile8A fake label to a madeup location for the solution file.2""@req_compile_fake//:solution.txt""\
parse_lockfile_testE@@rules_req_compile//private/tests/unit:parse_lockfile_test_suite.bzl
��,
*
nameA unique name for this target. =
;
content,The text content of a requirements lock file >
<
expected,A json encoded string of parsed requirements q
o
mock_lockfile8A fake label to a madeup location for the solution file.2""@req_compile_fake//:solution.txt"�parse_lockfile_test_suiteGDefine a test suite for requirements repository lockfile parsing logic.*�
�
parse_lockfile_test_suite'
nameThe name of the test suite. ()
kwargsAdditional keyword arguments.(GDefine a test suite for requirements repository lockfile parsing logic.2b
parse_lockfile_test_suiteE@@rules_req_compile//private/tests/unit:parse_lockfile_test_suite.bzl
��"_parse_lockfile_test*native.test_suite2native.test_suite�
//lib:unittest.bzlrw
!
bazel_skyliblibunittest.bzl 
assertsasserts
*1"
unittestunittest
5=
?�
//private:reqs_repo.bzlrk
+
rules_req_compileprivatereqs_repo.bzl.
parse_lockfileparse_lockfile
4B
D)Starlark unit tests for `parse_lockfile`.�
,
rules_req_compileprivateannotation.bzl*�ModuleInfo request error: invalid argument: Traceback (most recent call last):
	File "external/rules_req_compile/private/annotation.bzl", line 3, column 33, in <toplevel>
		load("@rules_cc//cc:defs.bzl", "CcInfo")
Error: file '@rules_cc//cc:defs.bzl' does not contain symbol 'CcInfo'�
2
rules_req_compileprivateannotation_utils.bzl�deserialize_package_annotation6Deserialize json encoded `py_package_annotation` data.*�
�
deserialize_package_annotation(
contentA json serialized string. (6Deserialize json encoded `py_package_annotation` data."'
%struct: `py_package_annotation` data.2S
deserialize_package_annotation1@@rules_req_compile//private:annotation_utils.bzl
�Utilities for applying annotations to Bazel python packages.

Split this from annotation.bzl since it loads CcInfo and this causes
a circular load() with rules_cc in WORKSPACE.bazel.
�6
*
rules_req_compileprivatecompiler.bzl�py_reqs_compiler�A Bazel rule for compiling python requirements for the current platform.


```python
load("@rules_req_compile//:defs.bzl", "py_reqs_compiler", "py_reqs_solution_test")

filegroup(
    name = "requriements",
    srcs = ["requirements.in"],
    data = [
        # Any transitive files included via `-r` should be added here.
    ],
)

py_reqs_compiler(
    name = "requirements.update",
    requirements_in = ":requirements",
    requirements_txt = "requirements.txt",
)

```

Updating requirements can be performed by running the new target.

```bash
bazel run //:requirements.update
```

By default the rule will try to recycle pins already existing in the solution file (`requirements.txt`). To perform
a clean resolution (fetching latest for all requirements) the `--upgrade` flag can be used.

```bash
bazel run //:requirements.update -- --upgrade
```
"�
�

py_reqs_compiler�A Bazel rule for compiling python requirements for the current platform.


```python
load("@rules_req_compile//:defs.bzl", "py_reqs_compiler", "py_reqs_solution_test")

filegroup(
    name = "requriements",
    srcs = ["requirements.in"],
    data = [
        # Any transitive files included via `-r` should be added here.
    ],
)

py_reqs_compiler(
    name = "requirements.update",
    requirements_in = ":requirements",
    requirements_txt = "requirements.txt",
)

```

Updating requirements can be performed by running the new target.

```bash
bazel run //:requirements.update
```

By default the rule will try to recycle pins already existing in the solution file (`requirements.txt`). To perform
a clean resolution (fetching latest for all requirements) the `--upgrade` flag can be used.

```bash
bazel run //:requirements.update -- --upgrade
```
*
nameA unique name for this target. _
allow_sdistsFWhether or not the solution file is allowed to contain sdist packages.2False�
custom_compile_command�The command to display in the header of the generated lock file (`requirements_txt`). Any references to `{label}` will be replaced with the label of this target.2"bazel run "{label}""2
requirements_inThe input requirements file *
requirements_txtThe solution file. "=
py_reqs_compiler)@@rules_req_compile//private:compiler.bzl
��,
*
nameA unique name for this target. a
_
allow_sdistsFWhether or not the solution file is allowed to contain sdist packages.2False�
�
custom_compile_command�The command to display in the header of the generated lock file (`requirements_txt`). Any references to `{label}` will be replaced with the label of this target.2"bazel run "{label}""4
2
requirements_inThe input requirements file ,
*
requirements_txtThe solution file. �py_reqs_solution_test�A Bazel test rule for ensuring the solution file for a `py_reqs_compiler` target satisifes the given requirements (`requirements_in`).

```python
load("@rules_req_compile//:defs.bzl", "py_reqs_compiler", "py_reqs_solution_test")

py_reqs_compiler(
    name = "requirements.update",
    requirements_in = "requirements.in",
    requirements_txt = "requirements.txt",
)

py_reqs_solution_test(
    name = "requirements_test",
    requirements_in = "requirements.in",
    requirements_txt = "requirements.txt",
)
```

Alternatively, a test can be defined in isolation using just the requirements files:

```python
load("@rules_req_compile//:defs.bzl", "py_reqs_solution_test")

py_reqs_solution_test(
    name = "requirements_test",
    custom_compile_command = "python3 -m req_compile --multiline --hashes --urls --solution requirements.txt requirements.in",
    requirements_in = "requirements.in",
    requirements_txt = "requirements.txt",
)
```
"�
�
py_reqs_solution_test�A Bazel test rule for ensuring the solution file for a `py_reqs_compiler` target satisifes the given requirements (`requirements_in`).

```python
load("@rules_req_compile//:defs.bzl", "py_reqs_compiler", "py_reqs_solution_test")

py_reqs_compiler(
    name = "requirements.update",
    requirements_in = "requirements.in",
    requirements_txt = "requirements.txt",
)

py_reqs_solution_test(
    name = "requirements_test",
    requirements_in = "requirements.in",
    requirements_txt = "requirements.txt",
)
```

Alternatively, a test can be defined in isolation using just the requirements files:

```python
load("@rules_req_compile//:defs.bzl", "py_reqs_solution_test")

py_reqs_solution_test(
    name = "requirements_test",
    custom_compile_command = "python3 -m req_compile --multiline --hashes --urls --solution requirements.txt requirements.in",
    requirements_in = "requirements.in",
    requirements_txt = "requirements.txt",
)
```
*
nameA unique name for this target. �
compiler�The `py_reqs_compiler` target to test. This attribute is mutally exclusive with `requirements_in` and `requirements_txt` and does not do any string formatting like `py_reqs_compiler` does.*
PyReqsCompilerInfo2None�
custom_compile_command�The command to display in the header of the generated lock file (`requirements_txt`). This attribute is required with `requirements_in` and `requirements_txt`.2""m
requirements_inRThe input requirements file. This attribute is mutually exclusive with `compiler`.2Noned
requirements_txtHThe solution file. This attribute is mutually exclusive with `compiler`.2None"B
py_reqs_solution_test)@@rules_req_compile//private:compiler.bzl
��,
*
nameA unique name for this target. �
�
compiler�The `py_reqs_compiler` target to test. This attribute is mutally exclusive with `requirements_in` and `requirements_txt` and does not do any string formatting like `py_reqs_compiler` does.*
PyReqsCompilerInfo2None�
�
custom_compile_command�The command to display in the header of the generated lock file (`requirements_txt`). This attribute is required with `requirements_in` and `requirements_txt`.2""o
m
requirements_inRThe input requirements file. This attribute is mutually exclusive with `compiler`.2Nonef
d
requirements_txtHThe solution file. This attribute is mutually exclusive with `compiler`.2None�PyReqsCompilerInfo0Information about a python requirements provider2�
�
PyReqsCompilerInfo0Information about a python requirements provider<
args4List[str]: A list of arguments core to the compiler.Y
requirements_inFTarget: The `requirements_in` target which provides requirement files.b
solutionVTarget: The solution file which represents the compiled result from `requirements_in`."?
PyReqsCompilerInfo)@@rules_req_compile//private:compiler.bzl
>
<
args4List[str]: A list of arguments core to the compiler.[
Y
requirements_inFTarget: The `requirements_in` target which provides requirement files.d
b
solutionVTarget: The solution file which represents the compiled result from `requirements_in`.&Rules for compiling requirements files�
1
rules_req_compileprivateremote_compiler.bzl�py_reqs_remote_compiler�A tool for compiling python requirements on a remote machine.

This rule wraps a `py_req_compiler` target behind a transition and
when a ssh user and host are provided, this target can deploy the
compiler to the remote system and perform compilation.


A rule for extracting variables attributes from the `py_req_compiler` target."�
�
py_reqs_remote_compiler�A tool for compiling python requirements on a remote machine.

This rule wraps a `py_req_compiler` target behind a transition and
when a ssh user and host are provided, this target can deploy the
compiler to the remote system and perform compilation.


A rule for extracting variables attributes from the `py_req_compiler` target.*
nameA unique name for this target. C
compilerThe `py_req_compiler` target. *
PyReqsCompilerInfo"N
_req_compile_output_groups0@@rules_req_compile//private:remote_compiler.bzl
::,
*
nameA unique name for this target. E
C
compilerThe `py_req_compiler` target. *
PyReqsCompilerInfo�
//private:compiler.bzlrr
*
rules_req_compileprivatecompiler.bzl6
PyReqsCompilerInfoPyReqsCompilerInfo
3E
G�
//private:transition.bzlr�
,
rules_req_compileprivatetransition.bzlF
platform_transitioned_fileplatform_transitioned_file
5O
Q�
//python/venv:defs.bzlr�
#

rules_venvpython/venvdefs.bzl.
py_venv_binarypy_venv_binary
,:.
py_venv_zipapppy_venv_zipapp
>L
N8Utilities for compiling requirements on a remote machine�e
+
rules_req_compileprivatereqs_repo.bzl�create_spoke_repos�Create the repos for each Python project from a constraints file.

These are the "spokes" of the wheel, attached to the central "hub".
*�
�
create_spoke_reposN
spoke_prefix:A name prefix including the hub and a platform identifier. (L
constraints9Mapping of Python project name to data about the project. (=
interpreter*Python interpreter to use to build sdists. (�Create the repos for each Python project from a constraints file.

These are the "spokes" of the wheel, attached to the central "hub".
"(
&List of names of repositories created.2@
create_spoke_repos*@@rules_req_compile//private:reqs_repo.bzl
::�generate_interface_bzl_contentPGenerate the defs.bzl file contents that selects between multiple architectures.*�
�
generate_interface_bzl_content0
defs$id -> constraint mapping dictionary. (C
repository_name,Name of the repository containing this file. (PGenerate the defs.bzl file contents that selects between multiple architectures."
The file contents.2L
generate_interface_bzl_content*@@rules_req_compile//private:reqs_repo.bzl
���parse_constraint?Parse a section of a requirements lock file from `req-compile`.*�
�
parse_constraintH
data<The stripped lines of a constraint's section in a lock file. (�
lockfilevThe label of the current lockfile. Used to resolve paths to
constraints represented by relative paths instead of urls. (q

wheel_dirs_A list of strings that represent directories containing
wheels, relative to the workspace root. (?Parse a section of a requirements lock file from `req-compile`."'
%dict: Parsed data for the constraint.2>
parse_constraint*@@rules_req_compile//private:reqs_repo.bzl
���parse_lockfile9Parse a requirements lock file into a map of constraints.*�
�
parse_lockfile>
content/The string content of a requirements lock file. (I
annotations6Annotation data for packages in the current lock file. (?
lockfile/The label of the lockfile containing `content`. (]

constraintGAn optional Label which represents the constraint value of the package.None(9Parse a requirements lock file into a map of constraints."Q
Odict: A mapping of package names to it's parsed data from the constraints file.2<
parse_lockfile*@@rules_req_compile//private:reqs_repo.bzl
���parse_requirements_locksFParse requirement locks into a mapping of the platform to Python deps.*�
�
parse_requirements_locksC
hub_name3Hub name containing the top-level BUILD.bazel file. (4
ctx)A Bazel context capable of reading files. (Z
attrsMA struct containing the repository rule or Bazel module tag class attributes. (O
annotations<The annotations to apply to the requirements from this lock. (FParse requirement locks into a mapping of the platform to Python deps."�
�Mapping of a derived friendly platform id to a struct containing:
    constraint: Bazel constraint for this platform.
    packages: Python packages read from the lock file for this platform.

If no constraint was provided, the constraint struct member will be None.2F
parse_requirements_locks*@@rules_req_compile//private:reqs_repo.bzl
���Gpy_requirements_repository�A rule for importing `requirements.txt` dependencies into Bazel.

Those dependencies become available in a generated `defs.bzl` file.

```python
load("@rules_req_compile//:defs.bzl", "py_requirements_repository")

py_requirements_repository(
    name = "py_requirements",
    requirements_lock = ":requirements.txt",
)

load("@py_requirements//:defs.bzl", "repositories")

repositories()
```

You can then reference installed dependencies from a `BUILD` file with:

```python
load("@py_requirements//:defs.bzl", "requirement")

py_library(
    name = "bar",
    ...
    deps = [
        "//my/other:dep",
        requirement("requests"),
        requirement("numpy"),
    ],
)
```

In addition to the `requirement` macro, which is used to access the generated `py_library`
target generated from a package's wheel, The generated `requirements.bzl` file contains
functionality for exposing [entry points][whl_ep] as `py_binary` targets as well.

[whl_ep]: https://packaging.python.org/specifications/entry-points/

```python
load("@py_requirements//:defs.bzl", "entry_point")

alias(
    name = "pip-compile",
    actual = entry_point(
        pkg = "pip-tools",
        script = "pip-compile",
    ),
)
```

Note that for packages whose name and script are the same, only the name of the package
is needed when calling the `entry_point` macro.

```python
load("@py_requirements//:defs.bzl", "entry_point")

alias(
    name = "flake8",
    actual = entry_point("flake8"),
)
```

A very important detail for generating python dependencies is sdist (source distribution)
dependencies are assumed to be incapable of yielding deterministic outputs. Therefore, any
case where a sdist (source distribution) is found in a solution file passed to either
`requirements_lock` or `requirements_locks`, the dependencies should not be considered
byte-for-byte reproducible. It is highly recommended solution files contain all wheels
so the generated repositories are byte-for-byte consistent. Failure to use binary-only
dependencies will result in unexpected cache invalidation as well as inconsistent or broken
cross-platform behavior when using `requirements_locks`.
R�6
�#
py_requirements_repository�A rule for importing `requirements.txt` dependencies into Bazel.

Those dependencies become available in a generated `defs.bzl` file.

```python
load("@rules_req_compile//:defs.bzl", "py_requirements_repository")

py_requirements_repository(
    name = "py_requirements",
    requirements_lock = ":requirements.txt",
)

load("@py_requirements//:defs.bzl", "repositories")

repositories()
```

You can then reference installed dependencies from a `BUILD` file with:

```python
load("@py_requirements//:defs.bzl", "requirement")

py_library(
    name = "bar",
    ...
    deps = [
        "//my/other:dep",
        requirement("requests"),
        requirement("numpy"),
    ],
)
```

In addition to the `requirement` macro, which is used to access the generated `py_library`
target generated from a package's wheel, The generated `requirements.bzl` file contains
functionality for exposing [entry points][whl_ep] as `py_binary` targets as well.

[whl_ep]: https://packaging.python.org/specifications/entry-points/

```python
load("@py_requirements//:defs.bzl", "entry_point")

alias(
    name = "pip-compile",
    actual = entry_point(
        pkg = "pip-tools",
        script = "pip-compile",
    ),
)
```

Note that for packages whose name and script are the same, only the name of the package
is needed when calling the `entry_point` macro.

```python
load("@py_requirements//:defs.bzl", "entry_point")

alias(
    name = "flake8",
    actual = entry_point("flake8"),
)
```

A very important detail for generating python dependencies is sdist (source distribution)
dependencies are assumed to be incapable of yielding deterministic outputs. Therefore, any
case where a sdist (source distribution) is found in a solution file passed to either
`requirements_lock` or `requirements_locks`, the dependencies should not be considered
byte-for-byte reproducible. It is highly recommended solution files contain all wheels
so the generated repositories are byte-for-byte consistent. Failure to use binary-only
dependencies will result in unexpected cache invalidation as well as inconsistent or broken
cross-platform behavior when using `requirements_locks`.
.
name"A unique name for this repository. �
annotations�Optional annotations to apply to packages. For details see [@rules_python//python:pip.bzl%package_annotation](https://github.com/bazelbuild/rules_python/blob/main/docs/pip_repository.md#package_annotation)
2{}N
hub_name<Name of the hub repository to generate. Do not use directly.2""�
interpreter�The label of a python interpreter to use for compiling source distributions (sdists). If this is not provided then the provided lock file must represent binary-only dependencies. Note that should this interpreter be needed (a sdist was found in `requirements_lock` or `requirements_locks`), the dependencies generated may not be byte-for-byte reproducible and users may experience unexpected cache invalidation or unexpected cross-platform behavior.2None�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
requirements_lock�A fully resolved 'requirements.txt' pip requirement file containing the transitive set of your dependencies. This file _must_ be produced by [req-compile](https://pypi.org/project/req-compile/) and include hashes and urls in the solution. This attribute is mutually exclusive with `requirements_locks`.2None�
requirements_locks�A map of fully resolved 'requirements.txt' pip requirement file containing the transitive set of your dependencies to labels of Bazel [platforms](https://bazel.build/extending/platforms). These requirements files __must__ be produced by [req-compile](https://pypi.org/project/req-compile/) and include hashes and urls in the solution. Each lock file provided will create a dependency tree matching `{name}_{id}__{package}` where `id` is the name of the lock file with `[".", "-"]` characters are replaced by `"_"` and the name `requirements` will be stripped. This means each `requirements_locks` entry will need to be somewhat uniquely named. This attribute is mutually exclusive with `requirements_lock`.	2{}*H
py_requirements_repository*@@rules_req_compile//private:reqs_repo.bzl
�-�-0
.
name"A unique name for this repository. �
�
annotations�Optional annotations to apply to packages. For details see [@rules_python//python:pip.bzl%package_annotation](https://github.com/bazelbuild/rules_python/blob/main/docs/pip_repository.md#package_annotation)
2{}P
N
hub_name<Name of the hub repository to generate. Do not use directly.2""�
�
interpreter�The label of a python interpreter to use for compiling source distributions (sdists). If this is not provided then the provided lock file must represent binary-only dependencies. Note that should this interpreter be needed (a sdist was found in `requirements_lock` or `requirements_locks`), the dependencies generated may not be byte-for-byte reproducible and users may experience unexpected cache invalidation or unexpected cross-platform behavior.2None�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
�
requirements_lock�A fully resolved 'requirements.txt' pip requirement file containing the transitive set of your dependencies. This file _must_ be produced by [req-compile](https://pypi.org/project/req-compile/) and include hashes and urls in the solution. This attribute is mutually exclusive with `requirements_locks`.2None�
�
requirements_locks�A map of fully resolved 'requirements.txt' pip requirement file containing the transitive set of your dependencies to labels of Bazel [platforms](https://bazel.build/extending/platforms). These requirements files __must__ be produced by [req-compile](https://pypi.org/project/req-compile/) and include hashes and urls in the solution. Each lock file provided will create a dependency tree matching `{name}_{id}__{package}` where `id` is the name of the lock file with `[".", "-"]` characters are replaced by `"_"` and the name `requirements` will be stripped. This means each `requirements_locks` entry will need to be somewhat uniquely named. This attribute is mutually exclusive with `requirements_lock`.	2{}�
!//tools/build_defs/repo:utils.bzlr]
/
bazel_toolstools/build_defs/repo	utils.bzl
maybemaybe
8=
?�
//private:utils.bzlru
'
rules_req_compileprivate	utils.bzl<
sanitize_package_namesanitize_package_name
0E
G�
//private:whl_repo.bzlrj
*
rules_req_compileprivatewhl_repo.bzl.
whl_repositorywhl_repository
3A
CBRepository rules for loading platform specific python requirements�
'
rules_req_compileprivate	sdist.bzl�
sdist_depsFLoad all cross-platform wheels required to build source distributions.J�
�

sdist_depsFLoad all cross-platform wheels required to build source distributions."4

sdist_deps&@@rules_req_compile//private:sdist.bzl
�
//private:reqs_repo.bzlr�
+
rules_req_compileprivatereqs_repo.bzl6
create_spoke_reposcreate_spoke_repos
4FB
parse_requirements_locksparse_requirements_locks
Jb
d6Requirements for extracting and building source dists.�
,
rules_req_compileprivatetransition.bzl�platform_transitioned_filePA rule for accessing files in a target's `OutputGroupInfo` through a transition."�
�
platform_transitioned_filePA rule for accessing files in a target's `OutputGroupInfo` through a transition.*
nameA unique name for this target. \
platformHThe label to a [Bazel platform](https://bazel.build/extending/platforms)2None'
targetThe target to transition. "I
platform_transitioned_file+@@rules_req_compile//private:transition.bzl
"",
*
nameA unique name for this target. ^
\
platformHThe label to a [Bazel platform](https://bazel.build/extending/platforms)2None)
'
targetThe target to transition. $Bazel rules for platform transitions�
'
rules_req_compileprivate	utils.bzl�execute&Run a subprocess and error if it fails*�
�
execute/
repository_ctxThe rule's context object (+
argsThe argv of the command to run. ()
kwargsAdditional keyword arguments.(&Run a subprocess and error if it fails"2
0struct: The results of `repository_ctx.execute`.21
execute&@@rules_req_compile//private:utils.bzl
&&�parse_artifact_name(Parse the artifact name from a pypi url.*�
�
parse_artifact_name
urlsA list of urls ((Parse the artifact name from a pypi url."E
COptional[str]: The name if it was correctly parsed, otherwise None.2=
parse_artifact_name&@@rules_req_compile//private:utils.bzl
==�sanitize_package_nameFSanitize a python package name to a consistent and safe name for Bazel*�
�
sanitize_package_name(
nameThe name of a python package (FSanitize a python package name to a consistent and safe name for Bazel""
 str: A sanitized python package.2?
sanitize_package_name&@@rules_req_compile//private:utils.bzl
�whl_repo_name,Compute the name name for a `whl_repository`*�
�
whl_repo_name`
spoke_prefixLThe name of a `py_requirements_repository` like rule plus a platform suffix. (.
packageThe package name for the wheel. (,Compute the name name for a `whl_repository`"
str: A Bazel repository name.27
whl_repo_name&@@rules_req_compile//private:utils.bzl
&Bazel utilities for req-compile rules.�%
*
rules_req_compileprivatewhl_repo.bzl�load_sdist_data*�
v
load_sdist_data
repository_ctx (
	data_file (2<
load_sdist_data)@@rules_req_compile//private:whl_repo.bzl
�whl_repo_to_python_path(Convert a label into a PYTHONPATH entry.*�
�
whl_repo_to_python_path0
repository_ctxThe rule's context object. ( 
rootThe label to a file. ((Convert a label into a PYTHONPATH entry."#
!str: A path to add to PYTHONPATH.2D
whl_repo_to_python_path)@@rules_req_compile//private:whl_repo.bzl
�whl_repository�A repository rule for extracting a python [wheel](https://peps.python.org/pep-0491/) and defining a `py_library`.

This repository is expected to be generated by [py_requirements_repository](#py_requirements_repository).
R�
�
whl_repository�A repository rule for extracting a python [wheel](https://peps.python.org/pep-0491/) and defining a `py_library`.

This repository is expected to be generated by [py_requirements_repository](#py_requirements_repository).
.
name"A unique name for this repository. j
annotationsSSee [py_requirements_repository.annotation](#py_requirements_repository.annotation)2"{}"�

constraintlAn optional constraint to assign to `target_compatible_with` where all other configurations will be invalid.2""O
depsCA list of python package names that the current package depends on. U
interpreter>Optional Python interpreter binary to use for building sdists.2NoneC
package4The name of the python package the wheel represents. 9
patches(Patches to apply to the installed wheel.2[]�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
sdist_deps_reposMINTERNAL: DO NOT USE. Default dependencies for building source distributions.2�[Label("@@req_compile_sdist_compiler__pip//:pkg"), Label("@@req_compile_sdist_compiler__setuptools//:pkg"), Label("@@req_compile_sdist_compiler__wheel//:pkg")]<
sha256,The expected SHA-256 of the file downloaded.2""~
spoke_prefixjThe name of the [py_requirements_repository](#py_requirements_repository) plus a friendly platform suffix. 1
urls#A list of URLs to the python wheel.2[]1
version"The version of the python package. $
whlThe label to a wheel.2None*;
whl_repository)@@rules_req_compile//private:whl_repo.bzl
�!�!0
.
name"A unique name for this repository. l
j
annotationsSSee [py_requirements_repository.annotation](#py_requirements_repository.annotation)2"{}"�
�

constraintlAn optional constraint to assign to `target_compatible_with` where all other configurations will be invalid.2""Q
O
depsCA list of python package names that the current package depends on. W
U
interpreter>Optional Python interpreter binary to use for building sdists.2NoneE
C
package4The name of the python package the wheel represents. ;
9
patches(Patches to apply to the installed wheel.2[]�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
�
sdist_deps_reposMINTERNAL: DO NOT USE. Default dependencies for building source distributions.2�[Label("@@req_compile_sdist_compiler__pip//:pkg"), Label("@@req_compile_sdist_compiler__setuptools//:pkg"), Label("@@req_compile_sdist_compiler__wheel//:pkg")]>
<
sha256,The expected SHA-256 of the file downloaded.2""�
~
spoke_prefixjThe name of the [py_requirements_repository](#py_requirements_repository) plus a friendly platform suffix. 3
1
urls#A list of URLs to the python wheel.2[]3
1
version"The version of the python package. &
$
whlThe label to a wheel.2None�
//private:annotation_utils.bzlr�
2
rules_req_compileprivateannotation_utils.bzlN
deserialize_package_annotationdeserialize_package_annotation
;Y
[�
//private:utils.bzlr�
'
rules_req_compileprivate	utils.bzl 
executeexecute
078
parse_artifact_nameparse_artifact_name
;N<
sanitize_package_namesanitize_package_name
Rg
iBRepository rules for downloading and extracting python wheel files��

rules_req_compiledefs.bzl�py_package_annotation_consumerBA rule for parsing `annotation_data` targets from a python target."�
�
py_package_annotation_consumerBA rule for parsing `annotation_data` targets from a python target.*
nameA unique name for this target. V
consumeGThe name of the `py_package_annotation` target to parse from `package`. 8
package)The python package to parse targets from. "@
py_package_annotation_consumer@@rules_req_compile//:defs.bzl
�&�&,
*
nameA unique name for this target. X
V
consumeGThe name of the `py_package_annotation` target to parse from `package`. :
8
package)The python package to parse targets from. �py_package_annotation_target\A container for targets defined by `py_package_annotation` data applied to a python package."�
�
py_package_annotation_target\A container for targets defined by `py_package_annotation` data applied to a python package.*
nameA unique name for this target. 6
target(The target to track in a python package. ">
py_package_annotation_target@@rules_req_compile//:defs.bzl
$$,
*
nameA unique name for this target. 8
6
target(The target to track in a python package. �py_reqs_compiler�A Bazel rule for compiling python requirements for the current platform.


```python
load("@rules_req_compile//:defs.bzl", "py_reqs_compiler", "py_reqs_solution_test")

filegroup(
    name = "requriements",
    srcs = ["requirements.in"],
    data = [
        # Any transitive files included via `-r` should be added here.
    ],
)

py_reqs_compiler(
    name = "requirements.update",
    requirements_in = ":requirements",
    requirements_txt = "requirements.txt",
)

```

Updating requirements can be performed by running the new target.

```bash
bazel run //:requirements.update
```

By default the rule will try to recycle pins already existing in the solution file (`requirements.txt`). To perform
a clean resolution (fetching latest for all requirements) the `--upgrade` flag can be used.

```bash
bazel run //:requirements.update -- --upgrade
```
"�
�

py_reqs_compiler�A Bazel rule for compiling python requirements for the current platform.


```python
load("@rules_req_compile//:defs.bzl", "py_reqs_compiler", "py_reqs_solution_test")

filegroup(
    name = "requriements",
    srcs = ["requirements.in"],
    data = [
        # Any transitive files included via `-r` should be added here.
    ],
)

py_reqs_compiler(
    name = "requirements.update",
    requirements_in = ":requirements",
    requirements_txt = "requirements.txt",
)

```

Updating requirements can be performed by running the new target.

```bash
bazel run //:requirements.update
```

By default the rule will try to recycle pins already existing in the solution file (`requirements.txt`). To perform
a clean resolution (fetching latest for all requirements) the `--upgrade` flag can be used.

```bash
bazel run //:requirements.update -- --upgrade
```
*
nameA unique name for this target. _
allow_sdistsFWhether or not the solution file is allowed to contain sdist packages.2False�
custom_compile_command�The command to display in the header of the generated lock file (`requirements_txt`). Any references to `{label}` will be replaced with the label of this target.2"bazel run "{label}""2
requirements_inThe input requirements file *
requirements_txtThe solution file. "2
py_reqs_compiler@@rules_req_compile//:defs.bzl
��,
*
nameA unique name for this target. a
_
allow_sdistsFWhether or not the solution file is allowed to contain sdist packages.2False�
�
custom_compile_command�The command to display in the header of the generated lock file (`requirements_txt`). Any references to `{label}` will be replaced with the label of this target.2"bazel run "{label}""4
2
requirements_inThe input requirements file ,
*
requirements_txtThe solution file. �py_reqs_solution_test�A Bazel test rule for ensuring the solution file for a `py_reqs_compiler` target satisifes the given requirements (`requirements_in`).

```python
load("@rules_req_compile//:defs.bzl", "py_reqs_compiler", "py_reqs_solution_test")

py_reqs_compiler(
    name = "requirements.update",
    requirements_in = "requirements.in",
    requirements_txt = "requirements.txt",
)

py_reqs_solution_test(
    name = "requirements_test",
    requirements_in = "requirements.in",
    requirements_txt = "requirements.txt",
)
```

Alternatively, a test can be defined in isolation using just the requirements files:

```python
load("@rules_req_compile//:defs.bzl", "py_reqs_solution_test")

py_reqs_solution_test(
    name = "requirements_test",
    custom_compile_command = "python3 -m req_compile --multiline --hashes --urls --solution requirements.txt requirements.in",
    requirements_in = "requirements.in",
    requirements_txt = "requirements.txt",
)
```
"�
�
py_reqs_solution_test�A Bazel test rule for ensuring the solution file for a `py_reqs_compiler` target satisifes the given requirements (`requirements_in`).

```python
load("@rules_req_compile//:defs.bzl", "py_reqs_compiler", "py_reqs_solution_test")

py_reqs_compiler(
    name = "requirements.update",
    requirements_in = "requirements.in",
    requirements_txt = "requirements.txt",
)

py_reqs_solution_test(
    name = "requirements_test",
    requirements_in = "requirements.in",
    requirements_txt = "requirements.txt",
)
```

Alternatively, a test can be defined in isolation using just the requirements files:

```python
load("@rules_req_compile//:defs.bzl", "py_reqs_solution_test")

py_reqs_solution_test(
    name = "requirements_test",
    custom_compile_command = "python3 -m req_compile --multiline --hashes --urls --solution requirements.txt requirements.in",
    requirements_in = "requirements.in",
    requirements_txt = "requirements.txt",
)
```
*
nameA unique name for this target. �
compiler�The `py_reqs_compiler` target to test. This attribute is mutally exclusive with `requirements_in` and `requirements_txt` and does not do any string formatting like `py_reqs_compiler` does.*
PyReqsCompilerInfo2None�
custom_compile_command�The command to display in the header of the generated lock file (`requirements_txt`). This attribute is required with `requirements_in` and `requirements_txt`.2""m
requirements_inRThe input requirements file. This attribute is mutually exclusive with `compiler`.2Noned
requirements_txtHThe solution file. This attribute is mutually exclusive with `compiler`.2None"7
py_reqs_solution_test@@rules_req_compile//:defs.bzl
��,
*
nameA unique name for this target. �
�
compiler�The `py_reqs_compiler` target to test. This attribute is mutally exclusive with `requirements_in` and `requirements_txt` and does not do any string formatting like `py_reqs_compiler` does.*
PyReqsCompilerInfo2None�
�
custom_compile_command�The command to display in the header of the generated lock file (`requirements_txt`). This attribute is required with `requirements_in` and `requirements_txt`.2""o
m
requirements_inRThe input requirements file. This attribute is mutually exclusive with `compiler`.2Nonef
d
requirements_txtHThe solution file. This attribute is mutually exclusive with `compiler`.2None�py_reqs_remote_compiler�A tool for compiling python requirements on a remote machine.

This rule wraps a `py_req_compiler` target behind a transition and
when a ssh user and host are provided, this target can deploy the
compiler to the remote system and perform compilation.


A rule for extracting variables attributes from the `py_req_compiler` target."�
�
py_reqs_remote_compiler�A tool for compiling python requirements on a remote machine.

This rule wraps a `py_req_compiler` target behind a transition and
when a ssh user and host are provided, this target can deploy the
compiler to the remote system and perform compilation.


A rule for extracting variables attributes from the `py_req_compiler` target.*
nameA unique name for this target. C
compilerThe `py_req_compiler` target. *
PyReqsCompilerInfo
::,
*
nameA unique name for this target. E
C
compilerThe `py_req_compiler` target. *
PyReqsCompilerInfo�py_package_annotation�Annotations to apply to the BUILD file content from package generated from a `pip_repository` rule.

[cf]: https://github.com/bazelbuild/bazel-skylib/blob/main/docs/copy_file_doc.md
*�
�
py_package_annotatione
additive_build_fileFThe label of a `BUILD` file to add to the generated one for a pacakge.None(b
additive_build_file_content;Raw text to add to the generated `BUILD` file of a package.None([
additive_build_content9__DEPRECATED__ use `additive_build_file_content` instead.None(�
	copy_srcs�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl][cf].
The output files are added to the `py_library.srcs` attribute.{}(�

copy_files�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl][cf].
The output files are added to the `py_library.data` attribute.{}(�
copy_executables�A mapping of `src` and `out` files for
[@bazel_skylib//rules:copy_file.bzl][cf]. Targets generated here will also be flagged as
executable.{}(b
dataTA list of labels to add as `data` dependencies to the generated `py_library` target.[](q
data_exclude_globVA list of exclude glob patterns to add as `data` to the generated
`py_library` target.[](b
srcs_exclude_globGA list of labels to add as `srcs` to the generated `py_library` target.[](`
depsRA list of dependencies to include to the package. Can be other packages or labels.[](|
deps_excludeseA list of packages to exclude from the package. (In cases where a package
has circular dependencies).[](=
patches,A list of patch files to apply to the wheel.[](�Annotations to apply to the BUILD file content from package generated from a `pip_repository` rule.

[cf]: https://github.com/bazelbuild/bazel-skylib/blob/main/docs/copy_file_doc.md
"5
3str: A json encoded string of the provided content.2D
py_package_annotation+@@rules_req_compile//private:annotation.bzl
�Gpy_requirements_repository�A rule for importing `requirements.txt` dependencies into Bazel.

Those dependencies become available in a generated `defs.bzl` file.

```python
load("@rules_req_compile//:defs.bzl", "py_requirements_repository")

py_requirements_repository(
    name = "py_requirements",
    requirements_lock = ":requirements.txt",
)

load("@py_requirements//:defs.bzl", "repositories")

repositories()
```

You can then reference installed dependencies from a `BUILD` file with:

```python
load("@py_requirements//:defs.bzl", "requirement")

py_library(
    name = "bar",
    ...
    deps = [
        "//my/other:dep",
        requirement("requests"),
        requirement("numpy"),
    ],
)
```

In addition to the `requirement` macro, which is used to access the generated `py_library`
target generated from a package's wheel, The generated `requirements.bzl` file contains
functionality for exposing [entry points][whl_ep] as `py_binary` targets as well.

[whl_ep]: https://packaging.python.org/specifications/entry-points/

```python
load("@py_requirements//:defs.bzl", "entry_point")

alias(
    name = "pip-compile",
    actual = entry_point(
        pkg = "pip-tools",
        script = "pip-compile",
    ),
)
```

Note that for packages whose name and script are the same, only the name of the package
is needed when calling the `entry_point` macro.

```python
load("@py_requirements//:defs.bzl", "entry_point")

alias(
    name = "flake8",
    actual = entry_point("flake8"),
)
```

A very important detail for generating python dependencies is sdist (source distribution)
dependencies are assumed to be incapable of yielding deterministic outputs. Therefore, any
case where a sdist (source distribution) is found in a solution file passed to either
`requirements_lock` or `requirements_locks`, the dependencies should not be considered
byte-for-byte reproducible. It is highly recommended solution files contain all wheels
so the generated repositories are byte-for-byte consistent. Failure to use binary-only
dependencies will result in unexpected cache invalidation as well as inconsistent or broken
cross-platform behavior when using `requirements_locks`.
R�6
�#
py_requirements_repository�A rule for importing `requirements.txt` dependencies into Bazel.

Those dependencies become available in a generated `defs.bzl` file.

```python
load("@rules_req_compile//:defs.bzl", "py_requirements_repository")

py_requirements_repository(
    name = "py_requirements",
    requirements_lock = ":requirements.txt",
)

load("@py_requirements//:defs.bzl", "repositories")

repositories()
```

You can then reference installed dependencies from a `BUILD` file with:

```python
load("@py_requirements//:defs.bzl", "requirement")

py_library(
    name = "bar",
    ...
    deps = [
        "//my/other:dep",
        requirement("requests"),
        requirement("numpy"),
    ],
)
```

In addition to the `requirement` macro, which is used to access the generated `py_library`
target generated from a package's wheel, The generated `requirements.bzl` file contains
functionality for exposing [entry points][whl_ep] as `py_binary` targets as well.

[whl_ep]: https://packaging.python.org/specifications/entry-points/

```python
load("@py_requirements//:defs.bzl", "entry_point")

alias(
    name = "pip-compile",
    actual = entry_point(
        pkg = "pip-tools",
        script = "pip-compile",
    ),
)
```

Note that for packages whose name and script are the same, only the name of the package
is needed when calling the `entry_point` macro.

```python
load("@py_requirements//:defs.bzl", "entry_point")

alias(
    name = "flake8",
    actual = entry_point("flake8"),
)
```

A very important detail for generating python dependencies is sdist (source distribution)
dependencies are assumed to be incapable of yielding deterministic outputs. Therefore, any
case where a sdist (source distribution) is found in a solution file passed to either
`requirements_lock` or `requirements_locks`, the dependencies should not be considered
byte-for-byte reproducible. It is highly recommended solution files contain all wheels
so the generated repositories are byte-for-byte consistent. Failure to use binary-only
dependencies will result in unexpected cache invalidation as well as inconsistent or broken
cross-platform behavior when using `requirements_locks`.
.
name"A unique name for this repository. �
annotations�Optional annotations to apply to packages. For details see [@rules_python//python:pip.bzl%package_annotation](https://github.com/bazelbuild/rules_python/blob/main/docs/pip_repository.md#package_annotation)
2{}N
hub_name<Name of the hub repository to generate. Do not use directly.2""�
interpreter�The label of a python interpreter to use for compiling source distributions (sdists). If this is not provided then the provided lock file must represent binary-only dependencies. Note that should this interpreter be needed (a sdist was found in `requirements_lock` or `requirements_locks`), the dependencies generated may not be byte-for-byte reproducible and users may experience unexpected cache invalidation or unexpected cross-platform behavior.2None�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
requirements_lock�A fully resolved 'requirements.txt' pip requirement file containing the transitive set of your dependencies. This file _must_ be produced by [req-compile](https://pypi.org/project/req-compile/) and include hashes and urls in the solution. This attribute is mutually exclusive with `requirements_locks`.2None�
requirements_locks�A map of fully resolved 'requirements.txt' pip requirement file containing the transitive set of your dependencies to labels of Bazel [platforms](https://bazel.build/extending/platforms). These requirements files __must__ be produced by [req-compile](https://pypi.org/project/req-compile/) and include hashes and urls in the solution. Each lock file provided will create a dependency tree matching `{name}_{id}__{package}` where `id` is the name of the lock file with `[".", "-"]` characters are replaced by `"_"` and the name `requirements` will be stripped. This means each `requirements_locks` entry will need to be somewhat uniquely named. This attribute is mutually exclusive with `requirements_lock`.	2{}*<
py_requirements_repository@@rules_req_compile//:defs.bzl
�-�-0
.
name"A unique name for this repository. �
�
annotations�Optional annotations to apply to packages. For details see [@rules_python//python:pip.bzl%package_annotation](https://github.com/bazelbuild/rules_python/blob/main/docs/pip_repository.md#package_annotation)
2{}P
N
hub_name<Name of the hub repository to generate. Do not use directly.2""�
�
interpreter�The label of a python interpreter to use for compiling source distributions (sdists). If this is not provided then the provided lock file must represent binary-only dependencies. Note that should this interpreter be needed (a sdist was found in `requirements_lock` or `requirements_locks`), the dependencies generated may not be byte-for-byte reproducible and users may experience unexpected cache invalidation or unexpected cross-platform behavior.2None�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
�
requirements_lock�A fully resolved 'requirements.txt' pip requirement file containing the transitive set of your dependencies. This file _must_ be produced by [req-compile](https://pypi.org/project/req-compile/) and include hashes and urls in the solution. This attribute is mutually exclusive with `requirements_locks`.2None�
�
requirements_locks�A map of fully resolved 'requirements.txt' pip requirement file containing the transitive set of your dependencies to labels of Bazel [platforms](https://bazel.build/extending/platforms). These requirements files __must__ be produced by [req-compile](https://pypi.org/project/req-compile/) and include hashes and urls in the solution. Each lock file provided will create a dependency tree matching `{name}_{id}__{package}` where `id` is the name of the lock file with `[".", "-"]` characters are replaced by `"_"` and the name `requirements` will be stripped. This means each `requirements_locks` entry will need to be somewhat uniquely named. This attribute is mutually exclusive with `requirements_lock`.	2{}�whl_repository�A repository rule for extracting a python [wheel](https://peps.python.org/pep-0491/) and defining a `py_library`.

This repository is expected to be generated by [py_requirements_repository](#py_requirements_repository).
R�
�
whl_repository�A repository rule for extracting a python [wheel](https://peps.python.org/pep-0491/) and defining a `py_library`.

This repository is expected to be generated by [py_requirements_repository](#py_requirements_repository).
.
name"A unique name for this repository. j
annotationsSSee [py_requirements_repository.annotation](#py_requirements_repository.annotation)2"{}"�

constraintlAn optional constraint to assign to `target_compatible_with` where all other configurations will be invalid.2""O
depsCA list of python package names that the current package depends on. U
interpreter>Optional Python interpreter binary to use for building sdists.2NoneC
package4The name of the python package the wheel represents. 9
patches(Patches to apply to the installed wheel.2[]�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
sdist_deps_reposMINTERNAL: DO NOT USE. Default dependencies for building source distributions.2�[Label("@@req_compile_sdist_compiler__pip//:pkg"), Label("@@req_compile_sdist_compiler__setuptools//:pkg"), Label("@@req_compile_sdist_compiler__wheel//:pkg")]<
sha256,The expected SHA-256 of the file downloaded.2""~
spoke_prefixjThe name of the [py_requirements_repository](#py_requirements_repository) plus a friendly platform suffix. 1
urls#A list of URLs to the python wheel.2[]1
version"The version of the python package. $
whlThe label to a wheel.2None*0
whl_repository@@rules_req_compile//:defs.bzl
�!�!0
.
name"A unique name for this repository. l
j
annotationsSSee [py_requirements_repository.annotation](#py_requirements_repository.annotation)2"{}"�
�

constraintlAn optional constraint to assign to `target_compatible_with` where all other configurations will be invalid.2""Q
O
depsCA list of python package names that the current package depends on. W
U
interpreter>Optional Python interpreter binary to use for building sdists.2NoneE
C
package4The name of the python package the wheel represents. ;
9
patches(Patches to apply to the installed wheel.2[]�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
�
sdist_deps_reposMINTERNAL: DO NOT USE. Default dependencies for building source distributions.2�[Label("@@req_compile_sdist_compiler__pip//:pkg"), Label("@@req_compile_sdist_compiler__setuptools//:pkg"), Label("@@req_compile_sdist_compiler__wheel//:pkg")]>
<
sha256,The expected SHA-256 of the file downloaded.2""�
~
spoke_prefixjThe name of the [py_requirements_repository](#py_requirements_repository) plus a friendly platform suffix. 3
1
urls#A list of URLs to the python wheel.2[]3
1
version"The version of the python package. &
$
whlThe label to a wheel.2None�
//private:annotation.bzlr�
,
rules_req_compileprivateannotation.bzl=
py_package_annotation_py_package_annotation
O
py_package_annotation_consumer_py_package_annotation_consumer
$K
py_package_annotation_target_py_package_annotation_target
"
�
//private:compiler.bzlr�
*
rules_req_compileprivatecompiler.bzl3
py_reqs_compiler_py_reqs_compiler
=
py_reqs_solution_test_py_reqs_solution_test

�
//private:remote_compiler.bzlr�
1
rules_req_compileprivateremote_compiler.bzlA
py_reqs_remote_compiler_py_reqs_remote_compiler

�
//private:reqs_repo.bzlr�
+
rules_req_compileprivatereqs_repo.bzlG
py_requirements_repository_py_requirements_repository
"" 
 #�
//private:whl_repo.bzlrk
*
rules_req_compileprivatewhl_repo.bzl/
whl_repository_whl_repository
&&
$'�# Bazel rules for `rules_req_compile`

- [py_package_annotation_consumer](#py_package_annotation_consumer)
- [py_package_annotation_target](#py_package_annotation_target)
- [py_package_annotation](#py_package_annotation)
- [py_reqs_compiler](#py_reqs_compiler)
- [py_reqs_remote_compiler](#py_reqs_remote_compiler)
- [py_reqs_solution_test](#py_reqs_solution_test)
- [py_requirements_repository](#py_requirements_repository)
- [sdist_repository](#sdist_repository)
- [whl_repository](#whl_repository)

---
---
�Y
#
rules_req_compileextensions.bzl�Wrequirements�Module extension providing parsing of Python requirements files into
a hub repository containing an interface to a repository for
each requirement listed in the file.J�V
� 
requirements�Module extension providing parsing of Python requirements files into
a hub repository containing an interface to a repository for
each requirement listed in the file.�
package_annotation9A tag representing a annotation editing a Python package.e
additive_build_fileFThe label of a `BUILD` file to add to the generated one for a pacakge.2None`
additive_build_file_content;Raw text to add to the generated `BUILD` file of a package.2""�
copy_executables�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl](https://github.com/bazelbuild/bazel-skylib/blob/1.7.1/docs/copy_file_doc.md). Targets generated here will also be flagged as executable.
2{}�

copy_files�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl](https://github.com/bazelbuild/bazel-skylib/blob/1.7.1/docs/copy_file_doc.md).
2{}�
	copy_srcs�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl](https://github.com/bazelbuild/bazel-skylib/blob/1.7.1/docs/copy_file_doc.md). The output files are added to the `py_library.srcs` attribute.
2{}b
dataTA list of labels to add as `data` dependencies to the generated `py_library` target.2[]q
data_exclude_globVA list of exclude glob patterns to add as `data` to the generated `py_library` target.2[]b
depsTA list of labels to add as `data` dependencies to the generated `py_library` target.2[]m
deps_excludesVA list of exclude glob patterns to add as `data` to the generated `py_library` target.2[]B
package3The name of the package the annotations applies to. =
patches,A list of patch files to apply to the wheel.2[]b
srcs_exclude_globGA list of labels to add as `srcs` to the generated `py_library` target.2[]�
parse�"Parse a lock file into a hub repo.

A hub repo is a single repository that can be pulled into a
module via `use_repo` and contains all of the Python wheel repos
specified by the requirements files.

Aliases are added at the top-level package of the hub repo to each
package it contains, using a normalized name of the Python project.

```python
requirements = use_extension("@rules_req_compile//extensions:python.bzl", "requirements")
requirements.parse(
    name = "pip_deps",
    requirements_locks = {
        "//3rdparty:requirements.linux.txt": "@platforms//os:linux",
        "//3rdparty:requirements.macos.txt": "@platforms//os:macos",
        "//3rdparty:requirements.windows.txt": "@platforms//os:windows",
    },
)
use_repo(requirements, "pip_deps")
```

This example was a multi-platform set of solutions, pulled into a single
hub repository named "pip_deps".
1
name%Name of the hub repository to create. f
interpreter_linux_aarch64AOptional Linux arm64 Python interpreter binary to use for sdists.2Nonee
interpreter_linux_x86_64AOptional Linux amd64 Python interpreter binary to use for sdists.2Noned
interpreter_macos_aarch64?Optional MacOS ARM Python interpreter binary to use for sdists.2Nonef
interpreter_macos_x86_64BOptional MacOS x86_64 Python interpreter binary to use for sdists.2None`
interpreter_windowsAOptional Windows x64 Python interpreter binary to use for sdists.2None�
override_module_repos�Mapping of module name to list of repos that should be overridden by this hub. The repos
must be those that are expected to be created by this module extension.

The overridden hub will attempt to map all of its requirements to the root module's hub, meaning
the root module hub must be a superset of the overridden hub.

This attribute is intended to have the root module coordinate all Python packages such
that Python libraries from dependencies can be safely imported into the same interpreter.
Do not override repos for libraries that will never be mixed. To inject Python dependencies
for use in most child modules, a custom toolchain type is most appropriate. N
requirements_lock1A single lockfile for a single platform solution.2NoneT
requirements_locks8A dictionary mapping platform to requirement lock files.	2{}"4
requirements$@@rules_req_compile//:extensions.bzl
� � �
�
package_annotation9A tag representing a annotation editing a Python package.e
additive_build_fileFThe label of a `BUILD` file to add to the generated one for a pacakge.2None`
additive_build_file_content;Raw text to add to the generated `BUILD` file of a package.2""�
copy_executables�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl](https://github.com/bazelbuild/bazel-skylib/blob/1.7.1/docs/copy_file_doc.md). Targets generated here will also be flagged as executable.
2{}�

copy_files�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl](https://github.com/bazelbuild/bazel-skylib/blob/1.7.1/docs/copy_file_doc.md).
2{}�
	copy_srcs�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl](https://github.com/bazelbuild/bazel-skylib/blob/1.7.1/docs/copy_file_doc.md). The output files are added to the `py_library.srcs` attribute.
2{}b
dataTA list of labels to add as `data` dependencies to the generated `py_library` target.2[]q
data_exclude_globVA list of exclude glob patterns to add as `data` to the generated `py_library` target.2[]b
depsTA list of labels to add as `data` dependencies to the generated `py_library` target.2[]m
deps_excludesVA list of exclude glob patterns to add as `data` to the generated `py_library` target.2[]B
package3The name of the package the annotations applies to. =
patches,A list of patch files to apply to the wheel.2[]b
srcs_exclude_globGA list of labels to add as `srcs` to the generated `py_library` target.2[]g
e
additive_build_fileFThe label of a `BUILD` file to add to the generated one for a pacakge.2Noneb
`
additive_build_file_content;Raw text to add to the generated `BUILD` file of a package.2""�
�
copy_executables�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl](https://github.com/bazelbuild/bazel-skylib/blob/1.7.1/docs/copy_file_doc.md). Targets generated here will also be flagged as executable.
2{}�
�

copy_files�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl](https://github.com/bazelbuild/bazel-skylib/blob/1.7.1/docs/copy_file_doc.md).
2{}�
�
	copy_srcs�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl](https://github.com/bazelbuild/bazel-skylib/blob/1.7.1/docs/copy_file_doc.md). The output files are added to the `py_library.srcs` attribute.
2{}d
b
dataTA list of labels to add as `data` dependencies to the generated `py_library` target.2[]s
q
data_exclude_globVA list of exclude glob patterns to add as `data` to the generated `py_library` target.2[]d
b
depsTA list of labels to add as `data` dependencies to the generated `py_library` target.2[]o
m
deps_excludesVA list of exclude glob patterns to add as `data` to the generated `py_library` target.2[]D
B
package3The name of the package the annotations applies to. ?
=
patches,A list of patch files to apply to the wheel.2[]d
b
srcs_exclude_globGA list of labels to add as `srcs` to the generated `py_library` target.2[]�
�
parse�"Parse a lock file into a hub repo.

A hub repo is a single repository that can be pulled into a
module via `use_repo` and contains all of the Python wheel repos
specified by the requirements files.

Aliases are added at the top-level package of the hub repo to each
package it contains, using a normalized name of the Python project.

```python
requirements = use_extension("@rules_req_compile//extensions:python.bzl", "requirements")
requirements.parse(
    name = "pip_deps",
    requirements_locks = {
        "//3rdparty:requirements.linux.txt": "@platforms//os:linux",
        "//3rdparty:requirements.macos.txt": "@platforms//os:macos",
        "//3rdparty:requirements.windows.txt": "@platforms//os:windows",
    },
)
use_repo(requirements, "pip_deps")
```

This example was a multi-platform set of solutions, pulled into a single
hub repository named "pip_deps".
1
name%Name of the hub repository to create. f
interpreter_linux_aarch64AOptional Linux arm64 Python interpreter binary to use for sdists.2Nonee
interpreter_linux_x86_64AOptional Linux amd64 Python interpreter binary to use for sdists.2Noned
interpreter_macos_aarch64?Optional MacOS ARM Python interpreter binary to use for sdists.2Nonef
interpreter_macos_x86_64BOptional MacOS x86_64 Python interpreter binary to use for sdists.2None`
interpreter_windowsAOptional Windows x64 Python interpreter binary to use for sdists.2None�
override_module_repos�Mapping of module name to list of repos that should be overridden by this hub. The repos
must be those that are expected to be created by this module extension.

The overridden hub will attempt to map all of its requirements to the root module's hub, meaning
the root module hub must be a superset of the overridden hub.

This attribute is intended to have the root module coordinate all Python packages such
that Python libraries from dependencies can be safely imported into the same interpreter.
Do not override repos for libraries that will never be mixed. To inject Python dependencies
for use in most child modules, a custom toolchain type is most appropriate. N
requirements_lock1A single lockfile for a single platform solution.2NoneT
requirements_locks8A dictionary mapping platform to requirement lock files.	2{}3
1
name%Name of the hub repository to create. h
f
interpreter_linux_aarch64AOptional Linux arm64 Python interpreter binary to use for sdists.2Noneg
e
interpreter_linux_x86_64AOptional Linux amd64 Python interpreter binary to use for sdists.2Nonef
d
interpreter_macos_aarch64?Optional MacOS ARM Python interpreter binary to use for sdists.2Noneh
f
interpreter_macos_x86_64BOptional MacOS x86_64 Python interpreter binary to use for sdists.2Noneb
`
interpreter_windowsAOptional Windows x64 Python interpreter binary to use for sdists.2None�
�
override_module_repos�Mapping of module name to list of repos that should be overridden by this hub. The repos
must be those that are expected to be created by this module extension.

The overridden hub will attempt to map all of its requirements to the root module's hub, meaning
the root module hub must be a superset of the overridden hub.

This attribute is intended to have the root module coordinate all Python packages such
that Python libraries from dependencies can be safely imported into the same interpreter.
Do not override repos for libraries that will never be mixed. To inject Python dependencies
for use in most child modules, a custom toolchain type is most appropriate. P
N
requirements_lock1A single lockfile for a single platform solution.2NoneV
T
requirements_locks8A dictionary mapping platform to requirement lock files.	2{}�
//extensions:python.bzlrh
+
rules_req_compile
extensions
python.bzl+
requirements_requirements

req-compile bzlmod extensions\
 
rules_req_compileversion.bzl#	VERSION	1.0.0rc38j	1.0.0rc38req-compile version 