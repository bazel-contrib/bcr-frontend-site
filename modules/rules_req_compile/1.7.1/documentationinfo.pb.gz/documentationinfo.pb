��
+
rules_req_compile
extensions
python.bzl��requirements�Module extension providing parsing of Python requirements files into
a hub repository containing an interface to a repository for
each requirement listed in the file.J��
ǀ
requirements�Module extension providing parsing of Python requirements files into
a hub repository containing an interface to a repository for
each requirement listed in the file.�
package_annotation�A tag representing an annotation editing a Python package.

By default an annotation applies to the package in the hubs defined by the same module,
so a module never changes another module's hubs by accident. `hubs` widens or narrows
that: the names of particular hubs, or `["*"]` for the hubs of every module, which is how
a module ships fixes for packages its users get by depending on it. A narrower scope
replaces a wider one for the package: a hub's own annotation beats its module's, which
beats one for every hub. The root module wins any disagreement within a scope.

Hubs sharing a wheel share its repository only while they annotate it identically, so an
annotation that applies to some hubs and not others gives those hubs their own repository
for the package.
e
additive_build_fileFThe label of a `BUILD` file to add to the generated one for a pacakge.2None`
additive_build_file_content;Raw text to add to the generated `BUILD` file of a package.2""�
copy_executables�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl](https://github.com/bazelbuild/bazel-skylib/blob/1.7.1/docs/copy_file_doc.md). Targets generated here will also be flagged as executable.
2{}�

copy_files�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl](https://github.com/bazelbuild/bazel-skylib/blob/1.7.1/docs/copy_file_doc.md).
2{}�
	copy_srcs�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl](https://github.com/bazelbuild/bazel-skylib/blob/1.7.1/docs/copy_file_doc.md). The output files are added to the `py_library.srcs` attribute.
2{}b
dataTA list of labels to add as `data` dependencies to the generated `py_library` target.2[]q
data_exclude_globVA list of exclude glob patterns to add as `data` to the generated `py_library` target.2[]b
depsTA list of labels to add as `data` dependencies to the generated `py_library` target.2[]m
deps_excludesVA list of exclude glob patterns to add as `data` to the generated `py_library` target.2[]�
hubs�The hubs the annotation applies to: names of `parse` or `resolve` tags, or `"*"` for the hubs of every module. Defaults to the hubs defined by the same module, which must then define at least one.2[]B
package3The name of the package the annotations applies to. =
patches,A list of patch files to apply to the wheel.2[]b
srcs_exclude_globGA list of labels to add as `srcs` to the generated `py_library` target.2[]�)
parse�"Define a hub repository of Python requirements.

A hub repo is a single repository that can be pulled into a
module via `use_repo` and provides every Python package of its
lock files.

Every distinct wheel pinned by any hub, of any module, is downloaded once into a
repository shared by all the hubs using it. Hub names must therefore be unique
across all modules.

```python
requirements = use_extension("@rules_req_compile//extensions:python.bzl", "requirements")
requirements.parse(
    name = "pip_deps",
    requirements_locks = {
        "//3rdparty:requirements.linux_x86_64.txt": "linux_x86_64",
        "//3rdparty:requirements.macos_aarch64.txt": "macos_aarch64",
        "//3rdparty:requirements.windows_x86_64.txt": "windows_x86_64",
    },
)
use_repo(requirements, "pip_deps")
```

This example was a multi-platform set of solutions, pulled into a single
hub repository named "pip_deps". Each lock is given an id. The platform of
each lock is read from the header `req-compile` writes to lock files compiled
for a platform by `py_reqs_compiler` (`## Platform: manylinux_2_28_x86_64`),
which selects on the operating system and CPU of that wheel platform tag.

To control exactly when a lock is used, map your own config settings to the
ids of the locks with `config_settings`. This is required when two locks share
a platform, e.g. the same operating system and CPU with different glibc floors:

```python
requirements.parse(
    name = "pip_deps",
    config_settings = {
        "//tools/constraints:linux": "linux",
        "//tools/constraints:macos": "macos",
        "@my_constraints//:windows_gpu": "windows",
        # Optionally, the lock used when nothing else matches.
        "//conditions:default": "linux",
    },
    requirements_locks = {
        "//3rdparty:requirements.linux.txt": "linux",
        "//3rdparty:requirements.macos.txt": "macos",
        "//3rdparty:requirements.windows.txt": "windows",
    },
)
```

Both dictionaries are keyed by labels, so the lock files and the config settings
are each resolved by the module defining the hub. Any `config_setting` or
`config_setting_group` visible to that module can be used, and the hub never
needs to see it: the hub aliases each setting and selects on the alias. Once
`config_settings` is used every lock must appear in it, mixing explicit settings
with platforms derived from headers is an error.

A hub whose locks do not all contain the same packages is supported. A package
missing from the lock of a platform is incompatible with that platform, so targets
depending on it are skipped there rather than failing to build.
T
nameHName of the hub repository to create. Must be unique across all modules. �
config_settings�A mapping of `config_setting` labels to the id of the lock in `requirements_locks` they select. The special key `//conditions:default` names the lock used when no config setting matches. When set, every lock must be mapped. When empty, locks are selected by the platform recorded in their header.	2{}f
interpreter_linux_aarch64AOptional Linux arm64 Python interpreter binary to use for sdists.2Nonee
interpreter_linux_x86_64AOptional Linux amd64 Python interpreter binary to use for sdists.2Noned
interpreter_macos_aarch64?Optional MacOS ARM Python interpreter binary to use for sdists.2Nonef
interpreter_macos_x86_64BOptional MacOS x86_64 Python interpreter binary to use for sdists.2None`
interpreter_windowsAOptional Windows x64 Python interpreter binary to use for sdists.2None�
legacy_root_pkg_aliases�If True, creates aliases in the root BUILD.bazel file pointing to the package targets in their subpackages. This provides backward compatibility for code that references packages at the root (e.g., `@repo//:package_name`).2False�
override_module_repos�Mapping of module name to list of hubs that should be overridden by this hub. The hubs
must be those that are expected to be created by this module extension for that module.

Every package of the overridden hub becomes an alias of the same package in this hub,
meaning this hub must provide every package of the overridden hub.

This attribute is intended to have the root module coordinate all Python packages such
that Python libraries from dependencies can be safely imported into the same interpreter.
Do not override repos for libraries that will never be mixed. To inject Python dependencies
for use in most child modules, a custom toolchain type is most appropriate. �
package_aliases�Map `py_library` targets to replace instances of the paired distribution when
used. This allows local source code to directly replaced a library which normally comes from
a downloaded wheel.	2{}N
requirements_lock1A single lockfile for a single platform solution.2None�
requirements_locks�A mapping of lock files to an id naming each lock within the hub. Ids are matched against `config_settings`; without `config_settings`, locks are selected by the platform recorded in their header. An empty id derives the id from the header or file name. For compatibility, a value that is a label string is treated as the config setting of the lock, but such labels are resolved relative to `rules_req_compile` and can only name config settings visible to it.	2{}�A
resolve�Define a hub repository of Python requirements that Bazel resolves itself.

The hub is resolved from requirement files, without a host Python: the solver is
the `req_compile` package running in a WebAssembly module, which Bazel executes
with its experimental `execute_wasm` support; set
`--experimental_repository_ctx_execute_wasm` (and, with Bazel 10 or newer,
`--experimental_repository_ctx_wasm_compilation`) in `.bazelrc`. The solution is
recorded in `MODULE.bazel.lock`, which is then the lock: it is reused until a
requirement file or the tag changes, and `--lockfile_mode=error` fails the build
when it is out of date. Each release of `rules_req_compile` knows the module built
with it and downloads it, through Bazel's repository cache, the first time a hub
resolves; `solver` names a locally built module instead.

```python
requirements = use_extension("@rules_req_compile//extensions:python.bzl", "requirements")
requirements.resolve(
    name = "pip_deps",
    requirements_in = ["//3rdparty:requirements.in"],
    requirements_txt = "//3rdparty:requirements.txt",
    python_version = "3.11",
    platforms = [
        "manylinux_2_28_x86_64",
        "macosx_11_0_arm64",
        "win_amd64",
    ],
)
use_repo(requirements, "pip_deps")
```

The hub is the same kind of repository a `parse` tag defines from lock files, and
hub names are unique across both. Every platform is resolved together, with one
version of each package across platforms, exactly as `py_reqs_compiler` does with
`requirements_txts`. The lock of each platform is selected like a lock file whose
header names that platform. Nothing of this runs unless some module uses this tag.

The solution is also remembered in the lock file's facts. When a requirement
file changes, the next resolution keeps every version the change does not
disturb, like `py_reqs_compiler` recycling its solution, and fetches only the
pages and metadata of what is new. To move a pin on purpose, with
`requirements_txt`:
`REQ_COMPILE_UPGRADE=<package>[,<package>] bazel run @<hub>//:requirements.update`
(`all` for every package); the extension resolves those packages again from the
index, ignoring their pins in the file, and the update writes the result. A hub
with no `requirements_txt` has only the lock to move:
`REQ_COMPILE_UPGRADE=<package>[,<package>] bazel mod deps`.

With `requirements_txt` the hub also keeps a pinned requirements file in the
workspace, in the shape `pip-compile --generate-hashes` writes: every package at
its resolved version with the hashes of the artifacts the hub's platforms use.
`bazel run @<hub>//:requirements.update` writes it and `@<hub>//:requirements.test`
fails while it is out of date, as `py_reqs_solution_test` does for compiled
locks. Fed back to the hub, the file is what an existing lock is to pip-compile:
each package keeps the version it pins, with the file's hashes, while
`requirements_in` and the other packages allow it, and is resolved again when
they do not, so a version Dependabot bumps in the file is what the next
resolution uses and a bound raised in `requirements_in` moves the pin by
itself; a package newly added to `requirements_in` resolves freely and then
appears in the file. The file is the pin list a bot can edit; `MODULE.bazel.lock`
remains the lock.
T
nameHName of the hub repository to create. Must be unique across all modules. J
allow_prerelease-Whether pre-release versions may be selected.2False�
allow_sdists�Whether source distributions may be selected. Only distributions whose dependencies are static metadata (PEP 643) can be used; the solver cannot run a build.2FalseX
constraintsCConstraint files, which constrain versions without being installed.2[]�
enforce_hashes�Whether the `--hash` values of the requirement files, if any, must match the artifacts chosen. With it, a pinned file maintained by Dependabot is also an integrity check: a version bumped without its hashes fails to resolve, and so does any package the files pin no hash for, as with `pip --require-hashes`. Disable it for a hub whose platforms need artifacts the file does not list hashes for.2TrueQ
extra_index_urls7Additional package indexes, searched after `index_url`.2[]�
	index_url�The package index to resolve from. An `https` URL: Bazel downloads a plain `http` URL only with a checksum, which index pages never have (Bazel 10 excepts `localhost`).2"https://pypi.org/simple"f
interpreter_linux_aarch64AOptional Linux arm64 Python interpreter binary to use for sdists.2Nonee
interpreter_linux_x86_64AOptional Linux amd64 Python interpreter binary to use for sdists.2Noned
interpreter_macos_aarch64?Optional MacOS ARM Python interpreter binary to use for sdists.2Nonef
interpreter_macos_x86_64BOptional MacOS x86_64 Python interpreter binary to use for sdists.2None`
interpreter_windowsAOptional Windows x64 Python interpreter binary to use for sdists.2None�
legacy_root_pkg_aliases�If True, creates aliases in the root BUILD.bazel file pointing to the package targets in their subpackages. This provides backward compatibility for code that references packages at the root (e.g., `@repo//:package_name`).2False�

max_roundsnThe most rounds of downloads the solver may ask for. Each round is one level of the dependency graph, or less.240�
override_module_repos�Mapping of module name to list of hubs that should be overridden by this hub. The hubs
must be those that are expected to be created by this module extension for that module.

Every package of the overridden hub becomes an alias of the same package in this hub,
meaning this hub must provide every package of the overridden hub.

This attribute is intended to have the root module coordinate all Python packages such
that Python libraries from dependencies can be safely imported into the same interpreter.
Do not override repos for libraries that will never be mixed. To inject Python dependencies
for use in most child modules, a custom toolchain type is most appropriate. �
package_aliases�Map `py_library` targets to replace instances of the paired distribution when
used. This allows local source code to directly replaced a library which normally comes from
a downloaded wheel.	2{}�
	platforms�The wheel platform tags to resolve for, as accepted by `pip --platform`, e.g. `manylinux_2_28_x86_64`, `macosx_11_0_arm64` or `win_amd64`. One lock is produced per tag.2[]S
python_version;The Python version to resolve for, e.g. `3.11` or `3.11.4`.2""�
requirements_in�Requirement files to resolve inside Bazel with the WebAssembly solver, instead of `requirements_lock` or `requirements_locks`. Needs `python_version` and `platforms`, and Bazel's experimental `execute_wasm` support.2[]�	
requirements_txt�	The hub's pinned requirements file, kept in step with its solution. The hub renders it (one entry per package with its version, the sha256 of every artifact its platforms use, and what requires it) and exposes `@<hub>//:requirements.update`, which writes it into the workspace, and `@<hub>//:requirements.test`, which fails when it is out of date. Fed back here, the file is what an existing lock is to pip-compile: each package keeps the version it pins, with the file's hashes, while `requirements_in` and the other packages allow it, and is resolved again when they do not. So a version bumped in it, by Dependabot for instance, is what the next resolution uses, a bound raised in `requirements_in` moves the pin by itself, and packages not yet in it resolve freely and then appear in it. A pin the requirements still allow is moved on purpose with `REQ_COMPILE_UPGRADE=<package>[,<package>] bazel run @<hub>//:requirements.update` (`all` for every package). Must be a file of the root module; it needs no `exports_files`. The test lives in the hub repository, outside `//...`, so a `test_suite` in the workspace that lists it puts it in the default test set.2None�
solver�A `req_compile_solver.wasm` module to use instead of the one built with this release of `rules_req_compile`, for instance the output of `bazel build //wasm:req_compile_solver` in a checkout. A source checkout of the rules has no module of its own and needs this.2NoneS
solver_memory_limit.The memory limit of one solver call, in bytes.2
1073741824":
requirements*@@rules_req_compile//extensions:python.bzl
� � �!
�
package_annotation�A tag representing an annotation editing a Python package.

By default an annotation applies to the package in the hubs defined by the same module,
so a module never changes another module's hubs by accident. `hubs` widens or narrows
that: the names of particular hubs, or `["*"]` for the hubs of every module, which is how
a module ships fixes for packages its users get by depending on it. A narrower scope
replaces a wider one for the package: a hub's own annotation beats its module's, which
beats one for every hub. The root module wins any disagreement within a scope.

Hubs sharing a wheel share its repository only while they annotate it identically, so an
annotation that applies to some hubs and not others gives those hubs their own repository
for the package.
e
additive_build_fileFThe label of a `BUILD` file to add to the generated one for a pacakge.2None`
additive_build_file_content;Raw text to add to the generated `BUILD` file of a package.2""�
copy_executables�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl](https://github.com/bazelbuild/bazel-skylib/blob/1.7.1/docs/copy_file_doc.md). Targets generated here will also be flagged as executable.
2{}�

copy_files�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl](https://github.com/bazelbuild/bazel-skylib/blob/1.7.1/docs/copy_file_doc.md).
2{}�
	copy_srcs�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl](https://github.com/bazelbuild/bazel-skylib/blob/1.7.1/docs/copy_file_doc.md). The output files are added to the `py_library.srcs` attribute.
2{}b
dataTA list of labels to add as `data` dependencies to the generated `py_library` target.2[]q
data_exclude_globVA list of exclude glob patterns to add as `data` to the generated `py_library` target.2[]b
depsTA list of labels to add as `data` dependencies to the generated `py_library` target.2[]m
deps_excludesVA list of exclude glob patterns to add as `data` to the generated `py_library` target.2[]�
hubs�The hubs the annotation applies to: names of `parse` or `resolve` tags, or `"*"` for the hubs of every module. Defaults to the hubs defined by the same module, which must then define at least one.2[]B
package3The name of the package the annotations applies to. =
patches,A list of patch files to apply to the wheel.2[]b
srcs_exclude_globGA list of labels to add as `srcs` to the generated `py_library` target.2[]g
e
additive_build_fileFThe label of a `BUILD` file to add to the generated one for a pacakge.2Noneb
`
additive_build_file_content;Raw text to add to the generated `BUILD` file of a package.2""�
�
copy_executables�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl](https://github.com/bazelbuild/bazel-skylib/blob/1.7.1/docs/copy_file_doc.md). Targets generated here will also be flagged as executable.
2{}�
�

copy_files�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl](https://github.com/bazelbuild/bazel-skylib/blob/1.7.1/docs/copy_file_doc.md).
2{}�
�
	copy_srcs�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl](https://github.com/bazelbuild/bazel-skylib/blob/1.7.1/docs/copy_file_doc.md). The output files are added to the `py_library.srcs` attribute.
2{}d
b
dataTA list of labels to add as `data` dependencies to the generated `py_library` target.2[]s
q
data_exclude_globVA list of exclude glob patterns to add as `data` to the generated `py_library` target.2[]d
b
depsTA list of labels to add as `data` dependencies to the generated `py_library` target.2[]o
m
deps_excludesVA list of exclude glob patterns to add as `data` to the generated `py_library` target.2[]�
�
hubs�The hubs the annotation applies to: names of `parse` or `resolve` tags, or `"*"` for the hubs of every module. Defaults to the hubs defined by the same module, which must then define at least one.2[]D
B
package3The name of the package the annotations applies to. ?
=
patches,A list of patch files to apply to the wheel.2[]d
b
srcs_exclude_globGA list of labels to add as `srcs` to the generated `py_library` target.2[]�>
�)
parse�"Define a hub repository of Python requirements.

A hub repo is a single repository that can be pulled into a
module via `use_repo` and provides every Python package of its
lock files.

Every distinct wheel pinned by any hub, of any module, is downloaded once into a
repository shared by all the hubs using it. Hub names must therefore be unique
across all modules.

```python
requirements = use_extension("@rules_req_compile//extensions:python.bzl", "requirements")
requirements.parse(
    name = "pip_deps",
    requirements_locks = {
        "//3rdparty:requirements.linux_x86_64.txt": "linux_x86_64",
        "//3rdparty:requirements.macos_aarch64.txt": "macos_aarch64",
        "//3rdparty:requirements.windows_x86_64.txt": "windows_x86_64",
    },
)
use_repo(requirements, "pip_deps")
```

This example was a multi-platform set of solutions, pulled into a single
hub repository named "pip_deps". Each lock is given an id. The platform of
each lock is read from the header `req-compile` writes to lock files compiled
for a platform by `py_reqs_compiler` (`## Platform: manylinux_2_28_x86_64`),
which selects on the operating system and CPU of that wheel platform tag.

To control exactly when a lock is used, map your own config settings to the
ids of the locks with `config_settings`. This is required when two locks share
a platform, e.g. the same operating system and CPU with different glibc floors:

```python
requirements.parse(
    name = "pip_deps",
    config_settings = {
        "//tools/constraints:linux": "linux",
        "//tools/constraints:macos": "macos",
        "@my_constraints//:windows_gpu": "windows",
        # Optionally, the lock used when nothing else matches.
        "//conditions:default": "linux",
    },
    requirements_locks = {
        "//3rdparty:requirements.linux.txt": "linux",
        "//3rdparty:requirements.macos.txt": "macos",
        "//3rdparty:requirements.windows.txt": "windows",
    },
)
```

Both dictionaries are keyed by labels, so the lock files and the config settings
are each resolved by the module defining the hub. Any `config_setting` or
`config_setting_group` visible to that module can be used, and the hub never
needs to see it: the hub aliases each setting and selects on the alias. Once
`config_settings` is used every lock must appear in it, mixing explicit settings
with platforms derived from headers is an error.

A hub whose locks do not all contain the same packages is supported. A package
missing from the lock of a platform is incompatible with that platform, so targets
depending on it are skipped there rather than failing to build.
T
nameHName of the hub repository to create. Must be unique across all modules. �
config_settings�A mapping of `config_setting` labels to the id of the lock in `requirements_locks` they select. The special key `//conditions:default` names the lock used when no config setting matches. When set, every lock must be mapped. When empty, locks are selected by the platform recorded in their header.	2{}f
interpreter_linux_aarch64AOptional Linux arm64 Python interpreter binary to use for sdists.2Nonee
interpreter_linux_x86_64AOptional Linux amd64 Python interpreter binary to use for sdists.2Noned
interpreter_macos_aarch64?Optional MacOS ARM Python interpreter binary to use for sdists.2Nonef
interpreter_macos_x86_64BOptional MacOS x86_64 Python interpreter binary to use for sdists.2None`
interpreter_windowsAOptional Windows x64 Python interpreter binary to use for sdists.2None�
legacy_root_pkg_aliases�If True, creates aliases in the root BUILD.bazel file pointing to the package targets in their subpackages. This provides backward compatibility for code that references packages at the root (e.g., `@repo//:package_name`).2False�
override_module_repos�Mapping of module name to list of hubs that should be overridden by this hub. The hubs
must be those that are expected to be created by this module extension for that module.

Every package of the overridden hub becomes an alias of the same package in this hub,
meaning this hub must provide every package of the overridden hub.

This attribute is intended to have the root module coordinate all Python packages such
that Python libraries from dependencies can be safely imported into the same interpreter.
Do not override repos for libraries that will never be mixed. To inject Python dependencies
for use in most child modules, a custom toolchain type is most appropriate. �
package_aliases�Map `py_library` targets to replace instances of the paired distribution when
used. This allows local source code to directly replaced a library which normally comes from
a downloaded wheel.	2{}N
requirements_lock1A single lockfile for a single platform solution.2None�
requirements_locks�A mapping of lock files to an id naming each lock within the hub. Ids are matched against `config_settings`; without `config_settings`, locks are selected by the platform recorded in their header. An empty id derives the id from the header or file name. For compatibility, a value that is a label string is treated as the config setting of the lock, but such labels are resolved relative to `rules_req_compile` and can only name config settings visible to it.	2{}V
T
nameHName of the hub repository to create. Must be unique across all modules. �
�
config_settings�A mapping of `config_setting` labels to the id of the lock in `requirements_locks` they select. The special key `//conditions:default` names the lock used when no config setting matches. When set, every lock must be mapped. When empty, locks are selected by the platform recorded in their header.	2{}h
f
interpreter_linux_aarch64AOptional Linux arm64 Python interpreter binary to use for sdists.2Noneg
e
interpreter_linux_x86_64AOptional Linux amd64 Python interpreter binary to use for sdists.2Nonef
d
interpreter_macos_aarch64?Optional MacOS ARM Python interpreter binary to use for sdists.2Noneh
f
interpreter_macos_x86_64BOptional MacOS x86_64 Python interpreter binary to use for sdists.2Noneb
`
interpreter_windowsAOptional Windows x64 Python interpreter binary to use for sdists.2None�
�
legacy_root_pkg_aliases�If True, creates aliases in the root BUILD.bazel file pointing to the package targets in their subpackages. This provides backward compatibility for code that references packages at the root (e.g., `@repo//:package_name`).2False�
�
override_module_repos�Mapping of module name to list of hubs that should be overridden by this hub. The hubs
must be those that are expected to be created by this module extension for that module.

Every package of the overridden hub becomes an alias of the same package in this hub,
meaning this hub must provide every package of the overridden hub.

This attribute is intended to have the root module coordinate all Python packages such
that Python libraries from dependencies can be safely imported into the same interpreter.
Do not override repos for libraries that will never be mixed. To inject Python dependencies
for use in most child modules, a custom toolchain type is most appropriate. �
�
package_aliases�Map `py_library` targets to replace instances of the paired distribution when
used. This allows local source code to directly replaced a library which normally comes from
a downloaded wheel.	2{}P
N
requirements_lock1A single lockfile for a single platform solution.2None�
�
requirements_locks�A mapping of lock files to an id naming each lock within the hub. Ids are matched against `config_settings`; without `config_settings`, locks are selected by the platform recorded in their header. An empty id derives the id from the header or file name. For compatibility, a value that is a label string is treated as the config setting of the lock, but such labels are resolved relative to `rules_req_compile` and can only name config settings visible to it.	2{}�i
�A
resolve�Define a hub repository of Python requirements that Bazel resolves itself.

The hub is resolved from requirement files, without a host Python: the solver is
the `req_compile` package running in a WebAssembly module, which Bazel executes
with its experimental `execute_wasm` support; set
`--experimental_repository_ctx_execute_wasm` (and, with Bazel 10 or newer,
`--experimental_repository_ctx_wasm_compilation`) in `.bazelrc`. The solution is
recorded in `MODULE.bazel.lock`, which is then the lock: it is reused until a
requirement file or the tag changes, and `--lockfile_mode=error` fails the build
when it is out of date. Each release of `rules_req_compile` knows the module built
with it and downloads it, through Bazel's repository cache, the first time a hub
resolves; `solver` names a locally built module instead.

```python
requirements = use_extension("@rules_req_compile//extensions:python.bzl", "requirements")
requirements.resolve(
    name = "pip_deps",
    requirements_in = ["//3rdparty:requirements.in"],
    requirements_txt = "//3rdparty:requirements.txt",
    python_version = "3.11",
    platforms = [
        "manylinux_2_28_x86_64",
        "macosx_11_0_arm64",
        "win_amd64",
    ],
)
use_repo(requirements, "pip_deps")
```

The hub is the same kind of repository a `parse` tag defines from lock files, and
hub names are unique across both. Every platform is resolved together, with one
version of each package across platforms, exactly as `py_reqs_compiler` does with
`requirements_txts`. The lock of each platform is selected like a lock file whose
header names that platform. Nothing of this runs unless some module uses this tag.

The solution is also remembered in the lock file's facts. When a requirement
file changes, the next resolution keeps every version the change does not
disturb, like `py_reqs_compiler` recycling its solution, and fetches only the
pages and metadata of what is new. To move a pin on purpose, with
`requirements_txt`:
`REQ_COMPILE_UPGRADE=<package>[,<package>] bazel run @<hub>//:requirements.update`
(`all` for every package); the extension resolves those packages again from the
index, ignoring their pins in the file, and the update writes the result. A hub
with no `requirements_txt` has only the lock to move:
`REQ_COMPILE_UPGRADE=<package>[,<package>] bazel mod deps`.

With `requirements_txt` the hub also keeps a pinned requirements file in the
workspace, in the shape `pip-compile --generate-hashes` writes: every package at
its resolved version with the hashes of the artifacts the hub's platforms use.
`bazel run @<hub>//:requirements.update` writes it and `@<hub>//:requirements.test`
fails while it is out of date, as `py_reqs_solution_test` does for compiled
locks. Fed back to the hub, the file is what an existing lock is to pip-compile:
each package keeps the version it pins, with the file's hashes, while
`requirements_in` and the other packages allow it, and is resolved again when
they do not, so a version Dependabot bumps in the file is what the next
resolution uses and a bound raised in `requirements_in` moves the pin by
itself; a package newly added to `requirements_in` resolves freely and then
appears in the file. The file is the pin list a bot can edit; `MODULE.bazel.lock`
remains the lock.
T
nameHName of the hub repository to create. Must be unique across all modules. J
allow_prerelease-Whether pre-release versions may be selected.2False�
allow_sdists�Whether source distributions may be selected. Only distributions whose dependencies are static metadata (PEP 643) can be used; the solver cannot run a build.2FalseX
constraintsCConstraint files, which constrain versions without being installed.2[]�
enforce_hashes�Whether the `--hash` values of the requirement files, if any, must match the artifacts chosen. With it, a pinned file maintained by Dependabot is also an integrity check: a version bumped without its hashes fails to resolve, and so does any package the files pin no hash for, as with `pip --require-hashes`. Disable it for a hub whose platforms need artifacts the file does not list hashes for.2TrueQ
extra_index_urls7Additional package indexes, searched after `index_url`.2[]�
	index_url�The package index to resolve from. An `https` URL: Bazel downloads a plain `http` URL only with a checksum, which index pages never have (Bazel 10 excepts `localhost`).2"https://pypi.org/simple"f
interpreter_linux_aarch64AOptional Linux arm64 Python interpreter binary to use for sdists.2Nonee
interpreter_linux_x86_64AOptional Linux amd64 Python interpreter binary to use for sdists.2Noned
interpreter_macos_aarch64?Optional MacOS ARM Python interpreter binary to use for sdists.2Nonef
interpreter_macos_x86_64BOptional MacOS x86_64 Python interpreter binary to use for sdists.2None`
interpreter_windowsAOptional Windows x64 Python interpreter binary to use for sdists.2None�
legacy_root_pkg_aliases�If True, creates aliases in the root BUILD.bazel file pointing to the package targets in their subpackages. This provides backward compatibility for code that references packages at the root (e.g., `@repo//:package_name`).2False�

max_roundsnThe most rounds of downloads the solver may ask for. Each round is one level of the dependency graph, or less.240�
override_module_repos�Mapping of module name to list of hubs that should be overridden by this hub. The hubs
must be those that are expected to be created by this module extension for that module.

Every package of the overridden hub becomes an alias of the same package in this hub,
meaning this hub must provide every package of the overridden hub.

This attribute is intended to have the root module coordinate all Python packages such
that Python libraries from dependencies can be safely imported into the same interpreter.
Do not override repos for libraries that will never be mixed. To inject Python dependencies
for use in most child modules, a custom toolchain type is most appropriate. �
package_aliases�Map `py_library` targets to replace instances of the paired distribution when
used. This allows local source code to directly replaced a library which normally comes from
a downloaded wheel.	2{}�
	platforms�The wheel platform tags to resolve for, as accepted by `pip --platform`, e.g. `manylinux_2_28_x86_64`, `macosx_11_0_arm64` or `win_amd64`. One lock is produced per tag.2[]S
python_version;The Python version to resolve for, e.g. `3.11` or `3.11.4`.2""�
requirements_in�Requirement files to resolve inside Bazel with the WebAssembly solver, instead of `requirements_lock` or `requirements_locks`. Needs `python_version` and `platforms`, and Bazel's experimental `execute_wasm` support.2[]�	
requirements_txt�	The hub's pinned requirements file, kept in step with its solution. The hub renders it (one entry per package with its version, the sha256 of every artifact its platforms use, and what requires it) and exposes `@<hub>//:requirements.update`, which writes it into the workspace, and `@<hub>//:requirements.test`, which fails when it is out of date. Fed back here, the file is what an existing lock is to pip-compile: each package keeps the version it pins, with the file's hashes, while `requirements_in` and the other packages allow it, and is resolved again when they do not. So a version bumped in it, by Dependabot for instance, is what the next resolution uses, a bound raised in `requirements_in` moves the pin by itself, and packages not yet in it resolve freely and then appear in it. A pin the requirements still allow is moved on purpose with `REQ_COMPILE_UPGRADE=<package>[,<package>] bazel run @<hub>//:requirements.update` (`all` for every package). Must be a file of the root module; it needs no `exports_files`. The test lives in the hub repository, outside `//...`, so a `test_suite` in the workspace that lists it puts it in the default test set.2None�
solver�A `req_compile_solver.wasm` module to use instead of the one built with this release of `rules_req_compile`, for instance the output of `bazel build //wasm:req_compile_solver` in a checkout. A source checkout of the rules has no module of its own and needs this.2NoneS
solver_memory_limit.The memory limit of one solver call, in bytes.2
1073741824V
T
nameHName of the hub repository to create. Must be unique across all modules. L
J
allow_prerelease-Whether pre-release versions may be selected.2False�
�
allow_sdists�Whether source distributions may be selected. Only distributions whose dependencies are static metadata (PEP 643) can be used; the solver cannot run a build.2FalseZ
X
constraintsCConstraint files, which constrain versions without being installed.2[]�
�
enforce_hashes�Whether the `--hash` values of the requirement files, if any, must match the artifacts chosen. With it, a pinned file maintained by Dependabot is also an integrity check: a version bumped without its hashes fails to resolve, and so does any package the files pin no hash for, as with `pip --require-hashes`. Disable it for a hub whose platforms need artifacts the file does not list hashes for.2TrueS
Q
extra_index_urls7Additional package indexes, searched after `index_url`.2[]�
�
	index_url�The package index to resolve from. An `https` URL: Bazel downloads a plain `http` URL only with a checksum, which index pages never have (Bazel 10 excepts `localhost`).2"https://pypi.org/simple"h
f
interpreter_linux_aarch64AOptional Linux arm64 Python interpreter binary to use for sdists.2Noneg
e
interpreter_linux_x86_64AOptional Linux amd64 Python interpreter binary to use for sdists.2Nonef
d
interpreter_macos_aarch64?Optional MacOS ARM Python interpreter binary to use for sdists.2Noneh
f
interpreter_macos_x86_64BOptional MacOS x86_64 Python interpreter binary to use for sdists.2Noneb
`
interpreter_windowsAOptional Windows x64 Python interpreter binary to use for sdists.2None�
�
legacy_root_pkg_aliases�If True, creates aliases in the root BUILD.bazel file pointing to the package targets in their subpackages. This provides backward compatibility for code that references packages at the root (e.g., `@repo//:package_name`).2False�
�

max_roundsnThe most rounds of downloads the solver may ask for. Each round is one level of the dependency graph, or less.240�
�
override_module_repos�Mapping of module name to list of hubs that should be overridden by this hub. The hubs
must be those that are expected to be created by this module extension for that module.

Every package of the overridden hub becomes an alias of the same package in this hub,
meaning this hub must provide every package of the overridden hub.

This attribute is intended to have the root module coordinate all Python packages such
that Python libraries from dependencies can be safely imported into the same interpreter.
Do not override repos for libraries that will never be mixed. To inject Python dependencies
for use in most child modules, a custom toolchain type is most appropriate. �
�
package_aliases�Map `py_library` targets to replace instances of the paired distribution when
used. This allows local source code to directly replaced a library which normally comes from
a downloaded wheel.	2{}�
�
	platforms�The wheel platform tags to resolve for, as accepted by `pip --platform`, e.g. `manylinux_2_28_x86_64`, `macosx_11_0_arm64` or `win_amd64`. One lock is produced per tag.2[]U
S
python_version;The Python version to resolve for, e.g. `3.11` or `3.11.4`.2""�
�
requirements_in�Requirement files to resolve inside Bazel with the WebAssembly solver, instead of `requirements_lock` or `requirements_locks`. Needs `python_version` and `platforms`, and Bazel's experimental `execute_wasm` support.2[]�	
�	
requirements_txt�	The hub's pinned requirements file, kept in step with its solution. The hub renders it (one entry per package with its version, the sha256 of every artifact its platforms use, and what requires it) and exposes `@<hub>//:requirements.update`, which writes it into the workspace, and `@<hub>//:requirements.test`, which fails when it is out of date. Fed back here, the file is what an existing lock is to pip-compile: each package keeps the version it pins, with the file's hashes, while `requirements_in` and the other packages allow it, and is resolved again when they do not. So a version bumped in it, by Dependabot for instance, is what the next resolution uses, a bound raised in `requirements_in` moves the pin by itself, and packages not yet in it resolve freely and then appear in it. A pin the requirements still allow is moved on purpose with `REQ_COMPILE_UPGRADE=<package>[,<package>] bazel run @<hub>//:requirements.update` (`all` for every package). Must be a file of the root module; it needs no `exports_files`. The test lives in the hub repository, outside `//...`, so a `test_suite` in the workspace that lists it puts it in the default test set.2None�
�
solver�A `req_compile_solver.wasm` module to use instead of the one built with this release of `rules_req_compile`, for instance the output of `bazel build //wasm:req_compile_solver` in a checkout. A source checkout of the rules has no module of its own and needs this.2NoneU
S
solver_memory_limit.The memory limit of one solver call, in bytes.2
1073741824w
	:defs.bzlrh

rules_req_compiledefs.bzl9
py_package_annotationpackage_annotation

�
*//req_compile/private:annotation_utils.bzlr�
>
rules_req_compilereq_compile/privateannotation_utils.bzl4
record_annotationrecord_annotation
	G	X
		Z�
#//req_compile/private:reqs_repo.bzlr�
7
rules_req_compilereq_compile/privatereqs_repo.bzl2
create_hub_reposcreate_hub_repos
"
hub_spechub_spec
$
	lock_spec	lock_spec
$
	plan_hubs	plan_hubs

�
!//req_compile/private:resolve.bzlr�
5
rules_req_compilereq_compile/privateresolve.bzl*
resolve_hubsresolve_hubs
>J*
resolve_specresolve_spec
NZ
\	ALL_HUBS*j*%Python requirements module extension.�&
8
rules_req_compilereq_compile/privateannotation.bzl�py_package_annotation_consumerBA rule for parsing `annotation_data` targets from a python target."�
�
py_package_annotation_consumerBA rule for parsing `annotation_data` targets from a python target.*
nameA unique name for this target. V
consumeGThe name of the `py_package_annotation` target to parse from `package`. 8
package)The python package to parse targets from. "Y
py_package_annotation_consumer7@@rules_req_compile//req_compile/private:annotation.bzl
�&�&,
*
nameA unique name for this target. X
V
consumeGThe name of the `py_package_annotation` target to parse from `package`. :
8
package)The python package to parse targets from. �py_package_annotation_target\A container for targets defined by `py_package_annotation` data applied to a python package."�
�
py_package_annotation_target\A container for targets defined by `py_package_annotation` data applied to a python package.*
nameA unique name for this target. 6
target(The target to track in a python package. "W
py_package_annotation_target7@@rules_req_compile//req_compile/private:annotation.bzl
$$,
*
nameA unique name for this target. 8
6
target(The target to track in a python package. �py_package_annotation�Annotations to apply to the BUILD file content from package generated from a `pip_repository` rule.

[cf]: https://github.com/bazelbuild/bazel-skylib/blob/main/docs/copy_file_doc.md
*�
�
py_package_annotatione
additive_build_fileFThe label of a `BUILD` file to add to the generated one for a pacakge.None(b
additive_build_file_content;Raw text to add to the generated `BUILD` file of a package.None([
additive_build_content9__DEPRECATED__ use `additive_build_file_content` instead.None(�
	copy_srcs�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl][cf].
The output files are added to the `py_library.srcs` attribute.{}(�

copy_files�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl][cf].
The output files are added to the `py_library.data` attribute.{}(�
copy_executables�A mapping of `src` and `out` files for
[@bazel_skylib//rules:copy_file.bzl][cf]. Targets generated here will also be flagged as
executable.{}(b
dataTA list of labels to add as `data` dependencies to the generated `py_library` target.[](q
data_exclude_globVA list of exclude glob patterns to add as `data` to the generated
`py_library` target.[](b
srcs_exclude_globGA list of labels to add as `srcs` to the generated `py_library` target.[](`
depsRA list of dependencies to include to the package. Can be other packages or labels.[](|
deps_excludeseA list of packages to exclude from the package. (In cases where a package
has circular dependencies).[](=
patches,A list of patch files to apply to the wheel.[](�Annotations to apply to the BUILD file content from package generated from a `pip_repository` rule.

[cf]: https://github.com/bazelbuild/bazel-skylib/blob/main/docs/copy_file_doc.md
"5
3str: A json encoded string of the provided content.2P
py_package_annotation7@@rules_req_compile//req_compile/private:annotation.bzl
�PyPackageAnnotatedTargetInfo@Information about a target proudced by `py_package_annotations`.2�
�
PyPackageAnnotatedTargetInfo@Information about a target proudced by `py_package_annotations`.B
	providers5List[str]: A set of provider names found in `target`.=
target3Target: The `py_package_annotation` defined target."W
PyPackageAnnotatedTargetInfo7@@rules_req_compile//req_compile/private:annotation.bzl
g(g(D
B
	providers5List[str]: A set of provider names found in `target`.?
=
target3Target: The `py_package_annotation` defined target.�PyPackageAnnotatedTargetsInfoIInfo about all `py_package_annotation` targets found on a python package.2�
�
PyPackageAnnotatedTargetsInfoIInfo about all `py_package_annotation` targets found on a python package.V
targetsKDepset[PyPackageAnnotatedTargetInfo]: A list of annotation defined targets."X
PyPackageAnnotatedTargetsInfo7@@rules_req_compile//req_compile/private:annotation.bzl
�)�)X
V
targetsKDepset[PyPackageAnnotatedTargetInfo]: A list of annotation defined targets.�!py_package_annotation_deps_aspectRAn aspect for locating `py_package_annotation_target` targets on a python package.:�
�
!py_package_annotation_deps_aspectRAn aspect for locating `py_package_annotation_target` targets on a python package."*
nameA unique name for this target. *\
!py_package_annotation_deps_aspect7@@rules_req_compile//req_compile/private:annotation.bzl
�+�+,
*
nameA unique name for this target. [
//cc:defs.bzlrH

rules_ccccdefs.bzl
CcInfoCcInfo
!'
);Utilities for applying annotations to Bazel python packages�
>
rules_req_compilereq_compile/privateannotation_utils.bzl�deserialize_package_annotation6Deserialize json encoded `py_package_annotation` data.*�
�
deserialize_package_annotation(
contentA json serialized string. (6Deserialize json encoded `py_package_annotation` data."'
%struct: `py_package_annotation` data.2_
deserialize_package_annotation=@@rules_req_compile//req_compile/private:annotation_utils.bzl
00�record_annotation�Record the annotation a module declares for a package.

Annotations are collected from every module. The root module decides any
disagreement, other modules must agree with each other. A module repeating
exactly what was already recorded never changes who decided it.
*�
�
record_annotationM
annotations:Package name to the serialized annotation recorded so far. (F
owners8Package name to the module whose annotation is recorded. (%
packageThe annotated package. (&
dataThe serialized annotation. (2
module$The name of the module declaring it. (6
is_root'Whether that module is the root module. (�Record the annotation a module declares for a package.

Annotations are collected from every module. The root module decides any
disagreement, other modules must agree with each other. A module repeating
exactly what was already recorded never changes who decided it.
2R
record_annotation=@@rules_req_compile//req_compile/private:annotation_utils.bzl


!	ROOT_MODULE<root>j<root>�Utilities for applying annotations to Bazel python packages.

Split this from annotation.bzl since it loads CcInfo and this causes
a circular load() with rules_cc in WORKSPACE.bazel.
�j
6
rules_req_compilereq_compile/privatecompiler.bzl�Hpy_reqs_compiler�A Bazel rule for compiling python requirements.


```python
load("@rules_req_compile//:defs.bzl", "py_reqs_compiler", "py_reqs_solution_test")

filegroup(
    name = "requriements",
    srcs = ["requirements.in"],
    data = [
        # Any transitive files included via `-r` should be added here.
    ],
)

py_reqs_compiler(
    name = "requirements.update",
    requirements_in = ":requirements",
    requirements_txt = "requirements.txt",
)

```

Updating requirements can be performed by running the new target.

```bash
bazel run //:requirements.update
```

By default the rule will try to recycle pins already existing in the solution file (`requirements.txt`). To perform
a clean resolution (fetching latest for all requirements) the `--upgrade` flag can be used. A solution compiled for
another platform or Python version, as recorded in its header, is not recycled: changing the `platform` or
`python_version` of the rule resolves the requirements again.

```bash
bazel run //:requirements.update -- --upgrade
```

By default a solution is compiled for the platform and Python version running the compiler. The `platform` and
`python_version` attributes compile a solution for a different environment, so solutions for every platform a
project supports can be produced and tested from any machine. To support several platforms, map a solution file
to each platform with `requirements_txts`. One target then compiles every solution, and the solutions always use
the same version of each package: a package keeps the version the first platform resolves it to and a version
that another platform cannot use, e.g. because no wheel is published for it, is dropped for all of them. When no
version of a package works on every platform the compilation fails and names the platforms that disagree, so
the package can be constrained in the requirements. A `py_reqs_solution_test` of the target checks every
solution, including that they agree.

```python
load("@rules_req_compile//:defs.bzl", "py_reqs_compiler", "py_reqs_solution_test")

py_reqs_compiler(
    name = "requirements.update",
    requirements_in = ":requirements",
    requirements_txts = {
        "requirements.linux.txt": "manylinux_2_28_x86_64",
        "requirements.macos.txt": "macosx_11_0_arm64",
        "requirements.windows.txt": "win_amd64",
    },
)

py_reqs_solution_test(
    name = "requirements_test",
    compiler = ":requirements.update",
)
```

The versions pinned by any of the solutions are recycled for all of them, so a platform added to
`requirements_txts` starts from the versions the others use. Solutions for different Python versions frequently
cannot share versions, so define one `py_reqs_compiler` per Python version.

Wheels are selected and environment markers are evaluated as they would be when installing on the target.
Source distributions (sdists) have their metadata extracted on the machine running the compiler, so solutions
for other platforms should avoid them, which is the default (`allow_sdists = False`).
"�0
�$
py_reqs_compiler�A Bazel rule for compiling python requirements.


```python
load("@rules_req_compile//:defs.bzl", "py_reqs_compiler", "py_reqs_solution_test")

filegroup(
    name = "requriements",
    srcs = ["requirements.in"],
    data = [
        # Any transitive files included via `-r` should be added here.
    ],
)

py_reqs_compiler(
    name = "requirements.update",
    requirements_in = ":requirements",
    requirements_txt = "requirements.txt",
)

```

Updating requirements can be performed by running the new target.

```bash
bazel run //:requirements.update
```

By default the rule will try to recycle pins already existing in the solution file (`requirements.txt`). To perform
a clean resolution (fetching latest for all requirements) the `--upgrade` flag can be used. A solution compiled for
another platform or Python version, as recorded in its header, is not recycled: changing the `platform` or
`python_version` of the rule resolves the requirements again.

```bash
bazel run //:requirements.update -- --upgrade
```

By default a solution is compiled for the platform and Python version running the compiler. The `platform` and
`python_version` attributes compile a solution for a different environment, so solutions for every platform a
project supports can be produced and tested from any machine. To support several platforms, map a solution file
to each platform with `requirements_txts`. One target then compiles every solution, and the solutions always use
the same version of each package: a package keeps the version the first platform resolves it to and a version
that another platform cannot use, e.g. because no wheel is published for it, is dropped for all of them. When no
version of a package works on every platform the compilation fails and names the platforms that disagree, so
the package can be constrained in the requirements. A `py_reqs_solution_test` of the target checks every
solution, including that they agree.

```python
load("@rules_req_compile//:defs.bzl", "py_reqs_compiler", "py_reqs_solution_test")

py_reqs_compiler(
    name = "requirements.update",
    requirements_in = ":requirements",
    requirements_txts = {
        "requirements.linux.txt": "manylinux_2_28_x86_64",
        "requirements.macos.txt": "macosx_11_0_arm64",
        "requirements.windows.txt": "win_amd64",
    },
)

py_reqs_solution_test(
    name = "requirements_test",
    compiler = ":requirements.update",
)
```

The versions pinned by any of the solutions are recycled for all of them, so a platform added to
`requirements_txts` starts from the versions the others use. Solutions for different Python versions frequently
cannot share versions, so define one `py_reqs_compiler` per Python version.

Wheels are selected and environment markers are evaluated as they would be when installing on the target.
Source distributions (sdists) have their metadata extracted on the machine running the compiler, so solutions
for other platforms should avoid them, which is the default (`allow_sdists = False`).
*
nameA unique name for this target. _
allow_sdistsFWhether or not the solution file is allowed to contain sdist packages.2False�
custom_compile_command�The command to display in the header of the generated lock file (`requirements_txt`). Any references to `{label}` will be replaced with the label of this target.2"bazel run "{label}""�
platform�The platform to compile the solution for as a wheel platform tag, as accepted by `pip --platform`, e.g. `manylinux_2_28_x86_64`, `manylinux2014_aarch64`, `macosx_11_0_arm64` or `win_amd64`. A manylinux tag accepts wheels for that glibc or older, a macosx tag wheels for that release or older. When unset, the solution is compiled for the platform running the compiler. Only applies to `requirements_txt`, `requirements_txts` names the platform of each solution.2""�
python_version�The Python version to compile the solution for, e.g. `3.11.4`. When unset, the exact version of the resolved Python toolchain is used, which keeps the solution independent of the machine running the compiler. A version without a patch number, e.g. `3.9`, is compiled as `3.9.0`.2""2
requirements_inThe input requirements file [
requirements_txt?The solution file. Mutually exclusive with `requirements_txts`.2None�
requirements_txts�Solution files mapped to the wheel platform tag each is compiled for, see `platform`. The solutions are compiled together and use the same version of every package. Mutually exclusive with `requirements_txt` and `platform`.	2{}"I
py_reqs_compiler5@@rules_req_compile//req_compile/private:compiler.bzl
��,
*
nameA unique name for this target. a
_
allow_sdistsFWhether or not the solution file is allowed to contain sdist packages.2False�
�
custom_compile_command�The command to display in the header of the generated lock file (`requirements_txt`). Any references to `{label}` will be replaced with the label of this target.2"bazel run "{label}""�
�
platform�The platform to compile the solution for as a wheel platform tag, as accepted by `pip --platform`, e.g. `manylinux_2_28_x86_64`, `manylinux2014_aarch64`, `macosx_11_0_arm64` or `win_amd64`. A manylinux tag accepts wheels for that glibc or older, a macosx tag wheels for that release or older. When unset, the solution is compiled for the platform running the compiler. Only applies to `requirements_txt`, `requirements_txts` names the platform of each solution.2""�
�
python_version�The Python version to compile the solution for, e.g. `3.11.4`. When unset, the exact version of the resolved Python toolchain is used, which keeps the solution independent of the machine running the compiler. A version without a patch number, e.g. `3.9`, is compiled as `3.9.0`.2""4
2
requirements_inThe input requirements file ]
[
requirements_txt?The solution file. Mutually exclusive with `requirements_txts`.2None�
�
requirements_txts�Solution files mapped to the wheel platform tag each is compiled for, see `platform`. The solutions are compiled together and use the same version of every package. Mutually exclusive with `requirements_txt` and `platform`.	2{}�py_reqs_solution_test�A Bazel test rule for ensuring the solution file for a `py_reqs_compiler` target satisifes the given requirements (`requirements_in`).

```python
load("@rules_req_compile//:defs.bzl", "py_reqs_compiler", "py_reqs_solution_test")

py_reqs_compiler(
    name = "requirements.update",
    requirements_in = "requirements.in",
    requirements_txt = "requirements.txt",
)

py_reqs_solution_test(
    name = "requirements_test",
    requirements_in = "requirements.in",
    requirements_txt = "requirements.txt",
)
```

Alternatively, a test can be defined in isolation using just the requirements files:

```python
load("@rules_req_compile//:defs.bzl", "py_reqs_solution_test")

py_reqs_solution_test(
    name = "requirements_test",
    custom_compile_command = "python3 -m req_compile --multiline --hashes --urls --solution requirements.txt requirements.in",
    requirements_in = "requirements.in",
    requirements_txt = "requirements.txt",
)
```
"�
�
py_reqs_solution_test�A Bazel test rule for ensuring the solution file for a `py_reqs_compiler` target satisifes the given requirements (`requirements_in`).

```python
load("@rules_req_compile//:defs.bzl", "py_reqs_compiler", "py_reqs_solution_test")

py_reqs_compiler(
    name = "requirements.update",
    requirements_in = "requirements.in",
    requirements_txt = "requirements.txt",
)

py_reqs_solution_test(
    name = "requirements_test",
    requirements_in = "requirements.in",
    requirements_txt = "requirements.txt",
)
```

Alternatively, a test can be defined in isolation using just the requirements files:

```python
load("@rules_req_compile//:defs.bzl", "py_reqs_solution_test")

py_reqs_solution_test(
    name = "requirements_test",
    custom_compile_command = "python3 -m req_compile --multiline --hashes --urls --solution requirements.txt requirements.in",
    requirements_in = "requirements.in",
    requirements_txt = "requirements.txt",
)
```
*
nameA unique name for this target. �
compiler�The `py_reqs_compiler` target to test. This attribute is mutally exclusive with `requirements_in` and `requirements_txt` and does not do any string formatting like `py_reqs_compiler` does.*
PyReqsCompilerInfo2None�
custom_compile_command�The command to display in the header of the generated lock file (`requirements_txt`). This attribute is required with `requirements_in` and `requirements_txt`.2""m
requirements_inRThe input requirements file. This attribute is mutually exclusive with `compiler`.2Noned
requirements_txtHThe solution file. This attribute is mutually exclusive with `compiler`.2None"N
py_reqs_solution_test5@@rules_req_compile//req_compile/private:compiler.bzl
��,
*
nameA unique name for this target. �
�
compiler�The `py_reqs_compiler` target to test. This attribute is mutally exclusive with `requirements_in` and `requirements_txt` and does not do any string formatting like `py_reqs_compiler` does.*
PyReqsCompilerInfo2None�
�
custom_compile_command�The command to display in the header of the generated lock file (`requirements_txt`). This attribute is required with `requirements_in` and `requirements_txt`.2""o
m
requirements_inRThe input requirements file. This attribute is mutually exclusive with `compiler`.2Nonef
d
requirements_txtHThe solution file. This attribute is mutually exclusive with `compiler`.2None�PyReqsCompilerInfo0Information about a python requirements provider2�
�
PyReqsCompilerInfo0Information about a python requirements provider<
args4List[str]: A list of arguments core to the compiler.Y
requirements_inFTarget: The `requirements_in` target which provides requirement files.|
	solutionsoList[Target]: The solution files which represent the compiled results from `requirements_in`, one per platform."K
PyReqsCompilerInfo5@@rules_req_compile//req_compile/private:compiler.bzl
>
<
args4List[str]: A list of arguments core to the compiler.[
Y
requirements_inFTarget: The `requirements_in` target which provides requirement files.~
|
	solutionsoList[Target]: The solution files which represent the compiled results from `requirements_in`, one per platform.&Rules for compiling requirements files�
6
rules_req_compilereq_compile/privatelockfile.bzl�annotate_packages.Attach package annotations to parsed packages.*�
�
annotate_packagesN
packages>Packages keyed by sanitized name, as `parse_lockfile` returns. (9
annotations&Annotation data keyed by package name. (.Attach package annotations to parsed packages."�
�dict: A copy of `packages` with the `annotations` of each annotated package
set. `packages` is left alone: it may be the recorded solution that
the lockfile keeps, which must not carry this evaluation's annotations.2J
annotate_packages5@@rules_req_compile//req_compile/private:lockfile.bzl
���parse_constraint?Parse a section of a requirements lock file from `req-compile`.*�
�
parse_constraintH
data<The stripped lines of a constraint's section in a lock file. (�
lockfilevThe label of the current lockfile. Used to resolve paths to
constraints represented by relative paths instead of urls. (q

wheel_dirs_A list of strings that represent directories containing
wheels, relative to the workspace root. (?Parse a section of a requirements lock file from `req-compile`."'
%dict: Parsed data for the constraint.2I
parse_constraint5@@rules_req_compile//req_compile/private:lockfile.bzl
�parse_lock_header�Parse the header `req-compile` writes to lock files compiled by Bazel.

The header records the platform and Python version the solution was
compiled for, e.g.

```
## Python: 3.11
## Platform: linux_x86_64
```
*�
�
parse_lock_header,
contentThe content of the lock file. (�Parse the header `req-compile` writes to lock files compiled by Bazel.

The header records the platform and Python version the solution was
compiled for, e.g.

```
## Python: 3.11
## Platform: linux_x86_64
```
"L
Jstruct: With `platform` and `python` members, either of which may be None.2J
parse_lock_header5@@rules_req_compile//req_compile/private:lockfile.bzl
���parse_lockfile9Parse a requirements lock file into a map of constraints.*�
�
parse_lockfile>
content/The string content of a requirements lock file. (I
annotations6Annotation data for packages in the current lock file. (?
lockfile/The label of the lockfile containing `content`. (]

constraintGAn optional Label which represents the constraint value of the package.None(9Parse a requirements lock file into a map of constraints."Q
Odict: A mapping of package names to it's parsed data from the constraints file.2G
parse_lockfile5@@rules_req_compile//req_compile/private:lockfile.bzl
XX�
//req_compile/private:utils.bzlr�
3
rules_req_compilereq_compile/private	utils.bzl<
sanitize_package_namesanitize_package_name
<Q
S0Parsing of lock files produced by `req-compile`.�	
>
rules_req_compilereq_compile/privatepackage_metadata.bzl�license*�
�
license

name (

kind (
textNone(

visibilityNone(29
license.@@package_metadata//licenses/rules:license.bzl
aa"_license2_license�license_kind*�
�
license_kind

name (

identifier (
	full_name (

visibilityNone(2C
license_kind3@@package_metadata//licenses/rules:license_kind.bzl
,,"_license_kind2_license_kind�package_metadata*�
�
package_metadata

name (

purl (

attributes[](

visibilityNone(2B
package_metadata.@@package_metadata//rules:package_metadata.bzl
@@"_package_metadata2_package_metadata�
//licenses/rules:license.bzlrb
/
package_metadatalicenses/ruleslicense.bzl!
license_license
7?
L�
!//licenses/rules:license_kind.bzlrq
4
package_metadatalicenses/ruleslicense_kind.bzl+
license_kind_license_kind
<I
[�
//rules:package_metadata.bzlrt
/
package_metadatarulespackage_metadata.bzl3
package_metadata_package_metadata
7H
^<The rules of `@package_metadata` for generated repositories.�
2
rules_req_compilereq_compile/privatepins.bzl�render_pins)The text of the pinned requirements file.*�
�
render_pins
hubThe name of the hub. (I
locks<Platform to packages, in the shape `parse_lockfile` returns. (A

index_urls/The hub's indexes, the first being `index_url`. (F
roots9How to name the requirement files the solution came from. (A
command2The command regenerating the file, for the header. ()The text of the pinned requirements file."
str: The file.2@
render_pins1@@rules_req_compile//req_compile/private:pins.bzl
�Render the pinned requirements file of a hub resolved in the extension.

The file is the pin list a human reviews and a bot such as Dependabot edits:
one entry per package with its version, the sha256 of every artifact chosen for
the hub's platforms, and the packages that require it. Fed back to the hub as
`requirements_txt`, it pins exactly those versions and hashes.
�}
7
rules_req_compilereq_compile/privatereqs_repo.bzl�create_hub_repos?Instantiate the repositories of a plan produced by `plan_hubs`.*�
�
create_hub_repos
planSee `plan_hubs`. (?Instantiate the repositories of a plan produced by `plan_hubs`.2J
create_hub_repos6@@rules_req_compile//req_compile/private:reqs_repo.bzl
���hub_spec&Describe a hub repository to generate.*�
�
hub_spec+
nameThe name of the hub repository. ()
locksThe `lock_spec`s of the hub. (@
module.The name of the Bazel module defining the hub.None(J
interpreter3The interpreter used to build source distributions.None(A
package_aliases(`py_library` targets replacing packages.{}(U
legacy_root_pkg_aliases1Whether to alias packages at the root of the hub.False(E
alias_of1The name of another hub this hub should defer to.None(�
pinszThe pinned requirements file the hub keeps in step with its
solution, for a hub resolved in the extension; None otherwise.None(L
pins_index_urls3The hub's indexes, written at the top of that file.[](N

pins_roots:The names of the requirement files the solution came from.[](&Describe a hub repository to generate." 
struct: The hub specification.2B
hub_spec6@@rules_req_compile//req_compile/private:reqs_repo.bzl
��2struct�is_sdistHWhether the distribution of a wheel repository is a source distribution.*�
�
is_sdist
attrs (HWhether the distribution of a wheel repository is a source distribution.2B
is_sdist6@@rules_req_compile//req_compile/private:reqs_repo.bzl
���		lock_specWDescribe a lock belonging to a hub: a lock file, or packages resolved in the extension.*�	
�
	lock_specB
file2The lock file. Mutually exclusive with `packages`.None(�
id�A name for the lock, unique within its hub. Defaults to the
platform recorded in the header of the lock file, or failing that to
the file name.None(b
constraint_valuesG`constraint_value`s that must be satisfied
for the lock to be selected.[](N
flag_values9Flag values that must be set for the lock
to be selected.{}(�
config_settingoAn existing `config_setting` selecting the lock.
Mutually exclusive with `constraint_values` and `flag_values`.None(I
default5Whether this lock is used when no other lock matches.False(�
platform�The wheel platform tag the lock was resolved for, when the
packages were resolved in the extension. Plays the part of the platform
recorded in the header of a lock file.None(~
packagesjPackages resolved in the extension, in the shape
`parse_lockfile` returns. Mutually exclusive with `file`.None(WDescribe a lock belonging to a hub: a lock file, or packages resolved in the extension."!
struct: The lock specification.2C
	lock_spec6@@rules_req_compile//req_compile/private:reqs_repo.bzl
]]�merge_wheel�Merge the attributes two hubs resolved for the same wheel repository.

Hubs share a repository when they pin the same distribution, identified by its
hash. They may have found it at different locations, e.g. a private mirror and
PyPI, in which case every location is kept as a download candidate.
*�
�
merge_wheel'
nameThe name of the repository. (1
existing!The attributes registered so far. (1
attrs$The attributes another hub resolved. (>
hub_name.The hub providing `attrs`, for error messages. (�Merge the attributes two hubs resolved for the same wheel repository.

Hubs share a repository when they pin the same distribution, identified by its
hash. They may have found it at different locations, e.g. a private mirror and
PyPI, in which case every location is kept as a download candidate.
"
dict: The merged attributes.2E
merge_wheel6@@rules_req_compile//req_compile/private:reqs_repo.bzl
���parse_lock_header�Parse the header `req-compile` writes to lock files compiled by Bazel.

The header records the platform and Python version the solution was
compiled for, e.g.

```
## Python: 3.11
## Platform: linux_x86_64
```
*�
�
parse_lock_header,
contentThe content of the lock file. (�Parse the header `req-compile` writes to lock files compiled by Bazel.

The header records the platform and Python version the solution was
compiled for, e.g.

```
## Python: 3.11
## Platform: linux_x86_64
```
"L
Jstruct: With `platform` and `python` members, either of which may be None.2J
parse_lock_header5@@rules_req_compile//req_compile/private:lockfile.bzl
���parse_lockfile9Parse a requirements lock file into a map of constraints.*�
�
parse_lockfile>
content/The string content of a requirements lock file. (I
annotations6Annotation data for packages in the current lock file. (?
lockfile/The label of the lockfile containing `content`. (]

constraintGAn optional Label which represents the constraint value of the package.None(9Parse a requirements lock file into a map of constraints."Q
Odict: A mapping of package names to it's parsed data from the constraints file.2G
parse_lockfile5@@rules_req_compile//req_compile/private:lockfile.bzl
XX�	plan_hubs�Plan the repositories needed for a set of hubs.

Every distinct wheel is downloaded into a single `whl_repository` which is
shared by every hub that pins it and annotates it the same way.
*�
�
	plan_hubs(
ctxA context able to read files. (*
hubs`hub_spec`s keyed by hub name. (d
annotationsQSerialized `py_package_annotation`s keyed by package
name, applying to every hub. (�
hub_annotations�Annotations applying to particular hubs,
keyed by hub name. They replace the annotation of the package in `annotations`
for that hub.{}(�Plan the repositories needed for a set of hubs.

Every distinct wheel is downloaded into a single `whl_repository` which is
shared by every hub that pins it and annotates it the same way.
"�
�struct: With `wheel_repos`, a mapping of repository name to `whl_repository`
attributes, and `hubs`, a mapping of hub name to the data needed to
generate the hub.2C
	plan_hubs6@@rules_req_compile//req_compile/private:reqs_repo.bzl
���platform_constraint_values�The Bazel constraints matching a wheel platform tag.

`req-compile` records the platform a lock was compiled for in the header of
the lock file as the wheel platform tag that was requested, e.g.
`manylinux_2_28_x86_64`, `macosx_11_0_arm64` or `win_amd64`.
*�
�
platform_constraint_values"
tagThe wheel platform tag. (�The Bazel constraints matching a wheel platform tag.

`req-compile` records the platform a lock was compiled for in the header of
the lock file as the wheel platform tag that was requested, e.g.
`manylinux_2_28_x86_64`, `macosx_11_0_arm64` or `win_amd64`.
"Q
Olist[str]: The `constraint_value` labels, or None if the tag is not understood.2T
platform_constraint_values6@@rules_req_compile//req_compile/private:reqs_repo.bzl
--�?py_requirements_repository�The hub repository of a set of Python requirements.

This repository is created by the `requirements` module extension, which also creates
a [whl_repository](#whl_repository) for every distinct wheel pinned by any hub. Hubs
sharing a pinned wheel share its repository.

The hub provides a package per Python project it contains, with the `py_library` of the
project as its default target and the wheel file as `:whl`, as well as a generated
`defs.bzl` file.

```python
load("@py_requirements//:defs.bzl", "requirement")

py_library(
    name = "bar",
    ...
    deps = [
        "//my/other:dep",
        requirement("requests"),
        requirement("numpy"),
    ],
)
```

`requirement("requests")` is the same target as `@py_requirements//requests`.

When a hub has more than one lock, each package selects the wheel of the lock matching the
configuration. A package missing from some of the locks is incompatible with the platforms
of those locks, so targets depending on it are skipped there instead of failing to analyze.

In addition to the `requirement` macro, which is used to access the generated `py_library`
target generated from a package's wheel, the generated `defs.bzl` file contains
functionality for exposing [entry points][whl_ep] as `py_binary` targets as well.

[whl_ep]: https://packaging.python.org/specifications/entry-points/

```python
load("@py_requirements//:defs.bzl", "entry_point")

alias(
    name = "pip-compile",
    actual = entry_point(
        pkg = "pip-tools",
        script = "pip-compile",
    ),
)
```

Note that for packages whose name and script are the same, only the name of the package
is needed when calling the `entry_point` macro.

```python
load("@py_requirements//:defs.bzl", "entry_point")

alias(
    name = "flake8",
    actual = entry_point("flake8"),
)
```

A very important detail for generating python dependencies is sdist (source distribution)
dependencies are assumed to be incapable of yielding deterministic outputs. Therefore, any
case where a sdist (source distribution) is found in a lock file, the dependencies should
not be considered byte-for-byte reproducible. It is highly recommended solution files contain
all wheels so the generated repositories are byte-for-byte consistent. Failure to use binary-only
dependencies will result in unexpected cache invalidation as well as inconsistent or broken
cross-platform behavior.
R�,
�
py_requirements_repository�The hub repository of a set of Python requirements.

This repository is created by the `requirements` module extension, which also creates
a [whl_repository](#whl_repository) for every distinct wheel pinned by any hub. Hubs
sharing a pinned wheel share its repository.

The hub provides a package per Python project it contains, with the `py_library` of the
project as its default target and the wheel file as `:whl`, as well as a generated
`defs.bzl` file.

```python
load("@py_requirements//:defs.bzl", "requirement")

py_library(
    name = "bar",
    ...
    deps = [
        "//my/other:dep",
        requirement("requests"),
        requirement("numpy"),
    ],
)
```

`requirement("requests")` is the same target as `@py_requirements//requests`.

When a hub has more than one lock, each package selects the wheel of the lock matching the
configuration. A package missing from some of the locks is incompatible with the platforms
of those locks, so targets depending on it are skipped there instead of failing to analyze.

In addition to the `requirement` macro, which is used to access the generated `py_library`
target generated from a package's wheel, the generated `defs.bzl` file contains
functionality for exposing [entry points][whl_ep] as `py_binary` targets as well.

[whl_ep]: https://packaging.python.org/specifications/entry-points/

```python
load("@py_requirements//:defs.bzl", "entry_point")

alias(
    name = "pip-compile",
    actual = entry_point(
        pkg = "pip-tools",
        script = "pip-compile",
    ),
)
```

Note that for packages whose name and script are the same, only the name of the package
is needed when calling the `entry_point` macro.

```python
load("@py_requirements//:defs.bzl", "entry_point")

alias(
    name = "flake8",
    actual = entry_point("flake8"),
)
```

A very important detail for generating python dependencies is sdist (source distribution)
dependencies are assumed to be incapable of yielding deterministic outputs. Therefore, any
case where a sdist (source distribution) is found in a lock file, the dependencies should
not be considered byte-for-byte reproducible. It is highly recommended solution files contain
all wheels so the generated repositories are byte-for-byte consistent. Failure to use binary-only
dependencies will result in unexpected cache invalidation as well as inconsistent or broken
cross-platform behavior.
.
name"A unique name for this repository. }
alias_ofkThe name of a hub every package of this hub is an alias of. Used to override the hubs of dependent modules.2""`
default_lockJThe id of the lock used when no lock of the hub matches the configuration.2""N
hub_name<Name of the hub repository to generate. Do not use directly.2""�
legacy_root_pkg_aliases�If True, creates aliases in the root BUILD.bazel file pointing to the package targets in their subpackages. This provides backward compatibility for code that references packages at the root (e.g., `@repo//:package_name`).2FalseR
locksEA json encoded list of the locks of the hub and how each is selected. H
package_aliases/Packages to override with a local `py_library`.	2{}r
packagesbA json encoded mapping of package names to the version and `whl_repository` resolved by each lock. d

pins_labelPThe label of the hub's pinned requirements file in the workspace, if it has one.2""<
	pins_path)The workspace-relative path of that file.2""Z
	pins_textGThe pinned requirements the hub resolved, as `render_pins` writes them.2""�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 *T
py_requirements_repository6@@rules_req_compile//req_compile/private:reqs_repo.bzl
�-�-0
.
name"A unique name for this repository. 
}
alias_ofkThe name of a hub every package of this hub is an alias of. Used to override the hubs of dependent modules.2""b
`
default_lockJThe id of the lock used when no lock of the hub matches the configuration.2""P
N
hub_name<Name of the hub repository to generate. Do not use directly.2""�
�
legacy_root_pkg_aliases�If True, creates aliases in the root BUILD.bazel file pointing to the package targets in their subpackages. This provides backward compatibility for code that references packages at the root (e.g., `@repo//:package_name`).2FalseT
R
locksEA json encoded list of the locks of the hub and how each is selected. J
H
package_aliases/Packages to override with a local `py_library`.	2{}t
r
packagesbA json encoded mapping of package names to the version and `whl_repository` resolved by each lock. f
d

pins_labelPThe label of the hub's pinned requirements file in the workspace, if it has one.2"">
<
	pins_path)The workspace-relative path of that file.2""\
Z
	pins_textGThe pinned requirements the hub resolved, as `render_pins` writes them.2""�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
"//req_compile/private:lockfile.bzlr�
6
rules_req_compilereq_compile/privatelockfile.bzl4
annotate_packagesannotate_packages
5
parse_lock_header_parse_lock_header
/
parse_lockfile_parse_lockfile

�
//req_compile/private:pins.bzlrl
2
rules_req_compilereq_compile/privatepins.bzl(
render_pinsrender_pins
	;	F
		H�
//req_compile/private:utils.bzlr�
3
rules_req_compilereq_compile/private	utils.bzl<
sanitize_package_namesanitize_package_name

<
Q,
whl_repo_namewhl_repo_name

U
b


d�
"//req_compile/private:whl_repo.bzlrv
6
rules_req_compilereq_compile/privatewhl_repo.bzl.
whl_repositorywhl_repository
?M
OBRepository rules for loading platform specific python requirements�&
5
rules_req_compilereq_compile/privateresolve.bzl�require_wasmMFail with instructions when the hubs need the solver but Bazel cannot run it.*�
�
require_wasm	
ctx (
	hub_names (MFail with instructions when the hubs need the solver but Bazel cannot run it.2D
require_wasm4@@rules_req_compile//req_compile/private:resolve.bzl
//�resolve_hubs�Resolve hubs defined by requirement files.

Hubs whose inputs equal those of the solution recorded in the lockfile's facts
are rebuilt from it without running the solver. The others are solved, with
their recorded solution as the starting point.
*�
�
resolve_hubs!
ctxThe extension context. (/
specs"`resolve_spec`s keyed by hub name. (�Resolve hubs defined by requirement files.

Hubs whose inputs equal those of the solution recorded in the lockfile's facts
are rebuilt from it without running the solver. The others are solved, with
their recorded solution as the starting point.
"�
�struct: With `locks`, hub name to a list of `(platform, packages)` pairs
where `packages` has the shape `parse_lockfile` returns, and `facts`,
what to record for the next evaluation.2D
resolve_hubs4@@rules_req_compile//req_compile/private:resolve.bzl
���
resolve_spec1Describe a hub to resolve from requirement files.*�

�

resolve_spec 
nameThe name of the hub. (-
requirements_inThe requirement files. (Q
python_version;The Python version to resolve for, e.g. `3.11` or `3.11.4`. (F
	platforms5Wheel platform tags to resolve for, one lock per tag. (R
solver@The WebAssembly solver module; None for the one of this release.None(B
constraints-Constraint files, never themselves installed.[](�
pins�The hub's pinned requirements file, which pins the version and
hashes of the packages it lists and which the hub keeps in step with its
solution (`requirements.update`); None when the hub has none.None(P

index_urls#Package indexes, searched in order.["https://pypi.org/simple"](W
allow_sdists>Whether source distributions with static metadata may be used.False(B
allow_prerelease%Whether pre-releases may be selected.False(X
enforce_hashes>Whether `--hash` values in the files must match the artifacts.True(A

max_rounds-The most rounds of requests before giving up.40(J
memory_limit,The memory limit of a solver call, in bytes.
1073741824(<
timeout)The timeout of a solver call, in seconds.3600(1Describe a hub to resolve from requirement files."$
"struct: The resolve specification.2D
resolve_spec4@@rules_req_compile//req_compile/private:resolve.bzl
442struct�wasm_available5Whether Bazel exposes `execute_wasm` on this context.*�
�
wasm_available	
ctx (5Whether Bazel exposes `execute_wasm` on this context.2F
wasm_available4@@rules_req_compile//req_compile/private:resolve.bzl
++�
!//tools/build_defs/repo:utils.bzlr�
/
bazel_toolstools/build_defs/repo	utils.bzl0
read_user_netrcread_user_netrc
8G$
	use_netrc	use_netrc
KT
V�
 //req_compile/private:solver.bzlr�
4
rules_req_compilereq_compile/private
solver.bzl,
SOLVER_SHA256SOLVER_SHA256
=J&

SOLVER_URL
SOLVER_URL
NX
Z�
//req_compile/private:utils.bzlr�
3
rules_req_compilereq_compile/private	utils.bzl<
sanitize_package_namesanitize_package_name
<Q
S	FACTS_SCHEMAj"	
INPUT_ROOT/inputsj	/inputs;	UPGRADE_ENVREQ_COMPILE_UPGRADEjREQ_COMPILE_UPGRADE�
Resolve requirements inside the module extension with the WebAssembly solver.

The solver is the unmodified `req_compile` package running on CPython inside a
WebAssembly module (see `wasm/README.md`). Bazel runs it with `execute_wasm`,
which cannot perform any I/O, so resolution happens in rounds: the solver is
called with every fact gathered so far, answers either with a solution or with
the files and downloads it is missing, this code performs them, and calls again.
Requirement files are read with `ctx.read`, which records them as inputs of the
extension, so the lock entry Bazel writes is invalidated when they change.

Across evaluations the extension remembers, through Bazel's lockfile `facts`, the
solution of each hub together with the inputs it was solved from, and the metadata
of every distribution it chose. A hub whose inputs did not change is rebuilt
from its recorded solution without loading the solver. A hub whose inputs changed
is re-solved with the recorded versions as soft pins and the recorded metadata on
hand, so only what the change touches is fetched. `REQ_COMPILE_UPGRADE=<package>[,<package>]`
(or `all`) on any command that evaluates the hub drops the pins for that resolution.

Nothing here runs unless a hub asks for it, and then only when Bazel's
WebAssembly support is enabled; see `require_wasm`.
�
3
rules_req_compilereq_compile/private	sdist.bzl�
sdist_depsFLoad all cross-platform wheels required to build source distributions.J�
�

sdist_depsFLoad all cross-platform wheels required to build source distributions."@

sdist_deps2@@rules_req_compile//req_compile/private:sdist.bzl
%%�
"//req_compile/private:lockfile.bzlrv
6
rules_req_compilereq_compile/privatelockfile.bzl.
parse_lockfileparse_lockfile
?M
O�
"//req_compile/private:whl_repo.bzlrv
6
rules_req_compilereq_compile/privatewhl_repo.bzl.
whl_repositorywhl_repository
?M
OP	SDIST_COMPILER_HUBreq_compile_sdist_compilerjreq_compile_sdist_compiler6Requirements for extracting and building source dists.�
4
rules_req_compilereq_compile/private
solver.bzld
:version.bzlrR
 
rules_req_compileversion.bzl 
VERSIONVERSION
+2
4�	SOLVER_SHA256@93fbb5f100f0833df4183560671d36a6623a48a15fd030b8fd04b35d4c8d9323jB@93fbb5f100f0833df4183560671d36a6623a48a15fd030b8fd04b35d4c8d9323�	
SOLVER_URLXhttps://github.com/periareon/req-compile/releases/download/1.7.1/req_compile_solver.wasmjZXhttps://github.com/periareon/req-compile/releases/download/1.7.1/req_compile_solver.wasm�The solver module that belongs to this release of `rules_req_compile`.

`.github/workflows/release_prep.sh` builds `req_compile_solver.wasm` for each
release with Bazel (`//wasm:req_compile_solver`, rules_venv's `py_wasm_module`),
attaches it to the GitHub release and fills in `SOLVER_SHA256` below in the copy
of this file that goes into the module archive. The `requirements` extension
downloads the module from here the first time a hub resolves, through Bazel's
repository cache. A source checkout carries no hash and says so; `bazel build
//wasm:req_compile_solver` builds a module to name with the `solver` attribute.
�
3
rules_req_compilereq_compile/private	utils.bzl�execute&Run a subprocess and error if it fails*�
�
execute/
repository_ctxThe rule's context object (+
argsThe argv of the command to run. ()
kwargsAdditional keyword arguments.(&Run a subprocess and error if it fails"2
0struct: The results of `repository_ctx.execute`.2=
execute2@@rules_req_compile//req_compile/private:utils.bzl
TT�parse_artifact_name(Parse the artifact name from a pypi url.*�
�
parse_artifact_name
urlsA list of urls ((Parse the artifact name from a pypi url."E
COptional[str]: The name if it was correctly parsed, otherwise None.2I
parse_artifact_name2@@rules_req_compile//req_compile/private:utils.bzl
kk�sanitize_package_nameFSanitize a python package name to a consistent and safe name for Bazel*�
�
sanitize_package_name(
nameThe name of a python package (FSanitize a python package name to a consistent and safe name for Bazel""
 str: A sanitized python package.2K
sanitize_package_name2@@rules_req_compile//req_compile/private:utils.bzl
�sanitize_versionJSanitize a python package version into a string safe for repository names.*�
�
sanitize_version!
versionA package version. (JSanitize a python package version into a string safe for repository names."
str: The sanitized version.2F
sanitize_version2@@rules_req_compile//req_compile/private:utils.bzl
�
short_hash7Produce a short, stable hexadecimal digest of a string.*�
�

short_hash
textThe text to hash. (7Produce a short, stable hexadecimal digest of a string."$
"str: Eight hexadecimal characters.2@

short_hash2@@rules_req_compile//req_compile/private:utils.bzl
�whl_repo_name�Compute the name of the `whl_repository` holding a particular wheel.

Wheels are shared between every hub that uses them, so the name only
depends on the wheel itself and on anything that changes its contents.
*�
�
whl_repo_name'
packageThe python package name. (#
versionThe package version. (w
identitygSomething identifying the exact distribution, preferably
its sha256 digest, otherwise its URL or label. (�
annotations�Serialized annotations applied to the wheel, if any.
Annotations change the contents of the repository, so annotated
wheels get a distinct repository.None(�Compute the name of the `whl_repository` holding a particular wheel.

Wheels are shared between every hub that uses them, so the name only
depends on the wheel itself and on anything that changes its contents.
"
str: A Bazel repository name.2C
whl_repo_name2@@rules_req_compile//req_compile/private:utils.bzl
((&Bazel utilities for req-compile rules.�_
6
rules_req_compilereq_compile/privatewhl_repo.bzl�declared_license�The license a wheel declares, from the fields of its `METADATA`.

PEP 639's `License-Expression` is authoritative. Without it, the free-form
`License` field is used when it holds exactly an SPDX identifier, and
failing that a trove classifier naming one license.
*�
�
declared_license-
metadataSee `parse_metadata_license`. (�
spdx�The SPDX identifiers `@package_metadata` has a `license_kind`
for, keyed by their lowercase form, which is how SPDX compares them. (�The license a wheel declares, from the fields of its `METADATA`.

PEP 639's `License-Expression` is authoritative. Without it, the free-form
`License` field is used when it holds exactly an SPDX identifier, and
failing that a trove classifier naming one license.
"�
�struct: With `identifier`, an SPDX identifier or expression, and `kind`,
the label of its `license_kind` when `@package_metadata` has one, else
None. None when the wheel declares nothing usable.2I
declared_license5@@rules_req_compile//req_compile/private:whl_repo.bzl
���hub_depsJThe Python packages a hub resolved for this wheel, as labels into the hub.*�
�
hub_deps
hubThe name of the hub. (�
hub_data�The `locks` of the hub using this wheel, a mapping of lock
id to a dict with the `deps` the lock resolved for this wheel and the
`config_setting` the hub uses to select the lock, which is None when the
hub has a single lock, and the `default_lock` of the hub, if any. (?
annotations,The deserialized annotations of the package. (JThe Python packages a hub resolved for this wheel, as labels into the hub."�
�struct: With `branches`, a mapping of the config setting selecting a lock
to the sorted dependency labels of that lock, keyed by None when the hub
has a single lock; `default`, the labels of the lock the hub falls back
to, or None; and `empty`, whether no lock resolved any dependency.2A
hub_deps5@@rules_req_compile//req_compile/private:whl_repo.bzl
���load_sdist_data*�
�
load_sdist_data
repository_ctx (
	data_file (2H
load_sdist_data5@@rules_req_compile//req_compile/private:whl_repo.bzl
�parse_metadata_license9Read the license fields out of the `METADATA` of a wheel.*�
�
parse_metadata_licenseE
content6The file, RFC 822 headers followed by the description. (9Read the license fields out of the `METADATA` of a wheel."�
�struct: With `expression`, the `License-Expression` of PEP 639; `license`,
the first line of the free-form `License` field; `files`, the
`License-File` entries; and `classifiers`, the `License ::` trove
classifiers. Each is None or empty when the wheel has none.2O
parse_metadata_license5@@rules_req_compile//req_compile/private:whl_repo.bzl
���render_depsERender the `deps` attribute of the library a hub sees for this wheel.*�
�
render_depsY
labelsKDependencies that do not depend on the hub, the labels
an annotation added. (3
deps'The hub's dependencies, see `hub_deps`. (ERender the `deps` attribute of the library a hub sees for this wheel."=
;str: Starlark source, a list or a list added to a `select`.2D
render_deps5@@rules_req_compile//req_compile/private:whl_repo.bzl
���render_package_metadata2Render the metadata targets of a wheel repository.*�
�
render_package_metadataC
distribution/The purl of the distribution, see `wheel_purl`. (F
license7The license of the wheel, see `wheel_license`, or None. (2Render the metadata targets of a wheel repository."p
nstruct: With `loads`, the `load` statement the targets need, and
`content`, the targets, both Starlark source.2P
render_package_metadata5@@rules_req_compile//req_compile/private:whl_repo.bzl
���wheel_license7The license of an extracted wheel, from its `METADATA`.*�
�
wheel_license0
repository_ctxThe rule's context object. (=
dist_info_dir(The `.dist-info` directory of the wheel. (L
package=The name of the package, for a license without an identifier. (7The license of an extracted wheel, from its `METADATA`."�
�struct: With `kind`, the label of a `license_kind` of `@package_metadata`
or None; `identifier` and `full_name`, the kind to declare when it
is None; and `text`, the path of the license file or None. None when
the wheel declares no license at all.2F
wheel_license5@@rules_req_compile//req_compile/private:whl_repo.bzl
���
wheel_purl/The purl of a distribution of a Python package.*�
�

wheel_purlA
package2The name of the package, as a lock file spells it. (*
versionThe version of the package. (L
	file_name7The file name of the distribution, a wheel or an sdist.None(G
url8Where the distribution was downloaded from, if anywhere.None(?
sha256-The hex sha256 of the distribution, if known.None(/The purl of a distribution of a Python package.";
9str: A `pkg:pypi/...` purl naming the exact distribution.2C

wheel_purl5@@rules_req_compile//req_compile/private:whl_repo.bzl
���whl_repo_to_python_path(Convert a label into a PYTHONPATH entry.*�
�
whl_repo_to_python_path0
repository_ctxThe rule's context object. ( 
rootThe label to a file. ((Convert a label into a PYTHONPATH entry."#
!str: A path to add to PYTHONPATH.2P
whl_repo_to_python_path5@@rules_req_compile//req_compile/private:whl_repo.bzl
�/whl_repository�
A repository rule for extracting a python [wheel](https://peps.python.org/pep-0491/) and defining a `py_library`.

This repository is expected to be generated by [py_requirements_repository](#py_requirements_repository).

The repository contains the wheel (`//:whl`), a `py_library` named after the package (`//:requests`) holding its
files but none of its dependencies, and a target per hub using the wheel (`//:pip_deps.requests`) holding its files
with the dependencies that hub resolved for the package, or aliasing the package when the hub resolved none. The
console scripts of the wheel are a `py_binary` per hub (`//:pip_deps.entry_point_<script>`). This allows a single
repository to be shared by every hub that pins the same wheel, even when they resolved its dependencies differently.

Every target of the repository carries the `package_metadata` of the wheel (`//:package_metadata`), from the
`@package_metadata` module: a `pkg:pypi` purl naming the distribution the lock pinned, with its file name, download
URL and sha256 as qualifiers, and the license the wheel declares in its `METADATA` (`//:license`), when it declares
one. The hub's aliases resolve to these targets, so tooling collecting the metadata of a binary's dependencies, such
as an SBOM generator, sees the wheel behind each requirement.
R�$
�
whl_repository�
A repository rule for extracting a python [wheel](https://peps.python.org/pep-0491/) and defining a `py_library`.

This repository is expected to be generated by [py_requirements_repository](#py_requirements_repository).

The repository contains the wheel (`//:whl`), a `py_library` named after the package (`//:requests`) holding its
files but none of its dependencies, and a target per hub using the wheel (`//:pip_deps.requests`) holding its files
with the dependencies that hub resolved for the package, or aliasing the package when the hub resolved none. The
console scripts of the wheel are a `py_binary` per hub (`//:pip_deps.entry_point_<script>`). This allows a single
repository to be shared by every hub that pins the same wheel, even when they resolved its dependencies differently.

Every target of the repository carries the `package_metadata` of the wheel (`//:package_metadata`), from the
`@package_metadata` module: a `pkg:pypi` purl naming the distribution the lock pinned, with its file name, download
URL and sha256 as qualifiers, and the license the wheel declares in its `METADATA` (`//:license`), when it declares
one. The hub's aliases resolve to these targets, so tooling collecting the metadata of a binary's dependencies, such
as an SBOM generator, sees the wheel behind each requirement.
.
name"A unique name for this repository. j
annotationsSSee [py_requirements_repository.annotation](#py_requirements_repository.annotation)2"{}"�
hubs�A json encoded mapping of hub names to the hub's use of this wheel: its `locks`, a mapping of lock id to the `deps` (python package names) resolved for the package and the `config_setting` label the hub uses to select the lock, which is `null` for hubs with a single lock, and the `default_lock` the hub falls back to, if any.2"{}"U
interpreter>Optional Python interpreter binary to use for building sdists.2NoneC
package4The name of the python package the wheel represents. 9
patches(Patches to apply to the installed wheel.2[]�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
sdist_deps_reposMINTERNAL: DO NOT USE. Default dependencies for building source distributions.2�[Label("@@req_compile_sdist_compiler__pip//:pip"), Label("@@req_compile_sdist_compiler__setuptools//:setuptools"), Label("@@req_compile_sdist_compiler__wheel//:wheel")]<
sha256,The expected SHA-256 of the file downloaded.2""1
urls#A list of URLs to the python wheel.2[]1
version"The version of the python package. $
whlThe label to a wheel.2None*G
whl_repository5@@rules_req_compile//req_compile/private:whl_repo.bzl
�!�!0
.
name"A unique name for this repository. l
j
annotationsSSee [py_requirements_repository.annotation](#py_requirements_repository.annotation)2"{}"�
�
hubs�A json encoded mapping of hub names to the hub's use of this wheel: its `locks`, a mapping of lock id to the `deps` (python package names) resolved for the package and the `config_setting` label the hub uses to select the lock, which is `null` for hubs with a single lock, and the `default_lock` the hub falls back to, if any.2"{}"W
U
interpreter>Optional Python interpreter binary to use for building sdists.2NoneE
C
package4The name of the python package the wheel represents. ;
9
patches(Patches to apply to the installed wheel.2[]�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
�
sdist_deps_reposMINTERNAL: DO NOT USE. Default dependencies for building source distributions.2�[Label("@@req_compile_sdist_compiler__pip//:pip"), Label("@@req_compile_sdist_compiler__setuptools//:setuptools"), Label("@@req_compile_sdist_compiler__wheel//:wheel")]>
<
sha256,The expected SHA-256 of the file downloaded.2""3
1
urls#A list of URLs to the python wheel.2[]3
1
version"The version of the python package. &
$
whlThe label to a wheel.2Nonec
//purl:purl.bzlrN
"
package_metadatapurlpurl.bzl
purlpurl
+/
1�
*//req_compile/private:annotation_utils.bzlr�
>
rules_req_compilereq_compile/privateannotation_utils.bzlN
deserialize_package_annotationdeserialize_package_annotation
Ge
g�
//req_compile/private:utils.bzlr�
3
rules_req_compilereq_compile/private	utils.bzl 
executeexecute
<C8
parse_artifact_nameparse_artifact_name
GZ<
sanitize_package_namesanitize_package_name
^s
uBRepository rules for downloading and extracting python wheel files�
>
rules_req_compilerule_tests/unitextension_test_suite.bzl�annotation_ownership_test"�
�
annotation_ownership_test*
nameA unique name for this target. "Z
annotation_ownership_test=@@rules_req_compile//rule_tests/unit:extension_test_suite.bzl
��,
*
nameA unique name for this target. �deps_default_lock_test"�
�
deps_default_lock_test*
nameA unique name for this target. "W
deps_default_lock_test=@@rules_req_compile//rule_tests/unit:extension_test_suite.bzl
��,
*
nameA unique name for this target. �deps_no_default_lock_test"�
�
deps_no_default_lock_test*
nameA unique name for this target. "Z
deps_no_default_lock_test=@@rules_req_compile//rule_tests/unit:extension_test_suite.bzl
��,
*
nameA unique name for this target. �deps_single_lock_test"�
�
deps_single_lock_test*
nameA unique name for this target. "V
deps_single_lock_test=@@rules_req_compile//rule_tests/unit:extension_test_suite.bzl
��,
*
nameA unique name for this target. �merge_interpreters_test"�
�
merge_interpreters_test*
nameA unique name for this target. "X
merge_interpreters_test=@@rules_req_compile//rule_tests/unit:extension_test_suite.bzl
��,
*
nameA unique name for this target. �merge_mirrors_test"�
�
merge_mirrors_test*
nameA unique name for this target. "S
merge_mirrors_test=@@rules_req_compile//rule_tests/unit:extension_test_suite.bzl
��,
*
nameA unique name for this target. �metadata_license_test"�
�
metadata_license_test*
nameA unique name for this target. "V
metadata_license_test=@@rules_req_compile//rule_tests/unit:extension_test_suite.bzl
��,
*
nameA unique name for this target. �render_package_metadata_test"�
�
render_package_metadata_test*
nameA unique name for this target. "]
render_package_metadata_test=@@rules_req_compile//rule_tests/unit:extension_test_suite.bzl
��,
*
nameA unique name for this target. �wheel_purl_test"�
�
wheel_purl_test*
nameA unique name for this target. "P
wheel_purl_test=@@rules_req_compile//rule_tests/unit:extension_test_suite.bzl
��,
*
nameA unique name for this target. �extension_test_suiteDefine the test suite.*�
�
extension_test_suite"
nameThe name of the suite. (Define the test suite.2U
extension_test_suite=@@rules_req_compile//rule_tests/unit:extension_test_suite.bzl
���
//lib:unittest.bzlrw
!
bazel_skyliblibunittest.bzl 
assertsasserts
*1"
unittestunittest
5=
?�
*//req_compile/private:annotation_utils.bzlr�
>
rules_req_compilereq_compile/privateannotation_utils.bzl(
ROOT_MODULEROOT_MODULE
GRN
deserialize_package_annotationdeserialize_package_annotation
Vt5
record_annotationrecord_annotation
x�
��
#//req_compile/private:reqs_repo.bzlr�
7
rules_req_compilereq_compile/privatereqs_repo.bzl"
is_sdistis_sdist

@
H(
merge_wheelmerge_wheel

L
W


Y�
"//req_compile/private:whl_repo.bzlr�
6
rules_req_compilereq_compile/privatewhl_repo.bzl2
declared_licensedeclared_license
"
hub_depshub_deps
>
parse_metadata_licenseparse_metadata_license
(
render_depsrender_deps
@
render_package_metadatarender_package_metadata
&

wheel_purl
wheel_purl

JStarlark unit tests for the planning done by the `requirements` extension.�
C
rules_req_compilerule_tests/unitparse_lockfile_test_suite.bzl�parse_lockfile_test"�
�
parse_lockfile_test*
nameA unique name for this target. ;
content,The text content of a requirements lock file <
expected,A json encoded string of parsed requirements o
mock_lockfile8A fake label to a madeup location for the solution file.2""@req_compile_fake//:solution.txt""Y
parse_lockfile_testB@@rules_req_compile//rule_tests/unit:parse_lockfile_test_suite.bzl
��,
*
nameA unique name for this target. =
;
content,The text content of a requirements lock file >
<
expected,A json encoded string of parsed requirements q
o
mock_lockfile8A fake label to a madeup location for the solution file.2""@req_compile_fake//:solution.txt"�parse_lockfile_test_suiteGDefine a test suite for requirements repository lockfile parsing logic.*�
�
parse_lockfile_test_suite'
nameThe name of the test suite. ()
kwargsAdditional keyword arguments.(GDefine a test suite for requirements repository lockfile parsing logic.2_
parse_lockfile_test_suiteB@@rules_req_compile//rule_tests/unit:parse_lockfile_test_suite.bzl
��"_parse_lockfile_test*native.test_suite2native.test_suite�
//lib:unittest.bzlrw
!
bazel_skyliblibunittest.bzl 
assertsasserts
*1"
unittestunittest
5=
?�
"//req_compile/private:lockfile.bzlrv
6
rules_req_compilereq_compile/privatelockfile.bzl.
parse_lockfileparse_lockfile
?M
O)Starlark unit tests for `parse_lockfile`.��

rules_req_compiledefs.bzl�py_package_annotation_consumerBA rule for parsing `annotation_data` targets from a python target."�
�
py_package_annotation_consumerBA rule for parsing `annotation_data` targets from a python target.*
nameA unique name for this target. V
consumeGThe name of the `py_package_annotation` target to parse from `package`. 8
package)The python package to parse targets from. "@
py_package_annotation_consumer@@rules_req_compile//:defs.bzl
�&�&,
*
nameA unique name for this target. X
V
consumeGThe name of the `py_package_annotation` target to parse from `package`. :
8
package)The python package to parse targets from. �py_package_annotation_target\A container for targets defined by `py_package_annotation` data applied to a python package."�
�
py_package_annotation_target\A container for targets defined by `py_package_annotation` data applied to a python package.*
nameA unique name for this target. 6
target(The target to track in a python package. ">
py_package_annotation_target@@rules_req_compile//:defs.bzl
$$,
*
nameA unique name for this target. 8
6
target(The target to track in a python package. �Hpy_reqs_compiler�A Bazel rule for compiling python requirements.


```python
load("@rules_req_compile//:defs.bzl", "py_reqs_compiler", "py_reqs_solution_test")

filegroup(
    name = "requriements",
    srcs = ["requirements.in"],
    data = [
        # Any transitive files included via `-r` should be added here.
    ],
)

py_reqs_compiler(
    name = "requirements.update",
    requirements_in = ":requirements",
    requirements_txt = "requirements.txt",
)

```

Updating requirements can be performed by running the new target.

```bash
bazel run //:requirements.update
```

By default the rule will try to recycle pins already existing in the solution file (`requirements.txt`). To perform
a clean resolution (fetching latest for all requirements) the `--upgrade` flag can be used. A solution compiled for
another platform or Python version, as recorded in its header, is not recycled: changing the `platform` or
`python_version` of the rule resolves the requirements again.

```bash
bazel run //:requirements.update -- --upgrade
```

By default a solution is compiled for the platform and Python version running the compiler. The `platform` and
`python_version` attributes compile a solution for a different environment, so solutions for every platform a
project supports can be produced and tested from any machine. To support several platforms, map a solution file
to each platform with `requirements_txts`. One target then compiles every solution, and the solutions always use
the same version of each package: a package keeps the version the first platform resolves it to and a version
that another platform cannot use, e.g. because no wheel is published for it, is dropped for all of them. When no
version of a package works on every platform the compilation fails and names the platforms that disagree, so
the package can be constrained in the requirements. A `py_reqs_solution_test` of the target checks every
solution, including that they agree.

```python
load("@rules_req_compile//:defs.bzl", "py_reqs_compiler", "py_reqs_solution_test")

py_reqs_compiler(
    name = "requirements.update",
    requirements_in = ":requirements",
    requirements_txts = {
        "requirements.linux.txt": "manylinux_2_28_x86_64",
        "requirements.macos.txt": "macosx_11_0_arm64",
        "requirements.windows.txt": "win_amd64",
    },
)

py_reqs_solution_test(
    name = "requirements_test",
    compiler = ":requirements.update",
)
```

The versions pinned by any of the solutions are recycled for all of them, so a platform added to
`requirements_txts` starts from the versions the others use. Solutions for different Python versions frequently
cannot share versions, so define one `py_reqs_compiler` per Python version.

Wheels are selected and environment markers are evaluated as they would be when installing on the target.
Source distributions (sdists) have their metadata extracted on the machine running the compiler, so solutions
for other platforms should avoid them, which is the default (`allow_sdists = False`).
"�0
�$
py_reqs_compiler�A Bazel rule for compiling python requirements.


```python
load("@rules_req_compile//:defs.bzl", "py_reqs_compiler", "py_reqs_solution_test")

filegroup(
    name = "requriements",
    srcs = ["requirements.in"],
    data = [
        # Any transitive files included via `-r` should be added here.
    ],
)

py_reqs_compiler(
    name = "requirements.update",
    requirements_in = ":requirements",
    requirements_txt = "requirements.txt",
)

```

Updating requirements can be performed by running the new target.

```bash
bazel run //:requirements.update
```

By default the rule will try to recycle pins already existing in the solution file (`requirements.txt`). To perform
a clean resolution (fetching latest for all requirements) the `--upgrade` flag can be used. A solution compiled for
another platform or Python version, as recorded in its header, is not recycled: changing the `platform` or
`python_version` of the rule resolves the requirements again.

```bash
bazel run //:requirements.update -- --upgrade
```

By default a solution is compiled for the platform and Python version running the compiler. The `platform` and
`python_version` attributes compile a solution for a different environment, so solutions for every platform a
project supports can be produced and tested from any machine. To support several platforms, map a solution file
to each platform with `requirements_txts`. One target then compiles every solution, and the solutions always use
the same version of each package: a package keeps the version the first platform resolves it to and a version
that another platform cannot use, e.g. because no wheel is published for it, is dropped for all of them. When no
version of a package works on every platform the compilation fails and names the platforms that disagree, so
the package can be constrained in the requirements. A `py_reqs_solution_test` of the target checks every
solution, including that they agree.

```python
load("@rules_req_compile//:defs.bzl", "py_reqs_compiler", "py_reqs_solution_test")

py_reqs_compiler(
    name = "requirements.update",
    requirements_in = ":requirements",
    requirements_txts = {
        "requirements.linux.txt": "manylinux_2_28_x86_64",
        "requirements.macos.txt": "macosx_11_0_arm64",
        "requirements.windows.txt": "win_amd64",
    },
)

py_reqs_solution_test(
    name = "requirements_test",
    compiler = ":requirements.update",
)
```

The versions pinned by any of the solutions are recycled for all of them, so a platform added to
`requirements_txts` starts from the versions the others use. Solutions for different Python versions frequently
cannot share versions, so define one `py_reqs_compiler` per Python version.

Wheels are selected and environment markers are evaluated as they would be when installing on the target.
Source distributions (sdists) have their metadata extracted on the machine running the compiler, so solutions
for other platforms should avoid them, which is the default (`allow_sdists = False`).
*
nameA unique name for this target. _
allow_sdistsFWhether or not the solution file is allowed to contain sdist packages.2False�
custom_compile_command�The command to display in the header of the generated lock file (`requirements_txt`). Any references to `{label}` will be replaced with the label of this target.2"bazel run "{label}""�
platform�The platform to compile the solution for as a wheel platform tag, as accepted by `pip --platform`, e.g. `manylinux_2_28_x86_64`, `manylinux2014_aarch64`, `macosx_11_0_arm64` or `win_amd64`. A manylinux tag accepts wheels for that glibc or older, a macosx tag wheels for that release or older. When unset, the solution is compiled for the platform running the compiler. Only applies to `requirements_txt`, `requirements_txts` names the platform of each solution.2""�
python_version�The Python version to compile the solution for, e.g. `3.11.4`. When unset, the exact version of the resolved Python toolchain is used, which keeps the solution independent of the machine running the compiler. A version without a patch number, e.g. `3.9`, is compiled as `3.9.0`.2""2
requirements_inThe input requirements file [
requirements_txt?The solution file. Mutually exclusive with `requirements_txts`.2None�
requirements_txts�Solution files mapped to the wheel platform tag each is compiled for, see `platform`. The solutions are compiled together and use the same version of every package. Mutually exclusive with `requirements_txt` and `platform`.	2{}"2
py_reqs_compiler@@rules_req_compile//:defs.bzl
��,
*
nameA unique name for this target. a
_
allow_sdistsFWhether or not the solution file is allowed to contain sdist packages.2False�
�
custom_compile_command�The command to display in the header of the generated lock file (`requirements_txt`). Any references to `{label}` will be replaced with the label of this target.2"bazel run "{label}""�
�
platform�The platform to compile the solution for as a wheel platform tag, as accepted by `pip --platform`, e.g. `manylinux_2_28_x86_64`, `manylinux2014_aarch64`, `macosx_11_0_arm64` or `win_amd64`. A manylinux tag accepts wheels for that glibc or older, a macosx tag wheels for that release or older. When unset, the solution is compiled for the platform running the compiler. Only applies to `requirements_txt`, `requirements_txts` names the platform of each solution.2""�
�
python_version�The Python version to compile the solution for, e.g. `3.11.4`. When unset, the exact version of the resolved Python toolchain is used, which keeps the solution independent of the machine running the compiler. A version without a patch number, e.g. `3.9`, is compiled as `3.9.0`.2""4
2
requirements_inThe input requirements file ]
[
requirements_txt?The solution file. Mutually exclusive with `requirements_txts`.2None�
�
requirements_txts�Solution files mapped to the wheel platform tag each is compiled for, see `platform`. The solutions are compiled together and use the same version of every package. Mutually exclusive with `requirements_txt` and `platform`.	2{}�py_reqs_solution_test�A Bazel test rule for ensuring the solution file for a `py_reqs_compiler` target satisifes the given requirements (`requirements_in`).

```python
load("@rules_req_compile//:defs.bzl", "py_reqs_compiler", "py_reqs_solution_test")

py_reqs_compiler(
    name = "requirements.update",
    requirements_in = "requirements.in",
    requirements_txt = "requirements.txt",
)

py_reqs_solution_test(
    name = "requirements_test",
    requirements_in = "requirements.in",
    requirements_txt = "requirements.txt",
)
```

Alternatively, a test can be defined in isolation using just the requirements files:

```python
load("@rules_req_compile//:defs.bzl", "py_reqs_solution_test")

py_reqs_solution_test(
    name = "requirements_test",
    custom_compile_command = "python3 -m req_compile --multiline --hashes --urls --solution requirements.txt requirements.in",
    requirements_in = "requirements.in",
    requirements_txt = "requirements.txt",
)
```
"�
�
py_reqs_solution_test�A Bazel test rule for ensuring the solution file for a `py_reqs_compiler` target satisifes the given requirements (`requirements_in`).

```python
load("@rules_req_compile//:defs.bzl", "py_reqs_compiler", "py_reqs_solution_test")

py_reqs_compiler(
    name = "requirements.update",
    requirements_in = "requirements.in",
    requirements_txt = "requirements.txt",
)

py_reqs_solution_test(
    name = "requirements_test",
    requirements_in = "requirements.in",
    requirements_txt = "requirements.txt",
)
```

Alternatively, a test can be defined in isolation using just the requirements files:

```python
load("@rules_req_compile//:defs.bzl", "py_reqs_solution_test")

py_reqs_solution_test(
    name = "requirements_test",
    custom_compile_command = "python3 -m req_compile --multiline --hashes --urls --solution requirements.txt requirements.in",
    requirements_in = "requirements.in",
    requirements_txt = "requirements.txt",
)
```
*
nameA unique name for this target. �
compiler�The `py_reqs_compiler` target to test. This attribute is mutally exclusive with `requirements_in` and `requirements_txt` and does not do any string formatting like `py_reqs_compiler` does.*
PyReqsCompilerInfo2None�
custom_compile_command�The command to display in the header of the generated lock file (`requirements_txt`). This attribute is required with `requirements_in` and `requirements_txt`.2""m
requirements_inRThe input requirements file. This attribute is mutually exclusive with `compiler`.2Noned
requirements_txtHThe solution file. This attribute is mutually exclusive with `compiler`.2None"7
py_reqs_solution_test@@rules_req_compile//:defs.bzl
��,
*
nameA unique name for this target. �
�
compiler�The `py_reqs_compiler` target to test. This attribute is mutally exclusive with `requirements_in` and `requirements_txt` and does not do any string formatting like `py_reqs_compiler` does.*
PyReqsCompilerInfo2None�
�
custom_compile_command�The command to display in the header of the generated lock file (`requirements_txt`). This attribute is required with `requirements_in` and `requirements_txt`.2""o
m
requirements_inRThe input requirements file. This attribute is mutually exclusive with `compiler`.2Nonef
d
requirements_txtHThe solution file. This attribute is mutually exclusive with `compiler`.2None�py_package_annotation�Annotations to apply to the BUILD file content from package generated from a `pip_repository` rule.

[cf]: https://github.com/bazelbuild/bazel-skylib/blob/main/docs/copy_file_doc.md
*�
�
py_package_annotatione
additive_build_fileFThe label of a `BUILD` file to add to the generated one for a pacakge.None(b
additive_build_file_content;Raw text to add to the generated `BUILD` file of a package.None([
additive_build_content9__DEPRECATED__ use `additive_build_file_content` instead.None(�
	copy_srcs�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl][cf].
The output files are added to the `py_library.srcs` attribute.{}(�

copy_files�A mapping of `src` and `out` files for [@bazel_skylib//rules:copy_file.bzl][cf].
The output files are added to the `py_library.data` attribute.{}(�
copy_executables�A mapping of `src` and `out` files for
[@bazel_skylib//rules:copy_file.bzl][cf]. Targets generated here will also be flagged as
executable.{}(b
dataTA list of labels to add as `data` dependencies to the generated `py_library` target.[](q
data_exclude_globVA list of exclude glob patterns to add as `data` to the generated
`py_library` target.[](b
srcs_exclude_globGA list of labels to add as `srcs` to the generated `py_library` target.[](`
depsRA list of dependencies to include to the package. Can be other packages or labels.[](|
deps_excludeseA list of packages to exclude from the package. (In cases where a package
has circular dependencies).[](=
patches,A list of patch files to apply to the wheel.[](�Annotations to apply to the BUILD file content from package generated from a `pip_repository` rule.

[cf]: https://github.com/bazelbuild/bazel-skylib/blob/main/docs/copy_file_doc.md
"5
3str: A json encoded string of the provided content.2P
py_package_annotation7@@rules_req_compile//req_compile/private:annotation.bzl
�?py_requirements_repository�The hub repository of a set of Python requirements.

This repository is created by the `requirements` module extension, which also creates
a [whl_repository](#whl_repository) for every distinct wheel pinned by any hub. Hubs
sharing a pinned wheel share its repository.

The hub provides a package per Python project it contains, with the `py_library` of the
project as its default target and the wheel file as `:whl`, as well as a generated
`defs.bzl` file.

```python
load("@py_requirements//:defs.bzl", "requirement")

py_library(
    name = "bar",
    ...
    deps = [
        "//my/other:dep",
        requirement("requests"),
        requirement("numpy"),
    ],
)
```

`requirement("requests")` is the same target as `@py_requirements//requests`.

When a hub has more than one lock, each package selects the wheel of the lock matching the
configuration. A package missing from some of the locks is incompatible with the platforms
of those locks, so targets depending on it are skipped there instead of failing to analyze.

In addition to the `requirement` macro, which is used to access the generated `py_library`
target generated from a package's wheel, the generated `defs.bzl` file contains
functionality for exposing [entry points][whl_ep] as `py_binary` targets as well.

[whl_ep]: https://packaging.python.org/specifications/entry-points/

```python
load("@py_requirements//:defs.bzl", "entry_point")

alias(
    name = "pip-compile",
    actual = entry_point(
        pkg = "pip-tools",
        script = "pip-compile",
    ),
)
```

Note that for packages whose name and script are the same, only the name of the package
is needed when calling the `entry_point` macro.

```python
load("@py_requirements//:defs.bzl", "entry_point")

alias(
    name = "flake8",
    actual = entry_point("flake8"),
)
```

A very important detail for generating python dependencies is sdist (source distribution)
dependencies are assumed to be incapable of yielding deterministic outputs. Therefore, any
case where a sdist (source distribution) is found in a lock file, the dependencies should
not be considered byte-for-byte reproducible. It is highly recommended solution files contain
all wheels so the generated repositories are byte-for-byte consistent. Failure to use binary-only
dependencies will result in unexpected cache invalidation as well as inconsistent or broken
cross-platform behavior.
R�,
�
py_requirements_repository�The hub repository of a set of Python requirements.

This repository is created by the `requirements` module extension, which also creates
a [whl_repository](#whl_repository) for every distinct wheel pinned by any hub. Hubs
sharing a pinned wheel share its repository.

The hub provides a package per Python project it contains, with the `py_library` of the
project as its default target and the wheel file as `:whl`, as well as a generated
`defs.bzl` file.

```python
load("@py_requirements//:defs.bzl", "requirement")

py_library(
    name = "bar",
    ...
    deps = [
        "//my/other:dep",
        requirement("requests"),
        requirement("numpy"),
    ],
)
```

`requirement("requests")` is the same target as `@py_requirements//requests`.

When a hub has more than one lock, each package selects the wheel of the lock matching the
configuration. A package missing from some of the locks is incompatible with the platforms
of those locks, so targets depending on it are skipped there instead of failing to analyze.

In addition to the `requirement` macro, which is used to access the generated `py_library`
target generated from a package's wheel, the generated `defs.bzl` file contains
functionality for exposing [entry points][whl_ep] as `py_binary` targets as well.

[whl_ep]: https://packaging.python.org/specifications/entry-points/

```python
load("@py_requirements//:defs.bzl", "entry_point")

alias(
    name = "pip-compile",
    actual = entry_point(
        pkg = "pip-tools",
        script = "pip-compile",
    ),
)
```

Note that for packages whose name and script are the same, only the name of the package
is needed when calling the `entry_point` macro.

```python
load("@py_requirements//:defs.bzl", "entry_point")

alias(
    name = "flake8",
    actual = entry_point("flake8"),
)
```

A very important detail for generating python dependencies is sdist (source distribution)
dependencies are assumed to be incapable of yielding deterministic outputs. Therefore, any
case where a sdist (source distribution) is found in a lock file, the dependencies should
not be considered byte-for-byte reproducible. It is highly recommended solution files contain
all wheels so the generated repositories are byte-for-byte consistent. Failure to use binary-only
dependencies will result in unexpected cache invalidation as well as inconsistent or broken
cross-platform behavior.
.
name"A unique name for this repository. }
alias_ofkThe name of a hub every package of this hub is an alias of. Used to override the hubs of dependent modules.2""`
default_lockJThe id of the lock used when no lock of the hub matches the configuration.2""N
hub_name<Name of the hub repository to generate. Do not use directly.2""�
legacy_root_pkg_aliases�If True, creates aliases in the root BUILD.bazel file pointing to the package targets in their subpackages. This provides backward compatibility for code that references packages at the root (e.g., `@repo//:package_name`).2FalseR
locksEA json encoded list of the locks of the hub and how each is selected. H
package_aliases/Packages to override with a local `py_library`.	2{}r
packagesbA json encoded mapping of package names to the version and `whl_repository` resolved by each lock. d

pins_labelPThe label of the hub's pinned requirements file in the workspace, if it has one.2""<
	pins_path)The workspace-relative path of that file.2""Z
	pins_textGThe pinned requirements the hub resolved, as `render_pins` writes them.2""�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 *<
py_requirements_repository@@rules_req_compile//:defs.bzl
�-�-0
.
name"A unique name for this repository. 
}
alias_ofkThe name of a hub every package of this hub is an alias of. Used to override the hubs of dependent modules.2""b
`
default_lockJThe id of the lock used when no lock of the hub matches the configuration.2""P
N
hub_name<Name of the hub repository to generate. Do not use directly.2""�
�
legacy_root_pkg_aliases�If True, creates aliases in the root BUILD.bazel file pointing to the package targets in their subpackages. This provides backward compatibility for code that references packages at the root (e.g., `@repo//:package_name`).2FalseT
R
locksEA json encoded list of the locks of the hub and how each is selected. J
H
package_aliases/Packages to override with a local `py_library`.	2{}t
r
packagesbA json encoded mapping of package names to the version and `whl_repository` resolved by each lock. f
d

pins_labelPThe label of the hub's pinned requirements file in the workspace, if it has one.2"">
<
	pins_path)The workspace-relative path of that file.2""\
Z
	pins_textGThe pinned requirements the hub resolved, as `render_pins` writes them.2""�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �/whl_repository�
A repository rule for extracting a python [wheel](https://peps.python.org/pep-0491/) and defining a `py_library`.

This repository is expected to be generated by [py_requirements_repository](#py_requirements_repository).

The repository contains the wheel (`//:whl`), a `py_library` named after the package (`//:requests`) holding its
files but none of its dependencies, and a target per hub using the wheel (`//:pip_deps.requests`) holding its files
with the dependencies that hub resolved for the package, or aliasing the package when the hub resolved none. The
console scripts of the wheel are a `py_binary` per hub (`//:pip_deps.entry_point_<script>`). This allows a single
repository to be shared by every hub that pins the same wheel, even when they resolved its dependencies differently.

Every target of the repository carries the `package_metadata` of the wheel (`//:package_metadata`), from the
`@package_metadata` module: a `pkg:pypi` purl naming the distribution the lock pinned, with its file name, download
URL and sha256 as qualifiers, and the license the wheel declares in its `METADATA` (`//:license`), when it declares
one. The hub's aliases resolve to these targets, so tooling collecting the metadata of a binary's dependencies, such
as an SBOM generator, sees the wheel behind each requirement.
R�$
�
whl_repository�
A repository rule for extracting a python [wheel](https://peps.python.org/pep-0491/) and defining a `py_library`.

This repository is expected to be generated by [py_requirements_repository](#py_requirements_repository).

The repository contains the wheel (`//:whl`), a `py_library` named after the package (`//:requests`) holding its
files but none of its dependencies, and a target per hub using the wheel (`//:pip_deps.requests`) holding its files
with the dependencies that hub resolved for the package, or aliasing the package when the hub resolved none. The
console scripts of the wheel are a `py_binary` per hub (`//:pip_deps.entry_point_<script>`). This allows a single
repository to be shared by every hub that pins the same wheel, even when they resolved its dependencies differently.

Every target of the repository carries the `package_metadata` of the wheel (`//:package_metadata`), from the
`@package_metadata` module: a `pkg:pypi` purl naming the distribution the lock pinned, with its file name, download
URL and sha256 as qualifiers, and the license the wheel declares in its `METADATA` (`//:license`), when it declares
one. The hub's aliases resolve to these targets, so tooling collecting the metadata of a binary's dependencies, such
as an SBOM generator, sees the wheel behind each requirement.
.
name"A unique name for this repository. j
annotationsSSee [py_requirements_repository.annotation](#py_requirements_repository.annotation)2"{}"�
hubs�A json encoded mapping of hub names to the hub's use of this wheel: its `locks`, a mapping of lock id to the `deps` (python package names) resolved for the package and the `config_setting` label the hub uses to select the lock, which is `null` for hubs with a single lock, and the `default_lock` the hub falls back to, if any.2"{}"U
interpreter>Optional Python interpreter binary to use for building sdists.2NoneC
package4The name of the python package the wheel represents. 9
patches(Patches to apply to the installed wheel.2[]�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
sdist_deps_reposMINTERNAL: DO NOT USE. Default dependencies for building source distributions.2�[Label("@@req_compile_sdist_compiler__pip//:pip"), Label("@@req_compile_sdist_compiler__setuptools//:setuptools"), Label("@@req_compile_sdist_compiler__wheel//:wheel")]<
sha256,The expected SHA-256 of the file downloaded.2""1
urls#A list of URLs to the python wheel.2[]1
version"The version of the python package. $
whlThe label to a wheel.2None*0
whl_repository@@rules_req_compile//:defs.bzl
�!�!0
.
name"A unique name for this repository. l
j
annotationsSSee [py_requirements_repository.annotation](#py_requirements_repository.annotation)2"{}"�
�
hubs�A json encoded mapping of hub names to the hub's use of this wheel: its `locks`, a mapping of lock id to the `deps` (python package names) resolved for the package and the `config_setting` label the hub uses to select the lock, which is `null` for hubs with a single lock, and the `default_lock` the hub falls back to, if any.2"{}"W
U
interpreter>Optional Python interpreter binary to use for building sdists.2NoneE
C
package4The name of the python package the wheel represents. ;
9
patches(Patches to apply to the installed wheel.2[]�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
�
sdist_deps_reposMINTERNAL: DO NOT USE. Default dependencies for building source distributions.2�[Label("@@req_compile_sdist_compiler__pip//:pip"), Label("@@req_compile_sdist_compiler__setuptools//:setuptools"), Label("@@req_compile_sdist_compiler__wheel//:wheel")]>
<
sha256,The expected SHA-256 of the file downloaded.2""3
1
urls#A list of URLs to the python wheel.2[]3
1
version"The version of the python package. &
$
whlThe label to a wheel.2None�
$//req_compile/private:annotation.bzlr�
8
rules_req_compilereq_compile/privateannotation.bzl=
py_package_annotation_py_package_annotation
O
py_package_annotation_consumer_py_package_annotation_consumer
$K
py_package_annotation_target_py_package_annotation_target
"
�
"//req_compile/private:compiler.bzlr�
6
rules_req_compilereq_compile/privatecompiler.bzl3
py_reqs_compiler_py_reqs_compiler
=
py_reqs_solution_test_py_reqs_solution_test

�
#//req_compile/private:reqs_repo.bzlr�
7
rules_req_compilereq_compile/privatereqs_repo.bzlG
py_requirements_repository_py_requirements_repository
"" 
 #�
"//req_compile/private:whl_repo.bzlrw
6
rules_req_compilereq_compile/privatewhl_repo.bzl/
whl_repository_whl_repository
((
&)�# Bazel rules for `rules_req_compile`

- [py_package_annotation_consumer](#py_package_annotation_consumer)
- [py_package_annotation_target](#py_package_annotation_target)
- [py_package_annotation](#py_package_annotation)
- [py_reqs_compiler](#py_reqs_compiler)
- [py_reqs_solution_test](#py_reqs_solution_test)
- [py_requirements_repository](#py_requirements_repository)
- [sdist_repository](#sdist_repository)
- [whl_repository](#whl_repository)

---
---
T
 
rules_req_compileversion.bzl	VERSION1.7.1j1.7.1req-compile version 