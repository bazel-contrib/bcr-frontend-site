�?
&

rules_rubyruby/private
binary.bzl�8	rb_binary�
Runs a Ruby binary.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

One of the files can be run as a Ruby script:

`lib/gem/version.rb`:
```ruby
module GEM
  VERSION = '0.1.0'
end

puts "Version is: #{GEM::VERSION}" if __FILE__ == $PROGRAM_NAME
```

You can run this script by defining a target:

`lib/gem/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_binary", "rb_library")

rb_library(
    name = "version",
    srcs = ["version.rb"],
)

rb_binary(
    name = "print-version",
    args = ["lib/gem/version.rb"],
    deps = [":version"],
)
```

```output
$ bazel run lib/gem:print-version
INFO: Analyzed target //lib/gem:print-version (1 packages loaded, 3 targets configured).
INFO: Found 1 target...
Target //lib/gem:print-version up-to-date:
  bazel-bin/lib/gem/print-version.rb.sh
INFO: Elapsed time: 0.121s, Critical Path: 0.01s
INFO: 4 processes: 4 internal.
INFO: Build completed successfully, 4 total actions
INFO: Build completed successfully, 4 total actions
Version is: 0.1.0
```

You can also run general purpose Ruby scripts that rely on a Ruby interpreter in PATH:

`lib/gem/add.rb`:
```ruby
#!/usr/bin/env ruby

a, b = *ARGV
puts Integer(a) + Integer(b)
```

`lib/gem/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_binary", "rb_library")

rb_library(
    name = "add",
    srcs = ["add.rb"],
)

rb_binary(
    name = "add-numbers",
    main = "add.rb",
    deps = [":add"],
)
```

```output
$ bazel run lib/gem:add-numbers 1 2
INFO: Analyzed target //lib/gem:add-numbers (1 packages loaded, 3 targets configured).
INFO: Found 1 target...
Target //lib/gem:add-numbers up-to-date:
  bazel-bin/lib/gem/add-numbers.rb.sh
INFO: Elapsed time: 0.092s, Critical Path: 0.00s
INFO: 1 process: 1 internal.
INFO: Build completed successfully, 1 total action
INFO: Build completed successfully, 1 total action
3
```

You can also run a Ruby binary script available in Gemfile dependencies,
by passing `bin` argument with a path to a Bundler binary stub:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_binary")

package(default_visibility = ["//:__subpackages__"])

rb_binary(
    name = "rake",
    main = "@bundle//:bin/rake",
    deps = [
        "//lib:gem",
        "@bundle",
    ],
)
```

```output
$ bazel run :rake -- --version
INFO: Analyzed target //:rake (0 packages loaded, 0 targets configured).
INFO: Found 1 target...
Target //:rake up-to-date:
  bazel-bin/rake.rb.sh
INFO: Elapsed time: 0.073s, Critical Path: 0.00s
INFO: 1 process: 1 internal.
INFO: Build completed successfully, 1 total action
INFO: Running command line: bazel-bin/rake.rb.sh --version
rake, version 10.5.0
```
"�!
�
	rb_binary�
Runs a Ruby binary.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

One of the files can be run as a Ruby script:

`lib/gem/version.rb`:
```ruby
module GEM
  VERSION = '0.1.0'
end

puts "Version is: #{GEM::VERSION}" if __FILE__ == $PROGRAM_NAME
```

You can run this script by defining a target:

`lib/gem/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_binary", "rb_library")

rb_library(
    name = "version",
    srcs = ["version.rb"],
)

rb_binary(
    name = "print-version",
    args = ["lib/gem/version.rb"],
    deps = [":version"],
)
```

```output
$ bazel run lib/gem:print-version
INFO: Analyzed target //lib/gem:print-version (1 packages loaded, 3 targets configured).
INFO: Found 1 target...
Target //lib/gem:print-version up-to-date:
  bazel-bin/lib/gem/print-version.rb.sh
INFO: Elapsed time: 0.121s, Critical Path: 0.01s
INFO: 4 processes: 4 internal.
INFO: Build completed successfully, 4 total actions
INFO: Build completed successfully, 4 total actions
Version is: 0.1.0
```

You can also run general purpose Ruby scripts that rely on a Ruby interpreter in PATH:

`lib/gem/add.rb`:
```ruby
#!/usr/bin/env ruby

a, b = *ARGV
puts Integer(a) + Integer(b)
```

`lib/gem/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_binary", "rb_library")

rb_library(
    name = "add",
    srcs = ["add.rb"],
)

rb_binary(
    name = "add-numbers",
    main = "add.rb",
    deps = [":add"],
)
```

```output
$ bazel run lib/gem:add-numbers 1 2
INFO: Analyzed target //lib/gem:add-numbers (1 packages loaded, 3 targets configured).
INFO: Found 1 target...
Target //lib/gem:add-numbers up-to-date:
  bazel-bin/lib/gem/add-numbers.rb.sh
INFO: Elapsed time: 0.092s, Critical Path: 0.00s
INFO: 1 process: 1 internal.
INFO: Build completed successfully, 1 total action
INFO: Build completed successfully, 1 total action
3
```

You can also run a Ruby binary script available in Gemfile dependencies,
by passing `bin` argument with a path to a Bundler binary stub:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_binary")

package(default_visibility = ["//:__subpackages__"])

rb_binary(
    name = "rake",
    main = "@bundle//:bin/rake",
    deps = [
        "//lib:gem",
        "@bundle",
    ],
)
```

```output
$ bazel run :rake -- --version
INFO: Analyzed target //:rake (0 packages loaded, 0 targets configured).
INFO: Found 1 target...
Target //:rake up-to-date:
  bazel-bin/rake.rb.sh
INFO: Elapsed time: 0.073s, Critical Path: 0.00s
INFO: 1 process: 1 internal.
INFO: Build completed successfully, 1 total action
INFO: Running command line: bazel-bin/rake.rb.sh --version
rake, version 10.5.0
```
*
nameA unique name for this target. F
data8List of non-Ruby source files used to build the library.2[]A
deps3List of other Ruby libraries the target depends on.2[];
env.Environment variables to use during execution.
2{}[
env_inheritFList of environment variable names to be inherited by the test runner.2[]�
main�
Ruby script to run. It may also be a binary stub generated by Bundler.
If omitted, it defaults to the Ruby interpreter.

Use a built-in `args` attribute to pass extra arguments to the script.
2NoneB
srcs4List of Ruby source files used to build the library.2[]"2
	rb_binary%@@rules_ruby//ruby/private:binary.bzl
��,
*
nameA unique name for this target. H
F
data8List of non-Ruby source files used to build the library.2[]C
A
deps3List of other Ruby libraries the target depends on.2[]=
;
env.Environment variables to use during execution.
2{}]
[
env_inheritFList of environment variable names to be inherited by the test runner.2[]�
�
main�
Ruby script to run. It may also be a binary stub generated by Bundler.
If omitted, it defaults to the Ruby interpreter.

Use a built-in `args` attribute to pass extra arguments to the script.
2NoneD
B
srcs4List of Ruby source files used to build the library.2[]�generate_rb_binary_script*�
�
generate_rb_binary_script	
ctx (
binary (
bundlerFalse(
args[](2B
generate_rb_binary_script%@@rules_ruby//ruby/private:binary.bzl
--xrb_binary_impl*d
T
rb_binary_impl	
ctx (27
rb_binary_impl%@@rules_ruby//ruby/private:binary.bzl
YY}
//ruby/private:library.bzlr]
'

rules_rubyruby/privatelibrary.bzl$
ATTRSLIBRARY_ATTRS
/<
G�
//ruby/private:providers.bzlr�
)

rules_rubyruby/privateproviders.bzl,
RubyFilesInfoRubyFilesInfo
.
get_bundle_envget_bundle_env
8
get_transitive_dataget_transitive_data
8
get_transitive_depsget_transitive_deps
		8
get_transitive_srcsget_transitive_srcs



$Implementation details for rb_binary�
&

rules_rubyruby/private
bundle.bzl�	rb_bundle�
Installs Bundler dependencies and registers an external repository
that can be used by other targets.

`WORKSPACE`:
```bazel
load("@rules_ruby//ruby:deps.bzl", "rb_bundle")

rb_bundle(
    name = "bundle",
    gemfile = "//:Gemfile",
    srcs = [
        "//:gem.gemspec",
        "//:lib/gem/version.rb",
    ]
)
```

All the installed gems can be accessed using `@bundle` target and additionally
gems binary files can also be used:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_binary")

package(default_visibility = ["//:__subpackages__"])

rb_binary(
    name = "rubocop",
    main = "@bundle//:bin/rubocop",
    deps = ["@bundle"],
)
```
R�
�
	rb_bundle�
Installs Bundler dependencies and registers an external repository
that can be used by other targets.

`WORKSPACE`:
```bazel
load("@rules_ruby//ruby:deps.bzl", "rb_bundle")

rb_bundle(
    name = "bundle",
    gemfile = "//:Gemfile",
    srcs = [
        "//:gem.gemspec",
        "//:lib/gem/version.rb",
    ]
)
```

All the installed gems can be accessed using `@bundle` target and additionally
gems binary files can also be used:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_binary")

package(default_visibility = ["//:__subpackages__"])

rb_binary(
    name = "rubocop",
    main = "@bundle//:bin/rubocop",
    deps = ["@bundle"],
)
```
.
name"A unique name for this repository. >
env1Environment variables to use during installation.
2{}:
gemfile'
Gemfile to install dependencies from.
2None�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 D
srcs6
List of Ruby source files used to build the library.
2[]
	toolchain *2
	rb_bundle%@@rules_ruby//ruby/private:bundle.bzl
HH0
.
name"A unique name for this repository. @
>
env1Environment variables to use during installation.
2{}<
:
gemfile'
Gemfile to install dependencies from.
2None�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 F
D
srcs6
List of Ruby source files used to build the library.
2[]

	toolchain .Implementation details for calling the bundler�
(

rules_rubyruby/privatedownload.bzl�rb_register_toolchains�Register a Ruby toolchain and lazily download the Ruby Interpreter.

* _(For MRI on Linux and macOS)_ Installed using [ruby-build](https://github.com/rbenv/ruby-build).
* _(For MRI on Windows)_ Installed using [RubyInstaller](https://rubyinstaller.org).
* _(For JRuby on any OS)_ Downloaded and installed directly from [official website](https://www.jruby.org).
* _(For TruffleRuby on Linux and macOS)_ Installed using [ruby-build](https://github.com/rbenv/ruby-build).

`WORKSPACE`:
```bazel
load("@rules_ruby//ruby:deps.bzl", "rb_download")

rb_register_toolchains(
    version = "2.7.5"
)
```
*�
�
rb_register_toolchainsT
name<base name of resulting repositories, by default "rules_ruby""rules_ruby"(k
versionXa semver version of Matz Ruby Interpreter, or a string like [interpreter type]-[version]None(^
registerJwhether to register the resulting toolchains, should be False under bzlmodTrue(M
kwargsAadditional parameters to the downloader for this interpreter type(�Register a Ruby toolchain and lazily download the Ruby Interpreter.

* _(For MRI on Linux and macOS)_ Installed using [ruby-build](https://github.com/rbenv/ruby-build).
* _(For MRI on Windows)_ Installed using [RubyInstaller](https://rubyinstaller.org).
* _(For JRuby on any OS)_ Downloaded and installed directly from [official website](https://www.jruby.org).
* _(For TruffleRuby on Linux and macOS)_ Installed using [ruby-build](https://github.com/rbenv/ruby-build).

`WORKSPACE`:
```bazel
load("@rules_ruby//ruby:deps.bzl", "rb_download")

rb_register_toolchains(
    version = "2.7.5"
)
```
2A
rb_register_toolchains'@@rules_ruby//ruby/private:download.bzl
*_rb_download�rb_toolchain_repository_proxyA proxy repository that contains the toolchain declaration; this indirection allows the Ruby toolchain to be downloaded lazily.R�

�
rb_toolchain_repository_proxyA proxy repository that contains the toolchain declaration; this indirection allows the Ruby toolchain to be downloaded lazily..
name"A unique name for this repository. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 
	toolchain 
toolchain_type *H
rb_toolchain_repository_proxy'@@rules_ruby//ruby/private:download.bzl
C0C00
.
name"A unique name for this repository. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 

	toolchain 

toolchain_type 5	DEFAULT_RUBY_REPOSITORY
rules_rubyj
rules_ruby.Repository rule for fetching Ruby interpreters�'
)

rules_rubyruby/privategem_build.bzl�"rb_gem_build�
Builds a Ruby gem.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

And a RubyGem specification is:

`gem.gemspec`:
```ruby
root = File.expand_path(__dir__)
$LOAD_PATH.push(File.expand_path('lib', root))
require 'gem/version'

Gem::Specification.new do |s|
  s.name = 'example'
  s.version = GEM::VERSION

  s.authors = ['Foo Bar']
  s.email = ['foobar@gmail.com']
  s.homepage = 'http://rubygems.org'
  s.license = 'MIT'

  s.summary = 'Example'
  s.description = 'Example gem'
  s.files = ['Gemfile'] + Dir['lib/**/*']

  s.require_paths = ['lib']
  s.add_dependency 'rake', '~> 10'
  s.add_development_dependency 'rspec', '~> 3.0'
  s.add_development_dependency 'rubocop', '~> 1.10'
end
```

You can now package everything into a `.gem` file by defining a target:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_gem_build")

package(default_visibility = ["//:__subpackages__"])

rb_gem_build(
    name = "gem-build",
    gemspec = "gem.gemspec",
    deps = [
        "//lib:gem",
        "@bundle",
    ],
)
```

```output
$ bazel build :gem-build
INFO: Analyzed target //:gem-build (0 packages loaded, 0 targets configured).
INFO: Found 1 target...
INFO: From Action gem-build.gem:
  Successfully built RubyGem
  Name: example
  Version: 0.1.0
  File: example-0.1.0.gem
Target //:gem-build up-to-date:
  bazel-bin/gem-build.gem
INFO: Elapsed time: 0.196s, Critical Path: 0.10s
INFO: 2 processes: 1 internal, 1 darwin-sandbox.
INFO: Build completed successfully, 2 total actions
```
"�
�
rb_gem_build�
Builds a Ruby gem.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

And a RubyGem specification is:

`gem.gemspec`:
```ruby
root = File.expand_path(__dir__)
$LOAD_PATH.push(File.expand_path('lib', root))
require 'gem/version'

Gem::Specification.new do |s|
  s.name = 'example'
  s.version = GEM::VERSION

  s.authors = ['Foo Bar']
  s.email = ['foobar@gmail.com']
  s.homepage = 'http://rubygems.org'
  s.license = 'MIT'

  s.summary = 'Example'
  s.description = 'Example gem'
  s.files = ['Gemfile'] + Dir['lib/**/*']

  s.require_paths = ['lib']
  s.add_dependency 'rake', '~> 10'
  s.add_development_dependency 'rspec', '~> 3.0'
  s.add_development_dependency 'rubocop', '~> 1.10'
end
```

You can now package everything into a `.gem` file by defining a target:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_gem_build")

package(default_visibility = ["//:__subpackages__"])

rb_gem_build(
    name = "gem-build",
    gemspec = "gem.gemspec",
    deps = [
        "//lib:gem",
        "@bundle",
    ],
)
```

```output
$ bazel build :gem-build
INFO: Analyzed target //:gem-build (0 packages loaded, 0 targets configured).
INFO: Found 1 target...
INFO: From Action gem-build.gem:
  Successfully built RubyGem
  Name: example
  Version: 0.1.0
  File: example-0.1.0.gem
Target //:gem-build up-to-date:
  bazel-bin/gem-build.gem
INFO: Elapsed time: 0.196s, Critical Path: 0.10s
INFO: 2 processes: 1 internal, 1 darwin-sandbox.
INFO: Build completed successfully, 2 total actions
```
*
nameA unique name for this target. Z

bundle_envFList of bundle environment variables to set when building the library.
2{}F
data8List of non-Ruby source files used to build the library.2[]A
deps3List of other Ruby libraries the target depends on.2[]4
gemspec%Gemspec file to use for gem building. B
srcs4List of Ruby source files used to build the library.2[]"8
rb_gem_build(@@rules_ruby//ruby/private:gem_build.bzl
OO,
*
nameA unique name for this target. \
Z

bundle_envFList of bundle environment variables to set when building the library.
2{}H
F
data8List of non-Ruby source files used to build the library.2[]C
A
deps3List of other Ruby libraries the target depends on.2[]6
4
gemspec%Gemspec file to use for gem building. D
B
srcs4List of Ruby source files used to build the library.2[]}
//ruby/private:library.bzlr]
'

rules_rubyruby/privatelibrary.bzl$
ATTRSLIBRARY_ATTRS
/<
G�
//ruby/private:providers.bzlr�
)

rules_rubyruby/privateproviders.bzl,
RubyFilesInfoRubyFilesInfo
.
get_bundle_envget_bundle_env
8
get_transitive_dataget_transitive_data
8
get_transitive_depsget_transitive_deps
		8
get_transitive_srcsget_transitive_srcs



'Implementation details for rb_gem_build�!
(

rules_rubyruby/privategem_push.bzl�rb_gem_push�

Pushes a built Ruby gem.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem and `rb_gem_build()` is used
to build a Ruby gem package from the sources.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

You can now release the built `.gem` file to RubyGems by defining a target:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_gem_build", "rb_gem_push")

package(default_visibility = ["//:__subpackages__"])

rb_gem_build(
    name = "gem-build",
    gemspec = "gem.gemspec",
    deps = ["//lib:gem"],
)

rb_gem_push(
    name = "gem-release",
    gem = ":gem-build",
)
```

```output
$ bazel run :gem-release
INFO: Analyzed target //:gem-release (3 packages loaded, 14 targets configured).
INFO: Found 1 target...
Target //:gem-release up-to-date:
  bazel-bin/gem-release.rb.sh
INFO: Elapsed time: 0.113s, Critical Path: 0.01s
INFO: 4 processes: 4 internal.
INFO: Build completed successfully, 4 total actions
INFO: Build completed successfully, 4 total actions
Pushing gem to https://rubygems.org...
Successfully registered gem: example (0.1.0)
```
"�
�
rb_gem_push�

Pushes a built Ruby gem.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem and `rb_gem_build()` is used
to build a Ruby gem package from the sources.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

You can now release the built `.gem` file to RubyGems by defining a target:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_gem_build", "rb_gem_push")

package(default_visibility = ["//:__subpackages__"])

rb_gem_build(
    name = "gem-build",
    gemspec = "gem.gemspec",
    deps = ["//lib:gem"],
)

rb_gem_push(
    name = "gem-release",
    gem = ":gem-build",
)
```

```output
$ bazel run :gem-release
INFO: Analyzed target //:gem-release (3 packages loaded, 14 targets configured).
INFO: Found 1 target...
Target //:gem-release up-to-date:
  bazel-bin/gem-release.rb.sh
INFO: Elapsed time: 0.113s, Critical Path: 0.01s
INFO: 4 processes: 4 internal.
INFO: Build completed successfully, 4 total actions
INFO: Build completed successfully, 4 total actions
Pushing gem to https://rubygems.org...
Successfully registered gem: example (0.1.0)
```
*
nameA unique name for this target. Z

bundle_envFList of bundle environment variables to set when building the library.
2{}F
data8List of non-Ruby source files used to build the library.2[]A
deps3List of other Ruby libraries the target depends on.2[];
env.Environment variables to use during execution.
2{}[
env_inheritFList of environment variable names to be inherited by the test runner.2[]k
gem`
Gem file to push to RubyGems. You would usually use an output of `rb_gem_build()` target here.
 B
srcs4List of Ruby source files used to build the library.2[]"6
rb_gem_push'@@rules_ruby//ruby/private:gem_push.bzl
&&,
*
nameA unique name for this target. \
Z

bundle_envFList of bundle environment variables to set when building the library.
2{}H
F
data8List of non-Ruby source files used to build the library.2[]C
A
deps3List of other Ruby libraries the target depends on.2[]=
;
env.Environment variables to use during execution.
2{}]
[
env_inheritFList of environment variable names to be inherited by the test runner.2[]m
k
gem`
Gem file to push to RubyGems. You would usually use an output of `rb_gem_build()` target here.
 D
B
srcs4List of Ruby source files used to build the library.2[]�
//ruby/private:binary.bzlr�
&

rules_rubyruby/private
binary.bzlD
generate_rb_binary_scriptgenerate_rb_binary_script
/H#
ATTRSBINARY_ATTRS
KW
b}
//ruby/private:library.bzlr]
'

rules_rubyruby/privatelibrary.bzl$
ATTRSLIBRARY_ATTRS
/<
G#Implementation details for gem_push�
'

rules_rubyruby/privatelibrary.bzl�
rb_library�	
Defines a Ruby library.

Suppose you have the following Ruby gem:

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

You can define packages for the gem source files:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_library")

package(default_visibility = ["//:__subpackages__"])

rb_library(
    name = "gem",
    deps = ["//lib:gem"],
)
```

`lib/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_library")

package(default_visibility = ["//:__subpackages__"])

rb_library(
    name = "gem",
    srcs = ["gem.rb"],
    deps = [
        "//lib/gem:add",
        "//lib/gem:subtract",
        "//lib/gem:version",
    ],
)
```

`lib/gem/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_library")

package(default_visibility = ["//:__subpackages__"])

rb_library(
    name = "add",
    srcs = ["add.rb"],
)

rb_library(
    name = "subtract",
    srcs = ["subtract.rb"],
)

rb_library(
    name = "version",
    srcs = ["version.rb"],
)
```

Once the packages are defined, you can use them in other targets
such as `rb_gem_build()` to build a Ruby gem. See examples of
using other rules.
"�
�

rb_library�	
Defines a Ruby library.

Suppose you have the following Ruby gem:

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

You can define packages for the gem source files:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_library")

package(default_visibility = ["//:__subpackages__"])

rb_library(
    name = "gem",
    deps = ["//lib:gem"],
)
```

`lib/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_library")

package(default_visibility = ["//:__subpackages__"])

rb_library(
    name = "gem",
    srcs = ["gem.rb"],
    deps = [
        "//lib/gem:add",
        "//lib/gem:subtract",
        "//lib/gem:version",
    ],
)
```

`lib/gem/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_library")

package(default_visibility = ["//:__subpackages__"])

rb_library(
    name = "add",
    srcs = ["add.rb"],
)

rb_library(
    name = "subtract",
    srcs = ["subtract.rb"],
)

rb_library(
    name = "version",
    srcs = ["version.rb"],
)
```

Once the packages are defined, you can use them in other targets
such as `rb_gem_build()` to build a Ruby gem. See examples of
using other rules.
*
nameA unique name for this target. Z

bundle_envFList of bundle environment variables to set when building the library.
2{}F
data8List of non-Ruby source files used to build the library.2[]A
deps3List of other Ruby libraries the target depends on.2[]B
srcs4List of Ruby source files used to build the library.2[]"4

rb_library&@@rules_ruby//ruby/private:library.bzl
((,
*
nameA unique name for this target. \
Z

bundle_envFList of bundle environment variables to set when building the library.
2{}H
F
data8List of non-Ruby source files used to build the library.2[]C
A
deps3List of other Ruby libraries the target depends on.2[]D
B
srcs4List of Ruby source files used to build the library.2[]�
//ruby/private:providers.bzlr�
)

rules_rubyruby/privateproviders.bzl,
RubyFilesInfoRubyFilesInfo
.
get_bundle_envget_bundle_env
8
get_transitive_dataget_transitive_data
8
get_transitive_depsget_transitive_deps
8
get_transitive_srcsget_transitive_srcs
		

%Implementation details for rb_library�
)

rules_rubyruby/privateproviders.bzl�get_bundle_envWObtain the BUNDLE_* environment variables for a target and its transitive dependencies.*�
�
get_bundle_env+
envsa list of environment variables (:
deps.a list of targets that are direct dependencies (WObtain the BUNDLE_* environment variables for a target and its transitive dependencies."6
4a collection of the transitive environment variables2:
get_bundle_env(@@rules_ruby//ruby/private:providers.bzl
22�get_transitive_dataCObtain the data files for a target and its transitive dependencies.*�
�
get_transitive_data 
dataa list of data files (:
deps.a list of targets that are direct dependencies (CObtain the data files for a target and its transitive dependencies."+
)a collection of the transitive data files2?
get_transitive_data(@@rules_ruby//ruby/private:providers.bzl
�get_transitive_depsEObtain the dependencies for a target and its transitive dependencies.*�
�
get_transitive_deps:
deps.a list of targets that are direct dependencies (EObtain the dependencies for a target and its transitive dependencies."-
+a collection of the transitive dependencies2?
get_transitive_deps(@@rules_ruby//ruby/private:providers.bzl
%%�get_transitive_srcsEObtain the source files for a target and its transitive dependencies.*�
�
get_transitive_srcs"
srcsa list of source files (:
deps.a list of targets that are direct dependencies (EObtain the source files for a target and its transitive dependencies."(
&a collection of the transitive sources2?
get_transitive_srcs(@@rules_ruby//ruby/private:providers.bzl
		�RubyFilesInfoProvider for Ruby files2�
�
RubyFilesInfoProvider for Ruby files!
transitive_data(Undocumented)!
transitive_deps(Undocumented)!
transitive_srcs(Undocumented)

bundle_env(Undocumented)"9
RubyFilesInfo(@@rules_ruby//ruby/private:providers.bzl
#
!
transitive_data(Undocumented)#
!
transitive_deps(Undocumented)#
!
transitive_srcs(Undocumented)


bundle_env(Undocumented),Providers for Interoperability between rules�G
$

rules_rubyruby/privatetest.bzl�Drb_test�
Runs a Ruby test.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
|-- lib
|   |-- BUILD
|   |-- gem
|   |   |-- BUILD
|   |   |-- add.rb
|   |   |-- subtract.rb
|   |   `-- version.rb
|   `-- gem.rb
`-- spec
    |-- BUILD
    |-- add_spec.rb
    |-- spec_helper.rb
    `-- subtract_spec.rb
```

You can run all tests inside `spec/` by defining individual targets:

`spec/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_library", "rb_test")

rb_library(
    name = "spec_helper",
    srcs = ["spec_helper.rb"],
)

rb_test(
    name = "add",
    srcs = ["add_spec.rb"],
    args = ["spec/add_spec.rb"],
    main = "@bundle//:bin/rspec",
    deps = [
        ":spec_helper",
        "@bundle",
    ],
)

rb_test(
    name = "subtract",
    srcs = ["subtract_spec.rb"],
    args = ["spec/subtract_spec.rb"],
    main = "@bundle//:bin/rspec",
    deps = [
        ":spec_helper",
        "@bundle",
    ],
)
```

```output
$ bazel test spec/...
INFO: Analyzed 3 targets (22 packages loaded, 621 targets configured).
INFO: Found 1 target and 2 test targets...
INFO: Elapsed time: 2.354s, Critical Path: 0.49s
INFO: 9 processes: 5 internal, 4 darwin-sandbox.
INFO: Build completed successfully, 9 total actions
//spec:add                                                               PASSED in 0.4s
//spec:subtract                                                          PASSED in 0.4s

Executed 2 out of 2 tests: 2 tests pass.
```

Since `rb_test()` is a wrapper around `rb_binary()`, you can also use it to run
a Ruby binary script available in Gemfile dependencies, by passing `main`
argument with a path to a Bundler binary stub.

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_test")

package(default_visibility = ["//:__subpackages__"])

rb_test(
    name = "rubocop",
    args = ["lib/"],
    main = "@bundle//:bin/rubocop",
    tags = ["no-sandbox"],
    deps = [
        "//lib:gem",
        "@bundle",
    ],
)
```

```output
$ bazel test :rubocop
INFO: Analyzed target //:rubocop (0 packages loaded, 123 targets configured).
INFO: Found 1 test target...
Target //:rubocop up-to-date:
  bazel-bin/rubocop.rb.sh
INFO: Elapsed time: 0.875s, Critical Path: 0.79s
INFO: 2 processes: 2 local.
INFO: Build completed successfully, 2 total actions
//:rubocop                                                               PASSED in 0.8s

Executed 1 out of 1 test: 1 test passes.
```

Note that you can also `run` every test target passing extra arguments to
the Ruby script. For example, you can re-use `:rubocop` target to perform autocorrect:

```output
$ bazel run :rubocop -- --autocorrect-all
INFO: Analyzed target //:rubocop (0 packages loaded, 0 targets configured).
INFO: Found 1 target...
Target //:rubocop up-to-date:
  bazel-bin/rubocop.rb.sh
INFO: Elapsed time: 0.066s, Critical Path: 0.00s
INFO: 1 process: 1 internal.
INFO: Build completed successfully, 1 total action
INFO: Running command line: external/bazel_tools/tools/test/test-setup.sh ./rubocop.rb.sh --autocorrect-all
exec ${PAGER:-/usr/bin/less} "$0" || exit 1
Executing tests from //:rubocop
-----------------------------------------------------------------------------
Inspecting 11 files
.C.........

Offenses:

gem.gemspec:1:1: C: [Corrected] Style/FrozenStringLiteralComment: Missing frozen string literal comment.
root = File.expand_path(__dir__)
^
gem.gemspec:2:1: C: [Corrected] Layout/EmptyLineAfterMagicComment: Add an empty line after magic comments.
root = File.expand_path(__dir__)
^

11 files inspected, 2 offenses detected, 2 offenses corrected
```
"�'
�"
rb_test�
Runs a Ruby test.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
|-- lib
|   |-- BUILD
|   |-- gem
|   |   |-- BUILD
|   |   |-- add.rb
|   |   |-- subtract.rb
|   |   `-- version.rb
|   `-- gem.rb
`-- spec
    |-- BUILD
    |-- add_spec.rb
    |-- spec_helper.rb
    `-- subtract_spec.rb
```

You can run all tests inside `spec/` by defining individual targets:

`spec/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_library", "rb_test")

rb_library(
    name = "spec_helper",
    srcs = ["spec_helper.rb"],
)

rb_test(
    name = "add",
    srcs = ["add_spec.rb"],
    args = ["spec/add_spec.rb"],
    main = "@bundle//:bin/rspec",
    deps = [
        ":spec_helper",
        "@bundle",
    ],
)

rb_test(
    name = "subtract",
    srcs = ["subtract_spec.rb"],
    args = ["spec/subtract_spec.rb"],
    main = "@bundle//:bin/rspec",
    deps = [
        ":spec_helper",
        "@bundle",
    ],
)
```

```output
$ bazel test spec/...
INFO: Analyzed 3 targets (22 packages loaded, 621 targets configured).
INFO: Found 1 target and 2 test targets...
INFO: Elapsed time: 2.354s, Critical Path: 0.49s
INFO: 9 processes: 5 internal, 4 darwin-sandbox.
INFO: Build completed successfully, 9 total actions
//spec:add                                                               PASSED in 0.4s
//spec:subtract                                                          PASSED in 0.4s

Executed 2 out of 2 tests: 2 tests pass.
```

Since `rb_test()` is a wrapper around `rb_binary()`, you can also use it to run
a Ruby binary script available in Gemfile dependencies, by passing `main`
argument with a path to a Bundler binary stub.

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_test")

package(default_visibility = ["//:__subpackages__"])

rb_test(
    name = "rubocop",
    args = ["lib/"],
    main = "@bundle//:bin/rubocop",
    tags = ["no-sandbox"],
    deps = [
        "//lib:gem",
        "@bundle",
    ],
)
```

```output
$ bazel test :rubocop
INFO: Analyzed target //:rubocop (0 packages loaded, 123 targets configured).
INFO: Found 1 test target...
Target //:rubocop up-to-date:
  bazel-bin/rubocop.rb.sh
INFO: Elapsed time: 0.875s, Critical Path: 0.79s
INFO: 2 processes: 2 local.
INFO: Build completed successfully, 2 total actions
//:rubocop                                                               PASSED in 0.8s

Executed 1 out of 1 test: 1 test passes.
```

Note that you can also `run` every test target passing extra arguments to
the Ruby script. For example, you can re-use `:rubocop` target to perform autocorrect:

```output
$ bazel run :rubocop -- --autocorrect-all
INFO: Analyzed target //:rubocop (0 packages loaded, 0 targets configured).
INFO: Found 1 target...
Target //:rubocop up-to-date:
  bazel-bin/rubocop.rb.sh
INFO: Elapsed time: 0.066s, Critical Path: 0.00s
INFO: 1 process: 1 internal.
INFO: Build completed successfully, 1 total action
INFO: Running command line: external/bazel_tools/tools/test/test-setup.sh ./rubocop.rb.sh --autocorrect-all
exec ${PAGER:-/usr/bin/less} "$0" || exit 1
Executing tests from //:rubocop
-----------------------------------------------------------------------------
Inspecting 11 files
.C.........

Offenses:

gem.gemspec:1:1: C: [Corrected] Style/FrozenStringLiteralComment: Missing frozen string literal comment.
root = File.expand_path(__dir__)
^
gem.gemspec:2:1: C: [Corrected] Layout/EmptyLineAfterMagicComment: Add an empty line after magic comments.
root = File.expand_path(__dir__)
^

11 files inspected, 2 offenses detected, 2 offenses corrected
```
*
nameA unique name for this target. F
data8List of non-Ruby source files used to build the library.2[]A
deps3List of other Ruby libraries the target depends on.2[];
env.Environment variables to use during execution.
2{}[
env_inheritFList of environment variable names to be inherited by the test runner.2[]�
main�
Ruby script to run. It may also be a binary stub generated by Bundler.
If omitted, it defaults to the Ruby interpreter.

Use a built-in `args` attribute to pass extra arguments to the script.
2NoneB
srcs4List of Ruby source files used to build the library.2[]".
rb_test#@@rules_ruby//ruby/private:test.bzl
,
*
nameA unique name for this target. H
F
data8List of non-Ruby source files used to build the library.2[]C
A
deps3List of other Ruby libraries the target depends on.2[]=
;
env.Environment variables to use during execution.
2{}]
[
env_inheritFList of environment variable names to be inherited by the test runner.2[]�
�
main�
Ruby script to run. It may also be a binary stub generated by Bundler.
If omitted, it defaults to the Ruby interpreter.

Use a built-in `args` attribute to pass extra arguments to the script.
2NoneD
B
srcs4List of Ruby source files used to build the library.2[]�
//ruby/private:binary.bzlr�
&

rules_rubyruby/private
binary.bzl
ATTRSATTRS
/4.
rb_binary_implrb_binary_impl
8F
H}
//ruby/private:library.bzlr]
'

rules_rubyruby/privatelibrary.bzl$
ATTRSLIBRARY_ATTRS
/<
G"Implementation details for rb_test��


rules_rubyrubydefs.bzl�7	rb_binary�
Runs a Ruby binary.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

One of the files can be run as a Ruby script:

`lib/gem/version.rb`:
```ruby
module GEM
  VERSION = '0.1.0'
end

puts "Version is: #{GEM::VERSION}" if __FILE__ == $PROGRAM_NAME
```

You can run this script by defining a target:

`lib/gem/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_binary", "rb_library")

rb_library(
    name = "version",
    srcs = ["version.rb"],
)

rb_binary(
    name = "print-version",
    args = ["lib/gem/version.rb"],
    deps = [":version"],
)
```

```output
$ bazel run lib/gem:print-version
INFO: Analyzed target //lib/gem:print-version (1 packages loaded, 3 targets configured).
INFO: Found 1 target...
Target //lib/gem:print-version up-to-date:
  bazel-bin/lib/gem/print-version.rb.sh
INFO: Elapsed time: 0.121s, Critical Path: 0.01s
INFO: 4 processes: 4 internal.
INFO: Build completed successfully, 4 total actions
INFO: Build completed successfully, 4 total actions
Version is: 0.1.0
```

You can also run general purpose Ruby scripts that rely on a Ruby interpreter in PATH:

`lib/gem/add.rb`:
```ruby
#!/usr/bin/env ruby

a, b = *ARGV
puts Integer(a) + Integer(b)
```

`lib/gem/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_binary", "rb_library")

rb_library(
    name = "add",
    srcs = ["add.rb"],
)

rb_binary(
    name = "add-numbers",
    main = "add.rb",
    deps = [":add"],
)
```

```output
$ bazel run lib/gem:add-numbers 1 2
INFO: Analyzed target //lib/gem:add-numbers (1 packages loaded, 3 targets configured).
INFO: Found 1 target...
Target //lib/gem:add-numbers up-to-date:
  bazel-bin/lib/gem/add-numbers.rb.sh
INFO: Elapsed time: 0.092s, Critical Path: 0.00s
INFO: 1 process: 1 internal.
INFO: Build completed successfully, 1 total action
INFO: Build completed successfully, 1 total action
3
```

You can also run a Ruby binary script available in Gemfile dependencies,
by passing `bin` argument with a path to a Bundler binary stub:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_binary")

package(default_visibility = ["//:__subpackages__"])

rb_binary(
    name = "rake",
    main = "@bundle//:bin/rake",
    deps = [
        "//lib:gem",
        "@bundle",
    ],
)
```

```output
$ bazel run :rake -- --version
INFO: Analyzed target //:rake (0 packages loaded, 0 targets configured).
INFO: Found 1 target...
Target //:rake up-to-date:
  bazel-bin/rake.rb.sh
INFO: Elapsed time: 0.073s, Critical Path: 0.00s
INFO: 1 process: 1 internal.
INFO: Build completed successfully, 1 total action
INFO: Running command line: bazel-bin/rake.rb.sh --version
rake, version 10.5.0
```
"�!
�
	rb_binary�
Runs a Ruby binary.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

One of the files can be run as a Ruby script:

`lib/gem/version.rb`:
```ruby
module GEM
  VERSION = '0.1.0'
end

puts "Version is: #{GEM::VERSION}" if __FILE__ == $PROGRAM_NAME
```

You can run this script by defining a target:

`lib/gem/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_binary", "rb_library")

rb_library(
    name = "version",
    srcs = ["version.rb"],
)

rb_binary(
    name = "print-version",
    args = ["lib/gem/version.rb"],
    deps = [":version"],
)
```

```output
$ bazel run lib/gem:print-version
INFO: Analyzed target //lib/gem:print-version (1 packages loaded, 3 targets configured).
INFO: Found 1 target...
Target //lib/gem:print-version up-to-date:
  bazel-bin/lib/gem/print-version.rb.sh
INFO: Elapsed time: 0.121s, Critical Path: 0.01s
INFO: 4 processes: 4 internal.
INFO: Build completed successfully, 4 total actions
INFO: Build completed successfully, 4 total actions
Version is: 0.1.0
```

You can also run general purpose Ruby scripts that rely on a Ruby interpreter in PATH:

`lib/gem/add.rb`:
```ruby
#!/usr/bin/env ruby

a, b = *ARGV
puts Integer(a) + Integer(b)
```

`lib/gem/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_binary", "rb_library")

rb_library(
    name = "add",
    srcs = ["add.rb"],
)

rb_binary(
    name = "add-numbers",
    main = "add.rb",
    deps = [":add"],
)
```

```output
$ bazel run lib/gem:add-numbers 1 2
INFO: Analyzed target //lib/gem:add-numbers (1 packages loaded, 3 targets configured).
INFO: Found 1 target...
Target //lib/gem:add-numbers up-to-date:
  bazel-bin/lib/gem/add-numbers.rb.sh
INFO: Elapsed time: 0.092s, Critical Path: 0.00s
INFO: 1 process: 1 internal.
INFO: Build completed successfully, 1 total action
INFO: Build completed successfully, 1 total action
3
```

You can also run a Ruby binary script available in Gemfile dependencies,
by passing `bin` argument with a path to a Bundler binary stub:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_binary")

package(default_visibility = ["//:__subpackages__"])

rb_binary(
    name = "rake",
    main = "@bundle//:bin/rake",
    deps = [
        "//lib:gem",
        "@bundle",
    ],
)
```

```output
$ bazel run :rake -- --version
INFO: Analyzed target //:rake (0 packages loaded, 0 targets configured).
INFO: Found 1 target...
Target //:rake up-to-date:
  bazel-bin/rake.rb.sh
INFO: Elapsed time: 0.073s, Critical Path: 0.00s
INFO: 1 process: 1 internal.
INFO: Build completed successfully, 1 total action
INFO: Running command line: bazel-bin/rake.rb.sh --version
rake, version 10.5.0
```
*
nameA unique name for this target. F
data8List of non-Ruby source files used to build the library.2[]A
deps3List of other Ruby libraries the target depends on.2[];
env.Environment variables to use during execution.
2{}[
env_inheritFList of environment variable names to be inherited by the test runner.2[]�
main�
Ruby script to run. It may also be a binary stub generated by Bundler.
If omitted, it defaults to the Ruby interpreter.

Use a built-in `args` attribute to pass extra arguments to the script.
2NoneB
srcs4List of Ruby source files used to build the library.2[]"(
	rb_binary@@rules_ruby//ruby:defs.bzl
��,
*
nameA unique name for this target. H
F
data8List of non-Ruby source files used to build the library.2[]C
A
deps3List of other Ruby libraries the target depends on.2[]=
;
env.Environment variables to use during execution.
2{}]
[
env_inheritFList of environment variable names to be inherited by the test runner.2[]�
�
main�
Ruby script to run. It may also be a binary stub generated by Bundler.
If omitted, it defaults to the Ruby interpreter.

Use a built-in `args` attribute to pass extra arguments to the script.
2NoneD
B
srcs4List of Ruby source files used to build the library.2[]�"rb_gem_build�
Builds a Ruby gem.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

And a RubyGem specification is:

`gem.gemspec`:
```ruby
root = File.expand_path(__dir__)
$LOAD_PATH.push(File.expand_path('lib', root))
require 'gem/version'

Gem::Specification.new do |s|
  s.name = 'example'
  s.version = GEM::VERSION

  s.authors = ['Foo Bar']
  s.email = ['foobar@gmail.com']
  s.homepage = 'http://rubygems.org'
  s.license = 'MIT'

  s.summary = 'Example'
  s.description = 'Example gem'
  s.files = ['Gemfile'] + Dir['lib/**/*']

  s.require_paths = ['lib']
  s.add_dependency 'rake', '~> 10'
  s.add_development_dependency 'rspec', '~> 3.0'
  s.add_development_dependency 'rubocop', '~> 1.10'
end
```

You can now package everything into a `.gem` file by defining a target:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_gem_build")

package(default_visibility = ["//:__subpackages__"])

rb_gem_build(
    name = "gem-build",
    gemspec = "gem.gemspec",
    deps = [
        "//lib:gem",
        "@bundle",
    ],
)
```

```output
$ bazel build :gem-build
INFO: Analyzed target //:gem-build (0 packages loaded, 0 targets configured).
INFO: Found 1 target...
INFO: From Action gem-build.gem:
  Successfully built RubyGem
  Name: example
  Version: 0.1.0
  File: example-0.1.0.gem
Target //:gem-build up-to-date:
  bazel-bin/gem-build.gem
INFO: Elapsed time: 0.196s, Critical Path: 0.10s
INFO: 2 processes: 1 internal, 1 darwin-sandbox.
INFO: Build completed successfully, 2 total actions
```
"�
�
rb_gem_build�
Builds a Ruby gem.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

And a RubyGem specification is:

`gem.gemspec`:
```ruby
root = File.expand_path(__dir__)
$LOAD_PATH.push(File.expand_path('lib', root))
require 'gem/version'

Gem::Specification.new do |s|
  s.name = 'example'
  s.version = GEM::VERSION

  s.authors = ['Foo Bar']
  s.email = ['foobar@gmail.com']
  s.homepage = 'http://rubygems.org'
  s.license = 'MIT'

  s.summary = 'Example'
  s.description = 'Example gem'
  s.files = ['Gemfile'] + Dir['lib/**/*']

  s.require_paths = ['lib']
  s.add_dependency 'rake', '~> 10'
  s.add_development_dependency 'rspec', '~> 3.0'
  s.add_development_dependency 'rubocop', '~> 1.10'
end
```

You can now package everything into a `.gem` file by defining a target:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_gem_build")

package(default_visibility = ["//:__subpackages__"])

rb_gem_build(
    name = "gem-build",
    gemspec = "gem.gemspec",
    deps = [
        "//lib:gem",
        "@bundle",
    ],
)
```

```output
$ bazel build :gem-build
INFO: Analyzed target //:gem-build (0 packages loaded, 0 targets configured).
INFO: Found 1 target...
INFO: From Action gem-build.gem:
  Successfully built RubyGem
  Name: example
  Version: 0.1.0
  File: example-0.1.0.gem
Target //:gem-build up-to-date:
  bazel-bin/gem-build.gem
INFO: Elapsed time: 0.196s, Critical Path: 0.10s
INFO: 2 processes: 1 internal, 1 darwin-sandbox.
INFO: Build completed successfully, 2 total actions
```
*
nameA unique name for this target. Z

bundle_envFList of bundle environment variables to set when building the library.
2{}F
data8List of non-Ruby source files used to build the library.2[]A
deps3List of other Ruby libraries the target depends on.2[]4
gemspec%Gemspec file to use for gem building. B
srcs4List of Ruby source files used to build the library.2[]"+
rb_gem_build@@rules_ruby//ruby:defs.bzl
OO,
*
nameA unique name for this target. \
Z

bundle_envFList of bundle environment variables to set when building the library.
2{}H
F
data8List of non-Ruby source files used to build the library.2[]C
A
deps3List of other Ruby libraries the target depends on.2[]6
4
gemspec%Gemspec file to use for gem building. D
B
srcs4List of Ruby source files used to build the library.2[]�rb_gem_push�

Pushes a built Ruby gem.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem and `rb_gem_build()` is used
to build a Ruby gem package from the sources.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

You can now release the built `.gem` file to RubyGems by defining a target:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_gem_build", "rb_gem_push")

package(default_visibility = ["//:__subpackages__"])

rb_gem_build(
    name = "gem-build",
    gemspec = "gem.gemspec",
    deps = ["//lib:gem"],
)

rb_gem_push(
    name = "gem-release",
    gem = ":gem-build",
)
```

```output
$ bazel run :gem-release
INFO: Analyzed target //:gem-release (3 packages loaded, 14 targets configured).
INFO: Found 1 target...
Target //:gem-release up-to-date:
  bazel-bin/gem-release.rb.sh
INFO: Elapsed time: 0.113s, Critical Path: 0.01s
INFO: 4 processes: 4 internal.
INFO: Build completed successfully, 4 total actions
INFO: Build completed successfully, 4 total actions
Pushing gem to https://rubygems.org...
Successfully registered gem: example (0.1.0)
```
"�
�
rb_gem_push�

Pushes a built Ruby gem.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem and `rb_gem_build()` is used
to build a Ruby gem package from the sources.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

You can now release the built `.gem` file to RubyGems by defining a target:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_gem_build", "rb_gem_push")

package(default_visibility = ["//:__subpackages__"])

rb_gem_build(
    name = "gem-build",
    gemspec = "gem.gemspec",
    deps = ["//lib:gem"],
)

rb_gem_push(
    name = "gem-release",
    gem = ":gem-build",
)
```

```output
$ bazel run :gem-release
INFO: Analyzed target //:gem-release (3 packages loaded, 14 targets configured).
INFO: Found 1 target...
Target //:gem-release up-to-date:
  bazel-bin/gem-release.rb.sh
INFO: Elapsed time: 0.113s, Critical Path: 0.01s
INFO: 4 processes: 4 internal.
INFO: Build completed successfully, 4 total actions
INFO: Build completed successfully, 4 total actions
Pushing gem to https://rubygems.org...
Successfully registered gem: example (0.1.0)
```
*
nameA unique name for this target. Z

bundle_envFList of bundle environment variables to set when building the library.
2{}F
data8List of non-Ruby source files used to build the library.2[]A
deps3List of other Ruby libraries the target depends on.2[];
env.Environment variables to use during execution.
2{}[
env_inheritFList of environment variable names to be inherited by the test runner.2[]k
gem`
Gem file to push to RubyGems. You would usually use an output of `rb_gem_build()` target here.
 B
srcs4List of Ruby source files used to build the library.2[]"*
rb_gem_push@@rules_ruby//ruby:defs.bzl
&&,
*
nameA unique name for this target. \
Z

bundle_envFList of bundle environment variables to set when building the library.
2{}H
F
data8List of non-Ruby source files used to build the library.2[]C
A
deps3List of other Ruby libraries the target depends on.2[]=
;
env.Environment variables to use during execution.
2{}]
[
env_inheritFList of environment variable names to be inherited by the test runner.2[]m
k
gem`
Gem file to push to RubyGems. You would usually use an output of `rb_gem_build()` target here.
 D
B
srcs4List of Ruby source files used to build the library.2[]�
rb_library�	
Defines a Ruby library.

Suppose you have the following Ruby gem:

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

You can define packages for the gem source files:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_library")

package(default_visibility = ["//:__subpackages__"])

rb_library(
    name = "gem",
    deps = ["//lib:gem"],
)
```

`lib/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_library")

package(default_visibility = ["//:__subpackages__"])

rb_library(
    name = "gem",
    srcs = ["gem.rb"],
    deps = [
        "//lib/gem:add",
        "//lib/gem:subtract",
        "//lib/gem:version",
    ],
)
```

`lib/gem/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_library")

package(default_visibility = ["//:__subpackages__"])

rb_library(
    name = "add",
    srcs = ["add.rb"],
)

rb_library(
    name = "subtract",
    srcs = ["subtract.rb"],
)

rb_library(
    name = "version",
    srcs = ["version.rb"],
)
```

Once the packages are defined, you can use them in other targets
such as `rb_gem_build()` to build a Ruby gem. See examples of
using other rules.
"�
�

rb_library�	
Defines a Ruby library.

Suppose you have the following Ruby gem:

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

You can define packages for the gem source files:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_library")

package(default_visibility = ["//:__subpackages__"])

rb_library(
    name = "gem",
    deps = ["//lib:gem"],
)
```

`lib/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_library")

package(default_visibility = ["//:__subpackages__"])

rb_library(
    name = "gem",
    srcs = ["gem.rb"],
    deps = [
        "//lib/gem:add",
        "//lib/gem:subtract",
        "//lib/gem:version",
    ],
)
```

`lib/gem/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_library")

package(default_visibility = ["//:__subpackages__"])

rb_library(
    name = "add",
    srcs = ["add.rb"],
)

rb_library(
    name = "subtract",
    srcs = ["subtract.rb"],
)

rb_library(
    name = "version",
    srcs = ["version.rb"],
)
```

Once the packages are defined, you can use them in other targets
such as `rb_gem_build()` to build a Ruby gem. See examples of
using other rules.
*
nameA unique name for this target. Z

bundle_envFList of bundle environment variables to set when building the library.
2{}F
data8List of non-Ruby source files used to build the library.2[]A
deps3List of other Ruby libraries the target depends on.2[]B
srcs4List of Ruby source files used to build the library.2[]")

rb_library@@rules_ruby//ruby:defs.bzl
((,
*
nameA unique name for this target. \
Z

bundle_envFList of bundle environment variables to set when building the library.
2{}H
F
data8List of non-Ruby source files used to build the library.2[]C
A
deps3List of other Ruby libraries the target depends on.2[]D
B
srcs4List of Ruby source files used to build the library.2[]�Drb_test�
Runs a Ruby test.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
|-- lib
|   |-- BUILD
|   |-- gem
|   |   |-- BUILD
|   |   |-- add.rb
|   |   |-- subtract.rb
|   |   `-- version.rb
|   `-- gem.rb
`-- spec
    |-- BUILD
    |-- add_spec.rb
    |-- spec_helper.rb
    `-- subtract_spec.rb
```

You can run all tests inside `spec/` by defining individual targets:

`spec/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_library", "rb_test")

rb_library(
    name = "spec_helper",
    srcs = ["spec_helper.rb"],
)

rb_test(
    name = "add",
    srcs = ["add_spec.rb"],
    args = ["spec/add_spec.rb"],
    main = "@bundle//:bin/rspec",
    deps = [
        ":spec_helper",
        "@bundle",
    ],
)

rb_test(
    name = "subtract",
    srcs = ["subtract_spec.rb"],
    args = ["spec/subtract_spec.rb"],
    main = "@bundle//:bin/rspec",
    deps = [
        ":spec_helper",
        "@bundle",
    ],
)
```

```output
$ bazel test spec/...
INFO: Analyzed 3 targets (22 packages loaded, 621 targets configured).
INFO: Found 1 target and 2 test targets...
INFO: Elapsed time: 2.354s, Critical Path: 0.49s
INFO: 9 processes: 5 internal, 4 darwin-sandbox.
INFO: Build completed successfully, 9 total actions
//spec:add                                                               PASSED in 0.4s
//spec:subtract                                                          PASSED in 0.4s

Executed 2 out of 2 tests: 2 tests pass.
```

Since `rb_test()` is a wrapper around `rb_binary()`, you can also use it to run
a Ruby binary script available in Gemfile dependencies, by passing `main`
argument with a path to a Bundler binary stub.

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_test")

package(default_visibility = ["//:__subpackages__"])

rb_test(
    name = "rubocop",
    args = ["lib/"],
    main = "@bundle//:bin/rubocop",
    tags = ["no-sandbox"],
    deps = [
        "//lib:gem",
        "@bundle",
    ],
)
```

```output
$ bazel test :rubocop
INFO: Analyzed target //:rubocop (0 packages loaded, 123 targets configured).
INFO: Found 1 test target...
Target //:rubocop up-to-date:
  bazel-bin/rubocop.rb.sh
INFO: Elapsed time: 0.875s, Critical Path: 0.79s
INFO: 2 processes: 2 local.
INFO: Build completed successfully, 2 total actions
//:rubocop                                                               PASSED in 0.8s

Executed 1 out of 1 test: 1 test passes.
```

Note that you can also `run` every test target passing extra arguments to
the Ruby script. For example, you can re-use `:rubocop` target to perform autocorrect:

```output
$ bazel run :rubocop -- --autocorrect-all
INFO: Analyzed target //:rubocop (0 packages loaded, 0 targets configured).
INFO: Found 1 target...
Target //:rubocop up-to-date:
  bazel-bin/rubocop.rb.sh
INFO: Elapsed time: 0.066s, Critical Path: 0.00s
INFO: 1 process: 1 internal.
INFO: Build completed successfully, 1 total action
INFO: Running command line: external/bazel_tools/tools/test/test-setup.sh ./rubocop.rb.sh --autocorrect-all
exec ${PAGER:-/usr/bin/less} "$0" || exit 1
Executing tests from //:rubocop
-----------------------------------------------------------------------------
Inspecting 11 files
.C.........

Offenses:

gem.gemspec:1:1: C: [Corrected] Style/FrozenStringLiteralComment: Missing frozen string literal comment.
root = File.expand_path(__dir__)
^
gem.gemspec:2:1: C: [Corrected] Layout/EmptyLineAfterMagicComment: Add an empty line after magic comments.
root = File.expand_path(__dir__)
^

11 files inspected, 2 offenses detected, 2 offenses corrected
```
"�'
�"
rb_test�
Runs a Ruby test.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
|-- lib
|   |-- BUILD
|   |-- gem
|   |   |-- BUILD
|   |   |-- add.rb
|   |   |-- subtract.rb
|   |   `-- version.rb
|   `-- gem.rb
`-- spec
    |-- BUILD
    |-- add_spec.rb
    |-- spec_helper.rb
    `-- subtract_spec.rb
```

You can run all tests inside `spec/` by defining individual targets:

`spec/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_library", "rb_test")

rb_library(
    name = "spec_helper",
    srcs = ["spec_helper.rb"],
)

rb_test(
    name = "add",
    srcs = ["add_spec.rb"],
    args = ["spec/add_spec.rb"],
    main = "@bundle//:bin/rspec",
    deps = [
        ":spec_helper",
        "@bundle",
    ],
)

rb_test(
    name = "subtract",
    srcs = ["subtract_spec.rb"],
    args = ["spec/subtract_spec.rb"],
    main = "@bundle//:bin/rspec",
    deps = [
        ":spec_helper",
        "@bundle",
    ],
)
```

```output
$ bazel test spec/...
INFO: Analyzed 3 targets (22 packages loaded, 621 targets configured).
INFO: Found 1 target and 2 test targets...
INFO: Elapsed time: 2.354s, Critical Path: 0.49s
INFO: 9 processes: 5 internal, 4 darwin-sandbox.
INFO: Build completed successfully, 9 total actions
//spec:add                                                               PASSED in 0.4s
//spec:subtract                                                          PASSED in 0.4s

Executed 2 out of 2 tests: 2 tests pass.
```

Since `rb_test()` is a wrapper around `rb_binary()`, you can also use it to run
a Ruby binary script available in Gemfile dependencies, by passing `main`
argument with a path to a Bundler binary stub.

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_test")

package(default_visibility = ["//:__subpackages__"])

rb_test(
    name = "rubocop",
    args = ["lib/"],
    main = "@bundle//:bin/rubocop",
    tags = ["no-sandbox"],
    deps = [
        "//lib:gem",
        "@bundle",
    ],
)
```

```output
$ bazel test :rubocop
INFO: Analyzed target //:rubocop (0 packages loaded, 123 targets configured).
INFO: Found 1 test target...
Target //:rubocop up-to-date:
  bazel-bin/rubocop.rb.sh
INFO: Elapsed time: 0.875s, Critical Path: 0.79s
INFO: 2 processes: 2 local.
INFO: Build completed successfully, 2 total actions
//:rubocop                                                               PASSED in 0.8s

Executed 1 out of 1 test: 1 test passes.
```

Note that you can also `run` every test target passing extra arguments to
the Ruby script. For example, you can re-use `:rubocop` target to perform autocorrect:

```output
$ bazel run :rubocop -- --autocorrect-all
INFO: Analyzed target //:rubocop (0 packages loaded, 0 targets configured).
INFO: Found 1 target...
Target //:rubocop up-to-date:
  bazel-bin/rubocop.rb.sh
INFO: Elapsed time: 0.066s, Critical Path: 0.00s
INFO: 1 process: 1 internal.
INFO: Build completed successfully, 1 total action
INFO: Running command line: external/bazel_tools/tools/test/test-setup.sh ./rubocop.rb.sh --autocorrect-all
exec ${PAGER:-/usr/bin/less} "$0" || exit 1
Executing tests from //:rubocop
-----------------------------------------------------------------------------
Inspecting 11 files
.C.........

Offenses:

gem.gemspec:1:1: C: [Corrected] Style/FrozenStringLiteralComment: Missing frozen string literal comment.
root = File.expand_path(__dir__)
^
gem.gemspec:2:1: C: [Corrected] Layout/EmptyLineAfterMagicComment: Add an empty line after magic comments.
root = File.expand_path(__dir__)
^

11 files inspected, 2 offenses detected, 2 offenses corrected
```
*
nameA unique name for this target. F
data8List of non-Ruby source files used to build the library.2[]A
deps3List of other Ruby libraries the target depends on.2[];
env.Environment variables to use during execution.
2{}[
env_inheritFList of environment variable names to be inherited by the test runner.2[]�
main�
Ruby script to run. It may also be a binary stub generated by Bundler.
If omitted, it defaults to the Ruby interpreter.

Use a built-in `args` attribute to pass extra arguments to the script.
2NoneB
srcs4List of Ruby source files used to build the library.2[]"&
rb_test@@rules_ruby//ruby:defs.bzl
,
*
nameA unique name for this target. H
F
data8List of non-Ruby source files used to build the library.2[]C
A
deps3List of other Ruby libraries the target depends on.2[]=
;
env.Environment variables to use during execution.
2{}]
[
env_inheritFList of environment variable names to be inherited by the test runner.2[]�
�
main�
Ruby script to run. It may also be a binary stub generated by Bundler.
If omitted, it defaults to the Ruby interpreter.

Use a built-in `args` attribute to pass extra arguments to the script.
2NoneD
B
srcs4List of Ruby source files used to build the library.2[]|
//ruby/private:binary.bzlr]
&

rules_rubyruby/private
binary.bzl%
	rb_binary
_rb_binary
.8
G�
//ruby/private:gem_build.bzlrf
)

rules_rubyruby/privategem_build.bzl+
rb_gem_build_rb_gem_build
1>
P�
//ruby/private:gem_push.bzlrc
(

rules_rubyruby/privategem_push.bzl)
rb_gem_push_rb_gem_push
0<
M�
//ruby/private:library.bzlr`
'

rules_rubyruby/privatelibrary.bzl'

rb_library_rb_library
/:
Jt
//ruby/private:test.bzlrW
$

rules_rubyruby/privatetest.bzl!
rb_test_rb_test
,4
APublic API for rules�(


rules_rubyrubydeps.bzl�	rb_bundle:Wraps `rb_bundle_rule()` providing default toolchain name.*�
�
	rb_bundleG
	toolchaindefault Ruby toolchain BUILD"@rules_ruby_dist//:BUILD"(7
kwargs+underlying attrs passed to rb_bundle_rule()(:Wraps `rb_bundle_rule()` providing default toolchain name.2(
	rb_bundle@@rules_ruby//ruby:deps.bzl
*
_rb_bundle�rb_register_toolchains�Register a Ruby toolchain and lazily download the Ruby Interpreter.

* _(For MRI on Linux and macOS)_ Installed using [ruby-build](https://github.com/rbenv/ruby-build).
* _(For MRI on Windows)_ Installed using [RubyInstaller](https://rubyinstaller.org).
* _(For JRuby on any OS)_ Downloaded and installed directly from [official website](https://www.jruby.org).
* _(For TruffleRuby on Linux and macOS)_ Installed using [ruby-build](https://github.com/rbenv/ruby-build).

`WORKSPACE`:
```bazel
load("@rules_ruby//ruby:deps.bzl", "rb_download")

rb_register_toolchains(
    version = "2.7.5"
)
```
*�
�
rb_register_toolchainsT
name<base name of resulting repositories, by default "rules_ruby""rules_ruby"(k
versionXa semver version of Matz Ruby Interpreter, or a string like [interpreter type]-[version]None(^
registerJwhether to register the resulting toolchains, should be False under bzlmodTrue(M
kwargsAadditional parameters to the downloader for this interpreter type(�Register a Ruby toolchain and lazily download the Ruby Interpreter.

* _(For MRI on Linux and macOS)_ Installed using [ruby-build](https://github.com/rbenv/ruby-build).
* _(For MRI on Windows)_ Installed using [RubyInstaller](https://rubyinstaller.org).
* _(For JRuby on any OS)_ Downloaded and installed directly from [official website](https://www.jruby.org).
* _(For TruffleRuby on Linux and macOS)_ Installed using [ruby-build](https://github.com/rbenv/ruby-build).

`WORKSPACE`:
```bazel
load("@rules_ruby//ruby:deps.bzl", "rb_download")

rb_register_toolchains(
    version = "2.7.5"
)
```
2A
rb_register_toolchains'@@rules_ruby//ruby/private:download.bzl
*_rb_download�rb_bundle_rule�
Installs Bundler dependencies and registers an external repository
that can be used by other targets.

`WORKSPACE`:
```bazel
load("@rules_ruby//ruby:deps.bzl", "rb_bundle")

rb_bundle(
    name = "bundle",
    gemfile = "//:Gemfile",
    srcs = [
        "//:gem.gemspec",
        "//:lib/gem/version.rb",
    ]
)
```

All the installed gems can be accessed using `@bundle` target and additionally
gems binary files can also be used:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_binary")

package(default_visibility = ["//:__subpackages__"])

rb_binary(
    name = "rubocop",
    main = "@bundle//:bin/rubocop",
    deps = ["@bundle"],
)
```
R�
�
rb_bundle_rule�
Installs Bundler dependencies and registers an external repository
that can be used by other targets.

`WORKSPACE`:
```bazel
load("@rules_ruby//ruby:deps.bzl", "rb_bundle")

rb_bundle(
    name = "bundle",
    gemfile = "//:Gemfile",
    srcs = [
        "//:gem.gemspec",
        "//:lib/gem/version.rb",
    ]
)
```

All the installed gems can be accessed using `@bundle` target and additionally
gems binary files can also be used:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_binary")

package(default_visibility = ["//:__subpackages__"])

rb_binary(
    name = "rubocop",
    main = "@bundle//:bin/rubocop",
    deps = ["@bundle"],
)
```
.
name"A unique name for this repository. >
env1Environment variables to use during installation.
2{}:
gemfile'
Gemfile to install dependencies from.
2None�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 D
srcs6
List of Ruby source files used to build the library.
2[]
	toolchain *-
rb_bundle_rule@@rules_ruby//ruby:deps.bzl
HH0
.
name"A unique name for this repository. @
>
env1Environment variables to use during installation.
2{}<
:
gemfile'
Gemfile to install dependencies from.
2None�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 F
D
srcs6
List of Ruby source files used to build the library.
2[]

	toolchain |
//ruby/private:bundle.bzlr]
&

rules_rubyruby/private
bundle.bzl%
	rb_bundle
_rb_bundle
.8
G�
//ruby/private:download.bzlry
(

rules_rubyruby/privatedownload.bzl?
rb_register_toolchains_rb_register_toolchains
0G
cPublic API for repository rules�

"

rules_rubyrubyextensions.bzl�rubyJ�
�
ruby�
bundle6
name(Resulting repository name for the bundle2""
env
2{}
gemfile2None
srcs2[]
	toolchain2None�
	toolchainW
nameIBase name for generated repositories, allowing multiple to be registered.2""*
versionExplicit version of ruby.2""")
ruby!@@rules_ruby//ruby:extensions.bzl
77�
�
bundle6
name(Resulting repository name for the bundle2""
env
2{}
gemfile2None
srcs2[]
	toolchain2None8
6
name(Resulting repository name for the bundle2""

env
2{}

gemfile2None

srcs2[]

	toolchain2None�
�
	toolchainW
nameIBase name for generated repositories, allowing multiple to be registered.2""*
versionExplicit version of ruby.2""Y
W
nameIBase name for generated repositories, allowing multiple to be registered.2"",
*
versionExplicit version of ruby.2""�
//ruby:deps.bzlr�


rules_rubyrubydeps.bzl$
	rb_bundle	rb_bundle
%.>
rb_register_toolchainsrb_register_toolchains
2H
J�
//ruby/private:download.bzlrz
(

rules_rubyruby/privatedownload.bzl@
DEFAULT_RUBY_REPOSITORYDEFAULT_RUBY_REPOSITORY
1H
J Module extensions used by bzlmod�
!

rules_rubyrubytoolchain.bzl�rb_toolchain"�
�
rb_toolchain*
nameA unique name for this target. +
bindirPath to Ruby bin/ directory2""%
bundle`bundle` to execute2None
gem`gem` to execute2None(
ruby`ruby` binary to execute2None
versionRuby version2"""0
rb_toolchain @@rules_ruby//ruby:toolchain.bzl
,
*
nameA unique name for this target. -
+
bindirPath to Ruby bin/ directory2""'
%
bundle`bundle` to execute2None!

gem`gem` to execute2None*
(
ruby`ruby` binary to execute2None

versionRuby version2""/Define a Bazel toolchain for a Ruby interpreter 