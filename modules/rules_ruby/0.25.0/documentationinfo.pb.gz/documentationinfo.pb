�
railsrails_test_factory.bzl�"rails_test_factory.new_system_test;Create a `rails_system_test` macro for a Rails application.*�
�
"rails_test_factory.new_system_test�
test_package�Optional. The name of the package that contains the test
helpers. For example, if the Rails app is rooted in the `foo`
directory, the test package is typically `foo/test`.None(z
application_system_test_caseROptional. The label for the Rails
application's `application_system_test_case.rb`.None(p
default_includesTOptional. A `list` of Ruby includes that should be
part of the Ruby test invocation.None(j
default_sizeOOptional. The default test size for the tests created with
the resulting macro."large"(\
tagsBOptional. A `list` of tags that are added to the test declaration.["no-sandbox"](;Create a `rails_system_test` macro for a Rails application."^
\A Bazel macro function that defines Rails system test targets using the
provided attributes.2:
_new_system_test&//rails/private:rails_test_factory.bzl�
�
test_package�Optional. The name of the package that contains the test
helpers. For example, if the Rails app is rooted in the `foo`
directory, the test package is typically `foo/test`.None(|
z
application_system_test_caseROptional. The label for the Rails
application's `application_system_test_case.rb`.None(r
p
default_includesTOptional. A `list` of Ruby includes that should be
part of the Ruby test invocation.None(l
j
default_sizeOOptional. The default test size for the tests created with
the resulting macro."large"(^
\
tagsBOptional. A `list` of tags that are added to the test declaration.["no-sandbox"](�rails_test_factory.new_test�Create a `rails_test` macro for a Rails application.

The resulting macro encapsulates the application-specific attributes for the
resulting test target.
*�
�
rails_test_factory.new_test�
test_package�Optional. The name of the package that contains the test
helpers. For example, if the Rails app is rooted in the `foo`
directory, the test package is typically `foo/test`.None(N
test_helper7The label for the Rails application's `test_helper.rb`.None(p
default_includesTOptional. A `list` of Ruby includes that should be
part of the Ruby test invocation.None(j
default_sizeOOptional. The default test size for the tests created with
the resulting macro."small"(P
tagsBOptional. A `list` of tags that are added to the test declaration.[](�Create a `rails_test` macro for a Rails application.

The resulting macro encapsulates the application-specific attributes for the
resulting test target.
"W
UA Bazel macro function that defines Rails test targets using the
provided attributes.23
	_new_test&//rails/private:rails_test_factory.bzl�
�
test_package�Optional. The name of the package that contains the test
helpers. For example, if the Rails app is rooted in the `foo`
directory, the test package is typically `foo/test`.None(P
N
test_helper7The label for the Rails application's `test_helper.rb`.None(r
p
default_includesTOptional. A `list` of Ruby includes that should be
part of the Ruby test invocation.None(l
j
default_sizeOOptional. The default test size for the tests created with
the resulting macro."small"(R
P
tagsBOptional. A `list` of tags that are added to the test declaration.[](+Public definition for `rails_test_factory`.��
rubydefs.bzl�,	rb_binary�Runs a Ruby binary.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

One of the files can be run as a Ruby script:

`lib/gem/version.rb`:
```ruby
module GEM
  VERSION = '0.1.0'
end

puts "Version is: #{GEM::VERSION}" if __FILE__ == $PROGRAM_NAME
```

You can run this script by defining a target:

`lib/gem/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_binary", "rb_library")

rb_library(
    name = "version",
    srcs = ["version.rb"],
)

rb_binary(
    name = "print-version",
    args = ["lib/gem/version.rb"],
    deps = [":version"],
)
```

```output
$ bazel run lib/gem:print-version
...
Version is: 0.1.0
```

You can also run general purpose Ruby scripts that rely on a Ruby interpreter in PATH:

`lib/gem/add.rb`:
```ruby
#!/usr/bin/env ruby

a, b = *ARGV
puts Integer(a) + Integer(b)
```

`lib/gem/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_binary", "rb_library")

rb_library(
    name = "add",
    srcs = ["add.rb"],
)

rb_binary(
    name = "add-numbers",
    main = "add.rb",
    deps = [":add"],
)
```

```output
$ bazel run lib/gem:add-numbers 1 2
...
3
```

You can also run a Ruby binary script available in Gemfile dependencies,
by passing `bin` argument with a path to a Bundler binary stub:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_binary")

package(default_visibility = ["//:__subpackages__"])

rb_binary(
    name = "rake",
    main = "@bundle//bin:rake",
    deps = [
        "//lib:gem",
        "@bundle",
    ],
)
```

```output
$ bazel run :rake -- --version
...
rake, version 13.1.0
```"�
�
	rb_binary�Runs a Ruby binary.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

One of the files can be run as a Ruby script:

`lib/gem/version.rb`:
```ruby
module GEM
  VERSION = '0.1.0'
end

puts "Version is: #{GEM::VERSION}" if __FILE__ == $PROGRAM_NAME
```

You can run this script by defining a target:

`lib/gem/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_binary", "rb_library")

rb_library(
    name = "version",
    srcs = ["version.rb"],
)

rb_binary(
    name = "print-version",
    args = ["lib/gem/version.rb"],
    deps = [":version"],
)
```

```output
$ bazel run lib/gem:print-version
...
Version is: 0.1.0
```

You can also run general purpose Ruby scripts that rely on a Ruby interpreter in PATH:

`lib/gem/add.rb`:
```ruby
#!/usr/bin/env ruby

a, b = *ARGV
puts Integer(a) + Integer(b)
```

`lib/gem/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_binary", "rb_library")

rb_library(
    name = "add",
    srcs = ["add.rb"],
)

rb_binary(
    name = "add-numbers",
    main = "add.rb",
    deps = [":add"],
)
```

```output
$ bazel run lib/gem:add-numbers 1 2
...
3
```

You can also run a Ruby binary script available in Gemfile dependencies,
by passing `bin` argument with a path to a Bundler binary stub:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_binary")

package(default_visibility = ["//:__subpackages__"])

rb_binary(
    name = "rake",
    main = "@bundle//bin:rake",
    deps = [
        "//lib:gem",
        "@bundle",
    ],
)
```

```output
$ bazel run :rake -- --version
...
rake, version 13.1.0
```*
nameA unique name for this target. �
main�Ruby script to run. It may also be a binary stub generated by Bundler.
If omitted, it defaults to the Ruby interpreter.

Use a built-in `args` attribute to pass extra arguments to the script.2None�
env|Environment variables to use during execution.

Supports `$(location)` expansion for targets from `srcs`, `data` and `deps`.
2{}[
env_inheritFList of environment variable names to be inherited by the test runner.2[]s
ruby7Override Ruby toolchain to use when running the script.**
ToolchainInfo
ToolchainInfo<native>2Nonep
coverage_filtersVAdditional coverage filters to add to SimpleCov. Only applied during 'bazel coverage'.2[]B
srcs4List of Ruby source files used to build the library.2[]\
dataNList of runtime dependencies needed by a program that depends on this library.2[]A
deps3List of other Ruby libraries the target depends on.2[]"&
	rb_binary//ruby/private:binary.bzl8,
*
nameA unique name for this target. �
�
main�Ruby script to run. It may also be a binary stub generated by Bundler.
If omitted, it defaults to the Ruby interpreter.

Use a built-in `args` attribute to pass extra arguments to the script.2None�
�
env|Environment variables to use during execution.

Supports `$(location)` expansion for targets from `srcs`, `data` and `deps`.
2{}]
[
env_inheritFList of environment variable names to be inherited by the test runner.2[]u
s
ruby7Override Ruby toolchain to use when running the script.**
ToolchainInfo
ToolchainInfo<native>2Noner
p
coverage_filtersVAdditional coverage filters to add to SimpleCov. Only applied during 'bazel coverage'.2[]D
B
srcs4List of Ruby source files used to build the library.2[]^
\
dataNList of runtime dependencies needed by a program that depends on this library.2[]C
A
deps3List of other Ruby libraries the target depends on.2[]�rb_bundle_install�Installs Bundler dependencies from cached gems.

You normally don't need to call this rule directly as it's an internal one
used by `rb_bundle_fetch()`."�
�
rb_bundle_install�Installs Bundler dependencies from cached gems.

You normally don't need to call this rule directly as it's an internal one
used by `rb_bundle_fetch()`.*
nameA unique name for this target. 4
gemfile%Gemfile to install dependencies from. >
gemfile_lock*Gemfile.lock to install dependencies from. T
gemsHList of gems in vendor/cache that are used to install dependencies from. .
jars JAR dependencies for JRuby gems.2[]X
	jars_pathEPath to the directory containing JAR dependencies (set as JARS_HOME).2""B
srcs4List of Ruby source files used to build the library.2[]>
env1Environment variables to use during installation.
2{}s
ruby7Override Ruby toolchain to use when installing the gem.**
ToolchainInfo
ToolchainInfo<native>2None"6
rb_bundle_install!//ruby/private:bundle_install.bzl,
*
nameA unique name for this target. 6
4
gemfile%Gemfile to install dependencies from. @
>
gemfile_lock*Gemfile.lock to install dependencies from. V
T
gemsHList of gems in vendor/cache that are used to install dependencies from. 0
.
jars JAR dependencies for JRuby gems.2[]Z
X
	jars_pathEPath to the directory containing JAR dependencies (set as JARS_HOME).2""D
B
srcs4List of Ruby source files used to build the library.2[]@
>
env1Environment variables to use during installation.
2{}u
s
ruby7Override Ruby toolchain to use when installing the gem.**
ToolchainInfo
ToolchainInfo<native>2None�rb_gem�Exposes a Ruby gem file.

You normally don't need to call this rule directly as it's an internal one
used by `rb_bundle_fetch()`."�
�
rb_gem�Exposes a Ruby gem file.

You normally don't need to call this rule directly as it's an internal one
used by `rb_bundle_fetch()`.*
nameA unique name for this target. 
gem	Gem file. " 
rb_gem//ruby/private:gem.bzl,
*
nameA unique name for this target. 

gem	Gem file. �rb_gem_build�Builds a Ruby gem.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

And a RubyGem specification is:

`gem.gemspec`:
```ruby
root = File.expand_path(__dir__)
$LOAD_PATH.push(File.expand_path('lib', root))
require 'gem/version'

Gem::Specification.new do |s|
  s.name = 'example'
  s.version = GEM::VERSION

  s.authors = ['Foo Bar']
  s.email = ['foobar@gmail.com']
  s.homepage = 'http://rubygems.org'
  s.license = 'MIT'

  s.summary = 'Example'
  s.description = 'Example gem'
  s.files = ['Gemfile'] + Dir['lib/**/*']

  s.require_paths = ['lib']
  s.add_dependency 'rake', '~> 10'
  s.add_development_dependency 'rspec', '~> 3.0'
  s.add_development_dependency 'rubocop', '~> 1.10'
end
```

You can now package everything into a `.gem` file by defining a target:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_gem_build")

package(default_visibility = ["//:__subpackages__"])

rb_gem_build(
    name = "gem-build",
    gemspec = "gem.gemspec",
    deps = [
        "//lib:gem",
        "@bundle",
    ],
)
```

```output
$ bazel build :gem-build
...
  Successfully built RubyGem
  Name: example
  Version: 0.1.0
  File: example-0.1.0.gem
...
```"�
�
rb_gem_build�Builds a Ruby gem.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

And a RubyGem specification is:

`gem.gemspec`:
```ruby
root = File.expand_path(__dir__)
$LOAD_PATH.push(File.expand_path('lib', root))
require 'gem/version'

Gem::Specification.new do |s|
  s.name = 'example'
  s.version = GEM::VERSION

  s.authors = ['Foo Bar']
  s.email = ['foobar@gmail.com']
  s.homepage = 'http://rubygems.org'
  s.license = 'MIT'

  s.summary = 'Example'
  s.description = 'Example gem'
  s.files = ['Gemfile'] + Dir['lib/**/*']

  s.require_paths = ['lib']
  s.add_dependency 'rake', '~> 10'
  s.add_development_dependency 'rspec', '~> 3.0'
  s.add_development_dependency 'rubocop', '~> 1.10'
end
```

You can now package everything into a `.gem` file by defining a target:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_gem_build")

package(default_visibility = ["//:__subpackages__"])

rb_gem_build(
    name = "gem-build",
    gemspec = "gem.gemspec",
    deps = [
        "//lib:gem",
        "@bundle",
    ],
)
```

```output
$ bazel build :gem-build
...
  Successfully built RubyGem
  Name: example
  Version: 0.1.0
  File: example-0.1.0.gem
...
```*
nameA unique name for this target. B
srcs4List of Ruby source files used to build the library.2[]A
deps3List of other Ruby libraries the target depends on.2[]\
dataNList of runtime dependencies needed by a program that depends on this library.2[]Z

bundle_envFList of bundle environment variables to set when building the library.
2{}s
ruby7Override Ruby toolchain to use when running the script.**
ToolchainInfo
ToolchainInfo<native>2None4
gemspec%Gemspec file to use for gem building. ",
rb_gem_build//ruby/private:gem_build.bzl,
*
nameA unique name for this target. D
B
srcs4List of Ruby source files used to build the library.2[]C
A
deps3List of other Ruby libraries the target depends on.2[]^
\
dataNList of runtime dependencies needed by a program that depends on this library.2[]\
Z

bundle_envFList of bundle environment variables to set when building the library.
2{}u
s
ruby7Override Ruby toolchain to use when running the script.**
ToolchainInfo
ToolchainInfo<native>2None6
4
gemspec%Gemspec file to use for gem building. �rb_gem_install�Installs a built Ruby gem.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem and `rb_gem_build()` is used
to build a Ruby gem package from the sources.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

You can now install the built `.gem` file by defining a target:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_gem_build", "rb_gem_install")

package(default_visibility = ["//:__subpackages__"])

rb_gem_build(
    name = "gem-build",
    gemspec = "gem.gemspec",
    deps = ["//lib:gem"],
)

rb_gem_install(
    name = "gem-install",
    gem = ":gem-build",
)
```

```output
$ bazel build :gem-install
...
Successfully installed example-0.1.0
1 gem installed
...
```"�

�	
rb_gem_install�Installs a built Ruby gem.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem and `rb_gem_build()` is used
to build a Ruby gem package from the sources.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

You can now install the built `.gem` file by defining a target:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_gem_build", "rb_gem_install")

package(default_visibility = ["//:__subpackages__"])

rb_gem_build(
    name = "gem-build",
    gemspec = "gem.gemspec",
    deps = ["//lib:gem"],
)

rb_gem_install(
    name = "gem-install",
    gem = ":gem-build",
)
```

```output
$ bazel build :gem-install
...
Successfully installed example-0.1.0
1 gem installed
...
```*
nameA unique name for this target. 
gemGem file to install. s
ruby7Override Ruby toolchain to use when installing the gem.**
ToolchainInfo
ToolchainInfo<native>2None"0
rb_gem_install//ruby/private:gem_install.bzl,
*
nameA unique name for this target. !

gemGem file to install. u
s
ruby7Override Ruby toolchain to use when installing the gem.**
ToolchainInfo
ToolchainInfo<native>2None�rb_gem_push�Pushes a built Ruby gem.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem and `rb_gem_build()` is used
to build a Ruby gem package from the sources.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

You can now release the built `.gem` file to RubyGems by defining a target:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_gem_build", "rb_gem_push")

package(default_visibility = ["//:__subpackages__"])

rb_gem_build(
    name = "gem-build",
    gemspec = "gem.gemspec",
    deps = ["//lib:gem"],
)

rb_gem_push(
    name = "gem-release",
    gem = ":gem-build",
)
```

```output
$ bazel run :gem-release
...
Pushing gem to https://rubygems.org...
Successfully registered gem: example (0.1.0)
```"�
�
rb_gem_push�Pushes a built Ruby gem.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem and `rb_gem_build()` is used
to build a Ruby gem package from the sources.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

You can now release the built `.gem` file to RubyGems by defining a target:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_gem_build", "rb_gem_push")

package(default_visibility = ["//:__subpackages__"])

rb_gem_build(
    name = "gem-build",
    gemspec = "gem.gemspec",
    deps = ["//lib:gem"],
)

rb_gem_push(
    name = "gem-release",
    gem = ":gem-build",
)
```

```output
$ bazel run :gem-release
...
Pushing gem to https://rubygems.org...
Successfully registered gem: example (0.1.0)
```*
nameA unique name for this target. B
srcs4List of Ruby source files used to build the library.2[]A
deps3List of other Ruby libraries the target depends on.2[]\
dataNList of runtime dependencies needed by a program that depends on this library.2[]Z

bundle_envFList of bundle environment variables to set when building the library.
2{}i
gem^Gem file to push to RubyGems. You would usually use an output of `rb_gem_build()` target here. �
env|Environment variables to use during execution.

Supports `$(location)` expansion for targets from `srcs`, `data` and `deps`.
2{}[
env_inheritFList of environment variable names to be inherited by the test runner.2[]s
ruby7Override Ruby toolchain to use when running the script.**
ToolchainInfo
ToolchainInfo<native>2None"*
rb_gem_push//ruby/private:gem_push.bzl8,
*
nameA unique name for this target. D
B
srcs4List of Ruby source files used to build the library.2[]C
A
deps3List of other Ruby libraries the target depends on.2[]^
\
dataNList of runtime dependencies needed by a program that depends on this library.2[]\
Z

bundle_envFList of bundle environment variables to set when building the library.
2{}k
i
gem^Gem file to push to RubyGems. You would usually use an output of `rb_gem_build()` target here. �
�
env|Environment variables to use during execution.

Supports `$(location)` expansion for targets from `srcs`, `data` and `deps`.
2{}]
[
env_inheritFList of environment variable names to be inherited by the test runner.2[]u
s
ruby7Override Ruby toolchain to use when running the script.**
ToolchainInfo
ToolchainInfo<native>2None�
rb_library�	Defines a Ruby library.

Suppose you have the following Ruby gem:

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

You can define packages for the gem source files:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_library")

package(default_visibility = ["//:__subpackages__"])

rb_library(
    name = "gem",
    deps = ["//lib:gem"],
)
```

`lib/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_library")

package(default_visibility = ["//:__subpackages__"])

rb_library(
    name = "gem",
    srcs = ["gem.rb"],
    deps = [
        "//lib/gem:add",
        "//lib/gem:subtract",
        "//lib/gem:version",
    ],
)
```

`lib/gem/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_library")

package(default_visibility = ["//:__subpackages__"])

rb_library(
    name = "add",
    srcs = ["add.rb"],
)

rb_library(
    name = "subtract",
    srcs = ["subtract.rb"],
)

rb_library(
    name = "version",
    srcs = ["version.rb"],
)
```

Once the packages are defined, you can use them in other targets
such as `rb_gem_build()` to build a Ruby gem. See examples of
using other rules."�
�

rb_library�	Defines a Ruby library.

Suppose you have the following Ruby gem:

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

You can define packages for the gem source files:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_library")

package(default_visibility = ["//:__subpackages__"])

rb_library(
    name = "gem",
    deps = ["//lib:gem"],
)
```

`lib/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_library")

package(default_visibility = ["//:__subpackages__"])

rb_library(
    name = "gem",
    srcs = ["gem.rb"],
    deps = [
        "//lib/gem:add",
        "//lib/gem:subtract",
        "//lib/gem:version",
    ],
)
```

`lib/gem/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_library")

package(default_visibility = ["//:__subpackages__"])

rb_library(
    name = "add",
    srcs = ["add.rb"],
)

rb_library(
    name = "subtract",
    srcs = ["subtract.rb"],
)

rb_library(
    name = "version",
    srcs = ["version.rb"],
)
```

Once the packages are defined, you can use them in other targets
such as `rb_gem_build()` to build a Ruby gem. See examples of
using other rules.*
nameA unique name for this target. B
srcs4List of Ruby source files used to build the library.2[]A
deps3List of other Ruby libraries the target depends on.2[]\
dataNList of runtime dependencies needed by a program that depends on this library.2[]Z

bundle_envFList of bundle environment variables to set when building the library.
2{}"(

rb_library//ruby/private:library.bzl,
*
nameA unique name for this target. D
B
srcs4List of Ruby source files used to build the library.2[]C
A
deps3List of other Ruby libraries the target depends on.2[]^
\
dataNList of runtime dependencies needed by a program that depends on this library.2[]\
Z

bundle_envFList of bundle environment variables to set when building the library.
2{}�<rb_test�Runs a Ruby test.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
|-- lib
|   |-- BUILD
|   |-- gem
|   |   |-- BUILD
|   |   |-- add.rb
|   |   |-- subtract.rb
|   |   `-- version.rb
|   `-- gem.rb
`-- spec
    |-- BUILD
    |-- add_spec.rb
    |-- spec_helper.rb
    `-- subtract_spec.rb
```

You can run all tests inside `spec/` by defining individual targets:

`spec/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_library", "rb_test")

rb_library(
    name = "spec_helper",
    srcs = ["spec_helper.rb"],
)

rb_test(
    name = "add",
    srcs = ["add_spec.rb"],
    args = ["spec/add_spec.rb"],
    main = "@bundle//bin:rspec",
    deps = [
        ":spec_helper",
        "@bundle",
    ],
)

rb_test(
    name = "subtract",
    srcs = ["subtract_spec.rb"],
    args = ["spec/subtract_spec.rb"],
    main = "@bundle//bin:rspec",
    deps = [
        ":spec_helper",
        "@bundle",
    ],
)
```

```output
$ bazel test spec/...
...
//spec:add                                                               PASSED in 0.4s
//spec:subtract                                                          PASSED in 0.4s

Executed 2 out of 2 tests: 2 tests pass.
```

Since `rb_test()` is a wrapper around `rb_binary()`, you can also use it to run
a Ruby binary script available in Gemfile dependencies, by passing `main`
argument with a path to a Bundler binary stub.

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_test")

package(default_visibility = ["//:__subpackages__"])

rb_test(
    name = "rubocop",
    args = ["lib/"],
    main = "@bundle//bin:rubocop",
    tags = ["no-sandbox"],
    deps = [
        "//lib:gem",
        "@bundle",
    ],
)
```

```output
$ bazel test :rubocop
...
//:rubocop                                                               PASSED in 0.8s

Executed 1 out of 1 test: 1 test passes.
```

### Code Coverage

To enable code coverage, run tests with the `coverage` command:

```bash
bazel coverage //...
```

> [!NOTE]
> Code coverage is currently not supported on Windows.

See the [README](../../README.md#code-coverage) for more details.

Note that you can also `run` every test target passing extra arguments to
the Ruby script. For example, you can re-use `:rubocop` target to perform autocorrect:

```output
$ bazel run :rubocop -- --autocorrect-all
...
Inspecting 11 files
.C.........

Offenses:

gem.gemspec:1:1: C: [Corrected] Style/FrozenStringLiteralComment: Missing frozen string literal comment.
root = File.expand_path(__dir__)
^
gem.gemspec:2:1: C: [Corrected] Layout/EmptyLineAfterMagicComment: Add an empty line after magic comments.
root = File.expand_path(__dir__)
^

11 files inspected, 2 offenses detected, 2 offenses corrected
```"�%
�
rb_test�Runs a Ruby test.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
|-- lib
|   |-- BUILD
|   |-- gem
|   |   |-- BUILD
|   |   |-- add.rb
|   |   |-- subtract.rb
|   |   `-- version.rb
|   `-- gem.rb
`-- spec
    |-- BUILD
    |-- add_spec.rb
    |-- spec_helper.rb
    `-- subtract_spec.rb
```

You can run all tests inside `spec/` by defining individual targets:

`spec/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_library", "rb_test")

rb_library(
    name = "spec_helper",
    srcs = ["spec_helper.rb"],
)

rb_test(
    name = "add",
    srcs = ["add_spec.rb"],
    args = ["spec/add_spec.rb"],
    main = "@bundle//bin:rspec",
    deps = [
        ":spec_helper",
        "@bundle",
    ],
)

rb_test(
    name = "subtract",
    srcs = ["subtract_spec.rb"],
    args = ["spec/subtract_spec.rb"],
    main = "@bundle//bin:rspec",
    deps = [
        ":spec_helper",
        "@bundle",
    ],
)
```

```output
$ bazel test spec/...
...
//spec:add                                                               PASSED in 0.4s
//spec:subtract                                                          PASSED in 0.4s

Executed 2 out of 2 tests: 2 tests pass.
```

Since `rb_test()` is a wrapper around `rb_binary()`, you can also use it to run
a Ruby binary script available in Gemfile dependencies, by passing `main`
argument with a path to a Bundler binary stub.

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_test")

package(default_visibility = ["//:__subpackages__"])

rb_test(
    name = "rubocop",
    args = ["lib/"],
    main = "@bundle//bin:rubocop",
    tags = ["no-sandbox"],
    deps = [
        "//lib:gem",
        "@bundle",
    ],
)
```

```output
$ bazel test :rubocop
...
//:rubocop                                                               PASSED in 0.8s

Executed 1 out of 1 test: 1 test passes.
```

### Code Coverage

To enable code coverage, run tests with the `coverage` command:

```bash
bazel coverage //...
```

> [!NOTE]
> Code coverage is currently not supported on Windows.

See the [README](../../README.md#code-coverage) for more details.

Note that you can also `run` every test target passing extra arguments to
the Ruby script. For example, you can re-use `:rubocop` target to perform autocorrect:

```output
$ bazel run :rubocop -- --autocorrect-all
...
Inspecting 11 files
.C.........

Offenses:

gem.gemspec:1:1: C: [Corrected] Style/FrozenStringLiteralComment: Missing frozen string literal comment.
root = File.expand_path(__dir__)
^
gem.gemspec:2:1: C: [Corrected] Layout/EmptyLineAfterMagicComment: Add an empty line after magic comments.
root = File.expand_path(__dir__)
^

11 files inspected, 2 offenses detected, 2 offenses corrected
```*
nameA unique name for this target. �
main�Ruby script to run. It may also be a binary stub generated by Bundler.
If omitted, it defaults to the Ruby interpreter.

Use a built-in `args` attribute to pass extra arguments to the script.2None�
env|Environment variables to use during execution.

Supports `$(location)` expansion for targets from `srcs`, `data` and `deps`.
2{}[
env_inheritFList of environment variable names to be inherited by the test runner.2[]s
ruby7Override Ruby toolchain to use when running the script.**
ToolchainInfo
ToolchainInfo<native>2Nonep
coverage_filtersVAdditional coverage filters to add to SimpleCov. Only applied during 'bazel coverage'.2[]B
srcs4List of Ruby source files used to build the library.2[]\
dataNList of runtime dependencies needed by a program that depends on this library.2[]A
deps3List of other Ruby libraries the target depends on.2[]""
rb_test//ruby/private:test.bzl08,
*
nameA unique name for this target. �
�
main�Ruby script to run. It may also be a binary stub generated by Bundler.
If omitted, it defaults to the Ruby interpreter.

Use a built-in `args` attribute to pass extra arguments to the script.2None�
�
env|Environment variables to use during execution.

Supports `$(location)` expansion for targets from `srcs`, `data` and `deps`.
2{}]
[
env_inheritFList of environment variable names to be inherited by the test runner.2[]u
s
ruby7Override Ruby toolchain to use when running the script.**
ToolchainInfo
ToolchainInfo<native>2Noner
p
coverage_filtersVAdditional coverage filters to add to SimpleCov. Only applied during 'bazel coverage'.2[]D
B
srcs4List of Ruby source files used to build the library.2[]^
\
dataNList of runtime dependencies needed by a program that depends on this library.2[]C
A
deps3List of other Ruby libraries the target depends on.2[]Public API for rules�r
rubydeps.bzl�	rb_bundle:Wraps `rb_bundle_rule()` providing default toolchain name.*�
�
	rb_bundle<
	toolchaindefault Ruby toolchain BUILD"@ruby//:BUILD"(7
kwargs+underlying attrs passed to rb_bundle_rule()(:Wraps `rb_bundle_rule()` providing default toolchain name.2
	rb_bundle//ruby:deps.bzl>
<
	toolchaindefault Ruby toolchain BUILD"@ruby//:BUILD"(9
7
kwargs+underlying attrs passed to rb_bundle_rule()(�&rb_register_toolchains�Register a Ruby toolchain and lazily download the Ruby Interpreter.

* _(For MRI on Linux and macOS)_ Installed using [ruby-build](https://github.com/rbenv/ruby-build).
* _(For MRI on Windows)_ Installed using [RubyInstaller](https://rubyinstaller.org).
* _(For JRuby on any OS)_ Downloaded and installed directly from [official website](https://www.jruby.org).
* _(For TruffleRuby on Linux and macOS)_ Installed using [ruby-build](https://github.com/rbenv/ruby-build).
* _(With portable_ruby)_ Portable Ruby downloaded from [bazel-contrib/portable-ruby](https://github.com/bazel-contrib/portable-ruby).
* _(For "system")_ Ruby found on the PATH is used. Please note that builds are not hermetic in this case.

`WORKSPACE`:
```bazel
load("@rules_ruby//ruby:deps.bzl", "rb_register_toolchains")

rb_register_toolchains(
    version = "3.0.6"
)
```

Once registered, you can use the toolchain directly as it provides all the binaries:

```output
$ bazel run @ruby -- -e "puts RUBY_VERSION"
$ bazel run @ruby//:bundle -- update
$ bazel run @ruby//:gem -- install rails
```

You can also use Ruby engine targets to `select()` depending on installed Ruby interpreter:

`BUILD`:
```bazel
rb_library(
    name = "my_lib",
    srcs = ["my_lib.rb"],
    deps = select({
        "@ruby//engine:jruby": [":my_jruby_lib"],
        "@ruby//engine:truffleruby": ["//:my_truffleruby_lib"],
        "@ruby//engine:ruby": ["//:my__lib"],
        "//conditions:default": [],
    }),
)
```
*�
�
rb_register_toolchainsH
name6base name of resulting repositories, by default "ruby""ruby"(f
versionSa semver version of MRI, or a string like [interpreter type]-[version], or "system"None(Q
version_file9.ruby-version or .tool-versions file to read version fromNone(@
msys2_packagesextra MSYS2 packages to install["libyaml"](�
portable_ruby�when True, downloads portable Ruby from bazel-contrib/portable-ruby instead of compiling
via ruby-build. Has no effect on JRuby, TruffleRuby, or Windows.False(q
portable_ruby_release_suffixKrelease suffix for portable Ruby (default "1", e.g. "2" downloads X.Y.Z-2).""(o
portable_ruby_checksumsNplatform checksums for portable Ruby downloads, overriding
built-in checksums.{}(^
registerJwhether to register the resulting toolchains, should be False under bzlmodTrue(M
kwargsAadditional parameters to the downloader for this interpreter type(�Register a Ruby toolchain and lazily download the Ruby Interpreter.

* _(For MRI on Linux and macOS)_ Installed using [ruby-build](https://github.com/rbenv/ruby-build).
* _(For MRI on Windows)_ Installed using [RubyInstaller](https://rubyinstaller.org).
* _(For JRuby on any OS)_ Downloaded and installed directly from [official website](https://www.jruby.org).
* _(For TruffleRuby on Linux and macOS)_ Installed using [ruby-build](https://github.com/rbenv/ruby-build).
* _(With portable_ruby)_ Portable Ruby downloaded from [bazel-contrib/portable-ruby](https://github.com/bazel-contrib/portable-ruby).
* _(For "system")_ Ruby found on the PATH is used. Please note that builds are not hermetic in this case.

`WORKSPACE`:
```bazel
load("@rules_ruby//ruby:deps.bzl", "rb_register_toolchains")

rb_register_toolchains(
    version = "3.0.6"
)
```

Once registered, you can use the toolchain directly as it provides all the binaries:

```output
$ bazel run @ruby -- -e "puts RUBY_VERSION"
$ bazel run @ruby//:bundle -- update
$ bazel run @ruby//:gem -- install rails
```

You can also use Ruby engine targets to `select()` depending on installed Ruby interpreter:

`BUILD`:
```bazel
rb_library(
    name = "my_lib",
    srcs = ["my_lib.rb"],
    deps = select({
        "@ruby//engine:jruby": [":my_jruby_lib"],
        "@ruby//engine:truffleruby": ["//:my_truffleruby_lib"],
        "@ruby//engine:ruby": ["//:my__lib"],
        "//conditions:default": [],
    }),
)
```
26
rb_register_toolchains//ruby/private:toolchain.bzlJ
H
name6base name of resulting repositories, by default "ruby""ruby"(h
f
versionSa semver version of MRI, or a string like [interpreter type]-[version], or "system"None(S
Q
version_file9.ruby-version or .tool-versions file to read version fromNone(B
@
msys2_packagesextra MSYS2 packages to install["libyaml"](�
�
portable_ruby�when True, downloads portable Ruby from bazel-contrib/portable-ruby instead of compiling
via ruby-build. Has no effect on JRuby, TruffleRuby, or Windows.False(s
q
portable_ruby_release_suffixKrelease suffix for portable Ruby (default "1", e.g. "2" downloads X.Y.Z-2).""(q
o
portable_ruby_checksumsNplatform checksums for portable Ruby downloads, overriding
built-in checksums.{}(`
^
registerJwhether to register the resulting toolchains, should be False under bzlmodTrue(O
M
kwargsAadditional parameters to the downloader for this interpreter type(�/rb_bundle_fetch�
Fetches Bundler dependencies to be automatically installed by other targets.

Currently doesn't support installing gems from Git repositories,
see https://github.com/bazel-contrib/rules_ruby/issues/62.

`WORKSPACE`:
```bazel
load("@rules_ruby//ruby:deps.bzl", "rb_bundle_fetch")

rb_bundle_fetch(
    name = "bundle",
    gemfile = "//:Gemfile",
    gemfile_lock = "//:Gemfile.lock",
    srcs = [
        "//:gem.gemspec",
        "//:lib/gem/version.rb",
    ]
)
```

Checksums for gems in Gemfile.lock are printed by the ruleset during the build.
It's recommended to add them to `gem_checksums` attribute.

`WORKSPACE`:
```bazel
rb_bundle_fetch(
    name = "bundle",
    gemfile = "//:Gemfile",
    gemfile_lock = "//:Gemfile.lock",
    gem_checksums = {
        "ast-2.4.2": "1e280232e6a33754cde542bc5ef85520b74db2aac73ec14acef453784447cc12",
        "concurrent-ruby-1.2.2": "3879119b8b75e3b62616acc256c64a134d0b0a7a9a3fcba5a233025bcde22c4f",
    },
)
```

All the installed gems can be accessed using `@bundle` target and additionally
gems binary files can also be used via BUILD rules or directly with `bazel run`:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_test")

package(default_visibility = ["//:__subpackages__"])

rb_test(
    name = "rubocop",
    main = "@bundle//bin:rubocop",
    deps = ["@bundle"],
)
```R�$
�
rb_bundle_fetch�
Fetches Bundler dependencies to be automatically installed by other targets.

Currently doesn't support installing gems from Git repositories,
see https://github.com/bazel-contrib/rules_ruby/issues/62.

`WORKSPACE`:
```bazel
load("@rules_ruby//ruby:deps.bzl", "rb_bundle_fetch")

rb_bundle_fetch(
    name = "bundle",
    gemfile = "//:Gemfile",
    gemfile_lock = "//:Gemfile.lock",
    srcs = [
        "//:gem.gemspec",
        "//:lib/gem/version.rb",
    ]
)
```

Checksums for gems in Gemfile.lock are printed by the ruleset during the build.
It's recommended to add them to `gem_checksums` attribute.

`WORKSPACE`:
```bazel
rb_bundle_fetch(
    name = "bundle",
    gemfile = "//:Gemfile",
    gemfile_lock = "//:Gemfile.lock",
    gem_checksums = {
        "ast-2.4.2": "1e280232e6a33754cde542bc5ef85520b74db2aac73ec14acef453784447cc12",
        "concurrent-ruby-1.2.2": "3879119b8b75e3b62616acc256c64a134d0b0a7a9a3fcba5a233025bcde22c4f",
    },
)
```

All the installed gems can be accessed using `@bundle` target and additionally
gems binary files can also be used via BUILD rules or directly with `bazel run`:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_test")

package(default_visibility = ["//:__subpackages__"])

rb_test(
    name = "rubocop",
    main = "@bundle//bin:rubocop",
    deps = ["@bundle"],
)
```.
name"A unique name for this repository. �
repo_mapping�In `WORKSPACE` context only: a dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.

For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).

This attribute is _not_ supported in `MODULE.bazel` context (when invoking a repository rule inside a module extension's implementation function).
4
gemfile%Gemfile to install dependencies from. >
gemfile_lock*Gemfile.lock to install dependencies from. F
srcs8List of Ruby source files necessary during installation.2[]>
env1Environment variables to use during installation.
2{}R
bundler_remote%Remote to fetch the bundler gem from.2"https://rubygems.org/"S
bundler_checksums8Custom map from Bundler version to its SHA-256 checksum.
2{}
gem_checksumshSHA-256 checksums for remote gems. Keys are gem names (e.g. foobar-1.2.3), values are SHA-256 checksums.
2{}�
jar_checksums�SHA-256 checksums for JAR dependencies. Keys are Maven coordinates (e.g. org.yaml:snakeyaml:1.33), values are SHA-256 checksums.
2{}l
ruby0Override Ruby toolchain to use for installation.**
ToolchainInfo
ToolchainInfo<native>2Nonei
auth_patternsRA list of patterns to match against urls for which the auth object should be used.
2{};
netrc,Path to .netrc file to read credentials from2""*2
rb_bundle_fetch//ruby/private:bundle_fetch.bzl0
.
name"A unique name for this repository. �
�
repo_mapping�In `WORKSPACE` context only: a dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.

For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).

This attribute is _not_ supported in `MODULE.bazel` context (when invoking a repository rule inside a module extension's implementation function).
6
4
gemfile%Gemfile to install dependencies from. @
>
gemfile_lock*Gemfile.lock to install dependencies from. H
F
srcs8List of Ruby source files necessary during installation.2[]@
>
env1Environment variables to use during installation.
2{}T
R
bundler_remote%Remote to fetch the bundler gem from.2"https://rubygems.org/"U
S
bundler_checksums8Custom map from Bundler version to its SHA-256 checksum.
2{}�

gem_checksumshSHA-256 checksums for remote gems. Keys are gem names (e.g. foobar-1.2.3), values are SHA-256 checksums.
2{}�
�
jar_checksums�SHA-256 checksums for JAR dependencies. Keys are Maven coordinates (e.g. org.yaml:snakeyaml:1.33), values are SHA-256 checksums.
2{}n
l
ruby0Override Ruby toolchain to use for installation.**
ToolchainInfo
ToolchainInfo<native>2Nonek
i
auth_patternsRA list of patterns to match against urls for which the auth object should be used.
2{}=
;
netrc,Path to .netrc file to read credentials from2""�rb_bundle_rule�(Deprecated) Use `rb_bundle_fetch()` instead.

Installs Bundler dependencies and registers an external repository
that can be used by other targets.

`WORKSPACE`:
```bazel
load("@rules_ruby//ruby:deps.bzl", "rb_bundle")

rb_bundle(
    name = "bundle",
    gemfile = "//:Gemfile",
    srcs = [
        "//:gem.gemspec",
        "//:lib/gem/version.rb",
    ]
)
```

All the installed gems can be accessed using `@bundle` target and additionally
gems binary files can also be used:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_binary")

package(default_visibility = ["//:__subpackages__"])

rb_binary(
    name = "rubocop",
    main = "@bundle//:bin/rubocop",
    deps = ["@bundle"],
)
```R�
�
rb_bundle_rule�(Deprecated) Use `rb_bundle_fetch()` instead.

Installs Bundler dependencies and registers an external repository
that can be used by other targets.

`WORKSPACE`:
```bazel
load("@rules_ruby//ruby:deps.bzl", "rb_bundle")

rb_bundle(
    name = "bundle",
    gemfile = "//:Gemfile",
    srcs = [
        "//:gem.gemspec",
        "//:lib/gem/version.rb",
    ]
)
```

All the installed gems can be accessed using `@bundle` target and additionally
gems binary files can also be used:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_binary")

package(default_visibility = ["//:__subpackages__"])

rb_binary(
    name = "rubocop",
    main = "@bundle//:bin/rubocop",
    deps = ["@bundle"],
)
```.
name"A unique name for this repository. �
repo_mapping�In `WORKSPACE` context only: a dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.

For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).

This attribute is _not_ supported in `MODULE.bazel` context (when invoking a repository rule inside a module extension's implementation function).
B
srcs4List of Ruby source files used to build the library.2[]
	toolchain 8
gemfile%Gemfile to install dependencies from.2None>
env1Environment variables to use during installation.
2{}*&
	rb_bundle//ruby/private:bundle.bzl0
.
name"A unique name for this repository. �
�
repo_mapping�In `WORKSPACE` context only: a dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.

For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).

This attribute is _not_ supported in `MODULE.bazel` context (when invoking a repository rule inside a module extension's implementation function).
D
B
srcs4List of Ruby source files used to build the library.2[]

	toolchain :
8
gemfile%Gemfile to install dependencies from.2None@
>
env1Environment variables to use during installation.
2{}Public API for repository rules 