�
@

rules_rubyruby/private/bundle_fetchgemfile_lock_parser.bzl�parse_gemfile_lockhParses a Gemfile.lock.

Find lines in the content of a Gemfile.lock that look like package
constraints.
*�
�
parse_gemfile_lock$
contentGemfile.lock contents (9
bundler_remote#Remote URL for the bundler package. (E
bundler_checksums,Map from bundler version to sha256 checksum. (hParses a Gemfile.lock.

Find lines in the content of a Gemfile.lock that look like package
constraints.
"!
struct with parsed Gemfile.lock2U
parse_gemfile_lock?@@rules_ruby//ruby/private/bundle_fetch:gemfile_lock_parser.bzl
rr�
Parses a Gemfile.lock purely in Starlark.

Largely based on https://github.com/sushain97/rules_ruby/blob/master/tools/ruby/gemfile_parser.bzl (private).
Modifications include:
  - Support for parsing out the gem remote URL.
  - Usage of structs with extra fields as return values.
�
:

rules_rubyruby/private/toolchainrepository_proxy.bzl�rb_toolchain_repository_proxy�
A proxy repository that contains the toolchain declaration; this indirection
allows the Ruby toolchain to be downloaded lazily.
R�

�
rb_toolchain_repository_proxy�
A proxy repository that contains the toolchain declaration; this indirection
allows the Ruby toolchain to be downloaded lazily.
.
name"A unique name for this repository. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 
	toolchain 
toolchain_type *Z
rb_toolchain_repository_proxy9@@rules_ruby//ruby/private/toolchain:repository_proxy.bzl
000
.
name"A unique name for this repository. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 

	toolchain 

toolchain_type :Repository rule for proxying registering Ruby interpreters�4
&

rules_rubyruby/private
binary.bzl�(	rb_binary�
Runs a Ruby binary.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

One of the files can be run as a Ruby script:

`lib/gem/version.rb`:
```ruby
module GEM
  VERSION = '0.1.0'
end

puts "Version is: #{GEM::VERSION}" if __FILE__ == $PROGRAM_NAME
```

You can run this script by defining a target:

`lib/gem/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_binary", "rb_library")

rb_library(
    name = "version",
    srcs = ["version.rb"],
)

rb_binary(
    name = "print-version",
    args = ["lib/gem/version.rb"],
    deps = [":version"],
)
```

```output
$ bazel run lib/gem:print-version
...
Version is: 0.1.0
```

You can also run general purpose Ruby scripts that rely on a Ruby interpreter in PATH:

`lib/gem/add.rb`:
```ruby
#!/usr/bin/env ruby

a, b = *ARGV
puts Integer(a) + Integer(b)
```

`lib/gem/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_binary", "rb_library")

rb_library(
    name = "add",
    srcs = ["add.rb"],
)

rb_binary(
    name = "add-numbers",
    main = "add.rb",
    deps = [":add"],
)
```

```output
$ bazel run lib/gem:add-numbers 1 2
...
3
```

You can also run a Ruby binary script available in Gemfile dependencies,
by passing `bin` argument with a path to a Bundler binary stub:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_binary")

package(default_visibility = ["//:__subpackages__"])

rb_binary(
    name = "rake",
    main = "@bundle//bin:rake",
    deps = [
        "//lib:gem",
        "@bundle",
    ],
)
```

```output
$ bazel run :rake -- --version
...
rake, version 13.1.0
```
"�
�
	rb_binary�
Runs a Ruby binary.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

One of the files can be run as a Ruby script:

`lib/gem/version.rb`:
```ruby
module GEM
  VERSION = '0.1.0'
end

puts "Version is: #{GEM::VERSION}" if __FILE__ == $PROGRAM_NAME
```

You can run this script by defining a target:

`lib/gem/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_binary", "rb_library")

rb_library(
    name = "version",
    srcs = ["version.rb"],
)

rb_binary(
    name = "print-version",
    args = ["lib/gem/version.rb"],
    deps = [":version"],
)
```

```output
$ bazel run lib/gem:print-version
...
Version is: 0.1.0
```

You can also run general purpose Ruby scripts that rely on a Ruby interpreter in PATH:

`lib/gem/add.rb`:
```ruby
#!/usr/bin/env ruby

a, b = *ARGV
puts Integer(a) + Integer(b)
```

`lib/gem/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_binary", "rb_library")

rb_library(
    name = "add",
    srcs = ["add.rb"],
)

rb_binary(
    name = "add-numbers",
    main = "add.rb",
    deps = [":add"],
)
```

```output
$ bazel run lib/gem:add-numbers 1 2
...
3
```

You can also run a Ruby binary script available in Gemfile dependencies,
by passing `bin` argument with a path to a Bundler binary stub:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_binary")

package(default_visibility = ["//:__subpackages__"])

rb_binary(
    name = "rake",
    main = "@bundle//bin:rake",
    deps = [
        "//lib:gem",
        "@bundle",
    ],
)
```

```output
$ bazel run :rake -- --version
...
rake, version 13.1.0
```
*
nameA unique name for this target. \
dataNList of runtime dependencies needed by a program that depends on this library.2[]A
deps3List of other Ruby libraries the target depends on.2[]�
env~
Environment variables to use during execution.

Supports `$(location)` expansion for targets from `srcs`, `data` and `deps`.

2{}[
env_inheritFList of environment variable names to be inherited by the test runner.2[]�
main�
Ruby script to run. It may also be a binary stub generated by Bundler.
If omitted, it defaults to the Ruby interpreter.

Use a built-in `args` attribute to pass extra arguments to the script.
2NoneB
srcs4List of Ruby source files used to build the library.2[]"2
	rb_binary%@@rules_ruby//ruby/private:binary.bzl
��,
*
nameA unique name for this target. ^
\
dataNList of runtime dependencies needed by a program that depends on this library.2[]C
A
deps3List of other Ruby libraries the target depends on.2[]�
�
env~
Environment variables to use during execution.

Supports `$(location)` expansion for targets from `srcs`, `data` and `deps`.

2{}]
[
env_inheritFList of environment variable names to be inherited by the test runner.2[]�
�
main�
Ruby script to run. It may also be a binary stub generated by Bundler.
If omitted, it defaults to the Ruby interpreter.

Use a built-in `args` attribute to pass extra arguments to the script.
2NoneD
B
srcs4List of Ruby source files used to build the library.2[]�generate_rb_binary_script*�
�
generate_rb_binary_script	
ctx (
binary (
bundlerFalse(
args[](
env{}(
java_bin""(2B
generate_rb_binary_script%@@rules_ruby//ruby/private:binary.bzl
@@xrb_binary_impl*d
T
rb_binary_impl	
ctx (27
rb_binary_impl%@@rules_ruby//ruby/private:binary.bzl
||}
//ruby/private:library.bzlr]
'

rules_rubyruby/privatelibrary.bzl$
ATTRSLIBRARY_ATTRS
/<
G�
//ruby/private:providers.bzlr�
)

rules_rubyruby/privateproviders.bzl(
BundlerInfoBundlerInfo
,
RubyFilesInfoRubyFilesInfo
.
get_bundle_envget_bundle_env
8
get_transitive_dataget_transitive_data
		8
get_transitive_depsget_transitive_deps


@
get_transitive_runfilesget_transitive_runfiles
8
get_transitive_srcsget_transitive_srcs

�
//ruby/private:utils.bzlr�
%

rules_rubyruby/private	utils.bzl@
BASH_RLOCATION_FUNCTIONBASH_RLOCATION_FUNCTION
B
BATCH_RLOCATION_FUNCTIONBATCH_RLOCATION_FUNCTION
=
convert_env_to_script_convert_env_to_script
'

is_windows_is_windows
/
normalize_path_normalize_path
5
to_rlocation_path_to_rlocation_path

$Implementation details for rb_binary�
&

rules_rubyruby/private
bundle.bzl�	rb_bundle�
(Deprecated) Use `rb_bundle_fetch()` instead.

Installs Bundler dependencies and registers an external repository
that can be used by other targets.

`WORKSPACE`:
```bazel
load("@rules_ruby//ruby:deps.bzl", "rb_bundle")

rb_bundle(
    name = "bundle",
    gemfile = "//:Gemfile",
    srcs = [
        "//:gem.gemspec",
        "//:lib/gem/version.rb",
    ]
)
```

All the installed gems can be accessed using `@bundle` target and additionally
gems binary files can also be used:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_binary")

package(default_visibility = ["//:__subpackages__"])

rb_binary(
    name = "rubocop",
    main = "@bundle//:bin/rubocop",
    deps = ["@bundle"],
)
```
R�
�
	rb_bundle�
(Deprecated) Use `rb_bundle_fetch()` instead.

Installs Bundler dependencies and registers an external repository
that can be used by other targets.

`WORKSPACE`:
```bazel
load("@rules_ruby//ruby:deps.bzl", "rb_bundle")

rb_bundle(
    name = "bundle",
    gemfile = "//:Gemfile",
    srcs = [
        "//:gem.gemspec",
        "//:lib/gem/version.rb",
    ]
)
```

All the installed gems can be accessed using `@bundle` target and additionally
gems binary files can also be used:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_binary")

package(default_visibility = ["//:__subpackages__"])

rb_binary(
    name = "rubocop",
    main = "@bundle//:bin/rubocop",
    deps = ["@bundle"],
)
```
.
name"A unique name for this repository. >
env1Environment variables to use during installation.
2{}:
gemfile'
Gemfile to install dependencies from.
2None�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 D
srcs6
List of Ruby source files used to build the library.
2[]
	toolchain *2
	rb_bundle%@@rules_ruby//ruby/private:bundle.bzl
QQ0
.
name"A unique name for this repository. @
>
env1Environment variables to use during installation.
2{}<
:
gemfile'
Gemfile to install dependencies from.
2None�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 F
D
srcs6
List of Ruby source files used to build the library.
2[]

	toolchain .Implementation details for calling the bundler�,
,

rules_rubyruby/privatebundle_fetch.bzl�&rb_bundle_fetch�

Fetches Bundler dependencies to be automatically installed by other targets.

Currently doesn't support installing gems from Git repositories,
see https://github.com/bazel-contrib/rules_ruby/issues/62.

`WORKSPACE`:
```bazel
load("@rules_ruby//ruby:deps.bzl", "rb_bundle_fetch")

rb_bundle_fetch(
    name = "bundle",
    gemfile = "//:Gemfile",
    gemfile_lock = "//:Gemfile.lock",
    srcs = [
        "//:gem.gemspec",
        "//:lib/gem/version.rb",
    ]
)
```

Checksums for gems in Gemfile.lock are printed by the ruleset during the build.
It's recommended to add them to `gem_checksums` attribute.

`WORKSPACE`:
```bazel
rb_bundle_fetch(
    name = "bundle",
    gemfile = "//:Gemfile",
    gemfile_lock = "//:Gemfile.lock",
    gem_checksums = {
        "ast-2.4.2": "1e280232e6a33754cde542bc5ef85520b74db2aac73ec14acef453784447cc12",
        "concurrent-ruby-1.2.2": "3879119b8b75e3b62616acc256c64a134d0b0a7a9a3fcba5a233025bcde22c4f",
    },
)
```

All the installed gems can be accessed using `@bundle` target and additionally
gems binary files can also be used via BUILD rules or directly with `bazel run`:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_test")

package(default_visibility = ["//:__subpackages__"])

rb_test(
    name = "rubocop",
    main = "@bundle//bin:rubocop",
    deps = ["@bundle"],
)
```
R�
�
rb_bundle_fetch�

Fetches Bundler dependencies to be automatically installed by other targets.

Currently doesn't support installing gems from Git repositories,
see https://github.com/bazel-contrib/rules_ruby/issues/62.

`WORKSPACE`:
```bazel
load("@rules_ruby//ruby:deps.bzl", "rb_bundle_fetch")

rb_bundle_fetch(
    name = "bundle",
    gemfile = "//:Gemfile",
    gemfile_lock = "//:Gemfile.lock",
    srcs = [
        "//:gem.gemspec",
        "//:lib/gem/version.rb",
    ]
)
```

Checksums for gems in Gemfile.lock are printed by the ruleset during the build.
It's recommended to add them to `gem_checksums` attribute.

`WORKSPACE`:
```bazel
rb_bundle_fetch(
    name = "bundle",
    gemfile = "//:Gemfile",
    gemfile_lock = "//:Gemfile.lock",
    gem_checksums = {
        "ast-2.4.2": "1e280232e6a33754cde542bc5ef85520b74db2aac73ec14acef453784447cc12",
        "concurrent-ruby-1.2.2": "3879119b8b75e3b62616acc256c64a134d0b0a7a9a3fcba5a233025bcde22c4f",
    },
)
```

All the installed gems can be accessed using `@bundle` target and additionally
gems binary files can also be used via BUILD rules or directly with `bazel run`:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_test")

package(default_visibility = ["//:__subpackages__"])

rb_test(
    name = "rubocop",
    main = "@bundle//bin:rubocop",
    deps = ["@bundle"],
)
```
.
name"A unique name for this repository. S
bundler_checksums8Custom map from Bundler version to its SHA-256 checksum.
2{}R
bundler_remote%Remote to fetch the bundler gem from.2"https://rubygems.org/">
env1Environment variables to use during installation.
2{}
gem_checksumshSHA-256 checksums for remote gems. Keys are gem names (e.g. foobar-1.2.3), values are SHA-256 checksums.
2{}4
gemfile%Gemfile to install dependencies from. >
gemfile_lock*Gemfile.lock to install dependencies from. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 F
srcs8List of Ruby source files necessary during installation.2[]*>
rb_bundle_fetch+@@rules_ruby//ruby/private:bundle_fetch.bzl
�"�"0
.
name"A unique name for this repository. U
S
bundler_checksums8Custom map from Bundler version to its SHA-256 checksum.
2{}T
R
bundler_remote%Remote to fetch the bundler gem from.2"https://rubygems.org/"@
>
env1Environment variables to use during installation.
2{}�

gem_checksumshSHA-256 checksums for remote gems. Keys are gem names (e.g. foobar-1.2.3), values are SHA-256 checksums.
2{}6
4
gemfile%Gemfile to install dependencies from. @
>
gemfile_lock*Gemfile.lock to install dependencies from. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 H
F
srcs8List of Ruby source files necessary during installation.2[]m
//lib:versions.bzlrU
!
bazel_skyliblibversions.bzl"
versionsversions
*2
4�
$//ruby/private:bundler_checksums.bzlrw
1

rules_rubyruby/privatebundler_checksums.bzl4
BUNDLER_CHECKSUMSBUNDLER_CHECKSUMS
:K
M�
//ruby/private:utils.bzlr�
%

rules_rubyruby/private	utils.bzl1
join_and_indent_join_and_indent
S
 normalize_bzlmod_repository_name!_normalize_bzlmod_repository_name
&
	�
3//ruby/private/bundle_fetch:gemfile_lock_parser.bzlr�
@

rules_rubyruby/private/bundle_fetchgemfile_lock_parser.bzl6
parse_gemfile_lockparse_gemfile_lock

I
[


]1	BINSTUBS_LOCATIONbin/privatejbin/private*Implementation details for rb_bundle_fetch�
.

rules_rubyruby/privatebundle_install.bzl�	rb_bundle_install�
Installs Bundler dependencies from cached gems.

You normally don't need to call this rule directly as it's an internal one
used by `rb_bundle_fetch()`.
"�
�
rb_bundle_install�
Installs Bundler dependencies from cached gems.

You normally don't need to call this rule directly as it's an internal one
used by `rb_bundle_fetch()`.
*
nameA unique name for this target. >
env1Environment variables to use during installation.
2{}4
gemfile%Gemfile to install dependencies from. >
gemfile_lock*Gemfile.lock to install dependencies from. T
gemsHList of gems in vendor/cache that are used to install dependencies from. B
srcs4List of Ruby source files used to build the library.2[]"B
rb_bundle_install-@@rules_ruby//ruby/private:bundle_install.bzl
pp,
*
nameA unique name for this target. @
>
env1Environment variables to use during installation.
2{}6
4
gemfile%Gemfile to install dependencies from. @
>
gemfile_lock*Gemfile.lock to install dependencies from. V
T
gemsHList of gems in vendor/cache that are used to install dependencies from. D
B
srcs4List of Ruby source files used to build the library.2[]�
//ruby/private:bundle_fetch.bzlrr
,

rules_rubyruby/privatebundle_fetch.bzl4
BINSTUBS_LOCATIONBINSTUBS_LOCATION
5F
H�
//ruby/private:providers.bzlr�
)

rules_rubyruby/privateproviders.bzl(
BundlerInfoBundlerInfo
2= 
GemInfoGemInfo
AH,
RubyFilesInfoRubyFilesInfo
LY
[�
//ruby/private:utils.bzlr�
%

rules_rubyruby/private	utils.bzl=
convert_env_to_script_convert_env_to_script
'

is_windows_is_windows
/
normalize_path_normalize_path
		

,Implementation details for rb_bundle_install]
1

rules_rubyruby/privatebundler_checksums.bzl(Provides checksums for bundler gem files�
(

rules_rubyruby/privatedownload.bzl�rb_downloadR�
�
rb_download.
name"A unique name for this repository. �
msys2_packagesa
Extra MSYS2 packages to install.

By default, contains `libyaml` (dependency of a `psych` gem).
2["libyaml"]�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
ruby_build_version�
Version of [ruby-build](https://github.com/rbenv/ruby-build/releases)
to install. You normally don't need to change this, unless `version` you pass is a new one
which isn't available in this ruby-build yet.
2
"20231225")
versionRuby version to install.2""7
version_fileFile to read Ruby version from.2None*6
rb_download'@@rules_ruby//ruby/private:download.bzl
��0
.
name"A unique name for this repository. �
�
msys2_packagesa
Extra MSYS2 packages to install.

By default, contains `libyaml` (dependency of a `psych` gem).
2["libyaml"]�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 �
�
ruby_build_version�
Version of [ruby-build](https://github.com/rbenv/ruby-build/releases)
to install. You normally don't need to change this, unless `version` you pass is a new one
which isn't available in this ruby-build yet.
2
"20231225"+
)
versionRuby version to install.2""9
7
version_fileFile to read Ruby version from.2None.Repository rule for fetching Ruby interpreters�
#

rules_rubyruby/privategem.bzl�rb_gem�
Exposes a Ruby gem file.

You normally don't need to call this rule directly as it's an internal one
used by `rb_bundle_fetch()`.
"�
�
rb_gem�
Exposes a Ruby gem file.

You normally don't need to call this rule directly as it's an internal one
used by `rb_bundle_fetch()`.
*
nameA unique name for this target. 
gem	Gem file. ",
rb_gem"@@rules_ruby//ruby/private:gem.bzl
,
*
nameA unique name for this target. 

gem	Gem file. }
//ruby/private:providers.bzlr[
)

rules_rubyruby/privateproviders.bzl 
GemInfoGemInfo
29
;!Implementation details for rb_gem�#
)

rules_rubyruby/privategem_build.bzl�rb_gem_build�
Builds a Ruby gem.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

And a RubyGem specification is:

`gem.gemspec`:
```ruby
root = File.expand_path(__dir__)
$LOAD_PATH.push(File.expand_path('lib', root))
require 'gem/version'

Gem::Specification.new do |s|
  s.name = 'example'
  s.version = GEM::VERSION

  s.authors = ['Foo Bar']
  s.email = ['foobar@gmail.com']
  s.homepage = 'http://rubygems.org'
  s.license = 'MIT'

  s.summary = 'Example'
  s.description = 'Example gem'
  s.files = ['Gemfile'] + Dir['lib/**/*']

  s.require_paths = ['lib']
  s.add_dependency 'rake', '~> 10'
  s.add_development_dependency 'rspec', '~> 3.0'
  s.add_development_dependency 'rubocop', '~> 1.10'
end
```

You can now package everything into a `.gem` file by defining a target:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_gem_build")

package(default_visibility = ["//:__subpackages__"])

rb_gem_build(
    name = "gem-build",
    gemspec = "gem.gemspec",
    deps = [
        "//lib:gem",
        "@bundle",
    ],
)
```

```output
$ bazel build :gem-build
...
  Successfully built RubyGem
  Name: example
  Version: 0.1.0
  File: example-0.1.0.gem
...
```
"�
�
rb_gem_build�
Builds a Ruby gem.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

And a RubyGem specification is:

`gem.gemspec`:
```ruby
root = File.expand_path(__dir__)
$LOAD_PATH.push(File.expand_path('lib', root))
require 'gem/version'

Gem::Specification.new do |s|
  s.name = 'example'
  s.version = GEM::VERSION

  s.authors = ['Foo Bar']
  s.email = ['foobar@gmail.com']
  s.homepage = 'http://rubygems.org'
  s.license = 'MIT'

  s.summary = 'Example'
  s.description = 'Example gem'
  s.files = ['Gemfile'] + Dir['lib/**/*']

  s.require_paths = ['lib']
  s.add_dependency 'rake', '~> 10'
  s.add_development_dependency 'rspec', '~> 3.0'
  s.add_development_dependency 'rubocop', '~> 1.10'
end
```

You can now package everything into a `.gem` file by defining a target:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_gem_build")

package(default_visibility = ["//:__subpackages__"])

rb_gem_build(
    name = "gem-build",
    gemspec = "gem.gemspec",
    deps = [
        "//lib:gem",
        "@bundle",
    ],
)
```

```output
$ bazel build :gem-build
...
  Successfully built RubyGem
  Name: example
  Version: 0.1.0
  File: example-0.1.0.gem
...
```
*
nameA unique name for this target. Z

bundle_envFList of bundle environment variables to set when building the library.
2{}\
dataNList of runtime dependencies needed by a program that depends on this library.2[]A
deps3List of other Ruby libraries the target depends on.2[]4
gemspec%Gemspec file to use for gem building. B
srcs4List of Ruby source files used to build the library.2[]"8
rb_gem_build(@@rules_ruby//ruby/private:gem_build.bzl
aa,
*
nameA unique name for this target. \
Z

bundle_envFList of bundle environment variables to set when building the library.
2{}^
\
dataNList of runtime dependencies needed by a program that depends on this library.2[]C
A
deps3List of other Ruby libraries the target depends on.2[]6
4
gemspec%Gemspec file to use for gem building. D
B
srcs4List of Ruby source files used to build the library.2[]}
//ruby/private:library.bzlr]
'

rules_rubyruby/privatelibrary.bzl$
ATTRSLIBRARY_ATTRS
/<
G�
//ruby/private:providers.bzlr�
)

rules_rubyruby/privateproviders.bzl(
BundlerInfoBundlerInfo
,
RubyFilesInfoRubyFilesInfo
.
get_bundle_envget_bundle_env
8
get_transitive_dataget_transitive_data
		8
get_transitive_depsget_transitive_deps


8
get_transitive_srcsget_transitive_srcs

|
//ruby/private:utils.bzlr^
%

rules_rubyruby/private	utils.bzl'

is_windows_is_windows
-8
H'Implementation details for rb_gem_build�
+

rules_rubyruby/privategem_install.bzl�rb_gem_install�
Installs a built Ruby gem.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem and `rb_gem_build()` is used
to build a Ruby gem package from the sources.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

You can now install the built `.gem` file by defining a target:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_gem_build", "rb_gem_install")

package(default_visibility = ["//:__subpackages__"])

rb_gem_build(
    name = "gem-build",
    gemspec = "gem.gemspec",
    deps = ["//lib:gem"],
)

rb_gem_install(
    name = "gem-install",
    gem = ":gem-build",
)
```

```output
$ bazel build :gem-install
...
Successfully installed example-0.1.0
1 gem installed
...
```
"�	
�
rb_gem_install�
Installs a built Ruby gem.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem and `rb_gem_build()` is used
to build a Ruby gem package from the sources.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

You can now install the built `.gem` file by defining a target:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_gem_build", "rb_gem_install")

package(default_visibility = ["//:__subpackages__"])

rb_gem_build(
    name = "gem-build",
    gemspec = "gem.gemspec",
    deps = ["//lib:gem"],
)

rb_gem_install(
    name = "gem-install",
    gem = ":gem-build",
)
```

```output
$ bazel build :gem-install
...
Successfully installed example-0.1.0
1 gem installed
...
```
*
nameA unique name for this target. 
gemGem file to install. "<
rb_gem_install*@@rules_ruby//ruby/private:gem_install.bzl
BB,
*
nameA unique name for this target. !

gemGem file to install. }
//ruby/private:providers.bzlr[
)

rules_rubyruby/privateproviders.bzl 
GemInfoGemInfo
29
;�
//ruby/private:utils.bzlr�
%

rules_rubyruby/private	utils.bzl=
convert_env_to_script_convert_env_to_script
'

is_windows_is_windows
/
normalize_path_normalize_path

	)Implementation details for rb_gem_install�
(

rules_rubyruby/privategem_push.bzl�rb_gem_push�
Pushes a built Ruby gem.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem and `rb_gem_build()` is used
to build a Ruby gem package from the sources.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

You can now release the built `.gem` file to RubyGems by defining a target:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_gem_build", "rb_gem_push")

package(default_visibility = ["//:__subpackages__"])

rb_gem_build(
    name = "gem-build",
    gemspec = "gem.gemspec",
    deps = ["//lib:gem"],
)

rb_gem_push(
    name = "gem-release",
    gem = ":gem-build",
)
```

```output
$ bazel run :gem-release
...
Pushing gem to https://rubygems.org...
Successfully registered gem: example (0.1.0)
```
"�
�
rb_gem_push�
Pushes a built Ruby gem.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem and `rb_gem_build()` is used
to build a Ruby gem package from the sources.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

You can now release the built `.gem` file to RubyGems by defining a target:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_gem_build", "rb_gem_push")

package(default_visibility = ["//:__subpackages__"])

rb_gem_build(
    name = "gem-build",
    gemspec = "gem.gemspec",
    deps = ["//lib:gem"],
)

rb_gem_push(
    name = "gem-release",
    gem = ":gem-build",
)
```

```output
$ bazel run :gem-release
...
Pushing gem to https://rubygems.org...
Successfully registered gem: example (0.1.0)
```
*
nameA unique name for this target. Z

bundle_envFList of bundle environment variables to set when building the library.
2{}\
dataNList of runtime dependencies needed by a program that depends on this library.2[]A
deps3List of other Ruby libraries the target depends on.2[]�
env~
Environment variables to use during execution.

Supports `$(location)` expansion for targets from `srcs`, `data` and `deps`.

2{}[
env_inheritFList of environment variable names to be inherited by the test runner.2[]k
gem`
Gem file to push to RubyGems. You would usually use an output of `rb_gem_build()` target here.
 B
srcs4List of Ruby source files used to build the library.2[]"6
rb_gem_push'@@rules_ruby//ruby/private:gem_push.bzl
&&,
*
nameA unique name for this target. \
Z

bundle_envFList of bundle environment variables to set when building the library.
2{}^
\
dataNList of runtime dependencies needed by a program that depends on this library.2[]C
A
deps3List of other Ruby libraries the target depends on.2[]�
�
env~
Environment variables to use during execution.

Supports `$(location)` expansion for targets from `srcs`, `data` and `deps`.

2{}]
[
env_inheritFList of environment variable names to be inherited by the test runner.2[]m
k
gem`
Gem file to push to RubyGems. You would usually use an output of `rb_gem_build()` target here.
 D
B
srcs4List of Ruby source files used to build the library.2[]�
//ruby/private:binary.bzlr�
&

rules_rubyruby/private
binary.bzlD
generate_rb_binary_scriptgenerate_rb_binary_script
/H#
ATTRSBINARY_ATTRS
KW
b}
//ruby/private:library.bzlr]
'

rules_rubyruby/privatelibrary.bzl$
ATTRSLIBRARY_ATTRS
/<
G&Implementation details for rb_gem_push�
'

rules_rubyruby/privatelibrary.bzl�
rb_library�	
Defines a Ruby library.

Suppose you have the following Ruby gem:

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

You can define packages for the gem source files:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_library")

package(default_visibility = ["//:__subpackages__"])

rb_library(
    name = "gem",
    deps = ["//lib:gem"],
)
```

`lib/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_library")

package(default_visibility = ["//:__subpackages__"])

rb_library(
    name = "gem",
    srcs = ["gem.rb"],
    deps = [
        "//lib/gem:add",
        "//lib/gem:subtract",
        "//lib/gem:version",
    ],
)
```

`lib/gem/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_library")

package(default_visibility = ["//:__subpackages__"])

rb_library(
    name = "add",
    srcs = ["add.rb"],
)

rb_library(
    name = "subtract",
    srcs = ["subtract.rb"],
)

rb_library(
    name = "version",
    srcs = ["version.rb"],
)
```

Once the packages are defined, you can use them in other targets
such as `rb_gem_build()` to build a Ruby gem. See examples of
using other rules.
"�
�

rb_library�	
Defines a Ruby library.

Suppose you have the following Ruby gem:

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

You can define packages for the gem source files:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_library")

package(default_visibility = ["//:__subpackages__"])

rb_library(
    name = "gem",
    deps = ["//lib:gem"],
)
```

`lib/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_library")

package(default_visibility = ["//:__subpackages__"])

rb_library(
    name = "gem",
    srcs = ["gem.rb"],
    deps = [
        "//lib/gem:add",
        "//lib/gem:subtract",
        "//lib/gem:version",
    ],
)
```

`lib/gem/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_library")

package(default_visibility = ["//:__subpackages__"])

rb_library(
    name = "add",
    srcs = ["add.rb"],
)

rb_library(
    name = "subtract",
    srcs = ["subtract.rb"],
)

rb_library(
    name = "version",
    srcs = ["version.rb"],
)
```

Once the packages are defined, you can use them in other targets
such as `rb_gem_build()` to build a Ruby gem. See examples of
using other rules.
*
nameA unique name for this target. Z

bundle_envFList of bundle environment variables to set when building the library.
2{}\
dataNList of runtime dependencies needed by a program that depends on this library.2[]A
deps3List of other Ruby libraries the target depends on.2[]B
srcs4List of Ruby source files used to build the library.2[]"4

rb_library&@@rules_ruby//ruby/private:library.bzl
>>,
*
nameA unique name for this target. \
Z

bundle_envFList of bundle environment variables to set when building the library.
2{}^
\
dataNList of runtime dependencies needed by a program that depends on this library.2[]C
A
deps3List of other Ruby libraries the target depends on.2[]D
B
srcs4List of Ruby source files used to build the library.2[]�
//ruby/private:providers.bzlr�
)

rules_rubyruby/privateproviders.bzl(
BundlerInfoBundlerInfo
,
RubyFilesInfoRubyFilesInfo
.
get_bundle_envget_bundle_env
8
get_transitive_dataget_transitive_data
8
get_transitive_depsget_transitive_deps
		@
get_transitive_runfilesget_transitive_runfiles


8
get_transitive_srcsget_transitive_srcs

%Implementation details for rb_library�
)

rules_rubyruby/privateproviders.bzl�get_bundle_envWObtain the BUNDLE_* environment variables for a target and its transitive dependencies.*�
�
get_bundle_env+
envsa list of environment variables (:
deps.a list of targets that are direct dependencies (WObtain the BUNDLE_* environment variables for a target and its transitive dependencies."6
4a collection of the transitive environment variables2:
get_bundle_env(@@rules_ruby//ruby/private:providers.bzl
]]�get_transitive_dataCObtain the data files for a target and its transitive dependencies.*�
�
get_transitive_data 
dataa list of data files (:
deps.a list of targets that are direct dependencies (CObtain the data files for a target and its transitive dependencies."+
)a collection of the transitive data files2?
get_transitive_data(@@rules_ruby//ruby/private:providers.bzl
00�get_transitive_depsEObtain the dependencies for a target and its transitive dependencies.*�
�
get_transitive_deps:
deps.a list of targets that are direct dependencies (EObtain the dependencies for a target and its transitive dependencies."-
+a collection of the transitive dependencies2?
get_transitive_deps(@@rules_ruby//ruby/private:providers.bzl
>>�get_transitive_runfilesMObtain the runfiles for a target, its transitive data files and dependencies.*�
�
get_transitive_runfiles
runfilesthe runfiles ("
srcsa list of source files ( 
dataa list of data files (:
deps.a list of targets that are direct dependencies (MObtain the runfiles for a target, its transitive data files and dependencies."
the runfiles2C
get_transitive_runfiles(@@rules_ruby//ruby/private:providers.bzl
LL�get_transitive_srcsEObtain the source files for a target and its transitive dependencies.*�
�
get_transitive_srcs"
srcsa list of source files (:
deps.a list of targets that are direct dependencies (EObtain the source files for a target and its transitive dependencies."(
&a collection of the transitive sources2?
get_transitive_srcs(@@rules_ruby//ruby/private:providers.bzl
""�BundlerInfo!Provider for Bundler installation2�
�
BundlerInfo!Provider for Bundler installation"
binBinstubs path (BUNDLE_BIN).)
gemfileGemfile path (BUNDLE_GEMFILE)."
pathBundle path (BUNDLE_PATH).$
envBundle environment variables."7
BundlerInfo(@@rules_ruby//ruby/private:providers.bzl
$
"
binBinstubs path (BUNDLE_BIN).+
)
gemfileGemfile path (BUNDLE_GEMFILE).$
"
pathBundle path (BUNDLE_PATH).&
$
envBundle environment variables.�GemInfoProvider for a packed Ruby gem2�
�
GemInfoProvider for a packed Ruby gem
name	Gem name.
versionGem version."3
GemInfo(@@rules_ruby//ruby/private:providers.bzl


name	Gem name.

versionGem version.�RubyFilesInfoProvider for Ruby files2�
�
RubyFilesInfoProvider for Ruby files
binaryMain Ruby script.<
transitive_data)Transitive data files to add to runfiles.=
transitive_deps*Transitive dependencies to get files from.)
transitive_srcsTransitive Ruby files.7

bundle_env)Bundle environment variables (deprecated)"9
RubyFilesInfo(@@rules_ruby//ruby/private:providers.bzl


binaryMain Ruby script.>
<
transitive_data)Transitive data files to add to runfiles.?
=
transitive_deps*Transitive dependencies to get files from.+
)
transitive_srcsTransitive Ruby files.9
7

bundle_env)Bundle environment variables (deprecated),Providers for interoperability between rules�7
$

rules_rubyruby/privatetest.bzl�4rb_test�
Runs a Ruby test.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
|-- lib
|   |-- BUILD
|   |-- gem
|   |   |-- BUILD
|   |   |-- add.rb
|   |   |-- subtract.rb
|   |   `-- version.rb
|   `-- gem.rb
`-- spec
    |-- BUILD
    |-- add_spec.rb
    |-- spec_helper.rb
    `-- subtract_spec.rb
```

You can run all tests inside `spec/` by defining individual targets:

`spec/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_library", "rb_test")

rb_library(
    name = "spec_helper",
    srcs = ["spec_helper.rb"],
)

rb_test(
    name = "add",
    srcs = ["add_spec.rb"],
    args = ["spec/add_spec.rb"],
    main = "@bundle//bin:rspec",
    deps = [
        ":spec_helper",
        "@bundle",
    ],
)

rb_test(
    name = "subtract",
    srcs = ["subtract_spec.rb"],
    args = ["spec/subtract_spec.rb"],
    main = "@bundle//bin:rspec",
    deps = [
        ":spec_helper",
        "@bundle",
    ],
)
```

```output
$ bazel test spec/...
...
//spec:add                                                               PASSED in 0.4s
//spec:subtract                                                          PASSED in 0.4s

Executed 2 out of 2 tests: 2 tests pass.
```

Since `rb_test()` is a wrapper around `rb_binary()`, you can also use it to run
a Ruby binary script available in Gemfile dependencies, by passing `main`
argument with a path to a Bundler binary stub.

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_test")

package(default_visibility = ["//:__subpackages__"])

rb_test(
    name = "rubocop",
    args = ["lib/"],
    main = "@bundle//bin:rubocop",
    tags = ["no-sandbox"],
    deps = [
        "//lib:gem",
        "@bundle",
    ],
)
```

```output
$ bazel test :rubocop
...
//:rubocop                                                               PASSED in 0.8s

Executed 1 out of 1 test: 1 test passes.
```

Note that you can also `run` every test target passing extra arguments to
the Ruby script. For example, you can re-use `:rubocop` target to perform autocorrect:

```output
$ bazel run :rubocop -- --autocorrect-all
...
Inspecting 11 files
.C.........

Offenses:

gem.gemspec:1:1: C: [Corrected] Style/FrozenStringLiteralComment: Missing frozen string literal comment.
root = File.expand_path(__dir__)
^
gem.gemspec:2:1: C: [Corrected] Layout/EmptyLineAfterMagicComment: Add an empty line after magic comments.
root = File.expand_path(__dir__)
^

11 files inspected, 2 offenses detected, 2 offenses corrected
```
"� 
�
rb_test�
Runs a Ruby test.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
|-- lib
|   |-- BUILD
|   |-- gem
|   |   |-- BUILD
|   |   |-- add.rb
|   |   |-- subtract.rb
|   |   `-- version.rb
|   `-- gem.rb
`-- spec
    |-- BUILD
    |-- add_spec.rb
    |-- spec_helper.rb
    `-- subtract_spec.rb
```

You can run all tests inside `spec/` by defining individual targets:

`spec/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_library", "rb_test")

rb_library(
    name = "spec_helper",
    srcs = ["spec_helper.rb"],
)

rb_test(
    name = "add",
    srcs = ["add_spec.rb"],
    args = ["spec/add_spec.rb"],
    main = "@bundle//bin:rspec",
    deps = [
        ":spec_helper",
        "@bundle",
    ],
)

rb_test(
    name = "subtract",
    srcs = ["subtract_spec.rb"],
    args = ["spec/subtract_spec.rb"],
    main = "@bundle//bin:rspec",
    deps = [
        ":spec_helper",
        "@bundle",
    ],
)
```

```output
$ bazel test spec/...
...
//spec:add                                                               PASSED in 0.4s
//spec:subtract                                                          PASSED in 0.4s

Executed 2 out of 2 tests: 2 tests pass.
```

Since `rb_test()` is a wrapper around `rb_binary()`, you can also use it to run
a Ruby binary script available in Gemfile dependencies, by passing `main`
argument with a path to a Bundler binary stub.

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_test")

package(default_visibility = ["//:__subpackages__"])

rb_test(
    name = "rubocop",
    args = ["lib/"],
    main = "@bundle//bin:rubocop",
    tags = ["no-sandbox"],
    deps = [
        "//lib:gem",
        "@bundle",
    ],
)
```

```output
$ bazel test :rubocop
...
//:rubocop                                                               PASSED in 0.8s

Executed 1 out of 1 test: 1 test passes.
```

Note that you can also `run` every test target passing extra arguments to
the Ruby script. For example, you can re-use `:rubocop` target to perform autocorrect:

```output
$ bazel run :rubocop -- --autocorrect-all
...
Inspecting 11 files
.C.........

Offenses:

gem.gemspec:1:1: C: [Corrected] Style/FrozenStringLiteralComment: Missing frozen string literal comment.
root = File.expand_path(__dir__)
^
gem.gemspec:2:1: C: [Corrected] Layout/EmptyLineAfterMagicComment: Add an empty line after magic comments.
root = File.expand_path(__dir__)
^

11 files inspected, 2 offenses detected, 2 offenses corrected
```
*
nameA unique name for this target. \
dataNList of runtime dependencies needed by a program that depends on this library.2[]A
deps3List of other Ruby libraries the target depends on.2[]�
env~
Environment variables to use during execution.

Supports `$(location)` expansion for targets from `srcs`, `data` and `deps`.

2{}[
env_inheritFList of environment variable names to be inherited by the test runner.2[]�
main�
Ruby script to run. It may also be a binary stub generated by Bundler.
If omitted, it defaults to the Ruby interpreter.

Use a built-in `args` attribute to pass extra arguments to the script.
2NoneB
srcs4List of Ruby source files used to build the library.2[]".
rb_test#@@rules_ruby//ruby/private:test.bzl
,
*
nameA unique name for this target. ^
\
dataNList of runtime dependencies needed by a program that depends on this library.2[]C
A
deps3List of other Ruby libraries the target depends on.2[]�
�
env~
Environment variables to use during execution.

Supports `$(location)` expansion for targets from `srcs`, `data` and `deps`.

2{}]
[
env_inheritFList of environment variable names to be inherited by the test runner.2[]�
�
main�
Ruby script to run. It may also be a binary stub generated by Bundler.
If omitted, it defaults to the Ruby interpreter.

Use a built-in `args` attribute to pass extra arguments to the script.
2NoneD
B
srcs4List of Ruby source files used to build the library.2[]�
//ruby/private:binary.bzlr�
&

rules_rubyruby/private
binary.bzl
ATTRSATTRS
/4.
rb_binary_implrb_binary_impl
8F
H}
//ruby/private:library.bzlr]
'

rules_rubyruby/privatelibrary.bzl$
ATTRSLIBRARY_ATTRS
/<
G"Implementation details for rb_test�
)

rules_rubyruby/privatetoolchain.bzl�rb_register_toolchains�Register a Ruby toolchain and lazily download the Ruby Interpreter.

* _(For MRI on Linux and macOS)_ Installed using [ruby-build](https://github.com/rbenv/ruby-build).
* _(For MRI on Windows)_ Installed using [RubyInstaller](https://rubyinstaller.org).
* _(For JRuby on any OS)_ Downloaded and installed directly from [official website](https://www.jruby.org).
* _(For TruffleRuby on Linux and macOS)_ Installed using [ruby-build](https://github.com/rbenv/ruby-build).
* _(For "system")_ Ruby found on the PATH is used. Please note that builds are not hermetic in this case.

`WORKSPACE`:
```bazel
load("@rules_ruby//ruby:deps.bzl", "rb_register_toolchains")

rb_register_toolchains(
    version = "3.0.6"
)
```

Once registered, you can use the toolchain directly as it provides all the binaries:

```output
$ bazel run @ruby -- -e "puts RUBY_VERSION"
$ bazel run @ruby//:bundle -- update
$ bazel run @ruby//:gem -- install rails
```
*�
�
rb_register_toolchainsH
name6base name of resulting repositories, by default "ruby""ruby"(f
versionSa semver version of MRI, or a string like [interpreter type]-[version], or "system"None(Q
version_file9.ruby-version or .tool-versions file to read version fromNone(@
msys2_packagesextra MSYS2 packages to install["libyaml"](^
registerJwhether to register the resulting toolchains, should be False under bzlmodTrue(M
kwargsAadditional parameters to the downloader for this interpreter type(�Register a Ruby toolchain and lazily download the Ruby Interpreter.

* _(For MRI on Linux and macOS)_ Installed using [ruby-build](https://github.com/rbenv/ruby-build).
* _(For MRI on Windows)_ Installed using [RubyInstaller](https://rubyinstaller.org).
* _(For JRuby on any OS)_ Downloaded and installed directly from [official website](https://www.jruby.org).
* _(For TruffleRuby on Linux and macOS)_ Installed using [ruby-build](https://github.com/rbenv/ruby-build).
* _(For "system")_ Ruby found on the PATH is used. Please note that builds are not hermetic in this case.

`WORKSPACE`:
```bazel
load("@rules_ruby//ruby:deps.bzl", "rb_register_toolchains")

rb_register_toolchains(
    version = "3.0.6"
)
```

Once registered, you can use the toolchain directly as it provides all the binaries:

```output
$ bazel run @ruby -- -e "puts RUBY_VERSION"
$ bazel run @ruby//:bundle -- update
$ bazel run @ruby//:gem -- install rails
```
2B
rb_register_toolchains(@@rules_ruby//ruby/private:toolchain.bzl
*_rb_download2_rb_download�
//ruby/private:download.bzlrc
(

rules_rubyruby/privatedownload.bzl)
rb_download_rb_download
0<
M�
-//ruby/private/toolchain:repository_proxy.bzlr�
:

rules_rubyruby/private/toolchainrepository_proxy.bzlM
rb_toolchain_repository_proxy_rb_toolchain_repository_proxy
B`
�)	DEFAULT_RUBY_REPOSITORYrubyjruby1Repository rule for registering Ruby interpreters�?
%

rules_rubyruby/private	utils.bzl�convert_env_to_script?Converts an env dictionary to a string of batch/shell commands.*�
�
convert_env_to_script
ctxrule context (.
env#dictionary of environment variables (?Converts an env dictionary to a string of batch/shell commands."6
4a string with export environment variables commands.2=
convert_env_to_script$@@rules_ruby//ruby/private:utils.bzl
UUk
is_windows*[
K

is_windows	
ctx (22

is_windows$@@rules_ruby//ruby/private:utils.bzl
QQ�join_and_indent=Convers a list of strings to a pretty indented BUILD variant.*�
�
join_and_indent
nameslist of strings (:
indentation_level how many 4 spaces to indent with2(=Convers a list of strings to a pretty indented BUILD variant."
indented string27
join_and_indent$@@rules_ruby//ruby/private:utils.bzl
zz� normalize_bzlmod_repository_name�Converts Bzlmod repostory to its private name.

This is needed to define a target that is called the same as the repository.
For example, given a canonical name "rules_ruby~override~ruby~bundle",
the function would return "bundle" as the name.

This is a hacky workaround and will be fixed upstream.
See https://github.com/bazelbuild/bazel/issues/20486.
*�
�
 normalize_bzlmod_repository_name%
namecanonical repository name (�Converts Bzlmod repostory to its private name.

This is needed to define a target that is called the same as the repository.
For example, given a canonical name "rules_ruby~override~ruby~bundle",
the function would return "bundle" as the name.

This is a hacky workaround and will be fixed upstream.
See https://github.com/bazelbuild/bazel/issues/20486.
"
repository name2H
 normalize_bzlmod_repository_name$@@rules_ruby//ruby/private:utils.bzl
���normalize_path+Converts path to an OS-specific equivalent.*�
�
normalize_path
ctxrule context (
pathfilepath string (+Converts path to an OS-specific equivalent."
an OS-specific path.26
normalize_path$@@rules_ruby//ruby/private:utils.bzl
kk�to_rlocation_path;Returns source path that can be used with runfiles library.*�
�
to_rlocation_path
source (;Returns source path that can be used with runfiles library.29
to_rlocation_path$@@rules_ruby//ruby/private:utils.bzl
���		BASH_RLOCATION_FUNCTION�
# --- begin runfiles.bash initialization v2 ---
set -uo pipefail; f=bazel_tools/tools/bash/runfiles/runfiles.bash
source "${RUNFILES_DIR:-/dev/null}/$f" 2>/dev/null || \
source "$(grep -sm1 "^$f " "${RUNFILES_MANIFEST_FILE:-/dev/null}" | cut -f2- -d' ')" 2>/dev/null || \
source "$0.runfiles/$f" 2>/dev/null || \
source "$(grep -sm1 "^$f " "$0.runfiles_manifest" | cut -f2- -d' ')" 2>/dev/null || \
source "$(grep -sm1 "^$f " "$0.exe.runfiles_manifest" | cut -f2- -d' ')" 2>/dev/null || \
{ echo>&2 "ERROR: cannot find $f"; exit 1; }; f=; set -e
# --- end runfiles.bash initialization v2 ---
j��
# --- begin runfiles.bash initialization v2 ---
set -uo pipefail; f=bazel_tools/tools/bash/runfiles/runfiles.bash
source "${RUNFILES_DIR:-/dev/null}/$f" 2>/dev/null || \
source "$(grep -sm1 "^$f " "${RUNFILES_MANIFEST_FILE:-/dev/null}" | cut -f2- -d' ')" 2>/dev/null || \
source "$0.runfiles/$f" 2>/dev/null || \
source "$(grep -sm1 "^$f " "$0.runfiles_manifest" | cut -f2- -d' ')" 2>/dev/null || \
source "$(grep -sm1 "^$f " "$0.exe.runfiles_manifest" | cut -f2- -d' ')" 2>/dev/null || \
{ echo>&2 "ERROR: cannot find $f"; exit 1; }; f=; set -e
# --- end runfiles.bash initialization v2 ---
�#	BATCH_RLOCATION_FUNCTION�
rem Usage of rlocation function:
rem        call :rlocation <runfile_path> <abs_path>
rem        The rlocation function maps the given <runfile_path> to its absolute
rem        path and stores the result in a variable named <abs_path>.
rem        This function fails if the <runfile_path> doesn't exist in mainifest
rem        file.
:: Start of rlocation
goto :rlocation_end
:rlocation
if "%~2" equ "" (
  echo>&2 ERROR: Expected two arguments for rlocation function.
  exit 1
)
if "%RUNFILES_MANIFEST_ONLY%" neq "1" (
  set %~2=%~1
  exit /b 0
)
if exist "%RUNFILES_DIR%" (
  set RUNFILES_MANIFEST_FILE=%RUNFILES_DIR%_manifest
)
if "%RUNFILES_MANIFEST_FILE%" equ "" (
  set RUNFILES_MANIFEST_FILE=%~f0.runfiles\MANIFEST
)
if not exist "%RUNFILES_MANIFEST_FILE%" (
  set RUNFILES_MANIFEST_FILE=%~f0.runfiles_manifest
)
set MF=%RUNFILES_MANIFEST_FILE:/=\%
if not exist "%MF%" (
  echo>&2 ERROR: Manifest file %MF% does not exist.
  exit 1
)
set runfile_path=%~1
set abs_path=
for /F "tokens=2* usebackq" %%i in (`%SYSTEMROOT%\system32\findstr.exe /l /c:"!runfile_path! " "%MF%"`) do (
  set abs_path=%%i
)
:: There should be a way to locate the fully resolved path to a file in runfiles
:: because the manifest doesn't contain paths to files in directories. This prevents
:: finding Bundler-generated binstubs (runfiles manifest has only `bin/private` record).
:: It works fine on runfiles.bash, so it's a matter of making a better batch script that
:: handles all the cases. PRs are welcome but current Ruby ruleset maintainers don't 
:: have enough Windows scripting knowledge. Below is a naive attempt to make it work
:: but it fails in certain cases, so this functionality is completely disabled.
::
:: if "!abs_path!" equ "" (
::   if exist %~f0.runfiles\!runfile_path:/=\! (
::     set pshpath=%~f0.runfiles\!runfile_path:/=\!
::     for /f %%A in ('powershell -Command "Get-Item -LiteralPath \"!pshpath!\" | Get-ItemProperty | Select-Object -ExpandProperty Target"') do (
::       set abs_path=%%A
::       set abs_path=!abs_path:\=/!
::     )
::   )
:: )
if "!abs_path!" equ "" (
  echo>&2 ERROR: !runfile_path! not found in runfiles manifest
  exit 1
)
set %~2=!abs_path!
exit /b 0
:rlocation_end
:: End of rlocation
j��
rem Usage of rlocation function:
rem        call :rlocation <runfile_path> <abs_path>
rem        The rlocation function maps the given <runfile_path> to its absolute
rem        path and stores the result in a variable named <abs_path>.
rem        This function fails if the <runfile_path> doesn't exist in mainifest
rem        file.
:: Start of rlocation
goto :rlocation_end
:rlocation
if "%~2" equ "" (
  echo>&2 ERROR: Expected two arguments for rlocation function.
  exit 1
)
if "%RUNFILES_MANIFEST_ONLY%" neq "1" (
  set %~2=%~1
  exit /b 0
)
if exist "%RUNFILES_DIR%" (
  set RUNFILES_MANIFEST_FILE=%RUNFILES_DIR%_manifest
)
if "%RUNFILES_MANIFEST_FILE%" equ "" (
  set RUNFILES_MANIFEST_FILE=%~f0.runfiles\MANIFEST
)
if not exist "%RUNFILES_MANIFEST_FILE%" (
  set RUNFILES_MANIFEST_FILE=%~f0.runfiles_manifest
)
set MF=%RUNFILES_MANIFEST_FILE:/=\%
if not exist "%MF%" (
  echo>&2 ERROR: Manifest file %MF% does not exist.
  exit 1
)
set runfile_path=%~1
set abs_path=
for /F "tokens=2* usebackq" %%i in (`%SYSTEMROOT%\system32\findstr.exe /l /c:"!runfile_path! " "%MF%"`) do (
  set abs_path=%%i
)
:: There should be a way to locate the fully resolved path to a file in runfiles
:: because the manifest doesn't contain paths to files in directories. This prevents
:: finding Bundler-generated binstubs (runfiles manifest has only `bin/private` record).
:: It works fine on runfiles.bash, so it's a matter of making a better batch script that
:: handles all the cases. PRs are welcome but current Ruby ruleset maintainers don't 
:: have enough Windows scripting knowledge. Below is a naive attempt to make it work
:: but it fails in certain cases, so this functionality is completely disabled.
::
:: if "!abs_path!" equ "" (
::   if exist %~f0.runfiles\!runfile_path:/=\! (
::     set pshpath=%~f0.runfiles\!runfile_path:/=\!
::     for /f %%A in ('powershell -Command "Get-Item -LiteralPath \"!pshpath!\" | Get-ItemProperty | Select-Object -ExpandProperty Target"') do (
::       set abs_path=%%A
::       set abs_path=!abs_path:\=/!
::     )
::   )
:: )
if "!abs_path!" equ "" (
  echo>&2 ERROR: !runfile_path! not found in runfiles manifest
  exit 1
)
set %~2=!abs_path!
exit /b 0
:rlocation_end
:: End of rlocation
LHelpers to get location of files in runfiles. Vendored from aspect_bazel_lib��


rules_rubyrubydefs.bzl�(	rb_binary�
Runs a Ruby binary.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

One of the files can be run as a Ruby script:

`lib/gem/version.rb`:
```ruby
module GEM
  VERSION = '0.1.0'
end

puts "Version is: #{GEM::VERSION}" if __FILE__ == $PROGRAM_NAME
```

You can run this script by defining a target:

`lib/gem/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_binary", "rb_library")

rb_library(
    name = "version",
    srcs = ["version.rb"],
)

rb_binary(
    name = "print-version",
    args = ["lib/gem/version.rb"],
    deps = [":version"],
)
```

```output
$ bazel run lib/gem:print-version
...
Version is: 0.1.0
```

You can also run general purpose Ruby scripts that rely on a Ruby interpreter in PATH:

`lib/gem/add.rb`:
```ruby
#!/usr/bin/env ruby

a, b = *ARGV
puts Integer(a) + Integer(b)
```

`lib/gem/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_binary", "rb_library")

rb_library(
    name = "add",
    srcs = ["add.rb"],
)

rb_binary(
    name = "add-numbers",
    main = "add.rb",
    deps = [":add"],
)
```

```output
$ bazel run lib/gem:add-numbers 1 2
...
3
```

You can also run a Ruby binary script available in Gemfile dependencies,
by passing `bin` argument with a path to a Bundler binary stub:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_binary")

package(default_visibility = ["//:__subpackages__"])

rb_binary(
    name = "rake",
    main = "@bundle//bin:rake",
    deps = [
        "//lib:gem",
        "@bundle",
    ],
)
```

```output
$ bazel run :rake -- --version
...
rake, version 13.1.0
```
"�
�
	rb_binary�
Runs a Ruby binary.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

One of the files can be run as a Ruby script:

`lib/gem/version.rb`:
```ruby
module GEM
  VERSION = '0.1.0'
end

puts "Version is: #{GEM::VERSION}" if __FILE__ == $PROGRAM_NAME
```

You can run this script by defining a target:

`lib/gem/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_binary", "rb_library")

rb_library(
    name = "version",
    srcs = ["version.rb"],
)

rb_binary(
    name = "print-version",
    args = ["lib/gem/version.rb"],
    deps = [":version"],
)
```

```output
$ bazel run lib/gem:print-version
...
Version is: 0.1.0
```

You can also run general purpose Ruby scripts that rely on a Ruby interpreter in PATH:

`lib/gem/add.rb`:
```ruby
#!/usr/bin/env ruby

a, b = *ARGV
puts Integer(a) + Integer(b)
```

`lib/gem/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_binary", "rb_library")

rb_library(
    name = "add",
    srcs = ["add.rb"],
)

rb_binary(
    name = "add-numbers",
    main = "add.rb",
    deps = [":add"],
)
```

```output
$ bazel run lib/gem:add-numbers 1 2
...
3
```

You can also run a Ruby binary script available in Gemfile dependencies,
by passing `bin` argument with a path to a Bundler binary stub:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_binary")

package(default_visibility = ["//:__subpackages__"])

rb_binary(
    name = "rake",
    main = "@bundle//bin:rake",
    deps = [
        "//lib:gem",
        "@bundle",
    ],
)
```

```output
$ bazel run :rake -- --version
...
rake, version 13.1.0
```
*
nameA unique name for this target. \
dataNList of runtime dependencies needed by a program that depends on this library.2[]A
deps3List of other Ruby libraries the target depends on.2[]�
env~
Environment variables to use during execution.

Supports `$(location)` expansion for targets from `srcs`, `data` and `deps`.

2{}[
env_inheritFList of environment variable names to be inherited by the test runner.2[]�
main�
Ruby script to run. It may also be a binary stub generated by Bundler.
If omitted, it defaults to the Ruby interpreter.

Use a built-in `args` attribute to pass extra arguments to the script.
2NoneB
srcs4List of Ruby source files used to build the library.2[]"(
	rb_binary@@rules_ruby//ruby:defs.bzl
��,
*
nameA unique name for this target. ^
\
dataNList of runtime dependencies needed by a program that depends on this library.2[]C
A
deps3List of other Ruby libraries the target depends on.2[]�
�
env~
Environment variables to use during execution.

Supports `$(location)` expansion for targets from `srcs`, `data` and `deps`.

2{}]
[
env_inheritFList of environment variable names to be inherited by the test runner.2[]�
�
main�
Ruby script to run. It may also be a binary stub generated by Bundler.
If omitted, it defaults to the Ruby interpreter.

Use a built-in `args` attribute to pass extra arguments to the script.
2NoneD
B
srcs4List of Ruby source files used to build the library.2[]�	rb_bundle_install�
Installs Bundler dependencies from cached gems.

You normally don't need to call this rule directly as it's an internal one
used by `rb_bundle_fetch()`.
"�
�
rb_bundle_install�
Installs Bundler dependencies from cached gems.

You normally don't need to call this rule directly as it's an internal one
used by `rb_bundle_fetch()`.
*
nameA unique name for this target. >
env1Environment variables to use during installation.
2{}4
gemfile%Gemfile to install dependencies from. >
gemfile_lock*Gemfile.lock to install dependencies from. T
gemsHList of gems in vendor/cache that are used to install dependencies from. B
srcs4List of Ruby source files used to build the library.2[]"0
rb_bundle_install@@rules_ruby//ruby:defs.bzl
pp,
*
nameA unique name for this target. @
>
env1Environment variables to use during installation.
2{}6
4
gemfile%Gemfile to install dependencies from. @
>
gemfile_lock*Gemfile.lock to install dependencies from. V
T
gemsHList of gems in vendor/cache that are used to install dependencies from. D
B
srcs4List of Ruby source files used to build the library.2[]�rb_gem�
Exposes a Ruby gem file.

You normally don't need to call this rule directly as it's an internal one
used by `rb_bundle_fetch()`.
"�
�
rb_gem�
Exposes a Ruby gem file.

You normally don't need to call this rule directly as it's an internal one
used by `rb_bundle_fetch()`.
*
nameA unique name for this target. 
gem	Gem file. "%
rb_gem@@rules_ruby//ruby:defs.bzl
,
*
nameA unique name for this target. 

gem	Gem file. �rb_gem_build�
Builds a Ruby gem.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

And a RubyGem specification is:

`gem.gemspec`:
```ruby
root = File.expand_path(__dir__)
$LOAD_PATH.push(File.expand_path('lib', root))
require 'gem/version'

Gem::Specification.new do |s|
  s.name = 'example'
  s.version = GEM::VERSION

  s.authors = ['Foo Bar']
  s.email = ['foobar@gmail.com']
  s.homepage = 'http://rubygems.org'
  s.license = 'MIT'

  s.summary = 'Example'
  s.description = 'Example gem'
  s.files = ['Gemfile'] + Dir['lib/**/*']

  s.require_paths = ['lib']
  s.add_dependency 'rake', '~> 10'
  s.add_development_dependency 'rspec', '~> 3.0'
  s.add_development_dependency 'rubocop', '~> 1.10'
end
```

You can now package everything into a `.gem` file by defining a target:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_gem_build")

package(default_visibility = ["//:__subpackages__"])

rb_gem_build(
    name = "gem-build",
    gemspec = "gem.gemspec",
    deps = [
        "//lib:gem",
        "@bundle",
    ],
)
```

```output
$ bazel build :gem-build
...
  Successfully built RubyGem
  Name: example
  Version: 0.1.0
  File: example-0.1.0.gem
...
```
"�
�
rb_gem_build�
Builds a Ruby gem.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

And a RubyGem specification is:

`gem.gemspec`:
```ruby
root = File.expand_path(__dir__)
$LOAD_PATH.push(File.expand_path('lib', root))
require 'gem/version'

Gem::Specification.new do |s|
  s.name = 'example'
  s.version = GEM::VERSION

  s.authors = ['Foo Bar']
  s.email = ['foobar@gmail.com']
  s.homepage = 'http://rubygems.org'
  s.license = 'MIT'

  s.summary = 'Example'
  s.description = 'Example gem'
  s.files = ['Gemfile'] + Dir['lib/**/*']

  s.require_paths = ['lib']
  s.add_dependency 'rake', '~> 10'
  s.add_development_dependency 'rspec', '~> 3.0'
  s.add_development_dependency 'rubocop', '~> 1.10'
end
```

You can now package everything into a `.gem` file by defining a target:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_gem_build")

package(default_visibility = ["//:__subpackages__"])

rb_gem_build(
    name = "gem-build",
    gemspec = "gem.gemspec",
    deps = [
        "//lib:gem",
        "@bundle",
    ],
)
```

```output
$ bazel build :gem-build
...
  Successfully built RubyGem
  Name: example
  Version: 0.1.0
  File: example-0.1.0.gem
...
```
*
nameA unique name for this target. Z

bundle_envFList of bundle environment variables to set when building the library.
2{}\
dataNList of runtime dependencies needed by a program that depends on this library.2[]A
deps3List of other Ruby libraries the target depends on.2[]4
gemspec%Gemspec file to use for gem building. B
srcs4List of Ruby source files used to build the library.2[]"+
rb_gem_build@@rules_ruby//ruby:defs.bzl
aa,
*
nameA unique name for this target. \
Z

bundle_envFList of bundle environment variables to set when building the library.
2{}^
\
dataNList of runtime dependencies needed by a program that depends on this library.2[]C
A
deps3List of other Ruby libraries the target depends on.2[]6
4
gemspec%Gemspec file to use for gem building. D
B
srcs4List of Ruby source files used to build the library.2[]�rb_gem_install�
Installs a built Ruby gem.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem and `rb_gem_build()` is used
to build a Ruby gem package from the sources.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

You can now install the built `.gem` file by defining a target:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_gem_build", "rb_gem_install")

package(default_visibility = ["//:__subpackages__"])

rb_gem_build(
    name = "gem-build",
    gemspec = "gem.gemspec",
    deps = ["//lib:gem"],
)

rb_gem_install(
    name = "gem-install",
    gem = ":gem-build",
)
```

```output
$ bazel build :gem-install
...
Successfully installed example-0.1.0
1 gem installed
...
```
"�
�
rb_gem_install�
Installs a built Ruby gem.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem and `rb_gem_build()` is used
to build a Ruby gem package from the sources.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

You can now install the built `.gem` file by defining a target:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_gem_build", "rb_gem_install")

package(default_visibility = ["//:__subpackages__"])

rb_gem_build(
    name = "gem-build",
    gemspec = "gem.gemspec",
    deps = ["//lib:gem"],
)

rb_gem_install(
    name = "gem-install",
    gem = ":gem-build",
)
```

```output
$ bazel build :gem-install
...
Successfully installed example-0.1.0
1 gem installed
...
```
*
nameA unique name for this target. 
gemGem file to install. "-
rb_gem_install@@rules_ruby//ruby:defs.bzl
BB,
*
nameA unique name for this target. !

gemGem file to install. �rb_gem_push�
Pushes a built Ruby gem.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem and `rb_gem_build()` is used
to build a Ruby gem package from the sources.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

You can now release the built `.gem` file to RubyGems by defining a target:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_gem_build", "rb_gem_push")

package(default_visibility = ["//:__subpackages__"])

rb_gem_build(
    name = "gem-build",
    gemspec = "gem.gemspec",
    deps = ["//lib:gem"],
)

rb_gem_push(
    name = "gem-release",
    gem = ":gem-build",
)
```

```output
$ bazel run :gem-release
...
Pushing gem to https://rubygems.org...
Successfully registered gem: example (0.1.0)
```
"�
�
rb_gem_push�
Pushes a built Ruby gem.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem and `rb_gem_build()` is used
to build a Ruby gem package from the sources.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

You can now release the built `.gem` file to RubyGems by defining a target:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_gem_build", "rb_gem_push")

package(default_visibility = ["//:__subpackages__"])

rb_gem_build(
    name = "gem-build",
    gemspec = "gem.gemspec",
    deps = ["//lib:gem"],
)

rb_gem_push(
    name = "gem-release",
    gem = ":gem-build",
)
```

```output
$ bazel run :gem-release
...
Pushing gem to https://rubygems.org...
Successfully registered gem: example (0.1.0)
```
*
nameA unique name for this target. Z

bundle_envFList of bundle environment variables to set when building the library.
2{}\
dataNList of runtime dependencies needed by a program that depends on this library.2[]A
deps3List of other Ruby libraries the target depends on.2[]�
env~
Environment variables to use during execution.

Supports `$(location)` expansion for targets from `srcs`, `data` and `deps`.

2{}[
env_inheritFList of environment variable names to be inherited by the test runner.2[]k
gem`
Gem file to push to RubyGems. You would usually use an output of `rb_gem_build()` target here.
 B
srcs4List of Ruby source files used to build the library.2[]"*
rb_gem_push@@rules_ruby//ruby:defs.bzl
&&,
*
nameA unique name for this target. \
Z

bundle_envFList of bundle environment variables to set when building the library.
2{}^
\
dataNList of runtime dependencies needed by a program that depends on this library.2[]C
A
deps3List of other Ruby libraries the target depends on.2[]�
�
env~
Environment variables to use during execution.

Supports `$(location)` expansion for targets from `srcs`, `data` and `deps`.

2{}]
[
env_inheritFList of environment variable names to be inherited by the test runner.2[]m
k
gem`
Gem file to push to RubyGems. You would usually use an output of `rb_gem_build()` target here.
 D
B
srcs4List of Ruby source files used to build the library.2[]�
rb_library�	
Defines a Ruby library.

Suppose you have the following Ruby gem:

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

You can define packages for the gem source files:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_library")

package(default_visibility = ["//:__subpackages__"])

rb_library(
    name = "gem",
    deps = ["//lib:gem"],
)
```

`lib/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_library")

package(default_visibility = ["//:__subpackages__"])

rb_library(
    name = "gem",
    srcs = ["gem.rb"],
    deps = [
        "//lib/gem:add",
        "//lib/gem:subtract",
        "//lib/gem:version",
    ],
)
```

`lib/gem/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_library")

package(default_visibility = ["//:__subpackages__"])

rb_library(
    name = "add",
    srcs = ["add.rb"],
)

rb_library(
    name = "subtract",
    srcs = ["subtract.rb"],
)

rb_library(
    name = "version",
    srcs = ["version.rb"],
)
```

Once the packages are defined, you can use them in other targets
such as `rb_gem_build()` to build a Ruby gem. See examples of
using other rules.
"�
�

rb_library�	
Defines a Ruby library.

Suppose you have the following Ruby gem:

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
`-- lib
    |-- BUILD
    |-- gem
    |   |-- BUILD
    |   |-- add.rb
    |   |-- subtract.rb
    |   `-- version.rb
    `-- gem.rb
```

You can define packages for the gem source files:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_library")

package(default_visibility = ["//:__subpackages__"])

rb_library(
    name = "gem",
    deps = ["//lib:gem"],
)
```

`lib/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_library")

package(default_visibility = ["//:__subpackages__"])

rb_library(
    name = "gem",
    srcs = ["gem.rb"],
    deps = [
        "//lib/gem:add",
        "//lib/gem:subtract",
        "//lib/gem:version",
    ],
)
```

`lib/gem/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_library")

package(default_visibility = ["//:__subpackages__"])

rb_library(
    name = "add",
    srcs = ["add.rb"],
)

rb_library(
    name = "subtract",
    srcs = ["subtract.rb"],
)

rb_library(
    name = "version",
    srcs = ["version.rb"],
)
```

Once the packages are defined, you can use them in other targets
such as `rb_gem_build()` to build a Ruby gem. See examples of
using other rules.
*
nameA unique name for this target. Z

bundle_envFList of bundle environment variables to set when building the library.
2{}\
dataNList of runtime dependencies needed by a program that depends on this library.2[]A
deps3List of other Ruby libraries the target depends on.2[]B
srcs4List of Ruby source files used to build the library.2[]")

rb_library@@rules_ruby//ruby:defs.bzl
>>,
*
nameA unique name for this target. \
Z

bundle_envFList of bundle environment variables to set when building the library.
2{}^
\
dataNList of runtime dependencies needed by a program that depends on this library.2[]C
A
deps3List of other Ruby libraries the target depends on.2[]D
B
srcs4List of Ruby source files used to build the library.2[]�4rb_test�
Runs a Ruby test.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
|-- lib
|   |-- BUILD
|   |-- gem
|   |   |-- BUILD
|   |   |-- add.rb
|   |   |-- subtract.rb
|   |   `-- version.rb
|   `-- gem.rb
`-- spec
    |-- BUILD
    |-- add_spec.rb
    |-- spec_helper.rb
    `-- subtract_spec.rb
```

You can run all tests inside `spec/` by defining individual targets:

`spec/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_library", "rb_test")

rb_library(
    name = "spec_helper",
    srcs = ["spec_helper.rb"],
)

rb_test(
    name = "add",
    srcs = ["add_spec.rb"],
    args = ["spec/add_spec.rb"],
    main = "@bundle//bin:rspec",
    deps = [
        ":spec_helper",
        "@bundle",
    ],
)

rb_test(
    name = "subtract",
    srcs = ["subtract_spec.rb"],
    args = ["spec/subtract_spec.rb"],
    main = "@bundle//bin:rspec",
    deps = [
        ":spec_helper",
        "@bundle",
    ],
)
```

```output
$ bazel test spec/...
...
//spec:add                                                               PASSED in 0.4s
//spec:subtract                                                          PASSED in 0.4s

Executed 2 out of 2 tests: 2 tests pass.
```

Since `rb_test()` is a wrapper around `rb_binary()`, you can also use it to run
a Ruby binary script available in Gemfile dependencies, by passing `main`
argument with a path to a Bundler binary stub.

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_test")

package(default_visibility = ["//:__subpackages__"])

rb_test(
    name = "rubocop",
    args = ["lib/"],
    main = "@bundle//bin:rubocop",
    tags = ["no-sandbox"],
    deps = [
        "//lib:gem",
        "@bundle",
    ],
)
```

```output
$ bazel test :rubocop
...
//:rubocop                                                               PASSED in 0.8s

Executed 1 out of 1 test: 1 test passes.
```

Note that you can also `run` every test target passing extra arguments to
the Ruby script. For example, you can re-use `:rubocop` target to perform autocorrect:

```output
$ bazel run :rubocop -- --autocorrect-all
...
Inspecting 11 files
.C.........

Offenses:

gem.gemspec:1:1: C: [Corrected] Style/FrozenStringLiteralComment: Missing frozen string literal comment.
root = File.expand_path(__dir__)
^
gem.gemspec:2:1: C: [Corrected] Layout/EmptyLineAfterMagicComment: Add an empty line after magic comments.
root = File.expand_path(__dir__)
^

11 files inspected, 2 offenses detected, 2 offenses corrected
```
"� 
�
rb_test�
Runs a Ruby test.

Suppose you have the following Ruby gem, where `rb_library()` is used
in `BUILD` files to define the packages for the gem.

```output
|-- BUILD
|-- Gemfile
|-- WORKSPACE
|-- gem.gemspec
|-- lib
|   |-- BUILD
|   |-- gem
|   |   |-- BUILD
|   |   |-- add.rb
|   |   |-- subtract.rb
|   |   `-- version.rb
|   `-- gem.rb
`-- spec
    |-- BUILD
    |-- add_spec.rb
    |-- spec_helper.rb
    `-- subtract_spec.rb
```

You can run all tests inside `spec/` by defining individual targets:

`spec/BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_library", "rb_test")

rb_library(
    name = "spec_helper",
    srcs = ["spec_helper.rb"],
)

rb_test(
    name = "add",
    srcs = ["add_spec.rb"],
    args = ["spec/add_spec.rb"],
    main = "@bundle//bin:rspec",
    deps = [
        ":spec_helper",
        "@bundle",
    ],
)

rb_test(
    name = "subtract",
    srcs = ["subtract_spec.rb"],
    args = ["spec/subtract_spec.rb"],
    main = "@bundle//bin:rspec",
    deps = [
        ":spec_helper",
        "@bundle",
    ],
)
```

```output
$ bazel test spec/...
...
//spec:add                                                               PASSED in 0.4s
//spec:subtract                                                          PASSED in 0.4s

Executed 2 out of 2 tests: 2 tests pass.
```

Since `rb_test()` is a wrapper around `rb_binary()`, you can also use it to run
a Ruby binary script available in Gemfile dependencies, by passing `main`
argument with a path to a Bundler binary stub.

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_test")

package(default_visibility = ["//:__subpackages__"])

rb_test(
    name = "rubocop",
    args = ["lib/"],
    main = "@bundle//bin:rubocop",
    tags = ["no-sandbox"],
    deps = [
        "//lib:gem",
        "@bundle",
    ],
)
```

```output
$ bazel test :rubocop
...
//:rubocop                                                               PASSED in 0.8s

Executed 1 out of 1 test: 1 test passes.
```

Note that you can also `run` every test target passing extra arguments to
the Ruby script. For example, you can re-use `:rubocop` target to perform autocorrect:

```output
$ bazel run :rubocop -- --autocorrect-all
...
Inspecting 11 files
.C.........

Offenses:

gem.gemspec:1:1: C: [Corrected] Style/FrozenStringLiteralComment: Missing frozen string literal comment.
root = File.expand_path(__dir__)
^
gem.gemspec:2:1: C: [Corrected] Layout/EmptyLineAfterMagicComment: Add an empty line after magic comments.
root = File.expand_path(__dir__)
^

11 files inspected, 2 offenses detected, 2 offenses corrected
```
*
nameA unique name for this target. \
dataNList of runtime dependencies needed by a program that depends on this library.2[]A
deps3List of other Ruby libraries the target depends on.2[]�
env~
Environment variables to use during execution.

Supports `$(location)` expansion for targets from `srcs`, `data` and `deps`.

2{}[
env_inheritFList of environment variable names to be inherited by the test runner.2[]�
main�
Ruby script to run. It may also be a binary stub generated by Bundler.
If omitted, it defaults to the Ruby interpreter.

Use a built-in `args` attribute to pass extra arguments to the script.
2NoneB
srcs4List of Ruby source files used to build the library.2[]"&
rb_test@@rules_ruby//ruby:defs.bzl
,
*
nameA unique name for this target. ^
\
dataNList of runtime dependencies needed by a program that depends on this library.2[]C
A
deps3List of other Ruby libraries the target depends on.2[]�
�
env~
Environment variables to use during execution.

Supports `$(location)` expansion for targets from `srcs`, `data` and `deps`.

2{}]
[
env_inheritFList of environment variable names to be inherited by the test runner.2[]�
�
main�
Ruby script to run. It may also be a binary stub generated by Bundler.
If omitted, it defaults to the Ruby interpreter.

Use a built-in `args` attribute to pass extra arguments to the script.
2NoneD
B
srcs4List of Ruby source files used to build the library.2[]|
//ruby/private:binary.bzlr]
&

rules_rubyruby/private
binary.bzl%
	rb_binary
_rb_binary
.8
G�
!//ruby/private:bundle_install.bzlru
.

rules_rubyruby/privatebundle_install.bzl5
rb_bundle_install_rb_bundle_install
6H
_p
//ruby/private:gem.bzlrT
#

rules_rubyruby/privategem.bzl
rb_gem_rb_gem
+2
>�
//ruby/private:gem_build.bzlrf
)

rules_rubyruby/privategem_build.bzl+
rb_gem_build_rb_gem_build
1>
P�
//ruby/private:gem_install.bzlrl
+

rules_rubyruby/privategem_install.bzl/
rb_gem_install_rb_gem_install
3B
V�
//ruby/private:gem_push.bzlrc
(

rules_rubyruby/privategem_push.bzl)
rb_gem_push_rb_gem_push
0<
M�
//ruby/private:library.bzlr`
'

rules_rubyruby/privatelibrary.bzl'

rb_library_rb_library
	/	:
		Jt
//ruby/private:test.bzlrW
$

rules_rubyruby/privatetest.bzl!
rb_test_rb_test

,
4


APublic API for rules�W


rules_rubyrubydeps.bzl�	rb_bundle:Wraps `rb_bundle_rule()` providing default toolchain name.*�
�
	rb_bundle<
	toolchaindefault Ruby toolchain BUILD"@ruby//:BUILD"(7
kwargs+underlying attrs passed to rb_bundle_rule()(:Wraps `rb_bundle_rule()` providing default toolchain name.2(
	rb_bundle@@rules_ruby//ruby:deps.bzl
*
_rb_bundle�rb_register_toolchains�Register a Ruby toolchain and lazily download the Ruby Interpreter.

* _(For MRI on Linux and macOS)_ Installed using [ruby-build](https://github.com/rbenv/ruby-build).
* _(For MRI on Windows)_ Installed using [RubyInstaller](https://rubyinstaller.org).
* _(For JRuby on any OS)_ Downloaded and installed directly from [official website](https://www.jruby.org).
* _(For TruffleRuby on Linux and macOS)_ Installed using [ruby-build](https://github.com/rbenv/ruby-build).
* _(For "system")_ Ruby found on the PATH is used. Please note that builds are not hermetic in this case.

`WORKSPACE`:
```bazel
load("@rules_ruby//ruby:deps.bzl", "rb_register_toolchains")

rb_register_toolchains(
    version = "3.0.6"
)
```

Once registered, you can use the toolchain directly as it provides all the binaries:

```output
$ bazel run @ruby -- -e "puts RUBY_VERSION"
$ bazel run @ruby//:bundle -- update
$ bazel run @ruby//:gem -- install rails
```
*�
�
rb_register_toolchainsH
name6base name of resulting repositories, by default "ruby""ruby"(f
versionSa semver version of MRI, or a string like [interpreter type]-[version], or "system"None(Q
version_file9.ruby-version or .tool-versions file to read version fromNone(@
msys2_packagesextra MSYS2 packages to install["libyaml"](^
registerJwhether to register the resulting toolchains, should be False under bzlmodTrue(M
kwargsAadditional parameters to the downloader for this interpreter type(�Register a Ruby toolchain and lazily download the Ruby Interpreter.

* _(For MRI on Linux and macOS)_ Installed using [ruby-build](https://github.com/rbenv/ruby-build).
* _(For MRI on Windows)_ Installed using [RubyInstaller](https://rubyinstaller.org).
* _(For JRuby on any OS)_ Downloaded and installed directly from [official website](https://www.jruby.org).
* _(For TruffleRuby on Linux and macOS)_ Installed using [ruby-build](https://github.com/rbenv/ruby-build).
* _(For "system")_ Ruby found on the PATH is used. Please note that builds are not hermetic in this case.

`WORKSPACE`:
```bazel
load("@rules_ruby//ruby:deps.bzl", "rb_register_toolchains")

rb_register_toolchains(
    version = "3.0.6"
)
```

Once registered, you can use the toolchain directly as it provides all the binaries:

```output
$ bazel run @ruby -- -e "puts RUBY_VERSION"
$ bazel run @ruby//:bundle -- update
$ bazel run @ruby//:gem -- install rails
```
2B
rb_register_toolchains(@@rules_ruby//ruby/private:toolchain.bzl
*_rb_download2_rb_download�&rb_bundle_fetch�

Fetches Bundler dependencies to be automatically installed by other targets.

Currently doesn't support installing gems from Git repositories,
see https://github.com/bazel-contrib/rules_ruby/issues/62.

`WORKSPACE`:
```bazel
load("@rules_ruby//ruby:deps.bzl", "rb_bundle_fetch")

rb_bundle_fetch(
    name = "bundle",
    gemfile = "//:Gemfile",
    gemfile_lock = "//:Gemfile.lock",
    srcs = [
        "//:gem.gemspec",
        "//:lib/gem/version.rb",
    ]
)
```

Checksums for gems in Gemfile.lock are printed by the ruleset during the build.
It's recommended to add them to `gem_checksums` attribute.

`WORKSPACE`:
```bazel
rb_bundle_fetch(
    name = "bundle",
    gemfile = "//:Gemfile",
    gemfile_lock = "//:Gemfile.lock",
    gem_checksums = {
        "ast-2.4.2": "1e280232e6a33754cde542bc5ef85520b74db2aac73ec14acef453784447cc12",
        "concurrent-ruby-1.2.2": "3879119b8b75e3b62616acc256c64a134d0b0a7a9a3fcba5a233025bcde22c4f",
    },
)
```

All the installed gems can be accessed using `@bundle` target and additionally
gems binary files can also be used via BUILD rules or directly with `bazel run`:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_test")

package(default_visibility = ["//:__subpackages__"])

rb_test(
    name = "rubocop",
    main = "@bundle//bin:rubocop",
    deps = ["@bundle"],
)
```
R�
�
rb_bundle_fetch�

Fetches Bundler dependencies to be automatically installed by other targets.

Currently doesn't support installing gems from Git repositories,
see https://github.com/bazel-contrib/rules_ruby/issues/62.

`WORKSPACE`:
```bazel
load("@rules_ruby//ruby:deps.bzl", "rb_bundle_fetch")

rb_bundle_fetch(
    name = "bundle",
    gemfile = "//:Gemfile",
    gemfile_lock = "//:Gemfile.lock",
    srcs = [
        "//:gem.gemspec",
        "//:lib/gem/version.rb",
    ]
)
```

Checksums for gems in Gemfile.lock are printed by the ruleset during the build.
It's recommended to add them to `gem_checksums` attribute.

`WORKSPACE`:
```bazel
rb_bundle_fetch(
    name = "bundle",
    gemfile = "//:Gemfile",
    gemfile_lock = "//:Gemfile.lock",
    gem_checksums = {
        "ast-2.4.2": "1e280232e6a33754cde542bc5ef85520b74db2aac73ec14acef453784447cc12",
        "concurrent-ruby-1.2.2": "3879119b8b75e3b62616acc256c64a134d0b0a7a9a3fcba5a233025bcde22c4f",
    },
)
```

All the installed gems can be accessed using `@bundle` target and additionally
gems binary files can also be used via BUILD rules or directly with `bazel run`:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_test")

package(default_visibility = ["//:__subpackages__"])

rb_test(
    name = "rubocop",
    main = "@bundle//bin:rubocop",
    deps = ["@bundle"],
)
```
.
name"A unique name for this repository. S
bundler_checksums8Custom map from Bundler version to its SHA-256 checksum.
2{}R
bundler_remote%Remote to fetch the bundler gem from.2"https://rubygems.org/">
env1Environment variables to use during installation.
2{}
gem_checksumshSHA-256 checksums for remote gems. Keys are gem names (e.g. foobar-1.2.3), values are SHA-256 checksums.
2{}4
gemfile%Gemfile to install dependencies from. >
gemfile_lock*Gemfile.lock to install dependencies from. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 F
srcs8List of Ruby source files necessary during installation.2[]*.
rb_bundle_fetch@@rules_ruby//ruby:deps.bzl
�"�"0
.
name"A unique name for this repository. U
S
bundler_checksums8Custom map from Bundler version to its SHA-256 checksum.
2{}T
R
bundler_remote%Remote to fetch the bundler gem from.2"https://rubygems.org/"@
>
env1Environment variables to use during installation.
2{}�

gem_checksumshSHA-256 checksums for remote gems. Keys are gem names (e.g. foobar-1.2.3), values are SHA-256 checksums.
2{}6
4
gemfile%Gemfile to install dependencies from. @
>
gemfile_lock*Gemfile.lock to install dependencies from. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 H
F
srcs8List of Ruby source files necessary during installation.2[]�rb_bundle_rule�
(Deprecated) Use `rb_bundle_fetch()` instead.

Installs Bundler dependencies and registers an external repository
that can be used by other targets.

`WORKSPACE`:
```bazel
load("@rules_ruby//ruby:deps.bzl", "rb_bundle")

rb_bundle(
    name = "bundle",
    gemfile = "//:Gemfile",
    srcs = [
        "//:gem.gemspec",
        "//:lib/gem/version.rb",
    ]
)
```

All the installed gems can be accessed using `@bundle` target and additionally
gems binary files can also be used:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_binary")

package(default_visibility = ["//:__subpackages__"])

rb_binary(
    name = "rubocop",
    main = "@bundle//:bin/rubocop",
    deps = ["@bundle"],
)
```
R�
�
rb_bundle_rule�
(Deprecated) Use `rb_bundle_fetch()` instead.

Installs Bundler dependencies and registers an external repository
that can be used by other targets.

`WORKSPACE`:
```bazel
load("@rules_ruby//ruby:deps.bzl", "rb_bundle")

rb_bundle(
    name = "bundle",
    gemfile = "//:Gemfile",
    srcs = [
        "//:gem.gemspec",
        "//:lib/gem/version.rb",
    ]
)
```

All the installed gems can be accessed using `@bundle` target and additionally
gems binary files can also be used:

`BUILD`:
```bazel
load("@rules_ruby//ruby:defs.bzl", "rb_binary")

package(default_visibility = ["//:__subpackages__"])

rb_binary(
    name = "rubocop",
    main = "@bundle//:bin/rubocop",
    deps = ["@bundle"],
)
```
.
name"A unique name for this repository. >
env1Environment variables to use during installation.
2{}:
gemfile'
Gemfile to install dependencies from.
2None�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 D
srcs6
List of Ruby source files used to build the library.
2[]
	toolchain *-
rb_bundle_rule@@rules_ruby//ruby:deps.bzl
QQ0
.
name"A unique name for this repository. @
>
env1Environment variables to use during installation.
2{}<
:
gemfile'
Gemfile to install dependencies from.
2None�
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 F
D
srcs6
List of Ruby source files used to build the library.
2[]

	toolchain |
//ruby/private:bundle.bzlr]
&

rules_rubyruby/private
bundle.bzl%
	rb_bundle
_rb_bundle
.8
G�
//ruby/private:bundle_fetch.bzlro
,

rules_rubyruby/privatebundle_fetch.bzl1
rb_bundle_fetch_rb_bundle_fetch
4D
Y�
//ruby/private:toolchain.bzlrz
)

rules_rubyruby/privatetoolchain.bzl?
rb_register_toolchains_rb_register_toolchains
1H
dPublic API for repository rules�
"

rules_rubyrubyextensions.bzl�rubyJ�
�
ruby�
bundle6
name(Resulting repository name for the bundle2""
env
2{}
gemfile2None
srcs2[]
	toolchain2None�
bundle_fetch6
name(Resulting repository name for the bundle2""
bundler_checksums
2{}+
bundler_remote2"https://rubygems.org/"
env
2{}
gem_checksums
2{}
gemfile2None
gemfile_lock2None
srcs2[]�
	toolchainW
nameIBase name for generated repositories, allowing multiple to be registered.2""A
msys2_packages Extra MSYS2 packages to install.2["libyaml"]*
versionExplicit version of ruby.2""7
version_fileFile to read Ruby version from.2None")
ruby!@@rules_ruby//ruby:extensions.bzl
SS�
�
bundle6
name(Resulting repository name for the bundle2""
env
2{}
gemfile2None
srcs2[]
	toolchain2None8
6
name(Resulting repository name for the bundle2""

env
2{}

gemfile2None

srcs2[]

	toolchain2None�
�
bundle_fetch6
name(Resulting repository name for the bundle2""
bundler_checksums
2{}+
bundler_remote2"https://rubygems.org/"
env
2{}
gem_checksums
2{}
gemfile2None
gemfile_lock2None
srcs2[]8
6
name(Resulting repository name for the bundle2""

bundler_checksums
2{}-
+
bundler_remote2"https://rubygems.org/"

env
2{}

gem_checksums
2{}

gemfile2None

gemfile_lock2None

srcs2[]�
�
	toolchainW
nameIBase name for generated repositories, allowing multiple to be registered.2""A
msys2_packages Extra MSYS2 packages to install.2["libyaml"]*
versionExplicit version of ruby.2""7
version_fileFile to read Ruby version from.2NoneY
W
nameIBase name for generated repositories, allowing multiple to be registered.2""C
A
msys2_packages Extra MSYS2 packages to install.2["libyaml"],
*
versionExplicit version of ruby.2""9
7
version_fileFile to read Ruby version from.2None�
//ruby:deps.bzlr�


rules_rubyrubydeps.bzl$
	rb_bundle	rb_bundle
%.0
rb_bundle_fetchrb_bundle_fetch
2A>
rb_register_toolchainsrb_register_toolchains
E[
]�
//ruby/private:toolchain.bzlr{
)

rules_rubyruby/privatetoolchain.bzl@
DEFAULT_RUBY_REPOSITORYDEFAULT_RUBY_REPOSITORY
2I
K Module extensions used by bzlmod�
!

rules_rubyrubytoolchain.bzl�rb_toolchain"�
�
rb_toolchain*
nameA unique name for this target. %
bundle`bundle` to execute2None=
env0Environment variables required by an interpreter
2{}0
files!All files necessary for toolchain2[]
gem`gem` to execute2None(
ruby`ruby` binary to execute2None
versionRuby version2"""0
rb_toolchain @@rules_ruby//ruby:toolchain.bzl
,
*
nameA unique name for this target. '
%
bundle`bundle` to execute2None?
=
env0Environment variables required by an interpreter
2{}2
0
files!All files necessary for toolchain2[]!

gem`gem` to execute2None*
(
ruby`ruby` binary to execute2None

versionRuby version2""/Define a Bazel toolchain for a Ruby interpreter 