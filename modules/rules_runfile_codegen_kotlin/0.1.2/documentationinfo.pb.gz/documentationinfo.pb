�i
(
rules_runfile_codegen_kotlindefs.bzl�Vkt_jvm_runfile_library�Generates a Kotlin JVM library containing compile-time safe accessors for runfiles.

This macro automates the process of accessing Bazel runfiles in Kotlin. It generates
a Kotlin source file containing a singleton `object` with properties that hold the
resolved runfile paths.

The generated library uses the official Bazel Java runfiles library (`@bazel_tools//tools/java/runfiles`)
to resolve the runfiles at runtime.

### Example Usage

In your `BUILD.bazel`:

```bazel
load("@rules_runfile_codegen_kotlin//:defs.bzl", "kt_runfile", "kt_jvm_runfile_library")

kt_jvm_runfile_library(
    name = "my_runfiles",
    package = "com.example.project.runfiles",
    entries = [
        kt_runfile(
            name = "configJson",
            target = "//config:config.json",
            doc = "The main configuration file.",
        ),
        kt_runfile(
            name = "helperTool",
            target = "//tools:helper_tool", # An executable target
            doc = "A helper CLI tool.",
        ),
        kt_runfile(
            name = "exampleSet",
            targets = ["//data:file1.txt", "//data:file2.txt"],
            base = "common_dir",
            doc = "A set of data files.",
        ),
    ],
)
```

In your `Main.kt`:

```kotlin
package com.example.project

import com.example.project.runfiles.MyRunfiles
import kotlin.io.path.readText

fun main() {
    // 1. Accessing a regular runfile:
    // Resolve the spec and read its content directly using Path.readText().
    val content = MyRunfiles.configJson.resolve().path.readText()
    println("Content: $content")

    // The resolved path is a java.nio.file.Path
    val path = MyRunfiles.configJson.resolve().path

    // 2. Running an executable runfile:
    // Resolve, configure, start, and wait for the process in a fluent chain.
    val exitCode = MyRunfiles.helperTool.resolve()
        .processBuilder("--verbose", "run")
        .inheritIO()
        .start()
        .waitFor()
    if (exitCode != 0) {
        error("Helper tool failed with exit code $exitCode")
    }

    // 3. Accessing a fileset:
    val fileset = MyRunfiles.exampleSet.resolve()
    // Access file inside fileset by its relative path (after base stripping)
    val f1 = fileset.resolveFile("file1.txt")
    // ... read f1.path.readText()
}
```


This rule compiles and links Kotlin and Java sources into a .jar file."�C
�+
kt_jvm_runfile_library�Generates a Kotlin JVM library containing compile-time safe accessors for runfiles.

This macro automates the process of accessing Bazel runfiles in Kotlin. It generates
a Kotlin source file containing a singleton `object` with properties that hold the
resolved runfile paths.

The generated library uses the official Bazel Java runfiles library (`@bazel_tools//tools/java/runfiles`)
to resolve the runfiles at runtime.

### Example Usage

In your `BUILD.bazel`:

```bazel
load("@rules_runfile_codegen_kotlin//:defs.bzl", "kt_runfile", "kt_jvm_runfile_library")

kt_jvm_runfile_library(
    name = "my_runfiles",
    package = "com.example.project.runfiles",
    entries = [
        kt_runfile(
            name = "configJson",
            target = "//config:config.json",
            doc = "The main configuration file.",
        ),
        kt_runfile(
            name = "helperTool",
            target = "//tools:helper_tool", # An executable target
            doc = "A helper CLI tool.",
        ),
        kt_runfile(
            name = "exampleSet",
            targets = ["//data:file1.txt", "//data:file2.txt"],
            base = "common_dir",
            doc = "A set of data files.",
        ),
    ],
)
```

In your `Main.kt`:

```kotlin
package com.example.project

import com.example.project.runfiles.MyRunfiles
import kotlin.io.path.readText

fun main() {
    // 1. Accessing a regular runfile:
    // Resolve the spec and read its content directly using Path.readText().
    val content = MyRunfiles.configJson.resolve().path.readText()
    println("Content: $content")

    // The resolved path is a java.nio.file.Path
    val path = MyRunfiles.configJson.resolve().path

    // 2. Running an executable runfile:
    // Resolve, configure, start, and wait for the process in a fluent chain.
    val exitCode = MyRunfiles.helperTool.resolve()
        .processBuilder("--verbose", "run")
        .inheritIO()
        .start()
        .waitFor()
    if (exitCode != 0) {
        error("Helper tool failed with exit code $exitCode")
    }

    // 3. Accessing a fileset:
    val fileset = MyRunfiles.exampleSet.resolve()
    // Access file inside fileset by its relative path (after base stripping)
    val f1 = fileset.resolveFile("file1.txt")
    // ... read f1.path.readText()
}
```


This rule compiles and links Kotlin and Java sources into a .jar file.*
nameA unique name for this target. �

associates�Kotlin deps who should be considered part of the same module/compilation-unit
for the purposes of "internal" access. Such deps must all share the same module space
and so a target cannot associate to two deps from two different modules.*
JavaInfo
	KtJvmInfo2[]�
data�The list of files needed by this rule at runtime. See general comments about `data` at
[Attributes common to all build rules](https://docs.bazel.build/versions/master/be/common-definitions.html#common-attributes).2[]�
deps�A list of dependencies of this rule.See general comments about `deps` at
[Attributes common to all build rules](https://docs.bazel.build/versions/master/be/common-definitions.html#common-attributes).*

JavaInfo*
	KtJvmInfo2[]�
exported_compiler_plugins�Exported compiler plugins.

Compiler plugins listed here will be treated as if they were added in the plugins attribute
of any targets that directly depend on this target. Like `java_plugin`s exported_plugins,
this is not transitive*
KtCompilerPluginInfo*
KtPluginConfiguration2[]�
exports�Exported libraries.

Deps listed here will be made available to other rules, as if the parents explicitly depended on
these deps. This is not true for regular (non-exported) deps.*

JavaInfo2[]<
java_stub_template2$//third_party:java_stub_template.txt�

javac_opts�Javac options to be used when compiling this target. These opts if provided will
be used instead of the ones provided to the toolchain.*
JavacOptions2None�
kotlinc_opts�Kotlinc options to be used when compiling this target. These opts if provided
will be used instead of the ones provided to the toolchain.*
KotlincOptions2None�
module_name�The name of the module, if not provided the module name is derived from the label. --e.g.,
`//some/package/path:label_name` is translated to
`some_package_path-label_name`.2""W
	neverlinkAIf true only use this library for compilation and not at runtime.2False{
plugins*
JavaPluginInfo*
KtPluginConfiguration*
KspPluginInfo*
KtCompilerPluginInfo*
KtCompilerPluginInfo2[]�
resource_jarssSet of archives containing Java resources. If specified, the contents of these jars are merged into
the output jar.2[]�
resource_strip_prefix�The path prefix to strip from Java resources. Should be a label pointing to a directory.
Files residing under common prefix such as `src/main/resources` or `src/test/resources` or `kotlin`
will have stripping applied by convention if this is not specified.2NoneH
	resources5A list of files that should be include in a Java jar.2[]�
runtime_deps�Libraries to make available to the final binary or test at runtime only. Like ordinary deps, these will
appear on the runtime classpath, but unlike them, not on the compile-time classpath.2[]�
srcs�The list of source files that are processed to create the target, this can contain both Java and Kotlin
files. Java analysis occurs first so Kotlin classes may depend on Java classes in the same compilation unit.2[]
77,
*
nameA unique name for this target. �
�

associates�Kotlin deps who should be considered part of the same module/compilation-unit
for the purposes of "internal" access. Such deps must all share the same module space
and so a target cannot associate to two deps from two different modules.*
JavaInfo
	KtJvmInfo2[]�
�
data�The list of files needed by this rule at runtime. See general comments about `data` at
[Attributes common to all build rules](https://docs.bazel.build/versions/master/be/common-definitions.html#common-attributes).2[]�
�
deps�A list of dependencies of this rule.See general comments about `deps` at
[Attributes common to all build rules](https://docs.bazel.build/versions/master/be/common-definitions.html#common-attributes).*

JavaInfo*
	KtJvmInfo2[]�
�
exported_compiler_plugins�Exported compiler plugins.

Compiler plugins listed here will be treated as if they were added in the plugins attribute
of any targets that directly depend on this target. Like `java_plugin`s exported_plugins,
this is not transitive*
KtCompilerPluginInfo*
KtPluginConfiguration2[]�
�
exports�Exported libraries.

Deps listed here will be made available to other rules, as if the parents explicitly depended on
these deps. This is not true for regular (non-exported) deps.*

JavaInfo2[]>
<
java_stub_template2$//third_party:java_stub_template.txt�
�

javac_opts�Javac options to be used when compiling this target. These opts if provided will
be used instead of the ones provided to the toolchain.*
JavacOptions2None�
�
kotlinc_opts�Kotlinc options to be used when compiling this target. These opts if provided
will be used instead of the ones provided to the toolchain.*
KotlincOptions2None�
�
module_name�The name of the module, if not provided the module name is derived from the label. --e.g.,
`//some/package/path:label_name` is translated to
`some_package_path-label_name`.2""Y
W
	neverlinkAIf true only use this library for compilation and not at runtime.2False}
{
plugins*
JavaPluginInfo*
KtPluginConfiguration*
KspPluginInfo*
KtCompilerPluginInfo*
KtCompilerPluginInfo2[]�
�
resource_jarssSet of archives containing Java resources. If specified, the contents of these jars are merged into
the output jar.2[]�
�
resource_strip_prefix�The path prefix to strip from Java resources. Should be a label pointing to a directory.
Files residing under common prefix such as `src/main/resources` or `src/test/resources` or `kotlin`
will have stripping applied by convention if this is not specified.2NoneJ
H
	resources5A list of files that should be include in a Java jar.2[]�
�
runtime_deps�Libraries to make available to the final binary or test at runtime only. Like ordinary deps, these will
appear on the runtime classpath, but unlike them, not on the compile-time classpath.2[]�
�
srcs�The list of source files that are processed to create the target, this can contain both Java and Kotlin
files. Java analysis occurs first so Kotlin classes may depend on Java classes in the same compilation unit.2[]�
kt_runfile�Creates a runfile entry configuration for Kotlin code generation.

This helper function constructs a structured dictionary representing a single runfile
dependency. It is intended to be passed in the `entries` list of `kt_jvm_runfile_library`.
*�
�

kt_runfile�
name�The Kotlin property name that will be generated to access this runfile.
This should follow Kotlin-idiomatic naming conventions (e.g., `configJson`,
`testData`). The generated code will expose this as a property on a Kotlin object. (X
targetFThe Bazel target label of the runfile. Alias for `targets = [target]`.None(�
targets�A list of Bazel target labels to include in this entry. If multiple
targets are specified, this entry is automatically treated as a `FileSet`.None(E
doc8A descriptive comment for the generated Kotlin property.""(�
base�An optional path base to resolve relative paths for FileSet files.
- If set to `""` (empty string), nothing is stripped (keeps full canonical paths).
- If it starts with `//`, it is resolved relative to the library's repository root.
- If it starts with `@`, it resolves relative to an external repository.
- If it starts with `.`, it resolves relative to the library's package path.
- If set to `"common_dir"`, it automatically computes the longest common prefix.None(�
type�An optional explicit type assertion for the target.
- `"auto"` (default): Automatically detects the type (file, directory, or fileset).
- `"file"`: Asserts the target is a single file.
- `"directory"`: Asserts the target is a TreeArtifact directory.
- `"fileset"`: Forces the target to be treated as a FileSet.
- `"executable"`: Asserts the target is an executable binary."auto"(�Creates a runfile entry configuration for Kotlin code generation.

This helper function constructs a structured dictionary representing a single runfile
dependency. It is intended to be passed in the `entries` list of `kt_jvm_runfile_library`.
"7
5A dictionary containing the configured runfile entry.27

kt_runfile)@@rules_runfile_codegen_kotlin//:defs.bzl
u
//kotlin:jvm.bzlr_

rules_kotlinkotlinjvm.bzl.
kt_jvm_librarykt_jvm_library
(6
8�
//internal:rules.bzlrs
1
rules_runfile_codegen_coreinternal	rules.bzl0
runfile_codegenrunfile_codegen
:I
K 