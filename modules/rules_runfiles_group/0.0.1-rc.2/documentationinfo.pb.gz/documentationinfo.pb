�
runfiles_grouplib.bzl�lib.group_names@Returns the list of group names in a RunfilesGroupInfo instance.*�
�
lib.group_names
runfiles_group_info (@Returns the list of group names in a RunfilesGroupInfo instance.20
_group_names //runfiles_group/private:lib.bzl

runfiles_group_info (�lib.ordered_groups*�
�
lib.ordered_groups
runfiles_group_info ('
runfiles_group_selection_infoNone(23
_ordered_groups //runfiles_group/private:lib.bzl

runfiles_group_info ()
'
runfiles_group_selection_infoNone(�lib.transform_groups*�
�
lib.transform_groups
runfiles_group_info (!
runfiles_transform_infoNone(25
_transform_groups //runfiles_group/private:lib.bzl

runfiles_group_info (#
!
runfiles_transform_infoNone(0Public API for runfiles group library functions.�+
runfiles_groupproviders.bzl�
RunfilesGroupInfo�Information about grouped runfiles.

Each field in this provider is a depset of File objects, representing a category of runfiles.
Merging all depsets from all fields should yield the same set (or a superset) of files as DefaultInfo.default_runfiles.

This provider functions similarly to OutputGroupInfo, but its presence in the output of a rule indicates that it can be used instead of DefaultInfo.default_runfiles.
It categorizes the runfiles of a target into different groups, allowing for more fine-grained control over which runfiles are used in different contexts.2�
�
RunfilesGroupInfo�Information about grouped runfiles.

Each field in this provider is a depset of File objects, representing a category of runfiles.
Merging all depsets from all fields should yield the same set (or a superset) of files as DefaultInfo.default_runfiles.

This provider functions similarly to OutputGroupInfo, but its presence in the output of a rule indicates that it can be used instead of DefaultInfo.default_runfiles.
It categorizes the runfiles of a target into different groups, allowing for more fine-grained control over which runfiles are used in different contexts."O
RunfilesGroupInfo://runfiles_group/private/providers:runfiles_group_info.bzl*{
RunfilesGroupInfo

kwargs(2Z
_make_runfilesgroupinfo_init://runfiles_group/private/providers:runfiles_group_info.bzl�RunfilesGroupSelectionInfo<Information about filtering and ordering groups of runfiles.2�
�	
RunfilesGroupSelectionInfo<Information about filtering and ordering groups of runfiles.�
	predicate�A starlark function that takes a single string (group name).
The function should return True if the group should be included in the output (and return False otherwise).
Set in functional form, None in list form.�
compare�A starlark function that takes two strings as input (group names)
and returns True if the first group name should come before the second (and False otherwise).
Set in functional form, None in list form.�
group_names�A list of group names defining the desired order.
Set in list form, None in functional form.
Mutually exclusive with predicate and compare.�
extra_group_treatment|How to treat groups not in group_names. One of "exclude", "prepend", or "append".
Set in list form, None in functional form."b
RunfilesGroupSelectionInfoD//runfiles_group/private/providers:runfiles_group_selection_info.bzl*�
RunfilesGroupSelectionInfo
	predicateNone(
compareNone(
group_namesNone(
extra_group_treatmentNone(2m
%_make_runfilesgroupselectioninfo_initD//runfiles_group/private/providers:runfiles_group_selection_info.bzl�
�
	predicate�A starlark function that takes a single string (group name).
The function should return True if the group should be included in the output (and return False otherwise).
Set in functional form, None in list form.�
�
compare�A starlark function that takes two strings as input (group names)
and returns True if the first group name should come before the second (and False otherwise).
Set in functional form, None in list form.�
�
group_names�A list of group names defining the desired order.
Set in list form, None in functional form.
Mutually exclusive with predicate and compare.�
�
extra_group_treatment|How to treat groups not in group_names. One of "exclude", "prepend", or "append".
Set in list form, None in functional form.�RunfilesGroupTransformInfoIInformation about how to transform a RunfilesGroupInfo by merging groups.2�
�	
RunfilesGroupTransformInfoIInformation about how to transform a RunfilesGroupInfo by merging groups.�
	transform�A starlark function that takes a RunfilesGroupInfo and returns a new RunfilesGroupInfo.
Set in functional form, None in dict form.�
merge_groups�A dict mapping output group name (string) to a list of source group names (list of string).
Each source group's depset is merged into the output group.
Set in dict form, None in functional form.�
unmatched_group_treatment�How to treat groups not listed in any merge_groups value.
One of "exclude", "keep_separate", or "merge_default".
Defaults to "keep_separate" if omitted. Set in dict form, None in functional form.�
default_group_name�The name of the group that unmatched groups are merged into.
Required when unmatched_group_treatment is "merge_default", None otherwise."b
RunfilesGroupTransformInfoD//runfiles_group/private/providers:runfiles_group_transform_info.bzl*�
RunfilesGroupTransformInfo
	transformNone(
merge_groupsNone(#
unmatched_group_treatmentNone(
default_group_nameNone(2h
 _make_runfilestransforminfo_initD//runfiles_group/private/providers:runfiles_group_transform_info.bzl�
�
	transform�A starlark function that takes a RunfilesGroupInfo and returns a new RunfilesGroupInfo.
Set in functional form, None in dict form.�
�
merge_groups�A dict mapping output group name (string) to a list of source group names (list of string).
Each source group's depset is merged into the output group.
Set in dict form, None in functional form.�
�
unmatched_group_treatment�How to treat groups not listed in any merge_groups value.
One of "exclude", "keep_separate", or "merge_default".
Defaults to "keep_separate" if omitted. Set in dict form, None in functional form.�
�
default_group_name�The name of the group that unmatched groups are merged into.
Required when unmatched_group_treatment is "merge_default", None otherwise.(Public API for runfiles group providers.�
2runfiles_group runfiles_group_analysis_test.bzl�runfiles_group_analysis_test�Checks that RunfilesGroupInfo is well formed by comparing the runfiles of the executable (DefaultInfo.default_runfiles.files)
with the union of all runfiles from RunfilesGroupInfo.

Additionally, it can warn about files appearing in multiple groups (overlapping)."�
�
runfiles_group_analysis_test�Checks that RunfilesGroupInfo is well formed by comparing the runfiles of the executable (DefaultInfo.default_runfiles.files)
with the union of all runfiles from RunfilesGroupInfo.

Additionally, it can warn about files appearing in multiple groups (overlapping).*
nameA unique name for this target. �
binaries!List of *_binary targets to test. *d
RunfilesGroupInfoO
RunfilesGroupInfo://runfiles_group/private/providers:runfiles_group_info.bzl�
overlapping_group_behaviorVHow to handle overlapping groups (the same file being present in more than one group).2"warn"J"warn"J"ignore"J"error""_
runfiles_group_analysis_test?//runfiles_group/private/rules:runfiles_group_analysis_test.bzl08,
*
nameA unique name for this target. �
�
binaries!List of *_binary targets to test. *d
RunfilesGroupInfoO
RunfilesGroupInfo://runfiles_group/private/providers:runfiles_group_info.bzl�
�
overlapping_group_behaviorVHow to handle overlapping groups (the same file being present in more than one group).2"warn"J"warn"J"ignore"J"error",Public API for runfiles_group_analysis_test. 