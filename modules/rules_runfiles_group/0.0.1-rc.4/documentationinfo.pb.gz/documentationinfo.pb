�
runfiles_grouplib.bzl�lib.collect_groups*�
w
lib.collect_groups

deps ( 
strip_executable_groupTrue(23
_collect_groups //runfiles_group/private:lib.bzl


deps ("
 
strip_executable_groupTrue(�lib.group_metadata*Creates a validated group metadata struct.*�
�
lib.group_metadataC
rank6Partial ordering key. Lower rank = earlier. Default 0.0(T
do_not_merge;If True, packager must not merge this group. Default False.False(G
weight5Merge priority hint (int >= 0 or None). Default None.None(�
executable_groupfIf True, the packager should place the executable
and supporting files into this group. Default False.False(*Creates a validated group metadata struct."H
FA struct with rank, do_not_merge, weight, and executable_group fields.2U
group_metadataC//runfiles_group/private/providers:runfiles_group_metadata_info.bzlE
C
rank6Partial ordering key. Lower rank = earlier. Default 0.0(V
T
do_not_merge;If True, packager must not merge this group. Default False.False(I
G
weight5Merge priority hint (int >= 0 or None). Default None.None(�
�
executable_groupfIf True, the packager should place the executable
and supporting files into this group. Default False.False(�lib.group_names@Returns the list of group names in a RunfilesGroupInfo instance.*�
�
lib.group_names
runfiles_group_info (@Returns the list of group names in a RunfilesGroupInfo instance.20
_group_names //runfiles_group/private:lib.bzl

runfiles_group_info (�lib.merge_metadata*k
X
lib.merge_metadata
	metadatas(23
_merge_metadata //runfiles_group/private:lib.bzl

	metadatas(�lib.merge_to_limit*�
�
lib.merge_to_limit
runfiles_group_info (&
runfiles_group_metadata_infoNone(

max_groups (
default_weight0(
merged_group_nameNone(23
_merge_to_limit //runfiles_group/private:lib.bzl

runfiles_group_info ((
&
runfiles_group_metadata_infoNone(


max_groups (

default_weight0(

merged_group_nameNone(�lib.ordered_groups*�
�
lib.ordered_groups
runfiles_group_info (&
runfiles_group_metadata_infoNone(23
_ordered_groups //runfiles_group/private:lib.bzl

runfiles_group_info ((
&
runfiles_group_metadata_infoNone(�lib.transform_groups*�
�
lib.transform_groups
runfiles_group_info (&
runfiles_group_metadata_infoNone(!
runfiles_transform_infoNone(25
_transform_groups //runfiles_group/private:lib.bzl

runfiles_group_info ((
&
runfiles_group_metadata_infoNone(#
!
runfiles_transform_infoNone(0Public API for runfiles group library functions.�'
runfiles_groupproviders.bzl�
RunfilesGroupInfo�Information about grouped runfiles.

Each field in this provider is a depset of File objects, representing a category of runfiles.
Merging all depsets from all fields must yield the same set of files as DefaultInfo.default_runfiles.

This provider functions similarly to OutputGroupInfo, but its presence in the output of a rule indicates that it can be used instead of DefaultInfo.default_runfiles.
It categorizes the runfiles of a target into different groups, allowing for more fine-grained control over which runfiles are used in different contexts.2�
�
RunfilesGroupInfo�Information about grouped runfiles.

Each field in this provider is a depset of File objects, representing a category of runfiles.
Merging all depsets from all fields must yield the same set of files as DefaultInfo.default_runfiles.

This provider functions similarly to OutputGroupInfo, but its presence in the output of a rule indicates that it can be used instead of DefaultInfo.default_runfiles.
It categorizes the runfiles of a target into different groups, allowing for more fine-grained control over which runfiles are used in different contexts."O
RunfilesGroupInfo://runfiles_group/private/providers:runfiles_group_info.bzl*{
RunfilesGroupInfo

kwargs(2Z
_make_runfilesgroupinfo_init://runfiles_group/private/providers:runfiles_group_info.bzl�RunfilesGroupMetadataInfo�Metadata about groups in a RunfilesGroupInfo instance.

Each entry maps a group name to a struct with:
- rank (int): Partial ordering key. Lower rank = earlier. Default 0.
- do_not_merge (bool): If True, packager must not merge this group. Default False.
- weight (int or None): Hint for merge priority. Lighter groups merge first.
  If None, the packager may apply an undefined default. Default None.
- executable_group (bool): If True, signals that the packager should place
  the executable file, runfiles symlinks, repo mapping manifest, and other
  supporting files for the main entrypoint into this group. Default False.

Groups not present in the dict are treated as having default metadata
(rank=0, do_not_merge=False, weight=None, executable_group=False).2�
�	
RunfilesGroupMetadataInfo�Metadata about groups in a RunfilesGroupInfo instance.

Each entry maps a group name to a struct with:
- rank (int): Partial ordering key. Lower rank = earlier. Default 0.
- do_not_merge (bool): If True, packager must not merge this group. Default False.
- weight (int or None): Hint for merge priority. Lighter groups merge first.
  If None, the packager may apply an undefined default. Default None.
- executable_group (bool): If True, signals that the packager should place
  the executable file, runfiles symlinks, repo mapping manifest, and other
  supporting files for the main entrypoint into this group. Default False.

Groups not present in the dict are treated as having default metadata
(rank=0, do_not_merge=False, weight=None, executable_group=False).�
groups�A dict mapping group name (string) to a struct with rank, do_not_merge, weight, and executable_group fields.
Groups not present get default metadata (rank=0, do_not_merge=False, weight=None, executable_group=False)."`
RunfilesGroupMetadataInfoC//runfiles_group/private/providers:runfiles_group_metadata_info.bzl*�
RunfilesGroupMetadataInfo
groups (2k
$_make_runfilesgroupmetadatainfo_initC//runfiles_group/private/providers:runfiles_group_metadata_info.bzl�
�
groups�A dict mapping group name (string) to a struct with rank, do_not_merge, weight, and executable_group fields.
Groups not present get default metadata (rank=0, do_not_merge=False, weight=None, executable_group=False).�
RunfilesGroupTransformInfo�Information about how to transform a RunfilesGroupInfo (and its metadata).

The transform function receives (RunfilesGroupInfo, RunfilesGroupMetadataInfo_or_None)
and must return a struct with two fields:
- runfiles_group_info: the transformed RunfilesGroupInfo
- runfiles_group_metadata_info: the transformed RunfilesGroupMetadataInfo (or None)2�
�
RunfilesGroupTransformInfo�Information about how to transform a RunfilesGroupInfo (and its metadata).

The transform function receives (RunfilesGroupInfo, RunfilesGroupMetadataInfo_or_None)
and must return a struct with two fields:
- runfiles_group_info: the transformed RunfilesGroupInfo
- runfiles_group_metadata_info: the transformed RunfilesGroupMetadataInfo (or None)�
	transform�A starlark function (RunfilesGroupInfo, RunfilesGroupMetadataInfo_or_None) ->
struct(runfiles_group_info, runfiles_group_metadata_info)."b
RunfilesGroupTransformInfoD//runfiles_group/private/providers:runfiles_group_transform_info.bzl*�
RunfilesGroupTransformInfo
	transform (2h
 _make_runfilestransforminfo_initD//runfiles_group/private/providers:runfiles_group_transform_info.bzl�
�
	transform�A starlark function (RunfilesGroupInfo, RunfilesGroupMetadataInfo_or_None) ->
struct(runfiles_group_info, runfiles_group_metadata_info).(Public API for runfiles group providers.�
2runfiles_group runfiles_group_analysis_test.bzl�runfiles_group_analysis_test�Checks that RunfilesGroupInfo is well formed by comparing the runfiles of the executable (DefaultInfo.default_runfiles.files)
with the union of all runfiles from RunfilesGroupInfo.

Additionally, it can warn about files appearing in multiple groups (overlapping),
verify the expected ordered group names after applying the full resolution protocol,
and optionally apply merge-to-limit before ordering."�
�
runfiles_group_analysis_test�Checks that RunfilesGroupInfo is well formed by comparing the runfiles of the executable (DefaultInfo.default_runfiles.files)
with the union of all runfiles from RunfilesGroupInfo.

Additionally, it can warn about files appearing in multiple groups (overlapping),
verify the expected ordered group names after applying the full resolution protocol,
and optionally apply merge-to-limit before ordering.*
nameA unique name for this target. �
binaries!List of *_binary targets to test. *d
RunfilesGroupInfoO
RunfilesGroupInfo://runfiles_group/private/providers:runfiles_group_info.bzl�
overlapping_group_behaviorVHow to handle overlapping groups (the same file being present in more than one group).2"warn"J"warn"J"ignore"J"error"�
expected_group_names�If set, the test verifies that the ordered group names (after optional merging and rank-based ordering)
match this list exactly. Applies to all binaries in the test.2[]i

max_groupsUIf >= 0, apply lib.merge_to_limit with this limit before ordering. -1 means no limit.2-1�
expected_group_count�If >= 0, verify the exact number of groups after merging (requires max_groups >= 0).
Use this when merging cannot reach max_groups (e.g., due to do_not_merge or rank constraints)
to assert the actual reachable count. -1 means no check (the test fails if group_count > max_groups instead).2-1"_
runfiles_group_analysis_test?//runfiles_group/private/rules:runfiles_group_analysis_test.bzl08,
*
nameA unique name for this target. �
�
binaries!List of *_binary targets to test. *d
RunfilesGroupInfoO
RunfilesGroupInfo://runfiles_group/private/providers:runfiles_group_info.bzl�
�
overlapping_group_behaviorVHow to handle overlapping groups (the same file being present in more than one group).2"warn"J"warn"J"ignore"J"error"�
�
expected_group_names�If set, the test verifies that the ordered group names (after optional merging and rank-based ordering)
match this list exactly. Applies to all binaries in the test.2[]k
i

max_groupsUIf >= 0, apply lib.merge_to_limit with this limit before ordering. -1 means no limit.2-1�
�
expected_group_count�If >= 0, verify the exact number of groups after merging (requires max_groups >= 0).
Use this when merging cannot reach max_groups (e.g., due to do_not_merge or rank constraints)
to assert the actual reachable count. -1 means no check (the test fails if group_count > max_groups instead).2-1,Public API for runfiles_group_analysis_test. 