�
Q
rules_runfiles_group runfiles_group/private/providersrunfiles_group_info.bzl�	RunfilesGroupInfo�Information about grouped runfiles.

Each field in this provider is a runfiles object, representing a category of runfiles.
Merging all runfiles objects from all fields must yield the same runfiles as DefaultInfo.default_runfiles.

This provider functions similarly to OutputGroupInfo, but its presence in the output of a rule indicates that it can be used instead of DefaultInfo.default_runfiles.
It categorizes the runfiles of a target into different groups, allowing for more fine-grained control over which runfiles are used in different contexts.
2�
�
RunfilesGroupInfo�Information about grouped runfiles.

Each field in this provider is a runfiles object, representing a category of runfiles.
Merging all runfiles objects from all fields must yield the same runfiles as DefaultInfo.default_runfiles.

This provider functions similarly to OutputGroupInfo, but its presence in the output of a rule indicates that it can be used instead of DefaultInfo.default_runfiles.
It categorizes the runfiles of a target into different groups, allowing for more fine-grained control over which runfiles are used in different contexts.
"e
RunfilesGroupInfoP@@rules_runfiles_group//runfiles_group/private/providers:runfiles_group_info.bzl
  �Defines provider for grouping runfiles into different subcategories.

This is essentially a special-purpose version of OutputGroupInfo.
If present, it can be used instead of DefaultInfo.default_runfiles.�
Z
rules_runfiles_group runfiles_group/private/providers runfiles_group_metadata_info.bzl�group_metadata*Creates a validated group metadata struct.*�
�
group_metadataC
rank6Partial ordering key. Lower rank = earlier. Default 0.0(T
do_not_merge;If True, packager must not merge this group. Default False.False(G
weight5Merge priority hint (int >= 0 or None). Default None.None(�
executable_groupfIf True, the packager should place the executable
and supporting files into this group. Default False.False(*Creates a validated group metadata struct."H
FA struct with rank, do_not_merge, weight, and executable_group fields.2k
group_metadataY@@rules_runfiles_group//runfiles_group/private/providers:runfiles_group_metadata_info.bzl
�RunfilesGroupMetadataInfo�Metadata about groups in a RunfilesGroupInfo instance.

Each entry maps a group name to a struct with:
- rank (int): Partial ordering key. Lower rank = earlier. Default 0.
- do_not_merge (bool): If True, packager must not merge this group. Default False.
- weight (int or None): Hint for merge priority. Lighter groups merge first.
  If None, the packager may apply an undefined default. Default None.
- executable_group (bool): If True, signals that the packager should place
  the executable file, runfiles symlinks, repo mapping manifest, and other
  supporting files for the main entrypoint into this group. Default False.

Groups not present in the dict are treated as having default metadata
(rank=0, do_not_merge=False, weight=None, executable_group=False).
2�

�
RunfilesGroupMetadataInfo�Metadata about groups in a RunfilesGroupInfo instance.

Each entry maps a group name to a struct with:
- rank (int): Partial ordering key. Lower rank = earlier. Default 0.
- do_not_merge (bool): If True, packager must not merge this group. Default False.
- weight (int or None): Hint for merge priority. Lighter groups merge first.
  If None, the packager may apply an undefined default. Default None.
- executable_group (bool): If True, signals that the packager should place
  the executable file, runfiles symlinks, repo mapping manifest, and other
  supporting files for the main entrypoint into this group. Default False.

Groups not present in the dict are treated as having default metadata
(rank=0, do_not_merge=False, weight=None, executable_group=False).
�
groups�A dict mapping group name (string) to a struct with rank, do_not_merge, weight, and executable_group fields.
Groups not present get default metadata (rank=0, do_not_merge=False, weight=None, executable_group=False).
"v
RunfilesGroupMetadataInfoY@@rules_runfiles_group//runfiles_group/private/providers:runfiles_group_metadata_info.bzl
P(P(�
�
groups�A dict mapping group name (string) to a struct with rank, do_not_merge, weight, and executable_group fields.
Groups not present get default metadata (rank=0, do_not_merge=False, weight=None, executable_group=False).
�Defines provider for metadata about RunfilesGroupInfo groups.

RunfilesGroupMetadataInfo holds per-group metadata that controls ordering
(rank), merge eligibility (do_not_merge), and merge priority (weight).
�
[
rules_runfiles_group runfiles_group/private/providers!runfiles_group_transform_info.bzl�	RunfilesGroupTransformInfo�Information about how to transform a RunfilesGroupInfo (and its metadata).

The transform function receives (RunfilesGroupInfo, RunfilesGroupMetadataInfo_or_None)
and must return a struct with two fields:
- runfiles_group_info: the transformed RunfilesGroupInfo
- runfiles_group_metadata_info: the transformed RunfilesGroupMetadataInfo (or None)
2�
�
RunfilesGroupTransformInfo�Information about how to transform a RunfilesGroupInfo (and its metadata).

The transform function receives (RunfilesGroupInfo, RunfilesGroupMetadataInfo_or_None)
and must return a struct with two fields:
- runfiles_group_info: the transformed RunfilesGroupInfo
- runfiles_group_metadata_info: the transformed RunfilesGroupMetadataInfo (or None)
�
	transform�A starlark function (RunfilesGroupInfo, RunfilesGroupMetadataInfo_or_None) ->
struct(runfiles_group_info, runfiles_group_metadata_info).
"x
RunfilesGroupTransformInfoZ@@rules_runfiles_group//runfiles_group/private/providers:runfiles_group_transform_info.bzl
))�
�
	transform�A starlark function (RunfilesGroupInfo, RunfilesGroupMetadataInfo_or_None) ->
struct(runfiles_group_info, runfiles_group_metadata_info).
�Defines provider for transforming RunfilesGroupInfo and RunfilesGroupMetadataInfo.

This provider is intended for use as an aspect_hint on a target
to transform runfiles groups, producing new RunfilesGroupInfo
and RunfilesGroupMetadataInfo instances.
�c
7
rules_runfiles_grouprunfiles_group/privatelib.bzl�lib.collect_groups*�
�
lib.collect_groups	
ctx (

deps ( 
strip_executable_groupTrue(2I
_collect_groups6@@rules_runfiles_group//runfiles_group/private:lib.bzl
���lib.group_metadata*Creates a validated group metadata struct.*�
�
lib.group_metadataC
rank6Partial ordering key. Lower rank = earlier. Default 0.0(T
do_not_merge;If True, packager must not merge this group. Default False.False(G
weight5Merge priority hint (int >= 0 or None). Default None.None(�
executable_groupfIf True, the packager should place the executable
and supporting files into this group. Default False.False(*Creates a validated group metadata struct."H
FA struct with rank, do_not_merge, weight, and executable_group fields.2k
group_metadataY@@rules_runfiles_group//runfiles_group/private/providers:runfiles_group_metadata_info.bzl
�lib.group_names@Returns the list of group names in a RunfilesGroupInfo instance.*�
�
lib.group_names
runfiles_group_info (@Returns the list of group names in a RunfilesGroupInfo instance.2F
_group_names6@@rules_runfiles_group//runfiles_group/private:lib.bzl
EE�lib.merge_metadata*�
n
lib.merge_metadata
	metadatas(2I
_merge_metadata6@@rules_runfiles_group//runfiles_group/private:lib.bzl
���lib.merge_to_limit*�
�
lib.merge_to_limit
runfiles_group_info (&
runfiles_group_metadata_infoNone(

max_groups (
default_weight0(
merged_group_nameNone(2I
_merge_to_limit6@@rules_runfiles_group//runfiles_group/private:lib.bzl
���lib.ordered_groups*�
�
lib.ordered_groups
runfiles_group_info (&
runfiles_group_metadata_infoNone(2I
_ordered_groups6@@rules_runfiles_group//runfiles_group/private:lib.bzl
NN�lib.transform_groups*�
�
lib.transform_groups
runfiles_group_info (&
runfiles_group_metadata_infoNone(!
runfiles_transform_infoNone(2K
_transform_groups6@@rules_runfiles_group//runfiles_group/private:lib.bzl
gg�4lib�Library for consuming and transforming RunfilesGroupInfo.

lib.group_names(runfiles_group_info)
    Returns the list of group names in a RunfilesGroupInfo instance.

lib.ordered_groups(runfiles_group_info, metadata_info = None)
    Returns a list of struct(name, runfiles, metadata) entries, ordered by rank
    (ascending). name is the group name (string), runfiles is a runfiles object,
    and metadata is the group_metadata struct (or None if no explicit
    metadata exists for that group).

    Within the same rank, order is deterministc,
    but consumers should not rely on intra-rank order.

    If metadata_info is None, all groups are included in deterministic order
    with metadata set to None.
    Groups not present in metadata get None as metadata.

lib.transform_groups(runfiles_group_info, metadata_info = None, transform_info = None)
    Applies a transform to (RunfilesGroupInfo, RunfilesGroupMetadataInfo).
    Returns struct(runfiles_group_info, runfiles_group_metadata_info).
    If transform_info is None, returns inputs unchanged.

lib.merge_to_limit(runfiles_group_info, metadata_info = None, max_groups, default_weight = 0, merged_group_name = None)
    Merges groups to fit within max_groups. Groups at the same rank
    without do_not_merge may be merged. Lighter groups (by weight) merge first.
    Returns struct(runfiles_group_info, runfiles_group_metadata_info, group_count).
    The caller must check group_count â if it exceeds max_groups, merging could
    not reduce far enough (e.g., due to do_not_merge or groups in different ranks).
    If merged_group_name is set, it is called as
    merged_group_name(lighter_name, lighter_weight, heavier_name, heavier_weight)
    to determine the name of the merged group. If None, the heavier group's name is kept.

lib.merge_metadata(*metadatas)
    Dict-merges any number of RunfilesGroupMetadataInfo instances (or None).
    Returns RunfilesGroupMetadataInfo or None. Per-key last-wins.

lib.collect_groups(ctx, deps, *, strip_executable_group = True)
    Extracts RunfilesGroupInfo and RunfilesGroupMetadataInfo from a list of
    dependency targets. For deps providing RunfilesGroupInfo, extracts all
    groups and metadata. For deps without it, creates a named group
    "data#<canonical label>" whose value is a runfiles object combining
    DefaultInfo.files and DefaultInfo.default_runfiles. This means that if
    two parts of the dependency graph share the same data dep, they produce
    the same group name â the binary-level dict merge naturally deduplicates
    the group so the files are recorded only once.
    If strip_executable_group is True (default), the executable_group bit
    is cleared on all collected metadata entries. This is the correct
    default when collecting from data deps: the executable_group annotation
    is only meaningful for the top-level *_binary target, not for binaries
    that appear as data dependencies of another binary.
    Returns struct(groups, metadata) where:
      groups: dict[str, runfiles]
      metadata: RunfilesGroupMetadataInfo or None
z�
lib
���Library for consuming and transforming RunfilesGroupInfo.

lib.group_names(runfiles_group_info)
    Returns the list of group names in a RunfilesGroupInfo instance.

lib.ordered_groups(runfiles_group_info, metadata_info = None)
    Returns a list of struct(name, runfiles, metadata) entries, ordered by rank
    (ascending). name is the group name (string), runfiles is a runfiles object,
    and metadata is the group_metadata struct (or None if no explicit
    metadata exists for that group).

    Within the same rank, order is deterministc,
    but consumers should not rely on intra-rank order.

    If metadata_info is None, all groups are included in deterministic order
    with metadata set to None.
    Groups not present in metadata get None as metadata.

lib.transform_groups(runfiles_group_info, metadata_info = None, transform_info = None)
    Applies a transform to (RunfilesGroupInfo, RunfilesGroupMetadataInfo).
    Returns struct(runfiles_group_info, runfiles_group_metadata_info).
    If transform_info is None, returns inputs unchanged.

lib.merge_to_limit(runfiles_group_info, metadata_info = None, max_groups, default_weight = 0, merged_group_name = None)
    Merges groups to fit within max_groups. Groups at the same rank
    without do_not_merge may be merged. Lighter groups (by weight) merge first.
    Returns struct(runfiles_group_info, runfiles_group_metadata_info, group_count).
    The caller must check group_count â if it exceeds max_groups, merging could
    not reduce far enough (e.g., due to do_not_merge or groups in different ranks).
    If merged_group_name is set, it is called as
    merged_group_name(lighter_name, lighter_weight, heavier_name, heavier_weight)
    to determine the name of the merged group. If None, the heavier group's name is kept.

lib.merge_metadata(*metadatas)
    Dict-merges any number of RunfilesGroupMetadataInfo instances (or None).
    Returns RunfilesGroupMetadataInfo or None. Per-key last-wins.

lib.collect_groups(ctx, deps, *, strip_executable_group = True)
    Extracts RunfilesGroupInfo and RunfilesGroupMetadataInfo from a list of
    dependency targets. For deps providing RunfilesGroupInfo, extracts all
    groups and metadata. For deps without it, creates a named group
    "data#<canonical label>" whose value is a runfiles object combining
    DefaultInfo.files and DefaultInfo.default_runfiles. This means that if
    two parts of the dependency graph share the same data dep, they produce
    the same group name â the binary-level dict merge naturally deduplicates
    the group so the files are recorded only once.
    If strip_executable_group is True (default), the executable_group bit
    is cleared on all collected metadata entries. This is the correct
    default when collecting from data deps: the executable_group annotation
    is only meaningful for the top-level *_binary target, not for binaries
    that appear as data dependencies of another binary.
    Returns struct(groups, metadata) where:
      groups: dict[str, runfiles]
      metadata: RunfilesGroupMetadataInfo or None
"D
group_metadata
��group_metadata"lib.group_metadata"<
group_names
��_group_names"lib.group_names"E
ordered_groups
��_ordered_groups"lib.ordered_groups"K
transform_groups
��_transform_groups"lib.transform_groups"E
merge_to_limit
��_merge_to_limit"lib.merge_to_limit"E
merge_metadata
��_merge_metadata"lib.merge_metadata"E
collect_groups
��_collect_groups"lib.collect_groups*6@@rules_runfiles_group//runfiles_group/private:lib.bzlq
:features.bzlr^

bazel_featuresfeatures.bzl.
bazel_featuresbazel_features
9)97
999�
://runfiles_group/private/providers:runfiles_group_info.bzlr�
Q
rules_runfiles_group runfiles_group/private/providersrunfiles_group_info.bzl4
RunfilesGroupInfoRunfilesGroupInfo
:Z:k
::m�
C//runfiles_group/private/providers:runfiles_group_metadata_info.bzlr�
Z
rules_runfiles_group runfiles_group/private/providers runfiles_group_metadata_info.bzl2
DEFAULT_METADATADEFAULT_METADATA
==D
RunfilesGroupMetadataInfoRunfilesGroupMetadataInfo
>>.
group_metadatagroup_metadata
??
;@�Library for consuming and transforming RunfilesGroupInfo.

lib.group_names(runfiles_group_info)
    Returns the list of group names in a RunfilesGroupInfo instance.

lib.ordered_groups(runfiles_group_info, metadata_info = None)
    Returns a list of struct(name, runfiles, metadata) entries, ordered by rank
    (ascending). name is the group name (string), runfiles is a runfiles object,
    and metadata is the group_metadata struct (or None if no explicit
    metadata exists for that group).

    Within the same rank, order is deterministc,
    but consumers should not rely on intra-rank order.

    If metadata_info is None, all groups are included in deterministic order
    with metadata set to None.
    Groups not present in metadata get None as metadata.

lib.transform_groups(runfiles_group_info, metadata_info = None, transform_info = None)
    Applies a transform to (RunfilesGroupInfo, RunfilesGroupMetadataInfo).
    Returns struct(runfiles_group_info, runfiles_group_metadata_info).
    If transform_info is None, returns inputs unchanged.

lib.merge_to_limit(runfiles_group_info, metadata_info = None, max_groups, default_weight = 0, merged_group_name = None)
    Merges groups to fit within max_groups. Groups at the same rank
    without do_not_merge may be merged. Lighter groups (by weight) merge first.
    Returns struct(runfiles_group_info, runfiles_group_metadata_info, group_count).
    The caller must check group_count â if it exceeds max_groups, merging could
    not reduce far enough (e.g., due to do_not_merge or groups in different ranks).
    If merged_group_name is set, it is called as
    merged_group_name(lighter_name, lighter_weight, heavier_name, heavier_weight)
    to determine the name of the merged group. If None, the heavier group's name is kept.

lib.merge_metadata(*metadatas)
    Dict-merges any number of RunfilesGroupMetadataInfo instances (or None).
    Returns RunfilesGroupMetadataInfo or None. Per-key last-wins.

lib.collect_groups(ctx, deps, *, strip_executable_group = True)
    Extracts RunfilesGroupInfo and RunfilesGroupMetadataInfo from a list of
    dependency targets. For deps providing RunfilesGroupInfo, extracts all
    groups and metadata. For deps without it, creates a named group
    "data#<canonical label>" whose value is a runfiles object combining
    DefaultInfo.files and DefaultInfo.default_runfiles. This means that if
    two parts of the dependency graph share the same data dep, they produce
    the same group name â the binary-level dict merge naturally deduplicates
    the group so the files are recorded only once.
    If strip_executable_group is True (default), the executable_group bit
    is cleared on all collected metadata entries. This is the correct
    default when collecting from data deps: the executable_group annotation
    is only meaningful for the top-level *_binary target, not for binaries
    that appear as data dependencies of another binary.
    Returns struct(groups, metadata) where:
      groups: dict[str, runfiles]
      metadata: RunfilesGroupMetadataInfo or None
�
/
rules_runfiles_grouprunfiles_grouplib.bzl�
 //runfiles_group/private:lib.bzlrb
7
rules_runfiles_grouprunfiles_group/privatelib.bzl
lib_lib
?C
L0Public API for runfiles group library functions.�*
5
rules_runfiles_grouprunfiles_groupproviders.bzl�	RunfilesGroupInfo�Information about grouped runfiles.

Each field in this provider is a runfiles object, representing a category of runfiles.
Merging all runfiles objects from all fields must yield the same runfiles as DefaultInfo.default_runfiles.

This provider functions similarly to OutputGroupInfo, but its presence in the output of a rule indicates that it can be used instead of DefaultInfo.default_runfiles.
It categorizes the runfiles of a target into different groups, allowing for more fine-grained control over which runfiles are used in different contexts.
2�
�
RunfilesGroupInfo�Information about grouped runfiles.

Each field in this provider is a runfiles object, representing a category of runfiles.
Merging all runfiles objects from all fields must yield the same runfiles as DefaultInfo.default_runfiles.

This provider functions similarly to OutputGroupInfo, but its presence in the output of a rule indicates that it can be used instead of DefaultInfo.default_runfiles.
It categorizes the runfiles of a target into different groups, allowing for more fine-grained control over which runfiles are used in different contexts.
"I
RunfilesGroupInfo4@@rules_runfiles_group//runfiles_group:providers.bzl
  �RunfilesGroupMetadataInfo�Metadata about groups in a RunfilesGroupInfo instance.

Each entry maps a group name to a struct with:
- rank (int): Partial ordering key. Lower rank = earlier. Default 0.
- do_not_merge (bool): If True, packager must not merge this group. Default False.
- weight (int or None): Hint for merge priority. Lighter groups merge first.
  If None, the packager may apply an undefined default. Default None.
- executable_group (bool): If True, signals that the packager should place
  the executable file, runfiles symlinks, repo mapping manifest, and other
  supporting files for the main entrypoint into this group. Default False.

Groups not present in the dict are treated as having default metadata
(rank=0, do_not_merge=False, weight=None, executable_group=False).
2�

�
RunfilesGroupMetadataInfo�Metadata about groups in a RunfilesGroupInfo instance.

Each entry maps a group name to a struct with:
- rank (int): Partial ordering key. Lower rank = earlier. Default 0.
- do_not_merge (bool): If True, packager must not merge this group. Default False.
- weight (int or None): Hint for merge priority. Lighter groups merge first.
  If None, the packager may apply an undefined default. Default None.
- executable_group (bool): If True, signals that the packager should place
  the executable file, runfiles symlinks, repo mapping manifest, and other
  supporting files for the main entrypoint into this group. Default False.

Groups not present in the dict are treated as having default metadata
(rank=0, do_not_merge=False, weight=None, executable_group=False).
�
groups�A dict mapping group name (string) to a struct with rank, do_not_merge, weight, and executable_group fields.
Groups not present get default metadata (rank=0, do_not_merge=False, weight=None, executable_group=False).
"Q
RunfilesGroupMetadataInfo4@@rules_runfiles_group//runfiles_group:providers.bzl
P(P(�
�
groups�A dict mapping group name (string) to a struct with rank, do_not_merge, weight, and executable_group fields.
Groups not present get default metadata (rank=0, do_not_merge=False, weight=None, executable_group=False).
�	RunfilesGroupTransformInfo�Information about how to transform a RunfilesGroupInfo (and its metadata).

The transform function receives (RunfilesGroupInfo, RunfilesGroupMetadataInfo_or_None)
and must return a struct with two fields:
- runfiles_group_info: the transformed RunfilesGroupInfo
- runfiles_group_metadata_info: the transformed RunfilesGroupMetadataInfo (or None)
2�
�
RunfilesGroupTransformInfo�Information about how to transform a RunfilesGroupInfo (and its metadata).

The transform function receives (RunfilesGroupInfo, RunfilesGroupMetadataInfo_or_None)
and must return a struct with two fields:
- runfiles_group_info: the transformed RunfilesGroupInfo
- runfiles_group_metadata_info: the transformed RunfilesGroupMetadataInfo (or None)
�
	transform�A starlark function (RunfilesGroupInfo, RunfilesGroupMetadataInfo_or_None) ->
struct(runfiles_group_info, runfiles_group_metadata_info).
"R
RunfilesGroupTransformInfo4@@rules_runfiles_group//runfiles_group:providers.bzl
))�
�
	transform�A starlark function (RunfilesGroupInfo, RunfilesGroupMetadataInfo_or_None) ->
struct(runfiles_group_info, runfiles_group_metadata_info).
�
://runfiles_group/private/providers:runfiles_group_info.bzlr�
Q
rules_runfiles_group runfiles_group/private/providersrunfiles_group_info.bzl5
RunfilesGroupInfo_RunfilesGroupInfo
Yk
��
C//runfiles_group/private/providers:runfiles_group_metadata_info.bzlr�
Z
rules_runfiles_group runfiles_group/private/providers runfiles_group_metadata_info.bzlE
RunfilesGroupMetadataInfo_RunfilesGroupMetadataInfo
b|
��
D//runfiles_group/private/providers:runfiles_group_transform_info.bzlr�
[
rules_runfiles_group runfiles_group/private/providers!runfiles_group_transform_info.bzlG
RunfilesGroupTransformInfo_RunfilesGroupTransformInfo
c~
�(Public API for runfiles group providers. 