ۿ
runfiles_grouplib.bzl�1runfiles_groups.collect�Returns the entry depset for a target: its own entries plus its dependencies'.

O(number of direct dependencies); never flattens anything.

`deps` and `data` are each an iterable of *attribute values*, not one
attribute, so a rule with several Label-typed attributes needs one call:

    runfiles_groups.collect(
        ctx,
        deps = [ctx.attr.deps, ctx.attr.exports],
        data = [ctx.attr.data, ctx.attr.tools],
    )

Every Label-typed attribute kind is accepted and every Target in one
contributes: attr.label, attr.label_list, attr.label_keyed_string_dict,
attr.string_keyed_label_dict and attr.label_list_dict. The string side of a
keyed dict is skipped. A rule with a single label_list can still pass
`deps = ctx.attr.deps` unwrapped: a list of Targets is itself an iterable of
legal elements.

`deps` and `data` are handled differently, which is the whole reason there are
two of them:

    deps    propagates RunfilesGroupInfo, and contributes nothing at all for a
            dependency that has none. These are the ruleset's own targets, so
            they are expected to speak the protocol: synthesizing a group for
            one that does not would hide the bug, and it would claim that
            dependency's whole DefaultInfo -- for a *_library, its entire
            closure's runfiles, which overlaps the groups of everything else
            that closure reaches.
    data    falls back to a synthesized per-target entry
            (runfiles_groups.data_entry()) for a dependency without
            RunfilesGroupInfo. These are arbitrary
            user-supplied targets, usually leaves, and not participating is
            the norm rather than a bug -- nothing else in the build is going
            to group them.

So a dependency that both lacks RunfilesGroupInfo *and* contributes to this
target's default_runfiles must reach `data`, not `deps`, or a packager will
place no group holding its files.

`deps` and `data` are mandatory because handling `data` is the protocol's
classic footgun: pass `data = []` explicitly if your rule has none.

Pass this target's own entries as `own` rather than wrapping the result in
another depset. A depset's depth grows by one per nesting level and Bazel
rejects depsets deeper than --nested_set_depth_limit (3500 by default), so a
long dependency chain has half as much headroom if every level adds two
levels instead of one. `transitive` is there for the same reason: entry
depsets from somewhere other than an attribute -- a toolchain, an aspect's
accumulator -- belong in the same single depset, not in a wrapper around it.
*�
�
runfiles_groups.collect
ctxThe rule context. (�
deps�Iterable of attribute values whose targets' groups this target
propagates -- typically the ruleset's own *_library targets, which
provide RunfilesGroupInfo. (�
data�Iterable of attribute values holding arbitrary targets. Those
without RunfilesGroupInfo get one synthesized per-target entry each,
named by their Label. (J
own=Entries this target owns, built with runfiles_groups.entry().[](E

transitive1Entry depsets to merge in, e.g. from a toolchain.[](�Returns the entry depset for a target: its own entries plus its dependencies'.

O(number of direct dependencies); never flattens anything.

`deps` and `data` are each an iterable of *attribute values*, not one
attribute, so a rule with several Label-typed attributes needs one call:

    runfiles_groups.collect(
        ctx,
        deps = [ctx.attr.deps, ctx.attr.exports],
        data = [ctx.attr.data, ctx.attr.tools],
    )

Every Label-typed attribute kind is accepted and every Target in one
contributes: attr.label, attr.label_list, attr.label_keyed_string_dict,
attr.string_keyed_label_dict and attr.label_list_dict. The string side of a
keyed dict is skipped. A rule with a single label_list can still pass
`deps = ctx.attr.deps` unwrapped: a list of Targets is itself an iterable of
legal elements.

`deps` and `data` are handled differently, which is the whole reason there are
two of them:

    deps    propagates RunfilesGroupInfo, and contributes nothing at all for a
            dependency that has none. These are the ruleset's own targets, so
            they are expected to speak the protocol: synthesizing a group for
            one that does not would hide the bug, and it would claim that
            dependency's whole DefaultInfo -- for a *_library, its entire
            closure's runfiles, which overlaps the groups of everything else
            that closure reaches.
    data    falls back to a synthesized per-target entry
            (runfiles_groups.data_entry()) for a dependency without
            RunfilesGroupInfo. These are arbitrary
            user-supplied targets, usually leaves, and not participating is
            the norm rather than a bug -- nothing else in the build is going
            to group them.

So a dependency that both lacks RunfilesGroupInfo *and* contributes to this
target's default_runfiles must reach `data`, not `deps`, or a packager will
place no group holding its files.

`deps` and `data` are mandatory because handling `data` is the protocol's
classic footgun: pass `data = []` explicitly if your rule has none.

Pass this target's own entries as `own` rather than wrapping the result in
another depset. A depset's depth grows by one per nesting level and Bazel
rejects depsets deeper than --nested_set_depth_limit (3500 by default), so a
long dependency chain has half as much headroom if every level adds two
levels instead of one. `transitive` is there for the same reason: entry
depsets from somewhere other than an attribute -- a toolchain, an aspect's
accumulator -- belong in the same single depset, not in a wrapper around it.
"
A depset of entries.2,
_collect //runfiles_group/private:lib.bzl

ctxThe rule context. (�
�
deps�Iterable of attribute values whose targets' groups this target
propagates -- typically the ruleset's own *_library targets, which
provide RunfilesGroupInfo. (�
�
data�Iterable of attribute values holding arbitrary targets. Those
without RunfilesGroupInfo get one synthesized per-target entry each,
named by their Label. (L
J
own=Entries this target owns, built with runfiles_groups.entry().[](G
E

transitive1Entry depsets to merge in, e.g. from a toolchain.[](�	runfiles_groups.data_entry�Synthesizes the entry for a dependency that provides no runfiles groups.

It is a per-target group named by the dependency's Label, so two targets that
share a data dependency synthesize the same group and
runfiles_groups.resolve() folds them back into one. Naming it with the Label
rather than a string derived from it means this costs nothing: Bazel already
interns the Label and the dependency already holds it.
*�
�
runfiles_groups.data_entry
ctxThe rule context. (.
dep#A Target without RunfilesGroupInfo. (�Synthesizes the entry for a dependency that provides no runfiles groups.

It is a per-target group named by the dependency's Label, so two targets that
share a data dependency synthesize the same group and
runfiles_groups.resolve() folds them back into one. Naming it with the Label
rather than a string derived from it means this costs nothing: Bazel already
interns the Label and the dependency already holds it.
"E
CA group entry covering the dependency's files and default runfiles.2/
_data_entry //runfiles_group/private:lib.bzl

ctxThe rule context. (0
.
dep#A Target without RunfilesGroupInfo. (�runfiles_groups.derive1Copies an entry, changing only the fields passed.*�
�
runfiles_groups.derive
entryThe entry to copy. (F
	overrides7Any subset of the fields runfiles_groups.entry() takes.(1Copies an entry, changing only the fields passed."
A new validated entry.2+
_derive //runfiles_group/private:lib.bzl!

entryThe entry to copy. (H
F
	overrides7Any subset of the fields runfiles_groups.entry() takes.(�runfiles_groups.entries<Builds an entry depset with the order the protocol requires.*�
�
runfiles_groups.entries-
directEntries owned by this target.[](b

transitiveNEntry depsets from dependencies, e.g. the result of
runfiles_groups.collect().[](<Builds an entry depset with the order the protocol requires."'
%A depset of entries, order "default".2,
_entries //runfiles_group/private:lib.bzl/
-
directEntries owned by this target.[](d
b

transitiveNEntry depsets from dependencies, e.g. the result of
runfiles_groups.collect().[](�runfiles_groups.entry"Creates one validated group entry.*�
�
runfiles_groups.entry�
name�The group's identity, in one of two forms.

A **Label** for a per-target group -- "the runfiles this one target
contributes". Pass `ctx.label` for your own, or a dependency's
`dep.label`. A Label is globally unique, so it needs no ruleset prefix,
and it costs nothing: Bazel already interns it.

A **string** for a named group that several targets contribute to --
"interpreter", "std", "third_party". Strings live in a namespace shared
by every provider merged into the same binary, so prefix them with
something unique to your ruleset, e.g. "my_rules#interpreter". (�
content�The group's contents, in one of two forms.

A **depset of File** for a group that is only files, which most
*_library groups are. Hand over the depset you already built: the entry
then points at it, where wrapping it in a runfiles object would retain
an extra ~64 bytes per group -- a 7-field Runfiles plus the nested set
node its compile-order builder has to allocate -- carrying no
information the depset does not.

A **runfiles object** for anything else, and for contents you received
from another rule. This is the general form: it is the only one that can
carry symlinks, root symlinks and empty filenames.

Consumers read either form through runfiles_groups.files() and
runfiles_groups.runfiles(). (�
kind�One of runfiles_groups.KINDS. A stable selector for packagers,
unaffected by renaming. Does not influence ordering or merging. Default "".""(I
rank<Partial ordering key. Lower rank = earlier layer. Default 0.0(U
do_not_merge<If True, packagers must not merge this group. Default False.False(c
weightQMerge priority hint (int >= 0 or None). Lighter groups merge
first. Default None.None(�
merge_affinityrMerge grouping hint. Groups that share an affinity are
preferred merge partners. "" means no affinity. Default "".""("Creates one validated group entry."L
JA group entry, suitable as an element of a RunfilesGroupInfo entry depset.2*
_entry //runfiles_group/private:lib.bzl�
�
name�The group's identity, in one of two forms.

A **Label** for a per-target group -- "the runfiles this one target
contributes". Pass `ctx.label` for your own, or a dependency's
`dep.label`. A Label is globally unique, so it needs no ruleset prefix,
and it costs nothing: Bazel already interns it.

A **string** for a named group that several targets contribute to --
"interpreter", "std", "third_party". Strings live in a namespace shared
by every provider merged into the same binary, so prefix them with
something unique to your ruleset, e.g. "my_rules#interpreter". (�
�
content�The group's contents, in one of two forms.

A **depset of File** for a group that is only files, which most
*_library groups are. Hand over the depset you already built: the entry
then points at it, where wrapping it in a runfiles object would retain
an extra ~64 bytes per group -- a 7-field Runfiles plus the nested set
node its compile-order builder has to allocate -- carrying no
information the depset does not.

A **runfiles object** for anything else, and for contents you received
from another rule. This is the general form: it is the only one that can
carry symlinks, root symlinks and empty filenames.

Consumers read either form through runfiles_groups.files() and
runfiles_groups.runfiles(). (�
�
kind�One of runfiles_groups.KINDS. A stable selector for packagers,
unaffected by renaming. Does not influence ordering or merging. Default "".""(K
I
rank<Partial ordering key. Lower rank = earlier layer. Default 0.0(W
U
do_not_merge<If True, packagers must not merge this group. Default False.False(e
c
weightQMerge priority hint (int >= 0 or None). Lighter groups merge
first. Default None.None(�
�
merge_affinityrMerge grouping hint. Groups that share an affinity are
preferred merge partners. "" means no affinity. Default "".""(�	runfiles_groups.files�Returns every File a group contributes, as a depset.

The read path for a packager that only needs paths -- a manifest, an output
group, a layer's contents. It allocates nothing for a files-only group and, for
a runfiles-form group, only the depset wrapper Bazel builds per `.files` access.

Note what it deliberately does not include: the symlinks, root symlinks and
empty filenames of a runfiles-form group. A packager that must place a complete
runfiles tree wants runfiles_groups.runfiles() instead.
*�
�
runfiles_groups.files
entryA group entry. (�Returns every File a group contributes, as a depset.

The read path for a packager that only needs paths -- a manifest, an output
group, a layer's contents. It allocates nothing for a files-only group and, for
a runfiles-form group, only the depset wrapper Bazel builds per `.files` access.

Note what it deliberately does not include: the symlinks, root symlinks and
empty filenames of a runfiles-form group. A packager that must place a complete
runfiles tree wants runfiles_groups.runfiles() instead.
"
A depset of File.2*
_files //runfiles_group/private:lib.bzl

entryA group entry. (�runfiles_groups.group_namesCReturns the group names of a resolved group set, as sorted strings.*�
�
runfiles_groups.group_namesE
resolved5A resolved group set, from runfiles_groups.resolve(). (CReturns the group names of a resolved group set, as sorted strings."}
{A sorted list of canonical name strings. Use resolved.by_name if you need
the names in their original Label-or-string form.20
_group_names //runfiles_group/private:lib.bzlG
E
resolved5A resolved group set, from runfiles_groups.resolve(). (�!runfiles_groups.index_by_name_str�Indexes a resolved group set by canonical name string.

Useful for a packager whose user-facing configuration names groups as strings:
a user writes "@@//src:lib_a" (the canonical form of a per-target group's Label)
or "my_rules#interpreter", and this resolves either against the actual entries.
*�
�
!runfiles_groups.index_by_name_strE
resolved5A resolved group set, from runfiles_groups.resolve(). (�Indexes a resolved group set by canonical name string.

Useful for a packager whose user-facing configuration names groups as strings:
a user writes "@@//src:lib_a" (the canonical form of a per-target group's Label)
or "my_rules#interpreter", and this resolves either against the actual entries.
"
dict[str, entry].26
_index_by_name_str //runfiles_group/private:lib.bzlG
E
resolved5A resolved group set, from runfiles_groups.resolve(). (�runfiles_groups.is_enabled�Returns whether RunfilesGroupInfo emission is globally enabled.

Reads the @rules_runfiles_group//runfiles_group:enabled build setting.
Requires runfiles_groups.RULE_ATTRS to have been merged into the rule's attrs.
*�
�
runfiles_groups.is_enabled
ctxThe rule context. (�Returns whether RunfilesGroupInfo emission is globally enabled.

Reads the @rules_runfiles_group//runfiles_group:enabled build setting.
Requires runfiles_groups.RULE_ATTRS to have been merged into the rule's attrs.
"8
6True if producing rules should emit RunfilesGroupInfo.2/
_is_enabled //runfiles_group/private:lib.bzl

ctxThe rule context. (�runfiles_groups.limit�Merges groups until at most max_groups remain.

Merges are picked in this order: same rank only; then prefer pairs that share
a merge_affinity ("" is the shared "no affinity" bucket); then the two
lightest by weight.
*�
�	
runfiles_groups.limit�
ctx�The rule or aspect context. Used only where a merged pair mixes a
files-only group's depset with another group's runfiles object, which
needs ctx.runfiles(). (E
resolved5A resolved group set, from runfiles_groups.resolve(). (4

max_groups"Maximum number of groups to leave. (I
default_weight2Weight to assume for entries whose weight is None.0(�
merged_group_name�Optional function
(lighter_name, lighter_weight, heavier_name, heavier_weight) -> name
naming the merged group. The names it receives are in their original
Label-or-string form; use runfiles_groups.name_str() to render them. It
may return either form, though a merged group is rarely still one target's, so a
string is the usual answer. If None, the heavier group's name is kept.None(�Merges groups until at most max_groups remain.

Merges are picked in this order: same rank only; then prefer pairs that share
a merge_affinity ("" is the shared "no affinity" bucket); then the two
lightest by weight.
"�
�struct(groups, by_name, executable_group, group_count). The caller MUST
check group_count: do_not_merge and rank constraints can make max_groups
unreachable.2*
_limit //runfiles_group/private:lib.bzl�
�
ctx�The rule or aspect context. Used only where a merged pair mixes a
files-only group's depset with another group's runfiles object, which
needs ctx.runfiles(). (G
E
resolved5A resolved group set, from runfiles_groups.resolve(). (6
4

max_groups"Maximum number of groups to leave. (K
I
default_weight2Weight to assume for entries whose weight is None.0(�
�
merged_group_name�Optional function
(lighter_name, lighter_weight, heavier_name, heavier_weight) -> name
naming the merged group. The names it receives are in their original
Label-or-string form; use runfiles_groups.name_str() to render them. It
may return either form, though a merged group is rarely still one target's, so a
string is the usual answer. If None, the heavier group's name is kept.None(�runfiles_groups.name_str�Canonical string form of a group name, for display and artifact naming.

Not injective by construction: nothing stops a producer from naming one group
with `Label("//p:t")` and another with the string `"@@//p:t"`. Anything that
*keys* on the result must therefore reject a collision rather than let one
group quietly overwrite another -- see runfiles_groups.index_by_name_str and
runfiles_groups.limit.
*�
�
runfiles_groups.name_str=
value0A group name (a Label or a string), or an entry. (�Canonical string form of a group name, for display and artifact naming.

Not injective by construction: nothing stops a producer from naming one group
with `Label("//p:t")` and another with the string `"@@//p:t"`. Anything that
*keys* on the result must therefore reject a collision rather than let one
group quietly overwrite another -- see runfiles_groups.index_by_name_str and
runfiles_groups.limit.
"E
Cstr(label) for a per-target group, the name itself for a named one.2-
	_name_str //runfiles_group/private:lib.bzl?
=
value0A group name (a Label or a string), or an entry. (�runfiles_groups.resolve�Flattens, folds, transforms and orders a target's runfiles groups.

This is the only place in the protocol that flattens a depset. Call it once per
*consuming* target, never from a library rule.

`aspect_hints` is a mandatory keyword: with a default, the correct call and the
call that silently ignores every user hint look identical. Pass
`ctx.rule.attr.aspect_hints` from an aspect, or `[]`.
*�

�
runfiles_groups.resolve�
ctx�The rule or aspect context. Used only if folding duplicate group names
has to union a files-only group's depset with another group's runfiles
object, which needs ctx.runfiles() -- the only lift Bazel offers. (D
source6A Target, a RunfilesGroupInfo, or a depset of entries. (G
aspect_hints3The target's aspect_hints (list of Targets), or []. (�Flattens, folds, transforms and orders a target's runfiles groups.

This is the only place in the protocol that flattens a depset. Call it once per
*consuming* target, never from a library rule.

`aspect_hints` is a mandatory keyword: with a default, the correct call and the
call that silently ignores every user hint look identical. Pass
`ctx.rule.attr.aspect_hints` from an aspect, or `[]`.
"�
�struct(groups, by_name, executable_group), or None when the source carries
no groups at all -- package DefaultInfo.default_runfiles as a single group
in that case.2,
_resolve //runfiles_group/private:lib.bzl�
�
ctx�The rule or aspect context. Used only if folding duplicate group names
has to union a files-only group's depset with another group's runfiles
object, which needs ctx.runfiles() -- the only lift Bazel offers. (F
D
source6A Target, a RunfilesGroupInfo, or a depset of entries. (I
G
aspect_hints3The target's aspect_hints (list of Targets), or []. (�runfiles_groups.resolved�Builds a resolved group set from a list of entries, ordered by (rank, name).

This is what a RunfilesGroupTransformInfo transform returns.
*�
�
runfiles_groups.resolved4
groups&List of entries. Names must be unique. (�
executable_groupgThe name (Label or string) of the group carrying the
executable, or None. It must name one of `groups`.None(�Builds a resolved group set from a list of entries, ordered by (rank, name).

This is what a RunfilesGroupTransformInfo transform returns.
",
*struct(groups, by_name, executable_group).2-
	_resolved //runfiles_group/private:lib.bzl6
4
groups&List of entries. Names must be unique. (�
�
executable_groupgThe name (Label or string) of the group carrying the
executable, or None. It must name one of `groups`.None(�runfiles_groups.runfiles�Returns a group's contents as a runfiles object.

Identity for a group that already carries one; for a files-only group it builds
one, which is why this takes a ctx. Never store the result in a provider: doing
so re-retains, per consuming target, exactly the object the producer avoided.
*�
�
runfiles_groups.runfilesK
ctx@The rule or aspect context. ctx.runfiles() is available in both. (
entryA group entry. (�Returns a group's contents as a runfiles object.

Identity for a group that already carries one; for a files-only group it builds
one, which is why this takes a ctx. Never store the result in a provider: doing
so re-retains, per consuming target, exactly the object the producer avoided.
"1
/A runfiles object holding the group's contents.2-
	_runfiles //runfiles_group/private:lib.bzlM
K
ctx@The rule or aspect context. ctx.runfiles() is available in both. (

entryA group entry. (�runfiles_groups.union�Unions several groups' contents into one content value.

For a producer that aggregates groups -- one group per repository out of one
group per target, say. Pass `entry.content` values and/or runfiles objects of
your own; the result goes straight into runfiles_groups.entry(content = ...).

Stays in the depset form when every part is one, so aggregating files-only
groups still retains no runfiles object. A mixed union is the only thing in the
protocol that must build one, because Bazel offers no way to merge a depset into
a runfiles object other than ctx.runfiles().
*�
�
runfiles_groups.union&
ctxThe rule or aspect context. (M
contents=List of content values (runfiles objects or depsets of File). (�Unions several groups' contents into one content value.

For a producer that aggregates groups -- one group per repository out of one
group per target, say. Pass `entry.content` values and/or runfiles objects of
your own; the result goes straight into runfiles_groups.entry(content = ...).

Stays in the depset form when every part is one, so aggregating files-only
groups still retains no runfiles object. A mixed union is the only thing in the
protocol that must build one, because Bazel offers no way to merge a depset into
a runfiles object other than ctx.runfiles().
"R
PA content value: a depset of File if every part was one, else a runfiles
object.2*
_union //runfiles_group/private:lib.bzl(
&
ctxThe rule or aspect context. (O
M
contents=List of content values (runfiles objects or depsets of File). (0Public API for runfiles group library functions.�N
runfiles_groupproviders.bzl�3RunfilesGroupInfo�Runfiles of a target, split into named groups.

Fields:

- `entries`: a depset of group entries, each built with `runfiles_groups.entry()`.
  Every entry carries its own name, contents and ordering/merge metadata, so a
  target propagates its dependencies' groups by referencing their depsets rather
  than by copying them. The per-target cost is therefore independent of how many
  groups the transitive closure contains.

  A group's name is either a **Label**, meaning a per-target group ("the runfiles
  this one target contributes"), or a **string**, meaning a named group that
  several targets contribute to. See `runfiles_groups.entry()`, and
  `runfiles_groups.name_str()` for rendering either form as a string.

  A group's contents are either a **runfiles object** or, for a group that is only
  files, a **depset of File**. Consumers read both through
  `runfiles_groups.files(entry)` and `runfiles_groups.runfiles(ctx, entry)` and must
  not touch `entry.content` directly, other than to pass it back to
  `runfiles_groups.union()` or `runfiles_groups.entry()`.

  The depset order MUST be `"default"` (stable): it is the only order that can be
  merged with every other order, which a producer needs in order to combine entry
  depsets coming from foreign rulesets. Starlark cannot read a depset's order
  back, so build the depset with `runfiles_groups.entries()` or
  `runfiles_groups.collect()`, which do it correctly. Traversal order is never
  observable: `runfiles_groups.resolve()` sorts by `(rank, name)`.

  Group names MAY repeat across the depset -- two targets can each synthesize an
  entry for the same shared data dependency. `runfiles_groups.resolve()` folds
  duplicates by name, unioning their contents.

- `executable_group`: the *name* of the group that should receive the executable,
  the runfiles symlinks, the repo mapping manifest and the other supporting files
  of the entrypoint, or None to let the packager decide. Either name form.

  A name rather than a reference to an entry, because a name survives renaming,
  merging and hint transforms, can be validated (`runfiles_groups.resolve()` fails
  if it names no surviving group), and is greppable. Entry references would compare
  by value, so a stale one would silently match nothing -- or two entries at once.

  Only meaningful on the top-level target. `runfiles_groups.collect()` never
  propagates a dependency's, so nothing has to be stripped.

Unioning the contents of every entry must yield the same runfiles as
DefaultInfo.default_runfiles. A group whose contents are a depset of File
contributes exactly those files and no symlinks, root symlinks or empty filenames,
so a rule whose runfiles carry any of those cannot express them in that form.

This provider functions similarly to OutputGroupInfo, but its presence in the
output of a rule indicates that it can be used instead of
DefaultInfo.default_runfiles.2�
�
RunfilesGroupInfo�Runfiles of a target, split into named groups.

Fields:

- `entries`: a depset of group entries, each built with `runfiles_groups.entry()`.
  Every entry carries its own name, contents and ordering/merge metadata, so a
  target propagates its dependencies' groups by referencing their depsets rather
  than by copying them. The per-target cost is therefore independent of how many
  groups the transitive closure contains.

  A group's name is either a **Label**, meaning a per-target group ("the runfiles
  this one target contributes"), or a **string**, meaning a named group that
  several targets contribute to. See `runfiles_groups.entry()`, and
  `runfiles_groups.name_str()` for rendering either form as a string.

  A group's contents are either a **runfiles object** or, for a group that is only
  files, a **depset of File**. Consumers read both through
  `runfiles_groups.files(entry)` and `runfiles_groups.runfiles(ctx, entry)` and must
  not touch `entry.content` directly, other than to pass it back to
  `runfiles_groups.union()` or `runfiles_groups.entry()`.

  The depset order MUST be `"default"` (stable): it is the only order that can be
  merged with every other order, which a producer needs in order to combine entry
  depsets coming from foreign rulesets. Starlark cannot read a depset's order
  back, so build the depset with `runfiles_groups.entries()` or
  `runfiles_groups.collect()`, which do it correctly. Traversal order is never
  observable: `runfiles_groups.resolve()` sorts by `(rank, name)`.

  Group names MAY repeat across the depset -- two targets can each synthesize an
  entry for the same shared data dependency. `runfiles_groups.resolve()` folds
  duplicates by name, unioning their contents.

- `executable_group`: the *name* of the group that should receive the executable,
  the runfiles symlinks, the repo mapping manifest and the other supporting files
  of the entrypoint, or None to let the packager decide. Either name form.

  A name rather than a reference to an entry, because a name survives renaming,
  merging and hint transforms, can be validated (`runfiles_groups.resolve()` fails
  if it names no surviving group), and is greppable. Entry references would compare
  by value, so a stale one would silently match nothing -- or two entries at once.

  Only meaningful on the top-level target. `runfiles_groups.collect()` never
  propagates a dependency's, so nothing has to be stripped.

Unioning the contents of every entry must yield the same runfiles as
DefaultInfo.default_runfiles. A group whose contents are a depset of File
contributes exactly those files and no symlinks, root symlinks or empty filenames,
so a rule whose runfiles carry any of those cannot express them in that form.

This provider functions similarly to OutputGroupInfo, but its presence in the
output of a rule indicates that it can be used instead of
DefaultInfo.default_runfiles.|
entriesqdepset of group entries, order = "default". Build it with runfiles_groups.entries() or runfiles_groups.collect().o
executable_group[Label, str or None: name of the group that carries the executable and its supporting files."O
RunfilesGroupInfo://runfiles_group/private/providers:runfiles_group_info.bzl*�
RunfilesGroupInfo
entries (
executable_groupNone(2Z
_make_runfilesgroupinfo_init://runfiles_group/private/providers:runfiles_group_info.bzl~
|
entriesqdepset of group entries, order = "default". Build it with runfiles_groups.entries() or runfiles_groups.collect().q
o
executable_group[Label, str or None: name of the group that carries the executable and its supporting files.�RunfilesGroupTransformInfo�Information about how to transform a target's resolved runfiles groups.

`transform` takes the value `runfiles_groups.resolve()` produced --
`struct(groups, by_name, executable_group)` -- and returns a new one, built with
`runfiles_groups.resolved()`. Edit or create individual entries with
`runfiles_groups.derive()` and `runfiles_groups.entry()`. A transform that changes
nothing should `return resolved` unchanged.

It runs once per consuming target, after the entry depset has been flattened
exactly once, so it is pure list and dict work: no depset is rebuilt and no
provider is reconstructed. A transform has no `ctx`, so it cannot build a runfiles
object -- an entry it creates from scratch has to carry a depset of File, which is
`runfiles_groups.entry()`'s files-only content form.

    def _drop_docs(resolved):
        if not [e for e in resolved.groups if e.kind == "docs"]:
            return resolved
        return runfiles_groups.resolved(
            [e for e in resolved.groups if e.kind != "docs"],
            executable_group = resolved.executable_group,
        )

`transform` MUST be a module-level `def`, never a lambda or a nested function
created during analysis: a nested function captures a cell per free variable and
pins everything it closes over -- ctx, dep lists, dicts -- for as long as the
provider lives. A module-level def closes only over its module, which Bazel
already retains for the lifetime of the server.2�
�
RunfilesGroupTransformInfo�Information about how to transform a target's resolved runfiles groups.

`transform` takes the value `runfiles_groups.resolve()` produced --
`struct(groups, by_name, executable_group)` -- and returns a new one, built with
`runfiles_groups.resolved()`. Edit or create individual entries with
`runfiles_groups.derive()` and `runfiles_groups.entry()`. A transform that changes
nothing should `return resolved` unchanged.

It runs once per consuming target, after the entry depset has been flattened
exactly once, so it is pure list and dict work: no depset is rebuilt and no
provider is reconstructed. A transform has no `ctx`, so it cannot build a runfiles
object -- an entry it creates from scratch has to carry a depset of File, which is
`runfiles_groups.entry()`'s files-only content form.

    def _drop_docs(resolved):
        if not [e for e in resolved.groups if e.kind == "docs"]:
            return resolved
        return runfiles_groups.resolved(
            [e for e in resolved.groups if e.kind != "docs"],
            executable_group = resolved.executable_group,
        )

`transform` MUST be a module-level `def`, never a lambda or a nested function
created during analysis: a nested function captures a cell per free variable and
pins everything it closes over -- ctx, dep lists, dicts -- for as long as the
provider lives. A module-level def closes only over its module, which Bazel
already retains for the lifetime of the server.E
	transform8A module-level Starlark function (resolved) -> resolved."b
RunfilesGroupTransformInfoD//runfiles_group/private/providers:runfiles_group_transform_info.bzl*�
RunfilesGroupTransformInfo
	transform (2h
 _make_runfilestransforminfo_initD//runfiles_group/private/providers:runfiles_group_transform_info.bzlG
E
	transform8A module-level Starlark function (resolved) -> resolved.(Public API for runfiles group providers.�6
2runfiles_group runfiles_group_analysis_test.bzl�5runfiles_group_analysis_test�Checks that RunfilesGroupInfo is well formed by comparing all runfiles components
(files, empty_filenames, symlinks, root_symlinks) of DefaultInfo.default_runfiles
with the union of all runfiles from RunfilesGroupInfo.

Resolving the provider also validates every group entry and that executable_group,
if set, names a surviving group.

Additionally, it can warn about entries appearing in multiple groups (overlapping),
verify the expected ordered group names, verify which group carries the executable,
and optionally apply merge-to-limit before ordering.

Every binary is analyzed in two configurations via a split transition, so one test
target also verifies that the rule honors the global on/off switch
(@rules_runfiles_group//runfiles_group:enabled):

  * enabled: all of the checks above run against the emitted providers.
  * disabled: the binary must provide no RunfilesGroupInfo at all. Set
    check_disabled = False to skip this branch, which avoids analyzing the
    binary's whole closure a second time.

Because both branches are pinned by the transition, the test is independent of the
value the flag has on the command line."�,
�
runfiles_group_analysis_test�Checks that RunfilesGroupInfo is well formed by comparing all runfiles components
(files, empty_filenames, symlinks, root_symlinks) of DefaultInfo.default_runfiles
with the union of all runfiles from RunfilesGroupInfo.

Resolving the provider also validates every group entry and that executable_group,
if set, names a surviving group.

Additionally, it can warn about entries appearing in multiple groups (overlapping),
verify the expected ordered group names, verify which group carries the executable,
and optionally apply merge-to-limit before ordering.

Every binary is analyzed in two configurations via a split transition, so one test
target also verifies that the rule honors the global on/off switch
(@rules_runfiles_group//runfiles_group:enabled):

  * enabled: all of the checks above run against the emitted providers.
  * disabled: the binary must provide no RunfilesGroupInfo at all. Set
    check_disabled = False to skip this branch, which avoids analyzing the
    binary's whole closure a second time.

Because both branches are pinned by the transition, the test is independent of the
value the flag has on the command line.*
nameA unique name for this target. 1
binaries!List of *_binary targets to test. �
check_disabled�Also analyze every binary with @rules_runfiles_group//runfiles_group:enabled set
to False and verify it emits no RunfilesGroupInfo.

This is the only automated check of the producer contract's one MUST, so it is on
by default. It does cost a second configuration for the binary and its entire
transitive closure, so set it to False on tests over large binaries and keep one
small target that checks it. Must not be a select().2True�
expected_group_names�If set, the test verifies that the ordered group names (after optional merging and rank-based ordering)
match this list exactly. Applies to all binaries in the test.

Names are compared in canonical string form (runfiles_groups.name_str), so a group
named by a Label is written as its canonical label string, e.g. "@@//src:lib_a".2[]�
expected_executable_group�If set, the test verifies that RunfilesGroupInfo.executable_group (after optional
merging) is exactly this group name, in canonical string form
(runfiles_groups.name_str) -- so a group named by a Label is written as its
canonical label string. Applies to all binaries in the test.2""l

max_groupsXIf >= 0, apply runfiles_groups.limit with this limit before ordering. -1 means no limit.2-1�
expected_group_count�If >= 0, verify the exact number of groups after merging (requires max_groups >= 0).
Use this when merging cannot reach max_groups (e.g., due to do_not_merge or rank constraints)
to assert the actual reachable count. -1 means no check (the test fails if group_count > max_groups instead).2-1�
group_name_prefix�If set, merged group names will strip this prefix from the second (heavier) group name
before joining with '+'. This avoids repeating a common prefix in merged names.
For example, with prefix "p#", merging "p#foo" and "p#bar" produces "p#foo+bar" instead of "p#foo+p#bar".
Names are canonicalized first, so this also applies to groups named by a Label.2""�
overlapping_group_behaviorWHow to handle overlapping groups (the same entry being present in more than one group).2"warn"J"warn"J"ignore"J"error""_
runfiles_group_analysis_test?//runfiles_group/private/rules:runfiles_group_analysis_test.bzl08,
*
nameA unique name for this target. 3
1
binaries!List of *_binary targets to test. �
�
check_disabled�Also analyze every binary with @rules_runfiles_group//runfiles_group:enabled set
to False and verify it emits no RunfilesGroupInfo.

This is the only automated check of the producer contract's one MUST, so it is on
by default. It does cost a second configuration for the binary and its entire
transitive closure, so set it to False on tests over large binaries and keep one
small target that checks it. Must not be a select().2True�
�
expected_group_names�If set, the test verifies that the ordered group names (after optional merging and rank-based ordering)
match this list exactly. Applies to all binaries in the test.

Names are compared in canonical string form (runfiles_groups.name_str), so a group
named by a Label is written as its canonical label string, e.g. "@@//src:lib_a".2[]�
�
expected_executable_group�If set, the test verifies that RunfilesGroupInfo.executable_group (after optional
merging) is exactly this group name, in canonical string form
(runfiles_groups.name_str) -- so a group named by a Label is written as its
canonical label string. Applies to all binaries in the test.2""n
l

max_groupsXIf >= 0, apply runfiles_groups.limit with this limit before ordering. -1 means no limit.2-1�
�
expected_group_count�If >= 0, verify the exact number of groups after merging (requires max_groups >= 0).
Use this when merging cannot reach max_groups (e.g., due to do_not_merge or rank constraints)
to assert the actual reachable count. -1 means no check (the test fails if group_count > max_groups instead).2-1�
�
group_name_prefix�If set, merged group names will strip this prefix from the second (heavier) group name
before joining with '+'. This avoids repeating a common prefix in merged names.
For example, with prefix "p#", merging "p#foo" and "p#bar" produces "p#foo+bar" instead of "p#foo+p#bar".
Names are canonicalized first, so this also applies to groups named by a Label.2""�
�
overlapping_group_behaviorWHow to handle overlapping groups (the same entry being present in more than one group).2"warn"J"warn"J"ignore"J"error",Public API for runfiles_group_analysis_test. 