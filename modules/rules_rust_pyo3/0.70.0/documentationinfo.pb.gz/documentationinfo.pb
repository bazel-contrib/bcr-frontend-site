�
.
rules_rust_pyo33rdparty/crates
crates.bzl�crate_repositories+Generates repositories for vendored crates.*�
�
crate_repositories+Generates repositories for vendored crates."E
CA list of repos visible to the module through the module extension.2C
crate_repositories-@@rules_rust_pyo3//3rdparty/crates:crates.bzl
�
!//tools/build_defs/repo:utils.bzlr]
/
bazel_toolstools/build_defs/repo	utils.bzl
maybemaybe
	8	=
		?�
*//crate_universe/private:crates_vendor.bzlr�
7

rules_rustcrate_universe/privatecrates_vendor.bzlP
crates_vendor_remote_repositorycrates_vendor_remote_repository
@_
a�
//3rdparty/crates:defs.bzlru
,
rules_rust_pyo33rdparty/cratesdefs.bzl7
crate_repositories_crate_repositories
4G
_GRules for defining repositories for remote `crates_vendor` repositories�
3
rules_rust_pyo33rdparty/cratesalias_rules.bzl�transition_alias_dbg?Transitions a Rust library crate to the `compilation_mode=opt`."�
�
transition_alias_dbg?Transitions a Rust library crate to the `compilation_mode=opt`.*
nameA unique name for this target. q
actual@`rust_library()` target to transition to `compilation_mode=opt`. *!
	CrateInfo
DepInfo
DefaultInfo"J
transition_alias_dbg2@@rules_rust_pyo3//3rdparty/crates:alias_rules.bzl
,
*
nameA unique name for this target. s
q
actual@`rust_library()` target to transition to `compilation_mode=opt`. *!
	CrateInfo
DepInfo
DefaultInfo�transition_alias_fastbuild?Transitions a Rust library crate to the `compilation_mode=opt`."�
�
transition_alias_fastbuild?Transitions a Rust library crate to the `compilation_mode=opt`.*
nameA unique name for this target. q
actual@`rust_library()` target to transition to `compilation_mode=opt`. *!
	CrateInfo
DepInfo
DefaultInfo"P
transition_alias_fastbuild2@@rules_rust_pyo3//3rdparty/crates:alias_rules.bzl
,
*
nameA unique name for this target. s
q
actual@`rust_library()` target to transition to `compilation_mode=opt`. *!
	CrateInfo
DepInfo
DefaultInfo�transition_alias_opt?Transitions a Rust library crate to the `compilation_mode=opt`."�
�
transition_alias_opt?Transitions a Rust library crate to the `compilation_mode=opt`.*
nameA unique name for this target. q
actual@`rust_library()` target to transition to `compilation_mode=opt`. *!
	CrateInfo
DepInfo
DefaultInfo"J
transition_alias_opt2@@rules_rust_pyo3//3rdparty/crates:alias_rules.bzl
,
*
nameA unique name for this target. s
q
actual@`rust_library()` target to transition to `compilation_mode=opt`. *!
	CrateInfo
DepInfo
DefaultInfo[
//cc:defs.bzlrH

rules_ccccdefs.bzl
CcInfoCcInfo
!'
)�
//rust:rust_common.bzlrg
#

rules_rustrustrust_common.bzl2
COMMON_PROVIDERSCOMMON_PROVIDERS
,<
>eAlias that transitions its target to `compilation_mode=opt`.  Use `transition_alias="opt"` to enable.� 
,
rules_rust_pyo33rdparty/cratesdefs.bzl�
aliases�Produces a map of Crate alias names to their original label

If no dependency kinds are specified, `normal` and `proc_macro` are used by default.
Setting any one flag will otherwise determine the contents of the returned dict.
*�
�
aliasesP
normal=If True, normal dependencies are included in the
output list.False(]

normal_devFIf True, normal dev dependencies will be
included in the output list..False(X

proc_macroAIf True, proc_macro dependencies are included
in the output list.False(`
proc_macro_devEIf True, dev proc_macro dependencies are
included in the output list.False(N
build<If True, build dependencies are included
in the output list.False(d
build_proc_macroGIf True, build proc_macro dependencies are
included in the output list.False(
package_namegThe package name of the set of dependencies to look up.
Defaults to `native.package_name()` when unset.None(�Produces a map of Crate alias names to their original label

If no dependency kinds are specified, `normal` and `proc_macro` are used by default.
Setting any one flag will otherwise determine the contents of the returned dict.
".
,dict: The aliases of all associated packages26
aliases+@@rules_rust_pyo3//3rdparty/crates:defs.bzl
���
all_crate_deps�Finds the fully qualified label of all requested direct crate dependencies     for the package where this macro is called.

If no parameters are set, all normal dependencies are returned. Setting any one flag will
otherwise impact the contents of the returned list.
*�
�
all_crate_depsP
normal=If True, normal dependencies are included in the
output list.False(\

normal_devEIf True, normal dev dependencies will be
included in the output list.False(X

proc_macroAIf True, proc_macro dependencies are included
in the output list.False(`
proc_macro_devEIf True, dev proc_macro dependencies are
included in the output list.False(N
build<If True, build dependencies are included
in the output list.False(d
build_proc_macroGIf True, build proc_macro dependencies are
included in the output list.False(
package_namegThe package name of the set of dependencies to look up.
Defaults to `native.package_name()` when unset.None(�Finds the fully qualified label of all requested direct crate dependencies     for the package where this macro is called.

If no parameters are set, all normal dependencies are returned. Setting any one flag will
otherwise impact the contents of the returned list.
"8
6list: A list of labels to generated rust targets (str)2=
all_crate_deps+@@rules_rust_pyo3//3rdparty/crates:defs.bzl
���
crate_depscFinds the fully qualified label of the requested crates for the package where this macro is called.*�
�

crate_deps.
deps"The desired list of crate targets. (t
package_name\The package name of the set of dependencies to look up.
Defaults to `native.package_name()`.None(cFinds the fully qualified label of the requested crates for the package where this macro is called."8
6list: A list of labels to generated rust targets (str)29

crate_deps+@@rules_rust_pyo3//3rdparty/crates:defs.bzl
VV�crate_repositories;A macro for defining repositories for all generated crates.*�
�
crate_repositories;A macro for defining repositories for all generated crates."E
CA list of repos visible to the module through the module extension.2A
crate_repositories+@@rules_rust_pyo3//3rdparty/crates:defs.bzl
��i
//lib:selects.bzlrR
 
bazel_skyliblibselects.bzl 
selectsselects
)0
2�
 //tools/build_defs/repo:http.bzlrj
.
bazel_toolstools/build_defs/repohttp.bzl*
http_archivehttp_archive
7C
E�
!//tools/build_defs/repo:utils.bzlr]
/
bazel_toolstools/build_defs/repo	utils.bzl
maybemaybe
8=
?�
# `crates_repository` API

- [aliases](#aliases)
- [crate_deps](#crate_deps)
- [all_crate_deps](#all_crate_deps)
- [crate_repositories](#crate_repositories)

�
3
rules_rust_pyo3privateinternal_extensions.bzl�rust_ext&Dependencies for pyo3 rules extension.J�
r
rust_ext&Dependencies for pyo3 rules extension.">
rust_ext2@@rules_rust_pyo3//private:internal_extensions.bzl
�
//3rdparty/crates:crates.bzlrv
.
rules_rust_pyo33rdparty/crates
crates.bzl6
crate_repositoriescrate_repositories
7I
KBzlmod module extensions�
7
rules_rust_pyo3privateinternal_extensions_dev.bzl�rust_ext_devCDevelopment dependencies for the rules_rust_wasm_bindgen extension.J�
�
rust_ext_devCDevelopment dependencies for the rules_rust_wasm_bindgen extension."F
rust_ext_dev6@@rules_rust_pyo3//private:internal_extensions_dev.bzl
  o
:rbe_repo.bzlr\

bazel_ci_rulesrbe_repo.bzl,
rbe_preconfigrbe_preconfig
)6
8Bzlmod internal extensions��
$
rules_rust_pyo3privatepyo3.bzl�py_pyo3_library-Define a Python library for a PyO3 extension."�

�
py_pyo3_library-Define a Python library for a PyO3 extension.*
nameA unique name for this target. �
compilation_mode�Specify the mode `extension` will be built in. For details see  [`--compilation_mode`](https://bazel.build/reference/command-line-reference#flag--compilation_mode)2"opt"3
	extensionThe PyO3 library. *
TestCrateInfoL
imports;List of import directories to be added to the `PYTHONPATH`.2[]e
module_namePA full dotted Python module path implemented by this extension (e.g. `foo.bar`).2""�
stubs�Whether or not to generate stubs. `-1` will default to the global config, `0` will never generate, and `1` will always generate stubs.2-1"6
py_pyo3_library#@@rules_rust_pyo3//private:pyo3.bzl
��,
*
nameA unique name for this target. �
�
compilation_mode�Specify the mode `extension` will be built in. For details see  [`--compilation_mode`](https://bazel.build/reference/command-line-reference#flag--compilation_mode)2"opt"5
3
	extensionThe PyO3 library. *
TestCrateInfoN
L
imports;List of import directories to be added to the `PYTHONPATH`.2[]g
e
module_namePA full dotted Python module path implemented by this extension (e.g. `foo.bar`).2""�
�
stubs�Whether or not to generate stubs. `-1` will default to the global config, `0` will never generate, and `1` will always generate stubs.2-1�rpyo3_extension�Define a PyO3 python extension module.

This target is consumed just as a `py_library` would be.

[rsl]: https://bazelbuild.github.io/rules_rust/defs.html#rust_shared_library
[pli]: https://bazel.build/reference/be/python#py_binary.imports


Builds a Rust shared library.

This shared library will contain all transitively reachable crates and native objects.
It is meant to be used when producing an artifact that is then consumed by some other build system
(for example to produce a shared library that Python program links against).

This rule provides CcInfo, so it can be used everywhere Bazel expects `rules_cc`.

When building the whole binary in Bazel, use `rust_library` instead.
"�m
�9
pyo3_extension�Define a PyO3 python extension module.

This target is consumed just as a `py_library` would be.

[rsl]: https://bazelbuild.github.io/rules_rust/defs.html#rust_shared_library
[pli]: https://bazel.build/reference/be/python#py_binary.imports


Builds a Rust shared library.

This shared library will contain all transitively reachable crates and native objects.
It is meant to be used when producing an artifact that is then consumed by some other build system
(for example to produce a shared library that Python program links against).

This rule provides CcInfo, so it can be used everywhere Bazel expects `rules_cc`.

When building the whole binary in Bazel, use `rust_library` instead.
*
nameA unique name for this target. �
aliases�Remap crates to a new name or moniker for linkage to this target

These are other `rust_library` targets and will be presented as the new name given.
	2{}W
allocator_libraries*
AllocatorLibrariesInfo2$//ffi/rs:default_allocator_libraries�

alwayslink�If 1, any binary that depends (directly or indirectly) on this library
will link in all the object files even if some contain no symbols referenced by the binary.

This attribute is used by the C++ Starlark API when passing CcInfo providers.
2False�
compile_data�List of files used by this rule at compile time.

This attribute can be used to specify any data files that are embedded into
the library, such as via the
[`include_str!`](https://doc.rust-lang.org/std/macro.include_str!.html)
macro.
2[]�
crate_features�List of features to enable for this crate.

Features are defined in the code using the `#[cfg(feature = "foo")]`
configuration option. The features listed here will be passed to `rustc`
with `--cfg feature="${feature_name}"` flags.
2[]�

crate_name�Crate name to use for this target.

This must be a valid Rust identifier, i.e. it may contain only alphanumeric characters and underscores.
Defaults to the target name, with any hyphens replaced by underscores.
2""�

crate_root�The file that will be passed to `rustc` to be used for building this crate.

If `crate_root` is not set, then this rule will look for a `lib.rs` file (or `main.rs` for rust_binary)
or the single file in `srcs` if `srcs` contains only one file.
2None�
data�List of files used by this rule at compile time and runtime.

If including data at compile time with include_str!() and similar,
prefer `compile_data` over `data`, to prevent the data also being included
in the runfiles.
2[]�
deps�List of other libraries to be linked to this library target.

These can be either other `rust_library` targets or `cc_library` targets if
linking a native library.
2[]q
edition`The rust edition to use for this crate. Defaults to the edition specified in the rust_toolchain.2""�
experimental_use_cc_common_link�Whether to use cc_common.link to link rust binaries. Possible values: [-1, 0, 1]. -1 means use the value of the toolchain.experimental_use_cc_common_link boolean build setting to determine. 0 means do not use cc_common.link (use rustc instead). 1 means use cc_common.link.2-1S
lint_config/Set of lints to apply when building this crate.*
	LintsInfo2None�
malloc�Override the default dependency on `malloc`.

By default, Rust binaries linked with [`cc_common.link`](https://bazel.build/rules/lib/toplevel/cc_common#link)
are linked against `@rules_rust//rust/private/cc:malloc`, which is an empty library
and the resulting binary will use libc's `malloc`. This label must refer to a
`cc_library` rule.
*
CcInfo2//rust/private/cc:mallocJ
platform6Optional platform to transition the static library to.2None�
proc_macro_depsJList of `rust_proc_macro` targets used to help build this library target.
*
	CrateInfo*
CrateGroupInfo2[]�
"require_explicit_unstable_features�Whether to require all unstable features to be explicitly opted in to using `-Zallow-features=...`. Possible values: [-1, 0, 1]. -1 means delegate to the toolchain.require_explicit_unstable_features boolean build setting; 0 means False; 1 means True.2-1�
	rustc_env�Dictionary of additional `"key": "value"` environment variables to set for rustc.

rust_test()/rust_binary() rules can use $(rootpath //package:target) to pass in the
location of a generated file or external tool. Cargo build scripts that wish to
expand locations should use cargo_build_script()'s build_script_env argument instead,
as build scripts are run in a different environment - see cargo_build_script()'s
documentation for more.

2{}�
rustc_env_files�Files containing additional environment variables to set for rustc.

These files should  contain a single variable per line, of format
`NAME=value`, and newlines may be included in a value by ending a
line with a trailing back-slash (`\\`).

The order that these files will be processed is unspecified, so
multiple definitions of a particular variable are discouraged.

Note that the variables here are subject to
[workspace status](https://docs.bazel.build/versions/main/user-manual.html#workspace_status)
stamping should the `stamp` attribute be enabled. Stamp variables
should be wrapped in brackets in order to be resolved. E.g.
`NAME={WORKSPACE_STATUS_VARIABLE}`.
2[]�
rustc_flags�List of compiler flags passed to `rustc`.

These strings are subject to Make variable expansion for predefined
source/output path variables like `$location`, `$execpath`, and
`$rootpath`. This expansion is useful if you wish to pass a generated
file of arguments to rustc: `@$(location //package:target)`.
2[]�
srcs�List of Rust `.rs` source files used to build the library.

If `srcs` contains more than one file, then there must be a file either
named `lib.rs`. Otherwise, `crate_root` must be set to the source file that
is the root of the crate to be passed to rustc to build this crate.
2[]�
stamp�Whether to encode build information into the `Rustc` action. Possible values:

- `stamp = 1`: Always stamp the build information into the `Rustc` action, even in             [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.             This setting should be avoided, since it potentially kills remote caching for the target and             any downstream actions that depend on it.

- `stamp = 0`: Always replace build information by constant values. This gives good build result caching.

- `stamp = -1`: Embedding of build information is controlled by the             [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.

Stamped targets are not rebuilt unless their dependencies change.

For example if a `rust_library` is stamped, and a `rust_binary` depends on that library, the stamped
library won't be rebuilt when we change sources of the `rust_binary`. This is different from how
[`cc_library.linkstamps`](https://docs.bazel.build/versions/main/be/c-cpp.html#cc_library.linkstamp)
behaves.
20�
unstable_rust_features_config�Controls which unstable features are allowed to be used by this target. Setting this to anything other than None requires a nightly toolchain.*
UnstableRustFeaturesInfo2NoneL
version6A version to inject in the cargo environment variable.2"0.0.0"
��,
*
nameA unique name for this target. �
�
aliases�Remap crates to a new name or moniker for linkage to this target

These are other `rust_library` targets and will be presented as the new name given.
	2{}Y
W
allocator_libraries*
AllocatorLibrariesInfo2$//ffi/rs:default_allocator_libraries�
�

alwayslink�If 1, any binary that depends (directly or indirectly) on this library
will link in all the object files even if some contain no symbols referenced by the binary.

This attribute is used by the C++ Starlark API when passing CcInfo providers.
2False�
�
compile_data�List of files used by this rule at compile time.

This attribute can be used to specify any data files that are embedded into
the library, such as via the
[`include_str!`](https://doc.rust-lang.org/std/macro.include_str!.html)
macro.
2[]�
�
crate_features�List of features to enable for this crate.

Features are defined in the code using the `#[cfg(feature = "foo")]`
configuration option. The features listed here will be passed to `rustc`
with `--cfg feature="${feature_name}"` flags.
2[]�
�

crate_name�Crate name to use for this target.

This must be a valid Rust identifier, i.e. it may contain only alphanumeric characters and underscores.
Defaults to the target name, with any hyphens replaced by underscores.
2""�
�

crate_root�The file that will be passed to `rustc` to be used for building this crate.

If `crate_root` is not set, then this rule will look for a `lib.rs` file (or `main.rs` for rust_binary)
or the single file in `srcs` if `srcs` contains only one file.
2None�
�
data�List of files used by this rule at compile time and runtime.

If including data at compile time with include_str!() and similar,
prefer `compile_data` over `data`, to prevent the data also being included
in the runfiles.
2[]�
�
deps�List of other libraries to be linked to this library target.

These can be either other `rust_library` targets or `cc_library` targets if
linking a native library.
2[]s
q
edition`The rust edition to use for this crate. Defaults to the edition specified in the rust_toolchain.2""�
�
experimental_use_cc_common_link�Whether to use cc_common.link to link rust binaries. Possible values: [-1, 0, 1]. -1 means use the value of the toolchain.experimental_use_cc_common_link boolean build setting to determine. 0 means do not use cc_common.link (use rustc instead). 1 means use cc_common.link.2-1U
S
lint_config/Set of lints to apply when building this crate.*
	LintsInfo2None�
�
malloc�Override the default dependency on `malloc`.

By default, Rust binaries linked with [`cc_common.link`](https://bazel.build/rules/lib/toplevel/cc_common#link)
are linked against `@rules_rust//rust/private/cc:malloc`, which is an empty library
and the resulting binary will use libc's `malloc`. This label must refer to a
`cc_library` rule.
*
CcInfo2//rust/private/cc:mallocL
J
platform6Optional platform to transition the static library to.2None�
�
proc_macro_depsJList of `rust_proc_macro` targets used to help build this library target.
*
	CrateInfo*
CrateGroupInfo2[]�
�
"require_explicit_unstable_features�Whether to require all unstable features to be explicitly opted in to using `-Zallow-features=...`. Possible values: [-1, 0, 1]. -1 means delegate to the toolchain.require_explicit_unstable_features boolean build setting; 0 means False; 1 means True.2-1�
�
	rustc_env�Dictionary of additional `"key": "value"` environment variables to set for rustc.

rust_test()/rust_binary() rules can use $(rootpath //package:target) to pass in the
location of a generated file or external tool. Cargo build scripts that wish to
expand locations should use cargo_build_script()'s build_script_env argument instead,
as build scripts are run in a different environment - see cargo_build_script()'s
documentation for more.

2{}�
�
rustc_env_files�Files containing additional environment variables to set for rustc.

These files should  contain a single variable per line, of format
`NAME=value`, and newlines may be included in a value by ending a
line with a trailing back-slash (`\\`).

The order that these files will be processed is unspecified, so
multiple definitions of a particular variable are discouraged.

Note that the variables here are subject to
[workspace status](https://docs.bazel.build/versions/main/user-manual.html#workspace_status)
stamping should the `stamp` attribute be enabled. Stamp variables
should be wrapped in brackets in order to be resolved. E.g.
`NAME={WORKSPACE_STATUS_VARIABLE}`.
2[]�
�
rustc_flags�List of compiler flags passed to `rustc`.

These strings are subject to Make variable expansion for predefined
source/output path variables like `$location`, `$execpath`, and
`$rootpath`. This expansion is useful if you wish to pass a generated
file of arguments to rustc: `@$(location //package:target)`.
2[]�
�
srcs�List of Rust `.rs` source files used to build the library.

If `srcs` contains more than one file, then there must be a file either
named `lib.rs`. Otherwise, `crate_root` must be set to the source file that
is the root of the crate to be passed to rustc to build this crate.
2[]�
�
stamp�Whether to encode build information into the `Rustc` action. Possible values:

- `stamp = 1`: Always stamp the build information into the `Rustc` action, even in             [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.             This setting should be avoided, since it potentially kills remote caching for the target and             any downstream actions that depend on it.

- `stamp = 0`: Always replace build information by constant values. This gives good build result caching.

- `stamp = -1`: Embedding of build information is controlled by the             [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.

Stamped targets are not rebuilt unless their dependencies change.

For example if a `rust_library` is stamped, and a `rust_binary` depends on that library, the stamped
library won't be rebuilt when we change sources of the `rust_binary`. This is different from how
[`cc_library.linkstamps`](https://docs.bazel.build/versions/main/be/c-cpp.html#cc_library.linkstamp)
behaves.
20�
�
unstable_rust_features_config�Controls which unstable features are allowed to be used by this target. Setting this to anything other than None requires a nightly toolchain.*
UnstableRustFeaturesInfo2NoneN
L
version6A version to inject in the cargo environment variable.2"0.0.0"a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.g
//python:defs.bzlrP
 
rules_pythonpythondefs.bzl
PyInfoPyInfo
)/
1�
//rust:defs.bzlr�


rules_rustrustdefs.bzl:
rust_analyzer_aspectrust_analyzer_aspect
6
rust_clippy_aspectrust_clippy_aspect
(
rust_commonrust_common
		8
rust_shared_libraryrust_shared_library


.
rustfmt_aspectrustfmt_aspect

�
//private:pyo3_toolchain.bzlrn
.
rules_rust_pyo3privatepyo3_toolchain.bzl.
PYO3_TOOLCHAINPYO3_TOOLCHAIN
7E
GBazel pyo3 rules�7
.
rules_rust_pyo3privatepyo3_toolchain.bzl�current_pyo3_toolchainIA rule for accessing the `pyo3_toolchain` from the current configuration."�
�
current_pyo3_toolchainIA rule for accessing the `pyo3_toolchain` from the current configuration.*
nameA unique name for this target. "G
current_pyo3_toolchain-@@rules_rust_pyo3//private:pyo3_toolchain.bzl
��,
*
nameA unique name for this target. �)current_rust_pyo3_introspection_toolchainiA rule for accessing the `rust_pyo3_toolchain.pyo3_introspection` library from the current configuration."�
�
)current_rust_pyo3_introspection_toolchainiA rule for accessing the `rust_pyo3_toolchain.pyo3_introspection` library from the current configuration.*
nameA unique name for this target. "Z
)current_rust_pyo3_introspection_toolchain-@@rules_rust_pyo3//private:pyo3_toolchain.bzl
�1�1,
*
nameA unique name for this target. �current_rust_pyo3_toolchain[A rule for accessing the `rust_pyo3_toolchain.pyo3` library from the current configuration."�
�
current_rust_pyo3_toolchain[A rule for accessing the `rust_pyo3_toolchain.pyo3` library from the current configuration.*
nameA unique name for this target. "L
current_rust_pyo3_toolchain-@@rules_rust_pyo3//private:pyo3_toolchain.bzl
�#�#,
*
nameA unique name for this target. �#pyo3_toolchain�Define a toolchain which generates config data for the PyO3 for producing extension modules on any target platform.

Note that this toolchain expects the `pyo3` crate to be built with the following features:
- [`abi3`](https://pyo3.rs/v0.26.0/features.html?highlight=abi3#abi3)
- [`abi3-py3*`](https://pyo3.rs/v0.26.0/features.html?highlight=abi3#the-abi3-pyxy-features) (e.g `abi3-py311`)
- [`extension-module`](https://pyo3.rs/v0.26.0/features.html?highlight=abi3#extension-module)

When using [rules_rust's crate_universe](https://bazelbuild.github.io/rules_rust/crate_universe.html), this data can be plubmed into the target using the following snippet.
```python
annotations = {
    "pyo3-build-config": [
        crate.annotation(
            build_script_data = [
                "@rules_rust_pyo3//:current_pyo3_toolchain",
            ],
            build_script_env = {
                "PYO3_CROSS": "$(PYO3_CROSS)",
                "PYO3_CROSS_LIB_DIR": "$(PYO3_CROSS_LIB_DIR)",
                "PYO3_CROSS_PYTHON_IMPLEMENTATION": "$(PYO3_CROSS_PYTHON_IMPLEMENTATION)",
                "PYO3_CROSS_PYTHON_VERSION": "$(PYO3_CROSS_PYTHON_VERSION)",
                "PYO3_NO_PYTHON": "$(PYO3_NO_PYTHON)",
                "PYO3_PYTHON": "$(PYO3_PYTHON)",
            },
            build_script_toolchains = [
                "@rules_rust_pyo3//:current_pyo3_toolchain",
            ],
        ),
    ],
    "pyo3-ffi": [
        crate.annotation(
            build_script_data = [
                "@rules_rust_pyo3//:current_pyo3_toolchain",
            ],
            build_script_env = {
                "PYO3_CROSS": "$(PYO3_CROSS)",
                "PYO3_CROSS_LIB_DIR": "$(PYO3_CROSS_LIB_DIR)",
                "PYO3_CROSS_PYTHON_IMPLEMENTATION": "$(PYO3_CROSS_PYTHON_IMPLEMENTATION)",
                "PYO3_CROSS_PYTHON_VERSION": "$(PYO3_CROSS_PYTHON_VERSION)",
                "PYO3_NO_PYTHON": "$(PYO3_NO_PYTHON)",
                "PYO3_PYTHON": "$(PYO3_PYTHON)",
            },
            build_script_toolchains = [
                "@rules_rust_pyo3//:current_pyo3_toolchain",
            ],
        ),
    ],
},
```
"�
�
pyo3_toolchain�Define a toolchain which generates config data for the PyO3 for producing extension modules on any target platform.

Note that this toolchain expects the `pyo3` crate to be built with the following features:
- [`abi3`](https://pyo3.rs/v0.26.0/features.html?highlight=abi3#abi3)
- [`abi3-py3*`](https://pyo3.rs/v0.26.0/features.html?highlight=abi3#the-abi3-pyxy-features) (e.g `abi3-py311`)
- [`extension-module`](https://pyo3.rs/v0.26.0/features.html?highlight=abi3#extension-module)

When using [rules_rust's crate_universe](https://bazelbuild.github.io/rules_rust/crate_universe.html), this data can be plubmed into the target using the following snippet.
```python
annotations = {
    "pyo3-build-config": [
        crate.annotation(
            build_script_data = [
                "@rules_rust_pyo3//:current_pyo3_toolchain",
            ],
            build_script_env = {
                "PYO3_CROSS": "$(PYO3_CROSS)",
                "PYO3_CROSS_LIB_DIR": "$(PYO3_CROSS_LIB_DIR)",
                "PYO3_CROSS_PYTHON_IMPLEMENTATION": "$(PYO3_CROSS_PYTHON_IMPLEMENTATION)",
                "PYO3_CROSS_PYTHON_VERSION": "$(PYO3_CROSS_PYTHON_VERSION)",
                "PYO3_NO_PYTHON": "$(PYO3_NO_PYTHON)",
                "PYO3_PYTHON": "$(PYO3_PYTHON)",
            },
            build_script_toolchains = [
                "@rules_rust_pyo3//:current_pyo3_toolchain",
            ],
        ),
    ],
    "pyo3-ffi": [
        crate.annotation(
            build_script_data = [
                "@rules_rust_pyo3//:current_pyo3_toolchain",
            ],
            build_script_env = {
                "PYO3_CROSS": "$(PYO3_CROSS)",
                "PYO3_CROSS_LIB_DIR": "$(PYO3_CROSS_LIB_DIR)",
                "PYO3_CROSS_PYTHON_IMPLEMENTATION": "$(PYO3_CROSS_PYTHON_IMPLEMENTATION)",
                "PYO3_CROSS_PYTHON_VERSION": "$(PYO3_CROSS_PYTHON_VERSION)",
                "PYO3_NO_PYTHON": "$(PYO3_NO_PYTHON)",
                "PYO3_PYTHON": "$(PYO3_PYTHON)",
            },
            build_script_toolchains = [
                "@rules_rust_pyo3//:current_pyo3_toolchain",
            ],
        ),
    ],
},
```
*
nameA unique name for this target. "?
pyo3_toolchain-@@rules_rust_pyo3//private:pyo3_toolchain.bzl
OO,
*
nameA unique name for this target. �rust_pyo3_toolchain�Define a toolchain for PyO3 Rust dependencies which power internal rules.

This toolchain is how the rules know which version of `pyo3` to link against.
"�
�
rust_pyo3_toolchain�Define a toolchain for PyO3 Rust dependencies which power internal rules.

This toolchain is how the rules know which version of `pyo3` to link against.
*
nameA unique name for this target. <
pyo3The PyO3 library. *
	CrateInfo*
CrateGroupInfoX
pyo3_introspectionThe PyO3 introspection library. *
	CrateInfo*
CrateGroupInfo"D
rust_pyo3_toolchain-@@rules_rust_pyo3//private:pyo3_toolchain.bzl
��,
*
nameA unique name for this target. >
<
pyo3The PyO3 library. *
	CrateInfo*
CrateGroupInfoZ
X
pyo3_introspectionThe PyO3 introspection library. *
	CrateInfo*
CrateGroupInfo�
//rules:common_settings.bzlrn
*
bazel_skylibrulescommon_settings.bzl2
BuildSettingInfoBuildSettingInfo
3C
Ek
//rust:defs.bzlrV


rules_rustrustdefs.bzl(
rust_commonrust_common
%0
2M	RUST_PYO3_TOOLCHAIN@@//:rust_toolchain_typej@@//:rust_toolchain_type>	PYO3_TOOLCHAIN@@//:toolchain_typej@@//:toolchain_typePyO3 Toolchains��

rules_rust_pyo3defs.bzl�"pyo3_toolchain�Define a toolchain which generates config data for the PyO3 for producing extension modules on any target platform.

Note that this toolchain expects the `pyo3` crate to be built with the following features:
- [`abi3`](https://pyo3.rs/v0.26.0/features.html?highlight=abi3#abi3)
- [`abi3-py3*`](https://pyo3.rs/v0.26.0/features.html?highlight=abi3#the-abi3-pyxy-features) (e.g `abi3-py311`)
- [`extension-module`](https://pyo3.rs/v0.26.0/features.html?highlight=abi3#extension-module)

When using [rules_rust's crate_universe](https://bazelbuild.github.io/rules_rust/crate_universe.html), this data can be plubmed into the target using the following snippet.
```python
annotations = {
    "pyo3-build-config": [
        crate.annotation(
            build_script_data = [
                "@rules_rust_pyo3//:current_pyo3_toolchain",
            ],
            build_script_env = {
                "PYO3_CROSS": "$(PYO3_CROSS)",
                "PYO3_CROSS_LIB_DIR": "$(PYO3_CROSS_LIB_DIR)",
                "PYO3_CROSS_PYTHON_IMPLEMENTATION": "$(PYO3_CROSS_PYTHON_IMPLEMENTATION)",
                "PYO3_CROSS_PYTHON_VERSION": "$(PYO3_CROSS_PYTHON_VERSION)",
                "PYO3_NO_PYTHON": "$(PYO3_NO_PYTHON)",
                "PYO3_PYTHON": "$(PYO3_PYTHON)",
            },
            build_script_toolchains = [
                "@rules_rust_pyo3//:current_pyo3_toolchain",
            ],
        ),
    ],
    "pyo3-ffi": [
        crate.annotation(
            build_script_data = [
                "@rules_rust_pyo3//:current_pyo3_toolchain",
            ],
            build_script_env = {
                "PYO3_CROSS": "$(PYO3_CROSS)",
                "PYO3_CROSS_LIB_DIR": "$(PYO3_CROSS_LIB_DIR)",
                "PYO3_CROSS_PYTHON_IMPLEMENTATION": "$(PYO3_CROSS_PYTHON_IMPLEMENTATION)",
                "PYO3_CROSS_PYTHON_VERSION": "$(PYO3_CROSS_PYTHON_VERSION)",
                "PYO3_NO_PYTHON": "$(PYO3_NO_PYTHON)",
                "PYO3_PYTHON": "$(PYO3_PYTHON)",
            },
            build_script_toolchains = [
                "@rules_rust_pyo3//:current_pyo3_toolchain",
            ],
        ),
    ],
},
```
"�
�
pyo3_toolchain�Define a toolchain which generates config data for the PyO3 for producing extension modules on any target platform.

Note that this toolchain expects the `pyo3` crate to be built with the following features:
- [`abi3`](https://pyo3.rs/v0.26.0/features.html?highlight=abi3#abi3)
- [`abi3-py3*`](https://pyo3.rs/v0.26.0/features.html?highlight=abi3#the-abi3-pyxy-features) (e.g `abi3-py311`)
- [`extension-module`](https://pyo3.rs/v0.26.0/features.html?highlight=abi3#extension-module)

When using [rules_rust's crate_universe](https://bazelbuild.github.io/rules_rust/crate_universe.html), this data can be plubmed into the target using the following snippet.
```python
annotations = {
    "pyo3-build-config": [
        crate.annotation(
            build_script_data = [
                "@rules_rust_pyo3//:current_pyo3_toolchain",
            ],
            build_script_env = {
                "PYO3_CROSS": "$(PYO3_CROSS)",
                "PYO3_CROSS_LIB_DIR": "$(PYO3_CROSS_LIB_DIR)",
                "PYO3_CROSS_PYTHON_IMPLEMENTATION": "$(PYO3_CROSS_PYTHON_IMPLEMENTATION)",
                "PYO3_CROSS_PYTHON_VERSION": "$(PYO3_CROSS_PYTHON_VERSION)",
                "PYO3_NO_PYTHON": "$(PYO3_NO_PYTHON)",
                "PYO3_PYTHON": "$(PYO3_PYTHON)",
            },
            build_script_toolchains = [
                "@rules_rust_pyo3//:current_pyo3_toolchain",
            ],
        ),
    ],
    "pyo3-ffi": [
        crate.annotation(
            build_script_data = [
                "@rules_rust_pyo3//:current_pyo3_toolchain",
            ],
            build_script_env = {
                "PYO3_CROSS": "$(PYO3_CROSS)",
                "PYO3_CROSS_LIB_DIR": "$(PYO3_CROSS_LIB_DIR)",
                "PYO3_CROSS_PYTHON_IMPLEMENTATION": "$(PYO3_CROSS_PYTHON_IMPLEMENTATION)",
                "PYO3_CROSS_PYTHON_VERSION": "$(PYO3_CROSS_PYTHON_VERSION)",
                "PYO3_NO_PYTHON": "$(PYO3_NO_PYTHON)",
                "PYO3_PYTHON": "$(PYO3_PYTHON)",
            },
            build_script_toolchains = [
                "@rules_rust_pyo3//:current_pyo3_toolchain",
            ],
        ),
    ],
},
```
*
nameA unique name for this target. ".
pyo3_toolchain@@rules_rust_pyo3//:defs.bzl
OO,
*
nameA unique name for this target. �rust_pyo3_toolchain�Define a toolchain for PyO3 Rust dependencies which power internal rules.

This toolchain is how the rules know which version of `pyo3` to link against.
"�
�
rust_pyo3_toolchain�Define a toolchain for PyO3 Rust dependencies which power internal rules.

This toolchain is how the rules know which version of `pyo3` to link against.
*
nameA unique name for this target. <
pyo3The PyO3 library. *
	CrateInfo*
CrateGroupInfoX
pyo3_introspectionThe PyO3 introspection library. *
	CrateInfo*
CrateGroupInfo"3
rust_pyo3_toolchain@@rules_rust_pyo3//:defs.bzl
��,
*
nameA unique name for this target. >
<
pyo3The PyO3 library. *
	CrateInfo*
CrateGroupInfoZ
X
pyo3_introspectionThe PyO3 introspection library. *
	CrateInfo*
CrateGroupInfo�rpyo3_extension�Define a PyO3 python extension module.

This target is consumed just as a `py_library` would be.

[rsl]: https://bazelbuild.github.io/rules_rust/defs.html#rust_shared_library
[pli]: https://bazel.build/reference/be/python#py_binary.imports


Builds a Rust shared library.

This shared library will contain all transitively reachable crates and native objects.
It is meant to be used when producing an artifact that is then consumed by some other build system
(for example to produce a shared library that Python program links against).

This rule provides CcInfo, so it can be used everywhere Bazel expects `rules_cc`.

When building the whole binary in Bazel, use `rust_library` instead.
"�m
�9
pyo3_extension�Define a PyO3 python extension module.

This target is consumed just as a `py_library` would be.

[rsl]: https://bazelbuild.github.io/rules_rust/defs.html#rust_shared_library
[pli]: https://bazel.build/reference/be/python#py_binary.imports


Builds a Rust shared library.

This shared library will contain all transitively reachable crates and native objects.
It is meant to be used when producing an artifact that is then consumed by some other build system
(for example to produce a shared library that Python program links against).

This rule provides CcInfo, so it can be used everywhere Bazel expects `rules_cc`.

When building the whole binary in Bazel, use `rust_library` instead.
*
nameA unique name for this target. �
aliases�Remap crates to a new name or moniker for linkage to this target

These are other `rust_library` targets and will be presented as the new name given.
	2{}W
allocator_libraries*
AllocatorLibrariesInfo2$//ffi/rs:default_allocator_libraries�

alwayslink�If 1, any binary that depends (directly or indirectly) on this library
will link in all the object files even if some contain no symbols referenced by the binary.

This attribute is used by the C++ Starlark API when passing CcInfo providers.
2False�
compile_data�List of files used by this rule at compile time.

This attribute can be used to specify any data files that are embedded into
the library, such as via the
[`include_str!`](https://doc.rust-lang.org/std/macro.include_str!.html)
macro.
2[]�
crate_features�List of features to enable for this crate.

Features are defined in the code using the `#[cfg(feature = "foo")]`
configuration option. The features listed here will be passed to `rustc`
with `--cfg feature="${feature_name}"` flags.
2[]�

crate_name�Crate name to use for this target.

This must be a valid Rust identifier, i.e. it may contain only alphanumeric characters and underscores.
Defaults to the target name, with any hyphens replaced by underscores.
2""�

crate_root�The file that will be passed to `rustc` to be used for building this crate.

If `crate_root` is not set, then this rule will look for a `lib.rs` file (or `main.rs` for rust_binary)
or the single file in `srcs` if `srcs` contains only one file.
2None�
data�List of files used by this rule at compile time and runtime.

If including data at compile time with include_str!() and similar,
prefer `compile_data` over `data`, to prevent the data also being included
in the runfiles.
2[]�
deps�List of other libraries to be linked to this library target.

These can be either other `rust_library` targets or `cc_library` targets if
linking a native library.
2[]q
edition`The rust edition to use for this crate. Defaults to the edition specified in the rust_toolchain.2""�
experimental_use_cc_common_link�Whether to use cc_common.link to link rust binaries. Possible values: [-1, 0, 1]. -1 means use the value of the toolchain.experimental_use_cc_common_link boolean build setting to determine. 0 means do not use cc_common.link (use rustc instead). 1 means use cc_common.link.2-1S
lint_config/Set of lints to apply when building this crate.*
	LintsInfo2None�
malloc�Override the default dependency on `malloc`.

By default, Rust binaries linked with [`cc_common.link`](https://bazel.build/rules/lib/toplevel/cc_common#link)
are linked against `@rules_rust//rust/private/cc:malloc`, which is an empty library
and the resulting binary will use libc's `malloc`. This label must refer to a
`cc_library` rule.
*
CcInfo2//rust/private/cc:mallocJ
platform6Optional platform to transition the static library to.2None�
proc_macro_depsJList of `rust_proc_macro` targets used to help build this library target.
*
	CrateInfo*
CrateGroupInfo2[]�
"require_explicit_unstable_features�Whether to require all unstable features to be explicitly opted in to using `-Zallow-features=...`. Possible values: [-1, 0, 1]. -1 means delegate to the toolchain.require_explicit_unstable_features boolean build setting; 0 means False; 1 means True.2-1�
	rustc_env�Dictionary of additional `"key": "value"` environment variables to set for rustc.

rust_test()/rust_binary() rules can use $(rootpath //package:target) to pass in the
location of a generated file or external tool. Cargo build scripts that wish to
expand locations should use cargo_build_script()'s build_script_env argument instead,
as build scripts are run in a different environment - see cargo_build_script()'s
documentation for more.

2{}�
rustc_env_files�Files containing additional environment variables to set for rustc.

These files should  contain a single variable per line, of format
`NAME=value`, and newlines may be included in a value by ending a
line with a trailing back-slash (`\\`).

The order that these files will be processed is unspecified, so
multiple definitions of a particular variable are discouraged.

Note that the variables here are subject to
[workspace status](https://docs.bazel.build/versions/main/user-manual.html#workspace_status)
stamping should the `stamp` attribute be enabled. Stamp variables
should be wrapped in brackets in order to be resolved. E.g.
`NAME={WORKSPACE_STATUS_VARIABLE}`.
2[]�
rustc_flags�List of compiler flags passed to `rustc`.

These strings are subject to Make variable expansion for predefined
source/output path variables like `$location`, `$execpath`, and
`$rootpath`. This expansion is useful if you wish to pass a generated
file of arguments to rustc: `@$(location //package:target)`.
2[]�
srcs�List of Rust `.rs` source files used to build the library.

If `srcs` contains more than one file, then there must be a file either
named `lib.rs`. Otherwise, `crate_root` must be set to the source file that
is the root of the crate to be passed to rustc to build this crate.
2[]�
stamp�Whether to encode build information into the `Rustc` action. Possible values:

- `stamp = 1`: Always stamp the build information into the `Rustc` action, even in             [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.             This setting should be avoided, since it potentially kills remote caching for the target and             any downstream actions that depend on it.

- `stamp = 0`: Always replace build information by constant values. This gives good build result caching.

- `stamp = -1`: Embedding of build information is controlled by the             [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.

Stamped targets are not rebuilt unless their dependencies change.

For example if a `rust_library` is stamped, and a `rust_binary` depends on that library, the stamped
library won't be rebuilt when we change sources of the `rust_binary`. This is different from how
[`cc_library.linkstamps`](https://docs.bazel.build/versions/main/be/c-cpp.html#cc_library.linkstamp)
behaves.
20�
unstable_rust_features_config�Controls which unstable features are allowed to be used by this target. Setting this to anything other than None requires a nightly toolchain.*
UnstableRustFeaturesInfo2NoneL
version6A version to inject in the cargo environment variable.2"0.0.0"
��,
*
nameA unique name for this target. �
�
aliases�Remap crates to a new name or moniker for linkage to this target

These are other `rust_library` targets and will be presented as the new name given.
	2{}Y
W
allocator_libraries*
AllocatorLibrariesInfo2$//ffi/rs:default_allocator_libraries�
�

alwayslink�If 1, any binary that depends (directly or indirectly) on this library
will link in all the object files even if some contain no symbols referenced by the binary.

This attribute is used by the C++ Starlark API when passing CcInfo providers.
2False�
�
compile_data�List of files used by this rule at compile time.

This attribute can be used to specify any data files that are embedded into
the library, such as via the
[`include_str!`](https://doc.rust-lang.org/std/macro.include_str!.html)
macro.
2[]�
�
crate_features�List of features to enable for this crate.

Features are defined in the code using the `#[cfg(feature = "foo")]`
configuration option. The features listed here will be passed to `rustc`
with `--cfg feature="${feature_name}"` flags.
2[]�
�

crate_name�Crate name to use for this target.

This must be a valid Rust identifier, i.e. it may contain only alphanumeric characters and underscores.
Defaults to the target name, with any hyphens replaced by underscores.
2""�
�

crate_root�The file that will be passed to `rustc` to be used for building this crate.

If `crate_root` is not set, then this rule will look for a `lib.rs` file (or `main.rs` for rust_binary)
or the single file in `srcs` if `srcs` contains only one file.
2None�
�
data�List of files used by this rule at compile time and runtime.

If including data at compile time with include_str!() and similar,
prefer `compile_data` over `data`, to prevent the data also being included
in the runfiles.
2[]�
�
deps�List of other libraries to be linked to this library target.

These can be either other `rust_library` targets or `cc_library` targets if
linking a native library.
2[]s
q
edition`The rust edition to use for this crate. Defaults to the edition specified in the rust_toolchain.2""�
�
experimental_use_cc_common_link�Whether to use cc_common.link to link rust binaries. Possible values: [-1, 0, 1]. -1 means use the value of the toolchain.experimental_use_cc_common_link boolean build setting to determine. 0 means do not use cc_common.link (use rustc instead). 1 means use cc_common.link.2-1U
S
lint_config/Set of lints to apply when building this crate.*
	LintsInfo2None�
�
malloc�Override the default dependency on `malloc`.

By default, Rust binaries linked with [`cc_common.link`](https://bazel.build/rules/lib/toplevel/cc_common#link)
are linked against `@rules_rust//rust/private/cc:malloc`, which is an empty library
and the resulting binary will use libc's `malloc`. This label must refer to a
`cc_library` rule.
*
CcInfo2//rust/private/cc:mallocL
J
platform6Optional platform to transition the static library to.2None�
�
proc_macro_depsJList of `rust_proc_macro` targets used to help build this library target.
*
	CrateInfo*
CrateGroupInfo2[]�
�
"require_explicit_unstable_features�Whether to require all unstable features to be explicitly opted in to using `-Zallow-features=...`. Possible values: [-1, 0, 1]. -1 means delegate to the toolchain.require_explicit_unstable_features boolean build setting; 0 means False; 1 means True.2-1�
�
	rustc_env�Dictionary of additional `"key": "value"` environment variables to set for rustc.

rust_test()/rust_binary() rules can use $(rootpath //package:target) to pass in the
location of a generated file or external tool. Cargo build scripts that wish to
expand locations should use cargo_build_script()'s build_script_env argument instead,
as build scripts are run in a different environment - see cargo_build_script()'s
documentation for more.

2{}�
�
rustc_env_files�Files containing additional environment variables to set for rustc.

These files should  contain a single variable per line, of format
`NAME=value`, and newlines may be included in a value by ending a
line with a trailing back-slash (`\\`).

The order that these files will be processed is unspecified, so
multiple definitions of a particular variable are discouraged.

Note that the variables here are subject to
[workspace status](https://docs.bazel.build/versions/main/user-manual.html#workspace_status)
stamping should the `stamp` attribute be enabled. Stamp variables
should be wrapped in brackets in order to be resolved. E.g.
`NAME={WORKSPACE_STATUS_VARIABLE}`.
2[]�
�
rustc_flags�List of compiler flags passed to `rustc`.

These strings are subject to Make variable expansion for predefined
source/output path variables like `$location`, `$execpath`, and
`$rootpath`. This expansion is useful if you wish to pass a generated
file of arguments to rustc: `@$(location //package:target)`.
2[]�
�
srcs�List of Rust `.rs` source files used to build the library.

If `srcs` contains more than one file, then there must be a file either
named `lib.rs`. Otherwise, `crate_root` must be set to the source file that
is the root of the crate to be passed to rustc to build this crate.
2[]�
�
stamp�Whether to encode build information into the `Rustc` action. Possible values:

- `stamp = 1`: Always stamp the build information into the `Rustc` action, even in             [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.             This setting should be avoided, since it potentially kills remote caching for the target and             any downstream actions that depend on it.

- `stamp = 0`: Always replace build information by constant values. This gives good build result caching.

- `stamp = -1`: Embedding of build information is controlled by the             [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.

Stamped targets are not rebuilt unless their dependencies change.

For example if a `rust_library` is stamped, and a `rust_binary` depends on that library, the stamped
library won't be rebuilt when we change sources of the `rust_binary`. This is different from how
[`cc_library.linkstamps`](https://docs.bazel.build/versions/main/be/c-cpp.html#cc_library.linkstamp)
behaves.
20�
�
unstable_rust_features_config�Controls which unstable features are allowed to be used by this target. Setting this to anything other than None requires a nightly toolchain.*
UnstableRustFeaturesInfo2NoneN
L
version6A version to inject in the cargo environment variable.2"0.0.0"}
//private:pyo3.bzlre
$
rules_rust_pyo3privatepyo3.bzl/
pyo3_extension_pyo3_extension

�
//private:pyo3_toolchain.bzlr�
.
rules_rust_pyo3privatepyo3_toolchain.bzl/
pyo3_toolchain_pyo3_toolchain


9
rust_pyo3_toolchain_rust_pyo3_toolchain

# rules_rust_pyo3
 