�
"
rules_shbzlmodextensions.bzlcsh_configureJQ
A
sh_configure"1
sh_configure!@@rules_sh//bzlmod:extensions.bzl
  u
//sh:posix.bzlra

rules_shsh	posix.bzl6
sh_posix_configuresh_posix_configure
"4
6�i

rules_shshsh.bzl�csh_binaries�.Defines a bundle of binaries usable as build tools in a genrule or a custom rule.

Exposes the bundled tools as make variables of the form
`$(BUNDLE_NAME_BINARY_NAME)`, and exposes a make variable of the form
`$(_BUNDLE_NAME_PATH)` to extend `PATH` with all bundled binaries.

Also exposes the bundled tools and a list of `PATH` items through the Starlark
provider `ShBinariesInfo`.

#### Example

*Defining a Bundle*

Create a binary bundle target as follows:

```bzl
sh_binaries(
    name = "a-bundle",
    srcs = [
        "binary-a",
        "binary-b",
    ],
)
```

*Using a Bundle in a Genrule*

Use the binaries in the bundle in a `genrule` by adding it to the `toolchains`
attribute and use the generated make variables to access the bundled binaries
as follows:

```bzl
genrule(
    name = "a-genrule",
    toolchains = [":a-bundle"],
    cmd = "\n".join([
        "$(A_BUNDLE_BINARY_A) -foo bar",  # Invoke binary-a
        "$(A_BUNDLE_BINARY_B) -baz qux",  # Invoke binary-b
        "PATH=$(_A_BUNDLE_PATH):$$PATH",  # Extend PATH to include both binaries
        "binary-a; binary-b",             # Invoke binary-a and binary-b
    ]),
    outs = [...],
)
```

*Merging Bundles*

Merge existing bundles into other bundles using the `deps` attribute as follows:

```bzl
sh_binaries(
    name = "another-bundle",
    srcs = ["binary-c"],
    deps = [":a-bundle"],
)
```

The make variable prefix will be determined by the `sh_binaries` target that
you depend on. E.g. with the above `another-bundle` target the make variable
prefix will be `ANOTHER_BUNDLE_`:

```bzl
genrule(
    name = "another-genrule",
    toolchains = [":another-bundle"],
    cmd = "\n".join([
        "$(ANOTHER_BUNDLE_BINARY_A) -foo bar", # Invoke binary-a
        "$(ANOTHER_BUNDLE_BINARY_C) -baz qux", # Invoke binary-c
        "PATH=$(_ANOTHER_BUNDLE_PATH):$$PATH", # Extend PATH to include both binaries
        "binary-a; binary-c",                  # Invoke binary-a and binary-c
    ]),
    outs = [...],
)
```

*Using a Bundle in a Custom Rule*

Use the binaries in a bundle in a custom rule by adding an attribute to depend
on the bundle as follows, note that it should use the `cfg = "exec"` parameter,
because these tools will be used as build tools:

```bzl
# defs.bzl
custom_rule = rule(
    _custom_rule_impl,
    attrs = {
        "tools": attr.label(
             cfg = "exec",
        ),
    },
)

# BUILD.bazel
custom_rule(
    name = "custom",
    tools = ":a-bundle",
)
```

Use the `ShBinariesInfo` provider to use the tools in build actions. The
individual tools are exposed in the `executables` field, and the `PATH` list is
exposed in `paths` as follows:

```bzl
load("@rules_sh//sh:sh.bzl", "ShBinariesInfo")

def _custom_rule_impl(ctx):
    tools = ctx.attr.tools[ShBinariesInfo]
    (tools_inputs, tools_manifest) = ctx.resolve_tools(tools = [ctx.attr.tools])

    # Use binary-a in a `run` action.
    ctx.actions.run(
        executable = tools.executables["binary-a"], # Invoke binary-a
        inputs = tools_inputs,
        input_manifests = tools_manifest,
        ...
    )

    # Use binary-a and binary-b in a `run_shell` action.
    ctx.actions.run_shell(
        command = "{binary_a}; {binary_b}".format(
            binary_a = tools.executables["binary-a"].path, # Path to binary-a
            binary_b = tools.executables["binary-b"].path, # Path to binary-b
        ]),
        tools = [
            tools.executables["binary-a"],
            tools.executables["binary-b"],
        ],
        inputs = tools_inputs,
        input_manifests = tools_manifest,
        ...
    )

    # Use binary-a and binary-b in a `run_shell` action with `PATH`.
    ctx.actions.run_shell(
        command = "PATH={path}:$PATH; binary-a; binary-b".format(
            path = ":".join(tools.paths.to_list()),
        ),
        tools = [
            tools.executables["binary-a"],
            tools.executables["binary-b"],
        ],
        inputs = tools_inputs,
        input_manifests = tools_manifest,
        ...
    )
```

*Caveat: Using Binaries that require Runfiles*

Note, support for binaries that require runfiles is limited due to limitations
imposed by Bazel's Starlark API, see [#15486][issue-15486]. In order for these
to work you will need to define the `RUNFILES_DIR` or `RUNFILES_MANIFEST_FILE`
environment variables for the action using tools from the bundle.

(Use `RUNFILES_MANIFEST_FILE` if your operating system and configuration does
not support a runfiles tree and instead only provides a runfiles manifest file,
as is commonly the case on Windows.)

You can achieve this in a `genrule` as follows:

```bzl
genrule(
    name = "runfiles-genrule",
    toolchains = [":a-bundle"],
    cmd = "\n".join([
        # The explicit RUNFILES_DIR/RUNFILES_MANIFEST_FILE is a workaround for
        # https://github.com/bazelbuild/bazel/issues/15486
        "RUNFILES_DIR=$(execpath :a-bundle).runfiles",
        "RUNFILES_MANIFEST_FILE=$(execpath :a-bundle).runfiles_manifest",
        "$(A_BUNDLE_BINARY_A)",
        "$(A_BUNDLE_BINARY_B)",
    ]),
    outs = [...],
)
```

And in a custom rule as follows:

```bzl
def _custom_rule_impl(ctx):
    tools = ctx.attr.tools[ShBinariesInfo]
    (tools_inputs, tools_manifest) = ctx.resolve_tools(tools = [ctx.attr.tools])
    # The explicit RUNFILES_DIR/RUNFILES_MANIFEST_FILE is a workaround for
    # https://github.com/bazelbuild/bazel/issues/15486
    tools_env = {
        "RUNFILES_DIR": ctx.attr.tools[DefaultInfo].files_to_run.runfiles_manifest.dirname,
        "RUNFILES_MANIFEST_FILE": ctx.attr.tools[DefaultInfo].files_to_run.runfiles_manifest.path,
    }

    ctx.actions.run(
        executable = tools.executables["binary-a"],
        env = tools_env, # Pass the environment into the action.
        inputs = tools_inputs,
        input_manifests = tools_manifest,
        ...
    )
```

[issue-15486]: https://github.com/bazelbuild/bazel/issues/15486
"�4
�1
sh_binaries�.Defines a bundle of binaries usable as build tools in a genrule or a custom rule.

Exposes the bundled tools as make variables of the form
`$(BUNDLE_NAME_BINARY_NAME)`, and exposes a make variable of the form
`$(_BUNDLE_NAME_PATH)` to extend `PATH` with all bundled binaries.

Also exposes the bundled tools and a list of `PATH` items through the Starlark
provider `ShBinariesInfo`.

#### Example

*Defining a Bundle*

Create a binary bundle target as follows:

```bzl
sh_binaries(
    name = "a-bundle",
    srcs = [
        "binary-a",
        "binary-b",
    ],
)
```

*Using a Bundle in a Genrule*

Use the binaries in the bundle in a `genrule` by adding it to the `toolchains`
attribute and use the generated make variables to access the bundled binaries
as follows:

```bzl
genrule(
    name = "a-genrule",
    toolchains = [":a-bundle"],
    cmd = "\n".join([
        "$(A_BUNDLE_BINARY_A) -foo bar",  # Invoke binary-a
        "$(A_BUNDLE_BINARY_B) -baz qux",  # Invoke binary-b
        "PATH=$(_A_BUNDLE_PATH):$$PATH",  # Extend PATH to include both binaries
        "binary-a; binary-b",             # Invoke binary-a and binary-b
    ]),
    outs = [...],
)
```

*Merging Bundles*

Merge existing bundles into other bundles using the `deps` attribute as follows:

```bzl
sh_binaries(
    name = "another-bundle",
    srcs = ["binary-c"],
    deps = [":a-bundle"],
)
```

The make variable prefix will be determined by the `sh_binaries` target that
you depend on. E.g. with the above `another-bundle` target the make variable
prefix will be `ANOTHER_BUNDLE_`:

```bzl
genrule(
    name = "another-genrule",
    toolchains = [":another-bundle"],
    cmd = "\n".join([
        "$(ANOTHER_BUNDLE_BINARY_A) -foo bar", # Invoke binary-a
        "$(ANOTHER_BUNDLE_BINARY_C) -baz qux", # Invoke binary-c
        "PATH=$(_ANOTHER_BUNDLE_PATH):$$PATH", # Extend PATH to include both binaries
        "binary-a; binary-c",                  # Invoke binary-a and binary-c
    ]),
    outs = [...],
)
```

*Using a Bundle in a Custom Rule*

Use the binaries in a bundle in a custom rule by adding an attribute to depend
on the bundle as follows, note that it should use the `cfg = "exec"` parameter,
because these tools will be used as build tools:

```bzl
# defs.bzl
custom_rule = rule(
    _custom_rule_impl,
    attrs = {
        "tools": attr.label(
             cfg = "exec",
        ),
    },
)

# BUILD.bazel
custom_rule(
    name = "custom",
    tools = ":a-bundle",
)
```

Use the `ShBinariesInfo` provider to use the tools in build actions. The
individual tools are exposed in the `executables` field, and the `PATH` list is
exposed in `paths` as follows:

```bzl
load("@rules_sh//sh:sh.bzl", "ShBinariesInfo")

def _custom_rule_impl(ctx):
    tools = ctx.attr.tools[ShBinariesInfo]
    (tools_inputs, tools_manifest) = ctx.resolve_tools(tools = [ctx.attr.tools])

    # Use binary-a in a `run` action.
    ctx.actions.run(
        executable = tools.executables["binary-a"], # Invoke binary-a
        inputs = tools_inputs,
        input_manifests = tools_manifest,
        ...
    )

    # Use binary-a and binary-b in a `run_shell` action.
    ctx.actions.run_shell(
        command = "{binary_a}; {binary_b}".format(
            binary_a = tools.executables["binary-a"].path, # Path to binary-a
            binary_b = tools.executables["binary-b"].path, # Path to binary-b
        ]),
        tools = [
            tools.executables["binary-a"],
            tools.executables["binary-b"],
        ],
        inputs = tools_inputs,
        input_manifests = tools_manifest,
        ...
    )

    # Use binary-a and binary-b in a `run_shell` action with `PATH`.
    ctx.actions.run_shell(
        command = "PATH={path}:$PATH; binary-a; binary-b".format(
            path = ":".join(tools.paths.to_list()),
        ),
        tools = [
            tools.executables["binary-a"],
            tools.executables["binary-b"],
        ],
        inputs = tools_inputs,
        input_manifests = tools_manifest,
        ...
    )
```

*Caveat: Using Binaries that require Runfiles*

Note, support for binaries that require runfiles is limited due to limitations
imposed by Bazel's Starlark API, see [#15486][issue-15486]. In order for these
to work you will need to define the `RUNFILES_DIR` or `RUNFILES_MANIFEST_FILE`
environment variables for the action using tools from the bundle.

(Use `RUNFILES_MANIFEST_FILE` if your operating system and configuration does
not support a runfiles tree and instead only provides a runfiles manifest file,
as is commonly the case on Windows.)

You can achieve this in a `genrule` as follows:

```bzl
genrule(
    name = "runfiles-genrule",
    toolchains = [":a-bundle"],
    cmd = "\n".join([
        # The explicit RUNFILES_DIR/RUNFILES_MANIFEST_FILE is a workaround for
        # https://github.com/bazelbuild/bazel/issues/15486
        "RUNFILES_DIR=$(execpath :a-bundle).runfiles",
        "RUNFILES_MANIFEST_FILE=$(execpath :a-bundle).runfiles_manifest",
        "$(A_BUNDLE_BINARY_A)",
        "$(A_BUNDLE_BINARY_B)",
    ]),
    outs = [...],
)
```

And in a custom rule as follows:

```bzl
def _custom_rule_impl(ctx):
    tools = ctx.attr.tools[ShBinariesInfo]
    (tools_inputs, tools_manifest) = ctx.resolve_tools(tools = [ctx.attr.tools])
    # The explicit RUNFILES_DIR/RUNFILES_MANIFEST_FILE is a workaround for
    # https://github.com/bazelbuild/bazel/issues/15486
    tools_env = {
        "RUNFILES_DIR": ctx.attr.tools[DefaultInfo].files_to_run.runfiles_manifest.dirname,
        "RUNFILES_MANIFEST_FILE": ctx.attr.tools[DefaultInfo].files_to_run.runfiles_manifest.path,
    }

    ctx.actions.run(
        executable = tools.executables["binary-a"],
        env = tools_env, # Pass the environment into the action.
        inputs = tools_inputs,
        input_manifests = tools_manifest,
        ...
    )
```

[issue-15486]: https://github.com/bazelbuild/bazel/issues/15486
*
nameA unique name for this target. T
dataFAdditional runtime dependencies needed by any of the bundled binaries.2[]�
deps�Existing binary bundles to merge into this bundle. In case of collision, later deps take precedence over earlier ones, and srcs take precedence over deps.2[]7
srcs)The executables to include in the bundle.2[]"$
sh_binaries@@rules_sh//sh:sh.bzl
��,
*
nameA unique name for this target. V
T
dataFAdditional runtime dependencies needed by any of the bundled binaries.2[]�
�
deps�Existing binary bundles to merge into this bundle. In case of collision, later deps take precedence over earlier ones, and srcs take precedence over deps.2[]9
7
srcs)The executables to include in the bundle.2[]�ShBinariesInfo(The description of a sh_binaries target.2�
�
ShBinariesInfo(The description of a sh_binaries target.L
executables=dict of File, The executables included in the bundle by name.Q
pathsHdepset of string, The directories under which the binaries can be found."'
ShBinariesInfo@@rules_sh//sh:sh.bzl
N
L
executables=dict of File, The executables included in the bundle by name.S
Q
pathsHdepset of string, The directories under which the binaries can be found.a
//lib:dicts.bzlrL

bazel_skyliblib	dicts.bzl
dictsdicts
',
.a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.w
//sh/private:defs.bzlr\
 
rules_sh
sh/privatedefs.bzl*
ConstantInfoConstantInfo
)5
7�
 
rules_sh
sh/privatedefs.bzl�bool_constant"�

bool_constant*
nameA unique name for this target. 
value2False"0
bool_constant@@rules_sh//sh/private:defs.bzl
,
*
nameA unique name for this target. 

value2False�ConstantInfo2�
X
ConstantInfo
value(Undocumented)"/
ConstantInfo@@rules_sh//sh/private:defs.bzl


value(Undocumented)�

rules_shsh
import.bzl�create_shim�Create a binary shim for the given target.

Creates a copy of the [shim binary][shim-binary] named `<name>.exe` with a
neighboring `<name>.shim` file that points to the given target.

[shim-binary]: https://github.com/ScoopInstaller/Shim

#### Example

This can be used inside a repository rule run on Windows to generate a shim
of an external executable and import it into an `sh_binaries` target.

```bzl
powershell = repository_ctx.which("powershell")
if powershell != None:
    create_shim(
        repository_ctx,
        name = "powershell",
        target = powershell,
    )

repository_ctx.file(
    "BUILD.bazel",
    "\n".join([
        "sh_binaries(",
        "    name = 'tools',",
        "    srcs = ['powershell.exe'],",
        "    data = ['powershell.shim'],",
        ")",
    ]),
)
```
*�	
�	
create_shim
repository_ctx (~
namerstring or path, The name of the newly created shim, without the .exe suffix, relative to the repository directory. (E
target7string or path, Absolute path to the target executable. (l
shim_exe1string; Label; or path, The original shim binary.+Label("@@rules_sh_shim_exe//file:shim.exe")(�Create a binary shim for the given target.

Creates a copy of the [shim binary][shim-binary] named `<name>.exe` with a
neighboring `<name>.shim` file that points to the given target.

[shim-binary]: https://github.com/ScoopInstaller/Shim

#### Example

This can be used inside a repository rule run on Windows to generate a shim
of an external executable and import it into an `sh_binaries` target.

```bzl
powershell = repository_ctx.which("powershell")
if powershell != None:
    create_shim(
        repository_ctx,
        name = "powershell",
        target = powershell,
    )

repository_ctx.file(
    "BUILD.bazel",
    "\n".join([
        "sh_binaries(",
        "    name = 'tools',",
        "    srcs = ['powershell.exe'],",
        "    data = ['powershell.shim'],",
        ")",
    ]),
)
```
2(
create_shim@@rules_sh//sh:import.bzl
�

rules_shsh	posix.bzl�
sh_posix_make_variables�
Provides POSIX toolchain commands as custom make variables.

Make variables:
  Provides a make variable of the form `POSIX_<COMMAND>` for each available
  command, where `<COMMAND>` is the name of the command in upper case.

Use `posix.MAKE_VARIABLES` instead of instantiating this rule yourself.

Example:
  >>> genrule(
          name = "use-grep",
          srcs = [":some-file"],
          outs = ["grep-out"],
          cmd = "$(POSIX_GREP) search $(execpath :some-file) > $(OUTS)",
          toolchains = [posix.MAKE_VARIABLES],
      )
"�
�
sh_posix_make_variables�
Provides POSIX toolchain commands as custom make variables.

Make variables:
  Provides a make variable of the form `POSIX_<COMMAND>` for each available
  command, where `<COMMAND>` is the name of the command in upper case.

Use `posix.MAKE_VARIABLES` instead of instantiating this rule yourself.

Example:
  >>> genrule(
          name = "use-grep",
          srcs = [":some-file"],
          outs = ["grep-out"],
          cmd = "$(POSIX_GREP) search $(execpath :some-file) > $(OUTS)",
          toolchains = [posix.MAKE_VARIABLES],
      )
*
nameA unique name for this target. "3
sh_posix_make_variables@@rules_sh//sh:posix.bzl
��,
*
nameA unique name for this target. �sh_posix_toolchain�
A toolchain capturing standard Unix shell commands.

Provides:
  commands: Dict of String, an item per command holding the path to the executable or None.
  paths: List of String, deduplicated bindir paths. Suitable for generating `$PATH`.

Use `sh_posix_configure` to create an instance of this toolchain.
See `sh_posix_make_variables` on how to use this toolchain in genrules.
"�
�
sh_posix_toolchain�
A toolchain capturing standard Unix shell commands.

Provides:
  commands: Dict of String, an item per command holding the path to the executable or None.
  paths: List of String, deduplicated bindir paths. Suitable for generating `$PATH`.

Use `sh_posix_configure` to create an instance of this toolchain.
See `sh_posix_make_variables` on how to use this toolchain in genrules.
*
nameA unique name for this target. B
cmds6dict where keys are command names and values are paths
 ".
sh_posix_toolchain@@rules_sh//sh:posix.bzl
��,
*
nameA unique name for this target. D
B
cmds6dict where keys are command names and values are paths
 �sh_posix_configure�Autodetect local Unix commands.

Scans the environment (`$PATH`) for standard shell commands, generates a
corresponding POSIX toolchain and registers the toolchain.

You can override the autodetection for individual commands by setting
environment variables of the form `POSIX_<COMMAND>`. E.g.
`POSIX_MAKE=/usr/bin/gmake` will override the make command.*�
�
sh_posix_configure
name"local_posix_config"(
registerTrue(�Autodetect local Unix commands.

Scans the environment (`$PATH`) for standard shell commands, generates a
corresponding POSIX toolchain and registers the toolchain.

You can override the autodetection for individual commands by setting
environment variables of the form `POSIX_<COMMAND>`. E.g.
`POSIX_MAKE=/usr/bin/gmake` will override the make command.2.
sh_posix_configure@@rules_sh//sh:posix.bzl
��2_sh_posix_configa
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths

'
,


.�
 //tools/cpp:lib_cc_configure.bzlrl
.
bazel_tools	tools/cpplib_cc_configure.bzl,
get_cpu_valueget_cpu_value
7D
F\	MAKE_VARIABLES"@rules_sh//sh/posix:make_variablesj$"@rules_sh//sh/posix:make_variables\	TOOLCHAIN_TYPE"@rules_sh//sh/posix:toolchain_typej$"@rules_sh//sh/posix:toolchain_type�Unix shell commands toolchain support.

Defines a toolchain capturing common Unix shell commands as defined by IEEE
1003.1-2008 (POSIX), see `sh_posix_toolchain`, and `sh_posix_configure` to scan
the local environment for shell commands. The list of known commands is
available in `posix.commands`.

�
 
rules_shshrepositories.bzl�rules_sh_dependencies'Load repositories required by rules_sh.*�
z
rules_sh_dependencies'Load repositories required by rules_sh.28
rules_sh_dependencies@@rules_sh//sh:repositories.bzl
�
 //tools/build_defs/repo:http.bzlr�
.
bazel_toolstools/build_defs/repohttp.bzl*
http_archivehttp_archive
7C$
	http_file	http_file
GP
R�
!//tools/build_defs/repo:utils.bzlr]
/
bazel_toolstools/build_defs/repo	utils.bzl
maybemaybe
8=
? 