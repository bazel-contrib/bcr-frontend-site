�
"
rules_shbzlmodextensions.bzl�sh_configure�
Module extension that sets up `rules_sh` toolchains.

This is essentially a wrapper over `@rules_sh//sh:posix.bzl#sh_posix_configure`
for use with bzlmod.
J�

�
sh_configure�
Module extension that sets up `rules_sh` toolchains.

This is essentially a wrapper over `@rules_sh//sh:posix.bzl#sh_posix_configure`
for use with bzlmod.
�
local_posix_configX
Tag class with options for the `@local_posix_config` repo that this extension
creates.
�
enable�
Whether to create and register the `@local_posix_config//:local_posix_toolchain`
toolchain.

In the event that there are multiple instances of this tag that contradict, the
first tag's value (where modules are ordered by BFS from the root module) will
be used.
2True"1
sh_configure!@@rules_sh//bzlmod:extensions.bzl
J J �
�
local_posix_configX
Tag class with options for the `@local_posix_config` repo that this extension
creates.
�
enable�
Whether to create and register the `@local_posix_config//:local_posix_toolchain`
toolchain.

In the event that there are multiple instances of this tag that contradict, the
first tag's value (where modules are ordered by BFS from the root module) will
be used.
2True�
�
enable�
Whether to create and register the `@local_posix_config//:local_posix_toolchain`
toolchain.

In the event that there are multiple instances of this tag that contradict, the
first tag's value (where modules are ordered by BFS from the root module) will
be used.
2True�
 //tools/build_defs/repo:http.bzlrj
.
bazel_toolstools/build_defs/repohttp.bzl*
http_archivehttp_archive
7C
Eu
//sh:posix.bzlra

rules_shsh	posix.bzl6
sh_posix_configuresh_posix_configure
"4
6�k

rules_shshsh.bzl�csh_binaries�.Defines a bundle of binaries usable as build tools in a genrule or a custom rule.

Exposes the bundled tools as make variables of the form
`$(BUNDLE_NAME_BINARY_NAME)`, and exposes a make variable of the form
`$(_BUNDLE_NAME_PATH)` to extend `PATH` with all bundled binaries.

Also exposes the bundled tools and a list of `PATH` items through the Starlark
provider `ShBinariesInfo`.

#### Example

*Defining a Bundle*

Create a binary bundle target as follows:

```bzl
sh_binaries(
    name = "a-bundle",
    srcs = [
        "binary-a",
        "binary-b",
    ],
)
```

*Using a Bundle in a Genrule*

Use the binaries in the bundle in a `genrule` by adding it to the `toolchains`
attribute and use the generated make variables to access the bundled binaries
as follows:

```bzl
genrule(
    name = "a-genrule",
    toolchains = [":a-bundle"],
    cmd = "\n".join([
        "$(A_BUNDLE_BINARY_A) -foo bar",  # Invoke binary-a
        "$(A_BUNDLE_BINARY_B) -baz qux",  # Invoke binary-b
        "PATH=$(_A_BUNDLE_PATH):$$PATH",  # Extend PATH to include both binaries
        "binary-a; binary-b",             # Invoke binary-a and binary-b
    ]),
    outs = [...],
)
```

*Merging Bundles*

Merge existing bundles into other bundles using the `deps` attribute as follows:

```bzl
sh_binaries(
    name = "another-bundle",
    srcs = ["binary-c"],
    deps = [":a-bundle"],
)
```

The make variable prefix will be determined by the `sh_binaries` target that
you depend on. E.g. with the above `another-bundle` target the make variable
prefix will be `ANOTHER_BUNDLE_`:

```bzl
genrule(
    name = "another-genrule",
    toolchains = [":another-bundle"],
    cmd = "\n".join([
        "$(ANOTHER_BUNDLE_BINARY_A) -foo bar", # Invoke binary-a
        "$(ANOTHER_BUNDLE_BINARY_C) -baz qux", # Invoke binary-c
        "PATH=$(_ANOTHER_BUNDLE_PATH):$$PATH", # Extend PATH to include both binaries
        "binary-a; binary-c",                  # Invoke binary-a and binary-c
    ]),
    outs = [...],
)
```

*Using a Bundle in a Custom Rule*

Use the binaries in a bundle in a custom rule by adding an attribute to depend
on the bundle as follows, note that it should use the `cfg = "exec"` parameter,
because these tools will be used as build tools:

```bzl
# defs.bzl
custom_rule = rule(
    _custom_rule_impl,
    attrs = {
        "tools": attr.label(
             cfg = "exec",
        ),
    },
)

# BUILD.bazel
custom_rule(
    name = "custom",
    tools = ":a-bundle",
)
```

Use the `ShBinariesInfo` provider to use the tools in build actions. The
individual tools are exposed in the `executables` field, and the `PATH` list is
exposed in `paths` as follows:

```bzl
load("@rules_sh//sh:sh.bzl", "ShBinariesInfo")

def _custom_rule_impl(ctx):
    tools = ctx.attr.tools[ShBinariesInfo]
    (tools_inputs, tools_manifest) = ctx.resolve_tools(tools = [ctx.attr.tools])

    # Use binary-a in a `run` action.
    ctx.actions.run(
        executable = tools.executables["binary-a"], # Invoke binary-a
        inputs = tools_inputs,
        input_manifests = tools_manifest,
        ...
    )

    # Use binary-a and binary-b in a `run_shell` action.
    ctx.actions.run_shell(
        command = "{binary_a}; {binary_b}".format(
            binary_a = tools.executables["binary-a"].path, # Path to binary-a
            binary_b = tools.executables["binary-b"].path, # Path to binary-b
        ]),
        tools = [
            tools.executables["binary-a"],
            tools.executables["binary-b"],
        ],
        inputs = tools_inputs,
        input_manifests = tools_manifest,
        ...
    )

    # Use binary-a and binary-b in a `run_shell` action with `PATH`.
    ctx.actions.run_shell(
        command = "PATH={path}:$PATH; binary-a; binary-b".format(
            path = ":".join(tools.paths.to_list()),
        ),
        tools = [
            tools.executables["binary-a"],
            tools.executables["binary-b"],
        ],
        inputs = tools_inputs,
        input_manifests = tools_manifest,
        ...
    )
```

*Caveat: Using Binaries that require Runfiles*

Note, support for binaries that require runfiles is limited due to limitations
imposed by Bazel's Starlark API, see [#15486][issue-15486]. In order for these
to work you will need to define the `RUNFILES_DIR` or `RUNFILES_MANIFEST_FILE`
environment variables for the action using tools from the bundle.

(Use `RUNFILES_MANIFEST_FILE` if your operating system and configuration does
not support a runfiles tree and instead only provides a runfiles manifest file,
as is commonly the case on Windows.)

You can achieve this in a `genrule` as follows:

```bzl
genrule(
    name = "runfiles-genrule",
    toolchains = [":a-bundle"],
    cmd = "\n".join([
        # The explicit RUNFILES_DIR/RUNFILES_MANIFEST_FILE is a workaround for
        # https://github.com/bazelbuild/bazel/issues/15486
        "RUNFILES_DIR=$(execpath :a-bundle).runfiles",
        "RUNFILES_MANIFEST_FILE=$(execpath :a-bundle).runfiles_manifest",
        "$(A_BUNDLE_BINARY_A)",
        "$(A_BUNDLE_BINARY_B)",
    ]),
    outs = [...],
)
```

And in a custom rule as follows:

```bzl
def _custom_rule_impl(ctx):
    tools = ctx.attr.tools[ShBinariesInfo]
    (tools_inputs, tools_manifest) = ctx.resolve_tools(tools = [ctx.attr.tools])
    # The explicit RUNFILES_DIR/RUNFILES_MANIFEST_FILE is a workaround for
    # https://github.com/bazelbuild/bazel/issues/15486
    tools_env = {
        "RUNFILES_DIR": ctx.attr.tools[DefaultInfo].files_to_run.runfiles_manifest.dirname,
        "RUNFILES_MANIFEST_FILE": ctx.attr.tools[DefaultInfo].files_to_run.runfiles_manifest.path,
    }

    ctx.actions.run(
        executable = tools.executables["binary-a"],
        env = tools_env, # Pass the environment into the action.
        inputs = tools_inputs,
        input_manifests = tools_manifest,
        ...
    )
```

[issue-15486]: https://github.com/bazelbuild/bazel/issues/15486
"�4
�1
sh_binaries�.Defines a bundle of binaries usable as build tools in a genrule or a custom rule.

Exposes the bundled tools as make variables of the form
`$(BUNDLE_NAME_BINARY_NAME)`, and exposes a make variable of the form
`$(_BUNDLE_NAME_PATH)` to extend `PATH` with all bundled binaries.

Also exposes the bundled tools and a list of `PATH` items through the Starlark
provider `ShBinariesInfo`.

#### Example

*Defining a Bundle*

Create a binary bundle target as follows:

```bzl
sh_binaries(
    name = "a-bundle",
    srcs = [
        "binary-a",
        "binary-b",
    ],
)
```

*Using a Bundle in a Genrule*

Use the binaries in the bundle in a `genrule` by adding it to the `toolchains`
attribute and use the generated make variables to access the bundled binaries
as follows:

```bzl
genrule(
    name = "a-genrule",
    toolchains = [":a-bundle"],
    cmd = "\n".join([
        "$(A_BUNDLE_BINARY_A) -foo bar",  # Invoke binary-a
        "$(A_BUNDLE_BINARY_B) -baz qux",  # Invoke binary-b
        "PATH=$(_A_BUNDLE_PATH):$$PATH",  # Extend PATH to include both binaries
        "binary-a; binary-b",             # Invoke binary-a and binary-b
    ]),
    outs = [...],
)
```

*Merging Bundles*

Merge existing bundles into other bundles using the `deps` attribute as follows:

```bzl
sh_binaries(
    name = "another-bundle",
    srcs = ["binary-c"],
    deps = [":a-bundle"],
)
```

The make variable prefix will be determined by the `sh_binaries` target that
you depend on. E.g. with the above `another-bundle` target the make variable
prefix will be `ANOTHER_BUNDLE_`:

```bzl
genrule(
    name = "another-genrule",
    toolchains = [":another-bundle"],
    cmd = "\n".join([
        "$(ANOTHER_BUNDLE_BINARY_A) -foo bar", # Invoke binary-a
        "$(ANOTHER_BUNDLE_BINARY_C) -baz qux", # Invoke binary-c
        "PATH=$(_ANOTHER_BUNDLE_PATH):$$PATH", # Extend PATH to include both binaries
        "binary-a; binary-c",                  # Invoke binary-a and binary-c
    ]),
    outs = [...],
)
```

*Using a Bundle in a Custom Rule*

Use the binaries in a bundle in a custom rule by adding an attribute to depend
on the bundle as follows, note that it should use the `cfg = "exec"` parameter,
because these tools will be used as build tools:

```bzl
# defs.bzl
custom_rule = rule(
    _custom_rule_impl,
    attrs = {
        "tools": attr.label(
             cfg = "exec",
        ),
    },
)

# BUILD.bazel
custom_rule(
    name = "custom",
    tools = ":a-bundle",
)
```

Use the `ShBinariesInfo` provider to use the tools in build actions. The
individual tools are exposed in the `executables` field, and the `PATH` list is
exposed in `paths` as follows:

```bzl
load("@rules_sh//sh:sh.bzl", "ShBinariesInfo")

def _custom_rule_impl(ctx):
    tools = ctx.attr.tools[ShBinariesInfo]
    (tools_inputs, tools_manifest) = ctx.resolve_tools(tools = [ctx.attr.tools])

    # Use binary-a in a `run` action.
    ctx.actions.run(
        executable = tools.executables["binary-a"], # Invoke binary-a
        inputs = tools_inputs,
        input_manifests = tools_manifest,
        ...
    )

    # Use binary-a and binary-b in a `run_shell` action.
    ctx.actions.run_shell(
        command = "{binary_a}; {binary_b}".format(
            binary_a = tools.executables["binary-a"].path, # Path to binary-a
            binary_b = tools.executables["binary-b"].path, # Path to binary-b
        ]),
        tools = [
            tools.executables["binary-a"],
            tools.executables["binary-b"],
        ],
        inputs = tools_inputs,
        input_manifests = tools_manifest,
        ...
    )

    # Use binary-a and binary-b in a `run_shell` action with `PATH`.
    ctx.actions.run_shell(
        command = "PATH={path}:$PATH; binary-a; binary-b".format(
            path = ":".join(tools.paths.to_list()),
        ),
        tools = [
            tools.executables["binary-a"],
            tools.executables["binary-b"],
        ],
        inputs = tools_inputs,
        input_manifests = tools_manifest,
        ...
    )
```

*Caveat: Using Binaries that require Runfiles*

Note, support for binaries that require runfiles is limited due to limitations
imposed by Bazel's Starlark API, see [#15486][issue-15486]. In order for these
to work you will need to define the `RUNFILES_DIR` or `RUNFILES_MANIFEST_FILE`
environment variables for the action using tools from the bundle.

(Use `RUNFILES_MANIFEST_FILE` if your operating system and configuration does
not support a runfiles tree and instead only provides a runfiles manifest file,
as is commonly the case on Windows.)

You can achieve this in a `genrule` as follows:

```bzl
genrule(
    name = "runfiles-genrule",
    toolchains = [":a-bundle"],
    cmd = "\n".join([
        # The explicit RUNFILES_DIR/RUNFILES_MANIFEST_FILE is a workaround for
        # https://github.com/bazelbuild/bazel/issues/15486
        "RUNFILES_DIR=$(execpath :a-bundle).runfiles",
        "RUNFILES_MANIFEST_FILE=$(execpath :a-bundle).runfiles_manifest",
        "$(A_BUNDLE_BINARY_A)",
        "$(A_BUNDLE_BINARY_B)",
    ]),
    outs = [...],
)
```

And in a custom rule as follows:

```bzl
def _custom_rule_impl(ctx):
    tools = ctx.attr.tools[ShBinariesInfo]
    (tools_inputs, tools_manifest) = ctx.resolve_tools(tools = [ctx.attr.tools])
    # The explicit RUNFILES_DIR/RUNFILES_MANIFEST_FILE is a workaround for
    # https://github.com/bazelbuild/bazel/issues/15486
    tools_env = {
        "RUNFILES_DIR": ctx.attr.tools[DefaultInfo].files_to_run.runfiles_manifest.dirname,
        "RUNFILES_MANIFEST_FILE": ctx.attr.tools[DefaultInfo].files_to_run.runfiles_manifest.path,
    }

    ctx.actions.run(
        executable = tools.executables["binary-a"],
        env = tools_env, # Pass the environment into the action.
        inputs = tools_inputs,
        input_manifests = tools_manifest,
        ...
    )
```

[issue-15486]: https://github.com/bazelbuild/bazel/issues/15486
*
nameA unique name for this target. T
dataFAdditional runtime dependencies needed by any of the bundled binaries.2[]�
deps�Existing binary bundles to merge into this bundle. In case of collision, later deps take precedence over earlier ones, and srcs take precedence over deps.2[]7
srcs)The executables to include in the bundle.2[]"$
sh_binaries@@rules_sh//sh:sh.bzl
ww,
*
nameA unique name for this target. V
T
dataFAdditional runtime dependencies needed by any of the bundled binaries.2[]�
�
deps�Existing binary bundles to merge into this bundle. In case of collision, later deps take precedence over earlier ones, and srcs take precedence over deps.2[]9
7
srcs)The executables to include in the bundle.2[]�ShBinariesInfo(The description of a sh_binaries target.2�
�
ShBinariesInfo(The description of a sh_binaries target.L
executables=dict of File, The executables included in the bundle by name.Q
pathsHdepset of string, The directories under which the binaries can be found."'
ShBinariesInfo@@rules_sh//sh:sh.bzl


N
L
executables=dict of File, The executables included in the bundle by name.S
Q
pathsHdepset of string, The directories under which the binaries can be found.a
//lib:dicts.bzlrL

bazel_skyliblib	dicts.bzl
dictsdicts
',
.a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.�
//sh/private:defs.bzlr�
 
rules_sh
sh/privatedefs.bzl*
ConstantInfoConstantInfo
T
!mk_default_info_with_files_to_run!mk_default_info_with_files_to_run
'D
mk_template_variable_infomk_template_variable_info

�X
/
rules_shsh/experimentalposix_hermetic.bzl�Rsh_posix_hermetic_toolchain�'Defines a POSIX toolchain based on an sh_binaries bundle.

Provides:
  sh_binaries_info: ShBinariesInfo, for use in custom rules, see `sh_binaries`.
  tool: Target, the sh_binaries target for use in custom rules that requires runfiles, see `sh_binaries`.
  commands: Dict of String, an item per command holding the path to the executable or None. Provided for backwards compatibility with `sh_posix_toolchain`.
  paths: List of String, deduplicated bindir paths. Suitable for generating `$PATH`. Provided for backwards compatibility with `sh_posix_toolchain`.

#### Example

*Using the toolchain in a genrule*

You need to add a dependency on the `@rules_sh//sh/posix:make_variables` target
to the `toolchains` attribute to import the toolchain into a `genrule`. You can
then use specific tools through make-variables of the form `POSIX_<TOOL>`, or
by extending the `PATH` variable with `$(_POSIX_PATH)`. For example:

```bzl
genrule(
    name = "a-genrule",
    toolchains = ["@rules_sh//sh/posix:make_variables"],
    cmd = "\n".join([
        "FILE=$(execpath :some-input-file.bzl)",
        "$(POSIX_GREP) some-pattern $$FILE > $(OUTS)",
        "PATH=$(_POSIX_PATH)",
        "grep some-pattern $$FILE >> $(OUTS)",
    ]),
    srcs = [":some-input-file"],
    outs = ["some-output-file"],
)
```

*Using the toolchain in a custom rule*

You need to add a dependency on the `@rules_sh//sh/posix:toolchain_type` to
your custom rule. For example:

```bzl
custom_rule = rule(
    _custom_rule_impl,
    toolchains = ["//sh/posix:toolchain_type"],
    ...
)
```

You can then access the `ShBinariesInfo` provider through the
`sh_binaries_info` attribute of the toolchain object. See `sh_binaries` for
details on the use of that provider. The example below illustrates how to
access the `grep` tool directly, or how to expose it through the `PATH`
environment variable.

```bzl
load("@rules_sh//sh:sh.bzl", "ShBinariesInfo")

def _custom_rule_impl(ctx):
    toolchain = ctx.toolchains["//sh/posix:toolchain_type"]
    sh_binaries_info = toolchain.sh_binaries_info

    ctx.actions.run(
        executable = sh_binaries_info.executables["grep"],
        ...
    )

    ctx.actions.run_shell(
        command = "grep ...",
        tools = [tools.executables["grep"]],
        env = {"PATH": ":".join(sh_binaries_info.paths.to_list())},
        ...
    )
```

Note that the `grep` tool still needs to be declared as an explicit dependency
of the action in the `PATH` use-case using the `tools` parameter.

The toolchain also exposes the attributes `commands` and `paths` exposed by the
non-hermetic POSIX toolchain for backwards compatibility. Note, however, that
actions still need to explicitly declare the relevant tool files as inputs
explicitly.

*Caveat: Using Binaries that require Runfiles*

If the tools bundled by the hermetic POSIX toolchains require Bazel runfiles
access then the same caveats as for `sh_binaries` apply.

For example, use in a `genrule` looks like this:

```bzl
genrule(
    name = "runfiles-genrule",
    toolchains = ["@rules_sh//sh/posix:make_variables"],
    cmd = "\n".join([
        # The explicit RUNFILES_DIR/RUNFILES_MANIFEST_FILE is a workaround for
        # https://github.com/bazelbuild/bazel/issues/15486
        "RUNFILES_DIR=$(execpath @rules_sh//sh/posix:make_variables).runfiles",
        "RUNFILES_MANIFEST_FILE=$(execpath @rules_sh//sh/posix:make_variables).runfiles_manifest",
        "FILE=$(execpath :some-input-file.bzl)",
        "$(POSIX_GREP) some-pattern $$FILE > $(OUTS)",
        "PATH=$(_POSIX_PATH)",
        "grep some-pattern $$FILE >> $(OUTS)",
    ]),
    srcs = [":some-input-file"],
    outs = ["some-output-file"],
)
```

And use in a custom rule looks like this:

```bzl
def _custom_rule_impl(ctx):
    toolchain = ctx.toolchains["//sh/posix:toolchain_type"]
    sh_binaries_info = toolchain.sh_binaries_info

    # The explicit RUNFILES_DIR/RUNFILES_MANIFEST_FILE is a workaround for
    # https://github.com/bazelbuild/bazel/issues/15486
    tools_env = {
        "RUNFILES_DIR": toolchain.tool[DefaultInfo].files_to_run.runfiles_manifest.dirname,
        "RUNFILES_MANIFEST_FILE": toolchain.tool[DefaultInfo].files_to_run.runfiles_manifest.path,
    }
    (tools_inputs, tools_manifest) = ctx.resolve_tools(tools = [toolchain.tool])

    ctx.actions.run(
        executable = sh_binaries_info.executables["grep"],
        env = tools_env, # Pass the environment into the action.
        inputs = tools_inputs,
        input_manifests = tools_manifest,
        ...
    )
```

*Defining a toolchain*

A hermetic POSIX toolchain can be defined by capturing an `sh_binaries` bundle
that provides the required tools. For example:

```bzl
sh_binaries(
    name = "commands",
    srcs = [
        ...
    ],
)

sh_posix_hermetic_toolchain(
    name = "posix",
    cmds = ":commands",
)

toolchain(
    name = "posix_toolchain",
    toolchain = ":posix",
    toolchain_type = "@rules_sh//sh/posix:toolchain_type",
    exec_compatible_with = [
        ...
    ],
    target_compatible_with = [
        ...
    ],
)
```
"�*
�)
sh_posix_hermetic_toolchain�'Defines a POSIX toolchain based on an sh_binaries bundle.

Provides:
  sh_binaries_info: ShBinariesInfo, for use in custom rules, see `sh_binaries`.
  tool: Target, the sh_binaries target for use in custom rules that requires runfiles, see `sh_binaries`.
  commands: Dict of String, an item per command holding the path to the executable or None. Provided for backwards compatibility with `sh_posix_toolchain`.
  paths: List of String, deduplicated bindir paths. Suitable for generating `$PATH`. Provided for backwards compatibility with `sh_posix_toolchain`.

#### Example

*Using the toolchain in a genrule*

You need to add a dependency on the `@rules_sh//sh/posix:make_variables` target
to the `toolchains` attribute to import the toolchain into a `genrule`. You can
then use specific tools through make-variables of the form `POSIX_<TOOL>`, or
by extending the `PATH` variable with `$(_POSIX_PATH)`. For example:

```bzl
genrule(
    name = "a-genrule",
    toolchains = ["@rules_sh//sh/posix:make_variables"],
    cmd = "\n".join([
        "FILE=$(execpath :some-input-file.bzl)",
        "$(POSIX_GREP) some-pattern $$FILE > $(OUTS)",
        "PATH=$(_POSIX_PATH)",
        "grep some-pattern $$FILE >> $(OUTS)",
    ]),
    srcs = [":some-input-file"],
    outs = ["some-output-file"],
)
```

*Using the toolchain in a custom rule*

You need to add a dependency on the `@rules_sh//sh/posix:toolchain_type` to
your custom rule. For example:

```bzl
custom_rule = rule(
    _custom_rule_impl,
    toolchains = ["//sh/posix:toolchain_type"],
    ...
)
```

You can then access the `ShBinariesInfo` provider through the
`sh_binaries_info` attribute of the toolchain object. See `sh_binaries` for
details on the use of that provider. The example below illustrates how to
access the `grep` tool directly, or how to expose it through the `PATH`
environment variable.

```bzl
load("@rules_sh//sh:sh.bzl", "ShBinariesInfo")

def _custom_rule_impl(ctx):
    toolchain = ctx.toolchains["//sh/posix:toolchain_type"]
    sh_binaries_info = toolchain.sh_binaries_info

    ctx.actions.run(
        executable = sh_binaries_info.executables["grep"],
        ...
    )

    ctx.actions.run_shell(
        command = "grep ...",
        tools = [tools.executables["grep"]],
        env = {"PATH": ":".join(sh_binaries_info.paths.to_list())},
        ...
    )
```

Note that the `grep` tool still needs to be declared as an explicit dependency
of the action in the `PATH` use-case using the `tools` parameter.

The toolchain also exposes the attributes `commands` and `paths` exposed by the
non-hermetic POSIX toolchain for backwards compatibility. Note, however, that
actions still need to explicitly declare the relevant tool files as inputs
explicitly.

*Caveat: Using Binaries that require Runfiles*

If the tools bundled by the hermetic POSIX toolchains require Bazel runfiles
access then the same caveats as for `sh_binaries` apply.

For example, use in a `genrule` looks like this:

```bzl
genrule(
    name = "runfiles-genrule",
    toolchains = ["@rules_sh//sh/posix:make_variables"],
    cmd = "\n".join([
        # The explicit RUNFILES_DIR/RUNFILES_MANIFEST_FILE is a workaround for
        # https://github.com/bazelbuild/bazel/issues/15486
        "RUNFILES_DIR=$(execpath @rules_sh//sh/posix:make_variables).runfiles",
        "RUNFILES_MANIFEST_FILE=$(execpath @rules_sh//sh/posix:make_variables).runfiles_manifest",
        "FILE=$(execpath :some-input-file.bzl)",
        "$(POSIX_GREP) some-pattern $$FILE > $(OUTS)",
        "PATH=$(_POSIX_PATH)",
        "grep some-pattern $$FILE >> $(OUTS)",
    ]),
    srcs = [":some-input-file"],
    outs = ["some-output-file"],
)
```

And use in a custom rule looks like this:

```bzl
def _custom_rule_impl(ctx):
    toolchain = ctx.toolchains["//sh/posix:toolchain_type"]
    sh_binaries_info = toolchain.sh_binaries_info

    # The explicit RUNFILES_DIR/RUNFILES_MANIFEST_FILE is a workaround for
    # https://github.com/bazelbuild/bazel/issues/15486
    tools_env = {
        "RUNFILES_DIR": toolchain.tool[DefaultInfo].files_to_run.runfiles_manifest.dirname,
        "RUNFILES_MANIFEST_FILE": toolchain.tool[DefaultInfo].files_to_run.runfiles_manifest.path,
    }
    (tools_inputs, tools_manifest) = ctx.resolve_tools(tools = [toolchain.tool])

    ctx.actions.run(
        executable = sh_binaries_info.executables["grep"],
        env = tools_env, # Pass the environment into the action.
        inputs = tools_inputs,
        input_manifests = tools_manifest,
        ...
    )
```

*Defining a toolchain*

A hermetic POSIX toolchain can be defined by capturing an `sh_binaries` bundle
that provides the required tools. For example:

```bzl
sh_binaries(
    name = "commands",
    srcs = [
        ...
    ],
)

sh_posix_hermetic_toolchain(
    name = "posix",
    cmds = ":commands",
)

toolchain(
    name = "posix_toolchain",
    toolchain = ":posix",
    toolchain_type = "@rules_sh//sh/posix:toolchain_type",
    exec_compatible_with = [
        ...
    ],
    target_compatible_with = [
        ...
    ],
)
```
*
nameA unique name for this target. T
cmdsHsh_binaries target that captures the tools to include in this toolchain. "M
sh_posix_hermetic_toolchain.@@rules_sh//sh/experimental:posix_hermetic.bzl
'#'#,
*
nameA unique name for this target. V
T
cmdsHsh_binaries target that captures the tools to include in this toolchain. a
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths
',
.�
//sh:posix.bzlr�

rules_shsh	posix.bzl.
MAKE_VARIABLESMAKE_VARIABLES
	"	0.
TOOLCHAIN_TYPETOOLCHAIN_TYPE
	4	B
		Dg
//sh:sh.bzlrV

rules_shshsh.bzl.
ShBinariesInfoShBinariesInfo


-


/r
//sh/private:posix.bzlrV
!
rules_sh
sh/private	posix.bzl#
commands	_commands
)2
@�Unix shell commands toolchain support.

Defines a hermetic version of the POSIX toolchain defined in
@rules_sh//sh:posix.bzl. Long-term this hermetic version will replace the old,
less hermetic version of the POSIX toolchain.
�	
 
rules_sh
sh/privatedefs.bzl�bool_constant"�

bool_constant*
nameA unique name for this target. 
value2False"0
bool_constant@@rules_sh//sh/private:defs.bzl
,
*
nameA unique name for this target. 

value2False�!mk_default_info_with_files_to_run*�
�
!mk_default_info_with_files_to_run	
ctx (

name (
files (
runfiles (2D
!mk_default_info_with_files_to_run@@rules_sh//sh/private:defs.bzl
""�mk_template_variable_info*�
}
mk_template_variable_info

name (
sh_binaries_info (2<
mk_template_variable_info@@rules_sh//sh/private:defs.bzl
2to_var_name2to_var_name�to_var_namekTurn a label name into a template variable info.

Uses all upper case variable names with `_` as separator.*�
�
to_var_name

label_name (kTurn a label name into a template variable info.

Uses all upper case variable names with `_` as separator.2.
to_var_name@@rules_sh//sh/private:defs.bzl
�ConstantInfo2�
X
ConstantInfo
value(Undocumented)"/
ConstantInfo@@rules_sh//sh/private:defs.bzl


value(Undocumented)a
//lib:dicts.bzlrL

bazel_skyliblib	dicts.bzl
dictsdicts
',
.�
)
rules_sh
sh/privateget_cpu_value.bzl�fail_on_err2Fail if the given return value indicates an error.*�
�
fail_on_errV
return_valueBPair; If the second element is not `None` this indicates an error. (_
prefixMoptional, String; A prefix for the error message contained in `return_value`.None(2Fail if the given return value indicates an error."@
>The first element of `return_value` if no error was indicated.27
fail_on_err(@@rules_sh//sh/private:get_cpu_value.bzl
((�get_cpu_valueHCompute the cpu_value based on the OS name. Doesn't %-escape the result!*�
�
get_cpu_value-
repository_ctxThe repository context. (HCompute the cpu_value based on the OS name. Doesn't %-escape the result!"K
IOne of (darwin, freebsd, x64_windows, ppc, s390x, arm, aarch64, k8, piii)29
get_cpu_value(@@rules_sh//sh/private:get_cpu_value.bzl
�

!
rules_sh
sh/private	posix.bzl�
	commandsj�
2�

admin
alias
ar
asa
at
awk

basename
batch
bc
bg
cc
c99
cal
cat
cd
cflow
chgrp
chmod
chown
cksum
cmp
comm
	command

compress
cp
	crontab
csplit
ctags
cut
cxref
date
dd
delta
df
diff
	dirname
du
echo
ed
env
ex
expand
expr
false
fc
fg
file
find
fold
fort77
fuser
gencat
get
	getconf
	getopts
grep
hash
head
iconv
id
ipcrm
ipcs
jobs
join
kill
lex
link
ln
locale
	localedef
logger
	logname
lp
ls
m4
mailx
make
man
mesg
mkdir
mkfifo
more
mv
newgrp
nice
nl
nm
nohup
od
paste
patch
	pathchk
pax
pr
printf
prs
ps
pwd
qalter
qdel
qhold
qmove
qmsg
qrerun
qrls
	qselect
qsig
qstat
qsub
read
renice
rm
rmdel
rmdir
sact
sccs
sed
sh
sleep
sort
split
	strings
strip
stty
tabs
tail
talk
tee
test
time
touch
tput
tr
true
tsort
tty
type
ulimit
umask
	unalias
uname

uncompress

unexpand
unget
uniq
unlink
uucp

uudecode

uuencode
uustat
uux
val
vi
wait
wc
what
who
write
xargs
yacc
zcat�

rules_shsh
import.bzl�create_shim�Create a binary shim for the given target.

Creates a copy of the [shim binary][shim-binary] named `<name>.exe` with a
neighboring `<name>.shim` file that points to the given target.

[shim-binary]: https://github.com/ScoopInstaller/Shim

#### Example

This can be used inside a repository rule run on Windows to generate a shim
of an external executable and import it into an `sh_binaries` target.

```bzl
powershell = repository_ctx.which("powershell")
if powershell != None:
    create_shim(
        repository_ctx,
        name = "powershell",
        target = powershell,
    )

repository_ctx.file(
    "BUILD.bazel",
    "\n".join([
        "sh_binaries(",
        "    name = 'tools',",
        "    srcs = ['powershell.exe'],",
        "    data = ['powershell.shim'],",
        ")",
    ]),
)
```
*�	
�	
create_shim
repository_ctx (~
namerstring or path, The name of the newly created shim, without the .exe suffix, relative to the repository directory. (E
target7string or path, Absolute path to the target executable. (h
shim_exe1string; Label; or path, The original shim binary.'Label("@@rules_sh_shim_exe//:shim.exe")(�Create a binary shim for the given target.

Creates a copy of the [shim binary][shim-binary] named `<name>.exe` with a
neighboring `<name>.shim` file that points to the given target.

[shim-binary]: https://github.com/ScoopInstaller/Shim

#### Example

This can be used inside a repository rule run on Windows to generate a shim
of an external executable and import it into an `sh_binaries` target.

```bzl
powershell = repository_ctx.which("powershell")
if powershell != None:
    create_shim(
        repository_ctx,
        name = "powershell",
        target = powershell,
    )

repository_ctx.file(
    "BUILD.bazel",
    "\n".join([
        "sh_binaries(",
        "    name = 'tools',",
        "    srcs = ['powershell.exe'],",
        "    data = ['powershell.shim'],",
        ")",
    ]),
)
```
2(
create_shim@@rules_sh//sh:import.bzl
�:

rules_shsh	posix.bzl�
sh_posix_make_variables�
Provides POSIX toolchain commands as custom make variables.

Make variables:
  Provides a make variable of the form `POSIX_<COMMAND>` for each available
  command, where `<COMMAND>` is the name of the command in upper case.

Use `posix.MAKE_VARIABLES` instead of instantiating this rule yourself.

Example:
  >>> genrule(
          name = "use-grep",
          srcs = [":some-file"],
          outs = ["grep-out"],
          cmd = "$(POSIX_GREP) search $(execpath :some-file) > $(OUTS)",
          toolchains = [posix.MAKE_VARIABLES],
      )
"�
�
sh_posix_make_variables�
Provides POSIX toolchain commands as custom make variables.

Make variables:
  Provides a make variable of the form `POSIX_<COMMAND>` for each available
  command, where `<COMMAND>` is the name of the command in upper case.

Use `posix.MAKE_VARIABLES` instead of instantiating this rule yourself.

Example:
  >>> genrule(
          name = "use-grep",
          srcs = [":some-file"],
          outs = ["grep-out"],
          cmd = "$(POSIX_GREP) search $(execpath :some-file) > $(OUTS)",
          toolchains = [posix.MAKE_VARIABLES],
      )
*
nameA unique name for this target. "3
sh_posix_make_variables@@rules_sh//sh:posix.bzl
YY,
*
nameA unique name for this target. �sh_posix_toolchain�
A toolchain capturing standard Unix shell commands.

Provides:
  commands: Dict of String, an item per command holding the path to the executable or None.
  paths: List of String, deduplicated bindir paths. Suitable for generating `$PATH`.

Use `sh_posix_configure` to create an instance of this toolchain.
See `sh_posix_make_variables` on how to use this toolchain in genrules.
"�
�
sh_posix_toolchain�
A toolchain capturing standard Unix shell commands.

Provides:
  commands: Dict of String, an item per command holding the path to the executable or None.
  paths: List of String, deduplicated bindir paths. Suitable for generating `$PATH`.

Use `sh_posix_configure` to create an instance of this toolchain.
See `sh_posix_make_variables` on how to use this toolchain in genrules.
*
nameA unique name for this target. B
cmds6dict where keys are command names and values are paths
 ".
sh_posix_toolchain@@rules_sh//sh:posix.bzl
++,
*
nameA unique name for this target. D
B
cmds6dict where keys are command names and values are paths
 �sh_posix_configure�## Usage

### Configure the toolchain

Add the following to your `WORKSPACE` file to configure a local POSIX toolchain.

``` python
load("@rules_sh//sh:posix.bzl", "sh_posix_configure")
sh_posix_configure()
```

Bazel will query `PATH` for common Unix shell commands. You can override the
path to individual commands with environment variables of the form
`POSIX_<COMMAND_NAME>`. E.g. `POSIX_MAKE=/usr/bin/gmake`.

Note, this introduces an inhermeticity to the build as the contents of `PATH`
may be specific to your machine's setup.

Refer to [`rules_nixpkgs`'s][rules_nixpkgs] `nixpkgs_posix_configure` for a
hermetic alternative.

[rules_nixpkgs]: https://github.com/tweag/rules_nixpkgs.git

### Use Unix tools in `genrule`s

The POSIX toolchain exposes custom make variables of the form
`POSIX_<COMMAND_NAME>` for discovered commands. Use these as follows:

``` python
genrule(
    name = "example",
    srcs = [":some-input-file"],
    outs = ["some-output-file"],
    cmd = "$(POSIX_GREP) some-pattern $(execpath :some-input-file.bzl) > $(OUTS)",
    toolchains = ["@rules_sh//sh/posix:make_variables"],
)
```

See `posix.commands` defined in `@rules_sh//sh/posix.bzl` for the list of known
POSIX commands.

### Use Unix tools in custom rules

The POSIX toolchain provides two attributes:
- `commands`: A `dict` mapping names of commands to their paths.
- `paths`: A deduplicated list of bindir paths suitable for generating `$PATH`.

``` python
def _my_rule_impl(ctx):
    posix_info = ctx.toolchains["@rules_sh//sh/posix:toolchain_type"]
    ctx.actions.run(
        executable = posix_info.commands["grep"],
        ...
    )
    ctx.actions.run_shell(
        command = "grep ...",
        env = {"PATH": ":".join(posix_info.paths)},
        ...
    )

my_rule = rule(
    _my_rule_impl,
    toolchains = ["@rules_sh//sh/posix:toolchain_type"],
    ...
)
```*�
�
sh_posix_configure
name"local_posix_config"(
registerTrue(�## Usage

### Configure the toolchain

Add the following to your `WORKSPACE` file to configure a local POSIX toolchain.

``` python
load("@rules_sh//sh:posix.bzl", "sh_posix_configure")
sh_posix_configure()
```

Bazel will query `PATH` for common Unix shell commands. You can override the
path to individual commands with environment variables of the form
`POSIX_<COMMAND_NAME>`. E.g. `POSIX_MAKE=/usr/bin/gmake`.

Note, this introduces an inhermeticity to the build as the contents of `PATH`
may be specific to your machine's setup.

Refer to [`rules_nixpkgs`'s][rules_nixpkgs] `nixpkgs_posix_configure` for a
hermetic alternative.

[rules_nixpkgs]: https://github.com/tweag/rules_nixpkgs.git

### Use Unix tools in `genrule`s

The POSIX toolchain exposes custom make variables of the form
`POSIX_<COMMAND_NAME>` for discovered commands. Use these as follows:

``` python
genrule(
    name = "example",
    srcs = [":some-input-file"],
    outs = ["some-output-file"],
    cmd = "$(POSIX_GREP) some-pattern $(execpath :some-input-file.bzl) > $(OUTS)",
    toolchains = ["@rules_sh//sh/posix:make_variables"],
)
```

See `posix.commands` defined in `@rules_sh//sh/posix.bzl` for the list of known
POSIX commands.

### Use Unix tools in custom rules

The POSIX toolchain provides two attributes:
- `commands`: A `dict` mapping names of commands to their paths.
- `paths`: A deduplicated list of bindir paths suitable for generating `$PATH`.

``` python
def _my_rule_impl(ctx):
    posix_info = ctx.toolchains["@rules_sh//sh/posix:toolchain_type"]
    ctx.actions.run(
        executable = posix_info.commands["grep"],
        ...
    )
    ctx.actions.run_shell(
        command = "grep ...",
        env = {"PATH": ":".join(posix_info.paths)},
        ...
    )

my_rule = rule(
    _my_rule_impl,
    toolchains = ["@rules_sh//sh/posix:toolchain_type"],
    ...
)
```2.
sh_posix_configure@@rules_sh//sh:posix.bzl
��2_sh_posix_configa
//lib:paths.bzlrL

bazel_skyliblib	paths.bzl
pathspaths

'
,


.�
//sh/private:defs.bzlr�
 
rules_sh
sh/privatedefs.bzlT
!mk_default_info_with_files_to_run!mk_default_info_with_files_to_run
'D
mk_template_variable_infomk_template_variable_info

�
//sh/private:get_cpu_value.bzlrg
)
rules_sh
sh/privateget_cpu_value.bzl,
get_cpu_valueget_cpu_value
2?
Ar
//sh/private:posix.bzlrV
!
rules_sh
sh/private	posix.bzl#
commands	_commands
)2
@\	MAKE_VARIABLES"@rules_sh//sh/posix:make_variablesj$"@rules_sh//sh/posix:make_variables\	TOOLCHAIN_TYPE"@rules_sh//sh/posix:toolchain_typej$"@rules_sh//sh/posix:toolchain_type�Unix shell commands toolchain support.

Defines a toolchain capturing common Unix shell commands as defined by IEEE
1003.1-2008 (POSIX), see `sh_posix_toolchain`, and `sh_posix_configure` to scan
the local environment for shell commands. The list of known commands is
available in `posix.commands`.

�
 
rules_shshrepositories.bzl�rules_sh_dependencies�## Setup

See the **WORKSPACE setup** section of the [current release][releases].

[releases]: https://github.com/tweag/rules_sh/releases

Or use the following template in your `WORKSPACE` file to install a development
version of `rules_sh`:

``` python
load("@bazel_tools//tools/build_defs/repo:http.bzl", "http_archive")
http_archive(
    name = "rules_sh",
    # Replace git revision and sha256.
    sha256 = "0000000000000000000000000000000000000000000000000000000000000000",
    strip_prefix = "rules_sh-0000000000000000000000000000000000000000",
    urls = ["https://github.com/tweag/rules_sh/archive/0000000000000000000000000000000000000000.tar.gz"],
)
load("@rules_sh//sh:repositories.bzl", "rules_sh_dependencies")
rules_sh_dependencies()
```*�
�
rules_sh_dependencies�## Setup

See the **WORKSPACE setup** section of the [current release][releases].

[releases]: https://github.com/tweag/rules_sh/releases

Or use the following template in your `WORKSPACE` file to install a development
version of `rules_sh`:

``` python
load("@bazel_tools//tools/build_defs/repo:http.bzl", "http_archive")
http_archive(
    name = "rules_sh",
    # Replace git revision and sha256.
    sha256 = "0000000000000000000000000000000000000000000000000000000000000000",
    strip_prefix = "rules_sh-0000000000000000000000000000000000000000",
    urls = ["https://github.com/tweag/rules_sh/archive/0000000000000000000000000000000000000000.tar.gz"],
)
load("@rules_sh//sh:repositories.bzl", "rules_sh_dependencies")
rules_sh_dependencies()
```28
rules_sh_dependencies@@rules_sh//sh:repositories.bzl
�
 //tools/build_defs/repo:http.bzlr�
.
bazel_toolstools/build_defs/repohttp.bzl*
http_archivehttp_archive
7C$
	http_file	http_file
GP
R�
!//tools/build_defs/repo:utils.bzlr]
/
bazel_toolstools/build_defs/repo	utils.bzl
maybemaybe
8=
? 