�
9
rules_shellshell/private/extensionssh_configure.bzlzsh_configureJh
X
sh_configure"H
sh_configure8@@rules_shell//shell/private/extensions:sh_configure.bzl
  �
*//shell/private/repositories:sh_config.bzlrn
8
rules_shellshell/private/repositoriessh_config.bzl$
	sh_config	sh_config
AJ
L"The sh_configure module extension.�	
8
rules_shellshell/private/repositoriessh_config.bzl�	sh_configR�
�
	sh_config.
name"A unique name for this repository. �
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 "WINDIR"PATH*D
	sh_config7@@rules_shell//shell/private/repositories:sh_config.bzl
XX0
.
name"A unique name for this repository. �
�
repo_mapping�A dictionary from local repository name to global repository name. This allows controls over workspace dependency resolution for dependencies of this repository.<p>For example, an entry `"@foo": "@bar"` declares that, for any time this repository depends on `@foo` (such as a dependency on `@foo//some:target`, it should actually resolve that dependency within globally-declared `@bar` (`@bar//some:target`).
 3Configure sh_toolchains based on the local machine.�
/
rules_shellshell/privatesh_executable.bzl�make_sh_executable_rule*�
�
make_sh_executable_rule
extra_attrs{}(

kwargs(2I
make_sh_executable_rule.@@rules_shell//shell/private:sh_executable.bzl
��*rule,Common code for sh_binary and sh_test rules.�
1
rules_shellshell/toolchainssh_toolchain.bzl�sh_toolchain&A runtime toolchain for shell targets."�
�
sh_toolchain&A runtime toolchain for shell targets.*
nameA unique name for this target. {
launchergThe generic launcher binary to use to run sh_binary/sh_test targets (only used when targeting Windows).2None�
launcher_makeryThe tool to use to create a target-specific launcher from the generic launcher binary (only used when targeting Windows).2None3
path'Absolute path to the shell interpreter. "@
sh_toolchain0@@rules_shell//shell/toolchains:sh_toolchain.bzl
,
*
nameA unique name for this target. }
{
launchergThe generic launcher binary to use to run sh_binary/sh_test targets (only used when targeting Windows).2None�
�
launcher_makeryThe tool to use to create a target-specific launcher from the generic launcher binary (only used when targeting Windows).2None5
3
path'Absolute path to the shell interpreter. &Define a toolchain rule for the shell.�
&
rules_shellshellrepositories.bzl�rules_shell_dependencies2Instantiates repositories required by rules_shell.*�
�
rules_shell_dependencies2Instantiates repositories required by rules_shell.2A
rules_shell_dependencies%@@rules_shell//shell:repositories.bzl
�rules_shell_toolchains?Register sh_toolchains for the host and common other platforms.*�
�
rules_shell_toolchains?Register sh_toolchains for the host and common other platforms.2?
rules_shell_toolchains%@@rules_shell//shell:repositories.bzl
�
*//shell/private/repositories:sh_config.bzlrn
8
rules_shellshell/private/repositoriessh_config.bzl$
	sh_config	sh_config
AJ
L0WORKSPACE dependency macros for the shell rules.�
#
rules_shellshellsh_binary.bzl�	sh_binary�
<p>
  The <code>sh_binary</code> rule is used to declare executable shell scripts.
  (<code>sh_binary</code> is a misnomer: its outputs aren't necessarily binaries.) This rule ensures
  that all dependencies are built, and appear in the <code>runfiles</code> area at execution time.
  We recommend that you name your <code>sh_binary()</code> rules after the name of the script minus
  the extension (e.g. <code>.sh</code>); the rule name and the file name must be distinct.
  <code>sh_binary</code> respects shebangs, so any available interpreter may be used (eg.
  <code>#!/bin/zsh</code>)
</p>
<h4 id="sh_binary_examples">Example</h4>
<p>For a simple shell script with no dependencies and some data files:
</p>
<pre class="code">
sh_binary(
    name = "foo",
    srcs = ["foo.sh"],
    data = glob(["datafiles/*.txt"]),
)
</pre>
"�
�
	sh_binary�
<p>
  The <code>sh_binary</code> rule is used to declare executable shell scripts.
  (<code>sh_binary</code> is a misnomer: its outputs aren't necessarily binaries.) This rule ensures
  that all dependencies are built, and appear in the <code>runfiles</code> area at execution time.
  We recommend that you name your <code>sh_binary()</code> rules after the name of the script minus
  the extension (e.g. <code>.sh</code>); the rule name and the file name must be distinct.
  <code>sh_binary</code> respects shebangs, so any available interpreter may be used (eg.
  <code>#!/bin/zsh</code>)
</p>
<h4 id="sh_binary_examples">Example</h4>
<p>For a simple shell script with no dependencies and some data files:
</p>
<pre class="code">
sh_binary(
    name = "foo",
    srcs = ["foo.sh"],
    data = glob(["datafiles/*.txt"]),
)
</pre>
*
nameA unique name for this target. 
data2[]�
deps�
The list of "library" targets to be aggregated into this target.
See general comments about <code>deps</code>
at <a href="${link common-definitions#typical.deps}">Typical attributes defined by
most build rules</a>.
<p>
  This attribute should be used to list other <code>sh_library</code> rules that provide
  interpreted program source code depended on by the code in <code>srcs</code>. The files
  provided by these rules will be present among the <code>runfiles</code> of this target.
</p>
2[]
env
2{}
env_inherit2[]�
srcs�
The list of input files.
<p>
  This attribute should be used to list shell script source files that belong to
  this library. Scripts can load other scripts using the shell's <code>source</code>
  or <code>.</code> command.
</p>
2[]"/
	sh_binary"@@rules_shell//shell:sh_binary.bzl
��,
*
nameA unique name for this target. 

data2[]�
�
deps�
The list of "library" targets to be aggregated into this target.
See general comments about <code>deps</code>
at <a href="${link common-definitions#typical.deps}">Typical attributes defined by
most build rules</a>.
<p>
  This attribute should be used to list other <code>sh_library</code> rules that provide
  interpreted program source code depended on by the code in <code>srcs</code>. The files
  provided by these rules will be present among the <code>runfiles</code> of this target.
</p>
2[]

env
2{}

env_inherit2[]�
�
srcs�
The list of input files.
<p>
  This attribute should be used to list shell script source files that belong to
  this library. Scripts can load other scripts using the shell's <code>source</code>
  or <code>.</code> command.
</p>
2[]�
!//shell/private:sh_executable.bzlr�
/
rules_shellshell/privatesh_executable.bzl@
make_sh_executable_rulemake_sh_executable_rule
8O
Qsh_binary rule definition.�#
$
rules_shellshellsh_library.bzl�"
sh_library�

<p>
  The main use for this rule is to aggregate together a logical
  "library" consisting of related scripts&mdash;programs in an
  interpreted language that does not require compilation or linking,
  such as the Bourne shell&mdash;and any data those programs need at
  run-time. Such "libraries" can then be used from
  the <code>data</code> attribute of one or
  more <code>sh_binary</code> rules.
</p>

<p>
  You can use the <a href="${link filegroup}"><code>filegroup</code></a> rule to aggregate data
  files.
</p>

<p>
  In interpreted programming languages, there's not always a clear
  distinction between "code" and "data": after all, the program is
  just "data" from the interpreter's point of view. For this reason
  this rule has three attributes which are all essentially equivalent:
  <code>srcs</code>, <code>deps</code> and <code>data</code>.
  The current implementation does not distinguish between the elements of these lists.
  All three attributes accept rules, source files and generated files.
  It is however good practice to use the attributes for their usual purpose (as with other rules).
</p>

<h4 id="sh_library_examples">Examples</h4>

<pre class="code">
sh_library(
    name = "foo",
    data = [
        ":foo_service_script",  # an sh_binary with srcs
        ":deploy_foo",  # another sh_binary with srcs
    ],
)
</pre>
"�
�

sh_library�

<p>
  The main use for this rule is to aggregate together a logical
  "library" consisting of related scripts&mdash;programs in an
  interpreted language that does not require compilation or linking,
  such as the Bourne shell&mdash;and any data those programs need at
  run-time. Such "libraries" can then be used from
  the <code>data</code> attribute of one or
  more <code>sh_binary</code> rules.
</p>

<p>
  You can use the <a href="${link filegroup}"><code>filegroup</code></a> rule to aggregate data
  files.
</p>

<p>
  In interpreted programming languages, there's not always a clear
  distinction between "code" and "data": after all, the program is
  just "data" from the interpreter's point of view. For this reason
  this rule has three attributes which are all essentially equivalent:
  <code>srcs</code>, <code>deps</code> and <code>data</code>.
  The current implementation does not distinguish between the elements of these lists.
  All three attributes accept rules, source files and generated files.
  It is however good practice to use the attributes for their usual purpose (as with other rules).
</p>

<h4 id="sh_library_examples">Examples</h4>

<pre class="code">
sh_library(
    name = "foo",
    data = [
        ":foo_service_script",  # an sh_binary with srcs
        ":deploy_foo",  # another sh_binary with srcs
    ],
)
</pre>
*
nameA unique name for this target. 
data2[]�
deps�
The list of "library" targets to be aggregated into this target.
See general comments about <code>deps</code>
at <a href="${link common-definitions#typical.deps}">Typical attributes defined by
most build rules</a>.
<p>
  This attribute should be used to list other <code>sh_library</code> rules that provide
  interpreted program source code depended on by the code in <code>srcs</code>. The files
  provided by these rules will be present among the <code>runfiles</code> of this target.
</p>
2[]�
srcs�
The list of input files.
<p>
  This attribute should be used to list shell script source files that belong to
  this library. Scripts can load other scripts using the shell's <code>source</code>
  or <code>.</code> command.
</p>
2[]"1

sh_library#@@rules_shell//shell:sh_library.bzl
--,
*
nameA unique name for this target. 

data2[]�
�
deps�
The list of "library" targets to be aggregated into this target.
See general comments about <code>deps</code>
at <a href="${link common-definitions#typical.deps}">Typical attributes defined by
most build rules</a>.
<p>
  This attribute should be used to list other <code>sh_library</code> rules that provide
  interpreted program source code depended on by the code in <code>srcs</code>. The files
  provided by these rules will be present among the <code>runfiles</code> of this target.
</p>
2[]�
�
srcs�
The list of input files.
<p>
  This attribute should be used to list shell script source files that belong to
  this library. Scripts can load other scripts using the shell's <code>source</code>
  or <code>.</code> command.
</p>
2[]sh_library rule definition. 