��
signingactions.bzl�signing_attrs�Returns the attributes a rule needs in order to call `signing_context`.

This does **not** include `STAMP_ATTRS`. Stamping is a rule-wide concern
rather than a signing-specific one -- a rule that stamps at all almost
certainly stamps more than its signing options, and `stamp` cannot be
prefixed because `maybe_stamp` looks it up by that exact name. Bundling it
here would therefore mean a rule that already declares `STAMP_ATTRS` for
its own purposes could not also use these attributes, since merging two
dicts that share a key is an error.

So the rule declares it, once, alongside these:

```starlark
load("@bazel_lib//lib:stamping.bzl", "STAMP_ATTRS")

my_rule = rule(
    attrs = dict({
        # ... your own attributes ...
    }, **dict(signing_attrs(), **STAMP_ATTRS)),
)
```

`signing_context` checks the stamp attributes are present and fails with
an explanation if they are not. That check matters: `maybe_stamp` reads
them with a default, so their absence would otherwise silently disable
stamping and turn an unresolved `{KEY}` placeholder into a confusing
downstream error rather than an obvious missing-attribute one.
*�
�
signing_attrs�
prefix�prepended to every attribute name. The default keeps the
signing options in their own namespace so they cannot collide with
attributes the host rule already defines -- a real risk for names
as generic as `tool`, `url`, `description` and `options`. Pass `""`
for the bare names.
"signing_"(�Returns the attributes a rule needs in order to call `signing_context`.

This does **not** include `STAMP_ATTRS`. Stamping is a rule-wide concern
rather than a signing-specific one -- a rule that stamps at all almost
certainly stamps more than its signing options, and `stamp` cannot be
prefixed because `maybe_stamp` looks it up by that exact name. Bundling it
here would therefore mean a rule that already declares `STAMP_ATTRS` for
its own purposes could not also use these attributes, since merging two
dicts that share a key is an error.

So the rule declares it, once, alongside these:

```starlark
load("@bazel_lib//lib:stamping.bzl", "STAMP_ATTRS")

my_rule = rule(
    attrs = dict({
        # ... your own attributes ...
    }, **dict(signing_attrs(), **STAMP_ATTRS)),
)
```

`signing_context` checks the stamp attributes are present and fails with
an explanation if they are not. That check matters: `maybe_stamp` reads
them with a default, so their absence would otherwise silently disable
stamping and turn an unresolved `{KEY}` placeholder into a confusing
downstream error rather than an obvious missing-attribute one.
"4
2A dict suitable for merging into a rule's `attrs`.2-
signing_attrs//signing/private:action.bzl�
�
prefix�prepended to every attribute name. The default keeps the
signing options in their own namespace so they cannot collide with
attributes the host rule already defines -- a real risk for names
as generic as `tool`, `url`, `description` and `options`. Pass `""`
for the bare names.
"signing_"(�signing_toolchains�Returns the toolchain types a rule needs in order to call `signing_context`.

All of these are `mandatory = False`: an unregistered signer is allowed
unless `signing_context` discovers an input that requires it. This includes
jarsigner, whose dedicated type does not resolve a JDK unless a consumer
explicitly registers an implementation.

Optional does not mean lazy: Bazel analyzes any matching registered
implementation before the rule runs, even if no source needs it. A rule
that structurally cannot need a signer can omit its type entirely.
*�
�
signing_toolchains~
osslsigncodefwhether to declare `OSSLSIGNCODE_TOOLCHAIN`, needed to
sign Windows PE binaries (`.exe`, `.dll`, ...).True(�
cosignwhether to declare `COSIGN_TOOLCHAIN`, needed for detached
`.sig`/`.bundle.json` signatures and anything with no native
signer.True(}
codesigniwhether to declare `CODESIGN_TOOLCHAIN`, needed to sign
Mach-O binaries and `.app`/`.pkg`/`.dmg` bundles.True(�
openssl�whether to declare `OPENSSL_TOOLCHAIN`. Only consulted when
`cosign` has to convert PKCS#12 certificate material to PEM,
which cannot be known until the signing action runs, so `cosign`
still requires this whenever it might be used with such
material.True(�
	jarsigner�whether to declare `JARSIGNER_TOOLCHAIN`. Set to `False`
for a rule that signs no `.jar`s or other JVM binaries, so it
never needs a Java runtime toolchain resolved and cannot be
broken by a registered implementation that fails to analyze.
Defaults to `True`, which is what `SIGNING_TOOLCHAINS` uses.True(�Returns the toolchain types a rule needs in order to call `signing_context`.

All of these are `mandatory = False`: an unregistered signer is allowed
unless `signing_context` discovers an input that requires it. This includes
jarsigner, whose dedicated type does not resolve a JDK unless a consumer
explicitly registers an implementation.

Optional does not mean lazy: Bazel analyzes any matching registered
implementation before the rule runs, even if no source needs it. A rule
that structurally cannot need a signer can omit its type entirely.
",
*A list suitable for a rule's `toolchains`.22
signing_toolchains//signing/private:action.bzl�
~
osslsigncodefwhether to declare `OSSLSIGNCODE_TOOLCHAIN`, needed to
sign Windows PE binaries (`.exe`, `.dll`, ...).True(�
�
cosignwhether to declare `COSIGN_TOOLCHAIN`, needed for detached
`.sig`/`.bundle.json` signatures and anything with no native
signer.True(
}
codesigniwhether to declare `CODESIGN_TOOLCHAIN`, needed to sign
Mach-O binaries and `.app`/`.pkg`/`.dmg` bundles.True(�
�
openssl�whether to declare `OPENSSL_TOOLCHAIN`. Only consulted when
`cosign` has to convert PKCS#12 certificate material to PEM,
which cannot be known until the signing action runs, so `cosign`
still requires this whenever it might be used with such
material.True(�
�
	jarsigner�whether to declare `JARSIGNER_TOOLCHAIN`. Set to `False`
for a rule that signs no `.jar`s or other JVM binaries, so it
never needs a Java runtime toolchain resolved and cannot be
broken by a registered implementation that fails to analyze.
Defaults to `True`, which is what `SIGNING_TOOLCHAINS` uses.True(�%signing_context�Resolves signing toolchains and certificate material for `ctx`.

The rule calling this must have merged `SIGNING_ATTRS` into its `attrs`
and `SIGNING_TOOLCHAINS` into its `toolchains`.
*�$
�
signing_context
ctxthe rule context. (�
srcs�Files that will be signed, when they are known at analysis time.
Used only to work out which signing toolchains are required under
`tool = "auto"`, and to explain why if one is missing. Rules that
sign something produced by the action itself (so nothing is known
yet) pass nothing here and use `require` instead.[](�
require�tool kinds (`"osslsigncode"`, `"codesign"`, `"cosign"`,
`"jarsigner"`) that this rule always needs regardless of `srcs`.
Use this when the signing target does not exist at analysis
time, so that a missing toolchain fails during analysis with a
clear message rather than part-way through the action.[](�
require_reason�human-readable explanation of `require`, quoted in the
missing-toolchain error. For example "an NSIS uninstaller is
always a PE executable".""(�
tool�overrides the `tool` attribute. Rules that only ever produce one
kind of artifact can pin the signer here instead of exposing the
choice.None(M
detached_signatures.overrides the `detached_signatures` attribute.None(�
formats�`File` to binary-format mapping from `binary_formats()`,
naming the sources that are native binaries. Sources absent from
it are classified by name instead, so passing nothing is valid
and simply means no rule vouched for anything.{}(�
name�base name for the generated parameter file. Defaults to the
target name. Pass distinct values if one target builds more than
one signing context.None(�
attr_prefixdthe prefix the signing attributes were declared with.
Must match what was passed to `signing_attrs`.
"signing_"(�Resolves signing toolchains and certificate material for `ctx`.

The rule calling this must have merged `SIGNING_ATTRS` into its `attrs`
and `SIGNING_TOOLCHAINS` into its `toolchains`.
"�
�A struct with:

* `executable`: the signer `File` to run.
* `params_file`: a `File` holding every argument that does not name an
  input or output, meant to be passed as `@<path>`. Keeping them in a
  file rather than on the command line means certificate paths and
  passwords are not exposed in process listings or embedded into
  generated scripts, and are not subject to a third-party tool's
  quoting rules.
* `inputs`: a `depset` of Files the action must declare as inputs.
* `tools`: a list of Files for the action's `tools`.
* `env`: environment variables needed when the signer is *not* the
  action's own executable (for example when another tool spawns it).
  Merge these into that action's `env`.
* `required_env_vars`: names of environment variables the signer reads
  from the ambient environment (currently the certificate's
  `password_env`, if set). The caller must make sure these reach the
  action, typically with `--action_env`.
* `tool_mode`: the resolved value of `tool`.
* `detached_signatures`: the resolved value of `detached_signatures`.2/
signing_context//signing/private:action.bzl

ctxthe rule context. (�
�
srcs�Files that will be signed, when they are known at analysis time.
Used only to work out which signing toolchains are required under
`tool = "auto"`, and to explain why if one is missing. Rules that
sign something produced by the action itself (so nothing is known
yet) pass nothing here and use `require` instead.[](�
�
require�tool kinds (`"osslsigncode"`, `"codesign"`, `"cosign"`,
`"jarsigner"`) that this rule always needs regardless of `srcs`.
Use this when the signing target does not exist at analysis
time, so that a missing toolchain fails during analysis with a
clear message rather than part-way through the action.[](�
�
require_reason�human-readable explanation of `require`, quoted in the
missing-toolchain error. For example "an NSIS uninstaller is
always a PE executable".""(�
�
tool�overrides the `tool` attribute. Rules that only ever produce one
kind of artifact can pin the signer here instead of exposing the
choice.None(O
M
detached_signatures.overrides the `detached_signatures` attribute.None(�
�
formats�`File` to binary-format mapping from `binary_formats()`,
naming the sources that are native binaries. Sources absent from
it are classified by name instead, so passing nothing is valid
and simply means no rule vouched for anything.{}(�
�
name�base name for the generated parameter file. Defaults to the
target name. Pass distinct values if one target builds more than
one signing context.None(�
�
attr_prefixdthe prefix the signing attributes were declared with.
Must match what was passed to `signing_attrs`.
"signing_"(�signing_argv�Builds a signer command line for the context returned by `signing_context`.

Exactly one of `infile` or `rel_src_manifest` must be given.
*�
�
signing_argv5
sctx)the struct returned by `signing_context`. (�
infile�path of the single file or directory to sign. Pass a `File`,
or a plain string when the path is only known to the tool that
will run the command (NSIS' `!finalize`, for instance, substitutes
the string `"%1"`).None(�
outfile�where to write the signed result. When omitted, `infile` is
signed in place, which is what compile-time hooks that hand over a
path to an artifact they already produced expect.None(@
out_dir-output directory for `rel_src_manifest` mode.None(�
rel_src_manifest�manifest of tab-separated `relpath\tsource` lines,
optionally with a third `\tsigner` field, for signing many files
in one invocation.None(�
require_detached_signatures�declares that the caller has already
declared `.sig`/`.bundle.json` outputs for every source the
manifest routes to cosign, so the signer must fail rather than
fall back to copying when no certificate resolves.False(�
path_fn�optional function applied to every path in the result. Use it
when the command is consumed by a tool that needs a different path
spelling than Bazel's (for example a Windows-style path).None(�Builds a signer command line for the context returned by `signing_context`.

Exactly one of `infile` or `rel_src_manifest` must be given.
"~
|A list of strings: the executable, the `--args-file` reference, and
the arguments naming this invocation's input and output.2,
signing_argv//signing/private:action.bzl7
5
sctx)the struct returned by `signing_context`. (�
�
infile�path of the single file or directory to sign. Pass a `File`,
or a plain string when the path is only known to the tool that
will run the command (NSIS' `!finalize`, for instance, substitutes
the string `"%1"`).None(�
�
outfile�where to write the signed result. When omitted, `infile` is
signed in place, which is what compile-time hooks that hand over a
path to an artifact they already produced expect.None(B
@
out_dir-output directory for `rel_src_manifest` mode.None(�
�
rel_src_manifest�manifest of tab-separated `relpath\tsource` lines,
optionally with a third `\tsigner` field, for signing many files
in one invocation.None(�
�
require_detached_signatures�declares that the caller has already
declared `.sig`/`.bundle.json` outputs for every source the
manifest routes to cosign, so the signer must fail rather than
fall back to copying when no certificate resolves.False(�
�
path_fn�optional function applied to every path in the result. Use it
when the command is consumed by a tool that needs a different path
spelling than Bazel's (for example a Windows-style path).None(�sign_action�Registers an action signing `srcs`, keeping their relative layout.

This is the "sign these files and keep their layout" case that the `sign`
rule exposes, factored out so other rules can reuse it directly. Pass
exactly one of:

* `outs`, from `signed_outputs`, to get one output artifact per source
  (plus cosign's sidecar files), which is what `sign` itself does; or
* `out_dir`, to collect everything into a single tree artifact instead,
  for rules that want one directory to hand downstream.
*�
�	
sign_action
ctxthe rule context. (
srcsthe Files to sign. (M
out_dir:a directory artifact from `ctx.actions.declare_directory`.None(8
outs(the struct returned by `signed_outputs`.None(H
sctx8a `signing_context` to reuse; one is created if omitted.None(�
formatsv`File` to binary-format mapping from `binary_formats()`.
Ignored when `sctx` is supplied, which already resolved them.{}(*
mnemonicaction mnemonic.
"SignTree"(4
progress_messageaction progress message.None(s
attr_prefixVthe prefix the signing attributes were declared with.
Ignored when `sctx` is supplied.
"signing_"(+
kwargsforwarded to `ctx.actions.run`.(�Registers an action signing `srcs`, keeping their relative layout.

This is the "sign these files and keep their layout" case that the `sign`
rule exposes, factored out so other rules can reuse it directly. Pass
exactly one of:

* `outs`, from `signed_outputs`, to get one output artifact per source
  (plus cosign's sidecar files), which is what `sign` itself does; or
* `out_dir`, to collect everything into a single tree artifact instead,
  for rules that want one directory to hand downstream.
"&
$The `signing_context` that was used.2+
sign_action//signing/private:action.bzl

ctxthe rule context. ( 

srcsthe Files to sign. (O
M
out_dir:a directory artifact from `ctx.actions.declare_directory`.None(:
8
outs(the struct returned by `signed_outputs`.None(J
H
sctx8a `signing_context` to reuse; one is created if omitted.None(�
�
formatsv`File` to binary-format mapping from `binary_formats()`.
Ignored when `sctx` is supplied, which already resolved them.{}(,
*
mnemonicaction mnemonic.
"SignTree"(6
4
progress_messageaction progress message.None(u
s
attr_prefixVthe prefix the signing attributes were declared with.
Ignored when `sctx` is supplied.
"signing_"(-
+
kwargsforwarded to `ctx.actions.run`.(�%signed_outputs�Declares one output artifact per source, plus cosign's sidecar files.

Every source keeps its own shape: a file is signed into a file and a
directory into a directory, both under their source-relative path, rather
than the whole target collapsing into one output tree. Sources routed to
cosign additionally get the `.sig` and `.bundle.json` files that a
detached signature consists of.

Which signer each source is routed to is decided here, and entirely from
what analysis knows: first the rule that builds the file, which reports
whether it is a native binary and in which format, and failing that the
source's name, for files no rule vouched for. The choice is recorded in
the manifest and the action is bound to it, so the files that appear are
always the files declared here, and each source is signed exactly once.

Nothing is re-decided at execution time. A file that reaches a native
signer has its signature embedded and needs no sidecar; one that does not
gets a detached signature and no embedded one. Because the signer is
settled before the build, those two facts can be declared together
instead of one of them being discovered too late to affect the other.

`detached_signatures` overrides the routing question for every source at
once: `"always"` gives each of them a `.sig` and `.bundle.json` whatever
its name, so the output shape stops depending on the sources entirely, and
`"never"` gives none of them any, leaving only the signatures native
signers embed.
*�
�
signed_outputs
ctxthe rule context. (
srcsthe Files to sign. (x
out_nameddirectory the outputs are placed under, relative to the
package. Defaults to `<target name>.signed`.None(N
tool>overrides the `tool` attribute, for rules that pin the signer.None(�
detached_signatureskoverrides the `detached_signatures` attribute,
which decides which sources get `.sig`/`.bundle.json` files.None(I
formats8`File` to binary-format mapping from `binary_formats()`.{}(R
attr_prefix5the prefix the signing attributes were declared with.
"signing_"(�Declares one output artifact per source, plus cosign's sidecar files.

Every source keeps its own shape: a file is signed into a file and a
directory into a directory, both under their source-relative path, rather
than the whole target collapsing into one output tree. Sources routed to
cosign additionally get the `.sig` and `.bundle.json` files that a
detached signature consists of.

Which signer each source is routed to is decided here, and entirely from
what analysis knows: first the rule that builds the file, which reports
whether it is a native binary and in which format, and failing that the
source's name, for files no rule vouched for. The choice is recorded in
the manifest and the action is bound to it, so the files that appear are
always the files declared here, and each source is signed exactly once.

Nothing is re-decided at execution time. A file that reaches a native
signer has its signature embedded and needs no sidecar; one that does not
gets a detached signature and no embedded one. Because the signer is
settled before the build, those two facts can be declared together
instead of one of them being discovered too late to affect the other.

`detached_signatures` overrides the routing question for every source at
once: `"always"` gives each of them a `.sig` and `.bundle.json` whatever
its name, so the output shape stops depending on the sources entirely, and
`"never"` gives none of them any, leaving only the signatures native
signers embed.
"�
�A struct with:

* `files`: every declared output, for `DefaultInfo` and the action.
* `signed`: just the signed counterparts of `srcs`, in `srcs` order,
  without the sidecar files.
* `signers`: dict keyed by source path naming the signer chosen for
  it, to pass to `rel_src_manifest`.
* `out_dir`: the path the action writes the tree under.
* `flatten_single_directory`: what `rel_src_manifest` must be told so
  its relpaths line up with these outputs.
* `require_detached_signatures`: whether sidecar files were declared
  and so have to be produced.2.
signed_outputs//signing/private:action.bzl

ctxthe rule context. ( 

srcsthe Files to sign. (z
x
out_nameddirectory the outputs are placed under, relative to the
package. Defaults to `<target name>.signed`.None(P
N
tool>overrides the `tool` attribute, for rules that pin the signer.None(�
�
detached_signatureskoverrides the `detached_signatures` attribute,
which decides which sources get `.sig`/`.bundle.json` files.None(K
I
formats8`File` to binary-format mapping from `binary_formats()`.{}(T
R
attr_prefix5the prefix the signing attributes were declared with.
"signing_"(�rel_src_manifest�Writes the manifest that pairs each source with its output-relative path.

Passing each (relpath, src) pair as separate `--rel`/`--src` argv tokens
would round-trip file names through the OS's native command-line encoding.
On Windows that's the system's ANSI code page, not UTF-8, so any relpath
character outside it (e.g. non-Latin scripts) arrives at sign_tool
corrupted. Writing the pairs to a manifest file instead keeps them as file
content, which Bazel always writes and Python always reads as UTF-8,
sidestepping the OS argv encoding entirely.
*�
�	
rel_src_manifest
ctxthe rule context. (
srcsthe Files to sign. (M
name=base name for the manifest file; defaults to the target name.None(�
flatten_single_directory�when a lone directory artifact is signed,
write its contents at the root of the output directory instead of
nesting them under the directory's own name. Defaults to doing so.None(�
signers�optional dict keyed by source path, naming the signer whose
outputs the caller has already declared for that source. Recorded
as a third manifest field so the action cannot produce a different
set of files than the one analysis promised.None(�Writes the manifest that pairs each source with its output-relative path.

Passing each (relpath, src) pair as separate `--rel`/`--src` argv tokens
would round-trip file names through the OS's native command-line encoding.
On Windows that's the system's ANSI code page, not UTF-8, so any relpath
character outside it (e.g. non-Latin scripts) arrives at sign_tool
corrupted. Writing the pairs to a manifest file instead keeps them as file
content, which Bazel always writes and Python always reads as UTF-8,
sidestepping the OS argv encoding entirely.
"
The manifest `File`.20
rel_src_manifest//signing/private:action.bzl

ctxthe rule context. ( 

srcsthe Files to sign. (O
M
name=base name for the manifest file; defaults to the target name.None(�
�
flatten_single_directory�when a lone directory artifact is signed,
write its contents at the root of the output directory instead of
nesting them under the directory's own name. Defaults to doing so.None(�
�
signers�optional dict keyed by source path, naming the signer whose
outputs the caller has already declared for that source. Recorded
as a third manifest field so the action cannot produce a different
set of files than the one analysis promised.None(�Public API for driving rules_signing from your own rules.

Load this instead of `defs.bzl` when you are writing a rule that produces a
signable artifact itself and needs to sign it as part of its own build, rather
than composing a separate `sign` target after the fact.

Typical use:

```starlark
load(
    "@rules_signing//signing:actions.bzl",
    "SIGNING_ATTRS",
    "SIGNING_TOOLCHAINS",
    "signing_argv",
    "signing_context",
)

def _my_packager_impl(ctx):
    out = ctx.actions.declare_file(ctx.label.name + ".exe")

    sctx = signing_context(
        ctx,
        require = ["osslsigncode"],
        require_reason = "the generated installer is always a PE executable",
    )

    # Hand the command to whatever tool does the packaging, so it can sign
    # the artifact in place once it has produced it.
    command = signing_argv(sctx, infile = out)

    ctx.actions.run(
        executable = ctx.executable._packager,
        arguments = [...],
        inputs = depset(transitive = [sctx.inputs]),
        tools = sctx.tools,
        outputs = [out],
        env = sctx.env,
    )

my_packager = rule(
    implementation = _my_packager_impl,
    attrs = dict({...}, **SIGNING_ATTRS),
    toolchains = SIGNING_TOOLCHAINS,
)
```

`signing_argv` also builds command lines that sign an artifact into a separate
output (`outfile`), or that sign many files in one pass (`rel_src_manifest`
together with `out_dir`). For the common "sign these files, keep their
layout" case, call `sign_action` and skip building the command line yourself.
Pair it with `signed_outputs` to emit one output artifact per source (plus
cosign's `.sig`/`.bundle.json` sidecars), or give it an `out_dir` tree
artifact to collect everything into a single directory instead.

`SIGNING_TOOLCHAINS` (equivalent to `signing_toolchains()`) declares every
toolchain type this module supports. A rule that structurally can only ever
sign one kind of artifact can call `signing_toolchains()` directly instead,
passing `False` for whichever toolchains it will never need, and pass that
to `toolchains=`. All signing types, including jarsigner and codesign, are
optional and require explicit registration by consumers. Their upstream JDK
and codesign.bzl toolchains are only resolved through registered adapters.
Optional toolchains are not lazy, however: Bazel still analyzes registered
implementations even when no source needs them, so omitting unused types can
avoid those dependencies.Ӣ
signingdefs.bzl�Asign�Signs all files from `src`, preserving relative output structure. Each source keeps its own shape: a file is signed into a file and a directory into a directory, both under their source-relative path. Sources signed with a detached signature (cosign) are accompanied by their `.sig` and `.bundle.json` files, which `detached_signatures` can extend to every source or turn off entirely."�>
� 
sign�Signs all files from `src`, preserving relative output structure. Each source keeps its own shape: a file is signed into a file and a directory into a directory, both under their source-relative path. Sources signed with a detached signature (cosign) are accompanied by their `.sig` and `.bundle.json` files, which `detached_signatures` can extend to every source or turn off entirely.*
nameA unique name for this target. 1
src *&
DefaultInfo
DefaultInfo<native>�
out�Optional name of the directory the signed outputs are placed under, relative to the package. Defaults to `<name>.signed`. The directory itself is not an output; the files inside it are.2""�
tool�Which signer to use, or "auto" (the default) to select one per file: from the rule that builds it where that is known, and otherwise from its extension. Note that "auto" requires every signing toolchain to be registered whenever an input is a directory artifact, because a tree's contents are not known until the action runs. Individual files require only the signers they actually select (plus cosign for forced detached signatures). Registered toolchains are still analyzed even when unused.2"auto"J"osslsigncode"J
"codesign"J"cosign"J"jarsigner"J"auto"�
detached_signatures�Which sources get the `.sig` and `.bundle.json` files a detached signature consists of. "auto" (the default) gives them to the sources no native signer claims, since a detached signature is the only kind they can have, and leaves natively signed artifacts to carry their signature embedded. "always" gives every source both, so the outputs of this target stop depending on what its sources are called, at the cost of a cosign invocation per file and a second signature to distribute keys and verification instructions for; it requires a certificate. "never" emits neither, leaving only the signatures native signers embed and copying through anything that has no native signer.2"auto"J"auto"J"always"J"never"�
certificate�The `certificate` target holding the signing material. Without one, files are copied through unsigned, which keeps builds working for contributors who have no key.*K
SigningCertificateInfo1
SigningCertificateInfo//signing:providers.bzl2None�
timestamp_url�Timestamp authority to countersign with. Empty (the default) does not timestamp, so signing makes no network call and no third party is told when you build. Set to "default" for the well-known authority of the signer in use (Apple's for codesign, DigiCert's for osslsigncode and jarsigner), or to the URL of a specific server. Note that without a timestamp a signature stops validating once the signing certificate expires, so released artifacts usually want one. Ignored by cosign.2""�
transparency_log�Rekor transparency log to publish cosign signatures to. Empty (the default) publishes nothing, so signing stays offline and no hash of your build output leaves the machine. Set to "default" to opt in to the public Sigstore instance, or to the URL of a specific instance (such as a private Rekor deployment). Enabling this makes every signing action a network call.2"":
description%Signature description when supported.2""*
urlPublisher URL when supported.2""4
optionscodesign --options values.2["runtime"]
entitlements2None�
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.2-1J1J0J-1""
sign//signing/private:sign.bzl,
*
nameA unique name for this target. 3
1
src *&
DefaultInfo
DefaultInfo<native>�
�
out�Optional name of the directory the signed outputs are placed under, relative to the package. Defaults to `<name>.signed`. The directory itself is not an output; the files inside it are.2""�
�
tool�Which signer to use, or "auto" (the default) to select one per file: from the rule that builds it where that is known, and otherwise from its extension. Note that "auto" requires every signing toolchain to be registered whenever an input is a directory artifact, because a tree's contents are not known until the action runs. Individual files require only the signers they actually select (plus cosign for forced detached signatures). Registered toolchains are still analyzed even when unused.2"auto"J"osslsigncode"J
"codesign"J"cosign"J"jarsigner"J"auto"�
�
detached_signatures�Which sources get the `.sig` and `.bundle.json` files a detached signature consists of. "auto" (the default) gives them to the sources no native signer claims, since a detached signature is the only kind they can have, and leaves natively signed artifacts to carry their signature embedded. "always" gives every source both, so the outputs of this target stop depending on what its sources are called, at the cost of a cosign invocation per file and a second signature to distribute keys and verification instructions for; it requires a certificate. "never" emits neither, leaving only the signatures native signers embed and copying through anything that has no native signer.2"auto"J"auto"J"always"J"never"�
�
certificate�The `certificate` target holding the signing material. Without one, files are copied through unsigned, which keeps builds working for contributors who have no key.*K
SigningCertificateInfo1
SigningCertificateInfo//signing:providers.bzl2None�
�
timestamp_url�Timestamp authority to countersign with. Empty (the default) does not timestamp, so signing makes no network call and no third party is told when you build. Set to "default" for the well-known authority of the signer in use (Apple's for codesign, DigiCert's for osslsigncode and jarsigner), or to the URL of a specific server. Note that without a timestamp a signature stops validating once the signing certificate expires, so released artifacts usually want one. Ignored by cosign.2""�
�
transparency_log�Rekor transparency log to publish cosign signatures to. Empty (the default) publishes nothing, so signing stays offline and no hash of your build output leaves the machine. Set to "default" to opt in to the public Sigstore instance, or to the URL of a specific instance (such as a private Rekor deployment). Enabling this makes every signing action a network call.2""<
:
description%Signature description when supported.2"",
*
urlPublisher URL when supported.2""6
4
optionscodesign --options values.2["runtime"]

entitlements2None�
�
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.2-1J1J0J-1�certificate�Produces SigningCertificateInfo for signing rules. Evaluates its own `stamp` attribute to resolve a `certificate` template (if used) into a real File once, independently of any `sign` target(s) that consume it."�
�
certificate�Produces SigningCertificateInfo for signing rules. Evaluates its own `stamp` attribute to resolve a `certificate` template (if used) into a real File once, independently of any `sign` target(s) that consume it.*
nameA unique name for this target. O
certificate:Certificate/key template with optional {KEY} placeholders.2""a
certificate_encoding-How to interpret `certificate` when provided.2"path"J"path"J"base64"8
certificate_fileStatic certificate/key file.2None�
ca_file�Optional PEM file holding the intermediate/root certificates that issued this certificate. The chain is embedded in the signature so verifiers can build a trust path back to the root without fetching it themselves. Ignored by cosign, which signs with a bare key rather than an X.509 chain.2NoneE
password3Optional password template with {KEY} placeholders.2""F
password_env0Optional env var name holding the cert password.2""T
identityBOptional Apple codesign identity template with {KEY} placeholders.2""G
stamp_defaults/Fallback map for unresolved {KEY} placeholders.
2{}�
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.2-1J1J0J-1"0
certificate!//signing/private:certificate.bzl,
*
nameA unique name for this target. Q
O
certificate:Certificate/key template with optional {KEY} placeholders.2""c
a
certificate_encoding-How to interpret `certificate` when provided.2"path"J"path"J"base64":
8
certificate_fileStatic certificate/key file.2None�
�
ca_file�Optional PEM file holding the intermediate/root certificates that issued this certificate. The chain is embedded in the signature so verifiers can build a trust path back to the root without fetching it themselves. Ignored by cosign, which signs with a bare key rather than an X.509 chain.2NoneG
E
password3Optional password template with {KEY} placeholders.2""H
F
password_env0Optional env var name holding the cert password.2""V
T
identityBOptional Apple codesign identity template with {KEY} placeholders.2""I
G
stamp_defaults/Fallback map for unresolved {KEY} placeholders.
2{}�
�
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.2-1J1J0J-1�Aself_signed_certificate�Issues a self-signed code-signing certificate during the build and provides it as `SigningCertificateInfo`, so it can be handed to `sign` (or any rule using `//signing:actions.bzl`) wherever a `certificate` target is accepted.

Nothing trusts a certificate that signs itself, so this is for development, tests and internal artifacts -- it makes a signed build reproducible for contributors who have no key, without checking a private key into the repository. Releases still need a real certificate supplied through `certificate`.

Requires the openssl toolchain. Three files are produced: the signing material (a unified PEM holding the private key and the certificate, or a PKCS#12 bundle when `format = "p12"`), the bare certificate as `<name>.crt` for use as a verification trust anchor, and its public key as `<name>.pub` for verifying cosign signatures."�:
�!
self_signed_certificate�Issues a self-signed code-signing certificate during the build and provides it as `SigningCertificateInfo`, so it can be handed to `sign` (or any rule using `//signing:actions.bzl`) wherever a `certificate` target is accepted.

Nothing trusts a certificate that signs itself, so this is for development, tests and internal artifacts -- it makes a signed build reproducible for contributors who have no key, without checking a private key into the repository. Releases still need a real certificate supplied through `certificate`.

Requires the openssl toolchain. Three files are produced: the signing material (a unified PEM holding the private key and the certificate, or a PKCS#12 bundle when `format = "p12"`), the bare certificate as `<name>.crt` for use as a verification trust anchor, and its public key as `<name>.pub` for verifying cosign signatures.*
nameA unique name for this target. |
common_namegCertificate subject common name (CN). Defaults to the target name. Supports `{KEY}` stamp placeholders.2""T
organization>Subject organization (O). Supports `{KEY}` stamp placeholders.2"">
organizational_unit!Subject organizational unit (OU).2""5
country$Subject two-letter country code (C).2"".
stateSubject state or province (ST).2""'
localitySubject locality (L).2""%
emailSubject email address.2""�
subject_alt_namesxSubject alternative names, each written in openssl's own form, for example `DNS:example.com` or `email:dev@example.com`.2[]�
validity_days�How long the certificate stays valid, in days. Note that signatures made without a timestamp stop verifying once the certificate expires.2365^
key_type<Key algorithm. Both RSA and EC are accepted by every signer.2"rsa"J"rsa"J"ec"H
key_size4RSA key size in bits. Ignored for `key_type = "ec"`.22048J
ec_curve.EC curve name. Ignored for `key_type = "rsa"`.2"prime256v1"d
digest0Digest used for the certificate's own signature.2"sha256"J"sha256"J"sha384"J"sha512"�
format�Shape of the generated signing material. `pem` (the default) writes the private key and certificate into one unencrypted file, which every signer reads directly. `p12` writes a PKCS#12 bundle protected by `password`; cosign then needs the openssl toolchain to convert it, which this rule already requires.2"pem"J"pem"J"p12"�
password�Password protecting the PKCS#12 bundle when `format = "p12"`. Supports `{KEY}` stamp placeholders. Ignored for `format = "pem"`, whose private key is written unencrypted because the signers cannot decrypt it.2""�
password_env�Name of an environment variable holding the PKCS#12 password, used when `password` is not set. The variable must reach the action (for example with `--action_env`).2""s
identityaOptional Apple codesign identity template passed through to consumers, with `{KEY}` placeholders.2""M

key_usages'X.509 keyUsage values, marked critical.2["digitalSignature"]�
extended_key_usages�X.509 extendedKeyUsage values. `codeSigning` alone is what every signer expects; Apple-specific critical extensions are deliberately not added, since osslsigncode rejects them.2["codeSigning"]I
stamp_defaults1Fallback map for unresolved `{KEY}` placeholders.
2{}�
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.2-1J1J0J-1"H
self_signed_certificate-//signing/private:self_signed_certificate.bzl*K
SigningCertificateInfo1
SigningCertificateInfo//signing:providers.bzl,
*
nameA unique name for this target. ~
|
common_namegCertificate subject common name (CN). Defaults to the target name. Supports `{KEY}` stamp placeholders.2""V
T
organization>Subject organization (O). Supports `{KEY}` stamp placeholders.2""@
>
organizational_unit!Subject organizational unit (OU).2""7
5
country$Subject two-letter country code (C).2""0
.
stateSubject state or province (ST).2"")
'
localitySubject locality (L).2""'
%
emailSubject email address.2""�
�
subject_alt_namesxSubject alternative names, each written in openssl's own form, for example `DNS:example.com` or `email:dev@example.com`.2[]�
�
validity_days�How long the certificate stays valid, in days. Note that signatures made without a timestamp stop verifying once the certificate expires.2365`
^
key_type<Key algorithm. Both RSA and EC are accepted by every signer.2"rsa"J"rsa"J"ec"J
H
key_size4RSA key size in bits. Ignored for `key_type = "ec"`.22048L
J
ec_curve.EC curve name. Ignored for `key_type = "rsa"`.2"prime256v1"f
d
digest0Digest used for the certificate's own signature.2"sha256"J"sha256"J"sha384"J"sha512"�
�
format�Shape of the generated signing material. `pem` (the default) writes the private key and certificate into one unencrypted file, which every signer reads directly. `p12` writes a PKCS#12 bundle protected by `password`; cosign then needs the openssl toolchain to convert it, which this rule already requires.2"pem"J"pem"J"p12"�
�
password�Password protecting the PKCS#12 bundle when `format = "p12"`. Supports `{KEY}` stamp placeholders. Ignored for `format = "pem"`, whose private key is written unencrypted because the signers cannot decrypt it.2""�
�
password_env�Name of an environment variable holding the PKCS#12 password, used when `password` is not set. The variable must reach the action (for example with `--action_env`).2""u
s
identityaOptional Apple codesign identity template passed through to consumers, with `{KEY}` placeholders.2""O
M

key_usages'X.509 keyUsage values, marked critical.2["digitalSignature"]�
�
extended_key_usages�X.509 extendedKeyUsage values. `codeSigning` alone is what every signer expects; Apple-specific critical extensions are deliberately not added, since osslsigncode rejects them.2["codeSigning"]K
I
stamp_defaults1Fallback map for unresolved `{KEY}` placeholders.
2{}�
�
stamp�Whether to encode build information into the output. Possible values:

- `stamp = 1`: Always stamp the build information into the output, even in
    [--nostamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) builds.
    This setting should be avoided, since it is non-deterministic.
    It potentially causes remote cache misses for the target and
    any downstream actions that depend on the result.
- `stamp = 0`: Never stamp, instead replace build information by constant values.
    This gives good build result caching.
- `stamp = -1`: Embedding of build information is controlled by the
    [--[no]stamp](https://docs.bazel.build/versions/main/user-manual.html#flag--stamp) flag.
    Stamped targets are not rebuilt unless their dependencies change.2-1J1J0J-1�
signingextensions.bzl�signing_toolsJ�
�
signing_toolsp
cosign
version2""'
urlshost_key -> URL override.
2{},
sha256host_key -> sha256 override.
2{}�
osslsigncode
version2""'
urlshost_key -> URL override.
2{},
sha256host_key -> sha256 override.
2{}8
strip_prefix"host_key -> strip_prefix override.
2{}�
openssl�
path�Path to an openssl binary already installed on the host, or a bare program name to resolve against PATH. Takes precedence over `label`.2""�
label�Target providing an openssl binary, built by another module. Only resolved when `path` is unset, so callers who adopt a host binary never need to depend on that module.2None"" //signing/private:extensions.bzl�
p
cosign
version2""'
urlshost_key -> URL override.
2{},
sha256host_key -> sha256 override.
2{}

version2"")
'
urlshost_key -> URL override.
2{}.
,
sha256host_key -> sha256 override.
2{}�
�
osslsigncode
version2""'
urlshost_key -> URL override.
2{},
sha256host_key -> sha256 override.
2{}8
strip_prefix"host_key -> strip_prefix override.
2{}

version2"")
'
urlshost_key -> URL override.
2{}.
,
sha256host_key -> sha256 override.
2{}:
8
strip_prefix"host_key -> strip_prefix override.
2{}�
�
openssl�
path�Path to an openssl binary already installed on the host, or a bare program name to resolve against PATH. Takes precedence over `label`.2""�
label�Target providing an openssl binary, built by another module. Only resolved when `path` is unset, so callers who adopt a host binary never need to depend on that module.2None�
�
path�Path to an openssl binary already installed on the host, or a bare program name to resolve against PATH. Takes precedence over `label`.2""�
�
label�Target providing an openssl binary, built by another module. Only resolved when `path` is unset, so callers who adopt a host binary never need to depend on that module.2None�

signingproviders.bzl�
SigningCertificateInfo,Signing material and interpolation settings.2�	
�
SigningCertificateInfo,Signing material and interpolation settings.�
certificate�Optional File containing already-resolved cert/key material: either the direct `certificate_file`, or the output of stamping and decoding a `certificate` template. Consumers never see raw templates.9
ca_file.Optional File containing the issuing CA chain.?
password3Optional password template with {KEY} placeholders.:
password_env*Optional env var name containing password.E
identity9Optional Apple identity template with {KEY} placeholders.C
stamp_defaults1Dict of default values for unresolved stamp keys."1
SigningCertificateInfo//signing:providers.bzl�
�
certificate�Optional File containing already-resolved cert/key material: either the direct `certificate_file`, or the output of stamping and decoding a `certificate` template. Consumers never see raw templates.;
9
ca_file.Optional File containing the issuing CA chain.A
?
password3Optional password template with {KEY} placeholders.<
:
password_env*Optional env var name containing password.G
E
identity9Optional Apple identity template with {KEY} placeholders.E
C
stamp_defaults1Dict of default values for unresolved stamp keys.+
)signing/toolchainscosign_versions.bzl1
/signing/toolchainsosslsigncode_versions.bzl�
&signing/toolchainsrepositories.bzl�cosign_repo<Repository rule that downloads cosign for the host platform.R�
�
cosign_repo<Repository rule that downloads cosign for the host platform..
name"A unique name for this repository. 
version2"3.1.3"
urls
2{}
sha256
2{}*4
cosign_repo%//signing/toolchains:repositories.bzl0
.
name"A unique name for this repository. 

version2"3.1.3"

urls
2{}

sha256
2{}�osslsigncode_repoBRepository rule that downloads osslsigncode for the host platform.R�
�
osslsigncode_repoBRepository rule that downloads osslsigncode for the host platform..
name"A unique name for this repository. 
version2"2.14"
urls
2{}
sha256
2{}
strip_prefix
2{}*:
osslsigncode_repo%//signing/toolchains:repositories.bzl0
.
name"A unique name for this repository. 

version2"2.14"

urls
2{}

sha256
2{}

strip_prefix
2{}�openssl_local_repozRepository rule that adopts an openssl binary already present on the host, either at a literal path or resolved from PATH.R�
�
openssl_local_repozRepository rule that adopts an openssl binary already present on the host, either at a literal path or resolved from PATH..
name"A unique name for this repository. 

path *;
openssl_local_repo%//signing/toolchains:repositories.bzl0
.
name"A unique name for this repository. 


path �openssl_label_repoERepository rule that wraps an openssl binary built by another module.R�
�
openssl_label_repoERepository rule that wraps an openssl binary built by another module..
name"A unique name for this repository. 
label *;
openssl_label_repo%//signing/toolchains:repositories.bzl0
.
name"A unique name for this repository. 

label �!
$signing/toolchainstoolchains.bzl�codesign_bzl_toolMExposes the rcodesign binary selected by codesign.bzl's toolchain resolution."�
�
codesign_bzl_toolMExposes the rcodesign binary selected by codesign.bzl's toolchain resolution.*
nameA unique name for this target. "8
codesign_bzl_tool#//signing/toolchains:toolchains.bzl,
*
nameA unique name for this target. �	codesign_toolchain�Provides an optional Apple signing toolchain using rcodesign.

By default, codesign.bzl selects the executable for the execution platform.
Set codesign to a custom rcodesign binary to bypass that resolution entirely.
Apple's /usr/bin/codesign has a different CLI and is not supported by this adapter."�
�
codesign_toolchain�Provides an optional Apple signing toolchain using rcodesign.

By default, codesign.bzl selects the executable for the execution platform.
Set codesign to a custom rcodesign binary to bypass that resolution entirely.
Apple's /usr/bin/codesign has a different CLI and is not supported by this adapter.*
nameA unique name for this target. {
codesignHAn rcodesign executable, or a target exposing one file and its runfiles.2#"//signing/toolchains:codesign_bzl"F
data8Additional runtime files needed by the rcodesign binary.2[]"9
codesign_toolchain#//signing/toolchains:toolchains.bzl**
ToolchainInfo
ToolchainInfo<native>,
*
nameA unique name for this target. }
{
codesignHAn rcodesign executable, or a target exposing one file and its runfiles.2#"//signing/toolchains:codesign_bzl"H
F
data8Additional runtime files needed by the rcodesign binary.2[]�jarsigner_toolchain�Adapts a Bazel/rules_java JDK runtime to the optional jarsigner toolchain.

The default runtime uses Bazel's Java toolchain resolution for the execution
platform, controlled by --tool_java_runtime_version. Set java_runtime to a
java_runtime target to use a specific local, downloaded, or custom JDK instead.
ToolchainInfo exposes tool (jarsigner), data (the full JDK), and java_runtime."�
�
jarsigner_toolchain�Adapts a Bazel/rules_java JDK runtime to the optional jarsigner toolchain.

The default runtime uses Bazel's Java toolchain resolution for the execution
platform, controlled by --tool_java_runtime_version. Set java_runtime to a
java_runtime target to use a specific local, downloaded, or custom JDK instead.
ToolchainInfo exposes tool (jarsigner), data (the full JDK), and java_runtime.*
nameA unique name for this target. �
java_runtimeUA Java runtime exposing ToolchainInfo.java_runtime, built for the execution platform.**
ToolchainInfo
ToolchainInfo<native>2."@bazel_tools//tools/jdk:current_java_runtime"":
jarsigner_toolchain#//signing/toolchains:toolchains.bzl**
ToolchainInfo
ToolchainInfo<native>,
*
nameA unique name for this target. �
�
java_runtimeUA Java runtime exposing ToolchainInfo.java_runtime, built for the execution platform.**
ToolchainInfo
ToolchainInfo<native>2."@bazel_tools//tools/jdk:current_java_runtime"�cosign_toolchain"�
�
cosign_toolchain*
nameA unique name for this target. 
cosign "7
cosign_toolchain#//signing/toolchains:toolchains.bzl**
ToolchainInfo
ToolchainInfo<native>,
*
nameA unique name for this target. 

cosign �osslsigncode_toolchain"�
�
osslsigncode_toolchain*
nameA unique name for this target. 
osslsigncode 
default_timestamp_url2"""=
osslsigncode_toolchain#//signing/toolchains:toolchains.bzl**
ToolchainInfo
ToolchainInfo<native>,
*
nameA unique name for this target. 

osslsigncode 

default_timestamp_url2""�openssl_toolchainCOptional toolchain used to convert PKCS#12 signing material to PEM."�
�
openssl_toolchainCOptional toolchain used to convert PKCS#12 signing material to PEM.*
nameA unique name for this target. 
openssl f
dataXExtra files openssl needs alongside it at runtime (e.g. Windows' libcrypto/libssl DLLs).2[]"8
openssl_toolchain#//signing/toolchains:toolchains.bzl**
ToolchainInfo
ToolchainInfo<native>,
*
nameA unique name for this target. 

openssl h
f
dataXExtra files openssl needs alongside it at runtime (e.g. Windows' libcrypto/libssl DLLs).2[]$
"signing/toolchainsversions.bzl 