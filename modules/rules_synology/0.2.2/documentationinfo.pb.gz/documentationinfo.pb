�
*
rules_synologybzlgo_dependencies.bzltgo_dependencies*_
O
go_dependencies2<
go_dependencies)@@rules_synology//bzl:go_dependencies.bzl
`
	:deps.bzlrQ

gazelledeps.bzl,
go_repositorygo_repository
+
-�
'
rules_synologyconfigplatforms.bzl	MINOR_VERSIONSj	2
7.1n	MINOR_VERSIONS_WITH_DUPESjO2M
7.1
7.1
7.1
7.1
7.1
7.1
7.1
7.1
7.1
7.1
7.1	PATCH_VERSIONSj2	
7.1.1�	PATCH_VERSIONS_WITH_DUPESje2c
7.1.1
7.1.1
7.1.1
7.1.1
7.1.1
7.1.1
7.1.1
7.1.1
7.1.1
7.1.1
7.1.1�9
.
rules_synologysynologydocker-project.bzl�docker_project�
## Configure a collection of Docker Projects

The Docker Project is a [Worker](glossary.md#worker) that carries one or more docker-compose
definitions into a Synology NAS, and can be used to turn-up the project defined in the compose
files.

Each project's name and compose file are represented as a `docker_compose()` target; these targets
are collected in an list `projects` in a `docker_project()` target.

For example:

(`BUILD` file)
```
docker_compose(
    name = "nginx"
    compose = ":dc.yaml",
)

docker_compose(
    name = "cryptobot"
    compose = ":some_other_compose.yaml",
)

docker_project(
    name = "green_stack",
    projects = [ ":nginx", "cryptobot" ]
)
```

References:

- [Synology: Docker Project](https://help.synology.com/developer-guide/resource_acquisition/docker-project.html)
"�

�
docker_project�
## Configure a collection of Docker Projects

The Docker Project is a [Worker](glossary.md#worker) that carries one or more docker-compose
definitions into a Synology NAS, and can be used to turn-up the project defined in the compose
files.

Each project's name and compose file are represented as a `docker_compose()` target; these targets
are collected in an list `projects` in a `docker_project()` target.

For example:

(`BUILD` file)
```
docker_compose(
    name = "nginx"
    compose = ":dc.yaml",
)

docker_compose(
    name = "cryptobot"
    compose = ":some_other_compose.yaml",
)

docker_project(
    name = "green_stack",
    projects = [ ":nginx", "cryptobot" ]
)
```

References:

- [Synology: Docker Project](https://help.synology.com/developer-guide/resource_acquisition/docker-project.html)
*
nameA unique name for this target. H
preload_image1OCI/Docker image to preload at install of the SPK2""]
projects:List of docker_compose() targets to bundle to this project*
DockerCompose2[]"?
docker_project-@@rules_synology//synology:docker-project.bzl
cc,
*
nameA unique name for this target. J
H
preload_image1OCI/Docker image to preload at install of the SPK2""_
]
projects:List of docker_compose() targets to bundle to this project*
DockerCompose2[]�docker_compose�## Configure a single Docker Project (a docker-compose)

The Docker Project is a [Worker](glossary.md#worker) that carries one or more docker-compose
definitions into a Synology NAS, and can be used to turn-up the project defined in the compose
files.

The Synology Docker Project Worker expects a name and a compose file for each project.
docker_compose() is used to provide a name/compose pair, which are then collected in a
docker_project() target:

(`BUILD` file)
```
docker_compose(
    name = "nginx"
    compose = ":dc.yaml",
)

docker_compose(
    name = "cryptobot"
    compose = ":some_other_compose.yaml",
)

docker_project(
    name = "green_stack",
    projects = [ ":nginx", "cryptobot" ]
)
```

References:

- [Synology: Docker Project](https://help.synology.com/developer-guide/resource_acquisition/docker-project.html)*�
�
docker_compose

name (
compose (
project_nameNone(
pathNone(
debugFalse(�## Configure a single Docker Project (a docker-compose)

The Docker Project is a [Worker](glossary.md#worker) that carries one or more docker-compose
definitions into a Synology NAS, and can be used to turn-up the project defined in the compose
files.

The Synology Docker Project Worker expects a name and a compose file for each project.
docker_compose() is used to provide a name/compose pair, which are then collected in a
docker_project() target:

(`BUILD` file)
```
docker_compose(
    name = "nginx"
    compose = ":dc.yaml",
)

docker_compose(
    name = "cryptobot"
    compose = ":some_other_compose.yaml",
)

docker_project(
    name = "green_stack",
    projects = [ ":nginx", "cryptobot" ]
)
```

References:

- [Synology: Docker Project](https://help.synology.com/developer-guide/resource_acquisition/docker-project.html)2?
docker_compose-@@rules_synology//synology:docker-project.bzl
��"_docker_compose2_docker_compose�DockerCompose2�
�
DockerCompose=
name5A human-readable name for a docker-compose definitionD
file<The file that carries the docker-compose for this definition$
pathThe path of the compose file">
DockerCompose-@@rules_synology//synology:docker-project.bzl
&&?
=
name5A human-readable name for a docker-compose definitionF
D
file<The file that carries the docker-compose for this definition&
$
pathThe path of the compose file�DockerProject2�
�
DockerProject�
preload_imageoA docker image stream that can be 'docker load' to the local docker engine before activating the compose actionc
projectsWA list of { name, path } naming compose projects and the relative paths containing themv
structlA verbatim instance of a 'docker-project' for the resource file: encompasses both preload_image and projects">
DockerProject-@@rules_synology//synology:docker-project.bzl
�
�
preload_imageoA docker image stream that can be 'docker load' to the local docker engine before activating the compose actione
c
projectsWA list of { name, path } naming compose projects and the relative paths containing themx
v
structlA verbatim instance of a 'docker-project' for the resource file: encompasses both preload_image and projectsu
//rules:copy_file.bzlrZ
$
bazel_skylibrulescopy_file.bzl$
	copy_file	copy_file
-6
8v
//pkg/private/tar:tar.bzlrW
%
	rules_pkgpkg/private/tartar.bzl 
pkg_tarpkg_tar
.5
7�	doc�
## Configure a collection of Docker Projects

The Docker Project is a [Worker](glossary.md#worker) that carries one or more docker-compose
definitions into a Synology NAS, and can be used to turn-up the project defined in the compose
files.

Each project's name and compose file are represented as a `docker_compose()` target; these targets
are collected in an list `projects` in a `docker_project()` target.

For example:

(`BUILD` file)
```
docker_compose(
    name = "nginx"
    compose = ":dc.yaml",
)

docker_compose(
    name = "cryptobot"
    compose = ":some_other_compose.yaml",
)

docker_project(
    name = "green_stack",
    projects = [ ":nginx", "cryptobot" ]
)
```

References:

- [Synology: Docker Project](https://help.synology.com/developer-guide/resource_acquisition/docker-project.html)
j��
## Configure a collection of Docker Projects

The Docker Project is a [Worker](glossary.md#worker) that carries one or more docker-compose
definitions into a Synology NAS, and can be used to turn-up the project defined in the compose
files.

Each project's name and compose file are represented as a `docker_compose()` target; these targets
are collected in an list `projects` in a `docker_project()` target.

For example:

(`BUILD` file)
```
docker_compose(
    name = "nginx"
    compose = ":dc.yaml",
)

docker_compose(
    name = "cryptobot"
    compose = ":some_other_compose.yaml",
)

docker_project(
    name = "green_stack",
    projects = [ ":nginx", "cryptobot" ]
)
```

References:

- [Synology: Docker Project](https://help.synology.com/developer-guide/resource_acquisition/docker-project.html)
�
&
rules_synologysynology
images.bzl�images7Create a filegroup of resized images: 16x16, 24x24, etc"�
�
images7Create a filegroup of resized images: 16x16, 24x24, etc*
nameA unique name for this target. �
images_template�template for output files: use a string with a single {} that will be replaced with the size.  The template should end with a suffix that determines the resulting format: .png, .jpg, .PNG, etc.  Note that Synology SPK packaging requires files of the form PACKAGE_ICON_<size>.PNG so changing this should ential converting the result back however desired for the payload of the SPK.2""�
sizes_sizes to convert: use a list of ints, each of which is a desired size of a square bounding box.2&[16, 24, 32, 48, 64, 72, 90, 120, 256]<
src1Initial source image to convert to various sizes. n
verboseZVerbosity can enable some debug messages from //tools:resize that can help resolve errors.2False"/
images%@@rules_synology//synology:images.bzl
,
*
nameA unique name for this target. �
�
images_template�template for output files: use a string with a single {} that will be replaced with the size.  The template should end with a suffix that determines the resulting format: .png, .jpg, .PNG, etc.  Note that Synology SPK packaging requires files of the form PACKAGE_ICON_<size>.PNG so changing this should ential converting the result back however desired for the payload of the SPK.2""�
�
sizes_sizes to convert: use a list of ints, each of which is a desired size of a square bounding box.2&[16, 24, 32, 48, 64, 72, 90, 120, 256]>
<
src1Initial source image to convert to various sizes. p
n
verboseZVerbosity can enable some debug messages from //tools:resize that can help resolve errors.2False��
)
rules_synologysynologyinfo-file.bzl�G	info_file�## Create an INFO file

The INFO file is the simple metadata k/v dict of the SPK: a number of `key=value` pairs that define
attributes of the package.

This file is needed to inform the Synology NAS of the name and unique ID of the package, quote
maintainers and distributors, and indicate architecture and OS constraints to install.  I
personally expect that the simple format of this file allows the UI to show install dialogs with
minimal complexity.

Likely the reader will notice that the `maintainer()` block collects more information than it needs
to for the `INFO` file: the additional URL is optional, but can help track down a maintainer if a
user or collaborator needs to find them.  This is not necessarily intended to be the upstream
URL(s) of a project (ie github pages, docker URLs,etc) but is intended to be a valid URL that can
help precisely identify where the preferred path to find that maintainer.

This implementation mimics the defaults from Synology's documentation so that the bare minimum
attributes can be provided to unblock immediate progress.

### Examples

(`BUILD` file)
```
load("@//:defs.bzl", "info_file", "maintainer")

maintainer(
    name = "chickenandpork",
    maintainer_name = "Allan Clark",
    maintainer_url = "http://linkedin.com/in/goldfish",
    visibility = ["//visibility:public"],
)

info_file(
    name = "floppydog_info",
    package_name = "FloppyDog",
    description = "Provides the FloppyDog set of CLI tools for Great Justice",
    maintainer = ":chickenandpork",
    os_min_ver = "7.0-1",  # correct-format=[^\d+(\.\d+){1,2}(-\d+){1,2}$]
    package_version = "1.0.0-1",
)
```

The `INFO` file generated by this looks similar to:
```
package="FloppyDog"
version="1.0.0-1"
os_min_ver="7.0-1"
description="Provides the FloppyDog set of CLI tools for Great Justice"
maintainer="Allan Clark"
arch="noarch"
ctl_stop="yes"
startable="yes"
thirdparty="yes"
```

`info_file()` uses [maintainer()](docs.md#maintainer) to carry information about the package's
maintainer: referring to a maintainer by target ID allows greatest re-use of a DRY data element,
and should allow the author to associate a maintainer globally maintained in a dependency resource:

(`MODULE.bazel`)
```
bazel_dep(name = "firehydrant_stuff", version = "1.2.3")
```
(`BUILD.bazel`)
```
info_file(
    name = "firehydrant_info",
    package_name = "FireHydrant",
    description = "A great Incident-Management resource made by SREs for SREs",
    maintainer = "@firehydrant_stuff//maint:robertross",
    os_min_ver = "7.0-1",  # correct-format=[^\d+(\.\d+){1,2}(-\d+){1,2}$]
    package_version = "1.0.0-1",
)
```

Ref:
* [Synology: INFO](https://help.synology.com/developer-guide/synology_package/INFO.html)
"�1
�#
	info_file�## Create an INFO file

The INFO file is the simple metadata k/v dict of the SPK: a number of `key=value` pairs that define
attributes of the package.

This file is needed to inform the Synology NAS of the name and unique ID of the package, quote
maintainers and distributors, and indicate architecture and OS constraints to install.  I
personally expect that the simple format of this file allows the UI to show install dialogs with
minimal complexity.

Likely the reader will notice that the `maintainer()` block collects more information than it needs
to for the `INFO` file: the additional URL is optional, but can help track down a maintainer if a
user or collaborator needs to find them.  This is not necessarily intended to be the upstream
URL(s) of a project (ie github pages, docker URLs,etc) but is intended to be a valid URL that can
help precisely identify where the preferred path to find that maintainer.

This implementation mimics the defaults from Synology's documentation so that the bare minimum
attributes can be provided to unblock immediate progress.

### Examples

(`BUILD` file)
```
load("@//:defs.bzl", "info_file", "maintainer")

maintainer(
    name = "chickenandpork",
    maintainer_name = "Allan Clark",
    maintainer_url = "http://linkedin.com/in/goldfish",
    visibility = ["//visibility:public"],
)

info_file(
    name = "floppydog_info",
    package_name = "FloppyDog",
    description = "Provides the FloppyDog set of CLI tools for Great Justice",
    maintainer = ":chickenandpork",
    os_min_ver = "7.0-1",  # correct-format=[^\d+(\.\d+){1,2}(-\d+){1,2}$]
    package_version = "1.0.0-1",
)
```

The `INFO` file generated by this looks similar to:
```
package="FloppyDog"
version="1.0.0-1"
os_min_ver="7.0-1"
description="Provides the FloppyDog set of CLI tools for Great Justice"
maintainer="Allan Clark"
arch="noarch"
ctl_stop="yes"
startable="yes"
thirdparty="yes"
```

`info_file()` uses [maintainer()](docs.md#maintainer) to carry information about the package's
maintainer: referring to a maintainer by target ID allows greatest re-use of a DRY data element,
and should allow the author to associate a maintainer globally maintained in a dependency resource:

(`MODULE.bazel`)
```
bazel_dep(name = "firehydrant_stuff", version = "1.2.3")
```
(`BUILD.bazel`)
```
info_file(
    name = "firehydrant_info",
    package_name = "FireHydrant",
    description = "A great Incident-Management resource made by SREs for SREs",
    maintainer = "@firehydrant_stuff//maint:robertross",
    os_min_ver = "7.0-1",  # correct-format=[^\d+(\.\d+){1,2}(-\d+){1,2}$]
    package_version = "1.0.0-1",
)
```

Ref:
* [Synology: INFO](https://help.synology.com/developer-guide/synology_package/INFO.html)
*
nameA unique name for this target. g
arch_stringsIarray of architectures (strings): [ "alpine", ...] (default: ["noarch"]).2
["noarch"]�
ctl_stopwIndicates (boolean) whether there is a start-stop-script and the SPK can be started or stopped (previously: startable).2True�
description�Brief description of the package: copy-paste from the upstream if permissible.  Although this is permitted be a looooong single-line string, it does display on the UIs to install a package, so brevity is still encouraged. o

maintainerOMaintainer of the build logic for the component (primary if multiple, a person) *

Maintainer�

os_min_ver�Earliest version of DSM that can install the package; ie "DSM 7.1.1-42962".  " +
"There seems to be no handling of the extended hard-to-parse suffixes used by " +
"Synology such as "DSM 7.1.1-42962 Update 6". \
outSName of the Info file, if INFO is not preferred (changing this is not recommended).o
package_name[Name of the package, unique within Synology SPKs, hopefully resembles external package name �
package_version�Version of the package; although I recommend semver-ish X.Y.Z-BUILDNUM, Synology describes as being any string of numbers separated by periods, dash, or underscore, but will later fail anything outside the pattern of (0-9]+\.){1-5}[-[0-9]+] (essentially 1-5 dot-separated digits with an optional hyphen and number of up to 5 digits: 1.2.3.4.5-56789) �
validation_softfail�Redirects fatal validation failures into either debug messages or ignored/unprinted in case of inaccuracy in any validation step, or workarounds, or unittesting.  Choice of ['fail', 'message', 'ignored'].  This should likely remain the default value.2"fail""5
	info_file(@@rules_synology//synology:info-file.bzl
��,
*
nameA unique name for this target. i
g
arch_stringsIarray of architectures (strings): [ "alpine", ...] (default: ["noarch"]).2
["noarch"]�
�
ctl_stopwIndicates (boolean) whether there is a start-stop-script and the SPK can be started or stopped (previously: startable).2True�
�
description�Brief description of the package: copy-paste from the upstream if permissible.  Although this is permitted be a looooong single-line string, it does display on the UIs to install a package, so brevity is still encouraged. q
o

maintainerOMaintainer of the build logic for the component (primary if multiple, a person) *

Maintainer�
�

os_min_ver�Earliest version of DSM that can install the package; ie "DSM 7.1.1-42962".  " +
"There seems to be no handling of the extended hard-to-parse suffixes used by " +
"Synology such as "DSM 7.1.1-42962 Update 6". ^
\
outSName of the Info file, if INFO is not preferred (changing this is not recommended).q
o
package_name[Name of the package, unique within Synology SPKs, hopefully resembles external package name �
�
package_version�Version of the package; although I recommend semver-ish X.Y.Z-BUILDNUM, Synology describes as being any string of numbers separated by periods, dash, or underscore, but will later fail anything outside the pattern of (0-9]+\.){1-5}[-[0-9]+] (essentially 1-5 dot-separated digits with an optional hyphen and number of up to 5 digits: 1.2.3.4.5-56789) �
�
validation_softfail�Redirects fatal validation failures into either debug messages or ignored/unprinted in case of inaccuracy in any validation step, or workarounds, or unittesting.  Choice of ['fail', 'message', 'ignored'].  This should likely remain the default value.2"fail"}info_file_impl*i
W
info_file_impl	
ctx (2:
info_file_impl(@@rules_synology//synology:info-file.bzl
��lnoprint*_
M
noprint
message (23
noprint(@@rules_synology//synology:info-file.bzl
���valid_version�Pre-check that the given version is valid for Synology

Despite how standards are better if we all adhere to them -- pick one, don't make a new one --
I'm not checking due to any bias about formats: *SYNOLOGY* accepts only a specific format here.

synopkg will report an error if the version in an INFO file does not match the correct
format=[^\d+(\.\d+){0,5}(-\d+)?$] -- problem is, Bazel not supporting regex, the steps to check
this are more complex:

1. split across the "-": confirm either 1 or two results; fail otherwise
2. confirm that the second item of the "-" split is all numbers; fail otherwise
3. split the first  item of the "-" split by decimal
4. confirm that the decimal-split has 6 or fewer items; fail otherwise
5. confirmthat each of the results of the decimal-split are all just numbers*�
�
valid_version
version (
_print (�Pre-check that the given version is valid for Synology

Despite how standards are better if we all adhere to them -- pick one, don't make a new one --
I'm not checking due to any bias about formats: *SYNOLOGY* accepts only a specific format here.

synopkg will report an error if the version in an INFO file does not match the correct
format=[^\d+(\.\d+){0,5}(-\d+)?$] -- problem is, Bazel not supporting regex, the steps to check
this are more complex:

1. split across the "-": confirm either 1 or two results; fail otherwise
2. confirm that the second item of the "-" split is all numbers; fail otherwise
3. split the first  item of the "-" split by decimal
4. confirm that the decimal-split has 6 or fewer items; fail otherwise
5. confirmthat each of the results of the decimal-split are all just numbers29
valid_version(@@rules_synology//synology:info-file.bzl
TT�InfoFile2�
�
InfoFile[
packagePA unique name for the package: no namespacing,might clash with other definitionsk
version`Package Version: a dotted-integer version with an optional hyphenated suffice number: 4.2.4-2668v

os_min_verhMinimum DSM version that can install this package: a string without clear constraints: 'DSM 7.1.1-42962'g
descriptionXA brief description of the Package: it may be multiline, but should be brief and concisep

maintainerbThe name of the maintainer: we draw this from a Maintainer provider from the 'maintainer()' target}
maintainer_urlkThe email address of the maintainer: we draw this from a Maintainer provider from the 'maintainer()' target^
archVSpace-separated text indicating compatible architectures for this SPK: 'noarch x86_64'�
ctl_stoptBoolean: is there a start-stop-status script to allow the SPK to start or stop? (writes both startable and ctl_stop)Y

thirdpartyKBoolean: is this SPK built outside of Synology corporation? (typically yes)"4
InfoFile(@@rules_synology//synology:info-file.bzl
yy]
[
packagePA unique name for the package: no namespacing,might clash with other definitionsm
k
version`Package Version: a dotted-integer version with an optional hyphenated suffice number: 4.2.4-2668x
v

os_min_verhMinimum DSM version that can install this package: a string without clear constraints: 'DSM 7.1.1-42962'i
g
descriptionXA brief description of the Package: it may be multiline, but should be brief and conciser
p

maintainerbThe name of the maintainer: we draw this from a Maintainer provider from the 'maintainer()' target
}
maintainer_urlkThe email address of the maintainer: we draw this from a Maintainer provider from the 'maintainer()' target`
^
archVSpace-separated text indicating compatible architectures for this SPK: 'noarch x86_64'�
�
ctl_stoptBoolean: is there a start-stop-status script to allow the SPK to start or stop? (writes both startable and ctl_stop)[
Y

thirdpartyKBoolean: is this SPK built outside of Synology corporation? (typically yes)�
//synology:maintainer.bzlrb
*
rules_synologysynologymaintainer.bzl&

Maintainer
Maintainer
3=
?�*	doc�## Create an INFO file

The INFO file is the simple metadata k/v dict of the SPK: a number of `key=value` pairs that define
attributes of the package.

This file is needed to inform the Synology NAS of the name and unique ID of the package, quote
maintainers and distributors, and indicate architecture and OS constraints to install.  I
personally expect that the simple format of this file allows the UI to show install dialogs with
minimal complexity.

Likely the reader will notice that the `maintainer()` block collects more information than it needs
to for the `INFO` file: the additional URL is optional, but can help track down a maintainer if a
user or collaborator needs to find them.  This is not necessarily intended to be the upstream
URL(s) of a project (ie github pages, docker URLs,etc) but is intended to be a valid URL that can
help precisely identify where the preferred path to find that maintainer.

This implementation mimics the defaults from Synology's documentation so that the bare minimum
attributes can be provided to unblock immediate progress.

### Examples

(`BUILD` file)
```
load("@//:defs.bzl", "info_file", "maintainer")

maintainer(
    name = "chickenandpork",
    maintainer_name = "Allan Clark",
    maintainer_url = "http://linkedin.com/in/goldfish",
    visibility = ["//visibility:public"],
)

info_file(
    name = "floppydog_info",
    package_name = "FloppyDog",
    description = "Provides the FloppyDog set of CLI tools for Great Justice",
    maintainer = ":chickenandpork",
    os_min_ver = "7.0-1",  # correct-format=[^\d+(\.\d+){1,2}(-\d+){1,2}$]
    package_version = "1.0.0-1",
)
```

The `INFO` file generated by this looks similar to:
```
package="FloppyDog"
version="1.0.0-1"
os_min_ver="7.0-1"
description="Provides the FloppyDog set of CLI tools for Great Justice"
maintainer="Allan Clark"
arch="noarch"
ctl_stop="yes"
startable="yes"
thirdparty="yes"
```

`info_file()` uses [maintainer()](docs.md#maintainer) to carry information about the package's
maintainer: referring to a maintainer by target ID allows greatest re-use of a DRY data element,
and should allow the author to associate a maintainer globally maintained in a dependency resource:

(`MODULE.bazel`)
```
bazel_dep(name = "firehydrant_stuff", version = "1.2.3")
```
(`BUILD.bazel`)
```
info_file(
    name = "firehydrant_info",
    package_name = "FireHydrant",
    description = "A great Incident-Management resource made by SREs for SREs",
    maintainer = "@firehydrant_stuff//maint:robertross",
    os_min_ver = "7.0-1",  # correct-format=[^\d+(\.\d+){1,2}(-\d+){1,2}$]
    package_version = "1.0.0-1",
)
```

Ref:
* [Synology: INFO](https://help.synology.com/developer-guide/synology_package/INFO.html)
j��## Create an INFO file

The INFO file is the simple metadata k/v dict of the SPK: a number of `key=value` pairs that define
attributes of the package.

This file is needed to inform the Synology NAS of the name and unique ID of the package, quote
maintainers and distributors, and indicate architecture and OS constraints to install.  I
personally expect that the simple format of this file allows the UI to show install dialogs with
minimal complexity.

Likely the reader will notice that the `maintainer()` block collects more information than it needs
to for the `INFO` file: the additional URL is optional, but can help track down a maintainer if a
user or collaborator needs to find them.  This is not necessarily intended to be the upstream
URL(s) of a project (ie github pages, docker URLs,etc) but is intended to be a valid URL that can
help precisely identify where the preferred path to find that maintainer.

This implementation mimics the defaults from Synology's documentation so that the bare minimum
attributes can be provided to unblock immediate progress.

### Examples

(`BUILD` file)
```
load("@//:defs.bzl", "info_file", "maintainer")

maintainer(
    name = "chickenandpork",
    maintainer_name = "Allan Clark",
    maintainer_url = "http://linkedin.com/in/goldfish",
    visibility = ["//visibility:public"],
)

info_file(
    name = "floppydog_info",
    package_name = "FloppyDog",
    description = "Provides the FloppyDog set of CLI tools for Great Justice",
    maintainer = ":chickenandpork",
    os_min_ver = "7.0-1",  # correct-format=[^\d+(\.\d+){1,2}(-\d+){1,2}$]
    package_version = "1.0.0-1",
)
```

The `INFO` file generated by this looks similar to:
```
package="FloppyDog"
version="1.0.0-1"
os_min_ver="7.0-1"
description="Provides the FloppyDog set of CLI tools for Great Justice"
maintainer="Allan Clark"
arch="noarch"
ctl_stop="yes"
startable="yes"
thirdparty="yes"
```

`info_file()` uses [maintainer()](docs.md#maintainer) to carry information about the package's
maintainer: referring to a maintainer by target ID allows greatest re-use of a DRY data element,
and should allow the author to associate a maintainer globally maintained in a dependency resource:

(`MODULE.bazel`)
```
bazel_dep(name = "firehydrant_stuff", version = "1.2.3")
```
(`BUILD.bazel`)
```
info_file(
    name = "firehydrant_info",
    package_name = "FireHydrant",
    description = "A great Incident-Management resource made by SREs for SREs",
    maintainer = "@firehydrant_stuff//maint:robertross",
    os_min_ver = "7.0-1",  # correct-format=[^\d+(\.\d+){1,2}(-\d+){1,2}$]
    package_version = "1.0.0-1",
)
```

Ref:
* [Synology: INFO](https://help.synology.com/developer-guide/synology_package/INFO.html)
�
*
rules_synologysynologymaintainer.bzl�
maintainer}A simple wrapper for re-use and typing, this produces a Maintainer that can be used as an attribute to targets they maintain."�
�

maintainer}A simple wrapper for re-use and typing, this produces a Maintainer that can be used as an attribute to targets they maintain.*
nameA unique name for this target. 
maintainer_name 
maintainer_url2"""7

maintainer)@@rules_synology//synology:maintainer.bzl
,
*
nameA unique name for this target. 

maintainer_name 

maintainer_url2""�
Maintainer2�
t

Maintainer
name(Undocumented)
url(Undocumented)"7

Maintainer)@@rules_synology//synology:maintainer.bzl


name(Undocumented)

url(Undocumented)�)
6
rules_synologysynologyport-service-configure.bzl�	protocol_file�The Protocol file is used as a wrapper/collector of service_configs: a building-block to generate the actual file as a buildable object for use in a Port Config resource.  Format is an INI file, as discussed in the DSM_Developer_Guide_7_enu.pdf, section "Port" on p 128 in my copy (search for "Configure Format Template").  Effectively, it builds the file that is pointed-to by a port-config.protocol-file entry in a resource JSON file."�
�
protocol_file�The Protocol file is used as a wrapper/collector of service_configs: a building-block to generate the actual file as a buildable object for use in a Port Config resource.  Format is an INI file, as discussed in the DSM_Developer_Guide_7_enu.pdf, section "Port" on p 128 in my copy (search for "Configure Format Template").  Effectively, it builds the file that is pointed-to by a port-config.protocol-file entry in a resource JSON file.*
nameA unique name for this target. 
out
package_name2""+
service_config*
ServiceConfigInfo2[]"F
protocol_file5@@rules_synology//synology:port-service-configure.bzl
[[,
*
nameA unique name for this target. 	

out

package_name2""-
+
service_config*
ServiceConfigInfo2[]�service_config_A function to define a service configuration (port-forward) for a package installed on Synology"�
�
service_config_A function to define a service configuration (port-forward) for a package installed on Synology*
nameA unique name for this target. 
description 
	dst_ports 
port_forward2True
	src_ports2""
title "G
service_config5@@rules_synology//synology:port-service-configure.bzl
  ,
*
nameA unique name for this target. 

description 

	dst_ports 

port_forward2True

	src_ports2""

title �PortConfigInfo2�
�
PortConfigInfo~
protocol_filemThe single file representing a ser of one or more Port configs (port-forwards) for mege into a resource file.^
structTA struct that will be converted to JSON (in writing of the resource file, not here)."G
PortConfigInfo5@@rules_synology//synology:port-service-configure.bzl
,,�
~
protocol_filemThe single file representing a ser of one or more Port configs (port-forwards) for mege into a resource file.`
^
structTA struct that will be converted to JSON (in writing of the resource file, not here).�ServiceConfigInfo2�
�
ServiceConfigInfoP
keyIservice-unique key for the section of the service configuration .ini file�
title�Title of the service or service component being configured; this is shown as the field "Protocol" on the firewall config UI, selection of built-in service.�
desc�Description of the service or service-specific component; this is shown as the field "Applications" on the firewall config UI, selection of built-in service.|
port_forwardl(Optional, but you want to set) set to activate port-forwarding from the external interfaces to the service.�
	src_ports�(Optional) if your service protocol has specific source ports (ie the client/requestor of your service connects FROM a specific port) you can configure that here.  This is less common, used in DNS, SUNRPC portmapper, DHCP, CORBA nameservice, etc.  "1:1024/tcp" can be used, for example, to configure that sources should use the port range typically reserved for non-guest root users on a server.  See DSM_Developer_Guide_7_enu.pdf, section "Port" in Workers, which was p 128 when I checked.�
	dst_ports�This configures where the port on the Synology will listen to forward traffic to your service.  For example, a webserver might put "80,443/tcp" here (but more likely configure the revproxy); a web-based admin UI for a container or service would put that service's listening port here."J
ServiceConfigInfo5@@rules_synology//synology:port-service-configure.bzl
R
P
keyIservice-unique key for the section of the service configuration .ini file�
�
title�Title of the service or service component being configured; this is shown as the field "Protocol" on the firewall config UI, selection of built-in service.�
�
desc�Description of the service or service-specific component; this is shown as the field "Applications" on the firewall config UI, selection of built-in service.~
|
port_forwardl(Optional, but you want to set) set to activate port-forwarding from the external interfaces to the service.�
�
	src_ports�(Optional) if your service protocol has specific source ports (ie the client/requestor of your service connects FROM a specific port) you can configure that here.  This is less common, used in DNS, SUNRPC portmapper, DHCP, CORBA nameservice, etc.  "1:1024/tcp" can be used, for example, to configure that sources should use the port range typically reserved for non-guest root users on a server.  See DSM_Developer_Guide_7_enu.pdf, section "Port" in Workers, which was p 128 when I checked.�
�
	dst_ports�This configures where the port on the Synology will listen to forward traffic to your service.  For example, a webserver might put "80,443/tcp" here (but more likely configure the revproxy); a web-based admin UI for a container or service would put that service's listening port here.�	
3
rules_synologysynologyprivilege-configure.bzl�	privilege_configA function (currently stubbed) to define a privilege configuration (conf/privilege) configuring packages installed in Synology."�
�
privilege_configA function (currently stubbed) to define a privilege configuration (conf/privilege) configuring packages installed in Synology.*
nameA unique name for this target. ]
	groupname<posix/unix groupname in which the app-specific user is added2"rules_synology"
outR
run_as_package:list of apps/services that sound run-as the given username2[]A
run_as_root,list of apps/services that sound run-as root2[]Q
usernameAapp-specific posix/unix username under which the app/service runs "F
privilege_config2@@rules_synology//synology:privilege-configure.bzl
66,
*
nameA unique name for this target. _
]
	groupname<posix/unix groupname in which the app-specific user is added2"rules_synology"	

outT
R
run_as_package:list of apps/services that sound run-as the given username2[]C
A
run_as_root,list of apps/services that sound run-as root2[]S
Q
usernameAapp-specific posix/unix username under which the app/service runs �
2
rules_synologysynologyresource-configure.bzl�resource_configiA function to define a resource configuration (conf/resource) configuring packages installed in Synology."�
�
resource_configiA function to define a resource configuration (conf/resource) configuring packages installed in Synology.*
nameA unique name for this target. 
out
	resources "D
resource_config1@@rules_synology//synology:resource-configure.bzl
;;,
*
nameA unique name for this target. 	

out

	resources �
//synology:docker-project.bzlrl
.
rules_synologysynologydocker-project.bzl,
DockerProjectDockerProject
7D
F�
%//synology:port-service-configure.bzlrv
6
rules_synologysynologyport-service-configure.bzl.
PortConfigInfoPortConfigInfo
?M
O�
//synology:usr-local-linker.bzlrp
0
rules_synologysynologyusr-local-linker.bzl.
UsrLocalLinkerUsrLocalLinker
	9	G
		I�	
)
rules_synologysynologyunittests.bzl�confirm_binary_matches_platform*�
�
confirm_binary_matches_platform
binary (
size"small"(2K
confirm_binary_matches_platform(@@rules_synology//synology:unittests.bzl
"expand_template_rule"native.sh_test�spk_component�Pull a member component from the SPK archive for further testing

spk_component pulls a component from the SPK file by passing the filename to an unpack; the result should be usable to confirm that the SPK packed up what was expected.*�
�
spk_component

name (	
spk (
filename (�Pull a member component from the SPK archive for further testing

spk_component pulls a component from the SPK file by passing the filename to an unpack; the result should be usable to confirm that the SPK packed up what was expected.29
spk_component(@@rules_synology//synology:unittests.bzl
;;2native.genrule�
//lib:expand_template.bzlrx
,
aspect_bazel_liblibexpand_template.bzl:
expand_template_ruleexpand_template_rule
5I
Ky
//rules:write_file.bzlr]
%
bazel_skylibruleswrite_file.bzl&

write_file
write_file
.8
:�)
0
rules_synologysynologyusr-local-linker.bzl�usr_local_linker�## Configure a /usr/local Linker

The /usr/local linker is a [Worker](glossary.md#worker) that softlinks payload binaries, libraries,
and config files to bin, lib, and etc subdirectories in /usr/local on package start and removes on
package stop.  If the link or file pre-exists, /usr/local worker will unlink() those files,
effectively overwriting.  Any failure to pre-delete or create a link results in the process
failing, triggering any rollback.

### Example
This will cause a softlink to be created in `/usr/local/bin` that points to
`/var/packages/<package>/target/bin/netfilter-mods`:
```
load("@//:defs.bzl", "usr_local_linker")

usr_local_linker(
    name = "softlinks",
    bin = ["netfilter-mods"],
)

```

There is currently no method of linking to a target with a different name: the underlying config
that Synology doesn't offer that capability.


References:

* [Synology: /usr/local linker](https://help.synology.com/developer-guide/resource_acquisition/usrlocal_linker.html)
"�
�

usr_local_linker�## Configure a /usr/local Linker

The /usr/local linker is a [Worker](glossary.md#worker) that softlinks payload binaries, libraries,
and config files to bin, lib, and etc subdirectories in /usr/local on package start and removes on
package stop.  If the link or file pre-exists, /usr/local worker will unlink() those files,
effectively overwriting.  Any failure to pre-delete or create a link results in the process
failing, triggering any rollback.

### Example
This will cause a softlink to be created in `/usr/local/bin` that points to
`/var/packages/<package>/target/bin/netfilter-mods`:
```
load("@//:defs.bzl", "usr_local_linker")

usr_local_linker(
    name = "softlinks",
    bin = ["netfilter-mods"],
)

```

There is currently no method of linking to a target with a different name: the underlying config
that Synology doesn't offer that capability.


References:

* [Synology: /usr/local linker](https://help.synology.com/developer-guide/resource_acquisition/usrlocal_linker.html)
*
nameA unique name for this target. 9
bin,binary paths to softlink into /usr/local/bin2[]=
etc0configfile paths to softlink into /usr/local/etc2[]:
lib-library paths to softlink into /usr/local/lib2[]"C
usr_local_linker/@@rules_synology//synology:usr-local-linker.bzl
DD,
*
nameA unique name for this target. ;
9
bin,binary paths to softlink into /usr/local/bin2[]?
=
etc0configfile paths to softlink into /usr/local/etc2[]<
:
lib-library paths to softlink into /usr/local/lib2[]�UsrLocalLinkerTUsrLocalLinker relates to a /usr/local linker in the packaging subsystem of Synology2�
�
UsrLocalLinkerTUsrLocalLinker relates to a /usr/local linker in the packaging subsystem of Synology>
bin7A list of binary paths to softlink into /usr/local/bin.>
etc7A list of binary paths to softlink into /usr/local/etc.>
lib7A list of binary paths to softlink into /usr/local/lib."A
UsrLocalLinker/@@rules_synology//synology:usr-local-linker.bzl
11@
>
bin7A list of binary paths to softlink into /usr/local/bin.@
>
etc7A list of binary paths to softlink into /usr/local/etc.@
>
lib7A list of binary paths to softlink into /usr/local/lib.�	doc�## Configure a /usr/local Linker

The /usr/local linker is a [Worker](glossary.md#worker) that softlinks payload binaries, libraries,
and config files to bin, lib, and etc subdirectories in /usr/local on package start and removes on
package stop.  If the link or file pre-exists, /usr/local worker will unlink() those files,
effectively overwriting.  Any failure to pre-delete or create a link results in the process
failing, triggering any rollback.

### Example
This will cause a softlink to be created in `/usr/local/bin` that points to
`/var/packages/<package>/target/bin/netfilter-mods`:
```
load("@//:defs.bzl", "usr_local_linker")

usr_local_linker(
    name = "softlinks",
    bin = ["netfilter-mods"],
)

```

There is currently no method of linking to a target with a different name: the underlying config
that Synology doesn't offer that capability.


References:

* [Synology: /usr/local linker](https://help.synology.com/developer-guide/resource_acquisition/usrlocal_linker.html)
j��## Configure a /usr/local Linker

The /usr/local linker is a [Worker](glossary.md#worker) that softlinks payload binaries, libraries,
and config files to bin, lib, and etc subdirectories in /usr/local on package start and removes on
package stop.  If the link or file pre-exists, /usr/local worker will unlink() those files,
effectively overwriting.  Any failure to pre-delete or create a link results in the process
failing, triggering any rollback.

### Example
This will cause a softlink to be created in `/usr/local/bin` that points to
`/var/packages/<package>/target/bin/netfilter-mods`:
```
load("@//:defs.bzl", "usr_local_linker")

usr_local_linker(
    name = "softlinks",
    bin = ["netfilter-mods"],
)

```

There is currently no method of linking to a target with a different name: the underlying config
that Synology doesn't offer that capability.


References:

* [Synology: /usr/local linker](https://help.synology.com/developer-guide/resource_acquisition/usrlocal_linker.html)
.
,
rules_synology
toolchainstoolchains.bzl�
&
rules_synology
toolchainsdeps.bzlOdeps*E
5
deps2-
deps%@@rules_synology//toolchains:deps.bzl
�
 //tools/build_defs/repo:http.bzlrj
.
bazel_toolstools/build_defs/repohttp.bzl*
http_archivehttp_archive
7C
E�
!//tools/build_defs/repo:utils.bzlr]
/
bazel_toolstools/build_defs/repo	utils.bzl
maybemaybe
8=
?�
//toolchains:toolchains.bzlre
,
rules_synology
toolchainstoolchains.bzl'

TOOLCHAINS_TOOLCHAINS
4?
O�	
TOOLCHAINSj{2y
&$armada37xx-gcc850_glibc226_armv8-GPL
&$denverton-gcc850_glibc226_x86_64-GPL
'%geminilake-gcc850_glibc226_x86_64-GPL�	TOOLCHAINS_PLUS_ARMj�2�
&$armada37xx-gcc850_glibc226_armv8-GPL
&$denverton-gcc850_glibc226_x86_64-GPL
'%geminilake-gcc850_glibc226_x86_64-GPL
arm64_gcc_linux_x86_64D	TOOLCHAINS_SHORT_LCj+2)

armada37xx
	denverton

geminilake�
,
rules_synology
toolchainsextensions.bzlpsynology_depsJ]
M
synology_deps"<
synology_deps+@@rules_synology//toolchains:extensions.bzl
!!�synology_toolchainsJi
Y
synology_toolchains"B
synology_toolchains+@@rules_synology//toolchains:extensions.bzl
''�
//toolchains:deps.bzlr�
&
rules_synology
toolchainsdeps.bzl$
deps_synology_deps
.<'

TOOLCHAINS_toolchains
GR
b�Provides the toolchains:
- "simple" toolchains: pre-compiled binaries pulled to match architecture
- "traditional" toolchains: compiler, tools, environment: for crossbuild

��

rules_synologydefs.bzl�docker_project�
## Configure a collection of Docker Projects

The Docker Project is a [Worker](glossary.md#worker) that carries one or more docker-compose
definitions into a Synology NAS, and can be used to turn-up the project defined in the compose
files.

Each project's name and compose file are represented as a `docker_compose()` target; these targets
are collected in an list `projects` in a `docker_project()` target.

For example:

(`BUILD` file)
```
docker_compose(
    name = "nginx"
    compose = ":dc.yaml",
)

docker_compose(
    name = "cryptobot"
    compose = ":some_other_compose.yaml",
)

docker_project(
    name = "green_stack",
    projects = [ ":nginx", "cryptobot" ]
)
```

References:

- [Synology: Docker Project](https://help.synology.com/developer-guide/resource_acquisition/docker-project.html)
"�

�
docker_project�
## Configure a collection of Docker Projects

The Docker Project is a [Worker](glossary.md#worker) that carries one or more docker-compose
definitions into a Synology NAS, and can be used to turn-up the project defined in the compose
files.

Each project's name and compose file are represented as a `docker_compose()` target; these targets
are collected in an list `projects` in a `docker_project()` target.

For example:

(`BUILD` file)
```
docker_compose(
    name = "nginx"
    compose = ":dc.yaml",
)

docker_compose(
    name = "cryptobot"
    compose = ":some_other_compose.yaml",
)

docker_project(
    name = "green_stack",
    projects = [ ":nginx", "cryptobot" ]
)
```

References:

- [Synology: Docker Project](https://help.synology.com/developer-guide/resource_acquisition/docker-project.html)
*
nameA unique name for this target. H
preload_image1OCI/Docker image to preload at install of the SPK2""]
projects:List of docker_compose() targets to bundle to this project*
DockerCompose2[]"-
docker_project@@rules_synology//:defs.bzl
cc,
*
nameA unique name for this target. J
H
preload_image1OCI/Docker image to preload at install of the SPK2""_
]
projects:List of docker_compose() targets to bundle to this project*
DockerCompose2[]�images7Create a filegroup of resized images: 16x16, 24x24, etc"�
�
images7Create a filegroup of resized images: 16x16, 24x24, etc*
nameA unique name for this target. �
images_template�template for output files: use a string with a single {} that will be replaced with the size.  The template should end with a suffix that determines the resulting format: .png, .jpg, .PNG, etc.  Note that Synology SPK packaging requires files of the form PACKAGE_ICON_<size>.PNG so changing this should ential converting the result back however desired for the payload of the SPK.2""�
sizes_sizes to convert: use a list of ints, each of which is a desired size of a square bounding box.2&[16, 24, 32, 48, 64, 72, 90, 120, 256]<
src1Initial source image to convert to various sizes. n
verboseZVerbosity can enable some debug messages from //tools:resize that can help resolve errors.2False"%
images@@rules_synology//:defs.bzl
,
*
nameA unique name for this target. �
�
images_template�template for output files: use a string with a single {} that will be replaced with the size.  The template should end with a suffix that determines the resulting format: .png, .jpg, .PNG, etc.  Note that Synology SPK packaging requires files of the form PACKAGE_ICON_<size>.PNG so changing this should ential converting the result back however desired for the payload of the SPK.2""�
�
sizes_sizes to convert: use a list of ints, each of which is a desired size of a square bounding box.2&[16, 24, 32, 48, 64, 72, 90, 120, 256]>
<
src1Initial source image to convert to various sizes. p
n
verboseZVerbosity can enable some debug messages from //tools:resize that can help resolve errors.2False�F	info_file�## Create an INFO file

The INFO file is the simple metadata k/v dict of the SPK: a number of `key=value` pairs that define
attributes of the package.

This file is needed to inform the Synology NAS of the name and unique ID of the package, quote
maintainers and distributors, and indicate architecture and OS constraints to install.  I
personally expect that the simple format of this file allows the UI to show install dialogs with
minimal complexity.

Likely the reader will notice that the `maintainer()` block collects more information than it needs
to for the `INFO` file: the additional URL is optional, but can help track down a maintainer if a
user or collaborator needs to find them.  This is not necessarily intended to be the upstream
URL(s) of a project (ie github pages, docker URLs,etc) but is intended to be a valid URL that can
help precisely identify where the preferred path to find that maintainer.

This implementation mimics the defaults from Synology's documentation so that the bare minimum
attributes can be provided to unblock immediate progress.

### Examples

(`BUILD` file)
```
load("@//:defs.bzl", "info_file", "maintainer")

maintainer(
    name = "chickenandpork",
    maintainer_name = "Allan Clark",
    maintainer_url = "http://linkedin.com/in/goldfish",
    visibility = ["//visibility:public"],
)

info_file(
    name = "floppydog_info",
    package_name = "FloppyDog",
    description = "Provides the FloppyDog set of CLI tools for Great Justice",
    maintainer = ":chickenandpork",
    os_min_ver = "7.0-1",  # correct-format=[^\d+(\.\d+){1,2}(-\d+){1,2}$]
    package_version = "1.0.0-1",
)
```

The `INFO` file generated by this looks similar to:
```
package="FloppyDog"
version="1.0.0-1"
os_min_ver="7.0-1"
description="Provides the FloppyDog set of CLI tools for Great Justice"
maintainer="Allan Clark"
arch="noarch"
ctl_stop="yes"
startable="yes"
thirdparty="yes"
```

`info_file()` uses [maintainer()](docs.md#maintainer) to carry information about the package's
maintainer: referring to a maintainer by target ID allows greatest re-use of a DRY data element,
and should allow the author to associate a maintainer globally maintained in a dependency resource:

(`MODULE.bazel`)
```
bazel_dep(name = "firehydrant_stuff", version = "1.2.3")
```
(`BUILD.bazel`)
```
info_file(
    name = "firehydrant_info",
    package_name = "FireHydrant",
    description = "A great Incident-Management resource made by SREs for SREs",
    maintainer = "@firehydrant_stuff//maint:robertross",
    os_min_ver = "7.0-1",  # correct-format=[^\d+(\.\d+){1,2}(-\d+){1,2}$]
    package_version = "1.0.0-1",
)
```

Ref:
* [Synology: INFO](https://help.synology.com/developer-guide/synology_package/INFO.html)
"�1
�#
	info_file�## Create an INFO file

The INFO file is the simple metadata k/v dict of the SPK: a number of `key=value` pairs that define
attributes of the package.

This file is needed to inform the Synology NAS of the name and unique ID of the package, quote
maintainers and distributors, and indicate architecture and OS constraints to install.  I
personally expect that the simple format of this file allows the UI to show install dialogs with
minimal complexity.

Likely the reader will notice that the `maintainer()` block collects more information than it needs
to for the `INFO` file: the additional URL is optional, but can help track down a maintainer if a
user or collaborator needs to find them.  This is not necessarily intended to be the upstream
URL(s) of a project (ie github pages, docker URLs,etc) but is intended to be a valid URL that can
help precisely identify where the preferred path to find that maintainer.

This implementation mimics the defaults from Synology's documentation so that the bare minimum
attributes can be provided to unblock immediate progress.

### Examples

(`BUILD` file)
```
load("@//:defs.bzl", "info_file", "maintainer")

maintainer(
    name = "chickenandpork",
    maintainer_name = "Allan Clark",
    maintainer_url = "http://linkedin.com/in/goldfish",
    visibility = ["//visibility:public"],
)

info_file(
    name = "floppydog_info",
    package_name = "FloppyDog",
    description = "Provides the FloppyDog set of CLI tools for Great Justice",
    maintainer = ":chickenandpork",
    os_min_ver = "7.0-1",  # correct-format=[^\d+(\.\d+){1,2}(-\d+){1,2}$]
    package_version = "1.0.0-1",
)
```

The `INFO` file generated by this looks similar to:
```
package="FloppyDog"
version="1.0.0-1"
os_min_ver="7.0-1"
description="Provides the FloppyDog set of CLI tools for Great Justice"
maintainer="Allan Clark"
arch="noarch"
ctl_stop="yes"
startable="yes"
thirdparty="yes"
```

`info_file()` uses [maintainer()](docs.md#maintainer) to carry information about the package's
maintainer: referring to a maintainer by target ID allows greatest re-use of a DRY data element,
and should allow the author to associate a maintainer globally maintained in a dependency resource:

(`MODULE.bazel`)
```
bazel_dep(name = "firehydrant_stuff", version = "1.2.3")
```
(`BUILD.bazel`)
```
info_file(
    name = "firehydrant_info",
    package_name = "FireHydrant",
    description = "A great Incident-Management resource made by SREs for SREs",
    maintainer = "@firehydrant_stuff//maint:robertross",
    os_min_ver = "7.0-1",  # correct-format=[^\d+(\.\d+){1,2}(-\d+){1,2}$]
    package_version = "1.0.0-1",
)
```

Ref:
* [Synology: INFO](https://help.synology.com/developer-guide/synology_package/INFO.html)
*
nameA unique name for this target. g
arch_stringsIarray of architectures (strings): [ "alpine", ...] (default: ["noarch"]).2
["noarch"]�
ctl_stopwIndicates (boolean) whether there is a start-stop-script and the SPK can be started or stopped (previously: startable).2True�
description�Brief description of the package: copy-paste from the upstream if permissible.  Although this is permitted be a looooong single-line string, it does display on the UIs to install a package, so brevity is still encouraged. o

maintainerOMaintainer of the build logic for the component (primary if multiple, a person) *

Maintainer�

os_min_ver�Earliest version of DSM that can install the package; ie "DSM 7.1.1-42962".  " +
"There seems to be no handling of the extended hard-to-parse suffixes used by " +
"Synology such as "DSM 7.1.1-42962 Update 6". \
outSName of the Info file, if INFO is not preferred (changing this is not recommended).o
package_name[Name of the package, unique within Synology SPKs, hopefully resembles external package name �
package_version�Version of the package; although I recommend semver-ish X.Y.Z-BUILDNUM, Synology describes as being any string of numbers separated by periods, dash, or underscore, but will later fail anything outside the pattern of (0-9]+\.){1-5}[-[0-9]+] (essentially 1-5 dot-separated digits with an optional hyphen and number of up to 5 digits: 1.2.3.4.5-56789) �
validation_softfail�Redirects fatal validation failures into either debug messages or ignored/unprinted in case of inaccuracy in any validation step, or workarounds, or unittesting.  Choice of ['fail', 'message', 'ignored'].  This should likely remain the default value.2"fail""(
	info_file@@rules_synology//:defs.bzl
��,
*
nameA unique name for this target. i
g
arch_stringsIarray of architectures (strings): [ "alpine", ...] (default: ["noarch"]).2
["noarch"]�
�
ctl_stopwIndicates (boolean) whether there is a start-stop-script and the SPK can be started or stopped (previously: startable).2True�
�
description�Brief description of the package: copy-paste from the upstream if permissible.  Although this is permitted be a looooong single-line string, it does display on the UIs to install a package, so brevity is still encouraged. q
o

maintainerOMaintainer of the build logic for the component (primary if multiple, a person) *

Maintainer�
�

os_min_ver�Earliest version of DSM that can install the package; ie "DSM 7.1.1-42962".  " +
"There seems to be no handling of the extended hard-to-parse suffixes used by " +
"Synology such as "DSM 7.1.1-42962 Update 6". ^
\
outSName of the Info file, if INFO is not preferred (changing this is not recommended).q
o
package_name[Name of the package, unique within Synology SPKs, hopefully resembles external package name �
�
package_version�Version of the package; although I recommend semver-ish X.Y.Z-BUILDNUM, Synology describes as being any string of numbers separated by periods, dash, or underscore, but will later fail anything outside the pattern of (0-9]+\.){1-5}[-[0-9]+] (essentially 1-5 dot-separated digits with an optional hyphen and number of up to 5 digits: 1.2.3.4.5-56789) �
�
validation_softfail�Redirects fatal validation failures into either debug messages or ignored/unprinted in case of inaccuracy in any validation step, or workarounds, or unittesting.  Choice of ['fail', 'message', 'ignored'].  This should likely remain the default value.2"fail"�
maintainer}A simple wrapper for re-use and typing, this produces a Maintainer that can be used as an attribute to targets they maintain."�
�

maintainer}A simple wrapper for re-use and typing, this produces a Maintainer that can be used as an attribute to targets they maintain.*
nameA unique name for this target. 
maintainer_name 
maintainer_url2""")

maintainer@@rules_synology//:defs.bzl
,
*
nameA unique name for this target. 

maintainer_name 

maintainer_url2""�privilege_configA function (currently stubbed) to define a privilege configuration (conf/privilege) configuring packages installed in Synology."�
�
privilege_configA function (currently stubbed) to define a privilege configuration (conf/privilege) configuring packages installed in Synology.*
nameA unique name for this target. ]
	groupname<posix/unix groupname in which the app-specific user is added2"rules_synology"
outR
run_as_package:list of apps/services that sound run-as the given username2[]A
run_as_root,list of apps/services that sound run-as root2[]Q
usernameAapp-specific posix/unix username under which the app/service runs "/
privilege_config@@rules_synology//:defs.bzl
66,
*
nameA unique name for this target. _
]
	groupname<posix/unix groupname in which the app-specific user is added2"rules_synology"	

outT
R
run_as_package:list of apps/services that sound run-as the given username2[]C
A
run_as_root,list of apps/services that sound run-as root2[]S
Q
usernameAapp-specific posix/unix username under which the app/service runs �	protocol_file�The Protocol file is used as a wrapper/collector of service_configs: a building-block to generate the actual file as a buildable object for use in a Port Config resource.  Format is an INI file, as discussed in the DSM_Developer_Guide_7_enu.pdf, section "Port" on p 128 in my copy (search for "Configure Format Template").  Effectively, it builds the file that is pointed-to by a port-config.protocol-file entry in a resource JSON file."�
�
protocol_file�The Protocol file is used as a wrapper/collector of service_configs: a building-block to generate the actual file as a buildable object for use in a Port Config resource.  Format is an INI file, as discussed in the DSM_Developer_Guide_7_enu.pdf, section "Port" on p 128 in my copy (search for "Configure Format Template").  Effectively, it builds the file that is pointed-to by a port-config.protocol-file entry in a resource JSON file.*
nameA unique name for this target. 
out
package_name2""+
service_config*
ServiceConfigInfo2[]",
protocol_file@@rules_synology//:defs.bzl
[[,
*
nameA unique name for this target. 	

out

package_name2""-
+
service_config*
ServiceConfigInfo2[]�resource_configiA function to define a resource configuration (conf/resource) configuring packages installed in Synology."�
�
resource_configiA function to define a resource configuration (conf/resource) configuring packages installed in Synology.*
nameA unique name for this target. 
out
	resources ".
resource_config@@rules_synology//:defs.bzl
;;,
*
nameA unique name for this target. 	

out

	resources �service_config_A function to define a service configuration (port-forward) for a package installed on Synology"�
�
service_config_A function to define a service configuration (port-forward) for a package installed on Synology*
nameA unique name for this target. 
description 
	dst_ports 
port_forward2True
	src_ports2""
title "-
service_config@@rules_synology//:defs.bzl
  ,
*
nameA unique name for this target. 

description 

	dst_ports 

port_forward2True

	src_ports2""

title �usr_local_linker�## Configure a /usr/local Linker

The /usr/local linker is a [Worker](glossary.md#worker) that softlinks payload binaries, libraries,
and config files to bin, lib, and etc subdirectories in /usr/local on package start and removes on
package stop.  If the link or file pre-exists, /usr/local worker will unlink() those files,
effectively overwriting.  Any failure to pre-delete or create a link results in the process
failing, triggering any rollback.

### Example
This will cause a softlink to be created in `/usr/local/bin` that points to
`/var/packages/<package>/target/bin/netfilter-mods`:
```
load("@//:defs.bzl", "usr_local_linker")

usr_local_linker(
    name = "softlinks",
    bin = ["netfilter-mods"],
)

```

There is currently no method of linking to a target with a different name: the underlying config
that Synology doesn't offer that capability.


References:

* [Synology: /usr/local linker](https://help.synology.com/developer-guide/resource_acquisition/usrlocal_linker.html)
"�
�

usr_local_linker�## Configure a /usr/local Linker

The /usr/local linker is a [Worker](glossary.md#worker) that softlinks payload binaries, libraries,
and config files to bin, lib, and etc subdirectories in /usr/local on package start and removes on
package stop.  If the link or file pre-exists, /usr/local worker will unlink() those files,
effectively overwriting.  Any failure to pre-delete or create a link results in the process
failing, triggering any rollback.

### Example
This will cause a softlink to be created in `/usr/local/bin` that points to
`/var/packages/<package>/target/bin/netfilter-mods`:
```
load("@//:defs.bzl", "usr_local_linker")

usr_local_linker(
    name = "softlinks",
    bin = ["netfilter-mods"],
)

```

There is currently no method of linking to a target with a different name: the underlying config
that Synology doesn't offer that capability.


References:

* [Synology: /usr/local linker](https://help.synology.com/developer-guide/resource_acquisition/usrlocal_linker.html)
*
nameA unique name for this target. 9
bin,binary paths to softlink into /usr/local/bin2[]=
etc0configfile paths to softlink into /usr/local/etc2[]:
lib-library paths to softlink into /usr/local/lib2[]"/
usr_local_linker@@rules_synology//:defs.bzl
DD,
*
nameA unique name for this target. ;
9
bin,binary paths to softlink into /usr/local/bin2[]?
=
etc0configfile paths to softlink into /usr/local/etc2[]<
:
lib-library paths to softlink into /usr/local/lib2[]�confirm_binary_matches_platform*�
�
confirm_binary_matches_platform
binary (
size"small"(2K
confirm_binary_matches_platform(@@rules_synology//synology:unittests.bzl
"expand_template_rule"native.sh_test�docker_compose�## Configure a single Docker Project (a docker-compose)

The Docker Project is a [Worker](glossary.md#worker) that carries one or more docker-compose
definitions into a Synology NAS, and can be used to turn-up the project defined in the compose
files.

The Synology Docker Project Worker expects a name and a compose file for each project.
docker_compose() is used to provide a name/compose pair, which are then collected in a
docker_project() target:

(`BUILD` file)
```
docker_compose(
    name = "nginx"
    compose = ":dc.yaml",
)

docker_compose(
    name = "cryptobot"
    compose = ":some_other_compose.yaml",
)

docker_project(
    name = "green_stack",
    projects = [ ":nginx", "cryptobot" ]
)
```

References:

- [Synology: Docker Project](https://help.synology.com/developer-guide/resource_acquisition/docker-project.html)*�
�
docker_compose

name (
compose (
project_nameNone(
pathNone(
debugFalse(�## Configure a single Docker Project (a docker-compose)

The Docker Project is a [Worker](glossary.md#worker) that carries one or more docker-compose
definitions into a Synology NAS, and can be used to turn-up the project defined in the compose
files.

The Synology Docker Project Worker expects a name and a compose file for each project.
docker_compose() is used to provide a name/compose pair, which are then collected in a
docker_project() target:

(`BUILD` file)
```
docker_compose(
    name = "nginx"
    compose = ":dc.yaml",
)

docker_compose(
    name = "cryptobot"
    compose = ":some_other_compose.yaml",
)

docker_project(
    name = "green_stack",
    projects = [ ":nginx", "cryptobot" ]
)
```

References:

- [Synology: Docker Project](https://help.synology.com/developer-guide/resource_acquisition/docker-project.html)2?
docker_compose-@@rules_synology//synology:docker-project.bzl
��"_docker_compose2_docker_compose�spk_component�Pull a member component from the SPK archive for further testing

spk_component pulls a component from the SPK file by passing the filename to an unpack; the result should be usable to confirm that the SPK packed up what was expected.*�
�
spk_component

name (	
spk (
filename (�Pull a member component from the SPK archive for further testing

spk_component pulls a component from the SPK file by passing the filename to an unpack; the result should be usable to confirm that the SPK packed up what was expected.29
spk_component(@@rules_synology//synology:unittests.bzl
;;2native.genrule�
//synology:docker-project.bzlr�
.
rules_synologysynologydocker-project.bzl/
docker_compose_docker_compose
6E/
docker_project_docker_project
Zi
}r
//synology:images.bzlrW
&
rules_synologysynology
images.bzl
images_images
.5
A~
//synology:info-file.bzlr`
)
rules_synologysynologyinfo-file.bzl%
	info_file
_info_file
1;
J�
//synology:maintainer.bzlr�
*
rules_synologysynologymaintainer.bzl&

Maintainer
Maintainer
3='

maintainer_maintainer
@K
[�
%//synology:port-service-configure.bzlr�
6
rules_synologysynologyport-service-configure.bzl-
protocol_file_protocol_file
>L/
service_config_service_config
`o
��
"//synology:privilege-configure.bzlrx
3
rules_synologysynologyprivilege-configure.bzl3
privilege_config_privilege_config
;L
b�
!//synology:resource-configure.bzlru
2
rules_synologysynologyresource-configure.bzl1
resource_config_resource_config
	:	J
		_�
//synology:unittests.bzlr�
)
rules_synologysynologyunittests.bzlQ
confirm_binary_matches_platform _confirm_binary_matches_platform

1
Q.
spk_component_spk_component

w
�


��
//synology:usr-local-linker.bzlru
0
rules_synologysynologyusr-local-linker.bzl3
usr_local_linker_usr_local_linker
8I
_k	SPK_REQUIRED_SCRIPTSjQ2O
	preinst

postinst
	preuninst

postuninst

preupgrade
postupgrade�

rules_synologydeps.bzlEdeps*;
+
deps2#
deps@@rules_synology//:deps.bzl
�
 //tools/build_defs/repo:http.bzlrj
.
bazel_toolstools/build_defs/repohttp.bzl*
http_archivehttp_archive
7C
E�
!//tools/build_defs/repo:utils.bzlr]
/
bazel_toolstools/build_defs/repo	utils.bzl
maybemaybe
8=
?w
//toolchains:deps.bzlr\
&
rules_synology
toolchainsdeps.bzl$
depstoolchain_deps
.<
F 