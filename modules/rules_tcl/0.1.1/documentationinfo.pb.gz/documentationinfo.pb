�W
*
	rules_tcltcl/private/lintinglint.bzl�current_tcl_tclint_toolchainKA rule for accessing the `tclint` attribute of the current `tcl_toolchain`."�
�
current_tcl_tclint_toolchainKA rule for accessing the `tclint` attribute of the current `tcl_toolchain`.*
nameA unique name for this target. "I
current_tcl_tclint_toolchain)@@rules_tcl//tcl/private/linting:lint.bzl
$$,
*
nameA unique name for this target. �tcl_format_test�A test rule for performing formatting checks on a Tcl target.

The `tcl_format_test` rule creates a test that verifies a Tcl target's source files are
properly formatted according to the configured style. This is useful for enforcing
consistent code style in CI/CD pipelines.

**Usage:**

```python
load("@rules_tcl//tcl:tcl_format_test.bzl", "tcl_format_test")

tcl_library(
    name = "mylib",
    srcs = ["mylib.tcl", "pkgIndex.tcl"],
)

tcl_format_test(
    name = "mylib_format",
    target = ":mylib",
)
```

Run the format test with:

```bash
bazel test //path/to:mylib_format
```

The test will fail if any source files are not properly formatted. Unlike `tcl_lint_test`,
this test includes `pkgIndex.tcl` files in the formatting check.
"�
�
tcl_format_test�A test rule for performing formatting checks on a Tcl target.

The `tcl_format_test` rule creates a test that verifies a Tcl target's source files are
properly formatted according to the configured style. This is useful for enforcing
consistent code style in CI/CD pipelines.

**Usage:**

```python
load("@rules_tcl//tcl:tcl_format_test.bzl", "tcl_format_test")

tcl_library(
    name = "mylib",
    srcs = ["mylib.tcl", "pkgIndex.tcl"],
)

tcl_format_test(
    name = "mylib_format",
    target = ":mylib",
)
```

Run the format test with:

```bash
bazel test //path/to:mylib_format
```

The test will fail if any source files are not properly formatted. Unlike `tcl_lint_test`,
this test includes `pkgIndex.tcl` files in the formatting check.
*
nameA unique name for this target. �
target�The Tcl target to perform formatting checks on.

This must be a target that provides `TclInfo` (e.g., `tcl_library`, `tcl_binary`, or `tcl_test`).
The test will check formatting for all source files in this target, including `pkgIndex.tcl` files.
 *	
TclInfo"<
tcl_format_test)@@rules_tcl//tcl/private/linting:lint.bzl
��,
*
nameA unique name for this target. �
�
target�The Tcl target to perform formatting checks on.

This must be a target that provides `TclInfo` (e.g., `tcl_library`, `tcl_binary`, or `tcl_test`).
The test will check formatting for all source files in this target, including `pkgIndex.tcl` files.
 *	
TclInfo�tcl_lint_test�A test rule for performing linting checks on a Tcl target.

The `tcl_lint_test` rule creates a test that verifies a Tcl target passes linting checks.
This is useful for enforcing code quality in CI/CD pipelines.

**Usage:**

```python
load("@rules_tcl//tcl:tcl_lint_test.bzl", "tcl_lint_test")

tcl_library(
    name = "mylib",
    srcs = ["mylib.tcl", "pkgIndex.tcl"],
)

tcl_lint_test(
    name = "mylib_lint",
    target = ":mylib",
)
```

Run the lint test with:

```bash
bazel test //path/to:mylib_lint
```

The test will fail if the target has any linting errors. The test automatically excludes
`pkgIndex.tcl` files from linting, as these are typically generated or follow a specific format.
"�

�
tcl_lint_test�A test rule for performing linting checks on a Tcl target.

The `tcl_lint_test` rule creates a test that verifies a Tcl target passes linting checks.
This is useful for enforcing code quality in CI/CD pipelines.

**Usage:**

```python
load("@rules_tcl//tcl:tcl_lint_test.bzl", "tcl_lint_test")

tcl_library(
    name = "mylib",
    srcs = ["mylib.tcl", "pkgIndex.tcl"],
)

tcl_lint_test(
    name = "mylib_lint",
    target = ":mylib",
)
```

Run the lint test with:

```bash
bazel test //path/to:mylib_lint
```

The test will fail if the target has any linting errors. The test automatically excludes
`pkgIndex.tcl` files from linting, as these are typically generated or follow a specific format.
*
nameA unique name for this target. �
target�The Tcl target to perform linting on.

This must be a target that provides `TclInfo` (e.g., `tcl_library`, `tcl_binary`, or `tcl_test`).
The test will lint all source files in this target, excluding `pkgIndex.tcl` files.
 *	
TclInfo":
tcl_lint_test)@@rules_tcl//tcl/private/linting:lint.bzl
��,
*
nameA unique name for this target. �
�
target�The Tcl target to perform linting on.

This must be a target that provides `TclInfo` (e.g., `tcl_library`, `tcl_binary`, or `tcl_test`).
The test will lint all source files in this target, excluding `pkgIndex.tcl` files.
 *	
TclInfo�	find_srcsrFind all lintable source files for a given target.

Note that generated files and pkgIndex.tcl files are ignored.
*�
�
	find_srcs)
targetThe target to collect from. (rFind all lintable source files for a given target.

Note that generated files and pkgIndex.tcl files are ignored.
"2
0depset[File]: A depset of lintable source files.26
	find_srcs)@@rules_tcl//tcl/private/linting:lint.bzl
%%�tcl_format_aspect�
An aspect for performing formatting checks on Tcl targets.

The `tcl_format_aspect` checks that Tcl source files are properly formatted according to
the configured style. It uses [tclint](https://github.com/nmoroze/tclint) to verify formatting.

**Usage:**

Apply the aspect to check formatting of all dependencies via command line:

```bash
bazel build //my:target --aspects=@rules_tcl//tcl:tcl_format_aspect.bzl%tcl_format_aspect
```

Or configure it in your `.bazelrc` file to enable format checking for all builds:

```bazelrc
# Enable tclfmt for all targets in the workspace
build:tclfmt --aspects=@rules_tcl//tcl:tcl_format_aspect.bzl%tcl_format_aspect
build:tclfmt --output_groups=+tcl_format_checks
```

Then use it with:
```bash
bazel build //my:target --config=tclfmt
```

Or use it in a test:

```python
load("@rules_tcl//tcl:tcl_format_test.bzl", "tcl_format_test")

tcl_format_test(
    name = "format_check",
    target = ":my_library",
)
```

**Ignoring targets:**

To skip format checking for specific targets, add one of these tags:
- `no_tcl_format`
- `no_tclformat`
- `no_tclfmt`
- `noformat`
- `nofmt`

```python
tcl_library(
    name = "generated_code",
    srcs = ["generated.tcl"],
    tags = ["no_tcl_format"],
)
```

The aspect processes all source files including `pkgIndex.tcl` files.
:�
�
tcl_format_aspect�
An aspect for performing formatting checks on Tcl targets.

The `tcl_format_aspect` checks that Tcl source files are properly formatted according to
the configured style. It uses [tclint](https://github.com/nmoroze/tclint) to verify formatting.

**Usage:**

Apply the aspect to check formatting of all dependencies via command line:

```bash
bazel build //my:target --aspects=@rules_tcl//tcl:tcl_format_aspect.bzl%tcl_format_aspect
```

Or configure it in your `.bazelrc` file to enable format checking for all builds:

```bazelrc
# Enable tclfmt for all targets in the workspace
build:tclfmt --aspects=@rules_tcl//tcl:tcl_format_aspect.bzl%tcl_format_aspect
build:tclfmt --output_groups=+tcl_format_checks
```

Then use it with:
```bash
bazel build //my:target --config=tclfmt
```

Or use it in a test:

```python
load("@rules_tcl//tcl:tcl_format_test.bzl", "tcl_format_test")

tcl_format_test(
    name = "format_check",
    target = ":my_library",
)
```

**Ignoring targets:**

To skip format checking for specific targets, add one of these tags:
- `no_tcl_format`
- `no_tclformat`
- `no_tclfmt`
- `noformat`
- `nofmt`

```python
tcl_library(
    name = "generated_code",
    srcs = ["generated.tcl"],
    tags = ["no_tcl_format"],
)
```

The aspect processes all source files including `pkgIndex.tcl` files.
"*
nameA unique name for this target. *>
tcl_format_aspect)@@rules_tcl//tcl/private/linting:lint.bzl
��,
*
nameA unique name for this target. �tcl_lint_aspect�	An aspect for performing linting checks on Tcl targets.

The `tcl_lint_aspect` applies linting checks to all Tcl targets in the dependency graph.
It uses [tclint](https://github.com/nmoroze/tclint) to check for code quality issues.

**Usage:**

Apply the aspect to check all dependencies of a target via command line:

```bash
bazel build //my:target --aspects=@rules_tcl//tcl:tcl_lint_aspect.bzl%tcl_lint_aspect
```

Or configure it in your `.bazelrc` file to enable linting for all builds:

```bazelrc
# Enable tclint for all targets in the workspace
build:tclint --aspects=@rules_tcl//tcl:tcl_lint_aspect.bzl%tcl_lint_aspect
build:tclint --output_groups=+tcl_lint_checks
```

Then use it with:
```bash
bazel build //my:target --config=tclint
```

Or use it in a test:

```python
load("@rules_tcl//tcl:tcl_lint_test.bzl", "tcl_lint_test")

tcl_lint_test(
    name = "lint_check",
    target = ":my_library",
)
```

**Ignoring targets:**

To skip linting for specific targets, add one of these tags:
- `no_tcl_lint`
- `no_lint`
- `nolint`

```python
tcl_library(
    name = "legacy_code",
    srcs = ["legacy.tcl"],
    tags = ["no_tcl_lint"],
)
```

The aspect only processes source files (not generated files) and excludes `pkgIndex.tcl` files.
:�
�

tcl_lint_aspect�	An aspect for performing linting checks on Tcl targets.

The `tcl_lint_aspect` applies linting checks to all Tcl targets in the dependency graph.
It uses [tclint](https://github.com/nmoroze/tclint) to check for code quality issues.

**Usage:**

Apply the aspect to check all dependencies of a target via command line:

```bash
bazel build //my:target --aspects=@rules_tcl//tcl:tcl_lint_aspect.bzl%tcl_lint_aspect
```

Or configure it in your `.bazelrc` file to enable linting for all builds:

```bazelrc
# Enable tclint for all targets in the workspace
build:tclint --aspects=@rules_tcl//tcl:tcl_lint_aspect.bzl%tcl_lint_aspect
build:tclint --output_groups=+tcl_lint_checks
```

Then use it with:
```bash
bazel build //my:target --config=tclint
```

Or use it in a test:

```python
load("@rules_tcl//tcl:tcl_lint_test.bzl", "tcl_lint_test")

tcl_lint_test(
    name = "lint_check",
    target = ":my_library",
)
```

**Ignoring targets:**

To skip linting for specific targets, add one of these tags:
- `no_tcl_lint`
- `no_lint`
- `nolint`

```python
tcl_library(
    name = "legacy_code",
    srcs = ["legacy.tcl"],
    tags = ["no_tcl_lint"],
)
```

The aspect only processes source files (not generated files) and excludes `pkgIndex.tcl` files.
"*
nameA unique name for this target. *<
tcl_lint_aspect)@@rules_tcl//tcl/private/linting:lint.bzl
ee,
*
nameA unique name for this target. z
//tcl/private:providers.bzlrY
'
	rules_tcltcl/privateproviders.bzl 
TclInfoTclInfo
07
9�
//tcl/private:toolchain.bzlrg
'
	rules_tcltcl/privatetoolchain.bzl.
TOOLCHAIN_TYPETOOLCHAIN_TYPE
0>
@k
//python:py_info.bzlrQ
!

rules_venvpythonpy_info.bzl
PyInfoPyInfo
*0
2TCL Lint rules�
'
	rules_tcltcl/privateproviders.bzl�TclInfoInfo about a Tcl target.2�
�
TclInfoInfo about a Tcl target.T
includesHDepset[str]: A list of include paths associated with the current target.@
srcs8Depset[File]: Direct source files of the current target.D
transitive_includes-Depset[str]: Include paths from dependencies.T
transitive_srcsADepset[File]: Source files required at runtime from dependencies."1
TclInfo&@@rules_tcl//tcl/private:providers.bzl
V
T
includesHDepset[str]: A list of include paths associated with the current target.B
@
srcs8Depset[File]: Direct source files of the current target.F
D
transitive_includes-Depset[str]: Include paths from dependencies.V
T
transitive_srcsADepset[File]: Source files required at runtime from dependencies.TCL Providers�J
!
	rules_tcltcl/privatetcl.bzl�
tcl_binary�A `tcl_binary` is an executable Tcl program consisting of a collection of
`.tcl` source files (possibly belonging to other `tcl_library` rules), a `*.runfiles`
directory tree containing all the code and data needed by the program at run-time,
and a stub script that starts up the program with the correct initial environment
and data.

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_binary")

tcl_binary(
    name = "foo",
    srcs = ["foo.tcl"],
    deps = [
        ":bar",  # a tcl_library
    ],
)
```
"�
�	

tcl_binary�A `tcl_binary` is an executable Tcl program consisting of a collection of
`.tcl` source files (possibly belonging to other `tcl_library` rules), a `*.runfiles`
directory tree containing all the code and data needed by the program at run-time,
and a stub script that starts up the program with the correct initial environment
and data.

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_binary")

tcl_binary(
    name = "foo",
    srcs = ["foo.tcl"],
    deps = [
        ":bar",  # a tcl_library
    ],
)
```
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2NoneV
srcsJThe list of source (`.tcl`) files that are processed to create the target. ".

tcl_binary @@rules_tcl//tcl/private:tcl.bzl
��,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]L
J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]k
i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}�
�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2NoneX
V
srcsJThe list of source (`.tcl`) files that are processed to create the target. �tcl_library�A Tcl library that can be depended upon by other Tcl targets.

A `tcl_library` represents a Tcl package that can be imported using Tcl's `package require` command.
The library must include a `pkgIndex.tcl` file in its `srcs` attribute, which defines the package
metadata and how to load the package.

**Important**: The `pkgIndex.tcl` file must be included in the `srcs` attribute. This file is used
by Tcl's package system to locate and load the package.

Example:

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_library")

tcl_library(
    name = "mylib",
    srcs = [
        "mylib.tcl",
        "pkgIndex.tcl",
    ],
    deps = [
        ":otherlib",  # Another tcl_library
    ],
    visibility = ["//visibility:public"],
)
```

The library can then be used as a dependency in other targets:

```python
tcl_binary(
    name = "app",
    srcs = ["app.tcl"],
    deps = [":mylib"],
)
```
"�
�

tcl_library�A Tcl library that can be depended upon by other Tcl targets.

A `tcl_library` represents a Tcl package that can be imported using Tcl's `package require` command.
The library must include a `pkgIndex.tcl` file in its `srcs` attribute, which defines the package
metadata and how to load the package.

**Important**: The `pkgIndex.tcl` file must be included in the `srcs` attribute. This file is used
by Tcl's package system to locate and load the package.

Example:

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_library")

tcl_library(
    name = "mylib",
    srcs = [
        "mylib.tcl",
        "pkgIndex.tcl",
    ],
    deps = [
        ":otherlib",  # Another tcl_library
    ],
    visibility = ["//visibility:public"],
)
```

The library can then be used as a dependency in other targets:

```python
tcl_binary(
    name = "app",
    srcs = ["app.tcl"],
    deps = [":mylib"],
)
```
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]V
srcsJThe list of source (`.tcl`) files that are processed to create the target. "/
tcl_library @@rules_tcl//tcl/private:tcl.bzl
��,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]L
J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]X
V
srcsJThe list of source (`.tcl`) files that are processed to create the target. � tcl_test�A test rule for Tcl code that can be executed with `bazel test`.

A `tcl_test` is similar to a `tcl_binary` but is designed for testing. It supports all the same
attributes as `tcl_binary`, plus additional test-specific features like environment variable
inheritance.

Tests are executed by Bazel's test runner and can be run with:

```bash
bazel test //path/to:my_test
```

Example:

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_test")

tcl_test(
    name = "my_test",
    srcs = ["test.tcl"],
    deps = [
        ":mylib",  # The library being tested
    ],
    env = {
        "TEST_MODE": "1",
    },
    env_inherit = ["PATH"],  # Inherit PATH from the environment
)
```

The test can use Tcl's standard testing frameworks or custom test code. Test failures are
detected by non-zero exit codes.
"�
�
tcl_test�A test rule for Tcl code that can be executed with `bazel test`.

A `tcl_test` is similar to a `tcl_binary` but is designed for testing. It supports all the same
attributes as `tcl_binary`, plus additional test-specific features like environment variable
inheritance.

Tests are executed by Bazel's test runner and can be run with:

```bash
bazel test //path/to:my_test
```

Example:

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_test")

tcl_test(
    name = "my_test",
    srcs = ["test.tcl"],
    deps = [
        ":mylib",  # The library being tested
    ],
    env = {
        "TEST_MODE": "1",
    },
    env_inherit = ["PATH"],  # Inherit PATH from the environment
)
```

The test can use Tcl's standard testing frameworks or custom test code. Test failures are
detected by non-zero exit codes.
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}�
env_inherit�Specifies additional environment variables to inherit from the external environment.

This attribute is only available for `tcl_test` rules. When the test is executed by
`bazel test`, these environment variables from the host environment will be passed
through to the test.

Example:
```python
tcl_test(
    name = "my_test",
    srcs = ["test.tcl"],
    env_inherit = [
        "PATH",
        "HOME",
        "USER",
    ],
)
```

This is useful when tests need access to system tools or user-specific configuration.
2[]�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2NoneV
srcsJThe list of source (`.tcl`) files that are processed to create the target. ",
tcl_test @@rules_tcl//tcl/private:tcl.bzl
��,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]L
J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]k
i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}�
�
env_inherit�Specifies additional environment variables to inherit from the external environment.

This attribute is only available for `tcl_test` rules. When the test is executed by
`bazel test`, these environment variables from the host environment will be passed
through to the test.

Example:
```python
tcl_test(
    name = "my_test",
    srcs = ["test.tcl"],
    env_inherit = [
        "PATH",
        "HOME",
        "USER",
    ],
)
```

This is useful when tests need access to system tools or user-specific configuration.
2[]�
�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2NoneX
V
srcsJThe list of source (`.tcl`) files that are processed to create the target. z
//tcl/private:providers.bzlrY
'
	rules_tcltcl/privateproviders.bzl 
TclInfoTclInfo
07
9�
//tcl/private:toolchain.bzlrg
'
	rules_tcltcl/privatetoolchain.bzl.
TOOLCHAIN_TYPETOOLCHAIN_TYPE
0>
@	Tcl rules�
'
	rules_tcltcl/privatetoolchain.bzl�tcl_toolchain�A toolchain rule that defines the Tcl interpreter and libraries for building Tcl targets.

The `tcl_toolchain` rule configures the Tcl environment used by all `tcl_binary`, `tcl_library`,
and `tcl_test` targets. It specifies:
- The Tcl interpreter (`tclsh`) to use for execution
- The Tcl core library files (`tclcore`)
- The Tcl standard library (`tcllib`)
- Optional linting tools (`tclint`) for code quality checks

Typically, you don't need to create a `tcl_toolchain` directly. The rules provide a default
toolchain that you register in your `MODULE.bazel`:

```python
register_toolchains("@rules_tcl//tcl/toolchain")
```

If you need a custom toolchain (e.g., a different Tcl version), you can define your own:

```python
load("@rules_tcl//tcl:tcl_toolchain.bzl", "tcl_toolchain")

tcl_toolchain(
    name = "my_tcl_toolchain",
    tclsh = "@tcl_8_6//:tclsh",
    tclcore = "@tcl_8_6//:tclcore",
    tcllib = "@tcllib//:tcllib",
    tclint = "@tclint//:tclint",  # Optional, for linting
)
```
"�
�
tcl_toolchain�A toolchain rule that defines the Tcl interpreter and libraries for building Tcl targets.

The `tcl_toolchain` rule configures the Tcl environment used by all `tcl_binary`, `tcl_library`,
and `tcl_test` targets. It specifies:
- The Tcl interpreter (`tclsh`) to use for execution
- The Tcl core library files (`tclcore`)
- The Tcl standard library (`tcllib`)
- Optional linting tools (`tclint`) for code quality checks

Typically, you don't need to create a `tcl_toolchain` directly. The rules provide a default
toolchain that you register in your `MODULE.bazel`:

```python
register_toolchains("@rules_tcl//tcl/toolchain")
```

If you need a custom toolchain (e.g., a different Tcl version), you can define your own:

```python
load("@rules_tcl//tcl:tcl_toolchain.bzl", "tcl_toolchain")

tcl_toolchain(
    name = "my_tcl_toolchain",
    tclsh = "@tcl_8_6//:tclsh",
    tclcore = "@tcl_8_6//:tclcore",
    tcllib = "@tcllib//:tcllib",
    tclint = "@tclint//:tclint",  # Optional, for linting
)
```
*
nameA unique name for this target. .
tclcoreA label to the `tclcore` files. �
tclint�The [`tclint`](https://github.com/nmoroze/tclint) python library. This attribute is required for [`tcl_lint_aspect`](#tcl_lint_aspect)/[`tcl_format_aspect`](#tcl_format_aspect) but otherwise optional for core rules.2None,
tcllibA label to the `tcllib` files. *
tclshThe path to a `tclsh` binary. "7
tcl_toolchain&@@rules_tcl//tcl/private:toolchain.bzl
II,
*
nameA unique name for this target. 0
.
tclcoreA label to the `tclcore` files. �
�
tclint�The [`tclint`](https://github.com/nmoroze/tclint) python library. This attribute is required for [`tcl_lint_aspect`](#tcl_lint_aspect)/[`tcl_format_aspect`](#tcl_format_aspect) but otherwise optional for core rules.2None.
,
tcllibA label to the `tcllib` files. ,
*
tclshThe path to a `tclsh` binary. D	TOOLCHAIN_TYPE@@//tcl:toolchain_typej@@//tcl:toolchain_typetcl toolchain rules�
'
	rules_tcltcl/settingssettings.bzl�tclint_configThe [tclint](https://github.com/nmoroze/tclint/blob/main/docs/configuration.md) config file to use in linting/formatting rules.*�
�
tclint_configThe [tclint](https://github.com/nmoroze/tclint/blob/main/docs/configuration.md) config file to use in linting/formatting rules.27
tclint_config&@@rules_tcl//tcl/settings:settings.bzl
?# TCL settings

Definitions for all `@rules_tcl//tcl` settings
�q

	rules_tcltcldefs.bzl�
tcl_binary�A `tcl_binary` is an executable Tcl program consisting of a collection of
`.tcl` source files (possibly belonging to other `tcl_library` rules), a `*.runfiles`
directory tree containing all the code and data needed by the program at run-time,
and a stub script that starts up the program with the correct initial environment
and data.

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_binary")

tcl_binary(
    name = "foo",
    srcs = ["foo.tcl"],
    deps = [
        ":bar",  # a tcl_library
    ],
)
```
"�
�	

tcl_binary�A `tcl_binary` is an executable Tcl program consisting of a collection of
`.tcl` source files (possibly belonging to other `tcl_library` rules), a `*.runfiles`
directory tree containing all the code and data needed by the program at run-time,
and a stub script that starts up the program with the correct initial environment
and data.

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_binary")

tcl_binary(
    name = "foo",
    srcs = ["foo.tcl"],
    deps = [
        ":bar",  # a tcl_library
    ],
)
```
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2NoneV
srcsJThe list of source (`.tcl`) files that are processed to create the target. "'

tcl_binary@@rules_tcl//tcl:defs.bzl
��,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]L
J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]k
i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}�
�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2NoneX
V
srcsJThe list of source (`.tcl`) files that are processed to create the target. �tcl_library�A Tcl library that can be depended upon by other Tcl targets.

A `tcl_library` represents a Tcl package that can be imported using Tcl's `package require` command.
The library must include a `pkgIndex.tcl` file in its `srcs` attribute, which defines the package
metadata and how to load the package.

**Important**: The `pkgIndex.tcl` file must be included in the `srcs` attribute. This file is used
by Tcl's package system to locate and load the package.

Example:

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_library")

tcl_library(
    name = "mylib",
    srcs = [
        "mylib.tcl",
        "pkgIndex.tcl",
    ],
    deps = [
        ":otherlib",  # Another tcl_library
    ],
    visibility = ["//visibility:public"],
)
```

The library can then be used as a dependency in other targets:

```python
tcl_binary(
    name = "app",
    srcs = ["app.tcl"],
    deps = [":mylib"],
)
```
"�
�	
tcl_library�A Tcl library that can be depended upon by other Tcl targets.

A `tcl_library` represents a Tcl package that can be imported using Tcl's `package require` command.
The library must include a `pkgIndex.tcl` file in its `srcs` attribute, which defines the package
metadata and how to load the package.

**Important**: The `pkgIndex.tcl` file must be included in the `srcs` attribute. This file is used
by Tcl's package system to locate and load the package.

Example:

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_library")

tcl_library(
    name = "mylib",
    srcs = [
        "mylib.tcl",
        "pkgIndex.tcl",
    ],
    deps = [
        ":otherlib",  # Another tcl_library
    ],
    visibility = ["//visibility:public"],
)
```

The library can then be used as a dependency in other targets:

```python
tcl_binary(
    name = "app",
    srcs = ["app.tcl"],
    deps = [":mylib"],
)
```
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]V
srcsJThe list of source (`.tcl`) files that are processed to create the target. "(
tcl_library@@rules_tcl//tcl:defs.bzl
��,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]L
J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]X
V
srcsJThe list of source (`.tcl`) files that are processed to create the target. �tcl_toolchain�A toolchain rule that defines the Tcl interpreter and libraries for building Tcl targets.

The `tcl_toolchain` rule configures the Tcl environment used by all `tcl_binary`, `tcl_library`,
and `tcl_test` targets. It specifies:
- The Tcl interpreter (`tclsh`) to use for execution
- The Tcl core library files (`tclcore`)
- The Tcl standard library (`tcllib`)
- Optional linting tools (`tclint`) for code quality checks

Typically, you don't need to create a `tcl_toolchain` directly. The rules provide a default
toolchain that you register in your `MODULE.bazel`:

```python
register_toolchains("@rules_tcl//tcl/toolchain")
```

If you need a custom toolchain (e.g., a different Tcl version), you can define your own:

```python
load("@rules_tcl//tcl:tcl_toolchain.bzl", "tcl_toolchain")

tcl_toolchain(
    name = "my_tcl_toolchain",
    tclsh = "@tcl_8_6//:tclsh",
    tclcore = "@tcl_8_6//:tclcore",
    tcllib = "@tcllib//:tcllib",
    tclint = "@tclint//:tclint",  # Optional, for linting
)
```
"�
�
tcl_toolchain�A toolchain rule that defines the Tcl interpreter and libraries for building Tcl targets.

The `tcl_toolchain` rule configures the Tcl environment used by all `tcl_binary`, `tcl_library`,
and `tcl_test` targets. It specifies:
- The Tcl interpreter (`tclsh`) to use for execution
- The Tcl core library files (`tclcore`)
- The Tcl standard library (`tcllib`)
- Optional linting tools (`tclint`) for code quality checks

Typically, you don't need to create a `tcl_toolchain` directly. The rules provide a default
toolchain that you register in your `MODULE.bazel`:

```python
register_toolchains("@rules_tcl//tcl/toolchain")
```

If you need a custom toolchain (e.g., a different Tcl version), you can define your own:

```python
load("@rules_tcl//tcl:tcl_toolchain.bzl", "tcl_toolchain")

tcl_toolchain(
    name = "my_tcl_toolchain",
    tclsh = "@tcl_8_6//:tclsh",
    tclcore = "@tcl_8_6//:tclcore",
    tcllib = "@tcllib//:tcllib",
    tclint = "@tclint//:tclint",  # Optional, for linting
)
```
*
nameA unique name for this target. .
tclcoreA label to the `tclcore` files. �
tclint�The [`tclint`](https://github.com/nmoroze/tclint) python library. This attribute is required for [`tcl_lint_aspect`](#tcl_lint_aspect)/[`tcl_format_aspect`](#tcl_format_aspect) but otherwise optional for core rules.2None,
tcllibA label to the `tcllib` files. *
tclshThe path to a `tclsh` binary. "*
tcl_toolchain@@rules_tcl//tcl:defs.bzl
II,
*
nameA unique name for this target. 0
.
tclcoreA label to the `tclcore` files. �
�
tclint�The [`tclint`](https://github.com/nmoroze/tclint) python library. This attribute is required for [`tcl_lint_aspect`](#tcl_lint_aspect)/[`tcl_format_aspect`](#tcl_format_aspect) but otherwise optional for core rules.2None.
,
tcllibA label to the `tcllib` files. ,
*
tclshThe path to a `tclsh` binary. �tcl_format_aspect�
An aspect for performing formatting checks on Tcl targets.

The `tcl_format_aspect` checks that Tcl source files are properly formatted according to
the configured style. It uses [tclint](https://github.com/nmoroze/tclint) to verify formatting.

**Usage:**

Apply the aspect to check formatting of all dependencies via command line:

```bash
bazel build //my:target --aspects=@rules_tcl//tcl:tcl_format_aspect.bzl%tcl_format_aspect
```

Or configure it in your `.bazelrc` file to enable format checking for all builds:

```bazelrc
# Enable tclfmt for all targets in the workspace
build:tclfmt --aspects=@rules_tcl//tcl:tcl_format_aspect.bzl%tcl_format_aspect
build:tclfmt --output_groups=+tcl_format_checks
```

Then use it with:
```bash
bazel build //my:target --config=tclfmt
```

Or use it in a test:

```python
load("@rules_tcl//tcl:tcl_format_test.bzl", "tcl_format_test")

tcl_format_test(
    name = "format_check",
    target = ":my_library",
)
```

**Ignoring targets:**

To skip format checking for specific targets, add one of these tags:
- `no_tcl_format`
- `no_tclformat`
- `no_tclfmt`
- `noformat`
- `nofmt`

```python
tcl_library(
    name = "generated_code",
    srcs = ["generated.tcl"],
    tags = ["no_tcl_format"],
)
```

The aspect processes all source files including `pkgIndex.tcl` files.
:�
�
tcl_format_aspect�
An aspect for performing formatting checks on Tcl targets.

The `tcl_format_aspect` checks that Tcl source files are properly formatted according to
the configured style. It uses [tclint](https://github.com/nmoroze/tclint) to verify formatting.

**Usage:**

Apply the aspect to check formatting of all dependencies via command line:

```bash
bazel build //my:target --aspects=@rules_tcl//tcl:tcl_format_aspect.bzl%tcl_format_aspect
```

Or configure it in your `.bazelrc` file to enable format checking for all builds:

```bazelrc
# Enable tclfmt for all targets in the workspace
build:tclfmt --aspects=@rules_tcl//tcl:tcl_format_aspect.bzl%tcl_format_aspect
build:tclfmt --output_groups=+tcl_format_checks
```

Then use it with:
```bash
bazel build //my:target --config=tclfmt
```

Or use it in a test:

```python
load("@rules_tcl//tcl:tcl_format_test.bzl", "tcl_format_test")

tcl_format_test(
    name = "format_check",
    target = ":my_library",
)
```

**Ignoring targets:**

To skip format checking for specific targets, add one of these tags:
- `no_tcl_format`
- `no_tclformat`
- `no_tclfmt`
- `noformat`
- `nofmt`

```python
tcl_library(
    name = "generated_code",
    srcs = ["generated.tcl"],
    tags = ["no_tcl_format"],
)
```

The aspect processes all source files including `pkgIndex.tcl` files.
"*
nameA unique name for this target. *.
tcl_format_aspect@@rules_tcl//tcl:defs.bzl
��,
*
nameA unique name for this target. �tcl_lint_aspect�	An aspect for performing linting checks on Tcl targets.

The `tcl_lint_aspect` applies linting checks to all Tcl targets in the dependency graph.
It uses [tclint](https://github.com/nmoroze/tclint) to check for code quality issues.

**Usage:**

Apply the aspect to check all dependencies of a target via command line:

```bash
bazel build //my:target --aspects=@rules_tcl//tcl:tcl_lint_aspect.bzl%tcl_lint_aspect
```

Or configure it in your `.bazelrc` file to enable linting for all builds:

```bazelrc
# Enable tclint for all targets in the workspace
build:tclint --aspects=@rules_tcl//tcl:tcl_lint_aspect.bzl%tcl_lint_aspect
build:tclint --output_groups=+tcl_lint_checks
```

Then use it with:
```bash
bazel build //my:target --config=tclint
```

Or use it in a test:

```python
load("@rules_tcl//tcl:tcl_lint_test.bzl", "tcl_lint_test")

tcl_lint_test(
    name = "lint_check",
    target = ":my_library",
)
```

**Ignoring targets:**

To skip linting for specific targets, add one of these tags:
- `no_tcl_lint`
- `no_lint`
- `nolint`

```python
tcl_library(
    name = "legacy_code",
    srcs = ["legacy.tcl"],
    tags = ["no_tcl_lint"],
)
```

The aspect only processes source files (not generated files) and excludes `pkgIndex.tcl` files.
:�
�

tcl_lint_aspect�	An aspect for performing linting checks on Tcl targets.

The `tcl_lint_aspect` applies linting checks to all Tcl targets in the dependency graph.
It uses [tclint](https://github.com/nmoroze/tclint) to check for code quality issues.

**Usage:**

Apply the aspect to check all dependencies of a target via command line:

```bash
bazel build //my:target --aspects=@rules_tcl//tcl:tcl_lint_aspect.bzl%tcl_lint_aspect
```

Or configure it in your `.bazelrc` file to enable linting for all builds:

```bazelrc
# Enable tclint for all targets in the workspace
build:tclint --aspects=@rules_tcl//tcl:tcl_lint_aspect.bzl%tcl_lint_aspect
build:tclint --output_groups=+tcl_lint_checks
```

Then use it with:
```bash
bazel build //my:target --config=tclint
```

Or use it in a test:

```python
load("@rules_tcl//tcl:tcl_lint_test.bzl", "tcl_lint_test")

tcl_lint_test(
    name = "lint_check",
    target = ":my_library",
)
```

**Ignoring targets:**

To skip linting for specific targets, add one of these tags:
- `no_tcl_lint`
- `no_lint`
- `nolint`

```python
tcl_library(
    name = "legacy_code",
    srcs = ["legacy.tcl"],
    tags = ["no_tcl_lint"],
)
```

The aspect only processes source files (not generated files) and excludes `pkgIndex.tcl` files.
"*
nameA unique name for this target. *,
tcl_lint_aspect@@rules_tcl//tcl:defs.bzl
ee,
*
nameA unique name for this target. s
//tcl:tcl_binary.bzlrY
 
	rules_tcltcltcl_binary.bzl'

tcl_binary_tcl_binary
(3
C�
//tcl:tcl_format_aspect.bzlrn
'
	rules_tcltcltcl_format_aspect.bzl5
tcl_format_aspect_tcl_format_aspect
/A
X�
//tcl:tcl_format_test.bzlrh
%
	rules_tcltcltcl_format_test.bzl1
tcl_format_test_tcl_format_test
-=
Rw
//tcl:tcl_library.bzlr\
!
	rules_tcltcltcl_library.bzl)
tcl_library_tcl_library
)5
F�
//tcl:tcl_lint_aspect.bzlrh
%
	rules_tcltcltcl_lint_aspect.bzl1
tcl_lint_aspect_tcl_lint_aspect
-=
R
//tcl:tcl_lint_test.bzlrb
#
	rules_tcltcltcl_lint_test.bzl-
tcl_lint_test_tcl_lint_test
+9
L
//tcl:tcl_toolchain.bzlrb
#
	rules_tcltcltcl_toolchain.bzl-
tcl_toolchain_tcl_toolchain
	+	9
		LTcl Bazel rules�
 
	rules_tcltcltcl_binary.bzl�
tcl_binary�A `tcl_binary` is an executable Tcl program consisting of a collection of
`.tcl` source files (possibly belonging to other `tcl_library` rules), a `*.runfiles`
directory tree containing all the code and data needed by the program at run-time,
and a stub script that starts up the program with the correct initial environment
and data.

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_binary")

tcl_binary(
    name = "foo",
    srcs = ["foo.tcl"],
    deps = [
        ":bar",  # a tcl_library
    ],
)
```
"�
�	

tcl_binary�A `tcl_binary` is an executable Tcl program consisting of a collection of
`.tcl` source files (possibly belonging to other `tcl_library` rules), a `*.runfiles`
directory tree containing all the code and data needed by the program at run-time,
and a stub script that starts up the program with the correct initial environment
and data.

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_binary")

tcl_binary(
    name = "foo",
    srcs = ["foo.tcl"],
    deps = [
        ":bar",  # a tcl_library
    ],
)
```
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2NoneV
srcsJThe list of source (`.tcl`) files that are processed to create the target. "-

tcl_binary@@rules_tcl//tcl:tcl_binary.bzl
��,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]L
J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]k
i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}�
�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2NoneX
V
srcsJThe list of source (`.tcl`) files that are processed to create the target. u
//tcl/private:tcl.bzlrZ
!
	rules_tcltcl/privatetcl.bzl'

tcl_binary_tcl_binary
)4
D
tcl_binary�
'
	rules_tcltcltcl_format_aspect.bzl�tcl_format_aspect�
An aspect for performing formatting checks on Tcl targets.

The `tcl_format_aspect` checks that Tcl source files are properly formatted according to
the configured style. It uses [tclint](https://github.com/nmoroze/tclint) to verify formatting.

**Usage:**

Apply the aspect to check formatting of all dependencies via command line:

```bash
bazel build //my:target --aspects=@rules_tcl//tcl:tcl_format_aspect.bzl%tcl_format_aspect
```

Or configure it in your `.bazelrc` file to enable format checking for all builds:

```bazelrc
# Enable tclfmt for all targets in the workspace
build:tclfmt --aspects=@rules_tcl//tcl:tcl_format_aspect.bzl%tcl_format_aspect
build:tclfmt --output_groups=+tcl_format_checks
```

Then use it with:
```bash
bazel build //my:target --config=tclfmt
```

Or use it in a test:

```python
load("@rules_tcl//tcl:tcl_format_test.bzl", "tcl_format_test")

tcl_format_test(
    name = "format_check",
    target = ":my_library",
)
```

**Ignoring targets:**

To skip format checking for specific targets, add one of these tags:
- `no_tcl_format`
- `no_tclformat`
- `no_tclfmt`
- `noformat`
- `nofmt`

```python
tcl_library(
    name = "generated_code",
    srcs = ["generated.tcl"],
    tags = ["no_tcl_format"],
)
```

The aspect processes all source files including `pkgIndex.tcl` files.
:�
�
tcl_format_aspect�
An aspect for performing formatting checks on Tcl targets.

The `tcl_format_aspect` checks that Tcl source files are properly formatted according to
the configured style. It uses [tclint](https://github.com/nmoroze/tclint) to verify formatting.

**Usage:**

Apply the aspect to check formatting of all dependencies via command line:

```bash
bazel build //my:target --aspects=@rules_tcl//tcl:tcl_format_aspect.bzl%tcl_format_aspect
```

Or configure it in your `.bazelrc` file to enable format checking for all builds:

```bazelrc
# Enable tclfmt for all targets in the workspace
build:tclfmt --aspects=@rules_tcl//tcl:tcl_format_aspect.bzl%tcl_format_aspect
build:tclfmt --output_groups=+tcl_format_checks
```

Then use it with:
```bash
bazel build //my:target --config=tclfmt
```

Or use it in a test:

```python
load("@rules_tcl//tcl:tcl_format_test.bzl", "tcl_format_test")

tcl_format_test(
    name = "format_check",
    target = ":my_library",
)
```

**Ignoring targets:**

To skip format checking for specific targets, add one of these tags:
- `no_tcl_format`
- `no_tclformat`
- `no_tclfmt`
- `noformat`
- `nofmt`

```python
tcl_library(
    name = "generated_code",
    srcs = ["generated.tcl"],
    tags = ["no_tcl_format"],
)
```

The aspect processes all source files including `pkgIndex.tcl` files.
"*
nameA unique name for this target. *;
tcl_format_aspect&@@rules_tcl//tcl:tcl_format_aspect.bzl
��,
*
nameA unique name for this target. �
//tcl/private/linting:lint.bzlrq
*
	rules_tcltcl/private/lintinglint.bzl5
tcl_format_aspect_tcl_format_aspect

tcl_format_aspect�

	rules_tcltcltcl_info.bzl�TclInfoInfo about a Tcl target.2�
�
TclInfoInfo about a Tcl target.T
includesHDepset[str]: A list of include paths associated with the current target.@
srcs8Depset[File]: Direct source files of the current target.D
transitive_includes-Depset[str]: Include paths from dependencies.T
transitive_srcsADepset[File]: Source files required at runtime from dependencies."(
TclInfo@@rules_tcl//tcl:tcl_info.bzl
V
T
includesHDepset[str]: A list of include paths associated with the current target.B
@
srcs8Depset[File]: Direct source files of the current target.F
D
transitive_includes-Depset[str]: Include paths from dependencies.V
T
transitive_srcsADepset[File]: Source files required at runtime from dependencies.{
//tcl/private:providers.bzlrZ
'
	rules_tcltcl/privateproviders.bzl!
TclInfo_TclInfo
/7
DTclInfo�
!
	rules_tcltcltcl_library.bzl�tcl_library�A Tcl library that can be depended upon by other Tcl targets.

A `tcl_library` represents a Tcl package that can be imported using Tcl's `package require` command.
The library must include a `pkgIndex.tcl` file in its `srcs` attribute, which defines the package
metadata and how to load the package.

**Important**: The `pkgIndex.tcl` file must be included in the `srcs` attribute. This file is used
by Tcl's package system to locate and load the package.

Example:

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_library")

tcl_library(
    name = "mylib",
    srcs = [
        "mylib.tcl",
        "pkgIndex.tcl",
    ],
    deps = [
        ":otherlib",  # Another tcl_library
    ],
    visibility = ["//visibility:public"],
)
```

The library can then be used as a dependency in other targets:

```python
tcl_binary(
    name = "app",
    srcs = ["app.tcl"],
    deps = [":mylib"],
)
```
"�
�

tcl_library�A Tcl library that can be depended upon by other Tcl targets.

A `tcl_library` represents a Tcl package that can be imported using Tcl's `package require` command.
The library must include a `pkgIndex.tcl` file in its `srcs` attribute, which defines the package
metadata and how to load the package.

**Important**: The `pkgIndex.tcl` file must be included in the `srcs` attribute. This file is used
by Tcl's package system to locate and load the package.

Example:

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_library")

tcl_library(
    name = "mylib",
    srcs = [
        "mylib.tcl",
        "pkgIndex.tcl",
    ],
    deps = [
        ":otherlib",  # Another tcl_library
    ],
    visibility = ["//visibility:public"],
)
```

The library can then be used as a dependency in other targets:

```python
tcl_binary(
    name = "app",
    srcs = ["app.tcl"],
    deps = [":mylib"],
)
```
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]V
srcsJThe list of source (`.tcl`) files that are processed to create the target. "/
tcl_library @@rules_tcl//tcl:tcl_library.bzl
��,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]L
J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]X
V
srcsJThe list of source (`.tcl`) files that are processed to create the target. w
//tcl/private:tcl.bzlr\
!
	rules_tcltcl/privatetcl.bzl)
tcl_library_tcl_library
)5
Ftcl_library�
%
	rules_tcltcltcl_lint_aspect.bzl�tcl_lint_aspect�	An aspect for performing linting checks on Tcl targets.

The `tcl_lint_aspect` applies linting checks to all Tcl targets in the dependency graph.
It uses [tclint](https://github.com/nmoroze/tclint) to check for code quality issues.

**Usage:**

Apply the aspect to check all dependencies of a target via command line:

```bash
bazel build //my:target --aspects=@rules_tcl//tcl:tcl_lint_aspect.bzl%tcl_lint_aspect
```

Or configure it in your `.bazelrc` file to enable linting for all builds:

```bazelrc
# Enable tclint for all targets in the workspace
build:tclint --aspects=@rules_tcl//tcl:tcl_lint_aspect.bzl%tcl_lint_aspect
build:tclint --output_groups=+tcl_lint_checks
```

Then use it with:
```bash
bazel build //my:target --config=tclint
```

Or use it in a test:

```python
load("@rules_tcl//tcl:tcl_lint_test.bzl", "tcl_lint_test")

tcl_lint_test(
    name = "lint_check",
    target = ":my_library",
)
```

**Ignoring targets:**

To skip linting for specific targets, add one of these tags:
- `no_tcl_lint`
- `no_lint`
- `nolint`

```python
tcl_library(
    name = "legacy_code",
    srcs = ["legacy.tcl"],
    tags = ["no_tcl_lint"],
)
```

The aspect only processes source files (not generated files) and excludes `pkgIndex.tcl` files.
:�
�

tcl_lint_aspect�	An aspect for performing linting checks on Tcl targets.

The `tcl_lint_aspect` applies linting checks to all Tcl targets in the dependency graph.
It uses [tclint](https://github.com/nmoroze/tclint) to check for code quality issues.

**Usage:**

Apply the aspect to check all dependencies of a target via command line:

```bash
bazel build //my:target --aspects=@rules_tcl//tcl:tcl_lint_aspect.bzl%tcl_lint_aspect
```

Or configure it in your `.bazelrc` file to enable linting for all builds:

```bazelrc
# Enable tclint for all targets in the workspace
build:tclint --aspects=@rules_tcl//tcl:tcl_lint_aspect.bzl%tcl_lint_aspect
build:tclint --output_groups=+tcl_lint_checks
```

Then use it with:
```bash
bazel build //my:target --config=tclint
```

Or use it in a test:

```python
load("@rules_tcl//tcl:tcl_lint_test.bzl", "tcl_lint_test")

tcl_lint_test(
    name = "lint_check",
    target = ":my_library",
)
```

**Ignoring targets:**

To skip linting for specific targets, add one of these tags:
- `no_tcl_lint`
- `no_lint`
- `nolint`

```python
tcl_library(
    name = "legacy_code",
    srcs = ["legacy.tcl"],
    tags = ["no_tcl_lint"],
)
```

The aspect only processes source files (not generated files) and excludes `pkgIndex.tcl` files.
"*
nameA unique name for this target. *7
tcl_lint_aspect$@@rules_tcl//tcl:tcl_lint_aspect.bzl
ee,
*
nameA unique name for this target. �
//tcl/private/linting:lint.bzlrm
*
	rules_tcltcl/private/lintinglint.bzl1
tcl_lint_aspect_tcl_lint_aspect

tcl_lint_aspect�
#
	rules_tcltcltcl_toolchain.bzl�tcl_toolchain�A toolchain rule that defines the Tcl interpreter and libraries for building Tcl targets.

The `tcl_toolchain` rule configures the Tcl environment used by all `tcl_binary`, `tcl_library`,
and `tcl_test` targets. It specifies:
- The Tcl interpreter (`tclsh`) to use for execution
- The Tcl core library files (`tclcore`)
- The Tcl standard library (`tcllib`)
- Optional linting tools (`tclint`) for code quality checks

Typically, you don't need to create a `tcl_toolchain` directly. The rules provide a default
toolchain that you register in your `MODULE.bazel`:

```python
register_toolchains("@rules_tcl//tcl/toolchain")
```

If you need a custom toolchain (e.g., a different Tcl version), you can define your own:

```python
load("@rules_tcl//tcl:tcl_toolchain.bzl", "tcl_toolchain")

tcl_toolchain(
    name = "my_tcl_toolchain",
    tclsh = "@tcl_8_6//:tclsh",
    tclcore = "@tcl_8_6//:tclcore",
    tcllib = "@tcllib//:tcllib",
    tclint = "@tclint//:tclint",  # Optional, for linting
)
```
"�
�
tcl_toolchain�A toolchain rule that defines the Tcl interpreter and libraries for building Tcl targets.

The `tcl_toolchain` rule configures the Tcl environment used by all `tcl_binary`, `tcl_library`,
and `tcl_test` targets. It specifies:
- The Tcl interpreter (`tclsh`) to use for execution
- The Tcl core library files (`tclcore`)
- The Tcl standard library (`tcllib`)
- Optional linting tools (`tclint`) for code quality checks

Typically, you don't need to create a `tcl_toolchain` directly. The rules provide a default
toolchain that you register in your `MODULE.bazel`:

```python
register_toolchains("@rules_tcl//tcl/toolchain")
```

If you need a custom toolchain (e.g., a different Tcl version), you can define your own:

```python
load("@rules_tcl//tcl:tcl_toolchain.bzl", "tcl_toolchain")

tcl_toolchain(
    name = "my_tcl_toolchain",
    tclsh = "@tcl_8_6//:tclsh",
    tclcore = "@tcl_8_6//:tclcore",
    tcllib = "@tcllib//:tcllib",
    tclint = "@tclint//:tclint",  # Optional, for linting
)
```
*
nameA unique name for this target. .
tclcoreA label to the `tclcore` files. �
tclint�The [`tclint`](https://github.com/nmoroze/tclint) python library. This attribute is required for [`tcl_lint_aspect`](#tcl_lint_aspect)/[`tcl_format_aspect`](#tcl_format_aspect) but otherwise optional for core rules.2None,
tcllibA label to the `tcllib` files. *
tclshThe path to a `tclsh` binary. "3
tcl_toolchain"@@rules_tcl//tcl:tcl_toolchain.bzl
II,
*
nameA unique name for this target. 0
.
tclcoreA label to the `tclcore` files. �
�
tclint�The [`tclint`](https://github.com/nmoroze/tclint) python library. This attribute is required for [`tcl_lint_aspect`](#tcl_lint_aspect)/[`tcl_format_aspect`](#tcl_format_aspect) but otherwise optional for core rules.2None.
,
tcllibA label to the `tcllib` files. ,
*
tclshThe path to a `tclsh` binary. �
//tcl/private:toolchain.bzlr�
'
	rules_tcltcl/privatetoolchain.bzl/
TOOLCHAIN_TYPE_TOOLCHAIN_TYPE
-
tcl_toolchain_tcl_toolchain

D	TOOLCHAIN_TYPE@@//tcl:toolchain_typej@@//tcl:toolchain_typetcl_toolchainK

	rules_tclversion.bzl	VERSION0.1.1j0.1.1"rules_tcl version 