�
/
	rules_tcltcl/nagelfar/privatenagelfar.bzl�tcl_nagelfar_test�A test rule for performing Nagelfar static analysis on a Tcl target.

**Usage:**

```python
load("@rules_tcl//tcl/nagelfar:tcl_nagelfar_test.bzl", "tcl_nagelfar_test")

tcl_nagelfar_test(
    name = "mylib_nagelfar",
    target = ":mylib",
)
```
"�
�
tcl_nagelfar_test�A test rule for performing Nagelfar static analysis on a Tcl target.

**Usage:**

```python
load("@rules_tcl//tcl/nagelfar:tcl_nagelfar_test.bzl", "tcl_nagelfar_test")

tcl_nagelfar_test(
    name = "mylib_nagelfar",
    target = ":mylib",
)
```
*
nameA unique name for this target. H
target/The Tcl target to perform Nagelfar analysis on. *	
TclInfo"C
tcl_nagelfar_test.@@rules_tcl//tcl/nagelfar/private:nagelfar.bzl
��,
*
nameA unique name for this target. J
H
target/The Tcl target to perform Nagelfar analysis on. *	
TclInfo�tcl_nagelfar_aspect�An aspect for performing Nagelfar static analysis on Tcl targets.

The `tcl_nagelfar_aspect` applies [Nagelfar](https://nagelfar.sourceforge.net/)
checks to all Tcl targets in the dependency graph. It also traverses `deps`
and `data` (via a required collector aspect) to gather any `nagelfar_syntaxdb`
targets attached to the graph, and forwards their files to Nagelfar alongside
the toolchain-shipped databases.

**Usage:**

```bash
bazel build //my:target \
    --aspects=@rules_tcl//tcl/nagelfar:tcl_nagelfar_aspect.bzl%tcl_nagelfar_aspect \
    --output_groups=+tcl_nagelfar_checks
```

Or configure it in your `.bazelrc`:

```bazelrc
build:nagelfar --aspects=@rules_tcl//tcl/nagelfar:tcl_nagelfar_aspect.bzl%tcl_nagelfar_aspect
build:nagelfar --output_groups=+tcl_nagelfar_checks
```

**Ignoring targets:**

To skip Nagelfar for specific targets, add one of these tags:
- `no_tcl_nagelfar`
- `no_nagelfar`
- `no_lint`
- `nolint`
:�
�
tcl_nagelfar_aspect�An aspect for performing Nagelfar static analysis on Tcl targets.

The `tcl_nagelfar_aspect` applies [Nagelfar](https://nagelfar.sourceforge.net/)
checks to all Tcl targets in the dependency graph. It also traverses `deps`
and `data` (via a required collector aspect) to gather any `nagelfar_syntaxdb`
targets attached to the graph, and forwards their files to Nagelfar alongside
the toolchain-shipped databases.

**Usage:**

```bash
bazel build //my:target \
    --aspects=@rules_tcl//tcl/nagelfar:tcl_nagelfar_aspect.bzl%tcl_nagelfar_aspect \
    --output_groups=+tcl_nagelfar_checks
```

Or configure it in your `.bazelrc`:

```bazelrc
build:nagelfar --aspects=@rules_tcl//tcl/nagelfar:tcl_nagelfar_aspect.bzl%tcl_nagelfar_aspect
build:nagelfar --output_groups=+tcl_nagelfar_checks
```

**Ignoring targets:**

To skip Nagelfar for specific targets, add one of these tags:
- `no_tcl_nagelfar`
- `no_nagelfar`
- `no_lint`
- `nolint`
depsdata"*
nameA unique name for this target. *E
tcl_nagelfar_aspect.@@rules_tcl//tcl/nagelfar/private:nagelfar.bzl
kk,
*
nameA unique name for this target. �
$//tcl/nagelfar:nagelfar_syntaxdb.bzlr|
0
	rules_tcltcl/nagelfarnagelfar_syntaxdb.bzl:
NagelfarSyntaxdbInfoNagelfarSyntaxdbInfo
9M
O�
%//tcl/nagelfar:nagelfar_toolchain.bzlr�
1
	rules_tcltcl/nagelfarnagelfar_toolchain.bzl@
NAGELFAR_TOOLCHAIN_TYPENAGELFAR_TOOLCHAIN_TYPE
:Q
S�
//tcl/private:providers.bzlr
'
	rules_tcltcl/privateproviders.bzl 
TclInfoTclInfo
07$
	find_srcs	find_srcs
;D
F�
//tcl/private:toolchain.bzlrg
'
	rules_tcltcl/privatetoolchain.bzl.
TOOLCHAIN_TYPETOOLCHAIN_TYPE
0>
@Nagelfar lint rules�D
#
	rules_tcltcl/nagelfardefs.bzl�nagelfar_syntaxdb�Wraps a set of Nagelfar syntax database (`syntaxdb`) files so they can be
attached to a Tcl target via `data` and picked up by `tcl_nagelfar_aspect`
and `tcl_nagelfar_test` when linting that target or any dependent.

**Usage:**

```python
load("@rules_tcl//tcl:tcl_library.bzl", "tcl_library")
load("@rules_tcl//tcl/nagelfar:nagelfar_syntaxdb.bzl", "nagelfar_syntaxdb")

nagelfar_syntaxdb(
    name = "mylib_syntaxdb",
    srcs = ["mylib.syntaxdb.tcl"],
)

tcl_library(
    name = "mylib",
    srcs = ["mylib.tcl"],
    data = [":mylib_syntaxdb"],
)
```
"�
�
nagelfar_syntaxdb�Wraps a set of Nagelfar syntax database (`syntaxdb`) files so they can be
attached to a Tcl target via `data` and picked up by `tcl_nagelfar_aspect`
and `tcl_nagelfar_test` when linting that target or any dependent.

**Usage:**

```python
load("@rules_tcl//tcl:tcl_library.bzl", "tcl_library")
load("@rules_tcl//tcl/nagelfar:nagelfar_syntaxdb.bzl", "nagelfar_syntaxdb")

nagelfar_syntaxdb(
    name = "mylib_syntaxdb",
    srcs = ["mylib.syntaxdb.tcl"],
)

tcl_library(
    name = "mylib",
    srcs = ["mylib.tcl"],
    data = [":mylib_syntaxdb"],
)
```
*
nameA unique name for this target. +
srcsNagelfar syntax database files. "7
nagelfar_syntaxdb"@@rules_tcl//tcl/nagelfar:defs.bzl
,
*
nameA unique name for this target. -
+
srcsNagelfar syntax database files. �nagelfar_toolchain�A toolchain rule for configuring the [Nagelfar](https://nagelfar.sourceforge.net/) Tcl syntax checker.

The `nagelfar_toolchain` rule specifies the Nagelfar script, syntax database files,
and any additional Nagelfar arguments used by `tcl_nagelfar_aspect` and
`tcl_nagelfar_test` for static analysis of Tcl code.

The toolchain also generates a syntax database for the ambient `tcl_toolchain`'s
tcllib by running `syntaxbuild.tcl` under an exec-cfg `tcl_binary`. That generated
database is automatically appended to `syntaxdb` and reaches every lint action.

The `@nagelfar` hub repository (populated by the `nagelfar` module extension)
exposes the shipped script and syntax databases as labels users combine with
their own files:

```python
load("@rules_tcl//tcl/nagelfar:nagelfar_toolchain.bzl", "nagelfar_toolchain")

nagelfar_toolchain(
    name = "nagelfar_toolchain",
    nagelfar = "@nagelfar//:nagelfar",
    syntaxbuild = "@nagelfar//:syntaxbuild",
    syntaxdb = [
        "@nagelfar//:syntaxdb",
        "//path/to:my_project_syntaxdb.tcl",
    ],
    extra_args = ["-len", "100"],
)

toolchain(
    name = "toolchain",
    toolchain = ":nagelfar_toolchain",
    toolchain_type = "@rules_tcl//tcl/nagelfar:toolchain_type",
)
```

Register the toolchain in `MODULE.bazel`:

```python
nagelfar = use_extension("@rules_tcl//tcl/nagelfar:extensions.bzl", "nagelfar")
use_repo(nagelfar, "nagelfar")
register_toolchains("//path/to:toolchain")
```
"�
�
nagelfar_toolchain�A toolchain rule for configuring the [Nagelfar](https://nagelfar.sourceforge.net/) Tcl syntax checker.

The `nagelfar_toolchain` rule specifies the Nagelfar script, syntax database files,
and any additional Nagelfar arguments used by `tcl_nagelfar_aspect` and
`tcl_nagelfar_test` for static analysis of Tcl code.

The toolchain also generates a syntax database for the ambient `tcl_toolchain`'s
tcllib by running `syntaxbuild.tcl` under an exec-cfg `tcl_binary`. That generated
database is automatically appended to `syntaxdb` and reaches every lint action.

The `@nagelfar` hub repository (populated by the `nagelfar` module extension)
exposes the shipped script and syntax databases as labels users combine with
their own files:

```python
load("@rules_tcl//tcl/nagelfar:nagelfar_toolchain.bzl", "nagelfar_toolchain")

nagelfar_toolchain(
    name = "nagelfar_toolchain",
    nagelfar = "@nagelfar//:nagelfar",
    syntaxbuild = "@nagelfar//:syntaxbuild",
    syntaxdb = [
        "@nagelfar//:syntaxdb",
        "//path/to:my_project_syntaxdb.tcl",
    ],
    extra_args = ["-len", "100"],
)

toolchain(
    name = "toolchain",
    toolchain = ":nagelfar_toolchain",
    toolchain_type = "@rules_tcl//tcl/nagelfar:toolchain_type",
)
```

Register the toolchain in `MODULE.bazel`:

```python
nagelfar = use_extension("@rules_tcl//tcl/nagelfar:extensions.bzl", "nagelfar")
use_repo(nagelfar, "nagelfar")
register_toolchains("//path/to:toolchain")
```
*
nameA unique name for this target. b

extra_argsNAdditional command-line arguments forwarded to `nagelfar` on every invocation.2[]*
nagelfarThe `nagelfar.tcl` script. �
syntaxbuild�The `syntaxbuild.tcl` script shipped with Nagelfar, used to snapshot the ambient tcllib into a syntax database at toolchain-build time. �
syntaxdb�Nagelfar syntax database files. The tcllib syntaxdb this toolchain generates for its ambient `tcl_toolchain` is appended automatically.2[]"8
nagelfar_toolchain"@@rules_tcl//tcl/nagelfar:defs.bzl
'',
*
nameA unique name for this target. d
b

extra_argsNAdditional command-line arguments forwarded to `nagelfar` on every invocation.2[],
*
nagelfarThe `nagelfar.tcl` script. �
�
syntaxbuild�The `syntaxbuild.tcl` script shipped with Nagelfar, used to snapshot the ambient tcllib into a syntax database at toolchain-build time. �
�
syntaxdb�Nagelfar syntax database files. The tcllib syntaxdb this toolchain generates for its ambient `tcl_toolchain` is appended automatically.2[]�NagelfarSyntaxdbInfoeA set of [Nagelfar](https://nagelfar.sourceforge.net/) syntax database files contributed by a target.2�
�
NagelfarSyntaxdbInfoeA set of [Nagelfar](https://nagelfar.sourceforge.net/) syntax database files contributed by a target.-
files$Depset[File]: Syntax database files.":
NagelfarSyntaxdbInfo"@@rules_tcl//tcl/nagelfar:defs.bzl
  /
-
files$Depset[File]: Syntax database files.�tcl_nagelfar_aspect�An aspect for performing Nagelfar static analysis on Tcl targets.

The `tcl_nagelfar_aspect` applies [Nagelfar](https://nagelfar.sourceforge.net/)
checks to all Tcl targets in the dependency graph. It also traverses `deps`
and `data` (via a required collector aspect) to gather any `nagelfar_syntaxdb`
targets attached to the graph, and forwards their files to Nagelfar alongside
the toolchain-shipped databases.

**Usage:**

```bash
bazel build //my:target \
    --aspects=@rules_tcl//tcl/nagelfar:tcl_nagelfar_aspect.bzl%tcl_nagelfar_aspect \
    --output_groups=+tcl_nagelfar_checks
```

Or configure it in your `.bazelrc`:

```bazelrc
build:nagelfar --aspects=@rules_tcl//tcl/nagelfar:tcl_nagelfar_aspect.bzl%tcl_nagelfar_aspect
build:nagelfar --output_groups=+tcl_nagelfar_checks
```

**Ignoring targets:**

To skip Nagelfar for specific targets, add one of these tags:
- `no_tcl_nagelfar`
- `no_nagelfar`
- `no_lint`
- `nolint`
:�
�
tcl_nagelfar_aspect�An aspect for performing Nagelfar static analysis on Tcl targets.

The `tcl_nagelfar_aspect` applies [Nagelfar](https://nagelfar.sourceforge.net/)
checks to all Tcl targets in the dependency graph. It also traverses `deps`
and `data` (via a required collector aspect) to gather any `nagelfar_syntaxdb`
targets attached to the graph, and forwards their files to Nagelfar alongside
the toolchain-shipped databases.

**Usage:**

```bash
bazel build //my:target \
    --aspects=@rules_tcl//tcl/nagelfar:tcl_nagelfar_aspect.bzl%tcl_nagelfar_aspect \
    --output_groups=+tcl_nagelfar_checks
```

Or configure it in your `.bazelrc`:

```bazelrc
build:nagelfar --aspects=@rules_tcl//tcl/nagelfar:tcl_nagelfar_aspect.bzl%tcl_nagelfar_aspect
build:nagelfar --output_groups=+tcl_nagelfar_checks
```

**Ignoring targets:**

To skip Nagelfar for specific targets, add one of these tags:
- `no_tcl_nagelfar`
- `no_nagelfar`
- `no_lint`
- `nolint`
depsdata"*
nameA unique name for this target. *9
tcl_nagelfar_aspect"@@rules_tcl//tcl/nagelfar:defs.bzl
kk,
*
nameA unique name for this target. �
$//tcl/nagelfar:nagelfar_syntaxdb.bzlr�
0
	rules_tcltcl/nagelfarnagelfar_syntaxdb.bzl;
NagelfarSyntaxdbInfo_NagelfarSyntaxdbInfo
8M5
nagelfar_syntaxdb_nagelfar_syntaxdb
hz
��
%//tcl/nagelfar:nagelfar_toolchain.bzlrz
1
	rules_tcltcl/nagelfarnagelfar_toolchain.bzl7
nagelfar_toolchain_nagelfar_toolchain
9L
d�
&//tcl/nagelfar:tcl_nagelfar_aspect.bzlr}
2
	rules_tcltcl/nagelfartcl_nagelfar_aspect.bzl9
tcl_nagelfar_aspect_tcl_nagelfar_aspect
:N
g�
$//tcl/nagelfar:tcl_nagelfar_test.bzlrw
0
	rules_tcltcl/nagelfartcl_nagelfar_test.bzl5
tcl_nagelfar_test_tcl_nagelfar_test
8J
aNagelfar Bazel rules�
)
	rules_tcltcl/nagelfarextensions.bzl�nagelfar�Fetches the Nagelfar releases listed in `NAGELFAR_VERSIONS`.

Exposes them through a single `@nagelfar` hub repository. Consumers
reference Nagelfar via `@nagelfar//:nagelfar` (script, newest release),
`@nagelfar//:syntaxdb` (shipped syntax DBs, newest release), or the
per-version subpackages under `@nagelfar//<version>`.

Users declare their own `nagelfar_toolchain(...)` combining these
labels with any additional syntaxdb files and extra Nagelfar arguments,
then register it.
J�
�
nagelfar�Fetches the Nagelfar releases listed in `NAGELFAR_VERSIONS`.

Exposes them through a single `@nagelfar` hub repository. Consumers
reference Nagelfar via `@nagelfar//:nagelfar` (script, newest release),
`@nagelfar//:syntaxdb` (shipped syntax DBs, newest release), or the
per-version subpackages under `@nagelfar//<version>`.

Users declare their own `nagelfar_toolchain(...)` combining these
labels with any additional syntaxdb files and extra Nagelfar arguments,
then register it.
"4
nagelfar(@@rules_tcl//tcl/nagelfar:extensions.bzl
{{m
//lib:versions.bzlrU
!
bazel_skyliblibversions.bzl"
versionsversions
*2
4�
 //tools/build_defs/repo:http.bzlrj
.
bazel_toolstools/build_defs/repohttp.bzl*
http_archivehttp_archive
7C
E�Bzlmod extension for Nagelfar.

Fetches one repository per known Nagelfar release and consolidates the
user-facing labels into a single `@nagelfar` hub repo:

    @nagelfar//:nagelfar   -> nagelfar.tcl from the newest release
    @nagelfar//:syntaxdb   -> shipped syntaxdb*.tcl from the newest release
    @nagelfar//135:nagelfar
    @nagelfar//135:syntaxdb

Consumers combine these labels with their own syntaxdb files and extra
arguments to declare a `nagelfar_toolchain(...)` in their own package,
then `register_toolchains(...)` it.
�
0
	rules_tcltcl/nagelfarnagelfar_syntaxdb.bzl�nagelfar_syntaxdb�Wraps a set of Nagelfar syntax database (`syntaxdb`) files so they can be
attached to a Tcl target via `data` and picked up by `tcl_nagelfar_aspect`
and `tcl_nagelfar_test` when linting that target or any dependent.

**Usage:**

```python
load("@rules_tcl//tcl:tcl_library.bzl", "tcl_library")
load("@rules_tcl//tcl/nagelfar:nagelfar_syntaxdb.bzl", "nagelfar_syntaxdb")

nagelfar_syntaxdb(
    name = "mylib_syntaxdb",
    srcs = ["mylib.syntaxdb.tcl"],
)

tcl_library(
    name = "mylib",
    srcs = ["mylib.tcl"],
    data = [":mylib_syntaxdb"],
)
```
"�
�
nagelfar_syntaxdb�Wraps a set of Nagelfar syntax database (`syntaxdb`) files so they can be
attached to a Tcl target via `data` and picked up by `tcl_nagelfar_aspect`
and `tcl_nagelfar_test` when linting that target or any dependent.

**Usage:**

```python
load("@rules_tcl//tcl:tcl_library.bzl", "tcl_library")
load("@rules_tcl//tcl/nagelfar:nagelfar_syntaxdb.bzl", "nagelfar_syntaxdb")

nagelfar_syntaxdb(
    name = "mylib_syntaxdb",
    srcs = ["mylib.syntaxdb.tcl"],
)

tcl_library(
    name = "mylib",
    srcs = ["mylib.tcl"],
    data = [":mylib_syntaxdb"],
)
```
*
nameA unique name for this target. +
srcsNagelfar syntax database files. "D
nagelfar_syntaxdb/@@rules_tcl//tcl/nagelfar:nagelfar_syntaxdb.bzl
,
*
nameA unique name for this target. -
+
srcsNagelfar syntax database files. �NagelfarSyntaxdbInfoeA set of [Nagelfar](https://nagelfar.sourceforge.net/) syntax database files contributed by a target.2�
�
NagelfarSyntaxdbInfoeA set of [Nagelfar](https://nagelfar.sourceforge.net/) syntax database files contributed by a target.-
files$Depset[File]: Syntax database files."G
NagelfarSyntaxdbInfo/@@rules_tcl//tcl/nagelfar:nagelfar_syntaxdb.bzl
  /
-
files$Depset[File]: Syntax database files.nagelfar_syntaxdb rule�#
1
	rules_tcltcl/nagelfarnagelfar_toolchain.bzl�current_nagelfar_toolchain6A rule for accessing the current `nagelfar_toolchain`."�
�
current_nagelfar_toolchain6A rule for accessing the current `nagelfar_toolchain`.*
nameA unique name for this target. "N
current_nagelfar_toolchain0@@rules_tcl//tcl/nagelfar:nagelfar_toolchain.bzl
|"|",
*
nameA unique name for this target. �nagelfar_toolchain�A toolchain rule for configuring the [Nagelfar](https://nagelfar.sourceforge.net/) Tcl syntax checker.

The `nagelfar_toolchain` rule specifies the Nagelfar script, syntax database files,
and any additional Nagelfar arguments used by `tcl_nagelfar_aspect` and
`tcl_nagelfar_test` for static analysis of Tcl code.

The toolchain also generates a syntax database for the ambient `tcl_toolchain`'s
tcllib by running `syntaxbuild.tcl` under an exec-cfg `tcl_binary`. That generated
database is automatically appended to `syntaxdb` and reaches every lint action.

The `@nagelfar` hub repository (populated by the `nagelfar` module extension)
exposes the shipped script and syntax databases as labels users combine with
their own files:

```python
load("@rules_tcl//tcl/nagelfar:nagelfar_toolchain.bzl", "nagelfar_toolchain")

nagelfar_toolchain(
    name = "nagelfar_toolchain",
    nagelfar = "@nagelfar//:nagelfar",
    syntaxbuild = "@nagelfar//:syntaxbuild",
    syntaxdb = [
        "@nagelfar//:syntaxdb",
        "//path/to:my_project_syntaxdb.tcl",
    ],
    extra_args = ["-len", "100"],
)

toolchain(
    name = "toolchain",
    toolchain = ":nagelfar_toolchain",
    toolchain_type = "@rules_tcl//tcl/nagelfar:toolchain_type",
)
```

Register the toolchain in `MODULE.bazel`:

```python
nagelfar = use_extension("@rules_tcl//tcl/nagelfar:extensions.bzl", "nagelfar")
use_repo(nagelfar, "nagelfar")
register_toolchains("//path/to:toolchain")
```
"�
�
nagelfar_toolchain�A toolchain rule for configuring the [Nagelfar](https://nagelfar.sourceforge.net/) Tcl syntax checker.

The `nagelfar_toolchain` rule specifies the Nagelfar script, syntax database files,
and any additional Nagelfar arguments used by `tcl_nagelfar_aspect` and
`tcl_nagelfar_test` for static analysis of Tcl code.

The toolchain also generates a syntax database for the ambient `tcl_toolchain`'s
tcllib by running `syntaxbuild.tcl` under an exec-cfg `tcl_binary`. That generated
database is automatically appended to `syntaxdb` and reaches every lint action.

The `@nagelfar` hub repository (populated by the `nagelfar` module extension)
exposes the shipped script and syntax databases as labels users combine with
their own files:

```python
load("@rules_tcl//tcl/nagelfar:nagelfar_toolchain.bzl", "nagelfar_toolchain")

nagelfar_toolchain(
    name = "nagelfar_toolchain",
    nagelfar = "@nagelfar//:nagelfar",
    syntaxbuild = "@nagelfar//:syntaxbuild",
    syntaxdb = [
        "@nagelfar//:syntaxdb",
        "//path/to:my_project_syntaxdb.tcl",
    ],
    extra_args = ["-len", "100"],
)

toolchain(
    name = "toolchain",
    toolchain = ":nagelfar_toolchain",
    toolchain_type = "@rules_tcl//tcl/nagelfar:toolchain_type",
)
```

Register the toolchain in `MODULE.bazel`:

```python
nagelfar = use_extension("@rules_tcl//tcl/nagelfar:extensions.bzl", "nagelfar")
use_repo(nagelfar, "nagelfar")
register_toolchains("//path/to:toolchain")
```
*
nameA unique name for this target. b

extra_argsNAdditional command-line arguments forwarded to `nagelfar` on every invocation.2[]*
nagelfarThe `nagelfar.tcl` script. �
syntaxbuild�The `syntaxbuild.tcl` script shipped with Nagelfar, used to snapshot the ambient tcllib into a syntax database at toolchain-build time. �
syntaxdb�Nagelfar syntax database files. The tcllib syntaxdb this toolchain generates for its ambient `tcl_toolchain` is appended automatically.2[]"F
nagelfar_toolchain0@@rules_tcl//tcl/nagelfar:nagelfar_toolchain.bzl
'',
*
nameA unique name for this target. d
b

extra_argsNAdditional command-line arguments forwarded to `nagelfar` on every invocation.2[],
*
nagelfarThe `nagelfar.tcl` script. �
�
syntaxbuild�The `syntaxbuild.tcl` script shipped with Nagelfar, used to snapshot the ambient tcllib into a syntax database at toolchain-build time. �
�
syntaxdb�Nagelfar syntax database files. The tcllib syntaxdb this toolchain generates for its ambient `tcl_toolchain` is appended automatically.2[]_	NAGELFAR_TOOLCHAIN_TYPE@@//tcl/nagelfar:toolchain_typej!@@//tcl/nagelfar:toolchain_typeNagelfar toolchain rules�
2
	rules_tcltcl/nagelfartcl_nagelfar_aspect.bzl�tcl_nagelfar_aspect�An aspect for performing Nagelfar static analysis on Tcl targets.

The `tcl_nagelfar_aspect` applies [Nagelfar](https://nagelfar.sourceforge.net/)
checks to all Tcl targets in the dependency graph. It also traverses `deps`
and `data` (via a required collector aspect) to gather any `nagelfar_syntaxdb`
targets attached to the graph, and forwards their files to Nagelfar alongside
the toolchain-shipped databases.

**Usage:**

```bash
bazel build //my:target \
    --aspects=@rules_tcl//tcl/nagelfar:tcl_nagelfar_aspect.bzl%tcl_nagelfar_aspect \
    --output_groups=+tcl_nagelfar_checks
```

Or configure it in your `.bazelrc`:

```bazelrc
build:nagelfar --aspects=@rules_tcl//tcl/nagelfar:tcl_nagelfar_aspect.bzl%tcl_nagelfar_aspect
build:nagelfar --output_groups=+tcl_nagelfar_checks
```

**Ignoring targets:**

To skip Nagelfar for specific targets, add one of these tags:
- `no_tcl_nagelfar`
- `no_nagelfar`
- `no_lint`
- `nolint`
:�
�
tcl_nagelfar_aspect�An aspect for performing Nagelfar static analysis on Tcl targets.

The `tcl_nagelfar_aspect` applies [Nagelfar](https://nagelfar.sourceforge.net/)
checks to all Tcl targets in the dependency graph. It also traverses `deps`
and `data` (via a required collector aspect) to gather any `nagelfar_syntaxdb`
targets attached to the graph, and forwards their files to Nagelfar alongside
the toolchain-shipped databases.

**Usage:**

```bash
bazel build //my:target \
    --aspects=@rules_tcl//tcl/nagelfar:tcl_nagelfar_aspect.bzl%tcl_nagelfar_aspect \
    --output_groups=+tcl_nagelfar_checks
```

Or configure it in your `.bazelrc`:

```bazelrc
build:nagelfar --aspects=@rules_tcl//tcl/nagelfar:tcl_nagelfar_aspect.bzl%tcl_nagelfar_aspect
build:nagelfar --output_groups=+tcl_nagelfar_checks
```

**Ignoring targets:**

To skip Nagelfar for specific targets, add one of these tags:
- `no_tcl_nagelfar`
- `no_nagelfar`
- `no_lint`
- `nolint`
depsdata"*
nameA unique name for this target. *H
tcl_nagelfar_aspect1@@rules_tcl//tcl/nagelfar:tcl_nagelfar_aspect.bzl
kk,
*
nameA unique name for this target. �
#//tcl/nagelfar/private:nagelfar.bzlrz
/
	rules_tcltcl/nagelfar/privatenagelfar.bzl9
tcl_nagelfar_aspect_tcl_nagelfar_aspect

tcl_nagelfar_aspect�
'
	rules_tcltcl/privateproviders.bzl�	find_srcs}Find all lintable source files for a given target.

Note that generated files are ignored, and external targets are skipped.
*�
�
	find_srcs)
targetThe target to collect from. (}Find all lintable source files for a given target.

Note that generated files are ignored, and external targets are skipped.
".
,list[File]: A list of lintable source files.23
	find_srcs&@@rules_tcl//tcl/private:providers.bzl
�TclCoreInfo@Info about a tclcore target consumed by `tcl_toolchain.tclcore`.2�
�
TclCoreInfo@Info about a tclcore target consumed by `tcl_toolchain.tclcore`.X
includeMstr: Runfiles-relative directory containing `init.tcl`, added to `auto_path`.3
init_tcl'File: `init.tcl` from the tclcore tree."5
TclCoreInfo&@@rules_tcl//tcl/private:providers.bzl
Z
X
includeMstr: Runfiles-relative directory containing `init.tcl`, added to `auto_path`.5
3
init_tcl'File: `init.tcl` from the tclcore tree.�TclInfoInfo about a Tcl target.2�
�
TclInfoInfo about a Tcl target.T
includesHDepset[str]: A list of include paths associated with the current target.@
srcs8Depset[File]: Direct source files of the current target.D
transitive_includes-Depset[str]: Include paths from dependencies.T
transitive_srcsADepset[File]: Source files required at runtime from dependencies."1
TclInfo&@@rules_tcl//tcl/private:providers.bzl
V
T
includesHDepset[str]: A list of include paths associated with the current target.B
@
srcs8Depset[File]: Direct source files of the current target.F
D
transitive_includes-Depset[str]: Include paths from dependencies.V
T
transitive_srcsADepset[File]: Source files required at runtime from dependencies.�
TclLibInfo>Info about a tcllib target consumed by `tcl_toolchain.tcllib`.2�
�

TclLibInfo>Info about a tcllib target consumed by `tcl_toolchain.tcllib`.j
include_str: Runfiles-relative directory containing the top-level `pkgIndex.tcl`, added to `auto_path`.@
	pkg_index3File: Top-level `pkgIndex.tcl` for the tcllib tree."4

TclLibInfo&@@rules_tcl//tcl/private:providers.bzl
l
j
include_str: Runfiles-relative directory containing the top-level `pkgIndex.tcl`, added to `auto_path`.B
@
	pkg_index3File: Top-level `pkgIndex.tcl` for the tcllib tree.TCL Providers�L
!
	rules_tcltcl/privatetcl.bzl�
tcl_binary�A `tcl_binary` is an executable Tcl program consisting of a collection of
`.tcl` or `.do` source files (possibly belonging to other `tcl_library` rules), a `*.runfiles`
directory tree containing all the code and data needed by the program at run-time,
and a stub script that starts up the program with the correct initial environment
and data.

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_binary")

tcl_binary(
    name = "foo",
    srcs = ["foo.tcl"],
    deps = [
        ":bar",  # a tcl_library
    ],
)
```
"�
�	

tcl_binary�A `tcl_binary` is an executable Tcl program consisting of a collection of
`.tcl` or `.do` source files (possibly belonging to other `tcl_library` rules), a `*.runfiles`
directory tree containing all the code and data needed by the program at run-time,
and a stub script that starts up the program with the correct initial environment
and data.

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_binary")

tcl_binary(
    name = "foo",
    srcs = ["foo.tcl"],
    deps = [
        ":bar",  # a tcl_library
    ],
)
```
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2None_
srcsSThe list of source (`.tcl` or `.do`) files that are processed to create the target. ".

tcl_binary @@rules_tcl//tcl/private:tcl.bzl
��,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]L
J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]k
i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}�
�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2Nonea
_
srcsSThe list of source (`.tcl` or `.do`) files that are processed to create the target. �tcl_library�A Tcl library that can be depended upon by other Tcl targets.

A `tcl_library` groups a set of `.tcl` or `.do` source files that can be consumed by other Tcl
targets. If a `pkgIndex.tcl` file is included in `srcs`, its directory is added to the consumer's
`auto_path` so the package can be loaded with Tcl's `package require` command. Libraries without a
`pkgIndex.tcl` are still made available through runfiles and can be loaded directly with `source`
(typically via the runfiles library's `rlocation`).

Example with `package require`:

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_library")

tcl_library(
    name = "mylib",
    srcs = [
        "mylib.tcl",
        "pkgIndex.tcl",
    ],
    deps = [
        ":otherlib",  # Another tcl_library
    ],
    visibility = ["//visibility:public"],
)
```

The library can then be used as a dependency in other targets:

```python
tcl_binary(
    name = "app",
    srcs = ["app.tcl"],
    deps = [":mylib"],
)
```
"�
�

tcl_library�A Tcl library that can be depended upon by other Tcl targets.

A `tcl_library` groups a set of `.tcl` or `.do` source files that can be consumed by other Tcl
targets. If a `pkgIndex.tcl` file is included in `srcs`, its directory is added to the consumer's
`auto_path` so the package can be loaded with Tcl's `package require` command. Libraries without a
`pkgIndex.tcl` are still made available through runfiles and can be loaded directly with `source`
(typically via the runfiles library's `rlocation`).

Example with `package require`:

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_library")

tcl_library(
    name = "mylib",
    srcs = [
        "mylib.tcl",
        "pkgIndex.tcl",
    ],
    deps = [
        ":otherlib",  # Another tcl_library
    ],
    visibility = ["//visibility:public"],
)
```

The library can then be used as a dependency in other targets:

```python
tcl_binary(
    name = "app",
    srcs = ["app.tcl"],
    deps = [":mylib"],
)
```
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]_
srcsSThe list of source (`.tcl` or `.do`) files that are processed to create the target. "/
tcl_library @@rules_tcl//tcl/private:tcl.bzl
��,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]L
J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]a
_
srcsSThe list of source (`.tcl` or `.do`) files that are processed to create the target. � tcl_test�A test rule for Tcl code that can be executed with `bazel test`.

A `tcl_test` is similar to a `tcl_binary` but is designed for testing. It supports all the same
attributes as `tcl_binary`, plus additional test-specific features like environment variable
inheritance.

Tests are executed by Bazel's test runner and can be run with:

```bash
bazel test //path/to:my_test
```

Example:

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_test")

tcl_test(
    name = "my_test",
    srcs = ["test.tcl"],
    deps = [
        ":mylib",  # The library being tested
    ],
    env = {
        "TEST_MODE": "1",
    },
    env_inherit = ["PATH"],  # Inherit PATH from the environment
)
```

The test can use Tcl's standard testing frameworks or custom test code. Test failures are
detected by non-zero exit codes.
"�
�
tcl_test�A test rule for Tcl code that can be executed with `bazel test`.

A `tcl_test` is similar to a `tcl_binary` but is designed for testing. It supports all the same
attributes as `tcl_binary`, plus additional test-specific features like environment variable
inheritance.

Tests are executed by Bazel's test runner and can be run with:

```bash
bazel test //path/to:my_test
```

Example:

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_test")

tcl_test(
    name = "my_test",
    srcs = ["test.tcl"],
    deps = [
        ":mylib",  # The library being tested
    ],
    env = {
        "TEST_MODE": "1",
    },
    env_inherit = ["PATH"],  # Inherit PATH from the environment
)
```

The test can use Tcl's standard testing frameworks or custom test code. Test failures are
detected by non-zero exit codes.
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}�
env_inherit�Specifies additional environment variables to inherit from the external environment.

This attribute is only available for `tcl_test` rules. When the test is executed by
`bazel test`, these environment variables from the host environment will be passed
through to the test.

Example:
```python
tcl_test(
    name = "my_test",
    srcs = ["test.tcl"],
    env_inherit = [
        "PATH",
        "HOME",
        "USER",
    ],
)
```

This is useful when tests need access to system tools or user-specific configuration.
2[]�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2None_
srcsSThe list of source (`.tcl` or `.do`) files that are processed to create the target. ",
tcl_test @@rules_tcl//tcl/private:tcl.bzl
��,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]L
J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]k
i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}�
�
env_inherit�Specifies additional environment variables to inherit from the external environment.

This attribute is only available for `tcl_test` rules. When the test is executed by
`bazel test`, these environment variables from the host environment will be passed
through to the test.

Example:
```python
tcl_test(
    name = "my_test",
    srcs = ["test.tcl"],
    env_inherit = [
        "PATH",
        "HOME",
        "USER",
    ],
)
```

This is useful when tests need access to system tools or user-specific configuration.
2[]�
�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2Nonea
_
srcsSThe list of source (`.tcl` or `.do`) files that are processed to create the target. z
//tcl/private:providers.bzlrY
'
	rules_tcltcl/privateproviders.bzl 
TclInfoTclInfo
07
9�
//tcl/private:toolchain.bzlrg
'
	rules_tcltcl/privatetoolchain.bzl.
TOOLCHAIN_TYPETOOLCHAIN_TYPE
0>
@	Tcl rules�
/
	rules_tcltcl/privatetclcore_filegroup.bzl�tclcore_filegroupqWraps a tclcore source tree and surfaces `init.tcl` via `TclCoreInfo` for consumption by `tcl_toolchain.tclcore`."�
�
tclcore_filegroupqWraps a tclcore source tree and surfaces `init.tcl` via `TclCoreInfo` for consumption by `tcl_toolchain.tclcore`.*
nameA unique name for this target. L
srcs@Files that make up the tclcore tree. Must contain an `init.tcl`. "C
tclcore_filegroup.@@rules_tcl//tcl/private:tclcore_filegroup.bzl
,
*
nameA unique name for this target. N
L
srcs@Files that make up the tclcore tree. Must contain an `init.tcl`. �
//tcl/private:providers.bzlra
'
	rules_tcltcl/privateproviders.bzl(
TclCoreInfoTclCoreInfo
0;
=�
//tcl/private:toolchain.bzlre
'
	rules_tcltcl/privatetoolchain.bzl,
rlocationpathrlocationpath
0=
?Public rule for tclcore.�
.
	rules_tcltcl/privatetcllib_extension.bzl�tcllib�Fetches the tcllib releases listed in `TCLLIB_VERSIONS`.

Exposes them through a single `@tcllib` hub repository. Consumers
reference tcllib via `@tcllib` (newest overall), `@tcllib//:tcl_8` /
`@tcllib//:tcl_9` (newest supporting a given Tcl major), or
`@tcllib//<version>` (a specific release).
J�
�
tcllib�Fetches the tcllib releases listed in `TCLLIB_VERSIONS`.

Exposes them through a single `@tcllib` hub repository. Consumers
reference tcllib via `@tcllib` (newest overall), `@tcllib//:tcl_8` /
`@tcllib//:tcl_9` (newest supporting a given Tcl major), or
`@tcllib//<version>` (a specific release).
"7
tcllib-@@rules_tcl//tcl/private:tcllib_extension.bzl
��m
//lib:versions.bzlrU
!
bazel_skyliblibversions.bzl"
versionsversions
*2
4�
 //tools/build_defs/repo:http.bzlrj
.
bazel_toolstools/build_defs/repohttp.bzl*
http_archivehttp_archive
7C
E�Bzlmod extension for tcllib.

Fetches one repository per known tcllib release and consolidates all
user-facing aliases into a single `@tcllib` hub repo:

    @tcllib          -> newest tcllib overall
    @tcllib//:tcl_8  -> newest tcllib compatible with Tcl 8
    @tcllib//:tcl_9  -> newest tcllib compatible with Tcl 9
    @tcllib//2.0     -> tcllib 2.0
    @tcllib//1.21    -> tcllib 1.21

The per-version archive repositories are extension-private; consumers
reference them only through the aliases above.
�	
.
	rules_tcltcl/privatetcllib_filegroup.bzl�tcllib_filegroupiStages a tcllib source tree under a prefix and generates a pkgIndex.tcl that auto-discovers sub-packages."�
�
tcllib_filegroupiStages a tcllib source tree under a prefix and generates a pkgIndex.tcl that auto-discovers sub-packages.*
nameA unique name for this target. >
prefix0Directory prefix to stage the tcllib tree under. 2
srcs&Files from the tcllib `modules/` tree. F
version7The tcllib version, used in the generated pkgIndex.tcl. "A
tcllib_filegroup-@@rules_tcl//tcl/private:tcllib_filegroup.bzl
99,
*
nameA unique name for this target. @
>
prefix0Directory prefix to stage the tcllib tree under. 4
2
srcs&Files from the tcllib `modules/` tree. H
F
version7The tcllib version, used in the generated pkgIndex.tcl. �
//tcl/private:providers.bzlr_
'
	rules_tcltcl/privateproviders.bzl&

TclLibInfo
TclLibInfo
0:
<�
//tcl/private:toolchain.bzlre
'
	rules_tcltcl/privatetoolchain.bzl,
rlocationpathrlocationpath
0=
?Public rules for tcllib.�|
'
	rules_tcltcl/privatetoolchain.bzl�xtcl_toolchain�4A toolchain rule that defines the Tcl interpreter, libraries, and executable wrapper used
to build `tcl_binary`, `tcl_library`, and `tcl_test` targets.

## Registering a toolchain

`rules_tcl` does not register a toolchain for you. Add the following to your `MODULE.bazel`
to use the default (a stock `tclsh` and tcllib, with the built-in shell/batch wrapper):

```python
register_toolchains("@rules_tcl//tcl/toolchain")
```

If you need a custom toolchain (e.g. a different Tcl version, or a wrapper that dispatches
into a different host interpreter), define your own. `tclcore` and `tcllib` are matched by
provider â pass a target that returns `TclCoreInfo` / `TclLibInfo`, typically produced by
the sibling `tclcore_filegroup` and `tcllib_filegroup` rules:

```python
load("@rules_tcl//tcl:tcl_toolchain.bzl", "tcl_toolchain", "tclcore_filegroup")

tclcore_filegroup(
    name = "my_tclcore",
    srcs = ["@my_tcl//:tclcore_files"],
)

tcl_toolchain(
    name = "my_tcl_toolchain",
    tclsh = "@my_tcl//:tclsh",
    tclcore = ":my_tclcore",     # optional; must provide TclCoreInfo
    tcllib = "@tcllib",          # optional; must provide TclLibInfo
    wrapper_template = "//path/to:my_wrapper_bundle",
    wrapper_entrypoint = "//path/to:my_entrypoint.tcl",  # optional
)
```

`tclcore` and `tcllib` may be omitted when the interpreter ships them itself.
`wrapper_entrypoint` is optional when the wrapper does not need a bootstrap script.

The template's own `DefaultInfo.default_runfiles` are merged into every produced binary,
so a template that needs a helper library (e.g. `@rules_shell//shell/runfiles` for sh,
`@rules_batch//batch/runfiles` for batch) should be declared via a `filegroup` that lists
the helper under `data`:

```python
filegroup(
    name = "my_wrapper_bundle",
    srcs = ["my_wrapper.sh.tpl"],
    data = ["@rules_shell//shell/runfiles"],
)
```

The same is true for `wrapper_entrypoint` â a `filegroup` around the entrypoint can carry
extra runtime data it needs at execution.

The extension appended to the produced wrapper is derived from the template's filename by
splitting the basename on the first `.` and dropping any trailing parts that are known
template suffixes (`.tpl`, `.template`, `.tmpl`, `.in`); whatever remains is the extension.
E.g. `my_wrapper.sh.tpl` yields `.sh`, `my_wrapper.bat.template` yields `.bat`,
`my_wrapper.vhook.tcl.tpl` yields `.vhook.tcl`. Since the split happens at the FIRST dot,
templates whose basename contains a dot in the name portion (e.g. `com.foo.wrapper.sh.tpl`
intending `.sh`) should be renamed so the first `.` marks the extension boundary.

## `ToolchainInfo` contract

The rule returns a `platform_common.ToolchainInfo` with the following fields. Non-underscore
fields are the public contract that consumers (including third-party rules that operate
over Tcl targets) may read. Underscore-prefixed fields are internal to the built-in
`tcl_binary` / `tcl_test` implementation â third-party rules that want a materially
different wrapper should carry their own template rather than reach into them.

| Field                | Type                                   | Access   | Notes                                                              |
|----------------------|----------------------------------------|----------|--------------------------------------------------------------------|
| `tclsh`              | `File`                                 | public   | Executable of the interpreter that will run the produced binaries. |
| `includes`           | `depset[str]`                          | public   | Runfiles-relative include paths implicitly on `auto_path`.         |
| `init_tcl`           | `File \| None`                        | public   | `init.tcl` from tclcore, or `None`.                                |
| `tcllib_pkg_index`   | `File \| None`                        | public   | tcllib's top-level `pkgIndex.tcl`, or `None`.                      |
| `all_files`          | `depset[File]`                         | public   | Runtime files merged into every produced target.                   |
| `make_variable_info` | `platform_common.TemplateVariableInfo` | public   | Exposes `$(TCLSH)` for `env` on downstream rules.                  |
| `_wrapper_*`         | (various)                              | internal | Wrapper template, entrypoint, and derived extension.               |

## Wrapper template contract

The built-in `tcl_binary` / `tcl_test` expand `wrapper_template` once per target into a
file named `<target><wrapper_extension>` and set it as the target's executable. The
template supports these substitutions; values whose backing toolchain field is unset
expand to the empty string, so a template can simply omit lines it does not need:

| Substitution         | Value                                                                                 | Empty when                   |
|----------------------|---------------------------------------------------------------------------------------|------------------------------|
| `{interpreter}`      | Runfiles path (rlocation) of `tclsh`.                                                 | never                        |
| `{entrypoint}`       | Runfiles path of `wrapper_entrypoint`.                                                | `wrapper_entrypoint` unset   |
| `{config}`           | Runfiles path of a per-target JSON config (see below).                                | never                        |
| `{main}`             | Runfiles path of the target's entry `.tcl` (resolved from `main` / `srcs`).           | never                        |
| `{init_tcl}`         | Runfiles path of tclcore's `init.tcl`.                                                | `tclcore` unset              |
| `{tcllib_pkg_index}` | Runfiles path of tcllib's top-level `pkgIndex.tcl`.                                   | `tcllib` unset               |
| `{auto_path}`        | Tcl-list literal (brace-quoted) of every include path visible to the target â the target's own workspace, each dep's `TclInfo.includes`, and the toolchain's `includes`. Suitable to `lappend` onto `auto_path`. | never |

The `{config}` file is JSON with this shape:

```json
{
  "includes": ["workspace_name", "workspace_name/path/to/lib", "..."],
  "runfiles": ["workspace_name/path/to/file", "..."]
}
```

`includes` is the same set of runfiles-relative paths surfaced through `{auto_path}`;
`runfiles` is every file merged into the target's runfiles. The default `entrypoint.tcl`
consumes this to set `TCLLIBPATH` and to materialize a `RUNFILES_DIR` when only a manifest
is available; alternate wrappers can consume, ignore, or extend it as they see fit.
"�D
�<
tcl_toolchain�4A toolchain rule that defines the Tcl interpreter, libraries, and executable wrapper used
to build `tcl_binary`, `tcl_library`, and `tcl_test` targets.

## Registering a toolchain

`rules_tcl` does not register a toolchain for you. Add the following to your `MODULE.bazel`
to use the default (a stock `tclsh` and tcllib, with the built-in shell/batch wrapper):

```python
register_toolchains("@rules_tcl//tcl/toolchain")
```

If you need a custom toolchain (e.g. a different Tcl version, or a wrapper that dispatches
into a different host interpreter), define your own. `tclcore` and `tcllib` are matched by
provider â pass a target that returns `TclCoreInfo` / `TclLibInfo`, typically produced by
the sibling `tclcore_filegroup` and `tcllib_filegroup` rules:

```python
load("@rules_tcl//tcl:tcl_toolchain.bzl", "tcl_toolchain", "tclcore_filegroup")

tclcore_filegroup(
    name = "my_tclcore",
    srcs = ["@my_tcl//:tclcore_files"],
)

tcl_toolchain(
    name = "my_tcl_toolchain",
    tclsh = "@my_tcl//:tclsh",
    tclcore = ":my_tclcore",     # optional; must provide TclCoreInfo
    tcllib = "@tcllib",          # optional; must provide TclLibInfo
    wrapper_template = "//path/to:my_wrapper_bundle",
    wrapper_entrypoint = "//path/to:my_entrypoint.tcl",  # optional
)
```

`tclcore` and `tcllib` may be omitted when the interpreter ships them itself.
`wrapper_entrypoint` is optional when the wrapper does not need a bootstrap script.

The template's own `DefaultInfo.default_runfiles` are merged into every produced binary,
so a template that needs a helper library (e.g. `@rules_shell//shell/runfiles` for sh,
`@rules_batch//batch/runfiles` for batch) should be declared via a `filegroup` that lists
the helper under `data`:

```python
filegroup(
    name = "my_wrapper_bundle",
    srcs = ["my_wrapper.sh.tpl"],
    data = ["@rules_shell//shell/runfiles"],
)
```

The same is true for `wrapper_entrypoint` â a `filegroup` around the entrypoint can carry
extra runtime data it needs at execution.

The extension appended to the produced wrapper is derived from the template's filename by
splitting the basename on the first `.` and dropping any trailing parts that are known
template suffixes (`.tpl`, `.template`, `.tmpl`, `.in`); whatever remains is the extension.
E.g. `my_wrapper.sh.tpl` yields `.sh`, `my_wrapper.bat.template` yields `.bat`,
`my_wrapper.vhook.tcl.tpl` yields `.vhook.tcl`. Since the split happens at the FIRST dot,
templates whose basename contains a dot in the name portion (e.g. `com.foo.wrapper.sh.tpl`
intending `.sh`) should be renamed so the first `.` marks the extension boundary.

## `ToolchainInfo` contract

The rule returns a `platform_common.ToolchainInfo` with the following fields. Non-underscore
fields are the public contract that consumers (including third-party rules that operate
over Tcl targets) may read. Underscore-prefixed fields are internal to the built-in
`tcl_binary` / `tcl_test` implementation â third-party rules that want a materially
different wrapper should carry their own template rather than reach into them.

| Field                | Type                                   | Access   | Notes                                                              |
|----------------------|----------------------------------------|----------|--------------------------------------------------------------------|
| `tclsh`              | `File`                                 | public   | Executable of the interpreter that will run the produced binaries. |
| `includes`           | `depset[str]`                          | public   | Runfiles-relative include paths implicitly on `auto_path`.         |
| `init_tcl`           | `File \| None`                        | public   | `init.tcl` from tclcore, or `None`.                                |
| `tcllib_pkg_index`   | `File \| None`                        | public   | tcllib's top-level `pkgIndex.tcl`, or `None`.                      |
| `all_files`          | `depset[File]`                         | public   | Runtime files merged into every produced target.                   |
| `make_variable_info` | `platform_common.TemplateVariableInfo` | public   | Exposes `$(TCLSH)` for `env` on downstream rules.                  |
| `_wrapper_*`         | (various)                              | internal | Wrapper template, entrypoint, and derived extension.               |

## Wrapper template contract

The built-in `tcl_binary` / `tcl_test` expand `wrapper_template` once per target into a
file named `<target><wrapper_extension>` and set it as the target's executable. The
template supports these substitutions; values whose backing toolchain field is unset
expand to the empty string, so a template can simply omit lines it does not need:

| Substitution         | Value                                                                                 | Empty when                   |
|----------------------|---------------------------------------------------------------------------------------|------------------------------|
| `{interpreter}`      | Runfiles path (rlocation) of `tclsh`.                                                 | never                        |
| `{entrypoint}`       | Runfiles path of `wrapper_entrypoint`.                                                | `wrapper_entrypoint` unset   |
| `{config}`           | Runfiles path of a per-target JSON config (see below).                                | never                        |
| `{main}`             | Runfiles path of the target's entry `.tcl` (resolved from `main` / `srcs`).           | never                        |
| `{init_tcl}`         | Runfiles path of tclcore's `init.tcl`.                                                | `tclcore` unset              |
| `{tcllib_pkg_index}` | Runfiles path of tcllib's top-level `pkgIndex.tcl`.                                   | `tcllib` unset               |
| `{auto_path}`        | Tcl-list literal (brace-quoted) of every include path visible to the target â the target's own workspace, each dep's `TclInfo.includes`, and the toolchain's `includes`. Suitable to `lappend` onto `auto_path`. | never |

The `{config}` file is JSON with this shape:

```json
{
  "includes": ["workspace_name", "workspace_name/path/to/lib", "..."],
  "runfiles": ["workspace_name/path/to/file", "..."]
}
```

`includes` is the same set of runfiles-relative paths surfaced through `{auto_path}`;
`runfiles` is every file merged into the target's runfiles. The default `entrypoint.tcl`
consumes this to set `TCLLIBPATH` and to materialize a `RUNFILES_DIR` when only a manifest
is available; alternate wrappers can consume, ignore, or extend it as they see fit.
*
nameA unique name for this target. e
tclcoreCA target providing `TclCoreInfo` (typically a `tclcore_filegroup`).*
TclCoreInfo2Nonea
tcllibAA target providing `TclLibInfo` (typically a `tcllib_filegroup`).*

TclLibInfo2Nonej
tclsh]The path to a `tclsh` binary. Runtime dependency of every produced `tcl_binary` / `tcl_test`. �
wrapper_entrypoint�Optional `.tcl` file added to the binary's runfiles and referenced via the `{entrypoint}` template substitution. The target's `default_runfiles` are also merged in. Leave unset when the wrapper doesn't need a bootstrap.2None�
wrapper_template�Template expanded per `tcl_binary` / `tcl_test`. The target's `default_runfiles` are merged into every produced binary, so a `filegroup` wrapping the template can list helper libraries under `data` (e.g. `@bazel_tools//tools/bash/runfiles`). See the wrapper template contract in the rule docs for the supported substitutions. "7
tcl_toolchain&@@rules_tcl//tcl/private:toolchain.bzl
\\,
*
nameA unique name for this target. g
e
tclcoreCA target providing `TclCoreInfo` (typically a `tclcore_filegroup`).*
TclCoreInfo2Nonec
a
tcllibAA target providing `TclLibInfo` (typically a `tcllib_filegroup`).*

TclLibInfo2Nonel
j
tclsh]The path to a `tclsh` binary. Runtime dependency of every produced `tcl_binary` / `tcl_test`. �
�
wrapper_entrypoint�Optional `.tcl` file added to the binary's runfiles and referenced via the `{entrypoint}` template substitution. The target's `default_runfiles` are also merged in. Leave unset when the wrapper doesn't need a bootstrap.2None�
�
wrapper_template�Template expanded per `tcl_binary` / `tcl_test`. The target's `default_runfiles` are merged into every produced binary, so a `filegroup` wrapping the template can list helper libraries under `data` (e.g. `@bazel_tools//tools/bash/runfiles`). See the wrapper template contract in the rule docs for the supported substitutions. �rlocationpath*z
j
rlocationpath

file (
workspace_name (27
rlocationpath&@@rules_tcl//tcl/private:toolchain.bzl
�
//tcl/private:providers.bzlr�
'
	rules_tcltcl/privateproviders.bzl(
TclCoreInfoTclCoreInfo
0;&

TclLibInfo
TclLibInfo
?I
KD	TOOLCHAIN_TYPE@@//tcl:toolchain_typej@@//tcl:toolchain_typetcl toolchain rules�!
+
	rules_tcltcl/tclint/private
tclint.bzl�tcl_tclint_fmt_test�A test rule for performing formatting checks on a Tcl target.

**Usage:**

```python
load("@rules_tcl//tcl/tclint:tcl_tclint_fmt_test.bzl", "tcl_tclint_fmt_test")

tcl_tclint_fmt_test(
    name = "mylib_format",
    target = ":mylib",
)
```
"�
�
tcl_tclint_fmt_test�A test rule for performing formatting checks on a Tcl target.

**Usage:**

```python
load("@rules_tcl//tcl/tclint:tcl_tclint_fmt_test.bzl", "tcl_tclint_fmt_test")

tcl_tclint_fmt_test(
    name = "mylib_format",
    target = ":mylib",
)
```
*
nameA unique name for this target. H
target/The Tcl target to perform formatting checks on. *	
TclInfo"A
tcl_tclint_fmt_test*@@rules_tcl//tcl/tclint/private:tclint.bzl
��,
*
nameA unique name for this target. J
H
target/The Tcl target to perform formatting checks on. *	
TclInfo�tcl_tclint_test�A test rule for performing tclint linting checks on a Tcl target.

**Usage:**

```python
load("@rules_tcl//tcl/tclint:tcl_tclint_test.bzl", "tcl_tclint_test")

tcl_tclint_test(
    name = "mylib_tclint",
    target = ":mylib",
)
```
"�
�
tcl_tclint_test�A test rule for performing tclint linting checks on a Tcl target.

**Usage:**

```python
load("@rules_tcl//tcl/tclint:tcl_tclint_test.bzl", "tcl_tclint_test")

tcl_tclint_test(
    name = "mylib_tclint",
    target = ":mylib",
)
```
*
nameA unique name for this target. >
target%The Tcl target to perform linting on. *	
TclInfo"=
tcl_tclint_test*@@rules_tcl//tcl/tclint/private:tclint.bzl
��,
*
nameA unique name for this target. @
>
target%The Tcl target to perform linting on. *	
TclInfo�tcl_tclint_aspect�An aspect for performing tclint linting checks on Tcl targets.

Uses [tclint](https://github.com/nmoroze/tclint) to check for code quality issues.

**Usage:**

```bash
bazel build //my:target \
    --aspects=@rules_tcl//tcl/tclint:tcl_tclint_aspect.bzl%tcl_tclint_aspect \
    --output_groups=+tcl_tclint_checks
```

**Ignoring targets:**

To skip tclint for specific targets, add one of these tags:
- `no_tcl_lint`
- `no_tclint`
- `no_lint`
- `nolint`
:�
�
tcl_tclint_aspect�An aspect for performing tclint linting checks on Tcl targets.

Uses [tclint](https://github.com/nmoroze/tclint) to check for code quality issues.

**Usage:**

```bash
bazel build //my:target \
    --aspects=@rules_tcl//tcl/tclint:tcl_tclint_aspect.bzl%tcl_tclint_aspect \
    --output_groups=+tcl_tclint_checks
```

**Ignoring targets:**

To skip tclint for specific targets, add one of these tags:
- `no_tcl_lint`
- `no_tclint`
- `no_lint`
- `nolint`
"*
nameA unique name for this target. *?
tcl_tclint_aspect*@@rules_tcl//tcl/tclint/private:tclint.bzl
44,
*
nameA unique name for this target. �	tcl_tclint_fmt_aspect�An aspect for performing formatting checks on Tcl targets.

Uses [tclint](https://github.com/nmoroze/tclint) to verify formatting.

**Usage:**

```bash
bazel build //my:target \
    --aspects=@rules_tcl//tcl/tclint:tcl_tclint_fmt_aspect.bzl%tcl_tclint_fmt_aspect \
    --output_groups=+tcl_tclint_fmt_checks
```

**Ignoring targets:**

To skip format checking for specific targets, add one of these tags:
- `no_tcl_format`
- `no_tclformat`
- `no_tclfmt`
- `noformat`
- `nofmt`
:�
�
tcl_tclint_fmt_aspect�An aspect for performing formatting checks on Tcl targets.

Uses [tclint](https://github.com/nmoroze/tclint) to verify formatting.

**Usage:**

```bash
bazel build //my:target \
    --aspects=@rules_tcl//tcl/tclint:tcl_tclint_fmt_aspect.bzl%tcl_tclint_fmt_aspect \
    --output_groups=+tcl_tclint_fmt_checks
```

**Ignoring targets:**

To skip format checking for specific targets, add one of these tags:
- `no_tcl_format`
- `no_tclformat`
- `no_tclfmt`
- `noformat`
- `nofmt`
"*
nameA unique name for this target. *C
tcl_tclint_fmt_aspect*@@rules_tcl//tcl/tclint/private:tclint.bzl
��,
*
nameA unique name for this target. �
//tcl/private:providers.bzlr
'
	rules_tcltcl/privateproviders.bzl 
TclInfoTclInfo
07$
	find_srcs	find_srcs
;D
FTclint lint and format rules�#
!
	rules_tcl
tcl/tclintdefs.bzl�
tclint_toolchain�A toolchain rule for configuring [tclint](https://github.com/nmoroze/tclint).

The `tclint_toolchain` rule specifies the tclint Python library used by
`tcl_tclint_aspect`, `tcl_format_aspect`, and related test rules.

Typically, you don't need to define this directly. Instead, use the bzlmod extension:

```python
tclint = use_extension("@rules_tcl//tcl/tclint:extensions.bzl", "tclint")
tclint.toolchain()
use_repo(tclint, "tclint_toolchains")
register_toolchains("@tclint_toolchains//:all")
```
"�
�
tclint_toolchain�A toolchain rule for configuring [tclint](https://github.com/nmoroze/tclint).

The `tclint_toolchain` rule specifies the tclint Python library used by
`tcl_tclint_aspect`, `tcl_format_aspect`, and related test rules.

Typically, you don't need to define this directly. Instead, use the bzlmod extension:

```python
tclint = use_extension("@rules_tcl//tcl/tclint:extensions.bzl", "tclint")
tclint.toolchain()
use_repo(tclint, "tclint_toolchains")
register_toolchains("@tclint_toolchains//:all")
```
*
nameA unique name for this target. O
tclintAThe [`tclint`](https://github.com/nmoroze/tclint) python library. "4
tclint_toolchain @@rules_tcl//tcl/tclint:defs.bzl
,
*
nameA unique name for this target. Q
O
tclintAThe [`tclint`](https://github.com/nmoroze/tclint) python library. �tcl_tclint_aspect�An aspect for performing tclint linting checks on Tcl targets.

Uses [tclint](https://github.com/nmoroze/tclint) to check for code quality issues.

**Usage:**

```bash
bazel build //my:target \
    --aspects=@rules_tcl//tcl/tclint:tcl_tclint_aspect.bzl%tcl_tclint_aspect \
    --output_groups=+tcl_tclint_checks
```

**Ignoring targets:**

To skip tclint for specific targets, add one of these tags:
- `no_tcl_lint`
- `no_tclint`
- `no_lint`
- `nolint`
:�
�
tcl_tclint_aspect�An aspect for performing tclint linting checks on Tcl targets.

Uses [tclint](https://github.com/nmoroze/tclint) to check for code quality issues.

**Usage:**

```bash
bazel build //my:target \
    --aspects=@rules_tcl//tcl/tclint:tcl_tclint_aspect.bzl%tcl_tclint_aspect \
    --output_groups=+tcl_tclint_checks
```

**Ignoring targets:**

To skip tclint for specific targets, add one of these tags:
- `no_tcl_lint`
- `no_tclint`
- `no_lint`
- `nolint`
"*
nameA unique name for this target. *5
tcl_tclint_aspect @@rules_tcl//tcl/tclint:defs.bzl
44,
*
nameA unique name for this target. �	tcl_tclint_fmt_aspect�An aspect for performing formatting checks on Tcl targets.

Uses [tclint](https://github.com/nmoroze/tclint) to verify formatting.

**Usage:**

```bash
bazel build //my:target \
    --aspects=@rules_tcl//tcl/tclint:tcl_tclint_fmt_aspect.bzl%tcl_tclint_fmt_aspect \
    --output_groups=+tcl_tclint_fmt_checks
```

**Ignoring targets:**

To skip format checking for specific targets, add one of these tags:
- `no_tcl_format`
- `no_tclformat`
- `no_tclfmt`
- `noformat`
- `nofmt`
:�
�
tcl_tclint_fmt_aspect�An aspect for performing formatting checks on Tcl targets.

Uses [tclint](https://github.com/nmoroze/tclint) to verify formatting.

**Usage:**

```bash
bazel build //my:target \
    --aspects=@rules_tcl//tcl/tclint:tcl_tclint_fmt_aspect.bzl%tcl_tclint_fmt_aspect \
    --output_groups=+tcl_tclint_fmt_checks
```

**Ignoring targets:**

To skip format checking for specific targets, add one of these tags:
- `no_tcl_format`
- `no_tclformat`
- `no_tclfmt`
- `noformat`
- `nofmt`
"*
nameA unique name for this target. *9
tcl_tclint_fmt_aspect @@rules_tcl//tcl/tclint:defs.bzl
��,
*
nameA unique name for this target. �
"//tcl/tclint:tcl_tclint_aspect.bzlru
.
	rules_tcl
tcl/tclinttcl_tclint_aspect.bzl5
tcl_tclint_aspect_tcl_tclint_aspect
6H
_�
&//tcl/tclint:tcl_tclint_fmt_aspect.bzlr�
2
	rules_tcl
tcl/tclinttcl_tclint_fmt_aspect.bzl=
tcl_tclint_fmt_aspect_tcl_tclint_fmt_aspect
:P
k�
$//tcl/tclint:tcl_tclint_fmt_test.bzlr{
0
	rules_tcl
tcl/tclinttcl_tclint_fmt_test.bzl9
tcl_tclint_fmt_test_tcl_tclint_fmt_test
8L
e�
 //tcl/tclint:tcl_tclint_test.bzlro
,
	rules_tcl
tcl/tclinttcl_tclint_test.bzl1
tcl_tclint_test_tcl_tclint_test
4D
Y�
!//tcl/tclint:tclint_toolchain.bzlrr
-
	rules_tcl
tcl/tclinttclint_toolchain.bzl3
tclint_toolchain_tclint_toolchain
5F
\Tclint Bazel rules�
'
	rules_tcl
tcl/tclintextensions.bzl�tclintJ�
i
tclint-
	toolchain Configures the tclint toolchain."0
tclint&@@rules_tcl//tcl/tclint:extensions.bzl
((/
-
	toolchain Configures the tclint toolchain.&Bzlmod extension for tclint toolchain.�

.
	rules_tcl
tcl/tclinttcl_tclint_aspect.bzl�tcl_tclint_aspect�An aspect for performing tclint linting checks on Tcl targets.

Uses [tclint](https://github.com/nmoroze/tclint) to check for code quality issues.

**Usage:**

```bash
bazel build //my:target \
    --aspects=@rules_tcl//tcl/tclint:tcl_tclint_aspect.bzl%tcl_tclint_aspect \
    --output_groups=+tcl_tclint_checks
```

**Ignoring targets:**

To skip tclint for specific targets, add one of these tags:
- `no_tcl_lint`
- `no_tclint`
- `no_lint`
- `nolint`
:�
�
tcl_tclint_aspect�An aspect for performing tclint linting checks on Tcl targets.

Uses [tclint](https://github.com/nmoroze/tclint) to check for code quality issues.

**Usage:**

```bash
bazel build //my:target \
    --aspects=@rules_tcl//tcl/tclint:tcl_tclint_aspect.bzl%tcl_tclint_aspect \
    --output_groups=+tcl_tclint_checks
```

**Ignoring targets:**

To skip tclint for specific targets, add one of these tags:
- `no_tcl_lint`
- `no_tclint`
- `no_lint`
- `nolint`
"*
nameA unique name for this target. *B
tcl_tclint_aspect-@@rules_tcl//tcl/tclint:tcl_tclint_aspect.bzl
44,
*
nameA unique name for this target. �
//tcl/tclint/private:tclint.bzlrr
+
	rules_tcltcl/tclint/private
tclint.bzl5
tcl_tclint_aspect_tcl_tclint_aspect

tcl_tclint_aspect�
2
	rules_tcl
tcl/tclinttcl_tclint_fmt_aspect.bzl�	tcl_tclint_fmt_aspect�An aspect for performing formatting checks on Tcl targets.

Uses [tclint](https://github.com/nmoroze/tclint) to verify formatting.

**Usage:**

```bash
bazel build //my:target \
    --aspects=@rules_tcl//tcl/tclint:tcl_tclint_fmt_aspect.bzl%tcl_tclint_fmt_aspect \
    --output_groups=+tcl_tclint_fmt_checks
```

**Ignoring targets:**

To skip format checking for specific targets, add one of these tags:
- `no_tcl_format`
- `no_tclformat`
- `no_tclfmt`
- `noformat`
- `nofmt`
:�
�
tcl_tclint_fmt_aspect�An aspect for performing formatting checks on Tcl targets.

Uses [tclint](https://github.com/nmoroze/tclint) to verify formatting.

**Usage:**

```bash
bazel build //my:target \
    --aspects=@rules_tcl//tcl/tclint:tcl_tclint_fmt_aspect.bzl%tcl_tclint_fmt_aspect \
    --output_groups=+tcl_tclint_fmt_checks
```

**Ignoring targets:**

To skip format checking for specific targets, add one of these tags:
- `no_tcl_format`
- `no_tclformat`
- `no_tclfmt`
- `noformat`
- `nofmt`
"*
nameA unique name for this target. *J
tcl_tclint_fmt_aspect1@@rules_tcl//tcl/tclint:tcl_tclint_fmt_aspect.bzl
��,
*
nameA unique name for this target. �
//tcl/tclint/private:tclint.bzlrz
+
	rules_tcltcl/tclint/private
tclint.bzl=
tcl_tclint_fmt_aspect_tcl_tclint_fmt_aspect

tcl_tclint_fmt_aspect�
-
	rules_tcl
tcl/tclinttclint_toolchain.bzl�current_tclint_toolchainNA rule for accessing the `tclint` attribute of the current `tclint_toolchain`."�
�
current_tclint_toolchainNA rule for accessing the `tclint` attribute of the current `tclint_toolchain`.*
nameA unique name for this target. "H
current_tclint_toolchain,@@rules_tcl//tcl/tclint:tclint_toolchain.bzl
> > ,
*
nameA unique name for this target. �
tclint_toolchain�A toolchain rule for configuring [tclint](https://github.com/nmoroze/tclint).

The `tclint_toolchain` rule specifies the tclint Python library used by
`tcl_tclint_aspect`, `tcl_format_aspect`, and related test rules.

Typically, you don't need to define this directly. Instead, use the bzlmod extension:

```python
tclint = use_extension("@rules_tcl//tcl/tclint:extensions.bzl", "tclint")
tclint.toolchain()
use_repo(tclint, "tclint_toolchains")
register_toolchains("@tclint_toolchains//:all")
```
"�
�
tclint_toolchain�A toolchain rule for configuring [tclint](https://github.com/nmoroze/tclint).

The `tclint_toolchain` rule specifies the tclint Python library used by
`tcl_tclint_aspect`, `tcl_format_aspect`, and related test rules.

Typically, you don't need to define this directly. Instead, use the bzlmod extension:

```python
tclint = use_extension("@rules_tcl//tcl/tclint:extensions.bzl", "tclint")
tclint.toolchain()
use_repo(tclint, "tclint_toolchains")
register_toolchains("@tclint_toolchains//:all")
```
*
nameA unique name for this target. O
tclintAThe [`tclint`](https://github.com/nmoroze/tclint) python library. "@
tclint_toolchain,@@rules_tcl//tcl/tclint:tclint_toolchain.bzl
,
*
nameA unique name for this target. Q
O
tclintAThe [`tclint`](https://github.com/nmoroze/tclint) python library. k
//python:py_info.bzlrQ
!

rules_venvpythonpy_info.bzl
PyInfoPyInfo
*0
2Y	TCLINT_TOOLCHAIN_TYPE@@//tcl/tclint:toolchain_typej@@//tcl/tclint:toolchain_typeTclint toolchain rules��

	rules_tcltcldefs.bzl�
tcl_binary�A `tcl_binary` is an executable Tcl program consisting of a collection of
`.tcl` or `.do` source files (possibly belonging to other `tcl_library` rules), a `*.runfiles`
directory tree containing all the code and data needed by the program at run-time,
and a stub script that starts up the program with the correct initial environment
and data.

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_binary")

tcl_binary(
    name = "foo",
    srcs = ["foo.tcl"],
    deps = [
        ":bar",  # a tcl_library
    ],
)
```
"�
�	

tcl_binary�A `tcl_binary` is an executable Tcl program consisting of a collection of
`.tcl` or `.do` source files (possibly belonging to other `tcl_library` rules), a `*.runfiles`
directory tree containing all the code and data needed by the program at run-time,
and a stub script that starts up the program with the correct initial environment
and data.

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_binary")

tcl_binary(
    name = "foo",
    srcs = ["foo.tcl"],
    deps = [
        ":bar",  # a tcl_library
    ],
)
```
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2None_
srcsSThe list of source (`.tcl` or `.do`) files that are processed to create the target. "'

tcl_binary@@rules_tcl//tcl:defs.bzl
��,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]L
J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]k
i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}�
�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2Nonea
_
srcsSThe list of source (`.tcl` or `.do`) files that are processed to create the target. �tcl_library�A Tcl library that can be depended upon by other Tcl targets.

A `tcl_library` groups a set of `.tcl` or `.do` source files that can be consumed by other Tcl
targets. If a `pkgIndex.tcl` file is included in `srcs`, its directory is added to the consumer's
`auto_path` so the package can be loaded with Tcl's `package require` command. Libraries without a
`pkgIndex.tcl` are still made available through runfiles and can be loaded directly with `source`
(typically via the runfiles library's `rlocation`).

Example with `package require`:

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_library")

tcl_library(
    name = "mylib",
    srcs = [
        "mylib.tcl",
        "pkgIndex.tcl",
    ],
    deps = [
        ":otherlib",  # Another tcl_library
    ],
    visibility = ["//visibility:public"],
)
```

The library can then be used as a dependency in other targets:

```python
tcl_binary(
    name = "app",
    srcs = ["app.tcl"],
    deps = [":mylib"],
)
```
"�
�

tcl_library�A Tcl library that can be depended upon by other Tcl targets.

A `tcl_library` groups a set of `.tcl` or `.do` source files that can be consumed by other Tcl
targets. If a `pkgIndex.tcl` file is included in `srcs`, its directory is added to the consumer's
`auto_path` so the package can be loaded with Tcl's `package require` command. Libraries without a
`pkgIndex.tcl` are still made available through runfiles and can be loaded directly with `source`
(typically via the runfiles library's `rlocation`).

Example with `package require`:

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_library")

tcl_library(
    name = "mylib",
    srcs = [
        "mylib.tcl",
        "pkgIndex.tcl",
    ],
    deps = [
        ":otherlib",  # Another tcl_library
    ],
    visibility = ["//visibility:public"],
)
```

The library can then be used as a dependency in other targets:

```python
tcl_binary(
    name = "app",
    srcs = ["app.tcl"],
    deps = [":mylib"],
)
```
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]_
srcsSThe list of source (`.tcl` or `.do`) files that are processed to create the target. "(
tcl_library@@rules_tcl//tcl:defs.bzl
��,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]L
J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]a
_
srcsSThe list of source (`.tcl` or `.do`) files that are processed to create the target. �xtcl_toolchain�4A toolchain rule that defines the Tcl interpreter, libraries, and executable wrapper used
to build `tcl_binary`, `tcl_library`, and `tcl_test` targets.

## Registering a toolchain

`rules_tcl` does not register a toolchain for you. Add the following to your `MODULE.bazel`
to use the default (a stock `tclsh` and tcllib, with the built-in shell/batch wrapper):

```python
register_toolchains("@rules_tcl//tcl/toolchain")
```

If you need a custom toolchain (e.g. a different Tcl version, or a wrapper that dispatches
into a different host interpreter), define your own. `tclcore` and `tcllib` are matched by
provider â pass a target that returns `TclCoreInfo` / `TclLibInfo`, typically produced by
the sibling `tclcore_filegroup` and `tcllib_filegroup` rules:

```python
load("@rules_tcl//tcl:tcl_toolchain.bzl", "tcl_toolchain", "tclcore_filegroup")

tclcore_filegroup(
    name = "my_tclcore",
    srcs = ["@my_tcl//:tclcore_files"],
)

tcl_toolchain(
    name = "my_tcl_toolchain",
    tclsh = "@my_tcl//:tclsh",
    tclcore = ":my_tclcore",     # optional; must provide TclCoreInfo
    tcllib = "@tcllib",          # optional; must provide TclLibInfo
    wrapper_template = "//path/to:my_wrapper_bundle",
    wrapper_entrypoint = "//path/to:my_entrypoint.tcl",  # optional
)
```

`tclcore` and `tcllib` may be omitted when the interpreter ships them itself.
`wrapper_entrypoint` is optional when the wrapper does not need a bootstrap script.

The template's own `DefaultInfo.default_runfiles` are merged into every produced binary,
so a template that needs a helper library (e.g. `@rules_shell//shell/runfiles` for sh,
`@rules_batch//batch/runfiles` for batch) should be declared via a `filegroup` that lists
the helper under `data`:

```python
filegroup(
    name = "my_wrapper_bundle",
    srcs = ["my_wrapper.sh.tpl"],
    data = ["@rules_shell//shell/runfiles"],
)
```

The same is true for `wrapper_entrypoint` â a `filegroup` around the entrypoint can carry
extra runtime data it needs at execution.

The extension appended to the produced wrapper is derived from the template's filename by
splitting the basename on the first `.` and dropping any trailing parts that are known
template suffixes (`.tpl`, `.template`, `.tmpl`, `.in`); whatever remains is the extension.
E.g. `my_wrapper.sh.tpl` yields `.sh`, `my_wrapper.bat.template` yields `.bat`,
`my_wrapper.vhook.tcl.tpl` yields `.vhook.tcl`. Since the split happens at the FIRST dot,
templates whose basename contains a dot in the name portion (e.g. `com.foo.wrapper.sh.tpl`
intending `.sh`) should be renamed so the first `.` marks the extension boundary.

## `ToolchainInfo` contract

The rule returns a `platform_common.ToolchainInfo` with the following fields. Non-underscore
fields are the public contract that consumers (including third-party rules that operate
over Tcl targets) may read. Underscore-prefixed fields are internal to the built-in
`tcl_binary` / `tcl_test` implementation â third-party rules that want a materially
different wrapper should carry their own template rather than reach into them.

| Field                | Type                                   | Access   | Notes                                                              |
|----------------------|----------------------------------------|----------|--------------------------------------------------------------------|
| `tclsh`              | `File`                                 | public   | Executable of the interpreter that will run the produced binaries. |
| `includes`           | `depset[str]`                          | public   | Runfiles-relative include paths implicitly on `auto_path`.         |
| `init_tcl`           | `File \| None`                        | public   | `init.tcl` from tclcore, or `None`.                                |
| `tcllib_pkg_index`   | `File \| None`                        | public   | tcllib's top-level `pkgIndex.tcl`, or `None`.                      |
| `all_files`          | `depset[File]`                         | public   | Runtime files merged into every produced target.                   |
| `make_variable_info` | `platform_common.TemplateVariableInfo` | public   | Exposes `$(TCLSH)` for `env` on downstream rules.                  |
| `_wrapper_*`         | (various)                              | internal | Wrapper template, entrypoint, and derived extension.               |

## Wrapper template contract

The built-in `tcl_binary` / `tcl_test` expand `wrapper_template` once per target into a
file named `<target><wrapper_extension>` and set it as the target's executable. The
template supports these substitutions; values whose backing toolchain field is unset
expand to the empty string, so a template can simply omit lines it does not need:

| Substitution         | Value                                                                                 | Empty when                   |
|----------------------|---------------------------------------------------------------------------------------|------------------------------|
| `{interpreter}`      | Runfiles path (rlocation) of `tclsh`.                                                 | never                        |
| `{entrypoint}`       | Runfiles path of `wrapper_entrypoint`.                                                | `wrapper_entrypoint` unset   |
| `{config}`           | Runfiles path of a per-target JSON config (see below).                                | never                        |
| `{main}`             | Runfiles path of the target's entry `.tcl` (resolved from `main` / `srcs`).           | never                        |
| `{init_tcl}`         | Runfiles path of tclcore's `init.tcl`.                                                | `tclcore` unset              |
| `{tcllib_pkg_index}` | Runfiles path of tcllib's top-level `pkgIndex.tcl`.                                   | `tcllib` unset               |
| `{auto_path}`        | Tcl-list literal (brace-quoted) of every include path visible to the target â the target's own workspace, each dep's `TclInfo.includes`, and the toolchain's `includes`. Suitable to `lappend` onto `auto_path`. | never |

The `{config}` file is JSON with this shape:

```json
{
  "includes": ["workspace_name", "workspace_name/path/to/lib", "..."],
  "runfiles": ["workspace_name/path/to/file", "..."]
}
```

`includes` is the same set of runfiles-relative paths surfaced through `{auto_path}`;
`runfiles` is every file merged into the target's runfiles. The default `entrypoint.tcl`
consumes this to set `TCLLIBPATH` and to materialize a `RUNFILES_DIR` when only a manifest
is available; alternate wrappers can consume, ignore, or extend it as they see fit.
"�D
�<
tcl_toolchain�4A toolchain rule that defines the Tcl interpreter, libraries, and executable wrapper used
to build `tcl_binary`, `tcl_library`, and `tcl_test` targets.

## Registering a toolchain

`rules_tcl` does not register a toolchain for you. Add the following to your `MODULE.bazel`
to use the default (a stock `tclsh` and tcllib, with the built-in shell/batch wrapper):

```python
register_toolchains("@rules_tcl//tcl/toolchain")
```

If you need a custom toolchain (e.g. a different Tcl version, or a wrapper that dispatches
into a different host interpreter), define your own. `tclcore` and `tcllib` are matched by
provider â pass a target that returns `TclCoreInfo` / `TclLibInfo`, typically produced by
the sibling `tclcore_filegroup` and `tcllib_filegroup` rules:

```python
load("@rules_tcl//tcl:tcl_toolchain.bzl", "tcl_toolchain", "tclcore_filegroup")

tclcore_filegroup(
    name = "my_tclcore",
    srcs = ["@my_tcl//:tclcore_files"],
)

tcl_toolchain(
    name = "my_tcl_toolchain",
    tclsh = "@my_tcl//:tclsh",
    tclcore = ":my_tclcore",     # optional; must provide TclCoreInfo
    tcllib = "@tcllib",          # optional; must provide TclLibInfo
    wrapper_template = "//path/to:my_wrapper_bundle",
    wrapper_entrypoint = "//path/to:my_entrypoint.tcl",  # optional
)
```

`tclcore` and `tcllib` may be omitted when the interpreter ships them itself.
`wrapper_entrypoint` is optional when the wrapper does not need a bootstrap script.

The template's own `DefaultInfo.default_runfiles` are merged into every produced binary,
so a template that needs a helper library (e.g. `@rules_shell//shell/runfiles` for sh,
`@rules_batch//batch/runfiles` for batch) should be declared via a `filegroup` that lists
the helper under `data`:

```python
filegroup(
    name = "my_wrapper_bundle",
    srcs = ["my_wrapper.sh.tpl"],
    data = ["@rules_shell//shell/runfiles"],
)
```

The same is true for `wrapper_entrypoint` â a `filegroup` around the entrypoint can carry
extra runtime data it needs at execution.

The extension appended to the produced wrapper is derived from the template's filename by
splitting the basename on the first `.` and dropping any trailing parts that are known
template suffixes (`.tpl`, `.template`, `.tmpl`, `.in`); whatever remains is the extension.
E.g. `my_wrapper.sh.tpl` yields `.sh`, `my_wrapper.bat.template` yields `.bat`,
`my_wrapper.vhook.tcl.tpl` yields `.vhook.tcl`. Since the split happens at the FIRST dot,
templates whose basename contains a dot in the name portion (e.g. `com.foo.wrapper.sh.tpl`
intending `.sh`) should be renamed so the first `.` marks the extension boundary.

## `ToolchainInfo` contract

The rule returns a `platform_common.ToolchainInfo` with the following fields. Non-underscore
fields are the public contract that consumers (including third-party rules that operate
over Tcl targets) may read. Underscore-prefixed fields are internal to the built-in
`tcl_binary` / `tcl_test` implementation â third-party rules that want a materially
different wrapper should carry their own template rather than reach into them.

| Field                | Type                                   | Access   | Notes                                                              |
|----------------------|----------------------------------------|----------|--------------------------------------------------------------------|
| `tclsh`              | `File`                                 | public   | Executable of the interpreter that will run the produced binaries. |
| `includes`           | `depset[str]`                          | public   | Runfiles-relative include paths implicitly on `auto_path`.         |
| `init_tcl`           | `File \| None`                        | public   | `init.tcl` from tclcore, or `None`.                                |
| `tcllib_pkg_index`   | `File \| None`                        | public   | tcllib's top-level `pkgIndex.tcl`, or `None`.                      |
| `all_files`          | `depset[File]`                         | public   | Runtime files merged into every produced target.                   |
| `make_variable_info` | `platform_common.TemplateVariableInfo` | public   | Exposes `$(TCLSH)` for `env` on downstream rules.                  |
| `_wrapper_*`         | (various)                              | internal | Wrapper template, entrypoint, and derived extension.               |

## Wrapper template contract

The built-in `tcl_binary` / `tcl_test` expand `wrapper_template` once per target into a
file named `<target><wrapper_extension>` and set it as the target's executable. The
template supports these substitutions; values whose backing toolchain field is unset
expand to the empty string, so a template can simply omit lines it does not need:

| Substitution         | Value                                                                                 | Empty when                   |
|----------------------|---------------------------------------------------------------------------------------|------------------------------|
| `{interpreter}`      | Runfiles path (rlocation) of `tclsh`.                                                 | never                        |
| `{entrypoint}`       | Runfiles path of `wrapper_entrypoint`.                                                | `wrapper_entrypoint` unset   |
| `{config}`           | Runfiles path of a per-target JSON config (see below).                                | never                        |
| `{main}`             | Runfiles path of the target's entry `.tcl` (resolved from `main` / `srcs`).           | never                        |
| `{init_tcl}`         | Runfiles path of tclcore's `init.tcl`.                                                | `tclcore` unset              |
| `{tcllib_pkg_index}` | Runfiles path of tcllib's top-level `pkgIndex.tcl`.                                   | `tcllib` unset               |
| `{auto_path}`        | Tcl-list literal (brace-quoted) of every include path visible to the target â the target's own workspace, each dep's `TclInfo.includes`, and the toolchain's `includes`. Suitable to `lappend` onto `auto_path`. | never |

The `{config}` file is JSON with this shape:

```json
{
  "includes": ["workspace_name", "workspace_name/path/to/lib", "..."],
  "runfiles": ["workspace_name/path/to/file", "..."]
}
```

`includes` is the same set of runfiles-relative paths surfaced through `{auto_path}`;
`runfiles` is every file merged into the target's runfiles. The default `entrypoint.tcl`
consumes this to set `TCLLIBPATH` and to materialize a `RUNFILES_DIR` when only a manifest
is available; alternate wrappers can consume, ignore, or extend it as they see fit.
*
nameA unique name for this target. e
tclcoreCA target providing `TclCoreInfo` (typically a `tclcore_filegroup`).*
TclCoreInfo2Nonea
tcllibAA target providing `TclLibInfo` (typically a `tcllib_filegroup`).*

TclLibInfo2Nonej
tclsh]The path to a `tclsh` binary. Runtime dependency of every produced `tcl_binary` / `tcl_test`. �
wrapper_entrypoint�Optional `.tcl` file added to the binary's runfiles and referenced via the `{entrypoint}` template substitution. The target's `default_runfiles` are also merged in. Leave unset when the wrapper doesn't need a bootstrap.2None�
wrapper_template�Template expanded per `tcl_binary` / `tcl_test`. The target's `default_runfiles` are merged into every produced binary, so a `filegroup` wrapping the template can list helper libraries under `data` (e.g. `@bazel_tools//tools/bash/runfiles`). See the wrapper template contract in the rule docs for the supported substitutions. "*
tcl_toolchain@@rules_tcl//tcl:defs.bzl
\\,
*
nameA unique name for this target. g
e
tclcoreCA target providing `TclCoreInfo` (typically a `tclcore_filegroup`).*
TclCoreInfo2Nonec
a
tcllibAA target providing `TclLibInfo` (typically a `tcllib_filegroup`).*

TclLibInfo2Nonel
j
tclsh]The path to a `tclsh` binary. Runtime dependency of every produced `tcl_binary` / `tcl_test`. �
�
wrapper_entrypoint�Optional `.tcl` file added to the binary's runfiles and referenced via the `{entrypoint}` template substitution. The target's `default_runfiles` are also merged in. Leave unset when the wrapper doesn't need a bootstrap.2None�
�
wrapper_template�Template expanded per `tcl_binary` / `tcl_test`. The target's `default_runfiles` are merged into every produced binary, so a `filegroup` wrapping the template can list helper libraries under `data` (e.g. `@bazel_tools//tools/bash/runfiles`). See the wrapper template contract in the rule docs for the supported substitutions. s
//tcl:tcl_binary.bzlrY
 
	rules_tcltcltcl_binary.bzl'

tcl_binary_tcl_binary
(3
Cw
//tcl:tcl_library.bzlr\
!
	rules_tcltcltcl_library.bzl)
tcl_library_tcl_library
)5
F
//tcl:tcl_toolchain.bzlrb
#
	rules_tcltcltcl_toolchain.bzl-
tcl_toolchain_tcl_toolchain
+9
LTcl Bazel rules�
 
	rules_tcltclextensions.bzl�tcllib�Fetches the tcllib releases listed in `TCLLIB_VERSIONS`.

Exposes them through a single `@tcllib` hub repository. Consumers
reference tcllib via `@tcllib` (newest overall), `@tcllib//:tcl_8` /
`@tcllib//:tcl_9` (newest supporting a given Tcl major), or
`@tcllib//<version>` (a specific release).
J�
�
tcllib�Fetches the tcllib releases listed in `TCLLIB_VERSIONS`.

Exposes them through a single `@tcllib` hub repository. Consumers
reference tcllib via `@tcllib` (newest overall), `@tcllib//:tcl_8` /
`@tcllib//:tcl_9` (newest supporting a given Tcl major), or
`@tcllib//<version>` (a specific release).
")
tcllib@@rules_tcl//tcl:extensions.bzl
���
"//tcl/private:tcllib_extension.bzlr_
.
	rules_tcltcl/privatetcllib_extension.bzl
tcllib_tcllib
6=
I Bzlmod extensions for rules_tcl.�
 
	rules_tcltcltcl_binary.bzl�
tcl_binary�A `tcl_binary` is an executable Tcl program consisting of a collection of
`.tcl` or `.do` source files (possibly belonging to other `tcl_library` rules), a `*.runfiles`
directory tree containing all the code and data needed by the program at run-time,
and a stub script that starts up the program with the correct initial environment
and data.

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_binary")

tcl_binary(
    name = "foo",
    srcs = ["foo.tcl"],
    deps = [
        ":bar",  # a tcl_library
    ],
)
```
"�
�	

tcl_binary�A `tcl_binary` is an executable Tcl program consisting of a collection of
`.tcl` or `.do` source files (possibly belonging to other `tcl_library` rules), a `*.runfiles`
directory tree containing all the code and data needed by the program at run-time,
and a stub script that starts up the program with the correct initial environment
and data.

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_binary")

tcl_binary(
    name = "foo",
    srcs = ["foo.tcl"],
    deps = [
        ":bar",  # a tcl_library
    ],
)
```
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2None_
srcsSThe list of source (`.tcl` or `.do`) files that are processed to create the target. "-

tcl_binary@@rules_tcl//tcl:tcl_binary.bzl
��,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]L
J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]k
i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}�
�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2Nonea
_
srcsSThe list of source (`.tcl` or `.do`) files that are processed to create the target. u
//tcl/private:tcl.bzlrZ
!
	rules_tcltcl/privatetcl.bzl'

tcl_binary_tcl_binary
)4
D
tcl_binary�

	rules_tcltcltcl_info.bzl�TclInfoInfo about a Tcl target.2�
�
TclInfoInfo about a Tcl target.T
includesHDepset[str]: A list of include paths associated with the current target.@
srcs8Depset[File]: Direct source files of the current target.D
transitive_includes-Depset[str]: Include paths from dependencies.T
transitive_srcsADepset[File]: Source files required at runtime from dependencies."(
TclInfo@@rules_tcl//tcl:tcl_info.bzl
V
T
includesHDepset[str]: A list of include paths associated with the current target.B
@
srcs8Depset[File]: Direct source files of the current target.F
D
transitive_includes-Depset[str]: Include paths from dependencies.V
T
transitive_srcsADepset[File]: Source files required at runtime from dependencies.{
//tcl/private:providers.bzlrZ
'
	rules_tcltcl/privateproviders.bzl!
TclInfo_TclInfo
/7
DTclInfo�
!
	rules_tcltcltcl_library.bzl�tcl_library�A Tcl library that can be depended upon by other Tcl targets.

A `tcl_library` groups a set of `.tcl` or `.do` source files that can be consumed by other Tcl
targets. If a `pkgIndex.tcl` file is included in `srcs`, its directory is added to the consumer's
`auto_path` so the package can be loaded with Tcl's `package require` command. Libraries without a
`pkgIndex.tcl` are still made available through runfiles and can be loaded directly with `source`
(typically via the runfiles library's `rlocation`).

Example with `package require`:

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_library")

tcl_library(
    name = "mylib",
    srcs = [
        "mylib.tcl",
        "pkgIndex.tcl",
    ],
    deps = [
        ":otherlib",  # Another tcl_library
    ],
    visibility = ["//visibility:public"],
)
```

The library can then be used as a dependency in other targets:

```python
tcl_binary(
    name = "app",
    srcs = ["app.tcl"],
    deps = [":mylib"],
)
```
"�
�

tcl_library�A Tcl library that can be depended upon by other Tcl targets.

A `tcl_library` groups a set of `.tcl` or `.do` source files that can be consumed by other Tcl
targets. If a `pkgIndex.tcl` file is included in `srcs`, its directory is added to the consumer's
`auto_path` so the package can be loaded with Tcl's `package require` command. Libraries without a
`pkgIndex.tcl` are still made available through runfiles and can be loaded directly with `source`
(typically via the runfiles library's `rlocation`).

Example with `package require`:

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_library")

tcl_library(
    name = "mylib",
    srcs = [
        "mylib.tcl",
        "pkgIndex.tcl",
    ],
    deps = [
        ":otherlib",  # Another tcl_library
    ],
    visibility = ["//visibility:public"],
)
```

The library can then be used as a dependency in other targets:

```python
tcl_binary(
    name = "app",
    srcs = ["app.tcl"],
    deps = [":mylib"],
)
```
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]_
srcsSThe list of source (`.tcl` or `.do`) files that are processed to create the target. "/
tcl_library @@rules_tcl//tcl:tcl_library.bzl
��,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]L
J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]a
_
srcsSThe list of source (`.tcl` or `.do`) files that are processed to create the target. w
//tcl/private:tcl.bzlr\
!
	rules_tcltcl/privatetcl.bzl)
tcl_library_tcl_library
)5
Ftcl_library�
#
	rules_tcltcltcl_toolchain.bzl�xtcl_toolchain�4A toolchain rule that defines the Tcl interpreter, libraries, and executable wrapper used
to build `tcl_binary`, `tcl_library`, and `tcl_test` targets.

## Registering a toolchain

`rules_tcl` does not register a toolchain for you. Add the following to your `MODULE.bazel`
to use the default (a stock `tclsh` and tcllib, with the built-in shell/batch wrapper):

```python
register_toolchains("@rules_tcl//tcl/toolchain")
```

If you need a custom toolchain (e.g. a different Tcl version, or a wrapper that dispatches
into a different host interpreter), define your own. `tclcore` and `tcllib` are matched by
provider â pass a target that returns `TclCoreInfo` / `TclLibInfo`, typically produced by
the sibling `tclcore_filegroup` and `tcllib_filegroup` rules:

```python
load("@rules_tcl//tcl:tcl_toolchain.bzl", "tcl_toolchain", "tclcore_filegroup")

tclcore_filegroup(
    name = "my_tclcore",
    srcs = ["@my_tcl//:tclcore_files"],
)

tcl_toolchain(
    name = "my_tcl_toolchain",
    tclsh = "@my_tcl//:tclsh",
    tclcore = ":my_tclcore",     # optional; must provide TclCoreInfo
    tcllib = "@tcllib",          # optional; must provide TclLibInfo
    wrapper_template = "//path/to:my_wrapper_bundle",
    wrapper_entrypoint = "//path/to:my_entrypoint.tcl",  # optional
)
```

`tclcore` and `tcllib` may be omitted when the interpreter ships them itself.
`wrapper_entrypoint` is optional when the wrapper does not need a bootstrap script.

The template's own `DefaultInfo.default_runfiles` are merged into every produced binary,
so a template that needs a helper library (e.g. `@rules_shell//shell/runfiles` for sh,
`@rules_batch//batch/runfiles` for batch) should be declared via a `filegroup` that lists
the helper under `data`:

```python
filegroup(
    name = "my_wrapper_bundle",
    srcs = ["my_wrapper.sh.tpl"],
    data = ["@rules_shell//shell/runfiles"],
)
```

The same is true for `wrapper_entrypoint` â a `filegroup` around the entrypoint can carry
extra runtime data it needs at execution.

The extension appended to the produced wrapper is derived from the template's filename by
splitting the basename on the first `.` and dropping any trailing parts that are known
template suffixes (`.tpl`, `.template`, `.tmpl`, `.in`); whatever remains is the extension.
E.g. `my_wrapper.sh.tpl` yields `.sh`, `my_wrapper.bat.template` yields `.bat`,
`my_wrapper.vhook.tcl.tpl` yields `.vhook.tcl`. Since the split happens at the FIRST dot,
templates whose basename contains a dot in the name portion (e.g. `com.foo.wrapper.sh.tpl`
intending `.sh`) should be renamed so the first `.` marks the extension boundary.

## `ToolchainInfo` contract

The rule returns a `platform_common.ToolchainInfo` with the following fields. Non-underscore
fields are the public contract that consumers (including third-party rules that operate
over Tcl targets) may read. Underscore-prefixed fields are internal to the built-in
`tcl_binary` / `tcl_test` implementation â third-party rules that want a materially
different wrapper should carry their own template rather than reach into them.

| Field                | Type                                   | Access   | Notes                                                              |
|----------------------|----------------------------------------|----------|--------------------------------------------------------------------|
| `tclsh`              | `File`                                 | public   | Executable of the interpreter that will run the produced binaries. |
| `includes`           | `depset[str]`                          | public   | Runfiles-relative include paths implicitly on `auto_path`.         |
| `init_tcl`           | `File \| None`                        | public   | `init.tcl` from tclcore, or `None`.                                |
| `tcllib_pkg_index`   | `File \| None`                        | public   | tcllib's top-level `pkgIndex.tcl`, or `None`.                      |
| `all_files`          | `depset[File]`                         | public   | Runtime files merged into every produced target.                   |
| `make_variable_info` | `platform_common.TemplateVariableInfo` | public   | Exposes `$(TCLSH)` for `env` on downstream rules.                  |
| `_wrapper_*`         | (various)                              | internal | Wrapper template, entrypoint, and derived extension.               |

## Wrapper template contract

The built-in `tcl_binary` / `tcl_test` expand `wrapper_template` once per target into a
file named `<target><wrapper_extension>` and set it as the target's executable. The
template supports these substitutions; values whose backing toolchain field is unset
expand to the empty string, so a template can simply omit lines it does not need:

| Substitution         | Value                                                                                 | Empty when                   |
|----------------------|---------------------------------------------------------------------------------------|------------------------------|
| `{interpreter}`      | Runfiles path (rlocation) of `tclsh`.                                                 | never                        |
| `{entrypoint}`       | Runfiles path of `wrapper_entrypoint`.                                                | `wrapper_entrypoint` unset   |
| `{config}`           | Runfiles path of a per-target JSON config (see below).                                | never                        |
| `{main}`             | Runfiles path of the target's entry `.tcl` (resolved from `main` / `srcs`).           | never                        |
| `{init_tcl}`         | Runfiles path of tclcore's `init.tcl`.                                                | `tclcore` unset              |
| `{tcllib_pkg_index}` | Runfiles path of tcllib's top-level `pkgIndex.tcl`.                                   | `tcllib` unset               |
| `{auto_path}`        | Tcl-list literal (brace-quoted) of every include path visible to the target â the target's own workspace, each dep's `TclInfo.includes`, and the toolchain's `includes`. Suitable to `lappend` onto `auto_path`. | never |

The `{config}` file is JSON with this shape:

```json
{
  "includes": ["workspace_name", "workspace_name/path/to/lib", "..."],
  "runfiles": ["workspace_name/path/to/file", "..."]
}
```

`includes` is the same set of runfiles-relative paths surfaced through `{auto_path}`;
`runfiles` is every file merged into the target's runfiles. The default `entrypoint.tcl`
consumes this to set `TCLLIBPATH` and to materialize a `RUNFILES_DIR` when only a manifest
is available; alternate wrappers can consume, ignore, or extend it as they see fit.
"�D
�<
tcl_toolchain�4A toolchain rule that defines the Tcl interpreter, libraries, and executable wrapper used
to build `tcl_binary`, `tcl_library`, and `tcl_test` targets.

## Registering a toolchain

`rules_tcl` does not register a toolchain for you. Add the following to your `MODULE.bazel`
to use the default (a stock `tclsh` and tcllib, with the built-in shell/batch wrapper):

```python
register_toolchains("@rules_tcl//tcl/toolchain")
```

If you need a custom toolchain (e.g. a different Tcl version, or a wrapper that dispatches
into a different host interpreter), define your own. `tclcore` and `tcllib` are matched by
provider â pass a target that returns `TclCoreInfo` / `TclLibInfo`, typically produced by
the sibling `tclcore_filegroup` and `tcllib_filegroup` rules:

```python
load("@rules_tcl//tcl:tcl_toolchain.bzl", "tcl_toolchain", "tclcore_filegroup")

tclcore_filegroup(
    name = "my_tclcore",
    srcs = ["@my_tcl//:tclcore_files"],
)

tcl_toolchain(
    name = "my_tcl_toolchain",
    tclsh = "@my_tcl//:tclsh",
    tclcore = ":my_tclcore",     # optional; must provide TclCoreInfo
    tcllib = "@tcllib",          # optional; must provide TclLibInfo
    wrapper_template = "//path/to:my_wrapper_bundle",
    wrapper_entrypoint = "//path/to:my_entrypoint.tcl",  # optional
)
```

`tclcore` and `tcllib` may be omitted when the interpreter ships them itself.
`wrapper_entrypoint` is optional when the wrapper does not need a bootstrap script.

The template's own `DefaultInfo.default_runfiles` are merged into every produced binary,
so a template that needs a helper library (e.g. `@rules_shell//shell/runfiles` for sh,
`@rules_batch//batch/runfiles` for batch) should be declared via a `filegroup` that lists
the helper under `data`:

```python
filegroup(
    name = "my_wrapper_bundle",
    srcs = ["my_wrapper.sh.tpl"],
    data = ["@rules_shell//shell/runfiles"],
)
```

The same is true for `wrapper_entrypoint` â a `filegroup` around the entrypoint can carry
extra runtime data it needs at execution.

The extension appended to the produced wrapper is derived from the template's filename by
splitting the basename on the first `.` and dropping any trailing parts that are known
template suffixes (`.tpl`, `.template`, `.tmpl`, `.in`); whatever remains is the extension.
E.g. `my_wrapper.sh.tpl` yields `.sh`, `my_wrapper.bat.template` yields `.bat`,
`my_wrapper.vhook.tcl.tpl` yields `.vhook.tcl`. Since the split happens at the FIRST dot,
templates whose basename contains a dot in the name portion (e.g. `com.foo.wrapper.sh.tpl`
intending `.sh`) should be renamed so the first `.` marks the extension boundary.

## `ToolchainInfo` contract

The rule returns a `platform_common.ToolchainInfo` with the following fields. Non-underscore
fields are the public contract that consumers (including third-party rules that operate
over Tcl targets) may read. Underscore-prefixed fields are internal to the built-in
`tcl_binary` / `tcl_test` implementation â third-party rules that want a materially
different wrapper should carry their own template rather than reach into them.

| Field                | Type                                   | Access   | Notes                                                              |
|----------------------|----------------------------------------|----------|--------------------------------------------------------------------|
| `tclsh`              | `File`                                 | public   | Executable of the interpreter that will run the produced binaries. |
| `includes`           | `depset[str]`                          | public   | Runfiles-relative include paths implicitly on `auto_path`.         |
| `init_tcl`           | `File \| None`                        | public   | `init.tcl` from tclcore, or `None`.                                |
| `tcllib_pkg_index`   | `File \| None`                        | public   | tcllib's top-level `pkgIndex.tcl`, or `None`.                      |
| `all_files`          | `depset[File]`                         | public   | Runtime files merged into every produced target.                   |
| `make_variable_info` | `platform_common.TemplateVariableInfo` | public   | Exposes `$(TCLSH)` for `env` on downstream rules.                  |
| `_wrapper_*`         | (various)                              | internal | Wrapper template, entrypoint, and derived extension.               |

## Wrapper template contract

The built-in `tcl_binary` / `tcl_test` expand `wrapper_template` once per target into a
file named `<target><wrapper_extension>` and set it as the target's executable. The
template supports these substitutions; values whose backing toolchain field is unset
expand to the empty string, so a template can simply omit lines it does not need:

| Substitution         | Value                                                                                 | Empty when                   |
|----------------------|---------------------------------------------------------------------------------------|------------------------------|
| `{interpreter}`      | Runfiles path (rlocation) of `tclsh`.                                                 | never                        |
| `{entrypoint}`       | Runfiles path of `wrapper_entrypoint`.                                                | `wrapper_entrypoint` unset   |
| `{config}`           | Runfiles path of a per-target JSON config (see below).                                | never                        |
| `{main}`             | Runfiles path of the target's entry `.tcl` (resolved from `main` / `srcs`).           | never                        |
| `{init_tcl}`         | Runfiles path of tclcore's `init.tcl`.                                                | `tclcore` unset              |
| `{tcllib_pkg_index}` | Runfiles path of tcllib's top-level `pkgIndex.tcl`.                                   | `tcllib` unset               |
| `{auto_path}`        | Tcl-list literal (brace-quoted) of every include path visible to the target â the target's own workspace, each dep's `TclInfo.includes`, and the toolchain's `includes`. Suitable to `lappend` onto `auto_path`. | never |

The `{config}` file is JSON with this shape:

```json
{
  "includes": ["workspace_name", "workspace_name/path/to/lib", "..."],
  "runfiles": ["workspace_name/path/to/file", "..."]
}
```

`includes` is the same set of runfiles-relative paths surfaced through `{auto_path}`;
`runfiles` is every file merged into the target's runfiles. The default `entrypoint.tcl`
consumes this to set `TCLLIBPATH` and to materialize a `RUNFILES_DIR` when only a manifest
is available; alternate wrappers can consume, ignore, or extend it as they see fit.
*
nameA unique name for this target. e
tclcoreCA target providing `TclCoreInfo` (typically a `tclcore_filegroup`).*
TclCoreInfo2Nonea
tcllibAA target providing `TclLibInfo` (typically a `tcllib_filegroup`).*

TclLibInfo2Nonej
tclsh]The path to a `tclsh` binary. Runtime dependency of every produced `tcl_binary` / `tcl_test`. �
wrapper_entrypoint�Optional `.tcl` file added to the binary's runfiles and referenced via the `{entrypoint}` template substitution. The target's `default_runfiles` are also merged in. Leave unset when the wrapper doesn't need a bootstrap.2None�
wrapper_template�Template expanded per `tcl_binary` / `tcl_test`. The target's `default_runfiles` are merged into every produced binary, so a `filegroup` wrapping the template can list helper libraries under `data` (e.g. `@bazel_tools//tools/bash/runfiles`). See the wrapper template contract in the rule docs for the supported substitutions. "3
tcl_toolchain"@@rules_tcl//tcl:tcl_toolchain.bzl
\\,
*
nameA unique name for this target. g
e
tclcoreCA target providing `TclCoreInfo` (typically a `tclcore_filegroup`).*
TclCoreInfo2Nonec
a
tcllibAA target providing `TclLibInfo` (typically a `tcllib_filegroup`).*

TclLibInfo2Nonel
j
tclsh]The path to a `tclsh` binary. Runtime dependency of every produced `tcl_binary` / `tcl_test`. �
�
wrapper_entrypoint�Optional `.tcl` file added to the binary's runfiles and referenced via the `{entrypoint}` template substitution. The target's `default_runfiles` are also merged in. Leave unset when the wrapper doesn't need a bootstrap.2None�
�
wrapper_template�Template expanded per `tcl_binary` / `tcl_test`. The target's `default_runfiles` are merged into every produced binary, so a `filegroup` wrapping the template can list helper libraries under `data` (e.g. `@bazel_tools//tools/bash/runfiles`). See the wrapper template contract in the rule docs for the supported substitutions. �tclcore_filegroupqWraps a tclcore source tree and surfaces `init.tcl` via `TclCoreInfo` for consumption by `tcl_toolchain.tclcore`."�
�
tclcore_filegroupqWraps a tclcore source tree and surfaces `init.tcl` via `TclCoreInfo` for consumption by `tcl_toolchain.tclcore`.*
nameA unique name for this target. L
srcs@Files that make up the tclcore tree. Must contain an `init.tcl`. "7
tclcore_filegroup"@@rules_tcl//tcl:tcl_toolchain.bzl
,
*
nameA unique name for this target. N
L
srcs@Files that make up the tclcore tree. Must contain an `init.tcl`. �tcllib_filegroupiStages a tcllib source tree under a prefix and generates a pkgIndex.tcl that auto-discovers sub-packages."�
�
tcllib_filegroupiStages a tcllib source tree under a prefix and generates a pkgIndex.tcl that auto-discovers sub-packages.*
nameA unique name for this target. >
prefix0Directory prefix to stage the tcllib tree under. 2
srcs&Files from the tcllib `modules/` tree. F
version7The tcllib version, used in the generated pkgIndex.tcl. "6
tcllib_filegroup"@@rules_tcl//tcl:tcl_toolchain.bzl
99,
*
nameA unique name for this target. @
>
prefix0Directory prefix to stage the tcllib tree under. 4
2
srcs&Files from the tcllib `modules/` tree. H
F
version7The tcllib version, used in the generated pkgIndex.tcl. �TclCoreInfo@Info about a tclcore target consumed by `tcl_toolchain.tclcore`.2�
�
TclCoreInfo@Info about a tclcore target consumed by `tcl_toolchain.tclcore`.X
includeMstr: Runfiles-relative directory containing `init.tcl`, added to `auto_path`.3
init_tcl'File: `init.tcl` from the tclcore tree."1
TclCoreInfo"@@rules_tcl//tcl:tcl_toolchain.bzl
Z
X
includeMstr: Runfiles-relative directory containing `init.tcl`, added to `auto_path`.5
3
init_tcl'File: `init.tcl` from the tclcore tree.�
TclLibInfo>Info about a tcllib target consumed by `tcl_toolchain.tcllib`.2�
�

TclLibInfo>Info about a tcllib target consumed by `tcl_toolchain.tcllib`.j
include_str: Runfiles-relative directory containing the top-level `pkgIndex.tcl`, added to `auto_path`.@
	pkg_index3File: Top-level `pkgIndex.tcl` for the tcllib tree."0

TclLibInfo"@@rules_tcl//tcl:tcl_toolchain.bzl
l
j
include_str: Runfiles-relative directory containing the top-level `pkgIndex.tcl`, added to `auto_path`.B
@
	pkg_index3File: Top-level `pkgIndex.tcl` for the tcllib tree.�
//tcl/private:providers.bzlr�
'
	rules_tcltcl/privateproviders.bzl)
TclCoreInfo_TclcoreInfo
'

TclLibInfo_TcllibInfo

�
#//tcl/private:tclcore_filegroup.bzlrv
/
	rules_tcltcl/privatetclcore_filegroup.bzl5
tclcore_filegroup_tclcore_filegroup



�
"//tcl/private:tcllib_filegroup.bzlrs
.
	rules_tcltcl/privatetcllib_filegroup.bzl3
tcllib_filegroup_tcllib_filegroup

�
//tcl/private:toolchain.bzlr�
'
	rules_tcltcl/privatetoolchain.bzl/
TOOLCHAIN_TYPE_TOOLCHAIN_TYPE
-
tcl_toolchain_tcl_toolchain

D	TOOLCHAIN_TYPE@@//tcl:toolchain_typej@@//tcl:toolchain_typetcl_toolchainM

	rules_tclversion.bzl	VERSION0.10.0j0.10.0"rules_tcl version 