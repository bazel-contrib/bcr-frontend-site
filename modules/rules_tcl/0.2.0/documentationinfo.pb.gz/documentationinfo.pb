�
/
	rules_tcltcl/nagelfar/privatenagelfar.bzl*�ModuleInfo request error: invalid argument: Traceback (most recent call last):
	File "external/rules_tcl/tcl/nagelfar/private/nagelfar.bzl", line 4, column 59, in <toplevel>
		load("@rules_tcl//tcl/private:providers.bzl", "TclInfo", "find_srcs")
Error: file '@rules_tcl//tcl/private:providers.bzl' does not contain symbol 'find_srcs'�
#
	rules_tcltcl/nagelfardefs.bzl�nagelfar_toolchain�A toolchain rule for configuring the [Nagelfar](https://nagelfar.sourceforge.net/) Tcl syntax checker.

The `nagelfar_toolchain` rule specifies the Nagelfar script and syntax database files
used by `tcl_nagelfar_aspect` and `tcl_nagelfar_test` for static analysis of Tcl code.

Typically, you don't need to define this directly. Instead, use the bzlmod extension:

```python
nagelfar = use_extension("@rules_tcl//tcl/nagelfar:extensions.bzl", "nagelfar")
nagelfar.toolchain()
use_repo(nagelfar, "nagelfar_toolchains")
register_toolchains("@nagelfar_toolchains//:all")
```
"�
�
nagelfar_toolchain�A toolchain rule for configuring the [Nagelfar](https://nagelfar.sourceforge.net/) Tcl syntax checker.

The `nagelfar_toolchain` rule specifies the Nagelfar script and syntax database files
used by `tcl_nagelfar_aspect` and `tcl_nagelfar_test` for static analysis of Tcl code.

Typically, you don't need to define this directly. Instead, use the bzlmod extension:

```python
nagelfar = use_extension("@rules_tcl//tcl/nagelfar:extensions.bzl", "nagelfar")
nagelfar.toolchain()
use_repo(nagelfar, "nagelfar_toolchains")
register_toolchains("@nagelfar_toolchains//:all")
```
*
nameA unique name for this target. *
nagelfarThe `nagelfar.tcl` script. 3
syntaxdbNagelfar syntax database files.2None"8
nagelfar_toolchain"@@rules_tcl//tcl/nagelfar:defs.bzl
,
*
nameA unique name for this target. ,
*
nagelfarThe `nagelfar.tcl` script. 5
3
syntaxdbNagelfar syntax database files.2None�tcl_nagelfar_aspect�An aspect for performing Nagelfar static analysis on Tcl targets.

The `tcl_nagelfar_aspect` applies [Nagelfar](https://nagelfar.sourceforge.net/)
checks to all Tcl targets in the dependency graph.

**Usage:**

```bash
bazel build //my:target \
    --aspects=@rules_tcl//tcl/nagelfar:tcl_nagelfar_aspect.bzl%tcl_nagelfar_aspect \
    --output_groups=+tcl_nagelfar_checks
```

Or configure it in your `.bazelrc`:

```bazelrc
build:nagelfar --aspects=@rules_tcl//tcl/nagelfar:tcl_nagelfar_aspect.bzl%tcl_nagelfar_aspect
build:nagelfar --output_groups=+tcl_nagelfar_checks
```

**Ignoring targets:**

To skip Nagelfar for specific targets, add one of these tags:
- `no_tcl_nagelfar`
- `no_nagelfar`
- `no_lint`
- `nolint`
:�
�
tcl_nagelfar_aspect�An aspect for performing Nagelfar static analysis on Tcl targets.

The `tcl_nagelfar_aspect` applies [Nagelfar](https://nagelfar.sourceforge.net/)
checks to all Tcl targets in the dependency graph.

**Usage:**

```bash
bazel build //my:target \
    --aspects=@rules_tcl//tcl/nagelfar:tcl_nagelfar_aspect.bzl%tcl_nagelfar_aspect \
    --output_groups=+tcl_nagelfar_checks
```

Or configure it in your `.bazelrc`:

```bazelrc
build:nagelfar --aspects=@rules_tcl//tcl/nagelfar:tcl_nagelfar_aspect.bzl%tcl_nagelfar_aspect
build:nagelfar --output_groups=+tcl_nagelfar_checks
```

**Ignoring targets:**

To skip Nagelfar for specific targets, add one of these tags:
- `no_tcl_nagelfar`
- `no_nagelfar`
- `no_lint`
- `nolint`
"*
nameA unique name for this target. *9
tcl_nagelfar_aspect"@@rules_tcl//tcl/nagelfar:defs.bzl
SS,
*
nameA unique name for this target. �
%//tcl/nagelfar:nagelfar_toolchain.bzlrz
1
	rules_tcltcl/nagelfarnagelfar_toolchain.bzl7
nagelfar_toolchain_nagelfar_toolchain
9L
d�
&//tcl/nagelfar:tcl_nagelfar_aspect.bzlr}
2
	rules_tcltcl/nagelfartcl_nagelfar_aspect.bzl9
tcl_nagelfar_aspect_tcl_nagelfar_aspect
:N
g�
$//tcl/nagelfar:tcl_nagelfar_test.bzlrw
0
	rules_tcltcl/nagelfartcl_nagelfar_test.bzl5
tcl_nagelfar_test_tcl_nagelfar_test
8J
aNagelfar Bazel rules�
)
	rules_tcltcl/nagelfarextensions.bzl�nagelfarJ�
q
nagelfar/
	toolchain"Configures the Nagelfar toolchain."4
nagelfar(@@rules_tcl//tcl/nagelfar:extensions.bzl
??1
/
	toolchain"Configures the Nagelfar toolchain.(Bzlmod extension for Nagelfar toolchain.�
1
	rules_tcltcl/nagelfarnagelfar_toolchain.bzl�current_nagelfar_toolchain6A rule for accessing the current `nagelfar_toolchain`."�
�
current_nagelfar_toolchain6A rule for accessing the current `nagelfar_toolchain`.*
nameA unique name for this target. "N
current_nagelfar_toolchain0@@rules_tcl//tcl/nagelfar:nagelfar_toolchain.bzl
;";",
*
nameA unique name for this target. �nagelfar_toolchain�A toolchain rule for configuring the [Nagelfar](https://nagelfar.sourceforge.net/) Tcl syntax checker.

The `nagelfar_toolchain` rule specifies the Nagelfar script and syntax database files
used by `tcl_nagelfar_aspect` and `tcl_nagelfar_test` for static analysis of Tcl code.

Typically, you don't need to define this directly. Instead, use the bzlmod extension:

```python
nagelfar = use_extension("@rules_tcl//tcl/nagelfar:extensions.bzl", "nagelfar")
nagelfar.toolchain()
use_repo(nagelfar, "nagelfar_toolchains")
register_toolchains("@nagelfar_toolchains//:all")
```
"�
�
nagelfar_toolchain�A toolchain rule for configuring the [Nagelfar](https://nagelfar.sourceforge.net/) Tcl syntax checker.

The `nagelfar_toolchain` rule specifies the Nagelfar script and syntax database files
used by `tcl_nagelfar_aspect` and `tcl_nagelfar_test` for static analysis of Tcl code.

Typically, you don't need to define this directly. Instead, use the bzlmod extension:

```python
nagelfar = use_extension("@rules_tcl//tcl/nagelfar:extensions.bzl", "nagelfar")
nagelfar.toolchain()
use_repo(nagelfar, "nagelfar_toolchains")
register_toolchains("@nagelfar_toolchains//:all")
```
*
nameA unique name for this target. *
nagelfarThe `nagelfar.tcl` script. 3
syntaxdbNagelfar syntax database files.2None"F
nagelfar_toolchain0@@rules_tcl//tcl/nagelfar:nagelfar_toolchain.bzl
,
*
nameA unique name for this target. ,
*
nagelfarThe `nagelfar.tcl` script. 5
3
syntaxdbNagelfar syntax database files.2None_	NAGELFAR_TOOLCHAIN_TYPE@@//tcl/nagelfar:toolchain_typej!@@//tcl/nagelfar:toolchain_typeNagelfar toolchain rules�
2
	rules_tcltcl/nagelfartcl_nagelfar_aspect.bzl�tcl_nagelfar_aspect�An aspect for performing Nagelfar static analysis on Tcl targets.

The `tcl_nagelfar_aspect` applies [Nagelfar](https://nagelfar.sourceforge.net/)
checks to all Tcl targets in the dependency graph.

**Usage:**

```bash
bazel build //my:target \
    --aspects=@rules_tcl//tcl/nagelfar:tcl_nagelfar_aspect.bzl%tcl_nagelfar_aspect \
    --output_groups=+tcl_nagelfar_checks
```

Or configure it in your `.bazelrc`:

```bazelrc
build:nagelfar --aspects=@rules_tcl//tcl/nagelfar:tcl_nagelfar_aspect.bzl%tcl_nagelfar_aspect
build:nagelfar --output_groups=+tcl_nagelfar_checks
```

**Ignoring targets:**

To skip Nagelfar for specific targets, add one of these tags:
- `no_tcl_nagelfar`
- `no_nagelfar`
- `no_lint`
- `nolint`
:�
�
tcl_nagelfar_aspect�An aspect for performing Nagelfar static analysis on Tcl targets.

The `tcl_nagelfar_aspect` applies [Nagelfar](https://nagelfar.sourceforge.net/)
checks to all Tcl targets in the dependency graph.

**Usage:**

```bash
bazel build //my:target \
    --aspects=@rules_tcl//tcl/nagelfar:tcl_nagelfar_aspect.bzl%tcl_nagelfar_aspect \
    --output_groups=+tcl_nagelfar_checks
```

Or configure it in your `.bazelrc`:

```bazelrc
build:nagelfar --aspects=@rules_tcl//tcl/nagelfar:tcl_nagelfar_aspect.bzl%tcl_nagelfar_aspect
build:nagelfar --output_groups=+tcl_nagelfar_checks
```

**Ignoring targets:**

To skip Nagelfar for specific targets, add one of these tags:
- `no_tcl_nagelfar`
- `no_nagelfar`
- `no_lint`
- `nolint`
"*
nameA unique name for this target. *H
tcl_nagelfar_aspect1@@rules_tcl//tcl/nagelfar:tcl_nagelfar_aspect.bzl
SS,
*
nameA unique name for this target. �
#//tcl/nagelfar/private:nagelfar.bzlrz
/
	rules_tcltcl/nagelfar/privatenagelfar.bzl9
tcl_nagelfar_aspect_tcl_nagelfar_aspect

tcl_nagelfar_aspect�
'
	rules_tcltcl/privateproviders.bzl�TclInfoInfo about a Tcl target.2�
�
TclInfoInfo about a Tcl target.T
includesHDepset[str]: A list of include paths associated with the current target.@
srcs8Depset[File]: Direct source files of the current target.D
transitive_includes-Depset[str]: Include paths from dependencies.T
transitive_srcsADepset[File]: Source files required at runtime from dependencies."1
TclInfo&@@rules_tcl//tcl/private:providers.bzl
V
T
includesHDepset[str]: A list of include paths associated with the current target.B
@
srcs8Depset[File]: Direct source files of the current target.F
D
transitive_includes-Depset[str]: Include paths from dependencies.V
T
transitive_srcsADepset[File]: Source files required at runtime from dependencies.TCL Providers�J
!
	rules_tcltcl/privatetcl.bzl�
tcl_binary�A `tcl_binary` is an executable Tcl program consisting of a collection of
`.tcl` source files (possibly belonging to other `tcl_library` rules), a `*.runfiles`
directory tree containing all the code and data needed by the program at run-time,
and a stub script that starts up the program with the correct initial environment
and data.

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_binary")

tcl_binary(
    name = "foo",
    srcs = ["foo.tcl"],
    deps = [
        ":bar",  # a tcl_library
    ],
)
```
"�
�	

tcl_binary�A `tcl_binary` is an executable Tcl program consisting of a collection of
`.tcl` source files (possibly belonging to other `tcl_library` rules), a `*.runfiles`
directory tree containing all the code and data needed by the program at run-time,
and a stub script that starts up the program with the correct initial environment
and data.

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_binary")

tcl_binary(
    name = "foo",
    srcs = ["foo.tcl"],
    deps = [
        ":bar",  # a tcl_library
    ],
)
```
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2NoneV
srcsJThe list of source (`.tcl`) files that are processed to create the target. ".

tcl_binary @@rules_tcl//tcl/private:tcl.bzl
��,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]L
J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]k
i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}�
�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2NoneX
V
srcsJThe list of source (`.tcl`) files that are processed to create the target. �tcl_library�A Tcl library that can be depended upon by other Tcl targets.

A `tcl_library` represents a Tcl package that can be imported using Tcl's `package require` command.
The library must include a `pkgIndex.tcl` file in its `srcs` attribute, which defines the package
metadata and how to load the package.

**Important**: The `pkgIndex.tcl` file must be included in the `srcs` attribute. This file is used
by Tcl's package system to locate and load the package.

Example:

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_library")

tcl_library(
    name = "mylib",
    srcs = [
        "mylib.tcl",
        "pkgIndex.tcl",
    ],
    deps = [
        ":otherlib",  # Another tcl_library
    ],
    visibility = ["//visibility:public"],
)
```

The library can then be used as a dependency in other targets:

```python
tcl_binary(
    name = "app",
    srcs = ["app.tcl"],
    deps = [":mylib"],
)
```
"�
�

tcl_library�A Tcl library that can be depended upon by other Tcl targets.

A `tcl_library` represents a Tcl package that can be imported using Tcl's `package require` command.
The library must include a `pkgIndex.tcl` file in its `srcs` attribute, which defines the package
metadata and how to load the package.

**Important**: The `pkgIndex.tcl` file must be included in the `srcs` attribute. This file is used
by Tcl's package system to locate and load the package.

Example:

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_library")

tcl_library(
    name = "mylib",
    srcs = [
        "mylib.tcl",
        "pkgIndex.tcl",
    ],
    deps = [
        ":otherlib",  # Another tcl_library
    ],
    visibility = ["//visibility:public"],
)
```

The library can then be used as a dependency in other targets:

```python
tcl_binary(
    name = "app",
    srcs = ["app.tcl"],
    deps = [":mylib"],
)
```
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]V
srcsJThe list of source (`.tcl`) files that are processed to create the target. "/
tcl_library @@rules_tcl//tcl/private:tcl.bzl
��,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]L
J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]X
V
srcsJThe list of source (`.tcl`) files that are processed to create the target. � tcl_test�A test rule for Tcl code that can be executed with `bazel test`.

A `tcl_test` is similar to a `tcl_binary` but is designed for testing. It supports all the same
attributes as `tcl_binary`, plus additional test-specific features like environment variable
inheritance.

Tests are executed by Bazel's test runner and can be run with:

```bash
bazel test //path/to:my_test
```

Example:

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_test")

tcl_test(
    name = "my_test",
    srcs = ["test.tcl"],
    deps = [
        ":mylib",  # The library being tested
    ],
    env = {
        "TEST_MODE": "1",
    },
    env_inherit = ["PATH"],  # Inherit PATH from the environment
)
```

The test can use Tcl's standard testing frameworks or custom test code. Test failures are
detected by non-zero exit codes.
"�
�
tcl_test�A test rule for Tcl code that can be executed with `bazel test`.

A `tcl_test` is similar to a `tcl_binary` but is designed for testing. It supports all the same
attributes as `tcl_binary`, plus additional test-specific features like environment variable
inheritance.

Tests are executed by Bazel's test runner and can be run with:

```bash
bazel test //path/to:my_test
```

Example:

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_test")

tcl_test(
    name = "my_test",
    srcs = ["test.tcl"],
    deps = [
        ":mylib",  # The library being tested
    ],
    env = {
        "TEST_MODE": "1",
    },
    env_inherit = ["PATH"],  # Inherit PATH from the environment
)
```

The test can use Tcl's standard testing frameworks or custom test code. Test failures are
detected by non-zero exit codes.
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}�
env_inherit�Specifies additional environment variables to inherit from the external environment.

This attribute is only available for `tcl_test` rules. When the test is executed by
`bazel test`, these environment variables from the host environment will be passed
through to the test.

Example:
```python
tcl_test(
    name = "my_test",
    srcs = ["test.tcl"],
    env_inherit = [
        "PATH",
        "HOME",
        "USER",
    ],
)
```

This is useful when tests need access to system tools or user-specific configuration.
2[]�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2NoneV
srcsJThe list of source (`.tcl`) files that are processed to create the target. ",
tcl_test @@rules_tcl//tcl/private:tcl.bzl
��,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]L
J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]k
i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}�
�
env_inherit�Specifies additional environment variables to inherit from the external environment.

This attribute is only available for `tcl_test` rules. When the test is executed by
`bazel test`, these environment variables from the host environment will be passed
through to the test.

Example:
```python
tcl_test(
    name = "my_test",
    srcs = ["test.tcl"],
    env_inherit = [
        "PATH",
        "HOME",
        "USER",
    ],
)
```

This is useful when tests need access to system tools or user-specific configuration.
2[]�
�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2NoneX
V
srcsJThe list of source (`.tcl`) files that are processed to create the target. z
//tcl/private:providers.bzlrY
'
	rules_tcltcl/privateproviders.bzl 
TclInfoTclInfo
07
9�
//tcl/private:toolchain.bzlrg
'
	rules_tcltcl/privatetoolchain.bzl.
TOOLCHAIN_TYPETOOLCHAIN_TYPE
0>
@	Tcl rules�
'
	rules_tcltcl/privatetoolchain.bzl�tcl_toolchain�A toolchain rule that defines the Tcl interpreter and libraries for building Tcl targets.

The `tcl_toolchain` rule configures the Tcl environment used by all `tcl_binary`, `tcl_library`,
and `tcl_test` targets. It specifies:
- The Tcl interpreter (`tclsh`) to use for execution
- The Tcl core library files (`tclcore`)
- The Tcl standard library (`tcllib`)
- Optional linting tools (`tclint`) for code quality checks

Typically, you don't need to create a `tcl_toolchain` directly. The rules provide a default
toolchain that you register in your `MODULE.bazel`:

```python
register_toolchains("@rules_tcl//tcl/toolchain")
```

If you need a custom toolchain (e.g., a different Tcl version), you can define your own:

```python
load("@rules_tcl//tcl:tcl_toolchain.bzl", "tcl_toolchain")

tcl_toolchain(
    name = "my_tcl_toolchain",
    tclsh = "@tcl_8_6//:tclsh",
    tclcore = "@tcl_8_6//:tclcore",
    tcllib = "@tcllib//:tcllib",
    tclint = "@tclint//:tclint",  # Optional, for linting
)
```
"�
�
tcl_toolchain�A toolchain rule that defines the Tcl interpreter and libraries for building Tcl targets.

The `tcl_toolchain` rule configures the Tcl environment used by all `tcl_binary`, `tcl_library`,
and `tcl_test` targets. It specifies:
- The Tcl interpreter (`tclsh`) to use for execution
- The Tcl core library files (`tclcore`)
- The Tcl standard library (`tcllib`)
- Optional linting tools (`tclint`) for code quality checks

Typically, you don't need to create a `tcl_toolchain` directly. The rules provide a default
toolchain that you register in your `MODULE.bazel`:

```python
register_toolchains("@rules_tcl//tcl/toolchain")
```

If you need a custom toolchain (e.g., a different Tcl version), you can define your own:

```python
load("@rules_tcl//tcl:tcl_toolchain.bzl", "tcl_toolchain")

tcl_toolchain(
    name = "my_tcl_toolchain",
    tclsh = "@tcl_8_6//:tclsh",
    tclcore = "@tcl_8_6//:tclcore",
    tcllib = "@tcllib//:tcllib",
    tclint = "@tclint//:tclint",  # Optional, for linting
)
```
*
nameA unique name for this target. .
tclcoreA label to the `tclcore` files. �
tclint�The [`tclint`](https://github.com/nmoroze/tclint) python library. This attribute is required for [`tcl_lint_aspect`](#tcl_lint_aspect)/[`tcl_format_aspect`](#tcl_format_aspect) but otherwise optional for core rules.2None,
tcllibA label to the `tcllib` files. *
tclshThe path to a `tclsh` binary. "7
tcl_toolchain&@@rules_tcl//tcl/private:toolchain.bzl
II,
*
nameA unique name for this target. 0
.
tclcoreA label to the `tclcore` files. �
�
tclint�The [`tclint`](https://github.com/nmoroze/tclint) python library. This attribute is required for [`tcl_lint_aspect`](#tcl_lint_aspect)/[`tcl_format_aspect`](#tcl_format_aspect) but otherwise optional for core rules.2None.
,
tcllibA label to the `tcllib` files. ,
*
tclshThe path to a `tclsh` binary. D	TOOLCHAIN_TYPE@@//tcl:toolchain_typej@@//tcl:toolchain_typetcl toolchain rules�
+
	rules_tcltcl/tclint/private
tclint.bzl*�ModuleInfo request error: invalid argument: Traceback (most recent call last):
	File "external/rules_tcl/tcl/tclint/private/tclint.bzl", line 3, column 59, in <toplevel>
		load("@rules_tcl//tcl/private:providers.bzl", "TclInfo", "find_srcs")
Error: file '@rules_tcl//tcl/private:providers.bzl' does not contain symbol 'find_srcs'�#
!
	rules_tcl
tcl/tclintdefs.bzl�
tclint_toolchain�A toolchain rule for configuring [tclint](https://github.com/nmoroze/tclint).

The `tclint_toolchain` rule specifies the tclint Python library used by
`tcl_tclint_aspect`, `tcl_format_aspect`, and related test rules.

Typically, you don't need to define this directly. Instead, use the bzlmod extension:

```python
tclint = use_extension("@rules_tcl//tcl/tclint:extensions.bzl", "tclint")
tclint.toolchain()
use_repo(tclint, "tclint_toolchains")
register_toolchains("@tclint_toolchains//:all")
```
"�
�
tclint_toolchain�A toolchain rule for configuring [tclint](https://github.com/nmoroze/tclint).

The `tclint_toolchain` rule specifies the tclint Python library used by
`tcl_tclint_aspect`, `tcl_format_aspect`, and related test rules.

Typically, you don't need to define this directly. Instead, use the bzlmod extension:

```python
tclint = use_extension("@rules_tcl//tcl/tclint:extensions.bzl", "tclint")
tclint.toolchain()
use_repo(tclint, "tclint_toolchains")
register_toolchains("@tclint_toolchains//:all")
```
*
nameA unique name for this target. O
tclintAThe [`tclint`](https://github.com/nmoroze/tclint) python library. "4
tclint_toolchain @@rules_tcl//tcl/tclint:defs.bzl
,
*
nameA unique name for this target. Q
O
tclintAThe [`tclint`](https://github.com/nmoroze/tclint) python library. �tcl_tclint_aspect�An aspect for performing tclint linting checks on Tcl targets.

Uses [tclint](https://github.com/nmoroze/tclint) to check for code quality issues.

**Usage:**

```bash
bazel build //my:target \
    --aspects=@rules_tcl//tcl/tclint:tcl_tclint_aspect.bzl%tcl_tclint_aspect \
    --output_groups=+tcl_tclint_checks
```

**Ignoring targets:**

To skip tclint for specific targets, add one of these tags:
- `no_tcl_lint`
- `no_tclint`
- `no_lint`
- `nolint`
:�
�
tcl_tclint_aspect�An aspect for performing tclint linting checks on Tcl targets.

Uses [tclint](https://github.com/nmoroze/tclint) to check for code quality issues.

**Usage:**

```bash
bazel build //my:target \
    --aspects=@rules_tcl//tcl/tclint:tcl_tclint_aspect.bzl%tcl_tclint_aspect \
    --output_groups=+tcl_tclint_checks
```

**Ignoring targets:**

To skip tclint for specific targets, add one of these tags:
- `no_tcl_lint`
- `no_tclint`
- `no_lint`
- `nolint`
"*
nameA unique name for this target. *5
tcl_tclint_aspect @@rules_tcl//tcl/tclint:defs.bzl
44,
*
nameA unique name for this target. �	tcl_tclint_fmt_aspect�An aspect for performing formatting checks on Tcl targets.

Uses [tclint](https://github.com/nmoroze/tclint) to verify formatting.

**Usage:**

```bash
bazel build //my:target \
    --aspects=@rules_tcl//tcl/tclint:tcl_tclint_fmt_aspect.bzl%tcl_tclint_fmt_aspect \
    --output_groups=+tcl_tclint_fmt_checks
```

**Ignoring targets:**

To skip format checking for specific targets, add one of these tags:
- `no_tcl_format`
- `no_tclformat`
- `no_tclfmt`
- `noformat`
- `nofmt`
:�
�
tcl_tclint_fmt_aspect�An aspect for performing formatting checks on Tcl targets.

Uses [tclint](https://github.com/nmoroze/tclint) to verify formatting.

**Usage:**

```bash
bazel build //my:target \
    --aspects=@rules_tcl//tcl/tclint:tcl_tclint_fmt_aspect.bzl%tcl_tclint_fmt_aspect \
    --output_groups=+tcl_tclint_fmt_checks
```

**Ignoring targets:**

To skip format checking for specific targets, add one of these tags:
- `no_tcl_format`
- `no_tclformat`
- `no_tclfmt`
- `noformat`
- `nofmt`
"*
nameA unique name for this target. *9
tcl_tclint_fmt_aspect @@rules_tcl//tcl/tclint:defs.bzl
��,
*
nameA unique name for this target. �
"//tcl/tclint:tcl_tclint_aspect.bzlru
.
	rules_tcl
tcl/tclinttcl_tclint_aspect.bzl5
tcl_tclint_aspect_tcl_tclint_aspect
6H
_�
&//tcl/tclint:tcl_tclint_fmt_aspect.bzlr�
2
	rules_tcl
tcl/tclinttcl_tclint_fmt_aspect.bzl=
tcl_tclint_fmt_aspect_tcl_tclint_fmt_aspect
:P
k�
$//tcl/tclint:tcl_tclint_fmt_test.bzlr{
0
	rules_tcl
tcl/tclinttcl_tclint_fmt_test.bzl9
tcl_tclint_fmt_test_tcl_tclint_fmt_test
8L
e�
 //tcl/tclint:tcl_tclint_test.bzlro
,
	rules_tcl
tcl/tclinttcl_tclint_test.bzl1
tcl_tclint_test_tcl_tclint_test
4D
Y�
!//tcl/tclint:tclint_toolchain.bzlrr
-
	rules_tcl
tcl/tclinttclint_toolchain.bzl3
tclint_toolchain_tclint_toolchain
5F
\Tclint Bazel rules�
'
	rules_tcl
tcl/tclintextensions.bzl�tclintJ�
i
tclint-
	toolchain Configures the tclint toolchain."0
tclint&@@rules_tcl//tcl/tclint:extensions.bzl
((/
-
	toolchain Configures the tclint toolchain.&Bzlmod extension for tclint toolchain.�

.
	rules_tcl
tcl/tclinttcl_tclint_aspect.bzl�tcl_tclint_aspect�An aspect for performing tclint linting checks on Tcl targets.

Uses [tclint](https://github.com/nmoroze/tclint) to check for code quality issues.

**Usage:**

```bash
bazel build //my:target \
    --aspects=@rules_tcl//tcl/tclint:tcl_tclint_aspect.bzl%tcl_tclint_aspect \
    --output_groups=+tcl_tclint_checks
```

**Ignoring targets:**

To skip tclint for specific targets, add one of these tags:
- `no_tcl_lint`
- `no_tclint`
- `no_lint`
- `nolint`
:�
�
tcl_tclint_aspect�An aspect for performing tclint linting checks on Tcl targets.

Uses [tclint](https://github.com/nmoroze/tclint) to check for code quality issues.

**Usage:**

```bash
bazel build //my:target \
    --aspects=@rules_tcl//tcl/tclint:tcl_tclint_aspect.bzl%tcl_tclint_aspect \
    --output_groups=+tcl_tclint_checks
```

**Ignoring targets:**

To skip tclint for specific targets, add one of these tags:
- `no_tcl_lint`
- `no_tclint`
- `no_lint`
- `nolint`
"*
nameA unique name for this target. *B
tcl_tclint_aspect-@@rules_tcl//tcl/tclint:tcl_tclint_aspect.bzl
44,
*
nameA unique name for this target. �
//tcl/tclint/private:tclint.bzlrr
+
	rules_tcltcl/tclint/private
tclint.bzl5
tcl_tclint_aspect_tcl_tclint_aspect

tcl_tclint_aspect�
2
	rules_tcl
tcl/tclinttcl_tclint_fmt_aspect.bzl�	tcl_tclint_fmt_aspect�An aspect for performing formatting checks on Tcl targets.

Uses [tclint](https://github.com/nmoroze/tclint) to verify formatting.

**Usage:**

```bash
bazel build //my:target \
    --aspects=@rules_tcl//tcl/tclint:tcl_tclint_fmt_aspect.bzl%tcl_tclint_fmt_aspect \
    --output_groups=+tcl_tclint_fmt_checks
```

**Ignoring targets:**

To skip format checking for specific targets, add one of these tags:
- `no_tcl_format`
- `no_tclformat`
- `no_tclfmt`
- `noformat`
- `nofmt`
:�
�
tcl_tclint_fmt_aspect�An aspect for performing formatting checks on Tcl targets.

Uses [tclint](https://github.com/nmoroze/tclint) to verify formatting.

**Usage:**

```bash
bazel build //my:target \
    --aspects=@rules_tcl//tcl/tclint:tcl_tclint_fmt_aspect.bzl%tcl_tclint_fmt_aspect \
    --output_groups=+tcl_tclint_fmt_checks
```

**Ignoring targets:**

To skip format checking for specific targets, add one of these tags:
- `no_tcl_format`
- `no_tclformat`
- `no_tclfmt`
- `noformat`
- `nofmt`
"*
nameA unique name for this target. *J
tcl_tclint_fmt_aspect1@@rules_tcl//tcl/tclint:tcl_tclint_fmt_aspect.bzl
��,
*
nameA unique name for this target. �
//tcl/tclint/private:tclint.bzlrz
+
	rules_tcltcl/tclint/private
tclint.bzl=
tcl_tclint_fmt_aspect_tcl_tclint_fmt_aspect

tcl_tclint_fmt_aspect�
-
	rules_tcl
tcl/tclinttclint_toolchain.bzl�current_tclint_toolchainNA rule for accessing the `tclint` attribute of the current `tclint_toolchain`."�
�
current_tclint_toolchainNA rule for accessing the `tclint` attribute of the current `tclint_toolchain`.*
nameA unique name for this target. "H
current_tclint_toolchain,@@rules_tcl//tcl/tclint:tclint_toolchain.bzl
> > ,
*
nameA unique name for this target. �
tclint_toolchain�A toolchain rule for configuring [tclint](https://github.com/nmoroze/tclint).

The `tclint_toolchain` rule specifies the tclint Python library used by
`tcl_tclint_aspect`, `tcl_format_aspect`, and related test rules.

Typically, you don't need to define this directly. Instead, use the bzlmod extension:

```python
tclint = use_extension("@rules_tcl//tcl/tclint:extensions.bzl", "tclint")
tclint.toolchain()
use_repo(tclint, "tclint_toolchains")
register_toolchains("@tclint_toolchains//:all")
```
"�
�
tclint_toolchain�A toolchain rule for configuring [tclint](https://github.com/nmoroze/tclint).

The `tclint_toolchain` rule specifies the tclint Python library used by
`tcl_tclint_aspect`, `tcl_format_aspect`, and related test rules.

Typically, you don't need to define this directly. Instead, use the bzlmod extension:

```python
tclint = use_extension("@rules_tcl//tcl/tclint:extensions.bzl", "tclint")
tclint.toolchain()
use_repo(tclint, "tclint_toolchains")
register_toolchains("@tclint_toolchains//:all")
```
*
nameA unique name for this target. O
tclintAThe [`tclint`](https://github.com/nmoroze/tclint) python library. "@
tclint_toolchain,@@rules_tcl//tcl/tclint:tclint_toolchain.bzl
,
*
nameA unique name for this target. Q
O
tclintAThe [`tclint`](https://github.com/nmoroze/tclint) python library. k
//python:py_info.bzlrQ
!

rules_venvpythonpy_info.bzl
PyInfoPyInfo
*0
2Y	TCLINT_TOOLCHAIN_TYPE@@//tcl/tclint:toolchain_typej@@//tcl/tclint:toolchain_typeTclint toolchain rules�q

	rules_tcltcldefs.bzl�
tcl_binary�A `tcl_binary` is an executable Tcl program consisting of a collection of
`.tcl` source files (possibly belonging to other `tcl_library` rules), a `*.runfiles`
directory tree containing all the code and data needed by the program at run-time,
and a stub script that starts up the program with the correct initial environment
and data.

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_binary")

tcl_binary(
    name = "foo",
    srcs = ["foo.tcl"],
    deps = [
        ":bar",  # a tcl_library
    ],
)
```
"�
�	

tcl_binary�A `tcl_binary` is an executable Tcl program consisting of a collection of
`.tcl` source files (possibly belonging to other `tcl_library` rules), a `*.runfiles`
directory tree containing all the code and data needed by the program at run-time,
and a stub script that starts up the program with the correct initial environment
and data.

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_binary")

tcl_binary(
    name = "foo",
    srcs = ["foo.tcl"],
    deps = [
        ":bar",  # a tcl_library
    ],
)
```
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2NoneV
srcsJThe list of source (`.tcl`) files that are processed to create the target. "'

tcl_binary@@rules_tcl//tcl:defs.bzl
��,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]L
J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]k
i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}�
�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2NoneX
V
srcsJThe list of source (`.tcl`) files that are processed to create the target. �tcl_library�A Tcl library that can be depended upon by other Tcl targets.

A `tcl_library` represents a Tcl package that can be imported using Tcl's `package require` command.
The library must include a `pkgIndex.tcl` file in its `srcs` attribute, which defines the package
metadata and how to load the package.

**Important**: The `pkgIndex.tcl` file must be included in the `srcs` attribute. This file is used
by Tcl's package system to locate and load the package.

Example:

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_library")

tcl_library(
    name = "mylib",
    srcs = [
        "mylib.tcl",
        "pkgIndex.tcl",
    ],
    deps = [
        ":otherlib",  # Another tcl_library
    ],
    visibility = ["//visibility:public"],
)
```

The library can then be used as a dependency in other targets:

```python
tcl_binary(
    name = "app",
    srcs = ["app.tcl"],
    deps = [":mylib"],
)
```
"�
�	
tcl_library�A Tcl library that can be depended upon by other Tcl targets.

A `tcl_library` represents a Tcl package that can be imported using Tcl's `package require` command.
The library must include a `pkgIndex.tcl` file in its `srcs` attribute, which defines the package
metadata and how to load the package.

**Important**: The `pkgIndex.tcl` file must be included in the `srcs` attribute. This file is used
by Tcl's package system to locate and load the package.

Example:

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_library")

tcl_library(
    name = "mylib",
    srcs = [
        "mylib.tcl",
        "pkgIndex.tcl",
    ],
    deps = [
        ":otherlib",  # Another tcl_library
    ],
    visibility = ["//visibility:public"],
)
```

The library can then be used as a dependency in other targets:

```python
tcl_binary(
    name = "app",
    srcs = ["app.tcl"],
    deps = [":mylib"],
)
```
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]V
srcsJThe list of source (`.tcl`) files that are processed to create the target. "(
tcl_library@@rules_tcl//tcl:defs.bzl
��,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]L
J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]X
V
srcsJThe list of source (`.tcl`) files that are processed to create the target. �tcl_toolchain�A toolchain rule that defines the Tcl interpreter and libraries for building Tcl targets.

The `tcl_toolchain` rule configures the Tcl environment used by all `tcl_binary`, `tcl_library`,
and `tcl_test` targets. It specifies:
- The Tcl interpreter (`tclsh`) to use for execution
- The Tcl core library files (`tclcore`)
- The Tcl standard library (`tcllib`)
- Optional linting tools (`tclint`) for code quality checks

Typically, you don't need to create a `tcl_toolchain` directly. The rules provide a default
toolchain that you register in your `MODULE.bazel`:

```python
register_toolchains("@rules_tcl//tcl/toolchain")
```

If you need a custom toolchain (e.g., a different Tcl version), you can define your own:

```python
load("@rules_tcl//tcl:tcl_toolchain.bzl", "tcl_toolchain")

tcl_toolchain(
    name = "my_tcl_toolchain",
    tclsh = "@tcl_8_6//:tclsh",
    tclcore = "@tcl_8_6//:tclcore",
    tcllib = "@tcllib//:tcllib",
    tclint = "@tclint//:tclint",  # Optional, for linting
)
```
"�
�
tcl_toolchain�A toolchain rule that defines the Tcl interpreter and libraries for building Tcl targets.

The `tcl_toolchain` rule configures the Tcl environment used by all `tcl_binary`, `tcl_library`,
and `tcl_test` targets. It specifies:
- The Tcl interpreter (`tclsh`) to use for execution
- The Tcl core library files (`tclcore`)
- The Tcl standard library (`tcllib`)
- Optional linting tools (`tclint`) for code quality checks

Typically, you don't need to create a `tcl_toolchain` directly. The rules provide a default
toolchain that you register in your `MODULE.bazel`:

```python
register_toolchains("@rules_tcl//tcl/toolchain")
```

If you need a custom toolchain (e.g., a different Tcl version), you can define your own:

```python
load("@rules_tcl//tcl:tcl_toolchain.bzl", "tcl_toolchain")

tcl_toolchain(
    name = "my_tcl_toolchain",
    tclsh = "@tcl_8_6//:tclsh",
    tclcore = "@tcl_8_6//:tclcore",
    tcllib = "@tcllib//:tcllib",
    tclint = "@tclint//:tclint",  # Optional, for linting
)
```
*
nameA unique name for this target. .
tclcoreA label to the `tclcore` files. �
tclint�The [`tclint`](https://github.com/nmoroze/tclint) python library. This attribute is required for [`tcl_lint_aspect`](#tcl_lint_aspect)/[`tcl_format_aspect`](#tcl_format_aspect) but otherwise optional for core rules.2None,
tcllibA label to the `tcllib` files. *
tclshThe path to a `tclsh` binary. "*
tcl_toolchain@@rules_tcl//tcl:defs.bzl
II,
*
nameA unique name for this target. 0
.
tclcoreA label to the `tclcore` files. �
�
tclint�The [`tclint`](https://github.com/nmoroze/tclint) python library. This attribute is required for [`tcl_lint_aspect`](#tcl_lint_aspect)/[`tcl_format_aspect`](#tcl_format_aspect) but otherwise optional for core rules.2None.
,
tcllibA label to the `tcllib` files. ,
*
tclshThe path to a `tclsh` binary. �tcl_format_aspect�
An aspect for performing formatting checks on Tcl targets.

The `tcl_format_aspect` checks that Tcl source files are properly formatted according to
the configured style. It uses [tclint](https://github.com/nmoroze/tclint) to verify formatting.

**Usage:**

Apply the aspect to check formatting of all dependencies via command line:

```bash
bazel build //my:target --aspects=@rules_tcl//tcl:tcl_format_aspect.bzl%tcl_format_aspect
```

Or configure it in your `.bazelrc` file to enable format checking for all builds:

```bazelrc
# Enable tclfmt for all targets in the workspace
build:tclfmt --aspects=@rules_tcl//tcl:tcl_format_aspect.bzl%tcl_format_aspect
build:tclfmt --output_groups=+tcl_format_checks
```

Then use it with:
```bash
bazel build //my:target --config=tclfmt
```

Or use it in a test:

```python
load("@rules_tcl//tcl:tcl_format_test.bzl", "tcl_format_test")

tcl_format_test(
    name = "format_check",
    target = ":my_library",
)
```

**Ignoring targets:**

To skip format checking for specific targets, add one of these tags:
- `no_tcl_format`
- `no_tclformat`
- `no_tclfmt`
- `noformat`
- `nofmt`

```python
tcl_library(
    name = "generated_code",
    srcs = ["generated.tcl"],
    tags = ["no_tcl_format"],
)
```

The aspect processes all source files including `pkgIndex.tcl` files.
:�
�
tcl_format_aspect�
An aspect for performing formatting checks on Tcl targets.

The `tcl_format_aspect` checks that Tcl source files are properly formatted according to
the configured style. It uses [tclint](https://github.com/nmoroze/tclint) to verify formatting.

**Usage:**

Apply the aspect to check formatting of all dependencies via command line:

```bash
bazel build //my:target --aspects=@rules_tcl//tcl:tcl_format_aspect.bzl%tcl_format_aspect
```

Or configure it in your `.bazelrc` file to enable format checking for all builds:

```bazelrc
# Enable tclfmt for all targets in the workspace
build:tclfmt --aspects=@rules_tcl//tcl:tcl_format_aspect.bzl%tcl_format_aspect
build:tclfmt --output_groups=+tcl_format_checks
```

Then use it with:
```bash
bazel build //my:target --config=tclfmt
```

Or use it in a test:

```python
load("@rules_tcl//tcl:tcl_format_test.bzl", "tcl_format_test")

tcl_format_test(
    name = "format_check",
    target = ":my_library",
)
```

**Ignoring targets:**

To skip format checking for specific targets, add one of these tags:
- `no_tcl_format`
- `no_tclformat`
- `no_tclfmt`
- `noformat`
- `nofmt`

```python
tcl_library(
    name = "generated_code",
    srcs = ["generated.tcl"],
    tags = ["no_tcl_format"],
)
```

The aspect processes all source files including `pkgIndex.tcl` files.
"*
nameA unique name for this target. *.
tcl_format_aspect@@rules_tcl//tcl:defs.bzl
��,
*
nameA unique name for this target. �tcl_lint_aspect�	An aspect for performing linting checks on Tcl targets.

The `tcl_lint_aspect` applies linting checks to all Tcl targets in the dependency graph.
It uses [tclint](https://github.com/nmoroze/tclint) to check for code quality issues.

**Usage:**

Apply the aspect to check all dependencies of a target via command line:

```bash
bazel build //my:target --aspects=@rules_tcl//tcl:tcl_lint_aspect.bzl%tcl_lint_aspect
```

Or configure it in your `.bazelrc` file to enable linting for all builds:

```bazelrc
# Enable tclint for all targets in the workspace
build:tclint --aspects=@rules_tcl//tcl:tcl_lint_aspect.bzl%tcl_lint_aspect
build:tclint --output_groups=+tcl_lint_checks
```

Then use it with:
```bash
bazel build //my:target --config=tclint
```

Or use it in a test:

```python
load("@rules_tcl//tcl:tcl_lint_test.bzl", "tcl_lint_test")

tcl_lint_test(
    name = "lint_check",
    target = ":my_library",
)
```

**Ignoring targets:**

To skip linting for specific targets, add one of these tags:
- `no_tcl_lint`
- `no_lint`
- `nolint`

```python
tcl_library(
    name = "legacy_code",
    srcs = ["legacy.tcl"],
    tags = ["no_tcl_lint"],
)
```

The aspect only processes source files (not generated files) and excludes `pkgIndex.tcl` files.
:�
�

tcl_lint_aspect�	An aspect for performing linting checks on Tcl targets.

The `tcl_lint_aspect` applies linting checks to all Tcl targets in the dependency graph.
It uses [tclint](https://github.com/nmoroze/tclint) to check for code quality issues.

**Usage:**

Apply the aspect to check all dependencies of a target via command line:

```bash
bazel build //my:target --aspects=@rules_tcl//tcl:tcl_lint_aspect.bzl%tcl_lint_aspect
```

Or configure it in your `.bazelrc` file to enable linting for all builds:

```bazelrc
# Enable tclint for all targets in the workspace
build:tclint --aspects=@rules_tcl//tcl:tcl_lint_aspect.bzl%tcl_lint_aspect
build:tclint --output_groups=+tcl_lint_checks
```

Then use it with:
```bash
bazel build //my:target --config=tclint
```

Or use it in a test:

```python
load("@rules_tcl//tcl:tcl_lint_test.bzl", "tcl_lint_test")

tcl_lint_test(
    name = "lint_check",
    target = ":my_library",
)
```

**Ignoring targets:**

To skip linting for specific targets, add one of these tags:
- `no_tcl_lint`
- `no_lint`
- `nolint`

```python
tcl_library(
    name = "legacy_code",
    srcs = ["legacy.tcl"],
    tags = ["no_tcl_lint"],
)
```

The aspect only processes source files (not generated files) and excludes `pkgIndex.tcl` files.
"*
nameA unique name for this target. *,
tcl_lint_aspect@@rules_tcl//tcl:defs.bzl
ee,
*
nameA unique name for this target. s
//tcl:tcl_binary.bzlrY
 
	rules_tcltcltcl_binary.bzl'

tcl_binary_tcl_binary
(3
C�
//tcl:tcl_format_aspect.bzlrn
'
	rules_tcltcltcl_format_aspect.bzl5
tcl_format_aspect_tcl_format_aspect
/A
X�
//tcl:tcl_format_test.bzlrh
%
	rules_tcltcltcl_format_test.bzl1
tcl_format_test_tcl_format_test
-=
Rw
//tcl:tcl_library.bzlr\
!
	rules_tcltcltcl_library.bzl)
tcl_library_tcl_library
)5
F�
//tcl:tcl_lint_aspect.bzlrh
%
	rules_tcltcltcl_lint_aspect.bzl1
tcl_lint_aspect_tcl_lint_aspect
-=
R
//tcl:tcl_lint_test.bzlrb
#
	rules_tcltcltcl_lint_test.bzl-
tcl_lint_test_tcl_lint_test
+9
L
//tcl:tcl_toolchain.bzlrb
#
	rules_tcltcltcl_toolchain.bzl-
tcl_toolchain_tcl_toolchain
	+	9
		LTcl Bazel rules�
 
	rules_tcltcltcl_binary.bzl�
tcl_binary�A `tcl_binary` is an executable Tcl program consisting of a collection of
`.tcl` source files (possibly belonging to other `tcl_library` rules), a `*.runfiles`
directory tree containing all the code and data needed by the program at run-time,
and a stub script that starts up the program with the correct initial environment
and data.

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_binary")

tcl_binary(
    name = "foo",
    srcs = ["foo.tcl"],
    deps = [
        ":bar",  # a tcl_library
    ],
)
```
"�
�	

tcl_binary�A `tcl_binary` is an executable Tcl program consisting of a collection of
`.tcl` source files (possibly belonging to other `tcl_library` rules), a `*.runfiles`
directory tree containing all the code and data needed by the program at run-time,
and a stub script that starts up the program with the correct initial environment
and data.

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_binary")

tcl_binary(
    name = "foo",
    srcs = ["foo.tcl"],
    deps = [
        ":bar",  # a tcl_library
    ],
)
```
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2NoneV
srcsJThe list of source (`.tcl`) files that are processed to create the target. "-

tcl_binary@@rules_tcl//tcl:tcl_binary.bzl
��,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]L
J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]k
i
env\Dictionary of strings; values are subject to `$(location)` and "Make variable" substitution.
2{}�
�
main�The name of the source file that is the main entry point of the application. This file must also be listed in `srcs`. If left unspecified, `name` is used instead. If `name` does not match any filename in `srcs`, `main` must be specified. 2NoneX
V
srcsJThe list of source (`.tcl`) files that are processed to create the target. u
//tcl/private:tcl.bzlrZ
!
	rules_tcltcl/privatetcl.bzl'

tcl_binary_tcl_binary
)4
D
tcl_binary�

	rules_tcltcltcl_info.bzl�TclInfoInfo about a Tcl target.2�
�
TclInfoInfo about a Tcl target.T
includesHDepset[str]: A list of include paths associated with the current target.@
srcs8Depset[File]: Direct source files of the current target.D
transitive_includes-Depset[str]: Include paths from dependencies.T
transitive_srcsADepset[File]: Source files required at runtime from dependencies."(
TclInfo@@rules_tcl//tcl:tcl_info.bzl
V
T
includesHDepset[str]: A list of include paths associated with the current target.B
@
srcs8Depset[File]: Direct source files of the current target.F
D
transitive_includes-Depset[str]: Include paths from dependencies.V
T
transitive_srcsADepset[File]: Source files required at runtime from dependencies.{
//tcl/private:providers.bzlrZ
'
	rules_tcltcl/privateproviders.bzl!
TclInfo_TclInfo
/7
DTclInfo�
!
	rules_tcltcltcl_library.bzl�tcl_library�A Tcl library that can be depended upon by other Tcl targets.

A `tcl_library` represents a Tcl package that can be imported using Tcl's `package require` command.
The library must include a `pkgIndex.tcl` file in its `srcs` attribute, which defines the package
metadata and how to load the package.

**Important**: The `pkgIndex.tcl` file must be included in the `srcs` attribute. This file is used
by Tcl's package system to locate and load the package.

Example:

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_library")

tcl_library(
    name = "mylib",
    srcs = [
        "mylib.tcl",
        "pkgIndex.tcl",
    ],
    deps = [
        ":otherlib",  # Another tcl_library
    ],
    visibility = ["//visibility:public"],
)
```

The library can then be used as a dependency in other targets:

```python
tcl_binary(
    name = "app",
    srcs = ["app.tcl"],
    deps = [":mylib"],
)
```
"�
�

tcl_library�A Tcl library that can be depended upon by other Tcl targets.

A `tcl_library` represents a Tcl package that can be imported using Tcl's `package require` command.
The library must include a `pkgIndex.tcl` file in its `srcs` attribute, which defines the package
metadata and how to load the package.

**Important**: The `pkgIndex.tcl` file must be included in the `srcs` attribute. This file is used
by Tcl's package system to locate and load the package.

Example:

```python
load("@rules_tcl//tcl:defs.bzl", "tcl_library")

tcl_library(
    name = "mylib",
    srcs = [
        "mylib.tcl",
        "pkgIndex.tcl",
    ],
    deps = [
        ":otherlib",  # Another tcl_library
    ],
    visibility = ["//visibility:public"],
)
```

The library can then be used as a dependency in other targets:

```python
tcl_binary(
    name = "app",
    srcs = ["app.tcl"],
    deps = [":mylib"],
)
```
*
nameA unique name for this target. o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]V
srcsJThe list of source (`.tcl`) files that are processed to create the target. "/
tcl_library @@rules_tcl//tcl:tcl_library.bzl
��,
*
nameA unique name for this target. q
o
dataaFiles needed by this rule at runtime. May list file or rule targets. Generally allows any target.2[]L
J
deps1Other Tcl packages to link to the current target.*	
TclInfo2[]X
V
srcsJThe list of source (`.tcl`) files that are processed to create the target. w
//tcl/private:tcl.bzlr\
!
	rules_tcltcl/privatetcl.bzl)
tcl_library_tcl_library
)5
Ftcl_library�
#
	rules_tcltcltcl_toolchain.bzl�tcl_toolchain�A toolchain rule that defines the Tcl interpreter and libraries for building Tcl targets.

The `tcl_toolchain` rule configures the Tcl environment used by all `tcl_binary`, `tcl_library`,
and `tcl_test` targets. It specifies:
- The Tcl interpreter (`tclsh`) to use for execution
- The Tcl core library files (`tclcore`)
- The Tcl standard library (`tcllib`)
- Optional linting tools (`tclint`) for code quality checks

Typically, you don't need to create a `tcl_toolchain` directly. The rules provide a default
toolchain that you register in your `MODULE.bazel`:

```python
register_toolchains("@rules_tcl//tcl/toolchain")
```

If you need a custom toolchain (e.g., a different Tcl version), you can define your own:

```python
load("@rules_tcl//tcl:tcl_toolchain.bzl", "tcl_toolchain")

tcl_toolchain(
    name = "my_tcl_toolchain",
    tclsh = "@tcl_8_6//:tclsh",
    tclcore = "@tcl_8_6//:tclcore",
    tcllib = "@tcllib//:tcllib",
    tclint = "@tclint//:tclint",  # Optional, for linting
)
```
"�
�
tcl_toolchain�A toolchain rule that defines the Tcl interpreter and libraries for building Tcl targets.

The `tcl_toolchain` rule configures the Tcl environment used by all `tcl_binary`, `tcl_library`,
and `tcl_test` targets. It specifies:
- The Tcl interpreter (`tclsh`) to use for execution
- The Tcl core library files (`tclcore`)
- The Tcl standard library (`tcllib`)
- Optional linting tools (`tclint`) for code quality checks

Typically, you don't need to create a `tcl_toolchain` directly. The rules provide a default
toolchain that you register in your `MODULE.bazel`:

```python
register_toolchains("@rules_tcl//tcl/toolchain")
```

If you need a custom toolchain (e.g., a different Tcl version), you can define your own:

```python
load("@rules_tcl//tcl:tcl_toolchain.bzl", "tcl_toolchain")

tcl_toolchain(
    name = "my_tcl_toolchain",
    tclsh = "@tcl_8_6//:tclsh",
    tclcore = "@tcl_8_6//:tclcore",
    tcllib = "@tcllib//:tcllib",
    tclint = "@tclint//:tclint",  # Optional, for linting
)
```
*
nameA unique name for this target. .
tclcoreA label to the `tclcore` files. �
tclint�The [`tclint`](https://github.com/nmoroze/tclint) python library. This attribute is required for [`tcl_lint_aspect`](#tcl_lint_aspect)/[`tcl_format_aspect`](#tcl_format_aspect) but otherwise optional for core rules.2None,
tcllibA label to the `tcllib` files. *
tclshThe path to a `tclsh` binary. "3
tcl_toolchain"@@rules_tcl//tcl:tcl_toolchain.bzl
II,
*
nameA unique name for this target. 0
.
tclcoreA label to the `tclcore` files. �
�
tclint�The [`tclint`](https://github.com/nmoroze/tclint) python library. This attribute is required for [`tcl_lint_aspect`](#tcl_lint_aspect)/[`tcl_format_aspect`](#tcl_format_aspect) but otherwise optional for core rules.2None.
,
tcllibA label to the `tcllib` files. ,
*
tclshThe path to a `tclsh` binary. �
//tcl/private:toolchain.bzlr�
'
	rules_tcltcl/privatetoolchain.bzl/
TOOLCHAIN_TYPE_TOOLCHAIN_TYPE
-
tcl_toolchain_tcl_toolchain

D	TOOLCHAIN_TYPE@@//tcl:toolchain_typej@@//tcl:toolchain_typetcl_toolchainK

	rules_tclversion.bzl	VERSION0.1.1j0.1.1"rules_tcl version 