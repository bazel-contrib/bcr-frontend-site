�<


rules_tofutfdefs.bzl�
tf_library�A reusable bundle of OpenTofu/Terraform configuration files.

Always generates:
  - `:<name>`     — the library target. Building it runs
                    `tofu init -backend=false && tofu validate` against
                    the library's transitive files.
  - `:<name>.fmt` — `bazel run` to reformat .tf files in-place.

When `fmt_test=True` (the default) and `srcs` is non-empty:
  - `:<name>.fmt_check`  — `bazel test` that fails if files are not formatted.
*�
�	

tf_library
nametarget name. (6
srcs&source .tf/.tf.json/.tftpl/.hcl files.None(;
deps+other `tf_library` targets to compose with.None(O
data?arbitrary files to include in the work tree for `file()` calls.None(�
	providers�providers (`@tf_providers//<namespace>/<name>`, from the
`tf_providers` extension in MODULE.bazel) that this library
references in `required_providers`. Propagates transitively to any
`tf_deploy` consuming this library.None(�
fmt_testpwhether to emit a `:<name>.fmt_check` test target. Only emitted
when True (the default) and `srcs` is non-empty.True(J
kwargs>forwarded to the underlying rule (visibility, tags, testonly).(�A reusable bundle of OpenTofu/Terraform configuration files.

Always generates:
  - `:<name>`     — the library target. Building it runs
                    `tofu init -backend=false && tofu validate` against
                    the library's transitive files.
  - `:<name>.fmt` — `bazel run` to reformat .tf files in-place.

When `fmt_test=True` (the default) and `srcs` is non-empty:
  - `:<name>.fmt_check`  — `bazel test` that fails if files are not formatted.
21

tf_library#@rules_tofu//tf/private:library.bzl

nametarget name. (8
6
srcs&source .tf/.tf.json/.tftpl/.hcl files.None(=
;
deps+other `tf_library` targets to compose with.None(Q
O
data?arbitrary files to include in the work tree for `file()` calls.None(�
�
	providers�providers (`@tf_providers//<namespace>/<name>`, from the
`tf_providers` extension in MODULE.bazel) that this library
references in `required_providers`. Propagates transitively to any
`tf_deploy` consuming this library.None(�
�
fmt_testpwhether to emit a `:<name>.fmt_check` test target. Only emitted
when True (the default) and `srcs` is non-empty.True(L
J
kwargs>forwarded to the underlying rule (visibility, tags, testonly).(�'	tf_deploy�A root Terraform/OpenTofu invocation.

Always generates:
  - `:<name>`         — data target. Building it materializes the work tree
                        and runs `tofu init -backend=false && tofu validate`
                        against it, so `bazel build :<name>` validates.
  - `:<name>.plan`    — `bazel run` to produce a plan.
  - `:<name>.apply`   — `bazel run` to apply.
  - `:<name>.destroy` — `bazel run` to destroy all managed resources.
  - `:<name>.fmt`     — `bazel run` to reformat .tf files in-place.

When `fmt_test=True` (the default) and `srcs` is non-empty:
  - `:<name>.fmt_check` — `bazel test` that fails if files are not formatted.
*�!
�
	tf_deploy
nametarget name. (O
srcs?optional deploy-local .tf files (e.g. provider/backend config).None(0
deps `tf_library` targets to compose.None(X
varsHdict of variable name -> value, rendered to rules_tofu.auto.tfvars.json.None(�
	var_files�`.tfvars.json` or `.tfvars` files passed to tofu with `-var-file`.
Any label works, e.g. a genrule output. Keys must not overlap with
`vars` or other `var_files` entries; a duplicate key fails
`bazel build`.None(j
dataZarbitrary files to include in the work tree, enabling `file()` calls
in Terraform configs.None(�
	providers�providers (`@tf_providers//<namespace>/<name>`, from the
`tf_providers` extension in MODULE.bazel) declared at the deploy
level, in addition to those its `deps` bring in. `tofu init` runs
offline against them.None(�
allow_ephemeral_state�allow `:<name>.apply` and `:<name>.destroy` to run
against local state. A deploy with no `backend "..." {}` or `cloud {}`
block keeps its state at
`bazel-bin/<pkg>/<name>.rules_tofu-state/terraform.tfstate`, which is
machine-local, forks with the build configuration, and is deleted by
`bazel clean` — losing it orphans whatever was applied. So by default
the runner refuses both mutating commands for such a deploy; `plan` is
never gated. Set True only where disposable state is the point: demos
and examples, throwaway sandboxes, or bootstrapping the bucket that
will hold real state (then move it with
`tofu init -migrate-state` once the backend block is in place).
Ignored when a backend/cloud block is present.False(�
fmt_testpwhether to emit a `:<name>.fmt_check` test target. Only emitted
when True (the default) and `srcs` is non-empty.True(J
kwargs>forwarded to the underlying rule (visibility, tags, testonly).(�A root Terraform/OpenTofu invocation.

Always generates:
  - `:<name>`         — data target. Building it materializes the work tree
                        and runs `tofu init -backend=false && tofu validate`
                        against it, so `bazel build :<name>` validates.
  - `:<name>.plan`    — `bazel run` to produce a plan.
  - `:<name>.apply`   — `bazel run` to apply.
  - `:<name>.destroy` — `bazel run` to destroy all managed resources.
  - `:<name>.fmt`     — `bazel run` to reformat .tf files in-place.

When `fmt_test=True` (the default) and `srcs` is non-empty:
  - `:<name>.fmt_check` — `bazel test` that fails if files are not formatted.
2/
	tf_deploy"@rules_tofu//tf/private:deploy.bzl

nametarget name. (Q
O
srcs?optional deploy-local .tf files (e.g. provider/backend config).None(2
0
deps `tf_library` targets to compose.None(Z
X
varsHdict of variable name -> value, rendered to rules_tofu.auto.tfvars.json.None(�
�
	var_files�`.tfvars.json` or `.tfvars` files passed to tofu with `-var-file`.
Any label works, e.g. a genrule output. Keys must not overlap with
`vars` or other `var_files` entries; a duplicate key fails
`bazel build`.None(l
j
dataZarbitrary files to include in the work tree, enabling `file()` calls
in Terraform configs.None(�
�
	providers�providers (`@tf_providers//<namespace>/<name>`, from the
`tf_providers` extension in MODULE.bazel) declared at the deploy
level, in addition to those its `deps` bring in. `tofu init` runs
offline against them.None(�
�
allow_ephemeral_state�allow `:<name>.apply` and `:<name>.destroy` to run
against local state. A deploy with no `backend "..." {}` or `cloud {}`
block keeps its state at
`bazel-bin/<pkg>/<name>.rules_tofu-state/terraform.tfstate`, which is
machine-local, forks with the build configuration, and is deleted by
`bazel clean` — losing it orphans whatever was applied. So by default
the runner refuses both mutating commands for such a deploy; `plan` is
never gated. Set True only where disposable state is the point: demos
and examples, throwaway sandboxes, or bootstrapping the bucket that
will hold real state (then move it with
`tofu init -migrate-state` once the backend block is in place).
Ignored when a backend/cloud block is present.False(�
�
fmt_testpwhether to emit a `:<name>.fmt_check` test target. Only emitted
when True (the default) and `srcs` is non-empty.True(L
J
kwargs>forwarded to the underlying rule (visibility, tags, testonly).(�Rules for OpenTofu and Terraform-compatible configuration.

`tf_library` bundles reusable `.tf` files; `tf_deploy` is a root
configuration you can plan, apply and destroy with `bazel run`. Load them
with:

    load("@rules_tofu//tf:defs.bzl", "tf_library", "tf_deploy")�6
*

rules_tofutf/providersextensions.bzl�1tf_providers�Downloads OpenTofu/Terraform providers for `tf_library` and `tf_deploy`.

BUILD files name each provider as `@tf_providers//<namespace>/<name>`, in lower
case and never with a version, in the `providers` of the targets that use it.
Only the providers a build uses are fetched, and `tofu init` then runs offline
against them.

Versions come from a `.terraform.lock.hcl` (`from_lock`, recommended) or from
`provider` tags, and the two can be mixed. Zips come from the OpenTofu registry,
the same builds `tofu init` installs, unless a tag sets `url_template`. Every
download is checked against a digest: the lock's, a tag's `sha256`, or the
registry's, recorded in MODULE.bazel.lock.

Each provider resolves to one version across the module graph. The root
module's lock or tag wins; otherwise the highest version any module tags is
used.

Only `tf_providers` needs a `use_repo`.J�*
�
tf_providers�Downloads OpenTofu/Terraform providers for `tf_library` and `tf_deploy`.

BUILD files name each provider as `@tf_providers//<namespace>/<name>`, in lower
case and never with a version, in the `providers` of the targets that use it.
Only the providers a build uses are fetched, and `tofu init` then runs offline
against them.

Versions come from a `.terraform.lock.hcl` (`from_lock`, recommended) or from
`provider` tags, and the two can be mixed. Zips come from the OpenTofu registry,
the same builds `tofu init` installs, unless a tag sets `url_template`. Every
download is checked against a digest: the lock's, a tag's `sha256`, or the
registry's, recorded in MODULE.bazel.lock.

Each provider resolves to one version across the module graph. The root
module's lock or tag wins; otherwise the highest version any module tags is
used.

Only `tf_providers` needs a `use_repo`.�	
provider�Pin a provider in MODULE.bazel, for what a lock can't express: digests you pin yourself, or a download mirror. Tagged providers are left out of the lock by `pin`. A provider can't be both tagged in the root module and locked.�
source�Provider source in `<namespace>/<name>` form, e.g. `"hashicorp/aws"`. BUILD files name it in lower case, as `@tf_providers//hashicorp/aws`. 8
version)Provider version to pin, e.g. `"5.70.0"`. �
sha256�Optional per-platform SHA256 of the provider zip. Keys are `<os>_<arch>` (e.g. `linux_amd64`). If set, list every platform you build on: one that is missing fails the build there. A digest that disagrees with the registry fails the fetch and reports the registry's value. If unset, the OpenTofu registry's digests are used for whichever of linux_amd64, linux_arm64, darwin_amd64, darwin_arm64 and windows_amd64 it publishes, and recorded in MODULE.bazel.lock: commit that file.
2{}�
url_template�Optional URL of each platform's provider zip, with `{namespace}`, `{name}`, `{version}`, `{os}` and `{arch}` placeholders, used instead of the OpenTofu registry (registry.opentofu.org). Needs `sha256`.2""�
	from_lock�Pin providers with a `.terraform.lock.hcl`, as in a plain OpenTofu project, so Renovate and Dependabot can update them. `bazel run @tf_providers//:pin` writes the lock for every provider the workspace's `tf_library` and `tf_deploy` targets require. Only the root module's lock is read; a dependency's `from_lock` is ignored. Use it at most once.�
lock�The workspace's `.terraform.lock.hcl`. Defaults to `//:.terraform.lock.hcl`. The file need not exist yet: `bazel run @tf_providers//:pin` writes it.2None"*(@rules_tofu//tf/providers:extensions.bzl�
�	
provider�Pin a provider in MODULE.bazel, for what a lock can't express: digests you pin yourself, or a download mirror. Tagged providers are left out of the lock by `pin`. A provider can't be both tagged in the root module and locked.�
source�Provider source in `<namespace>/<name>` form, e.g. `"hashicorp/aws"`. BUILD files name it in lower case, as `@tf_providers//hashicorp/aws`. 8
version)Provider version to pin, e.g. `"5.70.0"`. �
sha256�Optional per-platform SHA256 of the provider zip. Keys are `<os>_<arch>` (e.g. `linux_amd64`). If set, list every platform you build on: one that is missing fails the build there. A digest that disagrees with the registry fails the fetch and reports the registry's value. If unset, the OpenTofu registry's digests are used for whichever of linux_amd64, linux_arm64, darwin_amd64, darwin_arm64 and windows_amd64 it publishes, and recorded in MODULE.bazel.lock: commit that file.
2{}�
url_template�Optional URL of each platform's provider zip, with `{namespace}`, `{name}`, `{version}`, `{os}` and `{arch}` placeholders, used instead of the OpenTofu registry (registry.opentofu.org). Needs `sha256`.2""�
�
source�Provider source in `<namespace>/<name>` form, e.g. `"hashicorp/aws"`. BUILD files name it in lower case, as `@tf_providers//hashicorp/aws`. :
8
version)Provider version to pin, e.g. `"5.70.0"`. �
�
sha256�Optional per-platform SHA256 of the provider zip. Keys are `<os>_<arch>` (e.g. `linux_amd64`). If set, list every platform you build on: one that is missing fails the build there. A digest that disagrees with the registry fails the fetch and reports the registry's value. If unset, the OpenTofu registry's digests are used for whichever of linux_amd64, linux_arm64, darwin_amd64, darwin_arm64 and windows_amd64 it publishes, and recorded in MODULE.bazel.lock: commit that file.
2{}�
�
url_template�Optional URL of each platform's provider zip, with `{namespace}`, `{name}`, `{version}`, `{os}` and `{arch}` placeholders, used instead of the OpenTofu registry (registry.opentofu.org). Needs `sha256`.2""�
�
	from_lock�Pin providers with a `.terraform.lock.hcl`, as in a plain OpenTofu project, so Renovate and Dependabot can update them. `bazel run @tf_providers//:pin` writes the lock for every provider the workspace's `tf_library` and `tf_deploy` targets require. Only the root module's lock is read; a dependency's `from_lock` is ignored. Use it at most once.�
lock�The workspace's `.terraform.lock.hcl`. Defaults to `//:.terraform.lock.hcl`. The file need not exist yet: `bazel run @tf_providers//:pin` writes it.2None�
�
lock�The workspace's `.terraform.lock.hcl`. Defaults to `//:.terraform.lock.hcl`. The file need not exist yet: `bazel run @tf_providers//:pin` writes it.2None�The `tf_providers` module extension: the providers rules_tofu vendors.

Downloads OpenTofu/Terraform provider plugins, pinned by a
`.terraform.lock.hcl` or by tags, for `tf_library` and `tf_deploy` to use
offline:

    tf_providers = use_extension("@rules_tofu//tf/providers:extensions.bzl", "tf_providers")
    tf_providers.from_lock()  # reads //:.terraform.lock.hcl
    use_repo(tf_providers, "tf_providers")

BUILD files then name each provider as `@tf_providers//<namespace>/<name>`.�
'

rules_tofu	toolchainextensions.bzl�tofu�Downloads OpenTofu and registers it as a toolchain.

One OpenTofu version serves the whole build. A `tofu.version` tag in the root
module decides it, whatever dependencies ask for, and the root may have only
one. Without a root tag, modules that tag a version must all ask for the same
one, or the build fails naming them. With no tags at all, the default pinned
in rules_tofu is used.

Only `tofu_toolchains` needs a `use_repo`, and the toolchain is registered
for you.J�

�
tofu�Downloads OpenTofu and registers it as a toolchain.

One OpenTofu version serves the whole build. A `tofu.version` tag in the root
module decides it, whatever dependencies ask for, and the root may have only
one. Without a root tag, modules that tag a version must all ask for the same
one, or the build fails naming them. With no tags at all, the default pinned
in rules_tofu is used.

Only `tofu_toolchains` needs a `use_repo`, and the toolchain is registered
for you.�
version+Choose the OpenTofu version the build runs.�
version�OpenTofu version, e.g. `"1.8.5"`. It must be one rules_tofu has digests for, listed in `KNOWN_VERSIONS` in [toolchain/versions.bzl](https://github.com/benbirt/rules_tofu/blob/main/toolchain/versions.bzl). "'%@rules_tofu//toolchain:extensions.bzl�
�
version+Choose the OpenTofu version the build runs.�
version�OpenTofu version, e.g. `"1.8.5"`. It must be one rules_tofu has digests for, listed in `KNOWN_VERSIONS` in [toolchain/versions.bzl](https://github.com/benbirt/rules_tofu/blob/main/toolchain/versions.bzl). �
�
version�OpenTofu version, e.g. `"1.8.5"`. It must be one rules_tofu has digests for, listed in `KNOWN_VERSIONS` in [toolchain/versions.bzl](https://github.com/benbirt/rules_tofu/blob/main/toolchain/versions.bzl). �The `tofu` module extension: the OpenTofu binary rules_tofu runs.

Downloads a pinned OpenTofu release for each supported platform and
registers it as the toolchain every rules_tofu target uses:

    tofu = use_extension("@rules_tofu//toolchain:extensions.bzl", "tofu")
    # tofu.version(version = "1.8.5")  # optional; a default is pinned
    use_repo(tofu, "tofu_toolchains") 