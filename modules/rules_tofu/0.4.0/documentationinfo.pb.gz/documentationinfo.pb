��


rules_tofutfdefs.bzl�T
tf_library�A reusable bundle of OpenTofu and Terraform-compatible configuration files.

A `tf_library` carries no variable values and has no `.plan`, `.apply` or
`.destroy` targets; use `tf_deploy` for a root configuration.

Files in the main repository are materialised at their workspace-relative
paths, so same-package files see each other directly. Call modules in other
workspace packages by relative paths starting with `./` or `../`, such as
`../../infra/dns`.

Module calls are resolved offline at build time:
  - Every `module` block's `source` must be a literal string. `override`
    and `*_override` files replace `source` on matching `module` blocks,
    as OpenTofu merges them.
  - Relative paths starting with `./` or `../` resolve within the caller's
    own Bazel repository in the work tree and cannot cross into another
    Bazel repository.
  - Other `source` strings match the `tf_library` in `deps` whose
    normalised `module_source` equals the address or leaves the shortest
    `//<subdir>` suffix, so a submodule's own library takes precedence over
    its parent module's library.
  - Registry addresses normalise to lower-case
    `<host>/<namespace>/<name>/<system>`, defaulting `<host>` to
    `registry.opentofu.org`.
  - Git shorthands normalise as OpenTofu parses them:
    `github.com/<owner>/<repo>[/<subdir>]` becomes
    `git::https://github.com/<owner>/<repo>.git[//<subdir>]`, and
    `git@<host>:<path>` becomes `git::ssh://git@<host>/<path>`. `?ref=`
    must match, while `?depth=` is ignored.
  - Archive URLs match by archive format and URL after stripping
    `?archive=`, so `.tgz` and `?archive=tar.gz` share `tar.gz`; any other
    query parameters must match.
  - A library with `module_source` also satisfies calls from its own files
    to that `module_source` with `//<subdir>`.

`rules_tofu` writes `<name>.modules.json` at build time, copies it to
`.terraform/modules/modules.json`, and runs `tofu init -get=false`.
`bazel build` fails on:
  - A `module` block whose `source` is not a literal string or uses an
    unsupported source type.
  - A local `./` or `../` call to a directory outside the work tree, in
    another Bazel repository, or absent from `deps`.
  - A non-local `module` call that no `tf_library` in `deps` matches.
  - A direct `module_source` dependency unused by this target's own
    configuration. Calls inside other libraries' packages in `deps` do not
    count, whereas a `module_source` library in this target's own package
    or reached from it by `./` or `../` counts as used.
  - Two libraries in `deps` with the same normalised `module_source`.
  - A registry `module` call whose library has an empty `module_version` or
    fails the caller's `version` constraint.
  - A `module_source` call landing in a directory with no `.tf`,
    `.tf.json`, `.tofu` or `.tofu.json` files. Local `./` or `../` calls
    may target directories in the work tree that hold no configuration
    files.
  - A module call cycle.
  - A `required_providers` entry missing from `providers` or `deps`, or
    outside `registry.opentofu.org`. Built-in providers such as
    `terraform.io/builtin/terraform` are exempt.
See [Modules](https://github.com/benbirt/rules_tofu#modules).

Generated targets:
  - `:<name>`: materialises the work tree and runs
    `tofu init -backend=false && tofu validate`.
  - `:<name>.fmt`: `bazel run` target, emitted when `srcs` is non-empty,
    that reformats main-repository `.tf` and `.tofu` source files in `srcs`
    in place.
  - `:<name>.fmt_check`: `bazel test` target, emitted when `srcs` is
    non-empty and `fmt_test = True`, that checks formatting of `.tf` and
    `.tofu` files in `srcs`, including generated and external files.
*�7
�*

tf_library
nameTarget name. (�
srcs�`.tf`, `.tf.json`, `.tofu`, `.tofu.json`, `.tftpl` and `.hcl`
files. `.tofu` and `.tofu.json` shadow `.tf` and `.tf.json` of the
same name. OpenTofu ignores dot-prefixed filenames.
`.terraform.lock.hcl` is rejected in `srcs` and `data`, and test
files belong in `tf_test.srcs`.None(x
depsh`tf_library` targets whose files, providers and `module_source`
mappings propagate through this library.None(�
data�Files placed in the work tree at their workspace-relative paths for
`file()` and `templatefile()`. `terraform.tfvars`,
`terraform.tfvars.json`, `*.auto.tfvars` and `*.auto.tfvars.json` are
rejected; pass variable files via `var_files` on `tf_deploy` or
`tf_test`.None({
	providersf`@tf_providers//<namespace>/<name>` targets required by
`srcs`. Propagated transitively to dependants.None(�
module_source�Address by which HCL `module` blocks call this library or
`//<subdir>` within it when it is in the caller's `deps`. Required to
call a library from another Bazel repository.None(�
module_version�Version checked against callers' `version` constraints
when `module_source` is a registry address. Required for registry
addresses. Defaults to the version of the Bazel module that holds the
library when `module_source` is set, or `""` otherwise; setting it
without `module_source` is an error.None(e
fmt_testQEmit `:<name>.fmt_check` when `True` and `srcs` is non-empty;
defaults to `True`.True(�
kwargs�Forwarded to the underlying rules. `visibility`, `tags` and
`testonly` apply to all generated targets; other rule attributes
apply to `:<name>`.(�A reusable bundle of OpenTofu and Terraform-compatible configuration files.

A `tf_library` carries no variable values and has no `.plan`, `.apply` or
`.destroy` targets; use `tf_deploy` for a root configuration.

Files in the main repository are materialised at their workspace-relative
paths, so same-package files see each other directly. Call modules in other
workspace packages by relative paths starting with `./` or `../`, such as
`../../infra/dns`.

Module calls are resolved offline at build time:
  - Every `module` block's `source` must be a literal string. `override`
    and `*_override` files replace `source` on matching `module` blocks,
    as OpenTofu merges them.
  - Relative paths starting with `./` or `../` resolve within the caller's
    own Bazel repository in the work tree and cannot cross into another
    Bazel repository.
  - Other `source` strings match the `tf_library` in `deps` whose
    normalised `module_source` equals the address or leaves the shortest
    `//<subdir>` suffix, so a submodule's own library takes precedence over
    its parent module's library.
  - Registry addresses normalise to lower-case
    `<host>/<namespace>/<name>/<system>`, defaulting `<host>` to
    `registry.opentofu.org`.
  - Git shorthands normalise as OpenTofu parses them:
    `github.com/<owner>/<repo>[/<subdir>]` becomes
    `git::https://github.com/<owner>/<repo>.git[//<subdir>]`, and
    `git@<host>:<path>` becomes `git::ssh://git@<host>/<path>`. `?ref=`
    must match, while `?depth=` is ignored.
  - Archive URLs match by archive format and URL after stripping
    `?archive=`, so `.tgz` and `?archive=tar.gz` share `tar.gz`; any other
    query parameters must match.
  - A library with `module_source` also satisfies calls from its own files
    to that `module_source` with `//<subdir>`.

`rules_tofu` writes `<name>.modules.json` at build time, copies it to
`.terraform/modules/modules.json`, and runs `tofu init -get=false`.
`bazel build` fails on:
  - A `module` block whose `source` is not a literal string or uses an
    unsupported source type.
  - A local `./` or `../` call to a directory outside the work tree, in
    another Bazel repository, or absent from `deps`.
  - A non-local `module` call that no `tf_library` in `deps` matches.
  - A direct `module_source` dependency unused by this target's own
    configuration. Calls inside other libraries' packages in `deps` do not
    count, whereas a `module_source` library in this target's own package
    or reached from it by `./` or `../` counts as used.
  - Two libraries in `deps` with the same normalised `module_source`.
  - A registry `module` call whose library has an empty `module_version` or
    fails the caller's `version` constraint.
  - A `module_source` call landing in a directory with no `.tf`,
    `.tf.json`, `.tofu` or `.tofu.json` files. Local `./` or `../` calls
    may target directories in the work tree that hold no configuration
    files.
  - A module call cycle.
  - A `required_providers` entry missing from `providers` or `deps`, or
    outside `registry.opentofu.org`. Built-in providers such as
    `terraform.io/builtin/terraform` are exempt.
See [Modules](https://github.com/benbirt/rules_tofu#modules).

Generated targets:
  - `:<name>`: materialises the work tree and runs
    `tofu init -backend=false && tofu validate`.
  - `:<name>.fmt`: `bazel run` target, emitted when `srcs` is non-empty,
    that reformats main-repository `.tf` and `.tofu` source files in `srcs`
    in place.
  - `:<name>.fmt_check`: `bazel test` target, emitted when `srcs` is
    non-empty and `fmt_test = True`, that checks formatting of `.tf` and
    `.tofu` files in `srcs`, including generated and external files.
21

tf_library#@rules_tofu//tf/private:library.bzl

nameTarget name. (�
�
srcs�`.tf`, `.tf.json`, `.tofu`, `.tofu.json`, `.tftpl` and `.hcl`
files. `.tofu` and `.tofu.json` shadow `.tf` and `.tf.json` of the
same name. OpenTofu ignores dot-prefixed filenames.
`.terraform.lock.hcl` is rejected in `srcs` and `data`, and test
files belong in `tf_test.srcs`.None(z
x
depsh`tf_library` targets whose files, providers and `module_source`
mappings propagate through this library.None(�
�
data�Files placed in the work tree at their workspace-relative paths for
`file()` and `templatefile()`. `terraform.tfvars`,
`terraform.tfvars.json`, `*.auto.tfvars` and `*.auto.tfvars.json` are
rejected; pass variable files via `var_files` on `tf_deploy` or
`tf_test`.None(}
{
	providersf`@tf_providers//<namespace>/<name>` targets required by
`srcs`. Propagated transitively to dependants.None(�
�
module_source�Address by which HCL `module` blocks call this library or
`//<subdir>` within it when it is in the caller's `deps`. Required to
call a library from another Bazel repository.None(�
�
module_version�Version checked against callers' `version` constraints
when `module_source` is a registry address. Required for registry
addresses. Defaults to the version of the Bazel module that holds the
library when `module_source` is set, or `""` otherwise; setting it
without `module_source` is an error.None(g
e
fmt_testQEmit `:<name>.fmt_check` when `True` and `srcs` is non-empty;
defaults to `True`.True(�
�
kwargs�Forwarded to the underlying rules. `visibility`, `tags` and
`testonly` apply to all generated targets; other rule attributes
apply to `:<name>`.(�8	tf_deploy�A root OpenTofu configuration, with targets to plan, apply and destroy it.

The deploy's own package is its root module and must contain at least one
`.tf`, `.tf.json`, `.tofu` or `.tofu.json` file from `srcs` or a
`tf_library` in the same package; `deps` in other packages are reached only
via `module` blocks.

Generated targets:
  - `:<name>`: materialises the work tree, checks for duplicate variable
    keys across `vars` and `var_files`, and runs
    `tofu init -backend=false && tofu validate`.
  - `:<name>.plan`: `bazel run` target that runs `tofu plan`, saving the
    plan file to `<state-dir>/tfplan`.
  - `:<name>.apply`: `bazel run` target that runs a fresh `tofu apply`
    without reading `tfplan`. Prompts unless `-- -auto-approve` is passed.
  - `:<name>.destroy`: `bazel run` target that runs `tofu destroy`. Prompts
    unless `-- -auto-approve` is passed.
  - `:<name>.fmt`: `bazel run` target, emitted when `srcs` is non-empty,
    that reformats main-repository `.tf` and `.tofu` source files in `srcs`
    in place.
  - `:<name>.fmt_check`: `bazel test` target, emitted when `srcs` is
    non-empty and `fmt_test = True`, that checks formatting of `.tf` and
    `.tofu` files in `srcs`, including generated and external files.

Each launcher, such as `bazel-bin/<pkg>/<name>.apply.sh`, can also be
invoked directly in place from any working directory; do not copy or symlink
the script elsewhere. All three share
`bazel-bin/<pkg>/<name>.rules_tofu-state/work/<pkg>` without locking, so run
one command at a time. See
[How it works](https://github.com/benbirt/rules_tofu#how-it-works).
*�+
�
	tf_deploy
nameTarget name. (�
srcs�Deploy-local `.tf`, `.tf.json`, `.tofu`, `.tofu.json`, `.tftpl` and
`.hcl` files, typically `backend` and `provider` blocks. Test files
belong in `tf_test.srcs`.None(�
deps�`tf_library` targets included in the deploy's work tree. Those in
the deploy's own package join its root module; others are reached via
`module` blocks in the root module's files.None(�
vars�Dictionary of variable name to string value, written to
`rules_tofu.auto.tfvars.json` in the deploy's package directory. That
filename is reserved in the package. OpenTofu converts strings to
`number` or `bool` where declared; pass lists, maps and objects via
`var_files`.None(�
	var_files�`.tfvars` or `.tfvars.json` files passed to `tofu` via
`-var-file`, including outputs of other rules. Keys must not overlap
with `vars` or other `var_files` entries; duplicates fail
`bazel build`.None(�
data�Files placed in the work tree at their workspace-relative paths for
`file()` and `templatefile()`. `terraform.tfvars`,
`terraform.tfvars.json`, `*.auto.tfvars` and `*.auto.tfvars.json` are
rejected; use `vars` or `var_files`.None(�
	providersx`@tf_providers//<namespace>/<name>` targets required directly
by `srcs`, combined with providers propagated from `deps`.None(�
allow_ephemeral_state�Permit `:<name>.apply` and `:<name>.destroy` when
state lives under `bazel-bin`:
- no `backend` or `cloud` block is declared; or
- `backend "local"` does not set both `path` and `workspace_dir` to
  literal absolute paths outside `bazel-out`.
Defaults to `False`. See
[State and backends](https://github.com/benbirt/rules_tofu#state-and-backends).False(e
fmt_testQEmit `:<name>.fmt_check` when `True` and `srcs` is non-empty;
defaults to `True`.True(�
kwargs�Forwarded to the underlying rules. `visibility`, `tags` and
`testonly` apply to all generated targets; other rule attributes
apply to `:<name>`.(�A root OpenTofu configuration, with targets to plan, apply and destroy it.

The deploy's own package is its root module and must contain at least one
`.tf`, `.tf.json`, `.tofu` or `.tofu.json` file from `srcs` or a
`tf_library` in the same package; `deps` in other packages are reached only
via `module` blocks.

Generated targets:
  - `:<name>`: materialises the work tree, checks for duplicate variable
    keys across `vars` and `var_files`, and runs
    `tofu init -backend=false && tofu validate`.
  - `:<name>.plan`: `bazel run` target that runs `tofu plan`, saving the
    plan file to `<state-dir>/tfplan`.
  - `:<name>.apply`: `bazel run` target that runs a fresh `tofu apply`
    without reading `tfplan`. Prompts unless `-- -auto-approve` is passed.
  - `:<name>.destroy`: `bazel run` target that runs `tofu destroy`. Prompts
    unless `-- -auto-approve` is passed.
  - `:<name>.fmt`: `bazel run` target, emitted when `srcs` is non-empty,
    that reformats main-repository `.tf` and `.tofu` source files in `srcs`
    in place.
  - `:<name>.fmt_check`: `bazel test` target, emitted when `srcs` is
    non-empty and `fmt_test = True`, that checks formatting of `.tf` and
    `.tofu` files in `srcs`, including generated and external files.

Each launcher, such as `bazel-bin/<pkg>/<name>.apply.sh`, can also be
invoked directly in place from any working directory; do not copy or symlink
the script elsewhere. All three share
`bazel-bin/<pkg>/<name>.rules_tofu-state/work/<pkg>` without locking, so run
one command at a time. See
[How it works](https://github.com/benbirt/rules_tofu#how-it-works).
2/
	tf_deploy"@rules_tofu//tf/private:deploy.bzl

nameTarget name. (�
�
srcs�Deploy-local `.tf`, `.tf.json`, `.tofu`, `.tofu.json`, `.tftpl` and
`.hcl` files, typically `backend` and `provider` blocks. Test files
belong in `tf_test.srcs`.None(�
�
deps�`tf_library` targets included in the deploy's work tree. Those in
the deploy's own package join its root module; others are reached via
`module` blocks in the root module's files.None(�
�
vars�Dictionary of variable name to string value, written to
`rules_tofu.auto.tfvars.json` in the deploy's package directory. That
filename is reserved in the package. OpenTofu converts strings to
`number` or `bool` where declared; pass lists, maps and objects via
`var_files`.None(�
�
	var_files�`.tfvars` or `.tfvars.json` files passed to `tofu` via
`-var-file`, including outputs of other rules. Keys must not overlap
with `vars` or other `var_files` entries; duplicates fail
`bazel build`.None(�
�
data�Files placed in the work tree at their workspace-relative paths for
`file()` and `templatefile()`. `terraform.tfvars`,
`terraform.tfvars.json`, `*.auto.tfvars` and `*.auto.tfvars.json` are
rejected; use `vars` or `var_files`.None(�
�
	providersx`@tf_providers//<namespace>/<name>` targets required directly
by `srcs`, combined with providers propagated from `deps`.None(�
�
allow_ephemeral_state�Permit `:<name>.apply` and `:<name>.destroy` when
state lives under `bazel-bin`:
- no `backend` or `cloud` block is declared; or
- `backend "local"` does not set both `path` and `workspace_dir` to
  literal absolute paths outside `bazel-out`.
Defaults to `False`. See
[State and backends](https://github.com/benbirt/rules_tofu#state-and-backends).False(g
e
fmt_testQEmit `:<name>.fmt_check` when `True` and `srcs` is non-empty;
defaults to `True`.True(�
�
kwargs�Forwarded to the underlying rules. `visibility`, `tags` and
`testonly` apply to all generated targets; other rule attributes
apply to `:<name>`.(�4tf_test�
Runs `tofu test` over a module's test files as a Bazel test.

Test files are materialised at their workspace-relative paths alongside
`module`; directories other than `module`'s root are passed via
`-test-directory`. Helper modules loaded by `run` blocks are recorded in
`<name>.modules.json` and installed at `.terraform/modules/modules.json` so
`tofu` fetches nothing.

`tofu test`'s JSON event log is written to Bazel's undeclared test outputs
as `tofu-test.json`. If a `run` block's destroy fails, `tofu test` writes
`errored_test.tfstate` and exits 0; `tf_test` fails the test and copies
that file into undeclared outputs. Pass extra CLI flags via `--test_arg`.
See [Tests](https://github.com/benbirt/rules_tofu#tests).

Generated targets:
  - `:<name>`: `bazel build` validates `module` and `srcs`; `bazel test`
    copies the work tree into `$TEST_TMPDIR` and runs
    `tofu init -backend=false` and `tofu test` offline against the vendored
    providers.
  - `:<name>.fmt`: `bazel run` target that reformats main-repository
    `.tftest.hcl` and `.tofutest.hcl` source files in `srcs` in place.
  - `:<name>.fmt_check`: `bazel test` target, emitted when
    `fmt_test = True`, that checks formatting of `.tftest.hcl` and
    `.tofutest.hcl` files in `srcs`, including generated and external
    files.
*�*
�
tf_test
nameTarget name. (�
srcs�`.tftest.hcl`, `.tofutest.hcl`, `.tftest.json` and
`.tofutest.json` files, all in one directory at or below `module`'s
package directory, such as `module`'s own directory, `tests/` or
`tests/unit`. `.tofutest.hcl` and `.tofutest.json` shadow
`.tftest.hcl` and `.tftest.json` of the same name. (L
module>The `tf_library` or `tf_deploy` under test; may be an `alias`. (�
deps�Helper `tf_library` targets loaded by
`run { module { source = ... } }` blocks, reached by a path relative
to `module`'s package directory or by `module_source`.None(�
data�Files placed in the work tree at their workspace-relative paths for
`file()` and `templatefile()`. `terraform.tfvars`,
`terraform.tfvars.json`, `*.auto.tfvars` and `*.auto.tfvars.json` are
rejected; use `var_files`.None(�
	providers�`@tf_providers//<namespace>/<name>` targets needed beyond
those of `module` and `deps`. `mock_provider` still needs the
provider package for its schema. If `module`'s root directory has no
configuration files, `tofu init` installs no providers; add a file
declaring `required_providers` there when helper modules require
providers.None(�
	var_files�`.tfvars` or `.tfvars.json` files passed via `-var-file` after
a tested `tf_deploy`'s `vars` and `var_files`. Entries here may
override keys from the deploy, and `variables` blocks in test files
take precedence over both.None(�
allow_network�Allow tests to access the network. Defaults to `False`,
adding Bazel's `block-network` tag so accidental cloud calls fail in
the sandbox while plans and mocked applies run offline. When `True`,
the target carries `external` and `requires-network` and is never
cached.False(M
fmt_test9Emit `:<name>.fmt_check` when `True`; defaults to `True`.True(�
kwargs�Forwarded to the underlying rules. `visibility` and `testonly`
apply to all generated targets; other test attributes such as `tags`,
`size` and `timeout` apply to `:<name>`.(�
Runs `tofu test` over a module's test files as a Bazel test.

Test files are materialised at their workspace-relative paths alongside
`module`; directories other than `module`'s root are passed via
`-test-directory`. Helper modules loaded by `run` blocks are recorded in
`<name>.modules.json` and installed at `.terraform/modules/modules.json` so
`tofu` fetches nothing.

`tofu test`'s JSON event log is written to Bazel's undeclared test outputs
as `tofu-test.json`. If a `run` block's destroy fails, `tofu test` writes
`errored_test.tfstate` and exits 0; `tf_test` fails the test and copies
that file into undeclared outputs. Pass extra CLI flags via `--test_arg`.
See [Tests](https://github.com/benbirt/rules_tofu#tests).

Generated targets:
  - `:<name>`: `bazel build` validates `module` and `srcs`; `bazel test`
    copies the work tree into `$TEST_TMPDIR` and runs
    `tofu init -backend=false` and `tofu test` offline against the vendored
    providers.
  - `:<name>.fmt`: `bazel run` target that reformats main-repository
    `.tftest.hcl` and `.tofutest.hcl` source files in `srcs` in place.
  - `:<name>.fmt_check`: `bazel test` target, emitted when
    `fmt_test = True`, that checks formatting of `.tftest.hcl` and
    `.tofutest.hcl` files in `srcs`, including generated and external
    files.
2+
tf_test @rules_tofu//tf/private:test.bzl

nameTarget name. (�
�
srcs�`.tftest.hcl`, `.tofutest.hcl`, `.tftest.json` and
`.tofutest.json` files, all in one directory at or below `module`'s
package directory, such as `module`'s own directory, `tests/` or
`tests/unit`. `.tofutest.hcl` and `.tofutest.json` shadow
`.tftest.hcl` and `.tftest.json` of the same name. (N
L
module>The `tf_library` or `tf_deploy` under test; may be an `alias`. (�
�
deps�Helper `tf_library` targets loaded by
`run { module { source = ... } }` blocks, reached by a path relative
to `module`'s package directory or by `module_source`.None(�
�
data�Files placed in the work tree at their workspace-relative paths for
`file()` and `templatefile()`. `terraform.tfvars`,
`terraform.tfvars.json`, `*.auto.tfvars` and `*.auto.tfvars.json` are
rejected; use `var_files`.None(�
�
	providers�`@tf_providers//<namespace>/<name>` targets needed beyond
those of `module` and `deps`. `mock_provider` still needs the
provider package for its schema. If `module`'s root directory has no
configuration files, `tofu init` installs no providers; add a file
declaring `required_providers` there when helper modules require
providers.None(�
�
	var_files�`.tfvars` or `.tfvars.json` files passed via `-var-file` after
a tested `tf_deploy`'s `vars` and `var_files`. Entries here may
override keys from the deploy, and `variables` blocks in test files
take precedence over both.None(�
�
allow_network�Allow tests to access the network. Defaults to `False`,
adding Bazel's `block-network` tag so accidental cloud calls fail in
the sandbox while plans and mocked applies run offline. When `True`,
the target carries `external` and `requires-network` and is never
cached.False(O
M
fmt_test9Emit `:<name>.fmt_check` when `True`; defaults to `True`.True(�
�
kwargs�Forwarded to the underlying rules. `visibility` and `testonly`
apply to all generated targets; other test attributes such as `tags`,
`size` and `timeout` apply to `:<name>`.(�Rules for OpenTofu and Terraform-compatible configuration.

`tf_library` bundles reusable configuration files, `tf_deploy` binds variable
values and generates `.plan`, `.apply` and `.destroy` targets, and `tf_test`
runs `tofu test` as a Bazel test:

    load("@rules_tofu//tf:defs.bzl", "tf_deploy", "tf_library", "tf_test")

See the [README](https://github.com/benbirt/rules_tofu#rules) for a full guide.�U
(

rules_tofu
tf/modulesextensions.bzl�O
tf_modules�Fetches external OpenTofu modules and exposes each as a `tf_library` under `@tf_modules`.

Registry modules are labelled `@tf_modules//<namespace>/<name>/<system>` in
lower case, or `@tf_modules//<host>/<namespace>/<name>/<system>` for registries
other than `registry.opentofu.org`. Custom hosts must advertise `modules.v1` at
`/.well-known/terraform.json` and return a git or archive download location.
Git and archive modules are labelled `@tf_modules//<name>`. Submodules are
called in HCL with `//<subdir>` while depending on the parent module's label.

Every fetch is pinned:
  - Registry modules record their download location and git commit or archive
    `sha256` in `MODULE.bazel.lock`.
  - Git modules fetch `commit` when set, or resolve `?ref=`, defaulting to
    `HEAD`, on first fetch and record the commit in `MODULE.bazel.lock`.
    Fetching git modules requires `git` on `PATH`.
  - Archive modules verify `sha256`.

Unpacking deletes upstream Bazel files: `.bazelignore`, `BUILD`, `BUILD.bazel`,
`MODULE.bazel`, `REPO.bazel`, `WORKSPACE` and `WORKSPACE.bazel`. It also
excludes `.git/`, `.terraform/`, `.terraform.lock.hcl`, `terraform.tfvars`,
`terraform.tfvars.json`, `*.auto.tfvars` and `*.auto.tfvars.json`, and removes
directory, dangling or external symlinks; `//<subdir>` cannot be a symlink. Git
submodules are not fetched.

Each generated `tf_library` propagates providers from the module's root, its
`modules/` subdirectories, and directories it calls itself. If only a caller
reaches a `//<subdir>` outside `modules/`, declare that submodule's providers on
the caller. External modules called transitively must also be declared with
`tf_modules.module`.

Across the module graph, each `@tf_modules` path resolves once. For registry
modules, the root module's tag wins, else the highest version. Git and archive
declarations sharing a `name` must agree on `source` and must not disagree on
`commit` or `sha256`; an explicit `commit` wins over an unset one.

`tf_modules` scans sources and fetched modules with a Go helper compiled by
`rules_go`'s host Go SDK, honouring `GOPROXY`, `GONOSUMDB`, `GOPRIVATE`,
`GONOPROXY` and `GOSUMDB`; workspaces that register a Go SDK must select a
version at least as new as the `go` directive in `rules_tofu`'s `go.mod`.

Import only `tf_modules` with `use_repo`. See
[From a registry, git or an archive](https://github.com/benbirt/rules_tofu#from-a-registry-git-or-an-archive).J�;
�!

tf_modules�Fetches external OpenTofu modules and exposes each as a `tf_library` under `@tf_modules`.

Registry modules are labelled `@tf_modules//<namespace>/<name>/<system>` in
lower case, or `@tf_modules//<host>/<namespace>/<name>/<system>` for registries
other than `registry.opentofu.org`. Custom hosts must advertise `modules.v1` at
`/.well-known/terraform.json` and return a git or archive download location.
Git and archive modules are labelled `@tf_modules//<name>`. Submodules are
called in HCL with `//<subdir>` while depending on the parent module's label.

Every fetch is pinned:
  - Registry modules record their download location and git commit or archive
    `sha256` in `MODULE.bazel.lock`.
  - Git modules fetch `commit` when set, or resolve `?ref=`, defaulting to
    `HEAD`, on first fetch and record the commit in `MODULE.bazel.lock`.
    Fetching git modules requires `git` on `PATH`.
  - Archive modules verify `sha256`.

Unpacking deletes upstream Bazel files: `.bazelignore`, `BUILD`, `BUILD.bazel`,
`MODULE.bazel`, `REPO.bazel`, `WORKSPACE` and `WORKSPACE.bazel`. It also
excludes `.git/`, `.terraform/`, `.terraform.lock.hcl`, `terraform.tfvars`,
`terraform.tfvars.json`, `*.auto.tfvars` and `*.auto.tfvars.json`, and removes
directory, dangling or external symlinks; `//<subdir>` cannot be a symlink. Git
submodules are not fetched.

Each generated `tf_library` propagates providers from the module's root, its
`modules/` subdirectories, and directories it calls itself. If only a caller
reaches a `//<subdir>` outside `modules/`, declare that submodule's providers on
the caller. External modules called transitively must also be declared with
`tf_modules.module`.

Across the module graph, each `@tf_modules` path resolves once. For registry
modules, the root module's tag wins, else the highest version. Git and archive
declarations sharing a `name` must agree on `source` and must not disagree on
`commit` or `sha256`; an explicit `commit` wins over an unset one.

`tf_modules` scans sources and fetched modules with a Go helper compiled by
`rules_go`'s host Go SDK, honouring `GOPROXY`, `GONOSUMDB`, `GOPRIVATE`,
`GONOPROXY` and `GOSUMDB`; workspaces that register a Go SDK must select a
version at least as new as the `go` directive in `rules_tofu`'s `go.mod`.

Import only `tf_modules` with `use_repo`. See
[From a registry, git or an archive](https://github.com/benbirt/rules_tofu#from-a-registry-git-or-an-archive).�
module�Declare an external OpenTofu module from a registry, git repository or archive for offline use as a `tf_library` under `@tf_modules`.�
source�HCL module `source` address. Registry sources take `[<host>/]<namespace>/<name>/<system>` without `//<subdir>`. Git sources take `git::<url>`, `git://...`, `github.com/<owner>/<repo>` or `git@<host>:<path>`, with optional `//<subdir>` and `?ref=` or `?depth=`. Archive sources take `http://`, `https://` or `file://` URLs ending in `.zip`, `.tar.gz`, `.tgz`, `.tar.bz2`, `.tar.tbz2`, `.tar.xz` or `.txz`, or carrying `?archive=<type>`, with optional `//<subdir>`. S3 via `s3::`, GCS via `gcs::`, Bitbucket via `bitbucket.org/`, Mercurial via `hg::` and `X-Terraform-Get` redirects are not supported. �
version�Exact module version as `X.Y.Z`, e.g. `"5.8.1"`; constraints and prereleases such as `"1.2.0-rc1"` are rejected. Required for registry modules and disallowed for git or archive sources.2""�
name�Module label under `@tf_modules//<name>`, using only ASCII letters, digits, `_`, `-` and `.`. Required for git and archive sources. Disallowed for registry modules, which use `@tf_modules//<namespace>/<name>/<system>` in lower case, prefixed with `<host>/` for hosts other than `registry.opentofu.org`, e.g. `@tf_modules//example.com/acme/vpc/aws`.2""�
commit�Full 40- or 64-character lowercase hex commit SHA to fetch for a git source; abbreviated commit hashes are rejected in both `commit` and `?ref=`. When unset, the commit named by `?ref=`, or `HEAD` when omitted, is resolved on first fetch and recorded in `MODULE.bazel.lock`. Disallowed for non-git sources.2""d
sha256TSHA256 digest of the archive. Required for archive sources and disallowed otherwise.2"""(&@rules_tofu//tf/modules:extensions.bzl�
�
module�Declare an external OpenTofu module from a registry, git repository or archive for offline use as a `tf_library` under `@tf_modules`.�
source�HCL module `source` address. Registry sources take `[<host>/]<namespace>/<name>/<system>` without `//<subdir>`. Git sources take `git::<url>`, `git://...`, `github.com/<owner>/<repo>` or `git@<host>:<path>`, with optional `//<subdir>` and `?ref=` or `?depth=`. Archive sources take `http://`, `https://` or `file://` URLs ending in `.zip`, `.tar.gz`, `.tgz`, `.tar.bz2`, `.tar.tbz2`, `.tar.xz` or `.txz`, or carrying `?archive=<type>`, with optional `//<subdir>`. S3 via `s3::`, GCS via `gcs::`, Bitbucket via `bitbucket.org/`, Mercurial via `hg::` and `X-Terraform-Get` redirects are not supported. �
version�Exact module version as `X.Y.Z`, e.g. `"5.8.1"`; constraints and prereleases such as `"1.2.0-rc1"` are rejected. Required for registry modules and disallowed for git or archive sources.2""�
name�Module label under `@tf_modules//<name>`, using only ASCII letters, digits, `_`, `-` and `.`. Required for git and archive sources. Disallowed for registry modules, which use `@tf_modules//<namespace>/<name>/<system>` in lower case, prefixed with `<host>/` for hosts other than `registry.opentofu.org`, e.g. `@tf_modules//example.com/acme/vpc/aws`.2""�
commit�Full 40- or 64-character lowercase hex commit SHA to fetch for a git source; abbreviated commit hashes are rejected in both `commit` and `?ref=`. When unset, the commit named by `?ref=`, or `HEAD` when omitted, is resolved on first fetch and recorded in `MODULE.bazel.lock`. Disallowed for non-git sources.2""d
sha256TSHA256 digest of the archive. Required for archive sources and disallowed otherwise.2""�
�
source�HCL module `source` address. Registry sources take `[<host>/]<namespace>/<name>/<system>` without `//<subdir>`. Git sources take `git::<url>`, `git://...`, `github.com/<owner>/<repo>` or `git@<host>:<path>`, with optional `//<subdir>` and `?ref=` or `?depth=`. Archive sources take `http://`, `https://` or `file://` URLs ending in `.zip`, `.tar.gz`, `.tgz`, `.tar.bz2`, `.tar.tbz2`, `.tar.xz` or `.txz`, or carrying `?archive=<type>`, with optional `//<subdir>`. S3 via `s3::`, GCS via `gcs::`, Bitbucket via `bitbucket.org/`, Mercurial via `hg::` and `X-Terraform-Get` redirects are not supported. �
�
version�Exact module version as `X.Y.Z`, e.g. `"5.8.1"`; constraints and prereleases such as `"1.2.0-rc1"` are rejected. Required for registry modules and disallowed for git or archive sources.2""�
�
name�Module label under `@tf_modules//<name>`, using only ASCII letters, digits, `_`, `-` and `.`. Required for git and archive sources. Disallowed for registry modules, which use `@tf_modules//<namespace>/<name>/<system>` in lower case, prefixed with `<host>/` for hosts other than `registry.opentofu.org`, e.g. `@tf_modules//example.com/acme/vpc/aws`.2""�
�
commit�Full 40- or 64-character lowercase hex commit SHA to fetch for a git source; abbreviated commit hashes are rejected in both `commit` and `?ref=`. When unset, the commit named by `?ref=`, or `HEAD` when omitted, is resolved on first fetch and recorded in `MODULE.bazel.lock`. Disallowed for non-git sources.2""f
d
sha256TSHA256 digest of the archive. Required for archive sources and disallowed otherwise.2""�Bzlmod module extension that fetches OpenTofu modules for `@tf_modules`.

Exposes external modules from registries, git repositories and archives as
`tf_library` targets so `tofu init` never fetches modules:

    tf_modules = use_extension("@rules_tofu//tf/modules:extensions.bzl", "tf_modules")
    tf_modules.module(source = "terraform-aws-modules/vpc/aws", version = "5.8.1")
    tf_modules.module(
        name = "acme_vpc",
        source = "git::https://github.com/acme/infra.git//vpc?ref=v1.2.0",
    )
    tf_modules.module(
        name = "vpc_archive",
        source = "https://example.com/vpc-1.2.0.tar.gz",
        sha256 = "...",
    )
    use_repo(tf_modules, "tf_modules")

BUILD files then reference each module in `deps`, for example
`@tf_modules//terraform-aws-modules/vpc/aws` or `@tf_modules//acme_vpc`.�_
*

rules_tofutf/providersextensions.bzl�Ztf_providers�Downloads OpenTofu providers and exposes `@tf_providers`.

BUILD files reference providers as `@tf_providers//<namespace>/<name>` in lower
case and without a version. Only providers required by built targets are
fetched, and `tofu init` runs offline against them.

Versions come from `.terraform.lock.hcl` via `from_lock` or from `provider` tags
in `MODULE.bazel`, and the two can be mixed across providers. Archives come from
`registry.opentofu.org` unless a tag sets `url_template`, and every download is
verified against the lock's `zh:` hashes, a tag's `sha256`, or registry digests
recorded in `MODULE.bazel.lock`.

Each provider resolves to one version across the module graph. The root module's
lock or tag wins; otherwise an agreed version or the highest plain numeric
version is selected, comparing dot-separated digit components so `5.70` equals
`5.70.0`. If dependencies request different versions and any is not plain
numeric, such as `2.0.0-rc1` or `v1.2.3`, fetching that provider fails until
the root module selects a version via a tag or `pin`. For the winning version,
`sha256` maps are merged across modules, and conflicting digests or
`url_template` values fail analysis.

`from_lock` parses the lock with a Go helper compiled by `rules_go`'s host Go
SDK, honouring `GOPROXY`, `GONOSUMDB`, `GOPRIVATE`, `GONOPROXY` and `GOSUMDB`;
workspaces that register a Go SDK must select a version at least as new as the
`go` directive in `rules_tofu`'s `go.mod`.

Import only `tf_providers` with `use_repo`. See
[Providers](https://github.com/benbirt/rules_tofu#providers).J�N
�%
tf_providers�Downloads OpenTofu providers and exposes `@tf_providers`.

BUILD files reference providers as `@tf_providers//<namespace>/<name>` in lower
case and without a version. Only providers required by built targets are
fetched, and `tofu init` runs offline against them.

Versions come from `.terraform.lock.hcl` via `from_lock` or from `provider` tags
in `MODULE.bazel`, and the two can be mixed across providers. Archives come from
`registry.opentofu.org` unless a tag sets `url_template`, and every download is
verified against the lock's `zh:` hashes, a tag's `sha256`, or registry digests
recorded in `MODULE.bazel.lock`.

Each provider resolves to one version across the module graph. The root module's
lock or tag wins; otherwise an agreed version or the highest plain numeric
version is selected, comparing dot-separated digit components so `5.70` equals
`5.70.0`. If dependencies request different versions and any is not plain
numeric, such as `2.0.0-rc1` or `v1.2.3`, fetching that provider fails until
the root module selects a version via a tag or `pin`. For the winning version,
`sha256` maps are merged across modules, and conflicting digests or
`url_template` values fail analysis.

`from_lock` parses the lock with a Go helper compiled by `rules_go`'s host Go
SDK, honouring `GOPROXY`, `GONOSUMDB`, `GOPRIVATE`, `GONOPROXY` and `GOSUMDB`;
workspaces that register a Go SDK must select a version at least as new as the
`go` directive in `rules_tofu`'s `go.mod`.

Import only `tf_providers` with `use_repo`. See
[Providers](https://github.com/benbirt/rules_tofu#providers).�
provider�Pin a provider in `MODULE.bazel` when specifying custom SHA256 digests or a download mirror. Root-tagged providers are omitted from the lock by `pin`; a provider both root-tagged and present in the lock fails to fetch until `pin` rewrites the lock or the tag is removed.�
source�Provider source on `registry.opentofu.org` as `<namespace>/<name>`, e.g. `"hashicorp/aws"`. Referenced in BUILD files in lower case as `@tf_providers//<namespace>/<name>`. >
version/Exact provider version string, e.g. `"5.70.0"`. �
sha256�Optional per-platform SHA256 digests of the provider zip, keyed by `<os>_<arch>`: `linux_amd64`, `linux_arm64`, `linux_386`, `darwin_amd64`, `darwin_arm64`, `windows_amd64` or `windows_386`. When set, every listed platform is downloaded when the provider repository is fetched, so list every platform you build on. Without `url_template`, a digest that differs from `registry.opentofu.org` fails the fetch and reports the registry's value. When unset, the registry's digests for whichever of `linux_amd64`, `linux_arm64`, `darwin_amd64`, `darwin_arm64` and `windows_amd64` are published are recorded in `MODULE.bazel.lock`.
2{}�
url_template�Optional mirror URL template for provider zips, using `{namespace}`, `{name}`, `{version}`, `{os}` and `{arch}` placeholders, e.g. `"https://github.com/PostHog/terraform-provider-posthog/releases/download/v{version}/terraform-provider-{name}_{version}_{os}_{arch}.zip"`. Requires `sha256` and skips querying `registry.opentofu.org`, though the provider is still addressed under `registry.opentofu.org`.2""�
	from_lock�Pin providers from a `.terraform.lock.hcl` updated by `bazel run @tf_providers//:pin`, Renovate or Dependabot. Entries must target `registry.opentofu.org`; locks written by `terraform` against `registry.terraform.io` are rejected. `pin` collects `required_providers` across the workspace's `tf_library`, `tf_deploy` and `tf_test` targets and their external `deps`, leaving out directories of a fetched module outside `modules/` that nothing calls, such as its `examples/`. By default `pin` locks the five platforms `from_lock` resolves: `linux_amd64`, `linux_arm64`, `darwin_amd64`, `darwin_arm64` and `windows_amd64`. Pass `-- -platform=<os>_<arch>` to replace that list when a provider omits one of them. Locked providers record nothing in `MODULE.bazel.lock`. Only the root module's `from_lock` is read, at most once; `from_lock` in dependencies is ignored.�
	lock_file�Label of a file named `.terraform.lock.hcl` in the main repository, such as `"//:.terraform.lock.hcl"` or `"//infra:.terraform.lock.hcl"`. Write the label as a string literal rather than building it from a variable. Dependabot's `bazel` updater does not clone the repository. It fetches only the root Bazel files and files named in recognised `MODULE.bazel` attributes such as `lock_file`, together with the `BUILD.bazel` or `BUILD` file beside each, before regenerating `MODULE.bazel.lock`. The lock file need not exist before the first `bazel run @tf_providers//:pin` run. Its directory must be a Bazel package with a `BUILD.bazel` or `BUILD` file, which may be empty. "*(@rules_tofu//tf/providers:extensions.bzl�
�
provider�Pin a provider in `MODULE.bazel` when specifying custom SHA256 digests or a download mirror. Root-tagged providers are omitted from the lock by `pin`; a provider both root-tagged and present in the lock fails to fetch until `pin` rewrites the lock or the tag is removed.�
source�Provider source on `registry.opentofu.org` as `<namespace>/<name>`, e.g. `"hashicorp/aws"`. Referenced in BUILD files in lower case as `@tf_providers//<namespace>/<name>`. >
version/Exact provider version string, e.g. `"5.70.0"`. �
sha256�Optional per-platform SHA256 digests of the provider zip, keyed by `<os>_<arch>`: `linux_amd64`, `linux_arm64`, `linux_386`, `darwin_amd64`, `darwin_arm64`, `windows_amd64` or `windows_386`. When set, every listed platform is downloaded when the provider repository is fetched, so list every platform you build on. Without `url_template`, a digest that differs from `registry.opentofu.org` fails the fetch and reports the registry's value. When unset, the registry's digests for whichever of `linux_amd64`, `linux_arm64`, `darwin_amd64`, `darwin_arm64` and `windows_amd64` are published are recorded in `MODULE.bazel.lock`.
2{}�
url_template�Optional mirror URL template for provider zips, using `{namespace}`, `{name}`, `{version}`, `{os}` and `{arch}` placeholders, e.g. `"https://github.com/PostHog/terraform-provider-posthog/releases/download/v{version}/terraform-provider-{name}_{version}_{os}_{arch}.zip"`. Requires `sha256` and skips querying `registry.opentofu.org`, though the provider is still addressed under `registry.opentofu.org`.2""�
�
source�Provider source on `registry.opentofu.org` as `<namespace>/<name>`, e.g. `"hashicorp/aws"`. Referenced in BUILD files in lower case as `@tf_providers//<namespace>/<name>`. @
>
version/Exact provider version string, e.g. `"5.70.0"`. �
�
sha256�Optional per-platform SHA256 digests of the provider zip, keyed by `<os>_<arch>`: `linux_amd64`, `linux_arm64`, `linux_386`, `darwin_amd64`, `darwin_arm64`, `windows_amd64` or `windows_386`. When set, every listed platform is downloaded when the provider repository is fetched, so list every platform you build on. Without `url_template`, a digest that differs from `registry.opentofu.org` fails the fetch and reports the registry's value. When unset, the registry's digests for whichever of `linux_amd64`, `linux_arm64`, `darwin_amd64`, `darwin_arm64` and `windows_amd64` are published are recorded in `MODULE.bazel.lock`.
2{}�
�
url_template�Optional mirror URL template for provider zips, using `{namespace}`, `{name}`, `{version}`, `{os}` and `{arch}` placeholders, e.g. `"https://github.com/PostHog/terraform-provider-posthog/releases/download/v{version}/terraform-provider-{name}_{version}_{os}_{arch}.zip"`. Requires `sha256` and skips querying `registry.opentofu.org`, though the provider is still addressed under `registry.opentofu.org`.2""�
�
	from_lock�Pin providers from a `.terraform.lock.hcl` updated by `bazel run @tf_providers//:pin`, Renovate or Dependabot. Entries must target `registry.opentofu.org`; locks written by `terraform` against `registry.terraform.io` are rejected. `pin` collects `required_providers` across the workspace's `tf_library`, `tf_deploy` and `tf_test` targets and their external `deps`, leaving out directories of a fetched module outside `modules/` that nothing calls, such as its `examples/`. By default `pin` locks the five platforms `from_lock` resolves: `linux_amd64`, `linux_arm64`, `darwin_amd64`, `darwin_arm64` and `windows_amd64`. Pass `-- -platform=<os>_<arch>` to replace that list when a provider omits one of them. Locked providers record nothing in `MODULE.bazel.lock`. Only the root module's `from_lock` is read, at most once; `from_lock` in dependencies is ignored.�
	lock_file�Label of a file named `.terraform.lock.hcl` in the main repository, such as `"//:.terraform.lock.hcl"` or `"//infra:.terraform.lock.hcl"`. Write the label as a string literal rather than building it from a variable. Dependabot's `bazel` updater does not clone the repository. It fetches only the root Bazel files and files named in recognised `MODULE.bazel` attributes such as `lock_file`, together with the `BUILD.bazel` or `BUILD` file beside each, before regenerating `MODULE.bazel.lock`. The lock file need not exist before the first `bazel run @tf_providers//:pin` run. Its directory must be a Bazel package with a `BUILD.bazel` or `BUILD` file, which may be empty. �
�
	lock_file�Label of a file named `.terraform.lock.hcl` in the main repository, such as `"//:.terraform.lock.hcl"` or `"//infra:.terraform.lock.hcl"`. Write the label as a string literal rather than building it from a variable. Dependabot's `bazel` updater does not clone the repository. It fetches only the root Bazel files and files named in recognised `MODULE.bazel` attributes such as `lock_file`, together with the `BUILD.bazel` or `BUILD` file beside each, before regenerating `MODULE.bazel.lock`. The lock file need not exist before the first `bazel run @tf_providers//:pin` run. Its directory must be a Bazel package with a `BUILD.bazel` or `BUILD` file, which may be empty. �Bzlmod module extension that downloads OpenTofu providers for `@tf_providers`.

Pins provider plugins via `.terraform.lock.hcl` or `MODULE.bazel` tags for
`tf_library`, `tf_deploy` and `tf_test` targets to use offline:

    tf_providers = use_extension("@rules_tofu//tf/providers:extensions.bzl", "tf_providers")
    tf_providers.from_lock(lock_file = "//:.terraform.lock.hcl")
    use_repo(tf_providers, "tf_providers")

BUILD files reference each provider as `@tf_providers//<namespace>/<name>`.�
&

rules_tofu	toolchaintoolchain.bzl�opentofu_toolchain�Wraps an OpenTofu executable as a `rules_tofu` toolchain.

The `tofu` module extension declares one per downloaded release. A root module
may declare its own around any OpenTofu 1.12+ executable and register it with
`register_toolchains` to override the default download; see
[Bringing your own binary](https://github.com/benbirt/rules_tofu#bringing-your-own-binary)."�	
�
opentofu_toolchain�Wraps an OpenTofu executable as a `rules_tofu` toolchain.

The `tofu` module extension declares one per downloaded release. A root module
may declare its own around any OpenTofu 1.12+ executable and register it with
`register_toolchains` to override the default download; see
[Bringing your own binary](https://github.com/benbirt/rules_tofu#bringing-your-own-binary).*
nameA unique name for this target. H
binary:The `tofu` executable; OpenTofu 1.12 or later is required. p
versionaOpenTofu version string, e.g. `"1.12.0"`. Recorded on `TofuInfo` and not checked by `rules_tofu`. �
platform_keyp`<os>_<arch>` key, e.g. `"linux_amd64"`, used to select matching provider packages in each target's plugin tree. ":
opentofu_toolchain$@rules_tofu//toolchain:toolchain.bzl,
*
nameA unique name for this target. J
H
binary:The `tofu` executable; OpenTofu 1.12 or later is required. r
p
versionaOpenTofu version string, e.g. `"1.12.0"`. Recorded on `TofuInfo` and not checked by `rules_tofu`. �
�
platform_keyp`<os>_<arch>` key, e.g. `"linux_amd64"`, used to select matching provider packages in each target's plugin tree. �TofuInfo0Information about a resolved OpenTofu toolchain.2�
�
TofuInfo0Information about a resolved OpenTofu toolchain.&
binaryFile: the `tofu` executable.<
version1string: OpenTofu version string, e.g. `"1.12.0"`.�
platform_keyxstring: `<os>_<arch>` key, e.g. `"linux_amd64"`, used to select matching provider packages in each target's plugin tree."0
TofuInfo$@rules_tofu//toolchain:toolchain.bzl(
&
binaryFile: the `tofu` executable.>
<
version1string: OpenTofu version string, e.g. `"1.12.0"`.�
�
platform_keyxstring: `<os>_<arch>` key, e.g. `"linux_amd64"`, used to select matching provider packages in each target's plugin tree.�OpenTofu toolchain type, provider and rule.

Every `rules_tofu` rule resolves `@rules_tofu//toolchain:toolchain_type` to
obtain `TofuInfo` for the execution platform.�
'

rules_tofu	toolchainextensions.bzl�tofu�Downloads OpenTofu releases and exposes `@tofu_toolchains`.

One OpenTofu version serves the whole build. A single `tofu.version` tag in the
root module wins over dependency requests, and declaring more than one in the
root module is an error. Without a root tag, dependencies that tag a version
must all name the same one; with no tags, the default in `toolchain/versions.bzl`
is used.

`rules_tofu` already registers `@tofu_toolchains//:all`, so a consumer module
needs `use_extension` and `use_repo(tofu, "tofu_toolchains")` only when calling
`tofu.version`. To use a custom binary instead, register an `opentofu_toolchain`
in the root module; see
[The `tofu` binary](https://github.com/benbirt/rules_tofu#the-tofu-binary).J�
�
tofu�Downloads OpenTofu releases and exposes `@tofu_toolchains`.

One OpenTofu version serves the whole build. A single `tofu.version` tag in the
root module wins over dependency requests, and declaring more than one in the
root module is an error. Without a root tag, dependencies that tag a version
must all name the same one; with no tags, the default in `toolchain/versions.bzl`
is used.

`rules_tofu` already registers `@tofu_toolchains//:all`, so a consumer module
needs `use_extension` and `use_repo(tofu, "tofu_toolchains")` only when calling
`tofu.version`. To use a custom binary instead, register an `opentofu_toolchain`
in the root module; see
[The `tofu` binary](https://github.com/benbirt/rules_tofu#the-tofu-binary).�
version*Select the OpenTofu version for the build.�
version�OpenTofu version string, 1.12 or later, e.g. `"1.12.0"`. Must appear in `KNOWN_VERSIONS` in [toolchain/versions.bzl](https://github.com/benbirt/rules_tofu/blob/main/toolchain/versions.bzl). "'%@rules_tofu//toolchain:extensions.bzl�
�
version*Select the OpenTofu version for the build.�
version�OpenTofu version string, 1.12 or later, e.g. `"1.12.0"`. Must appear in `KNOWN_VERSIONS` in [toolchain/versions.bzl](https://github.com/benbirt/rules_tofu/blob/main/toolchain/versions.bzl). �
�
version�OpenTofu version string, 1.12 or later, e.g. `"1.12.0"`. Must appear in `KNOWN_VERSIONS` in [toolchain/versions.bzl](https://github.com/benbirt/rules_tofu/blob/main/toolchain/versions.bzl). �Bzlmod module extension that downloads OpenTofu and provides `@tofu_toolchains`.

`rules_tofu` registers `@tofu_toolchains//:all` at the default OpenTofu
version automatically. Call the extension only when choosing a specific
version:

    tofu = use_extension("@rules_tofu//toolchain:extensions.bzl", "tofu")
    tofu.version(version = "1.12.0")
    use_repo(tofu, "tofu_toolchains") 