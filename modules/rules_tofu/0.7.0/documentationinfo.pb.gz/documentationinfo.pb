��


rules_tofutfdefs.bzl�\
tf_library� A reusable bundle of OpenTofu and Terraform-compatible configuration files.

A `tf_library` carries no variable values and has no `.plan`, `.apply` or
`.destroy` targets; use `tf_deploy` for a root configuration.

Files in the main repository are materialised at their workspace-relative
paths, so same-package files see each other directly. Call modules in other
workspace packages by relative paths starting with `./` or `../`, such as
`../../infra/dns`.

Module calls are resolved offline at build time:
  - A `module` block's `source` may refer to local values and variables that
    declare a `default`; variables take their defaults when the manifest is
    built, and `source` must be a literal string in modules fetched by
    `tf_modules.module`. `override` and `*_override` files replace `source`
    on matching `module` blocks in the same target.
  - Relative paths starting with `./` or `../` resolve within the caller's
    own Bazel repository in the work tree and cannot cross into another
    Bazel repository.
  - Other `source` strings match the `tf_library` in `deps` whose
    normalised `module_source` equals the address or leaves the shortest
    `//<subdir>` suffix, so a submodule's own library takes precedence over
    its parent module's library.
  - Registry addresses normalise to lower-case
    `<host>/<namespace>/<name>/<system>`, defaulting `<host>` to
    `registry.opentofu.org`.
  - Git shorthands normalise as OpenTofu parses them:
    `github.com/<owner>/<repo>[/<subdir>]` becomes
    `git::https://github.com/<owner>/<repo>.git[//<subdir>]`, and
    `git@<host>:<path>` becomes `git::ssh://git@<host>/<path>`. `?ref=`
    must match, while `?depth=` is ignored.
  - Archive URLs match by archive format and URL after stripping
    `?archive=`, so `.tgz` and `?archive=tar.gz` share `tar.gz`; any other
    query parameters must match.
  - A library with `module_source` also satisfies calls from its own files
    to that `module_source` with `//<subdir>`.

`rules_tofu` writes `<name>.modules.json` at build time, copies it to
`.terraform/modules/modules.json`, and runs `tofu init -get=false`.
`bazel build` fails on:
  - Configuration that OpenTofu cannot load (including a `module` `source`
    referencing a variable without a default, or an override file without
    the block it overrides in the same target), or a `module` `source` of an
    unsupported type.
  - A local `./` or `../` call to a directory outside the work tree, in
    another Bazel repository, or absent from `deps`.
  - A non-local `module` call that no `tf_library` in `deps` matches.
  - A direct `module_source` dependency in another package that no call in
    `srcs` reaches, either by `module_source` or by `./` or `../` to one of
    its directories. Calls in other targets' files do not count.
  - Two libraries in `deps` with the same normalised `module_source`.
  - A registry `module` call whose library has an empty `module_version` or
    fails the caller's `version` constraint.
  - A `module_source` call landing in a directory with no `.tf`,
    `.tf.json`, `.tofu` or `.tofu.json` files. Local `./` or `../` calls
    may target directories in the work tree that hold no configuration
    files.
  - A module call cycle.
  - A non-built-in provider required by `srcs` (in `required_providers` or
    implied by a resource, data source or `provider` block) missing from
    this target's `providers`, even when `deps` supply it. An entry outside
    `registry.opentofu.org` always fails because `rules_tofu` cannot vendor
    it. Built-in providers such as `terraform.io/builtin/terraform` are
    exempt.
  - A non-local `module` call in `srcs` to a library not in direct `deps`,
    except self-calls to `//<subdir>`.
  - A `./` or `../` call in `srcs` to a directory with no files from
    `srcs`, `data` or direct `deps`.
  - A configuration file in `data`.
See [Modules](https://github.com/benbirt/rules_tofu#modules) and
[Strict dependencies](https://github.com/benbirt/rules_tofu#strict-dependencies).

`:<name>` is the only generated target. `bazel build` materialises the work
tree and runs `tofu init -backend=false && tofu validate` after `deps` pass
their checks.
*�;
�.

tf_library
nameTarget name. (�
srcs�`.tf`, `.tf.json`, `.tofu`, `.tofu.json`, `.tftpl` and `.hcl`
files. `.tofu` and `.tofu.json` shadow `.tf` and `.tf.json` of the
same name. OpenTofu ignores dot-prefixed filenames.
`.terraform.lock.hcl` is rejected in `srcs` and `data`, and test
files belong in `tf_test.srcs`.None(�
deps�`tf_library` targets whose files, providers and `module_source`
mappings are passed on to dependants. Other libraries called by
`srcs` must be listed here directly.None(�
data�Files placed in the work tree at their workspace-relative paths for
`file()` and `templatefile()`. Configuration files are rejected; list
them in `srcs`. `terraform.tfvars`,
`terraform.tfvars.json`, `*.auto.tfvars` and `*.auto.tfvars.json` are
rejected; pass variable files via `var_files` on `tf_deploy` or
`tf_test`.None(�
	providers�`@tf_providers//<namespace>/<name>` targets required by `srcs`.
Also installed in dependants' plugin trees for this library's files.
See
[Strict dependencies](https://github.com/benbirt/rules_tofu#strict-dependencies).None(�
module_source�Address by which HCL `module` blocks call this library or
`//<subdir>` within it when it is in the caller's `deps`. Required to
call a library from another Bazel repository.None(�
module_version�Version checked against callers' `version` constraints
when `module_source` is a registry address. Required for registry
addresses. Defaults to the version of the Bazel module that holds the
library when `module_source` is set, or `""` otherwise; setting it
without `module_source` is an error.None(8
kwargs,Attributes forwarded to the underlying rule.(� A reusable bundle of OpenTofu and Terraform-compatible configuration files.

A `tf_library` carries no variable values and has no `.plan`, `.apply` or
`.destroy` targets; use `tf_deploy` for a root configuration.

Files in the main repository are materialised at their workspace-relative
paths, so same-package files see each other directly. Call modules in other
workspace packages by relative paths starting with `./` or `../`, such as
`../../infra/dns`.

Module calls are resolved offline at build time:
  - A `module` block's `source` may refer to local values and variables that
    declare a `default`; variables take their defaults when the manifest is
    built, and `source` must be a literal string in modules fetched by
    `tf_modules.module`. `override` and `*_override` files replace `source`
    on matching `module` blocks in the same target.
  - Relative paths starting with `./` or `../` resolve within the caller's
    own Bazel repository in the work tree and cannot cross into another
    Bazel repository.
  - Other `source` strings match the `tf_library` in `deps` whose
    normalised `module_source` equals the address or leaves the shortest
    `//<subdir>` suffix, so a submodule's own library takes precedence over
    its parent module's library.
  - Registry addresses normalise to lower-case
    `<host>/<namespace>/<name>/<system>`, defaulting `<host>` to
    `registry.opentofu.org`.
  - Git shorthands normalise as OpenTofu parses them:
    `github.com/<owner>/<repo>[/<subdir>]` becomes
    `git::https://github.com/<owner>/<repo>.git[//<subdir>]`, and
    `git@<host>:<path>` becomes `git::ssh://git@<host>/<path>`. `?ref=`
    must match, while `?depth=` is ignored.
  - Archive URLs match by archive format and URL after stripping
    `?archive=`, so `.tgz` and `?archive=tar.gz` share `tar.gz`; any other
    query parameters must match.
  - A library with `module_source` also satisfies calls from its own files
    to that `module_source` with `//<subdir>`.

`rules_tofu` writes `<name>.modules.json` at build time, copies it to
`.terraform/modules/modules.json`, and runs `tofu init -get=false`.
`bazel build` fails on:
  - Configuration that OpenTofu cannot load (including a `module` `source`
    referencing a variable without a default, or an override file without
    the block it overrides in the same target), or a `module` `source` of an
    unsupported type.
  - A local `./` or `../` call to a directory outside the work tree, in
    another Bazel repository, or absent from `deps`.
  - A non-local `module` call that no `tf_library` in `deps` matches.
  - A direct `module_source` dependency in another package that no call in
    `srcs` reaches, either by `module_source` or by `./` or `../` to one of
    its directories. Calls in other targets' files do not count.
  - Two libraries in `deps` with the same normalised `module_source`.
  - A registry `module` call whose library has an empty `module_version` or
    fails the caller's `version` constraint.
  - A `module_source` call landing in a directory with no `.tf`,
    `.tf.json`, `.tofu` or `.tofu.json` files. Local `./` or `../` calls
    may target directories in the work tree that hold no configuration
    files.
  - A module call cycle.
  - A non-built-in provider required by `srcs` (in `required_providers` or
    implied by a resource, data source or `provider` block) missing from
    this target's `providers`, even when `deps` supply it. An entry outside
    `registry.opentofu.org` always fails because `rules_tofu` cannot vendor
    it. Built-in providers such as `terraform.io/builtin/terraform` are
    exempt.
  - A non-local `module` call in `srcs` to a library not in direct `deps`,
    except self-calls to `//<subdir>`.
  - A `./` or `../` call in `srcs` to a directory with no files from
    `srcs`, `data` or direct `deps`.
  - A configuration file in `data`.
See [Modules](https://github.com/benbirt/rules_tofu#modules) and
[Strict dependencies](https://github.com/benbirt/rules_tofu#strict-dependencies).

`:<name>` is the only generated target. `bazel build` materialises the work
tree and runs `tofu init -backend=false && tofu validate` after `deps` pass
their checks.
21

tf_library#@rules_tofu//tf/private:library.bzl

nameTarget name. (�
�
srcs�`.tf`, `.tf.json`, `.tofu`, `.tofu.json`, `.tftpl` and `.hcl`
files. `.tofu` and `.tofu.json` shadow `.tf` and `.tf.json` of the
same name. OpenTofu ignores dot-prefixed filenames.
`.terraform.lock.hcl` is rejected in `srcs` and `data`, and test
files belong in `tf_test.srcs`.None(�
�
deps�`tf_library` targets whose files, providers and `module_source`
mappings are passed on to dependants. Other libraries called by
`srcs` must be listed here directly.None(�
�
data�Files placed in the work tree at their workspace-relative paths for
`file()` and `templatefile()`. Configuration files are rejected; list
them in `srcs`. `terraform.tfvars`,
`terraform.tfvars.json`, `*.auto.tfvars` and `*.auto.tfvars.json` are
rejected; pass variable files via `var_files` on `tf_deploy` or
`tf_test`.None(�
�
	providers�`@tf_providers//<namespace>/<name>` targets required by `srcs`.
Also installed in dependants' plugin trees for this library's files.
See
[Strict dependencies](https://github.com/benbirt/rules_tofu#strict-dependencies).None(�
�
module_source�Address by which HCL `module` blocks call this library or
`//<subdir>` within it when it is in the caller's `deps`. Required to
call a library from another Bazel repository.None(�
�
module_version�Version checked against callers' `version` constraints
when `module_source` is a registry address. Required for registry
addresses. Defaults to the version of the Bazel module that holds the
library when `module_source` is set, or `""` otherwise; setting it
without `module_source` is an error.None(:
8
kwargs,Attributes forwarded to the underlying rule.(�8	tf_deploy�
A root OpenTofu configuration, with targets to plan, apply and destroy it.

The deploy's own package is its root module and must contain at least one
`.tf`, `.tf.json`, `.tofu` or `.tofu.json` file from `srcs` or a
`tf_library` in the same package; `deps` in other packages are reached only
via `module` blocks.

Generated targets:
  - `:<name>`: materialises the work tree, checks for duplicate variable
    keys across `vars` and `var_files`, and runs
    `tofu init -backend=false && tofu validate` after `deps` pass their
    checks. Launchers require these checks before running.
  - `:<name>.plan`: `bazel run` target that runs `tofu plan`, saving the
    plan file to `<state-dir>/tfplan`.
  - `:<name>.apply`: `bazel run` target that runs a fresh `tofu apply`
    without reading `tfplan`. Prompts unless `-- -auto-approve` is passed.
  - `:<name>.destroy`: `bazel run` target that runs `tofu destroy`. Prompts
    unless `-- -auto-approve` is passed.

Each launcher, such as `bazel-bin/<pkg>/<name>.apply.sh`, can also be
invoked directly in place from any working directory; do not copy or symlink
the script elsewhere. All three share
`bazel-bin/<pkg>/<name>.rules_tofu-state/work/<pkg>` without locking, so run
one command at a time. See
[How it works](https://github.com/benbirt/rules_tofu#how-it-works).
*�-
�
	tf_deploy
nameTarget name. (�
srcs�Deploy-local `.tf`, `.tf.json`, `.tofu`, `.tofu.json`, `.tftpl` and
`.hcl` files, typically `backend` and `provider` blocks. Test files
belong in `tf_test.srcs`.None(�
deps�`tf_library` targets included in the deploy's work tree. Those in
the deploy's own package join its root module; others are reached via
`module` blocks in the root module's files.None(�
vars�Dictionary of variable name to string value passed to `tofu` as
`-var=<name>=<value>` before `var_files`. `string` and untyped
variables receive the text as written, without interpolation. `number`
and `bool` values are converted. Any other type, including `any`, is
parsed as an OpenTofu expression, such as `"["a", "b"]"` for a
`list(string)` or `""hello""` for a string in `any`. See
[Variables and data files](https://github.com/benbirt/rules_tofu#variables-and-data-files).None(�
	var_files�`.tfvars` or `.tfvars.json` files passed to `tofu` via
`-var-file`, including outputs of other rules. Keys must not overlap
with `vars` or other `var_files` entries; duplicates fail
`bazel build`.None(�
data�Files placed in the work tree at their workspace-relative paths for
`file()` and `templatefile()`. Configuration files are rejected; list
them in `srcs`. `terraform.tfvars`,
`terraform.tfvars.json`, `*.auto.tfvars` and `*.auto.tfvars.json` are
rejected; use `vars` or `var_files`.None(�
	providers�`@tf_providers//<namespace>/<name>` targets required by `srcs`.
Providers from `deps` are also installed in the plugin tree. See
[Strict dependencies](https://github.com/benbirt/rules_tofu#strict-dependencies).None(�
allow_ephemeral_state�Permit `:<name>.apply` and `:<name>.destroy` when
state is ephemeral: either no `backend` or `cloud` block is declared,
or `backend "local"` does not resolve both `path` and `workspace_dir`
to absolute paths outside `bazel-out`. `:<name>.plan` is never gated.
Defaults to `False`. See
[State and backends](https://github.com/benbirt/rules_tofu#state-and-backends).False(�
kwargs�Forwarded to the underlying rules. `visibility`, `tags` and
`testonly` apply to all generated targets; other rule attributes
apply to `:<name>`.(�
A root OpenTofu configuration, with targets to plan, apply and destroy it.

The deploy's own package is its root module and must contain at least one
`.tf`, `.tf.json`, `.tofu` or `.tofu.json` file from `srcs` or a
`tf_library` in the same package; `deps` in other packages are reached only
via `module` blocks.

Generated targets:
  - `:<name>`: materialises the work tree, checks for duplicate variable
    keys across `vars` and `var_files`, and runs
    `tofu init -backend=false && tofu validate` after `deps` pass their
    checks. Launchers require these checks before running.
  - `:<name>.plan`: `bazel run` target that runs `tofu plan`, saving the
    plan file to `<state-dir>/tfplan`.
  - `:<name>.apply`: `bazel run` target that runs a fresh `tofu apply`
    without reading `tfplan`. Prompts unless `-- -auto-approve` is passed.
  - `:<name>.destroy`: `bazel run` target that runs `tofu destroy`. Prompts
    unless `-- -auto-approve` is passed.

Each launcher, such as `bazel-bin/<pkg>/<name>.apply.sh`, can also be
invoked directly in place from any working directory; do not copy or symlink
the script elsewhere. All three share
`bazel-bin/<pkg>/<name>.rules_tofu-state/work/<pkg>` without locking, so run
one command at a time. See
[How it works](https://github.com/benbirt/rules_tofu#how-it-works).
2/
	tf_deploy"@rules_tofu//tf/private:deploy.bzl

nameTarget name. (�
�
srcs�Deploy-local `.tf`, `.tf.json`, `.tofu`, `.tofu.json`, `.tftpl` and
`.hcl` files, typically `backend` and `provider` blocks. Test files
belong in `tf_test.srcs`.None(�
�
deps�`tf_library` targets included in the deploy's work tree. Those in
the deploy's own package join its root module; others are reached via
`module` blocks in the root module's files.None(�
�
vars�Dictionary of variable name to string value passed to `tofu` as
`-var=<name>=<value>` before `var_files`. `string` and untyped
variables receive the text as written, without interpolation. `number`
and `bool` values are converted. Any other type, including `any`, is
parsed as an OpenTofu expression, such as `"["a", "b"]"` for a
`list(string)` or `""hello""` for a string in `any`. See
[Variables and data files](https://github.com/benbirt/rules_tofu#variables-and-data-files).None(�
�
	var_files�`.tfvars` or `.tfvars.json` files passed to `tofu` via
`-var-file`, including outputs of other rules. Keys must not overlap
with `vars` or other `var_files` entries; duplicates fail
`bazel build`.None(�
�
data�Files placed in the work tree at their workspace-relative paths for
`file()` and `templatefile()`. Configuration files are rejected; list
them in `srcs`. `terraform.tfvars`,
`terraform.tfvars.json`, `*.auto.tfvars` and `*.auto.tfvars.json` are
rejected; use `vars` or `var_files`.None(�
�
	providers�`@tf_providers//<namespace>/<name>` targets required by `srcs`.
Providers from `deps` are also installed in the plugin tree. See
[Strict dependencies](https://github.com/benbirt/rules_tofu#strict-dependencies).None(�
�
allow_ephemeral_state�Permit `:<name>.apply` and `:<name>.destroy` when
state is ephemeral: either no `backend` or `cloud` block is declared,
or `backend "local"` does not resolve both `path` and `workspace_dir`
to absolute paths outside `bazel-out`. `:<name>.plan` is never gated.
Defaults to `False`. See
[State and backends](https://github.com/benbirt/rules_tofu#state-and-backends).False(�
�
kwargs�Forwarded to the underlying rules. `visibility`, `tags` and
`testonly` apply to all generated targets; other rule attributes
apply to `:<name>`.(�2tf_test�Runs `tofu test` over a module's test files as a Bazel test.

Test files are materialised at their workspace-relative paths alongside
`module`; directories other than `module`'s root are passed via
`-test-directory`. Helper modules loaded by `run` blocks are recorded in
`<name>.modules.json` and installed at `.terraform/modules/modules.json` so
`tofu` fetches nothing.

`tofu test`'s JSON event log is written to Bazel's undeclared test outputs
as `tofu-test.json`. If a `run` block's destroy fails, `tofu test` writes
`errored_test.tfstate` and exits 0; `tf_test` fails the test and copies
that file into undeclared outputs. Pass extra CLI flags via `--test_arg`.
See [Tests](https://github.com/benbirt/rules_tofu#tests).

`:<name>` is the only generated target. `bazel build` validates `module`
and `srcs` after `module` and `deps` pass their checks. `bazel test`
mirrors the work tree as symlinks into a new directory under
`$TEST_TMPDIR` after validation passes. It then runs
`tofu init -backend=false` and `tofu test` offline in `module`'s package
directory there against the vendored providers.
*�)
�
tf_test
nameTarget name. (�
srcs�`.tftest.hcl`, `.tofutest.hcl`, `.tftest.json` and
`.tofutest.json` files, all in one directory at or below `module`'s
package directory, such as `module`'s own directory, `tests/` or
`tests/unit`. `.tofutest.hcl` and `.tofutest.json` shadow
`.tftest.hcl` and `.tftest.json` of the same name. (L
module>The `tf_library` or `tf_deploy` under test; may be an `alias`. (�
deps�Helper `tf_library` targets loaded by
`run { module { source = ... } }` blocks, reached by a path relative
to `module`'s package directory or by `module_source`. Include any
library from `module`'s `deps` that a `run` block in `srcs` loads
directly. See
[Strict dependencies](https://github.com/benbirt/rules_tofu#strict-dependencies).None(�
data�Files placed in the work tree at their workspace-relative paths for
`file()` and `templatefile()`. Configuration files are rejected; list
them in the `srcs` of a `tf_library` in `deps`. `terraform.tfvars`,
`terraform.tfvars.json`, `*.auto.tfvars` and `*.auto.tfvars.json` are
rejected; use `var_files`.None(�
	providers�`@tf_providers//<namespace>/<name>` targets needed beyond
those of `module` and `deps`. `mock_provider` still needs the
provider package for its schema. If `module`'s root directory has no
configuration files, `tofu init` installs no providers; add a file
declaring `required_providers` there when helper modules require
providers.None(�
	var_files�`.tfvars` or `.tfvars.json` files passed via `-var-file` after
a tested `tf_deploy`'s `vars` and `var_files`. Entries here may
override keys from the deploy, and `variables` blocks in test files
take precedence over both.None(�
allow_network�Allow tests to access the network. Defaults to `False`,
adding Bazel's `block-network` tag so accidental cloud calls fail in
the sandbox while plans and mocked applies run offline. When `True`,
the target carries `external` and `requires-network` and is never
cached.False(c
kwargsWAttributes forwarded to the underlying test rule, such as
`tags`, `size` and `timeout`.(�Runs `tofu test` over a module's test files as a Bazel test.

Test files are materialised at their workspace-relative paths alongside
`module`; directories other than `module`'s root are passed via
`-test-directory`. Helper modules loaded by `run` blocks are recorded in
`<name>.modules.json` and installed at `.terraform/modules/modules.json` so
`tofu` fetches nothing.

`tofu test`'s JSON event log is written to Bazel's undeclared test outputs
as `tofu-test.json`. If a `run` block's destroy fails, `tofu test` writes
`errored_test.tfstate` and exits 0; `tf_test` fails the test and copies
that file into undeclared outputs. Pass extra CLI flags via `--test_arg`.
See [Tests](https://github.com/benbirt/rules_tofu#tests).

`:<name>` is the only generated target. `bazel build` validates `module`
and `srcs` after `module` and `deps` pass their checks. `bazel test`
mirrors the work tree as symlinks into a new directory under
`$TEST_TMPDIR` after validation passes. It then runs
`tofu init -backend=false` and `tofu test` offline in `module`'s package
directory there against the vendored providers.
2+
tf_test @rules_tofu//tf/private:test.bzl

nameTarget name. (�
�
srcs�`.tftest.hcl`, `.tofutest.hcl`, `.tftest.json` and
`.tofutest.json` files, all in one directory at or below `module`'s
package directory, such as `module`'s own directory, `tests/` or
`tests/unit`. `.tofutest.hcl` and `.tofutest.json` shadow
`.tftest.hcl` and `.tftest.json` of the same name. (N
L
module>The `tf_library` or `tf_deploy` under test; may be an `alias`. (�
�
deps�Helper `tf_library` targets loaded by
`run { module { source = ... } }` blocks, reached by a path relative
to `module`'s package directory or by `module_source`. Include any
library from `module`'s `deps` that a `run` block in `srcs` loads
directly. See
[Strict dependencies](https://github.com/benbirt/rules_tofu#strict-dependencies).None(�
�
data�Files placed in the work tree at their workspace-relative paths for
`file()` and `templatefile()`. Configuration files are rejected; list
them in the `srcs` of a `tf_library` in `deps`. `terraform.tfvars`,
`terraform.tfvars.json`, `*.auto.tfvars` and `*.auto.tfvars.json` are
rejected; use `var_files`.None(�
�
	providers�`@tf_providers//<namespace>/<name>` targets needed beyond
those of `module` and `deps`. `mock_provider` still needs the
provider package for its schema. If `module`'s root directory has no
configuration files, `tofu init` installs no providers; add a file
declaring `required_providers` there when helper modules require
providers.None(�
�
	var_files�`.tfvars` or `.tfvars.json` files passed via `-var-file` after
a tested `tf_deploy`'s `vars` and `var_files`. Entries here may
override keys from the deploy, and `variables` blocks in test files
take precedence over both.None(�
�
allow_network�Allow tests to access the network. Defaults to `False`,
adding Bazel's `block-network` tag so accidental cloud calls fail in
the sandbox while plans and mocked applies run offline. When `True`,
the target carries `external` and `requires-network` and is never
cached.False(e
c
kwargsWAttributes forwarded to the underlying test rule, such as
`tags`, `size` and `timeout`.(�Rules for OpenTofu and Terraform-compatible configuration.

`tf_library` bundles reusable configuration files, `tf_deploy` binds variable
values and generates `.plan`, `.apply` and `.destroy` targets, and `tf_test`
runs `tofu test` as a Bazel test:

    load("@rules_tofu//tf:defs.bzl", "tf_deploy", "tf_library", "tf_test")

See the [README](https://github.com/benbirt/rules_tofu#rules) for a full guide.�n
(

rules_tofu
tf/modulesextensions.bzl�g
tf_modules�Fetches external OpenTofu modules and exposes each as a `tf_library` under `@tf_modules`.

Registry modules are labelled `@tf_modules//<namespace>/<name>/<system>` in
lower case, or `@tf_modules//<host>/<namespace>/<name>/<system>` for registries
other than `registry.opentofu.org`. Custom hosts must advertise `modules.v1` at
`/.well-known/terraform.json` and return a git or archive download location.
Git and archive modules are labelled `@tf_modules//<name>`. Submodules are
called in HCL with `//<subdir>` while depending on the parent module's label.

Every fetch is pinned:
  - Registry modules record their download location and git commit or archive
    `sha256` in `MODULE.bazel.lock`.
  - Git modules fetch `commit` when set, or resolve `?ref=`, defaulting to
    `HEAD`, on first fetch and record the commit in `MODULE.bazel.lock`.
    Fetching git modules requires `git` on `PATH`.
  - Archive modules verify `sha256`.

A module is re-fetched only when its own `source` or pin changes. Changing its
`subdirs`, or declaring, removing or changing other modules, at most
regenerates its `BUILD` files.

Unpacking deletes upstream Bazel files: `.bazelignore`, `BUILD`, `BUILD.bazel`,
`MODULE.bazel`, `REPO.bazel`, `WORKSPACE` and `WORKSPACE.bazel`. It also
excludes `.git/`, `.terraform/`, `.terraform.lock.hcl`, `terraform.tfvars`,
`terraform.tfvars.json`, `*.auto.tfvars` and `*.auto.tfvars.json`, and removes
directory, dangling or external symlinks; `//<subdir>` cannot be a symlink. Git
submodules are not fetched.

Each generated `tf_library` lists as `srcs` the configuration files of the
module's root, its `modules/` subdirectories, directories it calls itself and
directories named in `subdirs`, and carries the non-built-in providers OpenTofu
reports for them, whether declared in `required_providers` or implied by
resources, data sources or `provider` blocks. A served directory that OpenTofu
cannot load fails the fetch with OpenTofu's diagnostics. Other files are `data`,
except `.tftest.hcl`, `.tofutest.hcl`, `.tftest.json` and `.tofutest.json` test
files, which are left out. Configuration files in other directories, such as
examples, are also left out and cannot be called. External modules called
transitively must also be declared with `tf_modules.module`. Each fetched
module is validated at its root directory before anything that depends on it,
failing in `TofuValidate @tf_modules//<path>` even if callers use only a
`//<subdir>`.

Across the module graph, each `@tf_modules` path resolves once. For registry
modules, the root module's tag wins, else the highest version. Git and archive
declarations sharing a `name` must agree on `source` and must not disagree on
`commit` or `sha256`; an explicit `commit` wins over an unset one.

`tf_modules` parses source addresses and scans fetched modules with a Go helper
compiled by `rules_go`'s host Go SDK, honouring `GOPROXY`, `GONOSUMDB`,
`GOPRIVATE`, `GONOPROXY` and `GOSUMDB`; workspaces that register a Go SDK must
select a version at least as new as the `go` directive in `rules_tofu`'s
`go.mod`. Scanning fetched modules also runs the pinned OpenTofu release
selected by `tofu.version`, or the default in `toolchain/versions.bzl`, even
when the build uses a custom `opentofu_toolchain`, so the host must be a
platform with a pinned release.

Import only `tf_modules` with `use_repo`. See
[From a registry, git or an archive](https://github.com/benbirt/rules_tofu#from-a-registry-git-or-an-archive).J�L
�,

tf_modules�Fetches external OpenTofu modules and exposes each as a `tf_library` under `@tf_modules`.

Registry modules are labelled `@tf_modules//<namespace>/<name>/<system>` in
lower case, or `@tf_modules//<host>/<namespace>/<name>/<system>` for registries
other than `registry.opentofu.org`. Custom hosts must advertise `modules.v1` at
`/.well-known/terraform.json` and return a git or archive download location.
Git and archive modules are labelled `@tf_modules//<name>`. Submodules are
called in HCL with `//<subdir>` while depending on the parent module's label.

Every fetch is pinned:
  - Registry modules record their download location and git commit or archive
    `sha256` in `MODULE.bazel.lock`.
  - Git modules fetch `commit` when set, or resolve `?ref=`, defaulting to
    `HEAD`, on first fetch and record the commit in `MODULE.bazel.lock`.
    Fetching git modules requires `git` on `PATH`.
  - Archive modules verify `sha256`.

A module is re-fetched only when its own `source` or pin changes. Changing its
`subdirs`, or declaring, removing or changing other modules, at most
regenerates its `BUILD` files.

Unpacking deletes upstream Bazel files: `.bazelignore`, `BUILD`, `BUILD.bazel`,
`MODULE.bazel`, `REPO.bazel`, `WORKSPACE` and `WORKSPACE.bazel`. It also
excludes `.git/`, `.terraform/`, `.terraform.lock.hcl`, `terraform.tfvars`,
`terraform.tfvars.json`, `*.auto.tfvars` and `*.auto.tfvars.json`, and removes
directory, dangling or external symlinks; `//<subdir>` cannot be a symlink. Git
submodules are not fetched.

Each generated `tf_library` lists as `srcs` the configuration files of the
module's root, its `modules/` subdirectories, directories it calls itself and
directories named in `subdirs`, and carries the non-built-in providers OpenTofu
reports for them, whether declared in `required_providers` or implied by
resources, data sources or `provider` blocks. A served directory that OpenTofu
cannot load fails the fetch with OpenTofu's diagnostics. Other files are `data`,
except `.tftest.hcl`, `.tofutest.hcl`, `.tftest.json` and `.tofutest.json` test
files, which are left out. Configuration files in other directories, such as
examples, are also left out and cannot be called. External modules called
transitively must also be declared with `tf_modules.module`. Each fetched
module is validated at its root directory before anything that depends on it,
failing in `TofuValidate @tf_modules//<path>` even if callers use only a
`//<subdir>`.

Across the module graph, each `@tf_modules` path resolves once. For registry
modules, the root module's tag wins, else the highest version. Git and archive
declarations sharing a `name` must agree on `source` and must not disagree on
`commit` or `sha256`; an explicit `commit` wins over an unset one.

`tf_modules` parses source addresses and scans fetched modules with a Go helper
compiled by `rules_go`'s host Go SDK, honouring `GOPROXY`, `GONOSUMDB`,
`GOPRIVATE`, `GONOPROXY` and `GOSUMDB`; workspaces that register a Go SDK must
select a version at least as new as the `go` directive in `rules_tofu`'s
`go.mod`. Scanning fetched modules also runs the pinned OpenTofu release
selected by `tofu.version`, or the default in `toolchain/versions.bzl`, even
when the build uses a custom `opentofu_toolchain`, so the host must be a
platform with a pinned release.

Import only `tf_modules` with `use_repo`. See
[From a registry, git or an archive](https://github.com/benbirt/rules_tofu#from-a-registry-git-or-an-archive).�
module�Declare an external OpenTofu module from a registry, git repository or archive for offline use as a `tf_library` under `@tf_modules`.�
source�HCL module `source` address. Registry sources take `[<host>/]<namespace>/<name>/<system>` without `//<subdir>`. Git sources take `git::<url>`, `git://...`, `github.com/<owner>/<repo>` or `git@<host>:<path>`, with optional `//<subdir>` and `?ref=` or `?depth=`. Archive sources take `http://`, `https://` or `file://` URLs ending in `.zip`, `.tar.gz`, `.tgz`, `.tar.bz2`, `.tar.tbz2`, `.tar.xz` or `.txz`, or carrying `?archive=<type>`, with optional `//<subdir>`. S3 via `s3::`, GCS via `gcs::`, Bitbucket via `bitbucket.org/`, Mercurial via `hg::` and `X-Terraform-Get` redirects are not supported. �
version�Exact module version as `X.Y.Z`, e.g. `"5.8.1"`; constraints and prereleases such as `"1.2.0-rc1"` are rejected. Required for registry modules and disallowed for git or archive sources.2""�
name�Module label under `@tf_modules//<name>`, using only ASCII letters, digits, `_`, `-` and `.`. Required for git and archive sources. Disallowed for registry modules, which use `@tf_modules//<namespace>/<name>/<system>` in lower case, prefixed with `<host>/` for hosts other than `registry.opentofu.org`, e.g. `@tf_modules//example.com/acme/vpc/aws`.2""�
commit�Full 40- or 64-character lowercase hex commit SHA to fetch for a git source; abbreviated commit hashes are rejected in both `commit` and `?ref=`. When unset, the commit named by `?ref=`, or `HEAD` when omitted, is resolved on first fetch and recorded in `MODULE.bazel.lock`. Disallowed for non-git sources.2""d
sha256TSHA256 digest of the archive. Required for archive sources and disallowed otherwise.2""�
subdirs�Directories of the module, relative to it, that callers reach with `//<subdir>`, e.g. `["peering"]`. Needed only for a directory outside `modules/` that the module does not call itself. Each must hold configuration files and cannot be a symlink. Tags declaring the same module, at the version selected for a registry module, are combined.2[]"(&@rules_tofu//tf/modules:extensions.bzl� 
�
module�Declare an external OpenTofu module from a registry, git repository or archive for offline use as a `tf_library` under `@tf_modules`.�
source�HCL module `source` address. Registry sources take `[<host>/]<namespace>/<name>/<system>` without `//<subdir>`. Git sources take `git::<url>`, `git://...`, `github.com/<owner>/<repo>` or `git@<host>:<path>`, with optional `//<subdir>` and `?ref=` or `?depth=`. Archive sources take `http://`, `https://` or `file://` URLs ending in `.zip`, `.tar.gz`, `.tgz`, `.tar.bz2`, `.tar.tbz2`, `.tar.xz` or `.txz`, or carrying `?archive=<type>`, with optional `//<subdir>`. S3 via `s3::`, GCS via `gcs::`, Bitbucket via `bitbucket.org/`, Mercurial via `hg::` and `X-Terraform-Get` redirects are not supported. �
version�Exact module version as `X.Y.Z`, e.g. `"5.8.1"`; constraints and prereleases such as `"1.2.0-rc1"` are rejected. Required for registry modules and disallowed for git or archive sources.2""�
name�Module label under `@tf_modules//<name>`, using only ASCII letters, digits, `_`, `-` and `.`. Required for git and archive sources. Disallowed for registry modules, which use `@tf_modules//<namespace>/<name>/<system>` in lower case, prefixed with `<host>/` for hosts other than `registry.opentofu.org`, e.g. `@tf_modules//example.com/acme/vpc/aws`.2""�
commit�Full 40- or 64-character lowercase hex commit SHA to fetch for a git source; abbreviated commit hashes are rejected in both `commit` and `?ref=`. When unset, the commit named by `?ref=`, or `HEAD` when omitted, is resolved on first fetch and recorded in `MODULE.bazel.lock`. Disallowed for non-git sources.2""d
sha256TSHA256 digest of the archive. Required for archive sources and disallowed otherwise.2""�
subdirs�Directories of the module, relative to it, that callers reach with `//<subdir>`, e.g. `["peering"]`. Needed only for a directory outside `modules/` that the module does not call itself. Each must hold configuration files and cannot be a symlink. Tags declaring the same module, at the version selected for a registry module, are combined.2[]�
�
source�HCL module `source` address. Registry sources take `[<host>/]<namespace>/<name>/<system>` without `//<subdir>`. Git sources take `git::<url>`, `git://...`, `github.com/<owner>/<repo>` or `git@<host>:<path>`, with optional `//<subdir>` and `?ref=` or `?depth=`. Archive sources take `http://`, `https://` or `file://` URLs ending in `.zip`, `.tar.gz`, `.tgz`, `.tar.bz2`, `.tar.tbz2`, `.tar.xz` or `.txz`, or carrying `?archive=<type>`, with optional `//<subdir>`. S3 via `s3::`, GCS via `gcs::`, Bitbucket via `bitbucket.org/`, Mercurial via `hg::` and `X-Terraform-Get` redirects are not supported. �
�
version�Exact module version as `X.Y.Z`, e.g. `"5.8.1"`; constraints and prereleases such as `"1.2.0-rc1"` are rejected. Required for registry modules and disallowed for git or archive sources.2""�
�
name�Module label under `@tf_modules//<name>`, using only ASCII letters, digits, `_`, `-` and `.`. Required for git and archive sources. Disallowed for registry modules, which use `@tf_modules//<namespace>/<name>/<system>` in lower case, prefixed with `<host>/` for hosts other than `registry.opentofu.org`, e.g. `@tf_modules//example.com/acme/vpc/aws`.2""�
�
commit�Full 40- or 64-character lowercase hex commit SHA to fetch for a git source; abbreviated commit hashes are rejected in both `commit` and `?ref=`. When unset, the commit named by `?ref=`, or `HEAD` when omitted, is resolved on first fetch and recorded in `MODULE.bazel.lock`. Disallowed for non-git sources.2""f
d
sha256TSHA256 digest of the archive. Required for archive sources and disallowed otherwise.2""�
�
subdirs�Directories of the module, relative to it, that callers reach with `//<subdir>`, e.g. `["peering"]`. Needed only for a directory outside `modules/` that the module does not call itself. Each must hold configuration files and cannot be a symlink. Tags declaring the same module, at the version selected for a registry module, are combined.2[]�Bzlmod module extension that fetches OpenTofu modules for `@tf_modules`.

Exposes external modules from registries, git repositories and archives as
`tf_library` targets so `tofu init` never fetches modules:

    tf_modules = use_extension("@rules_tofu//tf/modules:extensions.bzl", "tf_modules")
    tf_modules.module(source = "terraform-aws-modules/vpc/aws", version = "5.8.1")
    tf_modules.module(
        name = "acme_vpc",
        source = "git::https://github.com/acme/infra.git//vpc?ref=v1.2.0",
    )
    tf_modules.module(
        name = "vpc_archive",
        source = "https://example.com/vpc-1.2.0.tar.gz",
        sha256 = "...",
    )
    use_repo(tf_modules, "tf_modules")

BUILD files then reference each module in `deps`, for example
`@tf_modules//terraform-aws-modules/vpc/aws` or `@tf_modules//acme_vpc`.�S
*

rules_tofutf/providersextensions.bzl�Ntf_providers�Downloads OpenTofu providers and exposes `@tf_providers`.

BUILD files reference providers as `@tf_providers//<namespace>/<name>` in lower
case and without a version. `tofu init` runs offline against them.

Only the root module pins providers. Providers on `registry.opentofu.org` are
pinned by `.terraform.lock.hcl` via `from_lock`. Off-registry providers are
pinned by `provider` tags setting `source`, `version`, `url_template` and
`sha256`. `from_lock` and `provider` tags in dependencies are ignored, so the
root module locks or tags every provider its dependencies use. Nothing about
providers is recorded in `MODULE.bazel.lock`.

`from_lock` parses the lock with a Go helper compiled by `rules_go`'s host Go
SDK, honouring `GOPROXY`, `GONOSUMDB`, `GOPRIVATE`, `GONOPROXY` and `GOSUMDB`;
workspaces that register a Go SDK must select a version at least as new as the
`go` directive in `rules_tofu`'s `go.mod`.

Import only `tf_providers` with `use_repo`. See
[Providers](https://github.com/benbirt/rules_tofu#providers).J�F
�!
tf_providers�Downloads OpenTofu providers and exposes `@tf_providers`.

BUILD files reference providers as `@tf_providers//<namespace>/<name>` in lower
case and without a version. `tofu init` runs offline against them.

Only the root module pins providers. Providers on `registry.opentofu.org` are
pinned by `.terraform.lock.hcl` via `from_lock`. Off-registry providers are
pinned by `provider` tags setting `source`, `version`, `url_template` and
`sha256`. `from_lock` and `provider` tags in dependencies are ignored, so the
root module locks or tags every provider its dependencies use. Nothing about
providers is recorded in `MODULE.bazel.lock`.

`from_lock` parses the lock with a Go helper compiled by `rules_go`'s host Go
SDK, honouring `GOPROXY`, `GONOSUMDB`, `GOPRIVATE`, `GONOPROXY` and `GOSUMDB`;
workspaces that register a Go SDK must select a version at least as new as the
`go` directive in `rules_tofu`'s `go.mod`.

Import only `tf_providers` with `use_repo`. See
[Providers](https://github.com/benbirt/rules_tofu#providers).�

provider�Pin a provider outside `registry.opentofu.org` (such as a fork, an in-house provider or a vendor build published elsewhere) by URL template and per-platform SHA-256 digests. Providers on `registry.opentofu.org` are pinned with `from_lock` instead. Only root-module tags are used; tags in dependencies are ignored. `pin` excludes tagged providers from the lock; a provider present in both a root tag and the lock fails when used until the tag is removed or `pin` rewrites the lock.�
source�Provider source as `<namespace>/<name>`, e.g. `"acme/widgets"`, matching `required_providers`. OpenTofu still addresses the provider as `registry.opentofu.org/<namespace>/<name>`. Referenced in BUILD files in lower case as `@tf_providers//<namespace>/<name>`. =
version.Exact provider version string, e.g. `"1.4.0"`. �
url_template�Required. Download URL template for each platform's zip, using `{namespace}`, `{name}`, `{version}`, `{os}` and `{arch}` placeholders, e.g. `"https://github.com/acme/terraform-provider-widgets/releases/download/v{version}/terraform-provider-{name}_{version}_{os}_{arch}.zip"`.2""�
sha256�Required. Map of `<os>_<arch>` platform key (`linux_amd64`, `linux_arm64`, `darwin_amd64`, `darwin_arm64`, `windows_amd64`) to each zip's SHA-256 digest. Building on an unlisted execution platform fails analysis naming the listed platforms.
2{}�
	from_lock�Pin providers from a `.terraform.lock.hcl` updated by `bazel run @tf_providers//:pin`, Renovate or Dependabot. Entries for hosts other than `registry.opentofu.org`, such as those `terraform` writes against `registry.terraform.io`, fail a build only when a target uses them; run `pin` to rewrite the lock against `registry.opentofu.org`. `pin` reads the configuration files in `srcs` of each `tf_library`, `tf_deploy` and `tf_test` target in the workspace and their external `deps` with OpenTofu (building generated configuration files when present), locking every provider they declare or imply. A fetched module's examples are in no target, so they are left out. By default `pin` locks the five platforms `from_lock` resolves: `linux_amd64`, `linux_arm64`, `darwin_amd64`, `darwin_arm64` and `windows_amd64`. Pass `-- -platform=<os>_<arch>` to replace that list when a provider omits one of them. Providers record nothing in `MODULE.bazel.lock`. Only the root module's `from_lock` is read, at most once; `from_lock` in dependencies is ignored.�
	lock_file�Label of a file named `.terraform.lock.hcl` in the main repository, such as `"//:.terraform.lock.hcl"` or `"//infra:.terraform.lock.hcl"`. Write the label as a string literal rather than building it from a variable. Dependabot's `bazel` updater does not clone the repository. It fetches only the root Bazel files and files named in recognised `MODULE.bazel` attributes such as `lock_file`, together with the `BUILD.bazel` or `BUILD` file beside each, before regenerating `MODULE.bazel.lock`. The lock file need not exist before the first `bazel run @tf_providers//:pin` run. Its directory must be a Bazel package with a `BUILD.bazel` or `BUILD` file, which may be empty. "*(@rules_tofu//tf/providers:extensions.bzl�
�

provider�Pin a provider outside `registry.opentofu.org` (such as a fork, an in-house provider or a vendor build published elsewhere) by URL template and per-platform SHA-256 digests. Providers on `registry.opentofu.org` are pinned with `from_lock` instead. Only root-module tags are used; tags in dependencies are ignored. `pin` excludes tagged providers from the lock; a provider present in both a root tag and the lock fails when used until the tag is removed or `pin` rewrites the lock.�
source�Provider source as `<namespace>/<name>`, e.g. `"acme/widgets"`, matching `required_providers`. OpenTofu still addresses the provider as `registry.opentofu.org/<namespace>/<name>`. Referenced in BUILD files in lower case as `@tf_providers//<namespace>/<name>`. =
version.Exact provider version string, e.g. `"1.4.0"`. �
url_template�Required. Download URL template for each platform's zip, using `{namespace}`, `{name}`, `{version}`, `{os}` and `{arch}` placeholders, e.g. `"https://github.com/acme/terraform-provider-widgets/releases/download/v{version}/terraform-provider-{name}_{version}_{os}_{arch}.zip"`.2""�
sha256�Required. Map of `<os>_<arch>` platform key (`linux_amd64`, `linux_arm64`, `darwin_amd64`, `darwin_arm64`, `windows_amd64`) to each zip's SHA-256 digest. Building on an unlisted execution platform fails analysis naming the listed platforms.
2{}�
�
source�Provider source as `<namespace>/<name>`, e.g. `"acme/widgets"`, matching `required_providers`. OpenTofu still addresses the provider as `registry.opentofu.org/<namespace>/<name>`. Referenced in BUILD files in lower case as `@tf_providers//<namespace>/<name>`. ?
=
version.Exact provider version string, e.g. `"1.4.0"`. �
�
url_template�Required. Download URL template for each platform's zip, using `{namespace}`, `{name}`, `{version}`, `{os}` and `{arch}` placeholders, e.g. `"https://github.com/acme/terraform-provider-widgets/releases/download/v{version}/terraform-provider-{name}_{version}_{os}_{arch}.zip"`.2""�
�
sha256�Required. Map of `<os>_<arch>` platform key (`linux_amd64`, `linux_arm64`, `darwin_amd64`, `darwin_arm64`, `windows_amd64`) to each zip's SHA-256 digest. Building on an unlisted execution platform fails analysis naming the listed platforms.
2{}�
�
	from_lock�Pin providers from a `.terraform.lock.hcl` updated by `bazel run @tf_providers//:pin`, Renovate or Dependabot. Entries for hosts other than `registry.opentofu.org`, such as those `terraform` writes against `registry.terraform.io`, fail a build only when a target uses them; run `pin` to rewrite the lock against `registry.opentofu.org`. `pin` reads the configuration files in `srcs` of each `tf_library`, `tf_deploy` and `tf_test` target in the workspace and their external `deps` with OpenTofu (building generated configuration files when present), locking every provider they declare or imply. A fetched module's examples are in no target, so they are left out. By default `pin` locks the five platforms `from_lock` resolves: `linux_amd64`, `linux_arm64`, `darwin_amd64`, `darwin_arm64` and `windows_amd64`. Pass `-- -platform=<os>_<arch>` to replace that list when a provider omits one of them. Providers record nothing in `MODULE.bazel.lock`. Only the root module's `from_lock` is read, at most once; `from_lock` in dependencies is ignored.�
	lock_file�Label of a file named `.terraform.lock.hcl` in the main repository, such as `"//:.terraform.lock.hcl"` or `"//infra:.terraform.lock.hcl"`. Write the label as a string literal rather than building it from a variable. Dependabot's `bazel` updater does not clone the repository. It fetches only the root Bazel files and files named in recognised `MODULE.bazel` attributes such as `lock_file`, together with the `BUILD.bazel` or `BUILD` file beside each, before regenerating `MODULE.bazel.lock`. The lock file need not exist before the first `bazel run @tf_providers//:pin` run. Its directory must be a Bazel package with a `BUILD.bazel` or `BUILD` file, which may be empty. �
�
	lock_file�Label of a file named `.terraform.lock.hcl` in the main repository, such as `"//:.terraform.lock.hcl"` or `"//infra:.terraform.lock.hcl"`. Write the label as a string literal rather than building it from a variable. Dependabot's `bazel` updater does not clone the repository. It fetches only the root Bazel files and files named in recognised `MODULE.bazel` attributes such as `lock_file`, together with the `BUILD.bazel` or `BUILD` file beside each, before regenerating `MODULE.bazel.lock`. The lock file need not exist before the first `bazel run @tf_providers//:pin` run. Its directory must be a Bazel package with a `BUILD.bazel` or `BUILD` file, which may be empty. �Bzlmod module extension that downloads OpenTofu providers for `@tf_providers`.

Pins provider plugins for `tf_library`, `tf_deploy` and `tf_test` targets to
use offline. Providers on `registry.opentofu.org` are pinned via
`.terraform.lock.hcl`; off-registry providers use `tf_providers.provider`:

    tf_providers = use_extension("@rules_tofu//tf/providers:extensions.bzl", "tf_providers")
    tf_providers.from_lock(lock_file = "//:.terraform.lock.hcl")
    use_repo(tf_providers, "tf_providers")

BUILD files reference each provider as `@tf_providers//<namespace>/<name>`.�
&

rules_tofu	toolchaintoolchain.bzl�
opentofu_toolchain�Wraps an OpenTofu executable as a `rules_tofu` toolchain.

The `tofu` module extension declares one per downloaded release. A root module
may declare its own around any OpenTofu 1.12+ executable and register it with
`register_toolchains` to override the default download; see
[Bringing your own binary](https://github.com/benbirt/rules_tofu#bringing-your-own-binary)."�
�
opentofu_toolchain�Wraps an OpenTofu executable as a `rules_tofu` toolchain.

The `tofu` module extension declares one per downloaded release. A root module
may declare its own around any OpenTofu 1.12+ executable and register it with
`register_toolchains` to override the default download; see
[Bringing your own binary](https://github.com/benbirt/rules_tofu#bringing-your-own-binary).*
nameA unique name for this target. H
binary:The `tofu` executable; OpenTofu 1.12 or later is required. p
versionaOpenTofu version string, e.g. `"1.12.0"`. Recorded on `TofuInfo` and not checked by `rules_tofu`. ":
opentofu_toolchain$@rules_tofu//toolchain:toolchain.bzl,
*
nameA unique name for this target. J
H
binary:The `tofu` executable; OpenTofu 1.12 or later is required. r
p
versionaOpenTofu version string, e.g. `"1.12.0"`. Recorded on `TofuInfo` and not checked by `rules_tofu`. �TofuInfo0Information about a resolved OpenTofu toolchain.2�
�
TofuInfo0Information about a resolved OpenTofu toolchain.&
binaryFile: the `tofu` executable.<
version1string: OpenTofu version string, e.g. `"1.12.0"`."0
TofuInfo$@rules_tofu//toolchain:toolchain.bzl(
&
binaryFile: the `tofu` executable.>
<
version1string: OpenTofu version string, e.g. `"1.12.0"`.�OpenTofu toolchain type, provider and rule.

Every `rules_tofu` rule resolves `@rules_tofu//toolchain:toolchain_type` to
obtain `TofuInfo` for the execution platform.�
'

rules_tofu	toolchainextensions.bzl�tofu�Downloads OpenTofu releases and exposes `@tofu_toolchains`.

One OpenTofu version serves the whole build. A single `tofu.version` tag in the
root module wins over dependency requests, and declaring more than one in the
root module is an error. Without a root tag, dependencies that tag a version
must all name the same one; with no tags, the default in `toolchain/versions.bzl`
is used.

`rules_tofu` already registers `@tofu_toolchains//:all`, so a consumer module
needs `use_extension` and `use_repo(tofu, "tofu_toolchains")` only when calling
`tofu.version`. To use a custom binary instead, register an `opentofu_toolchain`
in the root module; see
[The `tofu` binary](https://github.com/benbirt/rules_tofu#the-tofu-binary).J�
�
tofu�Downloads OpenTofu releases and exposes `@tofu_toolchains`.

One OpenTofu version serves the whole build. A single `tofu.version` tag in the
root module wins over dependency requests, and declaring more than one in the
root module is an error. Without a root tag, dependencies that tag a version
must all name the same one; with no tags, the default in `toolchain/versions.bzl`
is used.

`rules_tofu` already registers `@tofu_toolchains//:all`, so a consumer module
needs `use_extension` and `use_repo(tofu, "tofu_toolchains")` only when calling
`tofu.version`. To use a custom binary instead, register an `opentofu_toolchain`
in the root module; see
[The `tofu` binary](https://github.com/benbirt/rules_tofu#the-tofu-binary).�
version*Select the OpenTofu version for the build.�
version�OpenTofu version string, 1.12 or later, e.g. `"1.12.0"`. Must appear in `KNOWN_VERSIONS` in [toolchain/versions.bzl](https://github.com/benbirt/rules_tofu/blob/main/toolchain/versions.bzl). "'%@rules_tofu//toolchain:extensions.bzl�
�
version*Select the OpenTofu version for the build.�
version�OpenTofu version string, 1.12 or later, e.g. `"1.12.0"`. Must appear in `KNOWN_VERSIONS` in [toolchain/versions.bzl](https://github.com/benbirt/rules_tofu/blob/main/toolchain/versions.bzl). �
�
version�OpenTofu version string, 1.12 or later, e.g. `"1.12.0"`. Must appear in `KNOWN_VERSIONS` in [toolchain/versions.bzl](https://github.com/benbirt/rules_tofu/blob/main/toolchain/versions.bzl). �Bzlmod module extension that downloads OpenTofu and provides `@tofu_toolchains`.

`rules_tofu` registers `@tofu_toolchains//:all` at the default OpenTofu
version automatically. Call the extension only when choosing a specific
version:

    tofu = use_extension("@rules_tofu//toolchain:extensions.bzl", "tofu")
    tofu.version(version = "1.12.0")
    use_repo(tofu, "tofu_toolchains") 